STARTcraft AI v47.1

v47의 앞마당 벙커 방어 기능을 유지하고 MSVC C2664 컴파일 오류를 수정했습니다.

1. 스타크래프트, StarterBot, Pluto를 모두 종료합니다.
2. upgrade_ai_v47_1.cmd를 실행합니다.
3. SUCCESS: AI v47.1 compiled and arena updated를 확인합니다.
4. 기존 run_STARTcraft_vs_Pluto.cmd를 실행합니다.
5. 경기 후 AI_v47_1_construction.csv, 리플레이, pluto.log, pluto_infer.log를 보내주세요.
