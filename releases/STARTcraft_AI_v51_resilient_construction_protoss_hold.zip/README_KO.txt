STARTcraft AI v51 - resilient construction and Protoss hold

1. Close StarCraft, StarterBot, and Pluto.
2. Run upgrade_ai_v51.cmd.
3. Wait for: SUCCESS: AI v51 compiled and arena updated
4. Run the existing run_STARTcraft_vs_Pluto.cmd.

Changes:
- Prepare one main-entrance bunker against early Protoss pressure without waiting for two scouted Gateways.
- Restore an accepted but stalled construction command every 6 game seconds.
- Keep the v50 natural defense, factory reserve, matched-expansion defense, and duplicate-order tracking.
- Construction log: AI_reports\AI_v51_construction.csv
