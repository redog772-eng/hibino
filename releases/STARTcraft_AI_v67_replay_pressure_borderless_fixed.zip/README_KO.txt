STARTcraft v67 - 리플레이 AI / 복구된 전체화면 창모드 실행기

[이미 v67을 설치한 경우]
게임과 봇을 종료하고 이 새 ZIP을 새 폴더에 풀어 run_STARTcraft_vs_Pluto.cmd를 실행하세요.
AI를 다시 설치할 필요가 없습니다.

[처음 설치하고 경기하기]
1. StarCraft / StarterBot / Pluto를 모두 종료합니다.
2. 이 ZIP을 새 폴더에 압축 해제합니다.
3. START_MATCH.cmd를 실행합니다.
   AI를 백업하고 Windows에서 컴파일한 뒤 Pluto 경기를 시작합니다.
   기존 STARTcraft / Pluto 경기 환경, Python 3, 기존 MSBuild 설치가 필요합니다.
   기본 설치 위치: C:\Users\User\starcraft-api\STARTcraft

AI만 설치하려면 upgrade_ai_v67.cmd를 실행합니다.
설치가 끝난 뒤 재경기는 run_STARTcraft_vs_Pluto.cmd만 실행하면 됩니다.
기존 v54-v66 및 같은 v67 소스를 확인한 뒤 설치합니다. 출처 불명 소스는 덮어쓰지 않습니다.
실패 시 ERROR 위의 메시지와 AI_v67_build.log를 확인하세요.

[리플레이에서 반영한 부분]
원본: qweklqwekqweqwe(T) vs Trap[kS](P), Aiolos 1.0b, 7,445프레임.
테란의 1배럭/1팩토리, 초반 마린, SCV 지원 공격, 벌처 2대,
전진 벙커, 머신숍, 첫 탱크 및 스파이더 마인 우선 흐름을 구현했습니다.
원본 명령: 팩토리 3382, 벌처 4640/5167, 전진 벙커 5292/5380(재요청),
머신숍 5763, 탱크 6795, 마인 연구 7252프레임.
생산 명령 반복 클릭을 실제 생산 수로 세지 않았습니다.

실제 동작은 자원, 기술 선행 조건과 공급에 맞춰 진행합니다.
지도 좌표와 프레임별 명령을 그대로 재생하지 않습니다.
적 본진을 정찰로 찾은 뒤 공격하며 SCV는 최대 8기를 지원대로 보냅니다.
최소 8기의 경제 인원을 남기고, 본진 위협이나 부상 시 복귀합니다.
건설 SCV는 공격대에서 제외합니다. 전진 벙커는 현장 지원과 건설 가능 위치가 필요합니다.
7,200프레임 이후 SCV 공격 지원을 종료하고 경제로 복귀합니다.
12,000프레임 이후에는 기존 장기전/확장 제어로 전환합니다.
따라서 원본과 동일한 타이밍/유닛 수/결과를 보장하는 재현은 아닙니다.

[화면 설정]
사용자가 제공한 STARTcraft_borderless_fullscreen_v3_fixed.zip의 실행기와
BWAPI 설정 도우미를 그대로 사용합니다. BWAPI의 작은 기본 창모드를 OFF로 두고
기존 cnc-ddraw가 전체화면 창모드와 확대를 담당합니다.
cnc-ddraw를 다운로드/재설치하지 않으며 기존 ddraw.dll / ddraw.ini를 수정하지 않습니다.
이미 복구된 cnc-ddraw 파일이 양쪽 게임 폴더에 있어야 합니다.
BWAPI INI는 백업 후 전체화면 창모드 실행기에 맞는 네이티브 OFF 설정을 적용합니다.

[검증]
현재 소스에 대해 seed 670001로 1,000개 새 제어기 시나리오를 실행했습니다.
800건은 탱크/마인 단계 도달, 200건은 길/건설 차단 조건이며 검사 실패 0입니다.
새 제어기 전체 C++ 본문을 추출해 모의 자원/명령 환경에서 실행했습니다.
기존 초기 생산/경로/이동 복구/공중 확장 구성 요소 검사도 통과했습니다.
공식 BWAPI 4.4.0 헤더로 새 제어기 문법 검사를 통과했습니다.
설치/체크섬/버전 확인/백업/실행파일 반영/실패 시 복원은 모의 빌드로 검사합니다.
실제 지형, 충돌, 전투 피해, 광물 채취 이동, Windows 전체 빌드와 실전 경기는 미검증입니다.
검사 결과는 승률이 아닙니다. 기존 arena 지도는 유지되므로 원본 Aiolos와 다를 수 있습니다.

[경기 후 보내줄 파일]
arena\STARTcraft_vs_Pluto\host\Replays\STARTcraft_vs_Pluto.rep
AI_reports\AI_v59_construction.csv (기존 파일명 유지, 새 행 version=67)
이 로그의 REPLAY_STATE / REPLAY_PROXY / REPLAY_VULTURE / REPLAY_SHOP /
REPLAY_HANDOFF와 건설 상태를 리플레이와 대조할 수 있습니다.
