STARTcraft vs Pluto 로컬 1대1 실행기

필요 조건
- StarCraft 1.16.1 / BWAPI 4.4.0이 설치된 기존 STARTcraft 폴더
- 현재 STARTcraft v40 StarterBot.exe
- Pluto v2.0의 pluto.zip과 pluto_weights.bin (100MB 이상)
- AVX2를 지원하는 64비트 Windows PC, 여유 RAM 약 2GB

사용법
1. 스타크래프트와 StarterBot을 모두 종료합니다.
2. pluto.zip과 pluto_weights.bin을 이 폴더 또는 다운로드 폴더에 둡니다.
3. setup_STARTcraft_vs_Pluto.cmd를 한 번 실행합니다.
4. SUCCESS가 표시되면 run_STARTcraft_vs_Pluto.cmd를 실행합니다.

설치기는 기존 파일을 변경하지 않습니다. STARTcraft 폴더 아래
arena\STARTcraft_vs_Pluto에 독립된 경기용 복사본 두 개를 만듭니다.

기본 경기 설정
- STARTcraft: Terran
- Pluto: Random
- 지도: Backrooms, Destination, 2인용 지도 순으로 자동 선택
- 방식: BWAPI Local PC 1대1 Melee

결과 위치
- 리플레이: arena\STARTcraft_vs_Pluto\host\Replays\STARTcraft_vs_Pluto.rep
- Pluto 로그: arena\STARTcraft_vs_Pluto\pluto\pluto.log
- STARTcraft 보고서: arena\STARTcraft_vs_Pluto\host\AI_reports

다른 STARTcraft 경로를 쓰는 경우 CMD 창에서 다음처럼 실행할 수 있습니다.
setup_STARTcraft_vs_Pluto.cmd -Root "D:\경로\STARTcraft"
run_STARTcraft_vs_Pluto.cmd -Root "D:\경로\STARTcraft"

