param(
    [string]$Root = 'C:\Users\User\starcraft-api\STARTcraft',
    [string]$Weights = ''
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$arenaRoot = Join-Path $Root 'arena\STARTcraft_vs_Pluto'
$hostRoot = Join-Path $arenaRoot 'host'
$guestRoot = Join-Path $arenaRoot 'pluto'

function Require-File([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "$Label not found: $Path"
    }
}

function Find-Weights {
    if ($Weights) {
        return [IO.Path]::GetFullPath($Weights)
    }
    $direct = @(
        (Join-Path $packageRoot 'pluto_weights.bin'),
        (Join-Path $Root 'pluto_weights.bin'),
        (Join-Path $Root 'bwapi-data\AI\pluto\pluto_weights.bin'),
        (Join-Path $env:USERPROFILE 'Downloads\pluto_weights.bin'),
        (Join-Path $env:USERPROFILE 'Desktop\pluto_weights.bin')
    )
    foreach ($candidate in $direct) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    foreach ($folder in @((Join-Path $env:USERPROFILE 'Downloads'), (Join-Path $env:USERPROFILE 'Desktop'))) {
        if (Test-Path -LiteralPath $folder -PathType Container) {
            $found = Get-ChildItem -LiteralPath $folder -Filter 'pluto_weights.bin' -File -Recurse -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($found) { return $found.FullName }
        }
    }
    throw 'pluto_weights.bin was not found. Put it beside setup_STARTcraft_vs_Pluto.cmd and run setup again.'
}

function Find-PlutoFile([string]$Name) {
    $direct = @(
        (Join-Path $packageRoot $Name),
        (Join-Path $Root $Name),
        (Join-Path $env:USERPROFILE "Downloads\$Name"),
        (Join-Path $env:USERPROFILE "Desktop\$Name")
    )
    foreach ($candidate in $direct) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    foreach ($folder in @((Join-Path $env:USERPROFILE 'Downloads'), (Join-Path $env:USERPROFILE 'Desktop'))) {
        if (Test-Path -LiteralPath $folder -PathType Container) {
            $found = Get-ChildItem -LiteralPath $folder -Filter $Name -File -Recurse -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($found) { return $found.FullName }
        }
    }
    return $null
}

function Resolve-PlutoPrograms {
    $dll = Find-PlutoFile 'pluto.dll'
    $infer = Find-PlutoFile 'pluto_infer.exe'
    if ($dll -and $infer) { return @($dll, $infer) }

    $zip = Find-PlutoFile 'pluto.zip'
    if (-not $zip) { $zip = Find-PlutoFile 'pluto-v2.0.zip' }
    if (-not $zip) {
        throw 'pluto.zip was not found. Put pluto.zip beside setup_STARTcraft_vs_Pluto.cmd and run setup again.'
    }
    $extract = Join-Path $env:TEMP 'STARTcraft_Pluto_v2_extract'
    if (Test-Path -LiteralPath $extract) { Remove-Item -LiteralPath $extract -Recurse -Force }
    Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force
    $dllItem = Get-ChildItem -LiteralPath $extract -Filter 'pluto.dll' -File -Recurse | Select-Object -First 1
    $inferItem = Get-ChildItem -LiteralPath $extract -Filter 'pluto_infer.exe' -File -Recurse | Select-Object -First 1
    if (-not $dllItem -or -not $inferItem) { throw "pluto.zip does not contain Pluto v2.0 programs: $zip" }
    return @($dllItem.FullName, $inferItem.FullName)
}

function Assert-GameStopped {
    $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -in @('StarCraft', 'StarterBot', 'pluto_infer')
    })
    if ($running.Count) { throw 'Close StarCraft, StarterBot, and Pluto before setup.' }
}

function Copy-Runtime([string]$Destination) {
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    $excluded = @(
        (Join-Path $Root 'arena'),
        (Join-Path $Root '.git'),
        (Join-Path $Root 'src'),
        (Join-Path $Root 'visualstudio'),
        (Join-Path $Root 'ai_backups'),
        (Join-Path $Root 'AI_reports')
    )
    $args = @($Root, $Destination, '/E', '/COPY:DAT', '/DCOPY:DAT', '/R:2', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/XD') + $excluded
    & robocopy.exe @args
    if ($LASTEXITCODE -gt 7) { throw "Runtime copy failed with robocopy code $LASTEXITCODE" }
}

function Select-Map([string]$Runtime) {
    $mapsRoot = Join-Path $Runtime 'maps'
    $maps = @(Get-ChildItem -LiteralPath $mapsRoot -Recurse -File -ErrorAction Stop |
        Where-Object { $_.Extension -in @('.scx', '.scm') })
    if (-not $maps.Count) { throw "No StarCraft map found below $mapsRoot" }
    $chosen = $maps | Sort-Object @(
        @{ Expression = { if ($_.Name -match 'Backrooms') { 0 } elseif ($_.Name -match 'Destination') { 1 } elseif ($_.Name -match '^\(2\)') { 2 } else { 3 } } },
        @{ Expression = { $_.FullName.Length } }
    ) | Select-Object -First 1
    return $chosen.FullName.Substring($Runtime.Length + 1)
}

function Write-Ini([string]$Path, [string]$Text) {
    [IO.File]::WriteAllText($Path, $Text, [Text.Encoding]::ASCII)
}

try {
    Assert-GameStopped
    foreach ($file in @('StarCraft.exe', 'injectory_x86.exe', 'bwapi-data\BWAPI.dll', 'bin\StarterBot.exe')) {
        Require-File (Join-Path $Root $file) $file
    }
    $plutoPrograms = Resolve-PlutoPrograms
    $plutoDll = $plutoPrograms[0]
    $plutoInfer = $plutoPrograms[1]
    $weightsPath = Find-Weights
    Require-File $weightsPath 'pluto_weights.bin'
    if ((Get-Item -LiteralPath $weightsPath).Length -lt 100MB) {
        throw 'pluto_weights.bin is unexpectedly small; use the complete Pluto v2.0 weights file.'
    }

    if (Test-Path -LiteralPath $arenaRoot) {
        $backup = "$arenaRoot.backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        Move-Item -LiteralPath $arenaRoot -Destination $backup
        Write-Host "Previous arena backed up: $backup"
    }
    New-Item -ItemType Directory -Path $arenaRoot -Force | Out-Null
    Write-Host 'Creating isolated STARTcraft runtime...'
    Copy-Runtime $hostRoot
    Write-Host 'Creating isolated Pluto runtime...'
    Copy-Runtime $guestRoot

    $plutoDir = Join-Path $guestRoot 'bwapi-data\AI\pluto'
    New-Item -ItemType Directory -Path $plutoDir -Force | Out-Null
    Copy-Item -LiteralPath $plutoDll -Destination (Join-Path $guestRoot 'bwapi-data\AI\pluto.dll') -Force
    Copy-Item -LiteralPath $plutoInfer -Destination $plutoDir -Force
    Copy-Item -LiteralPath $weightsPath -Destination $plutoDir -Force

    $map = Select-Map $hostRoot
    $hostIni = @"
[ai]
ai =
ai_dbg =
tournament =

[auto_menu]
auto_menu = LAN
character_name = STARTcraft
pause_dbg = OFF
lan_mode = Local PC
auto_restart = OFF
map = $map
game = STARTcraft_vs_Pluto
mapiteration = SEQUENCE
race = Terran
enemy_count = 1
enemy_race = Random
game_type = MELEE
save_replay = Replays/STARTcraft_vs_Pluto.rep
wait_for_min_players = 2
wait_for_max_players = 2
wait_for_time = 1000

[config]
holiday = OFF
shared_memory = ON
console_attach_on_startup = FALSE
console_alloc_on_startup = FALSE

[window]
windowed = ON
left = 0
top = 0
width = 640
height = 480

[starcraft]
sound = OFF
drop_players = ON

[paths]
log_path = bwapi-data/logs
"@
    $guestIni = @"
[ai]
ai = bwapi-data/AI/pluto.dll
ai_dbg = bwapi-data/AI/pluto.dll
tournament =

[auto_menu]
auto_menu = LAN
character_name = Pluto
pause_dbg = OFF
lan_mode = Local PC
auto_restart = OFF
map =
game = JOIN_FIRST
mapiteration = SEQUENCE
race = Random
enemy_count = 1
enemy_race = Terran
game_type = MELEE
wait_for_min_players = 2
wait_for_max_players = 2
wait_for_time = 1000

[config]
holiday = OFF
shared_memory = OFF
console_attach_on_startup = FALSE
console_alloc_on_startup = FALSE

[window]
windowed = ON
left = 680
top = 0
width = 640
height = 480

[starcraft]
sound = OFF
drop_players = ON

[paths]
log_path = bwapi-data/logs
"@
    Write-Ini (Join-Path $hostRoot 'bwapi-data\bwapi.ini') $hostIni
    Write-Ini (Join-Path $guestRoot 'bwapi-data\bwapi.ini') $guestIni

    $manifest = [ordered]@{
        format = 1
        created_utc = [DateTime]::UtcNow.ToString('o')
        source_root = $Root
        map = $map
        pluto_dll_sha256 = (Get-FileHash -LiteralPath $plutoDll -Algorithm SHA256).Hash.ToLowerInvariant()
        pluto_infer_sha256 = (Get-FileHash -LiteralPath $plutoInfer -Algorithm SHA256).Hash.ToLowerInvariant()
        pluto_weights_sha256 = (Get-FileHash -LiteralPath $weightsPath -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    $manifest | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $arenaRoot 'arena_manifest.json') -Encoding UTF8
    Write-Host "Map: $map"
    Write-Host 'SUCCESS: STARTcraft vs Pluto arena is ready.'
} catch {
    Write-Host "ERROR: $($_.Exception.Message)"
    exit 1
}

