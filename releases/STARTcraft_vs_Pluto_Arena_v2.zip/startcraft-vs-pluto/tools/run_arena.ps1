param([string]$Root = 'C:\Users\User\starcraft-api\STARTcraft')

$ErrorActionPreference = 'Stop'
$arenaRoot = Join-Path $Root 'arena\STARTcraft_vs_Pluto'
$hostRoot = Join-Path $arenaRoot 'host'
$guestRoot = Join-Path $arenaRoot 'pluto'

function Require-File([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "File not found: $Path" }
}

function Start-BwapiGame([string]$Runtime) {
    $inject = Join-Path $Runtime 'injectory_x86.exe'
    $launchArgs = @('--launch', 'StarCraft.exe', '--inject', 'bwapi-data\BWAPI.dll')
    if (Test-Path -LiteralPath (Join-Path $Runtime 'wmode.dll') -PathType Leaf) { $launchArgs += 'wmode.dll' }
    Start-Process -FilePath $inject -ArgumentList $launchArgs -WorkingDirectory $Runtime | Out-Null
}

try {
    $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -in @('StarCraft', 'StarterBot', 'pluto_infer')
    })
    if ($running.Count -gt 0) {
        throw 'Close every existing StarCraft, StarterBot, and Pluto process first.'
    }
    Require-File (Join-Path $arenaRoot 'arena_manifest.json')
    Require-File (Join-Path $hostRoot 'bin\StarterBot.exe')
    Require-File (Join-Path $guestRoot 'bwapi-data\AI\pluto.dll')
    Require-File (Join-Path $guestRoot 'bwapi-data\AI\pluto\pluto_infer.exe')
    Require-File (Join-Path $guestRoot 'bwapi-data\AI\pluto\pluto_weights.bin')

    Write-Host 'Launching STARTcraft host...'
    Start-BwapiGame $hostRoot
    Start-Sleep -Seconds 3
    if (-not (Get-Process -Name StarCraft -ErrorAction SilentlyContinue)) { throw 'STARTcraft StarCraft process did not start.' }

    Write-Host 'Connecting STARTcraft AI client...'
    Start-Process -FilePath (Join-Path $hostRoot 'bin\StarterBot.exe') -WorkingDirectory $hostRoot | Out-Null
    Start-Sleep -Seconds 5
    if (-not (Get-Process -Name StarterBot -ErrorAction SilentlyContinue)) { throw 'StarterBot exited before Pluto was launched.' }

    Write-Host 'Launching Pluto opponent...'
    Start-BwapiGame $guestRoot
    Start-Sleep -Seconds 3
    if (@(Get-Process -Name StarCraft -ErrorAction SilentlyContinue).Count -lt 2) { throw 'The second StarCraft process did not start.' }

    Write-Host 'SUCCESS: STARTcraft vs Pluto match is starting.'
    Write-Host "Replay: $hostRoot\Replays\STARTcraft_vs_Pluto.rep"
    Write-Host "Pluto logs: $guestRoot\pluto.log and pluto_infer.log"
} catch {
    Write-Host "ERROR: $($_.Exception.Message)"
    exit 1
}

