@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup_arena.ps1" %*
if errorlevel 1 (
  echo.
  echo SETUP FAILED. Send the ERROR line back.
) else (
  echo.
  echo SETUP COMPLETE. Double-click run_STARTcraft_vs_Pluto.cmd.
)
pause

