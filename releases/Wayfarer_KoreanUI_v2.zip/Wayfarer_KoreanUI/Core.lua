local _, api = ...
api = api or {}
local dictionary = {
    ["EpicSync Wayfarer"] = "EpicSync 웨이페어러",
    ["Gather + Grind · Guide"] = "채집 · 사냥 · 퀘스트 안내",
    ["Gather + Grind - Guide"] = "채집 · 사냥 · 퀘스트 안내",
    ["DO"] = "진행 방식", ["IF STUCK"] = "막혔을 때", ["NOW"] = "현재",
    ["Level 1-60"] = "1~60레벨", ["Level 1–60"] = "1~60레벨",
    ["Gather"] = "채집", ["Grind"] = "사냥", ["Guide"] = "퀘스트 안내",
    ["Wait"] = "대기", ["Continue nearby"] = "근처에서 계속",
    ["START"] = "시작", ["STOP"] = "중지", ["Start"] = "시작", ["Stop"] = "중지",
    ["Pause"] = "일시정지", ["Resume"] = "계속 진행",
    ["STOPPED"] = "중지됨", ["RUNNING"] = "진행 중", ["PAUSED"] = "일시정지됨",
    ["ADJUSTING AUTOMATICALLY"] = "자동 설정 중", ["APPLYING SETTINGS"] = "설정 적용 중",
    ["Ready. Press Start."] = "준비됐습니다. 시작을 누르세요.",
    ["Levelling with your RestedXP guide: it starts once the settings apply."] = "RestedXP 가이드로 진행합니다. 설정 적용이 끝나면 시작합니다.",
    ["Leveling with your RestedXP guide: it starts once the settings apply."] = "RestedXP 가이드로 진행합니다. 설정 적용이 끝나면 시작합니다.",
    ["Follows your RestedXP guide step by step: it walks, talks and fights each step while RestedXP keeps its place."] = "RestedXP 가이드의 각 단계에 맞춰 이동·대화·전투를 진행합니다.",
    ["LEVEL"] = "레벨", ["KILLS"] = "처치", ["NODES"] = "채집", ["BAGS FREE"] = "가방 빈칸",
    ["Settings"] = "설정", ["Compact"] = "작게 보기", ["Expand"] = "펼치기",
    ["General"] = "일반", ["Movement"] = "이동", ["Navigation"] = "길찾기",
    ["Combat"] = "전투", ["Survival"] = "생존", ["Recovery"] = "복구",
    ["Training"] = "기술 학습", ["Trainer"] = "상급자", ["Equipment"] = "장비",
    ["Inventory"] = "소지품", ["Loot"] = "전리품", ["Vendor"] = "상인",
    ["Repair"] = "수리", ["Class"] = "직업", ["Pet"] = "소환수",
    ["Enabled"] = "사용", ["Disabled"] = "사용 안 함",
    ["Enable"] = "사용", ["Disable"] = "사용 안 함",
    ["Apply"] = "적용", ["Save"] = "저장", ["Cancel"] = "취소",
    ["Close"] = "닫기", ["Reset"] = "초기화", ["Back"] = "뒤로",
    ["Food"] = "음식", ["Water"] = "물", ["Rest"] = "휴식",
    ["Target"] = "대상", ["Distance"] = "거리", ["Health"] = "생명력", ["Mana"] = "마나",
    ["Stuck"] = "이동 막힘", ["Recovering"] = "복구 중", ["Moving"] = "이동 중",
    ["Fighting"] = "전투 중", ["Looting"] = "전리품 획득 중", ["Waiting"] = "대기 중",
    ["Dead"] = "사망", ["Ghost"] = "유령", ["Returning"] = "복귀 중",
    ["Repairing"] = "수리 중", ["Selling"] = "판매 중", ["Buying"] = "구매 중",
    ["Learning spells"] = "기술 배우는 중", ["Equipping items"] = "장비 교체 중",
    ["Auto equip"] = "장비 자동 착용", ["Auto train"] = "기술 자동 학습",
    ["Death limit"] = "사망 횟수 제한", ["Time limit"] = "시간 제한",
}

local function translatePlain(text)
    local trimmed = text:gsub("%s+", " "):match("^%s*(.-)%s*$")
    if dictionary[trimmed] then return dictionary[trimmed] end
    local n = trimmed:match("^Limits: (%d+) deaths$")
    if n then return "제한: 사망 " .. n .. "회" end
    n = trimmed:match("^Limits: (%d+) death$")
    if n then return "제한: 사망 " .. n .. "회" end
    if trimmed:match("^Time [0-9:]+") then
        return (text:gsub("Time ", "시간 "):gsub("Deaths ", "사망 "):gsub("XP/hour", "시간당 경험치"))
    end
    local prefixes = {
        {"Moving to: ", "이동 대상: "}, {"Moving to ", "이동 대상: "},
        {"Target: ", "대상: "}, {"Waiting for ", "대기 중: "},
        {"Learning: ", "배우는 중: "}, {"Equipping: ", "착용 중: "},
    }
    for _, pair in ipairs(prefixes) do
        if trimmed:sub(1, #pair[1]) == pair[1] then return pair[2] .. trimmed:sub(#pair[1] + 1) end
    end
    return nil
end

local function translate(text)
    if type(text) ~= "string" then return nil end
    local direct = translatePlain(text)
    if direct then return direct end
    -- Preserve colors while translating text inside them. Never rewrite links or textures.
    if text:find("|[HThAt]") then return nil end
    local changed = false
    local colored = text:gsub("(|c%x%x%x%x%x%x%x%x)(.-)(|r)", function(start, words, finish)
        local result = translatePlain(words)
        if result then changed = true; return start .. result .. finish end
        return start .. words .. finish
    end)
    if changed then return colored end
    return nil
end
api.Translate = translate

local roots = setmetatable({}, {__mode = "k"})
local records = setmetatable({}, {__mode = "k"})
local enabled = true
local updateElapsed, scanElapsed = 0, 5
local scanCursor = nil
local function regions(frame)
    if not frame or type(frame.GetRegions) ~= "function" then return {} end
    local result = {pcall(frame.GetRegions, frame)}
    if not result[1] then return {} end
    table.remove(result, 1)
    return result
end
local function isFontString(region)
    return region and type(region.GetObjectType) == "function" and region:GetObjectType() == "FontString"
end
local function isEditor(frame)
    return frame and type(frame.GetObjectType) == "function" and frame:GetObjectType() == "EditBox"
end
local function titleMatches(text)
    return type(text) == "string" and text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):match("^EpicSync Wayfarer%s*$") ~= nil
end
local function findWindow(frame)
    for _ = 1, 6 do
        if not frame or frame == UIParent or frame == WorldFrame or isEditor(frame) then return nil end
        local w = frame.GetWidth and frame:GetWidth() or 0
        local h = frame.GetHeight and frame:GetHeight() or 0
        if w >= 250 and w <= 1200 and h >= 150 and h <= 1200 then return frame end
        frame = frame.GetParent and frame:GetParent()
    end
end
local function discover()
    if type(EnumerateFrames) ~= "function" then return end
    for _ = 1, 1000 do
        local frame = EnumerateFrames(scanCursor)
        scanCursor = frame
        if not frame then return end
        if not isEditor(frame) then
            for _, region in ipairs(regions(frame)) do
                if isFontString(region) and not region._wayfarerKoreanOverlay and titleMatches(region:GetText()) then
                    local root = findWindow(frame)
                    if root then roots[root] = true end
                end
            end
        end
    end
end
local function restore(source, record)
    if record then
        record.overlay:Hide()
        if record.active then source:SetAlpha(record.alpha) end
        record.active = false
    end
end
local function paint(source)
    if source._wayfarerKoreanOverlay then return end
    local target = translate(source:GetText())
    local record = records[source]
    if not target or target == source:GetText() then restore(source, record); return end
    local parent = source:GetParent()
    if not parent or type(parent.CreateFontString) ~= "function" then return end
    if not record then
        local alpha = source:GetAlpha()
        if alpha == 0 then return end
        local overlay = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal", 7)
        overlay._wayfarerKoreanOverlay = true
        record = {overlay = overlay, alpha = alpha, active = false}
        records[source] = record
    elseif not record.active and source:GetAlpha() == 0 then
        return
    elseif source:GetAlpha() ~= 0 then
        record.alpha = source:GetAlpha()
    end
    local overlay = record.overlay
    local _, size, flags = source:GetFont()
    local font = STANDARD_TEXT_FONT
    if not font and GameFontNormal and GameFontNormal.GetFont then font = GameFontNormal:GetFont() end
    if font then overlay:SetFont(font, size or 12, flags or "") end
    overlay:ClearAllPoints()
    overlay:SetAllPoints(source)
    overlay:SetJustifyH(source:GetJustifyH())
    overlay:SetJustifyV(source:GetJustifyV())
    overlay:SetTextColor(source:GetTextColor())
    if source.GetTextScale and overlay.SetTextScale then overlay:SetTextScale(source:GetTextScale()) end
    if overlay.SetWordWrap then overlay:SetWordWrap(true) end
    overlay:SetText(target)
    overlay:SetAlpha(record.alpha)
    if source:IsShown() then overlay:Show() else overlay:Hide() end
    -- Original text remains untouched so Wayfarer's button/state checks keep working.
    source:SetAlpha(0)
    record.active = true
end
local function walk(frame, depth, budget)
    if not frame or depth > 12 or budget.count >= 800 or isEditor(frame) then return end
    budget.count = budget.count + 1
    for _, region in ipairs(regions(frame)) do if isFontString(region) then paint(region) end end
    if type(frame.GetChildren) == "function" then
        local children = {frame:GetChildren()}
        for _, child in ipairs(children) do walk(child, depth + 1, budget) end
    end
end
local function update()
    if not enabled then return end
    for root in pairs(roots) do walk(root, 0, {count = 0}) end
end
local function setEnabled(value)
    enabled = value
    WayfarerKoreanUIDB = WayfarerKoreanUIDB or {}
    WayfarerKoreanUIDB.enabled = value
    if not enabled then
        local pending = {}
        for source, record in pairs(records) do pending[#pending + 1] = {source, record} end
        for _, pair in ipairs(pending) do restore(pair[1], pair[2]) end
    else
        discover();update()
    end
end
local function say(text)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff76d4bbWayfarer 한글 UI:|r " .. text) end
end
local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_LOGOUT")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        WayfarerKoreanUIDB = WayfarerKoreanUIDB or {}
        setEnabled(WayfarerKoreanUIDB.enabled ~= false)
    else
        local preference = enabled
        setEnabled(false)
        -- Logout restores only visuals; preserve the user's enabled setting.
        WayfarerKoreanUIDB.enabled = preference
    end
end)
events:SetScript("OnUpdate", function(_, elapsed)
    if not enabled then return end
    updateElapsed = updateElapsed + elapsed
    scanElapsed = scanElapsed + elapsed
    local scanInterval = next(roots) and 5 or 0.4
    if scanElapsed >= scanInterval then scanElapsed = 0;discover() end
    if updateElapsed >= 0.4 then updateElapsed = 0;update() end
end)
SLASH_WAYFARERKOREANUI1 = "/wfko"
SlashCmdList["WAYFARERKOREANUI"] = function(message)
    local cmd = (message or ""):match("^%s*(.-)%s*$"):lower()
    if cmd == "off" or cmd == "끄기" then setEnabled(false);say("꺼졌습니다. 원래 표시로 복구했습니다.")
    elseif cmd == "on" or cmd == "켜기" then setEnabled(true);say("켜졌습니다.")
    elseif cmd == "학습 켜기" or cmd == "학습 끄기" then
        if api.SetTrainerAutomation then
            local ok,result=api.SetTrainerAutomation(cmd=="학습 켜기")
            say(result)
        end
    elseif cmd == "장비안내 켜기" or cmd == "장비안내 끄기" then
        if api.SetEquipmentTips then
            local ok,result=api.SetEquipmentTips(cmd=="장비안내 켜기")
            say(result)
        end
    elseif cmd == "report" or cmd == "진단" then
        if api.CaptureDiagnostics then
            discover();update()
            local ok,report=pcall(api.CaptureDiagnostics)
            if ok then say("진단 준비 완료. /reload 후 WTF 폴더에서 Wayfarer_KoreanUI.lua 파일을 찾아 첨부해 주세요.")
            else say("진단에 실패했습니다. 게임 화면을 그대로 유지하고 오류 내용을 알려주세요.") end
        end
    elseif cmd == "rescan" or cmd == "찾기" then scanCursor = nil;discover();update();say("Wayfarer 창을 다시 찾습니다.")
    else
        local windows, labels = 0, 0
        for _ in pairs(roots) do windows = windows + 1 end
        for _, record in pairs(records) do if record.active then labels = labels + 1 end end
        say((enabled and "켜짐" or "꺼짐") .. " · 찾은 창 " .. windows .. "개 · 번역 문구 " .. labels .. "개")
        say("/wfko 켜기 · /wfko 끄기 · /wfko 찾기 · /wfko 진단")
        say("/wfko 학습 켜기 · /wfko 학습 끄기 · /wfko 장비안내 켜기 · /wfko 장비안내 끄기")
    end
end
-- Test entry points are local to the addon's namespace, not global game APIs.
api.Discover = discover
api.Update = update
api.SetEnabled = setEnabled
api.GetRoots = function()
    local list={}
    for root in pairs(roots) do list[#list+1]=root end
    return list
end
