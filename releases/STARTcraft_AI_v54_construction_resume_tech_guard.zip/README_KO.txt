STARTcraft AI v54 - construction resume and tech guard

Install:
1. Close StarCraft, StarterBot, and Pluto.
2. Run upgrade_ai_v54.cmd.
3. Wait for: SUCCESS: AI v54 compiled and arena updated
4. Run the existing run_STARTcraft_vs_Pluto.cmd for one actual validation match.

Changes from the uploaded v53 actual match:
- If an SCV dies after a Terran foundation starts, a nearby safe SCV resumes it.
- Checks BWAPI canMake before issuing tech-building commands.
- Holds one additional Marine against a confirmed two-Gateway opening.
- Construction log: AI_reports\AI_v54_construction.csv

Validation:
- Offline randomized scenarios: 1000/1000 passed with seed 540001.
- Actual v53 match: LOSS to Pluto 1GateCore at about 15:18.
- That match exposed a Factory stopped from 6:05 to 12:36 and 41 invalid Starport orders.
- Run one new actual match after installing v54 and return AI_v54_construction.csv,
  pluto.log, pluto_infer.log, and the replay for confirmation.

The verified embedded source is also included as source/StarterBot.cpp.
