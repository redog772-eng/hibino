STARTcraft AI v53 - resilient ground-path defense

Install:
1. Close StarCraft, StarterBot, and Pluto.
2. Run upgrade_ai_v53.cmd.
3. Wait for: SUCCESS: AI v53 compiled and arena updated

Changes:
- Replaces a killed construction SCV up to two times while preserving the accepted site.
- Projects both main and natural bunker positions from a traversable ground path.
- Widens the legal route-side search without placing the bunker in the traffic lane.
- Prepares the Protoss entrance bunker earlier and delays a pressured expansion until defense is ready.
- Construction log: AI_reports\AI_v53_construction.csv

Offline validation:
- 100 deterministic randomized scenarios passed.
- Covered one Gateway, two Gateway, fast Nexus, and tech openings.
- Varied construction delay, SCV death, mineral/gas income, and ground-path offset.

The verified embedded source is also included as source/StarterBot.cpp.
