STARTcraft AI v43: TvT mech and forward production. Close all game processes, run upgrade_ai_v43.cmd, wait for SUCCESS, then use the existing Pluto arena runner.
