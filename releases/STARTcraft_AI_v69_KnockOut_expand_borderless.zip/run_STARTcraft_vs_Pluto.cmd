@echo off
call "%~dp0START_MATCH.cmd" %*
exit /b %errorlevel%
