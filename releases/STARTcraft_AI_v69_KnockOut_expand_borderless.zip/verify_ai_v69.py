from install_ai_v69 import ROOT, NEW_SHA256, sha
import sys
src=ROOT/'src/starterbot/StarterBot.cpp'
exe=ROOT/'bin/StarterBot.exe'
arena=ROOT/'arena/STARTcraft_vs_Pluto/host/bin/StarterBot.exe'
try:
    ready=(sha(src.read_bytes())==NEW_SHA256 and b'AI v69: KnockOut one Factory expand and mech' in exe.read_bytes() and exe.read_bytes()==arena.read_bytes())
except OSError:
    ready=False
print('AI v69 ready in both installations.' if ready else 'AI v69 installation/update is required.')
sys.exit(0 if ready else 1)
