@echo off
setlocal
cd /d "%~dp0"
py -3 verify_ai_v69.py
if errorlevel 1 (
  echo Installing v69. Close all games and bots first.
  py -3 install_ai_v69.py
  if errorlevel 1 (
    echo INSTALL FAILED. Match was not launched. Send the ERROR line above.
    pause
    exit /b 1
  )
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\run_arena.ps1" -WindowMode Borderless
if errorlevel 1 (
  echo MATCH START FAILED. Send the ERROR line above.
  pause
  exit /b 1
)
pause
