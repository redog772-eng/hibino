"""Read-only file inventory. Does not open config, credentials, license files, or executables."""
from pathlib import Path
import os,json,tkinter as tk
from tkinter import filedialog,messagebox
OUTPUT=Path(__file__).resolve().parent/'Wayfarer_file_inventory.json'
EXTENSIONS={'.lua','.nn','.toc','.md','.exe','.dll'}
EXCLUDED={'license','account_data','credential','password','secret','token','auth','apikey'}

def inventory(root):
 root=Path(root).resolve();files=[];skipped_links=[];limited=False
 for base,dirs,names in os.walk(root,followlinks=False):
  kept=[]
  for name in dirs:
   p=Path(base)/name
   if p.is_symlink() or (hasattr(p,'is_junction') and p.is_junction()):skipped_links.append(str(p.relative_to(root)))
   else:kept.append(name)
  dirs[:]=kept
  for name in names:
   p=Path(base)/name
   if p.suffix.lower() not in EXTENSIONS or any(x in p.stem.lower() for x in EXCLUDED) or p.is_symlink():continue
   try:size=p.stat().st_size
   except OSError:continue
   entry={'path':str(p.relative_to(root)),'bytes':size,'kind':p.suffix.lower()}
   # A signature, not source contents. Configs and binaries are never opened.
   if p.suffix.lower() in {'.lua','.nn'}:
    try:
     with p.open('rb') as f:head=f.read(5)
     entry['format']='Lua bytecode '+str(head[4]>>4)+'.'+str(head[4]&15) if head[:4]==b'\x1bLua' else 'text_or_other'
    except OSError:entry['format']='unreadable'
   files.append(entry)
   if len(files)>=5000:limited=True;break
  if limited:break
 return {'inventory_version':1,'files':files,'scan_limited':limited,'skipped_links':skipped_links,'privacy':'No root path, credentials, license/config contents, source contents or executable contents included.'}

def main():
 app=tk.Tk();app.withdraw()
 root=filedialog.askdirectory(title='현재 사용하는 NoName_Release 폴더를 선택하세요')
 if not root:return
 try:
  report=inventory(root);OUTPUT.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 except OSError as e:messagebox.showerror('확인 실패',str(e));return
 messagebox.showinfo('파일 목록 저장 완료','설정과 게임 파일은 변경하지 않았습니다.\nWayfarer_file_inventory.json 파일을 이 채팅에 첨부해 주세요.\n파일 내용과 비밀번호는 포함하지 않았습니다.')
if __name__=='__main__':main()
