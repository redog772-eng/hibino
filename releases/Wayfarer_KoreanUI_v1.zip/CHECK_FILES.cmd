@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 inspect_wayfarer_files.py
) else (
  python inspect_wayfarer_files.py
)
if errorlevel 1 pause
