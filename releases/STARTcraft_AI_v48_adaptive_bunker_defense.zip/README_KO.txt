STARTcraft AI v48

프로토스 2게이트가 정찰되면 본진 입구 벙커와 마린 집결을 미리 시작합니다.
벙커 위치 탐색에서 배럭/팩토리 출구와 겹치는 후보를 제외해 같은 실패 위치를 반복하지 않습니다.
저그전 앞마당 벙커와 건설 중인 멀티 방어 기능도 유지됩니다.

1. 스타크래프트, StarterBot, Pluto를 모두 종료합니다.
2. upgrade_ai_v48.cmd를 실행합니다.
3. SUCCESS: AI v48 compiled and arena updated를 확인합니다.
4. 기존 run_STARTcraft_vs_Pluto.cmd를 실행합니다.
5. 경기 후 AI_v48_construction.csv, 리플레이, pluto.log, pluto_infer.log를 보내주세요.
