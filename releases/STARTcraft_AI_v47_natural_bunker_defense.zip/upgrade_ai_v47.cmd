@echo off
setlocal
cd /d "%~dp0"
echo STARTcraft AI v47 installer started.
echo The build may take several minutes. Keep this window open.
echo.
py -3 install_ai_v47.py
if errorlevel 1 (
  echo.
  echo INSTALL FAILED. Send the ERROR line back.
) else (
  echo.
  echo AI v47 installation finished.
)
pause
