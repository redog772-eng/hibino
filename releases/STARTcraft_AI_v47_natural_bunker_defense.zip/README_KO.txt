STARTcraft AI v47

앞마당 커맨드센터가 착공되는 순간부터 방어 기준점으로 사용합니다.
저그전 앞마당 벙커를 적 접근로 방향에 미리 건설합니다.
마린 집결, 벙커 탑승, 긴급 SCV 방어가 건설 중인 앞마당을 보호합니다.
건설 CSV의 버전 표기도 47로 수정했습니다.

1. 스타크래프트, StarterBot, Pluto를 모두 종료합니다.
2. upgrade_ai_v47.cmd를 실행합니다.
3. SUCCESS: AI v47 compiled and arena updated를 확인합니다.
4. 기존 run_STARTcraft_vs_Pluto.cmd를 실행합니다.
5. 경기 후 AI_v47_construction.csv, 리플레이, pluto.log, pluto_infer.log를 보내주세요.
