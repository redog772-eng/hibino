STARTcraft AI v41 - Pluto benchmark tempo response

1. Close StarCraft, StarterBot, and Pluto.
2. Run upgrade_ai_v41.cmd.
3. Confirm SUCCESS: AI v41 compiled and arena updated.
4. Run the existing run_STARTcraft_vs_Pluto.cmd.
5. Confirm the in-game message: AI v41: Pluto benchmark tempo response.

Changes: TvP skips early Academy, delays air/science tech until a stable mech economy or observed air, and produces Vultures while Machine Shops are under construction.
