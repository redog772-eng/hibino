@echo off
setlocal
cd /d "%~dp0"
echo Installing STARTcraft v67 replay opening. Close all games and bots first.
py -3 install_ai_v67.py
if errorlevel 1 (
  echo.
  echo INSTALL FAILED. Match was not launched. Send the ERROR line above.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\run_arena.ps1" -WindowMode Windowed
if errorlevel 1 (
  echo.
  echo MATCH START FAILED. Send the ERROR line above.
  pause
  exit /b 1
)
pause
