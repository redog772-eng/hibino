STARTcraft AI v42 - Pluto adaptation

Close StarCraft, StarterBot, and Pluto. Run upgrade_ai_v42.cmd and wait for SUCCESS. The installer also updates the existing Pluto arena copy. Then run run_STARTcraft_vs_Pluto.cmd. Confirm: AI v42: fast gas vulture natural timing.
