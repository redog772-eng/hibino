STARTcraft AI v50 - natural defense and factory discipline

1. Close StarCraft, StarterBot, and Pluto.
2. Run upgrade_ai_v50.cmd.
3. Wait for: SUCCESS: AI v50 compiled and arena updated
4. Run the existing run_STARTcraft_vs_Pluto.cmd.

Changes:
- Prepare a natural bunker and Marine line immediately against Protoss as well as Zerg.
- Stop the six-Marine fast-expansion pressure once STARTcraft has matched with its own natural.
- Preserve the Factory reserve instead of spending it on a fallback Barracks.
- Track accepted construction independently from overwritten SCV commands, preventing duplicate Refinery orders.
- Construction log: AI_reports\AI_v50_construction.csv
