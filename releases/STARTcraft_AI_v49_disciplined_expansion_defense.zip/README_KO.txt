STARTcraft AI v49 - disciplined expansion defense

1. Close StarCraft, StarterBot, and Pluto.
2. Run upgrade_ai_v49.cmd.
3. Wait for: SUCCESS: AI v49 compiled and arena updated
4. Run the existing run_STARTcraft_vs_Pluto.cmd.

Changes:
- After an expansion builder or foundation is destroyed, wait 150 game seconds before retrying.
- Against a scouted Protoss two-Gateway opening, require a completed bunker and a small mobile defense before expanding.
- Cap one-base TvP production at two Factories until the natural is completed.
- Place the main bunker farther toward the entrance while preserving production exits.
- Construction log: AI_reports\AI_v49_construction.csv
