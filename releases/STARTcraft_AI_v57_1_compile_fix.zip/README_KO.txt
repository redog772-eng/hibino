STARTcraft AI v57.1 - AIV25Seen 선언 누락 컴파일 오류 수정
게임과 봇을 종료한 뒤 upgrade_ai_v57.cmd를 실행하세요.
SUCCESS가 표시된 뒤 기존 run_STARTcraft_vs_Pluto.cmd로 한 경기 실행하세요.
v54/v55/v56의 확인된 소스에서 직접 업데이트할 수 있습니다.

벙커 사거리 밖으로 들어온 적에게 벙커 방어력을 잘못 계산하지 않습니다.
본진 안쪽 지상 적 발견 시 건강한 SCV를 최대 10기까지 지원합니다.
최소 4기는 채취용으로 남기며 건설/수리/가스 작업자는 제외합니다.
멀리 접근 중인 적에게는 SCV를 본진 앞에 모아 홀드합니다.
벙커 전방에 적이 없으면 마린을 내려 본진 방어에 합류시킵니다.
위협이 사라진 후 96프레임 동안 재탑승을 막습니다.
긴급 방어 명령은 일반 집결/탑승 명령 뒤에 실행합니다.
건물로 완전 봉쇄하는 맵별 배치는 이번 변경에 포함되지 않습니다.

AI_reports/AI_v57_construction.csv로 실행 버전을 확인하세요.
AI_reports/AI_v57_breach.csv 열: frame,cc_id,breached,ground_threat,defender_power,desired_scv,no_load_until
이 환경에서는 Windows 컴파일과 실제 경기를 실행하지 못했습니다.
오프라인 검사는 승률을 의미하지 않습니다.
