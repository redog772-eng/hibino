local addonName, addon = ...
addon.guides = {}
addon.guideList = {}
addon.guideIds = {}

local class = addon.player.class
local race = addon.player.race

local locale = GetLocale()
local fmt, tremove, tinsert = string.format, tremove, table.insert
local unpack = unpack
local strchar = string.char
local strbyte = string.byte
local bitand = bit.band
local bitxor = bit.bxor
local LibDeflate = LibStub("LibDeflate")
local RXPGuides = addon.RXPGuides
addon.condenseGroups = {}

local game = strlower(addon.game)
--local suffix = 1
-- Alias addon.locale.Get
local L = addon.locale.Get

-- File guides and string-imports need different load order support
local embeddedGuides = {}
addon.embeddedGuides = embeddedGuides

addon.minGuideVersion = 0
addon.maxGuideVersion = 0

addon.classicPrefix = "C-"

local aCache = {}

local function applies(textEntry,customClass,func)
    if textEntry then
        --if not(textEntry:match("Alliance") or textEntry:match("Horde")) then return true end
        local function parse(text,customClass)
            local isMatch = false
            text = text:gsub("(!?)%(%s*(.-)%s*%)",function(op,m)
                if parse(m,customClass) ~= (op == "!") then
                    return class
                else
                    return "NULL"
                end
            end)
            local faction = addon.player.faction
            local playerLevel = UnitLevel("player") or 1
            for str in string.gmatch(text, "[^/]+") do
                local v = true
                for entry in string.gmatch(str, "!?[%w%d]+") do
                    local state = false
                    local gendercheck
                    if entry:sub(1, 1) == "!" then
                        entry = entry:sub(2, -1)
                        state = true
                    end
                    local level = tonumber(entry) or 0xfff
                    local uppercase = strupper(entry)
                    if entry == "Undead" then
                        entry = "Scourge"
                    elseif uppercase == "DK" then
                        uppercase = "DEATHKNIGHT"
                    elseif uppercase == "MALE" and UnitSex("player") == 2 or
                        uppercase == "FEMALE" and UnitSex("player") == 3 then
                        gendercheck = true
                    elseif uppercase == "SOD" and addon.player.season == 2 then
                        entry = faction
                    elseif uppercase == "DF" then
                        entry = "RETAIL"
                    elseif faction == "Neutral" and not customClass and (entry == "Alliance" or entry == "Horde") then
                        entry = faction
                    elseif entry == "Haranir" then
                        entry = "Harronir"
                    end
                    local customCheck = func and func(entry, uppercase)
                    v = (not(gendercheck or uppercase == class or entry == race or
                             entry == faction or playerLevel >= level or uppercase == addon.game or
                             (addon.game == "FOREVER" and uppercase == "CLASSIC") or entry == customClass or entry == locale or customCheck) ==
                             state)
                    if not v then
                        break
                    end
                end
                if v then
                    isMatch = true
                    break
                end
            end
            --print(isMatch and "TRUE" or "FALSE",'-',text)
            return isMatch
        end
        local match
        if not aCache[textEntry] then
            match = parse(textEntry,customClass)
            aCache[textEntry] = match
            return match
        else
            return aCache[textEntry]
        end
    end
    return true
end

addon.applies = applies
addon.farmGuides = 0

addon.affix = function(smin, smax)
    if smax:len() == 1 then smax = "0" .. smax end
    return "0" .. smin .. "-" .. smax
end

function addon.RegisterGroup(guideGroup, parentGroup)
    if not RXPGuides[guideGroup] then RXPGuides[guideGroup] = {} end
    local group = RXPGuides[guideGroup]
    if parentGroup then
        if not RXPGuides[parentGroup] then RXPGuides[parentGroup] = {} end
        local parent = RXPGuides[parentGroup]
        parent.__index = parent
        setmetatable(parent, addon.functions)
        setmetatable(group, parent)
    else
        setmetatable(group, addon.functions)
    end
end

-- Load guide into addon options
function addon.AddGuide(guide)
    -- Not applicable (e.g. wrong faction), rely on upstream functions to report parsing errors
    if not guide then return false end
    addon.GroupOverride(guide)
    local loadedGuide
    for _, checkGuide in ipairs(addon.guides) do
        if guide.key == checkGuide.key then
            loadedGuide = checkGuide
            break
        end
    end

    if loadedGuide and addon.settings.profile.debug then
        local debugText
        if guide.version == loadedGuide.version then
            debugText = fmt('Overwriting (%s) v%d', guide.key, guide.version)
        elseif guide.version > loadedGuide.version then
            debugText = fmt(
                            'Newer guide for (%s) already exists (%s) >= checkGuide (%d)',
                            guide.key, guide.version, loadedGuide.version)
        else
            debugText = fmt('Loading new version for (%s) v%d', guide.key,
                            guide.version)
        end

        addon.safeCall(function() addon.guideImporter:UpdateImportStatusHistory(debugText) end)
    end
    local group = guide.group
    if guide.lowPrio then
        group = guide.lowPrio
    end
    local index = fmt("%s||%s",guide.group,guide.name)
    addon.RegisterGroup(group,guide.group ~= group and guide.group)

    local groupDisplayName = group
    if guide.groupdisplayname then
        if guide.lowPrio and guide.lowPrio:sub(1,1) == "*" then
            groupDisplayName = "*" .. guide.groupdisplayname
        else
            groupDisplayName = guide.groupdisplayname
        end
    end
    if groupDisplayName ~= group then
        addon.condenseGroups[group] = groupDisplayName
    end
    if not addon.guideList[groupDisplayName] then
        addon.guideList[groupDisplayName] = {}
        addon.guideList[groupDisplayName].names_ = {}
    end
    --print(group,guide.group ~= group and guide.group)
    addon.guideList[groupDisplayName].weight_ = tonumber(guide.groupweight)
                                    or addon.guideList[groupDisplayName].weight_

    local list = addon.guideList[groupDisplayName]

    if guide.guideId then
        addon.guideIds[guide.guideId] = index
    end

    if loadedGuide then -- guide exists, but new version
        for i, checkGuide in ipairs(addon.guides) do
            if guide.key == checkGuide.key then
                addon.guides[i] = checkGuide
                break
            end
        end
    else -- guide doesn't exist, so insert
        if not addon.guides[index] then
            tinsert(list.names_, {name = guide.name, group = guide.group:gsub("^%*","")})
        end
        addon.guides[index] = guide

        list[guide.name] = index
        --TODO: remove this part
        if not guide.lowPrio and guide.defaultFor and
            not addon.defaultGuide then addon.defaultGuide = guide end
    end
    return true
end

function addon.RemoveGuide(guideKey)
    if not guideKey then return false end

    local loadedGuide
    for _, checkGuide in ipairs(addon.guides) do
        if guideKey == checkGuide.key then
            loadedGuide = checkGuide
            break
        end
    end

    if not loadedGuide then
        addon.comms.PrettyDebug('Guide not found (%s)', guideKey)

        return
    end

    if addon.currentGuide and addon.currentGuide.key == guideKey then
        addon:LoadGuide(addon.emptyGuide)
    end

    local list = addon.guideList[loadedGuide.group]

    for i, name in ipairs(list.names_) do
        if loadedGuide.name == name then
            tremove(list.names_, i)
            break
        end
    end

    for name, _ in pairs(list) do
        if type(name) ~= "table" then
            if loadedGuide.name == name then
                list[name] = nil
                list.sorted_ = false
                break
            end
        end
    end

    -- Doesn't actually remove from addon.guides
    for i, checkGuide in pairs(addon.guides) do
        if loadedGuide.key == checkGuide.key then
            -- soft delete, hard delete messes up sorting
            addon.guides[i] = addon.emptyGuide
            break
        end
    end

    if next(list.names_) == nil then addon.guideList[loadedGuide.group] = nil end

    addon:ScheduleTask(addon.RXPFrame.GenerateMenuTable)

    return true
end

function addon.DeserializeTable(tbl)
    local t = {}
    for k, v in pairs(tbl) do
        if type(v) == "number" then v = strchar(v) end
        tinsert(t, v)
    end
    return table.concat(t)
end

local importChunkSize = 4096
local function CheckDataIntegrity(str, h1, mode, yieldImport)
    if not h1 then return addon.A32(str) end
    if mode ~= 58 then return end

    local S = {}
    local i, j
    local buffer = {}
    local n = addon.ReadCacheData("buffer")

    if not n then
        addon.comms.PrettyDebug('Failed to ReadCacheData')

        return false, L('Failed to ReadCacheData')
    end

    for k = 0, 255 do S[k] = n[k] end

    local decoded, decodeError
    if _G.C_EncodingUtil and _G.C_EncodingUtil.DecodeBase64 then
        local success
        success, decoded, decodeError = pcall(_G.C_EncodingUtil.DecodeBase64, str)

        if not success then return false, decoded end
    else
        decoded, decodeError = addon.read(str)
    end

    if not decoded or decodeError then
        return false, decodeError or L("Failed integrity check")
    end

    -- Keep one small byte buffer and concatenate completed chunks. A table
    -- entry for every byte of the entire export causes large GC allocations.
    local byteChars = {}
    for byte = 0, 255 do byteChars[byte] = strchar(byte) end
    local chunkBuffer = {}
    i, j = 0, 0
    local chunkEnd
    for chunkStart = 1, #decoded, importChunkSize do
        chunkEnd = chunkStart + importChunkSize - 1

        if chunkEnd > #decoded then chunkEnd = #decoded end

        for k = chunkStart, chunkEnd do
            i = bitand(i + 1, 0xff)
            j = bitand(j + S[i], 0xff)
            S[i], S[j] = S[j], S[i]
            chunkBuffer[k - chunkStart + 1] = byteChars[bitxor(strbyte(decoded, k), S[bitand((S[i] + S[j]), 0xff)])]
        end

        buffer[#buffer + 1] = table.concat(chunkBuffer, "", 1, chunkEnd - chunkStart + 1)
        if yieldImport then yieldImport() end
    end

    local compressed = table.concat(buffer)
    buffer, chunkBuffer, byteChars, decoded = nil, nil, nil, nil
    -- Reject likely account mismatches before passing data to the native decoder.
    local compressedLength = #compressed
    local cmf, flg = strbyte(compressed, 1, 2)
    local checksum = compressedLength >= 8 and
                     strbyte(compressed, compressedLength - 3) * 0x1000000 +
                     strbyte(compressed, compressedLength - 2) * 0x10000 +
                     strbyte(compressed, compressedLength - 1) * 0x100 +
                     strbyte(compressed, compressedLength)

    if not checksum or bitand(cmf, 0xf) ~= 8 or cmf > 0x78 or
        bitand(flg, 0x20) ~= 0 or (cmf * 256 + flg) % 31 ~= 0 or
        checksum ~= h1 % 4294967296 then
        return false, L('Account mismatch, import string does not apply to current account')
    end

    if yieldImport then yieldImport() end

    local decompressed, decompressError

    if _G.C_EncodingUtil and _G.C_EncodingUtil.DecompressString then
        local success
        success, decompressed, decompressError = pcall(_G.C_EncodingUtil.DecompressString, compressed, 1)

        if not success then return false, decompressed end
    else
        decompressed = LibDeflate:DecompressZlib(compressed)
    end

    if not decompressed then return false, decompressError or L("Failed integrity check") end

    str = decompressed

    if h1 % 4294967296 == addon.A32(str) then return true, str end

    return false, L('Account mismatch, import string does not apply to current account')
end

local function CompressDeflate(str)
    if _G.C_EncodingUtil and _G.C_EncodingUtil.CompressString then
        local success, compressed = pcall(_G.C_EncodingUtil.CompressString, str, 0)

        if success and compressed then return compressed end
    end

    return LibDeflate:CompressDeflate(str)
end

local ncache = 0
function addon.CacheGuide(key, guide, enabledFor, guideVersion, metadata)
    ncache = ncache + 1
    local profileKey = key .. "|" .. ncache

    if type(guide) == "table" then
        guide.groupOrContent = CompressDeflate(guide.groupOrContent)
        guide.key = key
        addon.db.profile.guides[profileKey] = guide
    else
        guide = guide:gsub("%s-[\r\n]+%s*", "\n")
        guide = guide:gsub("[\t ][\t ]+", " ")
        guide = guide:gsub("%-%-[^\n]*", "")
        guide = "--" .. addon.ReadCacheData("string") .. "\n" .. guide
        guide = CompressDeflate(guide)

        --print(profileKey:gsub("|","||"))
        addon.db.profile.guides[profileKey] = addon.BuildCacheObject(guide, enabledFor,
                                                             guideVersion, metadata, key)
    end
end

-- Parse and cache one-time guide
function addon.ImportGuide(guide, text, defaultFor, cache)
    if addon.db then -- Addon loaded already
        local importedGuide, errorMsg, metadata = addon.ParseGuide(guide)
        if errorMsg ~= "#0" and importedGuide and importedGuide.name and
            ((errorMsg and not cache) or addon.AddGuide(importedGuide)) then
            -- print(errorMsg,importedGuide.name)
            importedGuide.key = importedGuide.key or addon.BuildGuideKey(importedGuide)
            --print(importedGuide.key,importedGuide.enabledFor)
            importedGuide.imported = true
            addon.CacheGuide(importedGuide.key, guide, importedGuide.enabledFor,
                             importedGuide.version, metadata)
        end
        return importedGuide, errorMsg
    else -- Addon not loaded, add to queue
        tinsert(embeddedGuides, {
            groupOrContent = guide,
            text = text,
            defaultFor = defaultFor,
            cache = true
        })
    end
end

function addon.RegisterGuide(groupOrContent, text, defaultFor)
    if not groupOrContent then
        return error(L'Error: Guide has no contents')
    elseif addon.addonLoaded or
      (addon.addonLoaded == false and addon.settings.profile and
       (addon.settings.profile.preLoadData or not addon.player.hardcore)) then
        local importedGuide, errorMsg = addon.ParseGuide(groupOrContent, text,
                                                        defaultFor)

        return not errorMsg and addon.AddGuide(importedGuide)
    else
        tinsert(embeddedGuides, {
            groupOrContent = groupOrContent,
            text = text,
            defaultFor = defaultFor
        })
    end
end

function addon.BuildCacheObject(groupOrContent, enabledFor, guideVersion, metadata, key)
    return {
        groupOrContent = groupOrContent,
        cache = true,
        enabledFor = enabledFor,
        version = guideVersion,
        metadata = metadata,
        key = key,
    }
end

function addon.A32(tbl)
    local readfunc, offset
    if type(tbl) == "table" then
        readfunc = unpack
        offset = -1
    elseif type(tbl) == "string" then
        readfunc = strbyte
        offset = 0
    else
        return
    end

    local length = #tbl

    local i = 1
    local a = 1
    local b = 0
    while i <= length - 15 do
        local x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15,
              x16 = readfunc(tbl, i + offset, i + 15 + offset)
        b = (b + 16 * a + 16 * x1 + 15 * x2 + 14 * x3 + 13 * x4 + 12 * x5 + 11 *
                x6 + 10 * x7 + 9 * x8 + 8 * x9 + 7 * x10 + 6 * x11 + 5 * x12 + 4 *
                x13 + 3 * x14 + 2 * x15 + x16) % 65521
        a = (a + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + x9 + x10 + x11 + x12 +
                x13 + x14 + x15 + x16) % 65521
        i = i + 16
    end
    while (i <= length) do
        local x = readfunc(tbl, i + offset, i + offset)
        a = (a + x) % 65521
        b = (b + a) % 65521
        i = i + 1
    end
    return bitand((b * 65536 + a), 0xffffffff)

end

local cachedData = {}
function addon.ReadCacheData(mode)
    if not cachedData.base then
        local base = select(2, _G[addon.DeserializeTable(addon.base)]())
        if not base then
            cachedData.base = RXPData.cache
        else
            base = base:lower()
            local k = #base
            if k > 16 then
                base = base:sub(k - 15, -1)
                k = 16
            end
            k = 16 - k

            local buffer = {}
            for i = 0, 15 do
                local j = bitand(i - k, 0xf)
                buffer[i] = strbyte(base, j + 1) or 0
            end
            for i = 0, 15 do
                buffer[bitand(-i, 0xf)] = bitxor(bitxor(
                                                     bitxor(buffer[bitand(15 - i,
                                                                          0xf)],
                                                            buffer[bitand(
                                                                13 - i, 0xf)]),
                                                     buffer[bitand(12 - i, 0xf)]),
                                                 buffer[bitand(10 - i, 0xf)])
            end
            RXPData.cache = buffer
            cachedData.base = buffer
        end
    end

    if not cachedData.base then
        return
    elseif not cachedData.number then
        cachedData.number = addon.A32(cachedData.base)
        cachedData.number = cachedData.number - math.floor(addon.version / 1e2)
        cachedData.string = tostring(cachedData.number)
    end

    if not cachedData.buffer and mode == "buffer" then
        local buffer = {};
        local j = 0
        local base = cachedData.base

        for i = 0, 255 do buffer[i] = i end

        for i = 0, 255 do
            j = bitand(j + buffer[i] + base[bitand(i, 0xf)], 0xff)
            buffer[i], buffer[j] = buffer[j], buffer[i]
        end
        cachedData.buffer = buffer
    end

    return mode and cachedData[mode] or cachedData.base
end

local function LoadGuide(guideData,n)
    if guideData.cache then
        addon.ImportGuide(guideData.groupOrContent, guideData.text,
                            guideData.defaultFor, true)
    else
        local guide, errorMsg, metadata, length, key, group, name, version
        local enabled = true
        if RXPCData.guideDisabled[n] then
            enabled = false
        elseif not guideData.text then
            length = guideData.groupOrContent:len()
            local index = guideData.groupOrContent:find("[\r\n]%s*step")
            local header = index and guideData.groupOrContent:sub(1,index)
            if header then
                local subgroup, enabledFor
                enabled = false
                for line in header:gmatch("[^\r\n]+") do
                    if subgroup and name and group and enabledFor and enabled and version then
                        break
                    end
                    line = line:gsub("%-%-.*$","")
                    line = line:gsub("^%s*(#.+)%s*<<%s*(.+)", function(l,t)
                        if not applies(t) then
                            return ""
                        else
                            return l
                        end
                    end)
                    if not enabled then
                        local u = strupper(line)
                        if u:find("#" .. addon.game) or
                            (addon.game == "RETAIL" and u:find("#DF")) or
                            (addon.game == "FOREVER" and u:find("#CLASSIC")) then
                            enabled = true
                        end
                    end
                    enabledFor = enabledFor or line:match("^%s*<<%s*(.-)%s*$")
                    group = group or line:match("^%s*#group%s+(.-)%s*$")
                    subgroup = subgroup or line:match("^%s*#subgroup%s+(.-)%s*$")
                    name = name or line:match("^%s*#name%s+(.-)%s*$")
                    version = version or tonumber(line:match("^%s*#version%s+(.-)%s*$"))
                end
                enabled = enabled and (not enabledFor or applies(enabledFor))

                if enabled then
                    -- Keep an equal/newer loaded route before touching its metadata
                    -- or lazy parser. A newer embedded version may still replace it.
                    if group and name then
                        local existingGroup = addon.GroupOverride(group, subgroup)
                        local existingName = name:gsub("^(%d)-(%d%d?)", addon.affix)
                        local existingGuide = addon.guides[existingGroup .. "||" .. existingName]
                        if existingGuide and (tonumber(existingGuide.version) or 0) >= (version or 0) then
                            -- Only skip this duplicate when the already-loaded guide can
                            -- actually be fetched. A stale metadata stub can survive an
                            -- update without a guideCache parser, which makes selecting it
                            -- fail with "Tried to load an invalid Guide". In that case,
                            -- keep processing this embedded copy so it rebuilds the parser.
                            local existingParser = existingGuide.key and addon.guideCache[existingGuide.key]
                            if existingGuide.steps or existingGuide.parse or existingParser then
                                return
                            end
                        end
                    end
                    key = addon.BuildGuideKey(group,"",name)
                    guide = key and RXPCData.guideMetaData[key]
                else
                    RXPCData.guideDisabled[n] = length
                end
            end
            --print('g-ok',guide and guide.length)
        end

        if guide and guide.length == length then
            --print('w',guide.key)
            if (guide.defaultFor and not applies(guide.defaultFor)) then
                guide.lowPrio = "*" .. group
                --print(group)
            else
                guide.lowPrio = nil
            end
            errorMsg = not (not guide.enabledFor or applies(guide.enabledFor))
            --print(guide,errorMsg,guide.enabledFor)
            addon.guideCache[guide.key] = function(self)
                local tbl = addon.ParseGuide(guideData.groupOrContent,guideData.text)
                if RXPCData and RXPCData.guideMetaData then
                    RXPCData.guideMetaData[guide.key] = metadata
                end
                if addon.player.faction == "Neutral" and tbl then
                    tbl.parse = self
                end
                return tbl
            end
        elseif enabled then
            guide, errorMsg, metadata =
                addon.ParseGuide(guideData.groupOrContent,
                                guideData.text,
                                guideData.defaultFor, true, group, key)
                --print('n2',guide and guide.key)
            enabled = not errorMsg
            if key and metadata then
                local cleanup = {}
                for guideKey,data in pairs(RXPCData.guideMetaData) do
                    if data.key == guide.key then
                        tinsert(cleanup,guideKey)
                    end
                end
                for _,guideKey in pairs(cleanup) do
                    RXPCData.guideMetaData[guideKey] = nil
                end
                RXPCData.guideMetaData[key] = metadata
            end
        end
        if enabled then
            addon.AddGuide(guide)
        end
    end
end


--local embeddedGuidesLoaded
local loadedGuides = 0
function addon.GetLoadedGuides()
    return loadedGuides
end
function addon.LoadEmbeddedGuides(maxIterations)
    if not addon.db then
        error('Initialization error, db not set')
        return
    end
    -- if embeddedGuidesLoaded then
    --     return
    -- else
    --     embeddedGuidesLoaded = true
    -- end
    --A1 = GetTimePreciseSec()
    local nGuides = #embeddedGuides
    if not RXPCData.guideDisabled[0] or RXPCData.guideDisabled[0] <= nGuides then
        RXPCData.guideDisabled = {[0] = nGuides}
    end
    local iterations = 0
    for n = 1+loadedGuides,nGuides do
        iterations = iterations + 1
        if maxIterations and iterations > maxIterations then
            --print(iterations, maxIterations)
            break
        end
        local guideData = embeddedGuides[n]
        loadedGuides = n
        LoadGuide(guideData,n)
    end

    if addon.addonLoaded and loadedGuides == nGuides then
        table.wipe(embeddedGuides)
        loadedGuides = 0
    end

    --[[if addon.addonLoaded then
        embeddedGuides = nil
    else
        embeddedGuides = {}
    end]]

    --A1 = GetTimePreciseSec() - A1
    addon:ScheduleTask(addon.RXPFrame.GenerateMenuTable)
end

function addon.BuildGuideKey(arg1,arg2,arg3)
    if type(arg1) == "table" then
        return fmt("%s|%s|%s", arg1.group, arg1.subgroup or '',
                         arg1.name)
    elseif arg1 and arg3 then
        return fmt("%s|%s|%s", arg1, arg2 or '',
                         arg3)
    end
end

local decompressedGuides = {}

function addon.LoadCachedGuides()
    if not addon.db then
        error('Initialization error, db not set')
        return
    end
    local string = addon.string or RXPString
    if string then
        local header = string:sub(1,30)
        local n,id,content = header:match("^(%d+)|(%-?%d+):(.*)")
        n = tonumber(n)
        id = tonumber(id)
        if (n and n ~= addon.db.profile.guideLength or id and id ~= addon.db.profile.guideId or content and content ~=
            addon.db.profile.guideContent) then
            addon.guideImporter.guideId = id
            addon.guideImporter.guideLength = n
            addon.guideImporter.guideContent = content

            local success, isValid, importError = addon.safeCall(function()
                return addon.guideImporter:ImportString(string, true)
            end)
            if success and isValid and addon.guideImporter.importBufferSize > 0 then
                addon.guideImporter.cachedState = {
                    profileGuides = addon.db.profile.guides,
                    guides = addon.guides,
                    guideList = addon.guideList,
                    guideIds = addon.guideIds,
                    guideCache = addon.guideCache,
                    condenseGroups = addon.condenseGroups,
                    groupAlias = addon.groupAlias,
                    defaultGuide = addon.defaultGuide,
                    farmGuides = addon.farmGuides,
                    guide = addon.guide,
                    step = addon.step,
                    lastObjective = addon.lastObjective,
                    lastElement = addon.lastElement,
                    currentGuideName = addon.currentGuideName,
                    currentGuideGroup = addon.currentGuideGroup,
                    lastGuideName = addon.lastGuideName,
                    lastGuideGroup = addon.lastGuideGroup,
                    minGuideVersion = addon.minGuideVersion,
                    maxGuideVersion = addon.maxGuideVersion,
                    guideContent = addon.db.profile.guideContent,
                    guideLength = addon.db.profile.guideLength,
                    guideId = addon.db.profile.guideId
                }
                addon.guides = {}
                addon.guideList = {}
                addon.guideIds = {}
                addon.guideCache = {}
                addon.condenseGroups = {}
                addon.groupAlias = {}
                addon.defaultGuide = nil
                addon.farmGuides = 0
                addon.db.profile.guides = {}
                addon.safeCall(function() addon.guideImporter:Open() end)
            elseif not success then
                addon.safeCall(function() addon.guideImporter:AbortImport() end)
                addon.safeCall(function()
                    addon.guideImporter:UpdateImportStatusHistory("%s", true, importError or isValid)
                end)
            elseif not isValid then
                addon.safeCall(function() addon.guideImporter:AbortImport() end)
            end
            -- print(addon.string:len())
            if success and isValid and addon.guideImporter.importBufferSize > 0 then

                return
            end
        end
    end

    for key, guideData in pairs(addon.db.profile.guides) do
        if guideData.key then
            key = guideData.key
        else
            key = key:match("^[^|]+|[^|]-|[^|]+") or key
        end
        local guide, errorMsg, metadata
        local enabled = not guideData.enabledFor or
                            applies(guideData.enabledFor)
        if addon.release ~= RXPData.release then
            guideData.metadata = nil
        end
        if enabled then
            if guideData.metadata and
                    guideData.metadata.length == addon.ReadCacheData("string") then
                local data = guideData
                addon.guideCache[key] = function(self)
                    local g
                    if addon.player.hardcore and not addon.settings.profile.loadAllGuides then
                        if not decompressedGuides[key] then
                            decompressedGuides[key] = LibDeflate:DecompressDeflate(data.groupOrContent)
                            return
                        end
                        g = decompressedGuides[key]
                    else
                        g = LibDeflate:DecompressDeflate(data.groupOrContent)
                    end
                    local tbl = addon.ParseGuide(g)
                    if RXPCData and RXPCData.guideMetaData then
                        RXPCData.guideMetaData[guide.key] = metadata
                    end
                    if addon.player.faction == "Neutral" and tbl then
                        tbl.parse = self
                    end
                    tbl.imported = true
                    decompressedGuides[key] = nil
                    return tbl
                end
                guide = guideData.metadata
                local groupName = guide.group:gsub("^%*","")
                if (guide.defaultFor and not applies(guide.defaultFor)) then
                    guide.lowPrio = "*" .. groupName
                else
                    guide.lowPrio = nil
                end
            else
                guide = LibDeflate:DecompressDeflate(guideData.groupOrContent)
                if guide:find("^--" .. addon.ReadCacheData("string")) then
                    guide, errorMsg, metadata = addon.ParseGuide(guide)
                    if metadata then
                        guideData.metadata = metadata
                    end
                else
                    guide = nil
                end
            end
            if not errorMsg and guide then
                guide.imported = true
                addon.AddGuide(guide)
            else
                addon.comms.PrettyDebug(L('Unable to decode cached guide (%s), removed'), key)
                addon.db.profile.guides[key] = nil
            end
        end
    end
end

function addon.LoadAllGuides()
    addon.LoadEmbeddedGuides()
    print'ok1'

    local n = 1
    if addon.player.hardcore then
        n = 2
    end

    for i = 1,n do
        for _,guide in pairs(addon.guides) do
            if not guide.steps then
                addon:FetchGuide(guide)
            end
        end
    end
    print('L-total time: ', debugprofilestop() - addon.startTime)
end

local function parseLine(linetext,step,parsingLogic)
    if not parsingLogic then
        parsingLogic = addon.functions
    end
    addon.step = step
    if addon.lastObjective and addon.lastObjective.step ~= step then
        addon.lastObjective = nil
    end
    if addon.lastElement and addon.lastElement.step ~= step then
        addon.lastElement = nil
    end

    local line = linetext
    local classtag
    line = line:gsub("%s*<<%s*(.+)", function(t)
        classtag = t
        return ""
    end)
    if classtag and not applies(classtag) then return end

    if step then
        local steptag, assignment, value = line:match("^#(%S+)%s*(=?)%s*(.*)")
        if steptag and steptag ~= "" then
            if not step[steptag] then
                if assignment == "=" then
                    step[steptag] = parsingLogic[value]
                else
                    step[steptag] = value
                end
            end
            return
        end
    end

    local element
    local text
    line = line:gsub("%s*>>%s*(.*)", function(t)
        if t ~= "" then text = t end
        return ""
    end)

    if text and addon.KoreanFullTranslate then
        local sourceText = text
        text = addon.KoreanFullTranslate(text)
        if line:match("^%.accept%s") and sourceText:match("^Accept [^|%.!?]+$") then
            text = "퀘스트 받기: *quest*"
        elseif line:match("^%.turnin%s") and sourceText:match("^Turn in [^|%.!?]+$") then
            text = "퀘스트 완료: *quest*"
        end
    end

    line:gsub("^%.(%S+)%s*(.*)", function(tag, args)
        local t = {}

        if addon.separators[tag] then
            addon.separators[tag](t,args)
        else
            args = args:gsub("%s*,%s*", ",")
            for arg in string.gmatch(args, "[^,]+") do
                tinsert(t, arg)
            end
        end
        -- print(tag,args,type(guide))
        if parsingLogic[tag] then
            element = parsingLogic[tag](linetext, text, unpack(t))
            if not element then return end
            element.tag = tag
            element.step = step
            if element.parent then
                element.parent = addon.lastObjective
            end
        else
            local ltext
            if #linetext > 150 then
                ltext = linetext:sub(1,150)
            else
                ltext = linetext
            end
            return addon.error(L("Error parsing guide") .. " " ..
                                   addon.currentGuideName ..
                                   ": Invalid function call (." .. tag ..
                                   ")\n" .. ltext)
        end
    end)

    if text and not element then
        element = {text = text, textOnly = true, step = step}
    elseif line:sub(1, 1) == "+" then
        element = {text = addon.KoreanFullTranslate and addon.KoreanFullTranslate(line:sub(2, -1)) or line:sub(2, -1), step = step}
        addon.lastObjective = element
    elseif line:sub(1, 1) == "*" then
        element = {
            text = (addon.KoreanFullTranslate and addon.KoreanFullTranslate(line:sub(2, -1)) or line:sub(2, -1)):gsub("\\n", "\n"),
            step = step,
            hideTooltip = true,
            textOnly = true
        }
        -- else
        -- error('Error parsing guide at line '..linenumber..'/ '..guide.name)
    end
    if element and (element.text and not element.textOnly or element.dynamicText) then
        addon.lastObjective = element
    end

    --[[if RXPData.localeTable and element and element.text then
        RXPData.localeTable[element.text] = ""
    end]]
    if not step then
        if element then
            element.parent = nil
        --[[else
            addon.error(L("Error parsing ") .. addon.currentGuideName .. ':'
                 .. linetext)
        ]]
        end
    elseif step.elements and element then
        tinsert(step.elements, element)
        addon.lastElement = element
    end
    return element
end
addon.ParseLine = parseLine

function addon.ParseGuide(groupOrContent, text, defaultFor, isEmbedded, group, key)

    addon.lastObjective = nil
    addon.currentGuideName = nil
    if not groupOrContent then return end

    local playerLevel = UnitLevel("player")
    local parentGroup
    local length
    if isEmbedded then
        length = groupOrContent:len()
    else
        length = groupOrContent:match("^%-%-(%d+)")
    end
    -- A final inline comment needs a line terminator before normalization.
    if not (groupOrContent and text) then
        local currentGroup = group
        if type(length) ~= "string" then
            text = (groupOrContent .. "\n"):gsub("%-%-[^\r\n]*[\r\n]+", "\n")
        else
            text = groupOrContent
        end
        if not group then
            text = text:gsub(
                    "(#group[ \t]*)([^\r\n]-)[ \t]*<<[ \t]*([^\r\n]-)[ \t]*[\r\n]+",
                    function(prefix, group, t)
                    if not applies(t) then
                        return "\n"
                    else
                        currentGroup = group
                        return prefix .. group .. "\n"
                    end
                end)
        end
        if currentGroup then
            groupOrContent = currentGroup
        else
            groupOrContent = text:match("^%s*#group%s+(.-)%s*[\r\n]") or
                                 text:match("[\r\n]%s*#group%s+(.-)%s*[\r\n]")
            if not groupOrContent then
                addon.comms.PrettyPrint("\n%s: Invalid guide group %s",
                                        text:match("#name%s+.-%s*[\r\n]") or "", L("Error parsing guide") or "")
                return
            end
        end
    else
        text = (text .. "\n"):gsub("%-%-[^\r\n]*[\r\n]", "\n")
    end

    local guide = {}
    if groupOrContent:sub(1, 1) == "+" then
        addon.farmGuides = addon.farmGuides + 1
        guide.farm = true
    end
    addon.guide = guide

    guide.group = groupOrContent
    addon.currentGuideGroup = groupOrContent

    local currentStep = 0
    guide.steps = {}

    local parsingLogic
    local step
    local skip
    local skipGuide
    local linenumber = 0
    local game = strlower(addon.game)
    local hasGameTag, isGameCompatible, hasGuideMetadata

    for line in string.gmatch(text, "[^\n\r]+") do
        linenumber = linenumber + 1
        line = line:gsub("^%s+", "")
        line = line:gsub("%s+$", "")
        -- print(line)
        if line:sub(1, 4) == "step" then
            if currentStep == 0 then
                if guide.df then guide.retail = true end

                hasGameTag = guide.classic or guide.tbc or guide.wotlk or guide.df or guide.retail or guide.cata or guide.mop
                isGameCompatible = guide[game] or (addon.game == "FOREVER" and guide.classic)
                hasGuideMetadata = guide.name and guide.group

                if hasGameTag and not isGameCompatible then
                    skipGuide = "#0"
                end
                -- Excluded faction/class/season guides may have no conditional name.
                -- Applicable guides still need valid metadata.
                if not skipGuide and not hasGuideMetadata then
                    error(L("Error parsing guide") .. ": " .. L("Guide has no name"))
                end
                --debug purposes
                addon.lastGuideName = guide.name
                addon.lastGuideGroup = guide.group
            end
            if skipGuide then
                guide.version = tonumber(guide.version) or 0
                addon.minGuideVersion = math.min(guide.version,addon.minGuideVersion)
                addon.maxGuideVersion = math.max(guide.version,addon.maxGuideVersion)
                addon.guide = false
                addon.lastObjective = nil
                guide.key = guide.key or key
                return guide, skipGuide
            elseif currentStep == 0 then
                guide.key = guide.key or key or addon.BuildGuideKey(guide)
                guide.guideId = addon.A32(guide.key)
                addon.RegisterGroup(guide.group)
            end
            local classtag = line:match("<<%s*(.+)")
            if classtag and not applies(classtag) then
                skip = true
            else
                skip = false
                if step and step.elements and #step.elements == 0 then
                    step.hidewindow = true
                end
                currentStep = currentStep + 1
                guide.steps[currentStep] = {}
                guide.steps[currentStep].elements = {}
                step = guide.steps[currentStep]
                step.stepId = linenumber + guide.guideId
                --step.index = currentStep
                addon.step = step
                --addon.lastObjective = nil
                parsingLogic = addon.functions
            end
        elseif not skip then
            if currentStep > 0 then
                parseLine(line,step,parsingLogic)
            else
                -- print(line)
                line = line:gsub("(.-)%s*<<%s*(.+)", function(code, tag)
                    local isValid = applies(tag)
                    if #code == 0 then
                        skipGuide = not isValid and tag
                        guide.enabledFor = guide.enabledFor or tag
                        -- print("$"..code.."$",tag,#code)
                    elseif not isValid then
                        return ""
                    end
                    return code
                end)

                if line ~= "" then
                    line:gsub("^#(%S+)%s*(=?)%s*(.*)",
                              function(tag, assignment, value)
                        -- print(tag,string.len(tag))
                        if tag and tag ~= "" and not guide[tag] then
                            if assignment == "=" then
                                local func = addon.functions[value]
                                guide[tag] = func and func() or value
                            else
                                guide[tag] = value
                            end
                            if tag == "name" then
                                addon.currentGuideName = value
                            end
                        end
                    end)
                end
            end
        end
    end
    -- print(guide)
    addon.step = false
    if not guide.name then error(L('Guide has no name')) end

    defaultFor = guide.defaultfor or defaultFor
    guide.group = guide.group or groupOrContent
    groupOrContent = addon.GroupOverride(guide) or groupOrContent

    if addon.game == "TBC" and guide.classic and not guide.wotlk and not groupOrContent:find("TBC") and groupOrContent:sub(1,1) ~= "+" then
        if guide.subgroup then
            local range = guide.subgroup:match("( %d+%-%d+)$")
            if range then
                guide.subgroup = L"Classic"..range
            end
        end
        if groupOrContent:sub(1,8) == "RestedXP" then
            groupOrContent = addon.classicPrefix..groupOrContent
            guide.group = groupOrContent
        end
        defaultFor = "!tbc"
    end
    if defaultFor then
        local boost58
        if defaultFor == "58Boost" then
            if playerLevel >= 60 or playerLevel < 58 then
                parentGroup = groupOrContent
                guide.lowPrio = "*" .. groupOrContent
            end
            boost58 = true
        elseif not applies(defaultFor) then
            parentGroup = groupOrContent
            guide.lowPrio = "*" .. groupOrContent
        end
        addon.RegisterGroup(groupOrContent, parentGroup)
        guide.boost58 = boost58
        --guide.lowPrio = groupOrContent
    end

    guide.displayname = addon.settings.ReplaceColors(guide.displayname or guide.name)
    guide.name = guide.name:gsub("^(%d)-(%d%d?)", addon.affix)

    guide.key = addon.BuildGuideKey(guide)
    guide.version = tonumber(guide.version) or 0
    addon.minGuideVersion = math.min(guide.version,addon.minGuideVersion)
    addon.maxGuideVersion = math.max(guide.version,addon.maxGuideVersion)

    addon.guide = false
    addon.lastObjective = nil
    -- print(guide.name,"\n",guide.enabledFor)

    local metadata = {length = length}

    for k,v in pairs(guide) do
        if not (type(v) == "table" or type(v) == "function") then
            metadata[k] = v
        end
    end
    metadata.lowPrio = nil
    metadata.defaultFor = defaultFor
    return guide,nil,metadata
end

addon.groupAlias = {}
function addon.GroupOverride(guide,arg2)
    local guideTable = type(guide) == "table" and guide

    local function SwapGroup(grp,subgrp)
        local prefix = ""
        if grp:sub(1,1) == "*" then
            prefix = "*"
        end
        --local group,subgroup
        local swap
        if addon.game == "CLASSIC" or guideTable and guideTable.classic then
            local groupId = guideTable and guideTable.groupid
            local faction = not groupId and grp:match("RestedXP ([AH][lo][lr][id][ea]%w*)")
            if faction == "Alliance" or groupId == "RXP-SRGCE-A1" then
                subgrp = subgrp or grp
                if guideTable then
                    guideTable.groupdisplayname = prefix .. L"RestedXP Speedrun Guide (A)"
                end
                swap = true
                --print('\n',grp,subgrp,faction,type(guide) == "table" and guide.name,'\n')
            elseif faction == "Horde" or groupId == "RXP-SRGCE-H1" then
                subgrp = subgrp or grp
                if guideTable then
                    guideTable.groupdisplayname = prefix .. L"RestedXP Speedrun Guide (H)"
                end
                swap = true
                --print(group,guide.subgroup,faction,guide.group,guide.name)
            end
        elseif addon.game == "TBC" then
            if not guideTable or not guideTable.classic then
                local range = subgrp and subgrp:match("^RestedXP Survival.-( %d+%-%d+)$")
                if range then
                    subgrp = "TBC Survival Guide"..range
                    swap = true
                else
                    range = subgrp and subgrp:match("^RestedXP [AH][lo][lr][id][ea]%w*( %d+%-%d+)")
                    if range then
                        subgrp = "TBC Speedrun Guide"..range
                        swap = true
                    end
                end
                local SG = grp:match("^RestedXP Survival Guide(.*)")
                if SG then
                    swap = true
                    grp = "RXP TBC Survival Guide"..SG
                end
            end
        end
        return grp,subgrp,swap
    end

    if type(guide) == "table" then
        if guide.group then
        --if true then  return end
            local group,swap
            group, guide.subgroup,swap = SwapGroup(guide.group,guide.subgroup)
            if swap then
                addon.groupAlias[guide.group] = group
                guide.group = group
                guide.next = guide.next and guide.next:gsub("[^;]-\\","")
            end
            --print(group,'//',guide.subgroup)
            return group
        end
    elseif type(guide) == "string" then
        --print(guide,arg2)
        return SwapGroup(guide,arg2)
    else
        return guide
    end
end

if not _G.RXPGuides.RegisterGuide then
    _G.RXPGuides.RegisterGuide = addon.RegisterGuide
end

if not _G.RXPGuides.ImportGuide then _G.RXPGuides.ImportGuide =
    addon.ImportGuide end

local importCache = {bufferString = "", bufferData = {}, lastBuffer = 0}

addon.guideImporter = addon:NewModule("GuideImporter", addon.guideImporter)
addon.guideImporter.importCache = importCache
addon.guideImporter.widgets = {}
addon.guideImporter.gui = {
    selectedDeleteGuide = "",
    importStatusHistory = {},
    progressMessage = nil,
    progressError = false
}
addon.guideImporter.lastBNetQuery = 0
addon.guideImporter.cachedState = nil
addon.guideImporter.importReady = false
addon.guideImporter.importCoroutine = nil

function addon.guideImporter:Setup()
    if not addon.workerFrame then
        addon.workerFrame = CreateFrame("Frame")
        addon.workerFrame:Hide()
    end
end

function addon.guideImporter:Open()
    if _G.InCombatLockdown() then
        addon.settingsPanelAfterCombat = "Import"

        return
    end

    if not self.widgets.import then
        addon.ui.v2:InitializeGuideImporter()
        addon.ui.v2:CreateGuideImporter()
    end

    self.widgets.import:Show()
    self:UpdateImportUI()
end

addon.guideImporter.importBufferSize = 0
local importBuffer = {}
local importedGuideCount = 0
local scriptErrorsBeforeImport

local function LoadImportBuffer(str, nGuides, yieldImport)
    local errorMsg, validData, dataOrError

    for hash, mode, content in str:gmatch("(%-?%d+)(%D)([A-Za-z0-9%+%/%=]+)%%") do
        validData, dataOrError = CheckDataIntegrity(content, tonumber(hash),
                                                        strbyte(mode), yieldImport)

        if not validData or not dataOrError then
            errorMsg = dataOrError or L("Failed integrity check")

            break
        end

        for v in dataOrError:gmatch("[^%z]+") do tinsert(importBuffer, v) end
    end

    local importedCount = #importBuffer
    if not errorMsg and importedCount == 0 then
        errorMsg = L("Incomplete or invalid encoded string")
    end

    if errorMsg then
        errorMsg = fmt("%s\n%s", errorMsg,
                       fmt(L("Total guides loaded: %d/%s"), importedCount, nGuides))
    end

    return errorMsg
end

function addon.guideImporter:AbortImport()
    self.nextProgressUpdate = nil
    self.importCoroutine = nil
    importBuffer = {}
    importedGuideCount = 0
    self.importBufferSize = 0
    self.importReady = false
    self.importCache.bufferString = ""
    self.importCache.bufferData = {}
    self.importCache.lastBuffer = 0
    self.guideContent = nil
    self.guideLength = nil
    self.guideId = nil

    local cachedState = self.cachedState

    if cachedState then
        addon.db.profile.guides = cachedState.profileGuides
        addon.guides = cachedState.guides
        addon.guideList = cachedState.guideList
        addon.guideIds = cachedState.guideIds
        addon.guideCache = cachedState.guideCache
        addon.condenseGroups = cachedState.condenseGroups
        addon.groupAlias = cachedState.groupAlias
        addon.defaultGuide = cachedState.defaultGuide
        addon.farmGuides = cachedState.farmGuides
        addon.guide = cachedState.guide
        addon.step = cachedState.step
        addon.lastObjective = cachedState.lastObjective
        addon.lastElement = cachedState.lastElement
        addon.currentGuideName = cachedState.currentGuideName
        addon.currentGuideGroup = cachedState.currentGuideGroup
        addon.lastGuideName = cachedState.lastGuideName
        addon.lastGuideGroup = cachedState.lastGuideGroup
        addon.minGuideVersion = cachedState.minGuideVersion
        addon.maxGuideVersion = cachedState.maxGuideVersion
        addon.db.profile.guideContent = cachedState.guideContent
        addon.db.profile.guideLength = cachedState.guideLength
        addon.db.profile.guideId = cachedState.guideId

        self.cachedState = nil
    end

    addon.workerFrame:SetScript("OnUpdate", nil)
    addon.workerFrame:Hide()

    local importBox = self.widgets.importBox
    if importBox then
        local editBox = importBox:GetEditBox()
        editBox:SetScript("OnUpdate", nil)
        editBox:SetMaxBytes(0)
        editBox:Enable()
    end

    self.RestoreScriptErrorSetting()

    if cachedState then addon:ScheduleTask(addon.RXPFrame.GenerateMenuTable) end
end

function addon.guideImporter.RestoreScriptErrorSetting()
    if scriptErrorsBeforeImport == "0" then _G.SetCVar("scriptErrors", scriptErrorsBeforeImport) end

    scriptErrorsBeforeImport = nil
end

function addon.guideImporter:ImportString(str, synchronous)
    self.nextProgressUpdate = nil
    self:Setup()
    importBuffer = {}
    self.importBufferSize = 0
    importedGuideCount = 0
    self.gui.progressMessage = nil
    self.gui.progressError = false
    scriptErrorsBeforeImport = _G.GetCVar("scriptErrors")

    if scriptErrorsBeforeImport == "0" then _G.SetCVar("scriptErrors", "1") end

    str = str:gsub("^%D+", "")
    str = str:gsub("%D+$", "")
    local nGuides = str:match("^(%d+)|")
    local validHash = str:match("|(%d+):")
    local base = str:match("|(%d+)$")

    if not nGuides or not base or not validHash then
        addon.safeCall(function()
            self:UpdateImportStatusHistory(L("Incomplete or invalid encoded string"), true)
        end)

        addon.guideImporter.RestoreScriptErrorSetting()

        return false, L("Incomplete or invalid encoded string")
    end

    if tonumber(base) < addon.version then
        addon.safeCall(function()
            self:UpdateImportStatusHistory(L("Incompatible guide game %d version vs %d"), true, tonumber(base), addon.version)
        end)

        addon.guideImporter.RestoreScriptErrorSetting()

        return false, fmt(L("Incompatible guide, for %d version vs %d"), tonumber(base), addon.version)
    end

    addon.safeCall(function()
        self:UpdateImportStatusHistory(L("Loading Guides") .. "... (0/%d)", false, tonumber(nGuides))
    end)

    if not synchronous then
        self.importCoroutine = coroutine.create(function()
            return LoadImportBuffer(str, nGuides, coroutine.yield)
        end)

        addon.workerFrame:SetScript("OnUpdate", self.ProcessInputBuffer)
        addon.workerFrame:Show()

        return true
    end

    local errorMsg = LoadImportBuffer(str, nGuides)
    self.importBufferSize = #importBuffer

    if errorMsg then
        importBuffer = {}

        self.importBufferSize = 0
        self.RestoreScriptErrorSetting()

        return false, errorMsg
    end

    addon.workerFrame:SetScript("OnUpdate", addon.guideImporter.ProcessInputBuffer)
    addon.workerFrame:Show()

    return true
end

-- RestedXP import work limits (milliseconds and maximum batch size).
local importFrameBudgetMs = 8
local importFrameWorkLimit = 64

function addon.guideImporter.ProcessInputBuffer(workerFrame)
    local guideImporter = addon.guideImporter
    local importCoroutine = guideImporter.importCoroutine
    local frameStarted = debugprofilestop()
    local frameWork = 0

    if importCoroutine then
        repeat
            frameWork = frameWork + 1
            local success, errorMsg = coroutine.resume(importCoroutine)
            local finished = coroutine.status(importCoroutine) == "dead"

            if not success or (finished and errorMsg) then
                addon.safeCall(function() guideImporter:AbortImport() end)
                addon.safeCall(function()
                    guideImporter:UpdateImportStatusHistory(
                        "%s", true,
                        tostring(errorMsg or L("Guide import failed due to a Lua error.")))
                end)
                return
            end

            if finished then
                guideImporter.importCoroutine = nil
                guideImporter.importBufferSize = #importBuffer
                break
            end
        until frameWork >= importFrameWorkLimit or
              debugprofilestop() - frameStarted >= importFrameBudgetMs

        if guideImporter.importCoroutine or frameWork >= importFrameWorkLimit or
           debugprofilestop() - frameStarted >= importFrameBudgetMs then
            return
        end
    end

    local processed = 0
    while #importBuffer > 0 do
        local guideString = tremove(importBuffer)
        local success, parseGuide, skipReason = addon.safeCall(function()
            return RXPGuides.ImportGuide(guideString)
        end)

        if not success then
            addon.safeCall(function() guideImporter:AbortImport() end)
            addon.safeCall(function() guideImporter:UpdateImportStatusHistory("%s", true, parseGuide) end)
            return
        end

        -- A conditional skip may legitimately have no applicable guide name.
        if type(parseGuide) ~= "table" or (not parseGuide.name and not skipReason) then
            addon.safeCall(function() guideImporter:AbortImport() end)
            addon.safeCall(function()
                guideImporter:UpdateImportStatusHistory(L("Error parsing guide"), true)
            end)
            return
        end

        if parseGuide.imported then importedGuideCount = importedGuideCount + 1 end
        processed = processed + 1
        frameWork = frameWork + 1

        if frameWork >= importFrameWorkLimit or
           debugprofilestop() - frameStarted >= importFrameBudgetMs then
            break
        end
    end

    -- Refresh the progress display at most ten times per second. Errors and
    -- the final count still update immediately, even in a very short import.
    if processed > 0 and (#importBuffer == 0 or
                         GetTime() >= (guideImporter.nextProgressUpdate or 0)) then
        guideImporter.nextProgressUpdate = GetTime() + 0.1
        addon.safeCall(function()
            guideImporter:UpdateImportStatusHistory(
                L("Loading Guides") .. "... (%d/%d)",
                false, guideImporter.importBufferSize - #importBuffer,
                guideImporter.importBufferSize)
        end)
    end
    if #importBuffer > 0 then return end

    guideImporter.nextProgressUpdate = nil
    workerFrame:SetScript("OnUpdate", nil)
    workerFrame:Hide()
    guideImporter.RestoreScriptErrorSetting()

    if guideImporter.guideContent or guideImporter.guideLength or guideImporter.guideId then
        addon.db.profile.guideContent = guideImporter.guideContent
        addon.db.profile.guideLength = guideImporter.guideLength
        addon.db.profile.guideId = guideImporter.guideId

        guideImporter.guideContent = nil
        guideImporter.guideLength = nil
        guideImporter.guideId = nil
    end

    if importedGuideCount > 0 then
        addon.guideImporter.importReady = false

        addon.safeCall(function()
            addon.guideImporter:UpdateImportStatusHistory(L("Guides Loaded Successfully"), false)
        end)

        addon.guideImporter.importBufferSize = 0
        importedGuideCount = 0
    else
        addon.safeCall(function() addon.guideImporter:AbortImport() end)
        addon.safeCall(function()
            addon.guideImporter:UpdateImportStatusHistory(L("No guides apply to this game version or character."), true)
        end)
    end

    addon.safeCall(function() addon.guideImporter:UpdateImportUI() end)

    local importBox = addon.guideImporter.widgets.importBox
    if importBox then
        local editBox = importBox:GetEditBox()
        editBox:SetMaxBytes(0)
        editBox:Enable()
    end

    addon:ScheduleTask(addon.RXPFrame.GenerateMenuTable)
    addon.guideImporter.cachedState = nil
end
