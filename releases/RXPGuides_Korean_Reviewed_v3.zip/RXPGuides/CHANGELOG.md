# RestedXP Guides

## [v4.11.18](https://github.com/RestedXP/RXPGuides/tree/v4.11.18) (2026-10-06)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.11.17...v4.11.18) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Fix double Junk hooks with bag addons  
- Refresh v2 layout after resize, not during  
    Fixes significant frame drops while resizing  
- Allow v2 auto Show Step List on resize  
- zephras-isle add support for non-Skyborne characters  
- Propagate new defaults to Forever localDB  
- Fix conflicting guide step anchoring contention  
    fixes #356  
- Optimize v1 frame redraws  
