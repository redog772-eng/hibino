if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Pre-Expansion Preparations
#name a1) Quest Preparations (H)
#displayname |cFF00FF001|r - Quests
#chapters a) Quest Booklet (H);a) Furniture Favor (H);a) Fishing (H);a) Cooking (H);a) Balloon (H);a) Selfie Cam (H);a) Warbanding Together (H);a) Squally (H);a) Blade in Twillight (H);a) Delve Quests (H);a) Burning Steppes Prep (H);a) Gidwin (H);a) Tirisfal Midnight Prep (H);a) Alterac Valley Quests (H);a) Pet Battle Setup (H);a) Orc Heritage Quests (H);a) Undead Heritage Armor (H);a) Tauren Heritage Quests (H);a) Troll Heritage Quests (H);a) Blood Elf Heritage Quests (H);a) Goblin Heritage Quests (H);a) Heritage Pandaren (H);a) Trading Post (H);a) Begin Your Training: Master Cheng (H) << Horde
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Endeavor (H)
#subweight 1001
#displayname Endeavor |cRXP_WARN_30+ Quest Setup(NEW)|r
#subgroup Pre-Expansion Preparations
<< Horde
step
#include a) Endeavor
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Quest Booklet (H)
#next a) Furniture Favor (H)
#displayname |cFFFCDC00How to Use(MUST READ)|r
#chapter
<< Horde
step
#include RestedXP Midnight\a) Quest Booklet
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Furniture Favor (H)
#next a) Fishing (H)
#displayname Balloon
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Furniture Favor
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Fishing (H)
#next a) Cooking (H)
#displayname Fishing
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Fishing
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Cooking (H)
#next a) Balloon (H)
#displayname Cooking
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Cooking
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Balloon (H)
#next a) Selfie Cam (H)
#displayname Balloon
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Balloon
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Selfie Cam (H)
#next a) Warbanding Together (H)
#displayname Selfie Cam
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Selfie Cam
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Warbanding Together (H)
#next a) Squally (H)
#displayname Warbands
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up 2 quests that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
+This sets up a 2 quests that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Warbanding Together
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Squally (H)
#next a) Blade in Twillight (H)
#displayname Squally
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Squally
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Blade in Twillight (H)
#next a) Delve Quests (H)
#displayname Xalatath Lorewalking
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up one quest that rewards XP equivalent to up to five quests from levels 80–90 and unlocks an item we’ll also make use of.
*|cRXP_WARN_It can be done at any time|r.
*|cRXP_WARN_Estimate Setup Time: 10 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up one quest that rewards XP equivalent to up to five quests from levels 80–90 and unlocks an item we’ll also make use of.
*|cRXP_WARN_It can be done at any time|r.
*|cRXP_WARN_Estimate Setup Time: 10 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Xal'atath@LoreWalkingPrepStart-LoreWalkingPrepEnd
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Delve Quests (H)
#next a) Gidwin (H)
#displayname Delve Quests
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up |cRXP_WARN_13|r quests that rewards full XP on level 80
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up |cRXP_WARN_13|r quests that rewards full XP on level 80
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Delve Quests
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Gidwin (H)
#next a) Tirisfal Midnight Prep (H)
#displayname Eastern Plaguelands
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This unlocks the quest Journey’s End and keeps it in your quest log so a teleport item can be used during the 80–90 campaign, saving a significant amount of time.
*|cRXP_WARN_You may have already completed this quest; if so, the item is no longer obtainable|r
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zoneskip 23
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This unlocks the quest Journey’s End and keeps it in your quest log so a teleport item can be used during the 80–90 campaign, saving a significant amount of time.
*|cRXP_WARN_You may have already completed this quest; if so, the item is no longer obtainable|r
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Gidwin
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Alterac Valley Quests (H)
#next a) Pet Battle Setup (H)
#displayname Alterac Valley
#chapter
<< Horde
step
#completewith next
#label WarningText
+This sets up a |cRXP_WARN_6|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per character, you may have already completed it|r.
*This takes time depending on what your current reputation standing is with the Frostwolf Clan << Horde
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zoneskip 25
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a |cRXP_WARN_6|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per character, you may have already completed it|r.
*This takes time depending on what your current reputation standing is with the Frostwolf Clan << Horde
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Alterac Valley Quests
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Pet Battle Setup (H)
#displayname Pet Battles
#chapter
<< Horde
step
#completewith next
#label WarningText
+This sets up |cRXP_WARN_30-40|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 3-5 hours|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up |cRXP_WARN_30-40|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 3-5 hours|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Pet Battle Setup
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Orc Heritage Quests (H)
#next a) Trading Post (H)
#displayname Orc Heritage Quests
#chapter
<< Horde Orc
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Orc Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Undead Heritage Armor (H)
#next a) Trading Post (H)
#displayname Undead Heritage Quests
#chapter
<< Horde Undead
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Undead Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Tauren Heritage Quests (H)
#next a) Trading Post (H)
#displayname Tauren Heritage Quests
#chapter
<< Horde Tauren
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Tauren Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Troll Heritage Quests (H)
#next a) Trading Post (H)
#displayname Troll Heritage Quests
#chapter
<< Horde Troll
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Troll Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Blood Elf Heritage Quests (H)
#next a) Trading Post (H)
#displayname Blood Elf Heritage Quests
#chapter
<< Horde BloodElf
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Blood Elf Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Goblin Heritage Quests (H)
#next a) Trading Post (H)
#displayname Goblin Heritage Quests
#chapter
<< Horde Goblin
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Goblin Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Heritage Pandaren (H)
#next a) Trading Post (H)
#displayname Pandaren
#chapter
<< Horde Pandaren
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Heritage Pandaren
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Trading Post (H)
#next a) Begin Your Training: Master Cheng (H)
#displayname Trading Post
#chapter
<< Horde
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Trading Post
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Begin Your Training: Master Cheng (H)
#displayname Monk Quests
#chapter
<< Horde Monk
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 85 >>Go to Orgrimmar
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Speed Leveling\a) Monk Quests@Master Cheng-MonkIncludePrepEnd
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Pre-Expansion Preparations
#name a2) Item Preparations (H)
#displayname |cFF00FF002|r - Items
#chapters a) Item Information (H);a) Shopping List (H);a) Guild Items (H);a) Shadowberries (H);a) Bivigosa's Blood Sausages (H) << Horde
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Item Information (H)
#displayname |cFFFCDC00How to Use(MUST READ)|r
#chapter
<< Horde
step
#include RestedXP Midnight\a) Item Booklet
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shopping List (H)
#displayname Shopping
#chapter
<< Horde
step
#include RestedXP Midnight\a) Shopping List
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Guild Items (H)
#displayname XP Banners & Teleport Cloaks
#chapter
<< Horde
step
#include RestedXP Midnight\a) Guild Items
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shadowberries (H)
#displayname Shadowberries
#chapter
<< Horde
step
#include RestedXP Midnight\a) Shadowberries
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Bivigosa's Blood Sausages (H)
#displayname Bivigosa's Blood Sausages
#chapter
<< Horde
step
#include RestedXP Midnight\a) Bivigosa's Blood Sausages
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Quest Booklet
#internal
step
+Please read this section carefully.
*It explains how to use the guide and avoid common mistakes.
step
+This guide is designed to maximize experience and efficiency at launch.
*It is divided into three main sections:
step
#title |cFFFCDC00Prepping Quests|r
+Prepare quests in advance and hold them completed for launch day turnins
*This allows for fast experience as soon as leveling is unlocked.
step
#title |cFFFCDC00Prepping Items|r
+Collect items that increase leveling speed and quality of life.
*These items reduce downtime and improve overall efficiency
step
#title |cFFFCDC00Turnin Route|r
+Follow a structured route to turn in all prepared quests
*This section is integrated into the overall leveling route |cRXP_WARN_(normal & multibox)|r.
*Expect to turn in prepared quests not only at level 80, but throughout levels 80–90.
*Most prepared quests scale with your level.
step
#title |cFFFCDC00Accidental Turnins|r
+Any addon that auto-accepts or auto-turns-in quests |cRXP_WARN_(aside from RestedXP)|r can cause accidental turn-ins.
+This may result in lost experience before launch, use other addons at your own risk.
step
#title |cFFFCDC00Accountwide Quests|r
+Many quests in this guide can only be completed once per account or character
+If the guide skips many steps, this is by design
+It usually means those quests were already completed and unfortunately cannot be used for launch-day turn-ins.
step
#title |cFFFCDC00Time & Choice|r
+Each quest section clearly states its purpose and estimated time investment.
+This allows you to decide whether you want to pursue it.
step
#title |cFFFCDC00Estimated Total XP|r
+Estimated XP if you have access to every quest (none unavailable) as Horde: about 696,000 XP without buffs, reaching roughly 85% of level 81.
*Alliance: roughly 70% of level 81.
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Furniture Favor
#internal
step << Alliance
.isQuestAvailable 92572
.goto 84,56.07,77.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Second Chair Pawdo|r
.accept 92572 >>Accept Furniture Favor
.target Second Chair Pawdo
step << Alliance
.isOnQuest 92572
.goto 84,67.74,73.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Lancy Revshon|r
.complete 92572,1 
.buy 253168
.target Captain Lancy Revshon
step << Horde
.isQuestAvailable 92572
.goto 85,52.92,88.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Second Chair Pawdo|r
.accept 92572 >>Accept Furniture Favor
.target Second Chair Pawdo
step << Horde
.isOnQuest 92572
.goto 85,50.37,58.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stone Guard Nargol|r and buy |T7425121:0|t[Earthen Storage Crate]
.complete 92572,1 
.buy 253168
.target Stone Guard Nargol
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Fishing
#internal
step << Alliance
.goto 84,54.8,69.59
.train 7620 >>Talk to |cRXP_FRIENDLY_Arnold Leland|r in Stormwind and learn Fishing.
.target Arnold Leland
step << Alliance
.goto 84,55.04,69.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Catherine Leland|r in Stormwind.
.daily 26414,26420,26442,26488,26536 >> Accept Fishing Daily
.target Catherine Leland
step << Alliance
.isOnQuest 26442
#loop
.goto 84,22.18,51.9,30,0
.goto 84,19.65,37.27,30,0
.goto 84,20.28,19.37,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Traps|r.
.complete 26442,1 
step << Alliance
#completewith next
#label Crystal Bass
#hidewindow
.complete 26420,1 
step << Alliance
#completewith Crystal Bass
.isOnQuest 26420
#loop
.goto 84,59.08,20.7,10,0
.goto 84,58.08,10.54,30,0
.goto 84,60.52,6.94,30,0
.goto 84,63.47,5.75,30,0
.goto 84,64.97,8.75,30,0
.goto 84,63.88,16.66,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dirt Mound|r for |T236553:0|t[|cRXP_LOOT_Overgrown Earthworm|r].
.collect 58788,1,26420,1
step << Alliance
#requires Crystal Bass
#completewith next
#label Crystal Bass2
.isOnQuest 26420
>>Fish a |T3495040|t[Crystal Bass].
*|cRXP_WARN_You have 10 minutes before you need to get the bait again|r.
.aura -80534
.complete 26420,1 
.usespell 131474
step << Alliance
.isOnQuest 26420
#completewith Crystal Bass2
.cast 80534 >>Use |T236553:0|t[Overgrown Earthworm]
.use 58788
step << Alliance
#requires Crystal Bass2
.isOnQuest 26420
>>Fish a |T3495040|t[Crystal Bass].
*|cRXP_WARN_You have 10 minutes before you need to get the bait again|r.
.aura -80534
.complete 26420,1 
.usespell 131474
step << Alliance
.isOnQuest 26536
.goto 37,24.98,59.13
>>Fish |T133907:0|t[Violet Perches]
*|cRXP_WARN_you'll start catching them at skill 15|r.
.complete 26536,1 
.usespell 131474
step << Alliance
.isOnQuest 26414
.goto 84,53.44,39.14
>>Fish |T349503:0|t[Hardened Walleye's].
.complete 26414,1 
.usespell 131474
step << Alliance
.isOnQuest 26488
.goto 84,75.61,83.43
>>Fish |T348532:0|t[Royal Monkfishes] and use them to get |T349503:0|t[Precious Locket].
.complete 26488,1 
.usespell 131474
step << Horde
.goto 85,66.44,41.9
.train 7620 >>Talk to |cRXP_FRIENDLY_Lumak|r in Orgrimmar and learn Fishing.
.target Lumak
step << Horde
.goto 85,65.67,41.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razgar|r in Orgrimmar.
.daily 26543,26556,26557,26588,26572 >> Accept Fishing Daily
.target Razgar
step << Horde
.isOnQuest 26572
#hidewindow
#completewith Golden Stonefish
#loop
.goto 1,43.68,24.05,20,0
.goto 1,43.54,24.87,20,0
.goto 1,42.42,24.2,20,0
.goto 1,41.93,23.96,20,0
.goto 1,41.64,25.14,20,0
.goto 1,41.21,24.55,20,0
.goto 1,40.58,24.2,20,0
.goto 1,39.58,23.65,20,0
.goto 1,39.49,24.95,20,0
.goto 1,38.97,25.12,20,0
+1
step << Horde
.isOnQuest 26572
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drowned Thunder Lizard|r
*|cRXP_WARN_they periodically cast lighting discharge, be careful|r.
.collect 58958,1,26572,1
.target Drowned Thunder Lizard
.use 58955
step << Horde
.isOnQuest 26572
#label Golden Stonefish
>>Use |T133721:0|t[Drowned Thunder Lizard Tail] near |cRXP_ENEMY_Golden Stonefish|r to kill them.
*Loot them for |T350869:0|t[|cRXP_LOOT_Golden Stonefish|r].
.complete 26572,1 
.use 58958
.mob Golden Stonefish
step << Horde
.isOnQuest 26556
#loop
.goto 85,33.41,70.72,10,0
.goto 85,35.59,74.79,10,0
>>Fish [Toxic Puddlefish]
.complete 26556,1 
.usespell 131474
step << Horde
.isOnQuest 26557
.goto 76,25.29,74.79,30,0
.goto 76,27.98,73.94,30,0
.goto 76,29.15,75.48,30,0
>>Kill |cRXP_ENEMY_Weakened Mosshoof Stag|r.
.collect 58949,1,26557,1
.mob Weakened Mosshoof Stag
step << Horde
#completewith next
#label Sandy Carp
.isOnQuest 26557
.goto 85,45.51,47.61
>>Fish [Sandy Carp].
.complete 26557,1 
.usespell 131474
step << Horde
#completewith Sandy Carp
.cast 80868 >>Use |T135975:0|t[Stag Eye Bait]
.use 58949
step << Horde
#requires Sandy Carp
.isOnQuest 26557
.goto 85,45.51,47.61
>>Fish [Sandy Carp].
*|cRXP_WARN_You have 10 minutes before you need to get the bait again|r.
.complete 26557,1 
.aura -80868
.usespell 131474
step << Horde
.isOnQuest 26543
.goto 1,56.91,6.73,25,0
.goto 1,59.5,7.2,25,0
.goto 1,59.75,8.91,25,0
.goto 1,59.22,10.75,25,0
.goto 1,59.3,12.77,25,0
.goto 1,59.01,14.06,25,0
.goto 1,58.06,13.46,25,0
.goto 1,57.36,12.17,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the|cRXP_PICK_Clams|r on the |cRXP_WARN_ocean floor|r.
.complete 26543,1 
step << Horde
.isOnQuest 26588
.goto 1,36.88,10.51
>>Fish |T396545:0|t[|cRXP_LOOT_Giant Furious Pike|r.]
.complete 26588,1 
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Cooking
#internal
step << Alliance
.goto 84,50.67,73.81
.train 2550 >>Talk to |cRXP_FRIENDLY_Robby Flay|r in Stormwind.
.target Robby Flay
step << Alliance
.goto 84,50.66,73.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Robby Flay|r.
.daily 26153,26183,26190,26177,26192 >> Accept the Fishing Daily
.target Robby Flay
step << Alliance
.isOnQuest 26153
#loop
.goto 84,55.71,10.8,15,0
.goto 84,55.05,7.96,15,0
.goto 84,53.37,6.56,15,0
.goto 84,54.99,5.09,15,0
.goto 84,57.15,8.49,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pumpkins|r.
.complete 26153,1 
step << Alliance
.isOnQuest 26183
#loop
.goto 84,48.4,69.34,10,0
.goto 84,64.19,72.14,10,0
.goto 84,64.84,72.15,10,0
.goto 84,64.05,72.28,5,0
.goto 84,75.16,55.31,5,0
.goto 84,76.33,53.76,8,0
.goto 84,77.64,53.05,8,0
.goto 84,75.9,54.12,7,0
.goto 84,75.01,55.48,5,0
.goto 84,64.22,32.67,5,0
.goto 84,65.83,31.34,10,0
.goto 84,64.23,32.63,5,0
>>Buy |T134059:0|t[Confectioners' Sugar] from vendors in Stormwind.
.complete 26192,1 
.buy 57246,2
.target Lisa McKeever
.target Thurman Mullby
.target Erika Tate
.target Colin Field
.target Connor Rivers
step << Alliance
.isOnQuest 26183
.goto 84,49.98,78.84,25,0
.goto 84,51.75,81.52,25,0
.goto 84,48.83,83.31,25,0
.goto 84,44.01,74.92,25,0
.goto 84,55.08,74.17,25,0
.goto 84,54.15,63.66,25,0
.goto 84,60.07,58.81,25,0
.goto 84,57.26,56.26,25,0
.goto 84,49.3,50.98,25,0
.goto 84,58.41,43.36,25,0
.goto 84,62.11,34.93,25,0
.goto 84,66.84,51.58,25,0
.goto 84,72.61,55.74,25,0
.goto 84,76.2,62.06,25,0
.goto 84,72.49,67.89,25,0
.goto 84,65.45,62.26,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Apples|r laying around |cRXP_WARN_apple trees|r.
.complete 26183,1 
step << Alliance
.isOnQuest 26190
#loop
.goto 84,54.96,68.24,10,0
.goto 84,46.28,56.76,10,0
.goto 84,62.87,50.53,10,0
.goto 84,69.48,41.12,10,0
.goto 84,70.84,43.8,10,0
.goto 84,74.25,50.39,10,0
.goto 84,68.86,64.84,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
.complete 26190,1 
step << Alliance
.isOnQuest 26177
#loop
.goto 84,57.69,77.33,30,0
.goto 84,54.68,70.24,30,0
.goto 84,54.94,65.57,30,0
.goto 84,59.86,60.91,30,0
.goto 84,61.84,59.73,30,0
.goto 84,70.32,66.6,30,0
.goto 84,66.4,58.06,30,0
.goto 84,67.49,53.61,30,0
.goto 84,70.94,49.42,30,0
.goto 84,63.87,51.85,30,0
.goto 84,58.62,42.26,30,0
.goto 84,62.21,56.81,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crabs|r.
.complete 26177,1 
step << Horde
.goto 85,56.54,62.49
.train 2550 >>Talk to |cRXP_FRIENDLY_Marogg|r in Orgrimmar.
.target Marogg
step << Horde
.goto 85,56.54,62.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marogg|r.
.daily 26227,26226,26235,26220,26233,26234 >> Accept the Cooking Daily
.target Marogg
step << Horde
.isOnQuest 26227
#loop
.goto 85,59.99,61.29,30,0
.goto 85,59.31,54.41,30,0
.goto 85,60.68,52.15,30,0
.goto 85,58.95,49.24,30,0
.goto 85,52.37,49.1,30,0
.goto 85,42.83,47.9,30,0
.goto 85,46.38,53.38,30,0
.goto 85,42.71,55.53,30,0
.goto 85,41.24,59.81,30,0
.goto 85,40.85,66.62,30,0
.goto 85,42.58,70.57,30,0
.goto 85,43.9,69.06,30,0
.goto 85,44.96,73.94,30,0
.goto 85,49.94,86.56,30,0
.goto 85,50.62,75.08,30,0
.goto 85,52.13,65.93,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Prickly Pear Fruit|r.
.complete 26227,1 
step << Horde
.isOnQuest 26235
#loop
.goto 85,58.59,64.59,20,0
.goto 85,53.9,46.49,20,0
.goto 85,49.48,68.77,20,0
>>Kill |cRXP_ENEMY_Orgrimmar Thieves|r |cRXP_WARN_(Stealthed Orcs)|r
*Loot them for |T132762:0|t[|cRXP_LOOT_Horde Infantry Rations|r].
.complete 26235,1 
.mob Orgrimmar Thief
step << Horde
.isOnQuest 26233
.goto 85,36.51,73.04,20,0
.goto 85,35.14,69.78,20,0
.goto 85,32.48,68.64,20,0
.goto 85,27.67,65.45,20,0
.goto 85,32.4,64.62,20,0
.goto 85,35.6,66.12,20,0
.goto 85,34.86,67.96,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Barrels|r.
.complete 26233,1 
step << Horde
.isOnQuest 26234
.goto 85,36.51,73.04,20,0
.goto 85,35.14,69.78,20,0
.goto 85,32.48,68.64,20,0
.goto 85,27.67,65.45,20,0
.goto 85,32.4,64.62,20,0
.goto 85,35.6,66.12,20,0
.goto 85,34.86,67.96,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Barrels|r.
.complete 26233,1 
step << Horde
#loop
.isOnQuest 26220
.goto 1,49.07,15.98,30,0
.goto 1,48.22,15.92,30,0
.goto 1,46.82,14.84,30,0
.goto 1,42.81,15.25,30,0
>>Kill |cRXP_ENEMY_Boars|r.
*Loot them for |T350571:0|t[|cRXP_LOOT_Swine Belly|r].
.complete 26220,1 
.mob Mature Swine
.mob Wild Mature Swine
step << Horde
#loop
.isOnQuest 26226
.goto 85,62.84,39.16,20,0
.goto 85,62.82,43.56,20,0
.goto 85,65.67,43.99,20,0
.goto 85,67.4,42.43,20,0
.goto 85,69.07,43.67,20,0
.goto 85,70.69,41.69,20,0
.goto 85,72.02,39.19,20,0
.goto 85,74.99,38.74,20,0
.goto 85,56.4,54.26,30,0
.goto 85,47.64,49.8,30,0
.goto 85,46.85,46.11,30,0
.goto 85,43.65,45.9,30,0
.goto 85,30.88,62.47,30,0
.goto 85,26.74,63.34,30,0
.goto 85,28.47,66.25,30,0
.goto 85,31.31,66.08,30,0
.goto 85,34.58,72.5,30,0
.goto 85,36.77,75.33,30,0
.goto 85,36.51,85.27,30,0
.goto 85,38.7,85.49,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Muddy Crawfish|r.
.complete 26226,1 
.mob Muddy Crawfish
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Balloon
#internal
step << Alliance
.isQuestAvailable 29412
.goto 84,58.91,52.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vin|r.
.accept 29412 >>Accept Blown Away
.target Vin
step << Horde
.isQuestAvailable 29401
.goto 85,48.13,46.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaga|r.
.accept 29401 >>Accept Blown Away
.target Jaga
step << Alliance
.isOnQuest 29412
#loop
.goto 84,61.9,51.5,20,0
.goto 84,64.8,51.0,20,0
.goto 84,61.0,42.9,20,0
.goto 84,59.7,35.9,20,0
.goto 84,61.5,33.3,20,0
.goto 84,63.1,28.4,20,0
.goto 84,66.0,33.5,20,0
.goto 84,66.8,38.8,20,0
.goto 84,64.5,38.9,20,0
.goto 84,63.1,41.9,20,0
.goto 84,64.6,44.7,20,0
.goto 84,68.0,44.5,20,0
.goto 84,71.6,47.7,20,0
.goto 84,74.0,45.2,20,0
.goto 84,74.2,49.4,20,0
.goto 84,73.6,54.6,20,0
.goto 84,75.5,56.5,20,0
.goto 84,76.2,61.5,20,0
.goto 84,75.5,64.5,20,0
.goto 84,72.8,68.5,20,0
.goto 84,72.9,61.6,20,0
.goto 84,70.5,57.5,20,0
.goto 84,64.6,68.3,20,0
.goto 84,63.5,65.6,20,0
.goto 84,59.8,68.3,20,0
.goto 84,60.6,73.6,20,0
.goto 84,61.7,77.0,20,0
.goto 84,52.7,77.1,20,0
.goto 84,52.6,82.7,20,0
.goto 84,51.0,84.5,20,0
.goto 84,48.8,89.7,20,0
.goto 84,47.5,84.1,20,0
.goto 84,48.5,76.5,20,0
.goto 84,46.2,64.8,20,0
.goto 84,52.5,62.8,20,0
.goto 84,55.2,58.6,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Balloons|r.
.complete 29412,1 
step << Horde
.isOnQuest 29401
#loop
.goto 85,50.2,49.8,20,0
.goto 85,52.5,49.5,20,0
.goto 85,55.1,53.0,20,0
.goto 85,56.9,57.8,20,0
.goto 85,56.7,62.7,20,0
.goto 85,56.9,57.8,20,0
.goto 85,57.0,65.3,20,0
.goto 85,53.6,62.9,20,0
.goto 85,53.8,65.5,20,0
.goto 85,52.5,66.0,20,0
.goto 85,52.5,68.9,20,0
.goto 85,50.1,68.7,20,0
.goto 85,52.5,73.8,20,0
.goto 85,53.5,76.5,20,0
.goto 85,52.7,79.7,20,0
.goto 85,53.7,82.5,20,0
.goto 85,53.6,83.7,20,0
.goto 85,50.0,84.8,20,0
.goto 85,49.5,77.5,20,0
.goto 85,47.7,81.6,20,0
.goto 85,40.5,80.7,20,0
.goto 85,38.5,86.7,20,0
.goto 85,37.5,77.6,20,0
.goto 85,34.8,73.5,20,0
.goto 85,35.0,67.4,20,0
.goto 85,31.5,68.6,20,0
.goto 85,35.8,49.6,20,0
.goto 85,40.0,39.6,20,0
.goto 85,52.2,39.5,20,0
.goto 85,63.7,23.5,20,0
.goto 85,64.8,17.5,20,0
.goto 85,66.8,13.3,20,0
.goto 85,68.5,30.1,20,0
.goto 85,68.1,36.6,20,0
.goto 85,71.5,35.8,20,0
.goto 85,68.1,36.6,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Balloons|r.
.complete 29401,1 
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Selfie Cam
#internal
step << Alliance
.isQuestAvailable 32470
.goto 84,61.34,22.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arielle Snapflash|r.
.accept 32470 >>Accept Light Camera Action
.target Arielle Snapflash
step << Horde
.isQuestAvailable 32470
.goto 85,34.49,70.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivica Starshot|r.
.accept 32470 >>Accept Light Camera Action
.target Vivica Starshot
step << Alliance
.isOnQuest 32470
.goto 84,68.07,67.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Box|r.
*Loot it for |T133215:0|t[|cRXP_LOOT_Iron Box|r].
*Kill the |cRXP_ENEMY_Giant Rat|r if you get into combat.
.complete 32470,1 
.mob Giant Rat
step << Alliance
.isOnQuest 32470
.goto 84,53.23,82.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duncan Cullen|r.
.collect 3593,1 
.buy 3593,1
.target Duncan Cullen
step << Horde
.isOnQuest 32470
.goto 85,60.92,59.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'phan|r.
.complete 32470,3 
.buy 3593,1
.target Tor'phan
step << Horde
.isOnQuest 32470
.goto 85,63.76,19.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Box|r.
*Loot it for |T133215:0|t[|cRXP_LOOT_Iron Box|r].
*Kill the |cRXP_ENEMY_Giant Rat|r if you get into combat.
.complete 32470,1 
step << Alliance
.isOnQuest 32470
>>Buy a |T134441:0|t[Standard Scope] from the Auction House.
.collect 4406,1 
.target Auctioneer Fitch
step << Horde
.isOnQuest 32470
.goto 85,66.76,36.19
>>Buy a |T134441:0|t[Standard Scope] from the Auction House.
.complete 32470,2 
.target Auctioneer Kuvi
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Warbanding Together
#internal
step << Alliance
.isQuestAvailable 83493
.isQuestAvailable 83494
#completewith next
#label WarbandsAlliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut in tanaris|r.
.accept 83493 >>Accept Warbands: Rift Reader
.accept 83494 >>Accept Warbands: Space Ghosts by the Coast
.target Blue
step << Alliance
#completewith WarbandsAlliance
.goto 84,43.73,85.39
.zone 74 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Caverns of Time|r in the Portal room.
step << Alliance
#requires WarbandsAlliance
.isQuestAvailable 83493
.isQuestAvailable 83494
.goto 71,52.51,26.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut in tanaris|r.
.accept 83493 >>Accept Warbands: Rift Reader
.accept 83494 >>Accept Warbands: Space Ghosts by the Coast
.target Blue
step << Horde
#completewith next
#label WarbandsHorde
.isQuestAvailable 83493
.isQuestAvailable 83494
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut in tanaris|r.
.accept 83493 >>Accept Warbands: Rift Reader
.accept 83494 >>Accept Warbands: Space Ghosts by the Coast
.target Blue
step << Horde
#completewith WarbandsHorde
.goto 85,54.86,89.66,10,0
.goto 85,54.7,87.17,10,0
.goto 85,55.87,87.01,10,0
.goto 85,56.4,92.54
.zone 74 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Caverns of Time|r in the Portal room.
step << Horde
#requires WarbandsHorde
.isQuestAvailable 83493
.isQuestAvailable 83494
.goto 71,52.51,26.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut in tanaris|r.
.accept 83493 >>Accept Warbands: Rift Reader
.accept 83494 >>Accept Warbands: Space Ghosts by the Coast
.target Blue
step
.isOnQuest 83493,83494
#hidewindow
#completewith Partially Teleported Kobold
#loop
.goto 71,52.05,33.81,20,0
.goto 71,51.33,35.2,20,0
.goto 71,50.76,34.66,20,0
.goto 71,51.34,32.82,20,0
+1
step
.isOnQuest 83493,83494
#completewith next
>>Kill |cRXP_ENEMY_Partially Teleported Kobold, Murloc|r and |cRXP_ENEMY_Trogg|r. Loot them for |T463877:0|t[cRXP_LOOT_Spatial Residue|r].
.complete 83494,1 
.mob Partially Teleported Kobold
.mob Partially Teleported Murloc
.mob Partially Teleported Trogg
step
.isOnQuest 83493,83494
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Portals|r.
.complete 83493,1 
step
.isOnQuest 83493,83494
#label Partially Teleported Kobold
>>Kill |cRXP_ENEMY_Partially Teleported Kobold, Murloc|r and |cRXP_ENEMY_Trogg|r. Loot them for |T463877:0|t[cRXP_LOOT_Spatial Residue|r].
.complete 83494,1 
.mob Partially Teleported Kobold
.mob Partially Teleported Murloc
.mob Partially Teleported Trogg
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Squally
#internal
step
#completewith next
#label Squally
.achievementComplete 19030,1
.isQuestAvailable 82809
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Squally|r |cRXP_WARN_next to you|r.
.accept 82809 >>Accept Gryphons of a Feather
.target Squally
.use 4266
step
#completewith Squally
.cast 420759 >>Press the Macro in the "Active Items Frame" to summon the pet "Squally"
.macro Summon Squally,5333904 >>/summonpet Squally
step
#requires Squally
.achievementComplete 19030,1
.isQuestAvailable 82809
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Squally|r |cRXP_WARN_next to you|r.
.accept 82809 >>Accept Gryphons of a Feather
.target Squally
.use 4266
step
.achievementComplete 19030,1
.isOnQuest 82809
#completewith next
#label Kurdran Wildhammer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.complete 82809,1 
.skipgossip 222277,1
.target Kurdran Wildhammer
step
#completewith Kurdran Wildhammer
.goto 85,57.12,87.31 << Horde
.goto 84,48.91,93.42 << Alliance
.zone 2112 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Valdrakken|r
step
#requires Kurdran Wildhammer
.achievementComplete 19030,1
.isOnQuest 82809
.goto 2112,38.34,94.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.complete 82809,1 
.skipgossip 222277,1
.target Kurdran Wildhammer
step
.achievementComplete 19030,1
.isOnQuest 82809
.goto 2025,49.30,80.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Thundo|r.
.complete 82809,4 
.target Thundo
.mob Stormshroud Defender
step
.achievementComplete 19030,1
.isOnQuest 82809
.goto 2023,58.37,31.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Gale|r |cRXP_WARN_approach him from behind|r.
.complete 82809,3 
.target Gale
step
.achievementComplete 19030,1
.isOnQuest 82809
#label Flash
.goto 2022,71.17,25.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flash|r
.complete 82809,2 
.target Flash
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Delve Quests
#internal
step
.goto 85,57.12,87.31 << Horde
.goto 84,48.11,91.97 << Alliance
.zone 2112 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Dornogal|r in the Mage Tower.
*skip this step manually if you are already within a delve or in Khaz'Algar
step
.isQuestAvailable 83770
.goto 2347,52.89,76.03
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83770 >>Accept Delver's Call: Spiral Weave
.target DELVER'S CALL: Spiral Weave
step
.isOnQuest 83770
>>Complete Spiral Weave
.complete 83770,1 >>Complete Delver's Call: Spiral Weave
step
.isQuestAvailable 83768
.goto 2310,72.33,55.14
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83768 >>Accept Delver's Call: The Skittering Breach
.target DELVER'S CALL: The Skittering Breach
step
.isOnQuest 83768
>>Complete The Skittering Breach
.complete 83768,1 >>Complete Delver's Call: The Skittering Breach
step
.isQuestAvailable 83767
.goto 2301,53.14,20.35
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83767 >>Accept Delver's Call: The Sinkhole
.target DELVER'S CALL: The Sinkhole
step
.isOnQuest 83767
>>Complete The Sinkhole
.complete 83767,1 >>Complete Delver's Call: The Sinkhole
step
.isQuestAvailable 83769
.goto 2312,19.63,36.55
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83769 >>Accept Delver's Call: Mycomancer Cavern
.target DELVER'S CALL: Mycomancer Cavern
step
.isOnQuest 83769
>>Complete Mycomancer Cavern
.complete 83769,1 >>Complete Delver's Call: Mycomancer Cavern
step
.isQuestAvailable 85664
.goto 2277,72.72,27.39
>>Click on the |cRXP_PICK_Scroll|r.
.accept 85664 >>Accept Delver's Call: Nightfall Sanctum
.target DELVER'S CALL: Nightfall Sanctum
step
.isOnQuest 85664
>>Complete Nightfall Sanctum
.complete 85664,1 >>Complete Delver's Call: Nightfall Sanctum
step
.isQuestAvailable 85648
.goto 2269,44.45,12.18
>>Click on the |cRXP_PICK_Scroll|r.
.accept 85648 >>Accept Delver's Call: Earthcrawl Mines
.target DELVER'S CALL: Earthcrawl Mines
step
.isOnQuest 85648
.goto 2249,61.32,79.92
>>Click on the |cRXP_PICK_Scroll|r.
.complete 85648,1 >>Complete Delver's Call: Earthcrawl Mines
step
.isQuestAvailable 83758
.goto 2249,61.32,79.92
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83758 >>Accept Delver's Call: Fungal Folly
.target DELVER'S CALL: Fungal Folly
step
.isOnQuest 83758
>>Complete Fungal Folly
.complete 83758,1 >>Complete Delver's Call: Fungal Folly
.target DELVER'S CALL: Fungal Folly
step
.isQuestAvailable 83759
.goto 2250,35.65,27.44
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83759 >>Accept Delver's Call: Kriegval's Rest
.target DELVER'S CALL: Kriegval's Rest
step
.isOnQuest 83759
>>Complete Kriegval's Rest
.complete 83759,1 >>Complete Delver's Call: Kriegval's Rest
.target DELVER'S CALL: Kriegval's Rest
step
.isQuestAvailable 83766
.goto 2302,30.04,54.66
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83766 >>Accept Delver's Call: Dread Pit
.target DELVER'S CALL: Dread Pit
step
.isOnQuest 83766
>>Complete Dread Pit
.complete 83766,1 >>Complete Delver's Call: Dread Pit
.target DELVER'S CALL: Dread Pit
step
.isQuestAvailable 85649
.goto 2251,46.52,17.92
>>Click on the |cRXP_PICK_Scroll|r.
.accept 85649 >>Accept Delver's Call: The Waterworks
.target DELVER'S CALL: The Waterworks
step
.isOnQuest 85649
>>Complete The Waterworks
.complete 85649,1 >>Complete Delver's Call: The Waterworks
.target DELVER'S CALL: The Waterworks
step
.isQuestAvailable 83771
.goto 2259,53.21,20.52
>>Click on the |cRXP_PICK_Scroll|r.
.accept 83771 >>Accept Delver's Call: Tak'Rethan Abyss
.target DELVER'S CALL: Tak'Rethan Abyss
step
.isOnQuest 83771
>>Complete Tak'Rethan Abyss
.complete 83771,1 >>Complete Delver's Call: Tak'Rethan Abyss
.target DELVER'S CALL: Tak'Rethan Abyss
step
.isQuestAvailable 85667
.goto 2299,35.94,26.31
>>Click on the |cRXP_PICK_Scroll|r.
.accept 85667 >>Accept Delver's Call: The Underkeep
.target DELVER'S CALL: The Underkeep
step
.isOnQuest 85667
>>Complete The Underkeep
.complete 85667,1 >>Complete Delver's Call: The Underkeep
.target DELVER'S CALL: The Underkeep
step
.isQuestAvailable 85666
>>Click on the |cRXP_PICK_Scroll|r.
.accept 85666 >>Accept Delver's Call: Spiral Weave
.target DELVER'S CALL: Spiral Weave
step
.isOnQuest 85666
>>Complete Spiral Weave
.complete 85666,1 >>Complete Delver's Call: Spiral Weave
.target DELVER'S CALL: Spiral Weave
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Gidwin
#internal
step
.zone 23 >>Go to Eastern Plaguelands
step
.goto 23,9.05,66.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.accept 27370 >>Accept Tarenar Sunstrike
.target Fiona
.accept 27367 >>Accept Gidwin Goldbraids
step
.goto 23,4.14,36.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r
.turnin 27367 >>Turn in Gidwin Goldbraids
.target Gidwin Goldbraids
.accept 27368 >>Accept Just Encased
step
#loop
.goto 23,5.35,34.74,30,0
.goto 23,5.19,33.23,30,0
.goto 23,6.19,32.81,30,0
.goto 23,7.45,31.88,30,0
.goto 23,6.11,31.23,30,0
.goto 23,7.26,30.49,30,0
.goto 23,8.76,29.48,30,0
>>Kill |cRXP_ENEMY_Spiders|r
*Loot them for |T132104:0|t[|cRXP_LOOT_Crypt Bile|r].
.complete 27368,1 
.mob Crypt Walker
.mob Crypt Slayer
step
#completewith next
#label Just Encased
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r
.turnin 27368 >>Turn in Just Encased
.target Gidwin Goldbraids
.accept 27369 >>Accept Greasing the Wheel
.disablecheckbox
step
#completewith Just Encased
.goto 23,4.14,36.01,20 >>Leave the Cave
step
#requires Just Encased
.goto 23,4.14,36.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r
.turnin 27368 >>Turn in Just Encased
.target Gidwin Goldbraids
.accept 27369 >>Accept Greasing the Wheel
step
#loop
.goto 23,3.22,40.92,30,0
.goto 23,4.95,49.16,30,0
.goto 23,8.51,55.83,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bells|r.
.complete 27369,1 
step
.goto 23,9.01,66.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.turnin 27369 >>Turn in Greasing the Wheel
.target Fiona
step
.goto 23,18.37,74.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.turnin 27370 >>Turn in Tarenar Sunstrike
.target Tarenar Sunstrike
.accept 27371 >>Accept What I Do Best
step
#loop
.goto 23,18.49,77.14,30,0
.goto 23,17.32,78.59,30,0
.goto 23,19.43,77.5,20,0
.goto 23,19.28,79.46,30,0
.goto 23,18.7,82.47,30,0
.goto 23,16.34,79.46,30,0
>>Kill |cRXP_ENEMY_Death's Step Miscreation|r
.complete 27371,1 
.mob Death's Step Miscreation
step
.goto 23,17.06,79.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shiekone|r
.accept 27372 >>Accept A Gift For Fiona
.target Shiekone
.turnin 27371 >>Turn in *undefined*
step
#loop
.goto 23,18.4,75.56,30,0
.goto 23,18.27,57.68,30,0
>>Kill |cRXP_ENEMY_Hounds|r
*Loot them for |T237513:0|t[|cRXP_LOOT_Plaguehound Blood|r].
.complete 27372,1 
.mob Plaguehound Runt
step
.goto 23,9.02,66.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.turnin 27372 >>Turn in A Gift For Fiona
.target Fiona
.accept 27373 >>Accept Onward, to Light's Hope Chapel
step
#completewith next
#label Ride Fiona's Caravan
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 27373,1 
step
#completewith Ride Fiona's Caravan
.goto 23,8.8,66.62
.gossipoption 37586 >>Click on the |cRXP_PICK_Caravan|r.
.timer 132,RP
step
#requires Ride Fiona's Caravan
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 27373,1 
step
.goto 23,34.85,69.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.turnin 27373 >>Turn in Onward, to Light's Hope Chapel
.target Fiona
step
.goto 23,35.26,68.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.accept 27381 >>Accept Traveling Companions
.target Tarenar Sunstrike
step
.goto 23,35.60,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin Redpath|r
.accept 27383 >>Accept Little Pamela
.target Carlin Redpath
step
#completewith next
#label Rough Roads
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argus Highbeacon|r twice on the tower.
.complete 27381,1 
.accept 27382 >>Accept Rough Roads
.disablecheckbox
.target Argus Highbeacon
step
#completewith Rough Roads
.goto 23,35.34,68.75,5 >>Leave the Tower
step
#requires Rough Roads
#loop
.goto 23,36,69.01,5,0
.goto 23,35.94,68.74,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argus Highbeacon|r twice on the tower.
.complete 27381,1 
.skipgossipid 37583
.accept 27382 >>Accept Rough Roads
.target Argus Highbeacon
step
.goto 23,32.49,83.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela Redpath|r
.turnin 27383 >>Turn in Little Pamela
.target Pamela Redpath
.accept 27384 >>Accept Pamela's Doll
.accept 27392 >>Accept I'm Not Supposed to Tell You This
step
#loop
.goto 23,34.45,84.87,5,0
.goto 23,34.52,85.48,5,0
.goto 23,34.41,85.07,5,0
.goto 23,34.19,84.89,5,0
.goto 23,34.08,85.33,5,0
.goto 23,34.21,85.1,5,0
.goto 23,34.48,85.15,5,0
.goto 23,34.47,85.42,5,0
.goto 23,34.43,84.88,5,0
.goto 23,35.38,85.32,5,0
.goto 23,35.48,82.96,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Parts|r
.collect 12887,1,27384,1
.collect 12886,1,27384,1
.collect 12888,1,27384,1
step
.goto 23,34.46,85.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on one of the |cRXP_PICK_Parts|r in your inventory.
.complete 27384,1 
.use 12886
step
.goto 23,40.29,83.83
>>Kill |cRXP_ENEMY_Lone Hunter|r
*Loot him for |T135651:0|t[|cRXP_LOOT_Joseph's Hunting Blade|r].
.complete 27392,1 
step
.goto 23,32.56,83.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela Redpath|r
.turnin 27392 >>Turn in I'm Not Supposed to Tell You This
.target Pamela Redpath
.turnin 27384 >>Turn in Pamela's Doll
.accept 27385 >>Accept Uncle Carlin
step
.goto 23,35.27,68.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.turnin 27381 >>Turn in Traveling Companions
.target Tarenar Sunstrike
step
.goto 23,35.58,68.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin Redpath|r
.turnin 27385 >>Turn in Uncle Carlin
.target Carlin Redpath
.accept 27386 >>Accept A Strange Historian
step
.goto 23,35.29,68.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r
.turnin 27386 >>Turn in A Strange Historian
.target Chromie
.accept 27387 >>Accept Villains of Darrowshire
.accept 27389 >>Accept Marauders of Darrowshire
.accept 27388 >>Accept Heroes of Darrowshire
step
#loop
.goto 23,33,50.59,30,0
.goto 23,33.71,48.69,30,0
.goto 23,33.51,46.23,30,0
.goto 23,37.01,46.86,30,0
>>Kill |cRXP_ENEMY_Undeads|r
*Loot them for |T133728:0|t[|cRXP_LOOT_Fetid Skulls|r].
*Use |T134095:0|t[Mystic Crystal] on them.
.complete 27389,1 
.use 13156
.mob Scourge Champion
step
.goto 23,37.34,60.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Skull|r.
.complete 27387,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Plaguebat|r
.complete 27382,1 
.mob Plaguebat
step
.goto 23,39.76,72.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r
.complete 27387,2 
step
#loop
.goto 23,37.74,69.84,30,0
.goto 23,42.35,70.55,30,0
.goto 23,42.57,73.93,30,0
.goto 23,37.02,75.48,30,0
>>Kill |cRXP_ENEMY_Plaguebat|r
.complete 27382,1 
.mob Plaguebat
step
.goto 23,35.70,69.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argus Highbeacon|r on the tower.
.turnin 27382 >>Turn in Rough Roads
.target Argus Highbeacon
step
.goto 23,35.57,68.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin Redpath|r inside the tower.
.complete 27388,1 
.skipgossipid 29395
.target Carlin Redpath
step
#completewith next
#label Redpath's
.goto 23,22.7,68.16,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shield|r.
.complete 27388,3 
step
#completewith Redpath's
.goto 23,22.15,68.16,25 >>Enter the House
step
#requires Redpath's
.goto 23,22.15,68.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shield|r.
.complete 27388,3 
step
#completewith next
#label Davil's Libram
.goto 23,22.61,68.67,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 27388,2 
step
#completewith Davil's Libram
.goto 23,22.61,68.27,5 >>Go Upstairs
step
#requires Davil's Libram
.goto 23,22.32,68.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 27388,2 
step
.goto 23,35.29,68.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r
.turnin 27389 >>Turn in Marauders of Darrowshire
.turnin 27387 >>Turn in Villains of Darrowshire
.turnin 27388 >>Turn in Heroes of Darrowshire
.accept 27390 >>Accept The Battle of Darrowshire
.target Chromie
step
#completewith next
#label Relic Bundle
>>Kill the waves of enemies |cRXP_WARN_it takes time|r.
*Follow the on-screen instructions talk to |cRXP_FRIENDLY_Joseph Redpath|r at fountain when prompted.
.complete 27390,1 
step
#completewith Relic Bundle
.goto 23,35.06,84.16
.cast 18987 >>Use |T133639:0|t[Relic Bundle] at the fountain.
.use 15209
step
#requires Relic Bundle
#loop
.goto 23,34.39,82.04,30,0
.goto 23,36.4,81.46,30,0
>>Kill the waves of enemies |cRXP_WARN_it takes time|r.
*Follow the on-screen instructions talk to |cRXP_FRIENDLY_Joseph Redpath|r at fountain when prompted.
.complete 27390,1 
.use 15209
.mob Servant of Horgus
.mob Marauding Skeleton
.mob Bloodletter
.mob Darrowshire Betrayer
.mob Redpath the Corrupted
.target Joseph Redpath
step
.goto 23,32.44,83.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela Redpath|r
.turnin 27390 >>Turn in The Battle of Darrowshire
.target Pamela Redpath
.accept 27391 >>Accept Hidden Treasures
step
.goto 23,32.22,83.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.turnin 27391 >>Turn in Hidden Treasures
step
.goto 23,34.85,69.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.accept 27448 >>Accept The Trek Continues
.target Fiona
step
#completewith next
#label Fiona's Caravan2
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 27448,1 
.target Fiona's Caravan
step
#completewith Fiona's Caravan2
.goto 23,34.99,69.29
.gossipoption 37587 >>Click on the |cRXP_PICK_Caravan|r.
.timer 110,RP
step
#requires Fiona's Caravan2
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 27448,1 
.target Fiona's Caravan
step
.goto 23,52.92,53.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.turnin 27448 >>Turn in The Trek Continues
.target Fiona
.accept 27455 >>Accept Boys Will Be Boys
step
.goto 23,74.36,53.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r
.turnin 27455 >>Turn in Boys Will Be Boys
.target Gidwin Goldbraids
.accept 27463 >>Accept A Boyhood Dream
step
.goto 24,43.44,87.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.turnin 27463 >>Turn in A Boyhood Dream
.target Lord Maxwell Tyrosus
.accept 27464 >>Accept Argent Call: The Trial of the Crypt
step
#completewith next
#label Trial of the Crypt
#hidewindow
.goto 23,77.81,50.79,5,0
.complete 27464,1 
step
#completewith Trial of the Crypt
.goto 23,77.84,51.33,10 >>Enter the Crypt
step
#requires Trial of the Crypt
#completewith next
#label Trial of the Crypt 2
.goto 23,78.2,51.21,5,0
.goto 23,78.12,50.33,5,0
.goto 23,77.77,50.36,5,0
>>Kill |cRXP_ENEMY_Argent Wardens|r and |cRXP_ENEMY_Lord Raymond George|r.
.complete 27464,1 
.mob Lord Raymond George
.mob Argent Warden
step
#requires Trial of the Crypt
#completewith Trial of the Crypt 2
.goto 23,77.81,51.36
.cast 85308 >>Use |T237450:0|t[Argent Scroll] within the tomb |cRXP_WARN_if noone has yet|r.
.use 61309
.use 85308
step
#requires Trial of the Crypt 2
.goto 23,77.77,51.42
>>Kill |cRXP_ENEMY_Argent Wardens|r and |cRXP_ENEMY_Lord Raymond George|r.
.complete 27464,1 
.mob Lord Raymond George
.mob Argent Warden
step
#completewith next
#label The Noxious Glade
.goto 23,77.74,50.36,5,0
.goto 23,77.4,50.53,5,0
.goto 23,77.43,51.33,5,0
.goto 23,77.82,51.21,5,0
.goto 23,77.76,50.78,5,0
.goto 23,77.35,50.84,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r inside the chapel.
.turnin 27464 >>Turn in Argent Call: The Trial of the Crypt
.target Lord Maxwell Tyrosus
.accept 27465 >>Accept Argent Call: The Noxious Glade
.disablecheckbox
step
#completewith The Noxious Glade
.goto 24,43.48,87.06,60 >>Leave the Crypt
step
#requires The Noxious Glade
.goto 24,43.48,87.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r inside the chapel.
.turnin 27464 >>Turn in Argent Call: The Trial of the Crypt
.target Lord Maxwell Tyrosus
.accept 27465 >>Accept Argent Call: The Noxious Glade
step
#loop
.goto 23,77.72,40.37,30,0
.goto 23,80.74,40.6,30,0
.goto 23,80.84,37.17,30,0
.goto 23,78.24,32.58,30,0
.goto 23,75.74,35.29,30,0
>>Kill |cRXP_ENEMY_Noxious Glade Cultists|r and |cRXP_ENEMY_Noxious Glade Scourge|r
.complete 27465,2 
.complete 27465,1 
.mob Noxious Glade Cultists
.mob Noxious Glade Scourge
.mob Death Singer
.mob Dread Weaver
.mob Noxious Assassin
.mob Diseased Flayer
.mob Skullmage
step
#completewith next
#label Argent Call: The Noxious Glade
.goto 23,75.38,52.69,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.turnin 27465 >>Turn in Argent Call: The Noxious Glade
.target Lord Maxwell Tyrosus
step
#completewith Argent Call: The Noxious Glade
.goto 24,43.18,87.80,25 >>Enter the castle
step
#requires Argent Call: The Noxious Glade
.goto 24,43.18,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.turnin 27465 >>Turn in Argent Call: The Noxious Glade
.target Lord Maxwell Tyrosus
step
#completewith next
#label Argent Call: Northdale
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.accept 27466 >>Accept Argent Call: Northdale
.target Tarenar Sunstrike
step
#completewith Argent Call: Northdale
.goto 23,75.39,52.71,5 >>Leave the building to respawn the npcs within it
step
#requires Argent Call: Northdale
.goto 24,42.51,91.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.accept 27466 >>Accept Argent Call: Northdale
.target Tarenar Sunstrike
































































































step
.goto 23,61.49,42.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.turnin 27466 >>Turn in Argent Call: Northdale
.target Fiona
step
.goto 23,61.58,43.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.accept 27487 >>Accept Ix'lar the Underlord
.target Tarenar Sunstrike
step
#loop
.goto 23,60.7,30.28,30,0
.goto 23,63.09,35.2,30,0
.goto 23,59.76,35.02,30,0
>>Kill |cRXP_ENEMY_Ix'lar the Underlord|r and his |cRXP_ENEMY_minions|r
.complete 27487,1 
.complete 27487,2 
.mob Ix'lar the Underlord
.mob Nerubian Sycophant
.mob Gangled Golem
.mob Scourge Guard
step
.goto 23,61.48,42.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r
.turnin 27487 >>Turn in Ix'lar the Underlord
.target Fiona
step
.goto 23,61.57,43.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.accept 27488 >>Accept Impatience
.target Tarenar Sunstrike
step
.goto 23,65.48,24.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 27488,1 
step
.goto 23,61.56,43.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.turnin 27488 >>Turn in Impatience
.target Tarenar Sunstrike
.accept 27489 >>Accept Nobody to Blame but Myself
step
#completewith next
#label Northpass Tower
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 27489,1 
step
#completewith Northpass Tower
.goto 23,61.6,42.54
.gossipoption 37588 >>Click on the |cRXP_PICK_Caravan|r
.timer 95,RP
step
#requires Northpass Tower
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 27489,1 
step
.goto 23,50.44,20.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.turnin 27489 >>Turn in Nobody to Blame but Myself
.target Tarenar Sunstrike
.accept 27522 >>Accept Beat it Out of Them
step
#loop
.goto 23,53.29,15.88,30,0
.goto 23,55.43,16.51,30,0
.goto 23,56.86,19.23,30,0
>>Kill |cRXP_ENEMY_Scourge Siege Engineer|r
.complete 27522,2 
.complete 27522,3 
.complete 27522,1 
.mob Scourge Siege Engineer
step
.goto 23,50.51,20.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fiona|r.
.turnin 27522 >>Turn in Beat it Out of Them
.target Fiona
.accept 27524 >>Accept Blind Fury
.target Argus Highbeacon
step
.goto 23,27.59,21.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.turnin 27524 >>Turn in Blind Fury
.target Tarenar Sunstrike
step
.goto 23,25.38,19.82
>>Kill |cRXP_ENEMY_Omasum Blighthoof|r
*Loot him for |T134327:0|t[|cRXP_LOOT_The Baroness' Missive|r].
.accept 27551 >>Accept The Baroness' Missive
.mob Omasum Blighthoof
step
.goto 23,27.77,21.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.turnin 27551 >>Turn in The Baroness' Missive
.target Tarenar Sunstrike
.accept 27526 >>Accept Gidwin's Fate Revealed
step
.goto 23,29.22,26.29,10,0
.goto 23,29.06,26.19
>>Enter the building and wait for the cutscenes.
.complete 27526,1 
step
.goto 23,28.46,25.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r
.turnin 27526 >>Turn in Gidwin's Fate Revealed
.target Gidwin Goldbraids
.accept 27527 >>Accept Journey's End
step
.goto 23,73.65,51.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Caravan|r
.turnin 27560 >>Turn in Argus' Journal
.target Fiona's Caravan
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Alterac Valley Quests
#internal
step
.zone 25 >>Go to Hillsbrad Foothills
step << Alliance
.isQuestAvailable 7162
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.accept 7162 >>Accept Proving Grounds
.target Lieutenant Haggerdin
step << Alliance
.isOnQuest 7162
>>Queue for Alterac Valley and complete the quest.
.accept 7162,1 
step << Alliance
.reputation 730,exalted,3000 >>Queue for Alterac Valley until you reach exalted with the Stormpike Guard.
*Each Reputation Level rewards 1 additional quest for a total 6 quests on launch.
step << Horde
.isQuestAvailable 7161
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.accept 7161 >>Accept Proving Grounds
.target Warmaster Laggrond
step << Horde
.isOnQuest 7162
>>Queue for Alterac Valley and complete the quest.
.complete 7161,1 
step << Horde
.reputation 729,exalted,999 >>Queue for Alterac Valley until you reach exalted with the Frostwolf Clan.
>>For each Reputation Level, you earn an additional quest, allowing you to complete up to a total of 6 quests on launch.
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Pet Battle Setup
#internal
step << Alliance
.goto 84,69.49,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r train |T643856:0|t[Battle Pet Training] and any available pet
.train 125610 >>Train |T643856:0|t[Battle Pet Training]
.target Audrey Burnhep
step << Horde
.goto 85,52.56,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r train |T643856:0|t[Battle Pet Training] and any available pet
.train 125610 >>Train |T643856:0|t[Battle Pet Training]
.target Varzok
step << Alliance
.goto 84,61.17,70.8,-1
.goto 84,60.21,32.16,-1
>>Buy a |T797326:0|t[Zandalari Anklerender] from the Auction House on Level 1 |cRXP_WARN_if you can afford it|r.
.collectpet 70451,1
step << Horde
.goto 85,54.06,73.11,-1
.goto 85,66.53,36.32,-1
>>Buy a |T797326:0|t[Zandalari Anklerender] from the Auction House on Level 1 |cRXP_WARN_if you can afford it|r.
.collectpet 70451,1
step << Alliance
#loop
.goto 37,33.42,48.56,30,0
.goto 37,32.05,53.02,30,0
.goto 37,34.99,68.36,30,0
.goto 37,31.44,73.43,30,0
.goto 37,29.15,76.49,30,0
.goto 37,26.64,78.78,30,0
.goto 37,24.14,82.38,30,0
.goto 52,61.63,27.87,30,0
.goto 52,64.25,43.61,30,0
.goto 52,63.1,59.95,30,0
.goto 52,55.96,32.49,30,0
.achievement 6566,1 >>Defeat wild battle pets until you reach level 5 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.mob Rabbit
.mob Fawn
.mob Small Frog
.mob Prairie Dog
.mob Snake
.mob Chicken
step << Alliance
#loop
.goto 47,6.4,34.94,30,0
.goto 47,10.55,28.59,30,0
.goto 47,28.22,32.58,30,0
.goto 47,25.1,46.22,30,0
.goto 47,22.96,49.67,30,0
.goto 47,21.71,52.35,30,0
.goto 47,24,70.9,30,0
.goto 47,30.76,64.58,30,0
.goto 50,44.63,20.62,30,0
.goto 50,40.8,19.89,30,0
.goto 50,41.86,22.86,30,0
.goto 50,41.54,33.7,30,0
.goto 50,40.65,37.01,30,0
.achievement 6567,1 >>Defeat wild battle pets until you reach level 10 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.mob Mouse
.mob Small Frog
.mob Rabbit
.mob Black Rat
.mob Roach
.mob Skunk
.mob Dusk Spiderling
.mob Beetle
step << Alliance
.goto 210,49.83,15.5,30,0
.goto 210,48.33,20.24,30,0
.goto 210,46.71,57.79,30,0
.goto 210,49.83,15.5,30,0
.goto 210,48.33,20.24,30,0
.goto 210,46.71,57.79,30,0
.goto 32,28.56,81.73,30,0
.goto 32,29.07,70.27,30,0
.goto 32,30.23,58.99,30,0
.goto 32,29.59,51.13,30,0
.goto 32,32.13,42.96,30,0
.goto 32,52.26,69.15,30,0
.goto 36,35.75,30.15,30,0
.goto 36,34.03,39.54,30,0
.goto 36,40.01,59.23,30,0
.goto 36,26.79,59.01,30,0
.goto 36,18.83,59.55,30,0
.achievement 6568,1 >>Defeat wild battle pets until you reach level 15 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.mob Beetle
.mob Lizard Hatchling
.mob Strand Crab
.mob Crimson Moth
.mob Forest Spiderling
.mob Tree Frog
.mob Ash Spiderling
step << Alliance
#loop
.goto 32,28.56,81.73,30,0
.goto 32,29.07,70.27,30,0
.goto 32,30.23,58.99,30,0
.goto 32,29.59,51.13,30,0
.goto 32,32.13,42.96,30,0
.goto 32,52.26,69.15,30,0
.goto 36,35.75,30.15,30,0
.goto 36,34.03,39.54,30,0
.goto 36,40.01,59.23,30,0
.goto 36,26.79,59.01,30,0
.goto 36,18.83,59.55,30,0
.achievement 6569,1 >>Defeat wild battle pets until you reach level 20 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.use 125439
.use 86143
.mob Cockroach
.mob Mouse
.mob Scorpid
.mob Fire Beetle
.mob Ash Viper
.mob Lava Crab
step << Alliance
#completewith next
.goto 84,44.39,88.71,10,0
.zone 125 >>Take the Portal from Stormwind to Dalaran
step << Alliance
#label Level 25
#loop
.goto 127,40.36,45.78,30,0
.goto 127,53.72,46.48,30,0
.goto 127,39.23,57.66,30,0
.goto 127,33.92,53.54,30,0
.goto 127,27.03,48.45,30,0
.goto 127,15.08,49.89,30,0
.goto 127,35.29,34.23,30,0
.achievement 6570,1 >>Defeat wild battle pets until you reach level 25 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.use 125439
.use 8614
.mob Squirrel
.mob Cockroach
.mob Fire Beetle
.mob Ash Viper
.mob Lava Crab
step << Horde
#loop
.goto 1,43.02,20.84,30,0
.goto 1,45.8,23.56,30,0
.goto 1,45.65,30.05,30,0
.goto 1,45.77,35.77,30,0
.goto 1,41.21,39.37,30,0
.goto 1,35.98,41.75,30,0
.goto 10,66.28,42.49
.achievement 6566,1 >>Defeat wild battle pets until you reach level 5 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.mob Creepy Crawly
.mob Dung Beetle
.mob Water Snake
.mob Adder
step << Horde
.goto 63,64.45,84.17,30,0
.goto 63,61.12,83.3,30,0
.goto 63,60.79,80.09,30,0
.goto 63,57.06,73.54,30,0
.goto 63,53.58,71.77,30,0
.goto 65,73.2,55.37,30,0
.goto 65,71.34,56.73,30,0
.goto 65,74.85,64.97,30,0
.goto 199,32.58,9.93
.achievement 6567,1 >>Defeat wild battle pets until you reach level 10 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.mob Adder
.mob Prairie Dog
.mob Cheetah Cub
.mob Squirrel
.mob Forest Moth
.mob Toad
.mob Coral Snake
.mob Mountain Skunk
step << Horde
#loop
.goto 199,41.83,20.55,30,0
.goto 199,42.04,23.5,30,0
.goto 199,43.1,28.09,30,0
.goto 199,45.41,32.83,30,0
.goto 199,46.45,35.47,30,0
.goto 199,48.46,42.58,30,0
.goto 199,49.37,45.67,30,0
.goto 199,50.64,48.81,30,0
.goto 199,51.84,54.59,30,0
.goto 70,33.82,22.69,30,0
.goto 70,34.92,26.85,30,0
.goto 70,34.08,45.11,30,0
.goto 70,34.57,57.79,30,0
.goto 70,36.03,69.21,30,0
.goto 64,55.63,62.29
.achievement 6568,1 >>Defeat wild battle pets until you reach level 15 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.mob Spider
.mob Small Frog
.mob twilight iguana
step << Horde
#loop
.goto 78,65,36.42,30,0
.goto 78,65.74,41.43,30,0
.goto 78,65.82,51.98,30,0
.goto 78,47.15,64.35,30,0
.goto 78,42.91,64.71,30,0
.goto 78,38.56,66.23,30,0
.goto 78,34.61,67.51,30,0
.achievement 6569,1 >>Defeat wild battle pets until you reach level 20 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.use 125439
.use 86143
.mob Cockroach
.mob Beetle
.mob Ash Viper
.mob Lava Crab
.mob parrot
step << Horde
#completewith next
.goto 85,56.26,91.71,10,0
.zone 125 >>Take the Portal from Orgrimmar to Dalaran
step << Horde
#label Level 25
#loop
.goto 127,40.36,45.78,30,0
.goto 127,53.72,46.48,30,0
.goto 127,39.23,57.66,30,0
.goto 127,33.92,53.54,30,0
.goto 127,27.03,48.45,30,0
.goto 127,15.08,49.89,30,0
.goto 127,35.29,34.23,30,0
.achievement 6570,1 >>Defeat wild battle pets until you reach level 25 with any pet.
*If you are using the |T797326:0|t[Zandalari Anklerender] pet, spam |T132122:0|t[Rip]. Before defeating the opponent's pet, use |T132131:0|t[Devour] to heal.
.use 125439
.use 86143
.mob Cockroach
.mob Fire Beetle
.mob Ash Viper
.mob Lava Crab
step
#title |cFFFCDC00Skip this step to proceed|r
>>Buy the following Level 25 pets from the Auction House. |cRXP_WARN_If you can afford it, this will make things significantly faster and easier|r.
.collectpet 86447,3
.disablecheckbox
.collectpet 77221,3
.disablecheckbox
.collectpet 73011,3
.disablecheckbox
.collectpet 106181,3
.disablecheckbox
.collectpet 70451,3
.disablecheckbox
.collectpet 68662,3
.disablecheckbox
.collectpet 23909,3
.disablecheckbox
.collectpet 94867,3
.disablecheckbox
.collectpet 68659,1
.disablecheckbox
.collectpet 64899,3
.disablecheckbox
.collectpet 55356,3
.disablecheckbox
.collectpet 55367,3
.disablecheckbox
.collectpet 63098,3
.disablecheckbox
step
#title |cFFFCDC00Skip this step to proceed|r
*Create a Level 1 Orc in Durotar |cRXP_WARN_even if you only play alliance|r.
*|cRXP_WARN_This character is used to pick up Horde-specific quests that also work for Alliance, as they are account-wide and cannot be picked up on a high-level characters|r.
*|cRXP_WARN_Don't delete the character until after the guide is finished|r.
step << Horde
.goto 461,66.92,69.93,20,0
.goto 461,69.84,66.94,20,0
.goto 1,55.38,73.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Handler Marnlek|r.
.fly Orgrimmar >>Fly to Orgrimmar
.target Handler Marnlek
step << Horde
.isQuestTurnedIn 31966,31967
.goto 85,52.56,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31952 >>Accept Battle Pet Tamers: Pandaria
.target Varzok
step << Horde
.isQuestTurnedIn 31929,31927
.goto 85,52.59,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31967 >>Accept Battle Pet Tamers: Cataclysm
.target Varzok
step << Horde
.isQuestTurnedIn 31921,31919
.goto 85,52.54,59.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31929 >>Accept Battle Pet Tamers: Northrend
.target Varzok
step << Horde
.isQuestTurnedIn 31903,31902,31891,31889
.goto 85,52.54,59.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31921 >>Accept Battle Pet Tamers: Outland
step << Horde
.isQuestAvailable 31812
.goto 85,52.56,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r in Orgrimmar.
.accept 31812 >>Accept Zunta, The Pet Tamer
step << Horde
#completewith Cassandra Kaboom
.isQuestAvailable 31870
+Switch to a max-level Horde Character.
*|cRXP_WARN_If you don't have one, create a class trial Horde character|r.
step << Horde
.isOnQuest 31812
.goto 1,44.01,29.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zunta|r and defeat him in a pet battle.
.complete 31812,1 
.skipgossip
.target Zunta
step << Horde
.isOnQuest 31812
.goto 1,43.86,28.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zunta|r.
.turnin 31812 >>Turn in Zunta, The Pet Tamer
.target Zunta
step << Horde
.isQuestAvailable 31813
.goto 1,43.86,28.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zunta|r.
.accept 31813 >>Accept Dagra the Fierce
.target Zunta
step << Horde
.isOnQuest 31813
.goto 10,58.61,52.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dagra the Fierce|r and defeat him in a pet battle.
.complete 31813,1 
.skipgossip
.target Dagra the Fierce
step << Horde
.isOnQuest 31813
.goto 10,58.61,53.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dagra the Fierce|r.
.turnin 31813 >>Turn in Dagra the Fierce
.target Dagra the Fierce
step << Horde
.isQuestAvailable 31814
.goto 10,58.61,53.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dagra the Fierce|r.
.target Dagra the Fierce
.accept 31814 >>Accept Analynn
step << Horde
.isOnQuest 31814
.goto 63,20.05,29.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Analynn|r and defeat them in a pet battle.
.complete 31814,1 
.skipgossip
.target Analynn
step << Horde
.isOnQuest 31814
.goto 63,20.20,29.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Analynn|r.
.turnin 31814 >>Turn in Analynn
.target Analynn
step << Horde
.isQuestAvailable 31815
.goto 63,20.20,29.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Analynn|r.
.target Analynn
.accept 31815 >>Accept Zonya the Sadist
step << Horde
.isOnQuest 31815
.goto 65,59.80,71.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zonya the Sadist|r and defeat them in a pet battle.
.complete 31815,1 
.skipgossip
.target Zonya the Sadist
step << Horde
.isOnQuest 31815
.goto 65,59.66,71.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zonya the Sadist|r.
.turnin 31815 >>Turn in Zonya the Sadist
.target Zonya the Sadist
step << Horde
.isQuestAvailable 31817
.goto 65,59.66,71.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zonya the Sadist|r.
.target Zonya the Sadist
.accept 31817 >>Accept Merda Stronghoof
step << Horde
.isOnQuest 31817
.goto 66,57.25,45.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merda Stronghoof|r and defeat them in a pet battle.
.complete 31817,1 
.skipgossip
.target Merda Stronghoof
step << Horde
.isOnQuest 31817
.goto 66,57.11,45.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merda Stronghoof|r.
.turnin 31817 >>Turn in Merda Stronghoof
.target Merda Stronghoof
step << Horde
.isQuestAvailable 31870
.goto 66,57.11,45.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merda Stronghoof|r.
.target Merda Stronghoof
.accept 31870 >>Accept Cassandra Kaboom
step << Horde
.isOnQuest 31870
.goto 199,39.70,79.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cassandra Kaboom|r and defeat them in a pet battle.
.complete 31870,1 
.skipgossip
.target Cassandra Kaboom
step << Horde
#label Cassandra Kaboom
.isOnQuest 31870
.goto 199,39.59,79.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cassandra Kaboom|r.
.turnin 31870 >>Turn in Cassandra Kaboom
.target Cassandra Kaboom
step << Horde
#title |cFFFCDC00Skip this step to proceed|r
>>Log into your Level 1 Orc |cRXP_WARN_if you are not already|r.
step << Horde
.isQuestAvailable 31891
.goto 85,52.56,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31891 >>Accept Battle Pet Tamers: Kalimdor
.target Varzok
step << Horde
.isQuestAvailable 31903
.goto 85,52.56,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.target Varzok
.accept 31903 >>Accept Battle Pet Tamers: Eastern Kingdoms
step
#title |cFFFCDC00Skip this step to proceed|r
*Create a Level 1 Human in Northshire Valley |cFFFF0000(even if you only play Horde)|r.
*|cRXP_WARN_This character is used to pick up Alliance specific quests and they cannot be picked up on a high level Alliance characters|r.
*|cRXP_WARN_Do not delete the level 1 Human until the guide tells you to|r.
step
#title |cFFFCDC00Skip this step to proceed|r
*Create a Level 1 Human in Northshire Valley |cRXP_WARN_even if you only play horde|r.
*|cRXP_WARN_This character is used to pick up Alliance-specific quests that also work for Horde, as they are account-wide and cannot be picked up on a high-level characters|r.
*|cRXP_WARN_Don't delete the character until after the guide is finished|r.
step << Alliance
.isQuestTurnedIn 31966,31967
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31930 >>Accept Battle Pet Tamers: Pandaria
.target Audrey Burnhep
step << Alliance
.isQuestTurnedIn 31929,31927
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31966 >>Accept Battle Pet Tamers: Cataclysm
.target Audrey Burnhep
step << Alliance
.isQuestTurnedIn 31921,31919
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31927 >>Accept Battle Pet Tamers: Northrend
.target Audrey Burnhep
step << Alliance
.isQuestTurnedIn 31903,31902,31891,31889
.goto 84,69.49,25.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31919 >>Accept Battle Pet Tamers: Outland
.target Audrey Burnhep
step << Alliance
.isQuestAvailable 31316
.goto 84,69.49,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r in Stormwind.
.accept 31316 >>Accept Julia, The Pet Tamer
.target Audrey Burnhep
step
#completewith Turn in Bill Buckler
.isQuestAvailable 31728
+Switch to a max-level Alliance Character.
*|cRXP_WARN_If you don't have one, create a class trial Alliance character|r.
step << Alliance
.isOnQuest 31316
.goto 37,41.38,83.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Julia Stevens|r and defeat them in a pet battle.
.complete 31316,1 
.skipgossip
.target Julia Stevens
step << Alliance
.isOnQuest 31316
.goto 37,41.65,83.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Julia Stevens|r.
.turnin 31316 >>Turn in Julia, The Pet Tamer
.target Julia Stevens
step << Alliance
.isQuestAvailable 31724
.goto 37,41.65,83.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old MacDonald|r.
.target Old MacDonald
.accept 31724 >>Accept Old MacDonald
step << Alliance
.isOnQuest 31724
.goto 52,61.04,18.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old MacDonald|r and defeat them in a pet battle.
.complete 31724,1 
.skipgossip
.target Old MacDonald
step << Alliance
.isOnQuest 31724
.goto 52,60.86,18.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old MacDonald|r.
.turnin 31724 >>Turn in Old MacDonald
.target Old MacDonald
step << Alliance
.isQuestAvailable 31725
.goto 52,60.86,18.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lindsay|r.
.target Lindsay
.accept 31725 >>Accept Lindsay
step << Alliance
.isOnQuest 31725
.goto 49,33.04,53.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lindsay|r and defeat them in a pet battle.
.complete 31725,1 
.skipgossip
step << Alliance
.isOnQuest 31725
.goto 49,33.29,52.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lindsay|r.
.turnin 31725 >>Turn in Lindsay
.target Lindsay
step << Alliance
.isQuestAvailable 31726
.goto 49,33.29,52.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lindsay|r.
.target Lindsay
.accept 31726 >>Accept Eric Davidson
step << Alliance
.isOnQuest 31726
.goto 47,19.91,45.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eric Davidson|r and defeat them in a pet battle.
.complete 31726,1 
.skipgossip
step << Alliance
.isOnQuest 31726
.goto 47,19.88,44.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eric Davidson|r.
.turnin 31726 >>Turn in Eric Davidson
.target Eric Davidson
step << Alliance
.isQuestAvailable 31729
.goto 47,19.88,44.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eric Davidson|r.
.target Eric Davidson
.accept 31729 >>Accept Steven Lisbane
step << Alliance
.isOnQuest 31729
.goto 50,46.17,40.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steven Lisbane|r and defeat them in a pet battle.
.complete 31729,1 
.skipgossip
step << Alliance
.isOnQuest 31729
.goto 50,46.01,40.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steven Lisbane|r.
.turnin 31729 >>Turn in Steven Lisbane
.target Steven Lisbane
step << Alliance
.isQuestAvailable 31728
.goto 50,46.01,40.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steven Lisbane|r.
.target Steven Lisbane
.accept 31728 >>Accept Bill Buckler
step << Alliance
.isOnQuest 31728
.goto 210,51.22,73.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bill Buckler|r and defeat them in a pet battle.
.complete 31728,1 
.skipgossip
step << Alliance
#label Turn in Bill Buckler
.isOnQuest 31728
.goto 210,51.47,73.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bill Buckler|r.
.turnin 31728 >>Turn in Bill Buckler
.target Bill Buckler
step << Alliance
#title |cFFFCDC00Skip this step to proceed|r
>>Log into your Level 1 Human |cRXP_WARN_if you are not already|r.
step << Alliance
.isQuestAvailable 31902
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31902 >>Accept Battle Pet Tamers: Eastern Kingdoms
.target Audrey Burnhep
step << Alliance
.isQuestAvailable 31889
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.target Audrey Burnhep
.accept 31889 >>Accept Battle Pet Tamers: Kalimdor
step
#title |cFFFCDC00Skip this step to proceed|r
.isOnQuest 31902,31903
>>|cRXP_WARN_Switch to a max-level character, either Horde or Alliance|r.
step
.isOnQuest 31902,31903
#completewith next
.zone 51 >>Go to Swamp of Sorrows
step
.isOnQuest 31902
.goto 51,76.54,41.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Everessa|r and defeat them in a pet battle.
.complete 31902,4 
.skipgossip
step
.isOnQuest 31902,31903
#completewith next
.zone 51 >>Go to Swamp of Sorrows
step
.isOnQuest 31903
.goto 51,76.54,41.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Everessa|r and defeat them in a pet battle.
.complete 31903,4 
.skipgossip
.target Everessa
step
.isOnQuest 31902,31903
#completewith next
.zone 36 >>Go to Burning Steppes
step
.isOnQuest 31902
.goto 36,25.58,47.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durin Darkhammer|r and defeat them in a pet battle.
.complete 31902,5 
.skipgossip
step
.isOnQuest 31902,31903
#completewith next
.zone 36 >>Go to Burning Steppes
step
.isOnQuest 31903
.goto 36,25.58,47.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durin Darkhammer|r and defeat them in a pet battle.
.complete 31903,5 
.skipgossip
.target Durin Darkhammer
step
.isOnQuest 31902,31903
#completewith next
.zone 32 >>Go to Searing Gorge
step
.isOnQuest 31902
.goto 32,35.75,27.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kortas Darkhammer|r and defeat them in a pet battle.
.complete 31902,3 
.skipgossip
step
.isOnQuest 31902,31903
#completewith next
.zone 32 >>Go to Searing Gorge
step
.isOnQuest 31903
.goto 32,35.75,27.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kortas Darkhammer|r and defeat them in a pet battle.
.complete 31903,3 
.skipgossip
.target Kortas Darkhammer
step
.isOnQuest 31902,31903
#completewith next
.zone 26 >>Go to Hinterlands
step
.isOnQuest 31902
.goto 26,62.78,54.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_David Kosse|r and defeat them in a pet battle.
.complete 31902,1 
.skipgossip
step
.isOnQuest 31902,31903
#completewith next
.zone 26 >>Go to Hinterlands
step
.isOnQuest 31903
.goto 26,62.78,54.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_David Kosse|r and defeat them in a pet battle.
.complete 31903,1 
.skipgossip
.target David Kosse
step
.isOnQuest 31902,31903
#completewith next
.zone 23 >>Go to Eastern Plaguelands
step
.isOnQuest 31902
.goto 23,67.16,52.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deiza Plaguehorn|r and defeat them in a pet battle.
.complete 31902,2 
.skipgossip
step
.isOnQuest 31902,31903
#completewith next
.zone 23 >>Go to Eastern Plaguelands
step
.isOnQuest 31903
.goto 23,67.16,52.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deiza Plaguehorn|r and defeat them in a pet battle.
.complete 31903,2 
.skipgossip
.target Deiza Plaguehorn
step
.isQuestAvailable 31903
.isQuestAvailable 31889
.isQuestAvailable 31891
.isOnQuest 31902
.isOnQuest 31903
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of the Battle Pet Tamers: Eastern Kingdoms Quests.
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.turnin 31902 >>Turn in Battle Pet Tamers: Eastern Kingdoms
step
.isQuestAvailable 31902
.isQuestAvailable 31889
.isQuestAvailable 31891
.isOnQuest 31902
.isOnQuest 31903
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of the Battle Pet Tamers: Eastern Kingdoms Quests.
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.turnin 31903 >>Turn in Battle Pet Tamers: Eastern Kingdoms
step
.isQuestAvailable 31915
.goto 42,40.45,76.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest PoP-UP to accept [Defeat Grand Master Lydia Accoste]
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.accept 31915 >>Accept Grand Master Lydia Accoste
step
.isOnQuest 31915
#completewith next
.zone 42 >>Go to Deadwind Pass
step
.isOnQuest 31915
.goto 42,40.45,76.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydia Accoste|r and defeat them in a pet battle.
.complete 31915,1 
.skipgossip
.target Lydia Accoste
step
.isQuestComplete 31915
.goto 42,40.38,76.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to turn in the quest [Grand Master Lydia Accoste]
*|cRXP_WARN_You can minimize the other pop-ups and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.turnin 31915 >>Turn in Grand Master Lydia Accoste
.target Shiekrunner
step
.isOnQuest 31889,31891
>>|cRXP_WARN_Switch to a max-level character, either Horde or Alliance|r.
step
.isOnQuest 31889,31891
#completewith next
.zone 69 >>Go to Feralas
step
.isOnQuest 31889
.goto 69,59.61,49.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Traitor Gluk|r and defeat them in a pet battle.
.complete 31889,1 
.skipgossip
.target Traitor Gluk
step
.isOnQuest 31889,31891
#completewith next
.zone 69 >>Go to Feralas
step
.isOnQuest 31891
.goto 69,59.61,49.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Traitor Gluk|r and defeat them in a pet battle.
.complete 31891,1 
.skipgossip
.target Traitor Gluk
step
.isOnQuest 31889,31891
#completewith next
.zone 70 >>Go to Dustwallow Marsh
step
.isOnQuest 31889
.goto 70,53.81,74.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grazzle the Great|r and defeat them in a pet battle.
.complete 31889,2 
.skipgossip
.target Grazzle the Great
step
.isOnQuest 31889,31891
#completewith next
.zone 70 >>Go to Dustwallow Marsh
step
.isOnQuest 31891
.goto 70,53.81,74.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grazzle the Great|r and defeat them in a pet battle.
.complete 31891,2 
.skipgossip
.target Grazzle the Great
step
.isOnQuest 31889,31891
#completewith next
.zone 64 >>Go to Thousand Needles
step
.isOnQuest 31889
.goto 64,11.81,32.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kela Grimtotem|r and defeat them in a pet battle.
.complete 31889,3 
.skipgossip
.target Kela Grimtotem
step
.isOnQuest 31889,31891
#completewith next
.zone 64 >>Go to Thousand Needles
step
.isOnQuest 31891
.goto 64,11.81,32.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kela Grimtotem|r and defeat them in a pet battle.
.complete 31891,3 
.skipgossip
.target Kela Grimtotem
step
.isOnQuest 31889,31891
#completewith next
.zone 77 >>Go to Felwood
step
.isOnQuest 31889
.goto 77,40.01,56.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zoltan|r and defeat them in a pet battle.
.complete 31889,4 
.skipgossip
.target Zoltan
step
.isOnQuest 31889,31891
#completewith next
.zone 77 >>Go to Felwood
step
.isOnQuest 31891
.goto 77,40.01,56.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zoltan|r and defeat them in a pet battle.
.complete 31891,4 
.skipgossip
.target Zoltan
step
.isOnQuest 31889,31891
#completewith next
.zone 80 >>Go to Moonglade
step
.isOnQuest 31889
.goto 80,46.01,60.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elena Flutterfly|r and defeat them in a pet battle.
.complete 31889,5 
.skipgossip
.target Elena Flutterfly
step
.isOnQuest 31889,31891
#completewith next
.zone 80 >>Go to Moonglade
step
.isOnQuest 31891
.goto 80,46.01,60.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elena Flutterfly|r and defeat them in a pet battle.
.complete 31891,5 
.skipgossip
.target Elena Flutterfly





























step
.isQuestAvailable 31891
.isQuestAvailable 31902
.isQuestAvailable 31903
.isOnQuest 31889
.isOnQuest 31891
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of the Battle Pet Tamers: Kalimdor Quests.
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.turnin 31889 >>Turn in Battle Pet Tamers: Kalimdor
step
.isQuestAvailable 31889
.isQuestAvailable 31902
.isQuestAvailable 31903
.isOnQuest 31889
.isOnQuest 31891
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of the Battle Pet Tamers: Kalimdor Quests.
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.turnin 31891 >>Turn in Battle Pet Tamers: Kalimdor
step
.isQuestAvailable 31919
#completewith next
+Log into your Level 1 Human
step
.isQuestAvailable 31919
.goto 84,69.49,25.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31919 >>Accept Battle Pet Tamers: Outland
.target Audrey Burnhep
step
.isQuestAvailable 31921
#completewith next
+Log into your Level 1 Orc
step
.isQuestAvailable 31921
.goto 85,52.54,59.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31921 >>Accept Battle Pet Tamers: Outland
.target Varzok
step
.isOnQuest 31919,31921
#completewith next
.zone 111 >>Go to Shattrath
step
.isOnQuest 31919
.goto 111,59.51,69.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r and defeat them in a pet battle.
.complete 31919,4 
.skipgossip
step
.isOnQuest 31919,31921
#completewith next
.zone 111 >>Go to Shattrath
step
.isOnQuest 31921
.goto 111,59.51,69.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r and defeat them in a pet battle.
.complete 31921,4 
.skipgossip
step
.isOnQuest 31919,31921
#completewith next
.zone 107 >>Go to Narrok
step
.isOnQuest 31919
.goto 107,61.06,49.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narrok|r and defeat them in a pet battle.
.complete 31919,3 
.skipgossip
step
.isOnQuest 31919,31921
#completewith next
.zone 107 >>Go to Narrok
step
.isOnQuest 31921
.goto 107,61.06,49.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narrok|r and defeat them in a pet battle.
.complete 31921,3 
.skipgossip
step
.isOnQuest 31919,31921
#completewith next
.zone 102 >>Go to Zangarmarsh
step
.isOnQuest 31919
.goto 102,17.05,50.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ras'an|r and defeat them in a pet battle.
.complete 31919,2 
.skipgossip
step
.isOnQuest 31919,31921
#completewith next
.zone 102 >>Go to Zangarmarsh
step
.isOnQuest 31921
.goto 102,17.05,50.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ras'an|r and defeat them in a pet battle.
.complete 31921,2 
.skipgossip
step
.isOnQuest 31919,31921
#completewith next
.zone 100 >>Go to Hellfire Peninsula
step
.isOnQuest 31919
.goto 100,64.51,49.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nicki Tinytech|r and defeat them in a pet battle.
.complete 31919,1 
.skipgossip
step
.isOnQuest 31919,31921
#completewith next
.zone 100 >>Go to Hellfire Peninsula
step
.isOnQuest 31921
.goto 100,64.51,49.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nicki Tinytech|r and defeat them in a pet battle.
.complete 31921,1 
.skipgossip
step
.isQuestAvailable 31921
.isOnQuest 31919
.isOnQuest 31921
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of the Battle Pet Tamers: Outland
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.goto 100,64.44,49.31
.turnin 31919 >>Turn in Battle Pet Tamers: Outland
step
.isQuestAvailable 31919
.isOnQuest 31919
.isOnQuest 31921
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of the Battle Pet Tamers: Outland
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.goto 100,64.44,49.31
.turnin 31921 >>Turn in Battle Pet Tamers: Outland
step
.isQuestAvailable 31920
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to accept [Defeat Grand Master Antari]
*|cRXP_WARN_You can minimize the other pop-ups and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.goto 100,64.44,49.31
.accept 31920 >>Accept Grand Master Antari
step
.isOnQuest 31920
#completewith next
.zone 104 >>Go to Shadowmoon Valley
step
.isOnQuest 31920
.goto 104,30.43,42.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodknight Antari|r and defeat them in a pet battle.
.complete 31920,1 
.skipgossip
step
.isOnQuest 31920
.goto 104,30.51,41.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodknight Antari|r.
.turnin 31920 >>Turn in Grand Master Antari
.target Bloodknight Antari

step
.isQuestAvailable 31929
#completewith next
+Log into your Level 1 Orc
step
.isQuestAvailable 31929
.goto 85,52.54,59.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31929 >>Accept Battle Pet Tamers: Northrend
.target Varzok
step
.isQuestAvailable 31927
#completewith next
+Log into your Level 1 Human
step
.isQuestAvailable 31927
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31927 >>Accept Battle Pet Tamers: Northrend
.target Audrey Burnhep
step
.isOnQuest 31929,31927
#completewith next
>>|cRXP_WARN_Switch to a max-level character, either Horde or Alliance|r.
step
.isOnQuest 31929,31927
#completewith next
.zone 127 >>Go to Crystalsong Forest
step
.isOnQuest 31929
.goto 127,50.38,59.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r and defeat them in a pet battle.
.complete 31929,2 
.skipgossip
step
.isOnQuest 31929,31927
#completewith next
.zone 127 >>Go to Crystalsong Forest
step
.isOnQuest 31927
.goto 127,50.38,59.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r and defeat them in a pet battle.
.complete 31927,2 
.skipgossip
step
.isOnQuest 31929,31927
#completewith next
.zone 121 >>Go to Zul'Drak
step
.isOnQuest 31929
.goto 121,13.03,66.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gutretch|r and defeat them in a pet battle.
.complete 31929,4 
.skipgossip
step
.isOnQuest 31929,31927
#completewith next
.zone 121 >>Go to Zul'Drak
step
.isOnQuest 31927
.goto 121,13.03,66.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gutretch|r and defeat them in a pet battle.
.complete 31927,4 
.skipgossip
step
.isOnQuest 31929,31927
#completewith next
.zone 117 >>Go to Howling Fjord
step
.isOnQuest 31929
.goto 117,28.55,33.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beegle Blastfuse|r and defeat them in a pet battle.
.complete 31929,1 
.skipgossip
step
.isOnQuest 31929,31927
#completewith next
.zone 117 >>Go to Howling Fjord
step
.isOnQuest 31927
.goto 117,28.55,33.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beegle Blastfuse|r and defeat them in a pet battle.
.complete 31927,1 
.skipgossip
step
.isOnQuest 31929,31927
#completewith next
.zone 115 >>Go to Dragonblight
step
.isOnQuest 31929
.goto 115,59.02,76.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Okrut Dragonwaste|r and defeat them in a pet battle.
.complete 31929,3 
.skipgossip
step
.isOnQuest 31929,31927
#completewith next
.zone 115 >>Go to Dragonblight
step
.isOnQuest 31927
.goto 115,59.02,76.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Okrut Dragonwaste|r and defeat them in a pet battle.
.complete 31927,3 
.skipgossip
step
.isQuestAvailable 31929
.isOnQuest 31929
.isOnQuest 31927
.goto 115,59.02,76.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of Battle Pet Tamers: Northrend
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.turnin 31927 >>Turn in Battle Pet Tamers: Northrend
step
.isQuestAvailable 31927
.isOnQuest 31929
.isOnQuest 31927
.goto 115,59.02,76.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of Battle Pet Tamers: Northrend
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
*|cRXP_WARN_You can minimize the other pop-up and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.turnin 31929 >>Turn in Battle Pet Tamers: Northrend
step
.isOnQuest 31928
.goto 115,59.02,76.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to accept [Defeat Grand Master Payne]
*|cRXP_WARN_You can minimize the other pop-ups and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.accept 31928 >>Accept Grand Master Payne
step
.isOnQuest 31928
#completewith next
.zone 118 >>Go to Icecrown
step
.isOnQuest 31928
.goto 118,77.28,19.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Major Payne|r and defeat them in a pet battle.
.complete 31928,1 
.skipgossip
step
.isOnQuest 31928
.goto 118,77.39,19.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Major Payne|r.
.turnin 31928 >>Turn in Grand Master Payne
.target Major Payne

step
.isQuestAvailable 31966
#completewith next
+Log into your Level 1 Human
step
.isQuestAvailable 31966
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31966 >>Accept Battle Pet Tamers: Cataclysm
.target Audrey Burnhep
step
.isQuestAvailable 31967
#completewith next
+Log into your Level 1 Orc
step
.isQuestAvailable 31967
.goto 85,52.59,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31967 >>Accept Battle Pet Tamers: Cataclysm
.target Varzok
step
.isOnQuest 31966,31967
#completewith next
>>|cRXP_WARN_Switch to a max-level character, either Horde or Alliance|r.
step
.isOnQuest 31966,31967
#completewith next
.zone 198 >>Go to Hyjal
step
.isOnQuest 31966
.goto 198,61.38,33.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r and defeat them in a pet battle.
.complete 31966,1 
.skipgossip
step
.isOnQuest 31966,31967
#completewith next
.zone 198 >>Go to Hyjal
step
.isOnQuest 31967
.goto 198,61.38,33.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r and defeat them in a pet battle.
.complete 31967,1 
.skipgossip
step
.isOnQuest 31966,31967
#completewith next
.zone 207 >>Go to Deepholm
step
.isOnQuest 31966
.goto 207,50.06,57.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r and defeat them in a pet battle.
.complete 31966,2 
.skipgossip
step
.isOnQuest 31966,31967
#completewith next
.zone 207 >>Go to Deepholm
step
.isOnQuest 31967
.goto 207,50.06,57.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r and defeat them in a pet battle.
.complete 31967,2 
.skipgossip
step
.isOnQuest 31966,31967
#completewith next
.zone 241 >>Go to Twilight Highlands
step
.isOnQuest 31966
.goto 241,56.45,56.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r and defeat them in a pet battle.
.complete 31966,3 
.skipgossip
step
.isOnQuest 31966,31967
#completewith next
.zone 241 >>Go to Twilight Highlands
step
.isOnQuest 31967
.goto 241,56.45,56.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r and defeat them in a pet battle.
.complete 31967,3 
.skipgossip
step
.isQuestAvailable 31967
.isOnQuest 31966
.isOnQuest 31967
.goto 241,56.46,56.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of Battle Pet Tamers: Northrend
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
.turnin 31966 >>Turn in Battle Pet Tamers: Cataclysm
step
.isQuestAvailable 31966
.isOnQuest 31966
.isOnQuest 31967
.goto 241,56.46,56.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to |cFFFF0000ONLY|r turn in |cFFFF00001|r of Battle Pet Tamers: Northrend
*|cFFFF0000Keep the other one until launch night to turn it in for XP|r.
.turnin 31967 >>Turn in Battle Pet Tamers: Cataclysm
step
.isQuestAvailable 31970
.goto 241,56.46,56.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Quest Pop-UP to accept Grand Master Obalis
*|cRXP_WARN_You can minimize the other pop-ups and untrack the quest|r |cFFFF0000make sure all quest automation addons are off excluding RXP|r.
.accept 31970 >>Accept Grand Master Obalis
step
.isOnQuest 31970
#completewith next
.zone 1527 >>Go to Uldum
step
.isOnQuest 31970
.goto 1527,54.32,37.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Obalis|r and defeat them in a pet battle.
.complete 31970,1 
.skipgossip
step
.isOnQuest 31970
.goto 1527,54.44,37.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Obalis|r.
.turnin 31970 >>Turn in Grand Master Obalis
.target Obalis

step
.isQuestAvailable 31952
#completewith next
+Log into your Level 1 Orc
step
.isQuestAvailable 31952
.goto 85,52.56,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.accept 31952 >>Accept Battle Pet Tamers: Pandaria
.target Varzok
step
.isQuestAvailable 31930
#completewith next
+Log into your Level 1 Human
step
.isQuestAvailable 31930
.goto 84,69.48,25.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.accept 31930 >>Accept Battle Pet Tamers: Pandaria
.target Audrey Burnhep
step
.isOnQuest 31952,31930
#completewith next
>>|cRXP_WARN_Switch to a max-level character, either Horde or Alliance|r.
step
.isOnQuest 31952,31930
#completewith next
.zone 371 >>Go to Jade Forest
step
.isOnQuest 31952
.goto 371,47.99,53.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hyuna of the Shrines|r and defeat them in a pet battle.
.complete 31952,1 
.target Hyuna of the Shrines
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 371 >>Go to Jade Forest
step
.isOnQuest 31930
.goto 371,47.99,53.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hyuna of the Shrines|r and defeat them in a pet battle.
.complete 31930,1 
.target Hyuna of the Shrines
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 376 >>Go to Valley of the Four Winds
step
.isOnQuest 31952
.goto 376,45.81,43.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Nishi|r and defeat them in a pet battle.
.complete 31952,2 
.target Farmer Nishi
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 376 >>Go to Valley of the Four Winds
step
.isOnQuest 31930
.goto 376,45.81,43.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Nishi|r and defeat them in a pet battle.
.complete 31930,2 
.target Farmer Nishi
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 418 >>Go to Krasarang Wilds
step
.isOnQuest 31952
.goto 418,62.04,45.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mo'ruk|r and defeat them in a pet battle.
.complete 31952,3 
.skipgossip
.target Mo'ruk
step
.isOnQuest 31952,31930
#completewith next
.zone 418 >>Go to Krasarang Wilds
step
.isOnQuest 31930
.goto 418,62.04,45.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mo'ruk|r and defeat them in a pet battle.
.complete 31930,3 
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 422 >>Go to Dread Wastes
step
.isOnQuest 31952
.goto 422,54.94,37.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wastewalker Shu|r and defeat them in a pet battle.
.complete 31952,6 
.target Wastewalker Shu
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 422 >>Go to Dread Wastes
step
.isOnQuest 31930
.goto 422,54.94,37.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wastewalker Shu|r and defeat them in a pet battle.
.complete 31930,6 
.target Wastewalker Shu
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 379 >>Go to Kun-Lai Summit
step
.isOnQuest 31952
.goto 379,35.83,73.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Courageous Yon|r and defeat them in a pet battle.
.complete 31952,4 
.target Courageous Yon
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 379 >>Go to Kun-Lai Summit
step
.isOnQuest 31930
.goto 379,35.83,73.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Courageous Yon|r and defeat them in a pet battle.
.complete 31930,4 
.target Courageous Yon
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 388 >>Go to Townlong Steppes
step
.isOnQuest 31952
.goto 388,36.22,52.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Zusshi|r and defeat them in a pet battle.
.complete 31952,5 
.target Seeker Zusshi
.skipgossip
step
.isOnQuest 31952,31930
#completewith next
.zone 388 >>Go to Townlong Steppes
step
.isOnQuest 31930
.goto 388,36.22,52.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Zusshi|r and defeat them in a pet battle.
.complete 31930,5 
.target Seeker Zusshi
.skipgossip
*We no longer need the level 1 characters.
step
.isOnQuest 31952
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Pandaria Horde] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31930
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Pandaria Alliance] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31967
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Cataclysm Horde] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31966
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Cataclysm Alliance] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31929
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Northrend Horde] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31927
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Northrend Alliance] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31921
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Outland Horde] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31919
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Outland Alliance] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31903
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Eastern Kingdoms Horde] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31902
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Eastern Kingdoms Alliance] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31891
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Kalimdor Horde] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isOnQuest 31889
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Battle Pet Tamers: Kalimdor Alliance] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
>>|cRXP_WARN_Switch to a max-level or class trial alliance character|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Lindsay1
.zone 84 >> Go Stormwind
step
.isQuestAvailable 31850
.goto 47,19.87,44.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eric Davidson|r.
.daily 31850 >>Accept Eric Davidson
.target Eric Davidson
step
.isOnQuest 31850
.goto 47,19.87,44.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eric Davidson|r and defeat them in a pet battle.
.complete 31850,1 
.skipgossip
.target Eric Davidson
step
.isQuestComplete 31850
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Eric Davidson] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step.|
step
.isQuestAvailable 31851
.goto 210,51.49,73.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bill Buckler|r.
.daily 31851 >>Accept Bill Buckler
.target Bill Buckler
step
.isOnQuest 31851
.goto 210,51.49,73.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bill Buckler|r and defeat them in a pet battle.
.complete 31851,1 
.skipgossip
.target Bill Buckler
step
.isQuestComplete 31851
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Bill Buckler] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.isQuestAvailable 31781
.goto 49,33.29,52.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lindsay|r.
.daily 31781 >>Accept Lindsay
.target Lindsay
step
#label Lindsay1
.isOnQuest 31781
.goto 49,33.29,52.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lindsay|r and defeat them in a pet battle.
.complete 31781,1 
.skipgossip
.target Lindsay
step
.isQuestComplete 31781
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Lindsay] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
>>|cRXP_WARN_Switch to a max-level or class trial horde character|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step.|
step
#completewith DagraFierce
.isQuestAvailable 31819
.zone 85 >> Go Orgrimmar
step
.isQuestAvailable 31819
.goto 10,58.61,53.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dagra the Fierce|r.
.daily 31819 >>Accept Dagra the Fierce
.target Dagra the Fierce
step
#label DagraFierce
.isOnQuest 31819
.goto 10,58.61,53.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dagra the Fierce|r and defeat them in a pet battle.
.complete 31819,1 
.skipgossip
.target Dagra the Fierce
step
.isQuestComplete 31819
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Dagra the Fierce] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
>>|cRXP_WARN_Switch to a max-level or class trial horde or alliance character|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step.|
step
#completewith Defeat Major Payne
.isQuestAvailable 31935
.zone 118 >> Go to Icecrown
step
.isQuestAvailable 31935
.goto 118,77.28,19.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Master Payne|r and defeat them in a pet battle.
.daily 31935 >>Accept Grand Master Payne
.target Grand Master Payne
step
#label Defeat Major Payne
.isOnQuest 31935
.goto 118,77.28,19.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Master Payne|r and defeat them in a pet battle.
.complete 31935,1 
.skipgossip
step
.isQuestComplete 31935
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Grand Master Payne] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Shattrath
.isQuestAvailable 31925
.zone 111 >> Go to Shattrath
step
.isQuestAvailable 31925
.goto 111,59.51,69.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r and defeat them in a pet battle.
.daily 31925 >>Accept Morulu the Elder
.target Morulu the Elder
step
#label Shattrath
.isOnQuest 31925
.goto 111,59.51,69.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r and defeat them in a pet battle.
.complete 31925,1 
.skipgossip
.target Morulu the Elder
step
.isQuestComplete 31925
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Obalis] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Defeat Obalis
.isQuestAvailable 31971
.zone 1527 >> Go to Uldum
step
.isQuestAvailable 31971
.goto 1527,54.45,37.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Obalis|r.
.daily 31971 >>Accept Grand Master Obalis
.target Obalis
step
#label Defeat Obalis
.isOnQuest 31971
.goto 1527,54.45,37.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Obalis|r and defeat them in a pet battle.
.complete 31971,1 
.skipgossip
.target Obalis
step
.isQuestComplete 31971
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Obalis] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Defeat Nearly Headless Jacob
.isQuestAvailable 31932
.zone 127 >> Go to Crystalsong Forest
step
.isQuestAvailable 31932
.goto 127,50.09,58.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r.
.daily 31932 >>Accept Nearly Headless Jacob
.target Nearly Headless Jacob
step
#label Defeat Nearly Headless Jacob
.isOnQuest 31932
.goto 127,50.09,58.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r and defeat them in a pet battle.
.complete 31932,1 
.skipgossip
.target Nearly Headless Jacob
step
.isQuestComplete 31932
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Nearly Headless Jacob] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Defeat Bordin Steadyfist
.isQuestAvailable 31973
.zone 207 >> Go to Deepholm
step
.isQuestAvailable 31973
.goto 207,49.87,57.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r.
.daily 31973 >>Accept Bordin Steadyfist
.target Bordin Steadyfist
step
#label Defeat Bordin Steadyfist
.isOnQuest 31973
.goto 207,49.87,57.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r and defeat them in a pet battle.
.complete 31973,1 
.target Bordin Steadyfist
step
.isQuestComplete 31973
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Bordin Steadyfist] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Defeat Gutretch
.isQuestAvailable 31934
.zone 121 >> Go to Zul'drak
step
.isQuestAvailable 31934
.goto 121,13.25,66.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gutretch|r.
.daily 31934 >>Accept Gutretch
.target Gutretch
step
#label Defeat Gutretch
.isOnQuest 31934
.goto 121,13.25,66.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gutretch|r and defeat them in a pet battle.
.complete 31934,1 
.skipgossip
.target Gutretch
step
.isQuestComplete 31934
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Gutretch] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Defeat Brok
.isQuestAvailable 31972
.zone 198 >> Go to Hyjal
step
.isQuestAvailable 31972
.goto 198,61.39,32.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r.
.daily 31972 >>Accept Brok
.target Brok
step
#label Brok
.isOnQuest 31972
.goto 198,61.39,32.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r and defeat them in a pet battle.
.complete 31972,1 
.skipgossip
.target Brok
step
.isQuestComplete 31972
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Brok] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Defeat Goz Banefury
.isQuestAvailable 31974
.zone 241 >> Go to Twilight Highlands
step
.isQuestAvailable 31974
.goto 241,56.59,56.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r.
.daily 31974 >>Accept Goz Banefury
.target Goz Banefury
step
#label Defeat Goz Banefury
.isOnQuest 31974
.goto 241,56.59,56.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r and defeat them in a pet battle.
.complete 31974,1 
.skipgossip
.target Goz Banefury
step
.isQuestComplete 31974
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Goz Banefury] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step <<DarkIronDwarf
#completewith Defeat Bloodknight Antari
.isQuestAvailable 31926
.zone 104 >>Go to Shadowmoon Valley(Outland)
step <<DarkIronDwarf
.goto 104,30.51,41.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodknight Antari|r.
.target Bloodknight Antari
.daily 31926 >>Accept Grand Master Antari
step <<DarkIronDwarf
#label Defeat Bloodknight Antari
.goto 104,30.43,42.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodknight Antari|r and defeat them in a pet battle.
.complete 31926,1 
.target Bloodknight Antari
step <<DarkIronDwarf
.isQuestComplete 31926
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Grand Master Antari] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
#completewith Rescue Gurgl
.isQuestAvailable 64167
.zone 627 >> Go to Legion Dalaran
step
.isQuestAvailable 64167
.goto 627,58.47,39.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breanni|r.
.accept 64167 >>Accept Pets Detective
.target Breanni
step
.isOnQuest 64167
.goto 627,47.97,31.89
>>|cRXP_WARN_Follow the Arrow|r.
.complete 64167,1 
step
.isOnQuest 64167
.goto 627,47.97,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suspicious Onlooker|r.
.complete 64167,2 
.skipgossip
.target Suspicious Onlooker
step
.isOnQuest 64167
.goto 627,57.09,55.78
>>|cRXP_WARN_Follow the Arrow|r.
.complete 64167,3 
step
.isOnQuest 64167
.goto 627,57.09,55.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Precocious Onlooker|r.
.complete 64167,4 
.skipgossip
.target Precocious Onlooker
step
.isOnQuest 64167
.goto 627,55.48,82.13
>>|cRXP_WARN_Follow the Arrow|r.
.complete 64167,5 
.skipgossip
step
.isOnQuest 64167
.goto 627,55.48,82.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farsighted Onlooker|r.
.complete 64167,6 
.skipgossip
.target Farsighted Onlooker
step
.isOnQuest 64167
.goto 627,58.45,39.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breanni|r.
.turnin 64167 >>Turn in Pets Detective
step
.goto 627,58.45,39.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breanni|r.
.accept 64196 >>Accept Pet Up
.target Breanni
step
.isOnQuest 64196
.goto 790,74.24,67.69
>>|cRXP_WARN_Follow the Arrow|r.
.complete 64196,1 
step
.isOnQuest 64196
.goto 790,74.24,67.69
>>Interact with |cRXP_FRIENDLY_Stringfellowe|r |cRXP_WARN_If you have any instant heal abilities use those instead|r.
.complete 64196,3 
.use 186695
.target Stringfellowe
step
.isOnQuest 64196
.goto 790,73.24,74.98
>>Interact with |cRXP_FRIENDLY_Zantini|r |cRXP_WARN_If you have any instant heal abilities use those instead|r.
.complete 64196,2 
.use 186695
.target Zantini
step
.isOnQuest 64196
.goto 790,73.56,77.97
>>Interact with |cRXP_FRIENDLY_Speedy IV|r |cRXP_WARN_If you have any instant heal abilities use those instead|r.
.complete 64196,4 
.use 186695
.target Speedy IV
step
.isOnQuest 64196
.goto 790,73.24,74.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantini|r.
.turnin 64196 >>Turn in Pet Up
.target Zantini
step
.goto 790,73.24,74.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantini|r.
.accept 64203 >>Accept The Coast is Clear
.target Zantini
step
.isOnQuest 64203
.goto 790,73.41,74.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Speedy IV|r.
.complete 64203,1 
.skipgossip
.target Speedy IV
step
.isOnQuest 64203
#loop
.goto 790,74.27,67.48,25,0
.goto 790,70.44,63.92,25,0
.goto 790,70.87,61.27,25,0
.goto 790,74.04,58.45,25,0
.goto 790,75.6,52.12,25,0
.goto 790,75.79,50.99,25,0
.goto 790,77.76,53.94,25,0
.goto 790,77.77,55.64,25,0
.goto 790,76.63,57.5,25,0
.goto 790,78.37,62.19,25,0
.goto 790,78.13,64.57,25,0
.goto 790,78.12,66.13,25,0
.goto 790,75.89,63.45,25,0
>>Use |T839982:0|t[Spin'N Stun] near enemies to stun them make sure after clicking on the |cRXP_PICK_pet supplies|r to use |T965900:0|t[Dart] to sprint away
.complete 64203,2 
step
.isOnQuest 64203
.goto 790,73.23,74.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantini|r.
.turnin 64203 >>Turn in The Coast is Clear
.target Zantini
step
.goto 790,73.23,74.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantini|r.
.target Zantini
.accept 64215 >>Accept Paw Patrol
step
.isOnQuest 64215
#loop
.goto 790,43.39,42.56,30,0
.goto 790,40.08,42.77,30,0
.goto 790,43.4,38.99,30,0
.goto 790,45.53,37.37,30,0
.goto 790,42.92,35.28,30,0
.goto 790,46.96,36.41,30,0
.goto 790,48.55,34.25,30,0
.goto 790,49.73,33.14,30,0
>>Kill |cRXP_ENEMY_Violetsail Cutthroat|r, |cRXP_ENEMY_Violetsail Swiftshot|r and |cRXP_ENEMY_Violetsail Bruisebringer|r. Loot them for |T134242:0|t[Violetsail Pet Cage Key.]
*Use the keys to open |cRXP_PICK_Cages|r.
.complete 64215,1 
.collect 186772,6,64215,0x1,-1
.mob Violetsail Cutthroat
.mob Violetsail Swiftshot
.mob Violetsail Bruisebringer
step
.isOnQuest 64215
.goto 790,73.23,74.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantini|r.
.turnin 64215 >>Turn in Paw Patrol
.target Zantini
step
.goto 790,73.23,74.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantini|r.
.target Zantini
.accept 64237 >>Accept Gurgl and the Bandit
step
.isOnQuest 64237
.goto 790,31.96,58.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trainer Iris Greedsway|r and defeat her in a pet battle.
.complete 64237,1 
.skipgossip
.target Trainer Iris Greedsway
step
#label Rescue Gurgl
.isOnQuest 64237
.goto 790,32.08,58.20
>>Interact with |cRXP_FRIENDLY_Gurgl|r.
.complete 64237,2 
.target Gurgl
step
.isOnQuest 64237
*|cRXP_WARN_DO NOT TURN IN THE QUEST:|r. [Gurgl and the Bandit] |cRXP_WARN_BEFORE MIDNIGHT EXPANSION HAS LAUNCHED|r.
+|cFFFF0000To proceed in the guide, simply |TInterface/cursor/crosshair/interact.blp:20|tClick on the circle next to this text to manually skip this step|r.
step
.goto 23,66.96,52.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deiza Plaguehorn|r
*|cRXP_WARN_You need to do this on Alliance|r
.accept 31911 >>Accept Deiza Plaguehorn
.target Deiza Plaguehorn
step
.goto 23,67.16,52.19
>>Defeat |cRXP_ENEMY_Deiza Plaguehorn|r in a pet battle.
.complete 31911,1 
.target Deiza Plaguehorn
step
.goto 36,25.55,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durin Darkhammer|r
*|cRXP_WARN_You need to do this on Alliance|r
.accept 31914 >>Accept Durin Darkhammer
.target Durin Darkhammer
step
.goto 36,25.55,47.52
>>Defeat |cRXP_ENEMY_Durin Darkhammer|r in a pet battle.
.complete 31914,1 
.mob Durin Darkhammer
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Trading Post
#internal
step << Horde
#completewith Zen'kala's Inventory
>>Progress resets whenever you log into the opposite faction. Do this only when you no longer plan to log into the other faction before launch.
step << Horde
.isQuestAvailable 66959
>>Enter Orgrimmar
.accept 66959 >>Accept Tour the Trading Post
step << Horde
.isOnQuest 66959
.goto 85,48.44,75.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.complete 66959,1 
step << Horde
.isOnQuest 66959
.goto 85,48.27,74.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaa'je|r.
.complete 66959,3 
.target Zaa'je
step << Horde
.isOnQuest 66959
.goto 85,47.39,76.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gothal|r.
.complete 66959,2 
.target Gothal
step << Horde
.isOnQuest 66959
.goto 85,48.92,76.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 66959,4 
step << Horde
#label Zen'kala's Inventory
.isOnQuest 66959
.goto 85,48.77,75.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zen'kala|r.
.complete 66959,5 
.skipgossip
.target Zen'kala
step << Alliance
#completewith Seabraid's Inventory
>>Progress resets whenever you log into the opposite faction. Do this only when you no longer plan to log into the other faction before launch.
step << Alliance
.isQuestAvailable 66858
>>Enter Stormwind
.accept 66858 >>Accept Tour the Trading Post
step << Alliance
.isOnQuest 66858
.goto 84,51.32,72.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.complete 66858,1 
step << Alliance
.isOnQuest 66858
.goto 84,51.33,70.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dilya|r.
.complete 66858,3 
.target Dilya
step << Alliance
.isOnQuest 66858
#loop
.goto 84,49.17,71.77,10,0
.goto 84,48.09,72.07,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valarian|r.
.complete 66858,2 
.target Valarian
step << Alliance
.isOnQuest 66858
.goto 84,51.04,71.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 66858,4 
step << Alliance
#label Seabraid's Inventory
.isOnQuest 66858
.goto 84,51.07,72.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wilder Seabraid|r.
.complete 66858,5 
.skipgossip
.target Wilder Seabraid
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Endeavor
#internal
step << Alliance
.goto 84,62.89,71.61,-1
.goto 84,62.24,29.97,-1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hero's Call Board|r and accept "Broken Shore".
*|cRXP_WARN_You may need to accept another Call Board quest before you can accept the Broken Shore quest. If it still doesn’t work, skip this step.|r
*|cRXP_WARN_This is for an additional teleport to Stormwind|r
.accept 40519 >>Accept Legion: The Legion Returns
step << Horde
.goto 85,49.79,76.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hero's Call Board|r and accept "Broken Shore".
*|cRXP_WARN_You may need to accept another Call Board quest before you can accept the Broken Shore quest. If it still doesn’t work, skip this step.|r
*|cRXP_WARN_This is for an additional teleport to Orgrimmar|r
.accept 43926 >>Accept Legion: The Legion Returns
step
+This guide sets up 30+ quests within the same zone. It’s recommended to drop quests that send you far away, such as most Heritage Armor quests. With a recent update, Blizzard changed Burning Steppes and Tirisfal. If you still have quests in those zones, you can safely drop them, as they’re no longer useful. The same could happen to Endeavors, though it’s less likely.
*manually skip this step
step
+For Endeavors, you need to be part of a Neighborhood that has selected Grummies as this month’s Endeavor. Netherstorm also great, though it isn’t covered in this guide.
*manually skip this step
step
+This guide isn't optimized for efficient pickups, just to stack up all quests however the turnin steps will be optimized.
*manually skip this step
step << Horde
.zone 2351 >>Teleport to your Neighbourhood.
step << Horde
.zoneskip 2351,1
.zone 379 >>Take the portal to Kun-Lai Summit
step << Alliance
.zone 2352 >>Teleport to your Neighbourhood.
step << Alliance
.zoneskip 2352,1
.goto 2352,53.11,37.76
.zone 379 >>Take the portal to Kun-Lai Summit
step
.convertquest 30514,30515 << Horde
.convertquest 30583,31251 << Horde
.convertquest 30593,30594 << Horde
.convertquest 30619,30620 << Horde
.convertquest 30652,30657 << Horde
.convertquest 30650,30655 << Horde
.convertquest 30651,30656 << Horde
.convertquest 30660,30661 << Horde
step
#include RestedXP Speed Leveling\a) Kun-Lai Summit My Son@My Son...Start-Turn in The Waterspeaker's Staff
step
#title |cFFFCDC00Follow the Arrow|r
>>Don't turn in any quest there.
.complete 30834,1 
step
#include RestedXP Speed Leveling\a) Kun-Lai Summit Despoiler@BurilgiDespoilerStart-BurilgiDespoilerEnd
step
.goto 379,70.37,51.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anthea|r.
.accept 63435 >>Accept Temple Throwdown
.target Anthea
step
>>Defeat |cRXP_FRIENDLY_Anthea|r in a pet battle.
.complete 63435,1
step
.goto 379,68.78,43.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r.
.accept 31394 >>Accept A Celestial Experience
.target Anduin Wrynn
step
.goto 379,68.88,42.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xuen|r.
.complete 31394,1 
.timer 80,RP
.skipgossip
.target Xuen
step
.goto 379,68.78,44.01
>>Kill |cRXP_ENEMY_Spirit of Violence|r.
.complete 31394,2 
.timer 80,RP
.mob Spirit of Violence
step
.goto 379,68.78,44.01
>>Kill |cRXP_ENEMY_Spirit of Anger|r.
.complete 31394,3 
.timer 80,RP
.mob Spirit of Anger
step
.goto 379,68.78,44.01
>>Kill |cRXP_ENEMY_Spirit of Hatred|r.
.complete 31394,4 
.mob Spirit of Hatred
step
.goto 379,68.68,48.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gurgthock|r.
.accept 31207 >>Accept The Arena of Annihilation
.target Gurgthock
step
>>Finish the "The Arena of Annihilation" Scenario
.complete 31207,1 
step
.goto 379,65.49,60.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slimy Inkstain|r.
.accept 30614 >>Accept Oil Stop
.target Slimy Inkstain
step
.goto 379,64.88,60.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey Sootassle|r.
.accept 30616 >>Accept Traffic Issues
.target Smokey Sootassle
step
.goto 379,64.71,61.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Eightcoins|r.
.accept 30808 >>Accept A Grummle's Luck
.target Lucky Eightcoins
step
#completewith Filled Oil Vial
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30616,1 
.mob Ruqin Infantry
.mob Ruqin Elder
.mob Ruqin Outrider
step
#completewith Filled Oil Vial
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bags|r.
.complete 30808,1 
step
#label Filled Oil Vial
.goto 379,63.34,68.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Yaungol Oil Derrick|r.
.complete 30614,1 
step
#completewith Ruqin Yaungols
#hidewindow
#loop
.goto 379,62.19,69.29,20,0
.goto 379,62.04,67.93,20,0
.goto 379,63.38,66.86,20,0
.goto 379,62.19,69.29,0
.goto 379,62.04,67.93,0
.goto 379,63.38,66.86,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30616,1 
.mob Ruqin Infantry
.mob Ruqin Elder
.mob Ruqin Outrider
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bags|r.
.complete 30808,1 
step
#label Ruqin Yaungols
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30616,1 
.mob Ruqin Infantry
.mob Ruqin Elder
.mob Ruqin Outrider
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Keenbean|r and |cRXP_FRIENDLY_Cousin Gootfur|r.
.accept 30744 >>Accept Kota Blend
.accept 30745 >>Accept Trouble Brewing
.goto 379,42.42,69.66
.accept 30742 >>Accept Shut it Down
.accept 30743 >>Accept Gourmet Kafa
.goto 379,42.36,69.74
.target Uncle Keenbean
.target Cousin Gootfur
step
#hidewindow
#completewith Kafa-Crazed Yeti
#loop
.goto 379,40.52,71.32,15,0
.goto 379,38.55,72.66,15,0
.goto 379,37.88,74.9,15,0
.goto 379,40.45,72.64,15,0
.goto 379,40.85,73.33,15,0
.goto 379,40.23,75.24,15,0
.goto 379,39.41,77.1,15,0
.goto 379,39.35,74.9,15,0
.goto 379,39.19,74.56,15,0
.goto 379,39.19,74.16,15,0
.goto 379,38.46,74.39,15,0
.goto 379,37.87,73.91,15,0
.goto 379,38.54,74.4,15,0
.goto 379,38.11,72.48,15,0
.goto 379,38.69,74.22,15,0
.goto 379,39.26,74.38,15,0
.goto 379,39.42,75.46,15,0
.goto 379,39.03,76.65,15,0
.goto 379,38.44,78.28,15,0
.goto 379,37.78,80.29,15,0
.goto 379,36.72,79.3,15,0
.goto 379,36.77,77.87,15,0
.goto 379,39.46,72.72,15,0
+1
step
#completewith Kafa'kota Berry
>>Kill |cRXP_ENEMY_Kafa-Crazed Mountain Goats|r and |cRXP_ENEMY_Kafa-Crazed Yeti|r.
.complete 30742,1 
.complete 30745,1 
.mob Kafa-Crazed Yeti
.mob Kafa-Crazed Mountain Goat
step
#completewith Kafa'kota Berry
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Waste|r.
.complete 30743,1 
step
#label Kafa'kota Berry
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Berries|r
*Use |T133958:0|t[Kafa'kota Berries] to boost your stats|cRXP_WARN_(use in combat)|r.
.complete 30744,1 
.use 81054
step
#completewith next
>>Kill |cRXP_ENEMY_Kafa-Crazed Mountain Goats|r and |cRXP_ENEMY_Kafa-Crazed Yeti|r.
.complete 30742,1 
.complete 30745,1 
.mob Kafa-Crazed Yeti
.mob Kafa-Crazed Mountain Goat
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Waste|r.
.complete 30743,1 
step
#label Kafa-Crazed Yeti
>>Kill |cRXP_ENEMY_Kafa-Crazed Mountain Goats|r and |cRXP_ENEMY_Kafa-Crazed Yeti|r.
.complete 30742,1 
.complete 30745,1 
.mob Kafa-Crazed Yeti
.mob Kafa-Crazed Mountain Goat
step
.goto 379,58.1,61.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Trailscenter|r.
.accept 30592 >>Accept The Burlap Trail: To Burlap Waystation
.target Brother Trailscenter
step
.goto 379,57.34,61.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.accept 30999 >>Accept Path Less Traveled
.target Lorewalker Cho
step
.goto 379,57.23,61.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Cloverleaf|r.
.turnin 30999 >>Turn in Path Less Traveled
.accept 30601 >>Accept Instant Courage
.target Uncle Cloverleaf
step
#completewith next
#label Resupplying One Keg
.goto 379,57.69,61.58,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.accept 30618 >>Accept Resupplying One Keg
.target Big Sal
step
#completewith Resupplying One Keg
.goto 379,57.72,61.77,10 >>Enter the House
step
#requires Resupplying One Keg
.goto 379,57.72,61.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.accept 30618 >>Accept Resupplying One Keg
.target Big Sal
step
#completewith next
#label They Stole My Luck!
.goto 379,57.5,60.17,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside the house|r.
.accept 30621 >>Accept They Stole My Luck!
.target Ji-Lu the Lucky
step
#completewith They Stole My Luck!
.goto 379,57.33,60.19,10 >>Enter the House
step
#requires They Stole My Luck!
.goto 379,57.33,60.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside the house|r.
.accept 30621 >>Accept They Stole My Luck!
.target Ji-Lu the Lucky
step
#hidewindow
#completewith next
#label Lucky Virmen's Foot
.goto 379,59.12,52.86,20,0
.complete 30621,1 
step
#completewith Lucky Virmen's Foot
.goto 380,65.55,83.73,40 >>Enter the Cave
step
#requires Lucky Virmen's Foot
#hidewindow
#completewith Snow Piles
#loop
.goto 380,65.55,83.73,20,0
.goto 380,70.76,69.22,25,0
.goto 380,57.68,74.3,25,0
.goto 380,51.64,72.75,25,0
.goto 380,46.08,57.42,25,0
.goto 380,54.25,54.77,25,0
.goto 380,44.57,24.37,25,0
.goto 380,34.92,27.67,25,0
.goto 380,30.96,39.6,25,0
.goto 380,41.6,43.88,25,0
.goto 380,32.49,41.53,20,0
.goto 380,34.39,34.35,20,0
.goto 380,49.4,30.45,20,0
+1
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>Kill each |cRXP_ENEMY_Sprite|r seperately as only 1 item can drop at a time.
*Loot them for |T237176:0|t[|cRXP_LOOT_Belongins|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guides|r.
.complete 30601,1 
.skipgossip
.target Hiding Guide
step
#requires Lucky Virmen's Foot
#label Stolen Sprite Treasure
.turnin 31415 >> |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Treasure|r.
step
#completewith Hiding Guide
>>Kill each |cRXP_ENEMY_Sprite|r seperately as only 1 item can drop at a time.
*Loot them for |T237176:0|t[|cRXP_LOOT_Belongins|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
#completewith Hiding Guide
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#label Hiding Guide
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guides|r.
.complete 30601,1 
.skipgossip
.target Hiding Guide
step
#completewith next
>>Kill |cRXP_ENEMY_Sprites|r.
*Loot them for |T651358:0|t[|cRXP_LOOT_Belongins|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#label Snow Piles
>>Kill |cRXP_ENEMY_Sprites|r.
*Loot them for |T651358:0|t[|cRXP_LOOT_Belongins|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
.isQuestComplete 30621
.goto 379,59.14,53.15,25 >>Leave the Cave
step
.goto 379,58.71,64.77,20,0
.goto 379,58.29,64.78,20,0
.goto 379,49.74,67.57,20,0
.goto 379,53.08,66.58
>>|cRXP_WARN_Follow the Arrow,|r defend and escort the grummies.
.complete 30592,1 
.mob Knucklethump Snatcher
.mob Ookin Marauder
.mob Broketooth Spear-Haver
.target Trail Packer
step
.goto 379,51.67,67.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Trailscenter|r.
.turnin 30592 >>Turn in The Burlap Trail: To Burlap Waystation
.accept 30602 >>Accept The Rabbitsfoot
.target Brother Trailscenter
step
.goto 379,71.57,92.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Cheng|r.
.accept 30460 >>Accept Hit Medicine
.target Apothecary Cheng
step
.goto 379,72.27,91.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Bramblestaff|r.
.accept 30457 >>Accept Call Out Their Leader
.target Mayor Bramblestaff
step
.goto 379,70.75,90.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Hsieh|r.
.accept 30459 >>Accept All of the Arrows
.target Commander Hsieh
step
#completewith Dit Da Jow
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
#completewith Dit Da Jow
>>Use |T132798:0|t[Dit Da Jow] on |cRXP_FRIENDLY_Injured Binan Warrior|r.
*|cRXP_WARN_Prioritize your own healing spells, if you have any|r.
.complete 30460,1 
.use 79819
.target Injured Binan Warrior
step
#loop
.goto 379,70.52,89.43,25,0
.goto 379,70.15,90.44,25,0
.goto 379,69.23,90.44,25,0
.goto 379,67.59,89.61,25,0
.goto 379,67.58,88,25,0
.goto 379,68.66,86.9,25,0
>>Kill |cRXP_ENEMY_Taurens|r
.complete 30457,1 
.mob Bataari Flamecaller
.mob Bataari Yaungol
step
#label Dit Da Jow
#loop
.goto 379,68.05,88.35,25,0
.goto 379,69.46,89.2,25,0
#title |cFFFCDC00NPC Patrols|r
>>Kill |cRXP_ENEMY_Bataari Fire-Warrior|r
.complete 30457,2 
step
#hidewindow
#completewith Commander Hsieh
#loop
.goto 379,67.44,87.67,30,0
.goto 379,70.72,89.26,30,0
.goto 379,69.94,91.13,30,0
.goto 379,67.66,91.12,30,0
.goto 379,66.61,89.04,30,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
>>Use |T132798:0|t[Dit Da Jow] on |cRXP_FRIENDLY_Injured Binan Warrior|r.
*|cRXP_WARN_Prioritize your own healing spells, if you have any|r.
.complete 30460,1 
.use 79819
.target Injured Binan Warrior
step
#label Commander Hsieh
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
.goto 379,70.76,90.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Hsieh|r.
.turnin 30459 >>Turn in All of the Arrows
.target Commander Hsieh
step
.goto 379,72.27,91.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Bramblestaff|r.
.turnin 30457 >>Turn in Call Out Their Leader
.target Mayor Bramblestaff
step
.goto 379,71.57,92.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Cheng|r.
.turnin 30460 >>Turn in Hit Medicine
.target Apothecary Cheng
.accept 30508 >>Accept Admiral Taylor has Awakened
step
.goto 379,71.43,93.17,5,0
.goto 379,71.64,93.24,5,0
.goto 379,71.53,93.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r |cRXP_WARN_inside the house upstairs|r.
.turnin 30508 >>Turn in Admiral Taylor has Awakened
.target Admiral Taylor
.accept 30512 >>Accept Westwind Rest
step
.goto 379,58.87,80.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Bo|r.
.complete 30512,1 
.skipgossipid 41284
.target Farmhand Bo
step
.goto 379,56.34,84.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.complete 30512,2 
.skipgossipid 41467
.target Elder Tsulan
step
.goto 379,56.34,84.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.turnin 30512 >>Turn in Westwind Rest
.target Elder Tsulan
.accept 30514 >>Accept Challenge Accepted
step
#completewith next
#label Ur-Bataar
>>Kill the waves and |cRXP_ENEMY_Ur-Bataar|r.
.complete 30514,1 
.mob Ur-Bataar
step
#completewith Ur-Bataar
.goto 379,58.19,84.11
.cast 8386 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r
step
#requires Ur-Bataar
.goto 379,58.20,84.35
>>Kill the waves and |cRXP_ENEMY_Ur-Bataar|r.
.complete 30514,1 
.mob Ur-Bataar
step << Horde
.goto 379,61.58,80.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.turnin 30515 >>Turn in Challenge Accepted
.target Elder Shiao
step << Horde
.goto 379,63.00,80.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.accept 31256 >>Accept Round 'Em Up
.target General Nazgrim
step << Horde
.goto 379,62.70,80.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r.
.accept 30594 >>Accept Deanimate the Reanimated
.target Shademaster Kiryn
step << Horde
.goto 379,62.78,79.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r.
.accept 31251 >>Accept Best Meals Anywhere!
.target Rivett Clutchpop
step << Horde
.goto 379,62.53,79.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Ko|r.
.accept 30570 >>Accept Trouble on the Farmstead
.target Farmhand Ko
step << Horde
.goto 379,62.33,79.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.accept 30620 >>Accept Mogu?! Oh No-gu!
.target Elder Shiao
step << Alliance
.goto 379,54.69,84.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.turnin 30514 >>Turn in Challenge Accepted
.target Elder Tsulan
step << Alliance
.goto 379,54.69,84.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.turnin 30514 >>Turn in Challenge Accepted
.target Elder Tsulan
step << Alliance
.goto 379,53.77,82.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r.
.accept 30575 >>Accept Round 'Em Up
.target Admiral Taylor
step << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r and |cRXP_FRIENDLY_Elder Tsulan|r.
.accept 30583 >>Accept Blue Dwarf Needs Food Badly
.goto 379,54.15,83.30
.accept 30619 >>Accept Mogu?! Oh No-gu!
.goto 379,54.18,83.43
.target Elder Tsulan
.target Sully "The Pickle" McLeary
step << Alliance
.goto 379,53.78,84.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Bo|r.
.accept 30569 >>Accept Trouble on the Farmstead
.target Farmhand Bo
step << Alliance
#loop
.goto 379,53.45,83.36,10,0
.goto 379,53.46,83.08,10,0
.goto 379,53.68,83.28,10,0
.goto 379,53.45,83.36,0
.goto 379,53.46,83.08,0
.goto 379,53.68,83.28,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r.
.accept 30593 >>Accept Deanimate the Reanimated
.target Mishka
step
#completewith next
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
step
.goto 379,59.61,78.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bao Jian|r.
.accept 30595 >>Accept Profiting off of the Past
.target Bao Jian
step
#loop
.goto 379,58.84,76.29,40,0
.goto 379,57.77,76.89,40,0
.goto 379,56.62,76.53,40,0
.goto 379,56.88,75.53,40,0
.goto 379,57.96,74.50,40,0
.goto 379,59.28,73.51,40,0
.goto 379,59.98,75.57,20,0
.goto 379,58.84,76.29,0
.goto 379,57.77,76.89,0
.goto 379,56.62,76.53,0
.goto 379,56.88,75.53,0
.goto 379,57.96,74.50,0
.goto 379,59.28,73.51,0
.goto 379,59.98,75.57,0
>>Kill |cRXP_ENEMY_Mogu's|r.
*Loot them for |T454065:0|t[|cRXP_LOOT_Mogu Relic|r].
>>|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Relics|r
.complete 30593,1 
.complete 30595,1 
.mob Terracotta Guardian
.mob Terracotta Warrior
step
.goto 379,58.32,70.90
>>Kill |cRXP_ENEMY_Mogujia Soul-Caller|r.
.complete 30619,1 
.mob Mogujia Soul-Caller
step
#completewith next
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Chow|r. and |cRXP_FRIENDLY_Uyen Chow|r.
.turnin 30569 >>Turn in Trouble on the Farmstead << Alliance
.accept 30571 >>Accept Farmhand Freedom
.goto 379,60.25,85.81
.accept 30581 >>Accept ... and the Pot, Too!
.goto 379,60.17,85.93
.target Uyen Chow
.target Farmer Chow
step
#completewith Farmstead Slaves
#hidewindow
#loop
.goto 379,60.88,86.97,40,0
.goto 379,61.29,86.14,40,0
.goto 379,61.92,87.15,40,0
.goto 379,61.87,87.85,40,0
.goto 379,61.31,87.85,40,0
.goto 379,61.41,88.37,40,0
.goto 379,60.79,88.00,40,0
.goto 379,60.50,87.52,40,0
.goto 379,58.87,88.61,40,0
.goto 379,58.38,88.40,40,0
.goto 379,58.31,89.41,40,0
.goto 379,58.33,90.11,40,0
.goto 379,58.85,90.11,40,0
.goto 379,58.95,89.78,40,0
.goto 379,60.88,86.97,0
.goto 379,61.29,86.14,0
.goto 379,61.92,87.15,0
.goto 379,61.87,87.85,0
.goto 379,61.31,87.85,0
.goto 379,61.41,88.37,0
.goto 379,60.79,88.00,0
.goto 379,60.50,87.52,0
.goto 379,58.87,88.61,0
.goto 379,58.38,88.40,0
.goto 379,58.31,89.41,0
.goto 379,58.33,90.11,0
.goto 379,58.85,90.11,0
.goto 379,58.95,89.78,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Ordo Overseers|r to rescue the |cRXP_FRIENDLY_Slaves|r.
.complete 30571,1 
.mob Ordo Raider
.mob Ordo Overseer
step
>>Kill |cRXP_ENEMY_Wascally Wirmen|r.
*Loot them for |T250625:0|t[|cRXP_LOOT_Root Vegetables|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Root Vegetables|r.
.complete 30581,1 
.mob Wascally Wirmen
step
#label Farmstead Slaves
>>Kill |cRXP_ENEMY_Ordo Overseers|r to rescue |cRXP_FRIENDLY_Farmstead Slaves|r.
.complete 30571,1 
.mob Ordo Raider
.mob Ordo Overseer
step
.goto 379,60.09,88.24,5,0
.goto 379,60.02,88.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Root Vegetable|r |cRXP_WARN_inside the small house|r.
.complete 30581,2 
.mob Cookie McYaungol
step
#loop
.goto 379,57.58,87.26,30,0
.goto 379,54.05,88.74,30,0
.goto 379,53.26,90.94,30,0
.goto 379,51.9,88.52,30,0
.goto 379,52.11,84.21,30,0
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on 3x |cRXP_PICK_Wild Plains Yak|r
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
.mob Wild Plains Yak
step
.goto 379,53.79,84.11
>>Make sure 3x |cRXP_FRIENDLY_Captured Yak|r are following you.
*|cRXP_WARN_If not click on 3x |cRXP_PICK_Wild Plains Yak|r|r
*Bring them to |cRXP_FRIENDLY_Farmhand Bo|r
.complete 30575,1 
.target Captured Yak
.target Farmhand Bo
step
#completewith next
#label Defense of Shado-Pan
.goto 379,44.5,89.09,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.accept 30665 >>Accept The Defense of Shado-Pan Fallback
.accept 30670 >>Accept Turnabout
.target Shado-Master Chong
step
#completewith Defense of Shado-Pan
#title Enter Castle
.goto 379,44.48,89.93,35 >>Enter the Castle
step
#requires Defense of Shado-Pan
.goto 379,44.48,89.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.accept 30665 >>Accept The Defense of Shado-Pan Fallback
.accept 30670 >>Accept Turnabout
.target Shado-Master Chong
step
.goto 379,44.48,89.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.accept 30665 >>Accept The Defense of Shado-Pan Fallback
.accept 30670 >>Accept Turnabout
.target Shado-Master Chong
step
#completewith next
#label Holed Up
.goto 379,44.51,89.06,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sya Zhong|r |cRXP_WARN_inside the house|r.
.accept 30682 >>Accept Holed Up
.target Sya Zhong
step
#completewith Holed Up
.goto 379,42.94,88.32,100 >>Leave the Castle
step
#requires Holed Up
#completewith Holed Up2
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
#requires Holed Up
#completewith Holed Up2
>>Kill |cRXP_ENEMY_Blind Rage|r.
*Loot them for |T252178:0|t[|cRXP_LOOT_Blind Rage Essence|r].
.complete 30670,1 
.mob Blind Rage
step
#requires Holed Up
#label Holed Up2
.goto 379,42.94,88.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sya Zhong|r |cRXP_WARN_inside the house|r.
.accept 30682 >>Accept Holed Up
.target Sya Zhong
step
#completewith Jin Warmkeg
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
#completewith Jin Warmkeg
>>Kill |cRXP_ENEMY_Blind Rage|r.
*Loot them for |T252178:0|t[|cRXP_LOOT_Blind Rage Essence|r].
.complete 30670,1 
.mob Blind Rage
step
.goto 379,43.12,88.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sya Zhong|r.
.complete 30682,4 
.target Sya Zhong
step
#completewith next
#label Ya Firebough
#hidewindow
.complete 30682,2 
.target Ya Firebough
step
#completewith Ya Firebough
.goto 379,41.07,87.00
.gossipoption 37051 >>Talk to |cRXP_FRIENDLY_Ya Firebough|r.
step
#requires Ya Firebough
#completewith next
#label Old Lady Fung
#hidewindow
.complete 30682,3 
step
#requires Ya Firebough
#completewith Old Lady Fung
.goto 379,41.25,87.13,5,0
.goto 379,42.76,85.87,5,0
.goto 379,42.84,85.7
.gossipoption 37052 >>Talk to |cRXP_FRIENDLY_Old Lady Fung|r.
.target Old Lady Fung
step
#requires Old Lady Fung
#completewith next
#label Jin Warmkeg
#hidewindow
.complete 30682,1 
.target Jin Warmkeg
step
#requires Old Lady Fung
#completewith Jin Warmkeg
.goto 379,43.88,86.17
.gossipoption 35293 >>Talk to |cRXP_FRIENDLY_Jin Warmkeg|r.
.target Old Lady Fung
step
#requires Jin Warmkeg
#completewith Sha-Infested Yaungol
#hidewindow
#loop
.goto 379,45.15,88.27,40,0
.goto 379,42.89,87.97,40,0
.goto 379,41.06,86.39,40,0
.goto 379,42.80,86.06,40,0
.goto 379,45.15,88.27,0
.goto 379,42.89,87.97,0
.goto 379,41.06,86.39,0
.goto 379,42.80,86.06,0
+1
step
#requires Jin Warmkeg
#completewith next
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
#requires Jin Warmkeg
>>Kill |cRXP_ENEMY_Blind Rage|r.
*Loot them for |T252178:0|t[|cRXP_LOOT_Blind Rage Essence|r].
.complete 30670,1 
.mob Blind Rage
step
#label Sha-Infested Yaungol
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
.goto 379,49.10,70.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.accept 30603 >>Accept The Broketooth Ravage
.target Brother Rabbitsfoot
step
.goto 379,48.08,73.11
>>Kill |cRXP_ENEMY_Mo Mo|r in the cave.
*Loot him for |T134323:0|t[|cRXP_LOOT_Rabbitsfoot's Luckydo|r].
.complete 30603,1 
.mob Mo Mo
step
.goto 379,51.97,67.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30602 >>Turn in The Rabbitsfoot
.turnin 30603 >>Turn in The Broketooth Ravage
.accept 30599 >>Accept A Monkey Idol
.accept 30600 >>Accept No Pack Left Behind
.accept 30604 >>Accept Breaking Broketooth
.target Brother Rabbitsfoot
step
#completewith Turn in The Leader Hozen
+|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Luckydo's|r for a buff.
.target Luckydo
step
#completewith Dak Dak3
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob broketooth tosser
step
#completewith Dak Dak3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Packers|r
.complete 30600,1 
.target Dead Packer
step
#completewith next
#label Tak Tak
#hidewindow
.complete 30599,3 
step
#completewith Tak Tak
.goto 379,56.66,70.93
>>Kill |cRXP_ENEMY_Tak Tak|r
*Loot him for |T132159:0|t[|cRXP_LOOT_Corpse of Tak Tak|r].
.collect 80430,1,30599,3
step
#requires Tak Tak
#completewith next
#label Tak Tak2
#hidewindow
.complete 30599,3 
step
#requires Tak Tak
#completewith Tak Tak2
.goto 379,56.75,70.97
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Knife|r.
.mob Tak Tak
step
#requires Tak Tak2
#completewith next
#label Ko Ko
#hidewindow
.complete 30599,2 
step
#requires Tak Tak2
#completewith Ko Ko
.goto 379,52.47,71.37
>>Kill |cRXP_ENEMY_Ko Ko|r
*Loot him for |T132189:0|t[|cRXP_LOOT_Corpse of Ko Ko|r].
.collect 80429,1,30599,2
step
#requires Ko Ko
#completewith next
#label Ko Ko2
#hidewindow
.complete 30599,2 
step
#requires Ko Ko
#completewith Ko Ko2
.goto 379,52.27,71.44
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Knife|r.
.mob Ko Ko
step
#requires Ko Ko2
#completewith next
#label Dak Dak
#hidewindow
.complete 30599,1 
step
#requires Ko Ko2
#completewith Dak Dak
#title Enter Cave
.goto 379,52.83,71.41,10 >>Enter the Cave
step
#requires Dak Dak
#completewith next
#label Dak Dak2
#hidewindow
.complete 30599,1 
step
#requires Dak Dak
#completewith Dak Dak2
#loop
#title |cFFFCDC00NPC Patrols|r
.goto 383,54.79,28.62,15,0
.goto 383,35.05,55.28,15,0
.goto 383,41.74,71.35,15,0
.goto 383,58.75,59.33,15,0
.goto 384,50.33,36.53,15,0
>>Kill |cRXP_ENEMY_Dak Dak|r
*Loot him for |T458252:0|t[|cRXP_LOOT_Corpse of Dak Dak|r].
.collect 80428,1,30599,1
.mob Dak Dak
step
#requires Dak Dak2
#completewith next
#label Dak Dak3
#hidewindow
.complete 30599,1 
step
#requires Dak Dak2
#completewith Dak Dak3
.goto 384,49.84,39.7
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r.
.mob Dak Dak
step
#requires Dak Dak3
#hidewindow
#completewith Broketooths
#loop
.goto 384,40.96,49.75,25,0
.goto 383,55.48,64.39,25,0
.goto 383,60.41,42.46,25,0
.goto 379,52.89,71.24,25,0
.goto 379,51.92,70.29,25,0
.goto 379,53.58,69.53,25,0
.goto 379,56.09,70.71,25,0
.goto 379,52.92,71.22,25,0
+1
step
#requires Dak Dak3
#completewith next
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob Broketooth Tosser
step
#requires Dak Dak3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Packers|r
.complete 30600,1 
.target Dead Packer
step
#label Broketooths
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob broketooth tosser
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Item Booklet
#internal
step
#sticky
*|cRXP_WARN_Chapter 5:|r Item Showcase
*Highlights useful items for leveling, allowing you to choose which ones to pursue.
step
+|T4549102:0|t[Crystallized Augment Rune] increases your Main stat.
step !Shaman/!Mage/!Hunter/!Evoker
+|T4559223:0|t[Thunderous Drums] increases Haste by 15% for you and your party(shares cd with other bloodlust effects)
step
+|T1385244:0|t[Invigorating Healing Potion] is a healing potion.
step
+|T134014:0|t[Shadowberries] can regenerate up to 10% max health every 5 seconds.
.mob Mother Om'ra
step
+|T4497566:0|t[Potion of Gusts] will propel you forward a short distance.
step
+|T1405809:0|t[Gunshoes] significantly boost your Movement speed and allow you to travel on water for a short period of time.
step
+|T133632:0|t[Goblin Glider Kit] propel you forward and allow you to slowfall for 2 minutes or when you hit the ground.
step
+|T1405811:0|t[Leystone Buoy] will propel you to the ocean's surface.
step
+|T1373906:0|t[Felslate Anchor] will pull you straight to the ocean floor.
step
+|T463898:0|t[Potion of Deepholm] teleports to Deepholm.
step
+|T3671893:0|t[Fried Bonefish] movement speed boost when killing an enemy.
step
+|T628559:0|t[Cracked Radinax Control Gem] a big movement speed boosts with 3 charges.
step
+|T4672181:0|t[Pep-In-Your-Step] boosts movement speed.
step
+|T237296:0|t[Gnomish Army Knife] for profession tasks.
step
+|T134042:0|t[Unagi Skewer] deals damage to attackers(very minimal gain).
step
+|T986491:0|t[Loot-A-Rang]|cFFFF0000is an extremely useful during questing as it allows you to loot mobs from a far away range|r.
step
+The |T461816:0|t[Banner of Cooperation], |T461817:0|t[Standard of Unity], and |T461818:0|t[Battle Standard of Coordination] provide a significant XP boost, increasing the XP gained from monsters by up to 15% as long as you stay within 100 yards of the banner.
step
+|T1444943:0|t[Legion Dalaran Hearthstone] teleports you to Legion Dalaran.
step
+|T461813:0|t[Shroud of Cooperation], |T461814:0|t[Wrap of Unity] and |T461812:0|t[Cloak of Coordination] teleports you to Stormwind or Orgrimmar.
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shopping List
#internal
step
>>Buy Potion of Deepholm on the Auction House
.collect 58487,20 
step
>>|cRXP_WARN_Buy the following items of the auction house|r
*|cRXP_WARN_The quantity is only a recommendation|r
.collect 132516,40 
.collect 109076,40 
.collect 244839,40 
.collect 136606,20 
.collect 219905,20 
.collect 191398,20 
.collect 222745,20 
.collect 172063,20 
.collect 224572,10 
.collect 169280,5 
.collect 153123,1 
.collect 151239,1 
.collect 40772,1 
step
>>Train Cataclysm Engineering to 70 and learn |T986491:0|t[Loot-A-Rang]
.collecttoy 60854 
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Guild Items
#internal
step << Horde
.goto 85,47.14,80.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goram|r and buy the following items:
*|cRXP_WARN_If you cannot purchase the items, it may be due to one of the following reasons: you are not in a guild, your guild does not have the necessary achievements to unlock the items, or you lack the required reputation|r.
*|cRXP_WARN_If your current guild does not have the necessary achievements to unlock the items, consider temporarily joining another guild or working with a few guild members to unlock the necessary achievements|r.
*|cFFFF0000These items are mandatory|r.
.collect 63353,1 
.collect 63207,1 
.collect 65274,1 
.reputation 1168,revered >> Get Revered with a Guild
*|cRXP_WARN_While in a guild,|r complete max-level quests, including world quests, to increase your reputation. Raids, Mythic+ dungeons, and regular dungeons also reward reputation |cRXP_WARN_if the majority of your group is composed of guild members|r.
.target Goram
step << Horde
.goto 85,47.14,80.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goram|r and buy the following items:
*|cRXP_WARN_If you cannot purchase the items, it may be due to one of the following reasons: you are not in a guild, your guild does not possess the items, or you lack the required reputation|r.
.collect 64400,1 
.collect 64401,1 
.collect 64402,1 
.reputation 1168,revered >>Get Revered with a Guild
*|cRXP_WARN_While in a guild,|r complete max-level quests, including world quests, to increase your reputation. Raids, Mythic+ dungeons, and regular dungeons also reward reputation |cRXP_WARN_if the majority of your group is composed of guild members|r.
.target Goram
step << Alliance
.goto 84,64.16,77.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shay Pressler|r and buy the following items:
*|cRXP_WARN_If you cannot purchase the items, it may be due to one of the following reasons: you are not in a guild, your guild does not have the necessary achievements to unlock the items, or you lack the required reputation|r.
*|cRXP_WARN_If your current guild does not have the necessary achievements to unlock the items, consider temporarily joining another guild or working with a few guild members to unlock the necessary achievements|r.
*|cFFFF0000These items are mandatory|r.
.collect 63352,1 
.collect 63206,1 
.collect 65360,1 
.reputation 1168,revered >>Get Revered with a Guild
*|cRXP_WARN_While in a guild,|r complete max-level quests, including world quests, to increase your reputation. Raids, Mythic+ dungeons, and regular dungeons also reward reputation if the majority of your group is composed of guild members.
.target Shay Pressler
step << Alliance
.goto 84,64.16,77.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shay Pressler|r and buy the following items:
*|cRXP_WARN_If you cannot purchase the items, it may be due to one of the following reasons: you are not in a guild, your guild does not possess the items, or you lack the required reputation|r.
.collect 63359,1 
.collect 64398,1 
.collect 64399,1 
.reputation 1168,revered >>|cRXP_WARN_While in a guild,|r complete max-level quests, including world quests, to increase your reputation. Raids, Mythic+ dungeons, and regular dungeons also reward reputation if the majority of your group is composed of guild members.
.target Shay Pressler
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shadowberries
#internal
step
#completewith next
#label Mother Om'ra
>>Kill |cRXP_ENEMY_Mother Om'ra|r.
*Loot them for |T134014:0|t[|cRXP_LOOT_Shadowberries|r].
.collect 119449,40 
.mob Mother Om'ra
step
#completewith Mother Om'ra
.zone 539 >>Enter Draenor Shadowmoon Valley
step
#requires Mother Om'ra
.goto 539,43.95,57.65
>>Kill |cRXP_ENEMY_Mother Om'ra|r.
*Loot them for |T134014:0|t[|cRXP_LOOT_Shadowberries|r].
.collect 119449,40 
.mob Mother Om'ra
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Bivigosa's Blood Sausages
#internal
step
#completewith next
#label Bivigosa's Blood Sausages
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Assistant Innkeeper Durang|r.
.collect 201090,20 
.buy 201090,20
.target Assistant Innkeeper Durang
step
#completewith Bivigosa's Blood Sausages
.zone 2112 >>Enter Dornogal
step
#requires Bivigosa's Blood Sausages
.goto 539,43.95,57.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Assistant Innkeeper Durang|r.
.collect 201090,20 
.buy 201090,20
.target Assistant Innkeeper Durang
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Storylines
#name adb) The Coiled Isle Storylines (H)
#displayname |cFF00FF005|r - The Coiled Isle Sojourner
#chapters a) The Monster's Mother (H);a) Don't be Afrayed (H);a) Living Legend (H);a) Tokka's Crew (H);a) Somethin' Bad Inside (H);a) The Troubles of Mlurkkr Mine (H);a) Strange Friends in Odd Places (H);a) A Bond of Brothers (H);a) Ancient Anthropology (H);a) Bone Deep (H);a) The Honored Med'jai (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Monster's Mother (H)
#displayname |cFF00CCFF1|r - The Monster's Mother
#next a) Don't be Afrayed (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Monster's Mother
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Don't be Afrayed (H)
#displayname |cFF00CCFF2|r - Don't be Afrayed
#next a) Living Legend (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Don't be Afrayed
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Living Legend (H)
#displayname |cFF00CCFF3|r - Living Legend
#next a) Tokka's Crew (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Living Legend
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Tokka's Crew (H)
#displayname |cFF00CCFF4|r - Tokka's Crew
#next a) Somethin' Bad Inside (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Tokka's Crew
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Somethin' Bad Inside (H)
#displayname |cFF00CCFF5|r - Somethin' Bad Inside
#next a) The Troubles of Mlurkkr Mine (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Somethin' Bad Inside
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Troubles of Mlurkkr Mine (H)
#displayname |cFF00CCFF6|r - The Troubles of Mlurkkr Mine
#next a) Strange Friends in Odd Places (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Troubles of Mlurkkr Mine
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Strange Friends in Odd Places (H)
#displayname |cFF00CCFF7|r - Strange Friends in Odd Places
#next a) A Bond of Brothers (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Strange Friends in Odd Places
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Bond of Brothers (H)
#displayname |cFF00CCFF8|r - A Bond of Brothers
#next a) Ancient Anthropology (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Bond of Brothers
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Ancient Anthropology (H)
#displayname |cFF00CCFF9|r - Ancient Anthropology
#next a) Bone Deep (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Ancient Anthropology
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bone Deep (H)
#displayname |cFF00CCFF10|r - Bone Deep
#next a) The Honored Med'jai (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Bone Deep
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Honored Med'jai (H)
#displayname |cFF00CCFF11|r - The Honored Med'jai (Group)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Honored Med'jai
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) 90 Unlocking Systems (H)
#displayname |cFF00CCFF0|r - 90 Intro Unlocking Systems
#next a) Foothold (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) 90 Unlocking Systems
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 993.97
#name a) Saltheril's Haven (H)
#displayname Saltheril's Haven Campaign
<< Horde
step
#include a) Saltheril's Haven
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name a) Delve Campaign (H)
#subweight 993.99
#displayname Delve Campaign
<< Horde
step
#include a) Delve Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 993.98
#name a) Prey Campaign (H)
#displayname Prey Campaign
<< Horde
step
#include a) Prey Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name a) ZAbundance Campaign (H)
#subweight 993.96
#displayname Abundance Campaign
<< Horde
step
#include a) Abundance Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name a) 12.0.5 Campaign (H)
#displayname 12.0.5 Campaign
<< Horde
step
#include a) 12.0.5 Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 994
#name Z) The War of Light and Shadow Campaign (H)
#displayname The War of Light and Shadow
#chapters a) 90 Unlocking Systems (H);a) Foothold (H);a) The Voidspire (H);a) Gathering of the Elves (H);a) The Battle of the Bridge (H);a) The Darkwell (H);a) Dawn of a New Well (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Foothold (H)
#displayname |cFF00CCFF1|r - Foothold
#next a) The Voidspire (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Foothold
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Voidspire (H)
#displayname |cFF00CCFF2|r - The Voidspire
#next a) Gathering of the Elves(H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Voidspire
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Gathering of the Elves (H)
#displayname |cFF00CCFF3|r - Gathering of the Elves
#next a) The Battle of the Bridge (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Gathering of the Elves
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Battle of the Bridge (H)
#displayname |cFF00CCFF4|r - The Battle of the Bridge
#next a) The Darkwell (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Battle of the Bridge
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Darkwell (H)
#displayname |cFF00CCFF5|r - The Darkwell
#next a) Dawn of a New Well (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Darkwell
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Dawn of a New Well (H)
#displayname |cFF00CCFF6|r - Dawn of a New Well
#chapter
<< Horde
step
#include RestedXP Midnight\a) Dawn of a New Well
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 995
#name Y) The Curse of Ula'tek (H)
#displayname The Curse of Ula'tek (12.1)
#chapters a) Legacy of the Amani (H);b) An Island of Fangs (H);c) Ghosts of the Past (H);d) Original Sin (H);e) The Battle of Atal'Utek (H);f) The Call of the Void (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name a) Legacy of the Amani (H)
#displayname |cFF00CCFF1|r - Legacy of the Amani
#next b) An Island of Fangs (H)
<< Horde
step
#include a) Legacy of the Amani
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name b) An Island of Fangs (H)
#displayname |cFF00CCFF2|r - An Island of Fangs
#next c) Ghosts of the Past (H)
<< Horde
step
#include b) An Island of Fangs
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name c) Ghosts of the Past (H)
#displayname |cFF00CCFF3|r - Ghosts of the Past
#next d) Original Sin (H)
<< Horde
step
#include c) Ghosts of the Past
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name d) Original Sin (H)
#displayname |cFF00CCFF4|r - Original Sin
#next e) The Battle of Atal'Utek (H)
<< Horde
step
#include d) Original Sin
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name e) The Battle of Atal'Utek (H)
#displayname |cFF00CCFF5|r - The Battle of Atal'Utek
#next f) The Call of the Void (H)
<< Horde
step
#include e) The Battle of Atal'Utek
]])

