if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Gnarldor Isle
#internal
step
#arrowtext Enter Gnarldor Isle
.goto 2512,64.43,77.75
.enterScenario 3414,3415,3385 >>Enter the Gnarldor Isle Delve in The Coiled Isle.

step
.isInScenario 3415
#arrowtext Talk to\n|cRXP_FRIENDLY_Artolla|r
.goto 2635,75.21,48.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Artolla|r.
.scenario 17093,1 
.target Artolla
.skipgossipid 139635
step
#completewith SpeakingTheirLanguageA
#label SpeakingTheirLanguageTurtlesA
#hidewindow
.isInScenario 3415
.scenario 17094,1 
step
#completewith SpeakingTheirLanguageA
#label SpeakingTheirLanguagePowderA
#hidewindow
.isInScenario 3415
.scenario 17094,2 
step
#completewith SpeakingTheirLanguageA
#label SpeakingTheirLanguageCannonA
#hidewindow
.isInScenario 3415
.scenario 17094,3 
step
#completewith SpeakingTheirLanguageA
#label SpeakingTheirLanguageGunsA
#hidewindow
.isInScenario 3415
.scenario 17094,4 
step
#completewith SpeakingTheirLanguageA
#label SpeakingTheirLanguageShellmansA
#hidewindow
.isInScenario 3415
.scenario 17094,5 
step
.isInScenario 3415
#completewith SpeakingTheirLanguageTurtlesA
#label SpeakingTheirLanguageB
#arrowtext Click on\n|cRXP_PICK_turtle|r
.goto 2635,62.61,49.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_turtle|r.
.scenario 17094,1,1 
step
#requires SpeakingTheirLanguageB
#completewith SpeakingTheirLanguageGunsA
#label SpeakingTheirLanguageC
.isInScenario 3415
#arrowtext Click on\n|cRXP_PICK_guns|r
.goto 2635,57.46,54.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_guns|r.
.scenario 17094,4 
step
#requires SpeakingTheirLanguageC
#completewith SpeakingTheirLanguageShellmansA
#label SpeakingTheirLanguageD
.isInScenario 3415
#arrowtext Click on\n|cRXP_PICK_barrel|r
.goto 2635,58.24,60.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_barrel|r.
.scenario 17094,5 
step
.isInScenario 3415
#requires SpeakingTheirLanguageD
#completewith SpeakingTheirLanguageTurtlesA
#label SpeakingTheirLanguageE
#arrowtext Click on\n|cRXP_PICK_turtle|r
.goto 2635,57.60,71.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_turtle|r.
.scenario 17094,1,2 
step
#requires SpeakingTheirLanguageE
#completewith SpeakingTheirLanguageCannonA
#label SpeakingTheirLanguageF
.isInScenario 3415
#arrowtext Click on\n|cRXP_PICK_cannon balls|r
.goto 2635,54.28,64.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_cannon balls|r.
.scenario 17094,3 
step
#requires SpeakingTheirLanguageF
#completewith SpeakingTheirLanguagePowderA
#label SpeakingTheirLanguageG
#arrowtext Click on\n|cRXP_PICK_powder barrel|r
.goto 2635,50.70,69.70
.isInScenario 3415
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_powder barrel|r.
.scenario 17094,2 
step
#requires SpeakingTheirLanguageG
#completewith SpeakingTheirLanguageTurtlesA
#label SpeakingTheirLanguageA
#arrowtext Click on\n|cRXP_PICK_turtle|r
.goto 2635,49.17,60.36
.isInScenario 3415
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_turtle|r.
.scenario 17094,1 
step
#requires SpeakingTheirLanguageA
#arrowtext Follow the arrow
.isInScenario 3415
.goto 2635,46.02,49.80
.scenario 17154,1 
step
.isInScenario 3415
#arrowtext Click on\n|cRXP_PICK_War Turtle|r
.goto 2635,44.24,46.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_War Turtle|r.
.scenario 17154,2 
step
.isInScenario 3415
#arrowtext Use the turtle abilities
#loop
.goto 2635,30.97,38.12,28,0
.goto 2635,37.37,21.48,28,0
.goto 2635,30.99,23.96,28,0
.goto 2635,26.03,45.03,28,0
>>Just spam your four buttons.
.scenario 17155,1 
step
.isInScenario 3415
#arrowtext Kill\n|cRXP_ENEMY_Gralka Snake-Eater|r
.goto 2635,23.28,26.72
>>Kill |cRXP_ENEMY_Gralka Snake-Eater|r
.scenario 17095,1 
.mob Gralka Snake-Eater

step
.isInScenario 3414
#arrowtext Talk to\n|cRXP_FRIENDLY_Minchi|r
.goto 2635,75.63,48.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Minchi|r.
.scenario 17090,1 
.target Minchi
.skipgossipid 139585
step
.isInScenario 3414
#arrowtext Click on |cRXP_PICK_Piles|r\nKill |cRXP_ENEMY_Gnarldin|r
#loop
.goto 2635,62.57,45.28,35,0
.goto 2635,64.75,64.03,35,0
.goto 2635,67.42,73.66,35,0
.goto 2635,54.60,64.59,35,0
.goto 2635,48.81,68.73,35,0
.goto 2635,38.09,59.05,35,0
.goto 2635,26.17,44.23,35,0
.goto 2635,37.41,30.97,35,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Piles|r |cRXP_WARN_and kill the spawning enemies|r.
>>Kill the |cRXP_ENEMY_Gnarldin|r and click on them.
.scenario 17091,1 
.scenario 17091,2 
step
.isInScenario 3414
#arrowtext Click on\n|cRXP_PICK_Hearts|r
#loop
.goto 2635,27.73,33.26,10,0
.goto 2635,26.06,33.28,10,0
.goto 2635,26.10,30.84,10,0
.goto 2635,27.75,30.85,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hearts|r.
.scenario 17224,1 
step
#arrowtext Kill\n|cRXP_ENEMY_Osseous Amalgamation|r
.goto 2635,27.00,32.00
.isInScenario 3414
>>Kill the |cRXP_ENEMY_Osseous Amalgamation|r.
.scenario 17092,1 
.mob Osseous Amalgamation

step
#label OldsAndEndsA
.isInScenario 3385
#arrowtext Talk to\n|cRXP_FRIENDLY_Tormunda|r
.goto 2635,75.29,48.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tormunda|r.
.scenario 16908,1 
.target Tormunda
.skipgossipid 139462
step
.isInScenario 3385
#completewith OldsAndEndsE
#hidewindow
#arrowtext Kill |cRXP_ENEMY_Gnarldin forces|r\nCollect |cRXP_PICK_Relics|r\nRescue Tortollans
#loop
.goto 2635,62.45,45.18,25,0
.goto 2635,56.12,45.03,25,0
.goto 2635,58.04,50.29,25,0
.goto 2635,59.39,58.19,25,0
.goto 2635,57.18,71.92,30,0
.goto 2635,49.14,60.97,25,0
.goto 2635,44.20,55.67,25,0
.goto 2635,35.94,45.05,25,0
.goto 2635,25.31,43.74,25,0
.goto 2635,37.55,29.16,25,0
.goto 2635,33.77,38.56,35,0
.goto 2635,38.20,59.15,25,0
+1
step
.isInScenario 3385
#completewith OldsAndEndsE
#hidewindow
#label OldsAndEndsB
.scenario 16909,1 
step
#completewith next
.isInScenario 3385
>>Kill the |cRXP_ENEMY_Gnarldin forces|r. Run over the |cRXP_PICK_Relics|r.
.scenario 16909,1 
step
.isInScenario 3385
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Abducted Tortollan|r.
.scenario 16909,2 
step
#completewith OldsAndEndsB
#label OldsAndEndsE
.isInScenario 3385
>>Kill the |cRXP_ENEMY_Gnarldin forces|r. Run over the |cRXP_PICK_Relics|r.
.scenario 16909,1 
step
#requires OldsAndEndsB
.isInScenario 3385
#arrowtext Click on\n|cRXP_PICK_'Ol Shalty|r
.goto 2635,26.50,31.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_'Ol Shalty|r.
.scenario 17232,1 
.target 'Ol Shalty
step
.isOnQuest 96093
#arrowtext Click on\n|cRXP_PICK_Satchel|r
.goto 2635,25.35,34.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Satchel|r.
.complete 96093,1 
step
#label OldsAndEndsZ
.isInScenario 3385
#arrowtext Kill\n|cRXP_ENEMY_Gralka Snake-Eater|r
.goto 2635,26.26,31.37
>>Kill |cRXP_ENEMY_Gralka Snake-Eater|r.
.scenario 16910,1 
.mob Gralka Snake-Eater
step
#label GnarldorIslandZ
.zoneskip 2635,1
#arrowtext Leave the delve
.goto 2635,15.58,13.96
.zone 2512 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Miscellaneous
#name a) Lore Hunter
#displayname Lore Hunter (Renown)
#internal
step
#completewith VistaPointEversongWoodsLastA
+This guide will lead you through the Lore Hunter achievement |cRXP_WARN_with some additional easy to get treasures|r for gaining reputation.
step
.zone 2393 >>Go to Silvermoon
step
.isQuestAvailable account,93570
#completewith next
#label UnifishedMusicSheetA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unfinished Music Sheet|r.
.turnin 93570 >>Turn in |cRXP_PICK_Unfinished Music Sheet|r
step
#completewith UnifishedMusicSheetA
#arrowtext |cRXP_WARN_Enter the house\non the lowest level|r.
.goto 2393,37.74,78.48,4 >>|cRXP_WARN_Enter the house|r
step
.isQuestAvailable account,93570
#requires UnifishedMusicSheetA
#arrowtext Click on the |cRXP_PICK_Unfinished Music Sheet|r
.goto 2393,38.10,77.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unfinished Music Sheet|r.
.turnin 93570 >>Turn in |cRXP_PICK_Unfinished Music Sheet|r
step
.isQuestAvailable account,94536
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2393,20.23,79.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94536 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,94537
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2395,40.41,10.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94537 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93563
#arrowtext Click on the |cRXP_PICK_Shrine of Dath'Remar|r
.goto 2395,37.61,13.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine of Dath'Remar|r.
.turnin 93563 >>Turn in |cRXP_PICK_Shrine of Dath'Remar|r
step
#arrowtext Click on the |cRXP_PICK_Portal to Harandar|r
.zone 2576 >>Click on the |cRXP_PICK_Portal to Harandar|r
.goto 2393,36.97,67.95
step
.isQuestAvailable account,93554
#arrowtext Click on the |cRXP_PICK_Tarnished Mural|r
.goto 2413,55.67,54.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tarnished Mural|r.
.turnin 93554 >>Turn in |cRXP_PICK_Tarnished Mural|r
step
.isQuestAvailable account,94550
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2413,53.49,58.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94550 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93556
#arrowtext Click on the |cRXP_PICK_Ancient Runestone|r
.goto 2413,33.33,60.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Runestone|r.
.turnin 93556 >>Turn in |cRXP_PICK_Ancient Runestone|r
step
.isQuestAvailable account,93508
#completewith next
#label ImpenetrableSealedGourdA
#hidewindow
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pouch|r.
.turnin 93508 >>1
step
.isQuestAvailable account,93508
#completewith ImpenetrableSealedGourdA
#arrowtext |cRXP_WARN_Enter the cave\nin the mountains|r
.goto 2413,27.44,67.98 >>|cRXP_WARN_Enter the cave|r
step
.isQuestAvailable account,93508
#requires ImpenetrableSealedGourdA
#completewith MysteriousPurpleFluidA
#label ImpenetrableSealedGourdB
#hidewindow
.collect 260266,1 
step
.isQuestAvailable account,93508
#requires ImpenetrableSealedGourdA
#completewith ImpenetrableSealedGourdB
#label MysteriousRedFluidA
#arrowtext Click on the |cRXP_PICK_Pouch|r
.goto 2413,27.06,67.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pouch|r.
.collect 260251,1 
step
.isQuestAvailable account,93508
#requires MysteriousRedFluidA
#label MysteriousPurpleFluidA
#completewith ImpenetrableSealedGourdB
#arrowtext Click on the |cRXP_PICK_Flask|r
.goto 2413,26.65,68.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flask|r.
.collect 260250,1 
step
.isQuestAvailable account,93508
#requires ImpenetrableSealedGourdB
#arrowtext Click on the |cRXP_PICK_Durable Vase|r
.goto 2413,27.33,68.00,8,0
.goto 2413,26.54,67.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Durable Vase|r
.collect 260266,1 
step
.isQuestAvailable account,93508
#arrowtext Click on the |cRXP_PICK_Impenetrably Sealed Gourd|r
.goto 2413,26.74,67.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Impenetrably Sealed Gourd|r.
.turnin 93508 >>Turn in |cRXP_PICK_Impenetrably Sealed Gourd|r
step
.isQuestAvailable account,93650
#arrowtext Click on the |cRXP_PICK_Fungal Mallet|r
.goto 2413,41.31,67.99
.aura 1266347 >>Click on the |cRXP_PICK_Fungal Mallet|r
step
.isQuestAvailable account,93650
#arrowtext Click on the |cRXP_PICK_Mycelium Gong|r
.goto 2413,46.60,67.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mycelium Gong|r.
.turnin 93652 >>Turn in |cRXP_PICK_Mycelium Gong|r
step
.isQuestAvailable account,93650
#arrowtext Click on the |cRXP_PICK_Sporespawned Cache|r
.goto 2413,46.65,67.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sporespawned Cache|r.
.turnin 93650 >>Turn in |cRXP_PICK_Sporespawned Cache|r
step
.isQuestAvailable account,94548
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2413,49.40,75.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94548 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,94549
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2413,69.41,63.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94549 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,92427
#arrowtext Click on the |cRXP_PICK_Sporelord's Fight Prize|r
.goto 2413,73.64,65.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sporelord's Fight Prize|r.
.turnin 92427 >>Turn in |cRXP_PICK_Sporelord's Fight Prize|r
step
.isQuestAvailable account,92431
#arrowtext Click on the |cRXP_PICK_Reliquary's Lost Paint Supplies|r
.goto 2413,62.91,51.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Reliquary's Lost Paint Supplies|r.
.turnin 92431 >>Turn in |cRXP_PICK_Reliquary's Lost Paint Supplies|r
step
.isQuestAvailable account,94546
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2413,69.18,46.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94546 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93557
#arrowtext Click on the |cRXP_PICK_Derelict Mural|r
.goto 2413,72.43,38.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Derelict Mural|r.
.turnin 93557 >>Turn in |cRXP_PICK_Derelict Mural|r
step
.isQuestAvailable account,92424
#arrowtext Click on the |cRXP_PICK_Failed Shroom Jumper's Satchel|r
.goto 2413,71.69,31.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Failed Shroom Jumper's Satchel|r.
.turnin 92424 >>Turn in |cRXP_PICK_Failed Shroom Jumper's Satchel|r
step
.isQuestAvailable account,94547
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2413,68.16,25.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94547 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93558
#arrowtext Click on the |cRXP_PICK_Forgotten Mural|r
.goto 2413,68.20,23.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forgotten Mural|r.
.turnin 93558 >>Turn in |cRXP_PICK_Forgotten Mural|r
step
.isQuestAvailable account,92436
#arrowtext Click on the |cRXP_PICK_Kemet's Simmering Cauldron|r
.goto 2413,55.66,39.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kemet's Simmering Cauldron|r.
.turnin 92436 >>Turn in |cRXP_PICK_Kemet's Simmering Cauldron|r
step
.isQuestAvailable account,92426
#arrowtext Click on the |cRXP_PICK_Burning Branch of the World Tree|r
.goto 2413,47.07,50.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Burning Branch of the World Tree|r.
.turnin 92426 >>Turn in |cRXP_PICK_Burning Branch of the World Tree|r
step
.goto 2576,61.77,73.47
#arrowtext Click on the |cRXP_PICK_Portal to Voidstorm|r
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r
step
.isQuestAvailable account,94553
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2405,55.45,67.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94553 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,94394
#arrowtext Click on the |cRXP_PICK_Ancient Tablet|r
.goto 2405,50.32,87.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Tablet|r.
.turnin 94394 >>Turn in |cRXP_PICK_Ancient Tablet|r
step
.isQuestAvailable account,94389
#arrowtext Click on the |cRXP_PICK_Void Armor|r
.goto 2405,63.41,78.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Armor|r.
.turnin 94389 >>Turn in |cRXP_PICK_Void Armor|r
step
.isQuestAvailable account,93431
#arrowtext Click on the |cRXP_PICK_Forgotten Oubliette|r\nClick on the |cRXP_PICK_Dripping Meat|r\nClick on the |cRXP_PICK_Bloody Sack|r
.goto 2405,64.51,75.48,6,0
.goto 2405,64.42,75.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forgotten Oubliette|r.
.turnin 93431 >>Turn in |cRXP_PICK_Forgotten Oubliette|r
step
.isQuestAvailable account,94397
#arrowtext Click on the |cRXP_PICK_Tattered Page|r
.goto 2405,60.38,45.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tattered Page|r.
.turnin 94397 >>Turn in |cRXP_PICK_Tattered Page|r
step
.isQuestAvailable account,93840
#completewith next
#label MalignantChestA
#hidewindow
.turnin 94552 >>Turn in |cRXP_PICK_Malignant Chest|r
step
.isQuestAvailable account,93840
#completewith MalignantChestA
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2405,54.06,43.91,10 >>|cRXP_WARN_Enter the cave.|r
step
.isQuestAvailable account,93840
#requires MalignantChestA
#arrowtext Click on all |cRXP_PICK_Malignant Nodes|r\n|cRXP_WARN_in the cave|r\nClick on the |cRXP_PICK_Malignant Chest|r
.goto 2405,53.36,42.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Malignant Chest|r.
.turnin 93840 >>Turn in |cRXP_PICK_Malignant Chest|r
step
.isQuestAvailable account,94552
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2405,36.50,44.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94552 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93496
#arrowtext Click on the |cRXP_PICK_Discarded Energy Pike|r
.goto 2405,35.78,41.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Discarded Energy Pike|r.
.turnin 93496 >>Turn in |cRXP_PICK_Discarded Energy Pike|r
step
.isQuestAvailable account,93500
#arrowtext Click on the |cRXP_PICK_Quivering Egg|r
.goto 2405,31.50,44.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Quivering Egg|r.
.turnin 93500 >>Turn in |cRXP_PICK_Quivering Egg|r
step
.isQuestAvailable account,94398
#arrowtext Click on the |cRXP_PICK_Shadowgraft Harness|r
.goto 2405,27.83,54.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowgraft Harness|r.
.turnin 94398 >>Turn in |cRXP_PICK_Shadowgraft Harness|r
step
.isQuestAvailable account,94555
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2405,37.81,54.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94555 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,94395
#arrowtext Click on the |cRXP_PICK_Abandoned Telescope|r
.goto 2405,40.48,58.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Abandoned Telescope|r.
.turnin 94395 >>Turn in |cRXP_PICK_Abandoned Telescope|r
step
.isQuestAvailable account,94551
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2405,39.69,61.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94551 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93467
#completewith next
#label HalfDigestedVisceraA
#hidewindow
.turnin 93467 >>Turn in |cRXP_PICK_Half-Digested Viscera|r
step
#completewith HalfDigestedVisceraA
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2405,38.05,68.79,10 >>|cRXP_WARN_Enter the cave.|r
step
#requires HalfDigestedVisceraA
.isQuestAvailable account,93467
#arrowtext Click on the |cRXP_PICK_Half-Digested Viscera|r
.goto 2405,37.70,69.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Half-Digested Viscera|r.
.turnin 93467 >>Turn in |cRXP_PICK_Half-Digested Viscera|r
step
.isQuestAvailable account,94554
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2405,41.75,70.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94554 >>Turn in |cRXP_PICK_Vista Point|r
step
#arrowtext Click on the |cRXP_PICK_Portal to Silvermoon|r
.goto 2405,51.56,70.29
.zone 2393 >>Click on the |cRXP_PICK_Portal to Silvermoon|r
step
.isQuestAvailable account,94538
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2395,37.41,47.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94538 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93565
#arrowtext Click on the |cRXP_PICK_Profane Research|r
.goto 2395,36.05,72.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Profane Research|r.
.turnin 93565 >>Turn in |cRXP_PICK_Profane Research|r
step
.isQuestAvailable account,93893
#arrowtext Click on the |cRXP_PICK_Forgotten Ink and Quill|r
.goto 2395,43.28,69.50
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forgotten Ink and Quill|r.
.turnin 93893 >>Turn in |cRXP_PICK_Forgotten Ink and Quill|r
step
.isQuestAvailable account,91358
#arrowtext Click on the |cRXP_PICK_Burbling Paint Pot|r
.goto 2395,48.74,75.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Burbling Paint Pot|r.
.turnin 91358 >>Turn in |cRXP_PICK_Burbling Paint Pot|r
step
.isQuestAvailable account,91841
#arrowtext Click on the |cRXP_PICK_Memorial Plaque|r
.goto 2395,47.96,88.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Memorial Plaque|r.
.turnin 91841 >>Turn in |cRXP_PICK_Memorial Plaque|r
step
.isQuestAvailable account,94540
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2395,50.19,85.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94540 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,94544
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2395,63.62,85.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94544 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,90795
#completewith next
#label BaitAndTackleA
#hidewindow
.turnin 90795 >>1
step
.isQuestAvailable account,90795
#completewith BaitAndTackleA
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2437,21.09,66.99,8 >>|cRXP_WARN_Enter the cave.|r
step
.isQuestAvailable account,90795
#requires BaitAndTackleA
#arrowtext Click on the |cRXP_PICK_Bait and Tackle|r
.goto 2437,20.85,66.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bait and Tackle|r.
.turnin 90795 >>Turn in |cRXP_PICK_Bait and Tackle|r
step
.isQuestAvailable account,94541
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2437,27.79,70.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94541 >>Turn in |cRXP_PICK_Vista Point|r
step
#completewith next
#label TabletOfNalorakkA
.isQuestAvailable account,94632
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet of Nalorakk|r.
.turnin 94632 >>Turn in |cRXP_PICK_Tablet of Nalorakk|r
step
#completewith TabletOfNalorakkA
#arrowtext |cRXP_WARN_Enter the Den of Nalorakk|r
.goto 2437,31.23,84.00,10 >>|cRXP_WARN_Enter the Den of Nalorakk|r
step
#requires TabletOfNalorakkA
.isQuestAvailable account,94632
#arrowtext Click on the |cRXP_PICK_Tablet of Nalorakk|r
.goto 2437,30.15,84.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet of Nalorakk|r.
.turnin 94632 >>Turn in |cRXP_PICK_Tablet of Nalorakk|r
step
.isQuestAvailable account,94627
#arrowtext Click on the |cRXP_PICK_Tablet of Akil'zon|r
.goto 2437,53.11, 52.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet of Akil'zon|r.
.turnin 94627 >>Turn in |cRXP_PICK_Tablet of Akil'zon|r
step
.isQuestAvailable account,94542
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2437,53.02,81.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94542 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,90797
#arrowtext Click on the |cRXP_PICK_Mrruk's Mangy Trove|r
.goto 2437,52.32,65.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mrruk's Mangy Trov|r.
.turnin 90797 >>Turn in |cRXP_PICK_Mrruk's Mangy Trov|r
step
.isQuestAvailable account,90796
#completewith next
#label BurrowBountyA
#hidewindow
.turnin 90796 >>1
step
.isQuestAvailable account,90796
#completewith BurrowBountyA
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2437,42.17,47.61,8 >>|cRXP_WARN_Enter the cave.|r
step
.isQuestAvailable account,90796
#requires BurrowBountyA
#arrowtext Click on the |cRXP_PICK_Burrow Bounty|r
.goto 2437,41.99,47.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Burrow Bounty|r.
.turnin 90796 >>Turn in |cRXP_PICK_Burrow Bounty|r
step
.isQuestAvailable account,94673
#arrowtext Click on the |cRXP_PICK_Tablet of Kulzi|r
.goto 2437,39.27,44.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet of Kulzi|r.
.turnin 94673 >>Turn in |cRXP_PICK_Tablet of Kulzi|r
step
.isQuestAvailable account,94545
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2437,41.86,41.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94545 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,90798
#arrowtext Click on the |cRXP_PICK_Secret Formula|r
.goto 2437,40.47,35.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Secret Formula|r.
.turnin 90798 >>Turn in |cRXP_PICK_Secret Formula|r
step
.isQuestAvailable account,94674
#arrowtext Click on the |cRXP_PICK_Tablet of Filo|r
.goto 2437,52.92,32.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet of Filo|r.
.turnin 94674 >>Turn in |cRXP_PICK_Tablet of Filo|r
step
.isQuestAvailable account,94543
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2437,57.69,21.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94543 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,94631
#arrowtext Click on the |cRXP_PICK_Tablet of Jan'alai|r
.goto 2437,55.13,17.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet of Jan'alai|r.
.turnin 94631 >>Turn in |cRXP_PICK_Tablet of Jan'alai|r
step
.isQuestAvailable account,94628
#arrowtext Click on the |cRXP_PICK_Tablet of Halazzi|r
.goto 2437,32.09,31.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet of Halazzi|r.
.turnin 94628 >>Turn in |cRXP_PICK_Tablet of Halazzi|r
step
.isQuestAvailable account,93562
#arrowtext Click on the |cRXP_PICK_Hawkstrider Husbandry: Unabridged Edition|r
.goto 2395,57.81,50.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hawkstrider Husbandry: Unabridged Edition|r.
.turnin 93562 >>Turn in |cRXP_PICK_Hawkstrider Husbandry: Unabridged Edition|r
step
#label VistaPointEversongWoodsLastA
.isQuestAvailable account,94539
#arrowtext Click on the |cRXP_PICK_Vista Point|r
.goto 2395,54.58,51.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vista Point|r.
.turnin 94539 >>Turn in |cRXP_PICK_Vista Point|r
step
.isQuestAvailable account,93564
#arrowtext Click on the |cRXP_PICK_Mirveda's Notes|r
.goto 2395,50.53,43.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mirveda's Notes|r.
.turnin 93564 >>Turn in |cRXP_PICK_Mirveda's Notes|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Monk Quests
#internal
step
.xp >90,1
#completewith next
#label Master Cheng
.isQuestAvailable 31834
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.accept 31834 >>Accept Begin Your Training: Master Cheng
.target Master Hight
step
.xp >90,1
#completewith Master Cheng
.zone 379 >>Use Zen Pilgrimage
step
.xp >90,1
#requires Master Cheng
.isQuestAvailable 31834
.goto 379,48.56,42.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.accept 31834 >>Accept Begin Your Training: Master Cheng
.target Master Hight
step
.xp >90,1
.isOnQuest 31834
.zoneskip 379,1
#completewith next
#hidewindow
#label WaytoMasterCheng
.complete 31834,1 
step
.xp >90,1
.isOnQuest 31834
#completewith next
.goto 379,48.4,43.12,8,0
.goto 379,48.12,43.3,10 >>Leave the Temple
step
.xp >90,1
.isOnQuest 31834
#hidewindow
#completewith WaytoMasterCheng
.goto 379,47.06,40.15,80 >>1
step
.xp >90,1
.isOnQuest 31834
.zoneskip 379,1
#requires WaytoMasterCheng
#completewith next
#label Master Cheng's Training Completed
>>After speaking with |cRXP_FRIENDLY_Master Cheng|r, walk towards the center and stop.
.complete 31834,1 
.target Master Cheng
step
.xp >90,1
.isOnQuest 31834
#requires WaytoMasterCheng
#completewith Master Cheng's Training Completed
.goto 379,47.08,40.25
.gossipoption 41015 >>Talk to |cRXP_FRIENDLY_Master Cheng|r.
.timer 29,RP
.target Master Cheng
step
.xp >90,1
.isOnQuest 31834
.zoneskip 379,1
#requires Master Cheng's Training Completed
#label MonkIncludePrepEnd
.goto 379,48.12,40.35
#title |cFFFCDC00Follow the Arrow|r
>>Stop at the arrow's position and target |cRXP_FRIENDLY_Master Cheng|r. Defeat him in a duel.
.complete 31834,1 
.emote BOW,66138
.target Master Cheng
.mob Master Cheng
step
.xp >90,1
.isQuestComplete 31834
.zoneskip 379,1
#completewith next
#label Turn in Begin Your Training: Master Cheng
.goto 379,47.94,42.91,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31834 >>Turn in Begin Your Training: Master Cheng
.accept 31835 >>Accept Continue Your Training: Master Kistane
.disablecheckbox
.accept 31840 >>Accept Practice Makes Perfect: Master Cheng
.disablecheckbox
.target Master Hight
step
.xp >90,1
.isQuestComplete 31834
#completewith next
.goto 379,48.25,43.34,10 >>Enter the Temple
step
.xp >90,1
.isQuestComplete 31834
#hidewindow
#completewith Turn in Begin Your Training: Master Cheng
.goto 379,48.56,42.81,20 >>1
step
.xp >90,1
.isQuestComplete 31834
.zoneskip 379,1
#requires Turn in Begin Your Training: Master Cheng
.goto 379,48.56,42.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31834 >>Turn in Begin Your Training: Master Cheng
.accept 31835 >>Accept Continue Your Training: Master Kistane
.accept 31840 >>Accept Practice Makes Perfect: Master Cheng
.target Master Hight
step
.xp >90,1
.isOnQuest 31840,31835
.zoneskip 379,1
#completewith next
#hidewindow
#label WaytoMasterCheng2
.complete 31840,1 
.complete 31835,1 
step
.xp >90,1
.isOnQuest 31840,31835
#completewith next
.goto 379,48.4,43.12,8,0
.goto 379,48.12,43.3,10 >>Leave the Temple
step
.xp >90,1
.isOnQuest 31840,31835
#hidewindow
#completewith WaytoMasterCheng2
.goto 379,47.06,40.15,80 >>1
step
.xp >90,1
.isOnQuest 31840,31835
.zoneskip 379,1
#requires WaytoMasterCheng2
#completewith next
#hidewindow
#label Master Cheng's Training Completed2
.complete 31840,1 
.complete 31835,1 
step
.xp >90,1
.isOnQuest 31840,31835
#requires WaytoMasterCheng2
#completewith next
.gossipoption 41015 >>Talk to |cRXP_FRIENDLY_Master Kistane|r.
step
.xp >90,1
.isOnQuest 31840,31835
#requires WaytoMasterCheng2
#completewith Master Cheng's Training Completed2
.goto 379,47.08,40.25
.gossipoption 41015 >>Talk to |cRXP_FRIENDLY_Master Cheng|r.
.target Master Cheng
step
.xp >90,1
.isOnQuest 31840,31835
.zoneskip 379,1
#requires Master Cheng's Training Completed2
#completewith next
#label Master Cheng's Training Completed3
>>After speaking with |cRXP_FRIENDLY_Master Cheng|r and |cRXP_FRIENDLY_Master Kistane|r, walk towards the center and stop.
.complete 31840,1 
.complete 31835,1 
step
.xp >90,1
.isOnQuest 31840,31835
#requires Master Cheng's Training Completed2
#completewith next
.goto 379,47.99,39.11
.goto 379,48.05,39.02
.gossipoption 40841 >>Talk to |cRXP_FRIENDLY_Master Kistane|r.
.timer 27,RP
.target Master Kistane
step
.xp >90,1
.isOnQuest 31840,31835
.zoneskip 379,1
#requires Master Cheng's Training Completed3
.emote BOW,66138
.emote BOW,65899
.goto 379,48.11,40.31
#title |cFFFCDC00Follow the Arrow|r
>>Stop at the arrow's position and first target |cRXP_FRIENDLY_Master Cheng|r.
*Once |cRXP_FRIENDLY_Master Kistane|r reaches the arrow, switch your target to her. Defeat them both in a duel.
.complete 31840,1 
.complete 31835,1 
.target Master Cheng
.mob Master Cheng
.target Master Kistane
.mob Master Kistane
step
.xp >90,1
.isQuestComplete 31835
.zoneskip 379,1
#completewith next
#label WaytoMasterHight
.goto 379,47.94,42.91,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31835 >>Turn in Continue Your Training: Master Kistane
.turnin 31840 >>Turn in Practice Makes Perfect: Master Cheng
.accept 31836 >>Accept Continue Your Training: Master Yoon
.disablecheckbox
.target Master Hight
step
.xp >90,1
.isQuestComplete 31835
#completewith next
.goto 379,48.25,43.34,10 >>Enter the Temple
step
.xp >90,1
.isQuestComplete 31835
#hidewindow
#completewith WaytoMasterHight
.goto 379,48.56,42.81,20 >>1
step
.xp >90,1
.isQuestComplete 31835
.zoneskip 379,1
#requires WaytoMasterHight
.goto 379,48.62,42.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31835 >>Turn in Continue Your Training: Master Kistane
.turnin 31840 >>Turn in Practice Makes Perfect: Master Cheng
.target Master Hight
.accept 31836 >>Accept Continue Your Training: Master Yoon
.target Master Hight
step
.xp >90,1
.isOnQuest 31836
.zoneskip 379,1
#completewith next
#hidewindow
#label WaytoMasterYoon
.complete 31836,1 
step
.xp >90,1
.isOnQuest 31836
#completewith next
.goto 379,49.4,42.67,17 >>Leave the Temple
step
.xp >90,1
.isOnQuest 31836
#hidewindow
#completewith WaytoMasterYoon
.goto 379,48.8,40.49,80 >>1
step
.xp >90,1
.isOnQuest 31836
.zoneskip 379,1
#requires WaytoMasterYoon
#completewith next
#label Master Yoon's Training Completed
>>After speaking with |cRXP_FRIENDLY_Master Yoon|r, walk towards the center and stop.
.complete 31836,1 
.target Master Yoon
step
.xp >90,1
.isOnQuest 31836
#requires WaytoMasterYoon
#completewith Master Yoon's Training Completed
.goto 379,48.8,40.49
.gossipoption 40843 >>Talk to |cRXP_FRIENDLY_Master Yoon|r.
.timer 25,RP
.target Master Yoon
step
.xp >90,1
.isOnQuest 31836
.zoneskip 379,1
#requires Master Yoon's Training Completed
#title |cFFFCDC00Follow the Arrow|r
.goto 379,48.12,40.35
>>Stop at the arrow's position and target |cRXP_FRIENDLY_Master Yoon|r.
.complete 31836,1 
.emote BOW,66073
.target Master Yoon
step
.xp >90,1
.isOnQuest 31836
.zoneskip 379,1
#completewith next
#label WaytoMasterHight2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31836 >>Turn in Continue Your Training: Master Yoon
.accept 31837 >>Accept Continue Your Training: Master Cheng
.disablecheckbox
.target Master Hight
step
.xp >90,1
.isOnQuest 31836
#completewith next
.goto 379,49.22,42.32,10,0
.goto 379,49.15,42.92,10 >>Enter the Temple
step
.xp >90,1
.isOnQuest 31836
#hidewindow
#completewith WaytoMasterHight2
.goto 379,48.67,42.76,20 >>1
step
.xp >90,1
.isOnQuest 31836
.zoneskip 379,1
#requires WaytoMasterHight2
.goto 379,48.67,42.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31836 >>Turn in Continue Your Training: Master Yoon
.accept 31837 >>Accept Continue Your Training: Master Cheng
.target Master Hight
step
.xp >90,1
.isOnQuest 31837
.zoneskip 379,1
#completewith next
#hidewindow
#label WaytoMaster
.complete 31837,1 
step
.xp >90,1
.isOnQuest 31837
#completewith next
.goto 379,49.4,42.67,17 >>Leave the Temple
step
.xp >90,1
.isOnQuest 31837
#hidewindow
#completewith WaytoMaster
.goto 379,48.54,41.5,80 >>1
step
.xp >90,1
.isOnQuest 31837
.zoneskip 379,1
#requires WaytoMaster
#completewith next
#label Masters Training Completed
>>After speaking with |cRXP_FRIENDLY_Master Cheng|r, walk towards the center and stop.
.complete 31837,1 
.target Master Cheng
step
.xp >90,1
.isOnQuest 31837
#requires WaytoMaster
#completewith Masters Training Completed
.goto 379,48.54,41.5
.gossipoption 40975 >>Talk to |cRXP_FRIENDLY_Master Cheng|r.
.timer 27,RP
.target Master Cheng
step
.xp >90,1
.isOnQuest 31837
.zoneskip 379,1
#requires Masters Training Completed
#title |cFFFCDC00Follow the Arrow|r
.goto 379,48.12,40.35
>>Stop at the arrow's position and target |cRXP_FRIENDLY_Master Yoon|r. Defeat her in a duel.
.complete 31837,1 
.emote BOW,66180
.target Master Cheng
step
.xp >90,1
.isOnQuest 31837
.zoneskip 379,1
#completewith next
#label WaytoMasterHight3
.goto 379,47.94,42.91,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31837 >>Turn in Continue Your Training: Master Cheng
.accept 31838 >>Accept Continue Your Training: Master Tsang
.disablecheckbox
.target Master Hight
step
.xp >90,1
.isOnQuest 31837
#completewith next
.goto 379,48.25,43.34,10 >>Enter the Temple
step
.xp >90,1
.isOnQuest 31837
#hidewindow
#completewith WaytoMasterHight3
.goto 379,48.55,42.81,25 >>1
step
.xp >90,1
.isOnQuest 31837
.zoneskip 379,1
#requires WaytoMasterHight3
.goto 379,48.55,42.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31837 >>Turn in Continue Your Training: Master Cheng
.accept 31838 >>Accept Continue Your Training: Master Tsang
.target Master Hight
step
.xp >90,1
.isOnQuest 31838
.zoneskip 379,1
#completewith next
#hidewindow
#label WaytoMasterTsang
.complete 31838,1 
step
.xp >90,1
.isOnQuest 31838
#completewith next
.goto 379,48.4,43.12,8,0
.goto 379,48.12,43.3,10 >>Leave the Temple
step
.xp >90,1
.isOnQuest 31838
#hidewindow
#completewith WaytoMasterTsang
.goto 379,48.8,40.49,80 >>1
step
.xp >90,1
.isOnQuest 31838
.zoneskip 379,1
#requires WaytoMasterTsang
#completewith next
#label Master Tsang's Training Completed
>>After speaking with |cRXP_FRIENDLY_Master Tsang's|r, walk towards the center and stop.
.complete 31838,1 
.target Master Tsang
step
.xp >90,1
.isOnQuest 31838
#requires WaytoMasterTsang
#completewith Master Tsang's Training Completed
.goto 379,48.07,41.26
.goto 379,48.07,41.37
.gossipoption 41014 >>Talk to |cRXP_FRIENDLY_Master Tsang|r.
.timer 20,RP
.target Master Tsang
step
.xp >90,1
.isOnQuest 31838
.zoneskip 379,1
#requires Master Tsang's Training Completed
#title |cFFFCDC00Follow the Arrow|r
>>Stop at the position of the arrow and target |cRXP_FRIENDLY_Master Tsang|r. |cRXP_WARN_Untarget him once he bows to you|r.
*Use |T606542:0|t[Crackling Jade Lightning] on the |cRXP_ENEMY_Monk Trainees|r around you on the Balance Poles, then defeat |cRXP_ENEMY_Master Tsang|r
.emote BOW,66149
.goto 379,48.12,40.37
.complete 31838,1 
.target Master Tsang
.mob Monk Trainee
step
.xp >90,1
.isOnQuest 31838
.zoneskip 379,1
#completewith next
#label WaytoMasterHight4
.goto 379,47.94,42.91,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31838 >>Turn in Continue Your Training: Master Tsang
.accept 31839 >>Accept Continue Your Training: Master Hsu
.disablecheckbox
step
.xp >90,1
.isOnQuest 31838
#completewith next
.goto 379,48.25,43.34,10 >>Enter the Temple
step
.xp >90,1
.isOnQuest 31838
#hidewindow
#completewith WaytoMasterHight4
.goto 379,48.55,42.81,25 >>1
step
.xp >90,1
.isOnQuest 31838
.zoneskip 379,1
#requires WaytoMasterHight4
.goto 379,48.55,42.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31838 >>Turn in Continue Your Training: Master Tsang
.accept 31839 >>Accept Continue Your Training: Master Hsu
.target Master Hight
step
.xp >90,1
.isOnQuest 31839
.zoneskip 379,1
#completewith next
#hidewindow
#label WaytoMasterHsu's
.complete 31839,1 
step
.xp >90,1
.isOnQuest 31839
#completewith next
.goto 379,48.4,43.12,8,0
.goto 379,48.12,43.3,10 >>Leave the Temple
step
.xp >90,1
.isOnQuest 31839
#hidewindow
#completewith WaytoMasterHsu's
.goto 379,47.52,41.08,80 >>1
step
.xp >90,1
.isOnQuest 31839
.zoneskip 379,1
#requires WaytoMasterHsu's
#completewith next
#label Master Hsu's Training Completed
>>After speaking with |cRXP_FRIENDLY_Master Hsu|r, walk towards the center and stop.
.complete 31839,1 
.target Master Hsu
step
.xp >90,1
.isOnQuest 31839
#requires WaytoMasterHsu's
#completewith Master Hsu's Training Completed
.goto 379,47.52,41.08
.gossipoption 40709 >>Talk to |cRXP_FRIENDLY_Master Hsu|r.
.timer 30,RP
.target Master Hsu
step
.xp >90,1
.isOnQuest 31839
.zoneskip 379,1
#requires Master Hsu's Training Completed
#title |cFFFCDC00Follow the Arrow|r
.goto 379,48.11,40.36
>>Stop at the arrow's position and target |cRXP_FRIENDLY_Master Hsu|r. Defeat him in a duel.
.complete 31839,1 
.emote BOW,65977
.target Master Hsu
step
.xp >90,1
.isOnQuest 31839
.zoneskip 379,1
#completewith next
#label WaytoMasterHight5
.goto 379,47.94,42.91,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31839 >>Turn in Continue Your Training: Master Hsu
.accept 31944 >>Accept Complete Your Training: The Final Test
.disablecheckbox
.target Master Hight
step
.xp >90,1
.isOnQuest 31839
#completewith next
.goto 379,48.25,43.34,10 >>Enter the Temple
step
.xp >90,1
.isOnQuest 31839
#hidewindow
#completewith WaytoMasterHight5
.goto 379,48.55,42.81,25 >>1
step
.xp >90,1
.isOnQuest 31839
.zoneskip 379,1
#requires WaytoMasterHight5
.goto 379,48.55,42.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31839 >>Turn in Continue Your Training: Master Hsu
.accept 31944 >>Accept Complete Your Training: The Final Test
.target Master Hight
step
.xp >90,1
.isOnQuest 31944
.zoneskip 379,1
#completewith next
#hidewindow
#label WaytoMasterHight6
.complete 31944,1 
step
.xp >90,1
.isOnQuest 31944
#completewith next
.goto 379,48.4,43.12,8,0
.goto 379,48.12,43.3,10 >>Leave the Temple
step
.xp >90,1
.isOnQuest 31944
#hidewindow
#completewith WaytoMasterHight6
.goto 379,48.32,41.52,30 >>1
step
.xp >90,1
.isOnQuest 31944
.zoneskip 379,1
#requires WaytoMasterHight6
#completewith next
#label Master Hight Training Completed
>>After speaking with |cRXP_FRIENDLY_Master Hight|r defeat him in a duel.
.complete 31944,1 
.target Master Hight
step
.xp >90,1
.isOnQuest 31944
#requires WaytoMasterHight6
#completewith Master Hight Training Completed
.goto 379,48.32,41.52
.gossipoption 41235 >>Talk to |cRXP_FRIENDLY_Master Hight|r |cRXP_WARN_near the gong|r.
.target Master Hight
step
.xp >90,1
.isOnQuest 31944
.zoneskip 379,1
#requires Master Hight Training Completed
#title |cFFFCDC00Follow the Arrow|r
.goto 379,48.33,41.52
>>Defeat |cRXP_ENEMY_Master Hight|r in a duel.
*If the objective doesn’t complete at 0% health, try interrupting or stunning him.
*|cRXP_WARN_If you get credit but stay in combatt, either ignore him or defeat him again—just make sure to untarget him quickly.|r
.complete 31944,1 
.emote BOW,66732
.target Master Hight
step
.xp >90,1
.isOnQuest 31944
.zoneskip 379,1
#completewith next
#label WaytoMasterHight7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31944 >>Turn in Complete Your Training: The Final Test
step
.xp >90,1
.isOnQuest 31944
#completewith next
.goto 379,47.93,42.94,10,0
.goto 379,48.24,43.35,10 >>Enter the Temple
step
.xp >90,1
.isOnQuest 31944
#hidewindow
#completewith WaytoMasterHight7
.goto 379,48.55,42.81,25 >>1
step
.xp >90,1
.isOnQuest 31944
.zoneskip 379,1
#requires WaytoMasterHight7
.goto 379,48.55,42.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Hight|r.
.turnin 31944 >>Turn in Complete Your Training: The Final Test
.target Master Hight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Burning Steppes Prep
#internal
step
.convertquest 28174,28418 << Horde
.convertquest 28172,28417 << Horde
.convertquest 28177,28419 << Horde
.convertquest 28178,28421 << Horde
.convertquest 28179,28420 << Horde
step
.zone 36 >>Go to Burning Steppes
step << Alliance
.goto 36,17.32,52.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_John J. Keeshan|r
.accept 28174 >>Accept Burning Vengeance
.target John J. Keeshan
step << Alliance
.goto 36,16.98,51.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mouton Flamestar|r
.accept 28172 >>Accept Done Nothing Wrong
.target Mouton Flamestar
step << Horde
.goto 36,17.46,51.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ariok|r
.accept 28418 >>Accept Burning Vengeance
.target Ariok
step << Horde
.goto 36,16.98,51.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mouton Flamestar|r
.accept 28417 >>Accept Done Nothing Wrong
.target Mouton Flamestar
step
#hidewindow
#completewith Blackrock Whelper
#loop
.goto 36,14.18,64.03,30,0
.goto 36,14.69,69.21,30,0
.goto 36,17.39,68.09,30,0
.goto 36,23.26,67.54,30,0
.goto 36,25.46,69.16,30,0
.goto 36,25.75,64.87,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Blackrock Whelper|r and |cRXP_ENEMY_Flamescale Broodling|r
.complete 28174,1 
.complete 28174,2 
.mob Blackrock Whelper
.mob Flamescale Broodling
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Whelpings|r
.complete 28172,1 
.complete 28172,4 
.complete 28172,3 
.complete 28172,2 
step
#label Blackrock Whelper
>>Kill |cRXP_ENEMY_Blackrock Whelper|r and |cRXP_ENEMY_Flamescale Broodling|r
.complete 28174,1 
.complete 28174,2 
.mob Blackrock Whelper
.mob Flamescale Broodling
step << Alliance
.goto 36,17.26,52.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_John J. Keeshan|r
.turnin 28174 >>Turn in Burning Vengeance
.target John J. Keeshan
.accept 28177 >>Accept Stocking Up
.accept 28178 >>Accept A Future Project
.accept 28179 >>Accept Mud Hunter
step << Horde
.goto 36,17.47,51.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ariok|r
.turnin 28418 >>Turn in Burning Vengeance
.target Ariok
.accept 28419 >>Accept Stocking Up
.accept 28421 >>Accept Mud Hunter
.accept 28420 >>Accept A Future Project
step
#hidewindow
#completewith Razor-Sharp Scorpid Barb
#loop
.goto 36,13.58,57.62,30,0
.goto 36,7.95,54.56,30,0
.goto 36,13.6,42.96,30,0
.goto 36,15.62,45.23,30,0
.goto 36,17.05,42.53,30,0
.goto 36,19.64,55.47,30,0
+1
step
#completewith Flecked Mud
>>Kill |cRXP_ENEMY_Scorpions|r
*Loot them for |T237394:0|t[|cRXP_LOOT_Razor-Sharp Scorpid Barb|r].
.complete 28177,1 
.mob Venomtip Scorpid
step
#completewith Flecked Mud
>>Kill |cRXP_ENEMY_Ember Worg|r
*Loot them for |T134266:0|t[|cRXP_LOOT_Ember Worg Hide|r].
.complete 28178,1 
.mob Ember Worg
step
#label Flecked Mud
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mud|r
.complete 28179,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Scorpions|r
*Loot them for |T237394:0|t[|cRXP_LOOT_Razor-Sharp Scorpid Barb|r].
.complete 28177,1 
.mob Venomtip Scorpid
step
>>Kill |cRXP_ENEMY_Ember Worg|r
*Loot them for |T134266:0|t[|cRXP_LOOT_Ember Worg Hide|r].
.complete 28178,1 
.mob Ember Worg
step
#label Razor-Sharp Scorpid Barb
>>Kill |cRXP_ENEMY_Scorpions|r
*Loot them for |T237394:0|t[|cRXP_LOOT_Razor-Sharp Scorpid Barb|r].
.complete 28177,1 
.mob Venomtip Scorpid
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Tirisfal Midnight Prep
#internal
<< Horde
step
#include a) Tirisfal Correct Launch Phase
step
.zone 18 >>Go to Old Tirisfal Glades
step
.zoneskip 18
.goto 2070,69.45,62.81
.gossipoption 49018 >>Talk to |cRXP_FRIENDLY_Zidormi|r
.target Zidormi
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathguard Simmer|r and |cRXP_FRIENDLY_Apothecary Johaan|r.
.accept 24978 >>Accept Reaping the Reapers
.goto 18,44.75,53.67
.target +Deathguard Simmer
.accept 24975 >>Accept Fields of Grief
.goto 18,44.61,53.79
.target +Apothecary Johaan
step
.goto 18,44.48,53.86,4,0
.goto 18,44.74,53.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tGo upstairs and talk to |cRXP_FRIENDLY_Sedrick Calston|r.
.accept 24974 >>Accept Ever So Lonely
.target Sedrick Calston
step
#hidewindow
#completewith Tirisfal Farmer
#loop
.goto 18,36.82,51.45,20,0
.goto 18,35.57,51.12,20,0
.goto 18,36.68,49.50,20,0
.goto 18,36.48,50.85,20,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Tirisfal Farmers|r.
.complete 24978,1 
.mob Tirisfal Farmer
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pumpkins|r.
.complete 24975,1 
step
#label Tirisfal Farmer
>>Kill |cRXP_ENEMY_Tirisfal Farmers|r.
.complete 24978,1 
.mob Tirisfal Farmer
.mob Shadowstalker
.mob Farmer Solliden
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathguard Simmer|r and |cRXP_FRIENDLY_Apothecary Johaan|r.
.turnin 24978 >>Turn in Reaping the Reapers
.accept 24980 >>Accept The Scarlet Palisade
.goto 18,44.75,53.68
.target +Deathguard Simmer
.turnin 24975 >>Turn in Fields of Grief
.accept 24976 >>Accept Variety is the Spice of Death
.goto 18,44.61,53.78
.target +Apothecary Johaan
step
#loop
.goto 18,37.74,39.50,25,0
.goto 18,36.83,43.38,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Thorns|r.
.complete 24976,2 
step
#loop
.goto 18,35.67,37.67,30,0
.goto 18,33.42,42.96,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Briny Sea Cucumber|r
.complete 24976,3 
step
.goto 18,35.8,43.4
>>Use |T252282:0|t[Soft Foam Sword] on a |cRXP_ENEMY_Murloc|r then use the |T133802:0|t[Murloc Leash].
.complete 24974,1 
.mob Vile Fin Minor Oracle
.mob Vile Fin Puddlejumper
.mob Muad
.use 52059
step
#loop
.goto 18,32.72,46.27,30,0
.goto 18,30.82,48.91,30,0
.goto 18,33.37,50.27,30,0
>>Kill |cRXP_ENEMY_Scarlet Warrior|r.
.complete 24980,1 
*Loot them for |T237451:0|t[A Scarlet Letter].
.accept 24979 >>Accept A Scarlet Letter
.mob Scarlet Warrior
step
#completewith next
#hidewindow
.gossipoption 38512 >>1
.timer 50,Roleplay Duration
step
#label AScarletLetterA
.goto 18,31.74,46.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian Voss|r.
.complete 24979,1 
.target Lilian Voss
.skipgossipid 38511
.skipgossipid 38021
.skipgossipid 38022
step
>>Kill |cRXP_ENEMY_Scarlet Warrior|r.
.complete 24980,1 
.mob Scarlet Warrior
step
.goto 18,49.58,54.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Marrowpetal Stalks|r.
.complete 24976,1 
step
.goto 18,44.63,53.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Johaan|r
.turnin 24976 >>Turn in Variety is the Spice of Death
.target Apothecary Johaan
.accept 24977 >>Accept Johaan's Experiment
step
.goto 18,44.70,52.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captured Scarlet Zealot|r
.turnin 24977 >>Turn in Johaan's Experiment
.target Captured Scarlet Zealot
step
.goto 18,44.65,52.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordo|r
.accept 25038 >>Accept Gordo's Task
.target Gordo
step
#loop
.goto 18,46.68,53.64,30,0
.goto 18,48.11,57.65,30,0
.goto 18,51.5,58.98,30,0
.goto 18,53.51,51.07,30,0
.goto 18,57.45,52.16,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gloom Weed|r
.complete 25038,1 
step
.goto 18,60.14,53.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Junior Apothecary Holland|r
.accept 24990 >>Accept Darkhound Pounding
.target Junior Apothecary Holland
step
.goto 18,60.54,51.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Executor Zygand|r.
.accept 24981 >>Accept A Thorn in our Side
.target Executor Zygand
step
#completewith next
>>Kill |cRXP_ENEMY_Decrepit Darkhounds|r.
*Loot them for the |T134719:0|t[|cRXP_LOOT_Darkhound Blood|r].
.complete 24990,1 
.mob Decrepit Darkhound
step
#loop
.goto 18,47.33,59.51,30,0
.goto 18,45.18,60.11,30,0
.goto 18,46.13,63.75,30,0
#title DON'T KILL THE CURSED DARKHOUND
>>Use a non damaging ability on |cRXP_ENEMY_Cursed Darkhound|r.
*|cRXP_WARN_Wait for the Worgen to appear it might take a moment|r
.accept 24992 >>Accept Escaped From Gilneas
.mob Cursed Darkhound
step
#hidewindow
#completewith Darkhound Blood
#loop
.goto 18,51.56,67.81,35,0
.goto 18,53.11,70.39,35,0
.goto 18,58.98,59.3,35,0
.goto 18,53.84,53.81,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Decrepit Darkhounds|r.
*Loot them for the |T134719:0|t[|cRXP_LOOT_Darkhound Blood|r].
.complete 24990,1 
.mob Decrepit Darkhound
step
#completewith next
>>Kill |cRXP_ENEMY_Captain Perrine|r and his minions.
*Loot him for the |T237247:0|t[|cRXP_LOOT_Urgent Scarlet Memorandum|r].
.complete 24981,1 
.complete 24981,2 
.complete 24981,3 
.mob Scarlet Zealotstep
.mob Scarlet Missionary
.mob Captain Perrine
step
#label Darkhound Blood
>>Kill |cRXP_ENEMY_Decrepit Darkhounds|r.
*Loot them for the |T134719:0|t[|cRXP_LOOT_Darkhound Blood|r].
.complete 24990,1 
.mob Decrepit Darkhound
step
.goto 18,52.56,54.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathguard Dillinger|r
.accept 25090 >>Accept A Putrid Task
.accept 24982 >>Accept The New Forsaken
.target Deathguard Dillinger
step
#loop
.goto 18,54.65,57.64,30,0
.goto 18,53.57,59.24,30,0
.goto 18,52.05,56.94,30,0
>>Kill |cRXP_ENEMY_Zombies|r
*Loot them for the |T134294:0|t[|cRXP_LOOT_Putric Claw|r].
.complete 25090,1 
.mob Ravaged Corpse
.mob Rotten Dead
step
.goto 18,60.81,51.97,5,0
.goto 18,60.91,51.15,5,0
.goto 18,60.51,51.01,5,0
.goto 18,60.65,50.82,5,0
.goto 18,60.96,50.86,5,0
.goto 18,61.08,50.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Sevren|r
.turnin 24982 >>Turn in The New Forsaken
.target Magistrate Sevren
.accept 24983 >>Accept Forsaken Duties
step
.goto 18,65.49,60.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathguard Linnea|r
.turnin 24983 >>Turn in Forsaken Duties
.target Deathguard Linnea
step
.goto 18,65.25,60.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gretchen Dedmar|r
.accept 24988 >>Accept The Chill of Death
.target Gretchen Dedmar
step
#loop
.goto 18,66.78,61.54,30,0
.goto 18,71.81,59.26,30,0
.goto 18,68.76,55.83,30,0
.goto 18,62.21,56.91,30,0
>>Kill |cRXP_ENEMY_Bats|r
*Loot them for |T134355:0|t[|cRXP_LOOT_Pelt|r].
.complete 24988,1 
step
.goto 18,61.65,34.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Jerrod|r.
.accept 24994 >>Accept Doom Weed
.target Apothecary Jerrod
step
.goto 18,61.61,34.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Crispin|r.
.accept 24997 >>Accept Graverobbers
.target Apprentice Crispin
step
#hidewindow
#completewith Doom Weed
#loop
.goto 18,59.07,32.84,35,0
.goto 18,57.27,35.46,35,0
.goto 18,56.7,39.55,35,0
.goto 18,55.12,42.48,35,0
.goto 18,58.03,43.03,35,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Doom Weed|r.
.complete 24994,1 
step
>>Kill |cRXP_ENEMY_Rot Hide Mongrel|r and |cRXP_ENEMY_Rot Hide Graverobber|r
*Loot |cRXP_ENEMY_Graverobber|r for |T134717:0|t[|cRXP_LOOT_Embalming Ichors|r].
.complete 24997,2 
.complete 24997,3 
.complete 24997,1 
.mob Rot Hide Mongrel
.mob Rot Hide Graverobber
step
#label Doom Weed
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Doom Weed|r.
.complete 24994,1 
step
.goto 18,61.65,34.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Jerrod|r.
.turnin 24994 >>Turn in Doom Weed
.accept 24995 >>Accept Off the Scales
.target Apothecary Jerrod
step
.goto 18,61.60,34.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Crispin|r.


.accept 24999 >>Accept Planting the Seed of Fear
.target Apprentice Crispin
step
#completewith OffTheScalesA
#hidewindow
#loop
.goto 18,65.55,28.52,45,0
.goto 18,59.44,27.66,35,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Vile Fin Murlocs|r.
*Loot them for the |T134304:0|t[|cRXP_LOOT_Vile Fin Scales|r].
.complete 24995,1 
.mob Vile Fin Murloc
.mob Vile Fin Oracle
.mob Vile Fin Muckdweller
step
>>Run on top of the |cRXP_FRIENDLY_Vile Fin Tadpoles|r.
*|cRXP_WARN_NOTE:|r Follow the Murlocs until they count for the quest.
.complete 24999,1 
.target Vile Fin Tadpole
step
#label OffTheScalesA
>>Kill the |cRXP_ENEMY_Vile Fin Murlocs|r. Loot them for the |T134304:0|t[|cRXP_LOOT_Vile Fin Scales|r].
.complete 24995,1 
.mob Vile Fin Murloc
.mob Vile Fin Oracle
.mob Vile Fin Muckdweller





step
.goto 18,54.60,29.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Coleman Farthing|r.
.accept 25003 >>Accept The Family Crypt
.target Coleman Farthing
step
#completewith he Haunted Mills
>>Kill |cRXP_ENEMY_Wailing Ancestor|r and |cRXP_ENEMY_Rotting Ancestor|r.
.complete 25003,1 
.complete 25003,2 
.mob Wailing Ancestor
.mob Rotting Ancestor
step
#completewith next
#label TheHauntedMillsA
>>Kill |cRXP_ENEMY_Captain Dargol|r. Loot him for the |T133730:0|t[|cRXP_LOOT_Dargol's Skull|r].
.accept 25030 >>Accept The Haunted Mills
.mob Captain Dargol
step
#completewith TheHauntedMillsA
#title Enter the crypt
.goto 18,52.26,26.89,10,0
.goto 18,52.25,26.32,8 >>|cRXP_WARN_Follow the arrow into the crypt|r.
step
#requires TheHauntedMillsA
#label he Haunted Mills
.goto 18,52.75,26.36
>>Kill |cRXP_ENEMY_Captain Dargol|r. Loot him for the |T133730:0|t[|cRXP_LOOT_Dargol's Skull|r].
.accept 25030 >>Accept The Haunted Mills
.mob Captain Dargol
step
#completewith next
#label TheFamilyCryptA
>>Kill |cRXP_ENEMY_Wailing Ancestor|r and |cRXP_ENEMY_Rotting Ancestor|r.
.complete 25003,1 
.complete 25003,2 
.mob Wailing Ancestor
.mob Rotting Ancestor
step
#completewith TheFamilyCryptA
#title Leave the crypt
.goto 18,52.26,26.89,10 >>|cRXP_WARN_Leave the crypt.|r
step
#requires TheFamilyCryptA
#loop
.goto 18,49.76,29.28,35,0
.goto 18,51.06,31.86,35,0
.goto 18,54.60,29.91,50,0
.goto 18,52.26,26.89,20,0
>>Kill |cRXP_ENEMY_Wailing Ancestor|r and |cRXP_ENEMY_Rotting Ancestor|r.
.complete 25003,1 
.complete 25003,2 
.mob Wailing Ancestor
.mob Rotting Ancestor
step
.goto 18,54.59,29.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Coleman Farthing|r.
.turnin 25003 >>Turn in The Family Crypt
.accept 25029 >>Accept Deaths in the Family
.accept 25004 >>Accept The Mills Overrun
.target Coleman Farthing
step
#completewith DeathsInTheFamilyA
>>Kill |cRXP_ENEMY_Darkeye Bonecaster|r |cRXP_ENEMY_Cracked Skull Soldier|r
*Loot them for the |T133730:0|t[|cRXP_LOOT_Blackened Skulls|r] and |T133730:0|t[|cRXP_LOOT_Notched Ribs|r].
.complete 25004,2 
.complete 25004,1 
.mob Darkeye Bonecaster
.mob Cracked Skull Soldier
step
.goto 18,45.97,30.21
>>Kill |cRXP_ENEMY_Thurman Agamand|r. Loot him for |T237274:0|t[|cRXP_LOOT_Thurman's Remains|r].
.complete 25029,3 
.mob Thurman Agamand
step
.goto 18,45.58,29.54
>>Kill |cRXP_ENEMY_Gregor Agamand|r. Loot him for |T133729:0|t[|cRXP_LOOT_Gregor's Remains|r].
.complete 25029,2 
.mob Gregor Agamand
step
.goto 18,48.95,33.91
>>Kill |cRXP_ENEMY_Devlin Agamand|r. Loot him for |T133730:0|t[|cRXP_LOOT_Devlin's Remains|r].
.complete 25029,4 
.mob Devlin Agamand
step
#label DeathsInTheFamilyA
.goto 18,49.34,36.03
>>Kill |cRXP_ENEMY_Nissa Agamand|r. Loot him for |T134437:0|t[|cRXP_LOOT_Nissa's Remains|r].
.complete 25029,1 
.mob Nissa Agamand
step
#loop
.goto 18,49.83,28.72,40,0
.goto 18,47.22,35.9,40,0
.goto 18,47.95,40.67,40,0
>>Kill |cRXP_ENEMY_Darkeye Bonecaster|r |cRXP_ENEMY_Cracked Skull Soldier|r
*Loot them for the |T133730:0|t[|cRXP_LOOT_Blackened Skulls|r] and |T133730:0|t[|cRXP_LOOT_Notched Ribs|r].
.complete 25004,2 
.complete 25004,1 
.mob Darkeye Bonecaster
.mob Cracked Skull Soldier
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Tirisfal Correct Launch Phase
#internal
step
.goto 85,50.70,75.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.accept 65656 >>Accept Call to Lordaeron
.target Calia Menethil
step
.goto 85,50.84,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forsaken Dreadmage for a teleport|r.
.complete 65656,1 
.skipgossipid 54680
.target Forsaken Dreadmage for a teleport
step
.goto 2070,60.82,51.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.turnin 65656 >>Turn in Call to Lordaeron
.target Calia Menethil
.accept 65657 >>Accept Assemble the Forsaken
step
.goto 2070,61.96,50.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dark Ranger Velonara|r.
.complete 65657,1 
.accept 65658 >>Accept This Land is Ours
.target Dark Ranger Velonara
step
#loop
.goto 2070,61.97,49.48,30,0
.goto 2070,61.16,46.61,30,0
>>Kill |cRXP_ENEMY_Blighted Soldiers and Shadowmages|r.
.complete 65658,1 
.mob Blighted Soldier
.mob Blighted Shadowmage
step
.goto 2070,63.22,55.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Apothecary Faranell|r.
.complete 65657,3 
.skipgossipid 54569
.target Master Apothecary Faranell
step
.goto 2070,57.58,49.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian Voss|r.
.complete 65657,2 
.skipgossipid 54570
.target Lilian Voss
step
.goto 2070,60.79,51.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dark Ranger Velonara|r.
.turnin 65658 >>Turn in This Land is Ours
.target Dark Ranger Velonara
step
.goto 2070,60.90,51.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian Voss|r.
.turnin 65657 >>Turn in Assemble the Forsaken
.accept 65659 >>Accept The Blight Congress
.target Lilian Voss
step
.goto 2070,60.90,51.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian to begin|r.
.complete 65659,1 
.skipgossipid 54673
.target Lilian to begin
step
.goto 2070,60.90,51.32
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 65659,2 
step
.goto 2070,60.79,51.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia|r.
.complete 65659,3 
.skipgossipid 54676
.target Calia
step
.goto 2070,61.97,55.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.turnin 65659 >>Turn in The Blight Congress
.target Calia Menethil
.accept 65660 >>Accept Walk of Faith
step
.goto 2070,61.97,55.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia|r.
.complete 65660,1 
.skipgossipid 54677
.target Calia to Begin
step
>>Follow |cRXP_FRIENDLY_Calia|r use the ExtraActionButton when you can.
.complete 65660,2 
step
>>Follow |cRXP_FRIENDLY_Calia|r.
.complete 65660,3 
step
.goto 2070,61.91,55.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian Voss|r.
.turnin 65660 >>Turn in Walk of Faith
.target Lilian Voss
.accept 65661 >>Accept Consulting Our Allies
step
#completewith next
#label Consulting Our Allies
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Margrave Sin'dane|r.
.turnin 65661 >>Turn in Consulting Our Allies
.target Margrave Sin'dane
step
#completewith Consulting Our Allies
.goto 2070,62.21,55.2
.zone 1536 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Maldraxxus|r
step
#requires Consulting Our Allies
.goto 1536,74.76,33.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Margrave Sin'dane|r.
.turnin 65661 >>Turn in Consulting Our Allies
.target Margrave Sin'dane
.accept 65662 >>Accept House of Plagues
step
#completewith next
#label House of Plagues
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Plague Deviser Marileth|r.
.turnin 65662 >>Turn in House of Plagues
.target Plague Deviser Marileth
step
#completewith House of Plagues
.goto 1536,73.57,33.43
.cast 350876 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
step
#requires House of Plagues
.goto 1536,71.15,71.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Plague Deviser Marileth|r.
.turnin 65662 >>Turn in House of Plagues
.target Plague Deviser Marileth
.accept 65664 >>Accept Essence of Plague
step
.goto 1536,71.14,71.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.accept 65663 >>Accept Feed the Eater
.target Calia Menethil
step
#completewithTumultuous Concoction
>>Kill |cRXP_ENEMY_Plagues|r
.complete 65663,1 
step
.goto 1536,70.93,74.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r
.complete 65664,1 
step
.goto 1536,69.64,75.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r
.complete 65664,2 
step
#label Tumultuous Concoction
.goto 1536,68.56,79.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r
.complete 65664,3 
step
#loop
.goto 1536,67.96,81.26,30,0
.goto 1536,69.29,76.78,30,0
.goto 1536,70.64,73.85,30,0
>>Kill |cRXP_ENEMY_Plagues|r
.complete 65663,1 
step
.goto 1536,68.67,81.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.turnin 65663 >>Turn in Feed the Eater
.target Calia Menethil
step
.goto 1536,68.68,81.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Plague Deviser Marileth|r.
.turnin 65664 >>Turn in Essence of Plague
.target Plague Deviser Marileth
.accept 65665 >>Accept Embodiment
step
.goto 1536,68.17,84.57
>>Kill |cRXP_ENEMY_Lordaeron Blight|r.
.complete 65665,1 
.mob Lordaeron Blight
step
.goto 1536,68.61,81.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian Voss|r.
.turnin 65665 >>Turn in Embodiment
.target Lilian Voss
.accept 65666 >>Accept Return to Brill
step
#completewith next
#label Master Apothecary Faranell
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Apothecary Faranell|r.
.complete 65666,1 
.target Master Apothecary Faranell
step
#completewith Master Apothecary Faranell
.zone 2070 >>Use |T413582:0|t[Lilian's Hearthstone]
.use 191029
step
#requires Master Apothecary Faranell
.goto 2070,65.78,60.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Apothecary Faranell|r.
.complete 65666,1 
.skipgossipid 54622
.target Master Apothecary Faranell
step
.goto 2070,65.78,60.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Apothecary Faranell|r after the roleplay.
.turnin 65666 >>Turn in Return to Brill
.target Master Apothecary Faranell
step
.goto 2070,65.86,60.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.accept 65667 >>Accept The Remedy of Lordaeron
.target Calia Menethil
step
.goto 2070,65.70,59.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowbat|r
.complete 65667,1 
.target Shadowbat
step
>>Use |T136182:0|t[Deploy] and |T132182:0|t[Call Batriders] on Barrels
.complete 65667,2,100 
step
.goto 2070,62.84,69.01
>>Use |T136197:0|t[Shadowbolt] and |T136201:0|t[Shadow Conflagration] on |cRXP_ENEMY_Amalgam|r.
.complete 65667,3 
.mob Amalgam
step
.goto 2070,61.84,67.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian Voss|r.
.turnin 65667 >>Turn in The Remedy of Lordaeron
.target Lilian Voss
.accept 65668 >>Accept The Desolate Council
step
.goto 2070,61.82,67.96
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 65668,1 
step
.goto 2070,61.79,67.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.turnin 65668 >>Turn in The Desolate Council
.target Calia Menethil
step
.goto 2070,61.92,67.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dark Ranger Velonara|r.
.turnin 66091 >>Turn in Path of the Dark Rangers
.target Dark Ranger Velonara
step
.goto 2070,61.86,67.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilian Voss|r.
.accept 65788 >>Accept A Walk with Ghosts
.target Lilian Voss
step
.goto 2070,61.82,71.45
#title |cFFFCDC00Follow the Arrow|r
.complete 65788,1 
step
.goto 2070,61.85,72.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calia Menethil|r.
.turnin 65788 >>Turn in A Walk with Ghosts
.target Calia Menethil
step
.goto 2070,69.45,62.82
.gossipoption 49018 >>Talk to |cRXP_FRIENDLY_Zidormi|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Heritage Pandaren
#internal
#chapter
step << Horde
.isOnQuest 84444
.goto 85,70.32,38.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
.turnin 84444 >>Turn in Invitation to the Spirit Festival
.target Ji Firepaw
step << Horde
.goto 85,70.48,39.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout|r
.accept 84452 >>Accept The Wanderers
.target Li Li Stormstout
step << Horde
#completewith next
#label air balloon
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 84452,1 
step << Horde
#completewith air balloon
.goto 85,70.82,38.89
.vehicle >>Click on the Balloon
.timer 65,RP
step << Horde
#requires air balloon
.goto 2366,49.51,24.58
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 84452,1 
step << Horde
.goto 2366,50.68,19.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout|r
.turnin 84452 >>Turn in The Wanderers
.target Li Li Stormstout
step << Alliance
.isOnQuest 84442
.goto 84,68.39,16.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
.turnin 84442 >>Turn in Invitation to the Spirit Festival
.target Aysa Cloudsinger
step << Alliance
.goto 84,68.17,16.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout|r
.accept 84451 >>Accept The Wanderers
.target Li Li Stormstout
step << Alliance
#completewith next
#label air balloon2
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 84451,1 
step << Alliance
#completewith air balloon2
.goto 84,68.64,17.07
.vehicle >>Click on the Balloon
.timer 63,RP
step << Alliance
#requires air balloon2
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 84451,1 
step << Alliance
.goto 2366,50.69,19.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout|r
.turnin 84451 >>Turn in The Wanderers
.target Li Li Stormstout
step
.goto 2366,50.59,20.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.accept 84453 >>Accept To Dai-Lo Farmstead
.target Chen Stormstout
step << Horde
.goto 2366,50.34,20.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
.accept 84457 >>Accept To Morning Breeze
.target Ji Firepaw
step << Alliance
.goto 2366,50.36,20.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
.accept 84456 >>Accept To Morning Breeze
.target Aysa Cloudsinger
step << Horde
.goto 2366,30.13,41.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
.turnin 84457 >>Turn in To Morning Breeze
.accept 84459 >>Accept Scamps Ain't It!
.target Ji Firepaw
step << Alliance
.goto 2366,30.15,41.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
.turnin 84456 >>Turn in To Morning Breeze
.accept 84458 >>Accept Devil's in the Details
.target Aysa Cloudsinger
step << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r |cRXP_WARN_next to you|r.
.accept 84459 >>Accept Scamps Ain't It!
.target Ji Firepaw
step << Horde
.goto 2366,30.15,41.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
.accept 84458 >>Accept Devil's in the Details
.target Aysa Cloudsinger
step
#completewith Swarming Nymph
+|cRXP_WARN_Don't turn in the quest |r [Scamps Ain't It!] |cRXP_WARN_and|r [Devil's in the Details].
step
.goto 2366,28.57,41.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r
*|cRXP_WARN_Kill any |cRXP_ENEMY_Amberleaf Scamp|r that might spawn|r.
.complete 84459,1,2 
.mob Amberleaf Scamp
step
.goto 2366,28.47,42.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Clue|r inside the house.
.complete 84458,1,1 
step
.goto 2366,30.22,43.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r
*|cRXP_WARN_Kill any |cRXP_ENEMY_Amberleaf Scamp|r that might spawn|r.
.complete 84459,1,4 
step
.goto 2366,31.61,41.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morning Breeze Witness|r
.complete 84458,1,2 
.skipgossipid 124332
.target Morning Breeze Witness
step
.goto 2366,32.44,42.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r
*|cRXP_WARN_Kill any |cRXP_ENEMY_Amberleaf Scamp|r that might spawn|r.
.complete 84459,1,6 
step
.goto 2366,31.51,39.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r
*|cRXP_WARN_Kill any |cRXP_ENEMY_Amberleaf Scamp|r that might spawn|r.
.complete 84459,1,7 
step
.goto 2366,30.44,38.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bananas|r
.complete 84458,1,3 
step
.goto 2366,30.24,37.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r
*|cRXP_WARN_Kill any |cRXP_ENEMY_Amberleaf Scamp|r that might spawn|r.
.complete 84459,1,8 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r and |cRXP_FRIENDLY_Chon Po Stormstout|r
.turnin 84453 >>Turn in To Dai-Lo Farmstead
.accept 84454 >>Accept Tide of Virmen
.goto 2366,69.72,67.63
.target +Chen Stormstout
.accept 84455 >>Accept Big Bertha
.goto 2366,69.86,67.55
.target +Chon Po Stormstout
step
#completewith Yak Eater
>>Kill |cRXP_ENEMY_Virmen|r and |cRXP_ENEMY_Insects|r
.complete 84454,1,100 
.mob Swarming Nymph
.mob Emerald Superpest
.mob Plump Virmen
step
#completewith next
#label Big Bertha found
.goto 2366,72.14,70.68,20,0
#hidewindow
.complete 84455,1 
step
#completewith Big Bertha found
#title |cFFFCDC00Follow the Arrow|r
.goto 2366,74.65,73.69,50 >>Enter the Burrow
step
#requires Big Bertha found
.goto 2366,74.65,73.69
#title |cFFFCDC00Follow the Arrow|r
.complete 84455,1 
step
#label Yak Eater
.goto 2366,74.65,73.69
>>Kill |cRXP_ENEMY_Yak Eater|r
.complete 84455,2 
.mob Yak Eater
step
#completewith next
#label Take back the farm
>>Kill |cRXP_ENEMY_Virmen|r and |cRXP_ENEMY_Insects|r
.complete 84454,1,100 
.mob Swarming Nymph
.mob Emerald Superpest
.mob Plump Virmen
step
#completewith Take back the farm
#title |cFFFCDC00Follow the Arrow|r
.goto 2366,75.05,69.25,30 >>Leave the Burrow
step
#requires Take back the farm
#label Swarming Nymph
#loop
.goto 2366,74.56,67.01,25,0
.goto 2366,70.75,69.75,30,0
.goto 2366,67.54,75.1,30,0
.goto 2366,68.96,82.38,30,0
.goto 2366,74.57,77.23,30,0
.goto 2366,74.61,72,30,0
>>Kill |cRXP_ENEMY_Virmen|r and |cRXP_ENEMY_Insects|r
*>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r
.complete 84454,1,100 
.mob Swarming Nymph
.mob Emerald Superpest
.mob Plump Virmen














]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Endeavor Turnins
#internal
step << Alliance !Monk
.xp >90,1
.isOnQuest 30614,30616,30808,31207,31394,30491,30804,30489,30587,30744,30967,30496,30469,30834,30468,30571,30581,30595,30583,30619,30575,30593,31252,30665,30670,30682,30746,30745,30742,30743,30599,30604,30600,30605,30601,30618,30621,30492
.zone 2352 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Kun-lai Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step << Horde !Monk
.xp >90,1
.isOnQuest 30614,30616,30808,31207,31394,30491,30804,30489,30587,30744,30967,30496,30469,30834,30468,30571,30581,30595,31251,31253,30620,31256,30594,30665,30670,30682,30746,30745,30742,30743,30599,30604,30600,30605,30601,30618,30621,30492
.zone 2351 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Kun-lai Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.xp >90,1
.isQuestComplete 30614
.goto 379,65.49,60.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slimy Inkstain|r.
.turnin 30614 >>Turn in Oil Stop
.target Slimy Inkstain
step
.xp >90,1
.isQuestComplete 30616
.goto 379,64.88,60.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey Sootassle|r.
.turnin 30616 >>Turn in Traffic Issues
.target Smokey Sootassle
step
.xp >90,1
.isQuestComplete 30808
.goto 379,64.70,61.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Eightcoins|r.
.turnin 30808 >>Turn in A Grummle's Luck
.target Lucky Eightcoins
step
.xp >90,1
.isQuestComplete 31207
.goto 379,68.65,48.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wodin the Troll-Servant|r.
.turnin 31207 >>Turn in The Arena of Annihilation
.target Wodin the Troll-Servant
step
.xp >90,1
.isQuestComplete 31394
.goto 379,68.78,43.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r.
.turnin 31394 >>Turn in A Celestial Experience
.target Anduin Wrynn
step
.xp >90,1
.isQuestComplete 30491
.goto 379,71.39,69.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muskpaw Jr.|r.
.turnin 30491 >>Turn in At the Yak Wash
.target Muskpaw Jr.
step
.xp >90,1
.isQuestComplete 30804
.goto 379,71.68,70.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao Muskpaw|r.
.turnin 30804 >>Turn in The Fearmaster
.target Lao Muskpaw
step
.xp >90,1
.isQuestComplete 30489
.goto 379,71.68,70.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao Muskpaw|r.
.target Lao Muskpaw
.turnin 30489 >>Turn in Fresh Needle Scent
step
.xp >90,1
.isQuestComplete 30587
.goto 379,71.68,70.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao Muskpaw|r.
.target Lao Muskpaw
.turnin 30587 >>Turn in Yakity Yak
step
.xp >90,1
.zoneskip 379,1
.goto 379,71.39,69.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muskpaw Jr.|r.
.accept 30492 >>Accept Back in Yak
.target Muskpaw Jr.
step
.xp >90,1
.zoneskip 379,1
.isQuestComplete 30744
.goto 379,72.87,71.49
>>Click on the Quest Pop Up and turn in the quest.
.turnin 30744 >>Turn in Kota Blend
.accept 30746 >>Accept A Fair Trade
step
.xp >90,1
.isQuestComplete 30967
.goto 379,75.20,88.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Waterspeaker Gorai|r.
.turnin 30967 >>Turn in Free the Dissenters
.target Waterspeaker Gorai
step
.xp >90,1
.isQuestComplete 30496
.goto 379,75.20,88.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Waterspeaker Gorai|r.
.target Waterspeaker Gorai
.turnin 30496 >>Turn in The Waterspeaker's Staff
step
.xp >90,1
.isQuestComplete 30469
.goto 379,74.96,88.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merchant Shi|r.
.turnin 30469 >>Turn in Repossession
.target Merchant Shi
step
.xp >90,1
.isQuestComplete 30834
.goto 379,74.96,88.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merchant Shi|r.
.target Merchant Shi
.turnin 30834 >>Turn in Father and Child Reunion
step
.xp >90,1
.isQuestComplete 30468
.goto 379,74.79,88.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Swordmistress Mei|r.
.turnin 30468 >>Turn in Enraged Vengeance
.target Swordmistress Mei
step
.xp >90,1
.isQuestComplete 30571
.goto 379,60.25,85.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Chow|r.
.turnin 30571 >>Turn in Farmhand Freedom
.target Farmer Chow
step
.xp >90,1
.isQuestComplete 30581
.goto 379,60.17,85.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uyen Chow|r.
.turnin 30581 >>Turn in ... and the Pot, Too!
.target Uyen Chow
step
.xp >90,1
.zoneskip 379,1
.goto 379,60.24,85.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Chow|r.
.accept 31252 >>Accept Back to Westwind Rest
.target Farmer Chow
step
.xp >90,1
.isQuestComplete 30595
.goto 379,59.61,78.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bao Jian|r.
.turnin 30595 >>Turn in Profiting off of the Past
.target Bao Jian
step << Horde
.xp >90,1
.isQuestComplete 31251
.goto 379,62.78,79.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r.
.turnin 31251 >>Turn in Best Meals Anywhere!
.target Rivett Clutchpop
step << Horde
.xp >90,1
.isQuestComplete 31253
.goto 379,62.54,79.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Ko|r.
.turnin 31253 >>Turn in Back to Eastwind Rest
.target Farmhand Ko
step << Horde
.xp >90,1
.isQuestComplete 30620
.goto 379,62.34,79.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.turnin 30620 >>Turn in Mogu?! Oh No-gu!
.target Elder Shiao
step << Horde
.xp >90,1
.isQuestComplete 31256
.goto 379,63.00,80.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.turnin 31256 >>Turn in Round 'Em Up
.target General Nazgrim
step << Horde
.xp >90,1
.isQuestComplete 30594
.goto 379,62.69,80.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r.
.turnin 30594 >>Turn in Deanimate the Reanimated
.target Shademaster Kiryn
step << Alliance
.xp >90,1
.isQuestComplete 30583
.goto 379,54.16,83.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r.
.turnin 30583 >>Turn in Blue Dwarf Needs Food Badly
.target Sully "The Pickle" McLeary
step << Alliance
.xp >90,1
.isQuestComplete 30619
.goto 379,54.16,83.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.turnin 30619 >>Turn in Mogu?! Oh No-gu!
.target Elder Tsulan
step << Alliance
.xp >90,1
.isQuestComplete 30575
.goto 379,53.77,82.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r.
.turnin 30575 >>Turn in Round 'Em Up
.target Admiral Taylor
step << Alliance
.xp >90,1
.isQuestComplete 30593
.goto 379,53.67,83.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r.
.turnin 30593 >>Turn in Deanimate the Reanimated
.target Mishka
step << Alliance
.xp >90,1
.isQuestComplete 31252
.goto 379,53.78,84.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Bo|r.
.turnin 31252 >>Turn in Back to Westwind Rest
.target Farmhand Bo
step
.xp >90,1
.isOnQuest 31512
.goto 379,55.11,91.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin at the Gate of the August Celestials|r.
.complete 31512,1 
.target Anduin at the Gate of the August Celestials
step
.xp >90,1
.isQuestComplete 30665
.goto 379,44.48,89.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.turnin 30665 >>Turn in The Defense of Shado-Pan Fallback
.target Shado-Master Chong
step
.xp >90,1
.isQuestComplete 30670
.goto 379,44.48,89.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.target Shado-Master Chong
.turnin 30670 >>Turn in Turnabout
step
.xp >90,1
.isQuestComplete 30682
.goto 379,44.48,89.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.target Shado-Master Chong
.turnin 30682 >>Turn in Holed Up
step
.xp >90,1
.isQuestComplete 30746
.goto 379,36.93,76.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nephew Burrberry|r.
.turnin 30746 >>Turn in A Fair Trade
.target Nephew Burrberry
step
.xp >90,1
.isQuestComplete 30745
.goto 379,42.53,69.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Keenbean|r.
.turnin 30745 >>Turn in Trouble Brewing
.target Uncle Keenbean
step
.xp >90,1
.isQuestComplete 30742
.goto 379,42.46,69.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cousin Gootfur|r.
.turnin 30742 >>Turn in Shut it Down
.target Cousin Gootfur
step
.xp >90,1
.isQuestComplete 30743
.goto 379,42.46,69.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cousin Gootfur|r.
.target Cousin Gootfur
.turnin 30743 >>Turn in Gourmet Kafa
step
.xp >90,1
.isQuestComplete 30599
.goto 379,51.97,67.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30599 >>Turn in A Monkey Idol
.target Brother Rabbitsfoot
step
.xp >90,1
.isQuestComplete 30604
.goto 379,51.97,67.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.target Brother Rabbitsfoot
.turnin 30604 >>Turn in Breaking Broketooth
step
.xp >90,1
.isQuestComplete 30600
.goto 379,51.97,67.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.target Brother Rabbitsfoot
.turnin 30600 >>Turn in No Pack Left Behind1
step
.isQuestTurnedIn 30600
.xp >90,1
.goto 379,51.97,67.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.target Brother Rabbitsfoot
.accept 30605 >>Accept Lucky Yakshoe
step
.xp >90,1
.isOnQuest 30605
.goto 379,50.58,64.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Monkey|r
.complete 30605,1 
step
.xp >90,1
.isQuestComplete 30605
.goto 379,50.57,64.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Yakshoe|r.
.turnin 30605 >>Turn in Lucky Yakshoe
.target Brother Yakshoe
step
.xp >90,1
.isQuestComplete 30601
.goto 379,57.23,61.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Cloverleaf|r.
.turnin 30601 >>Turn in Instant Courage
.target Uncle Cloverleaf
step
.xp >90,1
.isQuestComplete 30618
.goto 379,57.71,61.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.turnin 30618 >>Turn in Resupplying One Keg
.target Big Sal
step
.xp >90,1
.isQuestComplete 30621
.goto 379,57.32,60.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r.
.turnin 30621 >>Turn in They Stole My Luck!
.target Ji-Lu the Lucky
step
.xp >90,1
.isOnQuest 30492
.goto 379,65.07,61.50
#title |cFFFCDC00Follow the Arrow|r
.complete 30492,1 
step
.xp >90,1
.isQuestComplete 30492
.goto 379,64.71,61.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Eightcoins|r.
.turnin 30492 >>Turn in Back in Yak
.target Lucky Eightcoins
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name a) Eversong Woods Campaign(A)
#displayname |cFF00FF001|r - Eversong Woods
#chapters a) The Light's Summons (A);a) Whispers in the Twilight (A);a) Shadowfall (A);a) Ripple Effects (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#groupweight 999
#name a) The Light's Summons (A)
#displayname |cFF00CCFF1|r - The Light's Summons
#next a) Whispers in the Twilight (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Light's Summons
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Whispers in the Twilight (A)
#displayname |cFF00CCFF2|r - Whispers in the Twilight
#next a) Shadowfall (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Whispers in the Twilight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shadowfall (A)
#displayname |cFF00CCFF3|r - Shadowfall
#next a) Ripple Effects (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Shadowfall
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Ripple Effects (A)
#displayname |cFF00CCFF4|r - Ripple Effects
#next a) The Path of Light (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Ripple Effects
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ab) Arator's Journey(A)
#displayname |cFF00FF002|r - Arator's Journey
#chapters a) The Path of Light (A);a) Regrets of the Past (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Path of Light (A)
#displayname |cFF00CCFF1|r - The Path of Light
#next a) Regrets of the Past (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Path of Light
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Regrets of the Past (A)
#displayname |cFF00CCFF2|r - Regrets of the Past
#next a) Of Caves and Cradles (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Regrets of the Past
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ac) Harandar Campaign (A)
#displayname |cFF00FF003|r - Harandar
#chapters a) Of Caves and Cradles (A);a) Call of the Goddess (A);a) Emergence (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Of Caves and Cradles (A)
#displayname |cFF00CCFF1|r - Of Caves and Cradles
#next a) Call of the Goddess (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Of Caves and Cradles
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Call of the Goddess (A)
#displayname |cFF00CCFF2|r - Call of the Goddess
#next a) Emergence (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Call of the Goddess
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Emergence (A)
#displayname |cFF00CCFF3|r - Emergence
#next a) Dis Was Our Land (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Emergence
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ad) Zul'aman Campaign(A)
#displayname |cFF00FF004|r - Zul'Aman
#chapters a) Dis Was Our Land (A);a) Path of de Hash'ey (A);a) Where War Slumbers (A);a) De Amani Never Die (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Dis Was Our Land (A)
#displayname |cFF00CCFF1|r - Dis Was Our Land
#next a) Path of de Hash'ey (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Dis Was Our Land
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Path of de Hash'ey (A)
#displayname |cFF00CCFF2|r - Path of de Hash'ey
#next a) Where War Slumbers (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Path of de Hash'ey
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Where War Slumbers (A)
#displayname |cFF00CCFF3|r - Where War Slumbers
#next a) De Amani Never Die (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Where War Slumbers
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) De Amani Never Die (A)
#displayname |cFF00CCFF4|r - De Amani Never Die
#next a) Darkening Sky (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) De Amani Never Die
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Darkening Sky (A)
#displayname |cFF00CCFF1|r - Darkening Sky
#next a) Into the Abyss (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Darkening Sky
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ae) Voidstorm Campaign(A)
#displayname |cFF00FF005|r - Voidstorm
#chapters a) Darkening Sky (A);a) Into the Abyss (A);a) The Night's Veil (A);a) Dawn of Reckoning (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Into the Abyss (A)
#displayname |cFF00CCFF2|r - Into the Abyss
#next a) The Night's Veil (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Into the Abyss
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Night's Veil (A)
#displayname |cFF00CCFF3|r - The Night's Veil
#next a) Dawn of Reckoning (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Night's Veil
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Dawn of Reckoning (A)
#displayname |cFF00CCFF4|r - Dawn of Reckoning
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Dawn of Reckoning
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Storylines
#subweight 993
#name a) Eversong Woods Storylines (A)
#displayname |cFF00FF001|r - Eversong Woods Sojourner
#chapters a) The Drinking Debt (A);a) Fear and Fel (A);a) Lesser Evil (A);a) Tailor Troubles (A);a) Scootin' Through Silvermoon (A);a) How to Train Your Protege (A);a) Aspiring Academic (A);a) One Adventurous Hatchling (A);a) Far Striding (A);a) Runestone Rumbles (A);a) Theft Tracking (A);a) Port Detective (A);a) Daggerspine Landing (A);a) Flowers for Amalthea (A);a) Sunbath, Take Me Away (A);a) Blinding Sun (A);a) Paladin Rescue (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Drinking Debt (A)
#displayname |cFF00CCFF1|r - The Drinking Debt
#next a) Fear and Fel (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Drinking Debt
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Fear and Fel (A)
#displayname |cFF00CCFF2|r - Fear and Fel
#next a) Lesser Evil (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Fear and Fel
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Lesser Evil (A)
#displayname |cFF00CCFF3|r - Lesser Evil
#next a) Tailor Troubles (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Lesser Evil
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Tailor Troubles (A)
#displayname |cFF00CCFF4|r - Tailor Troubles
#next a) Scootin' Through Silvermoon (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Tailor Troubles
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Scootin' Through Silvermoon (A)
#displayname |cFF00CCFF5|r - Scootin' Through Silvermoon
#next a) How to Train Your Protege (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Scootin' Through Silvermoon
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) How to Train Your Protege (A)
#displayname |cFF00CCFF6|r - How to Train Your Protege
#next a) Aspiring Academic (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) How to Train Your Protege
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Aspiring Academic (A)
#displayname |cFF00CCFF7|r - Aspiring Academic
#next a) One Adventurous Hatchling (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Aspiring Academic
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) One Adventurous Hatchling (A)
#displayname |cFF00CCFF8|r - One Adventurous Hatchling
#next a) Far Striding (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) One Adventurous Hatchling
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Far Striding (A)
#displayname |cFF00CCFF9|r - Far Striding
#next a) Runestone Rumbles (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Far Striding
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Runestone Rumbles (A)
#displayname |cFF00CCFF10|r - Runestone Rumbles
#next a) Theft Tracking (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Runestone Rumbles
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Theft Tracking (A)
#displayname |cFF00CCFF11|r - Theft Tracking
#next a) Port Detective (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Theft Tracking
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Port Detective (A)
#displayname |cFF00CCFF12|r - Port Detective
#next a) Daggerspine Landing (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Port Detective
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Daggerspine Landing (A)
#displayname |cFF00CCFF13|r - Daggerspine Landing
#next a) Flowers for Amalthea (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Daggerspine Landing
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Flowers for Amalthea (A)
#displayname |cFF00CCFF14|r - Flowers for Amalthea
#next a) Sunbath, Take Me Away (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Flowers for Amalthea
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Sunbath, Take Me Away (A)
#displayname |cFF00CCFF15|r - Sunbath, Take Me Away
#next a) Blinding Sun (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Sunbath, Take Me Away
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Blinding Sun (A)
#displayname |cFF00CCFF16|r - Blinding Sun
#next a) Paladin Rescue (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Blinding Sun
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Paladin Rescue (A)
#displayname |cFF00CCFF17|r - Paladin Rescue |cFFFCDC00(90)|r
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Paladin Rescue
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Storylines
#name ab) Zul'aman Storylines (A)
#displayname |cFF00FF002|r - Zul'Aman Sojourner
#chapters a) Bitter Honor (A);a) Sawdust to Sawdust (A);a) A Venomous History (A);a) The Sound of Her Voice (A);a) Unlikely Friends (A);a) The Loa of Murlocs (A);a) Vengeance for Tolbani (A);a) Between Two Trolls (A);a) Healing the Spirit (A);a) Beyond the Walls (A);a) No Fear (A);a) Sorrowing Kin (A);a) River-Walkers of the Prowl (A);a) The Voice of Nalorakk (A);a) Reclaiming de Honor (A);a) Bloodstains (A);a) Something Vile This Way Comes (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bitter Honor (A)
#displayname |cFF00CCFF1|r - Bitter Honor
#next a) Sawdust to Sawdust (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Bitter Honor
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Sawdust to Sawdust (A)
#displayname |cFF00CCFF2|r - Sawdust to Sawdust
#next a) A Venomous History (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Sawdust to Sawdust
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Venomous History (A)
#displayname |cFF00CCFF3|r - A Venomous History
#next a) The Sound of Her Voice (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Venomous History
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Sound of Her Voice (A)
#displayname |cFF00CCFF4|r - The Sound of Her Voice
#next a) Unlikely Friends (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Sound of Her Voice
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Unlikely Friends (A)
#displayname |cFF00CCFF5|r - Unlikely Friends
#next a) The Loa of Murlocs (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Unlikely Friends
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Loa of Murlocs (A)
#displayname |cFF00CCFF6|r - The Loa of Murlocs
#next a) Vengeance for Tolbani (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Loa of Murlocs
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Vengeance for Tolbani (A)
#displayname |cFF00CCFF7|r - Vengeance for Tolbani
#next a) Between Two Trolls (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Vengeance for Tolbani
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Between Two Trolls (A)
#displayname |cFF00CCFF8|r - Between Two Trolls
#next a) Healing the Spirit (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Between Two Trolls
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Healing the Spirit (A)
#displayname |cFF00CCFF9|r - Healing the Spirit
#next a) Beyond the Walls (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Healing the Spirit
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Beyond the Walls (A)
#displayname |cFF00CCFF10|r - Beyond the Walls
#next a) No Fear (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Beyond the Walls
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) No Fear (A)
#displayname |cFF00CCFF11|r - No Fear
#next a) Sorrowing Kin (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) No Fear
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Sorrowing Kin (A)
#displayname |cFF00CCFF12|r - Sorrowing Kin
#next a) River-Walkers of the Prowl (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Sorrowing Kin
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) River-Walkers of the Prowl (A)
#displayname |cFF00CCFF13|r - River-Walkers of the Prowl
#next a) The Voice of Nalorakk (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) River-Walkers of the Prowl
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Voice of Nalorakk (A)
#displayname |cFF00CCFF14|r - The Voice of Nalorakk
#next a) Reclaiming de Honor (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Voice of Nalorakk
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Reclaiming de Honor (A)
#displayname |cFF00CCFF15|r - Reclaiming de Honor
#next a) Bloodstains (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Reclaiming de Honor
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bloodstains (A)
#displayname |cFF00CCFF16|r - Bloodstains
#next a) Something Vile This Way Comes (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Bloodstains
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Something Vile This Way Comes (A)
#displayname |cFF00CCFF17|r - Something Vile This Way Comes |cFFFCDC00(90)|r
#next a) A Goblin in Harandar (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Something Vile This Way Comes
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Storylines
#name ac) Harandar Storylines (A)
#displayname |cFF00FF003|r - Harandar Sojourner
#chapters a) A Goblin in Harandar (A);a) The Legend of Aln'sharan (A);a) Late Bloomers (A);a) The Greenspeaker's Vigil (A);a) Peril Among Petals (A);a) Haranir Never Say Die (A);a) Harandar's Kitchen (A);a) Silence at Fungara Village (A);a) Cultivating Hope (A);a) Hunter's Rights (A);a) A Palette of Feelings (A);a) Predator Reintroduction (A);a) Bloomtown (A);a) The Grudge Pit 2 (A);a) Trials of the Shul'ka (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Goblin in Harandar (A)
#displayname |cFF00CCFF1|r - A Goblin in Harandar
#next a) The Legend of Aln'sharan (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Goblin in Harandar
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Legend of Aln'sharan (A)
#displayname |cFF00CCFF2|r - The Legend of Aln'sharan
#next a) Late Bloomers (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Legend of Aln'sharan
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Late Bloomers (A)
#displayname |cFF00CCFF3|r - Late Bloomers
#next a) The Greenspeaker's Vigil (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Late Bloomers
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Greenspeaker's Vigil (A)
#displayname |cFF00CCFF4|r - The Greenspeaker's Vigil
#next a) Peril Among Petals (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Greenspeaker's Vigil
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Peril Among Petals (A)
#displayname |cFF00CCFF5|r - Peril Among Petals
#next a) Haranir Never Say Die (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Peril Among Petals
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Haranir Never Say Die (A)
#displayname |cFF00CCFF6|r - Haranir Never Say Die
#next a) Harandar's Kitchen (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Haranir Never Say Die
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Harandar's Kitchen (A)
#displayname |cFF00CCFF7|r - Harandar's Kitchen
#next a) Silence at Fungara Village (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Harandar's Kitchen
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Silence at Fungara Village (A)
#displayname |cFF00CCFF8|r - Silence at Fungara Village
#next a) Cultivating Hope (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Silence at Fungara Village
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Cultivating Hope (A)
#displayname |cFF00CCFF9|r - Cultivating Hope
#next a) Hunter's Rights (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Cultivating Hope
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Hunter's Rights (A)
#displayname |cFF00CCFF10|r - Hunter's Rights
#next a) A Palette of Feelings (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Hunter's Rights
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Palette of Feelings (A)
#displayname |cFF00CCFF11|r - A Palette of Feelings
#next a) Predator Reintroduction (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Palette of Feelings
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Predator Reintroduction (A)
#displayname |cFF00CCFF12|r - Predator Reintroduction
#next a) Bloomtown (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Predator Reintroduction
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bloomtown (A)
#displayname |cFF00CCFF13|r - Bloomtown
#next a) The Grudge Pit 2 (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Bloomtown
]])

