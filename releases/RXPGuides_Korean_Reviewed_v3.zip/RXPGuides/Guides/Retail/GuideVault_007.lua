if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) CEversong & Harandar Part 1 (A)
#displayname |cFFFCDC003|r - Eversong & Harandar Part 1
#next a) DEversong Woods Part 2 (A)
<< Alliance
step
#include a) Eversong & Harandar Part 1
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) DEversong Woods Part 2 (A)
#displayname |cFFFCDC004|r - Eversong Part 2
#next a) EHarandar & Eversong Part 2 (A)
<< Alliance
step
#include a) Eversong Woods Part 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) EHarandar & Eversong Part 2 (A)
#displayname |cFFFCDC005|r - Harandar & Eversong Part 2
#next a) FHarandar Part 3 & Eversong Woods (A)
<< Alliance
step
#include a) Harandar & Eversong Part 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) FHarandar Part 3 & Eversong Woods (A)
#displayname |cFFFCDC006|r - Harandar & Eversong Part 3
#next a) GZul'aman Part 1 (A)
<< Alliance
step
#include a) Harandar Part 3 & Eversong Woods
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) GZul'aman Part 1 (A)
#displayname |cFFFCDC007|r - Zul'aman Part 1
#next a) HZul'aman Part 2 & Arathor (A)
<< Alliance
step
#include a) Zul'aman Part 1
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) HZul'aman Part 2 & Arathor (A)
#displayname |cFFFCDC008|r - Zul'aman Part 2 & Arathor
#next a) Foothold (A)
<< Alliance
step
#include a) Zul'aman Part 2 & Arathor
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup Treasures & Renown
#subweight 991
#name a) Lore Hunter (A)
#displayname Renown Treasures Worldtour
<< Alliance
step
#include RestedXP Midnight\a) Lore Hunter
]])

RXPGuides.RegisterGuide([[
#version 1
#retail
#group RestedXP Midnight
#subgroup Treasures & Renown
#name a) Skyriding Glyphs Worldtour (A)
#displayname Skyriding Glyphs Worldtour
<< Alliance
step
#include RestedXP Miscellaneous\a) Eversong Woods Glyphs
step
#include RestedXP Miscellaneous\a) Zul'aman Glyphs
step
#include RestedXP Miscellaneous\a) Harandar Glyphs
step
#include RestedXP Miscellaneous\a) Voidstorm Glyphs
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Treasures & Renown
#name a) Profession Knowledge Worldtour (A)
#displayname Profession Knowledge Worldtour
<< Alliance
step
#include RestedXP Miscellaneous\a) Eversong Woods Knowledge
step
#include RestedXP Miscellaneous\a) Zul'aman Knowledge
step
#include RestedXP Miscellaneous\a) Harandar Knowledge
step
#include RestedXP Miscellaneous\a) Voidstorm Knowledge
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) ARitual Sites (A)
#displayname Ritual Sites
<< Alliance
step
#include a) Ritual Sites
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-84)|r Delves Worldtour
#subweight 994.999
#name a) Delves Worldtour (A)
#displayname Just Delve Quests
<< Alliance
step
#completewith next
+This guide is for players wanting to do a delve worldtour.
*|cRXP_WARN_NOTE:|r This guide requires you to have unlocked the adventure mode or at least access to all zones.
step
#include RestedXP Midnight\a) The Light's Summons@TheLightsSummonsA-TheLightsSummonsB
step
#include RestedXP Midnight\a) Eversong Woods Route Delve Worldtour
step
#include RestedXP Midnight\a) Zul'Aman Route Delve Worldtour
step
#include RestedXP Midnight\a) Harandar Route Delve Worldtour
step
#include RestedXP Midnight\a) Voidstorm Route Delve Worldtour
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Isle of Quel'danas Delves (A)
#displayname Isle of Quel'Danas
#chapters a) Parhelion Plaza (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Parhelion Plaza (A)
#displayname Parhelion Plaza
#next a) The Darkway (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Parhelion Plaza
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#subweight 990
#name ab) Eversong Forest Delves (A)
#displayname Eversong Forest
#chapters a) The Shadow Enclave (A);a) Collegiate Calamity (A);a) The Darkway (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Shadow Enclave (A)
#displayname The Shadow Enclave
#next a) Collegiate Calamity (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Shadow Enclave
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Collegiate Calamity (A)
#displayname Collegiate Calamity
#next a) The Darkway (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Collegiate Calamity
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Darkway (A)
#displayname The Darkway
#next a) The Shadow Enclave (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Darkway
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name ac) Zul'aman Delves
#displayname Zul'Aman
#chapters a) Twilight Crypts (A);a) Atal’Aman (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Twilight Crypts (A)
#displayname Twilight Crypts
#next a) Atal’Aman (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Twilight Crypts
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Atal’Aman (A)
#displayname Atal’Aman
#next a) Twilight Crypts (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Atal'Aman
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name ad) Harandar Delves
#displayname Harandar
#chapters a) The Grudge Pit (A);a) The Gulf of Memory (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Grudge Pit (A)
#displayname The Grudge Pit
#next a) The Gulf of Memory (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Grudge Pit
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Gulf of Memory (A)
#displayname The Gulf of Memory
#next a) The Grudge Pit (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Gulf of Memory
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name ae) Voidstorm Delves (A)
#displayname Voidstorm
#chapters a) Sunkiller Sanctum (A);a) Shadowguard Point (A);a) Torment’s Rise (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Sunkiller Sanctum (A)
#displayname Sunkiller Sanctum
#next a) Shadowguard Point (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Sunkiller Sanctum
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Shadowguard Point (A)
#displayname Shadowguard Point
#next a) Sunkiller Sanctum (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Shadowguard Point
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name af) The Coiled Isle Delves (A)
#displayname The Coiled Isle
#chapters a) The Ring of Glory (A);a) Gnarldor Isle (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Ring of Glory (A)
#displayname The Ring of Glory
#next a) Gnarldor Isle (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Ring of Glory
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Gnarldor Isle (A)
#displayname Gnarldor Isle
#next a) The Ring of Glory (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Gnarldor Isle
]])

RXPGuides.RegisterGuide([[
#retail
#version 22
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name a) Eversong Woods Campaign (H)
#displayname |cFF00FF001|r - Eversong Woods
#chapters a) The Light's Summons (H);a) Whispers in the Twilight (H);a) Shadowfall (H);a) Ripple Effects (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#groupweight 999
#name a) The Light's Summons (H)
#displayname |cFF00CCFF1|r - The Light's Summons
#next a) Whispers in the Twilight (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Light's Summons
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Whispers in the Twilight (H)
#displayname |cFF00CCFF2|r - Whispers in the Twilight
#next a) Shadowfall (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Whispers in the Twilight
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Shadowfall (H)
#displayname |cFF00CCFF3|r - Shadowfall
#next a) Ripple Effects (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Shadowfall
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Ripple Effects (H)
#displayname |cFF00CCFF4|r - Ripple Effects
#next a) Regrets of the Past (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Ripple Effects
]])

RXPGuides.RegisterGuide([[
#retail
#version 22
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ab) Arator's Journey (H)
#displayname |cFF00FF002|r - Arator's Journey
#chapters a) The Path of Light (H);a) Regrets of the Past (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Path of Light (H)
#displayname |cFF00CCFF1|r - The Path of Light
#next a) Regrets of the Past (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Path of Light
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Regrets of the Past (H)
#displayname |cFF00CCFF2|r - Regrets of the Past
#next a) Of Caves and Cradles (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Regrets of the Past
]])

RXPGuides.RegisterGuide([[
#retail
#version 22
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ac) Harandar Campaign (H)
#displayname |cFF00FF003|r - Harandar
#chapters a) Of Caves and Cradles (H);a) Call of the Goddess (H);a) Emergence (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Of Caves and Cradles (H)
#displayname |cFF00CCFF1|r - Of Caves and Cradles
#next a) Call of the Goddess (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Of Caves and Cradles
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Call of the Goddess (H)
#displayname |cFF00CCFF2|r - Call of the Goddess
#next a) Emergence (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Call of the Goddess
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Emergence (H)
#displayname |cFF00CCFF3|r - Emergence
#next a) Dis Was Our Land (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Emergence
]])

RXPGuides.RegisterGuide([[
#retail
#version 22
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ad) Zul'aman Campaign (H)
#displayname |cFF00FF004|r - Zul'Aman
#chapters a) Dis Was Our Land (H);a) Path of de Hash'ey (H);a) Where War Slumbers (H);a) De Amani Never Die (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Dis Was Our Land (H)
#displayname |cFF00CCFF1|r - Dis Was Our Land
#next a) Path of de Hash'ey (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Dis Was Our Land
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Path of de Hash'ey (H)
#displayname |cFF00CCFF2|r - Path of de Hash'ey
#next a) Where War Slumbers (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Path of de Hash'ey
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Where War Slumbers (H)
#displayname |cFF00CCFF3|r - Where War Slumbers
#next a) De Amani Never Die (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Where War Slumbers
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) De Amani Never Die (H)
#displayname |cFF00CCFF4|r - De Amani Never Die
#next a) Darkening Sky (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) De Amani Never Die
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Darkening Sky (H)
#displayname |cFF00CCFF1|r - Darkening Sky
#next a) Into the Abyss (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Darkening Sky
]])

RXPGuides.RegisterGuide([[
#retail
#version 22
#group RestedXP Midnight
#subgroup Level-Up Campaigns
#subweight 994.5
#name ae) Voidstorm Campaign (H)
#displayname |cFF00FF005|r - Voidstorm
#chapters a) Darkening Sky (H);a) Into the Abyss (H);a) The Night's Veil (H);a) Dawn of Reckoning (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Into the Abyss (H)
#displayname |cFF00CCFF2|r - Into the Abyss
#next a) The Night's Veil (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Into the Abyss
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Night's Veil (H)
#displayname |cFF00CCFF3|r - The Night's Veil
#next a) Dawn of Reckoning (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Night's Veil
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Dawn of Reckoning (H)
#displayname |cFF00CCFF4|r - Dawn of Reckoning
#chapter
<< Horde
step
#include RestedXP Midnight\a) Dawn of Reckoning
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Storylines
#subweight 993
#name a) Eversong Woods Storylines (H)
#displayname |cFF00FF001|r - Eversong Woods
#chapters a) The Drinking Debt (H);a) Fear and Fel (H);a) Lesser Evil (H);a) Tailor Troubles (H);a) Scootin' Through Silvermoon (H);a) How to Train Your Protege (H);a) Aspiring Academic (H);a) One Adventurous Hatchling (H);a) Far Striding (H);a) Runestone Rumbles (H);a) Theft Tracking (H);a) Port Detective (H);a) Daggerspine Landing (H);a) Flowers for Amalthea (H);a) Sunbath, Take Me Away (H);a) Blinding Sun (H);a) Paladin Rescue (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Drinking Debt (H)
#displayname |cFF00CCFF1|r - The Drinking Debt
#next a) Fear and Fel (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Drinking Debt
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Fear and Fel (H)
#displayname |cFF00CCFF2|r - Fear and Fel
#next a) Lesser Evil (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Fear and Fel
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Lesser Evil (H)
#displayname |cFF00CCFF3|r - Lesser Evil
#next a) Tailor Troubles (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Lesser Evil
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Tailor Troubles (H)
#displayname |cFF00CCFF4|r - Tailor Troubles
#next a) Scootin' Through Silvermoon (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Tailor Troubles
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Scootin' Through Silvermoon (H)
#displayname |cFF00CCFF5|r - Scootin' Through Silvermoon
#next a) How to Train Your Protege (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Scootin' Through Silvermoon
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) How to Train Your Protege (H)
#displayname |cFF00CCFF6|r - How to Train Your Protege
#next a) Aspiring Academic (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) How to Train Your Protege
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Aspiring Academic (H)
#displayname |cFF00CCFF7|r - Aspiring Academic
#next a) One Adventurous Hatchling (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Aspiring Academic
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) One Adventurous Hatchling (H)
#displayname |cFF00CCFF8|r - One Adventurous Hatchling
#next a) Far Striding (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) One Adventurous Hatchling
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Far Striding (H)
#displayname |cFF00CCFF9|r - Far Striding
#next a) Runestone Rumbles (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Far Striding
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Runestone Rumbles (H)
#displayname |cFF00CCFF10|r - Runestone Rumbles
#next a) Theft Tracking (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Runestone Rumbles
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Theft Tracking (H)
#displayname |cFF00CCFF11|r - Theft Tracking
#next a) Port Detective (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Theft Tracking
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Port Detective (H)
#displayname |cFF00CCFF12|r - Port Detective
#next a) Daggerspine Landing (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Port Detective
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Daggerspine Landing (H)
#displayname |cFF00CCFF13|r - Daggerspine Landing
#next a) Flowers for Amalthea (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Daggerspine Landing
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Flowers for Amalthea (H)
#displayname |cFF00CCFF14|r - Flowers for Amalthea
#next a) Sunbath, Take Me Away (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Flowers for Amalthea
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Sunbath, Take Me Away (H)
#displayname |cFF00CCFF15|r - Sunbath, Take Me Away
#next a) Blinding Sun (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Sunbath, Take Me Away
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Blinding Sun (H)
#displayname |cFF00CCFF16|r - Blinding Sun
#next a) Paladin Rescue (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Blinding Sun
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Paladin Rescue (H)
#displayname |cFF00CCFF17|r - Paladin Rescue |cFFFCDC00(90)|r
#chapter
<< Horde
step
#include RestedXP Midnight\a) Paladin Rescue
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Storylines
#name ab) Zul'aman Storylines (H)
#displayname |cFF00FF002|r - Zul'Aman
#chapters a) Bitter Honor (H);a) Sawdust to Sawdust (H);a) A Venomous History (H);a) The Sound of Her Voice (H);a) Unlikely Friends (H);a) The Loa of Murlocs (H);a) Vengeance for Tolbani (H);a) Between Two Trolls (H);a) Healing the Spirit (H);a) Beyond the Walls (H);a) No Fear (H);a) Sorrowing Kin (H);a) River-Walkers of the Prowl (H);a) The Voice of Nalorakk (H);a) Reclaiming de Honor (H);a) Bloodstains (H);a) Something Vile This Way Comes (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Bitter Honor (H)
#displayname |cFF00CCFF1|r - Bitter Honor
#next a) Sawdust to Sawdust (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Bitter Honor
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Sawdust to Sawdust (H)
#displayname |cFF00CCFF2|r - Sawdust to Sawdust
#next a) A Venomous History (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Sawdust to Sawdust
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Venomous History (H)
#displayname |cFF00CCFF3|r - A Venomous History
#next a) The Sound of Her Voice (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Venomous History
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Sound of Her Voice (H)
#displayname |cFF00CCFF4|r - The Sound of Her Voice
#next a) Unlikely Friends (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Sound of Her Voice
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Unlikely Friends (H)
#displayname |cFF00CCFF5|r - Unlikely Friends
#next a) The Loa of Murlocs (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Unlikely Friends
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Loa of Murlocs (H)
#displayname |cFF00CCFF6|r - The Loa of Murlocs
#next a) Vengeance for Tolbani (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Loa of Murlocs
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Vengeance for Tolbani (H)
#displayname |cFF00CCFF7|r - Vengeance for Tolbani
#next a) Between Two Trolls (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Vengeance for Tolbani
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Between Two Trolls (H)
#displayname |cFF00CCFF8|r - Between Two Trolls
#next a) Healing the Spirit (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Between Two Trolls
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Healing the Spirit (H)
#displayname |cFF00CCFF9|r - Healing the Spirit
#next a) Beyond the Walls (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Healing the Spirit
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Beyond the Walls (H)
#displayname |cFF00CCFF10|r - Beyond the Walls
#next a) No Fear (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Beyond the Walls
]])

