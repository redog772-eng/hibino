if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) No Fear (H)
#displayname |cFF00CCFF11|r - No Fear
#next a) Sorrowing Kin (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) No Fear
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Sorrowing Kin (H)
#displayname |cFF00CCFF12|r - Sorrowing Kin
#next a) River-Walkers of the Prowl (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Sorrowing Kin
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) River-Walkers of the Prowl (H)
#displayname |cFF00CCFF13|r - River-Walkers of the Prowl
#next a) The Voice of Nalorakk (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) River-Walkers of the Prowl
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Voice of Nalorakk (H)
#displayname |cFF00CCFF14|r - The Voice of Nalorakk
#next a) Reclaiming de Honor (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Voice of Nalorakk
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Reclaiming de Honor (H)
#displayname |cFF00CCFF15|r - Reclaiming de Honor
#next a) Bloodstains (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Reclaiming de Honor
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Bloodstains (H)
#displayname |cFF00CCFF16|r - Bloodstains
#next a) Something Vile This Way Comes (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Bloodstains
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Something Vile This Way Comes (H)
#displayname |cFF00CCFF17|r - Something Vile This Way Comes |cFFFCDC00(90)|r
#next a) A Goblin in Harandar (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Something Vile This Way Comes
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Storylines
#name ac) Harandar Storylines (H)
#displayname |cFF00FF003|r - Harandar
#chapters a) A Goblin in Harandar (H);a) The Legend of Aln'sharan (H);a) Late Bloomers (H);a) The Greenspeaker's Vigil (H);a) Peril Among Petals (H);a) Haranir Never Say Die (H);a) Harandar's Kitchen (H);a) Silence at Fungara Village (H);a) Cultivating Hope (H);a) Hunter's Rights (H);a) A Palette of Feelings (H);a) Predator Reintroduction (H);a) Bloomtown (H);a) The Grudge Pit 2 (H);a) Trials of the Shul'ka (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Goblin in Harandar (H)
#displayname |cFF00CCFF1|r - A Goblin in Harandar
#next a) The Legend of Aln'sharan (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Goblin in Harandar
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Legend of Aln'sharan (H)
#displayname |cFF00CCFF2|r - The Legend of Aln'sharan
#next a) Late Bloomers (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Legend of Aln'sharan
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Late Bloomers (H)
#displayname |cFF00CCFF3|r - Late Bloomers
#next a) The Greenspeaker's Vigil (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Late Bloomers
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Greenspeaker's Vigil (H)
#displayname |cFF00CCFF4|r - The Greenspeaker's Vigil
#next a) Peril Among Petals (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Greenspeaker's Vigil
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Peril Among Petals (H)
#displayname |cFF00CCFF5|r - Peril Among Petals
#next a) Haranir Never Say Die (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Peril Among Petals
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Haranir Never Say Die (H)
#displayname |cFF00CCFF6|r - Haranir Never Say Die
#next a) Harandar's Kitchen (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Haranir Never Say Die
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Harandar's Kitchen (H)
#displayname |cFF00CCFF7|r - Harandar's Kitchen
#next a) Silence at Fungara Village (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Harandar's Kitchen
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Silence at Fungara Village (H)
#displayname |cFF00CCFF8|r - Silence at Fungara Village
#next a) Cultivating Hope (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Silence at Fungara Village
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Cultivating Hope (H)
#displayname |cFF00CCFF9|r - Cultivating Hope
#next a) Hunter's Rights (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Cultivating Hope
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Hunter's Rights (H)
#displayname |cFF00CCFF10|r - Hunter's Rights
#next a) A Palette of Feelings (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Hunter's Rights
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Palette of Feelings (H)
#displayname |cFF00CCFF11|r - A Palette of Feelings
#next a) Predator Reintroduction (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Palette of Feelings
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Predator Reintroduction (H)
#displayname |cFF00CCFF12|r - Predator Reintroduction
#next a) Bloomtown (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Predator Reintroduction
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Bloomtown (H)
#displayname |cFF00CCFF13|r - Bloomtown
#next a) The Grudge Pit 2 (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Bloomtown
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Grudge Pit 2 (H)
#displayname |cFF00CCFF14|r - The Grudge Pit
#next a) Trials of the Shul'ka (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Grudge Pit 2
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Trials of the Shul'ka (H)
#displayname |cFF00CCFF15|r - Trials of the Shul'ka
#next a) Trials of the Shul'ka (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Trials of the Shul'ka
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Storylines
#name ada) Voidstorm Storylines (H)
#displayname |cFF00FF004|r - Voidstorm
#chapters a) The Void Peers Back (H);a) Shadow Puppets (H);a) The Nethersent (H);a) The Nightbreaker (H);a) Pathogenic Problem (H);a) A Voice Inside (H);a) Shadowguard's Shadow (H);a) A Gift, Given Freely (H);a) Breaking the Triad (H);a) Go Low, Go Loud (H);a) Secrets in the Dark (H);a) Oaths to Family (H);a) To Be Changed (H);a) A Dance with the Devil (H);a) A Domanaar's Best Friend (H);a) A More Potent Foe (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Void Peers Back (H)
#displayname |cFF00CCFF1|r - The Void Peers Back
#next a) Shadow Puppets (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Void Peers Back
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shadow Puppets (H)
#displayname |cFF00CCFF2|r - Shadow Puppets
#next a) The Nethersent (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Shadow Puppets
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Nethersent (H)
#displayname |cFF00CCFF3|r - The Nethersent
#next a) The Nightbreaker (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Nethersent
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Nightbreaker (H)
#displayname |cFF00CCFF4|r - The Nightbreaker
#next a) Pathogenic Problem (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Nightbreaker
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Pathogenic Problem (H)
#displayname |cFF00CCFF5|r - Pathogenic Problem
#next a) A Voice Inside (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Pathogenic Problem
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Voice Inside (H)
#displayname |cFF00CCFF6|r - A Voice Inside
#next a) Shadowguard's Shadow (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Voice Inside
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shadowguard's Shadow (H)
#displayname |cFF00CCFF7|r - Shadowguard's Shadow
#next a) A Gift, Given Freely (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Shadowguard's Shadow
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Gift, Given Freely (H)
#displayname |cFF00CCFF8|r - A Gift, Given Freely
#next a) Breaking the Triad (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Gift, Given Freely
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Breaking the Triad (H)
#displayname |cFF00CCFF9|r - Breaking the Triad
#next a) Go Low, Go Loud (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Breaking the Triad
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Go Low, Go Loud (H)
#displayname |cFF00CCFF10|r - Go Low, Go Loud
#next a) Secrets in the Dark (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Go Low, Go Loud
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Secrets in the Dark (H)
#displayname |cFF00CCFF11|r - Secrets in the Dark
#next a) Oaths to Family (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Secrets in the Dark
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Oaths to Family (H)
#displayname |cFF00CCFF12|r - Oaths to Family
#next a) To Be Changed (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Oaths to Family
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) To Be Changed (H)
#displayname |cFF00CCFF13|r - To Be Changed
#next a) A Dance with the Devil (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) To Be Changed
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Dance with the Devil (H)
#displayname |cFF00CCFF14|r - A Dance with the Devil
#next a) A Domanaar's Best Friend (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Dance with the Devil
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Domanaar's Best Friend (H)
#displayname |cFF00CCFF15|r - A Domanaar's Best Friend
#next a) A More Potent Foe (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Domanaar's Best Friend
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A More Potent Foe (H)
#displayname |cFF00CCFF16|r - A More Potent Foe |cFFFCDC00(90)|r
#chapter
<< Horde
step
#include RestedXP Midnight\a) A More Potent Foe
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Storylines
#subweight 993.5
#name ae) Crimson Rogue (H)
#displayname The Crimson Rogue
#chapters a) The Regent's Request (H); a) A Favor for the Lion (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Regent's Request (H)
#displayname |cFF00CCFF1|r - The Regent's Request |cFFFCDC00(80+)|r
#next a) A Favor for the Lion (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Regent's Request
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Favor for the Lion (H)
#displayname |cFF00CCFF2|r - A Favor for the Lion |cFFFCDC00(90)|r
#chapter
<< Horde
step
#include RestedXP Midnight\a) A Favor for the Lion
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name af) Old Soldiers (H)
#subgroup Storylines
#displayname Old Soldiers
<< Horde
step
#include a) Old Soldiers
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Storylines
#name ag) Legends Never Die & The Empty Cradle (H)
#displayname Legends Never Die & The Empty Cradle
<< Horde
step
#include RestedXP Midnight\a) Legends Never Die & The Empty Cradle
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Pre-Turnins
#subweight 1000.5
#name a) 1Pre-Turnins Booklet (H)
#displayname Pre-Turnins Booklet|cRXP_WARN_(READ)|r
<< Horde
step
#include a) Pre-Turnins Booklet
step
+Select next guide
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Pre-Turnins
#name a) 2Turnin Route Horde (H)
#displayname Miscellaneous Turnins
<< Horde
step
#include a) Turnin Route Horde
step
+Select next guide
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Pre-Turnins
#name a) 4PoP-UP Quests Turnins (H)
#displayname First Crafts & Global Turnins
<< Horde
step
#include a) PoP-UP Quests Turnins
step
+Select next guide
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name c) Turnin Route Horde (H)
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route (H)
<< Horde
step
#include a) Turnin Route Horde
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name caa) Midnight Intro Route (H)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route (H)
<< Horde
step
#completewith TheLightsSummonsB
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#subweight 1000
#name cab) Eversong Woods Route (H)
#displayname |cFFFCDC002|r - Eversong Woods 1
#next cac) Eversong Woods Route (H) 2
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Eversong Woods Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#subweight 1000
#name cac) Eversong Woods Route (H) 2
#displayname |cFFFCDC003|r - Eversong Woods 2
#next cb) Arator Route (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Eversong Woods Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cb) Arator Route (H)
#displayname |cFFFCDC004|r - Arator
#next cca) Harandar Route (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Arator Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cca) Harandar Route (H)
#displayname |cFFFCDC005|r - Harandar 1
#next ccb) Harandar Route (H) 2
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Harandar Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name ccb) Harandar Route (H) 2
#displayname |cFFFCDC006|r - Harandar 2
#next cd) Zul'Aman Route (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Harandar Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cd) Zul'Aman Route (H)
#displayname |cFFFCDC007|r - Zul'Aman
#next ce) Voidstorm Route (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Zul'Aman Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name ce) Voidstorm Route (H)
#displayname |cFFFCDC008|r - Voidstorm Part 1
#next cf) Voidstorm Route (H) 2
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Voidstorm Route 1
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cf) Voidstorm Route (H) 2
#displayname |cFFFCDC009|r - Voidstorm Part 2
#next RestedXP Midnight\a) 90 Unlocking Systems (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Voidstorm Route 2
step
+If you're still not 90 then you can do your first crafts (in your crafting professions) now if you haven't done them already. Otherwise start the Adventure Mode guide or follow the next guide (by completing this step) to unlock the endgame systems.
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name c) Turnin Route Horde 2 (H)
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 2 (H)
<< Horde
step
#include RestedXP Midnight\a) Turnin Route Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name caa) Midnight Intro Route 2 (H)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 2 (H)
<< Horde
step
#completewith TheLightsSummonsB
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cab) Eversong Woods Route 2 (H)
#displayname |cFFFCDC002|r - Eversong Woods
#next cac) Eversong Woods Route 2 (H) 2
<< Horde
step
#completewith Recruit Lothraxion
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Eversong Woods Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cac) Eversong Woods Route 2 (H) 2
#displayname |cFFFCDC003|r - Eversong Woods 2
#next cb) Arator Route 2 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Eversong Woods Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cb) Arator Route 2 (H)
#displayname |cFFFCDC004|r - Arator
#next cca) Harandar Route 2 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Arator Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cca) Harandar Route 2 (H)
#displayname |cFFFCDC005|r - Harandar
#next ccb) Harandar Route 2 (H) 2
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Harandar Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name ccb) Harandar Route 2 (H) 2
#displayname |cFFFCDC006|r - Harandar
#next cd) Zul'Aman Route 2 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Harandar Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cd) Zul'Aman Route 2 (H)
#displayname |cFFFCDC007|r - Zul'Aman
#next ce) Voidstorm Route 2 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Zul'Aman Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name ce) Voidstorm Route 2 (H)
#displayname |cFFFCDC008|r - Voidstorm Part 1
#next cf) Voidstorm Route 2 (H) 2
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Voidstorm Route 1
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cf) Voidstorm Route 2 (H) 2
#displayname |cFFFCDC009|r - Voidstorm Part 2
#next RestedXP Midnight\a) 90 Unlocking Systems (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include RestedXP Midnight\a) Voidstorm Route 2
step
+If you're still not 90 then you can do your first crafts (in your crafting professions) now if you haven't done them already. Otherwise start the Adventure Mode guide or follow the next guide (by completing this step) to unlock the endgame systems.
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Turnin Route Horde 3 (H)
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 3 (H)
<< Horde
step
#include a) Turnin Route Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name caa) Midnight Intro Route 3 (H)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 3 (H)
<< Horde
step
#completewith TheLightsSummonsB
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#subweight 999
#name cab) Eversong Woods Route 3 (H)
#displayname |cFFFCDC002|r - Eversong Woods 1
#next cac) Eversong Woods Route 3 (H) 2
<< Horde
step
#completewith Recruit Lothraxion
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Eversong Woods Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#subweight 999
#name cac) Eversong Woods Route 3 (H) 2
#displayname |cFFFCDC003|r - Eversong Woods 2
#next cb) Arator Route 3 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Eversong Woods Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cb) Arator Route 3 (H)
#displayname |cFFFCDC004|r - Arator
#next cca) Harandar Route 3 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Arator Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cca) Harandar Route 3 (H)
#displayname |cFFFCDC005|r - Harandar 1
#next ccb) Harandar Route 3 (H) 2
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Harandar Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name ccb) Harandar Route 3 (H) 2
#displayname |cFFFCDC006|r - Harandar 2
#next cd) Zul'Aman Route 3 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Harandar Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cd) Zul'Aman Route 3 (H)
#displayname |cFFFCDC007|r - Zul'Aman
#next ce) Voidstorm Route 3 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Zul'Aman Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name ce) Voidstorm Route 3 (H)
#displayname |cFFFCDC008|r - Voidstorm Part 1
#next cf) Voidstorm Route 3 (H) 2
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Voidstorm Route 1
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cf) Voidstorm Route 3 (H) 2
#displayname |cFFFCDC009|r - Voidstorm Part 2
#next RestedXP Midnight\a) 90 Unlocking Systems (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Voidstorm Route 2
step
+If you're still not 90 then you can do your first crafts (in your crafting professions) now if you haven't done them already. Otherwise start the Adventure Mode guide or follow the next guide (by completing this step) to unlock the endgame systems.
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Turnin Route Horde 4 (H)
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 4 (H)
<< Horde
step
#include a) Turnin Route Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name caa) Midnight Intro Route 5 (H)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 5 (H)
<< Horde
step
#completewith TheLightsSummonsB
+This guide is for players who want to finish the campaign, complete Delve quests, and level quickly to 90.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

