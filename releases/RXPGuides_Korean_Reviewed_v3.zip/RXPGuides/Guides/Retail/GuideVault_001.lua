if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Val'sharah Intro Midnight
#internal
step
.goto 641,54.69,72.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r
.accept 40122 >>Accept Cenarius, Keeper of the Grove
.target Malfurion Stormrage
step
#label ValsharahIntroA
.goto 641,54.69,72.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion|r
.complete 40122,1 
.timer 59,Malfurion Roleplay
.target Malfurion
.skipgossipid 44675
step
#label ValsharahIntroY
.goto 641,51.91,64.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r
.turnin 40122 >>Turn in Cenarius, Keeper of the Grove
.accept 38384 >>Accept Nature's Call
.target Malfurion Stormrage
step
#label ValsharahIntroZ
.goto 641,54.37,73.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aranelle|r in |cRXP_WARN_Lorlathil|r.
.turnin 38384 >>Turn in Nature's Call
.accept 38142 >>Accept Archdruid of the Claw
.accept 44106 >>Accept Archdruid of Lore << Druid
.accept 38381 >>Accept Archdruid of Lore << !Druid
.accept 38382 >>Accept Archdruid of the Vale
.target Aranelle
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Archdruid of Lore Midnight
#internal
step
#label ArchdruidofLoreA
.goto 641,54.37,73.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aranelle|r in |cRXP_WARN_Lorlathil|r.
.accept 44106 >>Accept Archdruid of Lore << Druid
.accept 38381 >>Accept Archdruid of Lore << !Druid
.target Aranelle
step
#label ArchdruidofLoreB
.goto 641,48.86,70.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elothir|r.
.turnin 44106 >>Turn in Archdruid of Lore << Druid
.turnin 38381 >>Turn in Archdruid of Lore << !Druid
.accept 38225 >>Accept Death to the Witchmother
.accept 38235 >>Accept Solid as a Rock
.target Elothir
step
#completewith next
#label Marnor Lorleaf
#hidewindow
.complete 38235,1 
.target Marnor Lorleaf
step
#completewith Marnor Lorleaf
.goto 641,43.80,70.19
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Marnor Lorleaf|r.
step
#requires Marnor Lorleaf
#completewith next
#label Sagewood
#hidewindow
.complete 38235,3 
.target Del'thanar Sagewood
step
#requires Marnor Lorleaf
#completewith Sagewood
.goto 641,43.80,75.30
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Del'thanar Sagewood|r.
step
#requires Sagewood
#label Magula
#completewith next
#title |cFFFCDC00Enter Cave|r
.goto 641,45.47,76.99,15,0
>>Kill |cRXP_ENEMY_Magula|r |cRXP_WARN_inside the cave|r.
*|cRXP_WARN_Jump to remove|r |T136093:0|t[Stoneblood Poison].
.complete 38225,1 
.mob Magula
step
#requires Sagewood
#completewith Magula
.goto 641,45.79,77.85,50 >>Enter the Cave
step
#requires Magula
.goto 641,45.79,77.85
>>Kill |cRXP_ENEMY_Magula|r |cRXP_WARN_inside the cave|r.
*|cRXP_WARN_Jump to remove|r |T136093:0|t[Stoneblood Poison].
.complete 38225,1 
.mob Magula
step
#completewith next
#label Erwind Mistfen
#hidewindow
.goto 641,45.57,77,15,0
.complete 38235,2 
step
#completewith Erwind Mistfen
.goto 641,46.71,76.4
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Erwind Mistfen|r.
.target Erwind Mistfen
step
#requires Erwind Mistfen
.goto 641,48.85,70.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elothir|r.
.turnin 38225 >>Turn in Death to the Witchmother
.turnin 38235 >>Turn in Solid as a Rock
.target Elothir
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Archdruid of the Claw Midnight
#internal
step
#label ArchdruidOfTheClawA
.goto 641,49.08,82.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rylissa Bearsong|r.
.turnin 38142 >>Turn in Archdruid of the Claw
.accept 38455 >>Accept Frenzied Furbolgs
.target Rylissa Bearsong
step
.goto 641,48.40,84.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Sookh|r.
.accept 38922 >>Accept Littlefur
.target Elder Sookh
step
#completewith ArchdruidOfTheClawC
>>Kill |cRXP_ENEMY_Furbolgs|r.
.complete 38455,1 
.mob Smolderhide Warrior
.mob Smolderhide Hunter
.mob Smolderhide Chanter
step
.goto 641,46.26,84.55
#label ArchdruidOfTheClawB
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Littlefur|r.
.turnin 38922 >>Turn in Littlefur
.accept 38246 >>Accept Totemic Call
.target Littlefur
step
#completewith next
#label ArchdruidOfTheClawC
>>Kill |cRXP_ENEMY_Chieftain Graw|r.
*Loot him for |T133306:0|t[|cRXP_LOOT_Chieftain's Beads|r].
.collect 128340,1,38146,1
.accept 38146 >>Accept The Chieftain's Beads
.mob Chieftain Graw
step
.goto 641,48.83,88.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nightmare Totem|r.
.complete 38246,1 
step
>>Kill |cRXP_ENEMY_Chieftain Graw|r.
*Loot him for |T133306:0|t[|cRXP_LOOT_Chieftain's Beads|r].
.goto 641,48.83,88.55
.collect 128340,1,38146,1
.accept 38146 >>Accept The Chieftain's Beads
.mob Chieftain Graw
step
#loop
.goto 641,47.32,88.37,30,0
.goto 641,45.72,84.87,30,0
.goto 641,49.73,84.51,30,0
.goto 641,47.07,85.26,30,0
>>Kill |cRXP_ENEMY_Furbolgs|r.
.complete 38455,1 
.mob Smolderhide Warrior
.mob Smolderhide Hunter
.mob Smolderhide Chanter
step
#label ArchdruidOfTheClawD
.goto 641,48.40,84.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Sookh|r.
.turnin 38146 >>Turn in The Chieftain's Beads
.turnin 38246 >>Turn in Totemic Call
.target Elder Sookh
step
#label ArchdruidOfTheClawE
.goto 641,49.08,82.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rylissa Bearsong|r.
.turnin 38455 >>Turn in Frenzied Furbolgs
.accept 38143 >>Accept Awakening the Archdruid
.target Rylissa Bearsong
step
#completewith next
#label AwakeningTheArchdruidA
.goto 641,50.05,85.82,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Koda Steelclaw|r.
.turnin 38143 >>Turn in Awakening the Archdruid
.accept 38144 >>Accept The Demons Below
.accept 38145 >>Accept Out of the Dream
.target Koda Steelclaw
step
#completewith AwakeningTheArchdruidA
.goto 643,62.78,48.42,80 >>Enter the Sleeper's Barrow
step
#requires AwakeningTheArchdruidA
.goto 643,62.42,48.93,10,0
.goto 643,57.48,34.81,10,0
.goto 643,60.68,17.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Koda Steelclaw|r.
.turnin 38143 >>Turn in Awakening the Archdruid
.timer 6,Wake Up Roleplay
step
.goto 643,60.68,17.37,-1
.goto 643,62.66,48.68,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Koda Steelclaw|r |cRXP_WARN_after the roleplay|r.
.accept 38144 >>Accept The Demons Below
.accept 38145 >>Accept Out of the Dream
.target Koda Steelclaw
step
#completewith Druids of the Claw
>>Kill the |cRXP_ENEMY_Darkfiend Intruders|r.
.complete 38144,1 
.mob Darkfiend Dreamworg
.mob Darkfiend Tormentor
step
#completewith next
#label Druids of the Claw awakened
.goto 643,60.99,52.54,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,1 
.target Druid of the Claw
step
#completewith Druids of the Claw awakened
.goto 643,59.01,69.74,30 >>Follow the Arrow
step
#requires Druids of the Claw awakened
.goto 643,59.01,69.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,1 
.target Druid of the Claw
step
.goto 643,55.01,73.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,2 
.target Druid of the Claw
step
.goto 643,44.74,71.27,20,0
.goto 643,44,74.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,3 
.target Druid of the Claw
step
.goto 643,37.51,57.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,4 
.target Druid of the Claw
step
.goto 643,34.96,59.09,8,0
.goto 644,20.7,61.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,5 
.target Druid of the Claw
step
.goto 644,16.9,55.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,6 
.target Druid of the Claw
step
.goto 644,49.2,46.88,20,0
.goto 644,45.72,58.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,7 
.target Druid of the Claw
step
#label Druids of the Claw
.goto 644,51.04,57.3,5,0
.goto 644,61.24,65.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Druid of the Claw|r.
.complete 38145,1,8 
.target Druid of the Claw
step
#loop
.goto 644,71.79,41.21,30,0
.goto 644,51.89,36.06,30,0
.goto 644,37.47,45.31,30,0
.goto 644,19.24,45.88,30,0
.goto 643,37.69,67.69,30,0
.goto 643,60.65,64.18,30,0
>>Kill the |cRXP_ENEMY_Darkfiend Intruders|r.
.complete 38144,1 
.mob Darkfiend Dreamworg
.mob Darkfiend Tormentor
step
.goto 643,62.65,48.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Koda Steelclaw|r.
.turnin 38144 >>Turn in The Demons Below
.turnin 38145 >>Turn in Out of the Dream
.accept 38147 >>Accept Entangled Dreams
.target Koda Steelclaw
step
.goto 643,67.26,58.56,10,0
.goto 643,58.99,84.13
>>Kill |cRXP_ENEMY_Morphael|r.
*|TInterface/cursor/crosshair/interact.blp:20|t|cRXP_WARN_You may have to click on invisble |cRXP_PICK_Bramble Veins|r
.complete 38147,1 
.mob Morphael
step
#completewith next
#label EntangledDreamsA
.goto 643,66.02,69.16,15,0
.goto 643,66.65,56.09,15,0
.goto 643,63.88,47.33,15,0
.goto 643,64.86,46.28,15,0
.goto 641,49.99,85.52,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Koda Steelclaw|r.
.turnin 38147 >>Turn in Entangled Dreams
.target Koda Steelclaw
step
#completewith EntangledDreamsA
#label ArchdruidOfTheClawY
.goto 641,48.85,81.56,160 >>Leave the Sleeper's Barrow
step
#requires EntangledDreamsA
#label ArchdruidOfTheClawZ
.goto 641,48.85,81.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Koda Steelclaw|r.
.turnin 38147 >>Turn in Entangled Dreams
.target Koda Steelclaw
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Archdruid of the Vale Midnight
#internal
step
#label ArchdruidOfTheValeA
.goto 641,61.03,73.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaon Moonclaw|r.
.turnin 38382 >>Turn in Archdruid of the Vale
.accept 39383 >>Accept Dishonored
.target Thaon Moonclaw
step
>>Kill |cRXP_ENEMY_Xandris the Dishonored|r.
.goto 641,62.79,71.20,10,0
.goto 641,62.94,70.89
.complete 39383,1 
.mob Xandris the Dishonored
step
#label ArchdruidOfTheValeB
.goto 641,62.79,71.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaon Moonclaw|r.
.turnin 39383 >>Turn in Dishonored
.accept 39384 >>Accept The Corruptor
.target Thaon Moonclaw
step
#completewith next
#label ArchdruidOfTheValeC
>>Kill |cRXP_ENEMY_Kagraxxis the Corruptor|r.
.complete 39384,2 
.mob Kagraxxis the Corruptor
step
#title |cFFFCDC00Enter Cave|r
#completewith ArchdruidOfTheValeC
.goto 641,62.97,68.10,10 >>Enter the Moonclaw Cavern
step
#requires ArchdruidOfTheValeC
>>Kill |cRXP_ENEMY_Kagraxxis the Corruptor|r.
.goto 641,63.43,66.95,10,0
.goto 641,65.12,67.58,10,0
.goto 641,65.18,67.03
.complete 39384,2 
.mob Kagraxxis the Corruptor
step
.goto 641,65.18,67.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Evelle Nightwhisper|r.
.turnin 39384 >>Turn in The Corruptor
.accept 40573 >>Accept The Nightmare Lord
.target Evelle Nightwhisper
step
#label ArchdruidOfTheValeD
.goto 641,65.18,67.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Satyr Cage|r.
.complete 40573,1 
.target Evelle Nightwhisper
step
#completewith next
#label TheNightmareLordA
#title |cFFFCDC00Follow the Arrow|r
.complete 40573,2 
step
#completewith TheNightmareLordA
.goto 641,63.43,66.95,10,0
.goto 641,62.97,68.10,10 >>Leave the Moonclaw Cavern
step
#requires TheNightmareLordA
.goto 641,62.41,76.45
#title |cFFFCDC00Follow the Arrow|r
.complete 40573,2 
step
#label ArchdruidOfTheValeE
.goto 641,62.98,77.38,15,0
.goto 641,64.36,77.53
#title |cFFFCDC00Follow the Arrow|r
.complete 40573,3 
.mob Thaon Moonclaw
step
.goto 641,64.36,77.53
>>Kill |cRXP_ENEMY_Thaon Moonclaw|r.
.complete 40573,4 
.mob Thaon Moonclaw
step
#completewith next
#label TheNightmareLordB
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Evelle Nightwhisper|r.
.turnin 40573 >>Turn in The Nightmare Lord
.accept 38323 >>Accept Return to the Grove
.target Evelle Nightwhisper
step
#completewith TheNightmareLordB
.goto 641,62.98,77.38,15,0
.goto 641,62.41,76.45,10 >>Leave The Archdruid's Den
step
#requires TheNightmareLordB
#label ArchdruidOfTheValeF
.goto 641,62.34,76.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Evelle Nightwhisper|r.
.turnin 40573 >>Turn in The Nightmare Lord
.accept 38323 >>Accept Return to the Grove
.target Evelle Nightwhisper
step
#label ArchdruidOfTheValeZ
.goto 641,51.92,64.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r.
.turnin 38323 >>Turn in Return to the Grove
.target Malfurion Stormrage
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Into the Nightmare Midnight
#internal
step
#label IntoTheNightmareA
.goto 641,51.92,64.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r.
.accept 38377 >>Accept The Emerald Queen
.target Malfurion Stormrage
step
.goto 641,51.92,64.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r. Press "ESC" to skip the upcoming cutscene.
.complete 38377,1 
.target Malfurion Stormrage
.skipgossip 91109,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r and |cRXP_FRIENDLY_Ysera|r.
.turnin 38377 >>Turn in The Emerald Queen
.goto 641,52.52,64.15
.target +Malfurion Stormrage
.accept 38641 >>Accept The Temple of Elune
.goto 641,52.51,63.40
.target +Ysera
step
#label IntoTheNightmareB
.goto 641,52.24,56.64,31,0
.goto 641,51.92,57.30,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyanis Moonfall|r and |cRXP_FRIENDLY_Isoraen Nightstar|r |cRXP_WARN_inside the house|r.
.turnin 38641 >>Turn in The Temple of Elune
.accept 38662 >>Accept Tears for Fears
.goto 641,51.43,56.99
.target +Lyanis Moonfall
.accept 38655 >>Accept Root Cause
.goto 641,51.48,56.84
.target +Isoraen Nightstar
step
#completewith next
#label IntoTheNightmareC
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Twisted Roots|r.
.complete 38655,1 
step
.goto 641,58.88,54.02
#title |cFFFCDC00Follow the Arrow|r
.complete 38662,1 
step
#loop
.goto 641,58.71,54.90,20,0
.goto 641,58.02,54.20,20,0
.goto 641,58.11,52.58,20,0
.goto 641,57.63,52.47,20,0
.goto 641,57.14,55.46,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Twisted Roots|r.
.complete 38655,1 
step
#label IntoTheNightmareCA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Isoraen Nightstar|r and |cRXP_FRIENDLY_Lyanis Moonfall|r.
.turnin 38655 >>Turn in Root Cause
.goto 641,51.48,56.85
.target +Isoraen Nightstar
.turnin 38662 >>Turn in Tears for Fears
.accept 38663 >>Accept The Die is Cast
.goto 641,51.44,56.99
.target +Lyanis Moonfall
step
#label IntoTheNightmareCB
.goto 641,52.47,63.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysera|r
.turnin 38663 >>Turn in The Die is Cast
.accept 38595 >>Accept Malfurion's Fury
.target Ysera
step
#completewith next
#hidewindow
.goto 641,52.47,63.42
.gossipoption 44776 >>1
.timer 33,Flight Duration
step
.goto 641,60.56,61.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysera|r
.complete 38595,1 
.skipgossipid 44776
step
.goto 641,60.56,61.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysera|r
.turnin 38595 >>Turn in Malfurion's Fury
.accept 38582 >>Accept To Old Friends
.target Ysera
step
#loop
.goto 641,63.28,61.13,35,0
.goto 641,63.85,58.43,35,0
.goto 641,62.81,54.54,45,0
.goto 641,65.80,56.41,40,0
.goto 641,64.95,61.43,40,0
>>Use the |T135798:0|t[|cRXP_WARN_ExtraActionButton|r] to kill the |cRXP_ENEMY_Corrupted Plants|r.
.complete 38582,1 
step
.goto 641,66.28,56.16
#title |cFFFCDC00Follow the Arrow|r
.complete 38582,2 
step
#label IntoTheNightmareD
.goto 641,67.28,56.67,15,0
.goto 641,67.29,58.12
>>Kill |cRXP_ENEMY_Lyrathos Darkgrove|r
.complete 38582,3 
.mob Lyrathos Darkgrove
step
#completewith next
#label IntoTheNightmareE
#title |cFFFCDC00Leave Cave|r
.goto 641,67.22,56.63,15,0
.goto 641,66.75,56.17,15,0
.goto 641,65.87,56.58,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysera|r
.turnin 38582 >>Turn in To Old Friends
.accept 38753 >>Accept The Demon's Trail
.disablecheckbox
.target Ysera
step
#completewith IntoTheNightmareE
#title |cFFFCDC00Leave Cave|r
.goto 641,65.94,56.59,10 >>|cRXP_WARN_Leave the cave|r
step
#requires IntoTheNightmareE
.goto 641,64.92,61.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysera|r
.turnin 38582 >>Turn in To Old Friends
.accept 38753 >>Accept The Demon's Trail
.target Ysera
step
#label IntoTheNightmareY
.goto 641,67.45,56.09
#title |cFFFCDC00Follow the Arrow|r
.complete 38753,1 
.timer 18,RP
step
#label IntoTheNightmareZ
.goto 641,67.45,56.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 38753 >>Turn in The Demon's Trail
.target Tyrande Whisperwind
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) All Nightmare Long Midnight
#internal
step
#label AllNightmareLongA
.convertquest 41054,41056 << Alliance
.convertquest 41890,41708 << Alliance
.convertquest 38675,41724 << Alliance
.convertquest 41749,41893 << Alliance
.convertquest 41763,38687 << Alliance
.goto 641,67.45,56.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.accept 41054 >>Accept Love Lost << Horde
.accept 41056 >>Accept Love Lost << Alliance
.target Tyrande Whisperwind
step
#completewith next
#label AllNightmareLongB
.convertquest 41054,41056 << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 41054 >>Turn in Love Lost
.accept 41890 >>Accept Dark Side of the Moon
.disablecheckbox
.target Tyrande Whisperwind
step
#completewith AllNightmareLongB
#title |cFFFCDC00Enter Cave|r
.goto 641,69.32,49.77,10 >>|cRXP_WARN_Enter the cave|r
step
#requires AllNightmareLongB
#label AllNightmareLongC
.convertquest 41890,41708 << Alliance
.goto 641,69.54,49.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 41054 >>Turn in Love Lost
.accept 41890 >>Accept Dark Side of the Moon
.target Tyrande Whisperwind
step
#label AllNightmareLongD
.goto 641,66.92,50.13
#title |cFFFCDC00Follow the Arrow|r
.complete 41890,1 
step
#completewith next
#label DarkSideOfTheMoonA
>>Kill the |cRXP_ENEMY_Wormtalon Matriarch|r at the end
.complete 41890,2 
.mob Wormtalon Matriarch
step
#completewith DarkSideOfTheMoonA
.goto 641,66.92,50.13
.gossipoption 45499 >>Talk to |cRXP_FRIENDLY_Tyrande Whisperwind|r << Horde
.gossipoption 45498 >>Talk to |cRXP_FRIENDLY_Tyrande Whisperwind|r << Alliance
step
#requires DarkSideOfTheMoonA
#label AllNightmareLongE
.goto 641,66.92,50.13
>>Kill the incoming waves of enemies and the |cRXP_ENEMY_Wormtalon Matriarch|r that appears at the end.
.complete 41890,2 
.timer 15,Tyrande Roleplay
.mob Wormtalon Matriarch
.mob Wormtalon Witch
.mob Wormtalon Huntress
step
#label AllNightmareLongF
.goto 641,66.93,50.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 41890 >>Turn in Dark Side of the Moon
.accept 43576 >>Accept Regroup at the Refuge
.target Tyrande Whisperwind
step
.convertquest 38675,41724 << Alliance
.goto 641,69.54,49.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 43576 >>Turn in Regroup at the Refuge
.accept 38675 >>Accept Heart of the Nightmare
.timer 68,Tyrande Roleplay
.target Tyrande Whisperwind
step
.goto 641,66.21,44.77
>>|cRXP_WARN_Wait at the waypoint position|r
.complete 38675,1 
step
.goto 641,66.21,44.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 38675 >>Turn in Heart of the Nightmare
.target Tyrande Whisperwind
step
.convertquest 41749,41893 << Alliance
#label AllNightmareLongG
.goto 641,66.21,44.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elothir|r
.accept 38684 >>Accept Reading the Leaves
.accept 41749 >>Accept Given to Corruption
.target Elothir
step
#label AllNightmareLongH
#completewith next
>>Kill the |cRXP_ENEMY_Terrorvine Lashers|r. Loot them for the |T1357815:0|t[|cRXP_LOOT_Corrupted Petals|r].
.complete 38684,1 
.mob Terrorvine Lasher
step
#completewith next
#label GivenToCorruptionA
>>Kill |cRXP_ENEMY_Varethos|r
.complete 41749,1 
.mob Varethos
step
#completewith GivenToCorruptionA
#title |cFFFCDC00Enter Cave|r
.goto 641,66.67,35.95,15 >>|cRXP_WARN_Enter the cave|r
step
#requires GivenToCorruptionA
.goto 641,68.75,35.32
>>Kill |cRXP_ENEMY_Varethos|r
.complete 41749,1 
.mob Varethos
step
#completewith next
#label ReadingTheLeavesA
>>Kill the |cRXP_ENEMY_Terrorvine Lashers|r and |cRXP_ENEMY_Twisted Keeper|r. Loot them for the |T1357815:0|t[|cRXP_LOOT_Corrupted Petals|r].
.complete 38684,1 
.mob Terrorvine Lasher
.mob Twisted Keeper
step
#completewith ReadingTheLeavesA
#title |cFFFCDC00Leave Cave|r
.goto 641,66.67,35.95,15 >>|cRXP_WARN_Leave the cave|r
step
#requires ReadingTheLeavesA
#label AllNightmareLongI
#loop
.goto 641,65.56,37.94,35,0
.goto 641,66.75,39.36,35,0
.goto 641,68.59,39.19,35,0
>>Kill the |cRXP_ENEMY_Terrorvine Lashers|r and |cRXP_ENEMY_Twisted Keeper|r. Loot them for the |T1357815:0|t[|cRXP_LOOT_Corrupted Petals|r].
.complete 38684,1 
.mob Terrorvine Lasher
.mob Twisted Keeper
step
#label AllNightmareLongJ
.goto 641,66.21,44.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elothir|r
.turnin 38684 >>Turn in Reading the Leaves
.turnin 41749 >>Turn in Given to Corruption
.target Elothir
step
.goto 641,66.20,44.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.accept 43702 >>Accept Softening the Target
.target Tyrande Whisperwind
step
#completewith next
#label SofteningTheTargetA
>>Use |T535592:0|t[Terrorfiend Discharge] (1) and aim it at the glowing |cRXP_ENEMY_Nightmare Creatures|r.
.complete 43702,1 
step
#completewith SofteningTheTargetA
.goto 641,66.36,44.84
.vehicle 109827 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Subdued Nightwing|r
step
#requires SofteningTheTargetA
>>Use |T535592:0|t[Terrorfiend Discharge] (1) and aim it at the glowing |cRXP_ENEMY_Nightmare Creatures|r.
.complete 43702,1 
step
.convertquest 41763,38687 << Alliance
.goto 641,63.20,42.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r.
.turnin 43702 >>Turn in Softening the Target
.accept 41763 >>Accept Close Enough to Touch
.timer 46,Tyrande Roleplay
.target Tyrande Whisperwind
step
.goto 641,62.7,37.25,10,0
.goto 641,63.03,36.88
>>|cRXP_WARN_Wait at the waypoint for the roleplay|r.
.complete 41763,1 
step
#completewith next
#label Malfurion at the Inn1
>>Leave the Inn
.complete 41763,2 
.target Malfurion Stormrage
step
#completewith Malfurion at the Inn1
.goto 641,63.03,36.88
.cast 221373 >>Click on |cRXP_PICK_Malfurion Stormrage|r.
step
#requires Malfurion at the Inn1
.goto 641,62.61,37.23,10,0
.goto 641,62.43,33.15
>>Leave the Inn
.complete 41763,2 
.target Malfurion Stormrage
step
.goto 641,62.43,33.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Malfurion Stormrage|r.
.complete 41763,3 
.target Malfurion Stormrage
step
#label AllNightmareLongK
#completewith next
#hidewindow
.complete 41763,4 
.target Malfurion Stormrage
step
#completewith AllNightmareLongK
.goto 641,59.12,32.55
.cast 221375 >>Click on |cRXP_FRIENDLY_Malfurion Stormrage|r.
.target Malfurion Stormrage
step
#requires AllNightmareLongK
.goto 641,58.31,37.90
#title |cFFFCDC00Follow the Arrow|r
.complete 41763,4 
.target Malfurion Stormrage
step
#label AllNightmareLongL
.goto 641,58.31,37.90
#title |cFFFCDC00Follow the Arrow|r
.complete 41763,5 
step
.goto 641,57.82,38.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 41763 >>Turn in Close Enough to Touch
.accept 38743 >>Accept The Fate of Val'sharah
.target Tyrande Whisperwind
step
.goto 641,57.82,38.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande|r
.complete 38743,1 
.timer 64,Tyrande Roleplay
.target Tyrande
.skipgossipid 45380
step
.goto 641,53.66,55.78
>>Defeat |cRXP_ENEMY_Ysera|r
*- Dodge the Nightmare Breath
*- Interrupt the Cries of Insanity
.complete 38743,2 
.mob Ysera
step
#label AllNightmareLongY
.goto 641,53.68,55.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r
.turnin 38743 >>Turn in The Fate of Val'sharah
.accept 40567 >>Accept Darkheart Thicket: Enter the Nightmare
.target Tyrande Whisperwind
step
#label AllNightmareLongZ
.goto 641,53.49,55.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r.
.accept 40890 >>Accept The Tears of Elune
.target Tears of Elune
step
.isOnQuest 40890
.goto 627,49.39,48
>>Enter the center of Dalaran
.complete 40890,1 
step
.isOnQuest 40890
.goto 629,45.68,65.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tears of Elune|r
.turnin 40890 >>Turn in The Tears of Elune
.target Tears of Elune
.complete 44338,1 
step
#optional
.isQuestComplete 44338
+|cRXP_WARN_Switch to this guide to continue the Origin storyline|r
.clicknext RestedXP Speed Leveling\a) Origins>>CLICK HERE FOR GUIDE
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Braddensbrook Midnight
#internal
step
#label BraddensbrookA
.goto 641,51.29,51.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theo the Huntsman|r
.accept 39149 >>Accept A Village in Peril
.target Theo the Huntsman
step
.goto 641,42.35,59.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Heathrow|r
.turnin 39149 >>Turn in A Village in Peril
.target Mayor Heathrow
step
#label BraddensbrookB
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r and |cRXP_FRIENDLY_Emmeline|r
.accept 38645 >>Accept Children of the Night
.goto 641,42.46,58.98,-1
.target +Commander Jarod Shadowsong
.accept 38644 >>Accept The Farmsteads
.goto 641,42.13,59.04,-1
.target +Emmeline
step
#label BraddensbrookC
.goto 641,38.90,61.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Granny Marl|r
.accept 38646 >>Accept A Sight For Sore Eyes
.accept 38647 >>Accept For the Corn!
.complete 38644,2 
.target Granny Marl
step
#completewith Radcliffe
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_Falcons|r.
>>Kill |cRXP_ENEMY_Falcons|r and |cRXP_ENEMY_Risens|r.
.complete 38645,1 
.complete 38646,1 
.mob Risen Hound
.mob Risen Assassin
.mob Black Rook Falcon
.use 127030
step
#completewith Radcliffe
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels of Corn|r
.complete 38647,1 
step
#label BraddensbrookD
.goto 641,38.47,65.34,5,0
.goto 641,38.44,65.57,5,0
.goto 641,38.11,65.17
#title |cFFFCDC00Enter the Cellar|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Penelope Heathrow|r
.complete 38644,1 
.skipgossipid 44454
step
#completewith next
#label Shriek No More
.goto 641,38.47,65.58,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cecily Radcliffe|r
.accept 39117 >>Accept Shriek No More
.complete 38644,3 
.disablecheckbox
.target Cecily Radcliffe
step
#completewith Shriek No More
.goto 641,38.46,65.21,5 >>Leave the Cellar
step
#requires Shriek No More
.goto 641,37.06,58.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cecily Radcliffe|r
.accept 39117 >>Accept Shriek No More
.complete 38644,3 
.target Cecily Radcliffe
step
.goto 641,35.99,56.89
>>Kill |cRXP_ENEMY_Rotbeak|r.
*Loot it for |T648726:0|t[|cRXP_LOOT_Rotbeak's Head|r].
.complete 39117,1 
.mob Rotbeak
step
#label Radcliffe
.goto 641,37.06,58.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cecily Radcliffe|r
.turnin 39117 >>Turn in Shriek No More
.target Cecily Radcliffe
step
#hidewindow
#completewith Black Rook Falcons marked
#loop
.goto 641,37.27,60,30,0
.goto 641,38.16,63.41,30,0
.goto 641,38.48,59.61,30,0
.goto 641,39.72,63.24,30,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_Falcons|r.
>>Kill |cRXP_ENEMY_Falcons|r and |cRXP_ENEMY_Risens|r.
.complete 38645,1 
.complete 38646,1 
.mob Risen Hound
.mob Risen Assassin
.mob Black Rook Falcon
.use 127030
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels of Corn|r
.complete 38647,1 
step
#label Black Rook Falcons marked
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_Falcons|r.
>>Kill |cRXP_ENEMY_Falcons|r and |cRXP_ENEMY_Risens|r.
.complete 38645,1 
.complete 38646,1 
.mob Risen Hound
.mob Risen Assassin
.mob Black Rook Falcon
.use 127030
step
.goto 641,38.90,61.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Granny Marl|r
.turnin 38646 >>Turn in A Sight For Sore Eyes
.turnin 38647 >>Turn in For the Corn!
.mob Granny Marl
step
.goto 641,42.34,59.00
#title |cFFFCDC00Follow the Arrow|r
.complete 38644,4 
step
#label BraddensbrookZ
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Heathrow|r and |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.turnin 38644 >>Turn in The Farmsteads
.goto 641,42.34,59.00
.target +Mayor Heathrow
.turnin 38645 >>Turn in Children of the Night
.goto 641,42.46,58.97
.target +Commander Jarod Shadowsong
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Black Rook Hold Midnight
#internal
step
#label BlackRookHoldA
.goto 641,42.46,58.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.accept 38691 >>Accept Jarod's Mission
.target +Commander Jarod Shadowsong
step
.goto 641,42.46,58.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.complete 38691,1 
.target Commander Jarod Shadowsong
.skipgossipid 44726
step
.isOnQuest 38691
#title |cFFFCDC00Leave the vehicle|r
#completewith next
#label JarodsMissionA
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#completewith JarodsMissionA
#hidewindow
.goto 641,39.16,53.05,50 >>1
step
#requires JarodsMissionA
#completewith next
#label JarodsMissionB
.goto 641,40.85,53.01,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.turnin 38691 >>Turn in Jarod's Mission
.accept 38718 >>Accept Kur'talos Ravencrest
.target Commander Jarod Shadowsong
step
#requires JarodsMissionA
#completewith JarodsMissionB
#title |cFFFCDC00Enter the mausoleum|r
.goto 641,39.16,53.05,15 >>|cRXP_WARN_Enter the mausoleum|r
step
#requires JarodsMissionB
.goto 641,40.85,53.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.turnin 38691 >>Turn in Jarod's Mission
.accept 38718 >>Accept Kur'talos Ravencrest
.target Commander Jarod Shadowsong
step
.goto 641,40.89,53.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kur'talos' Ravencrest Sigil|r
.complete 38718,1 
step
.goto 641,40.74,53.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.turnin 38718 >>Turn in Kur'talos Ravencrest
.accept 38714 >>Accept Maiev's Trail
.accept 38715 >>Accept The Rook's Guard
.target Commander Jarod Shadowsong
step
#completewith next
#label Starlys Strongbow
>>Kill |cRXP_ENEMY_Starlys Strongbow|r
.complete 38715,1 
.mob Starlys Strongbow
step
#completewith Starlys Strongbow
#title |cFFFCDC00Leave the mausoleum|r
.goto 641,38.81,53.07,10 >>|cRXP_WARN_Leave the mausoleum|r
step
#requires Starlys Strongbow
.goto 641,39.93,52.06
>>Kill |cRXP_ENEMY_Starlys Strongbow|r
.complete 38715,1 
.mob Starlys Strongbow
step
.goto 641,40.50,51.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Bradensbrook Villager|r
.complete 38714,1 
.target Bradensbrook Villager
step
.goto 641,41.00,56.24
>>Kill |cRXP_ENEMY_Kester Farseeker|r
.complete 38715,2 
.mob Kester Farseeker
step
.goto 641,40.86,56.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Stareye's Orders|r
.complete 38714,2 
step
#completewith next
>>Kill |cRXP_ENEMY_Trelan Shieldbreaker|r
.complete 38715,3 
.mob Trelan Shieldbreaker
step
.goto 641,42.04,51.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Warden's Glaive|r
.complete 38714,3 
step
#loop
.goto 641,41.92,52.98,20,0
.goto 641,42.87,51.00,20,0
>>Kill |cRXP_ENEMY_Trelan Shieldbreaker|r
.complete 38715,3 
.mob Trelan Shieldbreaker
step
#label BlackRookHoldB
.goto 641,43.82,50.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.turnin 38714 >>Turn in Maiev's Trail
.turnin 38715 >>Turn in The Rook's Guard
.accept 38717 >>Accept Black Rook Prison
.target Commander Jarod Shadowsong
step
#label BlackRookHoldC
.goto 641,42.20,46.48
>>Kill |cRXP_ENEMY_Araxxas|r. Loot him for the |T134245:0|t[|cRXP_LOOT_Prison Keys|r].
*|cRXP_WARN_NOTE:|r If |cRXP_ENEMY_Araxxas|r is not there wait for the respawn or relog/reenter the zone.
.complete 38717,1 
.mob Araxxas
step
#completewith next
#label BlackRookPrisonC
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.turnin 38717 >>Turn in Black Rook Prison
.accept 38724 >>Accept Brotherly Love
.target Commander Jarod Shadowsong
step
#completewith BlackRookPrisonA
#label BlackRookPrisonB
#title |cFFFCDC00Enter the Darkpens|r
.goto 641,41.25,45.47,10 >>|cRXP_WARN_Enter the Darkpens|r
step
#requires BlackRookPrisonB
#label BlackRookPrisonC
#title |cFFFCDC00Jump down carefully|r
.goto 641,40.56,44.99,10,0
.goto 642,41.70,84.80,8 >>|cRXP_WARN_Jump down carefully|r
step
#requires BlackRookPrisonA
.goto 642,43.09,81.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Jarod Shadowsong|r
.turnin 38717 >>Turn in Black Rook Prison
.accept 38724 >>Accept Brotherly Love
.target Commander Jarod Shadowsong
step
.goto 642,43.20,82.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arduen Soulblade|r
.accept 38719 >>Accept Illidari Freedom
.target Arduen Soulblade
step
.goto 642,48.80,69.55,15,0
.goto 642,34.27,58.65,8,0
.goto 642,30.64,66.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sirius Ebonwing|r and defeat him
.complete 38719,1 
.target Sirius Ebonwing
.skipgossipid 44302
step
.goto 642,35.63,55.10,10,0
.goto 642,29.00,46.75,10,0
.goto 642,25.40,55.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Asha Ravensong|r
.complete 38719,3 
.target Asha Ravensong
.skipgossipid 44306
step
.goto 642,23.17,40.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maiev Shadowsong|r
.turnin 38724 >>Turn in Brotherly Love
.timer 11,Maiev Roleplay
.accept 38721 >>Accept Lieutenant of the Tower
.target Maiev Shadowsong
step
#completewith next
#label IllidariFreedomA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_Cassiel Nightthorn|r
.complete 38719,2 
.target Cassiel Nightthorn
.skipgossipid 44304
step
#completewith IllidariFreedomA
#title |cFFFCDC00Go up the stairs|r
.goto 642,39.17,53.20,12,0
.goto 642,40.63,36.45,10,0
.goto 642,48.33,36.00,10 >>|cRXP_WARN_Follow the arrow up the stairs|r
step
#requires IllidariFreedomA
.goto 642,61.36,50.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_Cassiel Nightthorn|r
.complete 38719,2 
.target Cassiel Nightthorn
.skipgossipid 44304
step
.goto 642,57.37,41.80,12,0
.goto 642,65.12,24.73
>>Kill |cRXP_ENEMY_Lieutenant Desdel Stareye|r
*- |cRXP_WARN_Interrupt the Spectral Storm and Infuse Death|r
.complete 38721,1 
.mob Lieutenant Desdel Stareye
step
#completewith next
#label LieutenantOfTheTowerA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Asha Ravensong|r
.turnin 38719 >>Turn in Illidari Freedom
.target Asha Ravensong
step
#completewith LieutenantOfTheTowerA
.goto 642,69.07,15.60
.zone 641 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gate to the Ravencrest Cemetery|r
.skipgossipid 45050
step
#requires LieutenantOfTheTowerA
#label BlackRookHoldY
.goto 641,39.15,51.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Asha Ravensong|r
.turnin 38719 >>Turn in Illidari Freedom
.target Asha Ravensong
step
#label BlackRookHoldZ
.goto 641,38.86,50.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maiev Shadowsong|r
.turnin 38721 >>Turn in Lieutenant of the Tower
.target Maiev Shadowsong
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) The Rivermane Tribe Midnight
#internal
step
.goto 650,35.97,65.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Oro|r.
.target Warbrave Oro
.accept 38907 >>Accept Keepers of the Hammer
step
#completewith next
#hidewindow
#label TheRivermaneTribeStart1
.complete 38907,2 
step
#completewith next
#label KeepersOfTheHammerA
.goto 652,27.04,79.62,10,0
#title |cFFFCDC00Follow the Arrow|r
.complete 38907,1 
step
#completewith KeepersOfTheHammerA
.goto 652,54.8,63.24,90 >>Enter Thunder Totem at the lower level.
step
#requires KeepersOfTheHammerA
.goto 652,54.8,63.24
>>|cRXP_WARN_Follow the arrow|r
.complete 38907,1 
step
.goto 652,54.86,63.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.target Mayla Highmountain
.turnin 38907 >>Turn in Keepers of the Hammer
.accept 38911 >>Accept The Rivermane Tribe
step
#completewith next
#label TheRivermaneTribeA
.goto 652,40.99,55.22,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r and |cRXP_FRIENDLY_Farmer Maya|r.
.turnin 38911 >>Turn in The Rivermane Tribe
.accept 39491 >>Accept Ormgul the Pestilent
.target +Jale Rivermane
.accept 39272 >>Accept Poisoned Crops
.accept 39490 >>Accept Infestation
.target +Farmer Maya
step
#completewith TheRivermaneTribeA
#title Leave Thunder Totem
.goto 650,43.64,59.92,135 >>Leave Thunder Totem
step
#requires TheRivermaneTribeA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r and |cRXP_FRIENDLY_Farmer Maya|r.
.turnin 38911 >>Turn in The Rivermane Tribe
.accept 39491 >>Accept Ormgul the Pestilent
.goto 650,43.64,59.92
.target +Jale Rivermane
.accept 39272 >>Accept Poisoned Crops
.accept 39490 >>Accept Infestation
.goto 650,43.69,59.90
.target +Farmer Maya
step
#completewith Poison Idol destroyed
>>Kill |cRXP_ENEMY_Diseased Grubs|r and |cRXP_ENEMY_Overgrown Larvas|r around you.
.complete 39490,1 
.complete 39490,2 
.mob Diseased Grub
.mob Overgrown Larva
step
#title Poison Idol (1/4)
.goto 650,43.10,59.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poison Idol|r.
.complete 39272,1,1 
step
#title Loot Bug Sprayer
.goto 650,42.32,58.39
>>Kill |cRXP_ENEMY_Ormgul the Pestilent|r. Loot him for the |T609616:0|t[|cRXP_LOOT_Bug Sprayer|r].
.complete 39491,1 
.mob Ormgul the Pestilent
.use 127988
step
#title Poison Idol (2/4)
.goto 650,43.21,56.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poison Idol|r.
.complete 39272,1,2 
step
#title Poison Idol (3/4)
.goto 650,43.20,57.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poison Idol|r.
.complete 39272,1,3 
step
#label Poison Idol destroyed
#title Poison Idol (4/4)
.goto 650,43.47,58.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poison Idol|r.
.complete 39272,1,4 
step
>>Kill |cRXP_ENEMY_Diseased Grubs|r and |cRXP_ENEMY_Overgrown Larvas|r.
.goto 650,43.30,57.63
.complete 39490,1 
.complete 39490,2 
.mob Diseased Grub
.mob Overgrown Larva
step
#label TheRivermaneTribeEnd1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Maya|r and |cRXP_FRIENDLY_Jale Rivermane|r.
.turnin 39272 >>Turn in Poisoned Crops
.turnin 39490 >>Turn in Infestation
.goto 650,43.69,59.90
.target Farmer Maya
.turnin 39491 >>Turn in Ormgul the Pestilent
.accept 39496 >>Accept The Flow of the River
.goto 650,43.64,59.91
.target Jale Rivermane
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angler Creel|r and |cRXP_FRIENDLY_Jale Rivermane|r.
.turnin 39496 >>Turn in The Flow of the River
.accept 39316 >>Accept Trapped Tauren
.accept 39614 >>Accept Fish Out of Water
.goto 650,41.14,61.58
.accept 39277 >>Accept Spray and Prey
.goto 650,41.17,61.49
.target Angler Creel
.target Jale Rivermane
step
#completewith HighmountainTaurenTrappedTauren
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
#completewith HighmountainTaurenTrappedTauren
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
#label HighmountainTaurenTrappedTauren
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood Barricade|r.
.goto 650,42.85,63.14
.complete 39316,1 
step
#hidewindow
#completewith Whitewater Carp
#loop
.goto 650,41.62,63.29,30,0
.goto 650,39.9,63.71,30,0
.goto 650,38.51,63.6,30,0
.goto 650,39.54,62.21,30,0
.goto 650,41.06,62.05,30,0
.goto 650,39.31,65.78,30,0
.goto 650,37.8,64.02,30,0
+1
step
#completewith next
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
#label Whitewater Carp
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fish|r while facing the water to kick it in.
.complete 39614,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angler Creel|r and |cRXP_FRIENDLY_Jale Rivermane|r.
.turnin 39316 >>Turn in Trapped Tauren
.turnin 39614 >>Turn in Fish Out of Water
.goto 650,41.13,61.57
.turnin 39277 >>Turn in Spray and Prey
.accept 39661 >>Accept Lifespring Cavern
.goto 650,41.18,61.49
.target Angler Creel
.target Jale Rivermane
step
#label TheRivermaneTribeStart2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r.
.goto 650,38.40,61.22
.turnin 39661 >>Turn in Lifespring Cavern
.accept 39488 >>Accept Balance of Elements
.accept 39489 >>Accept Invading Spelunkers
.target Jale Rivermane
step
#completewith TheRivermaneTribeEnd2
+|cRXP_WARN_You can run over |cRXP_FRIENDLY_Flowing Droplets|r for a Movement Speed increase|r.
step
#hidewindow
#completewith Violent Crageaters
#loop
.goto 655,70.5,70.11,15,0
.goto 655,62.88,54.25,15,0
.goto 655,68.39,43.42,15,0
.goto 655,56.67,38.67,15,0
.goto 655,48.86,38.02,15,0
.goto 655,45.35,55.77,15,0
.goto 655,41.78,79.56,15,0
.goto 656,36.55,77.95,15,0
.goto 655,41.27,58.37,15,0
.goto 655,45.84,50.98,15,0
.goto 655,41.62,28.95,15,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Violent Crageaters|r or |cRXP_ENEMY_Drogbar Manathirster|r.
.complete 39489,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Siphoning Crystals|r and loot them from |cRXP_ENEMY_Violent Crageaters|r or |cRXP_ENEMY_Drogbar Manathirster|r.
.complete 39488,1 
.mob Violent Crageater
.mob Drogbar Manathirster
step
#label Violent Crageaters
>>Kill |cRXP_ENEMY_Violent Crageaters|r or |cRXP_ENEMY_Drogbar Manathirster|r.
.complete 39489,1 
.goto 655,44.06,32.64
.mob Violent Crageater
.mob Drogbar Manathirster
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r |cRXP_WARN_next to you|r.
.turnin 39489 >>Turn in Invading Spelunkers
.turnin 39488 >>Turn in Balance of Elements
.accept 39487 >>Accept Crystal Fury
.target Jale Rivermane
step
#completewith next
#label Gelmogg
#hidewindow
.goto 655,41.42,62.15,15,0
.goto 656,40.67,65.44,30,0
>>Kill |cRXP_ENEMY_Gelmogg|r.
.complete 39487,1 
.mob Gelmogg
step
#completewith Gelmogg
.goto 656,44.06,28.43,35 >>Go up the ramp
step
#requires Gelmogg
#label The Rivermane Tribe
>>Kill |cRXP_ENEMY_Gelmogg|r.
.goto 656,44.06,28.43
.complete 39487,1 
.mob Gelmogg
step
#label TheRivermaneTribeEnd2
.goto 656,44.06,28.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r |cRXP_WARN_next to you|r.
.turnin 39487 >>Turn in Crystal Fury
.accept 39498 >>Accept High Water
.target Jale Rivermane
step
#completewith next
#label High Water
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r.
.goto 655,63.21,59.87,15,0
.goto 650,38.31,61.1,10,0
.turnin 39498 >>Turn in High Water
.target Jale Rivermane
step
.zoneskip 650
#completewith High Water
#title |cFFFCDC00Follow the Arrow|r
.goto 650,40.36,71.70,520 >>Leave the Cave
step
#requires High Water
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r.
.goto 650,40.36,71.70
.turnin 39498 >>Turn in High Water
.target Jale Rivermane
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Riverbend Midnight
#internal
step
#label RiverbendStart1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r.
.goto 650,40.36,71.70
.turnin 39498 >>Turn in High Water
.target Jale Rivermane
step
.goto 650,40.36,71.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r.
.accept 42104 >>Accept The Underking Comes
.target Jale Rivermane
step
#loop
.goto 650,40.41,69.83,25,0
.goto 650,39.46,70.29,25,0
.goto 650,40.43,69.04,25,0
.goto 650,39.89,68.23,25,0
>>Use the |cRXP_WARN_[ExtraActionButton]|r |T134227:0|t[Horn of Jale]|r near |cRXP_FRIENDLY_Rivermane Tauren|r.
*|cRXP_WARN_You can use the button while mounted|r.
.complete 42104,1 
.target Rivermane Tauren
step
#completewith next
#label The Underking Comes
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.turnin 42104 >>Turn in The Underking Comes
.target Spiritwalker Ebonhorn
step
#completewith The Underking Comes
.goto 650,38.66,68.65,10 >>Enter the tent
step
#requires The Underking Comes
.goto 650,38.57,69.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.turnin 42104 >>Turn in The Underking Comes
.target Spiritwalker Ebonhorn
step
#completewith next
#label Grasp of the Underking
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.accept 39025 >>Accept Grasp of the Underking
.accept 39026 >>Accept The Drogbar
.target Spiritwalker Ebonhorn
step
#completewith Grasp of the Underking
.goto 650,38.62,68.44,10 >>Leave the tent
step
#requires Grasp of the Underking
.goto 650,38.62,68.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.accept 39025 >>Accept Grasp of the Underking
.accept 39026 >>Accept The Drogbar
.target Spiritwalker Ebonhorn
step
#completewith HighmountainTaurenGraspoftheUnderking
>>Kill the |cRXP_ENEMY_Bitestones|r.
.complete 39026,1 
.mob Bitestone Rockcrusher
.mob Bitestone Raider
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Grasp of Dargrul|r
.goto 650,39.62,68.44
.complete 39025,2 
.mob Grasp of Dargrul
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Grasp of Dargrul|r
.goto 650,39.31,70.28
.complete 39025,1 
.mob Grasp of Dargrul
step
#label HighmountainTaurenGraspoftheUnderking
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Grasp of Dargrul|r
.goto 650,40.32,71.84
.complete 39025,3 
.mob Grasp of Dargrul
step
#label RiverbendEnd1
#loop
.goto 650,40.42,73.26,30,0
.goto 650,41.22,70.1,30,0
.goto 650,41.07,67.8,30,0
.goto 650,40.05,69.64,30,0
.goto 650,38.96,69.26,30,0
>>Kill the |cRXP_ENEMY_Bitestones|r.
.complete 39026,1 
.mob Bitestone Rockcrusher
.mob Bitestone Raider
step
#label RiverbendStart2
.isQuestAvailable 39025,39026
.goto 651,11.68,25.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Oro|r.
.turnin 39025 >>Turn in Grasp of the Underking
.turnin 39026 >>Turn in The Drogbar
.accept 39043 >>Accept Bitestone Enclave
.target Warbrave Oro
step
.isQuestTurnedIn 39025,39026
.goto 651,47.2,44.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Oro|r.
.accept 39043 >>Accept Bitestone Enclave
.target Warbrave Oro
step
#completewith next
#label Manaspine Basilisk
.goto 651,22.34,26.69,20,0
.goto 651,78.55,56.85,25,0
.goto 651,40.18,29.87,30,0
>>Kill |cRXP_ENEMY_Bitestone drogbar|r and |cRXP_ENEMY_Manaspine Basilisk|r.
.complete 39043,1 
.complete 39043,2 
.mob Manaspine Basilisk
.mob Bitestone Rockbeater
.mob Bitestone Slinger
.mob Bitestone Raider
step
#completewith Manaspine Basilisk
#title |cFFFCDC00Enter Cave|r
.goto 651,50.89,41.21,70 >>Enter the Cave
step
#requires Manaspine Basilisk
#loop
.goto 651,50.89,41.21,25,0
.goto 651,63.94,48.3,25,0
.goto 651,79.18,57.26,30,0
.goto 651,51.47,48.7,25,0
.goto 651,55.01,71.98,25,0
.goto 651,68.06,79.66,25,0
.goto 651,78.51,67.65,25,0
.goto 651,85.78,54.33,25,0
>>Kill |cRXP_ENEMY_Bitestone drogbar|r and |cRXP_ENEMY_Manaspine Basilisk|r.
.complete 39043,1 
.complete 39043,2 
.mob Manaspine Basilisk
.mob Bitestone Rockbeater
.mob Bitestone Slinger
.mob Bitestone Raider
step
.goto 651,47.23,44.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Oro|r.
.turnin 39043 >>Turn in Bitestone Enclave
.accept 39027 >>Accept Dargrul and the Hammer
.target Warbrave Oro
step
#completewith next
#label Confront Dargrul the Underking
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Grasp of Dargrul|r
.complete 39027,1 
step
#completewith Confront Dargrul the Underking
#title |cFFFCDC00Follow the Arrow|r
.goto 651,68.7,50.72,10 >>Follow the Arrow
.timer 3,RP
step
#requires Confront Dargrul the Underking

#arrowtext |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Grasp of Dargrul|r\nthen leave the cave
.goto 651,25.73,22.15,20,0
.goto 651,18.65,26.58,15,0
.goto 650,41.13,72.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Grasp of Dargrul|r then leave the cave.
.complete 39027,2 
.mob Grasp of Dargrul
step
#label Riverbend
.goto 650,38.62,68.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.turnin 39027 >>Turn in Dargrul and the Hammer
.accept 38909 >>Accept Get to High Ground
step
#completewith next
#hidewindow
#label Lead Jale Rivermane to Thunder Totem
.goto 652,27.89,79.13,10,0
.complete 38909,1 
step
#completewith Lead Jale Rivermane to Thunder Totem
.goto 652,54.80,63.28,100 >>Enter the lowest level of Thunder Totem.
.timer 26,RP
step
#requires Lead Jale Rivermane to Thunder Totem
.isQuestAvailable account,40471
.goto 652,62.98,67.92
.cast 3365 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#requires Lead Jale Rivermane to Thunder Totem
#label RiverbendEnd2
.goto 652,54.80,63.28
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 38909,2 
step
.goto 652,54.80,63.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.turnin 38909 >>Turn in Get to High Ground
.accept 38912 >>Accept The Bloodtotem Tribe
.accept 38913 >>Accept The Skyhorn Tribe
.accept 40515 >>Accept A Walk With the Spirits
.target Mayla Highmountain
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Huln's War Midnight
#internal
step
#label HulnsWarStart1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r.
.goto 650,40.36,71.70
.accept 40515 >>Accept A Walk With the Spirits
.target Jale Rivermane
step
.goto 652,67.65,77.86,15,0
.goto 652,74.68,75.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.turnin 40515 >>Turn in A Walk With the Spirits
.accept 40167 >>Accept The Story of Huln
.target Spiritwalker Ebonhorn
step
.goto 652,74.68,75.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r |cRXP_WARN_again|r.
.complete 40167,1 
.skipgossip 98825,1
.target Spiritwalker Ebonhorn
step
.goto 652,74.68,75.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.turnin 40167 >>Turn in The Story of Huln
.accept 40520 >>Accept To See the Past
.target Spiritwalker Ebonhorn
step
#completewith next
#label Bottle of Airspark
.goto 652,50.32,41.33,10,0
.goto 750,42.13,33.35,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanna Skyspark|r.
.complete 40520,1 
.buy 132247,1
.target Lanna Skyspark
step
#completewith Bottle of Airspark
#title |cFFFCDC00Leave Building|r
.goto 750,35.46,23.61,90 >>Leave the building
step
#requires Bottle of Airspark
.goto 750,35.46,23.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanna Skyspark|r and buy |T134784:0|t[Bottle of Airspark].
.complete 40520,1 
.buy 132247,1
.target Lanna Skyspark
step
#completewith next
#label Darkshard Crystal
>>Kill the |cRXP_ENEMY_Darkshard Crystal|r.
*Loot them for |T237070:0|t[|cRXP_LOOT_Darkshard Crystal|r].
.complete 40520,3 
step
#completewith Darkshard Crystal
.goto 650,45.14,53.44
.cast 197697 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Darkshard Crystal|r
step
#requires Darkshard Crystal
#label HulnsWarEnd1
.goto 650,45.14,53.44
>>Kill the |cRXP_ENEMY_Darkshard Crystal|r.
*Loot them for |T237070:0|t[|cRXP_LOOT_Darkshard Crystal|r].
.complete 40520,3 
step
.goto 750,57.84,10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mu'sha's Tears|r near the waterfall.
.complete 40520,2 
step
#completewith next
#label HulnsWarStart2
#hidewindow
.complete 39983,1 
step
#completewith next
#label Turn in To See the Past
.goto 652,49.55,17.57,10,0
.goto 652,51.26,32.55,10,0
.goto 652,51.25,43.69,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.turnin 40520 >>Turn in To See the Past
.accept 39983 >>Accept Huln's War - The Arrival
.complete 39983,1 
.target Spiritwalker Ebonhorn
.skipgossip 98825,1
step
#completewith Turn in To See the Past
.goto 652,74.76,75.05,110 >>Enter the lowest level of Thunder Totem
step
#requires Turn in To See the Past
.goto 652,74.76,75.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r.
.turnin 40520 >>Turn in To See the Past
.accept 39983 >>Accept Huln's War - The Arrival
.complete 39983,1 
.target Spiritwalker Ebonhorn
.skipgossip 98825,1
step
#completewith Tichondrius
+Use |T134174:0|t[Gore Charge] as your main AoE; it also greatly boosts movement speed.
*Use |T644382:0|t[Wild Carve] as a strong frontal when |T134174:0|t[Gore Charge] is on cooldown.
*Use |T135127:0|t[Harpoon Stomp] to leap to a target.
*Use |T136041:0|t[Eche'ro's Blessing] to heal yourself.
step
#loop
.goto 697,29.45,39.32,40,0
.goto 697,30.08,41.77,40,0
.goto 697,33.54,37.57,40,0
#title |cFFFCDC00Follow the Arrow|r
>>Kill |cRXP_ENEMY_Demons|r
.complete 39983,2 
step
.goto 697,29.45,39.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Unng Ak|r.
.turnin 39983 >>Turn in Huln's War - The Arrival
.accept 40112 >>Accept Huln's War - Malorne's Favored
.target Unng Ak
step
.goto 697,27.96,47.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eche'ro|r.
.turnin 40112 >>Turn in Huln's War - Malorne's Favored
.accept 39988 >>Accept Huln's War - Stormrage
.target Eche'ro
step
.goto 697,27.90,51.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r.
.turnin 39988 >>Turn in Huln's War - Stormrage
.accept 39990 >>Accept Huln's War - Reinforcements
.target Malfurion Stormrage
step
#title |cFFFCDC00Follow the Arrow|r
.goto 697,26.73,51.69
>>Kill |cRXP_ENEMY_Demons|r
.complete 39990,1 
step
.goto 697,27.90,51.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r.
.turnin 39990 >>Turn in Huln's War - Reinforcements
.accept 40388 >>Accept Huln's War - Shadowsong
step
.goto 697,31.34,52.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarod Shadowsong|r
.turnin 40388 >>Turn in Huln's War - Shadowsong
.target Jarod Shadowsong
.accept 39992 >>Accept Huln's War - The Nathrezim
step
#label Tichondrius
.goto 697,33.27,49.99
>>Kill |cRXP_ENEMY_Tichondrius|r
.complete 39992,1 
.mob Tichondrius
step
#completewith next
#label Huln's War - The Nathrezim
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 39992 >>Turn in Huln's War - The Nathrezim
.target Spiritwalker Ebonhorn
step
#completewith Huln's War - The Nathrezim
#title |cFFFCDC00Spam Macro|r
.goto 619,45.64,67.7
.zone 652 >>|cRXP_WARN_In the "Active Items" section|r There is a macro, spam it.
.macro Leave Vehicle,6656430 >> /leavevehicle
step
#requires Huln's War - The Nathrezim
.goto 652,74.86,75.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 39992 >>Turn in Huln's War - The Nathrezim
.accept 38916 >>Accept Secrets of Highmountain
.target Spiritwalker Ebonhorn
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Secrets of Highmountain Midnight
#internal
step
.goto 652,74.65,75.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.accept 38916 >>Accept Secrets of Highmountain
.target Spiritwalker Ebonhorn
step
#completewith next
#label Secrets of HighmountainZ
.goto 652,64.33,77.35,15,0
.goto 652,41.87,74,15,0
.goto 652,25.81,80.84,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 38916 >>Turn in Secrets of Highmountain
.target Spiritwalker Ebonhorn
.accept 39575 >>Accept The Path of Huln
.disablecheckbox
step
#completewith Secrets of HighmountainZ
#title |cFFFCDC00Leave Building|r
.goto 650,44.88,65.71,185 >>Leave the building.
step
#requires Secrets of HighmountainZ
#label SecretsofHighmountainEnd1
.goto 650,44.88,65.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 38916 >>Turn in Secrets of Highmountain
.target Spiritwalker Ebonhorn
.accept 39575 >>Accept The Path of Huln
.timer 68,RP
step
>>Follow |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.complete 39575,1 
.target Spiritwalker Ebonhorn
step
#label SecretsofHighmountainStart2
#completewith The Backdoor
+|cRXP_WARN_You can still skyride here, even though it’s a cave|r.
step
.goto 657,43.23,28.23
#title |cFFFCDC00Follow the Arrow|r
>>Jump into the abyss.
.complete 39575,2 
step
#label SecretsofHighmountainEnd2
.goto 657,43.23,28.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 39575 >>Turn in The Path of Huln
.target Spiritwalker Ebonhorn
.accept 40219 >>Accept In Defiance of Deathwing
step
.goto 657,38.66,47.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 40219,1 
step
#label SecretsofHighmountainStart3
.goto 657,51.41,30.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 40219,2 
step
.goto 657,49.50,54.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 40219,3 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r |cRXP_WARN_next to you|r.
.turnin 40219 >>Turn in In Defiance of Deathwing
.target Spiritwalker Ebonhorn
.accept 39578 >>Accept Titanic Showdown
step
.goto 657,47.98,70.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 39578,1 
step
.goto 657,51.37,69.18
>>Kill |cRXP_ENEMY_Vision of Deathwing|r
.complete 39578,2 
.mob Vision of Deathwing
step
.goto 657,49.17,72.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 39578 >>Turn in Titanic Showdown
.target Spiritwalker Ebonhorn
.accept 39577 >>Accept An Ancient Secret
step
.goto 657,56.67,77.71,15,0
.goto 657,59.68,77.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 39577,1 
.timer 29,RP
step
.goto 657,62.95,75.25
>>Kill |cRXP_ENEMY_Obsidian Reclaimers|r and |cRXP_WARN_wait for the Roleplay|r.
.complete 39577,2 
.timer 11.5,RP
.mob Obsidian Reclaimer
step
.goto 657,61.3,72.4
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 39577,3 
step
#label Secrets of Highmountain
.goto 657,61.3,72.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r
.turnin 39577 >>Turn in An Ancient Secret
.target Ebyssian
.accept 39579 >>Accept The Backdoor
step
#completewith next
#label The Backdoor
.goto 657,50.88,86.67,20,0
.goto 658,53.99,43.44,20,0
.goto 658,49.42,85.5,20,0
.goto 650,47.54,84.39,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39579 >>Turn in The Backdoor
.target Mayla Highmountain
.accept 39580 >>Accept The High Chieftain
.disablecheckbox
step
#completewith The Backdoor
#title |cFFFCDC00Leave Cave|r
.goto 650,47.47,84.75,30 >>Leave the Cave
step
#requires The Backdoor
#label SecretsofHighmountainEnd3
.goto 650,47.47,84.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39579 >>Turn in The Backdoor
.target Mayla Highmountain
.accept 39580 >>Accept The High Chieftain
step
#completewith next
#label High Chieftain
.goto 650,46.15,80.91,45,0
.goto 650,45.05,75.12,45,0
.goto 650,44.76,68.44,45,0
.goto 652,27.83,79.13,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39580 >>Turn in The High Chieftain
.target Mayla Highmountain
step
#completewith High Chieftain
*|cRXP_WARN_fly over the mountain|r
.goto 652,54.84,63.23,50 >>Enter the lowest level of Thunder Totem.
step
#requires High Chieftain
.goto 652,54.84,63.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39580 >>Turn in The High Chieftain
.target Mayla Highmountain
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) The Skyhorn Tribe Midnight
#internal
step
.goto 652,54.80,63.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.accept 38913 >>Accept The Skyhorn Tribe
.target Mayla Highmountain













step

.goto 650,52.46,44.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 38913 >>Turn in The Skyhorn Tribe
.target Lasan Skyhorn
.accept 39318 >>Accept Nursing the Wounds
step
.goto 650,53.73,48.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Windmaster Julan|r
.complete 39318,1 
.skipgossipid 44135
.target Windmaster Julan
step
.goto 650,53.73,48.24
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,1 
.usespell 189168
step
.goto 650,53.97,48.63
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,3 
.usespell 189168
step
.goto 650,53.34,48.15
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,4 
.usespell 189168
step
.goto 650,53.17,47.69
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,5 
.usespell 189168
step
.goto 650,52.92,47.52
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,6 
.usespell 189168
step
.goto 650,52.8,46.39
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,7 
.usespell 189168
step
.goto 650,52.93,46.03
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,8 
.usespell 189168
step
.goto 650,52.47,44.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39318 >>Turn in Nursing the Wounds
.target Lasan Skyhorn
.accept 38910 >>Accept Rocs vs Eagles
step
#label TheSkyhornTribeStart1
#title Eagle (1/7)
.goto 650,50.65,42.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,1 
.target Captive Great Eagle
step
#title Eagle (2/7)
.goto 650,51.06,40.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,2 
.target Captive Great Eagle
step
#title Eagle (3/7)
.goto 650,51.33,41.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,3 
.target Captive Great Eagle
step
#title Eagle (4/7)
.goto 650,52.88,42.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,4 
.target Captive Great Eagle
step
#title Eagle (5/7)
.goto 650,52.47,40.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,5 
.target Captive Great Eagle
step
#title Captive Great Eagle (6/7)
#label TheSkyhornTribeEnd1
.goto 650,52.58,40.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,6 
.target Captive Great Eagle
step
#title Captive Great Eagle (7/7)
.goto 650,52.27,38.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,7 
.target Captive Great Eagle
step
#label TheSkyhornTribeStart2
.goto 650,52.32,36.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 38910 >>Turn in Rocs vs Eagles
.target Lasan Skyhorn
.accept 39321 >>Accept The Three
.accept 39429 >>Accept Assaulting the Haglands
step
#completewith Skywhisker Loyalist slain
>>Kill |cRXP_ENEMY_Skywhiskers|r and |cRXP_ENEMY_Crawliacs|r
.complete 39429,2 
.complete 39429,1 
.mob Skywhisker Loyalist
.mob Crawliac Hagfeathers
.mob Deathscreamers
step
#label TheSkyhornTribeEnd2
.goto 650,52.52,33.3
>>Kill |cRXP_ENEMY_Ragi the Hexxer|r
.complete 39321,1 
.mob Ragi the Hexxer
step
.goto 650,50.13,32.11
>>Kill |cRXP_ENEMY_Agara Deathsong|r
.complete 39321,2 
.mob Agara Deathsong
step
#label Skywhisker Loyalist slain
.goto 650,50.58,35.44
>>Kill |cRXP_ENEMY_Ugla the Hag|r
.complete 39321,3 
.mob Ugla the Hag
step
#loop
.goto 650,49.44,36.26,30,0
.goto 650,49.68,31.82,30,0
.goto 650,50.79,31.8,30,0
.goto 650,52.8,33.62,30,0
.goto 650,53.24,35.49,30,0
>>Kill |cRXP_ENEMY_Skywhiskers|r and |cRXP_ENEMY_Crawliacs|r
.complete 39429,2 
.complete 39429,1 
.mob Skywhisker Loyalist
.mob Crawliac Hagfeathers
.mob Deathscreamers
step
.goto 650,49.22,36.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39321 >>Turn in The Three
.target Lasan Skyhorn
.turnin 39429 >>Turn in Assaulting the Haglands
.accept 39322 >>Accept The Witchqueen
step
.goto 650,46.36,39.94
>>Kill |cRXP_ENEMY_High Crawliac|r
.complete 39322,1 
.mob High Crawliac
step
.goto 650,45.68,39.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39322 >>Turn in The Witchqueen
.target Lasan Skyhorn
.accept 39387 >>Accept The Skies of Highmountain
step
.goto 750,42.16,33.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan|r
.complete 39387,1 
.timer 120
.skipgossipid 44839
.target Lasan Skyhorn
step
#label The Skyhorn Tribe
.goto 652,54.79,63.18
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 39387,2
step
.goto 652,54.89,63.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39387 >>Turn in The Skies of Highmountain
.target Mayla Highmountain
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) The Bloodtotem Tribe Midnight
#internal
step
.goto 652,54.80,63.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.turnin 38909 >>Turn in Get to High Ground
.accept 38912 >>Accept The Bloodtotem Tribe
.target Mayla Highmountain
step
#label BloodTotemStart1
.goto 650,39.42,36.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oakin Ironbull|r
.turnin 38912 >>Turn in The Bloodtotem Tribe
.target Oakin Ironbull
.accept 39372 >>Accept Witch of the Wood
.accept 39373 >>Accept Hags of a Feather
step
.goto 650,39.00,37.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.accept 39873 >>Accept I Have a Bad Feeling About This
.target Navarrogg
step
.goto 650,38.99,34.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cup|r
.complete 39873,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Witchwood Hag|r. Loot them for |T132918:0|t[|cRXP_LOOT_Hag Feather|r].
.complete 39373,1 
.mob Witchwood Hag
step
#label BloodTotemEnd1
.goto 650,41.23,27.98
>>Kill |cRXP_ENEMY_Witch of the Wood|r
.complete 39372,1 
.mob Witch of the Wood
step
#loop
.goto 650,42.49,29.4,30,0
.goto 650,41.54,32.94,30,0
.goto 650,40.4,32.37,30,0
.goto 650,41.1,28.37,30,0
>>Kill |cRXP_ENEMY_Witchwood Hag|r. Loot them for |T132918:0|t[|cRXP_LOOT_Hag Feather|r].
.complete 39373,1 
.mob Witchwood Hag
step
#label BloodTotemStart2
.goto 650,39.00,37.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r
.turnin 39873 >>Turn in I Have a Bad Feeling About This
.target Navarrogg's Cage
step
.goto 650,39.42,36.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oakin Ironbull|r
.turnin 39372 >>Turn in Witch of the Wood
.target Oakin Ironbull
.turnin 39373 >>Turn in Hags of a Feather
.accept 39374 >>Accept An Audience with Torok
step
.goto 650,39.13,34.75
#title |cFFFCDC00Follow the Arrow|r
.complete 39374,1 
step
#label BloodTotemEnd2
.goto 650,39.26,35.88,10,0
.goto 650,39.18,34.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oakin Ironbull|r
.turnin 39374 >>Turn in An Audience with Torok
.target Oakin Ironbull
.accept 39455 >>Accept Cave of the Blood Trial
step
#completewith next
#label Harpy Placed on Altar
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r
.complete 39455,1 
step
#completewith Harpy Placed on Altar
#title |cFFFCDC00Enter Cave|r
.goto 650,37.62,33.52,15 >>Enter the Cave
step
#requires Harpy Placed on Altar
.goto 653,54.04,28.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r
.complete 39455,1 
step
#label BloodTotemStart2.5
.goto 653,60.03,28.53
>>Kill |cRXP_ENEMY_Bloodtotem Warmonger|r
.complete 39455,2 
.mob Bloodtotem Warmonger
step
.goto 653,59.71,32.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torok Bloodtotem|r
.turnin 39455 >>Turn in Cave of the Blood Trial
.target Torok Bloodtotem
.accept 39860 >>Accept Rite of Blood
step
.goto 653,52.01,48.1,15,0
.goto 653,40.37,61.7,10,0
.goto 653,41.12,70.28,10,0
.goto 653,40.78,79.92
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Cross the Bridge|r
.complete 39860,1 
.timer 15,RP
step
.goto 653,40.41,84.29
>>Kill |cRXP_ENEMY_Marakhan|r
.complete 39860,2 
.mob Marakhan
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r |cRXP_WARN_next to you|r.
.turnin 39860 >>Turn in Rite of Blood
.target Navarrogg
.accept 39381 >>Accept Rock Troll in a Hard Place
.complete 39381,1 
.skipgossipid 44308
.target Navarrogg
step
.goto 650,45.21,32.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 39381 >>Turn in Rock Troll in a Hard Place
.target Navarrogg
.accept 39391 >>Accept Pet Rocks
.accept 39425 >>Accept Stonedark Crystal
.accept 39588 >>Accept They Will Pay With Blood
step
#completewith next
#label Rescue Gravel
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gravel|r
.complete 39391,2 
.target Gravel
step
#completewith Rescue Gravel
#title |cFFFCDC00Leave Cave|r
.goto 650,44.9,31.95,15 >>Leave the Cave
step
#requires Rescue Gravel
#completewith Stonedark Focus
>>Kill |cRXP_ENEMY_Feltotems|r. Loot them for |T463856:0|t[|cRXP_LOOT_Stonedark Focus|r].
.complete 39588,1 
.complete 39425,1 
.mob Feltotem Bloodbinder
.mob Feltotem Warmonger
step
#requires Rescue Gravel
.goto 650,43.54,33.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gravel|r
.complete 39391,2 
.target Gravel
step
#label BloodTotemEnd2.5
.goto 650,43.53,28.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r
.complete 39391,1 
.target Shard
step
#label Stonedark Focus
.goto 650,45.32,27.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gravel|r
.complete 39391,3 
step
#loop
.goto 650,46.72,28.1,40,0
.goto 650,47.71,29.76,40,0
.goto 650,43.82,30.84,40,0
.goto 650,43.29,33.2,40,0
.goto 650,44.33,28.42,40,0
>>Kill |cRXP_ENEMY_Feltotems|r. Loot them for |T463856:0|t[|cRXP_LOOT_Stonedark Focus|r].
.complete 39588,1 
.complete 39425,1 
.mob Feltotem Bloodbinder
.mob Feltotem Warmonger
step
#completewith next
#label They Will Pay With Blood
.goto 650,45.06,31.93,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 39425 >>Turn in Stonedark Crystal
.target Navarrogg
.turnin 39588 >>Turn in They Will Pay With Blood
.turnin 39391 >>Turn in Pet Rocks
.accept 39426 >>Accept Blood Debt
step
#completewith They Will Pay With Blood
#title |cFFFCDC00Enter Cave|r
.goto 650,45.21,32.52,30 >>Enter the Cave
step
#requires They Will Pay With Blood
.goto 650,45.21,32.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 39425 >>Turn in Stonedark Crystal
.target Navarrogg
.turnin 39588 >>Turn in They Will Pay With Blood
.turnin 39391 >>Turn in Pet Rocks
.accept 39426 >>Accept Blood Debt
step
#completewith next
#label Torok Bloodtotem
.goto 650,45.09,31.78,15,0
>>Kill |cRXP_ENEMY_Torok Bloodtotem|r
.complete 39426,1 
.mob Torok Bloodtotem
step
#completewith Torok Bloodtotem
#title |cFFFCDC00Leave Cave|r
.goto 650,49.53,23.62,500 >>Leave the Cave
step
#requires Torok Bloodtotem
.goto 650,49.53,23.62
>>Kill |cRXP_ENEMY_Torok Bloodtotem|r.
.complete 39426,1 
.mob Torok Bloodtotem
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r |cRXP_WARN_next to you|r.
.turnin 39426 >>Turn in Blood Debt
.target Navarrogg
.accept 40229 >>Accept Step into the Dark
step
#completewith next
#label Step into the Dark
.goto 659,21.07,80.68,15,0
.goto 659,23.3,73.82,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 40229 >>Turn in Step into the Dark
.accept 39456 >>Accept Unexpected Allies
.disablecheckbox
step
#completewith Step into the Dark
#title |cFFFCDC00Enter Cave|r
.goto 659,40.25,53.17,110 >>Enter the Cave
step
#requires Step into the Dark
.goto 659,40.25,53.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 40229 >>Turn in Step into the Dark
.accept 39456 >>Accept Unexpected Allies
.target Navarrogg
step
#title |cFFFCDC00Leave Cave|r
.isOnQuest 39456
.goto 659,22.87,75.97,10,0
.goto 650,42.73,25.36,15 >>Leave the Cave
step
.goto 750,42.16,33.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.complete 39387,1 
.timer 61,RP1
.skipgossipid 44839
.target Lasan Skyhorn
step
.goto 750,34.84,44.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.complete 39456,1 
.timer 30,RP2
.skipgossipid 44200 
.target Navarrogg
step
.isQuestAvailable account,40475
.goto 750,32.35,41.81
.cast 3365>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.isQuestAvailable account,40472
.goto 750,50.6,75.36
.cast 3365>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label Witness the Stonedark Ritual
#title |cFFFCDC00Follow the Arrow|r
.goto 652,25.14,80.45,10,0
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 39456,2 
.complete 39387,2
step
#completewith Witness the Stonedark Ritual
#title |cFFFCDC00Enter Building|r
.goto 652,54.79,63.18,105 >>Enter the Building
step
#requires Witness the Stonedark Ritual
#label The Bloodtotem Tribe
.goto 652,54.79,63.18
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 39456,2 
.complete 39387,2
step
.goto 652,54.80,63.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39456 >>Turn in Unexpected Allies
.turnin 39387 >>Turn in The Skies of Highmountain
.turnin 39580 >>Turn in The High Chieftain
.accept 38915 >>Accept Battle of Snowblind Mesa
.target Mayla Highmountain
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Battle of Snowblind Mesa Midnight
#internal
step
.goto 652,54.80,63.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.accept 38915 >>Accept Battle of Snowblind Mesa
.target Mayla Highmountain
step
#completewith next
#hidewindow
#label Battle of Snowblind Mesa
.goto 652,25.34,81.39,10,0
.turnin 38915 >>Turn in Battle of Snowblind Mesa
.accept 39776 >>Accept Battle Worms
.disablecheckbox
step
#completewith Battle of Snowblind Mesa
.goto 650,53.28,64.06,450 >>Leave Thunder Totem
step
#requires Battle of Snowblind Mesa
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r and |cRXP_FRIENDLY_Navarrogg|r.
.turnin 38915 >>Turn in Battle of Snowblind Mesa
.accept 39776 >>Accept Battle Worms
.goto 650,53.28,64.06
.target +Mayla Highmountain
.accept 39862 >>Accept The Siegebrul
.goto 650,53.38,64.11
.target +Navarrogg
.accept 39777 >>Accept Buy Us Time
.goto 650,53.36,64.01
.target +Jale Rivermane
step
#completewith BattleofSnowblindMesaEnd2
>>Kill |cRXP_ENEMY_Mightstones|r
.complete 39777,1 
.mob Mightstone Flanker
.mob Mightstone Slinger
step
.goto 650,52.95,58.46
>>Use the |cRXP_WARN_ExtraActionButton|r to assist with killing |cRXP_ENEMY_Naxa|r.
.complete 39776,1 
.usespell 195149
.mob Naxa
step
.goto 650,52.56,57.04
>>Kill |cRXP_ENEMY_Siegebrul Olgrul|r
.complete 39862,1 
.mob Siegebrul Olgrul
step
#label BattleofSnowblindMesaEnd2
.goto 650,53.93,56.87
>>Use the |cRXP_WARN_ExtraActionButton|r to assist with killing |cRXP_ENEMY_Xist|r.
.complete 39776,3 
.usespell 195144
.mob Xist
step
#label Arxas
.goto 650,54.59,58.99
>>Use the |cRXP_WARN_ExtraActionButton|r to assist with killing |cRXP_ENEMY_Arxas|r.
.complete 39776,2 
.usespell 195144
.mob Arxas
step
#loop
.goto 650,53.33,63.08,40,0
.goto 650,53.39,57.45,40,0
.goto 650,54.73,58.99,40,0
>>Kill |cRXP_ENEMY_Mightstones|r
.complete 39777,1 
.mob Mightstone Flanker
.mob Mightstone Slinger
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jale Rivermane|r, |cRXP_FRIENDLY_Navarrogg|r and |cRXP_FRIENDLY_Mayla Highmountain|r.
.turnin 39777 >>Turn in Buy Us Time
.goto 650,53.36,64.01
.target +Jale Rivermane
.turnin 39862 >>Turn in The Siegebrul
.goto 650,53.38,64.12
.target +Navarrogg
.turnin 39776 >>Turn in Battle Worms
.accept 42088 >>Accept Evacuate Snowmane
.goto 650,53.28,64.05
.target +Mayla Highmountain
step
#completewith next
#label Tarvim Daywalker evacuated
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 42088,2 
step
#completewith Tarvim Daywalker evacuated
.goto 650,53.32,67.11
.gossipoption 45373 >>Talk to |cRXP_FRIENDLY_Tarvim Daywalker|r
.timer 4.2,RP
.target Tarvim Daywalker
step
#requires Tarvim Daywalker evacuated

#sticky
#title |cFFFCDC00Follow the Arrow|r
.complete 42088,2 
step
#requires Tarvim Daywalker evacuated
.goto 650,53.12,66.99,5,0
.goto 650,53.33,69.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Nefu|r
.complete 42088,3 
.skipgossipid 45374
.target Old Nefu
step
#completewith next
#label Red Skymane
#title |cFFFCDC00Follow the Arrow|r
.complete 42088,1 
step
#completewith Red Skymane
.goto 650,51.67,66.52,10,0
.goto 650,52.01,66.67
.gossipoption 45372 >>Talk to |cRXP_FRIENDLY_Red Skymane|r
.timer 4,RP
.target Red Skymane
step
#requires Red Skymane
.goto 650,51.69,66.49,10,0
.goto 650,52.3,65.91
#title |cFFFCDC00Follow the Arrow|r
>>Leave the Tent
.complete 42088,1 
step
.goto 650,52.28,65.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 42088 >>Turn in Evacuate Snowmane
.target Mayla Highmountain
.accept 42512 >>Accept Highmountain Stands
step
.goto 650,53.84,65.53
#title |cFFFCDC00Follow the Arrow|r
.complete 42512,1 
step
.goto 650,53.25,64.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 42512 >>Turn in Highmountain Stands
.target Lasan Skyhorn
.accept 40594 >>Accept Justice Rains from Above
step
.goto 650,53.17,64.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_War Eagle|r
.complete 40594,1 
.target War Eagle
step
>>Use |T132172:0|t[Skyhorn Strafing Run] and |T1322283:0|t[Stonedark Brulfist] on the understone forces on cooldown.
.complete 40594,2 
step
#completewith next
#label Justice Rains from Above
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 40594 >>Turn in Justice Rains from Above
.target Lasan Skyhorn
.accept 39780 >>Accept The Underking
.disablecheckbox
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#completewith Justice Rains from Above
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Justice Rains from Above
.goto 650,53.15,68.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 40594 >>Turn in Justice Rains from Above
.target Lasan Skyhorn
.accept 39780 >>Accept The Underking
step
.goto 650,53.19,70.89
#title |cFFFCDC00Follow the Arrow|r
.complete 39780,1 
.timer 10,RP
step
#label Battle of Snowblind Mesa2
.goto 650,53.15,70.77
>>Kill |cRXP_ENEMY_Wrath of Dargrul|r
.complete 39780,2 
.mob Wrath of Dargrul
step
.goto 650,53.19,70.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39780 >>Turn in The Underking
.accept 39781 >>Accept Neltharion's Lair: Death to the Underking
.target Mayla Highmountain
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Isle of Dorn Campaign
#internal
step << Alliance
#label StateUnionStart
.goto 84,62.34,72.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r.
.accept 81930 >>Accept The War Within
step << Horde
.goto 85,49.60,77.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r.
.accept 78713 >>Accept The War Within
.target Thral
step
.isOnQuest 78713,81930
>>Use the |T4549141:0|t[Teleportation Scroll] to teleport to Silithus.
.complete 78713,1 << Horde 
.complete 81930,1 << Alliance 
.use 227669
step
#hidewindow
.isOnQuest 78713,81930
.countdown 6 >>test
step
.isOnQuest 78713,81930
.aura -255152
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zidormi|r.
.goto 81,78.93,21.97
.target Zidormi
.skipgossipid 47635
step
.isOnQuest 78713,81930
.aura -264606
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zidormi|r.
.goto 81,78.93,21.97
.target Zidormi
.skipgossipid 47635
step
.isOnQuest 78713,81930
.aura -262016
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zidormi|r.
.goto 81,78.93,21.97
.target Zidormi
.skipgossipid 47635
step
.isOnQuest 78713,81930
.itemcount 227669,1
.goto 81,41.89,45.09,150 >>Use the |T4549141:0|t[Teleportation Scroll] again.
.use 227669
step << Horde
.isQuestAvailable account,79197
.goto 81,41.96,45.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r.
.turnin 78713 >>Turn in The War Within
.accept 78714 >>Accept A Poor Reception
.target Thrall
step << Alliance
.goto 81,41.93,45.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r.
.turnin 81930 >>Turn in The War Within
.target +Lady Jaina Proudmoore
step << Alliance
.isQuestAvailable account,79197
.goto 81,41.96,45.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r.
.accept 78714 >>Accept A Poor Reception
.target +Thrall
step
.isQuestAvailable 78715
.goto 81,41.96,45.06
.isQuestTurnedIn account,79197
.gossipoption 123176 >>Talk to |cRXP_FRIENDLY_Thrall|r.
.skipto step,ViolentImpact2
step
.goto 81,43.19,44.50
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Translocator|r.
.complete 78714,1 
step
.goto 2321,50.08,64.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magni Bronzebeard|r.
.turnin 78714 >>Turn in A Poor Reception
.accept 78715 >>Accept Azeroth's Voice
.target Magni Bronzebeard
step
#loop
.goto 2321,56.48,64.70,15,0
.goto 2321,50.20,74.08,15,0
.goto 2321,43.82,64.62,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Consoles|r
.complete 78715,1 
step
.goto 2321,50.15,65.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magni|r.
.complete 78715,2 
.skipgossip 213624,1
.target Magni
step
.goto 2321,49.54,58.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r.
.turnin 78715 >>Turn in Azeroth's Voice
.accept 78716 >>Accept Painful Lessons
.target Lady Jaina Proudmoore
step
.goto 2321,53.32,58.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Dalaran|r.
.complete 78716,1 
step
.goto 619,45.85,64.51
.complete 78716,2 
step
.goto 629,42.96,60.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 78716 >>Turn in Painful Lessons
.target Archmage Khadgar
step
.goto 629,40.43,54.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r.
.accept 80500 >>Accept The Bronzebeard Family
.target Moira Thaurissan
step
#completewith TalkToBrann
#label TeleporterUsedA
.goto 629,64.84,20.84,2 >>Step on the teleporter
step
#requires TeleporterUsedA
#completewith TalkToBrann
.goto 627,53.05,52.13,10,0
.goto 627,52.09,56.93,5 >>Enter the Dalaran Visitor Center
step
#label TalkToBrann
.goto 627,50.77,55.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann|r.
.skipgossip 214669,1
.complete 80500,1 
.target Brann
step
#completewith next
#label Bronzebeard Family
.goto 627,52.07,56.92,5,0
.goto 627,53.2,52.14,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r.
.turnin 80500 >>Turn in The Bronzebeard Family
.target Moira Thaurissan
step
#completewith Bronzebeard Family
.goto 627,49.20,47.77,2 >>Step on the teleporter
step
#requires Bronzebeard Family
.goto 629,48.57,50.65,15,0
.goto 629,40.43,54.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r.
.turnin 80500 >>Turn in The Bronzebeard Family
.target Moira Thaurissan
step
.isOnQuest 81966
.goto 629,43.42,54.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r.
.turnin 81966 >>Turn in Slept Like a Rock
.target Moira Thaurissan
step
.goto 629,45.26,57.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magni Bronzebeard|r |cRXP_WARN_after the roleplay|r.
.accept 78717 >>Accept A Mysterious Warning
.target Magni Bronzebeard
step
.goto 629,42.88,59.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.complete 78717,1 
.skipgossipid 121395
.target Archmage Khadgar
step
.goto 629,41.05,62.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 78717 >>Turn in A Mysterious Warning
.target Archmage Khadgar
.accept 78719 >>Accept Citizens of Dalaran
step
.goto 629,47.09,49.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r.
.accept 78721 >>Accept Meet the Team
.target Brann Bronzebeard
step
.goto 629,56.68,32.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Drenden|r.
.accept 78718 >>Accept Strengthen the Wards
.target Archmage Drenden
step
#completewith Food
#label TeleporterUsedB
.goto 629,64.84,20.84,2 >>Step on the teleporter
step
#requires TeleporterUsedB
#label Gate2
#completewith Food
.goto 627,52.22,42.16,5,0
.goto 627,52.85,35,15 >>Visit the Food Stand
step
#label Food
.goto 627,52.85,35
>>|cRXP_WARN_Dismount|r and use the |cRXP_WARN_ExtraActionButton|r near |cRXP_FRIENDLY_Fialla Sweetberry|r.
.complete 78719,1,1 
.target Fialla Sweetberry
step
.goto 627,51.2,22.91
>>Use the |T135467:0|t[Tuning Wand] near the |cRXP_PICK_Bubble|r.
.complete 78718,1,1 
.use 220483
step
#completewith next
#label Herbalism Garden
>>|cRXP_WARN_Dismount|r and use the |cRXP_WARN_ExtraActionButton|r |cRXP_WARN_inside the Herbalism Garden|r.
.complete 78719,1,2 
step
#completewith Herbalism Garden
.goto 627,43.54,35.52,13 >>Visit the Herbalism Garden
step
#requires Herbalism Garden
.goto 627,42.7,34.29
>>|cRXP_WARN_Dismount|r and use the |cRXP_WARN_ExtraActionButton|r |cRXP_WARN_inside the Herbalism Garden|r.
.complete 78719,1,2 
step
.goto 627,37.55,46.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elise Starseeker|r.
.complete 78721,1 
.skipgossipid 121860
.target Elise Starseeker
step
.goto 627,30.42,48.89
>>Use the |T135467:0|t[Tuning Wand] near the |cRXP_PICK_Bubble|r |cRXP_WARN_inside the Violet Citadel|r.
.complete 78718,1,2 
.use 220483
step
.goto 627,44.88,72.97
>>Use the |T135467:0|t[Tuning Wand] near the |cRXP_PICK_Bubble|r |cRXP_WARN_in front of the bank|r.
.complete 78718,1,3 
.use 220483
step
#completewith next
#label Arsenal Absolute
.goto 627,53.27,61.21,10,0
>>Use the |cRXP_WARN_ExtraActionButton|r |cRXP_WARN_near|r |cRXP_FRIENDLY_Valaden Silverblade|r |cRXP_WARN_inside the house|r.
.complete 78719,1,3 
.use 220483
.target Valaden Silverblade
step
#completewith Arsenal Absolute
.goto 627,54.18,61.22,10 >>Enter the Arsenal Absolute
step
#requires Arsenal Absolute
.goto 627,54.18,61.22
>>Use the |cRXP_WARN_ExtraActionButton|r |cRXP_WARN_near|r |cRXP_FRIENDLY_Valaden Silverblade|r |cRXP_WARN_inside the house|r.
.complete 78719,1,3 
.use 220483
.target Valaden Silverblade
step
.goto 627,53.22,60.45,5,0
.goto 627,61.31,62.13
>>Use the |T135467:0|t[Tuning Wand] near the |cRXP_PICK_Bubble|r.
.complete 78718,1,4 
.use 220483
step
#completewith next
#label Strengthen the Wards
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Drenden|r.
.turnin 78718 >>Turn in Strengthen the Wards
.target Archmage Drenden
step
#completewith Strengthen the Wards
.goto 627,49.06,47.4,5 >>Step on the teleporter
step
#requires Strengthen the Wards
.goto 629,56.41,33.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Drenden|r.
.turnin 78718 >>Turn in Strengthen the Wards
.target Archmage Drenden
step
.goto 629,47.14,49.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r.
.turnin 78721 >>Turn in Meet the Team
.target Brann Bronzebeard
step
.goto 629,41.24,62.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 78719 >>Turn in Citizens of Dalaran
.target Archmage Khadgar
.accept 78722 >>Accept To Khaz Algar!
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.complete 78722,1 
.skipgossip
.target Archmage Khadgar
step
.goto 2305,50.45,50.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 78722 >>Turn in To Khaz Algar!
.target Alleria Windrunner
.accept 79105 >>Accept Breach
step
#label DalaranStart
#hidewindow
#completewith Nerubians
#loop
.goto 2305,57.36,52.31,15,0
.goto 2305,57.61,56.63,15,0
.goto 2305,57.82,61.85,15,0
.goto 2305,58.08,74.48,15,0
.goto 2305,54.47,62.09,15,0
.goto 2305,53.34,66.45,15,0
.goto 2305,53.29,62.26,15,0
.goto 2305,51.54,66.14,15,0
.goto 2305,51.73,62.96,15,0
.goto 2305,53.29,53.31,15,0
.goto 2305,52.14,58.77,15,0
.goto 2305,45.62,66.06,15,0
.goto 2305,45.52,62.31,15,0
.goto 2305,43.55,58.01,15,0
.goto 2305,46.19,57.5,15,0
.goto 2305,45.92,54.44,15,0
.goto 2305,43.78,53.96,15,0
.goto 2305,43.12,58.78,15,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Nerubians|r.
.complete 79105,2 
.mob Nerubians
.mob Small Threadling
.mob Rampaging Threadling
.mob Nerubian War-Weaver
.mob Nerubian Venomspitter
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Citizens|r.
.complete 79105,1 
.target Sabriana Sorrowgaze
.target Lianna Tai
.target Glaciela Rimebang
.target Professor Pallin
.target Imindril Spearsong
.target Kizi Copperclip
.target Fialla Sweetberry
.target Lucian Trias
.target Tassia Whisperglen
.target Aerith Primrose
.target Mei Francis
step
#label Nerubians
>>Kill |cRXP_ENEMY_Nerubians|r.
.complete 79105,2 
.mob Nerubians
.mob Small Threadling
.mob Rampaging Threadling
.mob Nerubian War-Weaver
.mob Nerubian Venomspitter
step
.goto 2305,35.70,71.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 79105 >>Turn in Breach
.target Alleria Windrunner
.accept 79106 >>Accept Rupture
step
.goto 2305,39.23,67.41,10,0
.goto 2305,39.89,62.28
#title |cFFFCDC00Follow the Arrow|r.
.complete 79106,1 
step
.goto 2305,41.45,60.77,10,0
.goto 2306,27.63,53.47,20,0
.goto 2306,42.22,51.92
#title |cFFFCDC00Follow the Arrow|r.
.complete 79106,2 
step
#title Citizens freed (1/5)
.goto 2306,51.29,51.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Victims|r.
.complete 79106,3,1 
.mob Skitterling
.mob Skitterling Chemist
.target Webbed Victims
step
#title Citizens freed (2/5)
.goto 2306,51.2,58.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Victims|r.
.complete 79106,3,2 
.mob Skitterling
.mob Skitterling Chemist
.target Webbed Victim
step
#title Citizens freed (3/5)
.goto 2306,54.97,57.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Victims|r.
.complete 79106,3,3 
.mob Skitterling
.mob Skitterling Chemist
.target Webbed Victim
step
#title Citizens freed (4/5)
.goto 2306,54.74,52.12,10,0
.goto 2306,57.91,53.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Victims|r.
.complete 79106,3,4 
.mob Skitterling
.mob Skitterling Chemist
.target Webbed Victim
step
#title Citizens freed (5/5)
.goto 2306,60.86,48.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Victims|r.
.complete 79106,3,5 
.mob Skitterling
.mob Skitterling Chemist
.target Webbed Victim
step
.goto 2306,66.80,50.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sewer Gate|r.
.complete 79106,4 
step
.goto 2307,75.23,68.11,10,0
.goto 2307,75.23,63.53,10,0
.goto 2307,72.63,58.07
#title |cFFFCDC00Follow the Arrow|r.
.complete 79106,5 
step
.goto 2307,72.63,58.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r.
.turnin 79106 >>Turn in Rupture
.accept 80321 >>Accept Departure
.target Anduin Wrynn
step
.goto 2307,24.71,79.23
#title |cFFFCDC00Follow the Arrow|r.
.complete 80321,1 
step
.goto 2307,4.94,74.75,10,0
.goto 2307,6.72,65.72,10,0
.goto 2307,15.04,70.5,10,0
.goto 2305,40.95,36.44
#title |cFFFCDC00Follow the Arrow|r.
.complete 80321,2 
step
.goto 2305,42.28,35.00
>>Kill |cRXP_ENEMY_Queensguard An'Jak Shabtir|r.
.complete 80321,3 
.mob Queensguard An'Jak Shabtir
step
.goto 2305,44.53,37.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.complete 80321,4 
.skipgossipid 124153
.target Archmage Khadgar
step
.goto 2305,44.20,36.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Khadgar's Portal|r.
.turnin 80321 >>Turn in Departure
.accept 78529 >>Accept Violent Impact
.target Khadgar's Portal
step
#completewith EscapeTheRubbleB
#label EscapeTheRubbleA
#hidewindow
.complete 78529,1 
step
.isOnQuest 78529
#completewith EscapeTheRubbleA
#label PileOfRubbleA
.goto 2248,28.91,54.53
.cast 429488 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r |cRXP_WARN_[1]|r.
*|cRXP_WARN_Relog if you can't |TInterface/cursor/crosshair/interact.blp:20|tClick on them|r.
step
.isOnQuest 78529
#completewith EscapeTheRubbleA
#requires PileOfRubbleA
#label PileOfRubbleB
.goto 2248,28.91,54.53
.cast 429488 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r |cRXP_WARN_[2]|r.
*|cRXP_WARN_Relog if you can't |TInterface/cursor/crosshair/interact.blp:20|tClick on them|r.
step
.isOnQuest 78529
#requires PileOfRubbleB
#completewith EscapeTheRubbleA
#label EscapeTheRubbleB
.goto 2248,28.91,54.53
.cast 429488 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r |cRXP_WARN_[3]|r.
*|cRXP_WARN_Relog if you can't |TInterface/cursor/crosshair/interact.blp:20|tClick on them|r.
step
#requires EscapeTheRubbleB
#label DalaranEnd
.goto 2248,28.91,54.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r.
.complete 78529,1 
step << Horde
#label ViolentImpact2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r and |cRXP_FRIENDLY_Lady Jaina Proudmoore|r.
.turnin 78529 >>Turn in Violent Impact
.accept 78531 >>Accept Urgent Recovery
.goto 2248,29.45,55.07
.target +Thrall
.accept 78530 >>Accept Slay the Saboteurs
.goto 2248,29.50,55.01
.target +Lady Jaina Proudmoore
step << Alliance
#label ViolentImpact2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r and |cRXP_FRIENDLY_Thrall|r.
.turnin 78529 >>Turn in Violent Impact
.accept 78530 >>Accept Slay the Saboteurs
.goto 2248,29.50,55.01
.target +Lady Jaina Proudmoore
.accept 78531 >>Accept Urgent Recovery
.goto 2248,29.45,55.07
.target +Thrall
step
#label DornStart
#completewith DamagedArcaneRelics
>>Kill |cRXP_ENEMY_Nerubians|r.
.complete 78530,1 
.mob Borrowing Saboteur
.mob Devious Webspinner
.mob Devious Webspinner
step
#title Survivor rescued (1/7)
.goto 2248,30.22,54.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Rittsyn's Soulstone|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78531,1,1 
step
#title Survivor rescued (2/7)
.goto 2248,30.92,55.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Rittsyn's Soulstone|r.
.complete 78531,1,2 
step
.goto 2248,30.95,55.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r.
.turnin -80334 >>Turn in Shattered Spires
.accept 78532 >>Accept Erratic Artifacts
.target Archmage Aethas Sunreaver
step
#title Relic destroyed (1/5)
.goto 2248,30.86,55.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Damaged Arcane Relics|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78532,1,1 
.target Damaged Arcane Relic
step
#title Survivor rescued (3/7)
.goto 2248,31.06,55.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Polymorphed Victim|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78531,1,3 
.target Polymorphed Victim
step
#title Relic destroyed (2/5)
.goto 2248,31.19,54.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Damaged Arcane Relics|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78532,1,2 
.target Damaged Arcane Relic
step
#title Relic destroyed (3/5)
.goto 2248,31.71,54.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Damaged Arcane Relics|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78532,1,3 
.target Damaged Arcane Relic
step
#title Survivor rescued (4/7)
.goto 2248,31.40,54.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Rittsyn's Soulstone|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78531,1,4 
step
#title Relic destroyed (4/5)
.goto 2248,31.23,54.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Damaged Arcane Relics|r.
*|cRXP_WARN_Relog if you can't |TInterface/cursor/crosshair/interact.blp:20|tClick on them|r.
.complete 78532,1,4 
.target Damaged Arcane Relic
step
#title Relic destroyed (5/5)
.goto 2248,31.07,54.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Damaged Arcane Relics|r.
.complete 78532,1 
.target Damaged Arcane Relic
step
#title Survivor rescued (6/7)
.goto 2248,30.58,53.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Rittsyn's Soulstone|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78531,1,6 
step
#label DamagedArcaneRelics
#title Survivor rescued (7/7)
.goto 2248,30.36,52.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Rittsyn's Soulstone|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 78531,1 
step
#hidewindow
#sticky
#completewith NerubiansSaboteurSlain
#loop
.goto 2248,29.40,54.49,40,0
.goto 2248,30.06,56.07,40,0
.goto 2248,31.87,53.64,35,0
.goto 2248,30.04,51.92,40,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Nerubians|r.
.complete 78530,1 
.mob Borrowing Saboteur
step
#label CrashSurvivorsAidedB
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the survivors or on the objects next to them to free them
.complete 78531,1 
step
#label NerubiansSaboteurSlain
>>Kill |cRXP_ENEMY_Nerubians|r.
.complete 78530,1 
.mob Borrowing Saboteur
step
#title |Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cFF00FF25Jaina|r and |cFF00FF25Thrall|r.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r and |cRXP_FRIENDLY_Thrall|r.
.turnin 78530 >>Turn in Slay the Saboteurs
.turnin 78532 >>Turn in Erratic Artifacts
.goto 2248,29.50,55.00
.target +Lady Jaina Proudmoore
.turnin 78531 >>Turn in Urgent Recovery
.goto 2248,29.45,55.07
.target +Thrall
step
#title |Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cFF00FF25Anduin Wrynn|r.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r.
.accept 78533 >>Accept Secure the Beach
.goto 2248,29.53,54.99
.target Anduin Wrynn
step
#title |cFFFCDC00Follow the Arrow|r.
.goto 2248,30.30,56.08
.complete 78533,1 
step
>>Damage |cRXP_ENEMY_Queensguard Zirix|r to 85%.
.goto 2248,30.24,56.29
.complete 78533,2 
.timer 7,Roleplay Duration
.mob Queensguard Zirix
step
#label DornEnd
.goto 2248,30.19,56.34
>>|cRXP_WARN_Wait for the roleplay|r.
.complete 78533,3 
step
.goto 2248,30.42,55.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78533 >>Turn in Secure the Beach
.accept 78534 >>Accept To Dornogal
.target Baelgrim
step
#completewith next
#label MeetBaelgrimA
#hidewindow
.complete 78534,3 
step
#arrowtext Fly through rings
#completewith MeetBaelgrimA
.goto 2248,31.59,54.64,15,0
.goto 2248,37.75,54.08,20 >>Fly through rings
step
#requires MeetBaelgrimA
#arrowtext Fly to Dornogal
.goto 2339,33.59,75.25
>>Follow the Arrow
.complete 78534,3 
step
.goto 2339,33.59,75.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78534 >>Turn in To Dornogal
.accept 78535 >>Accept They Come from Below
.target Baelgrim
step
#arrowtext |TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Lokren|r.
.goto 2339,33.89,75.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Lokren|r.
*|cRXP_WARN_Relog if you can't mount it|r.
.complete 78535,1 
.target Lokren
step
>>Use |T135990:0|t[Lightning Bolt] and |T136111:0|t[Storm Blast](2) on |cRXP_ENEMY_Nerubians|r.
.complete 78535,2 
.mob Armored Subjugator
.mob Invading Depthlurker
step
.goto 2339,35.76,64.96
>>Use |T252175:0|t[Dismount Stormrook] (6)
.complete 78535,3 
step
.goto 2339,36.21,64.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78535 >>Turn in They Come from Below
.accept 78536 >>Accept Impossible Odds
.target Baelgrim
step
.goto 2339,36.5,65.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r.
.complete 78536,1 
.target Thrall
.skipgossip 219757,1
step
.goto 2339,36.21,64.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78536 >>Turn in Impossible Odds
.accept 78460 >>Accept Hypocenter
.target Baelgrim
step
#title Earthen rescued (1/8)
.goto 2339,35.08,66.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Coreway Worker|r.
.complete 78460,1,1 
.target Coreway Worker
step
#title Earthen rescued (2/8)
.goto 2339,33.47,66.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Coreway Worker|r.
.complete 78460,1,2 
.target Coreway Worker
step
#title Earthen rescued (3/8)
.goto 2339,33.52,64.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coreway Rubble|r.
.complete 78460,1,3 
step
#title Earthen rescued (4/8)
.goto 2339,33.4,64.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Dead Earthen|r.
.complete 78460,1,4 
.mob Dead Earthen
step
#title Earthen rescued (5/8)
.goto 2339,33.66,64.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Coreway Worker|r.
.complete 78460,1,5 
.target Coreway Worker
step
#title Earthen rescued (6/8)
.goto 2339,31.99,62.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coreway Rubble|r.
.complete 78460,1,6 
step
#title Earthen rescued (7/8)
.goto 2339,31.22,60.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coreway Rubble|r.
.complete 78460,1,7 
step
#title Earthen rescued (8/8)
.goto 2339,31.15,59.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coreway Rubble|r.
.complete 78460,1,8 
step
.goto 2339,29.66,59.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78460 >>Turn in Hypocenter
.target Baelgrim
step
.goto 2339,29.4,59.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Speaker Brinthe|r.
.accept 78468 >>Accept The Archive
.target Speaker Brinthe
step
#hidewindow
#completewith next
.isOnQuest 78468
.cast 446651 >>1
.timer 3,Roleplay Duration
step
#completewith next
#label PrismaticCodexUsedA
>>Use the |cRXP_WARN_ExtraActionButton|r.
.complete 78468,1 
step
#completewith PrismaticCodexUsedA
.isOnQuest 78468
.cast 446651 >>Use the |cRXP_WARN_ExtraActionButton|r.
.timer 6,Roleplay Duration
step
#completewith next
#requires PrismaticCodexUsedA
>>Use the |cRXP_WARN_ExtraActionButton|r.
.complete 78468,1 
step
#requires PrismaticCodexUsedA
.goto 2339,29.40,59.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.accept 78457 >>Accept Stones of Dornogal
.target Merrix
step
.goto 2339,29.23,59.67
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 78468,1 
step
#arrowtext Upstairs
.goto 2339,29.23,59.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Archival Repository|r.
.complete 78468,2 
step
.goto 2339,29.4,59.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Speaker Brinthe|r.
.turnin 78468 >>Turn in The Archive
.target Speaker Brinthe
step
#label BrannStart
.goto 2339,30.39,59.51,8,0
.goto 2339,30.65,59.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Oathsworn Peacekeeper|r.
.complete 78457,1 
.target Oathsworn Peacekeeper
.skipgossipid 122786
step
.goto 2339,44.68,51.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breem|r.
.complete 78457,2 
.target Breem
.skipgossipid 120909
step
#completewith next
#label InnkeeperRonesh
.goto 2339,44.75,46.42,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Ronesh|r.
.complete 78457,3 
.target Innkeeper Ronesh
step
#title Enter Stonelight Rest
#completewith InnkeeperRonesh
.isOnQuest 78457
.goto 2339,45.29,47.3,6 >>Enter the Stonelight Rest
step
#requires InnkeeperRonesh
.goto 2339,44.75,46.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Ronesh|r.
.complete 78457,3 
.target Innkeeper Ronesh
.skipgossipid 120913
step
.goto 2339,44.75,46.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Ronesh|r.
.home >>Set your Hearthstone to Stonelight Rest
.skipgossipid 120914
.target Innkeeper Ronesh
step
#completewith next
#label Brann Bronzebeard
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r.
.complete 78457,4 
.target Brann Bronzebeard
step
#title Leave Stonelight Rest
#completewith Brann Bronzebeard
.goto 2339,45.29,47.3,6 >>Leave the Stonelight Rest
step
#requires Brann Bronzebeard
#label BrannStart
.goto 2339,47.4,44.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r.
.complete 78457,4 
.skipgossipid 122129
.target Brann Bronzebeard
step
#label StateUnionEndEnd
.goto 2339,39.1,24.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auditor Balwurz|r.
.complete 78457,5 
.target Auditor Balwurz
step
.goto 2339,39.86,26.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 78457 >>Turn in Stones of Dornogal
.accept 78459 >>Accept State of the Union
.target Merrix
.skipgossipid 122306
step
.goto 2339,39.86,26.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.complete 78459,1 
.skipgossipid 122306
.target Merrix
step
#label StateUnionEnd
.goto 2339,39.86,26.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 78459 >>Turn in State of the Union
.target Merrix
step
.goto 2339,40.55,25.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r.
.accept 78461 >>Accept The Fourth Seat
.target Moira Thaurissan
step
#title Use |cFFFCDC00Earthen Teleporter|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Earthen Teleporter|r.
.goto 2339,40.74,22.38
.complete 78461,1 
step
#label IsleOfDornB
#title |cFFFCDC00Follow the Arrow|r.
.goto 2339,40.69,27.07
.complete 78461,2 
step
#label IsleOfDornC
#arrowtext Follow the Arrow
.goto 2248,41.86,72.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r in Adelgonn.
.complete 78461,3 
.skipgossipid 122307
.target Adelgonn
step
#label IsleOfDornD
.goto 2248,41.86,72.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adelgonn|r.
.turnin 78461 >>Turn in The Fourth Seat
.accept 78464 >>Accept Delve into the Earth
.target Adelgonn
step
#label IsleOfDornE
#title |cFFFCDC00Follow the Arrow|r.
.goto 2248,38.87,73.27
.complete 78464,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r.
.complete 78464,2 
.goto 2248,38.87,73.27
.skipgossipid 120958
.target Brann Bronzebeard
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Explorer's League Supplies|r.
.complete 78464,3 
.skipgossipid 122660
.goto 2248,38.90,73.28
step
>>Choose Healer |cRXP_WARN_as DPS|r, or DPS |cRXP_WARN_as Healer|r.
.complete 78464,4 
.goto 2248,38.90,73.28
step
#title |cFFFCDC00Follow the Arrow|r.
>>Select |cRXP_WARN_Tier 1|r and |TInterface/cursor/crosshair/interact.blp:20|tClick on Enter.
.goto 2248,38.55,73.94
.complete 78464,5 
step
.goto 2269,44.46,12.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_DELVER'S CALL: Earthcrawl Mines|r
.accept 85648 >>Accept Delver's Call: Earthcrawl Mines
.target DELVER'S CALL: Earthcrawl Mines
step
.isOnQuest 78464
.goto 2269,43.01,15.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Pivk|r.
.scenario 6859,1 
.target Foreman Pivk
.skipgossipid 120330
step
.isOnQuest 78464
.goto 2269,41.76,15.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Hookshot|r.
.scenario 6859,2 
step
.isOnQuest 78464
.goto 2269,38.95,25.79
>>Wait at the waypoint location
.scenario 6864,1 
step
.isOnQuest 78464
.goto 2269,38.84,26.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trapped Earthen|r.
*|cRXP_WARN_When you run over the web |cRXP_ENEMY_Skittering Ambusher|r will spawn and attack you|r.
.scenario 6881,1,1 
.target Trapped Earthen
step
.isOnQuest 78464
.goto 2269,40.64,25.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trapped Earthen|r.
*|cRXP_WARN_When you run over the web |cRXP_ENEMY_Skittering Ambusher|r will spawn and attack you|r.
.scenario 6881,1,2 
.target Trapped Earthen
step
.isOnQuest 78464
.goto 2269,39.77,28.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Grapple Point|r.
.scenario 6881,2 
step
.isOnQuest 78464
.goto 2269,40.54,28.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trapped Earthen|r.
*|cRXP_WARN_When you run over the web |cRXP_ENEMY_Skittering Ambusher|r will spawn and attack you|r.
.scenario 6881,1,3 
.target Trapped Earthen
step
.isOnQuest 78464
.goto 2269,40.89,30.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trapped Earthen|r.
.scenario 6881,1,4 
.target Trapped Earthen

step
.isOnQuest 78464
.goto 2269,42.18,29.96
>>Wait at the waypoint location
.scenario 6883,1 
step
.isOnQuest 78464
.goto 2269,41.48,32.69
>>Kill the spawning |cRXP_ENEMY_Nerubians|r.
.scenario 6884,1 
.mob Chittering Fearmonger
.mob Nerubian Slasher
.mob Nerubian Threadmancer
.mob Ankle Biter
.mob Skittering Ambusher
.mob Skittering Menace
.mob Nerubian Captain
step

.isOnQuest 78464
#loop
.goto 2269,39.61,38.3,20,0
.goto 2269,39.58,40.55,20,0
.goto 2269,38.14,43.74,20,0
.goto 2269,37.09,36.92,20,0
.goto 2269,35.3,37.56,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trapped Earthen|r.
*|cRXP_WARN_Use the |cRXP_PICK_Grapple Points|r to move faster between each web|r.
*|cRXP_WARN_When you run over the web |cRXP_ENEMY_Skittering Ambusher|r will spawn and attack you|r.
.scenario 6886,1 
.target Trapped Earthen
.mob Skittering Ambusher
step
.isOnQuest 78464
#completewith next
#label SpeakwithPivk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Pivk|r.
.scenario 6887,1 
.target Foreman Pivk
step
.isOnQuest 78464
#completewith SpeakwithPivk
.goto 2269,32.35,41.75,20 >>Go up
step
.isOnQuest 78464
#requires SpeakwithPivk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Pivk|r.
.goto 2269,33.91,36.55
.scenario 6887,1 
.timer 10,Roleplay Duration
.target Foreman Pivk
.skipgossip 215685,1
step
.isOnQuest 78464
.goto 2269,39.21,42.75
>>Wait at the waypoint location
.scenario 6888,1 
step
.isOnQuest 78464
.goto 2269,39.21,42.75
>>Kill the |cRXP_ENEMY_Nerubians|r.
.scenario 6889,1 
.mob Nerubian Captain
.mob Chittering Fearmonger
step
.isOnQuest 78464
.goto 2269,44.81,49.31
>>Kill the |cRXP_ENEMY_Nerubians|r in the tunnel.
.scenario 6890,1,1 
.mob Nerubian Captain
.mob Skittering Menace
.mob Nerubian Darkcaster
.mob Chittering Fearmonger
.mob Ankle Biter
step
.isOnQuest 78464
.goto 2269,44.29,60.92
>>Kill the |cRXP_ENEMY_Nerubians|r in the tunnel.
.scenario 6890,1,2 
.mob Skittering Menace
.mob Nerubian Darkcaster
.mob Ankle Biter
step
.isOnQuest 78464
.goto 2269,52.00,72.29
>>Kill the |cRXP_ENEMY_Nerubians|r in the tunnel.
.scenario 6890,1 
.mob Nerubian Slasher
.mob Nerubian Threadmancer
.mob Ankle Biter
.mob Chittering Fearmonger
step
.isOnQuest 78464
.goto 2269,56.66,78.65
>>Kill |cRXP_ENEMY_Web General Ab'enar|r.
.scenario 6891,1 
.mob Web General Ab'enar
step
.goto 2269,56.70,78.50
.complete 78464,6 
step
.goto 2269,65.00,87.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the rightmost |cRXP_PICK_Chest|r.
.complete 78464,7 


step
#completewith LeaveDelveEarthcrawlMinesA
#label SpeakBranOutsideDelve
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r outside the delve.
.complete 78464,8 
.skipgossipid 120969
.target Brann Bronzebeard
step
#completewith SpeakBranOutsideDelve
#label EnterLeaveOBotA
.isOnQuest 78464
.goto 2269,65.39,88.01
.vehicle 205496 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Leave-O-Bot 7000|r.

.target Leave-O-Bot 7000
step
#requires EnterLeaveOBotA
#label LeaveDelveEarthcrawlMinesA
#completewith SpeakBranOutsideDelve
.isOnQuest 78464
.goto 2269,46.20,9.53
.zone 2248 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Leave Delve|r fog.
step
#requires SpeakBranOutsideDelve
.goto 2248,38.75,73.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r |cRXP_WARN_outside the delve|r.
.complete 78464,8 
.skipgossipid 120969
.target Brann Bronzebeard
step
.isOnQuest 84519
.goto 2248,38.89,73.28
>>Use the |T1379245:0|t[Brute Force Idol]
.use 225898
.complete 84519,1 
step
.isOnQuest 84519
.goto 2248,38.89,73.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Explorer's League Supplies|r and select the |T1379245:0|t[Brute Force Idol] under Combat Curio
.complete 84519,2 
.skipgossipid 122660
step
.goto 2248,41.86,72.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adelgonn|r.
.turnin 78464 >>Turn in Delve into the Earth
.accept 79553 >>Accept A Natural Remedy
.target Adelgonn
step
#label IsleOfDornF
.goto 2248,41.77,72.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.accept 78463 >>Accept Building Blocks
.target Baelgrim
step
#label IsleOfDornG
#completewith IsleOfDornH
#hidewindow
#loop
.goto 2248,36.92,74.05,30,0
.goto 2248,37.23,75.80,25,0
.goto 2248,35.91,76.65,30,0
.goto 2248,34.61,73.95,30,0
.goto 2248,35.91,73.00,25,0
+1
step
#label IsleOfDornGA
#completewith next
>>Kill |cRXP_ENEMY_Scarlet Stinkcaps|r and |cRXP_ENEMY_Budling Morel|r. Loot them for the |T134528:0|t[|cRXP_LOOT_Fungarian Chunks|r].
.complete 79553,1 
.mob Scarlet Stinkcap
.mob Budling Morel
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unsorted Ore Pile|r and on |cRXP_PICK_Ore Fragments|r.
.complete 78463,1 
step
#label IsleOfDornH
>>Kill |cRXP_ENEMY_Scarlet Stinkcaps|r and |cRXP_ENEMY_Budling Morel|r. Loot them for the |T134528:0|t[Fungarian Chunks]
.complete 79553,1 
.mob Scarlet Stinkcap
.mob Budling Morel
step
#label IsleOfDornI
.goto 2248,41.75,72.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78463 >>Turn in Building Blocks
.target Baelgrim
step
.goto 2248,41.86,72.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adelgonn|r.
.turnin 79553 >>Turn in A Natural Remedy
.accept 78462 >>Accept Echoes of Compassion
.target Adelgonn
step
#loop
.goto 2248,41.79,72.39,8,0
.goto 2248,42.07,72.62,8,0
.goto 2248,41.92,73.01,8,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Earthen|r.
.complete 78462,1 
.target Injured Earthen
step
.goto 2248,41.79,72.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Findorn|r.
*|cRXP_WARN_You can't pick him up while shapeshifted|r. <<Druid/Shaman
.complete 78462,2 
.skipgossipid 120682
.target Findorn
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the shade of |cRXP_FRIENDLY_Findorn|r.
.goto 2248,41.87,72.76
.complete 78462,3 
step
#label IsleOfDornJ
.goto 2248,41.86,72.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebona|r.
.complete 78462,4 
.timer 17,Roleplay Duration
.skipgossipid 120684
step
#label IsleOfDornK
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adelgonn|r and |cRXP_FRIENDLY_Moira Thaurissan|r.
.turnin 78462 >>Turn in Echoes of Compassion
.goto 2248,41.86,72.63
.target +Adelgonn
.accept 78470 >>Accept The Proscenium
.goto 2248,41.89,72.69
.target +Moira Thaurissan
step
#label IsleOfDornL
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r and |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78470 >>Turn in The Proscenium
.goto 2248,56.53,52.03
.target +Moira Thaurissan
.accept 79701 >>Accept The Cavalry is Here
.goto 2248,56.56,52.02
.target +Baelgrim
step
.goto 2248,56.67,52.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wenbrandt|r.
.accept 79721 >>Accept Fire in the Hole
.target Wenbrandt
step
.goto 2248,56.66,52.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cinderbrew Keg|r.
.complete 79721,1 
step
.goto 2248,56.74,52.13
>>Use your |cRXP_WARN_ExtraActionButton|r and aim it at the burrow.
.complete 79721,2 
step
#completewith NerubianBurrowsCollapsed
>>Kill the |cRXP_ENEMY_Nerubian invaders|r in the area.
.complete 79701,1 
.mob Clotweave Widow
.mob Necrofang Reaper
.mob Armored Scuttler
.mob Venombane Spitter
.mob Nerubian Swarmer
step
#title Burrow collapsed (1/3)
>>Use your |cRXP_WARN_ExtraActionButton|r and aim it at the burrow.
.goto 2248,58.22,50.50
.complete 79721,3,1 
step
#title Burrow collapsed (2/3)
>>Use your |cRXP_WARN_ExtraActionButton|r and aim it at the burrow.
.goto 2248,56.80,49.36
.complete 79721,3,2 
step
#title |cFFFCDC00Follow the Arrow|r.
.goto 2248,56.26,50.26
.complete 79701,2 
step
#label NerubianBurrowsCollapsed
#title Burrow collapsed (3/3)
>>Use your |cRXP_WARN_ExtraActionButton|r and aim it at the burrow.
.goto 2248,55.04,49.49
.complete 79721,3 
step
#loop
.goto 2248,56.17,52.72,40,0
.goto 2248,55.07,51.05,35,0
.goto 2248,56.16,49.07,38,0
.goto 2248,58.18,50.16,40,0
>>Kill the |cRXP_ENEMY_Nerubian invaders|r in the area.
*You can use your |cRXP_WARN_ExtraActionButton|r to weaken them
.complete 79701,1 
.mob Clotweave Widow
.mob Necrofang Reaper
.mob Armored Scuttler
.mob Venombane Spitter
.mob Nerubian Swarmer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r and |cRXP_FRIENDLY_Wenbrandt|r.
.turnin 79701 >>Turn in The Cavalry is Here
.goto 2248,56.45,48.09
.target +Baelgrim
.turnin 79721 >>Turn in Fire in the Hole
.goto 2248,56.42,47.95
.target +Wenbrandt
step
#label IsleOfDornM
.goto 2248,56.48,47.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r.
.accept 78471 >>Accept Convergence
.target Moira Thaurissan
step
#label IsleOfDornN
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moira Thaurissan|r.
.goto 2339,40.18,26.04
.turnin 78471 >>Turn in Convergence
.target Moira Thaurissan
step
.goto 2339,39.86,26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.accept 78538 >>Accept Group Effort
.target Merrix
step
#completewith next
.goto 2339,40.73,22.33
.cast 431519 >> Use the |cRXP_PICK_Earthen Teleporter|r.
step
.goto 2339,41.76,58.66
>>Use the |T1506451:0|t[Work Orders] and aim it at the |cRXP_FRIENDLY_Unbound Workers|r |cRXP_WARN_can't do while mounted|r.
.complete 78538,1,2 
.use 213271
.target Unbound Worker
step
.goto 2339,38.69,53.77
>>Use the |T1506451:0|t[Work Orders] and aim it at the |cRXP_FRIENDLY_Unbound Workers|r |cRXP_WARN_can't do while mounted|r.
.complete 78538,1,4 
.use 213271
.target Unbound Worker
step
.goto 2339,36.03,54.27
>>Use the |T1506451:0|t[Work Orders] and aim it at the |cRXP_FRIENDLY_Unbound Workers|r |cRXP_WARN_can't do while mounted|r.
.complete 78538,1,6 
.use 213271
.target Unbound Worker
step
.goto 2339,34.44,55.69
>>Use the |T1506451:0|t[Work Orders] and aim it at the |cRXP_FRIENDLY_Unbound Workers|r |cRXP_WARN_can't do while mounted|r.
.complete 78538,1,8 
.use 213271
.target Unbound Worker
step
.goto 2339,34.68,52.30
>>Use the |T1506451:0|t[Work Orders] and aim it at the |cRXP_FRIENDLY_Unbound Workers|r |cRXP_WARN_can't do while mounted|r.
.complete 78538,1,10 
.use 213271
.target Unbound Worker
step
.goto 2339,36.01,52.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 78538 >>Turn in Group Effort
.target Merrix
step
#label IsleOfDornO
.goto 2339,36.05,52.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.accept 80022 >>Accept Calling the Stormriders
.target Baelgrim
step
#label IsleOfDornP
#title |cFFFCDC00Follow the Arrow|r.
.goto 2339,32.18,35.71
.complete 80022,1 
step
.goto 2339,32.18,35.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.complete 80022,2 
.target Baelgrim to proceed
.skipgossipid 122130
step
#completewith VoidstoneMonstrosity
#label TheRookeryCorruptionA
>>Complete the follower dungeon
*- Use the |cRXP_WARN_ZoneButton|r to toggle between leading or following the followers
.complete 80022,3 
.skipgossipid 122130
step

.isOnQuest 80022
>>Kill |cRXP_ENEMY_Kyrioss|r.:
*- Clear the |cRXP_ENEMY_guards|r around the |cRXP_FRIENDLY_Stormrooks|r.
*- |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dark Fragment|r to free them.
*- |TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_FRIENDLY_Stormrook|r to advance to the boss area.
.scenario 6794,1 
.target Stormrook
.mob Kyrioss
step

.isOnQuest 80022
>>Kill |cRXP_ENEMY_Stormguard Gorren|r.:
*- Jump down and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stormrook Feather|r.
*- Dodge the purple balls
.scenario 6794,2 
.target Stormrook
.mob Stormguard Gorren
step
#label VoidstoneMonstrosity
#completewith TheRookeryCorruptionA

.isOnQuest 80022
>>Kill |cRXP_ENEMY_Voidstone Monstrosity|r.:
*- Kill the |cRXP_ENEMY_Void Ascendant|r and jump down.
*- Kill the |cRXP_ENEMY_void enemies|r before and around the boss to spawn him.
.scenario 6794,3 
.target Stormrook
.mob Stormguard Gorren
step
#requires TheRookeryCorruptionA
.goto 2339,30.24,42.60
>>Complete the follower dungeon
*- Use the |cRXP_WARN_ZoneButton|r to toggle between leading or following the followers.
.complete 80022,3 
.skipgossipid 122130
step
#completewith next
#label CallingtheStormriders
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r outside the instance.
.turnin 80022 >>Turn in Calling the Stormriders
.target Merrix
step
.isOnQuest 80022
#completewith CallingtheStormriders
.zone 2339 >>Leave the instance group (Right-Click your player frame).
step
#requires CallingtheStormriders
.goto 2339,36.02,52.58
#title |cFFFCDC00Fly Up|r.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 80022 >>Turn in Calling the Stormriders
.target Merrix
step
.goto 2339,35.91,52.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.accept 78539 >>Accept Lasting Repairs
.target Baelgrim
step
.goto 2339,35.91,52.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.complete 78539,1 
.target Baelgrim
.skipgossipid 122154
step
#label IsleOfDornQ
.goto 2339,35.91,52.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78539 >>Turn in Lasting Repairs
.accept 78540 >>Accept To the Meadery
.target Baelgrim
step
#label IsleOfDornR
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r and |cRXP_FRIENDLY_Wenbrandt|r.
.turnin 78540 >>Turn in To the Meadery
.accept 78541 >>Accept Lay the Trap
.goto 2248,75.31,43.13
.target +Baelgrim
.accept 78542 >>Accept Evacuation Area
.goto 2248,75.31,43.17
.target +Wenbrandt
step
#completewith LayTheTrap
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Unbound Meadworkers|r.
*|cRXP_WARN_This is an AOE cast. To hit multiple at once, position yourself between them|r.
.complete 78542,1 
.target Unbound Meadworker
step
#completewith next
#label FuseConnectedA
#hidewindow
.complete 78541,1,1 
step
#title Fuse connected (1/4)
#completewith FuseConnectedA
.isOnQuest 78541
.goto 2248,74.75,42.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_Meadery Ladder|r.
.aura 434279 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rope Fuse|r afterwards.
step
.goto 2248,74.78,42.72
#title Fuse connected (1/4)
#requires FuseConnectedA
>>Jump down and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sizzling Keg|r.
.complete 78541,1,1 
step
#completewith next
#label FuseConnectedB
#hidewindow
.complete 78541,1,2 
step
#title Fuse connected (2/4)
#completewith FuseConnectedB
.isOnQuest 78541
.goto 2248,74.50,42.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_Meadery Ladder|r.
.aura 450651 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rope Fuse|r afterwards.
step
.goto 2248,74.51,42.27
#title Fuse connected (2/4)
#requires FuseConnectedB
>>Jump down and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sizzling Keg|r.
.complete 78541,1,2 
step
#completewith next
#label FuseConnectedC
#hidewindow
.complete 78541,1,3 
step
#title Fuse connected (3/4)
#completewith FuseConnectedC
.isOnQuest 78541
.goto 2248,74.46,41.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_Meadery Ladder|r.
.aura 450652 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rope Fuse|r afterwards.
step
.goto 2248,74.41,41.76
#title Fuse connected (3/4)
#requires FuseConnectedC
>>Jump down and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sizzling Keg|r.
.complete 78541,1,3 
step
#completewith next
#label FuseConnectedD
#hidewindow
.complete 78541,1 
step
#title Fuse connected (4/4)
#completewith FuseConnectedD
.isOnQuest 78541
.goto 2248,74.79,41.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_Meadery Ladder|r.
.aura 450653 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rope Fuse|r afterwards.
step
.goto 2248,74.79,41.66
#title Fuse connected (4/4)
#requires FuseConnectedD
#label LayTheTrap
>>Jump down and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sizzling Keg|r.
.complete 78541,1 
step
#loop
.goto 2248,75.11,42.11,25,0
.goto 2248,74.55,43.18,35,0
.goto 2248,74.30,41.83,35,0
.goto 2248,74.69,41.26,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Unbound Meadworkers|r.
*|cRXP_WARN_This is an AOE cast. To hit multiple at once, position yourself between them|r.
.complete 78542,1 
.target Unbound Meadworker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wenbrandt|r and |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78542 >>Turn in Evacuation Area
.goto 2248,75.31,43.17
.target +Wenbrandt
.turnin 78541 >>Turn in Lay the Trap
.accept 78543 >>Accept Poking the Spider Nest
.goto 2248,75.32,43.13
.target +Baelgrim
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Keg of Cinderbrew Mead|r.
.goto 2248,74.53,40.96
.complete 78543,1 
step
>>Use the |cRXP_WARN_ExtraActionButton|r and aim it at the cave entrance.
.goto 2248,75.07,38.82
.complete 78543,2 
step
.goto 2248,74.77,42.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r.
.turnin 78543 >>Turn in Poking the Spider Nest
.accept 78544 >>Accept Bring the Thunder
.target Baelgrim
step
.goto 2248,74.75,42.27
>>Use |T5483861:0|t[Place Sticky Cinderhoney] (1) |cRXP_WARN_at each of the arrowheads on the ground|r.
*Use whatever for the remaining two
.complete 78544,1 
step
.goto 2248,74.77,42.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelgrim|r to begin the defense.
.complete 78544,2 
.target Baelgrim
.skipgossipid 120672
step
>>|cRXP_WARN_Use|r |T237587:0|t[Static Pulse] (3) |cRXP_WARN_to kill the |cRXP_ENEMY_Swarming Skyterror|r attacking you|r.
>>Use |T1397637:0|t[Storm Axe] (2) to kill |cRXP_ENEMY_Enraged Collosus|r.
>>Use |T135990:0|t[Lightning Bolt] (1) otherwise
>>Kill |cRXP_ENEMY_Nerubians|r.
.complete 78544,3 
.timer 15,Roleplay Duration
.mob Provoked Burrowfiend
.mob Enraged Colossus
.mob Razorfang Saboteur
.mob Swarking Skyterror
step
>>|cRXP_WARN_Wait for the roleplay|r.
.complete 78544,4 
step
#label IsleOfDornS
.goto 2248,75.10,43.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adelgonn|r.
.turnin 78544 >>Turn in Bring the Thunder
.accept 78545 >>Accept Return to the Coreway
.target Adelgonn
step
#title Use |T134414:0|t[Hearthstone]
#completewith next
.goto 2339,49.90,49.34,200,0
.hs >>Hearth to Dornogal
step
#label IsleOfDornT
#title |cFFFCDC00Follow the Arrow|r.
.goto 2339,32.06,59.69
.complete 78545,1 
step
.goto 2339,32.06,59.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 78545 >>Turn in Return to the Coreway
.accept 78546 >>Accept Recompense
.timer 11.5,Roleplay Duration
.target Merrix
step
.goto 2339,31.85,59.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adelgonn|r after the roleplay.
.complete 78546,1 
.complete 78546,2 
.target Adelgonn
.skipgossipid 122368
step
.goto 2339,32.06,59.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.complete 78546,3 
.skipgossipid 120762
step
#label IsleOfDornU
.goto 2339,32.06,59.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 78546 >>Turn in Recompense
.target Merrix
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Lunarwing Shallows Midnight
#internal
step
#label LunarwingShallowsA
.goto 641,53.75,79.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Saylanna Riverbreeze|r.
.accept 40220 >>Accept Thorny Dancing
.accept 40221 >>Accept Spread Your Lunarwings and Fly
.target Saylanna Riverbreeze
step
#completewith LunarwingShallowsB
#hidewindow
#loop
.goto 641,51.94,80.40,30,0
.goto 641,52.46,83.18,30,0
.goto 641,53.67,85.96,30,0
.goto 641,55.67,85.81,30,0
.goto 641,54.98,81.62,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Thistleleafs|r. Loot them for [|cRXP_LOOT_Lunarwing Eggs|r].
.accept 38862 >>Accept Thieving Thistleleaf
.complete 38862,1 
.mob Thistleleaf Ruffian
.mob Thistleleaf Menace
step
#completewith next
>>Rescue |cRXP_FRIENDLY_Trapped Lunarwings|r
*- |TInterface/cursor/crosshair/interact.blp:20|tClick on on the rooted |cRXP_FRIENDLY_Trapped Lunarwings|r
*- Kill |cRXP_ENEMY_Thistleleaf Ruffians|r riding a Lunarwing.
.complete 40221,1 
.target Trapped Lunarwing
.mob Thistleleaf Ruffian
step
>>Kill |cRXP_ENEMY_Thistleleaf Thorndancers|r.
.complete 40220,1 
.mob Thistleleaf Thorndancer
step
#completewith next
>>Kill |cRXP_ENEMY_Thistleleafs|r. Loot them for [|cRXP_LOOT_Lunarwing Eggs|r].
.accept 38862 >>Accept Thieving Thistleleaf
.complete 38862,1 
.mob Thistleleaf Ruffian
.mob Thistleleaf Menace
step
>>Rescue |cRXP_FRIENDLY_Trapped Lunarwings|r or kill |cRXP_ENEMY_Thistleleaf Ruffians|r riding a Lunarwing.
.complete 40221,1 
.target Trapped Lunarwing
.mob Thistleleaf Ruffian
step
#label LunarwingShallowsB
>>Kill |cRXP_ENEMY_Thistleleafs|r. Loot them for [|cRXP_LOOT_Lunarwing Eggs|r].
.accept 38862 >>Accept Thieving Thistleleaf
.complete 38862,1 
.mob Thistleleaf Ruffian
.mob Thistleleaf Menace
step
#label LunarwingShallowsZ
.goto 641,53.75,79.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Saylanna Riverbreeze|r.
.turnin 38862 >>Turn in Thieving Thistleleaf
.turnin 40220 >>Turn in Thorny Dancing
.turnin 40221 >>Turn in Spread Your Lunarwings and Fly
.target Saylanna Riverbreeze
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Lostlight Grotto Midnight
#internal
step
#label LostlightGrottoA
.goto 641,59.41,84.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guviena Bladesong|r
.accept 42748 >>Accept Emerald Sisters
.accept 42747 >>Accept Where the Wildkin Are
.target Guviena Bladesong
step
#completewith DreamcatcherA
>>Kill |cRXP_ENEMY_Moonlost Owlbeasts|r and |cRXP_ENEMY_Undulating Boneslimes|r. Loot them for the |T646670:0|t[Grotesque Remains]
.complete 42747,1 
.complete 42747,2 
.collect 138441,1,42786,0
.accept 42786 >>Accept Grotesque Remains
.mob Undulating Boneslime
.mob Owlbeast
step
#completewith DreamcatcherA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Sister of the Moon|r
.complete 42748,1 
.target Sister of the Moon
step
.goto 641,59.47,82.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leirana|r
.accept 42750 >>Accept Dreamcatcher
.target Leirana
step
.goto 641,59.23,81.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shriektalon Totem|r
.complete 42750,1 
step
#completewith next
#label DreamcatcherB
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fearfeather Totem|r
.complete 42750,2 
step
#completewith DreamcatcherB
#title |cFFFCDC00Enter Cave|r
.goto 641,57.64,81.28,10 >>|cRXP_WARN_Enter the cave|r
step
#requires DreamcatcherB
.goto 641,56.28,81.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fearfeather Totem|r
.complete 42750,2 
step
#completewith next
#label DreamcatcherC
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Reaverbeak Totem|r
.complete 42750,3 
step
#completewith DreamcatcherC
#title |cFFFCDC00Enter Cave|r
.goto 641,59.28,80.27,12 >>|cRXP_WARN_Enter the cave|r
step
#requires DreamcatcherC
#label DreamcatcherA
.goto 641,59.92,79.25,15,0
.goto 641,60.65,79.82,15,0
.goto 641,61.04,80.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Reaverbeak Totem|r
.complete 42750,3 
step
#completewith WhereTheWildkinAreA
#hidewindow
#loop
.goto 641,59.23,80.40,30,0
.goto 641,61.43,81.91,30,0
.goto 641,56.68,81.03,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Moonlost Owlbeasts|r and |cRXP_ENEMY_Undulating Boneslimes|r. Loot them for the |T646670:0|t[Grotesque Remains]
.complete 42747,1 
.complete 42747,2 
.collect 138441,1,42786,0
.accept 42786 >>Accept Grotesque Remains
.mob Undulating Boneslime
.mob Owlbeast
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Sister of the Moon|r
.complete 42748,1 
.target Sister of the Moon
step
#label WhereTheWildkinAreA
>>Kill |cRXP_ENEMY_Moonlost Owlbeasts|r and |cRXP_ENEMY_Undulating Boneslimes|r. Loot them for the |T646670:0|t[Grotesque Remains]
.complete 42747,1 
.complete 42747,2 
.collect 138441,1,42786,0
.accept 42786 >>Accept Grotesque Remains
.mob Undulating Boneslime
.mob Owlbeast
step
.goto 641,59.42,84.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guviena Bladesong|r
.turnin 42747 >>Turn in Where the Wildkin Are
.turnin 42748 >>Turn in Emerald Sisters
.turnin 42786 >>Turn in Grotesque Remains
.turnin 42750 >>Turn in Dreamcatcher
.accept 42751 >>Accept Moon Reaver
.target Guviena Bladesong
step
#completewith next
#label MoonReaverA
>>Kill |cRXP_ENEMY_Boneflux|r |cRXP_WARN_in the cave|r
.complete 42751,1 
.mob Boneflux
step
#completewith MoonReaverA
#title |cFFFCDC00Enter Cave|r
.goto 641,61.20,85.18,10 >>|cRXP_WARN_Enter the cave|r
step
#requires MoonReaverA
.goto 641,61.20,85.18,0,0
.goto 641,59.93,83.67,10,0
.goto 641,60.31,82.53
>>Kill |cRXP_ENEMY_Boneflux|r |cRXP_WARN_in the cave|r
.complete 42751,1 
.mob Boneflux
step
#label LostlightGrottoB
.goto 641,60.40,82.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Remulos|r
.complete 42751,2 
.target Keeper Remulos
.skipgossipid 45772
step
#completewith next
#label LostlightGrottoC
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 42751 >>Turn in Moon Reaver
.target Keeper Remulos
step
#completewith LostlightGrottoC
#label LostlightGrottoY
#title |cFFFCDC00Leave Cave|r
.goto 641,59.91,84.34,10,0
.goto 641,61.11,85.17,10 >>|cRXP_WARN_Leave the cave|r
step
#requires LostlightGrottoC
#label LostlightGrottoZ
.goto 641,59.32,84.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 42751 >>Turn in Moon Reaver
.target Keeper Remulos
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Grizzleweald Midnight
#internal
step
#label GrizzlewealdA
.goto 641,66.68,77.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Grizzleback|r
.accept 42883 >>Accept All Grell Broke Loose
.accept 42884 >>Accept Grassroots Effort
.accept 42865 >>Accept Grell to Pay
.target Old Grizzleback
step
.goto 641,66.81,75.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moist Grizzlecomb|r
.accept 42857 >>Accept Moist Around the Hedges
.target Moist Grizzlecomb
step
#completewith GrassrootsEffortA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Moist Grizzlecomb|r
>>Kill |cRXP_ENEMY_Wildeyed Undergrells|r. Loot them for the |T656684:0|t[Moist Grizzlecomb]
.complete 42883,1 
.complete 42857,1 
.mob Wildeyed Undergrell
step
#title Brambles disentangled (1/5)
.goto 641,68.23,74.43
>>Use the |T237004:0|t[Old Grizzleback's Staff]
.complete 42884,1,1 
.use 138815
step
#title Brambles disentangled (3/5)
.goto 641,68.67,73.62
>>Use the |T237004:0|t[Old Grizzleback's Staff]
.complete 42884,1,3 
.use 138815
step
#title Brambles disentangled (4/5)
.goto 641,68.62,72.68
>>Use the |T237004:0|t[Old Grizzleback's Staff]
.complete 42884,1,4 
.use 138815
step
.goto 641,68.11,71.59
>>Kill |cRXP_ENEMY_Enderkind|r
.complete 42865,1 
.mob Enderkind
step
#label GrassrootsEffortA
#title Brambles disentangled (5/5)
.goto 641,67.52,72.40
>>Use the |T237004:0|t[Old Grizzleback's Staff]
.complete 42884,1 
.use 138815
step
#label GrizzlewealdY
#loop
.goto 641,66.92,72.78,28,0
.goto 641,67.10,75.33,28,0
.goto 641,68.52,73.80,28,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Moist Grizzlecomb|r
>>Kill |cRXP_ENEMY_Wildeyed Undergrells|r. Loot them for the |T656684:0|t[Moist Grizzlecomb]
.complete 42883,1 
.complete 42857,1 
.mob Wildeyed Undergrell
step
#label GrizzlewealdZ
.goto 641,66.68,77.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Grizzleback|r
.turnin 42883 >>Turn in All Grell Broke Loose
.turnin 42884 >>Turn in Grassroots Effort
.turnin 42857 >>Turn in Moist Around the Hedges
.turnin 42865 >>Turn in Grell to Pay
.target Old Grizzleback
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Shadowfen Sorrows Midnight
#internal
step
#label ShadowfenSorrowsA
.goto 641,69.46,49.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mender Onelle|r and |cRXP_FRIENDLY_Aldos Duskwing|r
.accept 38671 >>Accept Lost in Retreat
.target +Mender Onelle
.accept 41707 >>Accept Wormtalon Wreckage
.target +Aldos Duskwing
step
#completewith LostInRetreatA
#label ShadowfenSorrowsB
>>Kill |cRXP_ENEMY_Wormtalon Harpies|r
.complete 41707,1 
.mob Wormtalon Harpy
.mob Wormtalon Huntress
.mob Wormtalon Witch
step
#title Heirlooms (1/5)
.goto 641,67.33,51.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowfen Heirloom|r
.complete 38671,1,1 
step
#completewith next
#label LostInRetreatB
#title Heirlooms (2/5)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowfen Heirloom|r
.complete 38671,1,2 
step
#completewith LostInRetreatB
#title |cFFFCDC00Enter House|r
.goto 641,66.98,52.86,8 >>|cRXP_WARN_Enter the house|r
step
#requires LostInRetreatB
#title Heirlooms (2/5)
.goto 641,67.01,53.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowfen Heirloom|r
.complete 38671,1,2 
step
#completewith next
#label LostInRetreatC
#title Heirlooms (3/5)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowfen Heirloom|r
.complete 38671,1,3 
step
#completewith LostInRetreatC
#title |cRXP_WARN_Leave the house|r
.goto 641,66.97,52.66,8 >>|cRXP_WARN_Leave the house|r
step
#requires LostInRetreatC
#title Heirlooms (3/5)
.goto 641,65.24,51.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowfen Heirloom|r
.complete 38671,1,3 
step
#title Heirlooms (4/5)
.goto 641,65.10,51.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowfen Heirloom|r
.complete 38671,1,4 
step
#label LostInRetreatA
#title Heirlooms (5/5)
.goto 641,65.48,50.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadowfen Heirloom|r
.complete 38671,1 
step
#label ShadowfenSorrowsY
#loop
.goto 641,67.66,51.63,35,0
.goto 641,65.86,52.01,35,0
.goto 641,65.36,49.60,35,0
>>Kill |cRXP_ENEMY_Wormtalon Harpies|r
.complete 41707,1 
.mob Wormtalon Harpy
.mob Wormtalon Huntress
.mob Wormtalon Witch
step
#label ShadowfenSorrowsZ
.goto 641,69.45,49.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mender Onelle|r and |cRXP_FRIENDLY_Aldos Duskwing|r
.turnin 38671 >>Turn in Lost in Retreat
.target +Mender Onelle
.turnin 41707 >>Turn in Wormtalon Wreckage
.target +Aldos Duskwing
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Wisp in the Willows Midnight
#internal
step
.goto 641,54.69,72.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r
.accept 40122 >>Accept Cenarius, Keeper of the Grove
.target Malfurion Stormrage
step
.goto 641,54.69,72.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion|r
.complete 40122,1 
.timer 63,Malfurion Roleplay
.target Malfurion
.skipgossipid 44675
step
.goto 641,51.91,64.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r
.turnin 40122 >>Turn in Cenarius, Keeper of the Grove
.accept 38384 >>Accept Nature's Call
.target Malfurion Stormrage
step
.goto 641,54.37,73.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aranelle|r back in Lorlathil.
.turnin 38384 >>Turn in Nature's Call
.target Aranelle
step
#label WispInTheWillowsA
.goto 641,54.27,68.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Syndrelle|r
.accept 39354 >>Accept Wisp in the Willows
.target Syndrelle
step
.goto 641,54.31,68.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Wisp|r
.complete 39354,1 
.target Wisp
step
.goto 641,48.77,65.43
>>Use |T136041:0|t[Grow Tree] (1) at the waypoint location
*- |cRXP_WARN_The quest is hardcoded so follow the arrow closely otherwise the arrow will be wrong|r
*- |cRXP_WARN_Avoid the circles in the water|r
.complete 39354,2,2 
step
.goto 641,49.27,63.85
>>Use |T136041:0|t[Grow Tree] (1) at the waypoint location
*- |cRXP_WARN_The quest is hardcoded so follow the arrow closely otherwise the arrow will be wrong|r
*- |cRXP_WARN_Avoid the circles in the water|r
.complete 39354,2,4 
step
.goto 641,49.02,63.36
>>Use |T136041:0|t[Grow Tree] (1) at the waypoint location
*- |cRXP_WARN_The quest is hardcoded so follow the arrow closely otherwise the arrow will be wrong|r
*- |cRXP_WARN_Avoid the circles in the water|r
.complete 39354,2,5 
step
.goto 641,48.34,62.61
>>Use |T136041:0|t[Grow Tree] (1) at the waypoint location
*- |cRXP_WARN_The quest is hardcoded so follow the arrow closely otherwise the arrow will be wrong|r
*- |cRXP_WARN_Avoid the circles in the water|r
.complete 39354,2 
step
#completewith next
#label WispInTheWillowsCustomA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Syndrelle|r
.turnin 39354 >>Turn in Wisp in the Willows
.target Syndrelle
step
#label WispInTheWillowsY
#completewith WispInTheWillowsCustomA
.macro Leave Vehicle,6656430 >>/leavevehicle
.exitvehicle 110572 >>|cRXP_WARN_Leave the vehicle
step
#requires WispInTheWillowsCustomA
#label WispInTheWillowsZ
.goto 641,54.27,68.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Syndrelle|r
.turnin 39354 >>Turn in Wisp in the Willows
.target Syndrelle
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Nesingwary's Retreat Midnight
#internal
step
#label NesingwarysRetreatStart1
.isOnQuest 39417
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r and |cRXP_FRIENDLY_Addie Fizzlebog|r
.turnin 39417 >>Turn in Rating Razik
.accept 40170 >>Accept Amateur Hour
.goto 650,40.04,52.24
.target +Hemet Nesingwary
.accept 39859 >>Accept Note-Eating Goats
.goto 650,39.93,52.24
.target +Addie Fizzlebog
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r and |cRXP_FRIENDLY_Addie Fizzlebog|r
.accept 40170 >>Accept Amateur Hour
.goto 650,40.04,52.24
.target +Hemet Nesingwary
.accept 39859 >>Accept Note-Eating Goats
.goto 650,39.93,52.24
.target +Addie Fizzlebog
step
#hidewindow
#completewith Sated Hillstrider
#loop
.goto 650,40.57,53.96,35,0
.goto 650,41.47,54.45,35,0
.goto 650,41.44,53.02,35,0
.goto 650,41.17,51.19,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Sated Hillstrider|r. Loot them for |T133741:0|t[|cRXP_LOOT_The Rocky Hills of Highmountain|r].
.complete 39859,1 
.mob Sated Hillstrider
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amateur Hunter|r
.complete 40170,1 
.skipgossipid 44518
.mob Amateur Hunter
step
#label Sated Hillstrider
>>Kill |cRXP_ENEMY_Sated Hillstrider|r. Loot them for |T133741:0|t[|cRXP_LOOT_The Rocky Hills of Highmountain|r].
.complete 39859,1 
.mob Sated Hillstrider
step
.goto 650,40.04,52.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r
.turnin 39859 >>Turn in Note-Eating Goats
.target Hemet Nesingwary
.turnin 40170 >>Turn in Amateur Hour
.accept 40216 >>Accept A Hunter at Heart
.accept 39123 >>Accept Lion Stalkin'
.accept 39124 >>Accept Moose Shootin'
.accept 39392 >>Accept Bear Huntin'
step
.goto 650,39.93,52.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Addie Fizzlebog|r
.complete 40216,1 
.skipgossipid 44520
.target Addie Fizzlebog
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_traps|r and kill |cRXP_ENEMY_wildlife|r to earn experience for |cRXP_FRIENDLY_Addie Fizzlebog|r. Each rank counts as a quest step.
.complete 40216,2 
step
#loop
.goto 650,40.45,50.84,30,0
.goto 650,39.4,49.11,30,0
.goto 650,37.96,48.39,30,0
>>Kill |cRXP_ENEMY_Pinerocks|r.
.complete 39123,1 
.mob Pinerock Prowlers
.mob Pinerock Stalkers
.mob Pinerock Elderhorn
.mob Skittish Doe
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r and |cRXP_FRIENDLY_Ellias|r
.turnin 39123 >>Turn in Lion Stalkin'
.target +Hemet Nesingwary
.goto 650,40.04,52.25
.accept 39867 >>Accept I'm Not Lion!
.goto 650,40.02,52.37
.target +Ellias
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_traps|r and kill |cRXP_ENEMY_wildlife|r to earn experience for |cRXP_FRIENDLY_Addie Fizzlebog|r. Each rank counts as a quest step.
.complete 40216,3 
.complete 40216,4 
.target Addie Fizzlebog
step
#label NesingwarysRetreatEnd1
#loop
.goto 650,39.7,47.26,30,0
.goto 650,42.3,48.1,30,0
.goto 650,42.78,46.65,30,0
.goto 650,42.25,52.24,30,0
>>Kill |cRXP_ENEMY_Pinerock Elderhorn|r.
.complete 39124,1 
.mob Pinerock Elderhorn
step
#completewith next
#label Bristlefur Bear
.goto 650,38.52,42.4,15,0
>>Kill |cRXP_ENEMY_Bristlefur Bear|r. Loot them for |T878263:0|t[|cRXP_LOOT_Bristlefur Pelt|r].
.complete 39392,1 
.mob Bristlefur Bear
step
#completewith Bristlefur Bear
#title |cFFFCDC00Leave Cave|r
.goto 654,42.31,60.56,80 >>Leave the Cave
step
#requires Bristlefur Bear
#loop
.goto 654,42.31,60.56,25,0
.goto 654,34.46,64.12,20,0
.goto 650,38.52,42.4,15,0
>>Kill |cRXP_ENEMY_Bristlefur Bear|r. Loot them for |T878263:0|t[|cRXP_LOOT_Bristlefur Pelt|r].
.complete 39392,1 
.mob Bristlefur Bear
step
#completewith next
#label Rashar's Right Eye
>>Kill |cRXP_ENEMY_Rashar|r. Loot him for |T255344:0|t[|cRXP_LOOT_Rashar's Right Eye|r].
.complete 39867,1 
.mob Rashar
step
#completewith Rashar's Right Eye
#title |cFFFCDC00Enter Cave|r
.goto 650,37.47,49.19,30 >>Enter the Cave
step
#requires Rashar's Right Eye
#label Bristlefur Pelt
.goto 650,37.47,49.19
>>Kill |cRXP_ENEMY_Rashar|r. Loot him for |T255344:0|t[|cRXP_LOOT_Rashar's Right Eye|r].
.complete 39867,1 
step
#loop
.goto 650,38.5,47.96,30,0
.goto 650,39.67,49.57,30,0
.goto 650,40.81,50.13,30,0
.goto 650,41.39,53.89,30,0
.goto 650,40.54,53.78,30,0
.goto 650,43.31,49.19,30,0
>>Kill wildlife to earn experience for |cRXP_FRIENDLY_Addie Fizzlebog|r. Each rank counts as a quest step.
.complete 40216,3 
.complete 40216,4 
.mob Pinerock Stalker
.mob Soothoof Hillstrider
.mob Pinerock Elderhorn
.mob Skittish Doe
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r, |cRXP_FRIENDLY_Laeni Silvershot|r and |cRXP_FRIENDLY_Ellias|r
.turnin 40216 >>Turn in A Hunter at Heart
.turnin 39124 >>Turn in Moose Shootin'
.turnin 39392 >>Turn in Bear Huntin'
.accept 40228 >>Accept Scout It Out
.target +Hemet Nesingwary
.goto 650,40.04,52.25
.accept 39178 >>Accept Moose on the Loose
.goto 650,40,52.31
.target +Laeni Silvershot
.turnin 39867 >>Turn in I'm Not Lion!
.goto 650,40.02,52.37
.target +Ellias
step
#completewith next
#label Irewing
>>Kill |cRXP_ENEMY_Irewing|r
.complete 40228,1 
.mob Irewing
step
#completewith Irewing
.goto 650,43.45,45.44
.cast 195071 >>Use |T134536:0|t[Flare Gun] on the rock.
step
#requires Irewing
.goto 650,43.45,45.44
>>Kill |cRXP_ENEMY_Irewing|r
.complete 40228,1 
.mob Irewing
step
#label Nesingwary's Retreat
.goto 650,45.74,42.49
>>Kill |cRXP_ENEMY_Morashu|r. Loot him for |T454039:0|t[|cRXP_LOOT_Morashu's Antlers|r].
.complete 39178,1 
.mob Morashu
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r, |cRXP_FRIENDLY_Laeni Silvershot|r and |cRXP_FRIENDLY_Ellias|r
.turnin 39178 >>Turn in Moose on the Loose
.goto 650,40.01,52.3
.target +Laeni Silvershot
.turnin 40228 >>Turn in Scout It Out
.accept 40244 >>Accept That Guy in the Costume
.accept 39386 >>Accept Procuring a Prototype
.goto 650,40.04,52.25
.target +Hemet Nesingwary
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Mucksnout Den Midnight
#internal
step
#completewith next
#label Shiny, But Deadly
.goto 650,41.6,46.84,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Rosalyn|r
.accept 39764 >>Accept Shiny, But Deadly
.target Apprentice Rosalyn
.accept 39773 >>Accept The Soulkeeper's Fate
.disablecheckbox
step
#completewith Shiny, But Deadly
#title |cFFFCDC00Enter Cave|r
.goto 654,51.93,81.36,50 >>Enter the Cave
step
#requires Shiny, But Deadly
.goto 654,51.93,81.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Rosalyn|r
.accept 39764 >>Accept Shiny, But Deadly
.target Apprentice Rosalyn
.accept 39773 >>Accept The Soulkeeper's Fate
step
#completewith next
>>Kill |cRXP_ENEMY_Mucksnouts|r. Loot them for |T134108:0|t[|cRXP_LOOT_Soul Chamber|r].
.complete 39764,1 
.mob Mucksnout Collector
.mob Mucksnout Scavenger
.mob Mucksnout Aggressor
step
.goto 654,31.04,66.08,15,0
.goto 654,30.87,62.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Soulkeeper Uriah|r
.complete 39773,1 
.timer 41.5,RP
.target Soulkeeper Uriah
step
#loop
.goto 654,32.45,58.03,30,0
.goto 654,39.54,61.15,30,0
.goto 654,47.01,51.84,30,0
.goto 654,48.64,73.38,30,0
.goto 654,33.5,78.12,30,0
>>Kill |cRXP_ENEMY_Mucksnouts|r. Loot them for |T134108:0|t[|cRXP_LOOT_Soul Chamber|r].
.complete 39764,1 
.mob Mucksnout Collector
.mob Mucksnout Scavenger
step
.goto 654,30.61,62.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Rosalyn|r
.turnin 39764 >>Turn in Shiny, But Deadly
.turnin 39773 >>Turn in The Soulkeeper's Fate
.target Apprentice Rosalyn
.accept 39774 >>Accept Demon Detainment
step
.goto 654,31.05,84.88
>>Kill |cRXP_ENEMY_Lozar|r
.complete 39774,2 
.mob Lozar
step
.goto 654,48.03,51.47,10,0
.goto 654,47.56,26.04,15,0
.goto 654,40.73,41.67
>>Kill |cRXP_ENEMY_Xorias|r
.complete 39774,3 
.mob Xorias
step
#label Mucksnout Den
.goto 654,54.29,9.24
>>Kill |cRXP_ENEMY_Ezerak|r
.complete 39774,1 
.mob Ezerak
step
#label DemonDetainmentZ
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Rosalyn|r |cRXP_WARN_next to you|r.
.turnin 39774 >>Turn in Demon Detainment
.target Apprentice Rosalyn
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Moozy's Family Reunion Midnight
#internal
step
.goto 650,40.25,64.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rordan Waterwise|r
.accept 39323 >>Accept Moozy's Sojourn
.target Rordan Waterwise
step
.goto 650,37.46,64.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bucket|r
.turnin 39323 >>Turn in Moozy's Sojourn
.target Moozy Waterwise
.accept 39572 >>Accept Moozy's Adventure
step
.goto 650,40.01,57.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.turnin 39572 >>Turn in Moozy's Adventure
.target Sella Waterwise
step
#completewith next
#label Moozy's Reunion
.goto 750,45.65,59.05,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.accept 42590 >>Accept Moozy's Reunion
.target Sella Waterwise
step
#completewith Moozy's Reunion
.goto 750,50.9,54.71,20 >>Enter the central room at the highest level of Thunder Totem.
step
#requires Moozy's Reunion
.goto 750,45.87,54.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.accept 42590 >>Accept Moozy's Reunion
.target Sella Waterwise
step
#completewith next
#label Ethel Waterwise
.goto 750,51.28,53.6,20,0
.goto 750,55.13,20.21,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ethel Waterwise|r
.complete 42590,1 
step
#completewith Ethel Waterwise
.goto 750,53.32,20.67,10 >>Follow the Arrow
step
#requires Ethel Waterwise
.goto 750,53.32,20.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ethel Waterwise|r
.complete 42590,1 
.timer 125,RP
.skipgossipid 45858
.target Ethel Waterwise
step
#label Moozy's Family Reunion
>>Escort |cRXP_FRIENDLY_Ethel Waterwise|r don't stand behind her always infront but not too far away
.complete 42590,2 
.target Ethel Waterwise
step
.goto 750,45.90,54.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.turnin 42590 >>Turn in Moozy's Reunion
.target Sella Waterwise
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Thunder Totem Troubles Midnight
#internal
step
.goto 652,54.89,77.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r at lowest level of Thunder Totem.
.accept 42622 >>Accept Ceremonial Drums
.target Torv Dubstomp
step
.goto 652,64.23,73.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,1 
step
.goto 652,48.72,44.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,1 
step
#completewith next
#label Bolas Bastion
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bolas Skyfeather|r
.accept 42630 >>Accept Bolas Bastion
.target Bolas Skyfeather
step
#completewith Bolas Bastion
.goto 750,42.31,32.96,40 >>Leave Thunder Totem
step
#requires Bolas Bastion
.goto 750,42.98,38.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bolas Skyfeather|r on the highest level of Thunder Totem.
.accept 42630 >>Accept Bolas Bastion
.target Bolas Skyfeather
step
#completewith next
#label Coven Attacker
>>Kill |cRXP_ENEMY_Coven Attacker|r
.complete 42630,1 
.mob Coven Attacker
step
#completewith Coven Attacker
.goto 750,43.39,37.92
.vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bolas Launcher|r
*|cRXP_WARN_Dismount and remain stationary before clicking to avoid potential disconnects|r.
.mob Bolas Launcher
step
#requires Coven Attacker
.goto 750,43.38,37.81
>>Use |T135808:0|t[Flaming Bolas] on the |cRXP_ENEMY_Coven Attackers|r in the air. Then exit and re-enter the launcher to reset the cooldown.
*|cRXP_WARN_(You can use the attached macro.)|r
.complete 42630,1 
.mob Coven Attacker
.macro Leave Vehicle,6656430 >> /leavevehicle
step
.goto 750,42.95,38.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bolas Skyfeather|r
.turnin 42630 >>Turn in Bolas Bastion
.target Bolas Skyfeather
step
#completewith next
>>Kill |cRXP_ENEMY_Bluewax Drumtakers|r as they specifically carry |cRXP_PICK_Small Drums|r
.complete 42622,3 
.mob Bluewax Drumtaker
step
.goto 750,53.96,45.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liza Galestride|r
.accept 42596 >>Accept Mountainstrider Round-Up
.target Liza Galestride
step
#completewith next
#label Frightened Mountainstrider1
>>Return |cRXP_PICK_Frightened Mountainstrider|r
.complete 42596,1,1 
step
#completewith Frightened Mountainstrider1
.goto 750,57.17,51.29
.vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Frightened Mountainstrider|r
.target Frightened Mountainstrider
step
#requires Frightened Mountainstrider1
.goto 750,54.73,54.82,10,0
.goto 750,54,45.81
>>Return |cRXP_PICK_Frightened Mountainstrider|r
.complete 42596,1,1 
step
.goto 750,61.15,48.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,2 
step
#completewith next
#label Frightened Mountainstrider2
>>Return |cRXP_PICK_Frightened Mountainstrider|r
.complete 42596,1,2 
step
#completewith Frightened Mountainstrider2
.goto 750,60.44,48.73
.vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Frightened Mountainstrider|r
.target Frightened Mountainstrider
step
#requires Frightened Mountainstrider2
.goto 750,54.73,54.82,10,0
.goto 750,54,45.81
>>Return |cRXP_PICK_Frightened Mountainstrider|r
.complete 42596,1,2 
step
.goto 750,61.45,35.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,2 
step
#completewith DrumLast
>>Kill |cRXP_ENEMY_Bluewax Drumtakers|r as they specifically carry |cRXP_PICK_Small Drums|r
.complete 42622,3 
.mob Bluewax Drumtaker
step
.goto 750,58.96,26.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,3 
step
.goto 750,58.74,22.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,3 
step
#label DrumLast
.goto 750,59.36,19.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,4 
.complete 42622,1,4 
step
#completewith next
#label Frightened Mountainstrider3
>>Return |cRXP_PICK_Frightened Mountainstrider|r
.complete 42596,1,3 
step
#completewith Frightened Mountainstrider3
.goto 750,57.58,24.36
.vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Frightened Mountainstrider|r
.target Frightened Mountainstrider
step
#requires Frightened Mountainstrider3
.goto 750,51.32,39.85,20,0
.goto 750,53.97,45.82
>>Return |cRXP_PICK_Frightened Mountainstrider|r
.complete 42596,1,3 
step
.goto 750,53.94,45.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liza Galestride|r
.turnin 42596 >>Turn in Mountainstrider Round-Up
.target Liza Galestride
step
#loop
#label Thunder Totem Troubles
.goto 750,51.09,44.1,40,0
.goto 750,42.16,43.62,40,0
.goto 750,40.68,57.8,40,0
.goto 750,50.9,59.05,40,0
.goto 750,53.05,51.56,40,0
>>Kill |cRXP_ENEMY_Bluewax Drumtakers|r as they specifically carry |cRXP_PICK_Small Drums|r
.complete 42622,3 
.mob Bluewax Drumtaker
step
#completewith next
#label Ceremonial Drums
.goto 652,26.11,80.07,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r at lowest level of Thunder Totem.
.turnin 42622 >>Turn in Ceremonial Drums
.target Torv Dubstomp
step
#completewith Ceremonial Drums
.goto 652,54.94,78.05,50 >>Enter Thunder Totem at it's lowest level.
step
#requires Ceremonial Drums
.goto 652,54.78,77.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r at lowest level of Thunder Totem.
.turnin 42622 >>Turn in Ceremonial Drums
.target Torv Dubstomp
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Crystal Calamity Midnight
#internal
step
#label CrystalCalamityStart1
.goto 650,49.03,55.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Nava|r
.accept 39134 >>Accept Wrathshard
.accept 39133 >>Accept No Time to Talk
.target Warbrave Nava
step
#completewith next
#label EnragedAmbershardsA
>>Kill |cRXP_ENEMY_Enraged Ambershards|r
.complete 39133,1 
.mob Enraged Ambershards
step
#completewith EnragedAmbershardsA
#title |cFFFCDC00Enter Cave|r
.goto 650,50.31,53.52,15 >>Enter the Cave
step
#requires EnragedAmbershardsA
#completewith next
>>Kill |cRXP_ENEMY_Enraged Ambershards|r
.complete 39133,1 
.mob Enraged Ambershards
step
#requires EnragedAmbershardsA
#label CrystalCalamityEnd1
.goto 650,51.25,52.63,15,0
.goto 650,51.53,52.56,15,0
.goto 650,52.11,53.13,15,0
.goto 650,52.86,54.5,15,0
.goto 650,53.28,54.39,15,0
.goto 650,54.01,54.45
>>Kill |cRXP_ENEMY_Wrathshard|r
.complete 39134,1 
.mob Wrathshard
step
#label Crystal Calamity
#loop
.goto 650,53.05,52.24,25,0
.goto 650,52.56,53.14,25,0
.goto 650,52.31,52.87,25,0
.goto 650,51.89,52.71,25,0
.goto 650,51.36,52.58,25,0
.goto 650,49.88,53.87,25,0
.goto 650,48.68,54.32,25,0
.goto 650,49.67,55.05,25,0
>>Kill |cRXP_ENEMY_Enraged Ambershards|r
.complete 39133,1 
.mob Enraged Ambershards
step
.goto 650,49.03,55.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Nava|r
.turnin 39134 >>Turn in Wrathshard
.target Warbrave Nava
.turnin 39133 >>Turn in No Time to Talk
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Icepine Point Midnight
#internal
step
#label IcepinePointStart1
.goto 650,57.59,56.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorna Stoutfoot|r
.accept 40000 >>Accept A True Hunter
.target Lorna Stoutfoot
step
.isOnQuest 39386
.goto 650,57.64,56.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razik Gazbolt|r
.turnin 39386 >>Turn in Procuring a Prototype
.accept 39670 >>Accept Critter Scatter Shot
.target Razik Gazbolt
step
.goto 650,57.64,56.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razik Gazbolt|r
.accept 39670 >>Accept Critter Scatter Shot
.target Razik Gazbolt
step
#hidewindow
#completewith Rabbits caught
#loop
.goto 650,57.29,60.92,30,0
.goto 650,55.71,60.23,30,0
.goto 650,56.43,58.37,30,0
.goto 650,57.03,62.24,30,0
.goto 650,55.11,62.11,30,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rabbits|r
.complete 39670,1 
step
>>Kill |cRXP_ENEMY_Bonebeak Hawk|r
.complete 40000,1 
.mob Bonebeak Hawk
step
#label Rabbits caught
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rabbits|r
.complete 39670,1 
step
#label Icepine Point
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorna Stoutfoot|r and |cRXP_FRIENDLY_Razik Gazbolt|r
.turnin 40000 >>Turn in A True Hunter
.goto 650,57.60,56.41
.target +Lorna Stoutfoot
.turnin 39670 >>Turn in Critter Scatter Shot
.accept 39656 >>Accept Wolf Pack Attack
.goto 650,57.63,56.61
.target +Razik Gazbolt
step
#label IcepinePointEnd1
#loop
.goto 650,55.9,55.89,30,0
.goto 650,56.2,54.37,30,0
.goto 650,57.62,54.66,30,0
.goto 650,55.48,53.34,30,0
>>Kill |cRXP_ENEMY_Icefang Packleader|r
*Use |T331784:0|t[Critter Hand Cannon] on wolf packs to fight only the leader. |cRXP_WARN_Do this only if needed|r.
.complete 39656,1 
.mob Icefang Packleader
.use 128651
step
.goto 650,57.63,56.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razik Gazbolt|r
.turnin 39656 >>Turn in Wolf Pack Attack
.target Razik Gazbolt
.accept 39417 >>Accept Rating Razik
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Bluewax Boss Midnight
#internal
step
#label BluewaxBossStart1
.goto 650,54.70,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oenia Skyhorn|r
.accept 39768 >>Accept Candle to the Grave
.target Oenia Skyhorn
.accept 39765 >>Accept Wax On, Wax Off
step
#completewith next
>>Kill |cRXP_ENEMY_Bluewax Graverobber|r
.complete 39768,1 
.mob Bluewax Graverobber
step
.goto 650,56.91,45.35
>>Kill |cRXP_ENEMY_Bluewax Skullcaptain|r. Loot him for |T133731:0|t[|cRXP_LOOT_Skull of Bossing Around|r].
.complete 39765,1 
.mob Bluewax Skullcaptain
step
#loop
.goto 650,55.71,46.95,30,0
.goto 650,55.97,44.03,30,0
.goto 650,56.7,45.9,30,0
>>Kill |cRXP_ENEMY_Bluewax Graverobber|r
.complete 39768,1 
.mob Bluewax Graverobber
step
#label BluewaxBossEnd0
.goto 650,54.7,45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oenia Skyhorn|r
.turnin 39768 >>Turn in Candle to the Grave
.target Oenia Skyhorn
.turnin 39765 >>Turn in Wax On, Wax Off
.accept 39769 >>Accept The Gates of Wax
step
#completewith next
#label Gates of Wax
.goto 650,55.13,44.26,15,0
.goto 650,54.55,42.96,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluewax Gatekeeper|r
.turnin 39769 >>Turn in The Gates of Wax
.target Bluewax Gatekeeper
.accept 40339 >>Accept Candle of Command
.disablecheckbox
step
#completewith Gates of Wax
#title |cFFFCDC00Enter Cave|r
.goto 650,55.29,41.80,80 >>Enter the Cave
step
#requires Gates of Wax
.goto 650,55.29,41.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluewax Gatekeeper|r
.turnin 39769 >>Turn in The Gates of Wax
.target Bluewax Gatekeeper
.accept 40339 >>Accept Candle of Command
step
.goto 650,55.17,42.16,15,0
.goto 650,55.30,42.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chair|r
.complete 40339,1 
.timer 2,RP
step
.goto 650,55.30,42.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluewax Gatekeeper|r
.complete 40339,2 
.timer 6,RP
.skipgossipid 44447
.target Snazzle Shinyfinder
step
.goto 650,55.30,42.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trytooth Hardchisel|r
.complete 40339,3 
.skipgossipid 44347
.timer 10,RP
.target Trytooth Hardchisel
step
.goto 650,55.30,42.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kindle Candlecrafter|r
.complete 40339,4 
.skipgossipid 45092
.timer 3.5,RP
.target Kindle Candlecrafter
step
.goto 650,55.30,42.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dug Digger|r
.complete 40339,5 
.skipgossipid 45094
.target Dug Digger
step
#completewith next
#label Candle of Command
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluewax Gatekeeper|r
.turnin 40339 >>Turn in Candle of Command
.target Bluewax Gatekeeper
.accept 40345 >>Accept Burn the Candle at Both Ends
.disablecheckbox
step
#completewith Candle of Command
#title |cFFFCDC00Spam Macro|r
.goto 619,45.64,67.7
.exitvehicle >>|cRXP_WARN_In the "Active Items" section|r There is a macro, spam it.
.macro Leave Vehicle,6656430 >> /leavevehicle
step
#requires Candle of Command
.goto 650,55.29,41.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluewax Gatekeeper|r
.turnin 40339 >>Turn in Candle of Command
.target Bluewax Gatekeeper
.accept 40345 >>Accept Burn the Candle at Both Ends
step
.goto 650,55.30,42.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chair|r
.complete 40345,1 
.timer 5,RP
step
.goto 650,55.3,42.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Snazzle Shinyfinder|r
.complete 40345,2 
.skipgossipid 45095
.timer 10,RP
.target Snazzle Shinyfinder
step
.goto 650,55.3,42.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trytooth Hardchisel|r
.complete 40345,3 
.skipgossipid 45096
.target Trytooth Hardchisel
step
.goto 650,55.32,42.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boot|r |cRXP_WARN_next to you|r.
.complete 40345,4 
step
#label BluewaxBossEnd1
.goto 650,55.30,42.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trytooth Hardchisel|r
.complete 40345,5 
.skipgossipid 45097
.target Trytooth Hardchisel
step
#completewith next
#label Miner found
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Miner|r
.complete 40345,6 
.target Dug Digger
step
#completewith Miner found
.goto 650,54.93,42.94
.exitvehicle >>Press Space to get off the chair
step
#requires Miner found
.goto 650,54.93,42.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Miner|r
.complete 40345,6 
.target Dug Digger
step
.goto 650,53.83,42.45,20,0
.goto 650,53.25,42.97,20,0
.goto 650,53.1,42.44,20,0
.goto 650,53.62,42.16
#title |cFFFCDC00Follow the Arrow|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kindle Candlecrafter|r
.complete 40345,7 
.skipgossipid 45098
.target Kindle Candlecrafter
step
.goto 650,53.62,42.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Candle|r
.complete 40345,8 
step
.goto 650,55.29,41.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluewax Gatekeeper|r
.turnin 40345 >>Turn in Burn the Candle at Both Ends
.target Bluewax Gatekeeper
.accept 39772 >>Accept Can't Hold a Candle To You
step
#requires Oenia's Skull
#label Bluewax Boss
#title |cFFFCDC00Click Gate|r
.goto 650,55.48,41.47,20,0
.goto 650,55.19,41.02
>>Kill |cRXP_ENEMY_The Candleking|r. Loot him for |T133732:0|t[|cRXP_LOOT_Oenia's Skull|r].
.complete 39772,1 
.mob The Candleking
step
#completewith next
#label Can't Hold a Candle To You
.goto 650,55.48,41.5,20,0
.goto 650,55.13,42.11,20,0
.goto 650,54.58,42.99,20,0
.goto 650,54.68,43.67,20,0
.goto 650,55.14,44.38,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oenia Skyhorn|r
.turnin 39772 >>Turn in Can't Hold a Candle To You
.target Oenia Skyhorn
step
#completewith Can't Hold a Candle To You
#title |cFFFCDC00Leave Cave|r
.goto 650,54.69,45.00,45 >>Leave the Cave
step
#requires Can't Hold a Candle To You
.goto 650,54.69,45.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oenia Skyhorn|r
.turnin 39772 >>Turn in Can't Hold a Candle To You
.target Oenia Skyhorn
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Rockcrawler Chasm Midnight
#internal
step
#completewith next
#label RockcrawlerChasmStart1
#hidewindow
.accept 40069 >>Accept Fledgling Worm Guts
step
#completewith next
#label Fledgling Worm Guts
.goto 650,51.45,37.29,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.accept 40069 >>Accept Fledgling Worm Guts
.target Oren Windstrider
.accept 40070 >>Accept Eagle Egg Recovery
.accept 40071 >>Accept Tamer Takedown
step
#completewith Fledgling Worm Guts
#title |cFFFCDC00Enter Cave|r
.goto 650,50.89,36.57,40 >>Enter the Cave
step
#requires Fledgling Worm Guts
.goto 650,50.89,36.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.accept 40069 >>Accept Fledgling Worm Guts
.target Oren Windstrider
.accept 40070 >>Accept Eagle Egg Recovery
.accept 40071 >>Accept Tamer Takedown
step
#completewith Tamer Korgrul
>>Kill |cRXP_ENEMY_Worms|r. Loot them for |T134895:0|t[|cRXP_LOOT_Worm Guts|r].
.complete 40069,1 
.mob Fledgling Rockcrawler
step
#completewith Tamer Korgrul
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eggs|r
.complete 40070,1 
step
#completewith Tamer Korgrul
.isQuestAvailable account,40497
.cast 3365>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#completewith Tamer Korgrul
.isQuestAvailable account,40496
.cast 3365>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#arrowtext You can fly here
#label Tamer Korgrul
.goto 650,50.7,35.13,15,0
.goto 650,51,36.58,15,0
.goto 650,50.73,37.15,25,0
.goto 650,49.9,36.04,25,0
.goto 650,50.08,34.91,25,0
.goto 650,49.02,37.02,25,0

.goto 650,49.08,42.31
>>Kill |cRXP_ENEMY_Tamer Korgrul|r
.complete 40071,1 
.mob Tamer Korgrul
step
#hidewindow
#completewith Eagle Egg
#loop
.goto 650,48.29,41.68,30,0
.goto 650,48.4,40.76,30,0
.goto 650,49.09,36.71,30,0
.goto 650,50.39,34.91,30,0
.goto 650,51.18,36.98,30,0
.goto 650,50.17,36.82,30,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eggs|r
.complete 40070,1 
step
>>Kill |cRXP_ENEMY_Worms|r. Loot them for |T134895:0|t[|cRXP_LOOT_Worm Guts|r].
.complete 40069,1 
.mob Fledgling Rockcrawler
step
#label Eagle Egg
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eggs|r
.complete 40070,1 
step
.goto 650,49.43,39.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 40070 >>Turn in Eagle Egg Recovery
.target Oren Windstrider
.turnin 40071 >>Turn in Tamer Takedown
.turnin 40069 >>Turn in Fledgling Worm Guts
.accept 42425 >>Accept Going Down, Going Up
step
#completewith next
#label Oren's Prized Possessions
#hidewindow
.complete 42425,1 
step
#completewith Oren's Prized Possessions
.goto 650,49.44,39.31
.cast 213041 >>Click on the |cRXP_PICK_Oren's Rappel Point|r
.timer 4,RP
step
#requires Oren's Prized Possessions
>>Click on the |cRXP_PICK_Oren's Prized Possessions|r on the ground ideally in midair
.complete 42425,1 
.timer 30,RP
step
#label Rockcrawler Chasm
.goto 650,49.43,39.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 42425 >>Turn in Going Down, Going Up
.target Oren Windstrider
.accept 39305 >>Accept Empty Nest
step
#completewith next
#label Eagle Eggs placed
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eggs|r
.complete 39305,1 
step
#completewith Eagle Eggs placed
.goto 650,49.28,39.82,20,0
.goto 650,48.99,40.37
.cast 215275 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r |cRXP_WARN_underneath a bridge in small room|r.
step
#requires Eagle Eggs placed
#label RockcrawlerChasmEnd1
.goto 650,51.66,37.35,15,0
.goto 650,51.70,36.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eggs|r |cRXP_WARN_on the cave|r.
.complete 39305,1 
step
#completewith next
#label Empty Nest
.goto 650,51.64,37.38,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 39305 >>Turn in Empty Nest
.target Oren Windstrider
step
#completewith Empty Nest
#title |cFFFCDC00Enter Cave|r
.goto 650,50.89,36.56,65 >>Enter the Cave
step
#requires Empty Nest
.goto 650,50.89,36.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 39305 >>Turn in Empty Nest
.target Oren Windstrider
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Stonedark Cavern: Trials of Liftbrul Midnight
#internal
step
#completewith next
#label You Lift, Brul?
.goto 650,42.7,25.22,20,0
.goto 659,26.92,71.2,20,0
.goto 659,42.04,62.17,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.accept 39440 >>Accept You Lift, Brul?
.target Damrul the Stronk
step
#completewith You Lift, Brul?
#title |cFFFCDC00Enter Cave|r
.goto 659,52.49,62.72,55 >>Enter the Cave
step
#requires You Lift, Brul?
#label LiftbrulStart1
.goto 659,52.49,62.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.accept 39440 >>Accept You Lift, Brul?
.target Damrul the Stronk
step
.goto 659,53.03,53.20
>>Walk to the Statue
.complete 39440,1 
.skipgossipid 45053
step
#completewith next
#label Return Weights to Damrul
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.complete 39440,2 
.target Damrul the Stronk
step
#completewith Return Weights to Damrul
.goto 659,52.35,61.52
.aura -189912 >>Use the macro in the Active Items frame.
.macro cancelaura,237477 >>/cancelaura Carry Weights
step
#requires Return Weights to Damrul
.goto 659,52.49,62.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.complete 39440,2 
.skipgossipid 45053
.target Damrul the Stronk
step
.goto 659,52.35,62.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.turnin 39440 >>Turn in You Lift, Brul?
.target Damrul the Stronk
.accept 39439 >>Accept Stonedark Relics
.accept 39438 >>Accept Guhruhlruhlruh
.accept 39437 >>Accept Deep in the Cavern
step
#completewith next
#label Deepcavern Murloc
>>Kill |cRXP_ENEMY_Deepcavern Murloc|r
.complete 39437,1 
.mob Deepcavern Murloc
step
#completewith Deepcavern Murloc
.goto 659,57.61,72.24,10,0
.goto 659,63.6,71.07,10 >>Follow the arrow, jump if needed.
step
#requires Deepcavern Murloc
#completewith LiftbrulEnd1
>>Kill |cRXP_ENEMY_Deepcavern Murloc|r
.complete 39437,1 
.mob Deepcavern Murloc
step
#requires Deepcavern Murloc
.goto 659,76.9,53.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chains|r
.complete 39439,1 
step
.goto 659,73.55,76.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chains|r
.complete 39439,2 
step
#label LiftbrulEnd1
.goto 659,46.38,84.86
>>Kill |cRXP_ENEMY_Guhruhlruhlruh|r
.complete 39438,1 
.mob Guhruhlruhlruh
step
.goto 659,54.19,73.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rod|r
.complete 39439,3 
step
#label Stonedark Cavern: Trials of Liftbrul
#loop
.goto 659,66.53,68.87,40,0
.goto 659,73,51.61,40,0
.goto 659,73.53,68.97,40,0
>>Kill |cRXP_ENEMY_Deepcavern Murloc|r
.complete 39437,1 
.mob Deepcavern Murloc
step
.goto 659,52.40,62.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.turnin 39438 >>Turn in Guhruhlruhlruh
.target Damrul the Stronk
.turnin 39437 >>Turn in Deep in the Cavern
.turnin 39439 >>Turn in Stonedark Relics
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Murky Waters Midnight
#internal
step
.isOnQuest 40244
#title |cFFFCDC00Skyride to him|r
.goto 650,42.73,10.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 40244 >>Turn in That Guy in the Costume
.target King Mrgl-Mrgl
.accept 40047 >>Accept I'll Huff, I'll Puff...
.accept 40049 >>Accept Slime Time
.accept 40045 >>Accept Nature vs. Nurture
step
#title |cFFFCDC00Skyride to him|r
.goto 650,42.73,10.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.target King Mrgl-Mrgl
.accept 40047 >>Accept I'll Huff, I'll Puff...
.accept 40049 >>Accept Slime Time
.accept 40045 >>Accept Nature vs. Nurture
step
#label MurkyWatersStart1
#hidewindow
#completewith Tadpole trust2
#loop
.goto 650,43.88,9.86,40,0
.goto 650,44.9,9.42,40,0
.goto 650,45.45,8.36,40,0
.goto 650,45.15,6.86,40,0
.goto 650,44.02,6.68,40,0
.goto 650,44.11,8.53,40,0
.goto 650,42.96,7.85,40,0
.goto 650,42.36,8.89,40,0
.goto 650,41.34,9.32,40,0
+1
step
#completewith Tadpole trust
>>Kill |cRXP_ENEMY_Pufferfish|r. Loot them for |T970831:0|t[|cRXP_LOOT_Pufferfish Egg|r].
.complete 40047,1 
.mob Pufferfish
step
#completewith Tadpole trust
>>Step on the Seaweed
.complete 40049,1 
step
#label Tadpole trust
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Swamprock Tadpole|r
.complete 40045,1 
.target Swamprock Tadpole
step
#completewith next
>>Step on the Seaweed
.complete 40049,1 
step
>>Kill |cRXP_ENEMY_Pufferfish|r. Loot them for |T970831:0|t[|cRXP_LOOT_Pufferfish Egg|r].
.complete 40047,1 
.mob Pufferfish
step
#label Tadpole trust2
>>Step on the Seaweed
.complete 40049,1 
step
#label MurkyWatersEnd1
.goto 650,42.74,10.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 40047 >>Turn in I'll Huff, I'll Puff...
.target King Mrgl-Mrgl
.turnin 40049 >>Turn in Slime Time
.turnin 40045 >>Turn in Nature vs. Nurture
.accept 40102 >>Accept Murlocs: The Next Generation
.accept 40230 >>Accept Oh, the Clawdacity!
step
.isOnQuest 40102
.goto 650,42.77,10.92
.vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r
.complete 40102,1 
step
.goto 650,42.77,10.92
.exitvehicle >>|cRXP_WARN_Leave the vehicle
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#completewith Cavemoss Clacker
>>Kill |cRXP_ENEMY_Cavemoss Clacker|r
.complete 40102,2 
.mob Cavemoss Clacker
step
#completewith next
#label Clawdayshus
>>Kill |cRXP_ENEMY_Clawdayshus|r
.complete 40230,1 
.mob Clawdayshus
step
#completewith Clawdayshus
#title |cFFFCDC00Enter Cave|r
.goto 650,49.56,15.96,60 >>Enter the Cave
step
#requires Clawdayshus
#label Cavemoss Clacker
.goto 650,49.56,15.96
>>Kill |cRXP_ENEMY_Clawdayshus|r
.complete 40230,1 
.mob Clawdayshus
step
#loop
.goto 650,50,13.48,25,0
.goto 650,50.22,11.36,25,0
.goto 650,47.26,12.18,25,0
.goto 650,48.6,13.58,25,0
>>Kill |cRXP_ENEMY_Cavemoss Clacker|r
.complete 40102,2 
.mob Cavemoss Clacker
step
#label Murky Waters
.goto 650,49.38,14.55,20,0
.goto 650,49.57,15.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 40230 >>Turn in Oh, the Clawdacity!
.target King Mrgl-Mrgl
.turnin 40102 >>Turn in Murlocs: The Next Generation
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Kun-Lai Summit My Son
#internal
step
#label My Son...Start
.goto 379,74.97,88.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merchant Shi|r.
.accept 30467 >>Accept My Son...
.accept 30469 >>Accept Repossession
.target Merchant Shi
step
.goto 379,74.80,88.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Swordmistress Mei|r.
.accept 30468 >>Accept Enraged Vengeance
.target Swordmistress Mei
step
.goto 379,75.14,87.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Waterspeaker Gorai|r.
.accept 30496 >>Accept The Waterspeaker's Staff
.accept 30967 >>Accept Free the Dissenters
.target Waterspeaker Gorai
step
#completewith My Son...
>>Kill |cRXP_ENEMY_Enraged Jinyu|r.
.complete 30468,1 
.mob Orachi
.mob Enraged Cavalier
.mob Enraged Priest
.mob Enraged Blacksmith
.mob Enraged Enforcer
.mob Enraged Spearman
.mob Enraged Tideweaver
step
#completewith My Son...
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Stolen Supplies|r.
.complete 30469,1 
step
#completewith My Son...
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Inkgill Dissenters|r.
.complete 30967,1 
.skipgossip
.target Inkgill Dissenter
step
#title |cFFFCDC00NPC Patrols|r
.goto 379,74.27,78.13
>>Kill |cRXP_ENEMY_Orachi|r.
*Loot him |T366767:0|t[|cRXP_LOOT_Staff|r].
.complete 30496,1 
.mob Orachi
step
#label My Son...
.goto 379,74.68,76.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wu-Peng|r.
.turnin 30467 >>Turn in My Son...
.accept 30834 >>Accept Father and Child Reunion
.target Wu-Peng
step
#completewith Turn in The Waterspeaker's Staff
#hidewindow
#loop
.goto 379,73.08,76.26,40,0
.goto 379,73.17,77.19,40,0
.goto 379,74.33,78.61,40,0
.goto 379,74.79,79.76,40,0
.goto 379,74.77,82.39,40,0
.goto 379,73.86,82.87,40,0
.goto 379,73.72,84.08,40,0
.goto 379,74.63,84.98,40,0
.goto 379,73.08,76.26,0
.goto 379,73.17,77.19,0
.goto 379,74.33,78.61,0
.goto 379,74.79,79.76,0
.goto 379,74.77,82.39,0
.goto 379,73.86,82.87,0
.goto 379,73.72,84.08,0
.goto 379,74.63,84.98,0
+1
step
#completewith Inkgill Dissenters
>>Kill |cRXP_ENEMY_Enraged Jinyu|r.
.complete 30468,1 
.mob Enraged Cavalier
.mob Enraged Priest
.mob Enraged Blacksmith
.mob Enraged Enforcer
.mob Enraged Spearman
.mob Enraged Tideweaver
.mob Orachi
step
#completewith Inkgill Dissenters
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30469,1 
step
#label Inkgill Dissenters
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Inkgill Dissenters|r.
.complete 30967,1 
.skipgossip
.target Inkgill Dissenter
step
#completewith next
>>Kill |cRXP_ENEMY_Enraged Jinyu|r.
.complete 30468,1 
.mob Enraged Cavalier
.mob Enraged Priest
.mob Enraged Blacksmith
.mob Enraged Enforcer
.mob Enraged Spearman
.mob Enraged Tideweaver
.mob Orachi
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Stolen Supplies|r.
.complete 30469,1 
step
#label Turn in The Waterspeaker's Staff
>>Kill |cRXP_ENEMY_Enraged Jinyu|r.
.complete 30468,1 
.mob Enraged Cavalier
.mob Enraged Priest
.mob Enraged Blacksmith
.mob Enraged Enforcer
.mob Enraged Spearman
.mob Enraged Tideweaver
.mob Orachi
step
.goto 379,75.21,88.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Waterspeaker Gorai|r.
.turnin 30496 >>Turn in The Waterspeaker's Staff
.turnin 30967 >>Turn in Free the Dissenters
.target Waterspeaker Gorai
step
.goto 379,74.78,88.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Swordmistress Mei|r.
.turnin 30468 >>Turn in Enraged Vengeance
.target Swordmistress Mei
step
.goto 379,74.97,88.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merchant Shi|r.
.turnin 30469 >>Turn in Repossession
.turnin 30834 >>Turn in Father and Child Reunion
.target Merchant Shi
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Kun-Lai Summit Despoiler
#internal
step
#label BurilgiDespoilerStart
#loop
.goto 379,71.57,74.97,40,0
.goto 379,70.74,72.41,40,0
.goto 379,71.55,71.05,40,0
.goto 379,71.57,74.97,0
.goto 379,70.74,72.41,0
.goto 379,71.55,71.05,0
>>Kill |cRXP_ENEMY_Burilgi Despoiler|r.
*Loot him for |T133364:0|t[|cRXP_LOOT_Muskpaw's Keepsake|r].
.accept 30582 >>Accept The Late Mrs. Muskpaw
.mob Burilgi Despoiler
step
#loop
.goto 379,71.71,70.39,15,0
.goto 379,70.83,69,15,0
#title |cFFFCDC00NPC Patrols|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao Muskpaw|r.
.turnin 30582 >>Turn in The Late Mrs. Muskpaw
.accept 30488 >>Accept The Missing Muskpaw
.accept 30489 >>Accept Fresh Needle Scent
.accept 30804 >>Accept The Fearmaster
.target Lao Muskpaw
step
#completewith The Missing Muskpaw2
>>Kill |cRXP_ENEMY_Needle Sprite|r.
*Loot them for |T134439:0|t[|cRXP_LOOT_Pungent Sprite Needles|r].
.complete 30489,1 
.mob Needle Sprite
step
#completewith next
#label The Missing Muskpaw
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muskpaw Jr|r.
.turnin 30488 >>Turn in The Missing Muskpaw
.target Muskpaw Jr.
step
#completewith The Missing Muskpaw
.goto 379,73.05,73.49,20 >>Enter the Cave
step
#requires The Missing Muskpaw
#label The Missing Muskpaw2
.goto 381,16.39,39.7,10,0
.goto 381,26.25,61.08,10,0
.goto 381,41.97,40.32,10,0
.goto 381,53.77,32.01,10,0
.goto 381,65.53,43.08,10,0
.goto 381,63.96,59.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muskpaw Jr|r.
.turnin 30488 >>Turn in The Missing Muskpaw
.target Muskpaw Jr
step
#completewith next
#label Yakity Yak
.goto 381,69.25,53.52,10,0
.goto 381,56.78,33.86,10,0
.goto 381,44.31,33.98,10,0
.goto 381,36.64,52.11,10,0
.goto 381,25.18,59.67,10,0
.goto 381,16.92,41.92,10,0
.goto 379,73.01,73.51,10,0
>>Kill |cRXP_ENEMY_Needle Sprite|r and |cRXP_ENEMY_Burilgi Despoiler|r
*Loot |cRXP_ENEMY_Needle Sprite|r for|T134439:0|t[|cRXP_LOOT_Pungent Sprite Needles|r].
.accept 30587 >>Accept Yakity Yak
.complete 30489,1 
.mob Burilgi Despoiler
.mob Needle Sprite
step
#completewith Yakity Yak
.goto 379,71.57,74.97,110 >>Leave the Cave
step
#requires Yakity Yak
#loop
.goto 379,71.57,74.97,40,0
.goto 379,71.54,71.06,40,0
.goto 379,73.37,72.52,40,0
>>Kill |cRXP_ENEMY_Needle Sprite|r and |cRXP_ENEMY_Burilgi Despoiler|r
*Loot |cRXP_ENEMY_Needle Sprite|r for|T134439:0|t[|cRXP_LOOT_Pungent Sprite Needles|r].
.accept 30587 >>Accept Yakity Yak
.complete 30489,1 
.mob Burilgi Despoiler
.mob Needle Sprite
step
#completewith The Fearmaster
>>Kill |cRXP_ENEMY_Burilgi Despoiler|r.
.complete 30587,1 
.mob Burilgi Despoiler
step
#label The Fearmaster
.goto 379,67.84,73.97
>>Kill |cRXP_ENEMY_The Fearmaster|r.
.complete 30804,1 
.mob The Fearmaster
step
#label BurilgiDespoilerEnd
#loop
.goto 379,68.23,72.25,30,0
.goto 379,70.79,69.97,30,0
.goto 379,65.85,69.81,30,0
>>Kill |cRXP_ENEMY_Burilgi Despoiler|r.
.complete 30587,1 
.mob burilgi despoiler
step
#title |cFFFCDC00NPC Patrols|r
#loop
.goto 379,71.21,69.39,15,0
.goto 379,71.94,70.30,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao Muskpaw|r.
.turnin 30489 >>Turn in Fresh Needle Scent
.turnin 30587 >>Turn in Yakity Yak
.turnin 30804 >>Turn in The Fearmaster
.target Lao Muskpaw
step
.goto 379,65.49,60.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slimy Inkstain|r.
.accept 30614 >>Accept Oil Stop
.target Slimy Inkstain
step
.goto 379,64.88,60.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey Sootassle|r.
.accept 30616 >>Accept Traffic Issues
.target Smokey Sootassle
step
.goto 379,64.71,61.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Eightcoins|r.
.accept 30808 >>Accept A Grummle's Luck
.target Lucky Eightcoins
step
#completewith Filled Oil Vial
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30616,1 
.mob Ruqin Infantry
.mob Ruqin Elder
.mob Ruqin Outrider
step
#completewith Filled Oil Vial
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bags|r.
.complete 30808,1 
step
#label Filled Oil Vial
.goto 379,63.34,68.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Yaungol Oil Derrick|r.
.complete 30614,1 
step
#completewith Ruqin Yaungols
#hidewindow
#loop
.goto 379,62.19,69.29,20,0
.goto 379,62.04,67.93,20,0
.goto 379,63.38,66.86,20,0
.goto 379,62.19,69.29,0
.goto 379,62.04,67.93,0
.goto 379,63.38,66.86,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30616,1 
.mob Ruqin Infantry
.mob Ruqin Elder
.mob Ruqin Outrider
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bags|r.
.complete 30808,1 
step
#label Ruqin Yaungols
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30616,1 
.mob Ruqin Infantry
.mob Ruqin Elder
.mob Ruqin Outrider
step
.goto 379,49.11,70.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brother Rabbitsfoot|r
.complete 30602,1 
.target Brother Rabbitsfoot
step
.goto 379,49.10,70.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.accept 30603 >>Accept The Broketooth Ravage
.target Brother Rabbitsfoot
step
.goto 379,48.08,73.11
>>Kill |cRXP_ENEMY_Mo Mo|r in the cave.
*Loot him for |T134323:0|t[|cRXP_LOOT_Rabbitsfoot's Luckydo|r].
.complete 30603,1 
.mob Mo Mo
step
.goto 379,47.88,73.52
.turnin 31868 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mo-Mo's Treasure Chest|r.
step
.goto 379,51.97,67.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30602 >>Turn in The Rabbitsfoot
.turnin 30603 >>Turn in The Broketooth Ravage
.accept 30599 >>Accept A Monkey Idol
.accept 30600 >>Accept No Pack Left Behind
.accept 30604 >>Accept Breaking Broketooth
.target Brother Rabbitsfoot
step
#completewith Turn in The Leader Hozen
+|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Luckydo's|r for a buff.
.target Luckydo
step
#completewith Dak Dak3
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob broketooth tosser
step
#completewith Dak Dak3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Packers|r
.complete 30600,1 
.target Dead Packer
step
#completewith next
#label Tak Tak
#hidewindow
.complete 30599,3 
step
#completewith Tak Tak
.goto 379,56.66,70.93
>>Kill |cRXP_ENEMY_Tak Tak|r
*Loot him for |T132159:0|t[|cRXP_LOOT_Corpse of Tak Tak|r].
.collect 80430,1,30599,3
step
#requires Tak Tak
#completewith next
#label Tak Tak2
#hidewindow
.complete 30599,3 
step
#requires Tak Tak
#completewith Tak Tak2
.goto 379,56.75,70.97
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Knife|r.
.mob Tak Tak
step
#requires Tak Tak2
#completewith next
#label Ko Ko
#hidewindow
.complete 30599,2 
step
#requires Tak Tak2
#completewith Ko Ko
.goto 379,52.47,71.37
>>Kill |cRXP_ENEMY_Ko Ko|r
*Loot him for |T132189:0|t[|cRXP_LOOT_Corpse of Ko Ko|r].
.collect 80429,1,30599,2
step
#requires Ko Ko
#completewith next
#label Ko Ko2
#hidewindow
.complete 30599,2 
step
#requires Ko Ko
#completewith Ko Ko2
.goto 379,52.27,71.44
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Knife|r.
.mob Ko Ko
step
#requires Ko Ko2
#completewith next
#label Dak Dak
#hidewindow
.complete 30599,1 
step
#requires Ko Ko2
#completewith Dak Dak
#title Enter Cave
.goto 379,52.83,71.41,10 >>Enter the Cave
step
#requires Dak Dak
#completewith next
#label Dak Dak2
#hidewindow
.complete 30599,1 
step
#requires Dak Dak
#completewith Dak Dak2
#loop
#title |cFFFCDC00NPC Patrols|r
.goto 383,54.79,28.62,15,0
.goto 383,35.05,55.28,15,0
.goto 383,41.74,71.35,15,0
.goto 383,58.75,59.33,15,0
.goto 384,50.33,36.53,15,0
>>Kill |cRXP_ENEMY_Dak Dak|r
*Loot him for |T458252:0|t[|cRXP_LOOT_Corpse of Dak Dak|r].
.collect 80428,1,30599,1
.mob Dak Dak
step
#requires Dak Dak2
#completewith next
#label Dak Dak3
#hidewindow
.complete 30599,1 
step
#requires Dak Dak2
#completewith Dak Dak3
.goto 384,49.84,39.7
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r.
.mob Dak Dak
step
#requires Dak Dak3
#hidewindow
#completewith Broketooths
#loop
.goto 384,40.96,49.75,25,0
.goto 383,55.48,64.39,25,0
.goto 383,60.41,42.46,25,0
.goto 379,52.89,71.24,25,0
.goto 379,51.92,70.29,25,0
.goto 379,53.58,69.53,25,0
.goto 379,56.09,70.71,25,0
.goto 379,52.92,71.22,25,0
+1
step
#requires Dak Dak3
#completewith next
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob Broketooth Tosser
step
#requires Dak Dak3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Packers|r
.complete 30600,1 
.target Dead Packer
step
#label Broketooths
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob broketooth tosser
step
.goto 379,51.97,67.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30599 >>Turn in A Monkey Idol
.turnin 30600 >>Turn in No Pack Left Behind
.turnin 30604 >>Turn in Breaking Broketooth
.accept 30605 >>Accept Lucky Yakshoe
.target Brother Rabbitsfoot

]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Kun-Lai Summit Defense Shado-Pan
#internal
step
#completewith next
#label Defense of Shado-Pan
.goto 379,44.5,89.09,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.accept 30665 >>Accept The Defense of Shado-Pan Fallback
.accept 30670 >>Accept Turnabout
.target Shado-Master Chong
step
#completewith Defense of Shado-Pan
#title Enter Castle
.goto 379,44.48,89.93,35 >>Enter the Castle
step
#requires Defense of Shado-Pan
.goto 379,44.48,89.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.accept 30665 >>Accept The Defense of Shado-Pan Fallback
.accept 30670 >>Accept Turnabout
.target Shado-Master Chong
step
.goto 379,44.48,89.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.accept 30665 >>Accept The Defense of Shado-Pan Fallback
.accept 30670 >>Accept Turnabout
.target Shado-Master Chong
step
#completewith next
#label Holed Up
.goto 379,44.51,89.06,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sya Zhong|r |cRXP_WARN_inside the house|r.
.accept 30682 >>Accept Holed Up
.target Sya Zhong
step
#completewith Holed Up
.goto 379,42.94,88.32,100 >>Leave the Castle
step
#requires Holed Up
#completewith Holed Up2
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
#requires Holed Up
#completewith Holed Up2
>>Kill |cRXP_ENEMY_Blind Rage|r.
*Loot them for |T252178:0|t[|cRXP_LOOT_Blind Rage Essence|r].
.complete 30670,1 
.mob Blind Rage
step
#requires Holed Up
#label Holed Up2
.goto 379,42.94,88.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sya Zhong|r |cRXP_WARN_inside the house|r.
.accept 30682 >>Accept Holed Up
.target Sya Zhong
step
#completewith Jin Warmkeg
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
#completewith Jin Warmkeg
>>Kill |cRXP_ENEMY_Blind Rage|r.
*Loot them for |T252178:0|t[|cRXP_LOOT_Blind Rage Essence|r].
.complete 30670,1 
.mob Blind Rage
step
.goto 379,43.12,88.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sya Zhong|r.
.complete 30682,4 
.target Sya Zhong
step
#completewith next
#label Ya Firebough
#hidewindow
.complete 30682,2 
.target Ya Firebough
step
#completewith Ya Firebough
.goto 379,41.07,87.00
.gossipoption 37051 >>Talk to |cRXP_FRIENDLY_Ya Firebough|r.
step
#requires Ya Firebough
#completewith next
#label Old Lady Fung
#hidewindow
.complete 30682,3 
step
#requires Ya Firebough
#completewith Old Lady Fung
.goto 379,41.25,87.13,5,0
.goto 379,42.76,85.87,5,0
.goto 379,42.84,85.7
.gossipoption 37052 >>Talk to |cRXP_FRIENDLY_Old Lady Fung|r.
.target Old Lady Fung
step
#requires Old Lady Fung
#completewith next
#label Jin Warmkeg
#hidewindow
.complete 30682,1 
.target Jin Warmkeg
step
#requires Old Lady Fung
#completewith Jin Warmkeg
.goto 379,43.88,86.17
.gossipoption 35293 >>Talk to |cRXP_FRIENDLY_Jin Warmkeg|r.
.target Old Lady Fung
step
#requires Jin Warmkeg
#completewith Sha-Infested Yaungol
#hidewindow
#loop
.goto 379,45.15,88.27,40,0
.goto 379,42.89,87.97,40,0
.goto 379,41.06,86.39,40,0
.goto 379,42.80,86.06,40,0
.goto 379,45.15,88.27,0
.goto 379,42.89,87.97,0
.goto 379,41.06,86.39,0
.goto 379,42.80,86.06,0
+1
step
#requires Jin Warmkeg
#completewith next
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
#requires Jin Warmkeg
>>Kill |cRXP_ENEMY_Blind Rage|r.
*Loot them for |T252178:0|t[|cRXP_LOOT_Blind Rage Essence|r].
.complete 30670,1 
.mob Blind Rage
step
#label Sha-Infested Yaungol
>>Kill |cRXP_ENEMY_Taurens|r.
.complete 30665,1 
.mob Sha-Infested Yaungol
step
#completewith next
#label Turnabout
.goto 379,44.51,89.06,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.turnin 30665 >>Turn in The Defense of Shado-Pan Fallback
.turnin 30670 >>Turn in Turnabout
.turnin 30682 >>Turn in Holed Up
.accept 30690 >>Accept Unmasking the Yaungol
.disablecheckbox
.target Shado-Master Chong
step
#completewith Turnabout
.goto 379,44.47,89.94,20 >>Enter the Castle
step
#requires Turnabout
.goto 379,44.47,89.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.turnin 30665 >>Turn in The Defense of Shado-Pan Fallback
.turnin 30670 >>Turn in Turnabout
.turnin 30682 >>Turn in Holed Up
.accept 30690 >>Accept Unmasking the Yaungol
.target Shado-Master Chong
step
#completewith next
#label KobaiTrap1
#hidewindow
.complete 30690,1 
step
#completewith KobaiTrap1
.goto 379,45.35,86.14
.cast 118938 >>Use |T537467:0|t[Blinding Rage Trap] near |cRXP_ENEMY_Kobai|r.
.use 81741
.mob Kobai
step
#requires KobaiTrap1
#completewith next
#label KobaiTrap2
#hidewindow
.complete 30690,1 
step
#requires KobaiTrap1
#completewith KobaiTrap2
.cast 118984 >>Kite |cRXP_ENEMY_Kobai|r into the trap and then use the ExtraActionButton.
.use 118984
.mob Kobai
step
#requires KobaiTrap2
.goto 379,45.35,86.14
>>Kill |cRXP_ENEMY_Malevolent Fury|r.
.complete 30690,2 
.mob malevolent fury
step
#completewith next
#label Winter's Blossom
.goto 379,44.51,89.06,12,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.turnin 30690 >>Turn in Unmasking the Yaungol
.target Shado-Master Chong
.accept 30699 >>Accept To Winter's Blossom
.disablecheckbox
step
#completewith Winter's Blossom
.goto 379,44.48,89.92,30 >>Enter the Castle
step
#requires Winter's Blossom
.goto 379,44.48,89.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.turnin 30690 >>Turn in Unmasking the Yaungol
.target Shado-Master Chong
.accept 30699 >>Accept To Winter's Blossom
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Defiance
#internal
step
.goto 371,43.49,75.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shao the Defiant|r.
.accept 29578 >>Accept Defiance
.accept 29579 >>Accept Rally the Survivors
.target Shao the Defiant
step
#title |cFFFCDC00NPC Patrols|r
.goto 371,43.24,76.06,5,0
.goto 371,43.29,75.68,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gentle Mother Hanae|r.
.accept 29580 >>Accept Orchard-Supplied Hardware
.accept 29585 >>Accept Spitfire
.target Gentle Mother Hanaed
step
#completewith Turn in Defiance
#hidewindow
#loop
.goto 371,43.40,75.36,20,0
.goto 371,43.06,74.88,20,0
.goto 371,43.21,73.76,20,0
.goto 371,43.72,72.16,20,0
.goto 371,43.72,71.14,20,0
.goto 371,44.27,71.18,20,0
.goto 371,44.42,71.82,20,0
.goto 371,44.34,72.51,20,0
.goto 371,44.64,73.35,20,0
.goto 371,44.49,74.45,20,0
.goto 371,43.91,75.07,20,0
.goto 371,44.66,75.61,20,0
.goto 371,43.98,76.54,20,0
.goto 371,43.40,75.36,0
.goto 371,43.06,74.88,0
.goto 371,43.21,73.76,0
.goto 371,43.72,72.16,0
.goto 371,43.72,71.14,0
.goto 371,44.27,71.18,0
.goto 371,44.42,71.82,0
.goto 371,44.34,72.51,0
.goto 371,44.64,73.35,0
.goto 371,44.49,74.45,0
.goto 371,43.91,75.07,0
.goto 371,44.66,75.61,0
.goto 371,43.98,76.54,0
+1
step
#completewith Orchard Fires
>>Kill |cRXP_ENEMY_Gormalis|r.
*|cRXP_WARN_Prioritize those fighting the |cRXP_FRIENDLY_Nectarbreeze Farmers|r.
.complete 29578,1 
.complete 29578,2 
.mob gormali incinerator
step
#completewith Orchard Fires
>>Click on the |cRXP_PICK_Tools|r.
.complete 29580,1 
step
#completewith Orchard Fires
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nectarbreeze Farmer|r.
.complete 29579,1 
.skipgossip
.target Nectarbreeze Farmer
step
#label Orchard Fires
>>Use |T463863:0|t[Nectarbreeze Cider]|cRXP_WARN_(a frontal on fire)|r.
.complete 29585,1 
.use 72578
step
#completewith Survivors
>>Kill |cRXP_ENEMY_Gormalis|r.
*|cRXP_WARN_Prioritize those fighting the |cRXP_FRIENDLY_Nectarbreeze Farmers|r.
.complete 29578,1 
.complete 29578,2 
.mob gormali incinerator
step
#completewith Survivors
>>Click on the |cRXP_PICK_Tools|r.
.complete 29580,1 
step
#label Survivors
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nectarbreeze Farmer|r.
.complete 29579,1 
.skipgossip
.target Nectarbreeze Farmer
step
#completewith next
>>Kill |cRXP_ENEMY_Gormalis|r.
*|cRXP_WARN_Prioritize those fighting the |cRXP_FRIENDLY_Nectarbreeze Farmers|r.
.complete 29578,1 
.complete 29578,2 
.mob gormali incinerator
step
>>Click on the |cRXP_PICK_Tools|r.
.complete 29580,1 
step
#label Turn in Defiance
>>Kill |cRXP_ENEMY_Gormalis|r.
*|cRXP_WARN_Prioritize those fighting the |cRXP_FRIENDLY_Nectarbreeze Farmers|r.
.complete 29578,1 
.complete 29578,2 
.mob gormali incinerator
step
.goto 371,43.49,75.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shao the Defiant|r.
.turnin 29578 >>Turn in Defiance
.turnin 29579 >>Turn in Rally the Survivors
.target Shao the Defiant
step
#title |cFFFCDC00NPC Patrols|r
.goto 371,43.24,76.06,5,0
.goto 371,43.29,75.68,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gentle Mother Hanae|r |cRXP_WARN_inside the house|r.
.turnin 29580 >>Turn in Orchard-Supplied Hardware
.turnin 29585 >>Turn in Spitfire
.target Gentle Mother Hanae
step
.goto 371,43.21,75.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Traumatized Nectarbreeze Farmer|r.
.accept 29586 >>Accept The Splintered Path
.target Traumatized Nectarbreeze Farmer
step
#completewith next
#label Mogu Camp
.goto 371,43.47,75.91,5,0
>>|cRXP_WARN_Follow the Arrow|r.
.complete 29586,1 
step
#completewith Mogu Camp
.goto 371,41.01,73.97,175 >>Leave the House
step
#requires Mogu Camp
.goto 371,41.01,73.97
>>|cRXP_WARN_Follow the Arrow|r.
.complete 29586,1 
step
.goto 371,41.00,73.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shao the Defiant|r.
.turnin 29586 >>Turn in The Splintered Path
.accept 29587 >>Accept Unbound
.accept 29670 >>Accept Maul Gormal
.target Shao the Defiant
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Farmers|r.
.complete 29587,1 
.mob Gormali Slaver
.target Captured Nectarbreeze Farmer
step
.goto 371,40.35,74.44,20,0
.goto 371,39.81,75.64,20,0
.goto 371,39.65,74.43,20,0
.goto 371,37.8,76.19
>>Kill |cRXP_ENEMY_Subjugator Gormal|r.
.complete 29670,1 
.mob Subjugator Gormal
step
#loop
.goto 371,37.78,76.92,20,0
.goto 371,38.86,76.28,20,0
.goto 371,39.73,75.51,20,0
.goto 371,40.39,74.56,20,0
.goto 371,39.53,74.26,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Farmers|r.
.complete 29587,1 
.mob Gormali Slaver
.target Captured Nectarbreeze Farmer
step
.goto 371,40.99,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shao the Defiant|r.
.turnin 29587 >>Turn in Unbound
.turnin 29670 >>Turn in Maul Gormal
.target Shao the Defiant
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Tian Monastery
#internal
step
#completewith next
.cast 441154 >> Use |T134491:0|t[Nostwin's Voucher] to teleport to Infinite Bazaar.
.use 217930
.itemcount 217930,1
step
.goto 371,42.96,27.44 
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arturos|r.
.accept 80446 >>Accept Looking for Group
.target Arturos






step
#hidewindow
#completewith All
#label all2
.achievement 20005,0
.achievement 19881,0
.achievement 20006,0
.achievement 20004,0
.achievement 40223,0
step
#completewith all2
.goto 371,43.01,27.58
.achievementComplete 40223,1
.collect 208555,1 >>Talk to |cRXP_FRIENDLY_Lidamorrutu|r and buy |T634012:0|t[Timerunner's Idol.]
.skipgossip
.buy 208555,1
.target Lidamorrutu
step
#completewith all2
.goto 371,43.01,27.58
.achievementComplete 20004,1
.collect 208487,1 >>Talk to |cRXP_FRIENDLY_Lidamorrutu|r and buy |T629696:0|t[Timerunner's Ring.]
.skipgossip
.buy 208487,1
.target Lidamorrutu
step
#completewith all2
.goto 371,43.01,27.58
.achievementComplete 20005,1
.collect 208491,1 >>Talk to |cRXP_FRIENDLY_Lidamorrutu|r and buy |T645143:0|t[Timerunner's Seal.]
.skipgossip
.buy 208491,1
.target Lidamorrutu
step
#completewith all2
.goto 371,43.01,27.58
.achievementComplete 20006,1
.collect 210523,1 >>Talk to |cRXP_FRIENDLY_Lidamorrutu|r and buy |T632849:0|t[Timerunner's Amulet.]
.skipgossip
.buy 210523,1
.target Lidamorrutu
step
#completewith all2
#label All
.goto 371,43.01,27.58
.achievementComplete 19881,0
.collect 208554,1 >>Talk to |cRXP_FRIENDLY_Lidamorrutu|r and buy |T971287:0|t[Timerunner's Beacon.]
.skipgossip
.buy 208554,1
.target Lidamorrutu
step
.achievementComplete 20005,0
.achievementComplete 19881,0
.achievementComplete 20006,0
.achievementComplete 20004,0
.achievementComplete 40223,0
.goto 371,43.01,27.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lidamorrutu|r and buy the jewellery.
.collect 208491,1
.collect 210523,1
.collect 208554,1
.collect 208555,1
.collect 208487,1
.buy 208487,1
.buy 208555,1
.buy 208555,1
.buy 208554,1
.buy 208491,1
.buy 210523,1
.skipgossip
.target Lidamorrutu
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pythagorus|r and |cRXP_FRIENDLY_Larah Treebender|r.
.accept 80447 >>Accept Looking for More
.goto 371,42.95,27.73 
.target +Pythagorus
.accept 80448 >>Accept A Fresh Scene
.goto 371,42.81,27.62 
.target +Larah Treebender





step
#completewith next
.goto 371,42.5,27.32,10,0
.vendor >>Talk to |cRXP_FRIENDLY_Momentus|r and upgrade your gear |cRXP_WARN_It's recommended for faster leveling but uses bronze, a cosmetic currency|r.
.skipgossip
.target Momentus
step
.goto 371,44.99,24.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lin Tenderpaw|r.
.target Lin Tenderpaw
.accept 29618 >>Accept The High Elder
step
.goto 371,45.22,25.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Elder Cloudfall|r |cRXP_WARN_on the balcony|r.
.turnin 29618 >>Turn in The High Elder
.target High Elder Cloudfall
step
.goto 371,44.99,24.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lin Tenderpaw|r.
.accept 29619 >>Accept A Courteous Guest
.target Lin Tenderpaw
step
#loop
.goto 371,45.67,26.91,10,0
.goto 371,45.96,27.19,10,0
.goto 371,45.92,27.68,10,0
.goto 371,45.63,27.50,10,0
.goto 371,45.67,26.91,0
.goto 371,45.96,27.19,0
.goto 371,45.92,27.68,0
.goto 371,45.63,27.50,0
>>Kill |cRXP_ENEMY_Greenwood Thieves|r. Loot them for [|cRXP_LOOT_Ripe Orange|r].
.complete 29619,1 
.mob Greenwood Thief
step
.goto 371,44.99,24.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lin Tenderpaw|r.
.turnin 29619 >>Turn in A Courteous Guest
.target Lin Tenderpaw
.accept 29620 >>Accept The Great Banquet
step
#hidewindow
#completewith next
#label SkipElderCloudfall
.gossipoption 39493 >>Talk to |cRXP_FRIENDLY_High Elder Cloudfall|r. (for the skip)
.gossipoption 40364 >>Talk to |cRXP_FRIENDLY_High Elder Cloudfall|r. (for the skip)
.goto 371,42.75,23.17
step
.isOnQuest 29620
#completewith next
.gossipoption 39491 >>Talk to |cRXP_FRIENDLY_High Elder Cloudfall|r.

.timer 162, RP
.target High Elder Cloudfall
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Elder Cloudfall|r.
.goto 371,42.75,23.17
.complete 29620,1 
.target High Elder Cloudfall
step
.goto 371,42.74,23.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Elder Cloudfall|r.
.turnin 29620 >>Turn in The Great Banquet
.timer 8, RP
.target High Elder Cloudfall
step
.goto 371,43.13,23.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xiao|r.
.accept 29622 >>Accept Your Training Starts Now
.accept 29626 >>Accept Groundskeeper Wu
.target Xiao
step
.goto 371,43.24,24.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Stone Fist|r.
.accept 29632 >>Accept Becoming Battle-Ready
.target Master Stone Fist
step
#loop
.goto 371,43.26,25.12,15,0
.goto 371,43.47,25.42,15,0
.goto 371,43.81,25.36,15,0
.goto 371,44.13,25.03,15,0
.goto 371,43.81,24.71,15,0
.goto 371,43.26,25.12,0
.goto 371,43.47,25.42,0
.goto 371,43.81,25.36,0
.goto 371,44.13,25.03,0
.goto 371,43.81,24.71,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tian Pupil|r to challenge them to duel. |cRXP_WARN_You can fight multiple at once if you dare|r.
.complete 29632,1 
.skipgossip
.target Tian Pupil
step
.goto 371,43.24,24.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Stone Fist|r.
.turnin 29632 >>Turn in Becoming Battle-Ready
.target Master Stone Fist
.accept 29633 >>Accept Zhi-Zhi, the Dextrous
.accept 29634 >>Accept Husshun, the Wizened
step
#completewith next
.goto 371,43.06,26.01
.gossipoption 40594 >> Talk to |cRXP_FRIENDLY_Zhi-Zhi|r.
.target Zhi-Zhi
step
>>Kill |cRXP_ENEMY_Zhi-Zhi|r.
.goto 371,43.06,26.01
.complete 29633,1 
.mob Zhi-Zhi
step
#completewith next
.goto 371,44.57,24.06
.gossipoption 40595 >> Talk to |cRXP_FRIENDLY_Husshun|r.
.target Husshun
step
.goto 371,44.57,24.06
>>Kill |cRXP_ENEMY_Husshun|r.
.complete 29634,1 
.mob Husshun
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Stone Fist|r.
.turnin 29633 >>Turn in Zhi-Zhi, the Dextrous
.turnin 29634 >>Turn in Husshun, the Wizened
.accept 29635 >>Accept Xiao, the Eater
.goto 371,43.24,24.76
.target Master Stone Fist
step
.isOnQuest 29633
.goto 371,43.06,26.01
.gossipoption 40594 >> Talk to |cRXP_FRIENDLY_Zhi-Zhi|r.
.target Zhi-Zhi
step
#completewith next
.goto 371,43.13,23.65
.gossipoption 40337 >> Talk to |cRXP_FRIENDLY_Xiao|r.
.target Xiao
step
.goto 371,43.13,23.65
>>Kill |cRXP_ENEMY_Xiao|r.
.complete 29635,1 
.mob Xiao
step
.goto 371,43.23,24.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Stone Fist|r.
.turnin 29635 >>Turn in Xiao, the Eater
.target Master Stone Fist
.accept 29636 >>Accept A Test of Endurance
step
.solo
.goto 371,41.61,28.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Xann|r.
.turnin 29622 >>Turn in Your Training Starts Now
.target Instructor Xann
step
.group
.goto 371,41.61,28.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Xann|r.
.turnin 29622 >>Turn in Your Training Starts Now
.accept 29623 >>Accept Perfection
.target Instructor Xann
step
.group
.goto 371,41.61,28.34
>>|cRXP_WARN_Face your |cFFFF0000character|r away from the training grounds and aim your |cFFFF0000camera|r towards it|r.
*After the |cRXP_FRIENDLY_Tian Students|r copy the |cFFFF0000master's action|r,use |T135906:0|t[Punch(1)] for a punch, |T132219:0|t[Kick(2)] for a stomp, and |T236169:0|t[Growl(3)] for a growl.
.complete 29623,1 
.target Tian Student
step
.group
.goto 371,41.61,28.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Xann|r.
.turnin 29623 >>Turn in Perfection
.target Instructor Xann
.accept 29624 >>Accept Attention
step
.group
.goto 371,41.15,27.98
>>Kill |cRXP_ENEMY_Training Bags|r.
.complete 29624,1 
.mob training bag
step
.group
.goto 371,41.61,28.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Xann|r.
.turnin 29624 >>Turn in Attention
.target Instructor Xann
step
.goto 371,41.61,23.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Groundskeeper Wu|r.
.turnin 29626 >>Turn in Groundskeeper Wu
.target Groundskeeper Wu
.accept 29627 >>Accept A Proper Weapon
step
#completewith 
>>Click on the |cRXP_PICK_Bambus|r.
.complete 29627,1 
step
.goto 371,41.40,24.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_June Whiteblossom|r.
.buy 72954,1
.complete 29627,2 
.target June Whiteblossom
step
#label 
.goto 371,41.77,24.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brewmaster Lei Kanglei|r.
.buy 72979,3
.complete 29627,3 
.target Brewmaster Lei Kanglei
step
#loop
.goto 371,41.86,24.87,20,0
.goto 371,42.28,24.64,20,0
.goto 371,41.87,23.99,20,0
.goto 371,41.35,23.17,20,0
.goto 371,41.10,23.07,20,0
.goto 371,40.89,23.72,20,0
.goto 371,41.01,24.14,20,0
.goto 371,41.86,24.87,0
.goto 371,42.28,24.64,0
.goto 371,41.87,23.99,0
.goto 371,41.35,23.17,0
.goto 371,41.10,23.07,0
.goto 371,40.89,23.72,0
.goto 371,41.01,24.14,0
>>Click on the |cRXP_PICK_Bambus|r.
.complete 29627,1 
step
.goto 371,41.62,23.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Groundskeeper Wu|r.
.turnin 29627 >>Turn in A Proper Weapon
.accept 29629 >>Accept A Steady Hand
.accept 29630 >>Accept And a Heavy Fist
.target Groundskeeper Wu
step
.goto 371,38.97,24.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Myang|r.
.turnin 29636 >>Turn in A Test of Endurance
.target Instructor Myang
step
.goto 371,38.02,23.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard Shan Long|r.
.accept 29631 >>Accept Burning Bright
.target Guard Shan Long
step
#hidewindow
#completewith Waxwood Hunter
#loop
.goto 371,37.18,20.65,25,0
.goto 371,36.41,22.21,25,0
.goto 371,35.36,23.41,25,0
.goto 371,34.62,23.61,25,0
.goto 371,34.31,22.87,25,0
.goto 371,33.93,21.73,25,0
.goto 371,33.59,21.70,25,0
.goto 371,33.67,21.05,25,0
.goto 371,33.29,19.95,25,0
.goto 371,33.79,20.01,25,0
.goto 371,34.99,20.93,25,0
.goto 371,36.05,21.92,25,0







+1
step
#completewith Blushleaf Extract
>>Kill |cRXP_ENEMY_Greenwood Trickster|r.
.complete 29630,1 
.mob greenwood trickster
step
#completewith Blushleaf Extract
>>Kill |cRXP_ENEMY_Waxwood Hunter|r.
.complete 29631,1 
.mob waxwood hunter
step
#label Blushleaf Extract
.goto 371,37.18,20.65,0
.goto 371,38.31,21.43,0
.goto 371,36.41,22.21,0
.goto 371,35.36,23.41,0
.goto 371,34.62,23.61,0
.goto 371,34.32,23.72,0
.goto 371,34.31,22.87,0
.goto 371,33.93,21.73,0
.goto 371,33.59,21.70,0
.goto 371,33.67,21.05,0
.goto 371,33.29,19.95,0
.goto 371,33.79,20.01,0
.goto 371,34.99,20.93,0
.goto 371,36.05,21.92,0







>>Click on |cRXP_PICK_Blushleaf Cluster|r |cRXP_WARN_and wait until the channel is over (you're not allowed to move or turn or your character)|r.
.complete 29629,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Greenwood Trickster|r.
.complete 29630,1 
.mob greenwood trickster
step
.goto 371,37.18,20.65,0
.goto 371,38.31,21.43,0
.goto 371,36.41,22.21,0
.goto 371,35.36,23.41,0
.goto 371,34.62,23.61,0
.goto 371,34.32,23.72,0
.goto 371,34.31,22.87,0
.goto 371,33.93,21.73,0
.goto 371,33.59,21.70,0
.goto 371,33.67,21.05,0
.goto 371,33.29,19.95,0
.goto 371,33.79,20.01,0
.goto 371,34.99,20.93,0
.goto 371,36.05,21.92,0







#label Waxwood Hunter
>>Kill |cRXP_ENEMY_Waxwood Hunter|r.
.complete 29631,1 
.mob waxwood hunter
step
#loop
.goto 371,37.83,18.34,20,0
.goto 371,37.70,20.48,20,0
.goto 371,37.75,22.54,20,0
.goto 371,36.65,21.73,20,0
.goto 371,38.31,17.65,20,0
.goto 371,37.83,18.34,0
.goto 371,37.70,20.48,0
.goto 371,37.75,22.54,0
.goto 371,36.65,21.73,0
.goto 371,38.31,17.65,0
>>Kill |cRXP_ENEMY_Greenwood Trickster|r.
.complete 29630,1 
.mob greenwood trickster













step
#label Burning Bright
.goto 371,38.02,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard Shan Long|r.
.turnin 29631 >>Turn in Burning Bright
.target Guard Shan Long




step
.convertquest 29646,29646 << Horde
.goto 371,41.60,23.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Groundskeeper Wu|r.

.turnin 29629 >>Turn in A Steady Hand
.turnin 29630 >>Turn in And a Heavy Fist

.target Groundskeeper Wu






]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Sprites Plight Midnight
#internal
step
.goto 371,48.67,24.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Outcast Sprite|r.
.accept 29745 >>Accept The Sprites' Plight
.target Outcast Sprite
step
#completewith next
.goto 371,49.22,22.72,20,0
.goto 371,48.71,21.13,20,0
>>Kill |cRXP_ENEMY_Stonebound Destroyer|r.
.complete 29745,1 
.mob stonebound destroyer
step
.goto 371,48.58,20.63
>>|cRXP_WARN_Follow the Arrow|r.
.complete 29745,2 
step
#loop
.goto 371,47.55,20.83,20,0
.goto 371,49.90,19.47,20,0
.goto 371,49.22,22.72,20,0
.goto 371,48.71,21.13,20,0
.goto 371,47.55,20.83,0
.goto 371,49.90,19.47,0
.goto 371,49.22,22.72,0
.goto 371,48.71,21.13,0
>>Kill |cRXP_ENEMY_Stonebound Destroyer|r.
.complete 29745,1 
.mob stonebound destroyer
step
.goto 371,49.04,20.86
>>Click on the popup to turn in the quest.
.turnin 29745 >>Turn in The Sprites' Plight
.accept 29747 >>Accept Break the Cycle
step
.goto 371,48.57,20.63
>>Click on the |cRXP_PICK_Mogu Head|r.
.accept 29748 >>Accept Simulacrumble
.target Shattered Destroyer
step
#completewith Vacant Destroyer
#hidewindow
#loop
.goto 371,48.44,20.61,20,0
.goto 371,48.33,18.78,20,0
.goto 371,47.79,18.20,20,0
.goto 371,47.18,16.91,20,0
.goto 371,46.95,16.13,20,0
.goto 371,46.32,15.78,20,0
.goto 371,48.44,20.61,0
.goto 371,48.33,18.78,0
.goto 371,47.79,18.20,0
.goto 371,47.18,16.91,0
.goto 371,46.95,16.13,0
.goto 371,46.32,15.78,0
+1
step
#completewith next
>>Click on the |cRXP_PICK_Statues|r.
.complete 29748,1 
step
>>Kill |cRXP_ENEMY_Shan'ze Spiritbinder|r.
.complete 29747,1 
.mob shan'ze spiritbinder
step
#label Vacant Destroyer
>>Click on the |cRXP_PICK_Statues|r.
.complete 29748,1 
step
.goto 371,47.99,18.74
>>Click on the popup to turn in the quest.
.turnin 29747 >>Turn in Break the Cycle
.turnin 29748 >>Turn in Simulacrumble
.accept 29749 >>Accept An Urgent Plea
step
.goto 371,44.23,14.95
>>Click on the |cRXP_PICK_Staff|r.
.complete 29749,1 

step
.goto 371,44.363,15.629
>>Kill |cRXP_ENEMY_Ancient Spirits|r until quest completion (you have to kill 20 mobs to fill the bar).
.complete 29749,2 
.mob Ancient Spirit
step
#completewith next
.logout >> |cRXP_WARN_Press Escape and select Logout|r wait until you can log back in to skip roleplay.
step
.goto 371,44.23,15.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pei-Zhi|r.
.turnin 29749 >>Turn in An Urgent Plea
.accept 29750 >>Accept Vessels of the Spirit
.accept 29751 >>Accept Ritual Artifacts
.accept 29752 >>Accept The Wayward Dead
.target Pei-Zhi

step
#completewith Chipped Ritual Bowl
>>Kill |cRXP_ENEMY_Shan'ze Spiritclaws|r. Loot them for the |T461804:0|t[|cRXP_LOOT_Spirit Bottles|r].
.complete 29750,1 
.mob Shan'ze Spiritclaw
step
#completewith Chipped Ritual Bowl
>>Click on |cRXP_ENEMY_Wayward Ancestor|r. |cRXP_WARN_You can walk during the cast|r.
.complete 29752,1 
.use 74771
.mob Wayward Ancestor
step
.goto 371,42.69,15.75
>>Click on |cRXP_PICK_Jade Cong|r.
.complete 29751,1 
step
.goto 371,42.28,17.1
>>Click on the |cRXP_PICK_Candle|r.
.complete 29751,3 
step
.goto 371,41.64,14.3
#label Chipped Ritual Bowl
>>Click on the |cRXP_PICK_Bowl|r.
.complete 29751,2 
step
#completewith Spirit Bottle
#hidewindow
#loop
.goto 371,40.29,15.13,20,0
.goto 371,40.35,13.82,20,0
.goto 371,41.10,14.15,20,0
.goto 371,41.61,17.42,20,0
.goto 371,40.29,15.13,0
.goto 371,40.35,13.82,0
.goto 371,41.10,14.15,0
.goto 371,41.61,17.42,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Shan'ze Spiritclaws|r. Loot them for the |T461804:0|t[|cRXP_LOOT_Spirit Bottles|r].
.complete 29750,1 
.mob Shan'ze Spiritclaw
step
>>Click on |cRXP_ENEMY_Wayward Ancestor|r. |cRXP_WARN_You can walk during the cast|r.
.complete 29752,1 
.use 74771
.mob Wayward Ancestor
step
#label Spirit Bottle
>>Kill |cRXP_ENEMY_Shan'ze Spiritclaws|r. Loot them for [|cRXP_LOOT_Spirit Bottles|r].
.complete 29750,1 
.mob Shan'ze Spiritclaw
step
.goto 371,44.24,15.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pei-Zhi|r.
.turnin 29750 >>Turn in Vessels of the Spirit
.turnin 29751 >>Turn in Ritual Artifacts
.turnin 29752 >>Turn in The Wayward Dead
.accept 29753 >>Accept Back to Nature
.accept 29756 >>Accept A Humble Offering
.target Pei-Zhi
step
#completewith Tidemist Cap
#hidewindow
#loop
.goto 371,40.15,11.19,40,0
.goto 371,38.81,09.96,40,0
.goto 371,38.11,10.50,40,0
.goto 371,37.69,12.00,40,0
.goto 371,38.29,12.58,40,0
.goto 371,39.19,12.60,40,0
.goto 371,40.15,11.76,40,0
.goto 371,40.15,11.19,0
.goto 371,38.81,09.96,0
.goto 371,38.11,10.50,0
.goto 371,37.69,12.00,0
.goto 371,38.29,12.58,0
.goto 371,39.19,12.60,0
.goto 371,40.15,11.76,0
+1

step
#completewith next
>>Click on the |cRXP_PICK_Tidemist Caps|r.
.complete 29756,1 
step
>>Use |T461804:0|t[Spirit Bottles] on the ground |cRXP_WARN_on cooldown|r. Kill emerging |cRXP_ENEMY_Raging Beast Spirit|r.
.complete 29753,1 
.use 74808
.mob Raging Beast Spirit
step
#label Tidemist Cap
>>Click on the |cRXP_PICK_Tidemist Caps|r.
.complete 29756,1 
step
.goto 371,44.24,15.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pei-Zhi|r.
.turnin 29753 >>Turn in Back to Nature
.turnin 29756 >>Turn in A Humble Offering

.timer 147,RP
.target Pei-Zhi





















]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Jade Forest Cloud Serpent Side Quests
#internal
step
#completewith next
.goto 371,65.25,37.20,20,0
.cast 437035 >>Use |T134376:0|t[Bronze Timepiece] to teleport to the dragonriding quests.
.itemcount 216712,1
.use 216712









step
.goto 371,57.64,44.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Anli|r.

.accept 30134 >>Accept Wild Things
.target Elder Anli










step
#completewith next
.goto 371,65.25,37.20,20,0
.cast 437035 >>Use |T134376:0|t[Bronze Timepiece] to teleport to the dragonriding quests.
.itemcount 216712,1
.use 216712
step
.goto 371,65.33,31.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Tong|r.
.turnin 30134 >>Turn in Wild Things
.accept 30135 >>Accept Beating the Odds
.accept 30136 >>Accept Empty Nests
.accept 30137 >>Accept Egg Collection
.target Instructor Tong
step
#completewith Interact with Windward Hatchlings
#hidewindow
#loop
.goto 371,65.25,32.10,20,0
.goto 371,64.75,32.28,20,0
.goto 371,64.74,31.10,20,0
.goto 371,64.69,30.44,20,0
.goto 371,64.54,29.52,20,0
.goto 371,65.25,29.19,20,0
.goto 371,65.53,29.54,20,0
.goto 371,65.25,32.10,0
.goto 371,64.75,32.28,0
.goto 371,64.74,31.10,0
.goto 371,64.69,30.44,0
.goto 371,64.54,29.52,0
.goto 371,65.25,29.19,0
.goto 371,65.53,29.54,0
+1
step
#completewith Interact with Windward Hatchlings
>>Kill |cRXP_ENEMY_Slitherscale Saurok|r.
.complete 30135,1 
.mob Slitherscale Eggdrinker
step
.isOnQuest 30136
.cast 110171 >>Interact with a |cRXP_FRIENDLY_Windward Hatchling|r |cRXP_WARN_[1]|r.
.use 78947
.target Windward Hatchlings
step
.isOnQuest 30136
.cast 110171 >>Interact with a |cRXP_FRIENDLY_Windward Hatchling|r |cRXP_WARN_[2]|r.
.use 78947
.target Windward Hatchlings
step
.isOnQuest 30136
.cast 110171 >>Interact with a |cRXP_FRIENDLY_Windward Hatchling|r |cRXP_WARN_[3]|r.
.use 78947
.target Windward Hatchlings
step
.isOnQuest 30136
.cast 110171 >>Interact with a |cRXP_FRIENDLY_Windward Hatchling|r |cRXP_WARN_[4]|r.
.use 78947
.target Windward Hatchlings
step
.isOnQuest 30136
.cast 110171 >>Interact with a |cRXP_FRIENDLY_Windward Hatchling|r |cRXP_WARN_[5]|r.
.use 78947
.target Windward Hatchlings
step
#label Interact with Windward Hatchlings
.isOnQuest 30136
.cast 110171 >>Interact with a |cRXP_FRIENDLY_Windward Hatchling|r |cRXP_WARN_[6]|r.
.use 78947
.target Windward Hatchlings
step
.goto 371,65.18,30.07,-1
.goto 371,65.64,30.22,-1
.goto 371,65.71,30.69,-1
.goto 371,65.8,31.25,-1
>>|cRXP_WARN_Follow the Arrow|r.
.complete 30136,1 
step
#completewith Slitherscale saurok
#hidewindow
#loop
.goto 371,66.85,28.05,20,0
.goto 371,67.43,27.94,20,0
.goto 371,67.75,28.87,20,0
.goto 371,67.77,30.25,20,0
.goto 371,67.73,31.90,20,0
.goto 371,68.74,32.16,20,0
.goto 371,69.03,29.14,20,0
.goto 371,69.07,27.93,20,0
.goto 371,69.06,26.11,20,0
.goto 371,68.14,25.30,20,0
.goto 371,66.85,28.05,0
.goto 371,67.43,27.94,0
.goto 371,67.75,28.87,0
.goto 371,67.77,30.25,0
.goto 371,67.73,31.90,0
.goto 371,68.74,32.16,0
.goto 371,69.03,29.14,0
.goto 371,69.07,27.93,0
.goto 371,69.06,26.11,0
.goto 371,68.14,25.30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Slitherscale saurok|r.
.complete 30135,1 
.mob Slitherscale Eggdrinker
.mob Slitherscale Ripper
step
>>Click on |cRXP_PICK_Serpent Eggs|r.
.complete 30137,1 
step
#label Slitherscale saurok
>>Kill |cRXP_ENEMY_Slitherscale saurok|r.
.complete 30135,1 
.mob Slitherscale Eggdrinker
.mob Slitherscale Ripper
step
#completewith next
.goto 371,65.25,37.20,20,0
.cast 437035 >>Use |T134376:0|t[Bronze Timepiece] to teleport to the dragonriding quests.
.itemcount 216712,1
.use 216712
step
.goto 371,65.34,31.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Tong|r.
.turnin 30135 >>Turn in Beating the Odds
.turnin 30136 >>Turn in Empty Nests
.turnin 30137 >>Turn in Egg Collection
.accept 30138 >>Accept Choosing the One
.turnin 30138 >>Turn in Choosing the One
step
.goto 371,65.34,31.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Tong|r.
.daily 30140,30141,30139 >>Accept The Rider's Journey
.target Instructor Tong
step
#completewith Egg hatched
.goto 371,65.25,37.20,20,0
.cast 437035 >>Use |T134376:0|t[Bronze Timepiece] to teleport to the dragonriding quests.
.itemcount 216712,1
.use 216712
step
.goto 371,57.55,45.10
.isOnQuest 30139
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Skythorn|r.
.turnin 30139 >>Turn in The Rider's Journey
.target Instructor Skythorn
step
.goto 371,57.55,45.10
.isOnQuest 30140
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Skythorn|r.
.turnin 30140 >>Turn in The Rider's Journey
.target Instructor Skythorn
step
.isOnQuest 30141
.goto 371,57.55,45.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Skythorn|r.
.turnin 30141 >>Turn in The Rider's Journey
.target Instructor Skythorn
step
#label Egg hatched
.goto 371,57.55,45.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Skythorn|r.
.accept 30142 >>Accept It's A...
.complete 30142,1 
.turnin 30142 >>Turn in It's A...
.target Instructor Skythorn
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Save the Hippos!
#internal
step
.goto 2022,71.27,40.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mender Eskros|r.
.accept 72122 >>Accept Erstwhile Ecologists
.target Mender Eskros
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ecologist Tharu|r and |cRXP_FRIENDLY_Ecologist Iskha|r.
.turnin 72122 >>Turn in Erstwhile Ecologists
.accept 66105 >>Accept A Scalpel of a Solution
.goto 2022,74.43,42.13
.target +Ecologist Tharu
.accept 66107 >>Accept Wildlife Rescue
.goto 2022,74.52,42.17
.target +Ecologist Iskha
step
#completewith RampagingWaterWind
#hidewindow
#loop
.goto 2022,76.13,42.62,25,0
.goto 2022,76.74,43.78,25,0
.goto 2022,76.21,45.68,25,0
.goto 2022,78.03,45.84,25,0
.goto 2022,78.72,47.83,25,0
.goto 2022,79.16,49.12,25,0
.goto 2022,80.19,47.91,25,0
.goto 2022,79.03,46.29,25,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Rampaging Water|r and |cRXP_ENEMY_Rampaging Wind|r.
.complete 66105,1 
.complete 66105,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trapped Animals|r.
.complete 66107,1 
.target Cowering Crab
.target Helpless Waterfowl
step
#label RampagingWaterWind
>>Kill |cRXP_ENEMY_Rampaging Water|r and |cRXP_ENEMY_Rampaging Wind|r.
.complete 66105,1 
.complete 66105,2 
.mob Rampaging Water
.mob Rampaging Wind
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ecologist Tharu|r and |cRXP_FRIENDLY_Ecologist Iskha|r.
.turnin 66107 >>Turn in Wildlife Rescue
.goto 2022,74.51,42.18
.target +Ecologist Tharu
.turnin 66105 >>Turn in A Scalpel of a Solution
.accept 66104 >>Accept Forensic Ecology
.goto 2022,74.42,42.14
.target +Ecologist Iskha
step
.goto 2022,74.46,42.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Corpses|r
.complete 66104,1 
.complete 66104,2 
step
.goto 2022,74.46,42.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shells|r
.complete 66104,3 
step
.goto 2022,74.43,42.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ecologist Iskha|r.
.turnin 66104 >>Turn in Forensic Ecology
.accept 66108 >>Accept A Sledgehammer of a Solution
.target Ecologist Iskha
step
.goto 2022,74.51,42.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ecologist Tharu|r
.accept 66106 >>Accept Don't Be So Shellfish
.target Ecologist Tharu
step
#completewith Sogglmoggl
>>Kill |cRXP_ENEMY_Murlocs|r.
*Loot them for |T1498852:0|t[|cRXP_LOOT_Shells|r].
>>|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Piles|r.
.complete 66106,2 
.complete 66106,1 
.mob Windyfin Skybasher
.mob Windyfin Windbringer
.mob Windyfin Squallstalker
.mob Soggymaw Wavebringer
step
.goto 2022,79.77,39.80
>>Kill |cRXP_ENEMY_Whirglgurgl|r.
.complete 66108,2 
step
.goto 2022,80.13,42.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bubbled Duckling|r
.accept 66196 >>Accept A Quack For Help
.target Bubbled Duckling
step
#label Sogglmoggl
.goto 2022,80.08,44.10
>>Kill |cRXP_ENEMY_Sogglmoggl|r.
.complete 66108,1 
step
#loop
.goto 2022,78.71,43.53,25,0
.goto 2022,78.32,42.94,25,0
.goto 2022,77.47,43.49,25,0
.goto 2022,79,41.16,25,0
.goto 2022,80.08,42.13,25,0
.goto 2022,80.77,45.45,25,0
.goto 2022,78.31,44.64,25,0
>>Kill |cRXP_ENEMY_Murlocs|r.
*Loot them for |T1498852:0|t[|cRXP_LOOT_Shells|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Piles|r.
.complete 66106,2 
.complete 66106,1 
.mob Windyfin Skybasher
.mob Windyfin Windbringer
.mob Windyfin Squallstalker
.mob Soggymaw Wavebringer
step
#completewith next
#label Bubbled Duckling
#hidewindow
.complete 66196,1 
step
#completewith Bubbled Duckling
.goto 2022,74.43,42.14,15 >>Follow the Arrow
.timer 7.5,RP
step
#requires Bubbled Duckling
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ecologist Iskha|r.
.turnin 66108 >>Turn in A Sledgehammer of a Solution
.goto 2022,74.42,42.14
.target +Ecologist Iskha
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ecologist Tharu|r.
.turnin 66106 >>Turn in Don't Be So Shellfish
.goto 2022,74.51,42.17
.target +Ecologist Tharu
step
.goto 2022,74.43,42.14
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66196,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ecologist Tharu|r.
.turnin 66196 >>Turn in A Quack For Help
.goto 2022,74.51,42.17
.target +Ecologist Tharu
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) A Ruby Lifecalling
#internal
step
.goto 2022,61.90,73.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lifecaller Tzadrak|r.
.accept 66825 >>Accept A Ruby Lifecalling
.target Lifecaller Tzadrak
step
.goto 2022,61.85,73.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Objects|r.
.complete 66825,1 
step
.goto 2022,61.89,73.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lifecaller Tzadrak|r.
.turnin 66825 >>Turn in A Ruby Lifecalling
.target Lifecaller Tzadrak
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Beyond the Barrier Midnight
#internal
step
#label BeyondBarrierStart1
.goto 2022,66.06,58.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Taiyang|r.
.accept 66435 >>Accept Site Salvage
.accept 66436 >>Accept Unearthed Troublemakers
.target Elementalist Taiyang
step
#completewith Orb of Primal Stone
>>Kill |cRXP_ENEMY_Earth Elementals|r.
*Loot them for 1x |T1020373:0|t[|cRXP_LOOT_Orb of Primal Stone|r].
.complete 66436,1 
.accept 66437 >>Accept A Key Element
.mob Displaced Earth
.mob Unsettled Rubble
step
#title Explorer rescued (1/5)
.goto 2022,67.17,58.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to a |cRXP_FRIENDLY_Beleaguered Explorer|r.
.complete 66435,1,1 
.target Beleaguered Explorer
.skipgossipid 54942
step
#title Explorer rescued (2/5)
.goto 2022,67.53,57.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to a |cRXP_FRIENDLY_Beleaguered Explorer|r.
.complete 66435,1,2 
.target Beleaguered Explorer
.skipgossipid 54942
step
#title Explorer rescued (3/5)
.goto 2022,67.87,57.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to a |cRXP_FRIENDLY_Beleaguered Explorer|r.
.complete 66435,1,3 
.target Beleaguered Explorer
.skipgossipid 54942
step
#title Explorer rescued (4/5)
.goto 2022,67.81,57.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to a |cRXP_FRIENDLY_Beleaguered Explorer|r.
.complete 66435,1,4 
.target Beleaguered Explorer
.skipgossipid 54942
step
#label Orb of Primal Stone
#title Explorer rescued (5/5)
.goto 2022,67.60,56.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to a |cRXP_FRIENDLY_Beleaguered Explorer|r.
.complete 66435,1 
.target Beleaguered Explorer
.skipgossipid 54942
step
#loop
.goto 2022,67.38,55.54,25,0
.goto 2022,66.92,56.47,25,0
.goto 2022,66.48,57.4,25,0
.goto 2022,67.62,57.33,25,0
>>Kill |cRXP_ENEMY_Earth Elementals|r.
.complete 66436,1 
.mob Displaced Earth
.mob Unsettled Rubble
step
.goto 2022,66.59,56.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Taiyang|r.
.turnin 66436 >>Turn in Unearthed Troublemakers
.turnin 66435 >>Turn in Site Salvage
.turnin 66437 >>Turn in A Key Element
.target Elementalist Taiyang
step
#label BeyondBarrierEnd1
.goto 2022,66.59,56.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Examiner Tae'shara Bloodwatcher|r, |cRXP_FRIENDLY_Elementalist Taiyang|r, and |cRXP_FRIENDLY_Acadia Chistlestone|r.
.accept 66438 >>Accept Lofty Goals
.accept 66441 >>Accept Distilled Effort
.accept 66439 >>Accept Rapid Fire Plans
.target Examiner Tae'shara Bloodwatcher
.target Elementalist Taiyang
.target Acadia Chistlestone
step
.goto 2022,72.17,56.71
>>Kill |cRXP_ENEMY_Acequian|r inside the Cave.
*Loot them for |T1020349:0|t[|cRXP_LOOT_Orb of Primal Waves|r].
.complete 66441,1 
.mob Acequian
step
#loop
.goto 2022,68.40,63.15,30,0
.goto 2022,68.26,64.59,30,0
.goto 2022,69.35,64.39,30,0
.goto 2022,69.84,65.71,30,0
>>Kill |cRXP_ENEMY_Primalist Forces|r.
*Loot them for |T135821:0|t[|cRXP_LOOT_Primal Flame Fragment|r].
.complete 66439,1 
.mob Primalist Magmashaper
.mob Destructive Flames
.mob Ashen Spark
step
#label BeyondBarrierStart2
.goto 2022,70.64,63.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Ri'tal|r.
.complete 66438,1 
.skipgossipid 55167
.target Scout Ri'tal
step
.goto 2022,70.61,62.38,10,0
.goto 2022,70.54,61.76,10,0
.goto 2022,70.14,61.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Francisco|r.
*|cRXP_WARN_Hug the right wall to dodge hazards|r.
.complete 66438,2 
.target Scout Francisco
.skipgossipid 55168
step
#completewith next
#label Orb of Primal Gales
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r
.complete 66438,3 
step
#completewith Orb of Primal Gales
.goto 2022,69.53,60.02,15 >>Leave the No Mount Zone and Mount Up
step
#requires Orb of Primal Gales
.goto 2022,67.71,60.36,15,0
.goto 2022,68.29,61.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r
.complete 66438,3 
step
.goto 2022,66.59,56.08
>>Use the |T135821:0|t[Primal Flame Fragments]
.complete 66439,2 
.use 192545
step
.goto 2022,66.59,56.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Taiyang|r.
.turnin 66438 >>Turn in Lofty Goals
.turnin 66439 >>Turn in Rapid Fire Plans
.turnin 66441 >>Turn in Distilled Effort
.accept 66442 >>Accept Let's Get Theoretical
.target Elementalist Taiyang
step
#completewith next
#label Fire and Air Orbs
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66442,1 
step
#completewith Fire and Air Orbs
.goto 2022,66.56,56.06
.gossipoption 54908 >>Talk to |cRXP_FRIENDLY_Elementalist Taiyang|r.
.timer 40,RP
step
#requires Fire and Air Orbs
.goto 2022,66.56,56.06
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66442,1 
step
.goto 2022,66.56,56.06
>>Use the [ExtraActionButton]
.complete 66442,2 
.timer 8.5,RP
step
.goto 2022,66.51,55.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Taiyang|r.
.turnin 66442 >>Turn in Let's Get Theoretical
.accept 66447 >>Accept Beyond the Barrier
.timer 10,RP
.target Elementalist Taiyang
step
.goto 2022,66.09,55.36
>>Kill |cRXP_ENEMY_Discordant Watcher|r.
.complete 66447,1 
.mob Discordant Watcher
step
.goto 2022,66.12,54.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 66447,2 
step
#completewith next
#label Beyond the Barrier
.goto 2022,66.75,56.44,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Taiyang|r.
.turnin 66447 >>Turn in Beyond the Barrier
.target Elementalist Taiyang
step
#completewith Beyond the Barrier
.goto 2022,65.88,57.47,88 >>Leave the House
step
#requires Beyond the Barrier
#label BeyondBarrierEnd2
.goto 2022,65.88,57.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Taiyang|r.
.turnin 66447 >>Turn in Beyond the Barrier
.target Elementalist Taiyang
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Professional Protographer Midnight
#internal
step
#label OutForDeliveryAccept
.goto 2022,48.48,78.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hauler Bennet|r.
.accept 66963 >>Accept Out For Delivery
.target Hauler Bennet
step
#label OutForDeliveryTurnin
.goto 2022,48.48,82.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cataloger Wulferd|r.
.turnin 66963 >>Turn in Out For Delivery
.accept 66524 >>Accept Amateur Protography
.target Cataloger Wulferd
step
#label ProfessionalProtographerStart1
.goto 2022,43.84,81.17
>>Use |T1109100:0|t[Camera] |cRXP_WARN_unmounted & non combat|r, face towards the |cRXP_FRIENDLY_Optimistic Whelp|r
*|cRXP_WARN_Use|r |T1109168:0|t[Catalog](1) |cRXP_WARN_when it flies|r.
.complete 66524,2 
.target Optimistic Whelp
.use 192465
step
.goto 2022,44.01,79.23
>>Use |T1109100:0|t[Camera] |cRXP_WARN_unmounted & non combat|r, face towards a |cRXP_ENEMY_Hungry Proto-Drake|r
*|cRXP_WARN_Use|r |T1109168:0|t[Catalog](1) |cRXP_WARN_when it caught a fish|r.
.complete 66524,3 
.macro Cancel Camera, 1109168 >>/cancelaura Cataloger's Camera
.mob Hungry Proto-Drake
.use 192465
step
.goto 2022,43.42,82.83
>>Use |T1109100:0|t[Camera] |cRXP_WARN_unmounted & non combat|r, face towards the |cRXP_ENEMY_Proto-Dragon Egg|r
*|cRXP_WARN_Use|r |T1109168:0|t[Catalog](1).
.complete 66524,1 
.macro Cancel Camera, 1109168 >>/cancelaura Cataloger's Camera
.use 192465
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cataloger Wulferd|r and |cRXP_FRIENDLY_Dervishian|r.
.turnin 66524 >>Turn in Amateur Protography
.accept 66525 >>Accept Competitive Protography
.goto 2022,39.03,83.25
.target +Cataloger Wulferd
.accept 66526 >>Accept Preserving the Wilds
.goto 2022,39.08,83.27
.target +Dervishian
step
#completewith next
>>Kill |cRXP_ENEMY_Primalists|r.
.complete 66526,1 
.mob Windborne Primalist
.mob Earthbound Primalist
step
.goto 2022,38.35,80.76
>>Use |T1109100:0|t[Camera] |cRXP_WARN_unmounted & non combat|r, face towards the |cRXP_ENEMY_Proto-Dragon Egg|r
*|cRXP_WARN_Use|r |T1109168:0|t[Catalog](1).
.complete 66525,1 
.use 192465
step
#hidewindow
#completewith Proto-Whelps or Proto-Drakes
#loop
.goto 2022,38.87,80.32,25,0
.goto 2022,38.1,79.98,25,0
.goto 2022,38.4,82.01,25,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Primalists|r
.complete 66526,1 
.mob Windborne Primalist
.mob Earthbound Primalist
step
>>Use |T1109100:0|t[Camera] |cRXP_WARN_unmounted & non combat|r, face towards the |cRXP_ENEMY_Infused Proto-Drake|r.
*|cRXP_WARN_Use|r |T1109168:0|t[Catalog](1),|cRXP_WARN_If it doesn't work try to get closer|r.
.complete 66525,2 
.use 192465
.mob Infused Proto-Drake
step
#label Proto-Whelps or Proto-Drakes
.goto 2022,38.32,80.76
>>Kill |cRXP_ENEMY_Primalists|r
.complete 66526,1 
.mob Windborne Primalist
.mob Earthbound Primalist
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dervishian|r and |cRXP_FRIENDLY_Cataloger Wulferd|r.
.turnin 66525 >>Turn in Competitive Protography
.goto 2022,39.09,83.27
.target +Dervishian
.turnin 66526 >>Turn in Preserving the Wilds
.accept 66527 >>Accept Professional Protography
.goto 2022,39.02,83.23
.target +Cataloger Wulferd
step
.goto 2022,38.95,83.39
>>|cRXP_WARN_Jump onto the spring|r.
.complete 66527,1 
step
.goto 2022,38.77,84.04
#title |cFFFCDC00Follow the spotlights|r
>>Use |T1109100:0|t[Camera] |cRXP_WARN_unmounted & non combat|r, face towards the |cRXP_ENEMY_Slumbering Proto-Dragon|r.
*|cRXP_WARN_Use|r |T1109168:0|t[Catalog](1).
.complete 66527,2 
.mob Slumbering Proto-Dragon
.use 192465
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cataloger Wulferd|r and |cRXP_FRIENDLY_Dervishian|r.
.turnin 66527 >>Turn in Professional Protography
.goto 2022,39.03,83.26
.target +Cataloger Wulferd
.accept 66528 >>Accept King Without a Crown
.goto 2022,39.09,83.27
.target +Dervishian
.macro Cancel Camera, 1109168 >>/cancelaura Cataloger's Camera
step
.goto 2022,38.84,83.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Claw|r.
.complete 66528,2 
step
.goto 2022,39.13,83.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spine|r.
.complete 66528,1 
step
.goto 2022,39.39,84.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rib|r.
.complete 66528,3 
step
.goto 2022,39.08,83.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dervishian|r.
.turnin 66528 >>Turn in King Without a Crown
.accept 66529 >>Accept A Thousand Words
.target Dervishian
step
.goto 2022,38.92,83.52
>>Use |T1109100:0|t[Camera] |cRXP_WARN_unmounted & non combat|r, face towards |cRXP_FRIENDLY_Dervishian|r.
*|cRXP_WARN_Use|r |T1109168:0|t[Catalog](1).
.complete 66529,1 
.macro Cancel Camera, 1109168 >>/cancelaura Cataloger's Camera
.use 192465
step
#label ProfessionalProtographerEnd1
.goto 2022,38.72,83.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dervishian|r.
.turnin 66529 >>Turn in A Thousand Words
.target Dervishian
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) The Shadow of His Wings Midnight
#internal
step
.goto 2022,39.43,48.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ingot|r.
.accept 65687 >>Accept Punching Up
.accept 65690 >>Accept A Cultist's Misgivings
.target Ingot
step
.goto 2022,37.45,46.70
#title |cFFFCDC00Follow the Arrow|r
.complete 65690,1 
step
.goto 2022,37.43,46.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ayasanth|r.
.turnin 65690 >>Turn in A Cultist's Misgivings
.accept 65782 >>Accept Under Lock and Key
.target Ayasanth
step
#completewith WorldbreakerCellKey
#hidewindow
#loop
.goto 2022,38.28,47.37,35,0
.goto 2022,38.16,48.63,35,0
.goto 2022,36.16,48.01,35,0
.goto 2022,34.45,48.72,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Worldbreaker Guards|r.
*Loot them for the |T4553307:0|t[|cRXP_LOOT_Worldbreaker Cell Key|r].
.complete 65782,1 
.mob Worldbreaker Guard
step
>>Kill |cRXP_ENEMY_Dragonkins|r.
.complete 65687,1 
.mob Worldbreaker Guard
.mob Worldbreaker Brute
.mob Worldbreaker Cultist
step
#label WorldbreakerCellKey
>>Kill |cRXP_ENEMY_Worldbreaker Guards|r.
*Loot them for |T4553307:0|t[|cRXP_LOOT_Worldbreaker Cell Key|r].
.complete 65782,1 
step
.goto 2022,37.33,46.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ingot|r.
.turnin 65687 >>Turn in Punching Up
.target +Ingot
step
.goto 2022,37.43,46.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 65782,2 
.timer 6.5,Roleplay Duration
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ayasanth|r after a short roleplay.
.turnin 65782 >>Turn in Under Lock and Key
.accept 65691 >>Accept The Shadow of His Wings
.goto 2022,37.35,46.62
.target +Ayasanth
step
#completewith next
#label CygenothTheCorruptedConfronted
.goto 2022,35.63,47.95,10,0
>>Kill |cRXP_ENEMY_Cygenoth the Corrupted|r after a short roleplay.
.complete 65691,1 
step
#completewith CygenothTheCorruptedConfronted
#title Enter Cave
.goto 2022,35.04,45.47,140 >>Enter the cave
step
#requires CygenothTheCorruptedConfronted
.goto 2022,34.98,47.76,25,0
.goto 2022,35.04,45.47
>>Kill |cRXP_ENEMY_Cygenoth the Corrupted|r after a short roleplay.
.complete 65691,1 
step
.goto 2022,35.04,45.47
>>Kill |cRXP_ENEMY_Cygenoth the Corrupted|r
.complete 65691,2 
.mob Cygenoth the Corrupted
step
#completewith next
#label TheShadowOfHisWings
.goto 2022,35.1,47.94,20,0
.goto 2022,35.71,47.9,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ayasanth|r
.turnin 65691 >>Turn in The Shadow of His Wings
.target Ayasanth
step
#completewith TheShadowOfHisWings
#title Leave Cave
.goto 2022,37.34,46.61,150 >>Leave the Cave
step
#requires TheShadowOfHisWings
.goto 2022,37.34,46.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ayasanth|r.
.turnin 65691 >>Turn in The Shadow of His Wings
.target Ayasanth
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Brave Researchers
#internal
step
.goto 2022,45.93,81.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iyali|r.
.accept 69897 >>Accept Behavior Analysis "Homework"
.target Iyali
step
#title Sleeping Whelp pet (1/3)
.goto 2022,42.55,79.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sleeping Whelp|r.
.complete 69897,1,1 
.target Sleeping Whelp
step
#title Sleeping Whelp pet (2/3)
.goto 2022,42.40,82.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sleeping Whelp|r.
.complete 69897,1,2 
.macro Cancel Camera, 1109168 >>/cancelaura Cataloger's Camera
.target Sleeping Whelp
step
#title Sleeping Whelp pet (3/3)
.goto 2022,43.53,84.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sleeping Whelp|r.
.complete 69897,1 
.target Sleeping Whelp
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Ruby Lifecalling
#internal
step
.goto 2022,53.42,58.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dazakros|r.
.turnin 66879 >>Turn in Hornstrider Havoc
.accept 66893 >>Accept Beaky Reclamation
.accept 66892 >>Accept Deluge Dilemma
.target Dazakros
step
#completewith DelugeDilemma
#hidewindow
#loop
.goto 2022,53.02,54.76,35,0
.goto 2022,51.66,53.93,35,0
.goto 2022,51.44,58.73,35,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Water Elementals|r in the area.
.complete 66892,1 
.mob Ensnaring Current
.mob Encroaching Downpour
.mob Frenzied Ripple
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Hornstrider|r.
.complete 66893,1 
.target Injufred Hornstrider
step
#label DelugeDilemma
>>Kill the |cRXP_ENEMY_Water Elementals|r in the area.
.complete 66892,1 
.mob Ensnaring Current
.mob Encroaching Downpour
.mob Frenzied Ripple
step
.goto 2022,53.42,58.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dazakros|r.
.turnin 66892 >>Turn in Deluge Dilemma
.turnin 66893 >>Turn in Beaky Reclamation
.target Dazakros
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crabtender Kad'irsza|r and |cRXP_FRIENDLY_Ru'kroszk|r.
.accept 66612 >>Accept Crabtender's Quandry
.goto 2022,59.75,51.23
.target +Crabtender Kad'irsza
.accept 71141 >>Accept Gills with Gall
.goto 2022,59.70,51.21
.target +Ru'kroszk
step
#completewith next
>>Kill the |cRXP_ENEMY_Cliffdrip Gorlocs|r.
.complete 66612,1 
.mob Cliffdrip Fallstriker
.mob Cliffdrip Snapstrider
.mob Cliffdrip Wavemender
step
#completewith next
#label GillsWithGall
.goto 2022,57.98,46.33,0,0
>>Kill |cRXP_ENEMY_Gurblbrblr the Invader|r.
.complete 71141,1 
.mob Gurblbrblr the Invader
step
#completewith GillsWithGall
#title Enter Cave
.goto 2022,58.93,47.06,15 >>Enter the cave
step
#requires GillsWithGall
#completewith next
>>Kill the |cRXP_ENEMY_Cliffdrip Gorlocs|r.
.complete 66612,1 
.mob Cliffdrip Fallstriker
.mob Cliffdrip Snapstrider
.mob Cliffdrip Wavemender
step
#requires GillsWithGall
.goto 2022,57.98,46.33
>>Kill |cRXP_ENEMY_Gurblbrblr the Invader|r.
.complete 71141,1 
.mob Gurblbrblr the Invader
step
#loop
.goto 2022,59.56,47.96,40,0
.goto 2022,60.57,46.86,45,0
.goto 2022,59.56,47.96,40,0
.goto 2022,59.89,50.09,40,0
.goto 2022,59.56,47.96,40,0
.goto 2022,57.98,46.33,35,0
>>Kill the |cRXP_ENEMY_Cliffdrip Gorlocs|r.
.complete 66612,1 
.mob Cliffdrip Fallstriker
.mob Cliffdrip Snapstrider
.mob Cliffdrip Wavemender
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crabtender Kad'irsza|r and |cRXP_FRIENDLY_Ru'kroszk|r.
.turnin 66612 >>Turn in Crabtender's Quandry
.goto 2022,59.75,51.23
.target +Crabtender Kad'irsza
.turnin 71141 >>Turn in Gills with Gall
.goto 2022,59.70,51.21
.target +Ru'kroszk
step
#completewith next
#title Use |T134414:0|t[Hearthstone]
.hs >>Hearth to Ruby Lifeshrine
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Spores of Dread
#internal
step
#completewith next
#label SporesOfDreadA
.goto 2248,41.62,71.34,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Freysworn Cruton|r.
*|cRXP_WARN_Relog if he's not there|r.
.accept 78570 >>Accept Frayed Legacy
.target Freysworn Cruton
step
#title Enter House
#completewith SporesOfDreadA
.isQuestAvailable 78570
.goto 2248,42.10,71.32,8 >>Enter the House
step
#requires SporesOfDreadA
#label SporesOfDreadB
.goto 2248,42.10,71.32,0
.goto 2248,41.62,71.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Freysworn Cruton|r.
*|cRXP_WARN_Relog if he's not there|r.
.accept 78570 >>Accept Frayed Legacy
.target Freysworn Cruton
step
#label SporesOfDreadC
.goto 2248,53.55,69.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.turnin -78570 >>Turn in Frayed Legacy
.accept 78571 >>Accept Mycomayhem
.target Woldtender Igris
step
.xp >79,1
.isQuestAvailable 78618
#completewith next
>>Kill the |cRXP_ENEMY_Boskroots|r, |cRXP_ENEMY_Infected Peafowls|r, |cRXP_ENEMY_Shalehorns|r, and |cRXP_ENEMY_Murmuring Trapcaps|r.
.complete 78618,1 
.mob Murmuring Trapcap
step
#loop
.goto 2248,52.27,70.55,37,0
.goto 2248,51.33,67.59,40,0
.goto 2248,53.58,65.18,40,0
.goto 2248,54.71,68.08,40,0
>>Kill the |cRXP_ENEMY_Boskroots|r, |cRXP_ENEMY_Infected Peafowls|r, and |cRXP_ENEMY_Shalehorns|r. Loot them for the |T1029746:0|t[|cRXP_LOOT_Boskroot Spores]
.complete 78571,1 
.mob Mycotic Shalehorn
.mob Infected Peafowls
.mob Boskroot Guardener
.mob Boskroot Lashbane
.mob Boskroot Brute
.mob Boskroot Button
.mob Boskroot Mycomancer
.mob Elder Shalehorn
.mob Murmuring Trapcap
step
#label SporesOfDreadD
.goto 2248,53.55,69.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.turnin 78571 >>Turn in Mycomayhem
.target Woldtender Igris
step
.goto 2248,53.55,69.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.accept 78572 >>Accept Wold Memories
.target Woldtender Igris
step
#title Enter House
>>Enter the House
.goto 2248,54.09,65.46
.complete 78572,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fine Earthen Urn|r.
.goto 2248,54.28,65.52
.complete 78572,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dusty Memory Gem|r.
.goto 2248,54.17,65.23
.complete 78572,3 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Oathbinder's Pledge|r.
.goto 2248,54.57,65.18
.complete 78572,4 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Freydrin's Shillelagh|r.
.goto 2248,54.32,65.02
.complete 78572,5 
step
.goto 2248,54.24,65.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.turnin 78572 >>Turn in Wold Memories
.accept 78573 >>Accept Keeper's Aid
.target Woldtender Igris
step
.isQuestAvailable 78618
#completewith InfectedWildlifeCleansed
>>Kill the |cRXP_ENEMY_Boskroots|r. and other |cRXP_ENEMY_enemies|r. in the quest area
.complete 78618,1 
.mob Mycotic Shalehorn
.mob Infected Peafowls
.mob Boskroot Guardener
.mob Boskroot Lashbane
.mob Boskroot Brute
.mob Boskroot Mycomancer
.mob Elder Shalehorn
.mob Murmuring Trapcap
.mob Rotbark the Unfelled
step
#completewith StoneWardsDestroyed
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_ Elder Shalehorns|r, |cRXP_ENEMY_ Mycotic Shalehorns|r. and |cRXP_ENEMY_Infected Peafowls|r.
.complete 78573,1 
.use 215158
.mob Elder Shalehorn
.mob Mycotic Shalehorn
.mob Infected Peafowl
step
#title Stone Ward destroyed (1/4)
.goto 2248,53.86,65.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Stone Ward|r.
.complete 78573,2,1 
step
#title Stone Ward destroyed (2/4)
.goto 2248,54.81,66.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Stone Ward|r.
.complete 78573,2,2 
step
#title Stone Ward destroyed (3/4)
.goto 2248,52.61,69.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Stone Ward|r.
.complete 78573,2,3 
step
#label StoneWardsDestroyed
#title Stone Ward destroyed (4/4)
.goto 2248,51.71,67.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Stone Ward|r.
.complete 78573,2 
step
#loop
.goto 2248,54.96,66.57,40,0
.goto 2248,53.58,65.18,40,0
.goto 2248,53.80,69.64,35,0
.goto 2248,51.77,70.30,40,0
.goto 2248,54.71,68.08,40,0
#label InfectedWildlifeCleansed
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_ Elder Shalehorns|r, |cRXP_ENEMY_ Mycotic Shalehorns|r. and |cRXP_ENEMY_Infected Peafowls|r.
.complete 78573,1 
.use 215158
.mob Elder Shalehorn
.mob Mycotic Shalehorn
.mob Infected Peafowl
step
.goto 2248,54.23,65.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.turnin 78573 >>Turn in Keeper's Aid
.accept 78574 >>Accept Boss of the Bosk
.target Woldtender Igris
step
#completewith FungariansDefeated
#hidewindow
#loop
.goto 2248,53.58,65.18,46,0
.goto 2248,54.71,68.08,46,0
.goto 2248,51.33,67.59,46,0
+1
step
.isQuestAvailable 78618
.isOnQuest 78618
#completewith next
>>Kill the |cRXP_ENEMY_Boskroots|r. and other |cRXP_ENEMY_enemies|r. in the quest area
.complete 78618,1 
.mob Mycotic Shalehorn
.mob Infected Peafowls
.mob Boskroot Guardener
.mob Boskroot Lashbane
.mob Boskroot Brute
.mob Boskroot Mycomancer
.mob Elder Shalehorn
.mob Murmuring Trapcap
.mob Rotbark the Unfelled
step
>>Kill |cRXP_ENEMY_Rotbark the Unfelled|r.
*Use the |T4636981:0|t[Freydrin's Shillelagh] on him to reduce his health by 10% (stackable)
.complete 78574,2 
.mob Rotbark the Unfelled
step
.isQuestAvailable 78618
#label FungariansDefeated
.goto 2248,53.39,67.21,0,0
>>Kill the |cRXP_ENEMY_Boskroots|r. and other |cRXP_ENEMY_enemies|r in the quest area
.complete 78618,1 
.mob Mycotic Shalehorn
.mob Infected Peafowls
.mob Boskroot Guardener
.mob Boskroot Lashbane
.mob Boskroot Brute
.mob Boskroot Mycomancer
.mob Elder Shalehorn
.mob Murmuring Trapcap
.mob Rotbark the Unfelled
step
.goto 2248,54.23,65.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.turnin 78574 >>Turn in Boss of the Bosk
.target Woldtender Igris
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Behind Closed Doors
#internal
step
.goto 2339,62.71,21.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aldra|r.
.accept 80207 >>Accept How Scandalous!
.target Aldra
step
#label ForgegroundsStart
#title |cFFFCDC00Follow the Arrow|r.
.goto 2339,49.90,49.34
.complete 80207,1 
step
.goto 2339,49.90,49.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Kragad|r.
.turnin 80207 >>Turn in How Scandalous!
.accept 79521 >>Accept Seizing Evidence
.target Peacekeeper Kragad
step
.goto 2339,51.38,51.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shipment Crates|r.
.complete 79521,1 
step
.goto 2339,49.90,49.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Kragad|r.
.turnin 79521 >>Turn in Seizing Evidence
.accept 79522 >>Accept Withheld Information
.target Peacekeeper Kragad
step
#title Worker interrogated (3/5)
.goto 2339,49.83,48.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Line Workers|r.
.complete 79522,1,3 
.target Line Worker
step
#title Worker interrogated (5/5)
.goto 2339,48.99,49.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Line Workers|r.
.complete 79522,1 
.target Line Worker
step
.goto 2339,49.90,49.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Kragad|r.
.turnin 79522 >>Turn in Withheld Information
.accept 79523 >>Accept Something Hidden
.target Peacekeeper Kragad
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Receipts|r, |cRXP_PICK_Bag|r, |cRXP_PICK_Underclay|r and |cRXP_PICK_Silk Ropes|r.
.complete 79523,2 
step
.goto 2339,51.38,51.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crates|r.
*Kill |cRXP_ENEMY_Disturbed Mudspawns|r.
.complete 79523,1 
.mob Disturbed Mudspawn
step
.goto 2339,51.38,51.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Receipts|r, |cRXP_PICK_Bag|r, |cRXP_PICK_Underclay|r and |cRXP_PICK_Silk Ropes|r.
.complete 79523,2 
step
#label ForgegroundsEnd
.goto 2339,49.90,49.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Kragad|r.
.turnin 79523 >>Turn in Something Hidden
.target Peacekeeper Kragad
step
.goto 2339,49.90,49.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Kragad|r.
.accept 79525 >>Accept Report to the Councilward
.target Peacekeeper Kragad
step
.goto 2214,43.34,32.66
.achievementComplete 19559,1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Saradi|r |cRXP_WARN_in The Ringing Deeps|r.
.accept 79542 >>Accept The Councilward's Summons
.target Saradi
step
#completewith next
#label FindMerrixRiseA
.goto 2339,56.84,10.16,0,0
.complete 79525,1 
step
#title Enter House
#completewith FindMerrixRiseA
.goto 2339,55.78,7.16,8 >>Enter the House
step
#requires FindMerrixRiseA
#title |cFFFCDC00Follow the Arrow|r.
.goto 2339,55.62,6.1
.complete 79525,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Open Ledger|r.
.goto 2339,55.62,6.08
.complete 79525,2 
step
.goto 2339,55.62,6.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Open Ledger|r.
.turnin 79525 >>Turn in Report to the Councilward
.target Open Ledger
step
>>Complete this Campaign Quest to continue the Storyline.
.turnin 79354 >>Turn in The Machine Speakers
step

.isQuestComplete 78837
#completewith next
.zone 2214 >> Go to Ringing Deeps
step

.isQuestComplete 78837
.goto 2214,43.34,32.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Saradi|r.
.accept 79542 >>Accept The Councilward's Summons
.target Saradi
step

.isQuestComplete 78837
#completewith next
.zone 2339 >> Go to Dornogal
step
.goto 2339,55.22,6.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.complete 79542,1 
.skipgossipid 121397
step
.goto 2339,55.22,6.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 79542 >>Turn in The Councilward's Summons
.target Merrix
.accept 79543 >>Accept Dornogal's Benefactor
step
#title Leave the House
.goto 2339,55.79,8.02,10 >>Leave the House
step
#title Enter the House
.goto 2339,32.74,25.26,10 >>Enter the House
step
.goto 2339,32.10,24.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.complete 79543,1 
.skipgossipid 121217
.target Merrix
step
#title Leave the House
.goto 2339,33.14,25.81,10 >>Leave the House
step
.goto 2339,58.47,62.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gostrof|r.
.complete 79543,2 
.skipgossipid 121218
.target Gostrof
step
.goto 2339,52.30,52.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trader Harthan|r.
.complete 79543,3 
.skipgossipid 121219
.target Trader Harthan
step
.goto 2339,52.30,52.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trader Harthan|r.
.complete 79543,4 
.skipgossipid 123491
.target Trader Harthan
step
.goto 2339,49.34,26.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 79543 >>Turn in Dornogal's Benefactor
.target Merrix
.accept 79544 >>Accept Security Through Trade
step
.goto 2339,55.62,50.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bevrusi|r.
.complete 79544,1 
.skipgossipid 121407
.target Bevrusi
step
.goto 2339,55.62,50.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bevrusi|r.
.target Bevrusi
.complete 79544,2 
.skipgossipid 121412
step
.goto 2339,55.62,50.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bevrusi|r.
.turnin 79544 >>Turn in Security Through Trade
.target Bevrusi
.accept 79545 >>Accept The Market Reeve of the Forgegrounds
step
.goto 2339,45.18,48.74
#title |cFFFCDC00Follow the Arrow|r.
.complete 79545,1 
step
#title Enter the House
.goto 2339,45.22,47.21,10 >> Enter the House
step
.goto 2339,44.72,46.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ronesh|r.
.complete 79545,2 
.buy 219961,1
.skipgossipid 121503
.target Ronesh
step
#title Leave the House
.goto 2339,45.48,47.71,10 >> Leave the House
step
.goto 2339,45.07,48.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vokgret|r.
.complete 79545,3 
.complete 79545,4 
.target Vokgret
.skipgossipid 121505
.skipgossipid 121506
.skipgossipid 121504
step
#title Enter the House
.goto 2339,48.03,72.68,10 >>Enter the House
step
.goto 2339,48.33,73.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loldren|r.
.complete 79545,5 
.target Loldren
.skipgossipid 121507
step
.goto 2339,48.28,73.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.complete 79545,6 
.complete 79545,7 
.skipgossipid 121512
.skipgossipid 121509
.skipgossipid 121517
.skipgossipid 121521
step
#title Leave the House
.goto 2339,47.92,71.85,10 >>Leave the House
step
#title Enter the House
.goto 2339,49.99,72.71,10 >>Enter the House
step
.goto 2339,49.59,73.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nernabel|r.
.complete 79545,8 
.skipgossipid 121452
.skipgossipid 121528
.target Nernabel
step
#title Leave the House
.goto 2339,50.09,71.78,10 >>Leave the House
step
#title Enter the House
.goto 2339,51.03,63.59,10 >>Enter the House
step
.goto 2339,50.44,63.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Core|r.
.complete 79545,9 
.mob Enraged Magma Fury
step
#title Leave the House
.goto 2339,51.36,64.59,10 >>Leave the House
step
#title Enter the House
.goto 2339,49.91,72.82,10 >>Enter the House
step
.goto 2339,49.58,73.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nernabel|r.
.complete 79545,10 
.skipgossipid 121547
step
#title Leave the House
.goto 2339,49.98,71.66,10 >>Leave the House
step
.goto 2339,45.05,48.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vokgret|r.
.turnin 79545 >>Turn in The Market Reeve of the Forgegrounds
.target Vokgret
.accept 79176 >>Accept Opals and Runes
step
.goto 2339,55.61,50.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bevrusi|r.
.complete 79176,1 
.buy 217414
.skipgossipid 122742
.target Bevrusi
step
.goto 2339,60.51,33.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 79176 >>Turn in Opals and Runes
.target Merrix
.accept 79546 >>Accept The Machine Speakeasy
step
#title Enter the House
.goto 2339,61.86,35.06,10 >>Enter the House
step
.goto 2339,62.93,36.7,10,0
.goto 2339,63.98,38.29,10,0
.goto 2339,62.37,40.28
#title |cFFFCDC00Follow the Arrow|r.
.complete 79546,1 
step
.goto 2339,62.37,40.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Speakeasy Runeguard|r.
.complete 79546,2 
.skipgossipid 121576
.target Speakeasy Runeguard
step
#completewith next
.goto 2339,62.04,37.66
.gossipoption 121577 >>Talk to |cRXP_FRIENDLY_Obstorn|r.
.timer 2,RP
.target Obstorn
step
.goto 2339,62.04,37.66
>>Kill |cRXP_ENEMY_Obstorn|r.
.complete 79546,3 
.mob Obstorn
step
.goto 2339,62.09,38.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 79546 >>Turn in The Machine Speakeasy
.target Merrix
step
#title Leave the House
.goto 2339,62.23,40.06,10,0
.goto 2339,64.09,38.42,10,0
.goto 2339,61.38,34.38,10 >> Leave the House
step
.goto 2339,45.90,47.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Angrily-Scrawled Poster|r.
.accept 79526 >>Accept Sedition
.target Angrily-Scrawled Poster
step
#title Enter the House
.goto 2339,55.79,7.23,10 >> Enter the House
step
.goto 2339,55.61,5.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 79526 >>Turn in Sedition
.target Merrix
.accept 79527 >>Accept Damage Mitigation
.accept 79528 >>Accept Dispelling Rumors
step
#title Leave the House
.goto 2339,55.79,8.03,10 >> Leave the House
step
#completewith Seditious Posters
>>Interact with |cRXP_FRIENDLY_Murmuring Peacekeeper|r defeat |cRXP_ENEMY_Murmuring Peacekeepers|r if they attack.
.complete 79528,1 
.target Murmuring Peacekeeper
.mob Murmuring Peacekeeper
step
.goto 2339,55.67,16.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,1 
step
.goto 2339,55.23,19.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,2 
step
.goto 2339,49.22,27.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,3 
step
.goto 2339,49.7,34.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,4 
step
.goto 2339,54.06,36.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,5 
step
.goto 2339,56.45,28.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,6 
step
.goto 2339,55.95,25.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,7 
step
#label Seditious Posters
.goto 2339,60.67,20.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.complete 79527,1,8 
step
#loop
.goto 2339,60.13,26.35,30,0
.goto 2339,53.31,33.84,30,0
.goto 2339,46.99,36.62,30,0
.goto 2339,44.86,33.89,30,0
.goto 2339,43.18,36.6,30,0
.goto 2339,38.08,40.28,30,0
.goto 2339,33.27,29.78,30,0
.goto 2339,34.7,24.99,30,0
.goto 2339,54.51,21.42,30,0
>>Interact with |cRXP_FRIENDLY_Murmuring Peacekeeper|r and kill |cRXP_ENEMY_Murmuring Peacekeepers|r if they fight back.
.complete 79528,1 
.target Murmuring Peacekeeper
.mob Murmuring Peacekeeper
step
#title Enter the House
.goto 2339,55.77,7.3,10 >> Enter the House
step
.goto 2339,55.60,5.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrix|r.
.turnin 79527 >>Turn in Damage Mitigation
.target Merrix
.turnin 79528 >>Turn in Dispelling Rumors
.accept 79529 >>Accept Forcing My Hand
step
#completewith next
.goto 2339,55.11,6.38
.cast 3365 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bundled Cloak|r.
step
.goto 2339,55.61,5.6
>>Interact with |cRXP_FRIENDLY_Merrix|r.
.complete 79529,1 
.target Merrix
step
#completewith next
.goto 2339,56.38,5.95
.cast 461749 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Accessory Chest|r.
step
.goto 2339,55.61,5.6
>>Interact with |cRXP_FRIENDLY_Merrix|r.
.complete 79529,2 
.target Merrix
step
#completewith next
.goto 2339,55.36,5.61
.cast 441008 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gilded Knuckles|r.
step
.goto 2339,55.61,5.6
>>Interact with |cRXP_FRIENDLY_Merrix|r.
.complete 79529,3 
.target Merrix
step
#completewith next
.goto 2339,55.86,6.67
.cast 3365 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Devices|r.
step
.goto 2339,55.61,5.6
>>Interact with |cRXP_FRIENDLY_Merrix|r.
.complete 79529,4 
.target Merrix
step
.goto 2339,55.61,5.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelvein|r.
.turnin 79529 >>Turn in Forcing My Hand
.target Steelvein
.accept 79530 >>Accept Bad Business
step
#title Leave the House
.goto 2339,55.79,8.21,10 >>Leave the House
step
#completewith next
.goto 2339,37.78,57.12,40,0
.goto 2339,38.87,59.91,40,0
.goto 2339,48.28,59.91,40,0
.goto 2339,50.24,64.24,40,0
.goto 2339,50.11,72.3,40,0
.zone 2214 >>Go to Ringing Deeps
step
.goto 2214,35.47,31.55,40,0
.goto 2214,35.66,29.78,40,0
.goto 2214,37.94,28.39,40,0
.goto 2214,38.63,23.94
#title |cFFFCDC00Follow the Arrow|r.
.complete 79530,1 
step
.isOnQuest 79530
.goto 2214,38.06,24.12
.gossipoption 121524 >>Talk to |cRXP_FRIENDLY_Overseer Ardgrin|r.
.timer 12,RP
.target Overseer Ardgrin
step
.goto 2214,38.10,23.93
>>Kill |cRXP_ENEMY_Sparking Haulbot|r.
.complete 79530,2 
.timer 10,RP
.mob Sparking Haulbot
step
.goto 2214,38.32,23.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelvein|r.
.turnin 79530 >>Turn in Bad Business
.target Steelvein
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Seven Soldiers
#internal
step
.goto 2248,42.73,71.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aggartha|r.
.accept 78996 >>Accept Weapons and Warriors
.target Aggartha
step
#title Warriors recruited (1/5)
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaldrinn|r.
.goto 2248,42.16,72.28
.complete 78996,1,1 
.target Kaldrinn
.skipgossipid 120276
.skipgossipid 120275
step
#title Warriors recruited (2/5)
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garrak|r.
.goto 2248,41.40,73.96
.complete 78996,1,2 
.target Garrak
.skipgossipid 120276
step
#completewith next
#label SevenSoldiersA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapons Crate|r.
.goto 2248,41.61,74.46,0,0
.complete 78996,2,1 
step
#title Enter House
#completewith SevenSoldiersA
.goto 2248,41.51,74.38,8 >>Enter the House
step
#requires SevenSoldiersA
#label SevenSoldiersB
#title Crate acquired (1/3)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapons Crate|r.
.goto 2248,41.51,74.38,0
.goto 2248,41.61,74.46
.complete 78996,2,1 
step
#label SevenSoldiersC
#title Crate acquired (2/3)
.goto 2248,41.03,73.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapons Crate|r.
.complete 78996,2,2 
step
#label SevenSoldiersD
#title Crate acquired (3/3)
.goto 2248,43.94,78.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapons Crate|r.
.complete 78996,2 
step
#completewith next
#title |cFFFCDC00FLY to the top of the Tower|r.

.goto 2248,44.53,78.98,10 >>|cFFFCDC00Fly to the top of the Tower|r.
step
#title Warriors recruited (3/5)
.goto 2248,44.72,79.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merrimack|r.
.complete 78996,1,3 
.target Merrimack
.skipgossipid 120277
step
#title Warriors recruited (5/5)
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bertola|r and |cRXP_FRIENDLY_Eiggard|r at the bottom of the tower
.goto 2248,44.45,79.26
.complete 78996,1 
.target Bertola
.target Eiggard
.skipgossipid 120274
.skipgossipid 120267
step
#label FreywoldVillageGlimmeringShoreStartA
.goto 2248,49.81,76.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aggartha|r.
.turnin 78996 >>Turn in Weapons and Warriors
.accept 78998 >>Accept Frontline Farmers
.accept 78997 >>Accept Pilfered Pearls
.target Aggartha
step
.xp >79,1
.isQuestAvailable 81614
#completewith DistributedWeaponCrates
>>Kill the |cRXP_ENEMY_Pearlfin Gorlocs|r.
.complete 81614,1 
.mob Seaborne Colossus
.mob Pearlfin Clawclacker
.mob Pearlfin Waterweaver
.mob Pearlfin Sea-Shaman
step
#completewith DistributedWeaponCrates
>>Kill the |cRXP_ENEMY_Pearlfin Gorlocs|r. Loot them for the |T464023:0|t[|cRXP_LOOT_Pilfered Pearl|r].
.complete 78997,1 
.mob Pearlfin Sparkleseeker
.mob Pearlfin Sea-Shaman
.mob Pearlfin Waterweaver
.mob Pearlfin Tiderunner
step
#title |cFFFCDC00Kill |cFFFF5722Gorlocs|r on the way|r.
.goto 2248,49.19,79.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapons Crate|r.
.complete 78998,1,1 
step
#title |cFFFCDC00Kill |cFFFF5722Gorlocs|r on the way|r.
.goto 2248,50.74,77.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapons Crate|r.
.complete 78998,1,2 
step
#label DistributedWeaponCrates
#title |cFFFCDC00Kill |cFFFF5722Gorlocs|r on the way|r.
.goto 2248,52.07,79.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapons Crate|r.
.complete 78998,1 
step
.isQuestAvailable 81614
#completewith next
>>Kill the |cRXP_ENEMY_Pearlfin Gorlocs|r.
.complete 81614,1 
.mob Seaborne Colossus
.mob Pearlfin Clawclacker
.mob Pearlfin Waterweaver
.mob Pearlfin Sea-Shaman
.mob Pearlfin Sparkleseeker
step
#loop
.goto 2248,51.35,84.60,35,0
.goto 2248,49.39,83.35,35,0
.goto 2248,49.18,79.31,35,0
.goto 2248,52.09,79.13,45,0
.goto 2248,50.45,81.06,45,0
.goto 2248,51.85,82.19,35,0
>>Kill the |cRXP_ENEMY_Pearlfin Gorlocs|r. Loot them for the |T464023:0|t[|cRXP_LOOT_Pilfered Pearl|r].
.complete 78997,1 
.mob Pearlfin Sparkleseeker
.mob Pearlfin Sea-Shaman
.mob Pearlfin Waterweaver
.mob Pearlfin Tiderunner
step
#label SevenSoldiersE
.goto 2248,49.55,76.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aggartha|r.
.turnin 78998 >>Turn in Frontline Farmers
.turnin 78997 >>Turn in Pilfered Pearls
.target Aggartha
step
#label SevenSoldiersF
.goto 2248,49.55,76.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aggartha|r.
.accept 78999 >>Accept Heart of a Hero
.target Aggartha
step
.isQuestAvailable 81614
#completewith HeartofaHero
>>Kill the |cRXP_ENEMY_Pearlfin Gorlocs|r.
.complete 81614,1 
.mob Seaborne Colossus
.mob Pearlfin Clawclacker
.mob Pearlfin Sparkleseeker
.mob Pearlfin Sea-Shaman
.mob Pearlfin Waterweaver
.mob Pearlfin Tiderunner
step
.goto 2248,51.65,82.91
>>Kill |cRXP_ENEMY_Purgle-lurgle|r.
.complete 78999,3 
.mob Purgle-lurgle
step
.goto 2248,51.10,84.68
>>Kill |cRXP_ENEMY_Murgle-whurgle|r.
.complete 78999,2 
.mob Murgle-whurgle
step
#label HeartofaHero
.goto 2248,49.32,83.85
>>Kill |cRXP_ENEMY_Burgle-gurgle|r.
.complete 78999,1 
.mob Burgle-gurgle
step
.isQuestAvailable 81614
#loop
.goto 2248,51.35,84.60,35,0
.goto 2248,49.39,83.35,35,0
.goto 2248,49.18,79.31,35,0
.goto 2248,52.09,79.13,45,0
.goto 2248,50.45,81.06,45,0
.goto 2248,51.85,82.19,35,0
>>Kill the |cRXP_ENEMY_Pearlfin Gorlocs|r.
.complete 81614,1 
.mob Seaborne Colossus
.mob Pearlfin Clawclacker
.mob Pearlfin Sparkleseeker
.mob Pearlfin Sea-Shaman
.mob Pearlfin Waterweaver
.mob Pearlfin Tiderunner
step
#label SevenSoldiersG
.goto 2248,50.51,78.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dorbund|r.
.turnin 78999 >>Turn in Heart of a Hero
.target Dorbund
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Lost Lord of the Storm
#internal
step
.goto 2339,32.77,33.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Otwin|r.
.accept 78289 >>Accept To Rambleshire
.target Rooktender Otwin
step
#completewith next
#label LostLordoftheStormA
.complete 78289,1 
step
#title Enter House
#completewith LostLordoftheStormA
.goto 2248,58.64,27.75,6 >>Enter the House
step
#requires LostLordoftheStormA
#label LostLordoftheStormB
.goto 2248,58.39,27.34
#title |cFFFCDC00Follow the Arrow|r.
.complete 78289,1 
step
#label LostLordoftheStormC
.goto 2248,61.45,31.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Lufsela|r.
.turnin 78289 >>Turn in To Rambleshire
.accept 78291 >>Accept Power Predators
.accept 78290 >>Accept Sleepy Sheep
.target Rooktender Lufsela
step
.goto 2248,62.31,31.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_Highlands Lodestone|r.
.complete 78290,1 
step
#label LostLordoftheStormD
.goto 2248,61.51,31.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Shraubendre|r.
.complete 78290,2 
.target Shraubendre
step
#label LostLordoftheStormE
#completewith next
>>Kill |cRXP_ENEMY_Stormtop Shalemaws|r or |cRXP_ENEMY_Stormtop Terralisks|r.
.complete 78291,1 
.mob Stormtop Shalemaw Young
.mob Stormtop Shalemaw
.mob Stormtop Terralisk
step
#loop
.goto 2248,58.10,32.20,40,0
.goto 2248,60.35,32.94,35,0
.goto 2248,60.80,31.49,40,0
.goto 2248,61.10,28.59,40,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_ENEMY_Lethargic Mosswool|r.
.complete 78290,3 
.mob Lethargic Mosswool
step
#loop
.goto 2248,61.10,24.94,40,0
.goto 2248,57.60,27.36,40,0
.goto 2248,56.89,33.29,40,0
.goto 2248,59.62,32.24,40,0
.goto 2248,62.07,28.73,40,0
>>Kill |cRXP_ENEMY_Stormtop Shalemaws|r or |cRXP_ENEMY_Stormtop Terralisks|r.
.complete 78291,1 
.mob Stormtop Shalemaw Young
.mob Stormtop Shalemaw
.mob Stormtop Terralisk
step
#label LostLordoftheStormF
.goto 2248,59.72,29.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Lufsela|r.
.turnin 78290 >>Turn in Sleepy Sheep
.turnin 78291 >>Turn in Power Predators
.target Rooktender Lufsela
step
.goto 2248,59.69,29.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.accept 78292 >>Accept Lost Lord of the Storm
.target Head Rancher Stenspor
step
#title |cFFFCDC00Follow the Arrow|r.
.goto 2248,55.55,28.79
.complete 78292,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbings|r.
.goto 2248,55.54,28.78
.complete 78292,3 
step
#label LostLordoftheStormG
.goto 2248,58.73,30.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.turnin 78292 >>Turn in Lost Lord of the Storm
.target Head Rancher Stenspor
step
.goto 2248,58.73,30.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.accept 78293 >>Accept Their Moss, Our Gain
.target Head Rancher Stenspor
step
#loop
.goto 2248,58.55,30.13,25,0
.goto 2248,58.01,30.48,25,0
.goto 2248,57.99,29.74,25,0
.goto 2248,59.91,29.53,25,0
.goto 2248,59.69,28.13,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Rambleshire Mosswools|r. kill them if they fight back.
.complete 78293,1 
.target Rambleshire Mosswool
.mob Rambleshire Mosswool
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Harvested Mosswool|r.
.goto 2248,58.79,30.36
.complete 78293,2 
step
.goto 2248,58.73,30.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.turnin 78293 >>Turn in Their Moss, Our Gain
.target Head Rancher Stenspor
step
.goto 2248,58.78,30.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Lufsela|r.
.accept 78294 >>Accept Thunderhead Butt
.target Rooktender Lufsela
step
.goto 2248,58.23,27.53,15,0
.goto 2248,57.70,27.11,15,0
.goto 2248,57.82,24.63,15,0
.goto 2248,57.42,24.09
>>Escort |cRXP_FRIENDLY_Durzan|r. |cRXP_WARN_Don't run ahead|r. Kill the appearing |cRXP_ENEMY_Shadow Vanguards|r.
.complete 78294,1 
.mob Shadow Vanguard Soldier
.mob Shadow Vanguard Brute
step
.goto 2248,58.94,29.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Lufsela|r.
.turnin 78294 >>Turn in Thunderhead Butt
.target Rooktender Lufsela
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Hope, An Anomaly
#internal
step
#label HopeAnAnomalyA
.goto 2248,41.74,70.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hreka|r.
.accept 78469 >>Accept Prairie Fever
.target Hreka
step
#label HopeAnAnomalyB
.goto 2248,41.62,70.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pottery Jars|r on the table.
.complete 78469,1 
.skipgossipid 121544
.skipgossipid 121673
.skipgossipid 121546
step
#completewith next
#label HopeAnAnomalyC
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.goto 2248,42.26,73.34,0,0
.complete 78469,2 
.target Kodun
.skipgossipid 121126
step
#title Enter House
#completewith HopeAnAnomalyC
.isOnQuest 78469
.goto 2248,42.20,73.10,8 >>Enter the House
step
#requires HopeAnAnomalyC
.goto 2248,42.20,73.10,0
.goto 2248,42.26,73.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.complete 78469,2 
.target Kodun
.skipgossipid 121126
step
#label HopeAnAnomalyD
.goto 2248,42.26,73.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.turnin 78469 >>Turn in Prairie Fever
.accept 79691 >>Accept Monsters in the Dark
.accept 79692 >>Accept Buried, Not Forgotten
.target Kodun
step
#completewith next
#label HopeAnAnomalyE
#hidewindow
.complete 79691,1 
.complete 79692,1 
.complete 79692,2 
step
#title Enter Cave
#completewith HopeAnAnomalyE
.goto 2248,34.92,75.47,8 >>Enter the Cave
step
#requires HopeAnAnomalyE
#completewith next
>>Kill |cRXP_ENEMY_Acute Blightspores|r and |cRXP_ENEMY_Festering Sporemass|r. Loot them for |T4625027:0|t[|cRXP_LOOT_Modhina's Notes|r], |T1519428:0|t[|cRXP_LOOT_Modhina's Bag of Ore|r], and |T1519428:0|t[|cRXP_LOOT_Memory Gem Fragment|r].
*|cRXP_WARN_Don't kill too many at the same time. Only one of them can drop at the same time|r.
.complete 79692,1 
.mob Acute Blightspore
.mob Festering Sporemass
step
#requires HopeAnAnomalyE
#completewith next
>>Kill the |cRXP_ENEMY_Ashen Stonestalker|r.
.complete 79691,1 
.mob Ashen Stonestalker
step
#requires HopeAnAnomalyE
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Modhina|r.
.goto 2248,34.61,76.01,10,0
.goto 2248,35.26,75.74,10,0
.goto 2248,34.60,74.32
.complete 79692,2 
step
#completewith next
>>Kill |cRXP_ENEMY_Acute Blightspores|r and |cRXP_ENEMY_Festering Sporemass|r. Loot them for |T4625027:0|t[|cRXP_LOOT_Modhina's Notes|r], |T1519428:0|t[|cRXP_LOOT_Modhina's Bag of Ore|r], and |T1519428:0|t[|cRXP_LOOT_Memory Gem Fragment|r].
*|cRXP_WARN_Don't kill too many at the same time. Only one of them can drop at the same time|r.
.complete 79692,1 
.mob Acute Blightspore
.mob Festering Sporemass
step
.goto 2248,34.82,74.02
>>Kill the |cRXP_ENEMY_Ashen Stonestalker|r.
.complete 79691,1 
.mob Ashen Stonestalker
step
.goto 2248,35.08,74.93
>>Kill |cRXP_ENEMY_Acute Blightspores|r and |cRXP_ENEMY_Festering Sporemass|r. Loot them for |T4625027:0|t[|cRXP_LOOT_Modhina's Notes|r], |T1519428:0|t[|cRXP_LOOT_Modhina's Bag of Ore|r], and |T1519428:0|t[|cRXP_LOOT_Memory Gem Fragment|r].
*|cRXP_WARN_Don't kill too many at the same time. Only one of them can drop at the same time|r.
.complete 79692,1 
.mob Acute Blightspore
.mob Festering Sporemass
step
.isOnQuest 79692
#label HopeAnAnomalyF
#title Leave Cave
.goto 2248,35.18,76.22,10,0
.goto 2248,34.55,75.88,10,0
.goto 2248,35.14,75.41
.subzone 15361,1 >>Leave the Cave
step
#completewith next
#label HopeAnAnomalyG
.goto 2248,42.26,73.34,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.turnin 79691 >>Turn in Monsters in the Dark
.turnin 79692 >>Turn in Buried, Not Forgotten
.target Kodun
step
#title Enter House
#completewith HopeAnAnomalyG
.isOnQuest 79691,79692
.goto 2248,42.20,73.10,8 >>Enter the House
step
#requires HopeAnAnomalyG
#label HopeAnAnomalyH
.goto 2248,42.26,73.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.turnin 79691 >>Turn in Monsters in the Dark
.turnin 79692 >>Turn in Buried, Not Forgotten
.timer 8,Roleplay Duration
.target Kodun
step
#label HopeAnAnomalyI
.goto 2248,42.29,73.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hreka|r.
.accept 79703 >>Accept Hope, An Anomaly
.target Hreka
step
.goto 2248,42.40,73.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forge Vessel|r.
.complete 79703,1 
step
.goto 2248,42.32,73.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ball of Clay|r.
.complete 79703,2 
step
.goto 2248,42.32,73.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unfired Pot|r.
.complete 79703,3 
step
.goto 2248,42.39,73.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unfired Pot|r.
.complete 79703,4 
step
#label HopeAnAnomalyJ
.goto 2248,42.35,73.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hreka|r.
.turnin 79703 >>Turn in Hope, An Anomaly
.target Hreka
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) The Hermit
#internal
step
#label TheHermitA
.goto 2248,55.54,56.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dropped Package|r.
.accept 78754 >>Accept Lost Delivery
.target Dropped Package
step
#label TheHermitB
.goto 2248,66.99,43.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harvester Farnee|r.
.turnin 78754 >>Turn in Lost Delivery
.target Harvester Farnee
step
.goto 2248,67.00,43.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harmot|r.
.accept 78757 >>Accept Honey and Clay the Pain Away
.target Harmot
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Earthen Mortar|r.
.goto 2248,67.11,43.80
.complete 78757,1 
step
#completewith next
#label FireHoneyMortar
>>Carry the honey from the |cRXP_PICK_Pot of Fire Honey|r to the |cRXP_PICK_Earthen Mortar|r.
.complete 78757,2 
step
#completewith FireHoneyMortar
.goto 2248,66.82,44.05
.cast 462691 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pot of Fire Honey|r.
step
#requires FireHoneyMortar
>>Carry the honey from the |cRXP_PICK_Pot of Fire Honey|r to the |cRXP_PICK_Earthen Mortar|r.
*Use the |cRXP_WARN_ExtraActionButton|r.
.goto 2248,67.11,43.80
.complete 78757,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Earthen Mortar|r.
.goto 2248,67.11,43.80
.complete 78757,3 
step
.goto 2248,67.01,43.80
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Shalehoof|r.
.complete 78757,4 
step
#label TheHermitC
.goto 2248,67.00,43.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harmot|r.
.turnin 78757 >>Turn in Honey and Clay the Pain Away
.target Harmot
step
.goto 2248,67.00,43.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harmot|r.
.accept 78758 >>Accept Pulse Within the Earth
.target Harmot
step
#title Tremor Stone Placed (1/4)
.goto 2248,66.30,46.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tremor Stone|r. |cRXP_WARN_The stone will knock you back|r.
.complete 78758,1,1 
step
#title Tremor Stone Placed (2/4)
.goto 2248,66.20,46.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tremor Stone|r. |cRXP_WARN_The stone will knock you back|r.
.complete 78758,1,2 
step
#title Tremor Stone Placed (3/4)
.goto 2248,65.80,47.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tremor Stone|r. |cRXP_WARN_The stone will knock you back|r.
.complete 78758,1,3 
step
#title Tremor Stone Placed (4/4)
.goto 2248,65.24,46.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tremor Stone|r. |cRXP_WARN_The stone will knock you back|r.
.complete 78758,1 
step
.goto 2248,66.99,47.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harmot|r.
.complete 78758,2 
.target Harmot
.skipgossipid 120785
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harmot|r and |cRXP_FRIENDLY_Harvester Farnee|r.
.turnin 78758 >>Turn in Pulse Within the Earth
.accept 78755 >>Accept Playing in the Mud
.goto 2248,66.99,47.37
.target +Harmot
.accept 78756 >>Accept Lots and Lots of Fire Honey
.goto 2248,67.01,47.29
.target +Harvester Farnee
step
>>Kill the |cRXP_ENEMY_Coalesced Living Honey|r. Loot it for the |T1129414:0|t[|cRXP_LOOT_Enormous Glob of Fire Honey|r].
.goto 2248,70.70,43.44
.complete 78756,1 
.mob Coalesced Living Honey
step
#loop
.goto 2248,72.22,48.98,30,0
.goto 2248,72.30,51.29,30,0
.goto 2248,68.66,56.45,35,0
.goto 2248,69.17,58.41,30,0
.goto 2248,72.30,51.29,40,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Elemental Silt Mound|r.
*|cRXP_WARN_You can also combine|r |T4554463:0|t[Frenzied Water Globule] and |T4554457:0|t[Frenzied Sand Globule] from the |cRXP_ENEMY_Scornful Sandshoals|r and |cRXP_ENEMY_Frenzied Tidecores|r.
.collect 211483,10
.disablecheckbox
.collect 211484,10
.disablecheckbox
.use 211483
.use 211484
.complete 78755,2 
.mob Scornful Sandshoal
.mob Frenzied Tidecore
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harvester Farnee|r and |cRXP_FRIENDLY_Harmot|r.
.turnin 78756 >>Turn in Lots and Lots of Fire Honey
.goto 2248,67.01,47.29
.target +Harvester Farnee
.turnin 78755 >>Turn in Playing in the Mud
.accept 78759 >>Accept To Wake a Giant
.goto 2248,67.00,47.37
.target +Harmot
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Slumbering Mountain Giant|r.
.goto 2248,66.48,47.08
.complete 78759,1 
.target Slumbering Mountain Giant
step
.goto 2248,66.99,47.37
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 78759,2 
step
#label end
.goto 2248,66.99,47.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harmot|r.
.turnin 78759 >>Turn in To Wake a Giant
.target Harmot
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) A Titanic Expedition
#internal
step
.goto 2248,58.79,28.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.accept 79724 >>Accept A Titanic Expedition!
.target Rannan Korren
step
#label Titanic ExpeditionStart
.goto 2248,77.92,30.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 79724 >>Turn in A Titanic Expedition!
.target Rannan Korren
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuberros|r and |cRXP_FRIENDLY_Rannan Korren|r.
.accept 79726 >>Accept "Cataloguing"
.goto 2248,77.91,30.33
.target +Tuberros
.accept 79725 >>Accept Not a Heating Pack
.goto 2248,77.96,30.31
.target +Rannan Korren
step
#completewith Cataloguing
>>Kill the |cRXP_ENEMY_Shimmerfin Gorlocs|r.
*Be careful of the menders as they heal the group
.complete 79725,1 
.mob Shimmerfin Scrapper
.mob Shimmerfin Oracle
.mob Shimmerfin Mender
step
#title Artifacts collected (1/7)
.goto 2248,79.43,29.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Artifacts|r.
.complete 79726,1,1 
step
#title Artifacts collected (2/7)
.goto 2248,80.35,29.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Artifacts|r.
.complete 79726,1,2 
step
#title Artifacts collected (3/7)
.goto 2248,80.85,29.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Artifacts|r.
.complete 79726,1,3 
step
#title Artifacts collected (4/7)
.goto 2248,80.74,29.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Artifacts|r.
.complete 79726,1,4 
step
#title Artifacts collected (5/7)
.goto 2248,80.43,30.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Artifacts|r.
.complete 79726,1,5 
step
#title Artifacts collected (6/7)
.goto 2248,80.07,29.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Artifacts|r.
.complete 79726,1,6 
step
#label Cataloguing
#title Artifacts collected (7/7)
.goto 2248,79.82,29.80
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Artifacts|r.
.complete 79726,1 
step
#loop
.goto 2248,79.97,29.97,30,0
.goto 2248,80.83,29.21,38,0
.goto 2248,79.00,27.87,35,0
.goto 2248,78.37,28.70,35,0
>>Kill the |cRXP_ENEMY_Shimmerfin Gorlocs|r.
.complete 79725,1 
.mob Shimmerfin Scrapper
.mob Shimmerfin Oracle
.mob Shimmerfin Mender
step
#label GorlocsSlainA
>>Kill the |cRXP_ENEMY_Shimmerfin Gorlocs|r.
.complete 79725,1 
.mob Shimmerfin Scrapper
.mob Shimmerfin Oracle
.mob Shimmerfin Mender
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuberros|r and |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 79726 >>Turn in "Cataloguing"
.goto 2248,77.91,30.33
.target +Tuberros
.turnin 79725 >>Turn in Not a Heating Pack
.goto 2248,77.96,30.31
.target +Rannan Korren
step
.goto 2248,77.95,30.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharessa Sunstrand|r.
.accept 79727 >>Accept Because It's Shiny
.target Tharessa Sunstrand
step
>>Kill |cRXP_ENEMY_Gramwharl|r. Loot it for the |T348536:0|t[|cRXP_LOOT_Titan Artifact|r].
.goto 2248,80.63,30.93
.complete 79727,1 
.mob Gramwharl
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharessa Sunstrand|r and |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 79727 >>Turn in Because It's Shiny
.goto 2248,77.94,30.32
.target +Tharessa Sunstrand
.accept 79728 >>Accept It's Probably Nothing
.goto 2248,77.96,30.31
.target +Rannan Korren
step
.goto 2248,77.95,30.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Titan Orb|r then wait for the roleplay.
.complete 79728,1 
.skipgossipid 121100
.skipgossipid 121103
step
#label Titanic ExpeditionEnd
.goto 2248,77.96,30.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 79728 >>Turn in It's Probably Nothing
.target Rannan Korren
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Remember Me, Earthen
#internal
step
.goto 2248,55.75,56.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.accept 81661 >>Accept To Mourning Rise
.target Urtago
step
#label CandleKoboldsStart
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r and |cRXP_FRIENDLY_Korgran|r.
.turnin -81661 >>Turn in To Mourning Rise
.goto 2248,57.47,42.94
.target +Urtago
.accept 78743 >>Accept Before I Depart
.goto 2248,57.45,42.96
.target +Korgran
step
#label RememberMeEarthenA
.goto 2248,61.70,41.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 78743 >>Turn in Before I Depart
.accept 78744 >>Accept Honor Their Memories
.target Urtago
step
#completewith PreciousGemPlaced
>>Kill the |cRXP_ENEMY_Kobolds|r in the area.
.complete 78744,4 
.mob Candlelit Pebblemaker
.mob Candlelit Desecrator
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Earthen Figurine|r.
.goto 2248,62.01,41.77
.complete 78744,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Deck of Cards|r.
.goto 2248,62.11,41.39
.complete 78744,1 
step
#label PreciousGemPlaced
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Precious Gem|r.
.goto 2248,62.52,40.95
.complete 78744,3 
step
#loop
.goto 2248,62.86,41.20,28,0
.goto 2248,62.00,41.67,28,0
.goto 2248,62.40,40.83,28,0
>>Kill the |cRXP_ENEMY_Candlelit Pebblemakers|r and |cRXP_ENEMY_Candlelit Desecrator|r in the area.
.complete 78744,4 
.mob Candlelit Pebblemaker
.mob Candlelit Desecrator
step
.goto 2248,61.70,41.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 78744 >>Turn in Honor Their Memories
.accept 78745 >>Accept You No Take Plunder!
.accept 78746 >>Accept Laws Apply to All
.target Urtago
step
#completewith EarthenBolongings
>>Kill the |cRXP_ENEMY_Kobolds|r in the area.
.complete 78746,1 
.mob Candlelit Hexthrower
.mob Candlelit Boomer
.mob Candlelit Lootsnatcher
step
#title Earthen Belongings (1/3)
.goto 2248,62.70,44.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Earthen Belongings|r |cRXP_WARN_inside the small house|r.
.complete 78745,1,1 
step
#title Earthen Belongings (2/3)
.goto 2248,63.19,43.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Earthen Belongings|r |cRXP_WARN_inside the small house|r.
.complete 78745,1,2 
step
#label EarthenBolongings
#title Earthen Belongings (3/3)
.goto 2248,63.86,42.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Earthen Belongings|r |cRXP_WARN_inside the small house|r.
.complete 78745,1 
step
#loop
.goto 2248,64.15,41.44,35,0
.goto 2248,62.85,41.79,30,0
.goto 2248,62.70,44.12,35,0
.goto 2248,63.33,42.52,30,0
>>Kill the |cRXP_ENEMY_Kobolds|r in the area.
.complete 78746,1 
.mob Candlelit Hexthrower
.mob Candlelit Boomer
.mob Candlelit Lootsnatcher
step
.goto 2248,63.31,42.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 78745 >>Turn in You No Take Plunder!
.turnin 78746 >>Turn in Laws Apply to All
.accept 78747 >>Accept The Great Collapse
.accept 78748 >>Accept Cutting the Wick
.target Urtago
step
#completewith next
>>Kill |cRXP_ENEMY_Hairless the Menace|r.
.complete 78748,1 
.mob Hairless the Menace
step
#title Tunnels Destroyed (1/3)
.goto 2248,64.19,42.95
>>Use the |T4203197:0|t[Explosive Sticks] and aim it at the |cRXP_PICK_Kobold Tunnel|r.^
*Do the World Quest aswell if its up
.complete 78747,1,1 
.use 211435
step
.goto 2248,64.71,42.51
>>Kill |cRXP_ENEMY_Hairless the Menace|r.
.complete 78748,1 
.mob Hairless the Menace
step
#label RememberMeEarthenB
.goto 2248,64.36,44.09
>>Kill |cRXP_ENEMY_Workmaster Earwax|r.
.complete 78748,2 
.mob Workmaster Earwax
step
#label RememberMeEarthenC
#completewith next
>>Kill |cRXP_ENEMY_Workmaster Nast|r.
.complete 78748,3 
.mob Workmaster Nast








step
#title Tunnels Destroyed (2/3)
.goto 2248,63.54,44.35
>>Use the |T4203197:0|t[Explosive Sticks] and aim it at the |cRXP_PICK_Kobold Tunnel|r.
*Do the World Quest aswell if its up
.complete 78747,1,2 
.use 211435
step
.goto 2248,63.26,45.05
>>Kill |cRXP_ENEMY_Workmaster Nast|r.
.complete 78748,3 
.mob Workmaster Nast
step
#title Tunnels Destroyed (3/3)
.goto 2248,62.85,44.78
>>Use the |T4203197:0|t[Explosive Sticks] and aim it at the |cRXP_PICK_Kobold Tunnel|r.
*Do the World Quest aswell if its up
.complete 78747,1 
.use 211435
step
#label RememberMeEarthenD
.goto 2248,63.30,42.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 78747 >>Turn in The Great Collapse
.turnin 78748 >>Turn in Cutting the Wick
.target Urtago
step
#label RememberMeEarthenE
.goto 2248,63.30,42.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.accept 78749 >>Accept Who Runs this Fine Establishment?
.target Urtago
step
#completewith next
#label GrandHeisterBokkSlain
.goto 2248,62.40,38.56,0,0
>>Kill |cRXP_ENEMY_Grand-Heister Bokk|r.
.complete 78749,1 
.mob Grand-Heister Bokk
step
#title Enter Cave
#completewith GrandHeisterBokkSlain
.goto 2248,62.48,39.18,10 >>Enter the Cave
step
#requires GrandHeisterBokkSlain
.goto 2248,62.40,38.56
>>Kill |cRXP_ENEMY_Grand-Heister Bokk|r.
.complete 78749,1 
.mob Grand-Heister Bokk
step
.goto 2248,62.46,39.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.complete 78749,2 
.target Urtago
.skipgossipid 120867
step
#label RememberMeEarthenF
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r and |cRXP_FRIENDLY_Korgran|r.
.turnin 78749 >>Turn in Who Runs this Fine Establishment?
.goto 2248,57.47,42.94
.target +Urtago
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r and |cRXP_FRIENDLY_Korgran|r.
.accept 79335 >>Accept One More Tradition
.goto 2248,57.45,42.96
.target +Korgran
step
#completewith ChargedCore
#hidewindow
#loop
.goto 2248,58.45,42.13,40,0
.goto 2248,59.58,41.23,35,0
.goto 2248,58.88,39.68,35,0
.goto 2248,59.91,38.90,40,0
.goto 2248,61.10,44.60,40,0
.goto 2248,59.42,44.43,37,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Scavenging Stormfangs|r and |cRXP_ENEMY_Great Stormfangs|r. Loot them for the |T340336:0|t[|cRXP_LOOT_Charged Core|r].
.complete 79335,1 
.mob Scavenging Stormfang
.mob Great Stormfang
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Veins of Ore|r.
.complete 79335,2 
step
#label ChargedCore
>>Kill |cRXP_ENEMY_Scavenging Stormfangs|r and |cRXP_ENEMY_Great Stormfangs|r. Loot them for the |T340336:0|t[|cRXP_LOOT_Charged Core|r].
.complete 79335,1 
.mob Scavenging Stormfang
step
#completewith next
#label OneMoreTradition
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korgran|r.
.turnin 79335 >>Turn in One More Tradition
.accept 79336 >>Accept The Forging of Memories
.target Korgran
step
.isOnQuest 79335
#title Enter House
#completewith OneMoreTradition
.goto 2248,57.38,42.90,8 >>Enter the House
step
#requires OneMoreTradition
.goto 2248,57.06,42.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korgran|r.
.turnin 79335 >>Turn in One More Tradition
.accept 79336 >>Accept The Forging of Memories
.target Korgran
step
.goto 2248,57.06,42.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korgran|r.
.complete 79336,1 
.target Korgran
.skipgossipid 120605
step
#completewith LanternCompleted
#label LanternForged
>>Complete the Lantern
.complete 79336,2 
.skipgossipid 120605
step
.isOnQuest 79336
#title Ingredient (1/6)
#completewith LanternForged
#label LanternIngredientA
.goto 2248,57.04,42.33
.cast 417168 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore Barrel|r |cRXP_WARN_when he requests the next ingredient|r.
.timer 12,Next Ingredient Estimation
step
.isOnQuest 79336
#title Ingredient (2/6)
#requires LanternIngredientA
#completewith LanternForged
#label LanternIngredientB
.goto 2248,56.99,42.52
.cast 417167 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Charged Core|r |cRXP_WARN_when he requests the next ingredient|r.
.timer 12,Next Ingredient Estimation
step
.isOnQuest 79336
#title Ingredient (3/6)
#requires LanternIngredientB
#completewith LanternForged
#label LanternIngredientC
.goto 2248,57.13,42.50
.cast 417163 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Pile of Coals|r |cRXP_WARN_when he requests the next ingredient|r.
.timer 12,Next Ingredient Estimation
step
.isOnQuest 79336
#title Ingredient (4/6)
#requires LanternIngredientC
#completewith LanternForged
#label LanternIngredientD
.goto 2248,57.06,42.49
>>Listen to |cRXP_FRIENDLY_Korgran|r.
*- "Would you toss me some of that |cRXP_WARN_ore|r, please?" -> |cRXP_PICK_Ore Barrel|r.
*- "Would you please hand me a |cRXP_WARN_charged core|r.? -> |cRXP_PICK_Charged Core|r.
*- "We need more heat! Toos in some |cRXP_WARN_coals|r|r. -> |cRXP_PICK_A Pile of Coals|r.
.cast 281581 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the correct ingredient |cRXP_WARN_when he requests the next ingredient|r.!
.timer 12,Next Ingredient Estimation
step
.isOnQuest 79336
#title Ingredient (5/6)
#requires LanternIngredientD
#completewith LanternForged
#label LanternIngredientE
.goto 2248,57.06,42.49
>>Listen to |cRXP_FRIENDLY_Korgran|r.
*- "Would you toss me some of that |cRXP_WARN_ore|r, please?" -> |cRXP_PICK_Ore Barrel|r.
*- "Would you please hand me a |cRXP_WARN_charged core|r.? -> |cRXP_PICK_Charged Core|r.
*- "We need more heat! Toos in some |cRXP_WARN_coals|r|r. -> |cRXP_PICK_A Pile of Coals|r.
.cast 281581 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the correct ingredient |cRXP_WARN_when he requests the next ingredient|r.!
.timer 12,Next Ingredient Estimation
step
.isOnQuest 79336
#title Ingredient (6/6)
#requires LanternIngredientE
#completewith LanternForged
#label LanternCompleted
.goto 2248,57.06,42.49
>>Listen to |cRXP_FRIENDLY_Korgran|r.
*- "Would you toss me some of that |cRXP_WARN_ore|r, please?" -> |cRXP_PICK_Ore Barrel|r.
*- "Would you please hand me a |cRXP_WARN_charged core|r.? -> |cRXP_PICK_Charged Core|r.
*- "We need more heat! Toos in some |cRXP_WARN_coals|r|r. -> |cRXP_PICK_A Pile of Coals|r.
.cast 281581 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the correct ingredient |cRXP_WARN_when he requests the next ingredient|r.!
.timer 3,Done!
step
#requires LanternForged
.goto 2248,57.06,42.49
>>Complete the Lantern
.complete 79336,2 
.skipgossipid 120605
step

.goto 2248,57.06,42.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korgran|r.
.turnin 79336 >>Turn in The Forging of Memories
.accept 79337 >>Accept The Last Journey
.timer 35,Roleplay Duration
.target Korgran
step
.goto 2248,57.47,42.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 79337 >>Turn in The Last Journey
.accept 79338 >>Accept The Lost Earthen
.target Urtago
step
#title |cFFFCDC00Follow the Arrow|r.
.goto 2248,61.00,43.89
.complete 79338,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Korgran's Lantern|r.
.goto 2248,61.36,43.70
.complete 79338,2 
step
#completewith next
#label SpeakToKorgranA

.goto 2248,61.00,43.89,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korgran|r.
.complete 79338,3 
.target Korgran
step
#completewith SpeakToKorgranA
.goto 2248,61.38,43.70
.skipgossipid 120893
.gossipoption 120892 >>Talk to |cRXP_FRIENDLY_Korgran|r.
.timer 22,Roleplay Duration
.target Korgran
step
#requires SpeakToKorgranA

.goto 2248,61.00,43.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korgran|r.
.complete 79338,3 
.target Korgran
.skipgossipid 120893
.skipgossipid 120892
step
.goto 2248,61.00,43.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 79338 >>Turn in The Lost Earthen
.accept 79339 >>Accept A Change of Tradition
.target Urtago
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.goto 2248,69.82,56.77
.turnin 79339 >>Turn in A Change of Tradition
.accept 79341 >>Accept Cleansing Ashes
.accept 79340 >>Accept Tools of Declaration
.target Urtago
step
#completewith AshenfoldCollected
>>Kill |cRXP_ENEMY_Shalehorn Impalers|r. Loot them for the |T4635273:0|t[|cRXP_LOOT_Pristine Horn|r].
.complete 79340,1 
.mob Shalehorn Impaler
step
#title Ashenfold Collected (1/6)
.goto 2248,68.56,54.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ashenfold|r.
*|cRXP_WARN_If you don't follow the exact route then the waypoints will be wrong|r.
.complete 79341,1,1 
step
#title Ashenfold Collected (2/6)
.goto 2248,67.98,53.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ashenfold|r.
*|cRXP_WARN_If you don't follow the exact route then the waypoints will be wrong|r.
.complete 79341,1,2 
step
#title Ashenfold Collected (3/6)
.goto 2248,67.84,54.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ashenfold|r.
*|cRXP_WARN_If you don't follow the exact route then the waypoints will be wrong|r.
.complete 79341,1,3 
step
#title Ashenfold Collected (4/6)
.goto 2248,67.40,53.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ashenfold|r.
*|cRXP_WARN_If you don't follow the exact route then the waypoints will be wrong|r.
.complete 79341,1,4 
step
#title Ashenfold Collected (5/6)
.goto 2248,67.37,54.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ashenfold|r.
*|cRXP_WARN_If you don't follow the exact route then the waypoints will be wrong|r.
.complete 79341,1,5 
step
#label AshenfoldCollected
#title Ashenfold Collected (6/6)
.goto 2248,67.16,54.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ashenfold|r.
*|cRXP_WARN_If you don't follow the exact route then the waypoints will be wrong|r.
.complete 79341,1 
step
#loop
.goto 2248,65.71,55.02,40,0
.goto 2248,66.40,58.92,40,0
.goto 2248,67.93,53.40,40,0
>>Kill |cRXP_ENEMY_Shalehorn Impalers|r. Loot them for the |T4635273:0|t[|cRXP_LOOT_Pristine Horn|r].
.complete 79340,1 
.mob Shalehorn Impaler
step
.goto 2248,69.82,56.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 79340 >>Turn in Cleansing Ashes
.turnin 79341 >>Turn in Cleansing Ashes
.accept 79342 >>Accept As He Departs
.target Urtago
step
.goto 2248,69.84,56.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
.complete 79342,1 
step

.goto 2248,69.85,56.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korgran|r.
.complete 79342,2 
.target Korgran
.skipgossipid 120638
.timer 14,Roleplay Duration
step
>>Wait for the roleplay
.goto 2248,69.82,56.77
.complete 79342,3 
step

.goto 2248,69.82,56.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 79342 >>Turn in As He Departs
.timer 30,Roleplay Duration
.target Urtago
step
.goto 2248,69.89,57.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r after the roleplay.
.accept 82895 >>Accept The Weight of Duty
.target Urtago
step
.goto 2248,57.30,42.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago at Fallside Outpost|r.
.complete 82895,1 
.target Urtago at Fallside Outpost
.skipgossipid 122723
step
#title |TInterface/cursor/crosshair/interact.blp:20|tClick on |cFFDB2EEFNew Placard|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_New Placard|r.
.goto 2248,57.36,42.53
.complete 82895,2 
step
#title |TInterface/cursor/crosshair/interact.blp:20|tClick on |cFFDB2EEFForge Tongs|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forge Tongs|r.
.goto 2248,57.23,42.79
.complete 82895,3 
step
#title |TInterface/cursor/crosshair/interact.blp:20|tClick on |cFFDB2EEFQuenching Oil|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Quenching Oil|r.
.goto 2248,57.37,43.05
.complete 82895,4 
step
#title |TInterface/cursor/crosshair/interact.blp:20|tClick on |cFFDB2EEFTempered Placard|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tempered Placard|r.
.goto 2248,57.06,43.49
.complete 82895,5 
step
.goto 2248,57.18,43.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urtago|r.
.turnin 82895 >>Turn in The Weight of Duty
.target Urtago
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) All Ore Nothing
#internal
step
.goto 2248,41.04,72.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Germira|r.
.accept 82792 >>Accept All Ore Nothing
.target Germira
step
.goto 2248,45.87,62.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alvegar|r.
.turnin 82792 >>Turn in All Ore Nothing
.accept 82796 >>Accept Third Mine Blind
.target Alvegar
step
#title Above the mine
.goto 2248,47.32,61.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alvegar|r |cRXP_WARN_above the mine|r.
.turnin 82796 >>Turn in Third Mine Blind
.accept 82797 >>Accept Hit Rock Bottom
.target Alvegar
step
#label FreywoldOpalcregMineStart
.goto 2248,47.32,61.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Parachute|r.
.complete 82797,1 
step
>>Jump down. |cRXP_WARN_Use your ExtraActionButton before reaching the bottom of the cave|r.
.goto 2248,47.85,61.83
.complete 82797,2 
step
.goto 2248,48.18,61.44,10,0
.goto 2248,48.46,61.88,12,0
.goto 2248,48.59,60.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cenderragg|r.
.turnin 82797 >>Turn in Hit Rock Bottom
.accept 82798 >>Accept An Opal of Mine
.accept 82799 >>Accept Web Beats Rock
.target Cenderragg
step
#completewith OpalsCollected
#hidewindow
#loop
.goto 2248,48.18,61.41,20,0
.goto 2248,47.59,60.14,20,0
.goto 2248,47.06,61.82,20,0
.goto 2248,47.79,62.85,20,0
.goto 2248,48.22,62.07,25,0
.goto 2248,48.90,61.54,18,0
.goto 2248,47.64,60.81,25,0
.goto 2248,47.71,61.77,18,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Opal Ore|r.
>>Kill |cRXP_ENEMY_Nerubian Skirmisher|r and |cRXP_ENEMY_Nerubian Webspinner|r. Loot them for the |T134089:0|t[|cRXP_LOOT_Opal Ore|r].
.complete 82798,1 
.mob Nerubian Skirmisher
.mob Nerubian Webspinner
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Opalcreg Worker|r.
.complete 82799,1 
step
#label OpalsCollected
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Opal Ore|r.
>>Kill |cRXP_ENEMY_Nerubian Skirmisher|r and |cRXP_ENEMY_Nerubian Webspinner|r. Loot them for the |T134089:0|t[|cRXP_LOOT_Opal Ore|r].
.complete 82798,1 
.mob Nerubian Skirmisher
.mob Nerubian Webspinner
step
#title Go up
.goto 2248,47.34,60.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cenderragg|r |cRXP_WARN_at the top near the exit of the cave|r.
.turnin 82799 >>Turn in An Opal of Mine
.turnin 82798 >>Turn in An Opal of Mine
.accept 82800 >>Accept A Sedimental Moment
.target Cenderragg
step
#loop
.goto 2248,47.08,61.75,8,0
.goto 2248,46.99,60.76,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Opalcreg Workers|r.
.complete 82800,1 
.target Opalcreg Worker
.skipgossipid 123364
step
#label FreywoldOpalcregMineStart
.goto 2248,47.35,60.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cenderragg|r.
.turnin 82800 >>Turn in A Sedimental Moment
.target Cenderragg
.accept 82801 >>Accept Beetlejeweled
step
#completewith next
#label KixArakSlain
>>Kill |cRXP_ENEMY_Kix'Arak|r.
.complete 82801,1 
.mob Kix'Arak
step
#title Leave Cave
#completewith KixArakSlain
.goto 2248,45.94,60.00,15 >>Leave the Cave
step
#requires KixArakSlain
.goto 2248,45.45,61.42
>>Kill |cRXP_ENEMY_Kix'Arak|r.
.complete 82801,1 
.mob Kix'Arak
step
#label FreywoldOpalcregEnd
.goto 2248,41.04,72.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Germira|r.
.turnin 82801 >>Turn in Beetlejeweled
.target Germira
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Heart of Stone
#internal
step
#label FreywoldVillageLoveofGems
.goto 2248,43.04,70.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.accept 82441 >>Accept For The Love of Gems
.target Natalia Pearce
step
#completewith next
#label TalkToBettaA
.goto 2248,41.67,71.79,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betta|r.
.complete 82441,1 
.target Betta
step
#title Enter House
#completewith TalkToBettaA
.goto 2248,41.55,72.36,8 >>Enter the House
step
#requires TalkToBettaA
.goto 2248,41.64,72.37,0
.goto 2248,41.55,72.36,0
.goto 2248,41.67,71.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betta|r.
.complete 82441,1 
.target Betta
.skipgossipid 122466
step
.goto 2248,40.93,71.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurron|r.
.complete 82441,2 
.target Kurron
.skipgossipid 122467
step
#completewith next
#label TalkToMalucA
.goto 2248,41.63,74.95,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maluc|r.
.complete 82441,3 
.target Maluc
.skipgossipid 122463
step
#title Enter House
#completewith TalkToMalucA
.goto 2248,41.51,74.38,8 >>Enter the House
step
#requires TalkToMalucA
.goto 2248,41.63,74.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maluc|r.
.complete 82441,3 
.target Maluc
.skipgossipid 122463
step
.goto 2248,43.04,70.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82441 >>Turn in For The Love of Gems
.accept 82465 >>Accept Precious Gems
.target Natalia Pearce
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.goto 2248,33.56,80.26
.complete 82465,1 
.timer 17,Roleplay Duration
.target Natalia Pearce

.skipgossip 223924,1
step
.goto 2248,33.59,80.03,0
.goto 2248,33.87,79.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82465 >>Turn in Precious Gems
.accept 82466 >>Accept What We Do For Gems
.target Natalia Pearce
step
#loop
.goto 2248,33.42,81.21,50,0
.goto 2248,31.07,73.50,45,0
>>Kill |cRXP_ENEMY_Igneous Elementals|r. Loot them for the |T5341572:0|t[|cRXP_LOOT_Igneous Core|r].
.complete 82466,1 
.mob Igneous Elemental
step
#completewith next
#label WhatWeDoForGemsA
.goto 2248,33.87,79.59,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82466 >>Turn in What We Do For Gems
.accept 82467 >>Accept Gems Are Forever
.target Natalia Pearce
step
#title Enter Cave
#completewith WhatWeDoForGemsA
.isOnQuest 82466
.goto 2248,33.59,80.03,8 >>Enter the Cave
step
#requires WhatWeDoForGemsA
.goto 2248,33.59,80.03,0
.goto 2248,33.87,79.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82466 >>Turn in What We Do For Gems
.accept 82467 >>Accept Gems Are Forever
.target Natalia Pearce
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.79,79.38
.complete 82467,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.96,79.68
.complete 82467,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.88,79.38
.complete 82467,3 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.97,79.55
.complete 82467,4 
.timer 17,Roleplay Duration
step

>>Wait for the roleplay
.goto 2248,33.87,79.58
.complete 82467,5 
step
.goto 2248,33.87,79.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82467 >>Turn in Gems Are Forever
.target Natalia Pearce
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Brotherhood in the Skolzgal Wood
#internal
step
.goto 2248,55.36,55.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dornogal Citizen|r.
.accept 80456 >>Accept A Sassy Arathi
.target Dornogal Citizen
step
.goto 2339,54.35,19.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80456 >>Turn in A Sassy Arathi
.accept 80209 >>Accept An Oddball in Dornogal
.target Peacekeeper Leif
step
#completewith next
#label ConcernedCitizensInverviewedA
.goto 2339,51.51,11.39,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Concerned Dornogal Citizen|r.
.complete 80209,1,1 
.target Concerned Dornogal Citizen
.skipgossipid 122512
step
.isOnQuest 80209
#completewith ConcernedCitizensInverviewedA
#title Enter House
.goto 2339,52.31,12.27,4 >>Enter the House
step
#requires ConcernedCitizensInverviewedA
.goto 2339,51.51,11.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Concerned Dornogal Citizen|r.
.complete 80209,1,1 
.target Concerned Dornogal Citizen
.skipgossipid 122512
step
#completewith next
#label ConcernedCitizensInverviewedB
.goto 2339,54.46,24.26,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Concerned Dornogal Citizen|r.
.complete 80209,1,2 
.target Concerned Dornogal Citizen
.skipgossipid 123322
step
.isOnQuest 80209
#completewith ConcernedCitizensInverviewedB
#title Enter House
.goto 2339,54.98,24.46,4 >>Enter the House
step
#requires ConcernedCitizensInverviewedB
.goto 2339,54.46,24.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Concerned Dornogal Citizen|r.
.complete 80209,1,2 
.target Concerned Dornogal Citizen
.skipgossipid 123322
step
.goto 2339,56.78,28.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Concerned Dornogal Citizen|r.
.complete 80209,1 
.target Concerned Dornogal Citizen
.skipgossipid 122511
step
#completewith next
#label AnOddballInDornogal
.goto 2339,67.17,18.73,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80209 >>Turn in An Oddball in Dornogal
.accept 80210 >>Accept Found Around the Unbound
.target Peacekeeper Leif
step
.isOnQuest 80209
#completewith AnOddballInDornogal
#title Enter House
.goto 2339,65.68,17.04,4 >>Enter the House
step
#requires AnOddballInDornogal
.goto 2339,67.17,18.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80209 >>Turn in An Oddball in Dornogal
.accept 80210 >>Accept Found Around the Unbound
.target Peacekeeper Leif
step
#completewith next
#label FoundAroundTheUnbound
.goto 2248,42.67,70.96,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80210 >>Turn in Found Around the Unbound
.accept 80211 >>Accept The Pillage of Freywold Village
.target Peacekeeper Leif
step
.isOnQuest 80211
#completewith FoundAroundTheUnbound
#title Leave House
.goto 2339,65.68,17.04,4 >>Leave the House
step
#requires FoundAroundTheUnbound
.goto 2248,42.67,70.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80210 >>Turn in Found Around the Unbound
.accept 80211 >>Accept The Pillage of Freywold Village
.target Peacekeeper Leif
step
#completewith next
#label ThePillageOfFreywoldVillageA
.goto 2248,41.86,73.87,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arathi Journal|r.
.complete 80211,1 
.skipgossipid 122552
step
.isOnQuest 80211
#completewith ThePillageOfFreywoldVillageA
#title Enter House
.goto 2248,41.87,73.56,4 >>Enter the House
step
#requires ThePillageOfFreywoldVillageA
.goto 2248,41.86,73.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arathi Journal|r.
.complete 80211,1 
.skipgossipid 122552
step
.goto 2248,41.82,75.11,10,0
.goto 2248,41.48,75.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conspicuous Arathi Candle|r.
.complete 80211,2 
.skipgossipid 122553
step
#completewith next
#label ThePillageOfFreywoldVillageB
.goto 2248,43.87,75.91,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Arathi Soldiers|r.
.complete 80211,3 
.target Arathi Soldier
.skipgossipid 122554
step
#completewith ThePillageOfFreywoldVillageB
#title Leave House
.goto 2248,41.84,75.03,5,0
.goto 2248,41.68,74.04,5,0
.goto 2248,41.86,73.54,4 >>Leave the House
step
#requires ThePillageOfFreywoldVillageB
.goto 2248,43.87,75.91,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Arathi Soldiers|r.
.complete 80211,3 
.target Arathi Soldier
.skipgossipid 122554
step
.goto 2248,42.66,70.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80211 >>Turn in The Pillage of Freywold Village
.accept 80212 >>Accept The Abductors' Obstructors
.target Peacekeeper Leif
step
.goto 2248,57.56,30.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80212 >>Turn in The Abductors' Obstructors
.target Peacekeeper Leif
step
.goto 2248,57.55,30.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lamplighter Kaerter|r.
.accept 80213 >>Accept Holy Fire in Rambleshire
.target Lamplighter Kaerter
step
#loop
.goto 2248,59.47,30.21,35,0
.goto 2248,59.94,29.64,35,0
.goto 2248,59.84,27.74,35,0
.goto 2248,58.57,28.16,35,0
>>Use the |T237546:0|t[Flashfire Thurible] |cRXP_WARN_and aim it at frightening citizens|r.
>>Kill the |cRXP_ENEMY_Nightshade Abductors|r. Loot them for the |T1500873:0|t[|cRXP_LOOT_Nightshade Letter|r].
.complete 80213,2 
.complete 80213,3 
.mob Nightshade Abductor
.use 224104
step
.goto 2248,62.05,30.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lamplighter Kaerter|r.
.turnin 80213 >>Turn in Holy Fire in Rambleshire
.accept 80214 >>Accept A Time to Kill at the Lumber Mill
.target Lamplighter Kaerter
step
.goto 2248,67.04,31.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lamplighter Kaerter|r.
.turnin 80214 >>Turn in A Time to Kill at the Lumber Mill
.accept 80215 >>Accept Ungirthin' the Earthen
.target Lamplighter Kaerter
step
.goto 2248,67.06,31.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.accept 80216 >>Accept Concealed in the Weald
.target Peacekeeper Leif
step
#completewith ConcealedInTheWeald
#hidewindow
#loop
.goto 2248,65.27,27.36,45,0
.goto 2248,68.45,26.25,45,0
.goto 2248,66.48,29.97,45,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Shadowsilk forces|r.
.complete 80216,1 
.mob Shadowsilk Burrower
.mob Shadowsilk Wallclimber
.mob Shadowsilk Taskmaster
.mob Shadowsilk Woodwebber
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lumberjack Restraints|r.
.complete 80215,1 
step
#label ConcealedInTheWeald
>>Kill the |cRXP_ENEMY_Shadowsilk forces|r.
.complete 80216,1 
.mob Shadowsilk Burrower
.mob Shadowsilk Wallclimber
.mob Shadowsilk Taskmaster
.mob Shadowsilk Woodwebber
step
.goto 2248,65.94,24.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80216 >>Turn in Concealed in the Weald
.turnin 80215 >>Turn in Ungirthin' the Earthen
.accept 80217 >>Accept A Lamplight for the Shipwright
.target Peacekeeper Leif
step
#completewith next
#label ALamplightForTheShipwright
.goto 2248,63.53,22.96,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_Shipwright Isaebela|r.
.complete 80217,1 
.mob Shipwright Isaebela
step
.isOnQuest 80217
#completewith ALamplightForTheShipwright
#title Enter Cave
.goto 2248,64.00,22.91,6 >>Enter the Cave
step
#requires ALamplightForTheShipwright
.goto 2248,63.53,22.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_Shipwright Isaebela|r.
.complete 80217,1 
.mob Shipwright Isaebela
step
>>Kill |cRXP_ENEMY_Shipwright Bodyguards|r.
.complete 80217,2 
.mob Shipwright Bodyguards
step
.goto 2248,63.52,22.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Lamplighter Kaerter|r.
.complete 80217,3 
.target Lamplighter Kaerter
step
.goto 2248,65.98,23.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80217 >>Turn in A Lamplight for the Shipwright
.accept 83181 >>Accept Best Friends, Same Ends
.target Peacekeeper Leif
step
.goto 2248,65.96,23.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lamplighter Kaerter|r.
.accept 80218 >>Accept Up to No Good Down in Silkwood
.target Lamplighter Kaerter
step
#completewith next
#label NoGoodDownInSilkwood
.goto 2248,63.88,20.04,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silkwood Explosive Barrel|r.
.complete 80218,1,1 
step
.isOnQuest 83181,80218
#completewith NoGoodDownInSilkwood
#title Enter Cave
.goto 2248,64.66,20.06,10 >>Enter the Cave
step
#requires NoGoodDownInSilkwood
#title Barrels collected (1/3)
.goto 2248,63.88,20.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silkwood Explosive Barrel|r.
.complete 80218,1,1 
step
#title Barrels collected (2/3)
.goto 2248,64.12,21.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silkwood Explosive Barrel|r.
.complete 80218,1,2 
step
.goto 2248,64.48,21.15
>>Kill |cRXP_ENEMY_Shadowspinner Azarak|r and |cRXP_ENEMY_Shipwright Isaebela|r.
.complete 83181,2 
.mob +Shadowspinner Azarak
.complete 83181,1 
.mob +Shipwright Isaebela
step
#title Barrels collected (3/3)
.goto 2248,64.41,20.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silkwood Explosive Barrel|r.
.complete 80218,1 
step
.goto 2248,63.68,20.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Explosive Barrels|r.
.complete 80218,2 
step
#completewith next
#label NoGoodInSameEnds
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lamplighter Kaerter|r and |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80218 >>Turn in Up to No Good Down in Silkwood
.goto 2248,65.51,20.45,0,0
.target +Lamplighter Kaerter
.turnin 83181 >>Turn in Best Friends, Same Ends
.goto 2248,65.49,20.46,0,0
.target +Peacekeeper Leif
step
.isOnQuest 80218,83181
#completewith NoGoodInSameEnds
#title Leave Cave
.goto 2248,64.77,19.97,10 >>Leave the Cave
step
#requires NoGoodInSameEnds
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lamplighter Kaerter|r and |cRXP_FRIENDLY_Peacekeeper Leif|r.
.turnin 80218 >>Turn in Up to No Good Down in Silkwood
.goto 2248,65.51,20.45
.target +Lamplighter Kaerter
.turnin 83181 >>Turn in Best Friends, Same Ends
.goto 2248,65.49,20.46
.target +Peacekeeper Leif
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name b1
#displayname |cFFFCDC00LEVEL 10-80|r |cRXP_ENEMY_(CHROMIE TIME)|r
#disabled
<< !Harronir/!Nightborne/!HighmountainTauren/!MagharOrc/!EarthenDwarf/!ZandalariTroll/!Vulpera/!Dracthyr/!VoidElf/!KulTiran/!LightforgedDraenei/!Mechagnome/!Pandaren DK
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name b1 2
#displayname |cFFFCDC00LEVEL 10-80|r |cRXP_ENEMY_(CHROMIE TIME)|r
#disabled
<< !Harronir/!Nightborne/!HighmountainTauren/!MagharOrc/!EarthenDwarf/!ZandalariTroll/!Vulpera/!Dracthyr/!VoidElf/!KulTiran/!LightforgedDraenei/!Mechagnome/!Pandaren DK
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bo
#displayname |cFFFCDC00LEVEL 10-80|r |cRXP_ENEMY_(W/O CHROMIE TIME)|r
#disabled
<< !Harronir/!Nightborne/!HighmountainTauren/!MagharOrc/!EarthenDwarf/!ZandalariTroll/!Vulpera/!Dracthyr/!VoidElf/!KulTiran/!LightforgedDraenei/!Mechagnome/!Pandaren DK
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bp
#displayname |cFFFCDC00LEVEL 10-80|r |cRXP_ENEMY_(W/O CHROMIE TIME)|r
#disabled
<< !Harronir/!Nightborne/!HighmountainTauren/!MagharOrc/!EarthenDwarf/!ZandalariTroll/!Vulpera/!Dracthyr/!VoidElf/!KulTiran/!LightforgedDraenei/!Mechagnome/!Pandaren DK
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Battle for Azeroth
#internal
<< Horde
step
.zoneskip 2022,1
.goto 2022,81.64,27.96
.zone 1 >>Take the Zeppelin to Orgrimmar
*|cRXP_WARN_You can now fly by using skyriding (double press space bar to start flying)|r
.macro Summon Random Favorite Mount,413588 >>/run C_MountJournal.SummonByID(0)
step
.goto 85,40.82,80.13
.cast 325534 >>Talk to |cRXP_FRIENDLY_Chromie|r.
.chromietime 9
.skipgossipid 51901
.skipgossipid 51902
.target Chromie
step
.isOnQuest 53502,50319,50303,55138,58124
.goto 85,40.777,80.404
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limbflayer Lasha|r.
.dailyturnin 53502,50319,50303,55138,58124 >>Turn in Stranger in a Strange Land
.target Limbflayer Lasha
step
.goto 85,48.68,70.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.accept 29611 >>Accept The Art of War
.target General Nazgrim
step
.goto 85,48.68,70.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.complete 29611,1 
.target General Nazgrim
step
.goto 85,48.68,70.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.turnin 29611 >>Turn in The Art of War
.target General Nazgrim
step
.goto 85,49.38,76.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warchief's Herald|r.
.accept 51443 >>Accept Battle for Azeroth: Mission Statement
.target Warchief's Herald
step
.goto 85,49.34,74.02
>>Follow the arrow into Grommash Hold
.complete 51443,1 
.isQuestAvailable 60360
step
.isNotOnQuest 44663
.goto 85,49.64,76.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Warchief's Command Board|r.
.accept 43926 >>Accept Legion: The Legion Returns
.choose 1851120
step
#include RestedXP Speed Leveling\a) Horde Legion Intro
step
#label MeetTeam
.goto 85,52.92,90.35,15,0
.goto 85,54.43,78.47
>>Wait for the roleplay.
.complete 51443,2 
.isOnQuest 51443
step
.zoneskip 1164
#veteran
.goto 85,54.43,78.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r to get teleported to Zandalar.
.turnin 51443 >>Turn in Battle for Azeroth: Mission Statement
.accept 50769 >>Accept The Stormwind Extraction
.zone 862 >> Teleport to Zandalar
.target Nathanos Blightcaller
.skipgossip
.isQuestAvailable 60360
.isQuestTurnedIn 52969
step << ZandalariTroll
.isOnQuest 50769
.isQuestComplete 50769
.goto 1164,39.94,71.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos Blightcaller|r.
.turnin 50769 >>Turn in The Stormwind Extraction
.target Nathanos Blightcaller
step
#label BFAStatement
.goto 85,54.43,78.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r.
.turnin 51443 >>Turn in Battle for Azeroth: Mission Statement
.accept 50769 >>Accept The Stormwind Extraction
.target Nathanos Blightcaller
.isQuestAvailable 60360
step << !ZandalariTroll
.goto 85,54.58,78.36
>>Loot the |cRXP_PICK_Potion|r on the table.
.complete 50769,1 
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 85,51.19,83.57
.vehicle >>Get onto a |cRXP_FRIENDLY_Skyhorn Eagle|r.
.timer 95,The Stormwind Extraction RP
.target Skyhorn Eagle
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
>>|cRXP_WARN_Wait out the RP|r.
.scenario 3718,1
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1012,46.31,58.20,-1
.goto 1012,46.16,58.04,-1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_PICK_Padlocks|r on the ground.
.scenario 3719,2
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1012,46.31,57.96
>>|cRXP_WARN_Go down the Stockades Portal in the water|r.
.scenario 3719,1
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1013,31.52,62.04,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tOpen the |cRXP_PICK_Cell Door|r to |cRXP_FRIENDLY_Saurfang|r.'s prison
>>|cRXP_WARN_Ignore all the|r |cRXP_ENEMY_7th Legion Enforcers|r |cRXP_WARN_and|r |cRXP_ENEMY_7th Legion Sharpshooters|r. |cRXP_WARN_They disappear when you open the|r |cRXP_PICK_Cell Door|r.
.scenario 3721,2
.goto 1013,50.67,38.88
.gossipoption 48752 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Saurfang|r.
.timer 48,The Stormwind Extraction RP
.goto 1013,48.05,33.52
.target High Overlord Saurfang
.skipgossip
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
#completewith next
.goto 1013,59.60,59.72,8,0
.goto 1013,55.65,64.12,5 >>Run to the next Prison Cell
step << !ZandalariTroll
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tOpen the |cRXP_PICK_Cell Door|r to |cRXP_FRIENDLY_Talanji|r.'s and |cRXP_FRIENDLY_Zul|r.'s prison
>>You may have to wait out |cRXP_FRIENDLY_Saurfang|r.'s RP
.goto 1013,55.65,64.48
.scenario 3722,1
.timer 61,The Stormwind Extraction RP
.mob 7th Legion Sharpshooter
.mob 7th Legion Enforcer
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
#completewith next
.goto 1013,59.44,37.24,8 >>|cRXP_WARN_Wait out the RP. Follow the group|r.
step << !ZandalariTroll
.goto 1013,75.57,26.40,8,0
.goto 1013,87.15,23.20
>>Kill |cRXP_ENEMY_7th Legion Enforcers|r, |cRXP_ENEMY_7th Legion Sharpshooters|r, and |cRXP_ENEMY_7th Legion Battlemages|r in the big circular room
>>Kill |cRXP_ENEMY_Lyra|r and her |cRXP_ENEMY_7th Legion Battlemages|r when they spawn.
>>After killing |cRXP_ENEMY_Lyra|r, |TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_PICK_Sewer Access Door on the ground|r.
.scenario 3722,2
.mob 7th Legion Enforcer
.mob 7th Legion Sharpshooter
.mob 7th Legion Battlemage
.mob Mage-Commander Lyra
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
#completewith next
.goto 1012,71.09,46.72
>>|cRXP_WARN_Dismiss your pet|r. << Hunter/Warlock
.gossipoption 48518 >> Talk to |cRXP_FRIENDLY_Rokhan|r.
.target Rokhan
step << !ZandalariTroll
.goto 1012,70.22,47.53,15,0
.goto 1012,68.51,49.84,15,0
.goto 1012,66.05,51.25,15,0
.goto 1012,64.00,49.59,15,0
.goto 1012,64.30,48.72,8,0
.goto 1012,62.34,47.46,15,0
.goto 1012,61.50,44.77,15,0
.goto 1012,60.00,44.85,8,0
.goto 1012,59.59,43.55
>>|cRXP_WARN_Follow|r |cRXP_FRIENDLY_Rokhan|r.
>>|cRXP_WARN_Stay inside|r |cRXP_FRIENDLY_Rokhan|r.|cRXP_WARN_'s circle to stay stealthed|r.
>>|cRXP_WARN_Avoid red circles to avoid detection|r.
.gossipoption 48339 >> Talk to |cRXP_FRIENDLY_Rokhan|r when he stops after jumping off the Bridge.
.target Rokhan
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1012,61.21,44.93,12,0
.goto 1012,60.48,45.70,15,0
.goto 1012,59.66,46.81,15,0
.goto 1012,60.29,49.05,15,0
.goto 1012,58.13,52.45,15,0
.goto 1012,57.57,54.49,15,0
.goto 1012,55.96,57.10
>>|cRXP_WARN_Follow|r |cRXP_FRIENDLY_Rokhan|r.
>>|cRXP_WARN_Stay inside|r |cRXP_FRIENDLY_Rokhan|r.|cRXP_WARN_'s circle to stay stealthed|r.
>>|cRXP_WARN_Avoid red circles to avoid detection|r.
>>|cRXP_WARN_Press "Escape" on your keyboard to skip the cinematic|r.
.scenario 3727,1
.target Rokhan
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1012,55.97,57.09
>>Kill the |cRXP_ENEMY_Gilnean Maulers|r attacking the shield.
>>|cRXP_WARN_Wait out the RP|r.
.scenario 3729,1
.mob Gilnean Mauler
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1012,53.79,55.25,20,0
.goto 1012,51.69,54.93,20,0
.goto 1012,49.60,52.21,20,0
.goto 1012,47.33,51.66,20,0
.goto 1012,47.43,47.28,20,0
.goto 1012,49.32,42.49,20,0
.goto 1012,45.43,43.18
>>Follow the group whilst killing |cRXP_ENEMY_Gilnean Maulers|r, |cRXP_ENEMY_Stormwind Guards|r, and |cRXP_ENEMY_Stormwind Battlemages|r.
.gossipoption 48198 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r.
.scenario 3729,2
.mob Gilnean Mauler
.mob Stormwind Guard
.mob Stormwind Battlemage
.target Nathanos Blightcaller
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1012,43.53,42.81,20,0
.goto 1012,42.41,42.79,20,0
.goto 1012,39.79,40.59
>>|cRXP_WARN_Dodge the White Swirls on the ground|r.
>>|cRXP_WARN_Stay in|r |cRXP_FRIENDLY_Talanji|r.|cRXP_WARN_'s Bubble when she casts it|r.
>>Kill the |cRXP_ENEMY_Ice Barrier|r.
.scenario 3730,1
.mob Ice Barrier
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
>>|cRXP_WARN_Follow the group|r.
>>Kill the |cRXP_ENEMY_Alliance|r to reach |cRXP_FRIENDLY_Talanji|r.'s Ship |cRXP_WARN_with the group|r.
.scenario 3788,1
.goto 1012,33.54,34.75,30,0
.goto 1012,31.47,31.73,30,0
.goto 1012,29.14,31.42,30,0
.goto 1012,29.69,26.64,30,0
.goto 1012,19.64,25.70
.mob Gilnean Mauler
.mob Stormwind Guard
.mob Stormwind Knight
.mob Stormwind Battlemage
.mob Teldrassil Sentinel
.mob Dwarven Rifleman
.mob Gnomish Gyro-Engineer
.mob Exodar Peacekeeper
.zoneskip 862
.isOnQuest 50769
step << !ZandalariTroll
.goto 1012,20.07,28.76,10,0
.goto 1012,20.54,28.94
>>|cRXP_WARN_Press "Escape" on your keyboard to skip the cinematics|r.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talanji|r when she gets onto the ship.
.complete 50769,3 
.target Princess Talanji
.skipgossip
.zoneskip 862
.isOnQuest 50769
steps << !ZandalariTroll
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r.
.goto 862,57.95,62.76
.turnin 60361 >>Turn in Battle for Azeroth: Mission Statement
.target Nathanos Blightcaller
.isOnQuest 60361
step << !ZandalariTroll
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r.
.turnin 50769 >>Turn in The Stormwind Extraction
.goto 1164,40.11,71.56,-1
.goto 862,57.96,62.76,-1
.target Nathanos Blightcaller
.isQuestComplete 50769
step << !ZandalariTroll
#label ZuldazarWelcometoZuldazar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talanji|r.
.accept 46957 >>Accept Welcome to Zuldazar
.goto 862,57.95,62.46
.target Princess Talanji
.zoneskip 1164
step << !ZandalariTroll
.goto 1165,50.78,92.73,40,0
.goto 1165,50.35,90.93,40,0
.goto 1165,49.94,85.84,40,0
.goto 1165,48.89,83.91,40,0
.goto 1165,49.98,82.33
>>|cRXP_WARN_Stay close to |cRXP_FRIENDLY_Princess Talanji|r else she will stop moving|r.
.complete 46957,1 
.target Princess Talanji
.zoneskip 1164
step << !ZandalariTroll
.goto 1165,49.98,82.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Jakra'zet|r.
.turnin 46957 >>Turn in Welcome to Zuldazar
.accept 46930 >>Accept Rastakhan
.target General Jakra'zet
.zoneskip 1164
step << !ZandalariTroll
.goto 1165,49.98,82.58
>>|cRXP_WARN_DO NOT ride the Pterrordax|r.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tInstead, talk to |cRXP_FRIENDLY_Talanji|r.
.complete 46930,1 
.target Princess Talanji
.skipgossip
.zoneskip 1164
step << !ZandalariTroll
.goto 1165,49.91,42.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan|r.
.turnin 46930 >>Turn in Rastakhan
.accept 46931 >>Accept Speaker of the Horde
.target King Rastakhan
.zoneskip 1164
step << !ZandalariTroll
#completewith next
#title |cFFFCDC00Follow the Arrow|r You don't need to follow Zolani.
.goto 1165,49.43,44.67,10,0
.goto 1165,48.66,44.61,20,0
.goto 1165,49.93,39.86
.complete 46931,1 
.isOnQuest 46931
step << !ZandalariTroll
.goto 1165,49.93,39.58
>>|TInterface/GossipFrame/HealerGossipIcon:0|tClick the shade of the |cRXP_PICK_Horde Banner|r.
.complete 46931,2 
.isOnQuest 46931
step << !ZandalariTroll
#completewith next
.cooldown item,132516,>0,1
.cast 202844 >>Use your |T1405809:0|t[Gunshoes] to move faster
.use 132516
.itemcount 132516,1
.isOnQuest 46931
step << !ZandalariTroll
>>Go into the three rooms
.complete 46931,3 
.goto 1163,49.78,73.50
.complete 46931,4 
.goto 1163,67.67,70.75
.complete 46931,5 
.goto 862,57.57,44.37
.isOnQuest 46931
step << !ZandalariTroll
#label Horde Zuldazar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tGo up and talk to |cRXP_FRIENDLY_Talanji|r.
*|cRXP_WARN_NOTE:|r If you're very fast then you can skip Talanji's roleplay by relogging
.goto 1164,44.67,70.33,20,0
.goto 1164,41.22,66.75
.turnin 46931 >>Turn in Speaker of the Horde
.target Princess Talanji
.isOnQuest 46931
step
#include a) Horde Zuldazar
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Zuldazar
#internal
<< Horde
step
#completewith BattleForAzerothHordeEnd
#hidewindow
+1
.usespell 1231411
step << !ZandalariTroll
.isQuestAvailable 51443
.goto 85,40.83,80.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
>>|cRXP_WARN_Select "Battle for Azeroth" Campaign|r.
*|cRXP_WARN_It's possible that it bugs out and doesn't give you the quest. If this is the case select the "Cataclysm" campaign and swap back to the "Battle for Azeroth" one until you get the quest|r.
.accept 51443 >>Accept Battle for Azeroth: Mission Statement
.skipgossip
.target Chromie
step << !ZandalariTroll
.isOnQuest 51443
>>Enter the building
.goto 85,49.43,75.11
*You can skip most cinematics/cutscene by presseing ESC and then clicking yes
.complete 51443,1 
step << !ZandalariTroll
.isOnQuest 51443
.goto 85,54.43,78.47
>>Go into the Inn
.complete 51443,2 
step << !ZandalariTroll
.isQuestAvailable 50769
.goto 85,54.43,78.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos Blightcaller|r.
.turnin -51443 >>Turn in Battle for Azeroth: Mission Statement
.accept 50769 >>Accept The Stormwind Extraction
.target Nathanos Blightcaller
step << !ZandalariTroll
.isOnQuest 50769
.isQuestTurnedIn 52969
.zoneskip 862
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos Blightcaller|r again.
*|cRXP_WARN_Don't take the potion. If you did then abandon the quest and accept it again|r.
.goto 85,54.43,78.47
.skipgossip 1
.target Nathanos Blightcaller
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>Loot the |cRXP_PICK_potion|r on the table.
.goto 85,54.58,78.36
.complete 50769,1 
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 85,1
.isQuestTurnedIn 52969
>>You took the potion. Abandon the quest, reaccept it and use the skip. If you really want to do the scenario again then skip this step
.abandon 50769
step << !ZandalariTroll
.isOnQuest 50769
#completewith next
.isQuestTurnedIn 52969
.zoneskip 85,1
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos Blightcaller|r again.
*|cRXP_WARN_Don't take the potion. If you did then abandon the quest and accept it again|r.
.goto 85,54.43,78.47
.skipgossip 1
.target Nathanos Blightcaller
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 85,1
>>Loot the |cRXP_PICK_potion|r on the table.
.goto 85,54.58,78.36
.complete 50769,1 
step << !ZandalariTroll
.isQuestComplete 50769
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos Blightcaller|r.
.turnin 50769 >>Turn in The Stormwind Extraction
.goto 1164,40.11,71.56,-1
.goto 862,57.96,62.76,-1
.target Nathanos Blightcaller
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>Leave the building. Get onto a |cRXP_FRIENDLY_Skyhorn Eagle|r outside. |cRXP_WARN_It's worth doing the scenario at least once so you can skip it on subsequent characters|r.
.goto 85,51.19,83.57
.complete 50769,2 
.target Skyhorn Eagle
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
.scenario 3718,1
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the two |cRXP_PICK_Padlocks|r next to the waypoint by clicking on them. Afterwards follow the arrow into the trapdoor
.scenario 3719,2
.goto 1012,46.31,58.22
.scenario 3719,1
.goto 1012,46.31,57.96
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tIf possible ignore all mobs, open the door at the end as fast as possible and talk to |cRXP_FRIENDLY_Saurfang|r.
.scenario 3720,1
.goto 1013,31.52,62.04,3,0
.goto 1013,50.99,39.32
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tIf possible ignore all mobs, open the door at the end as fast as possible and talk to |cRXP_FRIENDLY_Saurfang|r.
.scenario 3721,2
.scenario 3721,1
.goto 1013,48.03,33.56,10,0
.goto 1013,55.92,64.00
>> You can already wait at the next prison cell
.skipgossip
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>Wait at the waypoint until you can see the barrier and then wait until the barrier disappears
.scenario 3722,1
.goto 1013,55.92,64.00
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>You only need to kill the mobs in front and inside the big circular room. If you're experienced you can ignore the other ones
*|TInterface/GossipFrame/HealerGossipIcon:0|tClick on the |cRXP_PICK_Stormwind Sewer Access|r at the end.
.scenario 3722,2
.goto 1013,53.68,44.44,5,0
.goto 1013,87.17,23.20
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>|cRXP_WARN_Dismiss your pet as a Hunter or Warlock|r. << Hunter/Warlock
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rokhan|r and follow him. Stay inside the shroud.
.scenario 3727,1
.goto 1012,71.07,46.71,3,0
.skipgossip
.target Rokhan
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>Follow the arrow and kill mobs when you see them.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tAt the end talk to |cRXP_FRIENDLY_Nathanos|r.
.scenario 3729,1
.goto 1012,55.81,56.85
.scenario 3729,2
.goto 1012,53.20,55.42,15,0
.goto 1012,47.38,51.81,10,0
.goto 1012,49.42,42.23,15,0
.goto 1012,45.43,43.18
.skipgossip
.target Nathanos Blightcaller
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>Follow the arrow, dodge the swirlies on the ground and destroy the |cRXP_ENEMY_Ice Barrier|r.
.scenario 3730,1
.goto 1012,39.79,40.59
.mob Ice Barrier
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>Follow the arrow, kill all mobs on the way. Wait for the NPCs to attack them if you're not confident that you can kill them alone
.scenario 3788,1
.goto 1012,36.61,34.81,20,0
.goto 1012,34.40,34.65,10,0
.goto 1012,31.79,31.66,10,0
.goto 1012,28.72,31.54,20,0
.goto 1012,29.81,26.57,25,0
.goto 1012,19.64,25.70
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
#completewith next
+You can skip the cutscene at the end by pressing ESC and clicking on Yes
step << !ZandalariTroll
.isOnQuest 50769
.zoneskip 862
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tFollow |cRXP_FRIENDLY_Princess Talanji|r and talk to her.
.goto 1012,19.34,28.66,10,0
.goto 1012,20.54,28.93
.skipgossip
.complete 50769,3 
.mob Princess Talanji
steps << !ZandalariTroll
.isOnQuest 60361
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos Blightcaller|r.
.goto 862,57.95,62.76
.turnin 60361 >>Turn in Battle for Azeroth: Mission Statement
.target Nathanos Blightcaller
step << !ZandalariTroll
.isQuestComplete 50769
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos Blightcaller|r.
.turnin 50769 >>Turn in The Stormwind Extraction
.goto 1164,40.11,71.56,-1
.goto 862,57.96,62.76,-1
.target Nathanos Blightcaller
step << !ZandalariTroll
.zoneskip 1164
#label ZuldazarWelcometoZuldazar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Talanji|r.
.accept 46957 >>Accept Welcome to Zuldazar
.goto 862,57.95,62.46
.mob Princess Talanji
step << !ZandalariTroll
.isOnQuest 46957
.zoneskip 1164
>>|cRXP_WARN_Stay close to |cRXP_FRIENDLY_Talanji|r else she will stop moving|r.
.goto 1165,50.02,60.63,40,0
.goto 1165,50.78,92.73,40,0
.goto 1165,50.35,90.93,40,0
.goto 1165,49.94,85.84,40,0
.goto 1165,48.89,83.91,40,0
.goto 1165,49.98,82.33
.complete 46957,1 
step << !ZandalariTroll
.isQuestAvailable 46930
.zoneskip 1164
.goto 1165,49.98,82.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Jakra'zet|r.
.turnin -46957 >>Turn in Welcome to Zuldazar
.accept 46930 >>Accept Rastakhan
.target General Jakra'zet
step << !ZandalariTroll
.isOnQuest 46930
.zoneskip 1164
.goto 1165,49.98,82.58
>>|cRXP_WARN_DO NOT ride the Pterrordax|r.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tInstead, talk to |cRXP_FRIENDLY_Princess Talanji|r.
.complete 46930,1 
.skipgossip
.mob Princess Talanji
step << !ZandalariTroll
.isQuestAvailable 46931
.zoneskip 1164
.goto 1165,49.91,42.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan|r.
.turnin -46930 >>Turn in Rastakhan
.accept 46931 >>Accept Speaker of the Horde
.target King Rastakhan
step << !ZandalariTroll
.isOnQuest 46931
#completewith next
#title |cFFFCDC00Follow the Arrow|r You don't need to follow |cRXP_FRIENDLY_Zolani|r.
.goto 1165,49.43,44.67,10,0
.goto 1165,48.66,44.61,20,0
.goto 1165,49.93,39.86
.complete 46931,1 
step << !ZandalariTroll
.isOnQuest 46931
.goto 1165,49.93,39.86
>>|TInterface/GossipFrame/HealerGossipIcon:0|tClick on the shade of the |cRXP_PICK_Horde Banner|r.
.complete 46931,2 
step << !ZandalariTroll
.isOnQuest 46931
#completewith next
.cooldown item,132516,>0,1
.cast 202844 >>Use your |T1405809:0|t[Gunshoes] to move faster
.use 132516
.itemcount 132516,1
step << !ZandalariTroll
.isOnQuest 46931
>>Go into the three rooms
.complete 46931,3 
.goto 1163,49.78,73.50
.complete 46931,4 
.goto 1163,67.67,70.75
.complete 46931,5 
.goto 862,57.57,44.37
step << !ZandalariTroll
.isOnQuest 46931
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tGo up and talk to |cRXP_FRIENDLY_Talanji|r.
*|cRXP_WARN_NOTE:|r If you're very fast then you can skip Talanji's roleplay by relogging
.goto 1164,44.67,70.33,20,0
.goto 1164,41.22,66.75
.turnin 46931 >>Turn in Speaker of the Horde
.target Princess Talanji
step
.goto 85,53.38,90.49,10,0
.goto 85,54.80,90.20,10,0
.goto 85,54.80,87.00,10,0
.goto 85,56.06,87.11,10,0
.goto 85,57.84,89.83
.zone 862 >>Enter the |cRXP_PICK_Portal to Zuldazar|r.
.zoneskip 85,1



step
#label ZuldazarAcceptZuldazar
.goto 1164,41.72,69.33
>>|TInterface/GossipFrame/HealerGossipIcon:0|tClick on the |cRXP_PICK_Scouting Map|r and accept Zuldazar.
.accept 47514 >>Accept Zuldazar
.acceptmap 47514
step
.goto 1164,41.22,66.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talanji|r.
.turnin 47514 >>Turn in Zuldazar
.accept 49615 >>Accept Trust of a King
.target Princess Talanji
step
#completewith next
#label TrustOfAKingA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan|r, |cRXP_FRIENDLY_Zolani|r, and |cRXP_FRIENDLY_Yazma|r |cRXP_WARN_upstairs|r.
.turnin 49615 >>Turn in Trust of a King
.accept 49488 >>Accept Tal'gurub
.target King Rastakhan
step
#completewith TrustOfAKingA
.goto 1164,22.67,72.08,5,0
.goto 1165,48.72,44.92,10,0
.goto 1165,49.56,44.60,18 >>Take the elevator or fly up to |cRXP_FRIENDLY_King Rastakhan|r.
step
#requires TrustOfAKingA
.goto 1165,49.93,46.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan|r, |cRXP_FRIENDLY_Zolani|r, and |cRXP_FRIENDLY_Yazma|r |cRXP_WARN_upstairs|r.
.turnin 49615 >>Turn in Trust of a King
.accept 49488 >>Accept Tal'gurub
.target King Rastakhan
step
.goto 862,65.66,41.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Direhorn Hatchling|r.
.accept 47226 >>Accept The Orphaned Hatchling
.target Direhorn Hatchling
step
.goto 862,66.81,42.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beastlord L'kala|r.
.turnin 47226 >>Turn in The Orphaned Hatchling
.accept 47259 >>Accept Direhorn Daycare
.accept 48527 >>Accept Ravenous Landsharks
.target Beastlord L'kala
step
#completewith next
.goto 862,68.35,45.75,0,0
>>Kill |cRXP_ENEMY_Irritable Diemetradon|r.
.complete 48527,1 
.mob Irritable Diemetradon
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tClick the |cRXP_PICK_Soothing Lilybuds|r.
*When the plant keeps glowing you have to |TInterface/cursor/crosshair/interact.blp:20|tClick it again
.goto 862,68.09,43.42,6,0
.goto 862,68.70,43.99,6,0
.goto 862,68.96,44.07,6,0
.goto 862,69.90,44.22,6,0
.goto 862,69.53,44.95,6,0
.goto 862,69.20,45.51,6,0
.goto 862,68.88,45.34,6,0
.goto 862,68.65,44.48,6,0
.goto 862,68.11,44.31,6,0
.goto 862,68.38,45.78
.complete 47259,1 
step
.goto 862,69.04,47.68,30,0
.goto 862,69.61,44.45,30,0
.goto 862,68.96,43.89
>>Kill |cRXP_ENEMY_Irritable Diemetradons|r.
.complete 48527,1 
.mob Irritable Diemetradon
step
.goto 862,66.81,42.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beastlord L'kala|r and |cRXP_FRIENDLY_Trader Alexxi|r.
.turnin 47259 >>Turn in Direhorn Daycare
.turnin 48527 >>Turn in Ravenous Landsharks
.target Beastlord L'kala
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_PICK_Poster|r and |cRXP_FRIENDLY_Wingrider Nivek|r.
.accept 51980 >>Accept WANTED: Jabra'kan
.goto 862,69.07,40.85
.accept 47312 >>Accept Queenfeather
.goto 862,69.02,40.69
.target Wingrider Nivek
step
.goto 862,71.14,40.26
>>Kill |cRXP_ENEMY_Queenfeather|r. Loot her for her [|cRXP_LOOT_plume|r].
.complete 47312,1 
.mob Queenfeather
step
.goto 862,67.07,37.11
>>Kill |cRXP_ENEMY_Jabra'kan|r. |cRXP_WARN_Move away from Traps he throws at you and the cone damage from his Volley|r.
*|cRXP_WARN_Skip this step if he's not up during an assault|r.
.complete 51980,1 
.mob Jabra'kan the Poacher
step
.isQuestComplete 51980
.goto 862,69.02,40.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wingrider Nivek|r.
.turnin 51980 >>Turn in WANTED: Jabra'kan
.turnin 47312 >>Turn in Queenfeather
.target Wingrider Nivek
step
.goto 862,69.02,40.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wingrider Nivek|r.
.abandon 51980 >>Abandon WANTED: Jabra'kan
.turnin 47312 >>Turn in Queenfeather
.target Wingrider Nivek
step
.goto 862,64.13,35.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jangalar|r.
.accept 49810 >>Accept Monstrous Matchmaker
.target Witch Doctor Jangalar
step
.goto 862,63.06,37.13
>>Use the |T1692686:0|t[Jangalar's Voodoo Totem].
.complete 49810,1 
.use 155911
step
.goto 862,64.22,39.38
>>Use the |T1692686:0|t[Jangalar's Voodoo Totem].
.complete 49810,2 
.use 155911
step
.goto 862,64.13,35.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jangalar|r.
.turnin 49810 >>Turn in Monstrous Matchmaker
.accept 49814 >>Accept The Scent for a Brutosaur
.accept 50154 >>Accept They Say It's a Delicacy
.target Witch Doctor Jangalar
step
.goto 862,64.07,35.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cala Cruzpot|r.
.accept 49801 >>Accept Aggressive Mating Strategy
.target Cala Cruzpot
step
#completewith TheScentForABrutosaurA
>>Kill the |cRXP_ENEMY_Diemetradons|r. Loot them for the |T155917:0|t[|cRXP_LOOT_Partially Digested Pods|r].
.complete 50154,1 
.mob Young Diemetradon
.mob Elder Diemetradon
.mob Diemetradon
step
#title Rushes collected (1/7) |cFFFCDC00(Read Note)|r
.goto 862,62.74,35.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zandalari Rushes|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49814,1,1 
step
#title Rushes collected (2/7) |cFFFCDC00(Read Note)|r
.goto 862,62.49,36.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zandalari Rushes|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49814,1,2 
step
#title Rushes collected (3/7) |cFFFCDC00(Read Note)|r
.goto 862,62.72,36.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zandalari Rushes|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49814,1,3 
step
#title Rushes collected (4/7) |cFFFCDC00(Read Note)|r
.goto 862,62.94,38.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zandalari Rushes|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49814,1,4 
step
#title Rushes collected (5/7) |cFFFCDC00(Read Note)|r
.goto 862,62.63,38.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zandalari Rushes|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49814,1,5 
step
#title Rushes collected (6/7) |cFFFCDC00(Read Note)|r
.goto 862,62.75,38.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zandalari Rushes|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49814,1,6 
step
#label TheScentForABrutosaurA
#title Rushes collected (7/7) |cFFFCDC00(Read Note)|r
.goto 862,62.55,39.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zandalari Rushes|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49814,1 
step
#loop
.goto 862,62.84,39.82,35,0
.goto 862,62.27,34.75,35,0
>>Kill the |cRXP_ENEMY_Diemetradons|r. Loot them for the |T155917:0|t[|cRXP_LOOT_Partially Digested Pods|r].
.complete 50154,1 
.mob Young Diemetradon
.mob Elder Diemetradon
.mob Diemetradon
step
#loop
.goto 862,61.71,42.80,25,0
.goto 862,64.69,42.08,35,0
>>Kill the |cRXP_ENEMY_Invasive Razorwings|r. Loot them for the |T237414:0|t[|cRXP_LOOT_Bile Sacs|r].
.complete 49801,1 
.mob Invasive Razorwing
step
.goto 862,64.07,35.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cala Cruzpot|r.
.turnin 49801 >>Turn in Aggressive Mating Strategy
.target Cala Cruzpot
step
.goto 862,64.13,35.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jangalar|r.
.turnin 49814 >>Turn in The Scent for a Brutosaur
.turnin 50154 >>Turn in They Say It's a Delicacy
.accept 50150 >>Accept Setting the Mood
.target Witch Doctor Jangalar
step
.goto 862,64.07,35.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cala Cruzpot|r.
.accept 50074 >>Accept Brutal Boost
.target Cala Cruzpot
step
.goto 862,64.30,38.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Voodoo Love Incense|r.
.complete 50150,1 
step
.goto 862,64.04,39.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Romantic Brutosaur Meal|r.
.complete 50150,2 
.timer 15,Knockback
step
.goto 862,63.07,37.13
>>Use the |T237031:0|t[Aggression Formula] on the |cRXP_FRIENDLY_Gentle Ben'jin|r.
.complete 50074,1 
.target Gentle Ben'jin
.use 156475
step
.goto 862,64.07,35.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cala Cruzpot|r.
.turnin 50074 >>Turn in Brutal Boost
.target Cala Cruzpot
step
.goto 862,64.13,35.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jangalar|r.
.turnin 50150 >>Turn in Setting the Mood
.accept 50252 >>Accept Mating Season Halftime
.target Witch Doctor Jangalar
step
.goto 862,64.13,35.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jangalar|r.
.complete 50252,2 
.target Witch Doctor Jangalar
.skipgossipid 48272
.skipgossipid 48224
.skipgossipid 48225
step
.goto 862,64.07,35.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cala Cruzpot|r.
.complete 50252,1 
.target Cala Cruzpot
.skipgossipid 48271
.skipgossipid 48222
.skipgossipid 48223
step
.goto 862,64.13,35.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jangalar|r.
.turnin 50252 >>Turn in Mating Season Halftime
.target Witch Doctor Jangalar
step
.goto 862,64.07,35.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cala Cruzpot|r.
.accept 50268 >>Accept Give it a Little Juice
.target Cala Cruzpot
step
.goto 862,64.13,35.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Voodoo Cauldron|r.
.complete 50268,1 
step
.goto 862,64.07,35.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cala Cruzpot|r.
.turnin 50268 >>Turn in Give it a Little Juice
.accept 49870 >>Accept Size Matters
.target Cala Cruzpot
step
.goto 862,63.06,37.12
>>Use the |T237031:0|t[Voodoo'ed Aggression Formula] on the |cRXP_FRIENDLY_Tiny Sleeping Ben'jin|r.
.complete 49870,1 
.target Tiny Sleeping Ben'jin
.use 156867
step
.goto 862,64.25,41.90
>>|cRXP_WARN_Follow the arrow.|r
.complete 49870,2 
step
.goto 862,65.04,42.10
>>Kill |cRXP_ENEMY_Gloomtail|r. Loot it for |T132202:0|t[|cRXP_LOOT_Gloomtail's Head|r].
.complete 49870,3 
.mob Gloomtail
step
.goto 862,64.13,35.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jangalar|r.
.turnin 49870 >>Turn in Size Matters
.accept 50297 >>Accept The Head of Her Enemy
.target Witch Doctor Jangalar
step
.goto 862,64.19,38.94
>>|cRXP_WARN_Follow the arrow.|r
.complete 50297,1 
step
.goto 862,64.17,39.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.complete 50297,2 
.timer 15,Roleplay Duration
step
.goto 862,64.13,35.37
>>|cRXP_WARN_Wait for the roleplay.|r
.complete 50297,3 
step
.goto 1165,62.82,32.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Ata the Winglord|r.
.complete 49488,1 
.target Ata the Winglord
step
.goto 862,62.82,32.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul|r.
.turnin 49488 >>Turn in Tal'gurub
.accept 49489 >>Accept Needs a Little Body
.accept 49490 >>Accept The Urn of Voices
.target Zul
step
#completewith ZuldazarVoodooTotemEight
>>Kill the |cRXP_ENEMY_Jambani|r and |cRXP_ENEMY_Masks|r for their souls.
.complete 49490,1 
.mob Howling Voodoo Mask
.mob Jambani Spirit Twister
.mob Jambani Crusher
step
.goto 862,63.62,31.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Izita's Spirit|r.
.accept 49491 >>Accept Fuel for the Voodoo
.target Izita's Spirit
step
#title Totem (1/8) |cFFFCDC00(Read Note)|r
.goto 862,64.19,32.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,1 
step
#title Totem (2/8) |cFFFCDC00(Read Note)|r
.goto 862,64.72,32.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,2 
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 49491,1,3 
step
#title Concotion (1/2) |cFFFCDC00(Read Note)|r
.goto 862,65.03,32.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Atal'jamba Ungo|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49489,1,1 
.target Atal'jamba Ungo
step
#title Totem (3/8) |cFFFCDC00(Read Note)|r
.goto 862,64.98,32.91,-1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,3 
step
#completewith next
#label FuelForTheVoodooA
#title Totem (4/8) |cFFFCDC00(Read Note)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,4 
step
#completewith FuelForTheVoodooA
.goto 862,64.36,33.14,15,0
.goto 862,63.94,32.49,20 >>Go back across the bridge, then turn right as you get onto the stairs
step
#requires FuelForTheVoodooA
#title Totem (4/8) |cFFFCDC00(Read Note)|r
.goto 862,63.91,31.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,4 
step
#title Totem (5/8) |cFFFCDC00(Read Note)|r
.goto 862,63.74,30.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,5 
step
#title Totem (6/8) |cFFFCDC00(Read Note)|r
.goto 862,63.11,30.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,6 
step
#title Concotion (2/2) |cFFFCDC00(Read Note)|r
.goto 862,63.07,29.06,12,0
.goto 862,63.20,29.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Atal'jamba Iri|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49489,1 
.target Atal'jamba Iri
step
#title Totem (7/8) |cFFFCDC00(Read Note)|r
.goto 862,62.70,29.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,7 
step
#label ZuldazarVoodooTotemEight
#title Totem (8/8) |cFFFCDC00(Read Note)|r
.goto 862,62.88,28.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49491,1,8 
step
#loop
.goto 862,62.70,29.09,40,0
.goto 862,63.11,30.22,40,0
.goto 862,63.74,30.83,40,0
.goto 862,63.91,31.92,40,0
.goto 862,64.19,32.82,40,0
.goto 862,64.72,32.98,40,0
>>Kill the |cRXP_ENEMY_Jambani|r and |cRXP_ENEMY_Masks|r for their souls.
.complete 49490,1 
.mob Howling Voodoo Mask
.mob Jambani Spirit Twister
.mob Jambani Crusher
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_PICK_Brazier|r and |cRXP_FRIENDLY_Zul|r.
.turnin 49491 >>Turn in Fuel for the Voodoo
.goto 862,62.74,28.43
.turnin 49489 >>Turn in Needs a Little Body
.turnin 49490 >>Turn in The Urn of Voices
.accept 49492 >>Accept Arrogance of Vol'jamba
.goto 862,62.86,28.24
.target Zul
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tClick the |cRXP_PICK_Masks|r on the wall. Don't worry about their traps.
.complete 49492,1 
.goto 862,62.90,28.00
.complete 49492,2 
.goto 862,63.55,28.08
.complete 49492,3 
.goto 862,64.12,28.37
.timer 20,Zul RP
step
.goto 862,64.38,28.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tWait for |cRXP_FRIENDLY_Zul|r to walk up the stairs and talk to him.
.turnin 49492 >>Turn in Arrogance of Vol'jamba
.accept 49493 >>Accept Zul's Ethical Dilemma
.accept 49494 >>Accept Zuvembi Brew
.target Zul
step
#completewith ZuldazarJambaniStockpiles
>>Use the |T237388:0|t[Mindbreaker Chant] while standing in melee range of |cRXP_ENEMY_Mindslaved Berserkers|r and |cRXP_ENEMY_Mindslaved Gurubashi|r. Try to free multiple in one cast.
.complete 49493,1 
.mob Mindslaved Berserker
.mob Mindslaved Gurubashi
.use 155458
step
.goto 862,64.88,27.00
>>Kill |cRXP_ENEMY_Zuvembi Brewer Zekal|r.
.complete 49494,1 
.mob Zuvembi Brewer Zekal
step
#title Stockpile destroyed (1/8) |cFFFCDC00(Read Note)|r
.goto 862,65.29,28.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r twice.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.accept 51663 >>Accept Preparing for the Fall
.complete 51663,1,1 
step
#title Stockpile destroyed (2/8) |cFFFCDC00(Read Note)|r
.goto 862,65.39,27.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 51663,1,2 
step
#title Stockpile destroyed (3/8) |cFFFCDC00(Read Note)|r
.goto 862,65.00,28.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 51663,1,3 
step
#title Stockpile destroyed (4/8) |cFFFCDC00(Read Note)|r
.goto 862,64.92,28.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 51663,1,4 
step
#title Stockpile destroyed (5/8) |cFFFCDC00(Read Note)|r
.goto 862,64.66,28.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 51663,1,5 
step
#title Stockpile destroyed (6/8) |cFFFCDC00(Read Note)|r
.goto 862,64.61,29.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 51663,1,6 
step
#title Stockpile destroyed (7/8) |cFFFCDC00(Read Note)|r
.goto 862,65.02,29.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 51663,1,7 
step
#label ZuldazarJambaniStockpiles
#title Stockpile destroyed (8/8) |cFFFCDC00(Read Note)|r
.goto 862,65.59,29.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jambani Stockpile|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 51663,1 
step
#loop
.goto 862,66.35,29.55,30,0
.goto 862,66.47,28.56,30,0
.goto 862,66.07,28.57,30,0
.goto 862,64.66,28.64,30,0
.goto 862,64.61,29.82,30,0
>>Use the |T237388:0|t[Mindbreaker Chant] while standing in melee range of |cRXP_ENEMY_Mindslaved Berserkers|r and |cRXP_ENEMY_Mindslaved Gurubashi|r. Try to free multiple in one cast.
.complete 49493,1 
.mob Mindslaved Berserker
.mob Mindslaved Gurubashi
.use 155458
step
.goto 862,65.71,30.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul|r.
.turnin 49493 >>Turn in Zul's Ethical Dilemma
.turnin 49494 >>Turn in Zuvembi Brew
.turnin 51663 >>Turn in Preparing for the Fall
.accept 49495 >>Accept Enforcing Fate
.target Zul
step
.isOnQuest 49495
>>|cRXP_WARN_Make sure to accept the quest with two free bag slots. If you see this message then free up some bag space, abandon the quest and reaccept it|r.
.collect 160523,1,49495,1
.collect 160524,1,49495,1
step
.goto 862,65.89,31.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gong of Command|r.
.complete 49495,1 
step
.goto 862,65.89,30.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_shade of the urn|r.
.complete 49495,2 
.timer 6,Urn of Voices RP
step
.goto 862,65.86,30.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_shade of the urn|r again when it appears.
.complete 49495,3 
step
.goto 862,65.56,31.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_potion|r on the table.
.complete 49495,4 
step
.goto 862,65.71,30.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul|r.
.turnin 49495 >>Turn in Enforcing Fate
.accept 49905 >>Accept Plot Twist
.timer 30,Plot Twist RP
.target Zul
step
.goto 862,65.68,31.03
>>Wait for the roleplay. Attack |cRXP_ENEMY_Vol'jamba|r.
.complete 49905,1 
.mob Vol'jamba
step
.goto 862,65.68,31.03
>>Kill |cRXP_ENEMY_Vol'Jamba|r.
.complete 49905,2 
.mob Vol'jamba
step
.goto 862,65.58,30.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul|r.
.turnin 49905 >>Turn in Plot Twist
.accept 49663 >>Accept False Prophecies
.target Zul
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_PICK_Hunter's Board|r, |cRXP_FRIENDLY_Hemet Nesingwary|r, |cRXP_FRIENDLY_Erak|r, and |cRXP_FRIENDLY_Tracker Burke|r.
.accept 47706 >>Accept Hunt for King K'tal
.goto 862,67.44,17.90
.accept 50466 >>Accept He's Gone Mad!
.goto 862,67.50,17.70
.target +Hemet Nesingwary
.accept 47584 >>Accept A Thorn in the Side
.goto 862,67.45,17.72
.target +Erak
.accept 47583 >>Accept Die, Die, Diemetradon
.goto 862,67.56,17.73
.target +Tracker Burke
step
.goto 862,68.85,19.44,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the dead |cRXP_FRIENDLY_Trapper|r.
.accept 47585 >>Accept Predatory
.target Trapper Custer
step
#completewith ZuldazarWildtusk
>>Kill |cRXP_ENEMY_Venomous Diemetradon|r and |cRXP_ENEMY_Ankylodons|r.
.complete 47583,1 
.complete 47584,1 
.mob Venomous Diemetradon
.mob Ankylodons
step
#completewith next
.line 862,71.69,20.36,71.40,20.93,71.33,21.89,71.50,22.41,70.84,22.62,70.14,22.88,68.99,22.64,68.26,21.95,67.98,22.04,67.93,22.32,68.10,22.90,68.25,22.74,68.42,23.03,69.76,22.59,70.84,22.62
>>Kill |cRXP_ENEMY_King K'tal|r. Loot him for his [|cRXP_LOOT_skull|r]. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.
.complete 47706,1 
.isOnQuest 47706
.mob King K'tal
step
.goto 862,70.63,22.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Ranger Paalu|r.
.complete 47585,1 
.target Ranger Paalu
step
#label ZuldazarWildtusk
.goto 862,70.94,26.26
>>Kill the |cRXP_ENEMY_Wildtusk|r.
.complete 50466,1 
.mob Wildtusk
step
#completewith next
>>Kill |cRXP_ENEMY_Venomous Diemetradon|r.
.complete 47583,1 
.mob Venomous Diemetradon
step
.goto 862,67.81,25.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Marksman Julyen|r on the ground.
.complete 47585,2 
.target Marksman Julyen
step
#loop
.goto 862,68.00,26.14,40,0
.goto 862,68.86,25.70,40,0
.goto 862,68.80,25.22,40,0
.goto 862,68.41,25.03,40,0
.goto 862,68.56,24.19,40,0
.goto 862,67.78,24.33,40,0
.goto 862,67.41,24.86,40,0
.goto 862,68.00,26.14,40,0
>>Kill |cRXP_ENEMY_Venomous Diemetradon|r.
.complete 47583,1 
.mob Venomous Diemetradon
step
#completewith next
.line 862,71.69,20.36,71.40,20.93,71.33,21.89,71.50,22.41,70.84,22.62,70.14,22.88,68.99,22.64,68.26,21.95,67.98,22.04,67.93,22.32,68.10,22.90,68.25,22.74,68.42,23.03,69.76,22.59,70.84,22.62
>>Kill |cRXP_ENEMY_King K'tal|r. Loot him for his [|cRXP_LOOT_skull|r]. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.
.complete 47706,1 
.isOnQuest 47706
.mob King K'tal
step
#loop
.goto 862,67.81,22.89,45,0
.goto 862,68.74,21.43,45,0
.goto 862,68.63,20.44,45,0
.goto 862,67.66,20.12,45,0
.goto 862,68.26,18.54,45,0
.goto 862,69.11,18.71,45,0
>>Kill |cRXP_ENEMY_Ankylodons|r.
.complete 47584,1 
.mob Ankylodon
step
#completewith ZuldazarNesingwarysTrekTurnins
#loop
.goto 862,67.81,23.37,40,0
.goto 862,71.39,21.48,40,0
.goto 862,67.81,23.37,40,0
>>Kill |cRXP_ENEMY_King K'tal|r. Loot him for his [|cRXP_LOOT_skull|r]. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.
.complete 47706,1 
.isOnQuest 47706
.mob King K'tal
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_PICK_Tracker Burke's Hat|r, |cRXP_FRIENDLY_Erak|r, and |cRXP_FRIENDLY_Huntmaster Vol'ka|r.
.turnin 47583 >>Turn in Die, Die, Diemetradon
.goto 862,67.50,18.89
.turnin 47584 >>Turn in A Thorn in the Side
.goto 862,68.01,18.03
.turnin 47585 >>Turn in Predatory
.turnin 47706 >>Turn in Hunt for King K'tal
.turnin 50466 >>Turn in He's Gone Mad!
.accept 47586 >>Accept Hunting the Hunter
.goto 862,67.50,17.62
.isQuestComplete 47706
.target Erak
.target Huntmaster Vol'ka
step
#label ZuldazarNesingwarysTrekTurnins
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to Nesingwary's Trek. Talk to |cRXP_PICK_Tracker Burke's Hat|r, |cRXP_FRIENDLY_Erak|r, and |cRXP_FRIENDLY_Huntmaster Vol'ka|r.
.turnin 47583 >>Turn in Die, Die, Diemetradon
.goto 862,67.50,18.89
.turnin 47584 >>Turn in A Thorn in the Side
.goto 862,68.01,18.03
.turnin 50466 >>Turn in He's Gone Mad!
.turnin 47585 >>Turn in Predatory
.accept 47586 >>Accept Hunting the Hunter
.goto 862,67.50,17.62
.target Erak
.target Huntmaster Vol'ka
step
.abandon 47706 >> Abandon Hunt for King K'tal
step
#completewith ZuldazarFollowNesingwary
>>Kill |cRXP_ENEMY_Feathered Vipers|r, their |cRXP_ENEMY_Eggs|r, and |cRXP_ENEMY_Wild Sabertusks|r.
.complete 50178,1 
.mob Feathered Viper
.mob Feathered Viper Egg
.mob Wild Sabertusk
step
.goto 862,62.45,19.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Nesingwary's Campfire|r on the ground.
.complete 47586,1 
step
.goto 862,61.48,17.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dwarf Trap|r on the ground.
.complete 47586,2 
step
#label ZuldazarFollowNesingwary
.goto 862,62.32,16.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nesingwary's Rifle|r on the ground.
.complete 47586,3 
step
#loop
.goto 862,62.76,17.45,40,0
.goto 862,62.88,17.04,40,0
.goto 862,64.01,19.36,40,0
.goto 862,64.14,17.29,40,0
.goto 862,65.83,17.90,40,0
.goto 862,65.17,20.05,40,0
>>Kill |cRXP_ENEMY_Feathered Vipers|r, their |cRXP_ENEMY_Eggs|r, and |cRXP_ENEMY_Wild Sabertusks|r.
.complete 50178,1 
.mob Feathered Viper
.mob Feathered Viper Egg
.mob Wild Sabertusk
step
.goto 862,63.49,16.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r inside the building.
.turnin 47586 >>Turn in Hunting the Hunter
.accept 47587 >>Accept Headhunter Jo
.target Hemet Nesingwary
step
.goto 862,62.96,15.81
>>Kill |cRXP_ENEMY_Headhunter Jo|r.
.complete 47587,1 
.mob Headhunter Jo
step
.goto 862,63.49,16.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r.
.turnin 47587 >>Turn in Headhunter Jo
.target Hemet Nesingwary
step
.goto 862,47.32,25.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beastmother Jabati|r.
.accept 49679 >>Accept The Sethrak Incursion
.target Beastmother Jabati
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bladeguard Sonji|r.
.goto 862,47.25,24.95
.accept 49678 >>Accept I Spy a Spire
.accept 49680 >>Accept Skycaller Soltok
.target Bladeguard Sonji
step
#completewith SkycallerSoltokA
>>Kill the |cRXP_ENEMY_Sethrak|r and the |cRXP_ENEMY_Krolusk|r in the area.
.complete 49679,1 
.mob Sethrak Invader
.mob Sethrak Skycaller
.mob Krolusk Warcrawler
step
.goto 862,46.20,23.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lil'Tika|r.
.accept 49681 >>Accept Lil' Tika
.target Lil'Tika
step
.goto 862,46.20,23.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sethrak Cage|r.
.complete 49681,1 
step
#title Spire destroyed (1/4) |cFFFCDC00(Read Note)|r
.goto 862,46.00,22.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sethrak Spire|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49678,1,1 
step
#title Spire destroyed (2/4) |cFFFCDC00(Read Note)|r
.goto 862,45.62,23.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sethrak Spire|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49678,1,2 
step
#title Spire destroyed (3/4) |cFFFCDC00(Read Note)|r
.goto 862,45.11,24.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sethrak Spire|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49678,1,3 
step
#title Spire destroyed (4/4) |cFFFCDC00(Read Note)|r
.goto 862,44.34,24.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sethrak Spire|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49678,1 
step
.goto 862,45.37,26.40
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Chief Chan'tika|r.
.complete 49681,2 
step
#label SkycallerSoltokA
.goto 862,45.19,25.95,10,0
.goto 862,45.05,26.14,5,0
.goto 862,45.31,26.25
>>Kill |cRXP_ENEMY_Skycaller Soltok|r on the second floor.
.complete 49680,1 
.mob Skycaller Soltok
step
#loop
>>Kill the |cRXP_ENEMY_Sethrak|r and the |cRXP_ENEMY_Krolusk|r in the area.
.complete 49679,1 
.mob Sethrak Invader
.mob Sethrak Skycaller
.mob Krolusk Warcrawler
step
.goto 862,47.25,24.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bladeguard Sonji|r.
.turnin 49678 >>Turn in I Spy a Spire
.turnin 49680 >>Turn in Skycaller Soltok
.target Bladeguard Sonji
step
.goto 862,47.33,25.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beastmother Jabati|r.
.turnin 49679 >>Turn in The Sethrak Incursion
.turnin 49681 >>Turn in Lil' Tika
.target Beastmother Jabati
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan|r and |cRXP_FRIENDLY_Zolani|r.
.turnin 49663 >>Turn in False Prophecies
.goto 1165,49.93,46.62
.target +King Rastakhan
.accept 50835 >>Accept The Port of Zandalar
.goto 1165,49.82,46.55
.target +Zolani
.accept 47445 >>Accept The Zanchuli Council
.goto 1165,49.73,46.51
.target +Yazma
step
.goto 1165,45.26,24.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wardruid Loti|r.
.turnin 47445 >>Turn in The Zanchuli Council
.accept 47423 >>Accept Forbidden Practices
.target Wardruid Loti
step
#loop
.goto 1165,47.30,21.67,30,0
.goto 1165,48.09,20.82,30,0
.goto 1165,48.92,18.10,30,0
.goto 1165,49.84,17.92,30,0
.goto 1165,50.31,15.00,30,0
.goto 1165,50.40,13.00,30,0
.goto 1165,50.65,10.74,30,0
.goto 1165,51.65,10.35,30,0
.goto 1165,47.30,21.67,30,0
>>Use |T136008:0|t[Loti's Totem] near |cRXP_ENEMY_Zanchuli Acolytes|r to reveal them.
.complete 47423,1 
.target Zanchuli Acolyte
.use 152627
step
.goto 1165,51.90,11.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hexlord Raal|r.
.turnin 47423 >>Turn in Forbidden Practices
.target Hexlord Raal
step
.goto 1165,40.28,19.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nokano|r.
.accept 47441 >>Accept Pests
.target Nokano
step
.goto 1165,37.93,18.95
>>Kill |cRXP_ENEMY_Thieving Snapper|r.
.complete 47441,1 
.mob Thieving Snapper
step
.goto 1165,35.35,7.67
>>|cRXP_WARN_Follow the arrow.|r
.complete 47441,2 
step
.goto 1165,35.35,7.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jani|r.
.turnin 47441 >>Turn in Pests
.accept 47442 >>Accept Curse of Jani
.target Jani
step
#title Use Sprint when reaching the first guard
.goto 1165,38.81,17.80
.complete 47442,1 
step
.goto 1165,40.11,19.22
>>Attack |cRXP_ENEMY_Nokano|r.
.complete 47442,2 
.mob Nokano
step
.goto 1165,35.46,7.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jani|r.
.turnin 47442 >>Turn in Curse of Jani
.target Jani
step
.goto 862,51.62,45.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_WANTED board|r.
.accept 51071 >>Accept WANTED: Sabertusk Empress
.accept 51072 >>Accept WANTED: Prime Thumpknuckle
step
.goto 862,52.69,45.05
>>Kill a |cRXP_ENEMY_Prime Thumpknuckle|r.
>>|cRXP_WARN_SEMI HARD elite, skip if too hard|r.
.complete 51072,1 
.mob Prime Thumpknuckle
step
.goto 862,52.36,47.76
>>Kill a |cRXP_ENEMY_Sabertusk Empress|r.
>>|cRXP_WARN_VERY HARD elite, only try it if you know what to do and/or are using heirlooms|r.
*Even with heirlooms this elite can be very difficult depending on your class
.complete 51071,1 
.mob Sabertusk Empress
step
.isOnQuest 51071
.isQuestComplete 51071
.goto 862,51.65,50.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shaz'ki|r.
.turnin 51071 >>Turn in WANTED: Sabertusk Empress
.target Shaz'ki
step
.isOnQuest 51072
.isQuestComplete 51072
.goto 862,51.65,50.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shaz'ki|r.
.turnin 51072 >>Turn in WANTED: Prime Thumpknuckle
.target Shaz'ki
step
.abandon 51071 >>Abandon WANTED: Sabertusk Empress
.abandon 51072 >>Abandon WANTED: Prime Thumpknuckle
step
.goto 862,51.61,50.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bently Greaseflare|r.
.accept 49919 >>Accept Kaja'mite Ore Bust
.accept 49922 >>Accept King Da'ka
.target Bently Greaseflare
step
#label ZuldazarGorillaGorge
#completewith ZuldazarPeaceLovingGorillas
>>Kill |cRXP_ENEMY_Gorillas|r in the area.
.accept 49918 >>Accept Gorilla Gorge (Bonus Objective)
.complete 49918,1 
.mob Da'kani Pugilist
.mob Da'kani Highbrow
.mob Zayoos
.mob King Da'ka
step
#title Vent scanned (1/5) |cFFFCDC00(Read Note)|r
.goto 862,50.37,55.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kaja'mite Steam Vent|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49919,1,1 
step
.goto 862,50.17,54.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tsunga|r.
.accept 49920 >>Accept Gorilla Warfare
.target Tsunga
step
#completewith ZuldazarDakaniGorillas
.aura 269783,1+ >>Pick up a |cRXP_PICK_Kaja'mite Chunk|r for a damage buff.
step
#title Gorilla released (1/6) |cFFFCDC00(Read Note)|r
.goto 862,49.95,54.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49920,1,1 
step
#title Vent scanned (2/5) |cFFFCDC00(Read Note)|r
.goto 862,49.51,54.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kaja'mite Steam Vent|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49919,1,2 
step
#title Gorilla released (2/6) |cFFFCDC00(Read Note)|r
.goto 862,49.56,55.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49920,1,2 
step
#title Vent scanned (3/5) |cFFFCDC00(Read Note)|r
.goto 862,49.07,55.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kaja'mite Steam Vent|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49919,1,3 
step
#title Gorilla released (3/6) |cFFFCDC00(Read Note)|r
.goto 862,48.84,55.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49920,1,3 
step
#title Gorilla released (4/6) |cFFFCDC00(Read Note)|r
.goto 862,49.03,54.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49920,1,4 
step
#title Vent scanned (4/5) |cFFFCDC00(Read Note)|r
.goto 862,48.16,54.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kaja'mite Steam Vent|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49919,1,4 
step
#title Gorilla released (5/6) |cFFFCDC00(Read Note)|r
.goto 862,48.63,53.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49920,1,5 
step
#title Gorilla released (6/6) |cFFFCDC00(Read Note)|r
#label ZuldazarPeaceLovingGorillas
.goto 862,48.14,53.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49920,1 
step
#title Vent scanned (5/5) |cFFFCDC00(Read Note)|r
.goto 862,48.02,52.70
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kaja'mite Steam Vent|r.
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
.complete 49919,1 
step
#completewith next
#label KingDakaSlain
.goto 862,46.74,50.54,0,0
>>Kill |cRXP_ENEMY_King Da'ka|r.
.complete 49922,1 
.mob King Da'ka
step
#completewith KingDakaSlain
#title Enter Cave
.goto 862,47.10,51.52,10 >>Enter the cave
step
#requires KingDakaSlain
.goto 862,46.74,50.54
>>Kill |cRXP_ENEMY_King Da'ka|r.
.complete 49922,1 
.mob King Da'ka
step
.isQuestComplete 49920
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tsunga|r.
.goto 862,47.42,52.43
.turnin 49920 >>Turn in Gorilla Warfare
.target Tsunga
step
#label ZuldazarDakaniGorillas
>>Kill |cRXP_ENEMY_Gorillas|r in the area.
.waypoint 862,48.93,54.52,-25,0
.complete 49918,1 
.mob Da'kani Pugilist
.mob Da'kani Highbrow
.mob Zayoos
.mob King Da'ka
step
.goto 862,51.60,50.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bently Greaseflare|r.
.turnin 49919 >>Turn in Kaja'mite Ore Bust
.turnin 49922 >>Turn in King Da'ka
.target Bently Greaseflare
step
#label ZuldazarPortofZuldazar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zolani|r and |cRXP_FRIENDLY_Yazma|r.
.turnin 50835 >>Turn in The Port of Zandalar
.accept 46926 >>Accept Shakedown
.goto 1165,50.06,85.07
.accept 46846 >>Accept The Word of Zul
.goto 1165,50.05,84.76
.target Zolani
.target Yazma
step
#completewith ZuldazarDocksideThugs
>>Kill |cRXP_ENEMY_Gurubashi|r, |cRXP_ENEMY_Amani|r, and |cRXP_ENEMY_Sandfury Thugs|r.
.complete 46926,1 
.mob Gurubashi Thug
.mob Amani Thug
.mob Sandfury Thug
step
.goto 1165,51.52,91.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nokali|r. |cRXP_WARN_Do NOT go downstairs|r.
.complete 46846,1 
.target Nokali
.skipgossip
step
#completewith next
.goto 1165,53.48,90.62,20 >> Jump down through the gap in the wall
step
.goto 1165,53.89,91.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Volkini|r.
.complete 46846,2 
.target Volkini
.skipgossip
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dockmaster Cobo|r.
.goto 1165,45.31,79.78
.complete 46846,3 
.target Dockmaster Cobo
.skipgossip
step
#label ZuldazarDocksideThugs
.goto 1165,44.25,82.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jala|r.
.accept 48452 >>Accept The Red Market
.target Witch Doctor Jala
step
#completewith next
>>Kill |cRXP_ENEMY_Crimson Cultists|r. Loot them for their |T458256:0|t[|cRXP_LOOT_Dark Fetishes|r].
.complete 48452,1 
.mob Crimson Cultist
step
.goto 1165,42.76,83.64,12,0
.goto 1165,43.13,83.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chalice of Calling|r.
.complete 48452,2 
step
#loop
.goto 1165,41.82,82.83,30,0
.goto 1165,41.67,77.10,30,0
.goto 1165,43.13,83.07,30,0
>>Kill |cRXP_ENEMY_Crimson Cultists|r. Loot them for their |T458256:0|t[|cRXP_LOOT_Dark Fetishes|r].
.complete 48452,1 
.mob Crimson Cultist
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Jala|r.
.goto 1165,44.25,82.15
.turnin 48452 >>Turn in The Red Market
.accept 48454 >>Accept Evidence of Evil
.target Witch Doctor Jala
step
#loop
.goto 1165,45.31,80.04,40,0
.goto 1165,47.52,87.26,30,0
.goto 1165,46.97,89.89,30,0
.goto 1165,48.45,83.77,30,0
.goto 1165,45.31,80.04,35,0
>>Kill |cRXP_ENEMY_Gurubashi|r, |cRXP_ENEMY_Amani|r, and |cRXP_ENEMY_Sandfury Thugs|r.
.complete 46926,1 
.mob Gurubashi Thug
.mob Amani Thug
.mob Sandfury Thug
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zolani|r and |cRXP_FRIENDLY_Yazma|r.
.turnin 46926 >>Turn in Shakedown
.turnin 48454 >>Turn in Evidence of Evil
.goto 1165,50.06,85.07
.target +Zolani
.turnin 46846 >>Turn in The Word of Zul
.accept 46928 >>Accept Punishment of Tal'farrak
.goto 1165,50.05,84.76
.target +Yazma
step
#completewith next
#label PunishmentOfTalfarrakA
>>Kill |cRXP_ENEMY_Gahz'ragon|r. Loot him for the |T237348:0|t[|cRXP_LOOT_Tongue of Gahz'ragon|r].
.complete 46928,1 
.mob Gahz'ragon
step
#completewith PunishmentOfTalfarrakA
.goto 1165,46.61,73.87
.cast 3365 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Gong|r to summon |cRXP_ENEMY_Gahz'ragon|r
step
#requires PunishmentOfTalfarrakA
#label GahzRagonA
.goto 1165,46.63,72.61
>>Kill |cRXP_ENEMY_Gahz'ragon|r. Loot him for the |T237348:0|t[|cRXP_LOOT_Tongue of Gahz'ragon|r].
.complete 46928,1 
.mob Gahz'ragon
step
#loop
.goto 1165,46.61,70.64,40,0
.goto 1165,47.71,72.37,40,0
.goto 1165,45.82,77.73,40,0
.goto 1165,48.39,77.83,40,0
>>Kill |cRXP_ENEMY_Sandfury Trolls|r. Loot them for the |T134178:0|t[|cRXP_LOOT_Sandfury Heads|r].
.complete 46929,2 
.mob Sandfury Axe Thrower
.mob Sandfury Axe Dunerider
.mob Sandfury Axe Speaker
step
#loop
.goto 1165,51.74,77.65,40,0
.goto 1165,54.22,79.81,40,0
.goto 1165,57.31,80.80,40,0
>>Kill |cRXP_ENEMY_Amani Trolls|r. Loot them for the |T134177:0|t[|cRXP_LOOT_Amani Heads|r].
.complete 46929,1 
.mob Amani Warrior
step
.goto 1165,50.05,84.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yazma|r and |cRXP_FRIENDLY_Zolani|r.
.turnin 46928 >>Turn in Punishment of Tal'farrak
.target +Yazma
.turnin 46929 >>Turn in Deterrent
.goto 1165,50.05,85.08
.target +Zolani
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Koba|r and |cRXP_FRIENDLY_Batu|r.
.accept 49285 >>Accept Tiny Treasures
.goto 862,70.27,65.02
.target +Koba
.accept 49284 >>Accept Perfect Tidings
.goto 862,70.28,64.95
.target +Batu
step
#completewith ClueThree
>>Kill |cRXP_ENEMY_Murlocs|r and run on top of |cRXP_FRIENDLY_Tadpoles|r to scare them.
.complete 49315,1 
step
.goto 862,71.19,64.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_bag|r.
.complete 49284,1 
step
.goto 862,71.66,64.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_cage|r.
.complete 49285,1 
step
.goto 862,72.65,63.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_scroll|r.
.complete 49284,2 
step
.goto 862,73.10,64.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Spitzy|r.
.complete 49285,3 
step
.goto 862,73.19,67.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Alchemist Stone|r.
.complete 49285,2 
step
#label ClueThree
.goto 862,74.02,62.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll Case|r.
.complete 49284,3 
step
.goto 862,73.68,60.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Choa|r and |cRXP_FRIENDLY_Deyon|r.
.turnin 49285 >>Turn in Tiny Treasures
.target +Choa
.turnin 49284 >>Turn in Perfect Tidings
.accept 49286 >>Accept Caged Wisdom
.target +Deyon
step
.goto 862,73.66,60.49,20,0
.goto 862,74.60,59.34
>>Go inside the cave. Kill |cRXP_ENEMY_Sli'thrus|r. Loot him for the |T134241:0|t[|cRXP_LOOT_Nazeshi Cage Key|r].
.complete 49286,1 
.mob Sli'thrus
step
.goto 862,73.68,60.99
>>|TInterface/GossipFrame/HealerGossipIcon:0|tClick the |cRXP_PICK_cage|r, then talk to |cRXP_FRIENDLY_Deyon|r.
.complete 49286,2 
.turnin 49286 >>Turn in Caged Wisdom
.accept 49287 >>Accept Lost Chelonians
.accept 49288 >>Accept Scrollhunters
.target Deyon
step
#completewith ZuldazarLostChelonians
>>Kill |cRXP_ENEMY_Murlocs|r and |cRXP_ENEMY_Nagas|r.
*Run on top of |cRXP_FRIENDLY_Tadpoles|r to scare them.
.complete 49315,1 
step
#completewith ZuldazarLostChelonians
>>Kill |cRXP_ENEMY_Nazeshi Tempest-Wielders|r. Loot them for the |T1500861:0|t[|cRXP_LOOT_Tortollan Scrolls|r].
.complete 49288,1 
.mob Nazeshi Tempest-Wielder
step
.goto 862,73.90,65.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 49287,1 
.target Kono
step
.goto 862,75.13,66.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 49287,2 
.target Rauloo
step
.goto 862,77.05,66.48
>>|TInterface/GossipFrame/HealerGossipIcon:0|tClick the |cRXP_PICK_cages|r to free |cRXP_FRIENDLY_Akru|r.
.complete 49287,3 
.target Akru
step
#label ZuldazarLostChelonians
.goto 862,77.29,64.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_DO NOT PULL Tidecaller Nezara, she is level 60|r.
.complete 49287,4 
.target Crosh
step
#completewith CleanseTheDreadpearlShallowsA
#hidewindow
#loop
.goto 862,76.66,65.67,35,0
.goto 862,76.66,64.88,35,0
.goto 862,77.29,64.36,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Murlocs|r and |cRXP_ENEMY_Nagas|r.
*Run on top of |cRXP_FRIENDLY_Tadpoles|r to scare them.
.complete 49315,1 
step
>>Kill |cRXP_ENEMY_Nazeshi Tempest-Wielders|r. Loot them for the |T1500861:0|t[|cRXP_LOOT_Tortollan Scrolls|r].
.complete 49288,1 
.mob Nazeshi Tempest-Wielder
step
#label CleanseTheDreadpearlShallowsA
>>Kill |cRXP_ENEMY_Murlocs|r and |cRXP_ENEMY_Nagas|r.
*Run on top of |cRXP_FRIENDLY_Tadpoles|r to scare them.
.complete 49315,1 
step
.goto 862,75.22,61.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deyon|r.
.turnin 49287 >>Turn in Lost Chelonians
.turnin 49288 >>Turn in Scrollhunters
.accept 49289 >>Accept A Special Stone
.target Deyon
step
.goto 862,76.67,61.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone Fragment|r.
>>Kill |cRXP_ENEMY_Tidemistress Nazesh|r. Loot her for the |T1392955:0|t[|cRXP_LOOT_Orders from Nazjatar|r].
*You can use the |cRXP_PICK_Scroll of Storm Control|r for an extra ability.
.complete 49289,2 
.complete 49289,1 
.mob Tidemistress Nazesh
.use 157539
step
.goto 862,75.22,61.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deyon|r. Wait out the RP event.
.turnin 49289 >>Turn in A Special Stone
.timer 10,Roleplay Duration
.target Deyon
step
.goto 862,75.22,61.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tWait for the RP. Talk to |cRXP_FRIENDLY_Deyon|r again.
.accept 51407 >>Accept Find Their Words
.target Deyon
step
.goto 862,70.53,64.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akru|r.
.turnin 51407 >>Turn in Find Their Words
.accept 50331 >>Accept A Different Outcome
.target Akru
step
.goto 862,81.35,45.77
>>|cRXP_WARN_Fly to the waypoint location.|r
.complete 50331,1 
step
.goto 862,81.35,45.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rokor|r.
.turnin 50331 >>Turn in A Different Outcome
.accept 48015 >>Accept The Scrolls of Gral
.accept 48014 >>Accept Clear the Riffraff
.target Rokor
step
#completewith TheScrollsOfGralA
>>Kill |cRXP_ENEMY_Brackfin Scavenger|r.
.complete 48014,1 
.mob Brackfin Scavenger
step
.goto 862,80.52,45.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.complete 48015,1 
step
.goto 862,80.77,43.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.complete 48015,3 
step
#label TheScrollsOfGralA
.goto 862,79.98,44.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.complete 48015,2 
step
#loop
.goto 862,80.52,45.00,30,0
.goto 862,80.77,43.28,30,0
.goto 862,79.98,44.43,30,0
>>Kill |cRXP_ENEMY_Brackfin Scavenger|r.
.complete 48014,1 
.mob Brackfin Scavenger
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trader Kro|r and |cRXP_FRIENDLY_Scrollsage Goji|r.
.turnin 48014 >>Turn in Clear the Riffraff
.goto 862,79.22,42.29
.target +Trader Kro
.turnin 48015 >>Turn in The Scrolls of Gral
.accept 48025 >>Accept Saving for Later
.goto 862,79.20,42.10
.target +Scrollsage Goji
.goto 862,79.22,42.29
.accept 49969 >>Accept Awaken a God
.target +Trader Kro
step
#completewith SavingForLaterA
>>Kill the |cRXP_ENEMY_Naga|r. Loot them for the |T1:0|t[|cRXP_LOOT_Chunks of Naga Flesh|r].
.complete 49969,1 
.mob Dreadcoil Seeker
.mob Dreadcoil Myrmidon
step
.goto 862,81.75,41.21
>>Use the |T1103069:0|t[Scroll of Illusion].
.complete 48025,4 
.use 151859
step
.goto 862,83.52,39.95
>>Use the |T1103069:0|t[Scroll of Illusion].
.complete 48025,5 
.use 151859
step
.goto 862,81.38,39.00
>>Use the |T1103069:0|t[Scroll of Illusion].
.complete 48025,3 
.use 151859
step
.goto 862,79.66,36.72
>>Use the |T1103069:0|t[Scroll of Illusion].
.complete 48025,2 
.use 151859
step
#label SavingForLaterA
.goto 862,78.30,37.07
>>Use the |T1103069:0|t[Scroll of Illusion].
.complete 48025,1 
.use 151859
step
#loop
.goto 862,81.00,41.97,35,0
.goto 862,83.36,38.47,35,0
.goto 862,78.37,37.19,35,0
>>Kill the |cRXP_ENEMY_Naga|r. Loot them for the |T1:0|t[|cRXP_LOOT_Chunks of Naga Flesh|r].
.complete 49969,1 
.mob Dreadcoil Seeker
.mob Dreadcoil Myrmidon
step
.goto 862,82.76,42.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Offering Vessel|r.
.turnin 49969 >>Turn in Awaken a God
.target Offering Vessel
step
.goto 862,82.76,42.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shrine of Gral|r.
.accept 48026 >>Accept Beneath the Waves
.target Shrine of Gral
step
.goto 862,83.62,44.34
>>Kill |cRXP_ENEMY_Whispering Horror|r and |cRXP_ENEMY_Summoner Siavass|r.
.complete 48026,2 
.complete 48026,1 
.mob Whispering Horror
.mob Summoner Siavass
step
.goto 862,83.61,44.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spirit of Gral|r.
.turnin 48026 >>Turn in Beneath the Waves
.accept 51538 >>Accept Word from the Deep
.target Spirit of Gral
step
#label BattleForAzerothHordeEnd
.goto 862,79.20,42.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollsage Goji|r.
.turnin 48025 >>Turn in Saving for Later
.turnin 51538 >>Turn in Word from the Deep
.accept 51539 >>Accept Inform the Horde!
.target Scrollsage Goji
step
.goto 1164,41.19,72.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baine Bloodhoof|r.
.turnin 51539 >>Turn in Inform the Horde!
.target Baine Bloodhoof
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Draenor Scenario
#internal
<< Horde
step
#completewith DraenorScenarioHordeEnd
#hidewindow
+1
.usespell 1231411
step
.zoneskip 85
.use 140192
.zone 627 >>Use Dalaran Hearthstone
step
.goto 627,55.28,23.95
.zone 85 >>Take the portal to Orgrimmar
step
.isNotOnQuest 34398
.goto 85,40.82,80.13
.cast 325534 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r to activate the |cRXP_PICK_Draenor|r timeline.
.chromietime 9
.skipgossipid 51901
.skipgossipid 51902
.target Chromie
step
>>Don't question it, just do it!
.abandon 34398 >>Abandon Warlords of Draenor: The Dark Portal
step
#completewith next
#label AcceptTheDarkPortal
.goto 17,54.93,50.26,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.accept 36881 >>Accept Warlords of Draenor: The Dark Portal
.target Archmage Khadgar
step
#completewith AcceptTheDarkPortal
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_WARN_Follow the arrow|r. Talk to the |cRXP_FRIENDLY_Thrallmar Mage|r downstairs.
.goto 85,54.81,89.85,8,0
.goto 85,54.64,87.10,8,0
.goto 85,56.03,86.99,8,0
.goto 85,57.14,90.69
.skipgossip 1
.zone 17 >>Travel to the Blasted Lands
.target Thrallmar Mage
step
#requires AcceptTheDarkPortal
.goto 17,54.93,50.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.accept 36881 >>Accept Warlords of Draenor: The Dark Portal
.target Archmage Khadgar
step
.goto 17,54.93,50.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r |cRXP_WARN_and accept the popup|r.
.complete 36881,1 
.target Archmage Khadgar
step
.goto 577,54.79,48.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.target Archmage Khadgar
.turnin 34398 >>Turn in Warlords of Draenor: The Dark Portal
.accept 35933 >>Accept Azeroth's Last Stand
step
.goto 577,52.76,43.25
>>Kill an |cRXP_ENEMY_Iron Grunt|r. Loot him for the |T133469:0|t[Iron Horde Missive].
.complete 35933,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under the minimap.
.turnin 35933 >>Turn in Azeroth's Last Stand
.accept 34392 >>Accept Onslaught's End
step
.goto 577,51.03,42.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fel Spire|r.
.complete 34392,1 
step
.goto 577,51.26,54.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fel Spire|r.
.complete 34392,2 
step
.goto 577,52.98,48.30,30,0
.goto 577,54.70,48.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34392 >>Turn in Onslaught's End
.accept 34393 >>Accept The Portal's Power
.target Archmage Khadgar
step
.goto 577,54.92,45.03,8,0
.goto 577,54.93,46.13
#title |cFFFCDC00Follow the Arrow|r
.complete 34393,1 
step
.goto 577,56.02,46.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mark of the Burning Blade|r.
.complete 34393,2 
step
.goto 577,57.26,48.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mark of the Shattered Hand|r.
.complete 34393,3 
step
.goto 577,56.07,50.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mark of the Blackrock|r.
.complete 34393,4 
step
.goto 577,55.99,48.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stasis Rune|r on the ground.
.complete 34393,5 
step
#completewith next
#label PortalsPower
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.goto 577,56.82,45.84,0,0
.turnin 34393 >>Turn in The Portal's Power
.accept 34420 >>Accept The Cost of War
.target Archmage Khadgar
step
#completewith PortalsPower
#title Leave Prison
.goto 577,54.94,45.20,8 >>Leave the Prison
step
#requires PortalsPower
.goto 577,56.82,45.84,8,0
.goto 577,54.76,48.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34393 >>Turn in The Portal's Power
.accept 34420 >>Accept The Cost of War
.target Archmage Khadgar
step
.itemcount 132516,1
#completewith BlastedLandsTheDarkPortal
.cooldown item,132516,>0,1
.cast 202844 >>Use |T1405809:0|t[Gunshoes]
step
.goto 577,60.26,56.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34420 >>Turn in The Cost of War
.accept 34422 >>Accept Blaze of Glory
.target Archmage Khadgar
step
.goto 577,62.26,52.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ashka|r and |cRXP_FRIENDLY_Korag|r.
.accept 35241 >>Accept Vengeance for the Fallen
.target +Ashka
.accept 34421 >>Accept Bled Dry
.target +Korag
step
#completewith BledDry
>>Kill |cRXP_ENEMY_Bleeding Hollow Orcs|r on the side.
.goto 577,63.57,64.18,0,0
.complete 35241,1 
.mob Bleeding Hollow Savage
.mob Bleeding Hollow Berserker
.mob Bleeding Hollow Hatchet
step
.goto 577,63.61,50.07
>>Use the |T132839:0|t[Lucifrium Bead] to burn 3 |cRXP_PICK_Bleeding Hollow huts|r.
.complete 34422,1,3 
.use 113191
step
.goto 577,65.74,54.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bleeding Hollow Cage|r.
.complete 34421,1 
step
.goto 577,66.49,56.09
>>Use the |T132839:0|t[Lucifrium Bead] to burn 2 |cRXP_PICK_Bleeding Hollow huts|r.
.complete 34422,1,5 
.use 113191
step
#completewith next
.goto 577,61.02,62.77,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bleeding Hollow Cage|r.
.complete 34421,2 
step
.goto 577,61.43,61.97,0,0
>>Use the |T132839:0|t[Lucifrium Bead] to burn the missing |cRXP_PICK_Bleeding Hollow huts|r.
.complete 34422,1 
.use 113191
step
#label BledDry
.goto 577,61.02,62.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bleeding Hollow Cage|r.
.complete 34421,2 
step
#loop
.goto 577,65.80,69.32,35,0
.goto 577,61.02,62.77,35,0
.goto 577,66.49,56.09,35,0
.goto 577,63.61,50.07,35,0
.goto 577,61.02,62.77,35,0
>>Kill |cRXP_ENEMY_Bleeding Hollow Orcs|r on the side.
.complete 35241,1 
.mob Bleeding Hollow Savage
.mob Bleeding Hollow Berserker
.mob Bleeding Hollow Hatchet
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r and |cRXP_FRIENDLY_Archmage Khadgar|r after a short roleplay.
.turnin 35241 >>Turn in Vengeance for the Fallen
.goto 577,71.94,62.08
.target +Thrall
.turnin 34422 >>Turn in Blaze of Glory
.turnin 34421 >>Turn in Bled Dry
.accept 34423 >>Accept Altar Altercation
.goto 577,71.54,62.38
.target +Archmage Khadgar
step
.goto 577,71.99,62.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ariok|r.
.complete 34423,1 
.target Ariok
.skipgossipid 43152
step
.goto 577,76.98,58.04
#title |cFFFCDC00Follow the Arrow|r
.complete 34423,2 
step
#completewith next
#label BloodRitualOrbDestroyedA
.goto 577,79.22,57.04,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blood Ritual Orb|r.
.complete 34423,3,1 
step
#completewith BloodRitualOrbDestroyedA
#title Go up the stairs
.goto 577,79.22,57.04,8 >>Go up the stairs
step
#requires BloodRitualOrbDestroyedA
.goto 577,79.22,57.04,8,0
.goto 577,78.64,53.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blood Ritual Orb|r.
.complete 34423,3,1 
step
.goto 577,78.19,53.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blood Ritual Orb|r.
.complete 34423,3,2 
step
.goto 577,76.68,53.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blood Ritual Orb|r.
.complete 34423,3 
step
.goto 577,72.02,41.90
>>|cRXP_WARN_Cross the bridge|r.
.complete 34423,4 
step
.goto 577,71.95,40.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34423 >>Turn in Altar Altercation
.accept 34425 >>Accept The Kargathar Proving Grounds
.timer 30,Roleplay Duration
.target Archmage Khadgar
step
.goto 577,73.03,38.11
>>|cRXP_WARN_Wait for the roleplay|r.
.complete 34425,1 
step
.goto 577,73.03,38.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34425 >>Turn in The Kargathar Proving Grounds
.accept 34427 >>Accept A Potential Ally
.target Archmage Khadgar
step
.goto 577,68.91,33.73
>>Use the |T252270:0|t[Frostflurry Focus] near the fire
*|cRXP_WARN_Spam use the item if you have a bleed on you|r.
.complete 34427,1 
.timer 22,Wait for Farseer Drek'Thar
.use 110799
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Drek'Thar|r and |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34427 >>Turn in A Potential Ally
.goto 577,73.18,38.95
.target +Farseer Drek'Thar
.accept 34429 >>Accept Kill Your Hundred
.goto 577,73.03,38.10
.target +Archmage Khadgar
step
.goto 577,73.38,27.13
>>|cRXP_WARN_Wait at the waypoint location for roughly 20 seconds|r.
.complete 34429,1 
step
.goto 577,73.37,27.40
>>Kill the |cRXP_ENEMY_Shattered Hand Brawlers|r.
.complete 34429,2,99 
.mob Shattered Hand Brawler
step
.goto 578,81.88,49.92
#title |cFFFCDC00Follow the Arrow|r
.complete 34429,3 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r, |cRXP_FRIENDLY_Thrall|r and |cRXP_FRIENDLY_Luuka|r.
.turnin 34429 >>Turn in Kill Your Hundred
.goto 578,81.31,50.26
.accept 34739 >>Accept The Shadowmoon Clan
.goto 578,81.56,44.78
.accept 34737 >>Accept Masters of Shadow
.goto 578,82.90,44.35
.target Archmage Khadgar
.target Thrall
.target Luuka
step
#sticky
#label TanaanJungleIntroEnemyUmbralHalls
>>Kill |cRXP_ENEMY_Void Wolfs|r, |cRXP_ENEMY_Shadowmoon Ritualists|r or |cRXP_ENEMY_Shadowmoon Voidaxes|r.
.goto 578,56.93,51.91,0,0
.complete 34739,1 
.mob Void Wolf
.mob Shadowmoon Ritualist
.mob Shadowmoon Voidaxe
step
>>Kill |cRXP_ENEMY_Taskmaster Gurran|r.
.goto 578,46.37,38.95,10,0
.goto 578,52.69,24.16
.complete 34737,2 
.mob Taskmaster Gurran
step
.goto 578,53.52,19.81,4,0
.goto 578,45.59,15.27
>>|cRXP_WARN_Jump down and follow the arrow|r.
.complete 34737,3 
step
.goto 578,45.20,15.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yrel|r.
.accept 34740 >>Accept Yrel
.target Yrel
step
.goto 578,57.43,37.36,8,0
.goto 578,46.79,41.78
>>|cRXP_WARN_Follow the arrow to the escort location|r.
.complete 34740,1 
step
>>Kill |cRXP_ENEMY_Ungra|r.
.goto 578,46.41,41.62,20,0
.goto 578,43.78,77.37
.complete 34737,1 
.mob Ungra
step
#requires TanaanJungleIntroEnemyUmbralHalls
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Olin Umberhide|r, |cRXP_FRIENDLY_Yrel|r, and |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 34739 >>Turn in The Shadowmoon Clan
.goto 578,51.19,46.86
.target +Olin Umberhide
.turnin 34740 >>Turn in Yrel
.goto 578,50.55,48.28
.target +Yrel
.turnin 34737 >>Turn in Masters of Shadow
.accept 34741 >>Accept Keli'dan the Breaker
.goto 578,50.13,48.25
.target +Lady Liadrin
step
>>Kill |cRXP_ENEMY_Keli'dan the Breaker|r.
*|cRXP_WARN_Talent info some self healing or a pet before pulling him (without Heirlooms)|r. Hold your interrupt/stun for his ability 'Void Vacuum'.
*|cRXP_WARN_Drag him away from the totems otherwise he will deal a lot more damage|r.
.goto 578,36.30,48.95
.complete 34741,1 
.mob Keli'dan the Breaker
step
.goto 577,49.53,14.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34741 >>Turn in Keli'dan the Breaker
.target Archmage Khadgar
step
.goto 577,50.08,13.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r.
.accept 35005 >>Accept Prepare for Battle
.target Thrall
step
#completewith next
+Best sources for Blackrock Weapons:
>>1) |cRXP_PICK_Iron Horde Weapon Racks|r.
>>2) |cRXP_ENEMY_Blackrock Forgeworkers|r who are 'carrying Weapons'.
step
#loop
.goto 577,43.21,15.75,20,0
.goto 577,41.46,17.75,25,0
.goto 577,44.81,19.62,15,0
.goto 577,46.94,21.23,15,0
.goto 577,45.91,19.15,15,0
>>Pick up |cRXP_PICK_Blackrock Weapons|r.
.complete 35005,1 
.mob Blackrock Forgeworker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r and |cRXP_FRIENDLY_Cordana Felsong|r.
.turnin 35005 >>Turn in Prepare for Battle
.goto 577,50.06,13.31
.target +Thrall
.accept 34439 >>Accept The Battle of the Forge
.goto 577,49.50,14.22
.target +Cordana Felsong
step
#loop
.goto 577,44.13,15.06,35,0
.goto 577,43.21,19.33,35,0
>>Kill the |cRXP_ENEMY_Grunts|r and |cRXP_ENEMY_Ogrons|r in the area.
>>|cRXP_WARN_Focus on low HP mobs|r.
.complete 34439,1 
.complete 34439,2 
.mob Blackrock Grunt
.mob Ogron Warcrusher
step
.goto 577,43.04,26.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Drek'Thar|r.
.turnin 34439 >>Turn in The Battle of the Forge
.accept 34442 >>Accept Ga'nar of the Frostwolf
.target Farseer Drek'Thar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hansel Heavyhands|r and |cRXP_FRIENDLY_Thaelin Darkanvil|r.
.accept 34987 >>Accept The Gunpowder Plot
.goto 577,44.10,29.54
.target +Hansel Heavyhands
.accept 34958 >>Accept The Shadow of the Worldbreaker
.goto 577,44.07,29.69
.target +Thaelin Darkanvil
step
#completewith BackrockPowderKegB
>>Kill |cRXP_ENEMY_orcs|r in the area. Loot them for the [|cRXP_LOOT_schematics|r].
.goto 577,42.56,39.85,0,0
.complete 34958,1 
.mob Blackrock Laborer
.mob Blackrock Machinist
step
.goto 577,41.92,42.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ga'nar|r.
.turnin 34442 >>Turn in Ga'nar of the Frostwolf
.accept 34925 >>Accept Polishing the Iron Throne
.target Ga'nar
step
#completewith next
#label GanarsShackleKey
.goto 577,45.64,39.71,0,0
>>Kill |cRXP_ENEMY_Overseer Gotrigg|r downstairs. Loot him for |T134245:0|t[|cRXP_LOOT_Ga'nar's Shackle Key|r].
*|cRXP_WARN_If necessary run away from him when his blade is burning|r.
.complete 34925,1 
.mob Overseer Gotrigg
step
#completewith GanarsShackleKey
#title Enter House
.goto 577,44.29,38.07,8 >>Enter the building
step
#requires GanarsShackleKey
.goto 577,45.64,39.71
>>Kill |cRXP_ENEMY_Overseer Gotrigg|r downstairs. Loot him for |T134245:0|t[|cRXP_LOOT_Ga'nar's Shackle Key|r].
*|cRXP_WARN_If necessary run away from him when his blade is burning|r.
.complete 34925,1 
.mob Overseer Gotrigg
step
#completewith next
#label PolishingTheIronThrone
.goto 577,41.86,42.10,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ga'nar|r.
.turnin 34925 >>Turn in Polishing the Iron Throne
.accept 34437 >>Accept The Prodigal Frostwolf
.target Ga'nar
step
#completewith PolishingTheIronThrone
#title Leave House
.goto 577,44.29,38.07,8 >>Leave the building
step
#requires PolishingTheIronThrone
.goto 577,41.86,42.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ga'nar|r.
.turnin 34925 >>Turn in Polishing the Iron Throne
.accept 34437 >>Accept The Prodigal Frostwolf
.target Ga'nar
step
#completewith next
#label BackrockPowderKeg
.goto 577,46.98,32.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blackrock Powder Keg|r.
.complete 34987,1 
step
#completewith BackrockPowderKeg
#title Enter House
.goto 577,45.54,31.69,8 >>Enter the building
step
#requires BackrockPowderKeg
#label BackrockPowderKegB
.goto 577,46.98,32.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blackrock Powder Keg|r.
.complete 34987,1 
step
#loop
.goto 577,41.10,49.90,35,0
.goto 577,45.24,30.38,35,0
>>Kill |cRXP_ENEMY_orcs|r in the area. Loot them for the [|cRXP_LOOT_schematics|r].
.complete 34958,1 
.mob Blackrock Laborer
.mob Blackrock Machinist
step
#completewith next
#label ShadowOfTheWorldbreaker
.goto 577,44.09,29.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r.
.turnin 34958 >>Turn in The Shadow of the Worldbreaker
.target Thaelin Darkanvil
step
#completewith ShadowOfTheWorldbreaker
.goto 577,44.08,29.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Makeshift Plunger|r.
.complete 34987,2 
step
#requires ShadowOfTheWorldbreaker
.goto 577,44.08,29.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Makeshift Plunger|r.
.complete 34987,2 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r and |cRXP_FRIENDLY_Hansel Heavyhands|r.
.turnin 34958 >>Turn in The Shadow of the Worldbreaker
.goto 577,44.09,29.69
.target +Thaelin Darkanvil
.turnin 34987 >>Turn in The Gunpowder Plot
.goto 577,44.09,29.56
.target +Hansel Heavyhands
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Drek'Thar|r and |cRXP_FRIENDLY_Archmage Khadgar|r.
>>|cRXP_WARN_It's possible that you have to wait a few seconds before the quest pops up|r.
.turnin 34437 >>Turn in The Prodigal Frostwolf
.goto 577,43.03,26.38
.target +Farseer Drek'Thar
.accept 35747 >>Accept Taking a Trip to the Top of the Tank
.goto 577,43.13,28.74
.target +Archmage Khadgar
step
.goto 577,44.08,29.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r.
.complete 35747,1 
.target Thaelin Darkanvil
.skipgossipid 42452
step
.itemcount 132516,1
#completewith next
.use 132516
.cooldown item,132516,>0,1
.cast 202844 >>Use |T1405809:0|t[Gunshoes]
step
.goto 577,37.45,48.33
>>Kill |cRXP_ENEMY_Gogluk|r.
.complete 35747,2 
.mob Gogluk
step
.goto 577,40.14,48.32
>>|cRXP_WARN_Follow the arrow upwards|r.
.complete 35747,3 
step
.goto 577,40.11,48.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r.
.turnin 35747 >>Turn in Taking a Trip to the Top of the Tank
.accept 34445 >>Accept A Taste of Iron
.target Thaelin Darkanvil
step
.goto 577,40.17,48.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Worldbreaker Side Turret|r.
.complete 34445,1 
step
.goto 577,40.18,48.74
>>Spam |T252185:0|t[Turret Blast] (1) on the spot shown in the picture. |cRXP_WARN_You can ignore the cannons|r.
.link https://i.imgur.com/C5x3cTM.jpeg >>Spot to shoot at
.complete 34445,2 
step
.goto 577,40.30,48.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Main Cannon Trigger|r.
.complete 34445,3 
step
.goto 577,40.12,48.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r.
.turnin 34445 >>Turn in A Taste of Iron
.accept 34446 >>Accept The Home Stretch
.target Thaelin Darkanvil
step
.itemcount 132516,1
#completewith next
.use 132516
.cooldown item,132516,>0,1
.cast 202844 >>Use |T1405809:0|t[Gunshoes]
step
#label DraenorScenarioHordeEnd
.goto 577,44.30,79.91
#title |cFFFCDC00Follow the Arrow|r
.complete 34446,1 
step
.goto 577,44.38,80.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 34446 >>Turn in The Home Stretch
.accept 33868 >>Accept The Home of the Frostwolves
.target Archmage Khadgar
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Draenor Garrison
#internal
<< Horde
step
#completewith GarrisonHordeEnd
#hidewindow
+1
.usespell 1231411
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Drek'Thar|r.
.target Farseer Drek'Thar
.goto 525,40.79,67.09
.turnin 33868 >>Turn in The Home of the Frostwolves
.accept 33815 >>Accept A Song of Frost and Fire
.timer 32,Introduction Roleplay
step
.goto 525,41.54,67.61,20,0
.goto 525,41.81,69.65
>>Wait next to |cRXP_FRIENDLY_Durotan|r.
.complete 33815,1 
.target Durotan
step
.goto 525,41.81,69.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durotan|r.
.turnin 33815 >>Turn in A Song of Frost and Fire
.accept 34402 >>Accept Of Wolves and Warriors
.target Durotan
step
.goto 590,51.17,43.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_WARN_Follow the way up the mountain|r. Talk to |cRXP_FRIENDLY_Thrall|r. after he has arrived.
.turnin 34402 >>Turn in Of Wolves and Warriors
.accept 34364 >>Accept For the Horde!
.target Thrall
step
.goto 590,50.67,39.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Horde Banner|r.
.complete 34364,1 
.timer 16,Roleplay Duration
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tWait for |cRXP_FRIENDLY_Gazlowe|r and talk to him.
.goto 590,51.25,39.61
.turnin 34364 >>Turn in For the Horde!
.accept 34375 >>Accept Back to Work
.accept 34592 >>Accept A Gronnling Problem
.target Gazlowe
step
#completewith BackToWork
>>Kill |cRXP_ENEMY_Frostfire Gronnlings|r.
.complete 34592,1 
.mob Frostfire Gronnling
step
#title Tree marked (1/6)
.goto 590,47.29,57.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tree Marking|r.
.complete 34375,1,1 
step
#title Tree marked (2/6)
.goto 590,48.59,62.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tree Marking|r.
.complete 34375,1,2 
step
#title Tree marked (3/6)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tree Marking|r.
.goto 590,56.86,69.14
.complete 34375,1,3 
step
#title Tree marked (4/6)
.goto 590,59.53,72.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tree Marking|r.
.complete 34375,1,4 
step
#title Tree marked (5/6)
.goto 590,62.64,55.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tree Marking|r.
.complete 34375,1,5 
step
#label BackToWork
#title Tree marked (6/6)
.goto 590,63.30,51.90
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tree Marking|r.
.complete 34375,1 
step
#loop
.goto 590,73.41,41.49,35,0
.goto 590,41.01,20.24,35,0
.goto 590,38.56,48.53,35,0
>>Kill |cRXP_ENEMY_Frostfire Gronnlings|r.
.complete 34592,1 
.mob Frostfire Gronnling
step
.goto 590,51.26,39.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r.
.turnin 34375 >>Turn in Back to Work
.turnin 34592 >>Turn in A Gronnling Problem
.accept 34765 >>Accept The Den of Skog
.target Gazlowe
step
.goto 590,48.88,84.72
>>Kill |cRXP_ENEMY_Skog|r. |cRXP_WARN_Watch out for his Ground Slap ability|r.
.complete 34765,1 
.mob Skog
step
.goto 590,51.26,39.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r.
.turnin 34765 >>Turn in The Den of Skog
.accept 34378 >>Accept Establish Your Garrison
.target Gazlowe
step
.goto 590,35.60,52.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Master Surveyor|r.
.complete 34378,1 
step
.goto 590,52.49,53.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r in front of the Architect Table
.turnin 34378 >>Turn in Establish Your Garrison
.target Gazlowe
step
.goto 590,52.49,53.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r.
.accept 34824 >>Accept What We Got
.accept 34822 >>Accept What We Need
.target Gazlowe
step
.isOnQuest 34824
.goto 590,54.70,52.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Garrison Cache|r to the left.
.complete 34824,2 
step
.goto 590,51.29,51.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk with |cRXP_FRIENDLY_Rokhan|r.
.accept 34823 >>Accept The Ogron Live?
.target Rokhan
step
.isOnQuest 34824
.goto 590,41.02,50.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Skaggit|r.
.complete 34824,1 
.target Skaggit
.skipgossipid 42535
step
.isOnQuest 34824
.goto 590,49.36,16.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tGo north and talk to |cRXP_FRIENDLY_Senior Peon II|r.
.complete 34824,3 
.target Senior Peon II
.skipgossipid 43217
step
.isOnQuest 34822
#completewith GroogSlainB
>>Kill |cRXP_ENEMY_Pack Boars|r. Loot them for the |T132761:0|t[|cRXP_LOOT_Drudgeboat Salvage|r]. Or pick up |cRXP_PICK_Drudgeboat Salvages|r directly
.complete 34822,1 
.mob Pack Boar
step
.isOnQuest 34823
#completewith next
#label GroogSlain
>>Kill |cRXP_ENEMY_Groog|r.
>>Be sure to avoid his Rampaging Strike and Earthrending Slam.
.goto 525,40.29,58.95,0,0
.complete 34823,1 
.mob Groog
step
#completewith GroogSlain
#title Enter Cave
.goto 525,40.22,60.10,10 >>Enter the cave
step
.isOnQuest 34823
#requires GroogSlain
#label GroogSlainB
>>Kill |cRXP_ENEMY_Groog|r.
>>Be sure to avoid his Rampaging Strike and Earthrending Slam.
.goto 525,40.29,58.95,10,0
.goto 525,41.92,59.19
.complete 34823,1 
.mob Groog
step
.isOnQuest 34822
#loop
.goto 525,42.04,59.51,5,0
.goto 525,42.17,58.09,5,0
.goto 525,41.79,58.30,10,0
.goto 525,40.18,59.91,10,0
>>Kill |cRXP_ENEMY_Pack Boars|r. Loot them for the |T132761:0|t[|cRXP_LOOT_Drudgeboat Salvage|r]. Or pick up |cRXP_PICK_Drudgeboat Salvages|r directly
.complete 34822,1 
.mob Pack Boar
step
#completewith next
#label WhatGotNeedLive
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk with |cRXP_FRIENDLY_Gazlowe|r and |cRXP_FRIENDLY_Rokhan|r just outside the building.
.turnin 34824 >>Turn in What We Got
.turnin 34822 >>Turn in What We Need
.turnin 34823 >>Turn in The Ogron Live?
.target Gazlowe
.target Rokhan
step
.isOnQuest 34823
.zoneskip 590
#completewith WhatGotNeedLive
#title Use the |T1041860:0|t[Garrison Hearthstone]
.use 110560
.cast 171253 >>Use the Garrison Hearthstone
step
#requires WhatGotNeedLive
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk with |cRXP_FRIENDLY_Gazlowe|r and |cRXP_FRIENDLY_Rokhan|r just outside the building.
.turnin 34824 >>Turn in What We Got
.turnin 34822 >>Turn in What We Need
.goto 590,52.47,53.33
.target +Gazlowe
.turnin 34823 >>Turn in The Ogron Live?
.goto 590,51.29,51.39
.target +Rokhan
step
.goto 590,52.47,53.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r.
.accept 34461 >>Accept Build Your Barracks
.target Gazlowe
step
.goto 590,59.87,50.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Garrison Blueprint: Barracks|r.
.complete 34461,1 
step
.goto 590,59.87,50.15
>>Use the blueprint |T1001489:0|t[Barracks, Level 1] in your bags
.complete 34461,2 
.use 111956
step
.goto 590,52.27,53.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Architect Table|r.
*- |cRXP_WARN_Drag and drop 'Barrack' from the list on the left onto the glowing circle on the right|r.
.complete 34461,3 
.target Gazlowe
step
.goto 590,57.42,48.34
>>Now you have to wait for ~10s and follow |cRXP_FRIENDLY_Gazlowe|r. If he doesn't move then talk to him, open the Architect Table again or just wait for 1-2 minutes longer.
.complete 34461,4 
step
.goto 590,58.14,48.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Finalize Garrison Plot|r scroll.
.complete 34461,5 
step
.goto 590,57.42,48.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r.
.turnin 34461 >>Turn in Build Your Barracks
.target Gazlowe
step
.goto 590,57.42,48.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r.
.accept 34861 >>Accept We Need An Army
.target Gazlowe
step
.goto 590,53.90,54.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Zog|r.
.turnin 34861 >>Turn in We Need An Army
.accept 34462 >>Accept Winds of Change
.target Warmaster Zog
step
#completewith next
#label RescueOlinUmberhide
.goto 525,57.31,62.92,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Olin Umberhide|r.
.complete 34462,1 
.target Olin Umberhide
step
#completewith RescueOlinUmberhide
#title Enter Cave
.goto 525,56.76,62.59,6 >>Enter the cave
step
#requires RescueOlinUmberhide
.goto 525,57.31,62.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Olin Umberhide|r.
.complete 34462,1 
.target Olin Umberhide
step
.goto 590,53.90,54.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Zog|r.
.turnin 34462 >>Turn in Winds of Change
.accept 34775 >>Accept Mission Probable
.target Warmaster Zog
step
.goto 590,53.79,54.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Command Table|r. |cRXP_WARN_Follow these steps:|r.
*- |TInterface/cursor/crosshair/interact.blp:20|tClick on the mission |cRXP_PICK_Gronnling Abound|r.
*- Drag |cRXP_FRIENDLY_Olin Umberhide|r to the follower frame under the |cRXP_ENEMY_Frostfire Gronnling|r.
*- |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_WARN_"Start Mission"|r button.
.complete 34775,1 
step
#label GarrisonHordeEnd
.goto 590,53.89,54.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Zog|r.
.turnin 34775 >>Turn in Mission Probable
.target Warmaster Zog
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Silverpine Forest
#internal
<< Horde
step
#completewith SilverpineHordeEnd
#hidewindow
+1
.usespell 1231411
step
.zoneskip 85
.use 140192
.zone 627 >>Use Dalaran Hearthstone
step
.goto 627,55.28,23.95
.zone 85 >>Take the portal to Orgrimmar
step
.goto 85,53.44,90.43,10,0
.goto 85,54.88,89.80,8,0
.goto 85,54.81,86.92,8,0
.goto 85,56.13,87.19,8,0
.goto 85,54.59,90.37
.zone 110 >>Take the portal to Silvermoon (Burning Crusade) |cRXP_WARN_downstairs|r.
step
.zoneskip 18
.goto 110,51.84,17.95,8,0
.goto 110,49.52,17.19,8,0
.goto 110,48.87,14.04,8,0
.goto 110,49.52,14.81
.zone 18 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb of Translocation|r.
step
.goto 21,57.43,10.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Executor Mortuus|r.
.accept 26965 >>Accept The Warchief Cometh
.timer 300,Garrosh Roleplay
.target Grand Executor Mortuus
step
#completewith SilverpineStandbyWarchiefGarroshArrival
.goto 21,57.23,10.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.accept 28089 >>Accept Warchief's Command: Hillsbrad Foothills!
.target High Warlord Cromush
step
#label SilverpineStandbyWarchiefGarroshArrival
.goto 21,57.42,10.13
.complete 26965,1 
step
.goto 21,57.42,10.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Executor Mortuus|r.
.turnin 26965 >>Turn in The Warchief Cometh
.accept 26989 >>Accept The Gilneas Liberation Front
.target Grand Executor Mortuus
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Witherbloom|r and |cRXP_FRIENDLY_High Apothecary Shana T'veen|r.
.accept 26992 >>Accept Agony Abounds
.goto 21,56.77,9.19
.accept 26995 >>Accept Guts and Gore
.goto 21,56.26,8.40
.target Apothecary Witherbloom
.target High Apothecary Shana T'veen
step
#completewith CleanBeastGutsA
#hidewindow
#loop
.goto 21,60.83,6.82,30,0
.goto 21,62.24,12.54,25,0
.goto 21,61.76,13.12,20,0
.goto 21,59.36,12.96,20,0
.goto 21,55.66,20.18,20,0
.goto 21,56.01,22.62,20,0
.goto 21,56.01,22.62,30,0
.goto 21,53.93,17.13,15,0
.goto 21,56.07,12.92,30,0
+1
step
#completewith SilverpineWorgenRenegade
>>Kill |cRXP_ENEMY_beasts|r in the area. Loot them for the |T237414:0|t[|cRXP_LOOT_"Clean" Beast Guts|r].
*Keep an eye out for the rares |cRXP_ENEMY_Kree|r and |cRXP_ENEMY_Gorefang|r.
.complete 26995,1 
.mob Ferocious Grizzled Bear
.mob Worg
step
#completewith SilverpineWorgenRenegade
*>>Pick up |cRXP_PICK_Ferocious Doomweed|r from the ground.
.complete 26992,1 
step
#label SilverpineWorgenRenegade
>>Kill the |cRXP_ENEMY_Worgen Renegade|r in the area.
.complete 26989,1 
.mob Worgen Renegade
step
#completewith next
>>Kill |cRXP_ENEMY_beasts|r in the area. Loot them for their [|cRXP_LOOT_guts|r].
*Keep an eye out for the rares |cRXP_ENEMY_Kree|r and |cRXP_ENEMY_Gorefang|r.
.complete 26995,1 
.mob Ferocious Grizzled Bear
.mob Worg
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ferocious Doomweed|r.
.complete 26992,1 
step
#label CleanBeastGutsA
>>Kill |cRXP_ENEMY_beasts|r in the area. Loot them for their [|cRXP_LOOT_guts|r].
*Keep an eye out for the rares |cRXP_ENEMY_Kree|r and |cRXP_ENEMY_Gorefang|r.
.complete 26995,1 
.mob Ferocious Grizzled Bear
.mob Worg
step
#requires SilverpineCleanBeastGuts
.goto 21,57.41,10.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Executor Mortuus|r.
.turnin 26989 >>Turn in The Gilneas Liberation Front
.target Grand Executor Mortuus
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Witherbloom|r and |cRXP_FRIENDLY_High Apothecary Shana T'veen|r.
.turnin 26992 >>Turn in Agony Abounds
.goto 21,56.76,9.19
.target +Apothecary Witherbloom
.turnin 26995 >>Turn in Guts and Gore
.accept 26998 >>Accept Iterating Upon Success
.goto 21,56.26,8.40
.target +High Apothecary Shana T'veen
step
.goto 21,57.91,8.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bat Handler Maggotbreath|r.
.complete 26998,1 
.target Bat Handler Maggotbreath
.skipgossip 1
step
>>Spam |T236885:0|t[Blight Concoction] (1) on the |cRXP_ENEMY_Murlocs|r.
*|cRXP_WARN_NOTE:|r Don't use (2)!
.complete 26998,2 
step
.goto 21,56.26,8.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Apothecary Shana T'veen|r.
.turnin 26998 >>Turn in Iterating Upon Success
.target High Apothecary Shana T'veen
step
.goto 21,58.09,8.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathstalker Commander Belmont|r.
.accept 27039 >>Accept Dangerous Intentions
.target Deathstalker Commander Belmont
step
.goto 21,53.90,13.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Abandoned Outhouse|r.
.turnin 27039 >>Turn in Dangerous Intentions
.accept 27045 >>Accept Waiting to Exsanguinate
step
#title DON'T SKIP THE CUTSCENE
.goto 21,53.41,13.19,8,0
.goto 21,53.04,13.11,8,0
.goto 21,53.44,13.08,8,0
.goto 21,53.30,12.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Armoire|r.
.complete 27045,1 
step
.goto 21,58.09,8.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathstalker Commander Belmont|r.
.turnin 27045 >>Turn in Waiting to Exsanguinate
.accept 27056 >>Accept Belmont's Report
.target Deathstalker Commander Belmont
step
.goto 21,57.37,10.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27056 >>Turn in Belmont's Report
.accept 27065 >>Accept The Warchief's Fleet
.target Lady Sylvanas Windrunner
step
.goto 21,52.57,25.71,25,0
.goto 21,50.06,29.25,25,0
.goto 21,48.38,24.48,25,0
.goto 21,44.06,21.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Hatchet|r and |cRXP_FRIENDLY_Warlord Torok|r.
>>Follow the arrow to check the locations for the rares |cRXP_ENEMY_Nightlash|r, |cRXP_ENEMY_Gnath|r, and |cRXP_ENEMY_Bolgaff|r.
.turnin 27065 >>Turn in The Warchief's Fleet
.accept 27069 >>Accept Steel Thunder
.target +Admiral Hatchet
.accept 27073 >>Accept Give 'em Hell!
.target +Warlord Torok
step
.goto 21,44.80,20.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Wormcrud|r.
.accept 27082 >>Accept Playing Dirty
.target Apothecary Wormcrud
step
#completewith next
.goto 21,42.44,20.06,20,0
.goto 21,38.58,23.93,10,0
.goto 21,37.45,23.73,10,0
>>Kill |cRXP_ENEMY_Worgs|r and |cRXP_ENEMY_Bears|r. Loot them for the |T237411:0|t[|cRXP_LOOT_Diseased Organ|r].
.complete 27082,1 
.mob Giant Rabid Bear
.mob Rabid Worg
step
#completewith next
.goto 21,39.41,25.88,20,0
.goto 21,37.89,27.44,20,0
.goto 21,38.79,30.30,20,0
.goto 21,40.19,29.25,20,0
.goto 21,39.20,28.09,0,0
>>Kill |cRXP_ENEMY_Bloodfang Scavengers|r.
.complete 27073,1 
.mob Bloodfang Scavenger
step
.goto 21,39.20,28.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sea Dog Crates|r.
.complete 27069,1 
step
#loop
.goto 21,41.17,29.74,45,0
.goto 21,38.32,31.53,40,0
.goto 21,37.22,27.10,40,0
.goto 21,39.90,25.09,40,0
>>Kill |cRXP_ENEMY_Bloodfang Scavengers|r.
.complete 27073,1 
.mob Bloodfang Scavenger
step
#loop
.goto 21,40.88,18.16,35,0
.goto 21,47.44,16.91,35,0
.goto 21,49.92,24.57,35,0
.goto 21,45.69,27.85,35,0
>>Kill |cRXP_ENEMY_Worgs|r and |cRXP_ENEMY_Bears|r. Loot them for their [|cRXP_LOOT_organs|r].
.complete 27082,1 
.mob Giant Rabid Bear
.mob Rabid Worg
step
.goto 21,44.00,21.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Hatchet|r and |cRXP_FRIENDLY_Warlord Torok|r.
.turnin 27069 >>Turn in Steel Thunder
.target Admiral Hatchet
.turnin 27073 >>Turn in Give 'em Hell!
.accept 27095 >>Accept Skitterweb Menace
.target +Warlord Torok
.accept 27093 >>Accept Lost in the Darkness
.target +Admiral Hatchet
step
.goto 21,44.79,20.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Wormcrud|r.
.turnin 27082 >>Turn in Playing Dirty
.accept 27088 >>Accept It's Only Poisonous if You Ingest It
.target Apothecary Wormcrud
step
#completewith SilverpineSkitterwebMatriarch
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_ENEMY_Webbed Victims|r.
*Keep an eye out for the rare |cRXP_ENEMY_Krethis the Shadowspinner|r.
.complete 27093,1 
.mob Webbed Victim
step
#completewith SilverpineSkitterwebMatriarch
>>Kill |cRXP_ENEMY_Skitterweb Spiders|r.
.complete 27095,1 
.mob Skitterweb Spider
step
.goto 21,35.14,11.29,10,0
.goto 21,35.47,10.51,10,0
.goto 21,34.95,10.29,10,0
.goto 21,35.56,9.29
>>|cRXP_WARN_Follow the arrow into the mine. Jump up the rocks.|r
*|cRXP_WARN_NOTE:|r There may be a chest next to the jumping location.
.accept 27094 >>Accept Deeper into Darkness
step
#label SilverpineSkitterwebMatriarch
.goto 21,35.94,8.65
>>Kill the |cRXP_ENEMY_Skitterweb Matriarch|r.
.complete 27094,1 
.mob Skitterweb Matriarch
step
#completewith next
#label OrcSeaDogRescuedB
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_ENEMY_Webbed Victims|r.
*Keep an eye out for the rare |cRXP_ENEMY_Krethis the Shadowspinner|r.
.complete 27093,1 
.mob Webbed Victim
step
#completewith OrcSeaDogRescuedB
.goto 21,35.85,7.98,10 >>Check for a possible |cRXP_PICK_chest|r.
.goto 21,34.67,7.82,10,0
.goto 21,35.60,13.38,10 >>Leave the cave
step
#requires OrcSeaDogRescuedB
#completewith OrcSeaDogRescuedA
#hidewindow
#loop
.goto 21,34.80,15.02,30,0
.goto 21,35.60,17.69,30,0
.goto 21,37.11,16.23,30,0
.goto 21,35.90,14.58,30,0
+1
step
#requires OrcSeaDogRescuedB
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_ENEMY_Webbed Victims|r.
*Keep an eye out for the rare |cRXP_ENEMY_Krethis the Shadowspinner|r.
.complete 27093,1 
.mob Webbed Victim
step
#requires OrcSeaDogRescuedB
>>Kill |cRXP_ENEMY_Skitterweb Spiders|r.
.complete 27095,1 
.mob Skitterweb Spider
step
#label OrcSeaDogRescuedA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_ENEMY_Webbed Victims|r.
*Keep an eye out for the rare |cRXP_ENEMY_Krethis the Shadowspinner|r.
.complete 27093,1 
.mob Webbed Victim
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 27095 >>Turn in Skitterweb Menace
step
#requires SilverpineOrcSeaDog
#loop
.goto 21,46.68,18.04,30,0
.goto 21,46.20,28.45,30,0
.goto 21,39.64,29.99,30,0
.goto 21,39.90,16.58,30,0
>>Kill the |cRXP_ENEMY_Forest Ettin|r.
>>Use the |T132598:0|t[Mutant Bush Chicken Cage] on the |cRXP_ENEMY_Ettin|r to weaken him.
*|cRXP_WARN_The |cRXP_ENEMY_Ettin|r runs around the village.
*You should see a small yellow waypoint at his position|r.
.complete 27088,1 
.mob Forest Ettin
.use 60808
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Wormcrud|r, |cRXP_FRIENDLY_Admiral Hatchet|r, and |cRXP_FRIENDLY_Warlord Torok|r.
.turnin 27088 >>Turn in It's Only Poisonous if You Ingest It
.goto 21,44.79,20.91
.target +Apothecary Wormcrud
.turnin 27094 >>Turn in Deeper into Darkness
.goto 21,44.01,21.32
.target +Warlord Torok
.turnin 27093 >>Turn in Lost in the Darkness
.accept 27096 >>Accept Orcs are in Order
.goto 21,44.01,21.32
.target +Admiral Hatchet
step
#title Dismount
.goto 21,57.37,10.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
*|cRXP_WARN_NOTE:|r Dismount before talking to Sylvanas.
.turnin 27096 >>Turn in Orcs are in Order
.accept 27097 >>Accept Rise, Forsaken
.target Lady Sylvanas Windrunner
step
.goto 21,64.87,19.37,30,0
.goto 21,65.70,26.35
>>Kill |cRXP_ENEMY_Hillsbrad Refugees|r while |cRXP_FRIENDLY_Agatha|r is next to you.
*|cRXP_WARN_Wait until Agatha spawns before mounting up. If she despawns just dismount and wait for her to reappear|r.
.complete 27097,1 
step
.goto 21,65.70,26.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 27097 >>Turn in Rise, Forsaken
.accept 27099 >>Accept No Escape
step
#title DON'T SKIP THE CUTSCENE
.goto 21,65.73,24.39,10,0
.goto 21,66.27,24.34,10,0
.goto 21,66.07,23.92,10,0
.goto 21,65.54,23.44,10,0
.goto 21,65.92,23.35,8,0
.goto 21,65.94,23.91,8,0
.goto 21,65.29,23.94,10,0
.goto 21,65.27,24.97
>>Find the leaders upstairs. You don't need to kill any mobs |cRXP_WARN_if you can survive it|r.
*|cRXP_WARN_DON'T SKIP THE CINEMATIC|r.
.complete 27099,1 
step
.goto 21,57.35,10.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27099 >>Turn in No Escape
.accept 27098 >>Accept Lordaeron
.complete 27098,1 
.target Lady Sylvanas Windrunner
step
.goto 21,44.89,41.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.target Lady Sylvanas Windrunner
.turnin 27098 >>Turn in Lordaeron
.accept 27180 >>Accept Honor the Dead
step
.goto 21,45.78,41.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Hatchet|r and |cRXP_FRIENDLY_Warlord Torok|r.
.accept 27226 >>Accept Hair of the Dog
.accept 27231 >>Accept Reinforcements from Fenris
.target Admiral Hatchet
.target Warlord Torok
step
.goto 21,47.28,46.68
>>Kill a |cRXP_ENEMY_Bloodfang Stalker|r to trigger the quest.
.accept 27181 >>Accept Excising the Taint
.mob Bloodfang Stalker
step
#completewith BloodfangStalkerA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Veteran Forsaken Troopers|r.
.complete 27180,1 
.target Veteran Forsaken Trooper
step
#completewith BloodfangStalkerA
#hidewindow
.goto 21,43.34,50.79,15 >>1
step
#label BloodfangStalkerA
#loop
.goto 21,46.27,51.27,25,0
.goto 21,47.48,49.47,30,0
.goto 21,47.03,53.10,30,0
>>Kill |cRXP_ENEMY_Bloodfang Stalkers|r.
*Keep an eye out for the rare |cRXP_ENEMY_Berard the Moon-Crazed|r.
.complete 27181,1 
.mob Bloodfang Stalker
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 27181 >>Turn in Excising the Taint
.accept 27193 >>Accept Seek and Destroy
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Veteran Forsaken Troopers|r.
.complete 27180,1 
.target Veteran Forsaken Trooper
step
.goto 21,45.90,54.23
>>Kill |cRXP_ENEMY_Caretaker Smithers|r. Loot him for |T133736:0|t[|cRXP_LOOT_Smither's Logbook|r].
.complete 27193,1 
.mob Caretaker Smithers
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 27193 >>Turn in Seek and Destroy
.accept 27194 >>Accept Cornered and Crushed!
step
#loop
.goto 21,47.03,53.10,30,0
.goto 21,46.27,51.27,25,0
.goto 21,47.48,49.47,30,0
.goto 21,45.55,49.45,30,0
.goto 21,47.03,53.10,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Veteran Forsaken Troopers|r.
.complete 27180,1 
.target Veteran Forsaken Trooper
step
#requires SilverpineForsakenInsignia
.goto 21,55.88,46.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Forteski|r and follow him.
.turnin 27194 >>Turn in Cornered and Crushed!
.accept 27195 >>Accept Nowhere to Run
.target Master Forteski
step
#title Don't run too far away
.goto 21,58.05,44.89
*|cRXP_WARN_Don't run too far away from |cRXP_FRIENDLY_Master Forteski|r|r.
.complete 27195,1 
.target Master Forteski
step
#completewith next
#label HillsbradWorgenA
>>Kill |cRXP_ENEMY_Hillsbrad Worgen|r.
.complete 27231,1 
.mob Hillsbrad Worgen
step
#completewith HillsbradWorgenA
.goto 21,56.46,46.06,10 >>Leave the cave
step
#requires HillsbradWorgenA
#completewith SilverpineHairoftheDog
.goto 21,56.64,34.11,0,0
>>Kill |cRXP_ENEMY_Hillsbrad Worgen|r.
.complete 27231,1 
.mob Hillsbrad Worgen
step
#requires HillsbradWorgenA
#title Orcs roused (1/8) |cFFFCDC00(Read Note)|r
.goto 21,54.25,38.83
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,1 
.target Orc Sea Dog
.use 60870
step
#completewith next
#label OrcSeaDogRousedA
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,2 
.target Orc Sea Dog
.use 60870
step
#title Possible Chest
#completewith OrcSeaDogRousedA
.goto 21,53.51,38.64,10 >>Check for a possible |cRXP_PICK_chest|r.
step
#requires OrcSeaDogRousedA
#title Orcs roused (2/8) |cFFFCDC00(Read Note)|r
.goto 21,53.86,37.49
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,2 
.target Orc Sea Dog
.use 60870
step
#title Orcs roused (3/8) |cFFFCDC00(Read Note)|r
.goto 21,54.37,36.25
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,3 
.target Orc Sea Dog
.use 60870
step
#title Orcs roused (4/8) |cFFFCDC00(Read Note)|r
.goto 21,53.91,35.74
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,4 
.target Orc Sea Dog
.use 60870
step
#completewith next
#label OrcSeaDogRousedB
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,5 
.target Orc Sea Dog
.use 60870
step
#completewith OrcSeaDogRousedB
.goto 21,54.43,34.34,10 >>Check for a possible chest
step
#requires OrcSeaDogRousedB
#title Orcs roused (5/8) |cFFFCDC00(Read Note)|r
.goto 21,54.47,33.00
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,5 
.target Orc Sea Dog
.use 60870
step
#title Orcs roused (6/8) |cFFFCDC00(Read Note)|r
.goto 21,56.08,32.18
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,6 
.target Orc Sea Dog
.use 60870
step
#title Orcs roused (7/8) |cFFFCDC00(Read Note)|r
.goto 21,57.05,32.67
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1,7 
.target Orc Sea Dog
.use 60870
step
#label SilverpineHairoftheDog
#title Orcs roused (8/8) |cFFFCDC00(Read Note)|r
.goto 21,57.76,34.06
>>Use the |T252176:0|t[Barrel of Explosive Ale] on Orc Sea Dogs
*|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
*Keep an eye out for chests
.complete 27226,1 
.target Orc Sea Dog
.use 60870
step
#loop
.goto 21,57.01,34.96,30,0
.goto 21,54.34,34.19,30,0
.goto 21,52.93,31.90,30,0
>>Kill |cRXP_ENEMY_Hillsbrad Worgen|r.
.complete 27231,1 
.mob Hillsbrad Worgen
step
.goto 21,59.24,34.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Horde Communication Panel|r.
.turnin 27231 >>Turn in Reinforcements from Fenris
.accept 27232 >>Accept The Waters Run Red...
step
#completewith next
.goto 21,59.62,33.53
.vehicle 45263 >>Enter the |cRXP_PICK_Horde Cannon|r.
step
.goto 21,59.38,33.46,8,0
.goto 21,59.62,33.53
>>Use |T133032:0|t[Rocket Blast] (1) to kill the arriving |cRXP_ENEMY_Worgen|r.
>>Keep an eye out for the rare |cRXP_ENEMY_Fenwick Thatros|r.
.complete 27232,1 
step
#completewith next
.goto 21,46.43,42.70
.vendor
step
#label SilverpineTheWatersRunRed
.goto 21,45.79,41.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Hatchet|r and |cRXP_FRIENDLY_Warlord Torok|r.
.turnin 27232 >>Turn in The Waters Run Red...
.target +Admiral Hatchet
.turnin 27226 >>Turn in Hair of the Dog
.target +Warlord Torok
step
.goto 21,44.94,41.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27180 >>Turn in Honor the Dead
.turnin 27195 >>Turn in Nowhere to Run
.accept 27290 >>Accept To Forsaken Forward Command
.target Lady Sylvanas Windrunner
step
.goto 217,57.46,18.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tFly with |cRXP_FRIENDLY_Arthura|r and talk to |cRXP_FRIENDLY_Deathstalker Commander Belmont|r.
.turnin 27290 >>Turn in To Forsaken Forward Command
.target +Arthura
.accept 27342 >>Accept In Time, All Will Be Revealed
.target +Deathstalker Commander Belmont
step
.goto 217,57.54,18.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Onslaught|r.
.accept 27333 >>Accept Losing Ground
.accept 27345 >>Accept The F.C.D.
.target Forward Commander Onslaught
step
#completewith KorokTheColossusA
>>Kill |cRXP_ENEMY_Worgen Rebels|r.
.complete 27333,1 
.mob Worgen Rebel
step
#completewith TheFCDA
>>Kill |cRXP_ENEMY_Korok|r. (patrolling). Loot him for his [|cRXP_LOOT_head|r]. |TInterface/cursor/crosshair/interact.blp:15|tClick it in your bags
.collect 60956,1,27322,1
.accept 27322 >>Accept Korok the Colossus
.mob Korok the Colossus
step
#label TheFCDA
.goto 217,45.76,21.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Communication Device|r.
.complete 27345,1 
step
#label KorokTheColossusA
#loop
.goto 217,51.99,12.28,45,0
.goto 217,51.69,26.76,45,0
>>Kill |cRXP_ENEMY_Korok|r. (patrolling). Loot him for his [|cRXP_LOOT_head|r]. |TInterface/cursor/crosshair/interact.blp:15|tClick it in your bags
.collect 60956,1,27322,1
.accept 27322 >>Accept Korok the Colossus
.mob Korok the Colossus
step
#completewith next
>>Kill the |cRXP_ENEMY_Worgen Rebels|r.
.complete 27333,1 
.mob Worgen Rebel
step
#loop
.goto 217,58.82,32.55,35,0
.goto 217,62.30,33.88,35,0
.goto 217,63.78,31.96,35,0
.goto 217,59.83,28.20,35,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wolfsbane|r.
.complete 27342,1 
step
#loop
.goto 217,55.14,26.38,30,0
.goto 217,55.68,12.77,35,0
.goto 217,51.84,20.59,45,0
>>Kill the |cRXP_ENEMY_Worgen Rebels|r.
.complete 27333,1 
.mob Worgen Rebel
step
.goto 217,57.49,18.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Onslaught|r and |cRXP_FRIENDLY_Belmont|r.
.turnin 27333 >>Turn in Losing Ground
.turnin 27345 >>Turn in The F.C.D.
.turnin 27322 >>Turn in Korok the Colossus
.turnin 27342 >>Turn in In Time, All Will Be Revealed
.accept 27349 >>Accept Break in Communications: Dreadwatch Outpost
.target Forward Commander Onslaught
.target Deathstalker Commander Belmont
step
#title |cFFFCDC00Follow the Arrow|r
.goto 217,52.70,32.23
>>Follow the arrow.
*It may not complete if you fly too high.
.complete 27349,1 
step
.goto 217,52.76,32.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 27349 >>Turn in Break in Communications: Dreadwatch Outpost
.accept 27350 >>Accept Break in Communications: Rutsak's Guard
step
.goto 217,65.64,34.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Rutsak|r.
.turnin 27350 >>Turn in Break in Communications: Rutsak's Guard
.accept 27360 >>Accept Vengeance for Our Soldiers
.accept 27364 >>Accept On Whose Orders?
.target Captain Rutsak
step
#completewith next
>>Kill the |cRXP_ENEMY_Submariners|r in the area.
.complete 27360,1 
.mob 7th Legion Submariner
step
.goto 217,58.76,47.38
>>Kill |cRXP_ENEMY_Master Sergeant Pietro Zaren|r. Loot him for the |T237248:0|t[|cRXP_LOOT_Orders from High Command|r].
.complete 27364,1 
.mob Master Sergeant Pietro Zaren
step
.goto 217,58.17,47.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 27364 >>Turn in On Whose Orders?
.accept 27401 >>Accept What Tomorrow Brings
step
#loop
.goto 217,60.12,45.39,25,0
.goto 217,59.17,42.96,25,0
.goto 217,57.91,45.44,25,0
.goto 217,56.73,48.52,25,0
>>Kill |cRXP_ENEMY_7th Legion Submariners|r in the area.
*|cRXP_WARN_Be careful not to pull too many because they can do a lot of damage|r.
.complete 27360,1 
.mob 7th Legion Submariner
step
#title DON'T SKIP THE CUTSCENE
.goto 217,54.72,44.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
*|cRXP_WARN_DON'T SKIP THE CINEMATIC|r.
.complete 27401,1 
step
.goto 217,54.72,44.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 27401 >>Turn in What Tomorrow Brings
.accept 27405 >>Accept Fall Back!
step
.goto 217,65.70,34.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Rutsak|r.
.turnin 27360 >>Turn in Vengeance for Our Soldiers
.target Captain Rutsak
step
.goto 217,72.88,30.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathstalker Commander Belmont|r.
.turnin 27405 >>Turn in Fall Back!
.accept 27406 >>Accept A Man Named Godfrey
.target Deathstalker Commander Belmont
step
.goto 217,73.76,32.85
>>You automatically accept it when you reach the waypoint
.accept 27423 >>Accept Resistance is Futile
step
#completewith next
+|cRXP_WARN_Dismount if no NPC is following you to make them spawn|r.
step
#loop
.goto 217,71.84,42.71,45,0
.goto 217,71.78,51.53,45,0
.goto 217,76.38,56.02,45,0
.goto 217,77.65,61.04,45,0
*Focus on killing the |cRXP_ENEMY_Bloodfang Scout|r. + 5 |cRXP_ENEMY_Gilnean Warhound|r packs.
.complete 27423,1 
.mob Bloodfang Scout
.mob Gilnean Warhound
step
.goto 217,79.70,75.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_corpse|r of |cRXP_FRIENDLY_Lord Godfrey|r.
.complete 27406,1 
.target Lord Godfrey
step
.goto 217,79.70,75.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathstalker Commander Belmont|r.
*|cRXP_WARN_NOTE:|r Dismount if no NPC is following you to make them spawn.
.turnin 27406 >>Turn in A Man Named Godfrey
.turnin 27423 >>Turn in Resistance is Futile
.accept 27438 >>Accept The Great Escape
.target Deathstalker Commander Belmont
step
.goto 21,51.77,66.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27438 >>Turn in The Great Escape
.accept 27472 >>Accept Rise, Godfrey
.timer 90,RP Duration
.target Lady Sylvanas Windrunner
step
.goto 21,51.73,65.50
>>Wait for the roleplay.
.complete 27472,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r and |cRXP_FRIENDLY_Daschla|r.
.turnin 27472 >>Turn in Rise, Godfrey
.accept 27474 >>Accept Breaking the Barrier
.goto 21,51.88,65.08
.target +Lady Sylvanas Windrunner
.accept 27475 >>Accept Unyielding Servitors
.goto 21,51.91,64.69
.target +Daschla
step
.isOnQuest 27475
.goto 21,48.20,69.26
+Look for |cRXP_ENEMY_Effritus|r and |cRXP_ENEMY_Corpsefeeder|r (behind you)
*|cRXP_WARN_Complete this step when you're done.|r
*|cRXP_WARN_NOTE:|r You have to pull |cRXP_ENEMY_Corpsefeeder|r with a range ability.
step
#completewith SilverpineBreakingtheBarrier
>>Kill the |cRXP_ENEMY_elementals|r in the area. Loot them for the |T134565:0|t[|cRXP_LOOT_Servitor Cores|r].
.complete 27475,1 
.mob Elemental Servitor
step
#completewith BreakingTheBarrierC
#label BreakingTheBarrierA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 27474,1 
step
#completewith BreakingTheBarrierA
#label BreakingTheBarrierB
#title Check for Chest
.goto 21,58.48,61.62,8 >>Check possible |cRXP_PICK_Chest|r location.
step
#requires BreakingTheBarrierB
#completewith BreakingTheBarrierA
#label BreakingTheBarrierC
.goto 21,62.84,64.02,8 >>Enter the building
step
#requires BreakingTheBarrierA
#label SilverpineBreakingtheBarrier
.goto 21,63.48,64.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 27474,1 
step
#completewith next
#label UnyieldingServitorsA
>>Kill the |cRXP_ENEMY_elementals|r in the area. Loot them for the |T134565:0|t[|cRXP_LOOT_Servitor Cores|r].
.complete 27475,1 
step
#completewith UnyieldingServitorsA
.goto 21,62.84,64.02,8 >>Leave the building
step
#requires UnyieldingServitorsA
#loop
.goto 21,57.71,60.64,35,0
.goto 21,57.68,67.97,35,0
.goto 21,62.84,64.02,35,0
>>Kill the |cRXP_ENEMY_elementals|r in the area. Loot them for the |T134565:0|t[|cRXP_LOOT_Servitor Cores|r].
.complete 27475,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daschla|r and |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27475 >>Turn in Unyielding Servitors
.goto 21,51.89,64.67
.target +Daschla
.turnin 27474 >>Turn in Breaking the Barrier
.accept 27476 >>Accept Dalar Dawnweaver
.goto 21,51.94,64.99
.target Lady Sylvanas Windrunner
step
.goto 21,47.06,43.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dalar Dawnweaver|r.
.turnin 27476 >>Turn in Dalar Dawnweaver
.accept 27478 >>Accept Relios the Relic Keeper
.accept 27483 >>Accept Practical Vengeance
.target Dalar Dawnweaver
step
#completewith next
#label LeyEnergies
>>Kill an |cRXP_ENEMY_Arcane Remnant|r. Loot it for the |T135731:0|t[|cRXP_LOOT_Arcane Remnant|r].
.collect 61310,1,27480
.accept 27480 >>Accept Ley Energies
.mob Arcane Remnant
step
#completewith LeyEnergies
#title Portal to Dalaran Crater
.goto 21,47.25,43.37
.zone 25 >> |TInterface/cursor/crosshair/interact.blp:20|tClick the Portal to Dalaran Crater
step
#requires LeyEnergies
.goto 25,30.10,37.07
>>Kill an |cRXP_ENEMY_Arcane Remnant|r. Loot it for the |T135731:0|t[|cRXP_LOOT_Arcane Remnant|r].
.collect 61310,1,27480
.accept 27480 >>Accept Ley Energies
.mob Arcane Remnant
step
#completewith ReliosTheRelicKeeperA
>>Kill |cRXP_ENEMY_Arcane Remnants|r. Loot them for their |T135731:0|t[|cRXP_LOOT_Arcane Remnants|r].
.complete 27480,1 
.mob Arcane Remnant
step
#completewith ReliosTheRelicKeeperA
>>Kill the |cRXP_ENEMY_Dalaran Workers|r.
*|cRXP_WARN_NOTE:|r The summoners are not worth it.
.complete 27483,1 
.mob Dalaran Worker
step
#label ReliosTheRelicKeeperA
#loop
.goto 25,31.73,39.82,15,0
.goto 25,32.76,43.09,15,0
>>Kill |cRXP_ENEMY_Relios the Relic Keeper|r. Loot him for the |T133410:0|t[|cRXP_LOOT_Dalaran Archmage's Signet Ring|r].
>>Keep an eye out for the rare |cRXP_ENEMY_Indigos|r.
.complete 27478,1 
.mob Relios the Relic Keeper
.mob Indigos
step
#completewith next
>>Kill |cRXP_ENEMY_Arcane Remnants|r. Loot them for their |T135731:0|t[|cRXP_LOOT_Arcane Remnants|r].
.complete 27480,1 
.mob Arcane Remnant
step
#loop
.goto 25,28.30,44.78,35,0
.goto 25,33.05,43.68,35,0
.goto 25,34.01,31.01,35,0
.goto 25,33.05,43.68,35,0
>>Kill the |cRXP_ENEMY_Dalaran Workers|r.
*|cRXP_WARN_NOTE:|r The summoners are not worth it.
.complete 27483,1 
.mob Dalaran Worker
step
#loop
.goto 25,30.31,40.28,35,0
.goto 25,30.40,38.09,35,0
.goto 25,30.33,33.67,35,0
>>Kill |cRXP_ENEMY_Arcane Remnants|r. Loot them for their |T135731:0|t[|cRXP_LOOT_Arcane Remnants|r].
.complete 27480,1 
.mob Arcane Remnant
step
>>Kill the |cRXP_ENEMY_Dalaran Workers|r.
*|cRXP_WARN_NOTE:|r The summoners are not worth it.
.complete 27483,1 
.mob Dalaran Worker
step
#completewith next
#label ReliosTheRelicKeeperB
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dalar Dawnweaver|r.
.turnin 27478 >>Turn in Relios the Relic Keeper
.accept 27484 >>Accept Only One May Enter
.turnin 27483 >>Turn in Practical Vengeance
.turnin 27480 >>Turn in Ley Energies
.target Dalar Dawnweaver
step
#completewith ReliosTheRelicKeeperB
.goto 25,30.29,36.62
.zone 21 >>Take the Portal to the Sepulcher
step
#requires ReliosTheRelicKeeperB
.goto 21,47.07,43.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dalar Dawnweaver|r.
.turnin 27478 >>Turn in Relios the Relic Keeper
.accept 27484 >>Accept Only One May Enter
.turnin 27483 >>Turn in Practical Vengeance
.turnin 27480 >>Turn in Ley Energies
.target Dalar Dawnweaver
step
.goto 21,51.85,64.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27484 >>Turn in Only One May Enter
.accept 27512 >>Accept Transdimensional Warfare: Chapter I
.target Lady Sylvanas Windrunner
step
.goto 21,51.82,65.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.accept 27510 >>Accept A Wolf in Bear's Clothing
.target High Warlord Cromush
step
#loop
.goto 21,54.95,68.06,30,0
.goto 21,56.07,78.70,30,0
.goto 21,66.07,76.95,30,0
.goto 21,56.07,78.70,30,0
>>Kill |cRXP_ENEMY_Inconspicuous Bear|r.
.complete 27510,1 
.mob Inconspicuous Bear
step
#completewith next
#label TransdimensionalWarfareChapterIA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Ambermill Dimensional Portal|r.
.turnin 27512 >>Turn in Transdimensional Warfare: Chapter I
.accept 27513 >>Accept Transdimensional Warfare: Chapter II
.target Ambermill Dimensional Portal
step
#completewith TransdimensionalWarfareChapterIA
#title Enter the cave
.goto 21,60.24,72.20,10 >>|cRXP_WARN_Follow the arrow into the cave.|r
step
#requires TransdimensionalWarfareChapterIA
.goto 21,57.24,70.53,15,0
.goto 21,58.05,69.90
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Ambermill Dimensional Portal|r.
.turnin 27512 >>Turn in Transdimensional Warfare: Chapter I
.accept 27513 >>Accept Transdimensional Warfare: Chapter II
.target Ambermill Dimensional Portal
step
.subzoneskip 231,1
.isOnQuest 27513
.isQuestNotComplete 27513
.subzone 233 >>Click on the |cRXP_FRIENDLY_Ambermill Dimensional Portal|r.
.skipgossipid 37933
step
#completewith next
#label TransdimensionalWarfareChapterIIA
>>Kill the |cRXP_ENEMY_Ambermill Mages|r.
.complete 27513,1 
.mob Ambermill Mage
step
#title Leave the house
#completewith TransdimensionalWarfareChapterIIA
.goto 21,63.17,63.43,6,0
.goto 21,63.06,63.98,6,0
.goto 21,62.69,64.01,10 >>|cRXP_WARN_Follow the arrow out of the house.|r
step
#requires TransdimensionalWarfareChapterIIA
#loop
.goto 21,62.24,61.52,35,0
.goto 21,56.59,61.29,40,0
.goto 21,59.48,67.16,40,0
.goto 21,62.68,64.03,40,0
>>Kill the |cRXP_ENEMY_Ambermill Mages|r.
.complete 27513,1 
.mob Ambermill Mage
step
.goto 21,59.28,66.00
>>Click on the popup under your minimap.
.turnin 27513 >>Turn in Transdimensional Warfare: Chapter II
.accept 27518 >>Accept Transdimensional Warfare: Chapter III
step
.goto 21,56.64,64.36
>>Kill the |cRXP_ENEMY_Arcane Fiends|r.
.complete 27518,1 
step
.goto 21,51.97,66.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.turnin 27510 >>Turn in A Wolf in Bear's Clothing
.target High Warlord Cromush
step
.goto 21,51.90,65.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27518 >>Turn in Transdimensional Warfare: Chapter III
.turnin 27542 >>Turn in Taking the Battlefront
.target Lady Sylvanas Windrunner
step
.goto 21,51.90,65.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Godfrey|r, |cRXP_FRIENDLY_Lord Walden|r, and |cRXP_FRIENDLY_Baron Ashbury|r.
.accept 27550 >>Accept Pyrewood's Fall
.target +Lord Godfrey
.accept 27548 >>Accept Lessons in Fear
.target +Lord Walden
.accept 27547 >>Accept Of No Consequence
.target +Baron Ashbury
step
#completewith PyrewoodsFallA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Cowering Trooper|r.
>>Kill the |cRXP_ENEMY_7th Legion Scouts|r.
.complete 27548,1 
.complete 27547,1 
.mob 7th Legion Scout
step
.goto 21,46.18,73.44
>>Use the |T135432:0|t[Bundle of Torches]
.complete 27550,2 
.use 61374
step
.goto 21,44.97,71.78
>>Use the |T135432:0|t[Bundle of Torches]
.complete 27550,1 
.use 61374
step
#label PyrewoodsFallA
.goto 21,43.83,73.18
>>Use the |T135432:0|t[Bundle of Torches]
.complete 27550,3 
.use 61374
step
#loop
.goto 21,47.96,72.40,35,0
.goto 21,44.40,70.74,35,0
.goto 21,43.88,74.80,35,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Cowering Trooper|r.
>>Kill the |cRXP_ENEMY_7th Legion Scouts|r.
.complete 27548,1 
.complete 27547,1 
.mob 7th Legion Scout
step
.goto 21,44.44,73.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Godfrey|r, |cRXP_FRIENDLY_Baron Ashbury|r, and |cRXP_FRIENDLY_Lord Walden|r.
.turnin 27550 >>Turn in Pyrewood's Fall
.accept 27580 >>Accept Sowing Discord
.target +Lord Godfrey
.turnin 27547 >>Turn in Of No Consequence
.target +Baron Ashbury
.turnin 27548 >>Turn in Lesson in Fear
.accept 27577 >>Accept 7th Legion Battle Plans
.target +Lord Walden
step
.goto 21,42.72,78.07
>>Kill |cRXP_ENEMY_General Marstone|r and the |cRXP_ENEMY_Dwarven Infantry|r.
.complete 27580,1 
.complete 27577,1 
.mob General Marstone
.mob Dwarven Infantry
step
.goto 21,42.89,77.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Walden|r and |cRXP_FRIENDLY_Lord Godfrey|r.
.turnin 27577 >>Turn in 7th Legion Battle Plans
.target +Lord Walden
.turnin 27580 >>Turn in Sowing Discord
.accept 27594 >>Accept On Her Majesty's Secret Service
.target +Lord Godfrey
step
#label SilverpineHordeEnd
.goto 21,50.39,88.26
>>Kill |cRXP_ENEMY_Commander Lorna Crowley|r after the roleplay.
.complete 27594,1 
step
.goto 21,51.89,65.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r.
.turnin 27594 >>Turn in On Her Majesty's Secret Service
.target Lady Sylvanas Windrunner
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Hillsbrad Foothills
#internal
<< Horde
step
#completewith HillsbradHordeEnd
#hidewindow
+1
.usespell 1231411
step
.zoneskip 85,1
#completewith HillsbradHillsbradFoothills
.goto 85,56.02,88.25
.zone 110 >> Take the portal to Silvermoon
step
.zoneskip 18,1
#completewith HillsbradHillsbradFoothills
.goto 110,51.84,17.95,8,0
.goto 110,49.52,17.19,8,0
.goto 110,48.87,14.04,8,0
.goto 110,49.52,14.81
.zone 18 >>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Orb of Translocation|r.
step
#label HillsbradHillsbradFoothills
.isOnQuest 28089
.goto 25,29.24,63.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Darthalia|r.
.target High Executor Darthalia
.turnin 28089 >>Turn in Warchief's Command: Hillsbrad Foothills!
step
.goto 25,29.24,63.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Darthalia|r.
.target High Executor Darthalia
.accept 28096 >>Accept Welcome to the Machine
step
#completewith next
#label WelcomeToTheMachineA
>>Stay on the |cRXP_FRIENDLY_Steed|r and talk to the approaching |cRXP_FRIENDLY_NPCs|r.
.complete 28096,1 
.complete 28096,2 
.complete 28096,3 
step
#completewith WelcomeToTheMachineA
.goto 25,29.34,63.44
.vehicle 47488 >>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Skeletal Steed|r.
.timer 23,First Quest
.target Skeletal Steed
step
#requires WelcomeToTheMachineA
.goto 25,29.34,63.44
>>Stay on the |cRXP_FRIENDLY_Steed|r and talk to the approaching |cRXP_FRIENDLY_NPCs|r.
.complete 28096,1 
.timer 20,Second Quest
.complete 28096,2 
.timer 11,Third Quest
.complete 28096,3 
.skipgossip 1
step
.goto 25,29.24,63.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Darthalia|r.
.turnin 28096 >>Turn in Welcome to the Machine
.accept 28111 >>Accept Trouble at Azurelode
.target High Executor Darthalia
step
.goto 25,29.21,64.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Underhill|r.
.accept 28115 >>Accept Past Their Prime
.accept 28114 >>Accept Glorious Harvest
.target Apothecary Underhill
step
#title DON'T USE AOE ABILITIES
.goto 25,29.54,67.88,35,0
.goto 25,33.03,67.48,35,0
.goto 25,36.04,70.81,35,0
.goto 25,34.82,77.58,35,0
>>Kill |cRXP_ENEMY_Infested Bears|r.
>>|TInterface/cursor/crosshair/interact.blp:15|tClick on the |cRXP_PICK_Eggs|r on their back.
*|cRXP_WARN_Don't use AOE abilities otherwise you'll kill the Eggs|r. Each Bear has 8 Eggs.
.complete 28115,1 
.complete 28114,1 
step
.goto 25,33.29,73.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Keyton|r and |cRXP_FRIENDLY_Spider-Handler Sarus|r.
.turnin 28115 >>Turn in Past Their Prime
.turnin 28114 >>Turn in Glorious Harvest
.target +Spider-Handler Sarus
.turnin 28111 >>Turn in Trouble at Azurelode
.accept 28144 >>Accept Thieving Little Monsters!
.accept 28138 >>Accept Human Infestation
.target +Captain Keyton
step
#completewith DeepMineRescueC
>>|cRXP_WARN_Don't kill the humans|r. Use the |T134881:0|t[Titanium Shackles] at or below 35% HP.
.complete 28138,1 
.mob Hillsbrad Miner
.mob Hillsbrad Sentry
.use 63079
step
#completewith next
#label DeepMineRescueA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumass|r.
.accept 28156 >>Accept Deep Mine Rescue
.target Dumass
step
#completewith DeepMineRescueA
.goto 25,33.50,71.99,5 >>Enter the Mine
step
#requires DeepMineRescueA
.goto 25,35.71,71.51,10,0
.goto 25,36.63,70.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumass|r.
.accept 28156 >>Accept Deep Mine Rescue
.target Dumass
step
#completewith next
#label DeepMineRescueB
#hidewindow
.complete 28156,1 
step
#completewith DeepMineRescueB
#title Check for the rare
.goto 25,36.77,68.39,15 >>Kill |cRXP_ENEMY_Miasmiss|r if there.
.mob Miasmiss
step
#requires DeepMineRescueB
#label DeepMineRescueC
#title Leave the cave
.goto 25,33.29,73.58
>>Leave the cave
*|cRXP_WARN_Dumass follows you but he will randomly attack Miners so be careful not to lose him!|r.
.complete 28156,1 
.target Dumass
step
#title DON'T KILL THE HUMANS
.goto 25,33.32,72.59
>>Use the |T134881:0|t[Titanium Shackles] at or below 35% HP.
.complete 28138,1 
.mob Hillsbrad Miner
.mob Hillsbrad Sentry
.use 63079
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_ENEMY_Spider-Handler Sarus|r.
.goto 25,33.27,73.62
.accept 28146 >>Accept Coastal Delicacies!
.target Spider-Handler Sarus
step
.goto 25,33.30,73.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Keyton|r.
.turnin 28138 >>Turn in Human Infestation
.turnin 28156 >>Turn in Deep Mine Rescue
.target Captain Keyton
step
#completewith ThievingLittleMonstersA
>>Kill |cRXP_ENEMY_Muckgill|r. Loot him for [|cRXP_LOOT_Muckgill's Flipper|r]. |TInterface/cursor/crosshair/interact.blp:20|tClick it in your bags
.collect 63090,1,28154
.accept 28154 >>Accept Muckgill's Flipper or Something...
.mob Muckgill
.use 63090
step
#completewith ThievingLittleMonstersA
>>Kill |cRXP_ENEMY_murlocs|r in the area.
*Keep an eye out for the rare |cRXP_ENEMY_Scargil|r.
.complete 28146,1 
.mob Torn Fin Muckdweller
.mob Torn Fin Coastrunner
step
#label ThievingLittleMonstersA
#loop
.goto 25,31.37,75.71,25,0
.goto 25,32.52,79.91,25,0
.goto 25,34.47,81.14,25,0
.goto 25,35.81,81.72,25,0
.goto 25,37.60,80.94,25,0
.goto 25,32.60,79.96,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forsaken Camp "Supplies"
.complete 28144,1 
step
#loop
.goto 25,31.66,75.20,25,0
.goto 25,32.51,77.91,25,0
>>Kill |cRXP_ENEMY_Muckgill|r. Loot him for [|cRXP_LOOT_Muckgill's Flipper|r]. |TInterface/cursor/crosshair/interact.blp:20|tClick it in your bags
.collect 63090,1,28154
.accept 28154 >>Accept Muckgill's Flipper or Something...
.mob Muckgill
.use 63090
step
#loop
.goto 25,31.66,75.20,35,0
.goto 25,33.06,79.18,35,0
.goto 25,35.69,80.73,35,0
.goto 25,38.07,80.57,40,0
>>Kill |cRXP_ENEMY_murlocs|r in the area.
*Keep an eye out for the rare |cRXP_ENEMY_Scargil|r.
.complete 28146,1 
.mob Torn Fin Muckdweller
.mob Torn Fin Coastrunner
step
#completewith next
#label CoastalHumanThievingRescueSomethingA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spider-Handler Sarus|r and |cRXP_FRIENDLY_Captain Keyton|r.
.turnin 28146 >>Turn in Coastal Delicacies!
.turnin 28138 >>Turn in Human Infestation
.turnin 28144 >>Turn in Thieving Little Monsters!
.turnin 28156 >>Turn in Deep Mine Rescue
.turnin 28154 >>Turn in Muckgill's Flipper or Something...
.accept 28168 >>Accept Trouble at the Sludge Fields
.target Spider-Handler Sarus
.target Captain Keyton
step
#completewith CoastalHumanThievingRescueSomethingA
#title Check for the rare
.goto 25,35.08,78.48,25 >>Check for the rare |cRXP_ENEMY_Little Bjorn|r.
.mob Little Bjorn
step
#requires CoastalHumanThievingRescueSomethingA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spider-Handler Sarus|r and |cRXP_FRIENDLY_Captain Keyton|r.
.turnin 28146 >>Turn in Coastal Delicacies!
.turnin 28138 >>Turn in Human Infestation
.goto 25,33.27,73.67
.target +Spider-Handler Sarus
.turnin 28144 >>Turn in Thieving Little Monsters!
.turnin 28156 >>Turn in Deep Mine Rescue
.turnin 28154 >>Turn in Muckgill's Flipper or Something...
.accept 28168 >>Accept Trouble at the Sludge Fields
.goto 25,33.30,73.54
.target +Captain Keyton
step
.goto 25,36.22,61.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Stillwater|r.
.turnin 28168 >>Turn in Trouble at the Sludge Fields
.accept 28192 >>Accept No One Here Gets Out Alive
.turnin 28192 >>Turn in No One Here Gets Out Alive
.accept 28197 >>Accept Discretion is Key
.target Warden Stillwater
step
#completewith SilverpineForScience
.goto 25,35.85,61.26
.home >>Set your Hearthstone to The Sludge Fields
step
#completewith next
.goto 25,36.12,60.68
.vendor >> Vendor any trash you have.
step
.goto 25,36.34,60.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flesh-Shaper Arnauld|r.
.accept 28199 >>Accept For Science!
.target Flesh-Shaper Arnauld
step
#completewith DoTheRightThingA
>>Kill the |cRXP_ENEMY_zombies|r in the area. Loot them for some [|cRXP_LOOT_samples|r].
.complete 28199,1 
.mob Risen Hillsbrad Peasant
.mob Risen Hillsbrad Farmer
step
#loop
.goto 25,37.82,63.37,20,0
.goto 25,38.26,63.19,20,0
>>Kill |cRXP_ENEMY_Clerk Horrace|r. Loot him for the [|cRXP_LOOT_The Battle for Hillsbrad|r].
.complete 28197,2 
.collect 63249,1,28196
.accept 28196 >>Accept The Battle for Hillsbrad
.mob Clerk Horrace Whitesteed
.use 63249
step
.goto 25,39.73,63.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shovel|r.
.accept 28189 >>Accept Do the Right Thing
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Human Seedlings|r.
.complete 28189,1 
.target Human Seedling
step
.goto 25,38,98,64.71
>>Kill |cRXP_ENEMY_Citizen Wilkes|r
.complete 28197,1 
.mob Citizen Wilkes
step
#label DoTheRightThingA
.goto 25,39.14,63.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Human Seedlings|r.
.complete 28189,1 
.target Human Seedling
step
.goto 25,38.45,63.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest popup under your minimap or search for the quest in your quest log
.turnin 28189 >>Turn in Do the Right Thing
step
>>Kill the |cRXP_ENEMY_zombies|r in the area. Loot them for some [|cRXP_LOOT_samples|r].
.complete 28199,1 
.mob Risen Hillsbrad Peasant
.mob Risen Hillsbrad Farmer
step
#label SilverpineForScience
.goto 25,36.34,60.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flesh-Shaper Arnauld|r.
.turnin 28199 >>Turn in For Science!
.target Flesh-Shaper Arnauld
step
.goto 25,36.18,61.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Stillwater|r.
.turnin 28196 >>Turn in The Battle for Hillsbrad
.turnin 28197 >>Turn in Discretion is Key
.accept 28206 >>Accept A Lost Lad
.target Warden Stillwater
step
#title DON'T KILL THE GUARDS
.goto 25,40.33,59.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Johnny Awesome|r and |cRXP_FRIENDLY_Master Apothecary Lydon|r.
.turnin 28206 >>Turn in A Lost Lad
.target +Johnny Awesome
.accept 28209 >>Accept Freedom for Lydon
.target +Master Apothecary Lydon
step
#completewith next
#label FreedomForLydonA
>>Kill |cRXP_ENEMY_Infected Sludge Guards|r. Loot them for |T237379:0|t[|cRXP_LOOT_Lydon's Cage Key|r].
.complete 28209,1 
.mob Infected Sludge Guard
step
#completewith FreedomForLydonA
.goto 25,39.55,60.36,15 >>Check |cRXP_PICK_Chest|r location.
step
#requires FreedomForLydonA
.goto 25,38.97,59.66
>>Kill |cRXP_ENEMY_Infected Sludge Guards|r. Loot them for |T237379:0|t[|cRXP_LOOT_Lydon's Cage Key|r].
.complete 28209,1 
.mob Infected Sludge Guard
step
#completewith HillsbradHeadOfWardenStillwater
+|cRXP_WARN_If you can't see |cRXP_FRIENDLY_Lydon|r or |cRXP_FRIENDLY_Johnny|r dismount and wait until they respawn|r.
step
.goto 25,40.25,59.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Apothecary Lydon|r.
.turnin 28209 >>Turn in Freedom for Lydon
.accept 28230 >>Accept Protocol
.target Master Apothecary Lydon
step
.goto 25,40.25,59.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Johnny Awesome|r.
.accept 28231 >>Accept Do it for Twinkles
.target Johnny Awesome
step
.goto 25,38.37,56.61
>>Kill the |cRXP_ENEMY_Monstrosity|r and |cRXP_ENEMY_Verringtan|r.
.complete 28230,1 
.complete 28231,1 
.mob The Ray-Getz-Kalaba Monstrosity
.mob Blacksmith Verringtan
step
.goto 25,38.22,56.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Johnny Awesome|r and |cRXP_FRIENDLY_Master Apothecary Lydon|r.
.turnin 28230 >>Turn in Protocol
.target +Johnny Awesome
.turnin 28231 >>Turn in Do it for Twinkles
.accept 28235 >>Accept Burnside Must Fall
.target +Master Apothecary Lydon
step
.goto 25,36.64,58.00
>>Kill |cRXP_ENEMY_Magistrate Burnside|r.
.complete 28235,1 
.mob Magistrate Burnside
step
.goto 25,36.65,58.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Apothecary Lydon|r.
.turnin 28235 >>Turn in Burnside Must Fall
.accept 28237 >>Accept A Blight Upon the Land
.target Master Apothecary Lydon
step
.goto 25,36.37,61.16
>>Kill |cRXP_ENEMY_Warden Stillwater|r. Loot him for the |T134179:0|t[|cRXP_LOOT_Head of Warden Stillwater|r].
*|cRXP_WARN_NOTE:|r Make sure to face |cRXP_ENEMY_Warden Stillwater|r to the house because he will knock you back.
.complete 28237,1 
.mob Warden Stillwater
step
#label HillsbradHeadOfWardenStillwater
.goto 25,36.65,61.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Apothecary Lydon|r.
.turnin 28237 >>Turn in A Blight Upon the Land
.accept 28251 >>Accept Trouble at Southshore
.target Master Apothecary Lydon
step
.goto 25,49.10,66.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Serge Hinott|r.
>>Keep an eye out for the rare |cRXP_ENEMY_Alitus|r.
.turnin 28251 >>Turn in Green Living
.accept 28325 >>Accept Green Living
.accept 28324 >>Accept Studies in Lethality
.target Serge Hinott
.mob Alitus
step
#completewith AngryScrubbingBubblesA
>>Use the |T307036:0|t[Lethality Analyzer] on the |cRXP_ENEMY_slimes|r in the area.
*|cRXP_WARN_Remember that you can also just |TInterface/cursor/crosshair/interact.blp:20|tClick on the slimes to use the item|r.
.complete 28324,1 
.mob Blight Slime
.use 63426
step
#completewith AngryScrubbingBubblesA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Used Blight Canisters|r.
.complete 28325,1 
step
.goto 25,48.73,72.07
>>Kill an |cRXP_ENEMY_Angry Blight Slime|r.
.accept 28329 >>Accept Angry Scrubbing Bubbles
.mob Angry Blight Slime
step
#title DRAIN BEFORE KILLING
#label AngryScrubbingBubblesA
#loop
.goto 25,49.20,72.21,15,0
.goto 25,46.27,73.67,20,0
.goto 25,47.20,70.96,20,0
.goto 25,48.71,72.55,25,0
>>Kill |cRXP_ENEMY_Angry Blight Slimes|r.
*|cRXP_WARN_NOTE:|r Set your pet to passive if you want to drain them before killing them. << Hunter/Warlock
.complete 28329,1 
.mob Angry Blight Slime
step
.goto 25,48.71,72.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest popup under your minimap or search for the quest in your quest log
.turnin 28329 >>Turn in Angry Scrubbing Bubbles
.accept 28330 >>Accept Trail of Filth
step
#completewith next
#label TrailOfFilthA
#hidewindow
>>Kill |cRXP_ENEMY_Chet|r inside the house. |cRXP_WARN_You can drain him to make the fight easier|r.
.complete 28330,1 
.mob Chet the Slime-Breeder
step
#completewith TrailOfFilthA
#title Check for the rare
.goto 25,46.89,75.48,10 >>Check for the rare |cRXP_ENEMY_Carcinak|r.
.mob Carcinak
step
#requires TrailOfFilthA
#completewith next
#label TrailOfFilthB
>>Kill |cRXP_ENEMY_Chet|r inside the house. |cRXP_WARN_You can drain him to make the fight easier|r.
.complete 28330,1 
.mob Chet the Slime-Breeder
step
#requires TrailOfFilthA
#completewith TrailOfFilthB
#title Enter the house
.goto 25,48.34,72.26,8 >>|cRXP_WARN_Follow the arrow into the house.|r
step
#requires TrailOfFilthB
.goto 25,47.87,72.44
>>Kill |cRXP_ENEMY_Chet|r inside the house. |cRXP_WARN_You can drain him to make the fight easier|r.
.complete 28330,1 
.mob Chet the Slime-Breeder
step
#completewith next
>>Use the |T307036:0|t[Lethality Analyzer] on the |cRXP_ENEMY_slimes|r in the area.
*|cRXP_WARN_Remember that you can also just |TInterface/cursor/crosshair/interact.blp:20|tClick on the slimes to use the item|r.
.complete 28324,1 
.mob Blight Slime
.use 63426
step
#loop
.goto 25,50.86,68.27,30,0
.goto 25,49.15,71.34,30,0
.goto 25,48.79,69.12,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Used Blight Canisters|r.
.complete 28325,1 
step
#loop
.goto 25,48.73,73.12,35,0
.goto 25,49.82,68.50,35,0
.goto 25,46.39,72.43,50,0
>>Use the |T307036:0|t[Lethality Analyzer] on the |cRXP_ENEMY_slimes|r in the area.
*|cRXP_WARN_Remember that you can also just |TInterface/cursor/crosshair/interact.blp:20|tClick on the slimes to use the item|r.
.complete 28324,1 
.mob Blight Slime
.use 63426
step
.goto 25,49.57,74.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kingslayer Orkus|r.
.accept 28345 >>Accept *Gurgle* HELP! *Gurgle*
.complete 28345,1 
.target Kingslayer Orkus
.skipgossip 1
step
.goto 25,50.02,74.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kingslayer Orkus|r.
.turnin 28345 >>Turn in *Gurgle* HELP! *Gurgle*
.accept 28348 >>Accept Stormpike Rendezvous
.turnin 28348 >>Turn in Stormpike Rendezvous
.accept 28354 >>Accept Kasha Will Fly Again
.target Kingslayer Orkus
step
.goto 25,51.62,74.95
>>Kill |cRXP_ENEMY_Daggerspine|r. Loot him for the |T237386:0|t[|cRXP_LOOT_Daggerspine Attack Plans|r].
.collect 63686,1,28356,0
.accept 28356 >>Accept Preemptive Strike
.mob Daggerspine
.use 63686
step
#completewith next
.mob Lady Zephris
.goto 25,54.92,76.36,15 >>Try to target the rare |cRXP_ENEMY_Lady Zephris|r.
step
>>Kill |cRXP_ENEMY_Daggerspine Nagas|r.
.goto 25,54.34,77.17,25,0
.goto 25,55.11,81.10
.complete 28356,1 
.mob Daggerspine Shorestalker
.mob Daggerspine Shorehunter
.mob Daggerspine Screamer
.mob Daggerspine Siren
step
#completewith MudsnoutGnollOrShamanSlain
#hidewindow
#loop
.goto 25,57.16,75.18,25,0
.goto 25,58.12,72.31,25,0
.goto 25,57.72,74.66,25,0
+1
step
#completewith next
>>Pick up the |cRXP_PICK_Mushrooms|r.
.goto 25,57.72,74.66,0,0
.complete 28354,1 
step
>>Kill a |cRXP_ENEMY_Mudsnout Gnoll|r or |cRXP_ENEMY_Shaman|r. |cRXP_WARN_on the field|r.
*If this doesn't trigger after the first kill, turn on "Low Level Quests" in your tracking menu next to the minimap.
.accept 28355 >>Accept Terrible Little Creatures
.mob Mudsnout Gnoll
.mob Mudsnout Shaman
step
#completewith next
>>Kill |cRXP_ENEMY_Mudsnout Gnolls|r or |cRXP_ENEMY_Shamans|r.
>>Keep an eye out for the rare |cRXP_ENEMY_Ro'Bark|r and a |cRXP_PICK_chest|r.
.complete 28355,1 
.mob Mudsnout Gnoll
.mob Mudsnout Shaman
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mudsnout Blossoms|r.
.complete 28354,1 
step
#label MudsnoutGnollOrShamanSlain
>>Kill |cRXP_ENEMY_Mudsnout Gnolls|r or |cRXP_ENEMY_Shamans|r.
>>Keep an eye out for the rare |cRXP_ENEMY_Ro'Bark|r and a |cRXP_PICK_chest|r.
.complete 28355,1 
.mob Mudsnout Gnoll
.mob Mudsnout Shaman
step
.goto 25,57.16,75.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest popup under your minimap or search for the quest in your quest log
.turnin 28355 >>Turn in Terrible Little Creatures
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Jekyll|r and |cRXP_FRIENDLY_Nils Beerot|r.
.accept 28635 >>Accept A Haunting in Hillsbrad
.accept 28643 >>Accept The Durnholde Challenge: Zephyrus
.goto 25,60.01,63.34
.accept 28634 >>Accept Extinction
.goto 25,60.14,63.76
.target Captain Jekyll
.target Nils Beerot
step
#loop
.goto 25,63.52,60.82,25,0
.goto 25,63.05,57.45,25,0
.goto 25,64.42,57.03,25,0
.goto 25,65.50,54.18,25,0
.goto 25,63.61,52.69,25,0
.goto 25,67.46,54.00,25,0
.goto 25,68.89,55.88,25,0
.goto 25,71.22,57.08,25,0
.goto 25,73.03,59.96,25,0
>>Kill |cRXP_ENEMY_Rampaging Owlbeasts|r.
*Keep an eye out for the rares |cRXP_ENEMY_Big Samras|r and |cRXP_ENEMY_Lopex|r.
.complete 28634,1 
.mob Rampaging Owlbeast
step
#completewith next
+|cRXP_WARN_The following elementals are VERY DIFFICULT. You can skip them|r.
step
>>Kill |cRXP_ENEMY_Zephyrus|r.
*Run away when it summons a Tornado
.goto 25,68.64,59.43
.use 141295
.complete 28643,1 
.mob Zephyrus
step
.isQuestComplete 28643
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest popup under your minimap or search for the quest in your quest log
.turnin 28643 >>Turn in The Durnholde Challenge: Zephyrus
.accept 28644 >>Accept The Durnholde Challenge: Teracula
step
.isOnQuest 28644
>>Kill |cRXP_ENEMY_Teracula|r.
*Dodge or interrupt the Rupture Line
.goto 25,67.28,59.86
.use 141295
.complete 28644,1 
.mob Teracula
step
.isQuestComplete 28644
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest popup under your minimap or search for the quest in your quest log
.turnin -28644 >>Turn in The Durnholde Challenge: Teracula
.accept 28645 >>Accept The Durnholde Challenge: Bloodvenom
step
.isOnQuest 28645
>>Kill |cRXP_ENEMY_Bloodvenom|r.
*Move out of the blue void zones
.goto 25,66.26,60.10
.use 141295
.complete 28645,1 
.mob Bloodvenom
step
.isQuestComplete 28645
.goto 25,66.26,60.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest popup under your minimap or search for the quest in your quest log
.turnin 28645 >>Turn in The Durnholde Challenge: Bloodvenom
.accept 28646 >>Accept The Durnholde Challenge: Infernus
step
.isOnQuest 28646
>>Kill |cRXP_ENEMY_Infernus|r.
*|cRXP_WARN_This one is very hard without a pet because he will disorient you periodically|r.
.goto 25,68.01,63.17
.complete 28646,1 
.mob Infernus
step
.isQuestComplete 28646
>>You may have to |TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under the minimap
.turnin 28646 >>Turn in The Durnholde Challenge: Infernus
.accept 28647 >>Accept The Durnholde Challenge: D-1000
step
.isOnQuest 28647
>>Kill |cRXP_ENEMY_D-1000|r.
*|cRXP_WARN_This one is also very hard because of his hard hitting melee hits|r.
.goto 25,70.27,61.05
.complete 28647,1 
.mob D-1000
step
#completewith next
#label DunGarokA
#hidewindow
>>Follow the arrow
.complete 28635,1 
step
#completewith DunGarokA
.goto 25,77.05,59.90,30 >>Search for Zorn
.unitscan Zorn
.goto 14,26.26,28.21,30 >>Search for Snuffles and Singer
.unitscan Singer
.unitscan Snuffles
.goto 14,18.87,31.20,30 >>Search for Ruul Onestone
.unitscan Ruul Onestone
step
#requires DunGarokA
.goto 25,61.75,83.93
>>Follow the arrow
.complete 28635,1 
step
.goto 25,61.78,84.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Ironhill's Ghost|r.
.turnin 28635 >>Turn in A Haunting in Hillsbrad
.accept 28636 >>Accept Silence of the Dwarves
.target Captain Ironhill's Ghost
step
#loop
.goto 25,63.16,87.01,15,0
.goto 25,63.31,86.61,15,0
.goto 25,63.20,85.71,20,0
.goto 25,62.43,83.75,25,0
>>Kill |cRXP_ENEMY_Dun Garok Spirits|r.
*Keep an eye out for the rare |cRXP_ENEMY_Tamra Stormpike|r.
.complete 28636,1 
.mob Dun Garok Spirit
step
.isQuestComplete 28647
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Jekyll|r and |cRXP_FRIENDLY_Nils Beerot|r.
.turnin 28636 >>Turn in Silence of the Dwarves
.goto 25,59.98,63.36
.turnin 28634 >>Turn in Extinction
.turnin 28647 >>Turn in The Durnholde Challenge: D-1000
.goto 25,60.06,63.66
.target Captain Jekyll
.target Nils Beerot
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Jekyll|r and |cRXP_FRIENDLY_Nils Beerot|r.
.turnin 28636 >>Turn in Silence of the Dwarves
.goto 25,59.98,63.36
.turnin 28634 >>Turn in Extinction
.goto 25,60.06,63.66
.target Captain Jekyll
.target Nils Beerot
step
.abandon 28643 >>Abandon The Durnholde Challenge: Zephyrus
.abandon 28644 >>Abandon The Durnholde Challenge: Teracula
.abandon 28645 >>Abandon The Durnholde Challenge: Bloodvenom
.abandon 28646 >>Abandon The Durnholde Challenge: Infernus
.abandon 28647 >>Abandon The Durnholde Challenge: D-1000
step
.goto 25,49.13,66.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Serge Hinott|r and |cRXP_FRIENDLY_Helcular|r.
.turnin 28324 >>Turn in Studies in Lethality
.turnin 28330 >>Turn in Trail of Filth
.target Serge Hinott
.turnin 28325 >>Turn in Green Living
.turnin 28356 >>Turn in Preemptive Strike
.target Helcular
step
.goto 25,50.00,74.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kingslayer Orkus|r.
.turnin 28354 >>Turn in Kasha Will Fly Again
.accept 28375 >>Accept The Road to Purgation
.target Kingslayer Orkus
step
.goto 25,29.25,83.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kingslayer Orkus|r.
.turnin 28375 >>Turn in The Road to Purgation
.accept 28397 >>Accept They Will Never Expect This...
.target Kingslayer Orkus
step
#title DON'T PULL TOO MUCH
.goto 25,27.55,84.22
>>Kill |cRXP_ENEMY_Bloodfang Sentries|r and |cRXP_ENEMY_Stormpike Dwarves|r in the area.
*Be careful these NPCs deal a lot of damage.
*Keep an eye out for the rare |cRXP_ENEMY_Dustwing|r.
.complete 28397,2 
.complete 28397,1 
.mob Bloodfang Sentry
.mob Stormpike Dwarf
step
.goto 25,27.28,88.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_ENEMY_Kingslayer Orkus|r next to you.
*Type '/reload' into the chat if you can't turn in the quest
.turnin 28397 >>Turn in They Will Never Expect This...
.accept 28400 >>Accept Heroes of the Horde!
.target Kingslayer Orkus
step
.goto 25,27.35,87.35
>>Follow the path up the mountain
*Wait next to |cRXP_FRIENDLY_Orkus|r until you can talk to him.
>>Loot the |cRXP_ENEMY_Stormpike Battle Master|r after he has killed him.
.complete 28400,1 
.timer 150,Flight Duration
.skipgossip 1
step
.goto 25,57.48,46.87
>>Wait for the roleplay.
.complete 28400,2 
step
.goto 25,56.75,47.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Advisor Duskingdawn|r.
.accept 28495 >>Accept A Fighting Chance
.target Advisor Duskingdawn
step
.goto 25,57.08,46.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.turnin 28400 >>Turn in Heroes of the Horde!
.accept 28587 >>Accept Aid of the Frostwolf
.target High Warlord Cromush
step
.goto 25,56.99,45.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Bel'varil|r.
.accept 28484 >>Accept The Heart of the Matter
.target Keeper Bel'varil
step
#title Read note
.goto 25,57.16,45.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathguard Humbert|r and |cRXP_FRIENDLY_Samsa|r.
*|cRXP_WARN_NOTE:|r If you jump backwards while standing on the stairs you can accept the quest from downstairs. Otherwise go up the stairs in the building.
.accept 28487 >>Accept Humbert's Personal Problems
.accept 28485 >>Accept Yetimus the Yeti Lord
.target Deathguard Humbert
.target Samsa
step
.goto 25,58.70,34.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Voggah Deathgrip|r.
.turnin 28587 >>Turn in Aid of the Frostwolf
.accept 28600 >>Accept Matters of Loyalty
.target Voggah Deathgrip
step
#completewith next
#label MattersOfLoyaltyA
#hidewindow
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.turnin 28600 >>Turn in Matters of Loyalty
.accept 28506 >>Accept March of the Stormpike
.target High Warlord Cromush
step
#completewith MattersOfLoyaltyA
.goto 25,60.37,28.92,20 >>Check for the rare |cRXP_FRIENDLY_Maggarrak|r above the AV tunnel.
.mob Maggarrak
step
#requires MattersOfLoyaltyA
.goto 25,57.08,46.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.turnin 28600 >>Turn in Matters of Loyalty
.accept 28506 >>Accept March of the Stormpike
.target High Warlord Cromush
step
.goto 25,57.08,46.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.turnin 28506 >>Turn in March of the Stormpike
.accept 28556 >>Accept Breaking the Hand
.target High Warlord Cromush
step
.goto 25,57.27,46.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r.
.accept 28538 >>Accept Cry of the Banshee
.target Melisara
step
#completewith next
.goto 25,55.48,38.34,0,0
>>Use the |T237030:0|t[Goblin Pocket-Nuke] at the waypoint location
.complete 28556,1 
.use 64471
step
#title Use item at 35%
#loop
.goto 25,55.50,38.46,35,0
.goto 25,55.64,40.70,35,0
>>Damage the |cRXP_FRIENDLY_Assassins|r until 35% HP and use the |T458243:0|t[Banshee Mirror].
>>Keep an eye out for a |cRXP_PICK_chest|r.
.complete 28538,1 
.mob SI:7 Assassin
.use 64445
step
.goto 25,55.48,38.34
>>Use the |T237030:0|t[Goblin Pocket-Nuke] at the waypoint location
.complete 28556,1 
.use 64471
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 28538 >>Turn in Cry of the Banshee
.accept 28566 >>Accept Decimation
step
#completewith DecimationA
.goto 25,49.40,46.69,0,0
>>Use the |T237030:0|t[Goblin Pocket-Nuke] at the waypoint location
.complete 28556,2 
.use 64471
step
#completewith next
>>Kill |cRXP_ENEMY_Stormpike Soldiers|r.
.complete 28566,2 
.mob Stormpike Soldier
step
#loop
.goto 25,50.20,46.59,15,0
.goto 25,49.46,46.82,15,0
.goto 25,49.46,46.76,15,0
>>Kill |cRXP_ENEMY_Captain Iceheart|r (he's patrolling).
.complete 28566,1 
.mob Captain Iceheart
step
#label DecimationA
#loop
.goto 25,49.43,48.22,20,0
.goto 25,50.20,46.59,20,0
.goto 25,48.88,47.05,20,0
>>Kill |cRXP_ENEMY_Stormpike Soldiers|r.
.complete 28566,2 
.mob Stormpike Soldier
step
.goto 25,49.40,46.69
>>Use the |T237030:0|t[Goblin Pocket-Nuke] at the waypoint location
.complete 28556,2 
.use 64471
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 28566 >>Turn in Decimation
.accept 28603 >>Accept Infiltration
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilith|r next to you.
.accept 28604 >>Accept Deception and Trickery
.target Lilith
step
#completewith next
#label DeceptionInfiltrationA
#hidewindow
>>Use the |T132814:0|t[Water Barrel] next to |cRXP_FRIENDLY_Stormpike Trainees|r.
*|cRXP_WARN_Don't use the item again until you get credit for the last trainees|r.
.complete 28604,1 
.target Stormpike Trainee
.use 64583
step
#completewith DeceptionInfiltrationA
.goto 25,49.88,50.38,25 >>Check for the rare |cRXP_ENEMY_Jimmy the Bleeder|r and check for chest
.mob Jimmy the Bleeder
step
#requires DeceptionInfiltrationA
#completewith HillsbradTurninInfiltration
>>Use the |T132814:0|t[Water Barrel] next to |cRXP_FRIENDLY_Stormpike Trainees|r.
*|cRXP_WARN_Don't use the item again until you get credit for the last trainees|r.
.complete 28604,1 
.target Stormpike Trainee
.use 64583
step
#requires DeceptionInfiltrationA
#completewith DeceptionInfiltrationC
.goto 25,43.97,48.99,0,0
>>Use the |T237030:0|t[Goblin Pocket-Nuke] at the waypoint location
.complete 28556,3 
.use 64471
step
#requires DeceptionInfiltrationA
#label DeceptionInfiltrationB
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Rufus|r and kill him.
>>Kill |cRXP_ENEMY_Captain Crudbeard|r.
.complete 28603,1 
.goto 25,44.51,49.07
.mob +Instructor Rufus
.complete 28603,3 
.goto 25,44.31,50.39
.mob +Captain Crudbeard
.skipgossip
step
#completewith next
#label DeceptionInfiltrationD
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drill Sergeant Magnus|r.
*|cRXP_WARN_NOTE:|r You have to stay in melee range otherwise he may evade.
.complete 28603,2 
.target Drill Sergeant Magnus
.skipgossip
step
#completewith DeceptionInfiltrationD
.goto 25,44.20,52.32,10 >>Check possible |cRXP_PICK_Chest|r location.
.goto 25,44.32,53.83,25 >>Check for the rare |cRXP_ENEMY_Araga|r.
.unitscan Araga
step
#requires DeceptionInfiltrationD
#title Read the note
.goto 25,43.41,49.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drill Sergeant Magnus|r.
*|cRXP_WARN_NOTE:|r You have to stay in melee range otherwise he may evade.
.complete 28603,2 
.target Drill Sergeant Magnus
.skipgossip
step
#label HillsbradTurninInfiltration
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in your quest log under your minimap
.turnin 28603 >>Turn in Infiltration
step
#label DeceptionInfiltrationC
#title Read the note
#loop
.goto 25,44.65,48.99,20,0
.goto 25,44.14,50.89,20,0
.goto 25,44.16,52.43,20,0
.goto 25,44.14,50.89,20,0
>>Use the |T132814:0|t[Water Barrel] next to |cRXP_FRIENDLY_Stormpike Trainees|r.
*|cRXP_WARN_NOTE:|r Don't use the item again until you get credit for the last trainees.
.complete 28604,1 
.target Stormpike Trainee
.use 64583
step
.goto 25,43.97,48.99
>>Use the |T237030:0|t[Goblin Pocket-Nuke] at the waypoint location
.complete 28556,3 
.use 64471
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilith|r next to you.
.turnin 28604 >>Turn in Deception and Trickery
.accept 28605 >>Accept Domination
.target Lilith
step
#completewith next
>>Kill |cRXP_ENEMY_Stormpike Engineers|r.
.complete 28605,1 
.mob Stormpike Engineer
step
.goto 25,39.48,49.06
>>Use the |T237030:0|t[Goblin Pocket-Nuke] at the waypoint location
.complete 28556,4 
.use 64471
step
.goto 25,39.93,48.52
>>Kill |cRXP_ENEMY_Stormpike Engineers|r.
.complete 28605,1 
.mob Stormpike Engineer
step
#completewith next
>>Use |T135468:0|t[Duskingdawn's Wand] on the |cRXP_FRIENDLY_Fawns|r.
*|cRXP_WARN_Make sure to stay far away from the fawns otherwise they may attack you which will result in your death|r.
.complete 28495,1 
.use 64416
step
#completewith next
#label BeatingYetiHeartA
>>Kill |cRXP_ENEMY_Cave Yetis|r. Loot them for their [|cRXP_LOOT_hearts|r].
.complete 28484,1 
.mob Cave Yeti
step
#completewith BeatingYetiHeartA
.goto 25,46.62,54.41,10 >>Enter the cave
step
#requires BeatingYetiHeartA
#completewith HumbertsPersonalProblemsA
>>Kill |cRXP_ENEMY_Cave Yetis|r. Loot them for their [|cRXP_LOOT_hearts|r].
.complete 28484,1 
.mob Cave Yeti
step
#requires BeatingYetiHeartA
#title Don't jump down
.goto 25,45.09,51.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_glowing sword|r.
.complete 28487,1 
step
.goto 25,45.53,52.26,8,0
.goto 25,45.86,51.54,10,0
.goto 25,44.58,50.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_small helm|r.
.complete 28487,2 
step
#completewith next
#label HumbertsPersonalProblemsB
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_pants|r.
.complete 28487,3 
step
#completewith HumbertsPersonalProblemsB
.goto 25,45.86,51.54,20,0
.goto 25,45.77,53.39,20 >>Check for the rare |cRXP_FRIENDLY_Weevil|r.
.unitscan Weevil
step
#requires HumbertsPersonalProblemsB
#label HumbertsPersonalProblemsA
.goto 25,43.79,55.16,15,0
.goto 25,44.09,53.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_pants|r.
.complete 28487,3 
step
>>Kill |cRXP_ENEMY_Cave Yetis|r. Loot them for their [|cRXP_LOOT_hearts|r].
.complete 28484,1 
.mob Cave Yeti
step
#completewith AFightingChanceA
.isOnQuest 28485
.goto 25,48.37,56.74,0,0
>>|cRXP_WARN_VERY HARD Elite. Might not even kill him with Heirlooms|r.
*Within a party you should be able to kill him. You can skip this.
.complete 28485,1 
step
#completewith next
#label AFightingChanceB
#hidewindow
>>Use |T135468:0|t[Duskingdawn's Wand] (you don't have to target them).
*|cRXP_WARN_Make sure to stay far away from the fawns otherwise they may attack you which will result in your death|r.
.complete 28495,1 
.use 64416
step
#completewith AFightingChanceB
.goto 25,45.51,52.11,10,0
.goto 25,44.78,53.30,15,0
.goto 25,46.51,54.28,10 >>Leave the cave
step
#requires AFightingChanceB
#label AFightingChanceA
#loop
.goto 25,44.61,57.82,30,0
.goto 25,45.22,60.38,30,0
.goto 25,48.77,55.69,20,0
.goto 25,50.03,55.52,30,0
.goto 25,48.56,53.08,30,0
.goto 25,48.77,55.69,30,0
.goto 25,40.93,56.11,40,0
>>Use |T135468:0|t[Duskingdawn's Wand] (you don't have to target them).
*|cRXP_WARN_Make sure to stay far away from the fawns otherwise they may attack you which will result in your death|r.
.complete 28495,1 
.use 64416
step
.isOnQuest 28485
.goto 25,48.37,56.74
>>|cRXP_WARN_VERY HARD Elite. Might not even kill him with Heirlooms|r.
*Within a party you should be able to kill him. You can skip this.
.complete 28485,1 
step
#completewith next
#label AFightingChanceC
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Advisor Duskingdawn|r.
.turnin 28495 >>Turn in A Fighting Chance
.target Advisor Duskingdawn
step
#title Check for the rare
#completewith AFightingChanceC
.goto 25,55.86,54.57,35 >>Check for the rare |cRXP_ENEMY_Chordix|r.
.mob Chordix
step
#requires AFightingChanceC
.goto 25,56.74,47.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Advisor Duskingdawn|r.
.turnin 28495 >>Turn in A Fighting Chance
.target Advisor Duskingdawn
step
.goto 25,57.25,46.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r.
.turnin 28605 >>Turn in Domination
.target Melisara
step
.goto 25,57.08,46.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Warlord Cromush|r.
.turnin 28556 >>Turn in Breaking the Hand
.accept 28616 >>Accept Stormpike Apocalypse
.turnin 28616 >>Turn in Stormpike Apocalypse
.target High Warlord Cromush
step
#label HillsbradHordeEnd
.goto 25,57.00,45.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Bel'varil|r.
.turnin 28484 >>Turn in The Heart of the Matter
.target Keeper Bel'varil
step
.isQuestComplete 28485
.goto 25,57.19,45.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathguard Samsa|r.
.turnin 28485 >>Turn in Yetimus the Yeti Lord
.target Deathguard Samsa
step
.abandon 28485
step
.goto 25,57.16,45.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathguard Humbert|r.
.turnin 28487 >>Turn in Humbert's Personal Problems
.target Deathguard Humbert
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Hinterlands
#internal
<< Horde
step
#completewith HinterlandsHordeEnd
#hidewindow
+1
.usespell 1231411
step
.goto 26,31.83,58.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Surlis|r.
.accept 26382 >>Accept Can't Make An Omelette Without...
.target Apothecary Surlis
step
.goto 26,31.87,58.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkcleric Marnal|r.
.accept 26381 >>Accept The Eye of Shadra
.target Darkcleric Marnal
step
.goto 26,45.49,38.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cache of Shadra|r.
.complete 26381,1 
step
#loop
.goto 26,48.22,40.49,25,0
.goto 26,46.55,42.96,32,0
.goto 26,44.08,43.15,35,0
.goto 26,45.49,38.83,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadraspawn Eggs|r.
.complete 26382,1 
step
.goto 26,31.86,58.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkcleric Marnal|r.
.turnin 26381 >>Turn in The Eye of Shadra
.accept 26406 >>Accept The Fang of Shadra
.target Darkcleric Marnal
step
.goto 26,31.83,58.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Surlis|r.
.turnin 26382 >>Turn in Can't Make An Omelette Without...
.accept 26387 >>Accept Starvation Diet
.target Apothecary Surlis
step
.goto 26,49.50,52.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cache of Shadra|r.
.complete 26406,1 
step
.goto 26,48.92,52.44
>>Kill |cRXP_ENEMY_Cocooned Victim|r.
.complete 26387,1 
.mob Cocooned Victim
step
.goto 26,31.87,58.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkcleric Marnal|r.
.turnin 26406 >>Turn in The Fang of Shadra
.accept 26418 >>Accept The Shell of Shadra
.target Darkcleric Marnal
step
.goto 26,48.44,67.82
>>Kill |cRXP_ENEMY_Qiaga the Keeper|r. Loot her for the |T134321:0|t[|cRXP_LOOT_Shell of Shadra|r].
.complete 26418,1 
.mob Qiaga the Keeper
step
.goto 26,67.80,66.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kotonga|r.
.accept 26357 >>Accept Faces of Evil
.target Kotonga
step
.goto 26,67.81,66.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Primal Torntusk|r.
.accept 26366 >>Accept Heads Up
.accept 26306 >>Accept Start Taking Back
.target Primal Torntusk
step
.goto 26,67.65,66.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eliza Darkgrin|r.
.accept 26310 >>Accept All That Skitters
.target Eliza Darkgrin
step
.goto 26,65.13,64.93
>>Kill |cRXP_ENEMY_Umboda Three-Heads|r. Loot him for |T1:0|t[|cRXP_LOOT_Umboda's Head|r].
.complete 26366,1 
.mob Umboda Three-Heads
step
#completewith StartTakingBackA
#hidewindow
#loop
.goto 26,65.21,70.35,25,0
.goto 26,67.00,70.97,25,0
.goto 26,69.09,69.22,25,0
.goto 26,65.15,65.20,25,0
+1
step
#completewith FacesOfEvilA
>>Kill |cRXP_ENEMY_Vilebranch Headhunter|r and |cRXP_ENEMY_Vilebranch Witch Doctor|r.
.complete 26306,1 
.complete 26306,2 
.mob Vilebranch Headhunter
.mob Vilebranch Witch Doctor
step
#completewith FacesOfEvilA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_Skittering Spiderlings|r.
.complete 26310,1 
.mob Skittering Spiderling
step
#label FacesOfEvilA
>>Use the |T135432:0|t[Tiki Torch] next to the |cRXP_PICK_Tiki Masks|r.
.complete 26357,1 
.use 58209
step
#completewith next
>>Kill |cRXP_ENEMY_Vilebranch Headhunter|r and |cRXP_ENEMY_Vilebranch Witch Doctor|r.
.complete 26306,1 
.complete 26306,2 
.mob Vilebranch Headhunter
.mob Vilebranch Witch Doctor
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_ENEMY_Skittering Spiderlings|r.
.complete 26310,1 
.mob Skittering Spiderling
step
#label StartTakingBackA
>>Kill |cRXP_ENEMY_Vilebranch Headhunter|r and |cRXP_ENEMY_Vilebranch Witch Doctor|r.
.complete 26306,1 
.complete 26306,2 
.mob Vilebranch Headhunter
.mob Vilebranch Witch Doctor
step
.goto 26,67.64,66.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eliza Darkgrin|r.
.turnin 26310 >>Turn in All That Skitters
.target Eliza Darkgrin
step
.goto 26,67.82,66.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Primal Torntusk|r.
.turnin 26366 >>Turn in Heads Up
.turnin 26306 >>Turn in Start Taking Back
.target Primal Torntusk
step
.goto 26,67.78,66.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kotonga|r.
.turnin 26357 >>Turn in Faces of Evil
.target Kotonga
step
.goto 26,78.80,78.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mystic Yayo'jin|r.
.accept 26240 >>Accept Stomp To My Beat
.target Mystic Yayo'jin
step
.goto 26,79.14,79.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntsman Markhor|r.
.accept 26223 >>Accept Stalking the Stalkers
.target Huntsman Markhor
step
.goto 26,80.34,81.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Katoom the Angler|r.
.accept 26210 >>Accept Gammerita, Mon!
.accept 26211 >>Accept Snapjaws, Mon!
.target Katoom the Angler
step
.goto 26,78.13,81.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lard|r.
.accept 26212 >>Accept Lard Lost His Lunch
.target Lard
step
.goto 26,77.71,81.61,8,0
.goto 26,77.75,82.17,8,0
.goto 26,78.12,81.70,8,0
.goto 26,78.18,81.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Torntusk|r.
.accept 26238 >>Accept The Savage Dwarves
.accept 26263 >>Accept Thornar Thunderclash
.target Elder Torntusk
step
#completewith LardLostHisLunchA
>>Kill |cRXP_ENEMY_Saltwater Snapjaw|r.
.complete 26211,1 
.mob Saltwater Snapjaw
step
.goto 26,75.87,70.59
>>Kill |cRXP_ENEMY_Gammerita|r. Loot it for |T1:0|t[|cRXP_LOOT_Katoom's Best Lure|r].
.complete 26210,1 
.mob Gammerita
step
#label LardLostHisLunchA
.goto 26,84.47,41.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Lard's Picnic Basket|r.
>>Kill the |cRXP_ENEMY_Vilebranch Kidnapper|r. Loot him for |T134016:0|t[|cRXP_LOOT_Lard's Lunch|r].
.complete 26212,1 
.mob Vilebranch Kidnapper
step
#loop
.goto 26,76.46,73.96,35,0
.goto 26,77.38,63.01,35,0
.goto 26,81.76,37.57,55,0
>>Kill |cRXP_ENEMY_Saltwater Snapjaw|r.
.complete 26211,1 
.mob Saltwater Snapjaw
step
.goto 26,70.90,48.51
>>Kill |cRXP_ENEMY_Thornar Thunderclash|r.
.complete 26263,1 
.mob Thornar Thunderclash
step
#completewith TheSavageDwarvesA
#hidewindow
#loop
.goto 26,73.21,48.37,30,0
.goto 26,70.78,51.75,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Wildhammer|r.
.complete 26238,1 
.mob Wildhammer Warrior
.mob Wildhammer Shaman
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Revantusk Stalker|r.
.complete 26240,1 
.target Revantusk Stalker
step
#label TheSavageDwarvesA
>>Kill |cRXP_ENEMY_Wildhammer|r.
.complete 26238,1 
.mob Wildhammer Warrior
.mob Wildhammer Shaman
step
#loop
.goto 26,78.44,49.90,35,0
.goto 26,69.90,61.91,35,0
.goto 26,66.19,59.24,35,0
>>Kill |cRXP_ENEMY_Silvermane Stalker|r.
.complete 26223,1 
.mob Silvermane Stalker
step
.goto 26,78.80,78.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mystic Yayo'jin|r.
.turnin 26240 >>Turn in Stomp To My Beat
.target Mystic Yayo'jin
step
.goto 26,79.16,79.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntsman Markhor|r.
.turnin 26223 >>Turn in Stalking the Stalkers
.accept 26224 >>Accept Hunt the Savages
.target Huntsman Markhor
step
.goto 26,80.34,81.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Katoom the Angler|r.
.turnin 26211 >>Turn in Snapjaws, Mon!
.turnin 26210 >>Turn in Gammerita, Mon!
.target Katoom the Angler
step
.goto 26,78.14,81.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lard|r.
.turnin 26212 >>Turn in Lard Lost His Lunch
.target Lard
step
.goto 26,77.71,81.61,8,0
.goto 26,77.75,82.17,8,0
.goto 26,78.12,81.70,8,0
.goto 26,78.18,81.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Torntusk|r.
.turnin 26238 >>Turn in The Savage Dwarves
.turnin 26263 >>Turn in Thornar Thunderclash
.accept 26267 >>Accept Skulk Rock Clean-Up
.accept 26268 >>Accept Skulk Rock Supplies
.target Elder Torntusk
step
.goto 26,78.05,78.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malcom Fendelson|r.
.accept 26283 >>Accept Prime Slime
.target Malcom Fendelson
step
#completewith SkulkRockSuppliesA
>>Kill |cRXP_ENEMY_Jade Ooze|r.
.complete 26267,1 
.mob Jade Ooze
step
#completewith next
#label PrimeSlimeA
>>Kill |cRXP_ENEMY_The Direglob|r. Loot it for the |T134717:0|t[|cRXP_LOOT_Direglob Sample|r].
*|cRXP_WARN_NOTE:|r Make sure you're full HP and have damage cooldowns or cc ready.
.complete 26283,1 
.mob The Direglob
step
#completewith PrimeSlimeA
#title Enter the cave
.goto 26,57.48,39.13,10 >>|cRXP_WARN_Follow the arrow into the cave.|r
step
#requires PrimeSlimeA
.goto 26,57.59,41.59
>>Kill |cRXP_ENEMY_The Direglob|r. Loot it for the |T134717:0|t[|cRXP_LOOT_Direglob Sample|r].
*|cRXP_WARN_NOTE:|r Make sure you're full HP and have damage cooldowns or cc ready.
.complete 26283,1 
.mob The Direglob
step
#label SkulkRockSuppliesA
#loop
.goto 26,55.51,44.67,35,0
.goto 26,57.50,41.54,30,0
.goto 26,60.52,42.07,30,0
.goto 26,57.50,41.54,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ooze-coated Supply Crates|r.
.complete 26268,1 
step
#completewith next
#label SkulkRockCleanUpA
>>Kill |cRXP_ENEMY_Jade Ooze|r.
.complete 26267,1 
.mob Jade Ooze
step
#completewith SkulkRockCleanUpA
#title Leave the cave
.goto 26,57.13,42.55,10,0
.goto 26,58.39,41.99,10,0
.goto 26,57.42,38.42,20 >>|cRXP_WARN_Follow the arrow out of the cave.|r
step
#requires SkulkRockCleanUpA
#loop
.goto 26,60.29,43.84,35,0
.goto 26,56.75,45.70,35,0
.goto 26,55.75,38.77,35,0
>>Kill |cRXP_ENEMY_Jade Ooze|r.
.complete 26267,1 
.mob Jade Ooze
step
#optional
.isOnQuest 485
.goto 26,49.35,37.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r.
.turnin 485 >>Turn in Find OOX-09/HL!
.target Homing Robot OOX-09/HL
step
#loop
.goto 26,60.70,40.66,35,0
.goto 26,65.22,55.98,35,0
.goto 26,53.68,57.19,35,0
.goto 26,52.55,45.70,35,0
>>Kill |cRXP_ENEMY_Savage Owlbeast|r.
.complete 26224,1 
.mob Savage Owlbeast
step
.goto 26,78.05,78.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malcom Fendelson|r.
.turnin 26283 >>Turn in Prime Slime
.target Malcom Fendelson
step
.goto 26,79.16,79.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntsman Markhor|r.
.turnin 26224 >>Turn in Hunt the Savages
.target Huntsman Markhor
step
.goto 26,78.17,81.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Torntusk|r.
.turnin 26267 >>Turn in Skulk Rock Clean-Up
.turnin 26268 >>Turn in Skulk Rock Supplies
.target Elder Torntusk
step
.goto 26,31.86,58.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkcleric Marnal|r.
.turnin 26418 >>Turn in The Shell of Shadra
.accept 26558 >>Accept Summoning Shadra
.target Darkcleric Marnal
step
.goto 26,32.04,67.12
>>Use the |T135442:0|t[Idol of Shadra].
.complete 26558,1 
.use 58784
step
.goto 26,32.50,76.36
>>Use the |T135442:0|t[Idol of Shadra].
.complete 26558,3 
.use 58784
step
.goto 26,37.17,71.57
>>Use the |T135442:0|t[Idol of Shadra].
.complete 26558,2 
.use 58784
step
.goto 26,35.65,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathstalker Lookout|r.
.turnin 26558 >>Turn in Summoning Shadra
.accept 26419 >>Accept Shadra the Venom Queen
.target Deathstalker Lookout
step
#label HinterlandsHordeEnd
#title Wait for the Undead
.goto 26,34.51,69.64
>>Kill |cRXP_ENEMY_Shadra|r.
.complete 26419,1 
.mob Shadra
step
.goto 26,31.87,58.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkcleric Marnal|r.
.turnin 26419 >>Turn in Shadra the Venom Queen
.target Darkcleric Marnal
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Kun-Lai Summit
#internal
<< Horde
step
#completewith KunlaiSummitHordeEnd
#hidewindow
+1
.usespell 1231411
step
.convertquest 30514,30515 << Horde
.convertquest 30583,31251 << Horde
.convertquest 30593,30594 << Horde
.convertquest 30619,30620 << Horde
.convertquest 30652,30657 << Horde
.convertquest 30650,30655 << Horde
.convertquest 30651,30656 << Horde
.convertquest 30660,30661 << Horde
step
.zoneskip 85
.isQuestAvailable 30460
.use 140192
.zone 627 >>Use Dalaran Hearthstone
step
.isQuestAvailable 30460
.goto 627,55.28,23.95
.zone 85 >>Take the portal to Orgrimmar
step
.goto 85,40.82,80.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
.accept 60126 >>Accept Mists of Pandaria: To Pandaria!
.chromietime 8
.skipgossipid 51901
.skipgossipid 51902
.target Chromie
step
.goto 85,49.88,75.57
>>|cRXP_WARN_Follow the arrow.|r
.complete 60126,1 
step
>>Click on the quest popup under your minimap.
.turnin 60126 >>Turn in Mists of Pandaria: To Pandaria!
.target Nedaridea
step
.isQuestAvailable 30460
.goto 85,57.45,92.22
.zone 371 >>Take the Portal to Jade Forest in Orgrimmar
step << Monk
#include RestedXP Speed Leveling\a) Monk Quests
step
.goto 379,71.57,92.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Cheng|r.
.accept 30460 >>Accept Hit Medicine
.target Apothecary Cheng
step
.goto 379,72.27,91.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Bramblestaff|r.
.accept 30457 >>Accept Call Out Their Leader
.target Mayor Bramblestaff
step
.goto 379,70.75,90.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Hsieh|r.
.accept 30459 >>Accept All of the Arrows
.target Commander Hsieh
step
#completewith Dit Da Jow
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
#completewith Dit Da Jow
>>Use |T132798:0|t[Dit Da Jow] on |cRXP_FRIENDLY_Injured Binan Warrior|r.
*|cRXP_WARN_Prioritize your own healing spells, if you have any|r.
.complete 30460,1 
.use 79819
.target Injured Binan Warrior
step
#loop
.goto 379,70.52,89.43,25,0
.goto 379,70.15,90.44,25,0
.goto 379,69.23,90.44,25,0
.goto 379,67.59,89.61,25,0
.goto 379,67.58,88,25,0
.goto 379,68.66,86.9,25,0
>>Kill |cRXP_ENEMY_Taurens|r
.complete 30457,1 
.mob Bataari Flamecaller
.mob Bataari Yaungol
step
#label Dit Da Jow
#loop
.goto 379,68.05,88.35,25,0
.goto 379,69.46,89.2,25,0
#title |cFFFCDC00NPC Patrols|r
>>Kill |cRXP_ENEMY_Bataari Fire-Warrior|r
.complete 30457,2 
step
#hidewindow
#completewith Commander Hsieh
#loop
.goto 379,67.44,87.67,30,0
.goto 379,70.72,89.26,30,0
.goto 379,69.94,91.13,30,0
.goto 379,67.66,91.12,30,0
.goto 379,66.61,89.04,30,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
>>Use |T132798:0|t[Dit Da Jow] on |cRXP_FRIENDLY_Injured Binan Warrior|r.
*|cRXP_WARN_Prioritize your own healing spells, if you have any|r.
.complete 30460,1 
.use 79819
.target Injured Binan Warrior
step
#label Injured Binan Warrior
>>Kill |cRXP_ENEMY_Bataari Tribe Members|r and |cRXP_ENEMY_Bataari Fire-Warrior|r. |cRXP_WARN_he spawns after killing 10x |cRXP_ENEMY_Bataari Tribe Members|r|r.
.complete 30457,1 
.complete 30457,2 
.mob Bataari Flamecaller
.mob bataari fire-warrior
.mob Bataari Yaungol
step
#label Commander Hsieh
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
.goto 379,70.76,90.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Hsieh|r.
.turnin 30459 >>Turn in All of the Arrows
.target Commander Hsieh
step
.goto 379,72.27,91.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Bramblestaff|r.
.turnin 30457 >>Turn in Call Out Their Leader
.target Mayor Bramblestaff
step
.goto 379,71.57,92.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Cheng|r.
.turnin 30460 >>Turn in Hit Medicine
.target Apothecary Cheng
.accept 30511 >>Accept General Nazgrim has Awakened
step
.goto 379,71.48,93.18,5,0
.goto 379,71.65,93.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.turnin 30511 >>Turn in General Nazgrim has Awakened
.accept 30513 >>Accept Eastwind Rest
.target General Nazgrim
step
#include a) Kun-Lai Summit My Son
step
.goto 379,75.21,88.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Waterspeaker Gorai|r.
.accept 30480 >>Accept The Ritual
.target Waterspeaker Gorai
step
.goto 379,75.21,88.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Waterspeaker Gorai|r.
.complete 30480,1 
.timer 34,RP
.target Waterspeaker Gorai
.skipgossipid 38108
step
.goto 379,74.84,88.60
>>Kill |cRXP_ENEMY_Explosive Hatred|r.
.complete 30480,3 
.timer 14,RP
.mob Explosive Hatred
step
.goto 379,74.90,88.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Waterspeaker Gorai|r.
.turnin 30480 >>Turn in The Ritual
.target Waterspeaker Gorai
step
#include a) Kun-Lai Summit Despoiler
step
.goto 379,63.68,86.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Ko|r.
.complete 30513,1 
.target Farmhand Ko
.skipgossip 63751,1
step
.goto 379,61.20,82.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.complete 30513,2 
.skipgossip 63535,1
.target Elder Shiao
step
.goto 379,61.19,82.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.turnin 30513 >>Turn in Eastwind Rest
.accept 30515 >>Accept Challenge Accepted
.target Elder Shiao
step
#completewith next
.goto 379,58.19,84.11
.cast 8386 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r to summon |cRXP_ENEMY_Ur-Bataar|r.
step
#completewith next
#label Ur-Bataar
>>Kill the waves and |cRXP_ENEMY_Ur-Bataar|r.
.complete 30514,1 
.mob Ur-Bataar
step
#completewith Ur-Bataar
.goto 379,58.19,84.11
.cast 8386 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r
step
#requires Ur-Bataar
.goto 379,58.20,84.35
>>Kill the waves and |cRXP_ENEMY_Ur-Bataar|r.
.complete 30514,1 
.mob Ur-Bataar

step << Horde
.goto 379,61.58,80.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.turnin 30515 >>Turn in Challenge Accepted
.target Elder Shiao
step << Horde
.goto 379,63.00,80.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.accept 31256 >>Accept Round 'Em Up
.target General Nazgrim
step << Horde
.goto 379,62.70,80.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r.
.accept 30594 >>Accept Deanimate the Reanimated
.target Shademaster Kiryn
step << Horde
.goto 379,62.78,79.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r.
.accept 31251 >>Accept Best Meals Anywhere!
.target Rivett Clutchpop
step << Horde
.goto 379,62.53,79.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Ko|r.
.accept 30570 >>Accept Trouble on the Farmstead
.target Farmhand Ko
step << Horde
.goto 379,62.33,79.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.accept 30620 >>Accept Mogu?! Oh No-gu!
.target Elder Shiao

step
#completewith next
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
step
.goto 379,59.61,78.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bao Jian|r.
.accept 30595 >>Accept Profiting off of the Past
.target Bao Jian
step
#loop
.goto 379,58.84,76.29,40,0
.goto 379,57.77,76.89,40,0
.goto 379,56.62,76.53,40,0
.goto 379,56.88,75.53,40,0
.goto 379,57.96,74.50,40,0
.goto 379,59.28,73.51,40,0
.goto 379,59.98,75.57,20,0
.goto 379,58.84,76.29,0
.goto 379,57.77,76.89,0
.goto 379,56.62,76.53,0
.goto 379,56.88,75.53,0
.goto 379,57.96,74.50,0
.goto 379,59.28,73.51,0
.goto 379,59.98,75.57,0
>>Kill |cRXP_ENEMY_Mogu's|r.
*Loot them for |T454065:0|t[|cRXP_LOOT_Mogu Relic|r].
>>|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Relics|r
.complete 30593,1 
.complete 30595,1 
.mob Terracotta Guardian
.mob Terracotta Warrior
step
.goto 379,58.13,70.92
>>Kill |cRXP_ENEMY_Mogujia Soul-caller|r.
.complete 30619,1 
.mob Mogujia Soul-caller
step
.goto 379,59.60,78.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bao Jian|r.
.turnin 30595 >>Turn in Profiting off of the Past
.target Bao Jian
step
#completewith next
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Chow|r and |cRXP_FRIENDLY_Uyen Chow|r.
.turnin 30570 >>Turn in Trouble on the Farmstead << Horde
.accept 30571 >>Accept Farmhand Freedom
.goto 379,60.25,85.81
.accept 30581 >>Accept ... and the Pot, Too!
.goto 379,60.17,85.93
.target Uyen Chow
.target Farmer Chow
step
#completewith Farmstead Slaves
#hidewindow
#loop
.goto 379,60.88,86.97,40,0
.goto 379,61.29,86.14,40,0
.goto 379,61.92,87.15,40,0
.goto 379,61.87,87.85,40,0
.goto 379,61.31,87.85,40,0
.goto 379,61.41,88.37,40,0
.goto 379,60.79,88.00,40,0
.goto 379,60.50,87.52,40,0
.goto 379,58.87,88.61,40,0
.goto 379,58.38,88.40,40,0
.goto 379,58.31,89.41,40,0
.goto 379,58.33,90.11,40,0
.goto 379,58.85,90.11,40,0
.goto 379,58.95,89.78,40,0
.goto 379,60.88,86.97,0
.goto 379,61.29,86.14,0
.goto 379,61.92,87.15,0
.goto 379,61.87,87.85,0
.goto 379,61.31,87.85,0
.goto 379,61.41,88.37,0
.goto 379,60.79,88.00,0
.goto 379,60.50,87.52,0
.goto 379,58.87,88.61,0
.goto 379,58.38,88.40,0
.goto 379,58.31,89.41,0
.goto 379,58.33,90.11,0
.goto 379,58.85,90.11,0
.goto 379,58.95,89.78,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Ordo Overseer|r to rescue |cRXP_FRIENDLY_Farmstead Slaves|r.
.complete 30571,1 
.mob Ordo Raider
.mob Ordo Overseer
step
>>Kill |cRXP_ENEMY_Wascally Wirmen|r.
*Loot them for |T250625:0|t[|cRXP_LOOT_Root Vegetables|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Root Vegetables|r.
.complete 30581,1 
.mob Wascally Wirmen
step
#label Farmstead Slaves
>>Kill |cRXP_ENEMY_Ordo Overseer|r to rescue |cRXP_FRIENDLY_Farmstead Slaves|r.
.complete 30571,1 
.mob Ordo Raider
.mob Ordo Overseer
step
.goto 379,60.09,88.24,5,0
.goto 379,60.02,88.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Root Vegetable|r |cRXP_WARN_inside the small house|r.
.complete 30581,2 
.mob Cookie McYaungol
step
#label Back to Westwind Rest
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uyen Chow|r and |cRXP_FRIENDLY_Farmer Chow|r.
.turnin 30581 >>Turn in ... and the Pot, Too!
.goto 379,60.17,85.92
.turnin 30571 >>Turn in Farmhand Freedom
.accept 31253 >>Accept Back to Eastwind Rest
.goto 379,60.24,85.8
.target Uyen Chow
.target Farmer Chow
step
#loop
.goto 379,57.58,87.26,30,0
.goto 379,54.05,88.74,30,0
.goto 379,53.26,90.94,30,0
.goto 379,51.9,88.52,30,0
.goto 379,52.11,84.21,30,0
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on 3x |cRXP_PICK_Wild Plains Yak|r
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
.mob Wild Plains Yak
step
.goto 379,62.71,79.82
>>Make sure 3x |cRXP_FRIENDLY_Captured Yak|r are following you.
*|cRXP_WARN_If not click on 3x |cRXP_PICK_Wild Plains Yak|r|r
*Bring them to |cRXP_FRIENDLY_Farmhand Bo|r
.complete 31256,1 
.target Captured Yak
.target Farmhand Bo

step
.goto 379,62.78,79.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r.
.turnin 31251 >>Turn in Best Meals Anywhere!
.target Rivett Clutchpop
step
.goto 379,62.54,79.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Ko|r.
.turnin 31253 >>Turn in Back to Eastwind Rest
.target Farmhand Ko
step
.goto 379,62.34,79.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shiao|r.
.turnin 30620 >>Turn in Mogu?! Oh No-gu!
.accept 30655 >>Accept Pandaren Prisoners
.target Elder Shiao
step
.goto 379,62.73,79.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r.
.accept 30656 >>Accept Barrels of Fun
.target Rivett Clutchpop
step
.goto 379,63.00,80.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.turnin 31256 >>Turn in Round 'Em Up
.target General Nazgrim
.accept 30657 >>Accept In Tents Channeling
step
.goto 379,62.69,80.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r.
.turnin 30594 >>Turn in Deanimate the Reanimated
.target Shademaster Kiryn

step
#completewith Ordo Warbringer
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pandaren Prisoners|r.
.complete 30650,1 
.target Pandaren Prisoner
step
#completewith next
#label Eastern Oil Rig
#hidewindow
.complete 30651,1 
step
#completewith Eastern Oil Rig
.goto 379,51.25,79.27
.collect 80528,1,30651,1 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
step
#requires Eastern Oil Rig
#completewith next
#label Eastern Oil Rig2
#hidewindow
.complete 30651,1 
step
#requires Eastern Oil Rig
#completewith Eastern Oil Rig2
.goto 379,50.97,79.53
.cast 115550 >>Use |T252176:0|t[Explosives Barrel] next to the rig.
.use 80528
step
#requires Eastern Oil Rig2
#label Musaan
.goto 379,50.4,78.66
>>Kill |cRXP_ENEMY_Musaan the Blazecaster|r.
.complete 30652,1 
.mob musaan the blazecaster
step
.goto 379,49.44,78.49
>>Kill |cRXP_ENEMY_Harala the Firespeaker|r.
.complete 30652,3 
.mob harala the firespeaker
step
#completewith next
#label Southern Oil Rig
#hidewindow
.complete 30651,2 
step
#completewith Southern Oil Rig
.goto 379,49.57,78.96
.collect 80528,1,30651,2 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
step
#requires Southern Oil Rig
#completewith next
#label Southern Oil Rig2
#hidewindow
.complete 30651,2 
step
#requires Southern Oil Rig
#completewith Southern Oil Rig2
.goto 379,49.62,81.04
.cast 115550 >>Use |T252176:0|t[Explosives Barrel] next to the rig.
.use 80528
step
#requires Southern Oil Rig2
#completewith next
#label Pao-kun
>>Kill |cRXP_ENEMY_Pao-kun the Pyromancer|r.
.complete 30652,4 
.mob Pao-kun the Pyromancer
step
#requires Southern Oil Rig2
#completewith Pao-kun
.goto 379,49.35,81.07
.collect 80528,1,30651,3 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
step
#requires Pao-kun
.goto 379,49.17,80.38
>>Kill |cRXP_ENEMY_Pao-kun the Pyromancer|r.
.complete 30652,4 
.mob Pao-kun the Pyromancer
step
#requires Pao-kun
#completewith next
#label Western Oil Rig
#hidewindow
.complete 30651,3 
step
#completewith Western Oil Rig
.goto 379,47.86,81.42
.cast 115550 >>Use the |T252176:0|t[Explosives Barrel] next to the rig.
.use 80528
step
#requires Western Oil Rig
.goto 379,47.70,80.05
>>Kill |cRXP_ENEMY_Akonu the Embercaller|r.
.complete 30652,2 
.mob Akonu the Embercaller
step
.goto 379,48.9,76.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the questlog to turn in the quest.
.turnin 30652 >>Turn in In Tents Channeling
.accept 30660 >>Accept The Ordo Warbringer
step
#completewith next
#label Ordo Warbringer
.goto 379,48.9,76.89,10,0
>>Kill |cRXP_ENEMY_Ordo Warbringer|r.
.complete 30660,1 
.mob ordo warbringer
step
#title Enter Cave
#completewith Ordo Warbringer
.goto 379,48.37,76.70,25 >> Enter the cave.
step
#requires Ordo Warbringer
#label Ordo Warbringer2
.goto 379,48.37,76.70
>>Kill |cRXP_ENEMY_Ordo Warbringer|r.
.complete 30660,1 
.mob ordo warbringer
step
#loop
.goto 379,49.60,78.64,40,0
.goto 379,51.11,79.30,40,0
.goto 379,51.59,79.85,40,0
.goto 379,49.41,80.91,40,0
.goto 379,47.71,80.24,40,0
.goto 379,49.60,78.64,0
.goto 379,51.11,79.30,0
.goto 379,51.59,79.85,0
.goto 379,49.41,80.91,0
.goto 379,47.71,80.24,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pandaren Prisoners|r.
.complete 30650,1 
.target Pandaren Prisoner
step
#include a) Kun-Lai Summit Defense Shado-Pan

step
.goto 379,62.32,80.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.turnin 30655 >>Turn in Pandaren Prisoners
.turnin 30661 >>Turn in The Ordo Warbringer
.target General Nazgrim
step
.goto 379,62.77,79.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r.
.turnin 30656 >>Turn in Barrels of Fun
.target Rivett Clutchpop
step
.goto 379,62.69,80.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r.
.accept 31459 >>Accept Cho's Missive
.target Shademaster Kiryn
step
.goto 379,62.32,80.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r.
.turnin 30655 >>Turn in Pandaren Prisoners
.turnin 30661 >>Turn in The Ordo Warbringer
.target General Nazgrim
step
.goto 379,65.48,60.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slimy Inkstain|r.
.turnin 30614 >>Turn in Oil Stop
.target Slimy Inkstain
step
.goto 379,64.71,61.76,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Eightcoins|r.
.turnin 30808 >>Turn in A Grummle's Luck
.target Lucky Eightcoins
step
.goto 379,64.89,60.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey Sootassle|r.
.turnin 30616 >>Turn in Traffic Issues
.accept 30617 >>Accept Roadside Assistance
.target Smokey Sootassle

step
#loop
.goto 379,64.11,59.07,20,0
.goto 379,62.91,62.03,20,0
.goto 379,62.85,63.05,20,0
.goto 379,62.79,63.80,20,0
.goto 379,62.95,64.57,20,0
.goto 379,62.44,64.45,20,0
.goto 379,62.04,64.90,20,0
.goto 379,61.73,65.37,20,0
.goto 379,61.18,65.59,20,0
.goto 379,60.37,66.00,20,0
.goto 379,59.96,65.27,20,0
.goto 379,59.33,65.10,20,0
.goto 379,58.91,64.33,20,0
.goto 379,59.00,63.81,20,0
.goto 379,58.73,63.09,20,0
.goto 379,58.81,62.48,20,0
.goto 379,58.34,62.13,20,0
.goto 379,58.35,61.63,20,0
.goto 379,62.91,62.03,0
.goto 379,62.85,63.05,0
.goto 379,62.79,63.80,0
.goto 379,62.95,64.57,0
.goto 379,62.44,64.45,0
.goto 379,62.04,64.90,0
.goto 379,61.73,65.37,0
.goto 379,61.18,65.59,0
.goto 379,60.37,66.00,0
.goto 379,59.96,65.27,0
.goto 379,59.33,65.10,0
.goto 379,58.91,64.33,0
.goto 379,59.00,63.81,0
.goto 379,58.73,63.09,0
.goto 379,58.81,62.48,0
.goto 379,58.34,62.13,0
.goto 379,58.35,61.63,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Lucky Burlap Incense|r |cRXP_WARN_(possible while mounted)|r.
.complete 30617,1 
step
.goto 379,58.1,61.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Trailscenter|r.
.turnin 30617 >>Turn in Roadside Assistance
.accept 30592 >>Accept The Burlap Trail: To Burlap Waystation
.target Brother Trailscenter
step
.goto 379,57.34,61.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.turnin 31459 >>Turn in Cho's Missive
.accept 30999 >>Accept Path Less Traveled
.target Lorewalker Cho
step
.goto 379,57.23,61.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Cloverleaf|r.
.turnin 30999 >>Turn in Path Less Traveled
.accept 30601 >>Accept Instant Courage
.target Uncle Cloverleaf
step
#completewith next
#label Resupplying One Keg
.goto 379,57.69,61.58,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.accept 30618 >>Accept Resupplying One Keg
.target Big Sal
step
#completewith Resupplying One Keg
.goto 379,57.72,61.77,10 >>Enter the House
step
#requires Resupplying One Keg
.goto 379,57.72,61.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.accept 30618 >>Accept Resupplying One Keg
.target Big Sal
step
#completewith next
#label They Stole My Luck!
.goto 379,57.5,60.17,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside the house|r.
.accept 30621 >>Accept They Stole My Luck!
.target Ji-Lu the Lucky
step
#completewith They Stole My Luck!
.goto 379,57.33,60.19,10 >>Enter the House
step
#requires They Stole My Luck!
.goto 379,57.33,60.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside the house|r.
.accept 30621 >>Accept They Stole My Luck!
.target Ji-Lu the Lucky
step
#hidewindow
#completewith next
#label Lucky Virmen's Foot
.goto 379,59.12,52.86,20,0
.complete 30621,1 
step
#completewith Lucky Virmen's Foot
.goto 380,65.55,83.73,40 >>Enter the Cave
step
#requires Lucky Virmen's Foot
#hidewindow
#completewith Snow Piles
#loop
.goto 380,65.55,83.73,20,0
.goto 380,70.76,69.22,25,0
.goto 380,57.68,74.3,25,0
.goto 380,51.64,72.75,25,0
.goto 380,46.08,57.42,25,0
.goto 380,54.25,54.77,25,0
.goto 380,44.57,24.37,25,0
.goto 380,34.92,27.67,25,0
.goto 380,30.96,39.6,25,0
.goto 380,41.6,43.88,25,0
.goto 380,32.49,41.53,20,0
.goto 380,34.39,34.35,20,0
.goto 380,49.4,30.45,20,0
+1
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>Kill each |cRXP_ENEMY_Sprite|r seperately as only 1 item can drop at a time.
*Loot them for |T237176:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guides|r.
.complete 30601,1 
.skipgossip
.target Hiding Guide
step
#requires Lucky Virmen's Foot
#label Stolen Sprite Treasure
.turnin 31415 >> |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Treasure|r.
step
#completewith Hiding Guide
>>Kill each |cRXP_ENEMY_Sprite|r seperately as only 1 item can drop at a time.
*Loot them for |T237176:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
#completewith Hiding Guide
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#label Hiding Guide
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guides|r.
.complete 30601,1 
.skipgossip
.target Hiding Guide
step
#completewith next
>>Kill |cRXP_ENEMY_Sprites|r.
*Loot them for |T651358:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#label Snow Piles
>>Kill |cRXP_ENEMY_Sprites|r.
*Loot them for |T651358:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
.isQuestComplete 30621
.goto 379,59.14,53.15,25 >>Leave the Cave
step
#completewith next
#label TheyStoleMyLuck
.goto 379,57.5,60.17,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside small house|r.
.turnin 30621 >>Turn in They Stole My Luck!
.target Ji-Lu the Lucky
step
#completewith TheyStoleMyLuck
.goto 379,57.32,60.19,15 >>Enter the House
step
#requires TheyStoleMyLuck
.goto 379,57.32,60.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside small house|r.
.turnin 30621 >>Turn in They Stole My Luck!
.target Ji-Lu the Lucky
step
.goto 379,57.72,61.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.turnin 30618 >>Turn in Resupplying One Keg
.target Big Sal
step
.goto 379,57.22,61.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Cloverleaf|r.
.turnin 30601 >>Turn in Instant Courage
.accept 30487 >>Accept Comin' Round the Mountain
.target Uncle Cloverleaf
step
.isOnQuest 30487
#completewith ZuldazarTheTempleofRezan
>>Repair your gear
.goto 379,57.43,61.75
.vendor
step
.goto 379,57.30,61.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Ji-Lu's Cart|r.
.complete 30487,1 
.timer 125,RP
.target Ji-Lu's Cart
step
.goto 379,48.13,48.92
>>Wait for the roleplay
.complete 30487,2 
step
.goto 379,48.13,49.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Bluestring|r.
.turnin 30487 >>Turn in Comin' Round the Mountain
.target Lucky Bluestring
.accept 30683 >>Accept One Traveler's Misfortune
step
.goto 379,50.07,49.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Abandoned Wreckage|r.
.complete 30683,1 
.timer 9,RP
step
.goto 379,50.07,49.37
>>Kill |cRXP_ENEMY_Stone Guardians|r then |cRXP_ENEMY_General Sho Lien|r.
.complete 30683,2 
.mob general sho lien
.mob Stone Guardian
step
.goto 379,48.14,49.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Bluestring|r.
.turnin 30683 >>Turn in One Traveler's Misfortune
.target Lucky Bluestring
.accept 30684 >>Accept Seeker's Folly
step
.goto 379,44.78,49.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine|r.
.complete 30684,1 
step
.goto 379,42.68,50.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine|r.
.complete 30684,2 
step
.goto 379,43.17,51.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine|r.
.complete 30684,3 
step
.goto 379,43.80,51.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.turnin 30684 >>Turn in Seeker's Folly
.accept 30829 >>Accept The Tongue of Ba-Shon
.target Lorewalker Cho
step
#completewith next
#label Reclaimer Zuan A
>>Kill |cRXP_ENEMY_Reclaimer Zuan|r.
.complete 30829,1 
.mob Reclaimer Zuan
.mob Yachi
step
#completewith Reclaimer Zuan A
.goto 379,43.79,51.07
.gossipoption 40517 >>Talk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.timer 20,RP
.target Lorewalker Cho
step
#requires Reclaimer Zuan A
.goto 379,43.46,51.42
>>Kill |cRXP_ENEMY_Reclaimer Zuan|r.
.complete 30829,1 
.skipgossipid 40517
.mob Reclaimer Zuan
.mob Yachi
step
.goto 379,43.77,51.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.turnin 30829 >>Turn in The Tongue of Ba-Shon
.accept 30795 >>Accept Staying Connected
.target Lorewalker Cho
step
.goto 379,57.11,47.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curious Text|r.
.accept 30797 >>Accept It Was Almost Alive
.target Curious Text
step
.goto 379,57.11,47.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Torn Page|r.
.complete 30797,1 
step
.goto 379,57.11,47.89
>>Use |T512479:0|t[The Tongue of Ba-Shon] near the book.
.complete 30795,1 
.use 81712
step
.goto 379,57.11,47.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30795 >>Turn in Staying Connected
.accept 30796 >>Accept An End to Everything
.turnin 30797 >>Turn in It Was Almost Alive
.accept 30799 >>Accept The Tomb of Shadows
.use 81712
.target Image of Lorewalker Cho
step
#loop
.goto 379,57.18,49.04,20,0
.goto 379,56.73,47.23,20,0
.goto 379,57.46,47.40,20,0
>>Kill |cRXP_ENEMY_Tormented Spirits|r.
.complete 30796,1 
.mob tormented spirits
step
#completewith next
#label Dynasty Rubbing
.goto 379,55.88,46.21,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r.
.complete 30799,3 
step
#title Enter Temple
#completewith Dynasty Rubbing
.goto 379,57.07,45.03,80 >>Enter the Temple
step
#requires Dynasty Rubbing
.goto 379,57.07,45.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r.
.complete 30799,3 
step
.goto 379,57.13,43.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r |cRXP_WARN_next to the statue|r.
.complete 30799,1 
step
.goto 379,56.36,43.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r |cRXP_WARN_under the pole|r.
.complete 30799,2 
step
#completewith next
#label An End to Everything
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30796 >>Turn in An End to Everything
.turnin 30799 >>Turn in The Tomb of Shadows
.accept 30798 >>Accept Breaking the Emperor's Shield
.disablecheckbox
.target Image of Lorewalker Cho
.use 81712
step
#completewith An End to Everything
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires An End to Everything
.goto 379,55.88,46.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30796 >>Turn in An End to Everything
.turnin 30799 >>Turn in The Tomb of Shadows
.accept 30798 >>Accept Breaking the Emperor's Shield
.target Image of Lorewalker Cho
.use 81712
step
#completewith next
#label King's Coffer
.goto 379,53.35,49.21,10,0
.goto 379,53.06,46.52,15,0
.goto 385,83.74,64.02,10,0
.goto 385,80.6,75.25,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_King's Coffer|r.
.complete 30800,1 
step
#completewith King's Coffer
.goto 385,58.66,72.54,90 >>Enter the Temple
step
#requires King's Coffer
.goto 385,58.66,72.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_King's Coffer|r.
.complete 30800,1 
step
.goto 385,39.71,69.08,10,0
.goto 385,34.33,61.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Tablet|r on the wall.
.complete 30800,2 
.mob Terracotta Gladiator
step
#completewith next
#label Stealing Their Thunder King
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30800 >>Turn in Stealing Their Thunder King
.accept 30801 >>Accept Lessons from History
.target Image of Lorewalker Cho
.use 81712
step
#completewith Stealing Their Thunder King
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires Stealing Their Thunder King
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30800 >>Turn in Stealing Their Thunder King
.accept 30801 >>Accept Lessons from History
.target Image of Lorewalker Cho
.use 81712
step
.goto 385,34.33,61.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Tablet|r on the wall.
.complete 30801,1 
step
#completewith next
#label Chasing the Storm
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30801 >>Turn in Lessons from History
.accept 30802 >>Accept Chasing the Storm
.disablecheckbox
.target Image of Lorewalker Cho
.use 81712
step
#completewith Chasing the Storm
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires Chasing the Storm
.goto 385,33.44,62.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30801 >>Turn in Lessons from History
.accept 30802 >>Accept Chasing the Storm
.target Image of Lorewalker Cho
.use 81712
step
#loop
.goto 385,53.79,72.07,20,0
.goto 385,58.69,85.70,20,0
.goto 385,66.66,74.20,20,0
.goto 385,61.77,59.20,20,0
.goto 385,81.60,75.95,20,0
.goto 385,53.79,72.07,0
.goto 385,58.69,85.70,0
.goto 385,66.66,74.20,0
.goto 385,61.77,59.20,0
.goto 385,81.60,75.95,0
>>Kill |cRXP_ENEMY_Zandalari Warrior|r.
*Loot them for |T441148:0|t[|cRXP_LOOT_Blood-Revealed Map|r].
.complete 30802,1 
.mob Zandalari Warrior
step
#completewith next
#label Fisherman's Tale
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30802 >>Turn in Chasing the Storm
.target Image of Lorewalker Cho
.use 81712
step
#completewith Fisherman's Tale
#label KunlaiSummitHordeEnd
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires Fisherman's Tale
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30802 >>Turn in Chasing the Storm
.target Image of Lorewalker Cho
.use 81712
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Spires of Arak
#internal
<< Horde
step
#completewith SpiresOfArakHordeEnd
#hidewindow
+1
.usespell 1231411
step
.zoneskip 590
#completewith next
.cast 171253 >>Use your Garrison Hearthstone
step
.goto 590,50.85,50.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Murla Longeye|r.
.accept 36862 >>Accept Pinchwhistle Gearworks
.target Murla Longeye
step
>>Open the Adventure Guide (Shift + J), |TInterface/cursor/crosshair/interact.blp:20|tClick on the right arrow until you see 'Spires of Arak', |TInterface/cursor/crosshair/interact.blp:20|tClick 'Start Quest'
.accept 36951 >>Accept Arakkoa Exodus
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bron Skyhorn|r the Flight Master to be flown out to Spires of Arak.
.skipgossip 3
.turnin 36951 >> Turn in Arakkoa Exodus
.accept 34655 >>Accept The Shadows of Skettis
.goto 542,37.89,18.02
.target Bron Skyhorn
step
.goto 542,36.81,17.14
.turnin 36243 >>Loot the Outcast's Belongings within the mountains
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reshad|r.
.target Reshad
.goto 542,43.65,12.93
.skipgossip 79519
.complete 36243,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reshad|r.
.target Reshad
.goto 542,43.65,12.93
.turnin 34655 >>Turn in The Shadows of Skettis
.accept 34656 >>Accept Hidden in Plain Sight
.accept 34657 >>Accept Adherents of the Sun God
step
#completewith SpiresofArakHiddenInPlainSight
>>Kill |cRXP_ENEMY_Adherent Bladewings|r.
.complete 34657,1 
step
>>Pick up the Wingblades
.goto 542,41.23,16.27
.complete 34656,1 
step
>>|cRXP_WARN_Keep the item for later|r.
.goto 542,43.91,15.03
.turnin 36395 >>Pick up the Elixir of Shadow Sight
step
#label SpiresofArakHiddenInPlainSight
>>Pick up the Ragged Mask
.goto 542,44.93,15.14
.complete 34656,2 
step
>>Kill |cRXP_ENEMY_Adherent Bladewings|r.
.goto 542,45.62,13.06,25,0
.goto 542,43.63,14.16,30,0
.goto 542,41.56,16.22,30,0
.goto 542,45.62,13.06
.complete 34657,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reshad|r.
.target Reshad
.goto 542,43.65,12.93
.turnin 34656 >>Turn in Hidden in Plain Sight
.turnin 34657 >>Turn in Adherents of the Sun God
.accept 34658 >>Accept Orders From On High
step
>>Kill |cRXP_ENEMY_Sun-Sage Rathyx. Loot him for the proclamation
*When he or his bird cast Blinding Flash/Flash Bang |cRXP_WARN_look away|r.
*|cRXP_WARN_Interrupt Solar Radiance (50% heal)|r.
.goto 542,45.97,15.43
.complete 34658,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reshad|r.
.target Reshad
.goto 542,45.39,18.26
.turnin 34658 >>Turn in Orders From On High
.accept 34659 >>Accept The Crone
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Reshad again
.goto 542,45.39,18.26
.skipgossip 1
.train 78670 >>Train Apprentice Archaeology
step
.goto 542,42.96,16.37
.turnin 36245 >>Pick up the Relics of the Outcasts
step
.goto 542,42.70,18.32
.turnin 36244 >>Pick up the Misplaced Scrolls
step
.goto 542,50.51,22.10
.turnin 36246>>Pick up the Fractured Sunstone in the water
step
>>Try to not loot it just close the loot window. This skips the knockup
.goto 542,50.32,25.80
.turnin 36444 >>Pick up the Iron Horde Explosives
step
.goto 542,50.75,28.74
.turnin 36247 >>Pick up the Lost Herb Satchel
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ornekka|r.
.target Ornekka
.goto 542,51.62,31.37
.skipgossip 79890,1
.complete 34659,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Ornekka and Reshad
.goto 542,51.62,31.37
.turnin 34659 >>Turn in The Crone
.accept 34756 >>Accept A Charming Deception
.accept 35636 >>Accept All Due Respect
.accept 34805 >>Accept Echo Hunters
step
#completewith SpiresofArakAllDueRespect
>>Kill |cRXP_ENEMY_Echo Hunters|r.
.complete 34805,1 
step
#title Illusion Charm 1
>>Pick up the Illusion Charm
.goto 542,50.97,31.31
.complete 34756,1,1 
step
#title Illusion Charm 2
>>Pick up the Illusion Charm
.goto 542,51.31,33.58
.complete 34756,1,2 
step
#title Illusion Charm 3
>>Pick up the Illusion Charm
.goto 542,51.83,36.40
.complete 34756,1,3 
step
#title Illusion Charm 4
>>Pick up the Illusion Charm
.goto 542,51.13,36.50
.complete 34756,1,4 
step
>>Interact with the corpse of Syth
.goto 542,50.26,36.38
.complete 35636,1 
step
>>Interact with Syth's Bookcase. Defeat the three incoming waves afterwards
*If you see Echo Hunter nearby, kill them
.goto 542,50.02,36.73
.complete 35636,2 
step
#label SpiresofArakAllDueRespect
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reshad|r.
.target Reshad
.goto 542,50.28,36.70
.turnin 35636 >>Turn in All Due Respect
.accept 35668 >>Accept Syth's Secret
step
#completewith SpiresofArakSythsSecret
>>Kill |cRXP_ENEMY_Echo Hunters|r.
.goto 542,50.46,34.97,20,0
.goto 542,51.27,38.71,30,0
.complete 34805,1 
step
#title Illusion Charm 5
>>Pick up the Illusion Charm
.goto 542,50.40,40.05
.complete 34756,1,5 
step
.goto 542,49.20,37.30
.turnin 36445 >>Pick up Assassin's Spear
step
#completewith next
.goto 542,49.06,41.26,10 >>Enter the cave
step
#label SpiresofArakSythsSecret
>>Kill |cRXP_ENEMY_Sun-Talon Oberyx|r. Loot him for his eye.
*Dodge the chakrams (void zones)
.goto 542,48.34,42.87
.complete 35668,1 
step
>>Kill |cRXP_ENEMY_Echo Hunters|r.
.goto 542,47.79,42.68,25,0
.goto 542,48.90,43.08,25,0
.goto 542,50.04,39.01
.complete 34805,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reshad|r.
.target Reshad
.goto 542,48.56,44.48
.turnin 34756 >>Turn in A Charming Deception
.turnin 34805 >>Turn in Echo Hunters
.turnin 35668 >>Turn in Syth's Secret
.accept 35671 >>Accept A Gathering of Shadows
step
#completewith next
.use 115463
.cast 170183 >>Use the Elixir of Shadow Sight
step
.goto 542,48.58,44.49
.turnin 36386 >>Pick up the Gift of Anzu
step
>>Wait at the waypoint
.goto 542,46.51,45.61
.complete 35671,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Shadow-Sage Iskar
.goto 542,46.51,45.61
.turnin 35671 >>Turn in A Gathering of Shadows
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shadow Hunter Ukambe|r.
.target Shadow Hunter Ukambe
.goto 542,45.89,46.37
.accept 35272 >>Accept One of Our Own
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Shadow-Sage Iskar
.goto 542,46.51,45.61
.skipgossip
.complete 35272,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shadow Hunter Ukambe|r.
.target Shadow Hunter Ukambe
.goto 542,45.89,46.36
.turnin 35272 >>Turn in One of Our Own
.accept 35275 >>Accept Inspecting the Troops
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shadow Hunter Ukambe|r.
.target Shadow Hunter Ukambe
.goto 542,40.07,44.05
.turnin 35275 >>Turn in Inspecting the Troops
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taskmaster Gornek|r.
.target Taskmaster Gornek
.goto 542,40.19,43.50
.accept 35277 >>Accept Orders, Commander?
step
>>Interact with the Drafting Table and select 'Home Away From Home' (Hearthfire Tavern on the left)
.goto 542,40.19,43.50
.complete 35277,1 
.complete 35277,2 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taskmaster Gornek|r.
.target Taskmaster Gornek
.goto 542,40.18,43.50
.turnin 35277 >>Turn in Orders, Commander?
.accept 37326 >>Accept Befriending the Locals
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Percy|r.
.target Percy
.goto 542,40.10,43.97
.accept 35611 >>Accept Return to Veil Terokk
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Dusk-Seer Irizzar
.goto 542,43.90,48.91
.turnin 37326 >>Turn in Befriending the Locals
.accept 37296 >>Accept A Lack of Wasps
step
>>Kill |cRXP_ENEMY_Widow Wasps|r.
.goto 542,44.63,49.50,20,0
.goto 542,43.23,50.56,20,0
.goto 542,43.53,47.20
.complete 37296,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Dusk-Seer Irizzar
.goto 542,43.90,48.92
.turnin 37296 >>Turn in A Lack of Wasps
.accept 37328 >>Accept Not Here, Not Now
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Reshad and Shadow-Sage Iskar
.turnin 35611 >>Turn in Return to Veil Terokk
.accept 34998 >>Accept Talon Watch
.accept 34884 >>Accept The Kaliri Whisperer
.goto 542,45.87,45.73
.accept 34827 >>Accept Last of the Talonpriests
.goto 542,45.94,45.78
step
.goto 542,45.94,44.17
.turnin 36354 >>Pick up Relics of the Outcasts on the rope
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tInteract with Skizziks corpse
.goto 542,45.43,36.32
.skipgossip
.complete 34884,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Skizzik and the Kaliri Egg
.accept 34885 >>Accept Mother of Thorns
.goto 542,45.43,36.32
.accept 34838 >>Accept Ikky's Egg
.goto 542,45.39,36.74
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the egg
.goto 542,45.39,36.74
.complete 34838,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Ikky
.goto 542,45.39,36.74
.turnin 34838 >>Turn in Ikky's Egg
.accept 34886 >>Accept Baby Bird
step
#completewith next
>>Kill |cRXP_ENEMY_Shadeback Ravagers|r and pick up Ravager Grubs.
.complete 34886,1 
.complete 34885,1 
step
>>Kill the |cRXP_ENEMY_Shadeback Thornmother|r.
.goto 542,44.19,37.96
.complete 34885,2 
step
>>Kill |cffShadeback Ravager|r and pick up Ravager Grubs (small maggots).
.goto 542,45.10,37.92
.complete 34886,1 
.complete 34885,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikky|r.
.target Ikky
.goto 542,45.40,36.75
.turnin 34886 >>Turn in Baby Bird
step
.goto 542,47.77,36.11
.turnin 36411 >>Pick up the Lost Ring in the water
step
>>Use the |T134711:0|t[Elixir of Shadows]
.use 112100
.goto 542,47.98,34.69
.complete 34827,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talonpriest Ishaal|r.
.target Talonpriest Ishaal
.goto 542,48.01,34.76
.turnin 34827 >>Turn in Last of the Talonpriests
.accept 34828 >>Accept Ishaal's Orb
.accept 34829 >>Accept New Neighbors
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravager Egg|r.
.target Ravager Egg
.goto 542,47.13,31.66
.accept 36425 >>Accept Egg Punt
step
#completewith SpiresofArakIshaalsOrb
>>Kill |cRXP_ENEMY_Shattered Hand Orcs|r.
.complete 34829,1 
step
#completewith SpiresofArakIshaalsOrb
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Ravager Eggs on the ground
.complete 36425,1 
step
.goto 542,47.93,30.66
.turnin 36361 >>Pick up the Shattered Hand Lockbox
step
#label SpiresofArakIshaalsOrb
>>Pick up Ishaal's Orb
.goto 542,48.09,28.47
.complete 34828,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Shattered Hand Orcs|r.
*|cRXP_WARN_Dodge the Blade Flurries to the side|r.
.complete 34829,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Ravager Eggs on the ground
.goto 542,46.62,29.37,25,0
.goto 542,47.14,31.56,25,0
.goto 542,47.33,30.56
.complete 36425,1 
step
>>Finish killing |cRXP_ENEMY_Shattered Hand Orcs|r.
.goto 542,47.33,30.56
.complete 34829,1 
step
#sticky
#label SpiresofArakEggPunt
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the quest in the quest log under your minimap
.turnin 36425 >>Turn in Egg Punt
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talonpriest Ishaal|r.
.target Talonpriest Ishaal
.goto 542,48.01,34.75
.turnin 34828 >>Turn in Ishaal's Orb
.turnin 34829 >>Turn in New Neighbors
.accept 34830 >>Accept Behind the Veil
step
.goto 542,46.92,34.04
.turnin 36446 >>Pick up the Outcast's Pouch from the dead Arrakoa Outcast on the tree
step
>>Use the |T134711:0|t[Major Elixir of Shadows]
.use 112099
.goto 542,44.48,24.01
.complete 34830,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talonpriest Zellek|r.
.target Talonpriest Zellek
.goto 542,44.48,24.01
.turnin 34830 >>Turn in Behind the Veil
step
.goto 542,43.82,24.63
.turnin 36397 >>Pick up the Elixir of Shadow Sight
step
.goto 542,43.21,27.26
.turnin 36355 >>Pick up the Relics of the Outcasts located in the trees.
step
#completewith next
.cast 168499 >>Use Home Away From Home (|cRXP_WARN_Zone Ability not your Hearthstone|r.)
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taskmaster Gornek|r.
.target Taskmaster Gornek
.goto 542,40.19,43.50
.turnin 37328 >>Turn in Not Here, Not Now
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikky|r.
.target Ikky
.goto 542,46.20,45.69
.turnin 34898 >>Turn in Ikky
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reshad|r.
.target Reshad
.goto 542,45.87,45.74
.turnin 34884 >>Turn in The Kaliri Whisperer
.turnin 34885 >>Turn in Mother of Thorns
step
.goto 542,48.35,52.61
.turnin 36405 >>Pick up the Offering to the Raven Mother
step
#completewith next
.use 118267
.cast 174031 >>Use the Ravenmother Offering
step
.goto 542,48.91,54.71
.turnin 36406 >>Pick up the Offering to the Raven Mother
step
#completewith next
.use 118267
.cast 174031 >>Use the Ravenmother Offering
step
.goto 542,53.32,55.51
.turnin 36403 >>Pick up the Offering to the Raven Mother
step
#completewith next
.use 118267
.cast 174031 >>Use the Ravenmother Offering
step
.goto 542,60.97,63.88
.turnin 36410 >>Pick up the Offering to the Raven Mother
step
#completewith next
.use 118267
.cast 174031 >>Use the Ravenmother Offering
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Kimzee Pinchwhistle and Engineer Gazwitz
.goto 542,61.47,72.94
.turnin 36862 >>Turn in Pinchwhistle Gearworks
.accept 35077 >>Accept Defungination
.accept 35079 >>Accept Spore-be-Gone
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exterminator Lemmy|r.
.target Exterminator Lemmy
.goto 542,62.57,73.91
.accept 36179 >>Accept Unwanted Pests
step
#completewith SpiresofArakSporebeGone
>>Kill |cRXP_ENEMY_Spore Drifter|r. Avoid Fungal Hulks.
.complete 36179,1 
step
#completewith SpiresofArakSporebeGone
>>Use the |T134538:0|t [QR58 Flame Blaster] to burn the yellow/green spores on the ground
.use 112683
.complete 35077,1 
step
#title Turret 1
>>Activate the turret
.goto 542,63.16,73.92,20,0
.goto 542,63.59,74.08
.complete 35079,1,1 
step
#title Turret 2
>>Activate the turret
.goto 542,64.49,74.26
.complete 35079,1,2 
step
#title Turret 3
>>Activate the turret
.goto 542,64.76,74.23
.complete 35079,1,3 
step
#title Turret 4
>>Activate the turret
.goto 542,64.36,75.01,15,0
.goto 542,63.72,74.94
.complete 35079,1,4 
step
#title Turret 5
>>Activate the turret
.goto 542,63.36,75.78
.complete 35079,1,5 
step
#label SpiresofArakSporebeGone
#title Turret 6
>>Activate the turret
.goto 542,63.63,76.41
.complete 35079,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Spore Drifter|r. Avoid Fungal Hulks. The QR58 Flame Baster also damages these mobs.
.complete 36179,1 
step
#completewith SpiresofArakSporebeGone
>>Use the |T134538:0|t[QR58 Flame Blaster] to burn the yellow/green spores on the ground
.use 112683
.goto 542,62.68,76.40,20,0
.goto 542,63.60,75.34,20,0
.goto 542,64.57,75.18,20,0
.goto 542,63.31,74.30
.complete 35077,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Spore Drifter|r. Avoid Fungal Hulks.
.goto 542,62.68,76.40,20,0
.goto 542,63.60,75.34,20,0
.goto 542,64.57,75.18,20,0
.goto 542,63.31,74.30
.complete 36179,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Kimzee Pinchwhistle and Engineer Gazwitz
.goto 542,61.46,72.95
.turnin 35077 >>Turn in Defungination
.turnin 35079 >>Turn in Spore-be-Gone
.turnin 36179 >>Turn in Unwanted Pests
.accept 35080 >>Accept The Mother Lode
step
.itemcount 132516,1
#completewith next
.cooldown item,132516,>0,1
.cast 202844 >>Use |T1405809:0|t[Gunshoes]
step
>>Follow the arrow
.goto 542,59.12,79.18
.complete 35080,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Kimzee Pinchwhistle and Engineer Gazwitz
.turnin 35080 >>Turn in The Mother Lode
.accept 35082 >>Accept Getting the Crew Back Together
.goto 542,59.12,79.18
.accept 35081 >>Accept Clearing Out Before Cleaning Up
.goto 542,59.10,79.23
step
#completewith SpiresofArakGettingtheCrewBackTogether
>>Kill |cRXP_ENEMY_Crimsonwing Wasps|r.
.complete 35081,1 
step
#title Crew Revived 1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Injured Crewmans
.goto 542,60.25,79.77
.complete 35082,1,1 
step
#title Crew Revived 2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Injured Crewmans
.goto 542,60.43,80.66
.complete 35082,1,2 
step
#title Crew Revived 3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Injured Crewmans
.goto 542,60.19,81.49
.complete 35082,1,3 
step
#title Crew Revived 4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Injured Crewmans
.goto 542,60.54,81.65
.complete 35082,1,4 
step
#title Crew Revived 5
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Injured Crewmans
.goto 542,60.43,82.33
.complete 35082,1,5 
step
#label SpiresofArakGettingtheCrewBackTogether
#title Crew Revived 6
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the Injured Crewmans
.goto 542,60.00,82.09
.complete 35082,1 
step
>>Kill |cRXP_ENEMY_Crimsonwing Wasps|r.
.goto 542,59.20,81.89,25,0
.goto 542,60.91,82.22,20,0
.goto 542,59.91,80.80
.complete 35081,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Kimzee Pinchwhistle and Engineer Gazwitz
.goto 542,59.11,79.20
.turnin 35082 >>Turn in Getting the Crew Back Together
.turnin 35081 >>Turn in Clearing Out Before Cleaning Up
.accept 35285 >>Accept Follow that Hotrod!
step
>>Talk to Kimzee Pinchwhistle and Krixel Pinchwhistle
.turnin 35285 >>Turn in Follow that Hotrod!
.accept 35090 >>Accept The Right Parts for the Job
.accept 35089 >>Accept Skimming Off the Top
.goto 542,58.48,92.33
.accept 36384 >>Accept Field Trial
.goto 542,58.49,92.20
step
#completewith next
.goto 542,58.81,91.99
.vendor
step
.goto 542,59.15,90.63
.turnin 36366 >>Pick up the bottle in the small building
step
#completewith next
>>Kill |cRXP_ENEMY_Volatile Sludge|r. Loot them for the oil.
.complete 35089,1 
step
>>Use the |T133032:0|t[G-14 Buster Rocket] to destroy Broken Shredder and pick up the spawning gears
.goto 542,59.32,89.90,20,0
.goto 542,59.81,87.54,20,0
.goto 542,58.95,88.51,20,0
.goto 542,58.29,89.51,20,0
.goto 542,57.94,90.36
.use 112698
.complete 35090,1 
step
>>Kill |cRXP_ENEMY_Volatile Sludge|r. Loot them for the oil.
.goto 542,59.31,88.91
.complete 35089,1 
step
>>Use |T609895:0|t[Vial of Untested Serum] on an Infected Lumberjack
.goto 542,58.64,87.10
.use 115457
.complete 36384,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krixel Pinchwhistle|r.
.goto 542,58.49,92.21
.turnin 36384 >>Turn in Field Trial
.target Krixel Pinchwhistle
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kimzee Pinchwhistle|r.
.target Kimzee Pinchwhistle
.goto 542,58.83,92.84
.turnin 35089 >>Turn in Skimming Off the Top
.turnin 35090 >>Turn in The Right Parts for the Job
.accept 35091 >>Accept Sporicide
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krixel Pinchwhistle|r.
.target Krixel Pinchwhistle
.goto 542,58.48,92.20
.accept 35211 >>Accept Preventing the Worst
.accept 36428 >>Accept Curing With Force
step
#completewith next
>>Kill |cRXP_ENEMY_Spore Shamblers|r.
.complete 35091,1 
.mob Spore Shambler
step
#completewith next
>>Use |T609892:0|t[Vial of Refined Serum] on |cRXP_ENEMY_Infected Bruisers|r or |cRXP_ENEMY_Infected Bar Patrons|r below 30% HP.
.use 115533
.complete 36428,1 
.mob Infected Bruiser
.mob Infected Bar Patron
step
#title Bomb Placed 1/5
>>Place the |cRXP_PICK_bomb|r inside the small building.
.goto 542,56.62,89.99
.complete 35211,1,1 
step
#title Bomb Placed 2/5
>>Place the |cRXP_PICK_bomb|r.
.goto 542,56.46,89.45
.complete 35211,1,2 
step
>>Kill |cRXP_ENEMY_Spore Shamblers|r.
.goto 542,54.91,87.97
.complete 35091,1 
.mob Spore Shambler
step
#completewith SpiresofArakPreventingtheWorst
>>Use |T609892:0|t[Vial of Refined Serum] on |cRXP_ENEMY_Infected Bruisers|r or |cRXP_ENEMY_Infected Bar Patrons|r below 30% HP.
.use 115533
.complete 36428,1 
step
#title Bomb Placed 3/5
>>Place the |cRXP_PICK_bomb|r.
.goto 542,55.69,90.99
.complete 35211,1,3 
step
#title Bomb Placed 4/5
>>Place the |cRXP_PICK_bomb|r.
.goto 542,56.29,91.61
.complete 35211,1,4 
step
#label SpiresofArakPreventingtheWorst
#title Bomb Placed 5/5
>>Place the |cRXP_PICK_bomb|r.
.goto 542,56.74,91.56
.complete 35211,1 
step
>>Use |T609892:0|t[Vial of Refined Serum] on |cRXP_ENEMY_Infected Bruisers|r or |cRXP_ENEMY_Infected Bar Patrons|r below 30% HP.
.use 115533
.goto 542,56.20,90.70,20,0
.goto 542,58.28,87.30,40,0
.goto 542,56.20,90.70
.complete 36428,1 
.mob Infected Bruiser
.mob Infected Bar Patron
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Kimzee Pinchwhistle and Krixel Pinchwhistle
.turnin 35091 >>Turn in Sporicide
.goto 542,58.82,92.83
.turnin 35211 >>Turn in Preventing the Worst
.turnin 36428 >>Turn in Curing With Force
.accept 35298 >>Accept Flame On
.goto 542,58.49,92.20
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Plunger|r.
.goto 542,58.51,92.22
.complete 35298,1 
step
#label SpiresOfArakHordeEnd
>>Mount the |cRXP_FRIENDLY_Repaired Flying Machine|r.
.goto 542,58.87,92.86
.complete 35298,2 
.target Repaired Flying Machine
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kimzee Pinchwhistle|r.
.goto 542,61.60,72.85
.turnin 35298 >>Turn in Flame On
.turnin 36062 >>Turn in Kimzee Pinchwhistle
.target Kimzee Pinchwhistle
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Horde Gorgrond
#internal
<< Horde
step
#completewith GorgrondHordeEnd
#hidewindow
+1
.usespell 1231411
step
.zoneskip 590
#completewith next
.cast 171253 >>Use your Garrison Hearthstone
step
#label FrostfireRidgeAcceptGutGuttra
.goto 525,66.02,49.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tFly east and talk to |cRXP_FRIENDLY_Outrider Urukag|r.
.accept 33132 >>Accept Gut Guttra
.target Outrider Urukag
step
>>Kill |cRXP_ENEMY_Grimfrost Ogres|r and free |cRXP_FRIENDLY_Captured Frostwolves|r.
.goto 525,66.33,47.49,20,0
.goto 525,67.19,49.06,20,0
.goto 525,67.96,48.51,30,0
.goto 525,67.14,46.70
.complete 33145,1 
.complete 33145,2 
.mob Grimfrost Wolfslayer
.mob Grimfrost Lavaslinger
.mob Grimfrost Drudge
.target Captured Frostwolf
step
>>Kill |cRXP_ENEMY_Guttra Wolfchew|r.
.goto 525,68.27,45.53
.complete 33132,1 
.mob Guttra Wolfchew
step
.goto 525,66.06,49.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Outrider Urukag|r.
.target Outrider Urukag
.turnin 33132 >>Turn in Gut Guttra
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tFly to Gorgrond and talk to |cRXP_FRIENDLY_Durotan|r.
.goto 543,37.28,77.01
.accept 33543 >>Accept The Laughing Skull
.target Durotan
step
>>Follow the arrow
.goto 543,38.42,74.29
.complete 33543,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ripfist|r.
.target Ripfist
.goto 543,38.77,73.62
.turnin 33543 >>Turn in The Laughing Skull
.accept 33544 >>Accept Goren, Goren, Gone!
step
#sticky
#label GorgrondAcidtoothDevourers
>>Kill |cRXP_ENEMY_Acidtooth Devourers|r and turn in the quest under your minimap.
.goto 543,40.81,73.87,0,0
.complete 33544,1 
.turnin 33544 >>Turn in Goren, Goren, Gone!
.mob Acidtooth Devourer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaz the Shrieker|r.
.target Kaz the Shrieker
.goto 543,39.33,71.98
.accept 33548 >>Accept We Die Laughing!
step
#title Mask 1/5
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Dead Laughing Skull|r.
.goto 543,39.66,72.46
.complete 33548,1,1 
step
.goto 543,40.01,72.26
.turnin 36170 >>Pick up the |cRXP_PICK_bone|r.
step
#title Mask 2/5
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Dead Laughing Skull|r.
.goto 543,40.21,72.52
.complete 33548,1,2 
step
.goto 543,40.48,71.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limbflayer|r.
.target Limbflayer
.accept 33563 >>Accept Eye Candy
step
#title Mask 3/5
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Dead Laughing Skull|r.
.goto 543,41.12,72.26
.complete 33548,1,3 
step
>>Kill |cRXP_ENEMY_Skothwa|r. Loot him for his eye.
.goto 543,41.46,72.68
.complete 33563,1 
step
#title Mask 4/5
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Dead Laughing Skull|r.
.goto 543,41.14,72.87
.complete 33548,1,4 
step
#title Mask 5/5
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Dead Laughing Skull|r.
.goto 543,41.06,73.74
.complete 33548,1 
step
#requires GorgrondAcidtoothDevourers
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limbflayer|r, |cRXP_FRIENDLY_Kaz|r and |cRXP_FRIENDLY_Durotan|r.
.goto 543,41.48,74.13
.turnin 33563 >>Turn in Eye Candy
.turnin 33548 >>Turn in We Die Laughing!
.accept 33593 >>Accept A Flare for the Dramatic
.target Limbflayer
.target Kaz the Shrieker
.target Durotan
step
>>Use |T391128:0|t[Penny's Flare Gun]
.use 115534
.goto 543,41.38,74.10
.complete 33593,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durotan|r.
.target Durotan
*Skip the next cinematic with ESC
.goto 543,41.49,74.08
.turnin 33593 >>Turn in A Flare for the Dramatic
.accept 36434 >>Accept Penny From Heaven
step
.turnin 36621 >>Pick up the |cRXP_PICK_Explorer Canister|r in the water.
.goto 543,40.37,76.60
step
.turnin 36658 >>Pick up the |cRXP_PICK_Evermorn Supply Cache|r.
.goto 543,41.82,78.04
step
.turnin 35709 >>Pick up the |cRXP_PICK_Laughing Skull Cache|r on the tree.
.goto 543,44.19,74.23
step
.turnin 36118 >>Pick up the |cRXP_PICK_Pile of Rubble|r.
.goto 543,43.94,70.49
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Penny Clobberbottom|r.
.target Penny Clobberbottom
.goto 543,45.69,70.59
.turnin 36434 >>Turn in Penny From Heaven
.accept 36460 >>Accept Just Another Stick in the Wall
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with |cRXP_PICK_Penny's Plunger|r.
.goto 543,45.69,70.59
.complete 36460,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durotan|r.
.target Durotan
.goto 543,45.86,70.30
.turnin 36460 >>Turn in Just Another Stick in the Wall
.accept 35151 >>Accept Your Base, Your Choice
step
*|cRXP_WARN_Select the right building 'Savage Fight Club'|r.
.goto 543,45.85,70.26
.complete 35151,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durotan|r.
.target Durotan
.goto 543,46.10,70.19
.turnin 35151 >>Turn in Your Base, Your Choice
.accept 35880 >>Accept Rage and Wisdom
step
#completewith next
.goto 543,45.98,69.71
.home >>Set your Hearthstone to Beastwatch
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limbflayer|r.
.target Limbflayer
.goto 543,46.33,69.71
.accept 34697 >>Accept A Rediscovered Legend
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marrow|r.
.target Marrow
.goto 543,46.29,69.98
.accept 35667 >>Accept Skulltakers in Crimson Fen
.accept 33694 >>Accept Reagents from Rakthoth
step
.itemcount 132516,1
#completewith next
.cooldown item,132516,>0,1
.cast 202844 >>Use |T1405809:0|t[Gunshoes]
step
#completewith next
>>You have 60 seconds to get the following 3 items after using the ability. |cRXP_WARN_Before using the ability pull some mobs and damage them until they have only ~20% HP left.
*Skip the ones you didn't get
.goto 543,45.26,79.82,30,0
.cast 164012 >>Use Champion's Honor (Zone Ability)
step
*1) Loot 'Ravager Claw' from |cRXP_ENEMY_Thicket Ravagers|r.
*2) Loot 'Wasp Sting' from the |cRXP_ENEMY_Golden Pollinator|r.
*3) Loot 'Orc Thorn' from the |cRXP_ENEMY_Vined Guardians|r.
*Skip if you don't loot it after 60 seconds.
.goto 543,45.16,78.14,20,0
.goto 543,43.52,82.00,15,0
.goto 543,42.52,82.67,15,0
.goto 543,40.59,83.83,15,0
.goto 543,40.13,83.24,15,0
.collect 114032,1,36097,1
.collect 114034,1,36101,1
.collect 114027,1,36091,1
.accept 36097 >>Accept Proof of Strength: Ravager Claw
.accept 36101 >>Accept Proof of Strength: Wasp Stinger
.accept 36091 >>Accept Proof of Strength: Orc Thorn
.mob Thicket Ravager
.mob Golden Pllinator
.mob Vined Guardian
step
.goto 543,43.57,90.18
.accept 36520 >>Accept Tailthrasher Basin (Bonus Objective)
step
#completewith next
#title Destroy Rope Spikes
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Spikes|r to free the |cRXP_FRIENDLY_Axebeak|r.
.goto 543,43.57,90.78,10,0
.complete 36520,2 
step
#completewith next
.goto 543,44.73,90.17,8 >>Enter the cave
step
>>Kill |cRXP_ENEMY_Skull Trash|r.
.goto 543,44.43,88.89
.complete 36520,3 
.mob Skull Thrash
step
#sticky
#label GorgrondJungleAxebeakFreed
#title Destroy Rope Spikes
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Spikes|r to free the |cRXP_FRIENDLY_Axebeak|r.
.goto 543,45.13,90.61,10,0
.goto 543,44.57,91.58,10,0
.goto 543,45.93,89.72,10,0
.complete 36520,2 
step
>>Kill |cRXP_ENEMY_Tailthrasher Saberons|r.
.goto 543,44.18,91.01,0,0
.complete 36520,1 
.mob Tailthrasher Saberon
step
#requires GorgrondJungleAxebeakFreed
.goto 543,49.29,81.57
.accept 35881 >>Accept Ruins of the First Bastion (Bonus Objective)
step
#sticky
#label GorgrondFrenziedPodlingsSlain
>>Kill |cRXP_ENEMY_Frenzied Podlings|r.
.goto 543,50.69,79.66,0,0
.complete 35881,1 
.mob Frenzied Podling
step
#title Ancient Jar 1/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,49.72,80.42
.complete 35881,2,1 
step
#title Ancient Jar 2/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,49.85,80.34
.complete 35881,2,2 
step
#title Ancient Jar 3/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,50.57,80.09
.complete 35881,2,3 
step
#title Ancient Jar 4/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,50.47,80.55
.complete 35881,2,4 
step
#title Ancient Jar 5/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,51.09,80.96
.complete 35881,2,5 
step
#title Ancient Jar 6/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,51.26,80.71
.complete 35881,2,6 
step
>>Kill |cRXP_ENEMY_Malkor|r.
.goto 543,52.08,81.25
.complete 35881,3 
.mob Malkor
step
#title Ancient Jar 7/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,51.74,80.49
.complete 35881,2,7 
step
#title Ancient Jar 8/8
>>Pick up the |cRXP_PICK_Ancient Jar|r on the ground.
.goto 543,51.65,79.85
.complete 35881,2 
step
#requires GorgrondFrenziedPodlingsSlain
.goto 543,48.49,75.19
.accept 36500 >>Accept The Razorbloom (Bonus Objective)
step
#completewith next
>>Walk over the |cRXP_ENEMY_slimes|r.
.complete 36500,3 
step
>>Kill the Infested in the area
.goto 543,48.38,73.97,20,0
.goto 543,47.12,74.81,20,0
.goto 543,47.04,73.27,20,0
.goto 543,47.85,72.54
.complete 36500,1 
.mob Infested Orc
.mob Infested Behemoth
step
#sticky
#label GorgrondToxicSlimemold
>>Walk over the |cRXP_FRIENDLY_slimes|r on your flying mount.
.goto 543,48.25,73.02,0,0
.complete 36500,3 
step
>>Kill the |cRXP_ENEMY_Voice of Iyu|r.
.goto 543,49.43,71.65
.complete 36500,2 
.mob Voice of Iyu
step
#requires GorgrondToxicSlimemold
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bony Xuk|r.
.target Bony Xuk
.goto 543,43.56,65.01
.turnin 35880 >>Turn in Rage and Wisdom
.accept 35248 >>Accept A Harsh Reminder
.accept 35035 >>Accept Seedbearers of Bad News
step
#completewith next
>>You have 60 seconds to get the following 3 items after using the ability. |cRXP_WARN_Before using the ability pull some mobs and damage them until they have only ~20% HP left.
*Skip the ones you didn't get
.cast 164012 >>Use Champion's Honor (Zone Ability)
step
*1) Loot 'Gronnling Scale' from |cRXP_ENEMY_'Gronnling Bonebreaker'|r.
*2) Loot 'Acid-Stained Goren Tooth' from the |cRXP_ENEMY_'Goren Gouger'|r.
*3) Loot 'Botani Bloom' from |cRXP_ENEMY_'Botani Greensworn'|r.
*Skip the items you haven't looted after 60 seconds.
.goto 543,44.02,64.88,15,0
.goto 543,44.52,64.66,15,0
.goto 543,45.41,63.76,15,0
.collect 114021,1,36080,1
.collect 113590,1,35948,1
.collect 114025,1,36086,1
.accept 36080 >>Accept Proof of Strength: Gronnling Scale
.accept 35948 >>Accept Proof of Strength: Goren Tooth
.accept 36086 >>Accept Proof of Strength: Botani Bloom
.mob Gronnling Bonebreaker
.mob Goren Gouger
.mob Botani Greensworn
step
#sticky
#label GorgrondDenizensOfWasteland
>>Kill |cRXP_ENEMY_Gronnlings|r, |cRXP_ENEMY_Ogrons|r, and |cRXP_ENEMY_Gorens|r.
.goto 543,44.76,64.22,0,0
.complete 35248,1 
.mob Gronnling Bonebreaker
.mob Goren Gouger
.mob Gorgrond Ogron
.mob Gronn Rockthrower
step
>>Burn the |cRXP_FRIENDLY_Ancients|r on your flying mount.
.goto 543,44.76,64.22
.complete 35035,1 
.target Ancient Seedbearer
step
#requires GorgrondDenizensOfWasteland
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bony Xuk|r.
.target Bony Xuk
.goto 543,43.56,65.01
.turnin 35248 >>Turnin A Harsh Reminder
.turnin 35035 >>Turnin Seedbearers of Bad News
.accept 35025 >>Accept We Have Company
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kash'drakor|r, |cRXP_FRIENDLY_Beatface|r and |cRXP_FRIENDLY_Akaani|r.
.goto 543,42.77,63.12
.accept 36603 >>Accept Brimstone Springs
.turnin 34697 >>Turn in A Rediscovered Legend
.accept 34698 >>Accept Slave Hunters
.accept 34700 >>Accept Nazgrel
.accept 34702 >>Accept Krav'ogra
.accept 34699 >>Accept Getting Gladiators
.target Kash'drakor
.target Beatface
.target Akaani
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prowler Sasha|r.
.target Prowler Sasha
.goto 543,41.42,66.11
.accept 34012 >>Accept Need More Teeth
step
#sticky
#label GorgrondOgreTeeth
>>Kill |cRXP_ENEMY_Ogres|r. Loot them for their [|cRXP_LOOT_teeth|r].
.goto 543,38.94,68.04,0,0
.complete 34012,1 
step
>>Kill |cRXP_ENEMY_Slave Hunter Krag|r at the top of the building. Loot him for his [|cRXP_LOOT_pendant|r].
.goto 543,41.12,66.23
.complete 34698,2 
.mob Slave Hunter Krag
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tBreak the |cRXP_PICK_Shackles|r to free |cRXP_FRIENDLY_Bruto|r.
.goto 543,40.30,64.83
.complete 34699,3 
step
>>Kill |cRXP_FRIENDLY_Slave Hunter Brol|r. Loot him for his |cRPX_LOOT_pendant|r.
.goto 543,40.47,66.70
.complete 34698,1 
.mob Slave Hunter Brol
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Gong|r until |cRXP_ENEMY_Slavemaster Ok'mok|r jumps down.
*You have to use the Gong three times and after each use you've to kill an NPC
.goto 543,40.40,67.56
.complete 34702,1 
.mob Slavemaster Ok'mok
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tBreak the |cRXP_PICK_Shackles|r to free |cRXP_FRIENDLY_Y'kish|r.
.goto 543,39.75,67.83
.complete 34699,2 
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tBreak the |cRXP_PICK_Shackles|r to free |cRXP_FRIENDLY_Vaandaam|r inside the hut.
.goto 543,39.17,67.23
.complete 34699,1 
step
>>Kill |cRXP_ENEMY_Slave Hunter Mol|r inside the tower. Loot him for his [|cRXP_LOOT_pendant|r].
.goto 543,38.99,68.73
.complete 34698,3 
.mob Slave Hunter Mol
step
#completewith next
.goto 543,38.58,67.38,10 >>Enter the cave
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bruto|r.
.goto 543,36.85,67.90
.turnin 34699 >>Turn in Getting Gladiators
.accept 34703 >>Accept The Axe of Kor'gall
.target Bruto
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tBreak down the |cRXP_PICK_Barricade|r and cross the bridge to the throne.
*|cRXP_WARN_If you're not confident then wait for your cooldown before you attack |cRXP_ENEMY_Kor'gall|r|r.: Loot him for his [|cRXP_LOOT_axe|r].
.goto 543,36.25,68.78,10,0
.goto 543,36.41,69.66
.complete 34703,1 
.mob Kor'gall
step
*Jump down and hug the right wall
>>|TInterface/GossipFrame/HealerGossipIcon:0|tOpen the |cRXP_PICK_cage|r.
.goto 543,37.38,69.17,10,0
.goto 543,36.85,70.56
.complete 34700,1 
step
#requires GorgrondOgreTeeth
#completewith next
.goto 543,38.58,67.38,10 >>Leave the cave
step
#requires GorgrondOgreTeeth
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prowler Sasha|r.
.target Prowler Sasha
.goto 543,41.43,66.09
.turnin 34012 >>Turn in Need More Teeth
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beatface|r, |cRXP_FRIENDLY_Y'kish|r, |cRXP_FRIENDLY_Bruto|r, |cRXP_FRIENDLY_Akaani|r and |cRXP_FRIENDLY_Kash'drakor|r.
.goto 543,42.73,63.03
.turnin 34702 >>Turn in Krav'ogra
.turnin 34703 >>Turn in The Axe of Kor'gall
.turnin 34700 >>Turn in Slave Hunters
.turnin 34698 >>Turn in Slave Hunters
.accept 35152 >>Accept The Sparring Arena
.turnin 35882 >>Turn in The Interest of Bruto
.target Beatface
.target Yikish
.target Bruto
.target Akaani
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Dying Beast|r.
.target Dying Beast
.goto 543,44.24,61.61
.skipgossip
.complete 35025,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,44.27,61.64
.turnin 35025 >>Turn in We Have Company
.accept 35730 >>Accept Cauterizing Wounds
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Bonfire|r.
.goto 543,44.37,61.33
.complete 35730,1 
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with |cRXP_FRIENDLY_Nisha|r.
.goto 543,44.26,61.60
.complete 35730,2 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,44.28,61.64
.turnin 35730 >>Turn in Cauterizing Wounds
.accept 35026 >>Accept On the Mend
.accept 35870 >>Accept Basilisk Butcher
step
#completewith next
>>You have 60 seconds to get the following four items after using the ability. |cRXP_WARN_Before using the ability pull some mobs and damage them until they have only ~20% HP left.
*Skip the ones you didn't get
.cast 164012 >>Use Champion's Honor (Zone Ability)
step
#sticky
#label GorgrondGonnEyeRockthrower
*1) Loot 'Gronn Eye' from |cRXP_ENEMY_'Gronn Rockthrowers'|r.
*Skip the items you haven't looted after 60 seconds.
.goto 543,43.86,62.71,15,0
.goto 543,43.85,63.35,15,0
.goto 543,44.74,62.84,15,0
.goto 543,45.76,64.53,15,0
.collect 114023,1,36083,1
.accept 36083 >>Accept Proof of Strength: Gronn Eye
.mob Gronn Rockthrower
step
*2) Loot 'Elemental Crystal' from the |cRXP_ENEMY_'Steamfuries'|r.
*Skip the items you haven't looted after 60 seconds.
.goto 543,45.28,62.63,15,0
.goto 543,45.38,61.77,15,0
.collect 114038,1,36106,1
.accept 36106 >>Accept Proof of Strength: Elemental Crystal
.mob Rippling Steamfury
.mob Turbulent Steamfury
step
#requires GorgrondGonnEyeRockthrower
#completewith next
>>Kill |cRXP_ENEMY_Steamfuries|r around the pools. Loot them for the [|cRXP_LOOT_water|r].
.goto 543,45.53,59.40,15,0
.complete 35026,1 
.mob Rippling Steamfury
.mob Turbulent Steamfury
step
#requires GorgrondGonnEyeRockthrower
>>Kill |cRXP_ENEMY_Basilisks|r. Loot them for their [|cRXP_LOOT_meat|r. Or pick it up from |cRXP_ENEMY_Decaying Basilisks|r].
.goto 543,44.50,60.03
.complete 35870,1 
.mob Stoneshamble Basilisk
step
>>Kill |cRXP_ENEMY_Steamfuries|r around the pools. Loot them for the [|cRXP_LOOT_water|r].
.goto 543,44.15,57.57
.complete 35026,1 
.mob Rippling Steamfury
.mob Turbulent Steamfury
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nisha|r.
.target Nisha
.goto 543,45.87,54.95
.turnin 35870 >>Turn in Basilisk Butcher
.turnin 35026 >>Turn in On the Mend
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r twice.
.target Rexxar
.goto 543,46.02,54.75
.skipgossip
.accept 35036 >>Accept Is This One of Yours?
.complete 35036,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bony Xuk|r.
.target Bony Xuk
.goto 543,46.18,55.09
.turnin 35036 >>Turn in Is This One of Yours?
.accept 35038 >>Accept What the Bony Xuk?
.accept 35202 >>Accept Shells for Xuk
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,46.05,54.75
.accept 35037 >>Accept Bad at Breaking
.accept 35934 >>Accept Nisha's Vengeance
step
>>Kill |cRXP_ENEMY_Gorger|r. Loot them for their [|cRXP_LOOT_shells|r].
>>Pick up the |cRXP_PICK_Crystals|r from the corpses of |cRXP_ENEMY_Longtooth Gorgers|r.
#loop
.line 543,45.57,52.41,44.59,53.72,43.77,53.54,44.58,51.32
.goto 543,45.57,52.41,20,0
.goto 543,44.59,53.72,20,0
.goto 543,43.77,53.54,20,0
.goto 543,44.58,51.32,20,0
.complete 35038,1 
.complete 35202,1 
.mob Boneyard Tunneler
.mob Boneyard Gorger
.target Longtooth Gorger
step
#sticky
#label GorgrondGromkarGrunt
>>Kill |cRXP_ENEMY_Grom'kar Grunts|r.
.goto 543,47.91,52.91,0,0
.complete 35934,1 
.mob Grom'kar Grunt
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Orders|r.
.goto 543,47.75,52.07
.accept 35925 >>Accept The Gronn Strategy
step
>>Kill |cRXP_ENEMY_Gronnslaver Raz|r.
.goto 543,47.78,51.81
.complete 35037,2 
.mob Gronnslaver Raz
step
>>Kill the |cRXP_ENEMY_Mangled Boulderbreaker|r.
.goto 543,47.94,54.31
.complete 35037,1 
.mob Mangled Boulderbreaker
step
#requires GorgrondGromkarGrunt
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,46.04,54.75
.turnin 35037 >>Turn in Bad at Breaking
.turnin 35934 >>Turn in Nisha's Vengeance
.turnin 35925 >>Turn in The Gronn Strategy
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bony Xuk|r.
.target Bony Xuk
.goto 543,46.20,55.09
.turnin 35202 >>Turn in Shells for Xuk
.turnin 35038 >>Turn in What the Bony Xuk?
.accept 35041 >>Accept Xuk It!
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Tunnel|r.
.goto 543,46.92,55.38
.complete 35041,1 
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Rylak corpse|r.
.goto 543,45.75,50.39
.complete 35041,2 
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Tunnel|r.
.goto 543,45.75,50.39
.complete 35041,3 
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Tunnel|r.
.goto 543,44.30,41.77
.complete 35041,4 
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_corpse|r.
.goto 543,43.16,42.30
.complete 35041,5 
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Tunnel|r.
.goto 543,43.01,42.49
.complete 35041,6 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,46.04,54.74
.turnin 35041 >>Turn in Xuk It!
.accept 35129 >>Accept Leave Every Soldier Behind
.accept 35128 >>Accept Fair Warning
step
#completewith next
>>You have 60 seconds to get the following four items after using the ability. |cRXP_WARN_Before using the ability pull some mobs and damage them until they have only ~20% HP left.
*Skip the ones you didn't get
.cast 164012 >>Use Champion's Honor (Zone Ability)
step
*Loot 'Worn Ogron Horn' from the |cRXP_ENEMY_'Ogron Spinecrushers'|r.
*Skip the items you haven't looted after 60 seconds.
.goto 543,43.49,48.05,15,0
.goto 546,58.71,79.16,15,0
.goto 543,35.77,65.86,15,0
.collect 114019,1,36076,1
.accept 36076 >>Accept Proof of Strength: Ogron Horn
.mob Ogron Spinecrusher
step
#sticky
#label GorgrondOgronSpinecrusher
>>Kill |cRXP_ENEMY_Ogron Spinecrushers|r.
.goto 546,51.76,64.72,0,0
.complete 35128,1 
.mob Ogron Spinecrusher
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Corporal Thukmar|r and pick up the |cRXP_PICK_intel|r afterwards.
.goto 546,46.50,57.62,20,0
.goto 546,41.17,58.75,12,0
.goto 546,44.84,85.81
.skipgossip
.complete 35129,1 
.complete 35129,2 
.target Corporal Thukmar
step
>>Kill |cRXP_ENEMY_Borogahn|r.
.goto 547,31.07,75.36
.complete 35128,2 
.mob Borogahn
step
#requires GorgrondOgronSpinecrusher
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Tunnel|r.
.goto 547,34.77,66.63
.accept 35210 >>Accept A Great Escape
.complete 35210,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bony Xuk|r.
.target Bony Xuk
.goto 543,43.89,48.85
.accept 35247 >>Accept Zero Xuks Given
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bony Xuk|r again.
.target Bony Xuk
.goto 543,43.89,48.85
.skipgossip
.complete 35247,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,43.94,48.86
.turnin 35128 >>Turn in Fair Warning
.turnin 35129 >>Turn in Leave Every Soldier Behind
.turnin 35210 >>Turn in A Great Escape
.accept 35139 >>Accept Eye in the Sky
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nisha|r.
.target Nisha
*Skip the next cinematic with ESC
.goto 543,43.87,48.91
.skipgossip
.complete 35139,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,43.94,48.86
.turnin 35139 >>Turn in Eye in the Sky
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the Spirit
.goto 543,44.12,48.81
.turnin 35247 >>Turn in Zero Xuks Given
.turnin 36832 >>Turn in Get The Xuk Outta Here!
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rexxar|r.
.target Rexxar
.goto 543,43.94,48.86
.accept 35136 >>Accept Chains of Iron
step
.goto 543,44.71,48.69
.accept 36480 >>Accept Valley of Destruction (Bonus Objective)
step
#sticky
#label GorgrondCanyonBoulderbreak
>>Kill the closest |cRXP_ENEMY_Boulderbreakers|r around the waypoint.
.goto 543,45.73,46.44
.complete 36480,1 
.mob Canyon Boulderbreaker
step
>>Break |cRXP_ENEMY_Goren Eggs|r and kill |cRXP_ENEMY_Nibblers|r around the waypoint.
.goto 543,47.62,48.11
.complete 36480,2 
.complete 36480,3 
.mob Goren Nibbler
step
#requires GorgrondCanyonBoulderbreak
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakthoth|r.
.target Rakthoth
.goto 543,49.37,49.70
.turnin 33694 >>Turn in Reagents from Rakthoth
.accept 33689 >>Accept Plant Pruning
.accept 33685 >>Accept Ambassador to the Ancient
step
#sticky
#label defendersdionor
#loop
.line 543,49.80,47.63,49.46,47.19,49.82,46.36,50.28,46.09,50.89,46.31
.goto 543,49.80,47.63,15,0
.goto 543,49.46,47.19,15,0
.goto 543,49.82,46.36,15,0
.goto 543,50.28,46.09,15,0
.goto 543,50.89,46.31,15,0
>>Kill the |cRXP_ENEMY_Seedpriests|r or |cRXP_ENEMY_Growths|r.
.complete 33689,1 
.mob Dionor Seedpriest
.mob Primal Growth
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Birchus|r.
.goto 543,50.29,47.52
.skipgossip 1
.complete 33685,1 
.target Birchus
step
#requires defendersdionor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakthoth|r.
.target Rakthoth
.goto 543,51.28,47.98
.turnin 33689 >>Turn in Plant Pruning
.turnin 33685 >>Turn in Ambassador to the Ancient
.accept 33662 >>Accept Beatface vs. Boulder
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Boulder|r.
.goto 543,50.63,51.45
.complete 33662,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakthoth|r.
.target Rakthoth
.goto 543,50.91,51.43
.turnin 33662 >>Turn in Beatface vs. Boulder
.accept 33661 >>Accept Steamscar "Reagents"
step
>>|TInterface/GossipFrame/HealerGossipIcon:0|tInteract with the |cRXP_PICK_Saberon Stash|r.
.goto 543,51.05,51.62
.accept 33660 >>Accept The Sacking of the Saberon
step
#sticky
#label GorgrondSaberonHeart
>>Kill |cRXP_ENEMY_Steamscars|r. Loot them for their [|cRXP_LOOT_hearts|r].
.goto 543,51.86,51.27,0,0
.complete 33661,1 
.mob Steamscar Warrior
.mob Steamscar Primalist
step
#title Herb Bundle 1/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,51.41,51.87
.complete 33660,1,1 
step
#title Herb Bundle 2/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,51.66,52.47
.complete 33660,1,2 
step
#title Herb Bundle 3/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,51.95,51.04
.complete 33660,1,3 
step
#title Herb Bundle 4/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,53.23,50.98
.complete 33660,1,4 
step
#title Herb Bundle 5/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,53.64,50.82
.complete 33660,1,5 
step
#title Herb Bundle 6/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,53.70,51.20
.complete 33660,1,6 
step
#title Herb Bundle 7/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,53.59,51.75
.complete 33660,1,7 
step
#title Herb Bundle 8/8
>>Pick up the |cRXP_PICK_bundle|r.
.goto 543,53.47,51.82
.complete 33660,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakthoth|r.
.target Rakthoth
.goto 543,52.86,51.76
.turnin 33660 >>Turn in The Sacking of the Saberon
.turnin 33661 >>Turn in Steamscar "Reagents"
.accept 33695 >>Accept Taking the Death Bloom
step
>>Kill |cRXP_ENEMY_Smokemaster Snarl|r. Loot him for the [|cRXP_LOOT_Death Bloom|r].
.goto 543,54.27,52.61
.complete 33695,1 
.mob Smokemaster Snarl
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Birchus|r.
.target Birchus
.goto 543,50.30,47.53
.turnin 33695 >>Turn in Taking the Death Bloom
.accept 33706 >>Accept Laying Dionor to Rest
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tWait for ~5 seconds. Talk to |cRXP_FRIENDLY_Birchus|r again.
.goto 543,50.30,47.53
.turnin 33706 >>Turn in Laying Dionor to Rest
.target Birchus
step
.goto 543,48.93,47.31
.turnin 36203 >>Pick up the |cRXP_PICK_egg|r inside the cave.
step
>>Defeat the incoming waves. Kill |cRXP_ENEMY_Captain Brak|r at the end.
*|cRXP_WARN_If you're squishy only attack NPCs Rexxar is attacking and wait for him to generate some threat|r.
.goto 543,49.21,44.90
.complete 35136,1 
.mob Captain Brak
step
>>Pick up the |cRXP_PICK_Heart|r.
.goto 543,49.73,43.85
.complete 35136,2 
step
#completewith next
.hs >>Hearth to Beastwatch
step
.goto 543,48.88,69.68
.accept 36563 >>Accept Mistcreep Mire (Bonus Objective)
step
#completewith next
>>You have 60 seconds to get the following item after using the ability. |cRXP_WARN_Before using the ability pull some mobs and damage them until they have only ~20% HP left.
*Skip the ones you didn't get
.cast 164012 >>Use Champion's Honor (Zone Ability)
step
*Loot 'Basilisk Scale' from the |cRXP_ENEMY_'Mire Basilisks'|r.
*Skip the items you haven't looted after 60 seconds.
.goto 543,50.09,69.19,15,0
.goto 543,51.58,68.46
.collect 114036,1,36104,1
.accept 36104 >>Accept Proof of Strength: Basilisk Scale
.mob Mire Basilisk
step
#sticky
#label hydravilescale
>>Break |cRXP_ENEMY_Eggs|r and kill |cRXP_ENEMY_Vilescales|r around the waypoint.
.goto 543,51.84,66.54,0,0
.complete 36563,1 
.complete 36563,2 
.mob Lernaea Vilescale
.mob Hydra Egg
step
.goto 543,52.50,66.95
.turnin 36509 >>Pick up the |cRXP_PICK_skull|r.
step
#requires hydravilescale
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grulkor|r.
.target Grulkor
.goto 543,54.45,66.65
.turnin 35667 >>Turn in Skulltakers in Crimson Fen
.accept 35016 >>Accept Basic Skulltaking
step
#sticky
#label GorgrondFungalLurcher
>>Kill |cRXP_ENEMY_Fungal Lurchers|r in the area.
.goto 543,56.79,63.49,0,0
.complete 35017,1 
.mob Fungal Lurcher
step
#sticky
#label laughingskull1
#title Laughing Skull 1/5
>>Take the |cRXP_PICK_Laughing Skull|r from the |cRXP_ENEMY_Dead Skulltaker|r.
.goto 543,54.56,65.58
.complete 35016,1,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dying Skulltaker|r.
.target Dying Skulltaker
.goto 543,54.84,65.31
.accept 35017 >>Accept Skulltaker's Revenge
step
>>Kill |cRXP_ENEMY_Fungal Lurcher|r. Loot them for the [|cRXP_LOOT_Glowing Red Pod|r]. |TInterface/cursor/crosshair/interact.blp:20|tClick it in your bags
.goto 543,54.84,65.31
.collect 112378,1,35021
.accept 35021 >>Accept Mysterious Pod
.mob Fungal Lurcher
step
#requires laughingskull1
#title Laughing Skull 2/5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dying Skulltaker|r.
.goto 543,55.25,65.19
.complete 35016,1,2 
step
#title Laughing Skull 3/5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dying Skulltaker|r.
.goto 543,55.54,64.68
.complete 35016,1,3 
step
#title Laughing Skull 4/5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dying Skulltaker|r.
.goto 543,55.83,64.66
.complete 35016,1,4 
step
#title Laughing Skull 5/5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dying Skulltaker|r.
.goto 543,56.11,64.59
.complete 35016,1 
step
#requires GorgrondFungalLurcher
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grulkor|r.
.target Grulkor
.goto 543,57.20,61.95
.turnin 35016 >>Turn in Basic Skulltaking
.turnin 35017 >>Turn in Skulltaker's Revenge
.turnin 35021 >>Turn in Mysterious Pod
.accept 35027 >>Accept Clearing the Way
.accept 35029 >>Accept The Secret of the Fungus
step
#sticky
#label GorgrondFungusCoveredShamblers
>>Kill |cRXP_ENEMY_Fungus Covered Shambler|r.
.goto 543,57.31,60.74,0,0
.complete 35027,1 
.mob Fungus Covered Shambler
step
>>Pickup the five |cRXP_PICK_mushrooms|r that are closest to the waypoint.
.goto 543,57.31,60.74
.complete 35029,1 
step
#requires GorgrondFungusCoveredShamblers
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grulkor|r.
.target Grulkor
.goto 543,57.20,61.95
.turnin 35027 >>Turn in Clearing the Way
.turnin 35029 >>Turn in The Secret of the Fungus
.accept 35030 >>Accept A Grim Harvest
.accept 35031 >>Accept A Heartfelt Search
step
>>Follow the arrow
.goto 543,58.93,62.53
.complete 35031,1 
step
>>Kill |cRXP_ENEMY_Fungal Stompers|r. Loot them for the [|cRXP_LOOT_pods|r].
.goto 543,58.48,62.79,20,0
.goto 543,58.92,61.34,20,0
.goto 543,59.91,62.75
.complete 35030,1 
.mob Fungal Stomper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grulkor|r.
.target Grulkor
.goto 543,58.91,62.52
.turnin 35030 >>Turn in A Grim Harvest
.turnin 35031 >>Turn in A Heartfelt Search
.accept 35040 >>Accept Heart of the Fen
step
>>Kill |cRXP_ENEMY_Grulkor|r.
*If you damage is low wait for your cooldowns.
.goto 543,61.22,61.83
.complete 35040,1 
.mob Grulkor
step
.goto 543,61.20,57.58
.accept 36571 >>Accept Iyun Weald (Bonus Objective)
step
#sticky
#label GorgrondWealdStinger
>>Kill |cRXP_ENEMY_Weald Stingers|r.
>>They fly above you. Use a ranged ability to pull them.
.complete 36571,3 
.mob Weald Stinger
step
>>Kill |cRXP_ENEMY_Thorny Stabbers|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_ENEMY_Leaflings|r to insta-kill them.
.goto 543,61.35,56.61,15,0
.goto 543,60.88,55.54,15,0
.goto 543,61.01,54.37,15,0
.goto 543,60.61,53.62,15,0
.goto 543,61.12,53.22
.complete 36571,1 
.complete 36571,2 
.mob Thorny Stabber
.mob Thorny Leafling
step
#requires GorgrondWealdStinger
.goto 543,61.52,63.20
.accept 36564 >>Accept Tangleheart (Bonus Objective)
step
#sticky
#label GorgrondTangleheartCultivator
>>Kill |cRXP_ENEMY_Tangleheart Cultivator|r.
.goto 543,58.60,71.52,0,0
.complete 36564,1 
step
#title Pod 1/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,61.89,63.64
.complete 36564,2,1 
step
#title Pod 2/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,62.03,65.41
.complete 36564,2,2 
step
#title Pod 3/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,61.56,66.39
.complete 36564,2,3 
step
#title Pod 4/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,60.74,65.95
.complete 36564,2,4 
step
#title Pod 5/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,59.43,65.68
.complete 36564,2,5 
step
#title Pod 6/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,59.31,66.99
.complete 36564,2,6 
step
#title Pod 7/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,59.38,67.88
.complete 36564,2,7 
step
#title Pod 8/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,59.86,68.72
.complete 36564,2,8 
step
#title Pod 9/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,60.16,69.79
.complete 36564,2,9 
step
>>Kill |cRXP_ENEMY_Ontogen the Harvester|r.
.goto 543,59.87,71.06
.complete 36564,3 
.mob Ontogen the Harvester
step
#title Pod 10/10
>>|TInterface/GossipFrame/HealerGossipIcon:0|tDestroy the |cRXP_PICK_Pod|r.
.goto 543,59.39,71.03
.complete 36564,2 
step
#completewith next
>>You have 60 seconds to get the following 2 items after using the ability. |cRXP_WARN_Before using the ability pull some mobs and damage them until they have only ~20% HP left.
*Skip the ones you didn't get
.cast 164012 >>Use Champion's Honor (Zone Ability)
step
*1) Loot 'Orc Thorn' from |cRXP_ENEMY_'Infested Behemoths'|r.
*2) Loot 'Ancient Branch' from the |cRXP_ENEMY_'Bloom Defender'|r.
*Skip if you don't loot it after 60 seconds.
.goto 543,48.44,74.05,20,0
.goto 543,47.06,73.15,20,0
.goto 543,46.11,73.29,20,0
.collect 114027,1,36091,1
.collect 114030,1,36094,1
.accept 36091 >>Accept Proof of Strength: Orc Thorn
.accept 36094 >>Accept Proof of Strength: Ancient Branch
.mob Infested Behemoth
.mob Bloom Defender
step
#requires GorgrondTangleheartCultivator
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limbflayer|r.
.target Limbflayer
.goto 543,46.33,69.71
.turnin -35152 >>Turn in The Sparring Arena
.turnin -35948 >>Turn in Proof of Strength: Goren Tooth
.turnin -36076 >>Turn in Proof of Strength: Ogron Horn
.turnin -36080 >>Turn in Proof of Strength: Gronnling Scale
.turnin -36083 >>Turn in Proof of Strength: Gronn Eye
.turnin -36086 >>Turn in Proof of Strength: Botani Bloom
.turnin -36091 >>Turn in Proof of Strength: Orc Thorn
.turnin -36097 >>Turn in Proof of Strength: Ravager Claw
.turnin -36101 >>Turn in Proof of Strength: Wasp Stinger
.turnin -36104 >>Turn in Proof of Strength: Basilisk Scale
.turnin -36106 >>Turn in Proof of Strength: Elemental Crystal
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marrow|r.
.target Marrow
.goto 543,46.28,69.98
.turnin 35040 >>Turn in Heart of the Fen
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Durotan|r.
.target Durotan
.goto 543,46.10,70.19
.turnin 35136 >>Turn in Chains of Iron
step
.zoneskip 590
#completewith next
.cast 171253 >>Use your Garrison Hearthstone
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Zog|r in front of you.
.turnin 34462 >>Turn in Winds of Change
.accept 34775 >>Accept Mission Probable
.target Warmaster Zog
step
>>Interact with the Mission Table and skip through the tutorial
*If you can't press on the mission then type '/reload' into the chat.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on the first Mission then drag |cRXP_FRIENDLY_Olin Umberhide|r into the follower slot and start it.
.complete 34775,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Zog|r.
.target Warmaster Zog
.turnin 34775 >>Turn in Mission Probable
step
.isQuestTurnedIn 44184
#completewith next
.use 140192
.cast 222695 >>Use Dalaran Hearthstone
step
.isQuestTurnedIn 44184
.goto 627,55.28,23.95
.zone 85 >>Take the portal to Orgrimmar
step
.isQuestAvailable 44184
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r.
.target Gazlowe
.accept 36706 >>Accept Ashran Appearance
step
.isQuestAvailable 44184
>>Go to the Flight Master and talk to him
.skipgossip 2
.complete 36706,1 
step
#label GorgrondHordeEnd
.isQuestAvailable 44184
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stomphoof|r.
.target Stomphoof
.goto 624,45.55,34.64
.turnin 36706 >>Turn in Ashran Appearance
step
.isQuestAvailable 44184
.zoneskip 85
.goto 624,60.76,51.59,1 >>Use the Portal to Orgrimmar
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Val'sharah Speedrun Midnight Horde
#internal
<< Horde
step
#completewith ValsharahHordeEnd
#hidewindow
+1
.usespell 1231411
step
.pve
.zoneskip 85,1
#title Go to Orgrimmar. Active War Mode. Skip if you don't want to.
+|cRXP_WARN_Skip if you don't want to activate War Mode|r. (Bottom Right on your Talent Window (N)) even though it increases your experience gain by at least 10%
step
.use 140192
.zone 627 >>Use Dalaran Hearthstone
step
#arrowtext Fly to him
.goto 641,54.69,72.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r
.accept 40122 >>Accept Cenarius, Keeper of the Grove
.target Malfurion Stormrage
step
#include RestedXP Speed Leveling\a) Val'sharah Intro Midnight@ValsharahIntroA-ValsharahIntroZ
step
.isQuestAvailable 39093
.goto 641,54.18,70.58
.turnin 39093 >>Click on the |cRXP_PICK_Small Treasure Chest|r under the tree.


step
#include RestedXP Speed Leveling\a) Archdruid of Lore Midnight@ArchdruidofLoreA-ArchdruidofLoreB
step
#completewith next
#label Marnor Lorleaf
#hidewindow
.complete 38235,1 
.target Marnor Lorleaf
step
#completewith Marnor Lorleaf
.goto 641,43.80,70.19
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Marnor Lorleaf|r.
step
#requires Marnor Lorleaf
#completewith next
#label Sagewood
#hidewindow
.complete 38235,3 
.target Del'thanar Sagewood
step
#requires Marnor Lorleaf
#completewith Sagewood
.goto 641,43.80,75.30
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Del'thanar Sagewood|r.
step
#requires Sagewood

#completewith Erwind Mistfen2
>>Kill the |cRXP_ENEMY_Stoneblood Witches|r. Destroy the |cRXP_PICK_Hatching Harp Eggs|r with an AOE ability.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dry Harpy Nests|r and |cRXP_FRIENDLY_Acolytes of Elothir|r.
.complete 38372,1 
.target Acolyte of Elothir
.mob Stoneblood Temptress
.mob Stoneblood Elderwitch
step
#requires Sagewood
.isQuestAvailable 38363
.goto 641,43.40,75.90
.turnin 38363 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#label Magula
#completewith next
#title |cFFFCDC00Enter Cave|r
.goto 641,45.47,76.99,15,0
>>Kill |cRXP_ENEMY_Magula|r.
*|cRXP_WARN_Jump to remove|r |T136093:0|t[Stoneblood Poison].
.complete 38225,1 
.mob Magula
step
#completewith Magula
.goto 641,45.79,77.85,50 >>Enter the Cave
step
#requires Magula
.goto 641,45.79,77.85
>>Kill |cRXP_ENEMY_Magula|r.
*|cRXP_WARN_Jump to remove|r |T136093:0|t[Stoneblood Poison].
.complete 38225,1 
.mob Magula
step
#completewith next
#label Erwind Mistfen
#hidewindow
.goto 641,45.57,77,15,0
.complete 38235,2 
step
#completewith Erwind Mistfen
#label Erwind Mistfen2
.goto 641,46.71,76.4
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Erwind Mistfen|r.
.target Erwind Mistfen
step
#requires Erwind Mistfen
#loop
.goto 641,45.71,74.69,25,0
.goto 641,43.6,75.78,25,0
.goto 641,42.27,78.58,25,0
.goto 641,44.47,78.55,25,0
>>Kill the |cRXP_ENEMY_Stoneblood Witches|r. Destroy the |cRXP_PICK_Hatching Harp Eggs|r with an AOE ability.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dry Harpy Nests|r and |cRXP_FRIENDLY_Acolytes of Elothir|r.
.complete 38372,1 
.target Acolyte of Elothir
.mob Stoneblood Temptress
.mob Stoneblood Elderwitch
step
.goto 641,48.85,70.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elothir|r.
.turnin 38225 >>Turn in Death to the Witchmother
.turnin 38235 >>Turn in Solid as a Rock
.target Elothir
step
.isQuestAvailable 38366
.goto 641,48.69,73.79
.turnin 38366 >>Click on the |cRXP_PICK_Small Treasure Chest|r under the tree.
step
#include RestedXP Speed Leveling\a) Archdruid of the Claw Midnight@ArchdruidOfTheClawA-ArchdruidOfTheClawB
step
.isQuestAvailable 38277
.goto 641,46.45,86.32
.turnin 38277 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Claw Midnight@ArchdruidOfTheClawC-ArchdruidOfTheClawD
step
#title In the small cave
.isQuestAvailable 38886
.goto 641,48.99,86.15
.turnin 38886 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Claw Midnight@ArchdruidOfTheClawE-ArchdruidOfTheClawZ
step
#include RestedXP Speed Leveling\a) Lunarwing Shallows Midnight@LunarwingShallowsA-LunarwingShallowsB
step
#title In the cave
.isQuestAvailable 38861
.goto 641,56.03,83.75
.turnin 38861 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
.isOnQuest 38842
#loop
.goto 641,51.94,80.40,30,0
.goto 641,52.46,83.18,30,0
.goto 641,53.67,85.96,30,0
.goto 641,55.67,85.81,30,0
.goto 641,54.98,81.62,30,0
>>Kill the |cRXP_ENEMY_Thistleleaf forces|r.
.complete 38842,1 
step
.goto 641,53.75,79.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Saylanna Riverbreeze|r.
.turnin 38862 >>Turn in Thieving Thistleleaf
.turnin 40220 >>Turn in Thorny Dancing
.turnin 40221 >>Turn in Spread Your Lunarwings and Fly
.target Saylanna Riverbreeze
step
#include RestedXP Speed Leveling\a) Lostlight Grotto Midnight@LostlightGrottoA-LostlightGrottoB
step
.isOnQuest 42751
.isQuestAvailable 38893
.goto 641,60.49,82.15
.turnin 38893 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#completewith LostlightGrottoChestC
#label LostlightGrottoChestA
.isOnQuest 42751
.isQuestAvailable 38893
.turnin 38893 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#completewith LostlightGrottoChestA
#label LostlightGrottoChestB
#title |cFFFCDC00Leave Cave|r
.goto 641,59.91,84.34,10,0
.goto 641,61.11,85.17,10 >>|cRXP_WARN_Leave the cave|r
step
#requires LostlightGrottoChestB
#completewith LostlightGrottoChestA
#label LostlightGrottoChestC
.goto 641,62.56,85.74,6 >>|cRXP_WARN_Follow the arrow into the cave.|r
step
#requires LostlightGrottoChestA
.isOnQuest 42751
.isQuestAvailable 38893
.goto 641,62.70,85.26
.turnin 38893 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
.isQuestAvailable 38389
.goto 641,63.38,88.40
.turnin 38389 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#title Under the tree roots
.isQuestAvailable 39074
.goto 641,65.38,86.27
.turnin 39074 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
.goto 641,59.32,84.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 42751 >>Turn in Moon Reaver
.target Keeper Remulos
step
#title In a small cave
.isQuestAvailable 39089
.goto 641,61.01,79.18
.turnin 39089 >>Click on the |cRXP_PICK_Glimmering Treasure Chest|r.
step
.isQuestAvailable 39087
.goto 641,61.63,73.70
.turnin 39087 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Vale Midnight@ArchdruidOfTheValeA-ArchdruidOfTheValeB
step
#completewith next
#label TheWildwoodChestA
.isQuestAvailable 39071
.turnin 39071 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
#title Enter the waterfall cave
#completewith TheWildwoodChestA
.goto 641,62.00,67.94,8 >>|cRXP_WARN_Follow the arrow into the cave behind the waterfall.|r
step
#requires TheWildwoodChestA
#title In the waterfall cave
.isQuestAvailable 39071
.goto 641,62.06,67.37
.turnin 39071 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Vale Midnight@ArchdruidOfTheValeC-ArchdruidOfTheValeD
step
#completewith MoonclawValeChestC
#label MoonclawValeChestA
.isQuestAvailable 39102
.turnin 39102 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
#completewith MoonclawValeChestA
#label MoonclawValeChestB
.goto 641,63.43,66.95,10,0
.goto 641,62.97,68.10,10 >>Leave the Moonclaw Cavern
step
#title |cFFFCDC00Enter House|r
#requires MoonclawValeChestB
#completewith MoonclawValeChestA
#label MoonclawValeChestC
.goto 641,63.06,73.60,6 >>|cRXP_WARN_Follow the arrow into the house.|r
step
#requires MoonclawValeChestA
#title In the house
.isQuestAvailable 39102
.goto 641,63.27,74.01
.turnin 39102 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
.goto 641,62.41,76.45
>>|cRXP_WARN_Follow the arrow|r to Archdruid's Den
.complete 40573,2 
step
.isQuestAvailable 39070
.goto 641,63.04,76.96
.turnin 39070 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Vale Midnight@ArchdruidOfTheValeE-ArchdruidOfTheValeF
step
.isQuestAvailable 38391
.goto 641,65.87,79.19
.turnin 38391 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Grizzleweald Midnight@GrizzlewealdA-GrizzlewealdZ
step

.isQuestTurnedIn 38382
#loop
.goto 641,64.86,74.20,35,0
.goto 641,60.72,69.94,35,0
.goto 641,61.26,73.26,35,0
.goto 641,63.44,75.43,35,0
>>Kill the |cRXP_ENEMY_Nightmare Imps|r and |cRXP_ENEMY_Darkfiend Satyr|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nightmare Totems|r and |cRXP_FRIENDLY_Moonclaw Druids|r.
.complete 39393,1 
.mob Nightmare Imp
.mob Darkfiend Corruptor
.mob Darkfiend Zealot
.target Moonclaw Druid
step
.goto 641,51.92,64.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r.
.turnin 38323 >>Turn in Return to the Grove
.target Malfurion Stormrage
step
#include RestedXP Speed Leveling\a) Into the Nightmare Midnight@IntoTheNightmareA-IntoTheNightmareB
step
.isQuestAvailable 39072
.goto 641,56.23,57.31
.turnin 39072 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Into the Nightmare Midnight@IntoTheNightmareC-IntoTheNightmareCA
step
.isOnQuest 38582
.isQuestAvailable 38782
.goto 641,67.20,59.27
.turnin 38782 >>Click on the |cRXP_PICK_Treasure Chest|r.
step

.isQuestTurnedIn 38641
#loop
.goto 641,58.62,54.59,35,0
.goto 641,56.64,51.62,45,0
.goto 641,59.55,58.73,45,0
>>Kill the |cRXP_ENEMY_Defiled Grovewalker|r, |cRXP_ENEMY_Ancient Annihilator|r, |cRXP_ENEMY_Terrorfiend Bats|r and |cRXP_ENEMY_Darkfiend Satyr|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangling Vines|r.
.complete 39029,1 
.mob Defiled Grovewalker
.mob Ancient Annihilator
.mob Darkfiend Satyr
.mob Terrorfiend Bats
step
#include RestedXP Speed Leveling\a) Braddensbrook Midnight@BraddensbrookA-BraddensbrookB
step
#title Inside the house
.isQuestAvailable 39077
.goto 641,42.67,58.01
.turnin 39077 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Braddensbrook Midnight@BraddensbrookC-BraddensbrookD
step
#title Inside the cellar
.isOnQuest 38644
.isQuestAvailable 39080
.goto 641,38.43,65.32
.turnin 39080 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Braddensbrook Midnight@Shriek No More-BraddensbrookZ
step
#include RestedXP Speed Leveling\a) Black Rook Hold Midnight@BlackRookHoldA-BlackRookHoldB
step
#label ValsharahHordeEnd

.isQuestTurnedIn 38718
#loop
.goto 641,40.14,54.88,45,0
.goto 641,43.74,53.68,35,0
.goto 641,43.26,46.71,40,0
.goto 641,42.85,51.04,45,0
>>Kill the |cRXP_ENEMY_Black Rook forces|r and |cRXP_ENEMY_Risen Saber|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Racks|r and |cRXP_PICK_Kaldorei Tomes|r.
.complete 38716,1 
.mob Reanimated Archer
.mob Risen Soldier
.mob Risen Saber
.mob Servant of Ravencrest
step
#include RestedXP Speed Leveling\a) Black Rook Hold Midnight@BlackRookHoldC-BlackRookHoldZ
step
.goto 641,52.47,63.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysera|r
.turnin 38663 >>Turn in The Die is Cast
.target Ysera
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Highmountain Speedrun Midnight Horde
#internal
<< Horde
step
#completewith HighmountainHordeEnd
#hidewindow
+1
.usespell 1231411
step
#label HighmountainSpeedrun1A
.goto 650,35.97,65.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Oro|r.
.target Warbrave Oro
.accept 38907 >>Accept Keepers of the Hammer
step
.isQuestAvailable 40488
.goto 650,36.62,62.14
.turnin 40488 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#include RestedXP Speed Leveling\a) The Rivermane Tribe Midnight@TheRivermaneTribeStart1-TheRivermaneTribeEnd1
step
.isQuestAvailable 40491
.goto 750,13.76,55.38
.turnin 40491 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angler Creel|r and |cRXP_FRIENDLY_Jale Rivermane|r.
.turnin 39496 >>Turn in The Flow of the River
.accept 39316 >>Accept Trapped Tauren
.accept 39614 >>Accept Fish Out of Water
.goto 650,41.14,61.58
.target Angler Creel
.accept 39277 >>Accept Spray and Prey
.goto 650,41.17,61.49
.target Jale Rivermane
step
.isQuestAvailable 39274
#completewith HighmountainTaurenTrappedTauren
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
#completewith HighmountainTaurenTrappedTauren
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
#completewith HighmountainTaurenTrappedTauren
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
.goto 650,42.85,63.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood Barricade|r.
.complete 39316,1 
step
.goto 650,40.25,64.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rordan Waterwise|r
.accept 39323 >>Accept Moozy's Sojourn
.target Rordan Waterwise
step
#label HighmountainTaurenTrappedTauren
.goto 650,37.46,64.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bucket|r
.turnin 39323 >>Turn in Moozy's Sojourn
.target Moozy Waterwise
.accept 39572 >>Accept Moozy's Adventure
step
#completewith Drogbar sprayed2
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
#completewith Drogbar sprayed2
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
#completewith Drogbar sprayed2
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
#label Drogbar sprayed2
.isQuestAvailable 40474
.goto 650,39.39,62.28
.turnin 40474>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#hidewindow
#completewith Whitewater Carp
#loop
.goto 650,40.86,62.02,40,0
.goto 650,42.5,63.54,40,0
.goto 650,39.19,65.87,40,0
.goto 650,38.4,63.35,40,0
+1
step
#completewith Drogbar sprayed
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
#completewith Drogbar sprayed
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
#label Drogbar sprayed
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
#completewith next
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fish|r while facing the water to kick it in.
.complete 39614,1 
step
#label Whitewater Carp
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angler Creel|r and |cRXP_FRIENDLY_Jale Rivermane|r.
.turnin 39316 >>Turn in Trapped Tauren
.turnin 39614 >>Turn in Fish Out of Water
.goto 650,41.13,61.57
.target Angler Creel
.turnin 39277 >>Turn in Spray and Prey
.accept 39661 >>Accept Lifespring Cavern
.goto 650,41.18,61.49
.target Jale Rivermane
step
#include RestedXP Speed Leveling\a) The Rivermane Tribe Midnight@TheRivermaneTribeStart2-TheRivermaneTribeEnd2
step
.isQuestAvailable 40476
.goto 656,58.17,60.7,10,0
.goto 656,71.88,56.77,10,0
.goto 655,58.99,18.72,10,0
.goto 655,52.79,23.82
.turnin 40476 >>Click on the |cRXP_PICK_Glimmering Treasure Chest|r for experience.
step
#completewith next
#label Moozy's Adventure
.goto 655,63.21,59.87,15,0
.goto 650,38.31,61.1,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.turnin 39572 >>Turn in Moozy's Adventure
.target Sella Waterwise
step
.zoneskip 650
#completewith Moozy's Adventure
#title |cFFFCDC00Follow the Arrow|r
.goto 650,38.4,61.31,20 >>Leave the Cave
step
#requires Moozy's Adventure
.goto 650,40.01,57.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.turnin 39572 >>Turn in Moozy's Adventure
.target Sella Waterwise
step
.isQuestAvailable 39812
.goto 650,39.53,57.44
.turnin 39812 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
.isQuestAvailable 44731
.goto 650,38.91,54.14,10,0
.goto 650,38.96,54.49
.turnin 44731 >>Click on the |cRXP_PICK_Small Treasure Chest|r |cRXP_WARN_in the tent|r for experience.
step
#include RestedXP Speed Leveling\a) Nesingwary's Retreat Midnight@NesingwarysRetreatStart1-NesingwarysRetreatEnd1
step
#include RestedXP Speed Leveling\a) Mucksnout Den Midnight@Shiny, But Deadly-DemonDetainmentZ
step
.isQuestAvailable 40494
.goto 654,60.73,25.15
.turnin 40494>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label Bristlefur Bear2
.goto 654,42.31,60.56,25,0
.goto 654,34.46,64.12,20,0
.goto 650,38.52,42.4,15,0
>>Kill |cRXP_ENEMY_Bristlefur Bear|r.
*Loot them for |T878263:0|t[|cRXP_LOOT_Bristlefur Pelt|r].
.complete 39392,1 
.mob Bristlefur Bear
step
#completewith Bristlefur Bear2
#title |cFFFCDC00Leave Cave|r

.goto 650,37.82,40.32,120 >>Leave the Cave
step
#requires Bristlefur Bear2
#completewith Bristlefur Bear3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_traps|r and kill |cRXP_ENEMY_wildlife|r to earn experience for |cRXP_FRIENDLY_Addie Fizzlebog|r. Each rank counts as a quest step.
.complete 40216,3 
.complete 40216,4 
.target Addie Fizzlebog
step
#requires Bristlefur Bear2
#loop
.goto 650,37.82,40.32,40,0
.goto 650,36.09,42.46,40,0
.goto 650,37.37,43.46,40,0
.goto 650,37.18,46.38,40,0
>>Kill |cRXP_ENEMY_Bristlefur Bear|r.
*Loot them for |T878263:0|t[|cRXP_LOOT_Bristlefur Pelt|r].
.complete 39392,1 
.mob Bristlefur Bear
step
#completewith next
#label Rashar's Right Eye
>>Kill |cRXP_ENEMY_Rashar|r. Loot him for |T255344:0|t[|cRXP_LOOT_Rashar's Right Eye|r].
*|cRXP_WARN_NOTE:|r Dismount before the cave to make |cRXP_FRIENDLY_Addie|r spawn.
.complete 39867,1 
.mob Rashar
step
#completewith Rashar's Right Eye
#title |cFFFCDC00Enter Cave|r
.goto 650,37.47,49.19,30 >>Enter the Cave
step
#requires Rashar's Right Eye
#label Bristlefur Bear3
.goto 650,37.47,49.19
>>Kill |cRXP_ENEMY_Rashar|r. Loot him for |T255344:0|t[|cRXP_LOOT_Rashar's Right Eye|r].
*|cRXP_WARN_NOTE:|r Dismount before the cave to make |cRXP_FRIENDLY_Addie|r spawn.
.complete 39867,1 
step
#loop
.goto 650,39.67,49.57,30,0
.goto 650,40.81,50.13,30,0
.goto 650,41.39,53.89,30,0
.goto 650,40.54,53.78,30,0
.goto 650,43.31,49.19,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_traps|r and kill |cRXP_ENEMY_wildlife|r to earn experience for |cRXP_FRIENDLY_Addie Fizzlebog|r. Each rank counts as a quest step.
.complete 40216,3 
.complete 40216,4 
.mob Pinerock Stalker
.mob Soothoof Hillstrider
.mob Pinerock Elderhorn
.mob Skittish Doe
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r, |cRXP_FRIENDLY_Laeni Silvershot|r and |cRXP_FRIENDLY_Ellias|r
.turnin 40216 >>Turn in A Hunter at Heart
.turnin 39124 >>Turn in Moose Shootin'
.turnin 39392 >>Turn in Bear Huntin'
.accept 40228 >>Accept Scout It Out
.target +Hemet Nesingwary
.goto 650,40.04,52.25
.accept 39178 >>Accept Moose on the Loose
.goto 650,40,52.31
.target +Laeni Silvershot
.turnin 39867 >>Turn in I'm Not Lion!
.goto 650,40.02,52.37
.target +Ellias
step
#include RestedXP Speed Leveling\a) Riverbend Midnight@RiverbendStart1-RiverbendEnd1
step
#include RestedXP Speed Leveling\a) Riverbend Midnight@RiverbendStart2-RiverbendEnd2
step
.goto 652,54.80,63.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.turnin 38909 >>Turn in Get to High Ground
.accept 38912 >>Accept The Bloodtotem Tribe
.accept 38913 >>Accept The Skyhorn Tribe
.accept 40515 >>Accept A Walk With the Spirits
.target Mayla Highmountain
step
#include RestedXP Speed Leveling\a) Huln's War Midnight@HulnsWarStart1-HulnsWarEnd1
step
.goto 750,57.84,10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mu'sha's Tears|r near the waterfall.
.complete 40520,2 
step
#include RestedXP Speed Leveling\a) Huln's War Midnight@HulnsWarStart2-Tichondrius
step
.goto 652,74.86,75.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 39992 >>Turn in Huln's War - The Nathrezim
.accept 38916 >>Accept Secrets of Highmountain
.target Spiritwalker Ebonhorn
step
.goto 652,54.94,78.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r
.accept 42622 >>Accept Ceremonial Drums
.target Torv Dubstomp
step
#completewith next
#label Secrets of HighmountainZ
.goto 652,41.87,74,15,0
.goto 652,25.81,80.84,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,1 
step
#completewith Secrets of HighmountainZ
#title |cFFFCDC00Leave Building|r
.goto 650,44.88,65.71,185 >>Leave the building.
step
#requires Secrets of HighmountainZ
#label SecretsofHighmountainEnd1
.goto 750,39.47,74.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,1 
step
.goto 750,38.01,78.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,1 
step
.goto 650,45.1,65.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,2 
.complete 42622,2,2 
step
.goto 650,44.88,65.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 38916 >>Turn in Secrets of Highmountain
.target Spiritwalker Ebonhorn
.accept 39575 >>Accept The Path of Huln
.timer 68,RP
step
.goto 650,43.75,72.76,15,0
.goto 657,27.72,36.23
>>Follow |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r and click on the |cRXP_PICK_chest|r when |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r is nearby
.complete 39575,1 
.target Spiritwalker Ebonhorn
step
#include RestedXP Speed Leveling\a) Secrets of Highmountain Midnight@SecretsofHighmountainStart2-SecretsofHighmountainEnd2
step
#completewith SecretsofHighmountainEnd3
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39576,1,100
.mob Great Cavernbat
step
.goto 657,38.66,47.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 40219,1 
step
#arrowtext You can fly here
.isQuestAvailable 40509
.goto 657,40.22,50.05
.turnin 40509 >>Click on the |cRXP_PICK_Small Treasure Chest|r |cRXP_WARN_above|r for experience.
step
#include RestedXP Speed Leveling\a) Secrets of Highmountain Midnight@SecretsofHighmountainStart3-SecretsofHighmountainEnd3
step
.isOnQuest 39576
#loop
.goto 658,52.84,80.33,30,0
.goto 658,54.32,43.72,30,0
.goto 657,50.41,82.83,30,0
.goto 657,54.27,46.08,30,0
.goto 657,48.05,27.81,30,0
.goto 657,37.62,51.06,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39576,1,100
.mob Great Cavernbat
step
.isOnQuest 42622
#arrowtext |cFFFCDC00Follow the Arrow|r\nFly around the mountain
.goto 750,50.62,54.27,15 >>Enter the building.
step
.isOnQuest 42622
.goto 750,44.43,53.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ernu Mesawind|r
.home >>Set your Hearthstone to The Hammer's Cradle
.skipgossipid 44703
.target Ernu Mesawind
step
#completewith next
#label Large Ceremonial Drum
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,3 
step
#completewith Large Ceremonial Drum
#title |cFFFCDC00Leave Building|r
.goto 750,50.62,54.27,15 >>Leave the Building
step
#requires Large Ceremonial Drum
#completewith MediumLargeCeremonialDrumsB
>>Kill |cRXP_ENEMY_Bluewax Drumtakers|r as they specifically carry |cRXP_PICK_Small Drums|r
.complete 42622,3 
.mob Bluewax Drumtaker
step
#requires Large Ceremonial Drum
.goto 750,58.88,26.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,3 
step
.goto 750,58.68,22.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,3 
step
#label MediumLargeCeremonialDrumsB
.goto 750,59.44,19.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,4 
.complete 42622,1,4 
step
#loop
.goto 750,50.77,41.09,25,0
.goto 750,57.39,22.12,25,0
.goto 750,43.5,43.3,25,0
.goto 750,43.21,59.7,25,0
.goto 750,51.13,59.04,25,0
>>Kill |cRXP_ENEMY_Bluewax Drumtakers|r as they specifically carry |cRXP_PICK_Small Drums|r
.complete 42622,3 
.mob Bluewax Drumtaker
step
#include RestedXP Speed Leveling\a) Crystal Calamity Midnight@CrystalCalamityStart1-CrystalCalamityEnd1
step
#completewith next
>>Kill |cRXP_ENEMY_Enraged Ambershards|r
.complete 39133,1 
.mob Enraged Ambershards
step
.isQuestAvailable 40493
.goto 650,53.05,52.24
.turnin 40493>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#label HighmountainHordeEnd
#loop
.goto 650,53.05,52.24,25,0
.goto 650,52.56,53.14,25,0
.goto 650,52.31,52.87,25,0
.goto 650,51.89,52.71,25,0
.goto 650,51.36,52.58,25,0
.goto 650,49.88,53.87,25,0
.goto 650,48.68,54.32,25,0
.goto 650,49.67,55.05,25,0
>>Kill |cRXP_ENEMY_Enraged Ambershards|r
.complete 39133,1 
.mob Enraged Ambershards
step
#label HighmountainSpeedrun1Z
.goto 650,49.03,55.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Nava|r
.turnin 39134 >>Turn in Wrathshard
.target Warbrave Nava
.turnin 39133 >>Turn in No Time to Talk
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Highmountain Speedrun 2 Midnight Horde
#internal
<< Horde
step
#completewith HighmountainHordeEndB
#hidewindow
+1
.usespell 1231411
step
#label HighmountainSpeedrun2A
.goto 650,52.46,44.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 38913 >>Turn in The Skyhorn Tribe
.target Lasan Skyhorn
.accept 39318 >>Accept Nursing the Wounds
step
.goto 650,53.73,48.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Windmaster Julan|r
.complete 39318,1 
.skipgossipid 44135
.target Windmaster Julan
step
.goto 650,53.73,48.24
>>Use the |T1029595:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 39318,2,1 
.macro Extra Action Button,1029595 >>/click ExtraActionButton1
step
.goto 650,53.97,48.63
>>Use the |T1029595:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 39318,2,3 
.macro Extra Action Button,1029595 >>/click ExtraActionButton1
step
#arrowtext Click on the |cRXP_PICK_Small Treasure Chest|r\n|cRXP_WARN_inside the hut|r
.isQuestAvailable 40500
.goto 650,53.45,48.64
.turnin 40500>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
.isQuestAvailable 40487
.goto 650,55.14,49.66
.turnin 40487>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#include RestedXP Speed Leveling\a) Bluewax Boss Midnight@BluewaxBossStart1-BluewaxBossEnd0
step
#loop
.goto 650,53.5,45.51,10,0
.goto 650,53.41,46.21,10,0
.goto 650,53.38,45.73,10,0
.goto 650,53.26,45.86,10,0
.goto 650,52.92,46.08,10,0
>>Use the |T1029595:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 39318,2 
.macro Extra Action Button,1029595 >>/click ExtraActionButton1
step
.goto 650,52.47,44.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39318 >>Turn in Nursing the Wounds
.target Lasan Skyhorn
.accept 38910 >>Accept Rocs vs Eagles
step
#completewith Eagle rescued
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39317,1
step
#include RestedXP Speed Leveling\a) The Skyhorn Tribe Midnight@TheSkyhornTribeStart1-TheSkyhornTribeEnd1
step
.isQuestAvailable 40499
.goto 650,53.06,39.47
.turnin 40499>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#label Eagle rescued
#arrowtext Eagle rescued (7/7)
.goto 650,52.27,38.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,7 
.target Captive Great Eagle
step
#loop
.goto 650,51,39.63,30,0
.goto 650,49.53,40.75,30,0
.goto 650,49.11,43.3,30,0
.goto 650,50.55,44.26,30,0
.goto 650,52.94,42.56,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39317,1
step
#include RestedXP Speed Leveling\a) Rockcrawler Chasm Midnight@RockcrawlerChasmStart1-RockcrawlerChasmEnd1
step
#completewith next
#label Empty Nest
.goto 650,51.58,37.44,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 39305 >>Turn in Empty Nest
.target Oren Windstrider
step
#completewith Empty Nest
#title |cFFFCDC00Enter Cave|r
.goto 650,50.89,36.56,40 >>Enter the Cave
step
#requires Empty Nest
#label Rockcrawler Chasm
.goto 650,50.89,36.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 39305 >>Turn in Empty Nest
.target Oren Windstrider
step
#include RestedXP Speed Leveling\a) The Skyhorn Tribe Midnight@TheSkyhornTribeStart2-TheSkyhornTribeEnd2
step
.isQuestAvailable 40505
.goto 650,52.05,32.44
.turnin 40505>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
.goto 650,50.13,32.11
>>Kill |cRXP_ENEMY_Agara Deathsong|r
.complete 39321,2 
.mob Agara Deathsong
step
#loop
.goto 650,49.44,36.26,30,0
.goto 650,49.68,31.82,30,0
.goto 650,50.79,31.8,30,0
.goto 650,52.8,33.62,30,0
.goto 650,53.24,35.49,30,0
>>Kill |cRXP_ENEMY_Skywhiskers|r and |cRXP_ENEMY_Crawliacs|r
.complete 39429,2 
.complete 39429,1 
.mob Skywhisker Loyalist
.mob Crawliac Hagfeathers
.mob Deathscreamers
step
.isQuestAvailable 40506
.goto 650,50.81,35.05
.turnin 40506>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#label Skywhisker Loyalist slain
.goto 650,50.58,35.44
>>Kill |cRXP_ENEMY_Ugla the Hag|r
.complete 39321,3 
.mob Ugla the Hag
step
.isQuestAvailable 39466
.goto 650,49.64,37.75
.turnin 39466>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
.isQuestAvailable 39466
.goto 650,49.64,37.77
.turnin 39466>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
.goto 650,49.22,36.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39321 >>Turn in The Three
.target Lasan Skyhorn
.turnin 39429 >>Turn in Assaulting the Haglands
.accept 39322 >>Accept The Witchqueen
step
.goto 650,46.36,39.96
>>Kill |cRXP_ENEMY_High Crawliac|r
.complete 39322,1 
.mob High Crawliac
step
.isQuestAvailable 40507
.goto 650,46.82,40.14
.turnin 40507>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 650,45.68,39.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39322 >>Turn in The Witchqueen
.target Lasan Skyhorn
.accept 39387 >>Accept The Skies of Highmountain
step
#completewith Hex-a-Gone
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40316,1
.mob Cursed Prowler
.mob Cursed Elderhorn
step
.goto 650,45.74,42.49
>>Kill |cRXP_ENEMY_Morashu|r. Loot him for |T454039:0|t[|cRXP_LOOT_Morashu's Antlers|r].
.complete 39178,1 
.mob Morashu
step
#completewith next
#label Irewing
>>Kill |cRXP_ENEMY_Irewing|r
.complete 40228,1 
.mob Irewing
step
#completewith Irewing
.goto 650,43.45,45.44
.cast 195071 >>Use |T134536:0|t[Flare Gun] on the rock.
.use 130074
step
#requires Irewing
.goto 650,43.45,45.44
>>Kill |cRXP_ENEMY_Irewing|r
.complete 40228,1 
.mob Irewing
step
.isQuestAvailable 39503
.goto 650,47.64,44.07
.turnin 39503>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 650,47.17,47.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maltha Silenthoof|r
.accept 39419 >>Accept Hex-a-Gone
.target Maltha Silenthoof
step
.goto 650,45.64,49.25
>>Kill |cRXP_ENEMY_Hexweaver Akara|r
.complete 39419,1 
.mob Hexweaver Akara
step
#label Hex-a-Gone
.goto 650,47.17,47.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maltha Silenthoof|r
.turnin 39419 >>Turn in Hex-a-Gone
.target Maltha Silenthoof
step
.isOnQuest 40316
#loop
.goto 650,45.11,45.94,30,0
.goto 650,46.6,44.58,30,0
.goto 650,47.51,46.81,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40316,1
.mob Cursed Prowler
.mob Cursed Elderhorn
.mob Hexxing Fetish
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r, |cRXP_FRIENDLY_Laeni Silvershot|r and |cRXP_FRIENDLY_Ellias|r
.turnin 39178 >>Turn in Moose on the Loose
.goto 650,40.01,52.3
.target +Laeni Silvershot
.turnin 40228 >>Turn in Scout It Out
.accept 40244 >>Accept That Guy in the Costume
.accept 39386 >>Accept Procuring a Prototype
.goto 650,40.04,52.25
.target +Hemet Nesingwary
step
#include RestedXP Speed Leveling\a) The Bloodtotem Tribe Midnight@BloodTotemStart1-BloodTotemEnd1
step
.isQuestAvailable 40479
.goto 650,42.2,27.32
.turnin 40479>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#loop
.goto 650,42.16,29.64,30,0
.goto 650,41.06,31.23,30,0
.goto 650,41.79,33.61,30,0
.goto 650,40.3,33.2,30,0
.goto 650,40.55,29.54,30,0
>>Kill |cRXP_ENEMY_Witchwood Hag|r. Loot them for |T132918:0|t[|cRXP_LOOT_Hag Feather|r].
.complete 39373,1 
.mob Witchwood Hag
step
.isOnQuest 39371
#loop
.goto 650,42.16,29.64,30,0
.goto 650,41.06,31.23,30,0
.goto 650,41.79,33.61,30,0
.goto 650,40.3,33.2,30,0
.goto 650,40.55,29.54,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eggs|r.
>>Kill |cRXP_ENEMY_Witchwood Hag|r and |cRXP_ENEMY_Bewitched Bears|r.
.complete 39371,1 
.mob Witchwood Hag
.mob Bewitched Bear
step
.isQuestAvailable 40480
.goto 650,42.51,35.05
.turnin 40480>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#include RestedXP Speed Leveling\a) The Bloodtotem Tribe Midnight@BloodTotemStart2-BloodTotemEnd2
step
.isQuestAvailable 40477
.goto 650,37.35,33.81
.turnin 40477>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label Harpy Placed on Altar
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r
.complete 39455,1 
step
#completewith Harpy Placed on Altar
#title |cFFFCDC00Enter Cave|r
.goto 650,37.62,33.52,15 >>Enter the Cave
step
#requires Harpy Placed on Altar
.goto 653,54.04,28.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r
.complete 39455,1 
step
#include RestedXP Speed Leveling\a) The Bloodtotem Tribe Midnight@BloodTotemStart2.5-BloodTotemEnd2.5
step
#label Stonedark Focus
.goto 650,45.32,27.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gravel|r
.complete 39391,3 
step
.isQuestAvailable 40482
.goto 650,46.66,28.12
.turnin 40482>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#loop
.goto 650,46.72,28.1,40,0
.goto 650,47.71,29.76,40,0
.goto 650,43.82,30.84,40,0
.goto 650,43.29,33.2,40,0
.goto 650,44.33,28.42,40,0
>>Kill |cRXP_ENEMY_Feltotems|r. Loot them for |T237176:0|t[|cRXP_LOOT_Stonedark Focus|r].
.complete 39588,1 
.complete 39425,1 
.mob Feltotem Bloodbinder
.mob Feltotem Warmonger
step
.isQuestAvailable 40481
.goto 650,45.56,34.6
.turnin 40481>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#completewith next
#label They Will Pay With Blood
.goto 650,45.06,31.93,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 39425 >>Turn in Stonedark Crystal
.target Navarrogg
.turnin 39588 >>Turn in They Will Pay With Blood
.turnin 39391 >>Turn in Pet Rocks
.accept 39426 >>Accept Blood Debt
step
#completewith They Will Pay With Blood
#title |cFFFCDC00Enter Cave|r
.goto 650,45.21,32.52,30 >>Enter the Cave
step
#requires They Will Pay With Blood
.goto 650,45.21,32.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 39425 >>Turn in Stonedark Crystal
.target Navarrogg
.turnin 39588 >>Turn in They Will Pay With Blood
.turnin 39391 >>Turn in Pet Rocks
.accept 39426 >>Accept Blood Debt
step
#completewith next
#label Torok Bloodtotem
.goto 650,45.09,31.78,15,0
>>Kill |cRXP_ENEMY_Torok Bloodtotem|r
.complete 39426,1 
.mob Torok Bloodtotem
step
#completewith Torok Bloodtotem
#title |cFFFCDC00Leave Cave|r
.goto 650,49.53,23.62,500 >>Leave the Cave
step
#requires Torok Bloodtotem
#label BloodTotemEnd3
.goto 650,49.53,23.62
>>Kill |cRXP_ENEMY_Torok Bloodtotem|r.
.complete 39426,1 
.mob Torok Bloodtotem
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r |cRXP_WARN_next to you|r.
.turnin 39426 >>Turn in Blood Debt
.target Navarrogg
.accept 40229 >>Accept Step into the Dark
step
#loop
.goto 650,49.05,27.27,25,0
.goto 650,47.82,27.25,25,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 42373,1
.mob Feltotem Bloodbinder
.mob Feltotem Warmonger
step
#completewith next
#label Step into the Dark
.goto 659,21.07,80.68,15,0
.goto 659,23.3,73.82,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 40229 >>Turn in Step into the Dark
.accept 39456 >>Accept Unexpected Allies
.disablecheckbox
step
#completewith Step into the Dark
#title |cFFFCDC00Enter Cave|r
.goto 659,40.25,53.17,90 >>Enter the Cave
step
#requires Step into the Dark
.goto 659,40.25,53.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 40229 >>Turn in Step into the Dark
.accept 39456 >>Accept Unexpected Allies
.target Navarrogg




step
#include RestedXP Speed Leveling\a) Stonedark Cavern: Trials of Liftbrul Midnight@LiftbrulStart1-LiftbrulEnd1
step
.isQuestAvailable 40478
.goto 659,35.95,72.63
.turnin 40478>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 659,54.19,73.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rod|r
.complete 39439,3 
step
#loop
.goto 659,66.53,68.87,40,0
.goto 659,73,51.61,40,0
.goto 659,73.53,68.97,40,0
>>Kill |cRXP_ENEMY_Deepcavern Murloc|r
.complete 39437,1 
.mob Deepcavern Murloc
step
.goto 659,52.40,62.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.turnin 39438 >>Turn in Guhruhlruhlruh
.target Damrul the Stronk
.turnin 39437 >>Turn in Deep in the Cavern
.turnin 39439 >>Turn in Stonedark Relics
step
.isOnQuest 39456
#title |cFFFCDC00Leave Cave|r
.goto 659,22.87,75.97,10,0
.goto 650,42.73,25.36,15 >>Leave the Cave
step
#completewith MurkyWatersEnd1
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40050,1
step
.isOnQuest 40244
#title |cFFFCDC00Skyride to him|r
.goto 650,42.73,10.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 40244 >>Turn in That Guy in the Costume
.target King Mrgl-Mrgl
.accept 40047 >>Accept I'll Huff, I'll Puff...
.accept 40049 >>Accept Slime Time
.accept 40045 >>Accept Nature vs. Nurture
step
#title |cFFFCDC00Skyride to him|r
.goto 650,42.73,10.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.target King Mrgl-Mrgl
.accept 40047 >>Accept I'll Huff, I'll Puff...
.accept 40049 >>Accept Slime Time
.accept 40045 >>Accept Nature vs. Nurture
step
#include RestedXP Speed Leveling\a) Murky Waters Midnight@MurkyWatersStart1-Murky Waters
step
#loop
.goto 650,49.3,14.09,30,0
.goto 650,47.53,8.05,30,0
.goto 650,46.17,6.37,30,0
.goto 650,43.01,9.11,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40050,1
step
.isOnQuest 39387
.hs >>Use Hearthstone
step
#completewith next
#label Meet Lasan
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan|r
.complete 39387,1 
.target Lasan Skyhorn
step
#completewith Meet Lasan
#title |cFFFCDC00Leave Building|r
.goto 750,51.27,53.71,15 >>Leave the Building
step
#requires Meet Lasan
.goto 750,42.16,33.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.complete 39387,1 
.timer 48,RP1
.skipgossipid 44839
.target Lasan Skyhorn
step
.goto 750,34.84,44.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.complete 39456,1 
.timer 30,RP2
.skipgossipid 44200 
.target Navarrogg
step
#arrowtext Outside
.isQuestAvailable 40475
.goto 750,32.35,41.81
.turnin 40475>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#arrowtext Outside
.isQuestAvailable 40472
.goto 750,50.6,75.36
.turnin 40472>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#arrowtext Outside
.isQuestAvailable 39531
.goto 750,63.49,59.39
.turnin 39531>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#completewith next
#label Witness the Stonedark Ritual
#title |cFFFCDC00Follow the Arrow|r
.goto 652,25.14,80.45,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r at lowest level of Thunder Totem.
.turnin 42622 >>Turn in Ceremonial Drums
.target Torv Dubstomp
step
#completewith Witness the Stonedark Ritual
#title |cFFFCDC00Enter Building|r
.goto 652,54.79,63.18,105 >>Enter the Building
step
#requires Witness the Stonedark Ritual
.goto 652,54.78,77.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r at lowest level of Thunder Totem.
.turnin 42622 >>Turn in Ceremonial Drums
.target Torv Dubstomp
step
.isQuestAvailable 40471
.goto 652,62.98,67.92
.turnin 40471 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 652,54.79,63.18
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 39456,2 
.complete 39387,2
step
.goto 652,54.80,63.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39456 >>Turn in Unexpected Allies
.turnin 39387 >>Turn in The Skies of Highmountain
.turnin 39580 >>Turn in The High Chieftain
.accept 38915 >>Accept Battle of Snowblind Mesa
.target Mayla Highmountain
step
#include RestedXP Speed Leveling\a) Battle of Snowblind Mesa Midnight@Battle of Snowblind Mesa-BattleofSnowblindMesaEnd2
step
#include RestedXP Speed Leveling\a) Icepine Point Midnight@IcepinePointStart1-IcepinePointEnd1
step
.goto 650,57.63,56.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razik Gazbolt|r
.turnin 39656 >>Turn in Wolf Pack Attack
.target Razik Gazbolt
step
#include RestedXP Speed Leveling\a) Battle of Snowblind Mesa Midnight@Arxas-Battle of Snowblind Mesa2
step
.goto 650,53.19,70.89
#title |cFFFCDC00Follow the Arrow|r
.complete 39780,1 
.timer 10,RP
step
#label HighmountainHordeEndB
.isQuestAvailable 40471
.goto 650,52.55,66.38
.turnin 40471 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#label Wrath of Dargrul
.goto 650,53.15,70.77
>>Kill |cRXP_ENEMY_Wrath of Dargrul|r
.complete 39780,2 
.mob Wrath of Dargrul
step
#label HighmountainSpeedrun2Z
.goto 650,53.19,70.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39780 >>Turn in The Underking
.target Mayla Highmountain
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Val'sharah Speedrun Midnight
#internal
step
.isQuestAvailable 40122
.subzoneskip 10523,1
.goto 84,46.22,92.05,5,0
.goto 84,45.14,92.13,5,0
.goto 84,43.23,94.33,5,0
.goto 84,43.28,97.55
.zone 2239 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Bel'ameth|r
step
#completewith next
#label Keeper of the Grove 1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r
.accept 40122 >>Accept Cenarius, Keeper of the Grove
.target Malfurion Stormrage
step
#completewith Keeper of the Grove 1
.goto 2239,55.23,64.66,10,0
.goto 2239,55.19,64.86
.zone 641 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Val'sharah|r |cRXP_WARN_on the right side|r.
step
#requires Keeper of the Grove 1
.goto 641,54.69,72.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r
.accept 40122 >>Accept Cenarius, Keeper of the Grove
.target Malfurion Stormrage
step
#include RestedXP Speed Leveling\a) Val'sharah Intro Midnight@ValsharahIntroA-ValsharahIntroZ
step
.isQuestAvailable 39093
.goto 641,54.18,70.58
.turnin 39093 >>Click on the |cRXP_PICK_Small Treasure Chest|r under the tree.


step
#include RestedXP Speed Leveling\a) Archdruid of Lore Midnight@ArchdruidofLoreA-ArchdruidofLoreB
step
#completewith next
#label Marnor Lorleaf
#hidewindow
.complete 38235,1 
.target Marnor Lorleaf
step
#completewith Marnor Lorleaf
.goto 641,43.80,70.19
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Marnor Lorleaf|r.
step
#requires Marnor Lorleaf
#completewith next
#label Sagewood
#hidewindow
.complete 38235,3 
.target Del'thanar Sagewood
step
#requires Marnor Lorleaf
#completewith Sagewood
.goto 641,43.80,75.30
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Del'thanar Sagewood|r.
step
#requires Sagewood

#completewith Erwind Mistfen2
>>Kill the |cRXP_ENEMY_Stoneblood Witches|r. Destroy the |cRXP_PICK_Hatching Harp Eggs|r with an AOE ability.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dry Harpy Nests|r and |cRXP_FRIENDLY_Acolytes of Elothir|r.
.complete 38372,1 
.target Acolyte of Elothir
.mob Stoneblood Temptress
.mob Stoneblood Elderwitch
step
#requires Sagewood
.isQuestAvailable 38363
.goto 641,43.40,75.90
.turnin 38363 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#label Magula
#completewith next
#title |cFFFCDC00Enter Cave|r
.goto 641,45.47,76.99,15,0
>>Kill |cRXP_ENEMY_Magula|r.
*|cRXP_WARN_Jump to remove|r |T136093:0|t[Stoneblood Poison].
.complete 38225,1 
.mob Magula
step
#completewith Magula
.goto 641,45.79,77.85,50 >>Enter the Cave
step
#requires Magula
.goto 641,45.79,77.85
>>Kill |cRXP_ENEMY_Magula|r.
*|cRXP_WARN_Jump to remove|r |T136093:0|t[Stoneblood Poison].
.complete 38225,1 
.mob Magula
step
#completewith next
#label Erwind Mistfen
#hidewindow
.goto 641,45.57,77,15,0
.complete 38235,2 
step
#completewith Erwind Mistfen
#label Erwind Mistfen2
.goto 641,46.71,76.4
.cast 182117 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Erwind Mistfen|r.
.target Erwind Mistfen
step
#requires Erwind Mistfen
#loop
.goto 641,45.71,74.69,25,0
.goto 641,43.6,75.78,25,0
.goto 641,42.27,78.58,25,0
.goto 641,44.47,78.55,25,0
>>Kill the |cRXP_ENEMY_Stoneblood Witches|r. Destroy the |cRXP_PICK_Hatching Harp Eggs|r with an AOE ability.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dry Harpy Nests|r and |cRXP_FRIENDLY_Acolytes of Elothir|r.
.complete 38372,1 
.target Acolyte of Elothir
.mob Stoneblood Temptress
.mob Stoneblood Elderwitch
step
.goto 641,48.85,70.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elothir|r.
.turnin 38225 >>Turn in Death to the Witchmother
.turnin 38235 >>Turn in Solid as a Rock
.target Elothir
step
.isQuestAvailable 38366
.goto 641,48.69,73.79
.turnin 38366 >>Click on the |cRXP_PICK_Small Treasure Chest|r under the tree.
step
#include RestedXP Speed Leveling\a) Archdruid of the Claw Midnight@ArchdruidOfTheClawA-ArchdruidOfTheClawB
step
.isQuestAvailable 38277
.goto 641,46.45,86.32
.turnin 38277 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Claw Midnight@ArchdruidOfTheClawC-ArchdruidOfTheClawD
step
#title In the small cave
.isQuestAvailable 38886
.goto 641,48.99,86.15
.turnin 38886 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Claw Midnight@ArchdruidOfTheClawE-ArchdruidOfTheClawZ
step
#include RestedXP Speed Leveling\a) Lunarwing Shallows Midnight@LunarwingShallowsA-LunarwingShallowsB
step
#title In the cave
.isQuestAvailable 38861
.goto 641,56.03,83.75
.turnin 38861 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
.goto 641,53.75,79.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Saylanna Riverbreeze|r.
.turnin 38862 >>Turn in Thieving Thistleleaf
.turnin 40220 >>Turn in Thorny Dancing
.turnin 40221 >>Turn in Spread Your Lunarwings and Fly
.target Saylanna Riverbreeze
step
#include RestedXP Speed Leveling\a) Lostlight Grotto Midnight@LostlightGrottoA-LostlightGrottoB
step
.isOnQuest 42751
.isQuestAvailable 38893
.goto 641,60.49,82.15
.turnin 38893 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#completewith LostlightGrottoChestC
#label LostlightGrottoChestA
.isOnQuest 42751
.isQuestAvailable 38893
.turnin 38893 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#completewith LostlightGrottoChestA
#label LostlightGrottoChestB
#title |cFFFCDC00Leave Cave|r
.goto 641,59.91,84.34,10,0
.goto 641,61.11,85.17,10 >>|cRXP_WARN_Leave the cave|r
step
#requires LostlightGrottoChestB
#completewith LostlightGrottoChestA
#label LostlightGrottoChestC
.goto 641,62.56,85.74,6 >>|cRXP_WARN_Follow the arrow into the cave.|r
step
#requires LostlightGrottoChestA
.isOnQuest 42751
.isQuestAvailable 38893
.goto 641,62.70,85.26
.turnin 38893 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
.isQuestAvailable 38389
.goto 641,63.38,88.40
.turnin 38389 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#title Under the tree roots
.isQuestAvailable 39074
.goto 641,65.38,86.27
.turnin 39074 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
.goto 641,59.32,84.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 42751 >>Turn in Moon Reaver
.target Keeper Remulos
step
#title In a small cave
.isQuestAvailable 39089
.goto 641,61.01,79.18
.turnin 39089 >>Click on the |cRXP_PICK_Glimmering Treasure Chest|r.
step
.isQuestAvailable 39087
.goto 641,61.63,73.70
.turnin 39087 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Vale Midnight@ArchdruidOfTheValeA-ArchdruidOfTheValeB
step
#completewith next
#label TheWildwoodChestA
.isQuestAvailable 39071
.turnin 39071 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
#title Enter the waterfall cave
#completewith TheWildwoodChestA
.goto 641,62.00,67.94,8 >>|cRXP_WARN_Follow the arrow into the cave behind the waterfall.|r
step
#requires TheWildwoodChestA
#title In the waterfall cave
.isQuestAvailable 39071
.goto 641,62.06,67.37
.turnin 39071 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Vale Midnight@ArchdruidOfTheValeC-ArchdruidOfTheValeD
step
#completewith MoonclawValeChestC
#label MoonclawValeChestA
.isQuestAvailable 39102
.turnin 39102 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
#completewith MoonclawValeChestA
#label MoonclawValeChestB
.goto 641,63.43,66.95,10,0
.goto 641,62.97,68.10,10 >>Leave the Moonclaw Cavern
step
#title |cFFFCDC00Enter House|r
#requires MoonclawValeChestB
#completewith MoonclawValeChestA
#label MoonclawValeChestC
.goto 641,63.06,73.60,6 >>|cRXP_WARN_Follow the arrow into the house.|r
step
#requires MoonclawValeChestA
#title In the house
.isQuestAvailable 39102
.goto 641,63.27,74.01
.turnin 39102 >>Click on the |cRXP_PICK_Treasure Chest|r.
step
.goto 641,62.41,76.45
>>|cRXP_WARN_Follow the arrow|r to Archdruid's Den
.complete 40573,2 
step
.isQuestAvailable 39070
.goto 641,63.04,76.96
.turnin 39070 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Archdruid of the Vale Midnight@ArchdruidOfTheValeE-ArchdruidOfTheValeF
step
.isQuestAvailable 38391
.goto 641,65.87,79.19
.turnin 38391 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Grizzleweald Midnight@GrizzlewealdA-GrizzlewealdZ
step

.isQuestTurnedIn 38382
#loop
.goto 641,64.86,74.20,35,0
.goto 641,60.72,69.94,35,0
.goto 641,61.26,73.26,35,0
.goto 641,63.44,75.43,35,0
>>Kill the |cRXP_ENEMY_Nightmare Imps|r and |cRXP_ENEMY_Darkfiend Satyr|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nightmare Totems|r and |cRXP_FRIENDLY_Moonclaw Druids|r.
.complete 39393,1 
.mob Nightmare Imp
.mob Darkfiend Corruptor
.mob Darkfiend Zealot
.target Moonclaw Druid
step
#label Return to the Grove
.goto 641,51.92,64.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malfurion Stormrage|r.
.turnin 38323 >>Turn in Return to the Grove
.target Malfurion Stormrage
step
#include RestedXP Speed Leveling\a) Into the Nightmare Midnight@IntoTheNightmareA-IntoTheNightmareB
step
.isQuestAvailable 39072
.goto 641,56.23,57.31
.turnin 39072 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Into the Nightmare Midnight@IntoTheNightmareC-IntoTheNightmareCA
step
.isOnQuest 38582
.isQuestAvailable 38782
.goto 641,67.20,59.27
.turnin 38782 >>Click on the |cRXP_PICK_Treasure Chest|r.
step

.isQuestTurnedIn 38641
#loop
.goto 641,58.62,54.59,35,0
.goto 641,56.64,51.62,45,0
.goto 641,59.55,58.73,45,0
>>Kill the |cRXP_ENEMY_Defiled Grovewalker|r, |cRXP_ENEMY_Ancient Annihilator|r, |cRXP_ENEMY_Terrorfiend Bats|r and |cRXP_ENEMY_Darkfiend Satyr|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangling Vines|r.
.complete 39029,1 
.mob Defiled Grovewalker
.mob Ancient Annihilator
.mob Darkfiend Satyr
.mob Terrorfiend Bats
step
#include RestedXP Speed Leveling\a) Braddensbrook Midnight@BraddensbrookA-BraddensbrookB
step
#title Inside the house
.isQuestAvailable 39077
.goto 641,42.67,58.01
.turnin 39077 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Braddensbrook Midnight@BraddensbrookC-BraddensbrookD
step
#title Inside the cellar
.isOnQuest 38644
.isQuestAvailable 39080
.goto 641,38.43,65.32
.turnin 39080 >>Click on the |cRXP_PICK_Small Treasure Chest|r.
step
#include RestedXP Speed Leveling\a) Braddensbrook Midnight@Shriek No More-BraddensbrookZ
step
#include RestedXP Speed Leveling\a) Black Rook Hold Midnight@BlackRookHoldA-BlackRookHoldB
step

.isQuestTurnedIn 38718
#loop
.goto 641,40.14,54.88,45,0
.goto 641,43.74,53.68,35,0
.goto 641,43.26,46.71,40,0
.goto 641,42.85,51.04,45,0
>>Kill the |cRXP_ENEMY_Black Rook forces|r and |cRXP_ENEMY_Risen Saber|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Racks|r and |cRXP_PICK_Kaldorei Tomes|r.
.complete 38716,1 
.mob Reanimated Archer
.mob Risen Soldier
.mob Risen Saber
.mob Servant of Ravencrest
step
#include RestedXP Speed Leveling\a) Black Rook Hold Midnight@BlackRookHoldC-BlackRookHoldZ
step
.goto 641,52.47,63.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysera|r
.turnin 38663 >>Turn in The Die is Cast
.target Ysera
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Highmountain Speedrun Midnight
#internal
step
#label HighmountainSpeedrun1A
.goto 650,35.97,65.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Oro|r.
.target Warbrave Oro
.accept 38907 >>Accept Keepers of the Hammer
step
.isQuestAvailable 40488
.goto 650,36.62,62.14
.turnin 40488 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#include RestedXP Speed Leveling\a) The Rivermane Tribe Midnight@TheRivermaneTribeStart1-TheRivermaneTribeEnd1
step
.isQuestAvailable 40491
.goto 750,13.76,55.38
.turnin 40491 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angler Creel|r and |cRXP_FRIENDLY_Jale Rivermane|r.
.turnin 39496 >>Turn in The Flow of the River
.accept 39316 >>Accept Trapped Tauren
.accept 39614 >>Accept Fish Out of Water
.goto 650,41.14,61.58
.accept 39277 >>Accept Spray and Prey
.goto 650,41.17,61.49
.target Angler Creel
.target Jale Rivermane
step
.isQuestAvailable 39274
#completewith HighmountainTaurenTrappedTauren
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
#completewith HighmountainTaurenTrappedTauren
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
#completewith HighmountainTaurenTrappedTauren
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
.goto 650,42.85,63.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood Barricade|r.
.complete 39316,1 
step
.goto 650,40.25,64.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rordan Waterwise|r
.accept 39323 >>Accept Moozy's Sojourn
.target Rordan Waterwise
step
#label HighmountainTaurenTrappedTauren
.goto 650,37.46,64.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bucket|r
.turnin 39323 >>Turn in Moozy's Sojourn
.target Moozy Waterwise
.accept 39572 >>Accept Moozy's Adventure
step
#completewith Drogbar sprayed2
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
#completewith Drogbar sprayed2
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
#completewith Drogbar sprayed2
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
#label Drogbar sprayed2
.isQuestAvailable 40474
.goto 650,39.39,62.28
.turnin 40474>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#hidewindow
#completewith Whitewater Carp
#loop
.goto 650,40.86,62.02,40,0
.goto 650,42.5,63.54,40,0
.goto 650,39.19,65.87,40,0
.goto 650,38.4,63.35,40,0
+1
step
#completewith Drogbar sprayed
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
#completewith Drogbar sprayed
>>Stand with the |cRXP_FRIENDLY_Whitewater Carp|r between you and the water and interact with it.
.complete 39614,1 
step
#label Drogbar sprayed
>>Use the |T609616:0|t[Bug Sprayer] while aiming at |cRXP_ENEMY_Drogbar Wormhooks|r |cRXP_WARN_you can do it while walking|r.
*|cRXP_WARN_Don't kill them before using the item|r.
.complete 39277,1 
.use 127988
.mob Drogbar Wormhook
.mob Drogbar Rivertroller
step
#completewith next
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fish|r while facing the water to kick it in.
.complete 39614,1 
step
#label Whitewater Carp
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39274,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angler Creel|r and |cRXP_FRIENDLY_Jale Rivermane|r.
.turnin 39316 >>Turn in Trapped Tauren
.turnin 39614 >>Turn in Fish Out of Water
.goto 650,41.13,61.57
.turnin 39277 >>Turn in Spray and Prey
.accept 39661 >>Accept Lifespring Cavern
.goto 650,41.18,61.49
.target Angler Creel
.target Jale Rivermane
step
#include RestedXP Speed Leveling\a) The Rivermane Tribe Midnight@TheRivermaneTribeStart2-TheRivermaneTribeEnd2
step
.isQuestAvailable 40476
.goto 656,58.17,60.7,10,0
.goto 656,71.88,56.77,10,0
.goto 655,58.99,18.72,10,0
.goto 655,52.79,23.82
.turnin 40476 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label Moozy's Adventure
.goto 655,63.21,59.87,15,0
.goto 650,38.31,61.1,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.turnin 39572 >>Turn in Moozy's Adventure
.target Sella Waterwise
step
.zoneskip 650
#completewith Moozy's Adventure
#title |cFFFCDC00Follow the Arrow|r
.goto 650,38.4,61.31,20 >>Leave the Cave
step
#requires Moozy's Adventure
.goto 650,40.01,57.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sella Waterwise|r
.turnin 39572 >>Turn in Moozy's Adventure
.target Sella Waterwise
step
.isQuestAvailable 39812
.goto 650,39.53,57.44
.turnin 39812 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.isQuestAvailable 44731
.goto 650,38.91,54.14,10,0
.goto 650,38.96,54.49
.turnin 44731 >>Click on the |cRXP_PICK_Small Treasure Chest|r |cRXP_WARN_in the tent|r for experience and powers.
step
#include RestedXP Speed Leveling\a) Nesingwary's Retreat Midnight@NesingwarysRetreatStart1-NesingwarysRetreatEnd1
step
#include RestedXP Speed Leveling\a) Mucksnout Den Midnight@Shiny, But Deadly-DemonDetainmentZ
step
.isQuestAvailable 40494
.goto 654,60.73,25.15
.turnin 40494>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label Bristlefur Bear2
.goto 654,42.31,60.56,25,0
.goto 654,34.46,64.12,20,0
.goto 650,38.52,42.4,15,0
>>Kill |cRXP_ENEMY_Bristlefur Bear|r.
*Loot them for |T878263:0|t[|cRXP_LOOT_Bristlefur Pelt|r].
.complete 39392,1 
.mob Bristlefur Bear
step
#completewith Bristlefur Bear2
#title |cFFFCDC00Leave Cave|r
.goto 650,37.82,40.32,120 >>Leave the Cave
step
#requires Bristlefur Bear2
#completewith Bristlefur Bear3
>>Kill wildlife to earn experience for |cRXP_FRIENDLY_Addie Fizzlebog|r. Each rank counts as a quest step.
.complete 40216,3 
.complete 40216,4 
.target Addie Fizzlebog
step
#requires Bristlefur Bear2
#loop
.goto 650,37.82,40.32,40,0
.goto 650,36.09,42.46,40,0
.goto 650,37.37,43.46,40,0
.goto 650,37.18,46.38,40,0
>>Kill |cRXP_ENEMY_Bristlefur Bear|r.
*Loot them for |T878263:0|t[|cRXP_LOOT_Bristlefur Pelt|r].
.complete 39392,1 
.mob Bristlefur Bear
step
#completewith next
#label Rashar's Right Eye
>>Kill |cRXP_ENEMY_Rashar|r. Loot him for |T255344:0|t[|cRXP_LOOT_Rashar's Right Eye|r].
.complete 39867,1 
.mob Rashar
step
#completewith Rashar's Right Eye
#title |cFFFCDC00Enter Cave|r
.goto 650,37.47,49.19,30 >>Enter the Cave
step
#requires Rashar's Right Eye
#label Bristlefur Bear3
.goto 650,37.47,49.19
>>Kill |cRXP_ENEMY_Rashar|r.
*Loot him for |T255344:0|t[|cRXP_LOOT_Rashar's Right Eye|r].
.complete 39867,1 
step
#loop
.goto 650,39.67,49.57,30,0
.goto 650,40.81,50.13,30,0
.goto 650,41.39,53.89,30,0
.goto 650,40.54,53.78,30,0
.goto 650,43.31,49.19,30,0
>>Kill wildlife to earn experience for |cRXP_FRIENDLY_Addie Fizzlebog|r. Each rank counts as a quest step.
.complete 40216,3 
.complete 40216,4 
.mob Pinerock Stalker
.mob Soothoof Hillstrider
.mob Pinerock Elderhorn
.mob Skittish Doe
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r, |cRXP_FRIENDLY_Laeni Silvershot|r and |cRXP_FRIENDLY_Ellias|r
.turnin 40216 >>Turn in A Hunter at Heart
.turnin 39124 >>Turn in Moose Shootin'
.turnin 39392 >>Turn in Bear Huntin'
.accept 40228 >>Accept Scout It Out
.target +Hemet Nesingwary
.goto 650,40.04,52.25
.accept 39178 >>Accept Moose on the Loose
.goto 650,40,52.31
.target +Laeni Silvershot
.turnin 39867 >>Turn in I'm Not Lion!
.goto 650,40.02,52.37
.target +Ellias
step
#include RestedXP Speed Leveling\a) Riverbend Midnight@RiverbendStart1-RiverbendEnd1
step
.isQuestAvailable 40473
.goto 650,39.29,76.18
.turnin 40473 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#include RestedXP Speed Leveling\a) Riverbend Midnight@RiverbendStart2-RiverbendEnd2
step
.goto 652,54.80,63.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.turnin 38909 >>Turn in Get to High Ground
.accept 38912 >>Accept The Bloodtotem Tribe
.accept 38913 >>Accept The Skyhorn Tribe
.accept 40515 >>Accept A Walk With the Spirits
.target Mayla Highmountain
step
#include RestedXP Speed Leveling\a) Huln's War Midnight@HulnsWarStart1-HulnsWarEnd1
step
.goto 750,57.84,10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mu'sha's Tears|r near the waterfall.
.complete 40520,2 
step
#include RestedXP Speed Leveling\a) Huln's War Midnight@HulnsWarStart2-Tichondrius
step
.goto 652,74.86,75.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 39992 >>Turn in Huln's War - The Nathrezim
.accept 38916 >>Accept Secrets of Highmountain
.target Spiritwalker Ebonhorn
step
.goto 652,54.94,78.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r
.accept 42622 >>Accept Ceremonial Drums
.target Torv Dubstomp
step
#completewith next
#label Secrets of HighmountainZ
.goto 652,41.87,74,15,0
.goto 652,25.81,80.84,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,1 
step
#completewith Secrets of HighmountainZ
#title |cFFFCDC00Leave Building|r
.goto 650,44.88,65.71,185 >>Leave the building.
step
#requires Secrets of HighmountainZ
#label SecretsofHighmountainEnd1
.goto 750,39.47,74.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,1 
step
.goto 750,38.01,78.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,1 
step
.goto 650,45.1,65.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,2 
.complete 42622,2,2 
step
.goto 650,44.88,65.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r
.turnin 38916 >>Turn in Secrets of Highmountain
.target Spiritwalker Ebonhorn
.accept 39575 >>Accept The Path of Huln
.timer 68,RP
step
.goto 650,43.75,72.76,15,0
.goto 657,27.72,36.23
>>Follow |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r and click on the |cRXP_PICK_chest|r when |cRXP_FRIENDLY_Spiritwalker Ebonhorn|r is nearby
.complete 39575,1 
.target Spiritwalker Ebonhorn
step
#include RestedXP Speed Leveling\a) Secrets of Highmountain Midnight@SecretsofHighmountainStart2-SecretsofHighmountainEnd2
step
#completewith SecretsofHighmountainEnd3
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39576,1,100
.mob Great Cavernbat
step
.goto 657,38.66,47.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 40219,1 
step
.isQuestAvailable 40509
.goto 657,40.22,50.05
.turnin 40509 >>Click on the |cRXP_PICK_Small Treasure Chest|r |cRXP_WARN_above|r for experience and powers.
step
#include RestedXP Speed Leveling\a) Secrets of Highmountain Midnight@SecretsofHighmountainStart3-SecretsofHighmountainEnd3
step
.isOnQuest 39576
#loop
.goto 658,52.84,80.33,30,0
.goto 658,54.32,43.72,30,0
.goto 657,50.41,82.83,30,0
.goto 657,54.27,46.08,30,0
.goto 657,48.05,27.81,30,0
.goto 657,37.62,51.06,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39576,1,100
.mob Great Cavernbat
step
.isOnQuest 42622
#title |cFFFCDC00Follow the Arrow|r
.goto 750,45.75,55.01,40 >>Enter the building.
step
.isOnQuest 42622
.goto 750,44.43,53.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ernu Mesawind|r
.home >>Set your Hearthstone to The Hammer's Cradle
.skipgossipid 44703
.target Ernu Mesawind
step
#completewith next
#label Large Ceremonial Drum
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,3 
step
#completewith Large Ceremonial Drum
#title |cFFFCDC00Leave Building|r
.goto 750,53.96,45.85,60 >>Leave the Building
step
#requires Large Ceremonial Drum
.goto 750,58.88,26.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,3 
step
.goto 750,58.68,22.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,1,3 
step
.goto 750,59.44,19.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drums|r
.complete 42622,2,4 
.complete 42622,1,4 
step
#loop
.goto 750,50.77,41.09,25,0
.goto 750,57.39,22.12,25,0
.goto 750,43.5,43.3,25,0
.goto 750,43.21,59.7,25,0
.goto 750,51.13,59.04,25,0
>>Kill |cRXP_ENEMY_Bluewax Drumtakers|r as they specifically carry |cRXP_PICK_Small Drums|r
.complete 42622,3 
.mob Bluewax Drumtaker
step
#include RestedXP Speed Leveling\a) Crystal Calamity Midnight@CrystalCalamityStart1-CrystalCalamityEnd1
step
#completewith next
>>Kill |cRXP_ENEMY_Enraged Ambershards|r
.complete 39133,1 
.mob Enraged Ambershards
step
.isQuestAvailable 40493
.goto 650,53.05,52.24
.turnin 40493>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#label Enraged Ambershards
#loop
.goto 650,53.05,52.24,25,0
.goto 650,52.56,53.14,25,0
.goto 650,52.31,52.87,25,0
.goto 650,51.89,52.71,25,0
.goto 650,51.36,52.58,25,0
.goto 650,49.88,53.87,25,0
.goto 650,48.68,54.32,25,0
.goto 650,49.67,55.05,25,0
>>Kill |cRXP_ENEMY_Enraged Ambershards|r
.complete 39133,1 
.mob Enraged Ambershards
step
#label HighmountainSpeedrun1Z
.goto 650,49.03,55.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warbrave Nava|r
.turnin 39134 >>Turn in Wrathshard
.target Warbrave Nava
.turnin 39133 >>Turn in No Time to Talk
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Highmountain Speedrun 2 Midnight
#internal
step
#label HighmountainSpeedrun2A
.goto 650,52.46,44.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 38913 >>Turn in The Skyhorn Tribe
.target Lasan Skyhorn
.accept 39318 >>Accept Nursing the Wounds
step
.goto 650,53.73,48.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Windmaster Julan|r
.complete 39318,1 
.skipgossipid 44135
.target Windmaster Julan
step
.goto 650,53.73,48.24
>>Use the |T1029595:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 39318,2,1 
.macro Extra Action Button,1029595 >>/click ExtraActionButton1
step
.goto 650,53.97,48.63
>>Use the |T1029595:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 39318,2,3 
.macro Extra Action Button,1029595 >>/click ExtraActionButton1
step
.isQuestAvailable 40500
.goto 650,53.45,48.64
.turnin 40500>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
.isQuestAvailable 40487
.goto 650,55.14,49.66
.turnin 40487>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience.
step
#include RestedXP Speed Leveling\a) Bluewax Boss Midnight@BluewaxBossStart1-BluewaxBossEnd0
step
.goto 650,53.5,45.51
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,4 
.usespell 189168
step
.goto 650,53.41,46.21
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,5 
.usespell 189168
step
.goto 650,53.38,45.73
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,6 
.usespell 189168
step
.goto 650,53.26,45.86
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,7 
.usespell 189168
step
.goto 650,52.92,46.08
>>Use the |cRXP_WARN_ExtraActionButton|r
.complete 39318,2,8 
.usespell 189168
step
.goto 650,52.47,44.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39318 >>Turn in Nursing the Wounds
.target Lasan Skyhorn
.accept 38910 >>Accept Rocs vs Eagles
step
#completewith Eagle rescued
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39317,1
step
#include RestedXP Speed Leveling\a) The Skyhorn Tribe Midnight@TheSkyhornTribeStart1-TheSkyhornTribeEnd1
step
.isQuestAvailable 40499
.goto 650,53.06,39.47
.turnin 40499>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#label Eagle rescued
.goto 650,52.27,38.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Captive Great Eagle|r
.complete 38910,1,7 
.target Captive Great Eagle
step
#loop
.goto 650,51,39.63,30,0
.goto 650,49.53,40.75,30,0
.goto 650,49.11,43.3,30,0
.goto 650,50.55,44.26,30,0
.goto 650,52.94,42.56,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 39317,1
step
#include RestedXP Speed Leveling\a) Rockcrawler Chasm Midnight@RockcrawlerChasmStart1-RockcrawlerChasmEnd1
step
#completewith next
#label Empty Nest
.goto 650,51.58,37.44,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 39305 >>Turn in Empty Nest
.target Oren Windstrider
step
#completewith Empty Nest
#title |cFFFCDC00Enter Cave|r
.goto 650,50.89,36.56,40 >>Enter the Cave
step
#requires Empty Nest
#label Rockcrawler Chasm
.goto 650,50.89,36.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oren Windstrider|r
.turnin 39305 >>Turn in Empty Nest
.target Oren Windstrider
step
#include RestedXP Speed Leveling\a) The Skyhorn Tribe Midnight@TheSkyhornTribeStart2-TheSkyhornTribeEnd2
step
.isQuestAvailable 40505
.goto 650,52.05,32.44
.turnin 40505>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 650,50.13,32.11
>>Kill |cRXP_ENEMY_Agara Deathsong|r
.complete 39321,2 
.mob Agara Deathsong
step
.isQuestAvailable 40506
.goto 650,50.81,35.05
.turnin 40506>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#label Skywhisker Loyalist slain
.goto 650,50.58,35.44
>>Kill |cRXP_ENEMY_Ugla the Hag|r
.complete 39321,3 
.mob Ugla the Hag
step
.isQuestAvailable 39466
.goto 650,49.64,37.75
.turnin 39466>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#loop
.goto 650,49.44,36.26,30,0
.goto 650,49.68,31.82,30,0
.goto 650,50.79,31.8,30,0
.goto 650,52.8,33.62,30,0
.goto 650,53.24,35.49,30,0
>>Kill |cRXP_ENEMY_Skywhiskers|r and |cRXP_ENEMY_Crawliacs|r
.complete 39429,2 
.complete 39429,1 
.mob Skywhisker Loyalist
.mob Crawliac Hagfeathers
.mob Deathscreamers
step
.isQuestAvailable 39466
.goto 650,49.64,37.77
.turnin 39466>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 650,49.22,36.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39321 >>Turn in The Three
.target Lasan Skyhorn
.turnin 39429 >>Turn in Assaulting the Haglands
.accept 39322 >>Accept The Witchqueen
step
.goto 650,46.36,39.96
>>Kill |cRXP_ENEMY_High Crawliac|r
.complete 39322,1 
.mob High Crawliac
step
.isQuestAvailable 40507
.goto 650,46.82,40.14
.turnin 40507>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 650,45.68,39.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lasan Skyhorn|r
.turnin 39322 >>Turn in The Witchqueen
.target Lasan Skyhorn
.accept 39387 >>Accept The Skies of Highmountain
step
#completewith Hex-a-Gone
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40316,1
.mob Cursed Prowler
.mob Cursed Elderhorn
step
.goto 650,45.74,42.49
>>Kill |cRXP_ENEMY_Morashu|r. Loot him for |T454039:0|t[|cRXP_LOOT_Morashu's Antlers|r].
.complete 39178,1 
.mob Morashu
step
#completewith next
#label Irewing
>>Kill |cRXP_ENEMY_Irewing|r
.complete 40228,1 
.mob Irewing
step
#completewith Irewing
.goto 650,43.45,45.44
.cast 195071 >>Use |T134536:0|t[Flare Gun] on the rock.
.use 130074
step
#requires Irewing
.goto 650,43.45,45.44
>>Kill |cRXP_ENEMY_Irewing|r
.complete 40228,1 
.mob Irewing
step
.isQuestAvailable 39503
.goto 650,47.64,44.07
.turnin 39503>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 650,47.17,47.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maltha Silenthoof|r
.accept 39419 >>Accept Hex-a-Gone
.target Maltha Silenthoof
step
.goto 650,45.64,49.25
>>Kill |cRXP_ENEMY_Hexweaver Akara|r
.complete 39419,1 
.mob Hexweaver Akara
step
#label Hex-a-Gone
.goto 650,47.17,47.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maltha Silenthoof|r
.turnin 39419 >>Turn in Hex-a-Gone
.target Maltha Silenthoof
step
.isOnQuest 40316
#loop
.goto 650,45.11,45.94,30,0
.goto 650,46.6,44.58,30,0
.goto 650,47.51,46.81,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40316,1
.mob Cursed Prowler
.mob Cursed Elderhorn
.mob Hexxing Fetish
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r, |cRXP_FRIENDLY_Laeni Silvershot|r and |cRXP_FRIENDLY_Ellias|r
.turnin 39178 >>Turn in Moose on the Loose
.goto 650,40.01,52.3
.target +Laeni Silvershot
.turnin 40228 >>Turn in Scout It Out
.accept 40244 >>Accept That Guy in the Costume
.accept 39386 >>Accept Procuring a Prototype
.goto 650,40.04,52.25
.target +Hemet Nesingwary
step
#include RestedXP Speed Leveling\a) The Bloodtotem Tribe Midnight@BloodTotemStart1-BloodTotemEnd1
step
.isQuestAvailable 40479
.goto 650,42.2,27.32
.turnin 40479>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#loop
.goto 650,42.16,29.64,30,0
.goto 650,41.06,31.23,30,0
.goto 650,41.79,33.61,30,0
.goto 650,40.3,33.2,30,0
.goto 650,40.55,29.54,30,0
>>Kill |cRXP_ENEMY_Witchwood Hag|r. Loot them for |T132918:0|t[|cRXP_LOOT_Hag Feather|r].
.complete 39373,1 
.mob Witchwood Hag
step
.isQuestAvailable 40480
.goto 650,42.51,35.05
.turnin 40480>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#include RestedXP Speed Leveling\a) The Bloodtotem Tribe Midnight@BloodTotemStart2-BloodTotemEnd2
step
.isQuestAvailable 40477
.goto 650,37.35,33.81
.turnin 40477>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label Harpy Placed on Altar
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r
.complete 39455,1 
step
#completewith Harpy Placed on Altar
#title |cFFFCDC00Enter Cave|r
.goto 650,37.62,33.52,15 >>Enter the Cave
step
#requires Harpy Placed on Altar
.goto 653,54.04,28.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r
.complete 39455,1 
step
#include RestedXP Speed Leveling\a) The Bloodtotem Tribe Midnight@BloodTotemStart2.5-BloodTotemEnd2.5
step
#label Stonedark Focus
.goto 650,45.32,27.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gravel|r
.complete 39391,3 
step
.isQuestAvailable 40482
.goto 650,46.66,28.12
.turnin 40482>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#loop
.goto 650,46.72,28.1,40,0
.goto 650,47.71,29.76,40,0
.goto 650,43.82,30.84,40,0
.goto 650,43.29,33.2,40,0
.goto 650,44.33,28.42,40,0
>>Kill |cRXP_ENEMY_Feltotems|r. Loot them for |T237176:0|t[|cRXP_LOOT_Stonedark Focus|r].
.complete 39588,1 
.complete 39425,1 
.mob Feltotem Bloodbinder
.mob Feltotem Warmonger
step
.isQuestAvailable 40481
.goto 650,45.56,34.6
.turnin 40481>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label They Will Pay With Blood
.goto 650,45.06,31.93,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 39425 >>Turn in Stonedark Crystal
.target Navarrogg
.turnin 39588 >>Turn in They Will Pay With Blood
.turnin 39391 >>Turn in Pet Rocks
.accept 39426 >>Accept Blood Debt
step
#completewith They Will Pay With Blood
#title |cFFFCDC00Enter Cave|r
.goto 650,45.21,32.52,30 >>Enter the Cave
step
#requires They Will Pay With Blood
.goto 650,45.21,32.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 39425 >>Turn in Stonedark Crystal
.target Navarrogg
.turnin 39588 >>Turn in They Will Pay With Blood
.turnin 39391 >>Turn in Pet Rocks
.accept 39426 >>Accept Blood Debt
step
#completewith next
#label Torok Bloodtotem
.goto 650,45.09,31.78,15,0
>>Kill |cRXP_ENEMY_Torok Bloodtotem|r
.complete 39426,1 
.mob Torok Bloodtotem
step
#completewith Torok Bloodtotem
#title |cFFFCDC00Leave Cave|r
.goto 650,49.53,23.62,500 >>Leave the Cave
step
#requires Torok Bloodtotem
#label BloodTotemEnd3
.goto 650,49.53,23.62
>>Kill |cRXP_ENEMY_Torok Bloodtotem|r.
.complete 39426,1 
.mob Torok Bloodtotem
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r |cRXP_WARN_next to you|r.
.turnin 39426 >>Turn in Blood Debt
.target Navarrogg
.accept 40229 >>Accept Step into the Dark
step
#loop
.goto 650,49.05,27.27,25,0
.goto 650,47.82,27.25,25,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 42373,1
.mob Feltotem Bloodbinder
.mob Feltotem Warmonger
step
#completewith next
#label Step into the Dark
.goto 659,21.07,80.68,15,0
.goto 659,23.3,73.82,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 40229 >>Turn in Step into the Dark
.accept 39456 >>Accept Unexpected Allies
.disablecheckbox
step
#completewith Step into the Dark
#title |cFFFCDC00Enter Cave|r
.goto 659,40.25,53.17,90 >>Enter the Cave
step
#requires Step into the Dark
.goto 659,40.25,53.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.turnin 40229 >>Turn in Step into the Dark
.accept 39456 >>Accept Unexpected Allies
.target Navarrogg




step
#include RestedXP Speed Leveling\a) Stonedark Cavern: Trials of Liftbrul Midnight@LiftbrulStart1-LiftbrulEnd1
step
.isQuestAvailable 40478
.goto 659,35.95,72.63
.turnin 40478>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 659,54.19,73.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rod|r
.complete 39439,3 
step
#loop
.goto 659,66.53,68.87,40,0
.goto 659,73,51.61,40,0
.goto 659,73.53,68.97,40,0
>>Kill |cRXP_ENEMY_Deepcavern Murloc|r
.complete 39437,1 
.mob Deepcavern Murloc
step
.goto 659,52.40,62.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Damrul the Stronk|r
.turnin 39438 >>Turn in Guhruhlruhlruh
.target Damrul the Stronk
.turnin 39437 >>Turn in Deep in the Cavern
.turnin 39439 >>Turn in Stonedark Relics
step
.isOnQuest 39456
#title |cFFFCDC00Leave Cave|r
.goto 659,22.87,75.97,10,0
.goto 650,42.73,25.36,15 >>Leave the Cave
step
#completewith MurkyWatersEnd1
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40050,1
step
.isOnQuest 40244
#title |cFFFCDC00Skyride to him|r
.goto 650,42.73,10.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 40244 >>Turn in That Guy in the Costume
.target King Mrgl-Mrgl
.accept 40047 >>Accept I'll Huff, I'll Puff...
.accept 40049 >>Accept Slime Time
.accept 40045 >>Accept Nature vs. Nurture
step
#title |cFFFCDC00Skyride to him|r
.goto 650,42.73,10.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.target King Mrgl-Mrgl
.accept 40047 >>Accept I'll Huff, I'll Puff...
.accept 40049 >>Accept Slime Time
.accept 40045 >>Accept Nature vs. Nurture
step
#include RestedXP Speed Leveling\a) Murky Waters Midnight@MurkyWatersStart1-Murky Waters
step
#loop
.goto 650,49.3,14.09,30,0
.goto 650,47.53,8.05,30,0
.goto 650,46.17,6.37,30,0
.goto 650,43.01,9.11,30,0
>>Kill |cRXP_ENEMY_Enemies|r and click on |cRXP_PICK_Objects|r.
.complete 40050,1
step
.isOnQuest 39387
.hs >>Use Hearthstone
step
#completewith next
#label Meet Lasan
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.complete 39387,1 
.target Lasan Skyhorn
step
#completewith Meet Lasan
#title |cFFFCDC00Leave Building|r
.goto 750,51.27,53.71,15 >>Leave the Building
step
#requires Meet Lasan
.goto 750,42.16,33.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.complete 39387,1 
.timer 48,RP1
.skipgossipid 44839
.target Lasan Skyhorn
step
.goto 750,34.84,44.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Navarrogg|r
.complete 39456,1 
.timer 30,RP2
.skipgossipid 44200 
.target Navarrogg
step
.isQuestAvailable 40475
.goto 750,32.35,41.81
.turnin 40475>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.isQuestAvailable 40472
.goto 750,50.6,75.36
.turnin 40472>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.isQuestAvailable 39531
.goto 750,63.49,59.39
.turnin 39531>>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#completewith next
#label Witness the Stonedark Ritual
#title |cFFFCDC00Follow the Arrow|r
.goto 652,25.14,80.45,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r at lowest level of Thunder Totem.
.turnin 42622 >>Turn in Ceremonial Drums
.target Torv Dubstomp
step
#completewith Witness the Stonedark Ritual
#title |cFFFCDC00Enter Building|r
.goto 652,54.79,63.18,105 >>Enter the Building
step
#requires Witness the Stonedark Ritual
.goto 652,54.78,77.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torv Dubstomp|r at lowest level of Thunder Totem.
.turnin 42622 >>Turn in Ceremonial Drums
.target Torv Dubstomp
step
.isQuestAvailable 40471
.goto 652,62.98,67.92
.turnin 40471 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
.goto 652,54.79,63.18
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 39456,2 
.complete 39387,2
step
.goto 652,54.80,63.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39456 >>Turn in Unexpected Allies
.turnin 39387 >>Turn in The Skies of Highmountain
.turnin 39580 >>Turn in The High Chieftain
.accept 38915 >>Accept Battle of Snowblind Mesa
.target Mayla Highmountain
step
#include RestedXP Speed Leveling\a) Battle of Snowblind Mesa Midnight@Battle of Snowblind Mesa-BattleofSnowblindMesaEnd2
step
#include RestedXP Speed Leveling\a) Icepine Point Midnight@IcepinePointStart1-IcepinePointEnd1
step
.goto 650,57.63,56.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razik Gazbolt|r
.turnin 39656 >>Turn in Wolf Pack Attack
.target Razik Gazbolt
step
#include RestedXP Speed Leveling\a) Battle of Snowblind Mesa Midnight@Arxas-Battle of Snowblind Mesa2
step
.goto 650,53.19,70.89
#title |cFFFCDC00Follow the Arrow|r
.complete 39780,1 
.timer 10,RP
step
.isQuestAvailable 40471
.goto 650,52.55,66.38
.turnin 40471 >>Click on the |cRXP_PICK_Small Treasure Chest|r for experience and powers.
step
#label Wrath of Dargrul
.goto 650,53.15,70.77
>>Kill |cRXP_ENEMY_Wrath of Dargrul|r
.complete 39780,2 
.mob Wrath of Dargrul
step
#label HighmountainSpeedrun2Z
.goto 650,53.19,70.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r
.turnin 39780 >>Turn in The Underking
.accept 39781 >>Accept Neltharion's Lair: Death to the Underking
.target Mayla Highmountain
step
.subzoneskip 6292
.isOnQuest 65436
>>Use |T134309:0|t[Lost Dragonscale] to teleport to Stormwind.
.complete 65436,1 
.use 205456
step
.isOnQuest 40519
.subzone 10523 >>Use |T135975:0|t[Stormwind Portal Stone]
.cooldown item,132120,>0,1
.use 132120
step
.zoneskip 84
.zone 2352 >>Teleport to a Neighborhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.goto 2352,57.43,26.65
.zone 84 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.zoneskip 2352,1
step
.pve
+You can enable War Mode to gain 10–30% bonus experience and additional PvP talents; however, this makes you hostile to the opposing faction and you’ll remain attackable at all times until War Mode is turned off in a rested area.
*To turn on Warmode press the macro in the "Active Items Frame"
.macro Enable Warmode,1965766 >>/run C_PvP.ToggleWarMode();
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) Tiragarde Sound Midnight
#internal
<< Alliance
step
#completewith next
#label Norwington Festival
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.accept 48070 >>Accept The Norwington Festival
step
#completewith Norwington Festival
.goto 84,45.06,90.02,10,0
.goto 84,44.8,91.69,10,0
.goto 84,42.94,93.81,10,0
.goto 84,40.88,92.76
.zone 1161 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Boralus|r.
step
#requires Norwington Festival
.goto 895,67.14,24.80
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.accept 48070 >>Accept The Norwington Festival
step
.goto 895,66.85,24.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r.
.accept 51358 >>Accept WANTED: Gryphon 'Nappers
step
.goto 895,67.40,24.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Davey Brindle|r.
.accept 50699 >>Accept Worker's Rights
.target Davey Brindle
step
#completewith Give a Dam
+|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Small Treasure Chests|r|cRXP_WARN_(they spawn randomly in BFA zones and grant decent XP)|r.
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maynard Algerson|r and |cRXP_FRIENDLY_Benjamin Algerson|r.
.turnin 50699 >>Turn in Worker's Rights
.accept 49465 >>Accept Maximizing Resources
.accept 49452 >>Accept Inventory Deficit
.goto 895,68.92,20.43,10,0
.goto 895,68.93,20.59
.accept 49451 >>Accept Time Off Requests
.goto 895,68.89,20.44,5,0
.goto 895,68.89,19.84
.target Maynard Algerson
.target Benjamin Algerson
step
#completewith Loamy Soil
>>Kill |cRXP_ENEMY_Timberbough Invaders|r and |cRXP_ENEMY_Timberfang Lurkers|r
*Loot them for |T236946:0|t[|cRXP_LOOT_Wood-Adorned Skull|r].
.complete 49465,1 
.mob Timberbough Invader
.mob Timberfang Lurker
step
.goto 895,68.41,19.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r.
.complete 49452,1,1 
step
.goto 895,68.17,18.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangled Lumberjack|r.
.complete 49451,1,1 
.target Entangled Lumberjack
step
.goto 895,68.06,18.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r.
.complete 49452,1,2 
step
.goto 895,67.64,19.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangled Lumberjack|r.
.complete 49451,1,2 
.target Entangled Lumberjack
step
.goto 895,67.37,19.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangled Lumberjack|r.
.complete 49451,1,3 
.target Entangled Lumberjack
step
.goto 895,67.4,19.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Reclaimed Axe|r.
.complete 49452,1,3 
step
.goto 895,67.41,18.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Reclaimed Axe|r.
.complete 49452,1,4 
step
.goto 895,67.43,18.6
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangled Lumberjack|r.
.complete 49451,1,4 
.target Entangled Lumberjack
step
.goto 895,67.53,18.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Reclaimed Axe|r.
.complete 49452,1,5 
step
.goto 895,67.27,17.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangled Lumberjack|r.
.complete 49451,1,5 
.target Entangled Lumberjack
step
#label Give a Dam
.goto 895,66.62,17.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssa Treewarden|r.
.accept 49453 >>Accept Give a Dam
.accept 48557 >>Accept Sowing Saplings
.target Lyssa Treewarden
step
#completewith Loamy Soil
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Woodchewing Beavers|r.
.complete 49453,1 
.target Woodchewing Beaver
step
.goto 895,66.55,16.8
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loamy Soil|r.
.complete 48557,1,1 
step
.goto 895,66.29,16.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loamy Soil|r.
.complete 48557,1,2 
step
.goto 895,66.51,15.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loamy Soil|r.
.complete 48557,1,3 
step
#label Loamy Soil
.goto 895,66.62,15.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loamy Soil|r.
.complete 48557,1,4 
step
#completewith next
>>Kill |cRXP_ENEMY_Timberbough Invaders|r and |cRXP_ENEMY_Timberfang Lurkers|r
*Loot them for |T236946:0|t[|cRXP_LOOT_Wood-Adorned Skull|r].
.complete 49465,1 
.mob Timberbough Invader
.mob Timberfang Lurker
step
#loop
.goto 895,66.94,16.03,20,0
.goto 895,66.79,16.56,20,0
.goto 895,66.37,17.3,20,0
.goto 895,66.03,15.69,20,0
.goto 895,66.5,15.33,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Woodchewing Beavers|r.
.complete 49453,1 
.target Woodchewing Beaver
step
.goto 895,66.62,17.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssa Treewarden|r.
.turnin 49453 >>Turn in Give a Dam
.turnin 48557 >>Turn in Sowing Saplings
.target Lyssa Treewarden
step
#loop
.goto 895,67.51,17.88,25,0
.goto 895,68.62,18.49,25,0
.goto 895,68.57,20.4,25,0
.goto 895,67.5,20.48,25,0
.goto 895,67.14,18.81,25,0
>>Kill |cRXP_ENEMY_Timberbough Invaders|r and |cRXP_ENEMY_Timberfang Lurkers|r
*Loot them for |T236946:0|t[|cRXP_LOOT_Wood-Adorned Skull|r].
.complete 49465,1 
.mob Timberbough Invader
.mob Timberfang Lurker
step
.goto 895,68.92,20.43,10,0
.goto 895,68.93,20.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maynard Algerson|r.
.turnin 49465 >>Turn in Maximizing Resources
.turnin 49452 >>Turn in Inventory Deficit
.turnin 49451 >>Turn in Time Off Requests
.accept 48369 >>Accept Emergent Strategy
.target Maynard Algerson
step
.goto 895,68.9,20.44,5,0
.goto 895,70.09,18.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Benjamin Algerson|r.
.turnin 48369 >>Turn in Emergent Strategy
.accept 49468 >>Accept Required Webinar
.accept 49454 >>Accept Pest Prevention
.accept 49450 >>Accept Incident Reports
.target Benjamin Algerson
step
#completewith Webbed Lumberjack freed
>>Kill |cRXP_ENEMY_Bears|r, |cRXP_ENEMY_Spiders|r and |cRXP_ENEMY_Eggs|r.
.complete 49450,1 
.complete 49454,1 
.mob Enthralled Ashclaw
.mob Enthralled Mossfang
.mob Mossfang Egg
step
.goto 895,70.63,18.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Lumberjack|r.
.complete 49468,1,1 
.target Webbed Lumberjack
step
.goto 895,71.29,17.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Lumberjack|r.
.complete 49468,1,2 
.target Webbed Lumberjack
step
.goto 895,71.84,18.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Lumberjack|r.
.complete 49468,1,3 
.target Webbed Lumberjack
step
.goto 895,72.33,17.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Lumberjack|r.
.complete 49468,1,4 
.target Webbed Lumberjack
step
.goto 895,72.96,17.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Terrence Foster|r.
.accept 50058 >>Accept The Witch's Pet
.target Terrence Foster
step
.goto 895,73.49,18.71
>>Kill |cRXP_ENEMY_Mossfang Matriarch|r.
*|cRXP_WARN_Avoid the frontal cone|r.
.complete 50058,1 
.mob Mossfang Matriarch
step
#label Webbed Lumberjack freed
.goto 895,73.61,19.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Lumberjack|r.
.complete 49468,1,5 
.target Webbed Lumberjack
step
>>Click the Quest Turnin Pop-Up in your Questlog
.turnin 50058 >>Turn in The Witch's Pet
step
#loop
.goto 895,72.32,16.95,25,0
.goto 895,71.01,16.98,25,0
.goto 895,70.05,17.72,25,0
.goto 895,70.52,19.59,25,0
.goto 895,72.33,18.35,25,0
>>Kill |cRXP_ENEMY_Bears|r, |cRXP_ENEMY_Spiders|r and |cRXP_ENEMY_Eggs|r.
.complete 49450,1 
.complete 49454,1 
.mob Enthralled Ashclaw
.mob Enthralled Mossfang
.mob Mossfang Egg
step
.goto 895,70.09,18.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Benjamin Algerson|r.
.turnin 49468 >>Turn in Required Webinar
.turnin 49454 >>Turn in Pest Prevention
.turnin 49450 >>Turn in Incident Reports
.accept 49467 >>Accept Witch of the Woods
.target Benjamin Algerson
step
.goto 895,70.45,13.75
>>Kill the |cRXP_ENEMY_Witch of the Woods|r.
*Loot her for |T1013278:0|t[|cRXP_LOOT_Petula's Locket|r].
*|cRXP_WARN_Avoid the frontal cone|r.
.complete 49467,1 
.mob Witch of the Woods
step
.goto 895,68.85,13.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maynard Algerson|r.
.turnin 49467 >>Turn in Witch of the Woods
.target Maynard Algerson
step
#completewith next
#label Boris
.goto 895,67.38,22.07,20,0
>>Kill |cRXP_ENEMY_Boris|r and |cRXP_ENEMY_Lindel|r.
.complete 51358,1 
.complete 51358,2 
.mob Lindel the Snatcher
.mob Silent Boris
step
#completewith Boris
.goto 895,67.24,21.74,20 >>Enter the Cave.
step
#requires Boris
.goto 895,67.24,21.74
>>Kill |cRXP_ENEMY_Boris|r and |cRXP_ENEMY_Lindel|r.
.complete 51358,1 
.complete 51358,2 
.mob Lindel the Snatcher
.mob Silent Boris
step
#completewith next
#label Gryphon 'Nappers
.goto 895,66.42,24.42,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dandy Jones|r.
.turnin 51358 >>Turn in WANTED: Gryphon 'Nappers
.target Dandy Jones
step
#completewith Gryphon 'Nappers
.goto 895,66.27,24.28,15 >>Enter the House
step
#requires Gryphon 'Nappers
.goto 895,66.27,24.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dandy Jones|r.
.turnin 51358 >>Turn in WANTED: Gryphon 'Nappers
.target Dandy Jones
step
#completewith next
#label Drust in Time
.goto 895,66.42,24.42,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Hatherford Guard|r.
.accept 50700 >>Accept Drust in Time
.target Hatherford Guard
step
#completewith Drust in Time
.goto 895,66.32,24.80,10 >>Leave the House.
step
#requires Drust in Time
.goto 895,66.32,24.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Hatherford Guard|r.
.accept 50700 >>Accept Drust in Time
.target Hatherford Guard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drogrin Alewhisker|r and |cRXP_FRIENDLY_Recruit Brutis|r.
.turnin 50700 >>Turn in Drust in Time
.accept 49225 >>Accept Chasing the Leader
.accept 49229 >>Accept The Ruins Fought Back
.goto 895,62.73,29.95
.accept 49234 >>Accept A Marine Out of Water
.goto 895,62.95,29.92
.target Drogrin Alewhisker
.target Recruit Brutis
step
#completewith
>>Kill |cRXP_ENEMY_Ancient Protectors|r.
.complete 49229,1 
.mob Ancient Protector
step
#completewith next
#label Salvaging a Disaster
.goto 1171,44.51,88.32,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Birch Tomlin|r and |cRXP_FRIENDLY_Pendi Cranklefuse|r.
.accept 49233 >>Accept I'm a Druid, Not a Priest
.accept 49232 >>Accept Salvaging a Disaster
.target Birch Tomlin
.target Pendi Cranklefuse
step
#completewith Salvaging a Disaster
.goto 1171,50.39,70.36,95 >>Enter the Cave.
step
#requires Salvaging a Disaster
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Birch Tomlin|r and |cRXP_FRIENDLY_Pendi Cranklefuse|r.
.accept 49233 >>Accept I'm a Druid, Not a Priest
.goto 1171,50.39,70.36
.accept 49232 >>Accept Salvaging a Disaster
.goto 1171,51.27,70.58
.target Birch Tomlin
.target Pendi Cranklefuse
step
#completewith Ancient Protector
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cursed Raiders|r.
.complete 49233,1 
.use 153350
.mob Cursed Raider
step
.goto 1171,57.34,65.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r.
.complete 49232,1,1 
step
.goto 1171,64.17,53.31,20,0
.goto 1171,58.63,37.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilde Firebreaker|r.
.turnin 49225 >>Turn in Chasing the Leader
.accept 49260 >>Accept Backup While I Pack Up
.target Hilde Firebreaker
step
#completewith Ancient Protector
>>|cRXP_WARN_Don't Defend|r |cRXP_FRIENDLY_Firebreaker|r; Move on, but watch for possible ambushes.
.complete 49260,1 
step
#title |cFFFCDC00Follow the Arrow|r
.goto 1171,62.59,55.61,10,0
.goto 1171,41.39,50.8
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r.
.complete 49232,1,2 
step
.goto 1172,44.19,69.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r.
.complete 49232,1,3 
step
.goto 1172,51.73,83.04,10,0
.goto 1172,66.72,42.72,10,0
.goto 1172,59.84,18.18
>>Kill |cRXP_ENEMY_Awakened Guardian|r.
.complete 49234,1 
.mob Awakened Guardian
step
.goto 1172,59.55,13.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r.
.complete 49232,1,4 
step
.goto 1171,46.34,54.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r.
.complete 49232,1,5 
step
.goto 1171,44.99,60.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r.
.complete 49232,1,6 
step
#label Ancient Protector
.goto 1171,64.17,53.31,15,0
.goto 1171,58.63,37.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilde Firebreaker|r.
.turnin 49260 >>Turn in Backup While I Pack Up
.target Hilde Firebreaker
step
#hidewindow
#completewith Ancient Protector2
#loop
.goto 1171,75.94,39.38,20,0
.goto 1171,59.83,56.5,20,0
.goto 1171,43.87,55.47,20,0
.goto 1171,32.55,51.98,20,0
.goto 1171,21.94,59.7,20,0
.goto 1171,22.59,42.21,20,0
.goto 1171,34.77,39.74,20,0
.goto 1171,36.29,50.45,20,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Ancient Protectors|r.
.complete 49229,1 
.mob Ancient Protector
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cursed Raiders|r.
.complete 49233,1 
.use 153350
.mob Cursed Raider
step
#label Ancient Protector2
.goto 1171,51.27,70.58
>>Kill |cRXP_ENEMY_Ancient Protectors|r.
.complete 49229,1 
.mob Ancient Protector
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pendi Cranklefuse|r and |cRXP_FRIENDLY_Birch Tomlin|r.
.turnin 49232 >>Turn in Salvaging a Disaster
.goto 1171,51.27,70.58
.turnin 49233 >>Turn in I'm a Druid, Not a Priest
.goto 1171,50.39,70.36
.target Pendi Cranklefuse
.target Birch Tomlin
step
#completewith next
#label Marine Out of Water
.goto 1171,40.22,71.90,15,0
.goto 1171,44.51,88.32,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Brutis|r and |cRXP_FRIENDLY_Drogrin Alewhisker|r.
.turnin 49234 >>Turn in A Marine Out of Water
.turnin 49229 >>Turn in The Ruins Fought Back
.target Recruit Brutis
.target Drogrin Alewhisker
step
#completewith Marine Out of Water
.goto 895,62.82,29.88,125 >>Leave the cave
step
#requires Marine Out of Water
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Brutis|r and |cRXP_FRIENDLY_Drogrin Alewhisker|r.
.turnin 49234 >>Turn in A Marine Out of Water
.goto 895,62.82,29.88
.turnin 49229 >>Turn in The Ruins Fought Back
.goto 895,62.73,29.95
.target Recruit Brutis
.target Drogrin Alewhisker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abbey Watkins|r and |cRXP_FRIENDLY_Harold Beckett|r.
.turnin 48070 >>Turn in The Norwington Festival
.accept 48077 >>Accept The Stoat Hunt
.goto 895,55.45,24.67
.accept 48080 >>Accept An Element of Danger
.accept 48616 >>Accept Bolas and Birds
.goto 895,55.52,24.59
.target Abbey Watkins
.target Harold Beckett
step
#completewith Mudbrush
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Falcons|r.
.complete 48616,1 
.use 152643
.mob Hollowbeak Falcon
step
#completewith Mudbrush
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stoat Den|r
*Kill |cRXP_ENEMY_Faintstep Stoat|r.
*Loot them for |T1029741:0|t[|cRXP_LOOT_Soft Stoat Pelt|r].
.complete 48077,1 
.mob Faintstep Stoat
step
#completewith Mudbrush
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for|T133722:0|t[|cRXP_LOOT_Rugged Boar Tusk|r].
.complete 48080,1 
.mob Mudbrush Boar
step
#completewith next
#label Settle the Score
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caleb Batharen|r.
.accept 48965 >>Accept Settle the Score
.target Caleb Batharen
step
#completewith Settle the Score
#hidewindow
.goto 895,55.85,25.28,20,0
.goto 895,56.2,26.62,20,0
.goto 895,56.5,28.3,20,0
.goto 895,57.03,25.69,20,0
.goto 895,57.69,26.55,20,0
.goto 895,58.3,25.4,50 >>Follow the Arrow
step
#requires Settle the Score
.goto 895,58.3,25.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caleb Batharen|r.
.accept 48965 >>Accept Settle the Score
.target Caleb Batharen
step
#completewith next
#label Chartusk
.goto 895,61.18,22.09,20,0
>>Kill |cRXP_ENEMY_Chartusk|r.
.complete 48965,1 
step
#completewith Chartusk
.goto 895,61.67,22.73,50>>Enter the Cave.
step
#requires Chartusk
.goto 895,61.67,22.73
>>Kill |cRXP_ENEMY_Chartusk|r.
.complete 48965,1 
step
#label Mudbrush
.goto 895,58.29,25.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caleb Batharen|r.
.turnin 48965 >>Turn in Settle the Score
.target Caleb Batharen
step
#hidewindow
#completewith Hollowbeak Falcons
#loop
.goto 895,60,22.4,30,0
.goto 895,58.1,23.74,30,0
.goto 895,56.09,24.3,30,0
.goto 895,55.52,25.55,30,0
.goto 895,57.93,25.59,30,0
.goto 895,57.46,28.92,30,0
+1
step
#completewith Rugged Boar Tusk
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Falcons|r.
.complete 48616,1 
.use 152643
.mob Hollowbeak Falcon
step
#completewith Rugged Boar Tusk
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stoat Den|r
*Kill |cRXP_ENEMY_Faintstep Stoat|r.
*Loot them for |T1029741:0|t[|cRXP_LOOT_Soft Stoat Pelt|r].
.complete 48077,1 
.mob Faintstep Stoat
step
#label Rugged Boar Tusk
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for|T133722:0|t[|cRXP_LOOT_Rugged Boar Tusk|r].
.complete 48080,1 
.mob Mudbrush Boar
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Falcons|r.
.complete 48616,1 
.use 152643
.mob Hollowbeak Falcon
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stoat Den|r
*Kill |cRXP_ENEMY_Faintstep Stoat|r.
*Loot them for |T1029741:0|t[|cRXP_LOOT_Soft Stoat Pelt|r].
.complete 48077,1 
.mob Faintstep Stoat
step
#label Hollowbeak Falcons
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Falcons|r.
.complete 48616,1 
.use 152643
.mob Hollowbeak Falcon
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Beckett|r, |cRXP_FRIENDLY_Abbey Watkins|r and |cRXP_FRIENDLY_Melissa Kenny|r.
.turnin 48616 >>Turn in Bolas and Birds
.turnin 48080 >>Turn in An Element of Danger
.goto 895,55.52,24.59
.turnin 48077,1 >>Turn in The Stoat Hunt
.goto 895,55.45,24.66
.accept 48670 >>Accept Runaway Rider
.goto 895,55.59,24.6
.target Harold Beckett
.target Abbey Watkins
.target Melissa Kenny
step
.goto 895,54.47,19.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melissa Kenny|r.
.turnin 48670 >>Turn in Runaway Rider
.accept 48196 >>Accept Following Eddie's Trail
.accept 48195 >>Accept Troublesome Troglodytes
.target Melissa Kenny
step
.goto 895,56.09,17.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Corpse|r.
.complete 48196,1 
.target Hotshout
step
.goto 895,56.17,17.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rock|r.
.accept 48778 >>Accept Stone Soup
step
.goto 895,56.15,17.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 48778,1,1 
step
#completewith Stone Soup
>>Kill |cRXP_ENEMY_Grimestones|r.
*Loot |cRXP_ENEMY_Chefs|r for |T237350:0|t[|cRXP_LOOT_Meat|r].
.complete 48195,1 
.complete 48195,2 
.complete 48778,2 
.mob Grimestone Bully
.mob Grimestone Thrower
step
.goto 895,55.95,17.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trapped Saurolisk|r.
.accept 48597 >>Accept Saurolisk Escape
.target Trapped Saurolisk
step
.goto 895,56.38,17.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Post|r.
.complete 48597,1,1 
.target Trapped Saurolisk
step
.goto 895,56.44,16.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 48778,1,2 
step
.goto 895,56.47,16.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Post|r.
.complete 48597,1,2 
.target Trapped Saurolisk
step
.goto 895,56.22,16.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag of Horse Treats|r.
.complete 48196,2 
step
.goto 895,56.03,15.3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 48778,1,3 
step
.goto 895,55.89,14.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Post|r.
.complete 48597,1,3 
.target Trapped Saurolisk
step
.goto 895,55.7,14.32
>>Kill |cRXP_ENEMY_Boneface the Giant|r
*Loot him for the |T135233:0|t[|cRXP_LOOT_Key|r].
.complete 48196,3 
.mob Boneface the Giant
step
.goto 895,55.62,14.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 48196,4 
.target Eddie Norwingto
step
.goto 895,55.61,14.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eddie Norwington|r.
.turnin 48196 >>Turn in Following Eddie's Trail
.target Eddie Norwington
step
.goto 895,55.99,15.36,5,0
.goto 895,56.87,15.1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 48778,1,4 
step
#completewith Stone Soup
>>Kill |cRXP_ENEMY_Grimestone Handlers|r
*Loot them for |T1526620:0|t[|cRXP_LOOT_Saurolisk Scale|r].
.complete 48778,3 
.mob Grimestone Handlers
step
.goto 895,58.07,14.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stirring Bone|r.
.complete 48778,4 
step
.goto 895,58.32,14.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Post|r.
.complete 48597,1,4 
.target Trapped Saurolisk
step
.goto 895,58.44,15.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Post|r.
.complete 48597,1,5 
.target Trapped Saurolisk
step
#label Stone Soup
.goto 895,58.18,15.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Post|r.
.complete 48597,1,6 
.target Trapped Saurolisk
step
#hidewindow
#completewith Chefs
#loop
.goto 895,58.78,15.63,20,0
.goto 895,58.41,16.72,20,0
.goto 895,57.17,17.21,20,0
.goto 895,56.93,15.55,20,0
.goto 895,56.25,15.61,20,0
.goto 895,57.83,14.55,20,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Grimestones|r.
*Loot |cRXP_ENEMY_Chefs|r for |T237350:0|t[|cRXP_LOOT_Meat|r].
.complete 48195,1 
.complete 48195,2 
.complete 48778,2 
.mob Grimestone Bully
.mob Grimestone Thrower
step
>>Kill |cRXP_ENEMY_Grimestone Handlers|r
*Loot them for |T1526620:0|t[|cRXP_LOOT_Saurolisk Scale|r].
.complete 48778,3 
.mob Grimestone Handlers
step
#label Chefs
>>Kill |cRXP_ENEMY_Grimestones|r.
*Loot |cRXP_ENEMY_Chefs|r for |T237350:0|t[|cRXP_LOOT_Meat|r].
.complete 48195,1 
.complete 48195,2 
.complete 48778,2 
.mob Grimestone Bully
.mob Grimestone Thrower
step
.goto 895,56.56,15.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r.
.turnin 48778 >>Turn in Stone Soup
step
.goto 895,54.47,19.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melissa Kenny|r.
.turnin 48195 >>Turn in Troublesome Troglodytes
.turnin 48597 >>Turn in Saurolisk Escape
.accept 48003 >>Accept The Lord's Behest
.target Melissa Kenny
step
.goto 895,51.57,27.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 48003 >>Turn in The Lord's Behest
.accept 48005 >>Accept Be Our Guest
.target Lord Aldrius Norwington
step
.goto 895,51.57,27.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 48003 >>Turn in The Lord's Behest
.accept 48005 >>Accept Be Our Guest
.target Lord Aldrius Norwington
step
.goto 895,51.45,26.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dolan Northfield|r.
.complete 48005,1 
.target Dolan Northfield
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Joma|r and |cRXP_FRIENDLY_Majo|r.
.accept 48898 >>Accept Lucky Charm
.accept 48902 >>Accept Monstrous Energy
.goto 895,51.31,25.90
.accept 48899 >>Accept Safety First
.goto 895,51.29,25.87
.target Joma
.target Majo
step
.goto 895,49.74,25.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arthur Seville|r.
.complete 48005,2 
.target Arthur Seville
step
.goto 895,48.7,28.1
>>Damage |cRXP_ENEMY_Lucktail|r|cRXP_WARN_(Stealthed Fox)|r to 60%.
.complete 48898,1 
.mob Lucktail
step
.goto 895,48.12,25.43
>>Damage |cRXP_ENEMY_Lucktail|r to 30%.
.complete 48898,2 
.mob Lucktail
step
#completewith LucktailWaterfall
>>Kill |cRXP_ENEMY_Venomscale Slitherer|r.
*Loot them for |T1379235:0|t[|cRXP_LOOT_Pulsating Extract|r].
.complete 48902,1 
.mob Venomscale Slitherer
step
.goto 895,47.87,24.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,1 
step
.goto 895,47.9,22.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,2 
step
.goto 895,48.49,22.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,3 
step
.goto 895,49.41,22.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,4 
step
.goto 895,49.68,22.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,5 
step
.goto 895,50.02,23.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,6 
step
.goto 895,50.18,22.5
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,7 
step
.goto 895,50.39,22.8
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shell|r.
.complete 48899,1,8 
step
.goto 895,50.7,22.19
#label LucktailWaterfall
>>Kill |cRXP_ENEMY_Lucktail|r
*Loot them for |T134363:0|t[|cRXP_LOOT_Lucktail's Tail|r].
.complete 48898,3 
.mob Lucktail
step
#loop
.goto 895,49.15,23.63,30,0
.goto 895,47.06,24.91,30,0
.goto 895,48.18,22.62,30,0
>>Kill |cRXP_ENEMY_Venomscale Slitherer|r.
*Loot them for |T1379235:0|t[|cRXP_LOOT_Pulsating Extract|r].
.complete 48902,1 
.mob Venomscale Slitherer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Joma|r and |cRXP_FRIENDLY_Majo|r.
.turnin 48898 >>Turn in Lucky Charm
.turnin 48902 >>Turn in Monstrous Energy
.goto 895,51.32,25.90
.turnin 48899 >>Turn in Safety First
.accept 48903 >>Accept The Perfect Horse, of Course
.goto 895,51.28,25.87
.timer 27, Majo RP
.target Majo
.target Joma
step
#completewith Smithy visited
#hidewindow
.complete 48903,1 
.target Majo
step
.goto 895,53.10,28.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wanted Posters|r.
.accept 48347 >>Accept Anglepoint Wharf
.accept 51367 >>Accept WANTED: Raging Earthguard
step
.goto 895,53.31,28.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Terry Rigglesmith|r |cRXP_WARN_inside the small house|r.
.complete 48005,4 
.target Terry Rigglesmith
step
#label Smithy visited
.goto 895,53.48,28.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_George Mitchell|r |cRXP_WARN_outside the small house|r.
.complete 48005,3 
.target George Mitchell
step
.goto 895,51.68,25.67
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 48903,1 
.target Majo
step
.goto 895,51.68,25.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Goldie|r.
.complete 48903,2 
.target Goldie
step
.goto 895,51.79,25.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Scout|r.
.complete 48903,3 
.target Scout
step
.goto 895,51.87,25.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Avalon|r.
.complete 48903,4 
.target Avalon
step
.goto 895,51.83,26.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Maxwell|r.
.complete 48903,5 
.target Maxwell
step
.goto 895,51.81,26.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Majo|r.
.complete 48903,6 
.target Majo
step
.goto 895,51.81,26.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Joma|r.
.turnin 48903,1 >>Turn in The Perfect Horse, of Course
.target Joma
step
#completewith next
#label Be Our Guest
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 48005 >>Turn in Be Our Guest
.accept 48004 >>Accept Beginner Equitation
.target Lord Aldrius Norwington
step
#completewith Be Our Guest
.goto 895,51.65,26.21
.vehicle >>Click on |cRXP_FRIENDLY_Cooper|r.
.target Cooper
step
#requires Be Our Guest
.goto 895,51.57,27.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 48005 >>Turn in Be Our Guest
.accept 48004 >>Accept Beginner Equitation
.target Lord Aldrius Norwington
step
.goto 895,51.41,26.86
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Gnolls|r.
.complete 48004,2,1 
step
.goto 895,51.1,26.79
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Gnolls|r.
.complete 48004,2,2 
step
.goto 895,50.8,26.66
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Gnolls|r.
.complete 48004,2,3 
step
.goto 895,51.08,26.33
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Gnolls|r.
.complete 48004,2,4 
step
.goto 895,51.41,26.87
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Gnolls|r.
.complete 48004,2,5 
step
.goto 895,51.1,26.79
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Gnolls|r.
.complete 48004,2,6 
step
>>Use |T1661331:0|t(3)[Bolas] on |cRXP_FRIENDLY_Paper Zeppelins|r.
.complete 48004,3 
.target Paper Zeppelin
step
.goto 895,50.9,26.81
>>|cRXP_WARN_You only have to jump near/along the fences, not necessarily OVER the fences|r.
.complete 48004,4 
step
.goto 895,51.57,27.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 48004 >>Turn in Beginner Equitation
.accept 48087 >>Accept Equine Retrieval
.accept 48939 >>Accept Show Me What You've Got
.target Lord Aldrius Norwington
step
#completewith next
#label Challenge Explanation
#title Challenge Explanation
>>Jumping fences grants a stacking points buff from all sources.
*Stack to 15, then farm points |cRXP_WARN_don’t let it expire|r.
*|cRXP_WARN_Priority Buff,Zeppelins,Gnolls|r.
.complete 48939,2
step
#completewith Challenge Explanation
#title |cFFFCDC00Follow the Arrow|r
.goto 895,51.52,27.03,5 >>Challenge Start
step
#requires Challenge Explanation
>>Jumping fences grants a stacking points buff from all sources.
*Stack to 15, then farm points |cRXP_WARN_don’t let it expire|r.
*|cRXP_WARN_Priority Buff,Zeppelins,Gnolls|r.
.complete 48939,2
step
.goto 895,51.57,27.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldruis Norwington|r.
.turnin 48939 >>Turn Show Me What You've Got
.target Lord Aldruis Norwington
step
#completewith next
#label Rose mounted
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Rose|r.
.complete 48087,1 
.target Rose
step
#completewith Rose mounted
.goto 895,52.57,28.72
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Rose mounted
.goto 895,53.16,30.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Rose|r.
.complete 48087,1 
.target Rose
step
.goto 895,52.54,28.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.complete 48087,2 
.target Lord Aldrius Norwington
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r and |cRXP_FRIENDLY_Gora Layton|r.
.turnin 48087 >>Turn in Equine Retrieval
.accept 48088 >>Accept No Party Like a Trogg Party
.goto 895,52.54,28.50
.accept 48089 >>Accept Mountain Sounds
.goto 895,52.48,28.55
.target Lord Aldrius Norwington
.target Gora Layton
step
#completewith next
#label Kul Tirans rallied2
#hidewindow
.complete 48089,1 
step
#completewith Kul Tirans rallied2
.goto 895,52.53,28.61
.vehicle >>Click on |cRXP_PICK_Cooper|r.
.target Cooper
step
#requires Kul Tirans rallied2
#hidewindow
#completewith Kul Tirans rallied
#loop
.goto 895,52.45,28.31,10,0
.goto 895,53.16,28.81,20,0
.goto 895,51.88,27,25,0
.goto 895,51.1,25.45,25,0
.goto 895,51.34,26.45,25,0
.goto 895,50.57,27,25,0
.goto 895,50.56,27.8,25,0
.goto 895,51.19,28.17,25,0
.goto 895,50.98,29.14,25,0
.goto 895,51.93,29.1,25,0
+1
step
#requires Kul Tirans rallied2
#completewith next
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Grimestones|r.
.complete 48088,1 
.mob Grimestone Invader
step
#requires Kul Tirans rallied2
>>Use |T134228:0|t[Battlehorn of the Mountain] to rally Kul Tirans.
.complete 48089,1 
.target Kul Tiran Noble
.target Kul Tiran Equestrian
.use 153357
step
#label Kul Tirans rallied
>>Use |T132226:0|t(1)[Dash] for speed.
*Use |T1661331:0|t(2)[Jab] on |cRXP_ENEMY_Grimestones|r.
.complete 48088,1 
.mob Grimestone Invader
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gora Layton|r and |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 48088 >>Turn in No Party Like a Trogg Party
.goto 895,52.54,28.46
.turnin 48089 >>Turn in Mountain Sounds
.goto 895,52.49,28.55
.target Lord Aldrius Norwington
.target Gora Layton
step
#completewith next
#label Roughnecks
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flyer|r.
.accept 49393 >>Accept The Roughnecks
step
#completewith Roughnecks
.goto 895,52.57,28.72
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Roughnecks
.goto 895,51.67,29.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flyer|r.
.accept 49393 >>Accept The Roughnecks
step
.goto 895,49.46,31.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thomas Pinker|r.
.accept 50026 >>Accept Save Our Shipmates
step
.goto 895,47.26,32.37
>>Kill |cRXP_ENEMY_Raging Earthguard|r.
.complete 51367,1 
.mob Raging Earthguard
step
.goto 895,50.31,37.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Henry Hardwick|r.
.turnin 50026 >>Turn in Save Our Shipmates
.accept 47755 >>Accept Captured and Enraptured
.accept 50002 >>Accept A Very Precious Cargo
.target Henry Hardwick
step
#completewith Enthralled Sailor
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Enthralled Sailors|r.
.complete 47755,1 
.use 151135
.mob Enthralled Sailor
step
#completewith Enthralled Sailor
>>Kill |cRXP_ENEMY_Alluring Sirens|r and |cRXP_ENEMY_Lichenjaw Saurolisks|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r.
.complete 50009,1,100 
.mob Alluring Siren
.mob Lichenjaw Saurolisk
step
.goto 895,51.11,35.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earless Joe|r.
.accept 50059 >>Accept Can't Hear A Thing
.target Earless Joe
step
#completewith next
#label Anthemusa
.goto 895,53.7,33.44,15,0
>>Kill |cRXP_ENEMY_Anthemusa|r.
.complete 50059,1 
.mob Anthemusa
.use 151135
step
#completewith Anthemusa
.goto 895,53.65,32.67,35 >>Enter the Cave
step
#requires Anthemusa
>>Kill |cRXP_ENEMY_Anthemusa|r.
.complete 50059,1 
.mob Anthemusa
.use 151135
step
#label Enthralled Sailor
.goto 895,55.49,35.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Penny "Precious" Hardwick|r.
.turnin 50002 >>Turn in A Very Precious Cargo
.target Penny "Precious" Hardwick
step
#hidewindow
#completewith Enthralled Sailor2
#loop
.goto 895,54.13,35.37,25,0
.goto 895,53.51,36.92,25,0
.goto 895,51.59,37.53,25,0
.goto 895,51.93,35.49,25,0
.goto 895,53.46,33.95,25,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Enthralled Sailors|r.
.complete 47755,1 
.use 151135
.mob Enthralled Sailor
step
>>Kill |cRXP_ENEMY_Alluring Sirens|r and |cRXP_ENEMY_Lichenjaw Saurolisks|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r.
.complete 50009,1,100 
.mob Alluring Siren
.mob Lichenjaw Saurolisk
step
#label Enthralled Sailor2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Enthralled Sailors|r.
.complete 47755,1 
.use 151135
.mob Enthralled Sailor
step
.goto 895,51.11,35.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earless Joe|r.
.turnin 50059 >>Turn in Can't Hear A Thing
.target Earless Joe
step
.goto 895,50.31,37.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Henry Hardwick|r.
.turnin 47755 >>Turn in Captured and Enraptured
.target Henry Hardwick
step
#completewith next
#label Raging Earthguard
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 51367 >>Turn in WANTED: Raging Earthguard
.accept 49036 >>Accept Best In Show
.disablecheckbox
.target Lord Aldrius Norwington
step
#completewith Raging Earthguard
.goto 895,51.65,26.21
.vehicle >>Click on |cRXP_PICK_Cooper|r.
.target Cooper
step
#requires Raging Earthguard
.goto 895,51.57,27.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldrius Norwington|r.
.turnin 51367 >>Turn in WANTED: Raging Earthguard
.accept 49036 >>Accept Best In Show
.target Lord Aldrius Norwington
step
#completewith next
#label Challenge Explanation 2
*Stack to 15, then farm points |cRXP_WARN_don’t let it expire|r.
*|cRXP_WARN_Priority Buff,Zeppelins,Gnolls|r.
.complete 49036,2
step
#completewith Challenge Explanation 2
#title |cFFFCDC00Follow the Arrow|r
.goto 895,51.52,27.03,5 >>Challenge Start
step
#requires Challenge Explanation 2
>>Jumping fences grants a stacking points buff from all sources.
*Stack to 15, then farm points |cRXP_WARN_don’t let it expire|r.
*|cRXP_WARN_Priority Buff,Zeppelins,Gnolls|r.
.complete 49036,2
step
.goto 895,51.57,27.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Aldruis Norwington|r.
.turnin 49036 >>Turn in Best In Show
.target Lord Aldruis Norwington
step
#completewith next
#label WANTED: The Hornet
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wanted Poster|r.
.accept 51368 >>Accept WANTED: The Hornet
step
#completewith WANTED: The Hornet
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires WANTED: The Hornet
.goto 895,42.16,22.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wanted Poster|r.
.accept 51368 >>Accept WANTED: The Hornet
step
.goto 895,42.36,22.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tagart|r.
.turnin 49393 >>Turn in The Roughnecks
.accept 49394 >>Accept Hold Still
.accept 49395 >>Accept The Bears and the Bees
.target Tagart
step
#completewith Bee Honey
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goats|r.
*|cRXP_WARN_Goats may become hostile|r.
.complete 49394,1 
.use 153596
.mob Gentle Goat
step
#completewith Bee Honey
>>Kill |cRXP_ENEMY_Bears|r.
.complete 49395,2 
.mob Scruffhide Bear
step
.goto 895,45.38,20.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Honey|r.
.complete 49395,1,1 
step
.goto 895,46.51,19.6
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Honey|r.
.complete 49395,1,2 
step
.goto 895,47.09,18.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Honey|r.
.complete 49395,1,3 
step
.goto 895,47.44,18.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Honey|r.
.complete 49395,1,4 
step
.goto 895,47.11,18.2
>>Kill the |cRXP_ENEMY_Hornet|r.
.complete 51368,1 
.mob The Hornet
step
.goto 895,47.7,17.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Helpless" Henry|r.
.accept 49412 >>Accept Helping Henry
.target "Helpless" Henry
step
.goto 895,48.18,18.11
>>Kill |cRXP_ENEMY_Brawr|r.
.complete 49412,1 
.mob Brawr
step
.goto 895,47.68,17.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Helpless" Henry|r.
.turnin 49412 >>Turn in Helping Henry
.target "Helpless" Henry
step
.goto 895,47.45,19.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Honey|r.
.complete 49395,1,5 
step
#label Bee Honey
.goto 895,46.89,20.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Honey|r.
.complete 49395,1,6 
step
#hidewindow
#completewith Goat Fur
#loop
.goto 895,46.04,22.87,25,0
.goto 895,44.53,21.36,25,0
.goto 895,45.74,19.32,25,0
.goto 895,46.87,19.15,25,0
.goto 895,47.08,17.86,25,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goats|r
*|cRXP_WARN_Goats may become hostile|r.
.complete 49394,1 
.use 153596
.mob Gentle Goat
step
>>Kill |cRXP_ENEMY_Bears|r.
.complete 49395,2 
.mob Scruffhide Bear
step
#label Goat Fur
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goats|r
*|cRXP_WARN_Goats may become hostile|r.
.complete 49394,1 
.use 153596
.mob Gentle Goat
step
.goto 895,42.36,22.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tagart|r.
.turnin 51368 >>Turn in WANTED: The Hornet
.turnin 49394 >>Turn in Hold Still
.turnin 49395 >>Turn in The Bears and the Bees
.isQuestComplete 51368
.target Tagart
step
.goto 895,42.49,22.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rulf|r.
.accept 49735 >>Accept Protect the Nests
.accept 49710 >>Accept An Offering of Eggs
.target Rulf
step
#completewith Spotted Gryphon Egg
>>Kill |cRXP_ENEMY_Hungry Dewscales|r.
.complete 49735,1 
.mob Hungry Dewscale
step
.goto 895,44.06,19.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r
.complete 49710,1,1 
step
.goto 895,44.62,18.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r
.complete 49710,1,3 
step
#label Spotted Gryphon Egg
.goto 895,45.88,18.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r
.complete 49710,1.4 
step
#loop
.goto 895,46.48,18.37,20,0
.goto 895,46.15,17.22,20,0
.goto 895,44.04,17.67,20,0
.goto 895,44.46,20.31,20,0
>>Kill |cRXP_ENEMY_Hungry Dewscales|r.
.complete 49735,1 
.mob Hungry Dewscales
step
.goto 895,47.94,16.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gryphon Nest|r.
.turnin 49710 >>Turn in An Offering of Eggs
step
.goto 895,47.85,16.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shawn McClinter|r.
.turnin 49735 >>Turn in Protect the Nests
.accept 49417 >>Accept Roughneck Riders
.target Shawn McClinter
step
#completewith next
#label Greatfeather
>>|cRXP_WARN_Use [1],[2],[3] on cooldown|r.
.complete 49417,1 
.target Greatfeather
step
#completewith Greatfeather
#loop
.goto 895,48.03,17.47,25,0
.goto 895,48.51,18.8,25,0
.goto 895,47.27,19.16,25,0
.cast 256465 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Greatfeather|r
.use 153679
step
#requires Greatfeather
.goto 895,47.91,18.53
>>|cRXP_WARN_Use [1],[2],[3] on cooldown|r.
.complete 49417,1 
.use 153679
.target Greatfeather
step
#requires Roughneck Riders
.goto 895,42.36,22.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tagart|r.
.turnin 49417,1 >>Turn in Roughneck Riders
.accept 49418 >>Accept Big Boss
.target Tagart
step
.goto 895,41.99,16.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss Tak|r.
.turnin 49418 >>Turn in Big Boss
.accept 49433 >>Accept Wendies
.accept 49435 >>Accept Where'd They Go?
.target Boss Tak
step
#completewith Frozen
>>Kill |cRXP_ENEMY_Wendigos|r.
.complete 49433,1 
.mob Savage Wendigo
.mob Glacial Wendigo
step
.goto 895,42.27,15.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boot|r.
.complete 49435,1 
step
#label Frozen
.goto 895,43.68,15.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Helpless" Henry|r.
.accept 49419 >>Accept Frozen
.target "Helpless" Henry
step
.goto 895,44.91,15.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Griddon|r.
.accept 49431 >>Accept Warm and Cozy
.target Griddon
step
#completewith next
>>Kill |cRXP_ENEMY_Elementals|r
*Loot them for |T1020351:0|t[|cRXP_LOOT_Steamy Essence|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Shards|r
.complete 49431,1 
step
.goto 895,48.67,14.62
>>Kill |cRXP_ENEMY_Prince Rathaw|r
*Loot him for |T1020381:0|t[|cRXP_LOOT_Fiery Essence|r].
.complete 49419,1 
.mob Prince Rathaw
step
#loop
.goto 895,49.09,13.75,25,0
.goto 895,44.7,14.55,25,0
.goto 895,46.49,15,25,0
>>Kill |cRXP_ENEMY_Elementals|r
*Loot them for |T1020351:0|t[|cRXP_LOOT_Steamy Essence|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Shards|r
.complete 49431,1 
step
.goto 895,44.91,15.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Griddon|r.
.turnin 49431,1 >>Turn in Warm and Cozy
.target Griddon
step
.goto 895,43.68,15.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Helpless" Henry|r.
.turnin 49419 >>Turn in Frozen
.target "Helpless" Henry
step
#completewith Whompus
>>Kill |cRXP_ENEMY_Wendigos|r.
.complete 49433,1 
.mob Savage Wendigo
.mob Glacial Wendigo
step
.goto 895,43.73,14.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
.complete 49435,2 
step
.goto 895,41.58,13.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r.
.complete 49435,3 
step
.goto 895,39.68,13.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rucksack|r.
.complete 49435,4 
step
#loop
.goto 895,40.44,15.4,30,0
.goto 895,39.74,13.57,30,0
.goto 895,40.89,12.28,30,0
.goto 895,43.08,13.66,30,0
.goto 895,43.26,15.7,30,0
>>Kill |cRXP_ENEMY_Wendigos|r.
.complete 49433,1 
.mob Savage Wendigo
.mob Glacial Wendigo
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss Tak|r |cRXP_WARN_next to you|r.
.turnin 49433 >>Turn in Wendies
.turnin 49435 >>Turn in Where'd They Go?
.accept 49439 >>Accept Boss' Revenge
.target Boss Tak
step
#completewith next
#label Whompus
.goto 895,39.66,12.94,10,0
>>Kill |cRXP_ENEMY_Whompus|r
.complete 49439,1 
.mob Whompus
step
#completewith Whompus
.goto 895,39.33,12.37,35 >>Enter the Cave
step
#requires Whompus
#label Rucksack
.goto 895,39.33,12.37
>>Kill |cRXP_ENEMY_Whompus|r
.complete 49439,1 
.mob Whompus
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss Tak|r |cRXP_WARN_next to you|r.
.turnin 49433 >>Turn in Wendies
.turnin 49439 >>Turn in Boss' Revenge
.accept 49719 >>Accept Getting Paid
.target Boss Tak
step
.goto 895,42.37,22.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tagart|r.
.turnin 49719 >>Turn in Getting Paid
.target Tagart
step
.goto 895,42.28,29.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Therold|r.
.turnin 48347 >>Turn in Anglepoint Wharf
.accept 48540 >>Accept Aiding the Wharf
step
.goto 895,43.23,29.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bundle of Vellum|r on the barrel.
.complete 48540,2 
step
.goto 895,41.93,30.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hera Copeland|r.
.complete 48540,1 
.skipgossipid 47892
.target Hera Copeland
step
.goto 895,41.79,30.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jar|r.
.complete 48540,3 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Therold|r and |cRXP_FRIENDLY_Okri Putterwrench|r.
.turnin 48540 >>Turn in Aiding the Wharf
.accept 48352 >>Accept A Cure from the Sea
.accept 49268 >>Accept Sharks in the Water
.goto 895,42.28,29.31
.accept 48348 >>Accept Stinging Barbs
.goto 895,42.19,29.32
.target Brother Therold
.target Okri Putterwrench
step
#completewith Invading Dreadmaw
+Run on the Seafoor for increased movement speed.
step
#completewith Intact Venomous Barb
>>Kill |cRXP_ENEMY_Sharks|r.
.complete 49268,1 
.mob Invading Dreadmaw
step
#completewith Intact Venomous Barb
>>Kill |cRXP_ENEMY_Stingrays|r
*Loot them for |T132274:0|t[|cRXP_LOOT_Intact Venomous Barb|r].
.complete 48348,1 
.mob Barbtail Stingray
step
.goto 895,41.7,29.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,1 
step
.goto 895,41.47,28.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,2 
step
.goto 895,40.94,28.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,3 
step
.goto 895,40.11,28.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,4 
step
.goto 895,39.85,28.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,5 
step
.goto 895,39.76,30.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,6 
step
.goto 895,40.1,30.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,7 
step
#label Intact Venomous Barb
.goto 895,41.43,29.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seaweed|r on the seafloor.
.complete 48352,1,8 
.mob Invading Dreadmaw
.mob Barbtail Stingray
step
#hidewindow
#completewith Invading Dreadmaw
#loop
.goto 895,41.33,31.75,30,0
.goto 895,39.33,28.35,30,0
.goto 895,42.18,28.4,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Invading Dreadmaw|r.
.complete 49268,1 
.mob Invading Dreadmaw
step
>>Kill |cRXP_ENEMY_Stingrays|r
*Loot them for |T132274:0|t[|cRXP_LOOT_Intact Venomous Barb|r].
.complete 48348,1 
.mob Barbtail Stingray
step
#label Invading Dreadmaw
>>Kill |cRXP_ENEMY_Sharks|r.
.complete 49268,1 
.mob Invading Dreadmaw
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Okri Putterwrench|r and |cRXP_FRIENDLY_Brother Therold|r.
.turnin 48348 >>Turn in Stinging Barbs
.goto 895,42.19,29.32
.turnin 48352,2 >>Turn in A Cure from the Sea
.turnin 49268 >>Turn in Sharks in the Water
.accept 49292 >>Accept Algae Shakes
.accept 48353 >>Accept Pulse of the Wharf
.goto 895,42.28,29.31
.target Okri Putterwrench
.target Brother Therold
step
.goto 895,42.61,27.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Villager|r |cRXP_WARN_they spawn parasites; ignore if you can|r.
.complete 49292,1,1 
.use 153513
.target Nauseated Villager
step
.goto 895,42.30,26.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Julian Nichols|r.
.complete 48353,1 
.skipgossipid 47946
.target Julian Nichols
step
.goto 895,42.29,27.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poster|r
.accept 51384 >>Accept WANTED: Quartermaster Ssylis
step
.goto 895,42.24,27.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ginger Freelin|r.
.complete 48353,2 
.skipgossipid 47947
.target Ginger Freelin
step
.goto 895,42.1,27.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Villager|r |cRXP_WARN_they spawn parasites; ignore if you can|r.
.complete 49292,1,2 
.use 153513
.target Nauseated Villager
step
.goto 895,41.9,27.3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Villager|r |cRXP_WARN_they spawn parasites; ignore if you can|r.
.complete 49292,1,3 
.use 153513
.target Nauseated Villager
step
.goto 895,41.93,26.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Villager|r |cRXP_WARN_they spawn parasites; ignore if you can|r.
.complete 49292,1,4 
.use 153513
.target Nauseated Villager
step
.goto 895,41.87,26.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Villager|r |cRXP_WARN_they spawn parasites; ignore if you can|r.
.complete 49292,1,5 
.use 153513
.target Nauseated Villager
step
#completewith next
#label Aaron Gutier
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Villager|r |cRXP_WARN_they spawn parasites; ignore if you can|r.
.complete 49292,1,6 
.use 153513
.target Nauseated Villager
step
#completewith Aaron Gutier
.goto 895,41.68,26.98
.gossipoption 47948 >>Talk to |cRXP_FRIENDLY_Aaron Gutier|r.
.timer 9, RP
.target Aaron Gutier
step
#requires Aaron Gutier
.goto 895,41.53,26.5
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Villager|r |cRXP_WARN_they spawn parasites; ignore if you can|r.
.complete 49292,1,6 
.use 153513
.target Nauseated Villager
steps
.goto 895,41.64,26.96
>>Kill |cRXP_ENEMY_Aaron Gutier|r.
.complete 48353,3 
.mob Aaron Gutier
step
.goto 895,41.29,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Therold|r.
.turnin 49292 >>Turn in Algae Shakes
.turnin 48353 >>Turn in Pulse of the Wharf
.accept 48355 >>Accept Evacuate the Premises
.accept 48354 >>Accept Tainted Shipments
.target Brother Therold
step
.goto 895,40.73,26.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r |cRXP_WARN_they spawn parasites; kill them|r.
.complete 48354,1,1 
.mob Infesting Brainworm
step
.goto 895,40.73,26.93
>>Use the |cRXP_WARN_[Extra Action Button]|r.
.complete 48355,1,2 
.target Anglepoint Fishpackers
step
.goto 895,40.63,27.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r |cRXP_WARN_they spawn parasites; kill them|r.
.complete 48354,1,2 
.mob Infesting Brainworm
step
.goto 895,40.43,27.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r |cRXP_WARN_they spawn parasites; kill them|r.
.complete 48354,1,3 
.mob Infesting Brainworm
step
.goto 895,40.43,27.34
>>Use the |cRXP_WARN_[Extra Action Button]|r.
.complete 48355,1,4 
.target Anglepoint Fishpackers
step
.goto 895,39.94,27.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r |cRXP_WARN_they spawn parasites; kill them|r.
.complete 48354,1,4 
.mob Infesting Brainworm
step
.goto 895,40.01,26.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r |cRXP_WARN_they spawn parasites; kill them|r.
.complete 48354,1,5 
.mob Infesting Brainworm
step
.goto 895,40,26.98
>>Use the |cRXP_WARN_[Extra Action Button]|r.
.complete 48355,1,6 
.target Anglepoint Fishpackers
step
.goto 895,39.96,26.43
>>Use the |cRXP_WARN_[Extra Action Button]|r near |cRXP_FRIENDLY_Fishpacker|r |cRXP_WARN_they spawn parasites; kill them|r.
.complete 48355,1 
.target Anglepoint Fishpackers
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Therold|r and |cRXP_FRIENDLY_Keegan Alby|r.
.turnin 48354 >>Turn in Tainted Shipments
.turnin 48355 >>Turn in Evacuate the Premises
.accept 48356 >>Accept Possessive Headgear
.goto 895,39.49,26.68
.accept 48365 >>Accept The Young Lord Stormsong
.accept 48009 >>Accept Betrayal of the Guard
.goto 895,39.52,26.74
.target Keegan Alby
.target Brother Therold
step
#completewith Infested Cargo burned
>>Kill |cRXP_ENEMY_Mind-addled Enforcers|r and |cRXP_ENEMY_Possessed Dockworkers|r.
*|cRXP_WARN_Priotize |cRXP_ENEMY_Enforcers|r|r
.complete 48356,1 
.complete 48009,1 
.mob Possessed Dockworkers
.mob Mind-addled Enforcers
.mob Parasitic Mindstealer
step
#completewith next
#label Brother Conway
.goto 895,39.05,27.23,20,0
.goto 895,38.83,26.65,20,0
.goto 895,38.59,27.44,20,0
.goto 895,38.92,28,20,0
>>Kill |cRXP_ENEMY_Brother Conway|r.
.complete 48365,1 
.mob Brother Conway
step
#completewith Brother Conway
.goto 895,39.49,31.67,25 >>Enter the House
step
#requires Brother Conway
.goto 895,39.49,31.67
>>Kill |cRXP_ENEMY_Brother Conway|r.
.complete 48365,1 
.mob Brother Conway
step
.goto 895,37.57,29.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Manager Yerold|r.
.accept 48008 >>Accept Dangerous Cargo
.accept 49299 >>Accept Enemy Within
.target Manager Yerold
step
.goto 895,37.71,29.81,5,0
.goto 895,37.49,29.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r behind the wall.
.complete 48008,1,1 
step
.goto 895,37.27,29.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r.
.complete 48008,1,2 
step
.goto 895,37.25,28.83
>>Kill |cRXP_ENEMY_Overseer Bates|r.
*|cRXP_WARN_Avoid Frontal|r.
.complete 49299,1 
.mob Overseer Bates
step
.goto 895,37.27,28.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r.
.complete 48008,1,3
step
.goto 895,37.32,28.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r.
.complete 48008,1,4 
step
.goto 895,37.66,29.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrels|r.
.complete 48008,1,5 
step
#label Infested Cargo burned
.goto 895,37.97,29.48,5,0
.goto 895,37.57,29.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Manager Yerold|r.
.turnin 48008 >>Turn in Dangerous Cargo
.turnin 49299 >>Turn in Enemy Within
.target Manager Yerold
step
#loop
.goto 895,37.98,29.45,20,0
.goto 895,38.61,29.17,20,0
.goto 895,39.24,30,20,0
.goto 895,38.06,27.9,20,0
.goto 895,37.31,27.72,20,0
.goto 895,37.31,29.34,20,0
.goto 895,39.02,27.24,20,0
>>Kill |cRXP_ENEMY_Mind-addled Enforcers|r and |cRXP_ENEMY_Possessed Dockworkers|r.
*|cRXP_WARN_Priotize |cRXP_ENEMY_Enforcers|r|r
.complete 48356,1 
.complete 48009,1 
.mob Possessed Dockworkers
.mob Mind-addled Enforcers
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Therold|r and |cRXP_FRIENDLY_Keegan Alby|r.
.turnin 48356 >>Turn in Possessive Headgear
.goto 895,39.50,26.68
.turnin 48009 >>Turn in Betrayal of the Guard
.turnin 48365 >>Turn in The Young Lord Stormsong
.goto 895,39.52,26.74
.target Keegan Alby
.target Brother Therold
step
.goto 895,39.54,26.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brannon Stormsong|r.
.accept 48366 >>Accept Paddle to Safety
.target Brannon Stormsong
step
.goto 895,39.60,26.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Escape Rowboat|r.
.complete 48366,1 
.timer 40, Rowboat Time
step
.goto 895,35.20,24.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brannon Stormsong|r.
.turnin 48366 >>Turn in Paddle to Safety
.accept 48372 >>Accept Eldritch Invocations
.target Brannon Stormsong
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keegan Alby|r and |cRXP_FRIENDLY_Brother Therold|r.
.accept 48370 >>Accept Death in the Depths
.goto 895,35.25,24.17
.accept 48368 >>Accept Deep Sea Defilement
.goto 895,35.24,24.27
.target Keegan Alby
.target Brother Therold
step
.goto 895,34.95,24.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rosaline Madison|r.
.accept 48367 >>Accept Those Aren't Fish Eggs
.target Rosaline Madison
step
#completewith Director Deepwarden2
>>Kill |cRXP_ENEMY_Deepwarden Followers|r
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Eggs|r.
.complete 48367,1 
.complete 48370,1 
.mob Merciless Aberration
.mob K'thir Harbinger
.mob Willing Cultist
.mob Corrupted Egg
step
.goto 895,34.03,25.42,15,0
.goto 895,34.58,25,15,0
.goto 895,35.39,24.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r in the underwater cave.
.complete 48368,2 
step
#completewith next
#label Southern Corrupting Pylon
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r.
.complete 48368,1 
step
#completewith Southern Corrupting Pylon
.goto 895,30.37,31.11,130 >>Enter the Underwater Cave
step
#requires Southern Corrupting Pylon
.goto 895,30.37,31.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r.
.complete 48368,1 
step
#completewith next
#label Director Deepwarden
.goto 895,31.31,28.92,15,0
.goto 895,30.64,25.69,15,0
.goto 895,30.62,24.11,15,0
.goto 895,30.67,21.3,15,0
>>Kill |cRXP_ENEMY_Director Deepwarden|r.
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Pylon|r.
.complete 48368,3 
.complete 48372,1 
.mob Director Deepwarden
step
#completewith Director Deepwarden
.goto 895,30,19.36,120 >>Enter the Underwater Cave
step
#requires Director Deepwarden
#label Director Deepwarden2
.goto 895,30,19.36
>>Kill |cRXP_ENEMY_Director Deepwarden|r.
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Pylon|r.
.complete 48368,3 
.complete 48372,1 
.mob Director Deepwarden
step
#loop
.goto 895,30.92,21.6,30,0
.goto 895,31.6,21.92,30,0
.goto 895,31.86,22.66,30,0
.goto 895,32.02,21.83,30,0
.goto 895,32.87,22.02,30,0
.goto 895,32.6,23.45,30,0
.goto 895,34.07,27.14,30,0
.goto 895,31.9,29.09,30,0
>>Kill |cRXP_ENEMY_Deepwarden Followers|r
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Eggs|r.
.complete 48367,1 
.complete 48370,1 
.mob Merciless Aberration
.mob K'thir Harbinger
.mob Willing Cultist
.mob Corrupted Egg
step
.goto 895,30.42,17.96
>>Kill |cRXP_ENEMY_Quartermaster Ssylis|r
.complete 51384,1 
.mob Quartermaster Ssylis
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Therold|r, |cRXP_FRIENDLY_Brannon Stormsong|r and |cRXP_FRIENDLY_Rosaline Madison|r.
>>|cRXP_WARN_Press "Escape" on your keyboard to skip the cinematic|r.
.turnin 48368 >>Turn in Deep Sea Defilement
.goto 895,35.23,24.27
.turnin 48370 >>Turn in Death in the Depths
.turnin 48372 >>Turn in Eldritch Invocations
.goto 895,35.2,24.19
.turnin 48367 >>Turn in Those Aren't Fish Eggs
.goto 895,34.95,24.21
.target Brother Therold
.target Brannon Stormsong
.target Rosaline Madison
step
.goto 896,53.93,26.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaddeus "Gramps" Rifthold|r.
.accept 48793 >>Accept The Adventurer's Society
.accept 48792 >>Accept Menace to Society
step
#completewith Bonegnasher trogg
>>Kill |cRXP_ENEMY_Troggs|r
.complete 48792,1 
.mob Bonegnasher Earthcaller
.mob Bonegnasher Skullcrusher
step
.goto 896,53.37,25.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Backpack|r.
.complete 48793,1 
.skipgossipid 47798
.skipgossipid 48123
step
#completewith next
#label Guide to Archaeology
.goto 896,53.3,23.47,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 48793,2 
step
#completewith Guide to Archaeology
.goto 896,53.52,23.26,20 >>Enter the Cave
step
#requires Guide to Archaeology
.goto 896,53.52,23.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 48793,2 
step
#completewith next
#label Identify Relics
.goto 896,53.26,23.35,15,0
.goto 896,52.97,22.71,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 48793,3 
step
#completewith Identify Relics
.goto 896,53.05,22.44,20 >>Enter the Cave
step
#requires Identify Relics
.goto 896,53.05,22.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 48793,3 
step
.goto 896,51.81,24.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Journal|r.
.complete 48793,4 
step
.goto 896,51.37,23.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marcus Howlingdale|r.
.turnin 48793 >>Turn in The Adventurer's Society
.accept 48804 >>Accept Mistakes Were Made
step
.goto 896,51.82,22.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.accept 48805 >>Accept Research Recovery
step
.goto 896,51.59,21.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Disk|r.
.complete 48805,2 
step
#completewith next
#label Amelia Tidecrest
#hidewindow
.complete 48804,2 
.target Amelia Tidecrest
step
#completewith Amelia Tidecrest
.goto 896,51.67,21.48
.cast 252924 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Amelia Tidecrest|r.
step
#requires Amelia Tidecrest
.goto 896,52.67,20.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Jonathan|r.
.complete 48804,1 
.target Jonathan
step
.goto 896,50.76,20.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r.
.complete 48805,1 
step
.goto 896,50.64,22.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chase|r
.complete 48804,3 
.target Chase
step
#label Bonegnasher trogg
.goto 896,51.14,22.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_PICK_Shards|r.
.complete 48805,3 
step
#loop
.goto 896,51.68,24.28,30,0
.goto 896,52.89,23.39,30,0
.goto 896,51.11,21.35,30,0
>>Kill |cRXP_ENEMY_Troggs|r
.complete 48792,1 
.mob Bonegnasher Earthcaller
.mob Bonegnasher Skullcrusher
step
.goto 896,50.61,24.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marcus Howlingdale|r.
.turnin 48805 >>Turn in Research Recovery
.turnin 48804 >>Turn in Mistakes Were Made
.turnin 48792 >>Turn in Menace to Society
.accept 48853 >>Accept Terminal Degree
step
.goto 896,49.68,23.52
>>Kill |cRXP_ENEMY_Cragg|r.
.complete 48853,1 
step
.goto 896,49.41,23.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nigel Rifthold|r
.complete 48853,2 
.target Nigel Rifthold
step
.goto 896,50.59,24.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaddeus "Gramps" Rifthold|r.
.turnin 48853 >>Turn in Terminal Degree
step
.goto 896,63.25,27.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thomas Staughton|r.
.accept 47946 >>Accept Save Their Bacon
.accept 47947 >>Accept Big Bad Wolves
.accept 47948 >>Accept Pork Chop
step
#completewith Spellbound beasts
>>Kill |cRXP_ENEMY_Wolves|r.
.complete 47947,1 
.mob Hexed Howler
step
.goto 896,64.24,28.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pig|r.
.complete 47946,1 
.mob Trevor Hightide
step
.goto 896,64.70,30.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pig|r.
.complete 47946,3 
.mob Kyle Sailford
step
.goto 896,64.05,31.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pig|r.
.complete 47946,4 
.mob Burke Stevenson
step
.goto 896,63.61,30.41
>>Kill |cRXP_ENEMY_Roland Hacksaw|r.
.complete 47948,1 
.mob Roland Hacksaw
step
.goto 896,63.35,30.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pig Effigy|r
.accept 47949 >>Accept That's Not My Fetish
step
#label Spellbound beasts
.goto 896,63.62,29.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pig|r.
.complete 47946,2 
.mob Travis Daybreak
step
#loop
.goto 896,63.31,28.72,30,0
.goto 896,65.17,28.69,30,0
.goto 896,63.55,32.06,30,0
>>Kill |cRXP_ENEMY_Wolves|r.
.complete 47947,1 
.mob Hexed Howler
step
.goto 896,63.25,27.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thomas Staughton|r.
.turnin 47946 >>Turn in Save Their Bacon
.turnin 47947 >>Turn in Big Bad Wolves
.turnin 47948,1 >>Turn in Pork Chop
.turnin 47949 >>Turn in That's Not My Fetish
.accept 47950 >>Accept Cured Ham
step
.goto 896,63.29,27.02
>>Use |T135997:0|t[Pig Fetish] and throw it in the fire.
.complete 47950,1 
.use 153432
step
#label Cured Ham
.goto 896,63.25,27.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thomas Staughton|r.
.turnin 47950 >>Turn in Cured Ham
.target Thomas Staughton
step
.isOnQuest 40519
.subzone 10523 >>Use |T135975:0|t[Stormwind Portal Stone]
.cooldown item,132120,>0,1
.use 132120
step
.zoneskip 84
.zone 2352 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.goto 2352,57.43,26.65
.zone 84 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.zoneskip 2352,1
step
.pve
+You can enable War Mode to gain 10–30% bonus experience and additional PvP talents; however, this makes you hostile to the opposing faction and you’ll remain attackable at all times until War Mode is turned off in a rested area.
*To turn on Warmode press the macro in the "Active Items Frame"
.macro Enable Warmode,1965766 >>/run C_PvP.ToggleWarMode();
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Kunlai Summit 1 Midnight
#internal
step
.isOnQuest 40519
.subzone 10523 >>Use |T135975:0|t[Stormwind Portal Stone]
.cooldown item,132120,>0,1
.use 132120
step
.zoneskip 84
.zone 2352 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.goto 2352,57.43,26.65
.zone 84 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.zoneskip 2352,1
step
.pve
+You can enable War Mode to gain 10–30% bonus experience and additional PvP talents; however, this makes you hostile to the opposing faction and you’ll remain attackable at all times until War Mode is turned off in a rested area.
*To turn on Warmode press the macro in the "Active Items Frame"
.macro Enable Warmode,1965766 >>/run C_PvP.ToggleWarMode();
step
.isQuestAvailable 30460
.goto 84,45.7,87.16
.zone 379 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Jade Forest|r
step
#include RestedXP Speed Leveling\a) Defiance
step << Monk
#include RestedXP Speed Leveling\a) Monk Quests
step
.goto 379,71.57,92.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Cheng|r.
.accept 30460 >>Accept Hit Medicine
.target Apothecary Cheng
step
.goto 379,72.27,91.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Bramblestaff|r.
.accept 30457 >>Accept Call Out Their Leader
.target Mayor Bramblestaff
step
.goto 379,70.75,90.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Hsieh|r.
.accept 30459 >>Accept All of the Arrows
.target Commander Hsieh
step
#completewith Dit Da Jow
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
#completewith Dit Da Jow
>>Use |T132798:0|t[Dit Da Jow] on |cRXP_FRIENDLY_Injured Binan Warrior|r.
*|cRXP_WARN_Prioritize your own healing spells, if you have any|r.
.complete 30460,1 
.use 79819
.target Injured Binan Warrior
step
#loop
.goto 379,70.52,89.43,25,0
.goto 379,70.15,90.44,25,0
.goto 379,69.23,90.44,25,0
.goto 379,67.59,89.61,25,0
.goto 379,67.58,88,25,0
.goto 379,68.66,86.9,25,0
>>Kill |cRXP_ENEMY_Taurens|r
.complete 30457,1 
.mob Bataari Flamecaller
.mob Bataari Yaungol
step
#label Dit Da Jow
#loop
.goto 379,68.05,88.35,25,0
.goto 379,69.46,89.2,25,0
#title |cFFFCDC00NPC Patrols|r
>>Kill |cRXP_ENEMY_Bataari Fire-Warrior|r
.complete 30457,2 
step
#hidewindow
#completewith Commander Hsieh
#loop
.goto 379,67.44,87.67,30,0
.goto 379,70.72,89.26,30,0
.goto 379,69.94,91.13,30,0
.goto 379,67.66,91.12,30,0
.goto 379,66.61,89.04,30,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
>>Use |T132798:0|t[Dit Da Jow] on |cRXP_FRIENDLY_Injured Binan Warrior|r.
*|cRXP_WARN_Prioritize your own healing spells, if you have any|r.
.complete 30460,1 
.use 79819
.target Injured Binan Warrior
step
#label Commander Hsieh
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arrows|r.
.complete 30459,1 
step
.goto 379,70.76,90.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Hsieh|r.
.turnin 30459 >>Turn in All of the Arrows
.target Commander Hsieh
step
.goto 379,72.27,91.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayor Bramblestaff|r.
.turnin 30457 >>Turn in Call Out Their Leader
.target Mayor Bramblestaff
step
.goto 379,71.57,92.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Cheng|r.
.turnin 30460 >>Turn in Hit Medicine
.target Apothecary Cheng
.accept 30508 >>Accept Admiral Taylor has Awakened
step
.goto 379,71.43,93.17,5,0
.goto 379,71.64,93.24,5,0
.goto 379,71.53,93.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r |cRXP_WARN_inside the house upstairs|r.
.turnin 30508 >>Turn in Admiral Taylor has Awakened
.target Admiral Taylor
.accept 30512 >>Accept Westwind Rest
step
#include a) Kun-Lai Summit My Son
step
#include a) Kun-Lai Summit Despoiler
Step
.goto 379,58.87,80.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Bo|r.
.complete 30512,1 
.skipgossipid 41284
.target Farmhand Bo
step
.goto 379,56.34,84.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.complete 30512,2 
.skipgossipid 41467
.target Elder Tsulan
step
.goto 379,56.34,84.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.turnin 30512 >>Turn in Westwind Rest
.target Elder Tsulan
.accept 30514 >>Accept Challenge Accepted
step
#completewith next
#label Ur-Bataar
>>Kill the waves and |cRXP_ENEMY_Ur-Bataar|r.
.complete 30514,1 
.mob Ur-Bataar
step
#completewith Ur-Bataar
.goto 379,58.19,84.11
.cast 8386 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r
step
#requires Ur-Bataar
.goto 379,58.20,84.35
>>Kill the waves and |cRXP_ENEMY_Ur-Bataar|r.
.complete 30514,1 
.mob Ur-Bataar
step << Alliance
.goto 379,54.69,84.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r.
.turnin 30514 >>Turn in Challenge Accepted
.target Elder Tsulan
step << Alliance
.goto 379,53.77,82.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r.
.accept 30575 >>Accept Round 'Em Up
.target Admiral Taylor
step << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r and |cRXP_FRIENDLY_Elder Tsulan|r.
.accept 30583 >>Accept Blue Dwarf Needs Food Badly
.goto 379,54.15,83.30
.accept 30619 >>Accept Mogu?! Oh No-gu!
.goto 379,54.18,83.43
.target Elder Tsulan
.target Sully "The Pickle" McLeary
step << Alliance
.goto 379,53.78,84.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Bo|r.
.accept 30569 >>Accept Trouble on the Farmstead
.target Farmhand Bo
step << Alliance
#loop
.goto 379,53.45,83.36,10,0
.goto 379,53.46,83.08,10,0
.goto 379,53.68,83.28,10,0
.goto 379,53.45,83.36,0
.goto 379,53.46,83.08,0
.goto 379,53.68,83.28,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r.
.accept 30593 >>Accept Deanimate the Reanimated
.target Mishka
step
#completewith next
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
step
.goto 379,59.61,78.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bao Jian|r.
.accept 30595 >>Accept Profiting off of the Past
.target Bao Jian
step
#loop
.goto 379,58.84,76.29,40,0
.goto 379,57.77,76.89,40,0
.goto 379,56.62,76.53,40,0
.goto 379,56.88,75.53,40,0
.goto 379,57.96,74.50,40,0
.goto 379,59.28,73.51,40,0
.goto 379,59.98,75.57,20,0
.goto 379,58.84,76.29,0
.goto 379,57.77,76.89,0
.goto 379,56.62,76.53,0
.goto 379,56.88,75.53,0
.goto 379,57.96,74.50,0
.goto 379,59.28,73.51,0
.goto 379,59.98,75.57,0
>>Kill |cRXP_ENEMY_Mogu's|r.
*Loot them for |T454065:0|t[|cRXP_LOOT_Mogu Relic|r].
>>|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Relics|r
.complete 30593,1 
.complete 30595,1 
.mob Terracotta Guardian
.mob Terracotta Warrior
step
.goto 379,58.13,70.92
>>Kill |cRXP_ENEMY_Mogujia Soul-caller|r.
.complete 30619,1 
.mob Mogujia Soul-caller
step
.goto 379,59.60,78.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bao Jian|r.
.turnin 30595 >>Turn in Profiting off of the Past
.target Bao Jian
step
#completewith next
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmer Chow|r. and |cRXP_FRIENDLY_Uyen Chow|r.
.turnin 30569 >>Turn in Trouble on the Farmstead << Alliance
.accept 30571 >>Accept Farmhand Freedom
.goto 379,60.25,85.81
.accept 30581 >>Accept ... and the Pot, Too!
.goto 379,60.17,85.93
.target Uyen Chow
.target Farmer Chow
step
#completewith Farmstead Slaves
#hidewindow
#loop
.goto 379,60.88,86.97,40,0
.goto 379,61.29,86.14,40,0
.goto 379,61.92,87.15,40,0
.goto 379,61.87,87.85,40,0
.goto 379,61.31,87.85,40,0
.goto 379,61.41,88.37,40,0
.goto 379,60.79,88.00,40,0
.goto 379,60.50,87.52,40,0
.goto 379,58.87,88.61,40,0
.goto 379,58.38,88.40,40,0
.goto 379,58.31,89.41,40,0
.goto 379,58.33,90.11,40,0
.goto 379,58.85,90.11,40,0
.goto 379,58.95,89.78,40,0
.goto 379,60.88,86.97,0
.goto 379,61.29,86.14,0
.goto 379,61.92,87.15,0
.goto 379,61.87,87.85,0
.goto 379,61.31,87.85,0
.goto 379,61.41,88.37,0
.goto 379,60.79,88.00,0
.goto 379,60.50,87.52,0
.goto 379,58.87,88.61,0
.goto 379,58.38,88.40,0
.goto 379,58.31,89.41,0
.goto 379,58.33,90.11,0
.goto 379,58.85,90.11,0
.goto 379,58.95,89.78,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Ordo Overseers|r to rescue the |cRXP_FRIENDLY_Slaves|r.
.complete 30571,1 
.mob Ordo Raider
.mob Ordo Overseer
step
>>Kill |cRXP_ENEMY_Wascally Wirmen|r.
*Loot them for |T250625:0|t[|cRXP_LOOT_Root Vegetables|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Root Vegetables|r.
.complete 30581,1 
.mob Wascally Wirmen
step
#label Farmstead Slaves
>>Kill |cRXP_ENEMY_Ordo Overseers|r to rescue |cRXP_FRIENDLY_Farmstead Slaves|r.
.complete 30571,1 
.mob Ordo Raider
.mob Ordo Overseer
step
.goto 379,60.09,88.24,5,0
.goto 379,60.02,88.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Root Vegetable|r |cRXP_WARN_inside the small house|r.
.complete 30581,2 
.mob Cookie McYaungol
step
#label Back to Westwind Rest
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uyen Chow|r and |cRXP_FRIENDLY_Farmer Chow|r.
.turnin 30581 >>Turn in ... and the Pot, Too!
.goto 379,60.17,85.92
.turnin 30571 >>Turn in Farmhand Freedom
.accept 31252 >>Accept Back to Westwind Rest << Alliance
.goto 379,60.24,85.8
.target Uyen Chow
.target Farmer Chow
step
#loop
.goto 379,57.58,87.26,30,0
.goto 379,54.05,88.74,30,0
.goto 379,53.26,90.94,30,0
.goto 379,51.9,88.52,30,0
.goto 379,52.11,84.21,30,0
>>Kill |cRXP_ENEMY_Kun-lai Wildlife|r.
*Loot them for |T237346:0|t[|cRXP_LOOT_Kun-Lai Meaty Bits|r].
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on 3x |cRXP_PICK_Wild Plains Yak|r
.complete 30583,1 
.mob Highlands Calf
.mob Highlands Mushan
.mob Razorquill Porcupine
.mob Summit Bonestripper
.mob Wild Plains Yak
step
.goto 379,53.79,84.11
>>Make sure 3x |cRXP_FRIENDLY_Captured Yak|r are following you.
*|cRXP_WARN_If not click on 3x |cRXP_PICK_Wild Plains Yak|r|r
*Bring them to |cRXP_FRIENDLY_Farmhand Bo|r
.complete 30575,1 
.target Captured Yak
.target Farmhand Bo
step << Alliance
.goto 379,53.79,84.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farmhand Bo|r.
.turnin 31252 >>Turn in Back to Westwind Rest
.accept 31392 >>Accept Temple of the White Tiger
.target Farmhand Bo
step << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Tsulan|r and |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r.
.turnin 30619 >>Turn in Mogu?! Oh No-gu!
.accept 30650 >>Accept Pandaren Prisoners
.goto 379,54.17,83.43
.turnin 30583 >>Turn in Blue Dwarf Needs Food Badly
.accept 30651 >>Accept Barrels of Fun
.goto 379,54.17,83.28
.target Sully "The Pickle" McLeary
.target Elder Tsulan
step << Alliance
.goto 379,53.76,82.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r |cRXP_WARN_inside the tent|r.
.turnin 30575 >>Turn in Round 'Em Up
.accept 30652 >>Accept In Tents Channeling
.target Admiral Taylor
step << Alliance
#loop
.goto 379,53.45,83.36,10,0
.goto 379,53.46,83.08,10,0
.goto 379,53.68,83.28,10,0
#title |cFFFCDC00NPC Patrols|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r.
.turnin 30593 >>Turn in Deanimate the Reanimated
.target Mishka
step
#completewith Ordo Warbringer
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pandaren Prisoners|r.
.complete 30650,1 
.target Pandaren Prisoner
step
#completewith next
#label Eastern Oil Rig
#hidewindow
.complete 30651,1 
step
#completewith Eastern Oil Rig
.goto 379,51.25,79.27
.collect 80528,1,30651,1 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
step
#requires Eastern Oil Rig
#completewith next
#label Eastern Oil Rig2
#hidewindow
.complete 30651,1 
step
#requires Eastern Oil Rig
#completewith Eastern Oil Rig2
.goto 379,50.97,79.53
.cast 115550 >>Use |T252176:0|t[Explosives Barrel] next to the rig.
.use 80528
step
#requires Eastern Oil Rig2
#label Musaan
.goto 379,50.4,78.66
>>Kill |cRXP_ENEMY_Musaan the Blazecaster|r.
.complete 30652,1 
.mob musaan the blazecaster
step
.goto 379,49.44,78.49
>>Kill |cRXP_ENEMY_Harala the Firespeaker|r.
.complete 30652,3 
.mob harala the firespeaker
step
#completewith next
#label Southern Oil Rig
#hidewindow
.complete 30651,2 
step
#completewith Southern Oil Rig
.goto 379,49.57,78.96
.collect 80528,1,30651,2 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
step
#requires Southern Oil Rig
#completewith next
#label Southern Oil Rig2
#hidewindow
.complete 30651,2 
step
#requires Southern Oil Rig
#completewith Southern Oil Rig2
.goto 379,49.62,81.04
.cast 115550 >>Use |T252176:0|t[Explosives Barrel] next to the rig.
.use 80528
step
#requires Southern Oil Rig2
#completewith next
#label Pao-kun
>>Kill |cRXP_ENEMY_Pao-kun the Pyromancer|r.
.complete 30652,4 
.mob Pao-kun the Pyromancer
step
#requires Southern Oil Rig2
#completewith Pao-kun
.goto 379,49.35,81.07
.collect 80528,1,30651,3 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
step
#requires Pao-kun
.goto 379,49.17,80.38
>>Kill |cRXP_ENEMY_Pao-kun the Pyromancer|r.
.complete 30652,4 
.mob Pao-kun the Pyromancer
step
#requires Pao-kun
#completewith next
#label Western Oil Rig
#hidewindow
.complete 30651,3 
step
#completewith Western Oil Rig
.goto 379,47.86,81.42
.cast 115550 >>Use the |T252176:0|t[Explosives Barrel] next to the rig.
.use 80528
step
#requires Western Oil Rig
.goto 379,47.70,80.05
>>Kill |cRXP_ENEMY_Akonu the Embercaller|r.
.complete 30652,2 
.mob Akonu the Embercaller
step
.goto 379,48.9,76.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the questlog to turn in the quest.
.turnin 30652 >>Turn in In Tents Channeling
.accept 30660 >>Accept The Ordo Warbringer
step
#completewith next
#label Ordo Warbringer
.goto 379,48.9,76.89,10,0
>>Kill |cRXP_ENEMY_Ordo Warbringer|r.
.complete 30660,1 
.mob ordo warbringer
step
#title Enter Cave
#completewith Ordo Warbringer
.goto 379,48.37,76.70,25 >> Enter the cave.
step
#requires Ordo Warbringer
#label Ordo Warbringer2
.goto 379,48.37,76.70
>>Kill |cRXP_ENEMY_Ordo Warbringer|r.
.complete 30660,1 
.mob ordo warbringer
step
#loop
.goto 379,49.60,78.64,40,0
.goto 379,51.11,79.30,40,0
.goto 379,51.59,79.85,40,0
.goto 379,49.41,80.91,40,0
.goto 379,47.71,80.24,40,0
.goto 379,49.60,78.64,0
.goto 379,51.11,79.30,0
.goto 379,51.59,79.85,0
.goto 379,49.41,80.91,0
.goto 379,47.71,80.24,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pandaren Prisoners|r.
.complete 30650,1 
.target Pandaren Prisoner
step
#include a) Kun-Lai Summit Defense Shado-Pan
step << Alliance
#completewith next
#label Pandaren Prisoners
.goto 379,45.12,89.96,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r.
.turnin 30650 >>Turn in Pandaren Prisoners
.turnin 30660 >>Turn in The Ordo Warbringer
.target Admiral Taylor
step << Alliance
#completewith Pandaren Prisoners
.goto 379,53.99,83.2,625 >>Leave the Castle
step << Alliance
#requires Pandaren Prisoners
#title |cFFFCDC00NPC Patrols|r
.goto 379,53.99,83.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r.
.turnin 30650 >>Turn in Pandaren Prisoners
.turnin 30660 >>Turn in The Ordo Warbringer
.target Admiral Taylor
step << Alliance
.goto 379,54.17,83.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r.
.turnin 30651 >>Turn in Barrels of Fun
.target Sully "The Pickle" McLeary
step << Alliance
#loop
.goto 379,53.45,83.36,10,0
.goto 379,53.46,83.08,10,0
.goto 379,53.68,83.28,10,0
.goto 379,53.45,83.36,0
.goto 379,53.46,83.08,0
.goto 379,53.68,83.28,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r.
.accept 31460 >>Accept Cho's Missive
.target Mishka
step
.goto 379,44.48,89.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado-Master Chong|r.
.accept 30699 >>Accept To Winter's Blossom
.target Shado-Master Chong
step
.goto 379,65.48,60.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slimy Inkstain|r.
.turnin 30614 >>Turn in Oil Stop
.target Slimy Inkstain
step
.goto 379,64.71,61.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Eightcoins|r.
.turnin 30808 >>Turn in A Grummle's Luck
.target Lucky Eightcoins
step
.goto 379,64.89,60.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey Sootassle|r.
.turnin 30616 >>Turn in Traffic Issues
.accept 30617 >>Accept Roadside Assistance
.target Smokey Sootassle
step
#loop
.goto 379,64.11,59.07,20,0
.goto 379,62.91,62.03,20,0
.goto 379,62.85,63.05,20,0
.goto 379,62.79,63.80,20,0
.goto 379,62.95,64.57,20,0
.goto 379,62.44,64.45,20,0
.goto 379,62.04,64.90,20,0
.goto 379,61.73,65.37,20,0
.goto 379,61.18,65.59,20,0
.goto 379,60.37,66.00,20,0
.goto 379,59.96,65.27,20,0
.goto 379,59.33,65.10,20,0
.goto 379,58.91,64.33,20,0
.goto 379,59.00,63.81,20,0
.goto 379,58.73,63.09,20,0
.goto 379,58.81,62.48,20,0
.goto 379,58.34,62.13,20,0
.goto 379,58.35,61.63,20,0
.goto 379,62.91,62.03,0
.goto 379,62.85,63.05,0
.goto 379,62.79,63.80,0
.goto 379,62.95,64.57,0
.goto 379,62.44,64.45,0
.goto 379,62.04,64.90,0
.goto 379,61.73,65.37,0
.goto 379,61.18,65.59,0
.goto 379,60.37,66.00,0
.goto 379,59.96,65.27,0
.goto 379,59.33,65.10,0
.goto 379,58.91,64.33,0
.goto 379,59.00,63.81,0
.goto 379,58.73,63.09,0
.goto 379,58.81,62.48,0
.goto 379,58.34,62.13,0
.goto 379,58.35,61.63,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Lucky Burlap Incense|r |cRXP_WARN_(possible while mounted)|r.
.complete 30617,1 
step
.goto 379,58.1,61.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Trailscenter|r.
.turnin 30617 >>Turn in Roadside Assistance
.accept 30592 >>Accept The Burlap Trail: To Burlap Waystation
.target Brother Trailscenter
step
.goto 379,57.34,61.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.turnin 31460 >>Turn in Cho's Missive
.target Lorewalker Cho
.accept 30999 >>Accept Path Less Traveled
step
.goto 379,57.21,61.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Cloverleaf|r.
.turnin 30999 >>Turn in Path Less Traveled
.target Uncle Cloverleaf
.accept 30601 >>Accept Instant Courage
step
#completewith next
#label Resupplying One Keg
.goto 379,57.69,61.58,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.accept 30618 >>Accept Resupplying One Keg
.target Big Sal
step
#completewith Resupplying One Keg
.goto 379,57.72,61.77,10 >>Enter the House
step
#requires Resupplying One Keg
.goto 379,57.72,61.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.accept 30618 >>Accept Resupplying One Keg
.target Big Sal
step
#completewith next
#label They Stole My Luck!
.goto 379,57.5,60.17,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside the house|r.
.accept 30621 >>Accept They Stole My Luck!
.target Ji-Lu the Lucky
step
#completewith They Stole My Luck!
.goto 379,57.33,60.19,10 >>Enter the House
step
#requires They Stole My Luck!
.goto 379,57.33,60.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside the house|r.
.accept 30621 >>Accept They Stole My Luck!
.target Ji-Lu the Lucky
step
#hidewindow
#completewith next
#label Lucky Virmen's Foot
.goto 379,59.12,52.86,20,0
.complete 30621,1 
step
#completewith Lucky Virmen's Foot
.goto 380,65.55,83.73,40 >>Enter the Cave
step
#requires Lucky Virmen's Foot
#hidewindow
#completewith Snow Piles
#loop
.goto 380,65.55,83.73,20,0
.goto 380,70.76,69.22,25,0
.goto 380,57.68,74.3,25,0
.goto 380,51.64,72.75,25,0
.goto 380,46.08,57.42,25,0
.goto 380,54.25,54.77,25,0
.goto 380,44.57,24.37,25,0
.goto 380,34.92,27.67,25,0
.goto 380,30.96,39.6,25,0
.goto 380,41.6,43.88,25,0
.goto 380,32.49,41.53,20,0
.goto 380,34.39,34.35,20,0
.goto 380,49.4,30.45,20,0
+1
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>Kill each |cRXP_ENEMY_Sprite|r seperately as only 1 item can drop at a time.
*Loot them for |T237176:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#requires Lucky Virmen's Foot
#completewith Stolen Sprite Treasure
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guides|r.
.complete 30601,1 
.skipgossip
.target Hiding Guide
step
#requires Lucky Virmen's Foot
#label Stolen Sprite Treasure
.turnin 31415 >> |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Treasure|r.
step
#completewith Hiding Guide
>>Kill each |cRXP_ENEMY_Sprite|r seperately as only 1 item can drop at a time.
*Loot them for |T237176:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
#completewith Hiding Guide
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#label Hiding Guide
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guides|r.
.complete 30601,1 
.skipgossip
.target Hiding Guide
step
#completewith next
>>Kill |cRXP_ENEMY_Sprites|r.
*Loot them for |T651358:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supplies|r.
.complete 30618,1 
step
#label Snow Piles
>>Kill |cRXP_ENEMY_Sprites|r.
*Loot them for |T651358:0|t[|cRXP_LOOT_Belongings|r].
.complete 30621,4 
.complete 30621,1 
.complete 30621,2 
.complete 30621,3 
.mob Mischievous Snow Sprite
.mob Suspicious Snow Pile
step
.isQuestComplete 30621
.goto 379,59.14,53.15,25 >>Leave the Cave
step
#completewith next
#label TheyStoleMyLuck
.goto 379,57.5,60.17,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside small house|r.
.turnin 30621 >>Turn in They Stole My Luck!
.target Ji-Lu the Lucky
step
#completewith TheyStoleMyLuck
.goto 379,57.32,60.19,15 >>Enter the House
step
#requires TheyStoleMyLuck
#label They Stole My Luck!
.goto 379,57.32,60.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji-Lu the Lucky|r |cRXP_WARN_inside small house|r.
.turnin 30621 >>Turn in They Stole My Luck!
.target Ji-Lu the Lucky
step
.goto 379,57.72,61.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Sal|r.
.turnin 30618 >>Turn in Resupplying One Keg
.target Big Sal
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Kunlai Summit 2 Midnight
#internal
step
.goto 379,57.22,61.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Cloverleaf|r.
.turnin 30601 >>Turn in Instant Courage
.accept 30487 >>Accept Comin' Round the Mountain
.target Uncle Cloverleaf
step
.goto 379,57.30,61.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cart|r.
.complete 30487,1 
.timer 125,RP
.target Ji-Lu's Cart
step
.goto 379,48.13,48.92
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 30487,2 
.use 211279
.usespell 436523
.usespell 433397
step
.goto 379,48.13,49.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Bluestring|r.
.turnin 30487 >>Turn in Comin' Round the Mountain
.accept 30683 >>Accept One Traveler's Misfortune
.target Lucky Bluestring
step
.goto 379,50.07,49.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Abandoned Wreckage|r.
.complete 30683,1 
.timer 9,RP
step
.goto 379,50.07,49.37
>>Kill |cRXP_ENEMY_Stone Guardians|r then |cRXP_ENEMY_General Sho Lien|r.
.complete 30683,2 
.mob general sho lien
.mob Stone Guardian
step
.goto 379,48.14,49.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucky Bluestring|r.
.turnin 30683 >>Turn in One Traveler's Misfortune
.target Lucky Bluestring
.accept 30684 >>Accept Seeker's Folly
step
.goto 379,44.78,49.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine|r.
.complete 30684,1 
step
.goto 379,42.68,50.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine|r.
.complete 30684,2 
step
.goto 379,43.17,51.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine|r.
.complete 30684,3 
step
.goto 379,43.80,51.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.turnin 30684 >>Turn in Seeker's Folly
.accept 30829 >>Accept The Tongue of Ba-Shon
.target Lorewalker Cho
step
#completewith next
#label Reclaimer Zuan A
>>Kill |cRXP_ENEMY_Reclaimer Zuan|r.
.complete 30829,1 
.mob Reclaimer Zuan
.mob Yachi
step
#completewith Reclaimer Zuan A
.goto 379,43.79,51.07
.gossipoption 40517 >>Talk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.timer 20,RP
.target Lorewalker Cho
step
#requires Reclaimer Zuan A
.goto 379,43.46,51.42
>>Kill |cRXP_ENEMY_Reclaimer Zuan|r.
.complete 30829,1 
.skipgossipid 40517
.mob Reclaimer Zuan
.mob Yachi
step
.goto 379,43.77,51.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.turnin 30829 >>Turn in The Tongue of Ba-Shon
.accept 30795 >>Accept Staying Connected
.target Lorewalker Cho
step
.goto 379,57.11,47.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.accept 30797 >>Accept It Was Almost Alive
.target Curious Text
step
.goto 379,57.11,47.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Torn Page|r.
.complete 30797,1 
step
.goto 379,57.11,47.89
>>Use |T512479:0|t[The Tongue of Ba-Shon] near the book.
.complete 30795,1 
.use 81712
step
.goto 379,57.11,47.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30795 >>Turn in Staying Connected
.accept 30796 >>Accept An End to Everything
.turnin 30797 >>Turn in It Was Almost Alive
.accept 30799 >>Accept The Tomb of Shadows
.use 81712
.target Image of Lorewalker Cho
step
#loop
.goto 379,57.18,49.04,20,0
.goto 379,56.73,47.23,20,0
.goto 379,57.46,47.40,20,0
.goto 379,57.18,49.04,0
.goto 379,56.73,47.23,0
.goto 379,57.46,47.40,0
>>Kill |cRXP_ENEMY_Tormented Spirits|r.
.complete 30796,1 
.mob tormented spirits
step
#completewith next
#label Dynasty Rubbing
.goto 379,55.88,46.21,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r.
.complete 30799,3 
step
#title Enter Temple
#completewith Dynasty Rubbing
.goto 379,57.07,45.03,80 >>Enter the Temple
step
#requires Dynasty Rubbing
.goto 379,57.07,45.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r.
.complete 30799,3 
step
.goto 379,57.13,43.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r |cRXP_WARN_next to the statue|r.
.complete 30799,1 
step
.goto 379,56.36,43.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r |cRXP_WARN_under the pole|r.
.complete 30799,2 
step
#completewith next
#label An End to Everything
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30796 >>Turn in An End to Everything
.turnin 30799 >>Turn in The Tomb of Shadows
.accept 30798 >>Accept Breaking the Emperor's Shield
.disablecheckbox
.target Image of Lorewalker Cho
.use 81712
step
#completewith An End to Everything
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires An End to Everything
.goto 379,55.88,46.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30796 >>Turn in An End to Everything
.turnin 30799 >>Turn in The Tomb of Shadows
.accept 30798 >>Accept Breaking the Emperor's Shield
.target Image of Lorewalker Cho
.use 81712
step
#completewith next
#label Imperial Guards
.goto 379,56.47,44.51,15,0
.goto 379,55.85,46.29,10,0
.goto 379,53.33,49.35,10,0
>>Kill |cRXP_ENEMY_Imperial Guards|r and |cRXP_ENEMY_Nakk'rakas|r.
.complete 30798,1 
.mob Imperial Guard
.mob Nakk'rakas
step
#completewith Imperial Guards
.goto 379,52.93,51.34,80 >>Enter the Temple
step
#requires Imperial Guards
.goto 379,52.93,51.34
>>Kill |cRXP_ENEMY_Imperial Guards|r and |cRXP_ENEMY_Nakk'rakas|r.
.complete 30798,1 
.mob Imperial Guard
.mob Nakk'rakas
step
#completewith next
#label Their Thunder King
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30798 >>Turn in Breaking the Emperor's Shield
.accept 30800 >>Accept Stealing Their Thunder King
.target Image of Lorewalker Cho
step
#completewith Their Thunder King
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.use 81712
step
#requires Their Thunder King
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
*|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30798 >>Turn in Breaking the Emperor's Shield
.accept 30800 >>Accept Stealing Their Thunder King
.target Image of Lorewalker Cho
.use 81712
step
#completewith next
#label King's Coffer
.goto 379,53.35,49.21,10,0
.goto 379,53.06,46.52,15,0
.goto 385,83.74,64.02,10,0
.goto 385,80.6,75.25,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_King's Coffer|r.
.complete 30800,1 
step
#completewith King's Coffer
.goto 385,58.66,72.54,90 >>Enter the Temple
step
#requires King's Coffer
.goto 385,58.66,72.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_King's Coffer|r.
.complete 30800,1 
step
.goto 385,39.71,69.08,10,0
.goto 385,34.33,61.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Tablet|r on the wall.
.complete 30800,2 
.mob Terracotta Gladiator
step
#completewith next
#label Stealing Their Thunder King
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30800 >>Turn in Stealing Their Thunder King
.accept 30801 >>Accept Lessons from History
.target Image of Lorewalker Cho
.use 81712
step
#completewith Stealing Their Thunder King
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires Stealing Their Thunder King
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30800 >>Turn in Stealing Their Thunder King
.accept 30801 >>Accept Lessons from History
.target Image of Lorewalker Cho
.use 81712
step
.goto 385,34.33,61.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Tablet|r on the wall.
.complete 30801,1 
step
#completewith next
#label Chasing the Storm
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30801 >>Turn in Lessons from History
.accept 30802 >>Accept Chasing the Storm
.disablecheckbox
.target Image of Lorewalker Cho
.use 81712
step
#completewith Chasing the Storm
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires Chasing the Storm
.goto 385,33.44,62.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30801 >>Turn in Lessons from History
.accept 30802 >>Accept Chasing the Storm
.target Image of Lorewalker Cho
.use 81712
step
#loop
.goto 385,53.79,72.07,20,0
.goto 385,58.69,85.70,20,0
.goto 385,66.66,74.20,20,0
.goto 385,61.77,59.20,20,0
.goto 385,81.60,75.95,20,0
.goto 385,53.79,72.07,0
.goto 385,58.69,85.70,0
.goto 385,66.66,74.20,0
.goto 385,61.77,59.20,0
.goto 385,81.60,75.95,0
>>Kill |cRXP_ENEMY_Zandalari Warrior|r.
*Loot them for |T441148:0|t[|cRXP_LOOT_Blood-Revealed Map|r].
.complete 30802,1 
.mob Zandalari Warrior
step
#completewith next
#label Fisherman's Tale
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
>>|cRXP_WARN_Use|r |T512479:0|t[The Tongue of Ba-Shon] |cRXP_WARN_if you can't see |cRXP_FRIENDLY_Image of Lorewalker Cho|r|r.
.turnin 30802 >>Turn in Chasing the Storm
.accept 30935 >>Accept Fisherman's Tale
.disablecheckbox
.target Image of Lorewalker Cho
.use 81712
step
#completewith Fisherman's Tale
.cast 118927 >>Use |T512479:0|t[The Tongue of Ba-Shon] to summon an |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
step
#requires Fisherman's Tale
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lorewalker Cho|r.
.turnin 30802 >>Turn in Chasing the Storm
.accept 30935 >>Accept Fisherman's Tale
.target Image of Lorewalker Cho
.use 81712
step
#completewith next
#label Mishi1
#hidewindow
.goto 385,82.66,75.15,15,0
.goto 385,83.41,64.77,15,0
.complete 30935,1 
step
#completewith Mishi1
.goto 379,52.97,46.39,10 >>Leave the Temple
step
#requires Mishi1
#completewith next
#label Mishi2
*|cRXP_WARN_During Logout|r:
*|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishi|r.
.complete 30935,1 
.target Mishi
step
#requires Mishi1
#completewith Mishi2
.goto 379,52.97,46.39
.logout >>Use the Logout Macro in the "Active Items Frame" while in front of |cRXP_FRIENDLY_Mishi|r.
.macro Logout,638661 >>/logout
step
#requires Mishi2
.goto 379,52.97,46.39
*|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishi|r |cRXP_WARN_then cancel the logout|r.
.complete 30935,1 
.skipgossipid 30224
.target Mishi
step
#completewith next
#label SpeakShinWhispercloudProvince
*|cRXP_WARN_After the countdown|r:
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shin Whispercloud|r.
.complete 30935,2 
.target Shin Whispercloud
step
#completewith SpeakShinWhispercloudProvince
.goto 379,63.32,40.22
.logout >>Use the Logout Macro in the "Active Items Frame" while in front of |cRXP_FRIENDLY_Shin Whispercloud|r.
.macro Logout,638661 >>/logout
.timer 15,Countdown
step
#requires SpeakShinWhispercloudProvince
#completewith next
#label ZouchinProvince
#hidewindow
.complete 30935,2 
step
#requires SpeakShinWhispercloudProvince
#completewith ZouchinProvince
.countdown 15 >>|cRXP_WARN_Wait for the Countdown|r.
step
#requires ZouchinProvince
.goto 379,63.32,40.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shin Whispercloud|r.
.complete 30935,2 
.skipgossipid 30226
.target Shin Whispercloud
step
#requires SpeakShinWhispercloudZouchinProvince
.goto 379,62.32,29.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_inside the house|r.
.turnin 30935 >>Turn in Fisherman's Tale
.accept 30944 >>Accept It Takes A Village
.target Lorewalker Cho
step
#completewith next
#label What's Yours Is Mine
.goto 379,62.39,29.27,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelbender Doshu|r.
.accept 30945 >>Accept What's Yours Is Mine
.target Steelbender Doshu
step
#completewith What's Yours Is Mine
.goto 379,63.37,30.64,83 >>Leave the House
step
#requires What's Yours Is Mine
.goto 379,63.37,30.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelbender Doshu|r.
.accept 30945 >>Accept What's Yours Is Mine
.target Steelbender Doshu
step
.goto 379,63.74,30.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shomi|r |cRXP_WARN_under the house|r.
.accept 30942 >>Accept Make A Fighter Out of Me
.target Shomi
step
#completewith Amani Skirmishers
>>Kill |cRXP_ENEMY_Amani Skirmishers|r.
.complete 30942,1 
.mob Amani Skirmishers
step
#completewith Amani Skirmishers
#label ExhaustedDefenderRelieved
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exhausted Defenders|r.
.complete 30944,1 
.skipgossip
.target Exhausted Defender
step
#label Amani Skirmishers
#completewith ExhaustedDefenderRelieved
#hidewindow
.isNotOnQuest 30816
.isQuestNotComplete 30944
.goto 379,64.03,31.46,25,0
.goto 379,64.56,29.79,30,0
.goto 379,63.17,29.36,50 >> 1
step
#requires Amani Skirmishers
.goto 379,63.17,29.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Hai|r.
.accept 30816 >>Accept Checking In
.target Li Hai
step
#loop
.goto 379,63.33,28.75,10,0
.goto 379,63.58,28.73,10,0
.goto 379,63.23,28.65,10,0
.goto 379,63.47,28.81,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shu|r.
.accept 30943 >>Accept Handle With Care
.target Elder Shu
step
#completewith Exhausted Defender Relieved
#hidewindow
#loop
.goto 379,63.50,28.22,15,0
.goto 379,61.90,28.16,32,0
.goto 379,63.93,31.50,32,0
.goto 379,64.59,29.73,32,0
.goto 379,64.05,28.68,32,0
.goto 379,63.50,28.22,0
.goto 379,61.90,28.16,0
.goto 379,63.93,31.50,0
.goto 379,64.59,29.73,0
.goto 379,64.05,28.68,0
+1
step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exhausted Defenders|r.
.complete 30944,1 
.skipgossip
.target Exhausted Defender
step
>>Kill |cRXP_ENEMY_Amani Skirmishers|r.
.complete 30942,1 
.mob Amani Skirmishers
step
#label Exhausted Defender Relieved
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exhausted Defenders|r.
.complete 30944,1 
.skipgossip
.target Exhausted Defender
step
.goto 379,60.60,21.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Liao|r.
.turnin 30816 >>Turn in Checking In
.accept 30794 >>Accept Emergency Care
.target Sage Liao
step << Hunter/Rogue/Warlock/Warrior/DeathKnight/DemonHunter/Mage
#completewith next
#label HutSage
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Liao|r.
.complete 30794,1 
.timer 8,RP
.target Sage Liao
step << Hunter/Rogue/Warlock/Warrior/DeathKnight/DemonHunter/Mage
#completewith HutSage
.goto 379,61.01,21.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Treasure Chests|r inside the hut.
.collect 81177,1,30794,1
step << Hunter/Rogue/Warlock/Warrior/DeathKnight/DemonHunter/Mage
#requires HutSage
.goto 379,60.61,21.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Liao|r.
.complete 30794,1 
.timer 8,RP
.target Sage Liao
step << !Hunter/!Rogue/!Warlock/!Warrior/!DeathKnight/!DemonHunter/!Mage
.goto 379,60.61,21.35
>>Use a healing ability on |cRXP_FRIENDLY_Sage Liao|r.
.complete 30794,1 
.timer 8,RP
.target Sage Liao
step
.goto 379,60.61,21.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Liao|r.
.turnin 30794 >>Turn in Emergency Care
.target Sage Liao
step
.goto 379,60.61,21.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shu|r.

.accept 30805 >>Accept Justice
.accept 30806 >>Accept The Scent of Life
.accept 30807 >>Accept By the Falls, For the Fallen
.target Elder Shu
step
#completewith next
.goto 379,59.46,22.16,25,0
>>Kill |cRXP_ENEMY_Azure Prickly Crawler|r.
*Loot them for |T237176:0|t[|cRXP_LOOT_Opalescent Blue Crab Shell|r].
.complete 30806,1 
.mob Azure Prickly Crawler
step
#loop
.goto 379,59.03,27.23,30,0
.goto 379,59.72,29.83,30,0
.goto 379,60.19,31.25,30,0
.goto 379,58.89,24.56,30,0
.goto 379,59.03,27.23,0
.goto 379,59.72,29.83,0
.goto 379,60.19,31.25,0
.goto 379,58.89,24.56,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Waterfall-Polished Stone|r.
.complete 30807,1 
step
#completewith Captain Ripflesh
>>Kill |cRXP_ENEMY_Azure Prickly Crawler|r.
*Loot them for |T237176:0|t[|cRXP_LOOT_Opalescent Blue Crab Shell|r].
.complete 30806,1 
.mob Azure Prickly Crawler
step
#completewith Captain Ripflesh
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Barrels|r.
*Kill |cRXP_ENEMY_Blackmanes|r.
*Loot them for |T463533:0|t[|cRXP_LOOT_Spices|r].
.complete 30806,2 
.complete 30805,2 
.mob Blackmane Tracker
.mob Blackmane Brigand
.mob Blackmane Pillager
step
#label Captain Ripflesh
.goto 379,62.11,23.51
>>Kill |cRXP_ENEMY_Captain Ripflesh|r.
.complete 30805,1 
.mob Captain Ripflesh
step
#completewith Blackmane Mercenaries
#hidewindow
#loop
.goto 379,62.61,21.88,40,0
.goto 379,63.55,21.97,40,0
.goto 379,64.51,21.12,40,0
.goto 379,63.30,20.80,40,0
.goto 379,62.16,20.72,40,0
.goto 379,62.61,21.88,0
.goto 379,63.55,21.97,0
.goto 379,64.51,21.12,0
.goto 379,63.30,20.80,0
.goto 379,62.16,20.72,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Azure Prickly Crawler|r.
*Loot them for |T237176:0|t[|cRXP_LOOT_Opalescent Blue Crab Shell|r].
.complete 30806,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Barrels|r.
*Kill |cRXP_ENEMY_Blackmanes|r.
*Loot them for |T463533:0|t[|cRXP_LOOT_Spices|r].
.complete 30806,2 
.complete 30805,2 
.mob Blackmane Tracker
.mob Blackmane Brigand
.mob Blackmane Pillager
step
#label Blackmane Mercenaries
>>Kill |cRXP_ENEMY_Azure Prickly Crawler|r.
*Loot them for |T237176:0|t[|cRXP_LOOT_Opalescent Blue Crab Shell|r].
.complete 30806,1 
step
.goto 379,60.61,21.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Liao|r.
.turnin 30805 >>Turn in Justice
.turnin 30806 >>Turn in The Scent of Life
.turnin 30807 >>Turn in By the Falls, For the Fallen
.accept 30819 >>Accept Preparing the Remains
.target Sage Liao
step
#hidewindow
#completewith statue of xuen
.goto 379,70.6,26.34,30,0
.goto 379,71.6,27.36,30,0
.goto 379,72.19,29.33,30,0
.goto 379,72.87,30.8,30,0
.goto 379,72.24,33.02,30,0
.goto 379,72.02,33.97
+1
step
#completewith statue of xuen
>>Kill |cRXP_ENEMY_Gurubashi Hexxer|r, |cRXP_ENEMY_Drakkari Frostweavers|r and |cRXP_ENEMY_Amani Skirmishers|r.
.complete 30942,1 
.mob +Amani Skirmishers
.complete 30942,2 
.mob +Gurubashi Hexxer
.complete 30942,3 
.mob +Drakkari Frostweavers
step
#completewith statue of xuen
>>Kill |cRXP_ENEMY_Amani Skullbreaker|r.
*Loot them for |T132461:0|t[|cRXP_LOOT_Blood-Stained Blade|r].
.complete 30945,1 
.mob Amani Raptor-Handler
step
#completewith statue of xuen
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Volatile Blooms|r.
.complete 30943,1 
step
#completewith statue of xuen
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exhausted Defenders|r.
.complete 30944,1 
.skipgossip
.target Exhausted Defender
step
#label statue of xuen
.turnin 31416 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Statue of Xuen|r |cRXP_WARN_underwater|r.
step
#completewith Drakkari Frostweavers
#hidewindow
#loop
.goto 379,72.74,32.15,30,0
.goto 379,73.69,30.3,30,0
.goto 379,71.25,25.95,30,0
.goto 379,71.52,29.64,30,0
.goto 379,67.67,28.26,30,0
.goto 379,67.83,25.77,30,0
+1
step
#completewith Exhausted Defender
>>Kill |cRXP_ENEMY_Gurubashi Hexxer|r, |cRXP_ENEMY_Drakkari Frostweavers|r and |cRXP_ENEMY_Amani Skirmishers|r.
.complete 30942,1 
.mob +Amani Skirmishers
.complete 30942,2 
.mob +Gurubashi Hexxer
.complete 30942,3 
.mob +Drakkari Frostweavers
step
#completewith Exhausted Defender
>>Kill |cRXP_ENEMY_Amani Skullbreaker|r.
*Loot them for |T132461:0|t[|cRXP_LOOT_Blood-Stained Blade|r].
.complete 30945,1 
.mob Amani Raptor-Handler
step
#completewith Exhausted Defender
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Volatile Blooms|r.
.complete 30943,1 
step
#label Exhausted Defender
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exhausted Defenders|r.
.complete 30944,1 
.skipgossip
.target Exhausted Defender
step
#completewith Volatile Blooms
>>Kill |cRXP_ENEMY_Gurubashi Hexxer|r, |cRXP_ENEMY_Drakkari Frostweavers|r and |cRXP_ENEMY_Amani Skirmishers|r.
.complete 30942,1 
.mob +Amani Skirmishers
.complete 30942,2 
.mob +Gurubashi Hexxer
.complete 30942,3 
.mob +Drakkari Frostweavers
step
#completewith Volatile Blooms
>>Kill |cRXP_ENEMY_Amani Skullbreaker|r and |cRXP_ENEMY_Raptor-Handler|r. Loot them for |T132461:0|t[|cRXP_LOOT_Blood-Stained Blade|r].
.complete 30945,1 
.mob Amani Skullbreaker
.mob Amani Raptor-Handler
step
#label Volatile Blooms
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Volatile Blooms|r.
.complete 30943,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Gurubashi Hexxer|r, |cRXP_ENEMY_Drakkari Frostweavers|r and |cRXP_ENEMY_Amani Skirmishers|r.
.complete 30942,1 
.complete 30942,2 
.complete 30942,3 
.mob drakkari frostweaver
.mob gurubashi hexxer
.mob amani skirmisher
step
>>Kill |cRXP_ENEMY_Amani Skullbreaker|r.
*Loot them for |T132461:0|t[|cRXP_LOOT_Blood-Stained Blade|r].
.complete 30945,1 
.mob Amani Skullbreaker
.mob Amani Raptor-Handler
step
#label Drakkari Frostweavers
>>Kill |cRXP_ENEMY_Gurubashi Hexxer|r, |cRXP_ENEMY_Drakkari Frostweavers|r and |cRXP_ENEMY_Amani Skirmishers|r.
.complete 30942,1 
.complete 30942,2 
.complete 30942,3 
.mob drakkari frostweaver
.mob gurubashi hexxer
.mob amani skirmisher
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shomi|r |cRXP_WARN_next to you|r.
.turnin 30942 >>Turn in Make A Fighter Out of Me
.target Shomi
step
.goto 379,63.16,29.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Hai|r.
.turnin 30819 >>Turn in Preparing the Remains
.target Li Hai
.accept 30820 >>Accept A Funeral
step
#loop
.goto 379,63.33,28.75,10,0
.goto 379,63.58,28.73,10,0
.goto 379,63.23,28.65,10,0
.goto 379,63.47,28.81,10,0
.goto 379,63.33,28.75,0
.goto 379,63.58,28.73,0
.goto 379,63.23,28.65,0
.goto 379,63.47,28.81,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shu|r.
.turnin 30943 >>Turn in Handle With Care
.target Elder Shu
step
.goto 379,66.95,33.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
.complete 30820,1 
step
.goto 379,67.05,33.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Liao|r.
.turnin 30820 >>Turn in A Funeral
.target Sage Liao
step
#loop
.goto 379,63.4,30.86,5,0
.goto 379,63.33,30.76,5,0
.goto 379,63.37,30.64,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelbender Doshu|r.
.turnin 30945 >>Turn in What's Yours Is Mine
.target Steelbender Doshu
step
.goto 379,62.33,29.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_inside the house|r.
.turnin 30944 >>Turn in It Takes A Village
.accept 31011 >>Accept Enemies At Our Door
.target Lorewalker Cho
step
#completewith next
#label Amani Berserker
>>Kill |cRXP_ENEMY_Amani Berserker|r.
.complete 31011,1 
.mob amani berserker
step
#completewith Amani Berserker
.goto 379,62.41,29.32,10 >> Leave the House
step
#requires Amani Berserker
#completewith next
>>Kill |cRXP_ENEMY_Amani Berserker|r.
.complete 31011,1 
.mob amani berserker
step
#requires Amani Berserker
#loop
.goto 379,64.40,29.05,30,0
.goto 379,65.44,28.04,30,0
.goto 379,65.43,31.15,30,0
.goto 379,64.29,32.11,30,0
.goto 379,64.40,29.05,0
.goto 379,65.44,28.04,0
.goto 379,65.43,31.15,0
.goto 379,64.29,32.11,0
>>Kill |cRXP_ENEMY_Gurubashi Bloodrider|r as they run up to the barricades.
.complete 31011,3 
.mob gurubashi bloodrider
step
#completewith next
>>Kill |cRXP_ENEMY_Amani Berserker|r.
.complete 31011,1 
.mob amani berserker
step
.goto 379,61.19,29.13
>>Kill |cRXP_ENEMY_Amani Behemoth|r
*|cRXP_WARN_Use the barrels to kill them at the barricade|r.
.complete 31011,2 
.mob amani behemoth
step
#loop
.goto 379,62.83,30.34,30,0
.goto 379,63.8,29.38,30,0
.goto 379,63.35,27.56,30,0
.goto 379,62.06,28.49,30,0
>>Kill |cRXP_ENEMY_Amani Berserker|r.
.complete 31011,1 
.mob amani berserker
step
#completewith next
#label At Our Door
.goto 379,62.36,29.2,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_inside the house|r.
.turnin 31011 >>Turn in Enemies At Our Door
.accept 30946 >>Accept Revelations
.target Lorewalker Cho
step
#completewith At Our Door
.goto 379,62.33,29.06,10 >>Enter the House
step
#requires At Our Door
.goto 379,62.33,29.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_inside the house|r.
.turnin 31011 >>Turn in Enemies At Our Door
.accept 30946 >>Accept Revelations
.target Lorewalker Cho
step
.goto 379,62.59,28.90,5,0
.goto 379,62.46,29.05,5,0
.goto 379,62.48,28.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_ENEMY_Zandalari Prisoner|r |cRXP_WARN_upstairs|r.
.complete 30946,1 
.skipgossipid 40352
step
.goto 379,62.32,29.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
.turnin 30946 >>Turn in Revelations
.target Lorewalker Cho
step
#completewith next
#label EscortGrummlesA
>>|cRXP_WARN_Follow the Arrow,|r defend and escort the grummles.
.complete 30592,1 
.mob Knucklethump Snatcher
.mob Ookin Marauder
.mob Broketooth Spear-Haver
.target Trail Packer
step
#completewith EscortGrummlesA
.cooldown item,6948,>0,1
.goto 379,62.32,29.06
.hs >>Use your Hearthstone to One Keg
step
#requires EscortGrummlesA
.goto 379,58.71,64.77,20,0
.goto 379,58.29,64.78,20,0
.goto 379,49.74,67.57,20,0
.goto 379,53.08,66.58
>>|cRXP_WARN_Follow the Arrow,|r defend and escort the grummles.
.complete 30592,1 
.mob Knucklethump Snatcher
.mob Ookin Marauder
.mob Broketooth Spear-Haver
.target Trail Packer
step
.goto 379,51.67,67.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Trailscenter|r.
.turnin 30592 >>Turn in The Burlap Trail: To Burlap Waystation
.accept 30602 >>Accept The Rabbitsfoot
.target Brother Trailscenter
step
.goto 379,49.11,70.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brother Rabbitsfoot|r
.complete 30602,1 
.target Brother Rabbitsfoot
step
.goto 379,49.10,70.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.accept 30603 >>Accept The Broketooth Ravage
.target Brother Rabbitsfoot
step
.goto 379,48.08,73.11
>>Kill |cRXP_ENEMY_Mo Mo|r in the cave.
*Loot him for |T134323:0|t[|cRXP_LOOT_Rabbitsfoot's Luckydo|r].
.complete 30603,1 
.mob Mo Mo
step
.goto 379,47.88,73.52
.turnin 31868 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mo-Mo's Treasure Chest|r.
step
.goto 379,51.97,67.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30602 >>Turn in The Rabbitsfoot
.turnin 30603 >>Turn in The Broketooth Ravage
.accept 30599 >>Accept A Monkey Idol
.accept 30600 >>Accept No Pack Left Behind
.accept 30604 >>Accept Breaking Broketooth
.target Brother Rabbitsfoot
step
#completewith Turn in The Leader Hozen
+|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Luckydo's|r for a buff.
.target Luckydo
step
#completewith Dak Dak3
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob broketooth tosser
step
#completewith Dak Dak3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Packers|r
.complete 30600,1 
.target Dead Packer
step
#completewith next
#label Tak Tak
#hidewindow
.complete 30599,3 
step
#completewith Tak Tak
.goto 379,56.66,70.93
>>Kill |cRXP_ENEMY_Tak Tak|r
*Loot him for |T132159:0|t[|cRXP_LOOT_Corpse of Tak Tak|r].
.collect 80430,1,30599,3
step
#requires Tak Tak
#completewith next
#label Tak Tak2
#hidewindow
.complete 30599,3 
step
#requires Tak Tak
#completewith Tak Tak2
.goto 379,56.75,70.97
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Knife|r.
.mob Tak Tak
step
#requires Tak Tak2
#completewith next
#label Ko Ko
#hidewindow
.complete 30599,2 
step
#requires Tak Tak2
#completewith Ko Ko
.goto 379,52.47,71.37
>>Kill |cRXP_ENEMY_Ko Ko|r
*Loot him for |T132189:0|t[|cRXP_LOOT_Corpse of Ko Ko|r].
.collect 80429,1,30599,2
step
#requires Ko Ko
#completewith next
#label Ko Ko2
#hidewindow
.complete 30599,2 
step
#requires Ko Ko
#completewith Ko Ko2
.goto 379,52.27,71.44
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Knife|r.
.mob Ko Ko
step
#requires Ko Ko2
#completewith next
#label Dak Dak
#hidewindow
.complete 30599,1 
step
#requires Ko Ko2
#completewith Dak Dak
#title Enter Cave
.goto 379,52.83,71.41,10 >>Enter the Cave
step
#requires Dak Dak
#completewith next
#label Dak Dak2
#hidewindow
.complete 30599,1 
step
#requires Dak Dak
#completewith Dak Dak2
#loop
#title |cFFFCDC00NPC Patrols|r
.goto 383,54.79,28.62,15,0
.goto 383,35.05,55.28,15,0
.goto 383,41.74,71.35,15,0
.goto 383,58.75,59.33,15,0
.goto 384,50.33,36.53,15,0
>>Kill |cRXP_ENEMY_Dak Dak|r
*Loot him for |T458252:0|t[|cRXP_LOOT_Corpse of Dak Dak|r].
.collect 80428,1,30599,1
.mob Dak Dak
step
#requires Dak Dak2
#completewith next
#label Dak Dak3
#hidewindow
.complete 30599,1 
step
#requires Dak Dak2
#completewith Dak Dak3
.goto 384,49.84,39.7
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r.
.mob Dak Dak
step
#requires Dak Dak3
#hidewindow
#completewith Broketooths
#loop
.goto 384,40.96,49.75,25,0
.goto 383,55.48,64.39,25,0
.goto 383,60.41,42.46,25,0
.goto 379,52.89,71.24,25,0
.goto 379,51.92,70.29,25,0
.goto 379,53.58,69.53,25,0
.goto 379,56.09,70.71,25,0
.goto 379,52.92,71.22,25,0
+1
step
#requires Dak Dak3
#completewith next
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob Broketooth Tosser
step
#requires Dak Dak3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Packers|r
.complete 30600,1 
.target Dead Packer
step
#label Broketooths
>>Kill |cRXP_ENEMY_Broketooths|r.
.complete 30604,1 
.complete 30604,2 
.mob Broketooth Charger
.mob broketooth tosser
step
.goto 379,51.97,67.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30599 >>Turn in A Monkey Idol
.turnin 30600 >>Turn in No Pack Left Behind
.turnin 30604 >>Turn in Breaking Broketooth
.accept 30605 >>Accept Lucky Yakshoe
.target Brother Rabbitsfoot
step
#completewith next
#label RescueBrother
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 30605,1 
step
#completewith RescueBrother
.goto 379,50.53,64.2
.cast 115562 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mok Mok|r
.timer 10,RP
.mob Mok Mok
step
#requires RescueBrother
.goto 379,50.57,64.08
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 30605,1 
step
.goto 379,50.56,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Yakshoe|r.
.turnin 30605 >>Turn in Lucky Yakshoe
.accept 30606 >>Accept Thumping Knucklethump
.accept 30607 >>Accept Hozen Love Their Keys
.accept 30608 >>Accept The Snackrifice
.target Brother Yakshoe
step
#completewith Release Old Poot Poot
>>Kill |cRXP_ENEMY_Knucklethump Smasher|r and |cRXP_ENEMY_Knucklethump Jibstabber|r.
.complete 30606,1 
.mob Knucklethump Smasher
.mob Knucklethump Jibstabber
step
#loop
.goto 379,50.96,62.73,15,0
.goto 379,50.94,61.97,15,0
.goto 379,50.29,62.45,15,0
.goto 379,51.04,64.09,15,0
.goto 379,51.61,63.23,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Cages|r and destroy |cRXP_ENEMY_Ropes|r.
.complete 30608,1 
.target Imprisoned Grummle
.mob Prisoner Bindings
step
#completewith next
#label Yeti Shackle Key
.goto 382,75.83,91.72,10,0
>>Kill |cRXP_ENEMY_Cho Cho the Wicked|r.
*Loot him for |T134247:0|t[|cRXP_LOOT_Yeti Shackle Key|r].
.complete 30607,1 
.mob Cho Cho the Wicked
step
#completewith Yeti Shackle Key
.goto 382,42.73,26.19,110 >>Enter the Cave
step
#requires Yeti Shackle Key
.goto 382,76.35,77.58,10,0
.goto 382,74.8,58.31,10,0
.goto 382,48.4,70.72,10,0
.goto 382,36.22,52.47,10,0
.goto 382,32.32,30.96,10,0
.goto 382,36.14,13.76
>>Kill |cRXP_ENEMY_Cho Cho the Wicked|r.
*Loot him for |T134247:0|t[|cRXP_LOOT_Yeti Shackle Key|r].
.complete 30607,1 
.mob Cho Cho the Wicked
step
.goto 382,51.79,27.23
.turnin 31414 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hozen Treasure Cache|r.
step
#label Release Old Poot Poot
.goto 382,42.73,26.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Old Poot Poot|r.
.complete 30607,2 
.timer 25, Time until Cave Exit
.target Old Poot Poot
step
#completewith next
#label Love Their Keys
#hidewindow
.turnin 30607 >>Turn in Hozen Love Their Keys
step
#completewith Love Their Keys
.goto 379,50.99,63.14,10 >>Press the Macro to leave the vehicle |cRXP_WARN_when you're at the waypoint location|r.
*It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Love Their Keys
#loop
.goto 379,49.90,64.28,25,0
.goto 379,51.63,63.58,25,0
.goto 382,74.31,85.72,25,0
.goto 379,49.90,64.28,0
.goto 379,51.63,63.58,0
.goto 382,74.31,85.72,0
>>Kill |cRXP_ENEMY_Knucklethump Smasher|r and |cRXP_ENEMY_Knucklethump Jibstabber|r.
.complete 30606,1 
.mob Knucklethump Smasher
.mob Knucklethump Jibstabber
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#label Silverback Hozen
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r and |cRXP_FRIENDLY_Brother Yakshoe|r.
.turnin 30607 >>Turn in Hozen Love Their Keys
.turnin 30608 >>Turn in The Snackrifice
.accept 30610 >>Accept Grummle! Grummle! Grummle!
.goto 379,52.02,67.18
.turnin 30606 >>Turn in Thumping Knucklethump
.accept 30611 >>Accept Unleash The Yeti!
.goto 379,51.98,67.22
.target Brother Rabbitsfoot
.target Brother Yakshoe
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#completewith Cagemaster
#hidewindow
#loop
.goto 379,46.33,64.87,40,0
.goto 379,46.74,66.01,40,0
.goto 379,45.41,65.40,40,0
.goto 379,45.88,64.12,30,0
.goto 379,45.27,63.01,30,0
.goto 379,46.06,62.07,30,0
.goto 379,46.83,63.26,30,0
.goto 379,46.33,64.87,0
.goto 379,46.74,66.01,0
.goto 379,45.41,65.40,0
.goto 379,45.88,64.12,0
.goto 379,45.27,63.01,0
.goto 379,46.06,62.07,0
.goto 379,46.83,63.26,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Cagemasters|r.
.complete 30611,1 
.mob cagemaster
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Grummle Gear|r |cRXP_WARN_but ensure there's approximately a 2-second gap before clicking on the next one|r.
.complete 30610,1 
step
#label Cagemaster
>>Kill |cRXP_ENEMY_Cagemasters|r.
.complete 30611,1 
.mob cagemaster
step
#label Turn in Grummle! Grummle! Grummle!
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Yakshoe|r and |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30610 >>Turn in Grummle! Grummle! Grummle!
.turnin 30611 >>Turn in Unleash The Yeti!
.goto 379,45.95,64.06
.accept 30612 >>Accept The Leader Hozen
.goto 379,45.91,64.06
.timer 24,RP
.target Brother Yakshoe
.target Brother Rabbitsfoot
step
.goto 379,46.09,63.34
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 30612,1 
step
#loop
.goto 379,45.74,62.85,15,0
.goto 379,46.11,62.79,15,0
.goto 379,46.20,63.34,15,0
.goto 379,45.74,62.85,0
.goto 379,46.11,62.79,0
.goto 379,46.20,63.34,0
>>Kill |cRXP_ENEMY_The Ook of Dook|r.
.complete 30612,2 
.mob the ook of dook
step
#label Turn in The Leader Hozen
.goto 379,51.97,67.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Rabbitsfoot|r.
.turnin 30612 >>Turn in The Leader Hozen
.target Brother Rabbitsfoot
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uncle Keenbean|r and |cRXP_FRIENDLY_Cousin Gootfur|r.
.accept 30744 >>Accept Kota Blend
.accept 30745 >>Accept Trouble Brewing
.goto 379,42.42,69.66
.accept 30742 >>Accept Shut it Down
.accept 30743 >>Accept Gourmet Kafa
.goto 379,42.36,69.74
.target Uncle Keenbean
.target Cousin Gootfur
step
#hidewindow
#completewith Kafa-Crazed Yeti
#loop
.goto 379,40.52,71.32,15,0
.goto 379,38.55,72.66,15,0
.goto 379,37.88,74.9,15,0
.goto 379,40.45,72.64,15,0
.goto 379,40.85,73.33,15,0
.goto 379,40.23,75.24,15,0
.goto 379,39.41,77.1,15,0
.goto 379,39.35,74.9,15,0
.goto 379,39.19,74.56,15,0
.goto 379,39.19,74.16,15,0
.goto 379,38.46,74.39,15,0
.goto 379,37.87,73.91,15,0
.goto 379,38.54,74.4,15,0
.goto 379,38.11,72.48,15,0
.goto 379,38.69,74.22,15,0
.goto 379,39.26,74.38,15,0
.goto 379,39.42,75.46,15,0
.goto 379,39.03,76.65,15,0
.goto 379,38.44,78.28,15,0
.goto 379,37.78,80.29,15,0
.goto 379,36.72,79.3,15,0
.goto 379,36.77,77.87,15,0
.goto 379,39.46,72.72,15,0
+1
step
#completewith Kafa'kota Berry
>>Kill |cRXP_ENEMY_Kafa-Crazed Mountain Goats|r and |cRXP_ENEMY_Kafa-Crazed Yeti|r.
.complete 30742,1 
.complete 30745,1 
.mob Kafa-Crazed Yeti
.mob Kafa-Crazed Mountain Goat
step
#completewith Kafa'kota Berry
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Waste|r.
.complete 30743,1 
step
#label Kafa'kota Berry
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Berries|r
*Use |T133958:0|t[Kafa'kota Berries] to boost your stats|cRXP_WARN_(use in combat)|r.
.complete 30744,1 
.turnin 30744 >>Turn in Kota Blend
.accept 30746 >>Accept A Fair Trade
.use 81054
step
#completewith next
>>Kill |cRXP_ENEMY_Kafa-Crazed Mountain Goats|r and |cRXP_ENEMY_Kafa-Crazed Yeti|r.
.complete 30742,1 
.complete 30745,1 
.mob Kafa-Crazed Yeti
.mob Kafa-Crazed Mountain Goat
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Waste|r.
.complete 30743,1 
step
#label Kafa-Crazed Yeti
>>Kill |cRXP_ENEMY_Kafa-Crazed Mountain Goats|r and |cRXP_ENEMY_Kafa-Crazed Yeti|r.
.complete 30742,1 
.complete 30745,1 
.mob Kafa-Crazed Yeti
.mob Kafa-Crazed Mountain Goat
step
#label A Fair Trade
.goto 379,36.94,76.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nephew Burrberry|r |cRXP_WARN_outside the cave ontop of the mountain|r.
.turnin 30746 >>Turn in A Fair Trade
.target Nephew Burrberry
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cousin Gootfur|r and |cRXP_FRIENDLY_Uncle Keenbean|r.
.turnin 30742 >>Turn in Shut it Down
.turnin 30743 >>Turn in Gourmet Kafa
.goto 379,42.52,69.35
.turnin 30745 >>Turn in Trouble Brewing
.goto 379,42.53,69.44
.goto 379,42.52,69.35
.target Nephew Burrberry
.target Uncle Keenbean
.target Cousin Gootfur
step
.goto 379,34.96,59.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lin Silentstrike|r.
.turnin 30699 >>Turn in To Winter's Blossom
.target Lin Silentstrike
.accept 30723 >>Accept Honor, Even in Death
step
.goto 379,35.12,59.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.accept 30715 >>Accept A Line Unbroken
.target Ban Bearheart
step
#completewith Shiya Boldblade
>>Kill |cRXP_ENEMY_Kun-Lai Corpsepicker|r.
.complete 30723,1 
.mob kun-lai corpsepicker
step
.goto 379,29.98,64.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Shiya Boldblade|r.
.complete 30715,3 
.target Shiya Boldblade
step
.goto 379,30.16,62.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Liu of the Thousand Blows|r.
.complete 30715,2 
.target Liu of the Thousand
step
#label Shiya Boldblade
.goto 379,30.33,60.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shado-Master Zhiyao|r
.complete 30715,1 
.target Shado-Master Zhiyao
step
#loop
.goto 379,32.00,62.40,20,0
.goto 379,29.73,63.74,20,0
.goto 379,30.30,60.30,20,0
.goto 379,32.00,62.40,0
.goto 379,29.73,63.74,0
.goto 379,30.30,60.30,0
>>Kill |cRXP_ENEMY_Kun-Lai Corpsepicker|r.
.complete 30723,1 
.mob kun-lai corpsepicker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lin Silentstrike|r and |cRXP_FRIENDLY_Ban Bearheart|r.
.turnin 30715 >>Turn in A Line Unbroken
.goto 379,35.11,59.64
.target +Lin Silentstrike
.turnin 30723 >>Turn in Honor, Even in Death
.goto 379,34.95,59.30
.target +Ban Bearheart
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.accept 30724 >>Accept To the Wall!
.goto 379,34.95,59.30
.target Ban Bearheart
step
#completewith next
#label SpeakKiteMasterA
*|cRXP_WARN_During Logout|r:
*|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kite-Master Len|r.
.complete 30724,1 
.target Kite-Master Len
step
#completewith SpeakKiteMasterA
.goto 379,34.53,59.12
.logout >>Use the Logout Macro in the "Active Items Frame" while in front of |cRXP_FRIENDLY_Kite-Master Len|r.
.macro Logout,638661 >>/logout
step
.isOnQuest 30724
#requires SpeakKiteMasterA
.goto 379,34.53,59.12
*|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kite-Master Len|r |cRXP_WARN_then cancel the logout|r.
.complete 30724,1 
.skipgossipid 29681
.target Kite-Master Len
step
#completewith next
#label To the Wall!
.goto 379,29.4,62.43,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r.
.turnin 30724 >>Turn in To the Wall!
.target Lao-Chin the Iron Belly
step
#completewith To the Wall!
.goto 379,29.31,62.29,10 >>Enter the Building
step
#requires To the Wall!
.goto 379,29.31,62.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r.
.turnin 30724 >>Turn in To the Wall!
.target Lao-Chin the Iron Belly
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r and |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r.
.accept 30750 >>Accept Off the Wall!
.goto 379,29.31,62.29
.target +Lao-Chin the Iron Belly
.accept 30751 >>Accept A Terrible Sacrifice
.goto 379,29.25,62.3
.target +Suna Silentstrike
step
#completewith Osul Veteran Archers
#hidewindow
#loop
.goto 379,27.92,60.90,25,0
.goto 379,26.84,60.04,25,0
.goto 379,26.05,59.10,25,0
.goto 379,27.92,60.90,0
.goto 379,26.84,60.04,0
.goto 379,26.05,59.10,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Veteran Archer|r |cRXP_ENEMY_Fire-Warrior|r.
.complete 30750,1 
.mob Osul Veteran Archer
.mob Osul Fire-Warrior
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Barrel|r.
.complete 30751,1 
step
#label Osul Veteran Archers
>>Kill |cRXP_ENEMY_Veteran Archer|r |cRXP_ENEMY_Fire-Warrior|r.
.complete 30750,1 
.mob Osul Veteran Archer
.mob Osul Fire-Warrior
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r and |cRXP_FRIENDLY_Suna Silentstrike|r.
.turnin 30751 >>Turn in A Terrible Sacrifice
.goto 379,29.25,62.30
.target +Lao-Chin the Iron Belly
.turnin 30750 >>Turn in Off the Wall!
.goto 379,29.3,62.29
.target +Suna Silentstrike
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r.
.accept 30994 >>Accept Lao-Chin's Gambit
.goto 379,29.3,62.29
.target Suna Silentstrike
step
#completewith next
#label TalkSunaSilentstrikeA
*|cRXP_WARN_During Logout|r:
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r.
.complete 30994,1 
.target Suna Silentstrike
step
#completewith TalkSunaSilentstrikeA
.goto 379,29.31,62.29
.logout >>Use the Logout Macro in the "Active Items Frame" while in front of |cRXP_FRIENDLY_Suna Silentstrike|r.
.macro Logout,638661 >>/logout
step
#requires TalkSunaSilentstrikeA
.goto 379,29.31,62.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r.
.complete 30994,1 
.skipgossipid 30541
.target Suna Silentstrike
step
.goto 379,31.81,60.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r |cRXP_WARN_then cancel the logout|r.
.turnin 30994 >>Turn in Lao-Chin's Gambit
.target Lao-Chin the Iron Belly
step
.goto 379,31.81,60.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r.
.accept 30991 >>Accept Do a Barrel Roll!
.target Lao-Chin the Iron Belly
step
#completewith next
#label Osul Invader
>>Use |T135265:0|t[Ignite Keg](1) to destroy nearby |cRXP_ENEMY_Invaders|r and |cRXP_ENEMY_Osul Treelauncher|r |cRXP_WARN_do it multiple times|r.
.complete 30991,1 
.complete 30991,2 
.mob osul invader
.mob osul treelauncher
step
#completewith Osul Invader
.goto 379,32.08,60.52
.vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Keg Bomb|r.
.target Keg Bomb
step
#requires Osul Invader
#loop
.goto 379,30.90,62.46,20,0
.goto 379,30.90,63.36,20,0
.goto 379,30.09,63.92,20,0
.goto 379,29.94,62.80,20,0
.goto 379,30.90,62.46,0
.goto 379,30.90,63.36,0
.goto 379,30.09,63.92,0
.goto 379,29.94,62.80,0
>>Use |T135265:0|t[Ignite Keg](1) to destroy nearby |cRXP_ENEMY_Invaders|r and |cRXP_ENEMY_Osul Treelauncher|r |cRXP_WARN_do it multiple times|r.
.complete 30991,1 
.complete 30991,2 
.mob osul invader
.mob osul treelauncher
step
.goto 379,31.82,60.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r.
.turnin -30991 >>Turn in Do a Barrel Roll!
.target Lao-Chin the Iron Belly
step
.goto 379,31.82,60.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r.
.accept 30992 >>Accept Finish This!
.target Lao-Chin the Iron Belly
step
.goto 379,30.86,62.25
>>Kill |cRXP_ENEMY_Gong Da|r.
.complete 30992,1 
.mob Gong Da
step
.goto 379,31.28,61.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.turnin 30992 >>Turn in Finish This!
.target Ban Bearheart
step
.goto 379,31.28,61.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.accept 30993 >>Accept Where are My Reinforcements?
.target Ban Bearheart
step
.goto 379,31.3,61.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r.
.complete 30993,1 
.skipgossipid 29128
.target Ban Bearheart
step
.goto 379,31.28,61.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r.
.accept 30768 >>Accept My Husband...
.target Suna Silentstrike
step
#completewith next
#label Kite to the Wall
#hidewindow
.complete 30993,2 
.target Ban Bearheart
step
#completewith Kite to the Wall
.goto 379,34.53,59.12
.logout >>Use the Logout Macro in the "Active Items Frame" while in front of |cRXP_FRIENDLY_Ban Bearheart|r.
.macro Logout,638661 >>/logout
.timer 15,Countdown
step
#requires Kite to the Wall
#completewith next
#label Kite to the Wall2
*|cRXP_WARN_After the countdown|r:
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.complete 30993,2 
.target Ban Bearheart
step
#requires Kite to the Wall
#completewith Kite to the Wall2
.countdown 15 >>|cRXP_WARN_Wait for the Countdown|r.
step
#requires Kite to the Wall2
.goto 379,33.97,58.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.complete 30993,2 
.skipgossipid 29129
.target Ban Bearheart
step
.goto 379,35.32,49.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.turnin 30993 >>Turn in Where are My Reinforcements?
.target Ban Bearheart
step
#label Unbelievable!
.goto 379,35.32,49.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.accept 30752 >>Accept Unbelievable!
.target Ban Bearheart
step
#completewith next
#label Shado-Pan Sentinel
>>Kill |cRXP_ENEMY_Shado-Pan Sentinel|r.
.complete 30752,1 
.target Shado-Pan Sentinel
step
#completewith Shado-Pan Sentinel
.goto 379,36.7,47.72
.gossipoption 41432 >>Talk to |cRXP_FRIENDLY_Shado-Pan Sentinel|r.
.timer 10,RP
.target Shado-Pan Sentinel
step
#requires Shado-Pan Sentinel
.goto 379,36.7,47.72
>>Kill |cRXP_ENEMY_Shado-Pan Sentinel|r.
.complete 30752,1 
.target Shado-Pan Sentinel
step
.goto 379,36.70,47.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r |cRXP_WARN_next to you|r.
.turnin 30752 >>Turn in Unbelievable!
.target Ban Bearheart
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Townlong Steppes Midnight
#internal
step
.goto 388,71.15,56.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Suna Silentstrike|r.
.turnin 30768 >>Turn in My Husband...
.target Suna Silentstrike
step
.goto 388,71.16,56.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.accept 30814 >>Accept A Foot in the Door
.target Taran Zhu
step
#loop
.goto 388,70.33,54.19,30,0
.goto 388,70.06,53.00,30,0
.goto 388,71.12,52.16,30,0
.goto 388,71.47,53.14,30,0
.goto 388,70.33,54.19,0
.goto 388,70.06,53.00,0
.goto 388,71.12,52.16,0
.goto 388,71.47,53.14,0
>>Kill |cRXP_ENEMY_Osul Charger|r.
.complete 30814,1 
.mob osul charger
step
.goto 388,71.16,56.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.turnin 30814 >>Turn in A Foot in the Door
.accept 30769 >>Accept First Assault
.accept 30770 >>Accept Running Rampant
.accept 30771 >>Accept Perfect Pitch
.target Taran Zhu
step
#completewith Osul Sharphorn
#hidewindow
#loop
.goto 388,68.96,55.25,40,0
.goto 388,68.43,54.65,40,0
.goto 388,67.26,54.54,40,0
.goto 388,67.43,53.88,40,0
.goto 388,68.39,53.10,40,0
.goto 388,68.80,52.01,40,0
.goto 388,69.37,50.29,40,0
+1
step
#completewith Pots
>>Kill |cRXP_ENEMY_Osul Sharphorn|r.
.complete 30769,1 
.mob osul sharphorn
step
#completewith Pots
>>Interact with |cRXP_FRIENDLY_Long-Haired Yak|r and |cRXP_FRIENDLY_Steppebeast|r.
.complete 30770,1 
.target Long-Haired Yak
.target Steppebeast
step
#label Pots
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pots|r.
.complete 30771,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Osul Sharphorn|r.
.complete 30769,1 
.mob osul sharphorn
step
>>Interact with |cRXP_FRIENDLY_Long-Haired Yak|r and |cRXP_FRIENDLY_Steppebeast|r.
.complete 30770,1 
.target Long-Haired Yak
.target Steppebeast
step
#label Osul Sharphorn
.goto 388,68.96,55.25,0
.goto 388,68.43,54.65,0
.goto 388,67.26,54.54,0
.goto 388,67.43,53.88,0
.goto 388,68.39,53.10,0
.goto 388,68.80,52.01,0
.goto 388,69.37,50.29,0
>>Kill |cRXP_ENEMY_Osul Sharphorn|r.
.complete 30769,1 
.mob osul sharphorn
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r and |cRXP_FRIENDLY_Suna Silentstrike|r.
.turnin 30770 >>Turn in Running Rampant
.turnin 30771 >>Turn in Perfect Pitch
.accept 30773 >>Accept Pitching In
.goto 388,67.21,52.28
.target +Ban Bearheart
.turnin 30769 >>Turn in First Assault
.accept 30772 >>Accept Seeing Red
.accept 30774 >>Accept Ranger Rescue
.goto 388,67.25,52.22
.target +Suna Silentstrike
step
#completewith next
>>Kill |cRXP_ENEMY_Osul Marauder|r. Loot them for [|cRXP_LOOT_Stone Keys|r and use them to open nearby |cRXP_PICK_Cages|r].
.complete 30772,1 
.complete 30774,1 
.collect 81178,4,30774,0x2,-1
.disablecheckbox
.mob osul marauder
.target Longying Ranger
step
.goto 388,67.01,51.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Katak the Defeated|r.
.accept 30775 >>Accept The Exile
.target Katak the Defeated
step
#completewith Ku-Tong
>>Kill |cRXP_ENEMY_Osul Marauder|r |cRXP_ENEMY_Osul Spitfire|r. Loot them for [|cRXP_LOOT_Stone Keys|r and use them to open nearby |cRXP_PICK_Cages|r].
.complete 30772,1 
.complete 30774,1 
.collect 81178,4,30774,0x2,-1
.disablecheckbox
.mob osul marauder
.mob Osul Spitfire
.target Longying Ranger
step
#completewith Ku-Tong
>>Throw |T463515:0|t[Ban's Explosives] on |cRXP_WARN_Ballistas|r |cFFFF0000Don't throw it on the ones with the spinning pole|r.
.complete 30773,1 
.use 81193
step
.goto 388,66.97,47.93,10,0
.goto 388,66.96,48.25
#label Ku-Tong
>>Kill |cRXP_ENEMY_Ku-Tong|r |cRXP_WARN_inside the hut|r.
.complete 30775,3 
.mob ku-tong
step
#completewith Free Lin Silentstrike
>>Throw |T463515:0|t[Ban's Explosives] on |cRXP_WARN_Ballistas|r |cFFFF0000Don't throw it on the ones with the spinning pole|r.
.complete 30773,1 
.use 81193
step
#completewith Free Lin Silentstrike
>>Kill |cRXP_ENEMY_Osul Marauder|r |cRXP_ENEMY_Osul Spitfire|r. Loot them for [|cRXP_LOOT_Stone Keys|r and use them to open nearby |cRXP_PICK_Cages|r].
.complete 30772,1 
.complete 30774,2 
.collect 81178,4,30774,0x2,-1
.disablecheckbox
.mob osul marauder
.mob Osul Spitfire
.target Longying Ranger
step
.goto 388,66.58,49.16
#label Free Lin Silentstrike
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lin Silentstrike|r.
.complete 30774,3 
.skipgossip
.target Lin Silentstrike
step
#completewith Urang
>>Kill |cRXP_ENEMY_Osul Marauder|r |cRXP_ENEMY_Osul Spitfire|r. Loot them for [|cRXP_LOOT_Stone Keys|r and use them to open nearby |cRXP_PICK_Cages|r].
.complete 30772,1 
.collect 81178,4,30774,0x2,-1
.complete 30774,2 
.mob osul marauder
.mob Osul Spitfire
.target Longying Ranger
step
#completewith Urang
>>Throw |T463515:0|t[Ban's Explosives] on |cRXP_WARN_Ballistas|r |cFFFF0000Don't throw it on the ones with the spinning pole|r.
.complete 30773,1 
.use 81193
step
.goto 388,64.80,50.21
#label Urang
>>Kill |cRXP_ENEMY_Urang|r |cRXP_WARN_inside the hut|r.
.complete 30775,2 
.mob urang
step
#completewith Battat
>>Kill |cRXP_ENEMY_Osul Marauder|r |cRXP_ENEMY_Osul Spitfire|r. Loot them for [|cRXP_LOOT_Stone Keys|r and use them to open nearby |cRXP_PICK_Cages|r].
.complete 30772,1 
.collect 81178,4,30774,0x2,-1
.complete 30774,2 
.mob osul marauder
.mob Osul Spitfire
.target Longying Ranger
step
#completewith Battat
>>Throw |T463515:0|t[Ban's Explosives] on |cRXP_WARN_Ballistas|r. |cFFFF0000Don't throw it on the ones with the spinning pole|r.
.complete 30773,1 
.use 81193
step
.goto 388,65.75,51.4,10,0
.goto 388,65.72,51.64
#label Battat
>>Kill |cRXP_ENEMY_Battat|r |cRXP_WARN_inside the hut|r.
.complete 30775,1 
.mob battat
step
#completewith Osul Marauder
#hidewindow
#loop
.goto 388,66.14,52.44,40,0
.goto 388,67.49,50.99,40,0
.goto 388,68.05,49.37,40,0
.goto 388,67.27,46.01,40,0
.goto 388,67.43,44.31,40,0
.goto 388,67.10,43.57,40,0
.goto 388,66.34,45.13,40,0
.goto 388,66.25,46.27,40,0
.goto 388,64.89,50.58,40,0
.goto 388,66.14,52.44,0
.goto 388,67.49,50.99,0
.goto 388,68.05,49.37,0
.goto 388,67.27,46.01,0
.goto 388,67.43,44.31,0
.goto 388,67.10,43.57,0
.goto 388,66.34,45.13,0
.goto 388,66.25,46.27,0
.goto 388,64.89,50.58,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Osul Marauder|r |cRXP_ENEMY_Osul Spitfire|r. Loot them for [|cRXP_LOOT_Stone Keys|r and use them to open nearby |cRXP_PICK_Cages|r].
.complete 30772,1 
.collect 81178,4,30774,0x2,-1
.complete 30774,2 
.mob osul marauder
.mob Osul Spitfire
.target Longying Ranger
step
>>Throw |T463515:0|t[Ban's Explosives] on |cRXP_WARN_Ballistas|r. |cFFFF0000Don't throw it on the ones with the spinning pole|r.
.complete 30773,1 
.use 81193
step
#label Osul Marauder
>>Kill |cRXP_ENEMY_Osul Marauder|r |cRXP_ENEMY_Osul Spitfire|r. Loot them for [|cRXP_LOOT_Stone Keys|r and use them to open nearby |cRXP_PICK_Cages|r].
.complete 30772,1 
.collect 81178,4,30774,0x2,-1
.complete 30774,2 
.mob osul marauder
.mob Osul Spitfire
.target Longying Ranger
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r and |cRXP_FRIENDLY_Suna Silentstrike|r.
.turnin 30774 >>Turn in Ranger Rescue
.turnin 30772 >>Turn in Seeing Red
.turnin 30773 >>Turn in Pitching In
.goto 388,67.21,52.27
.accept 30776 >>Accept Jung Duk
.goto 388,67.26,52.22
.target Suna Silentstrike
.target Ban Bearheart
step
.goto 388,66.99,51.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Katak the Defeated|r.
.turnin 30775 >>Turn in The Exile
.target Katak the Defeated
step
.goto 388,66.66,51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ceremonial Pile|r and Kill |cRXP_ENEMY_Jung Duk|r.
.complete 30776,1 
.mob jung duk
step
.goto 388,71.02,56.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.turnin 30776 >>Turn in Jung Duk
.accept 30777 >>Accept In Search of Suna
.target Ban Bearheart
step
.goto 388,82.68,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r.
.turnin 30777 >>Turn in In Search of Suna
.accept 30778 >>Accept Dust to Dust
.accept 30779 >>Accept Slaying the Scavengers
.target Ban Bearheart
step
.goto 388,82.71,73.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xiao Tu|r.
.accept 30781 >>Accept Last Toll of the Yaungol
.target Xiao Tu
step
.goto 388,82.59,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yalia Sagewhisper|r.
.accept 30780 >>Accept Totemic Research
.target Yalia Sagewhisper
step
#completewith Western Smoke Trail
>>Kill |cRXP_ENEMY_Ashfang Hyena|r.
.complete 30779,1 
.mob ashfang hyena
step
#completewith Western Smoke Trail
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Palewind Totems|r.
.complete 30780,1 
step
#completewith Western Smoke Trail
>>Throw |T135432:0|t[Shado-Pan Torch] on |cRXP_ENEMY_Palewind Villagers|r.
.complete 30778,1 
.mob Palewind Villager
step
#label Western Smoke Trail
.goto 388,81.26,72.27
>>Go to the smoke trail but ensure |cRXP_FRIENDLY_Xiao Tu|r is following you.
*|cRXP_WARN_Wait for him at the smoke trail|r.
*|cFFFF0000In case you lose him, talk to him at his original location|r.
.complete 30781,2 
.timer 6,RP
.target Xiao Tu
step
#completewith Northwestern Smoke Trail
>>Kill |cRXP_ENEMY_Ashfang Hyena|r.
.complete 30779,1 
.mob ashfang hyena
step
#completewith Northwestern Smoke Trail
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Palewind Totems|r.
.complete 30780,1 
step
#completewith Northwestern Smoke Trail
>>Throw |T135432:0|t[Shado-Pan Torch] on |cRXP_ENEMY_Palewind Villagers|r.
.complete 30778,1 
.mob Palewind Villager
step
#label Northwestern Smoke Trail
.goto 388,84.12,70.62
>>Go to the smoke trail but ensure |cRXP_FRIENDLY_Xiao Tu|r is following you.
*|cRXP_WARN_Wait for him at the smoke trail|r.
*|cFFFF0000In case you lose him, talk to him at his original location|r.
.complete 30781,4 
.target Xiao Tu
step
#completewith Eastern Smoke Trail
>>Kill |cRXP_ENEMY_Ashfang Hyena|r.
.complete 30779,1 
.mob ashfang hyena
step
#completewith Eastern Smoke Trail
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Palewind Totems|r.
.complete 30780,1 
step
#completewith Eastern Smoke Trail
>>Throw |T135432:0|t[Shado-Pan Torch] on |cRXP_ENEMY_Palewind Villagers|r.
.complete 30778,1 
.mob Palewind Villager
step
#label Eastern Smoke Trail
.goto 388,84.86,71.55
>>Go to the smoke trail but ensure |cRXP_FRIENDLY_Xiao Tu|r is following you.
*|cRXP_WARN_Wait for him at the smoke trail|r.
*|cFFFF0000In case you lose him, talk to him at his original location|r.
.complete 30781,1 
.target Xiao Tu
step
#completewith Southern Smoke Trail
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Palewind Totems|r.
.complete 30780,1 
step
#completewith Southern Smoke Trail
>>Throw |T135432:0|t[Shado-Pan Torch] on |cRXP_ENEMY_Palewind Villagers|r.
.complete 30778,1 
.mob Palewind Villager
step
#label Southern Smoke Trail
.goto 388,83.49,78.51
>>Go to the smoke trail but ensure |cRXP_FRIENDLY_Xiao Tu|r is following you.
*|cFFFF0000In case you lose him, talk to him at his original location|r.
.complete 30781,3 
.target Xiao Tu
step
#completewith Ashfang Hyena
#hidewindow
#loop
.goto 388,83.02,79.57,40,0
.goto 388,83.00,77.23,40,0
.goto 388,82.62,74.11,40,0
.goto 388,80.27,71.93,40,0
.goto 388,82.65,70.41,40,0
.goto 388,83.02,79.57,0
.goto 388,83.00,77.23,0
.goto 388,82.62,74.11,0
.goto 388,80.27,71.93,0
.goto 388,82.65,70.41,0
+1
step
#completewith Palewind Villagers
>>Kill |cRXP_ENEMY_Ashfang Hyena|r.
.complete 30779,1 
.mob ashfang hyena
step
#completewith Palewind Villagers
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Palewind Totems|r.
.complete 30780,1 
step
#label Palewind Villagers
>>Throw |T135432:0|t[Shado-Pan Torch] on |cRXP_ENEMY_Palewind Villagers|r.
.complete 30778,1 
.mob Palewind Villager
step
#completewith next
>>Kill |cRXP_ENEMY_Ashfang Hyena|r.
.complete 30779,1 
.mob ashfang hyena
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Palewind Totems|r.
.complete 30780,1 
step
#label Ashfang Hyena
>>Kill |cRXP_ENEMY_Ashfang Hyena|r.
.complete 30779,1 
.mob ashfang hyena
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r and |cRXP_FRIENDLY_Yalia Sagewhisper|r.
.turnin 30778 >>Turn in Dust to Dust
.turnin 30779 >>Turn in Slaying the Scavengers
.turnin 30781 >>Turn in Last Toll of the Yaungol
.goto 388,82.68,73.03
.turnin 30780 >>Turn in Totemic Research
.accept 30827 >>Accept What Lies Beneath
.goto 388,82.6,73.03
.target Yalia Sagewhisper
.target Ban Bearheart
step
.goto 388,82.59,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yalia Sagewhisper|r.
.complete 30827,1 
.timer 18,RP
.skipgossip 60864,1
.target Yalia Sagewhisper
step
.goto 388,82.59,73.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Totem of Kindness|r.
.complete 30827,2 
step
.goto 388,82.69,73.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Totem of Serenity|r.
.complete 30827,4 
step
.goto 388,82.42,73.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Totem of Tranquility|r.
.complete 30827,3 
.timer 30,RP
step
.complete 30827,5 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yalia Sagewhisper|r and |cRXP_FRIENDLY_Ban Bearheart|r.
.turnin 30827 >>Turn in What Lies Beneath
.accept 30783 >>Accept Hatred Becomes Us
.goto 388,82.59,73.04
.accept 30782 >>Accept Spiteful Spirits
.goto 388,82.68,73.03
.target Ban Bearheart
step
#completewith Spiteful Spirit
#hidewindow
#loop
.goto 388,83.22,73.59,20,0
.goto 388,82.28,73.91,20,0
.goto 388,81.97,72.68,20,0
.goto 388,83.02,71.87,20,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Spiteful Spirit|r.
.complete 30782,1 
.mob spiteful spirit
step
>>Throw |T310733:0|t[Totem of Harmony] on |cRXP_FRIENDLY_Crazed Shado-Pan Rangers|r and kill |cRXP_ENEMY_Seething Hatred|r.
.complete 30783,1 
.use 81417
.mob Seething Hatred
step
#label Spiteful Spirit
>>Kill |cRXP_ENEMY_Spiteful Spirit|r.
.complete 30782,1 
.mob spiteful spirit
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yalia Sagewhisper|r and |cRXP_FRIENDLY_Ban Bearheart|r.
.turnin 30783 >>Turn in Hatred Becomes Us
.goto 388,82.6,73.03
.turnin 30782 >>Turn in Spiteful Spirits
.accept 30784 >>Accept The Point of No Return
.goto 388,82.67,73.03
.target Yalia Sagewhisper
.target Ban Bearheart
step
.goto 388,84.08,70.52
>>Kill |cRXP_ENEMY_Suna Silentstrike|r.
.complete 30784,1 
.mob Suna Silentstrike
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ban Bearheart|r and |cRXP_FRIENDLY_Yalia Sagewhisper|r.
.turnin 30784 >>Turn in The Point of No Return
.accept 30785 >>Accept Gao-Ran Battlefront
.goto 388,82.68,73.02
.goto 388,82.59,73.03
.target Yalia Sagewhisper
.target Ban Bearheart
step
.goto 388,76.41,82.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.turnin 30785 >>Turn in Gao-Ran Battlefront
.target Taran Zhu
.accept 30884 >>Accept Behind the Battlefront
step
.goto 388,75.86,83.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Septi the Herbalist|r.
.accept 30891 >>Accept Treatment for the Troops
.target Septi the Herbalist
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Violet Citron|r.
.complete 30891,1 
step
.goto 388,76.94,78.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r.
.turnin 30884 >>Turn in Behind the Battlefront
.target Taoshi
.accept 30887 >>Accept Unwelcome Intruders
step
#completewith Krik'thik Deep-Scout
#hidewindow
#loop
.goto 388,77.99,80.34,40,0
.goto 388,78.69,80.95,40,0
.goto 388,79.41,78.88,40,0
.goto 388,79.84,76.93,40,0
.goto 388,78.77,75.90,40,0
.goto 388,78.41,75.15,40,0
.goto 388,76.48,76.91,40,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Krik'thik Deep-Scout|r.
.complete 30887,1 
.mob krik'thik deep-scout
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Violet Citron|r.
.complete 30891,1 
step
#label Krik'thik Deep-Scout
.goto 388,77.99,80.34,0
.goto 388,78.69,80.95,0
.goto 388,79.41,78.88,0
.goto 388,79.84,76.93,0
.goto 388,78.77,75.90,0
.goto 388,78.41,75.15,0
.goto 388,76.48,76.91,0
>>Kill |cRXP_ENEMY_Krik'thik Deep-Scout|r.
.complete 30887,1 
.mob krik'thik deep-scout
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r and |cRXP_FRIENDLY_Mao the Lookout|r.
.turnin 30887 >>Turn in Unwelcome Intruders
.accept 30888 >>Accept Breach in the Defenses
.accept 30890 >>Accept The Restless Watch
.goto 388,79.47,84.47
.accept 30889 >>Accept Trap Setting
.goto 388,79.38,84.45
.target Mao the Lookout
.target Taoshi
step
#completewith Scout Jai-gan
*Use |T135815:0|t[Shado-Pan Flare] near moving red dust to make |cRXP_ENEMY_Krik'thik Scentlayer|r visible.
>>Kill |cRXP_ENEMY_Krik'thik Scentlayer|r.
.complete 30888,1 
.mob krik'thik scentlayer
.use 81925
step
#completewith Scout Jai-gan
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Shado-Pan Spike Traps|r.
.complete 30889,1 
step
.isOnQuest 30890
.goto 388,82.21,84.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Wei-chin|r.
.complete 30890,1 
.skipgossip
.target Scout Wei-chin
step
.isOnQuest 30890
.goto 388,81.30,86.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Long|r.
.complete 30890,2 
.skipgossip
.target Scout Long
step
.isOnQuest 30890
.goto 388,82.52,89.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Ying|r.
.complete 30890,3 
.skipgossip
.target Scout Ying
step
#label Scout Jai-gan
.goto 388,79.02,90.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Jai-gan|r.
.complete 30890,4 
.skipgossip
.target Scout Jai-gan
step
#completewith Krik'thik Scentlayer
#hidewindow
#loop
.goto 388,80.71,87.11,40,0
.goto 388,81.30,83.97,40,0
.goto 388,81.34,82.25,40,0
.goto 388,81.98,84.61,40,0
.goto 388,81.87,88.40,40,0
.goto 388,81.11,90.75,40,0
.goto 388,80.71,87.11,0
.goto 388,81.30,83.97,0
.goto 388,81.34,82.25,0
.goto 388,81.98,84.61,0
.goto 388,81.87,88.40,0
.goto 388,81.11,90.75,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Krik'thik Scentlayer|r.
*Use |T135815:0|t[Shado-Pan Flare] near moving red dust to make |cRXP_ENEMY_Krik'thik Scentlayer|r visible.
.complete 30888,1 
.mob krik'thik scentlayer
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Shado-Pan Spike Traps|r.
.complete 30889,1 
.use 81925
step
#label Krik'thik Scentlayer
>>Kill |cRXP_ENEMY_Krik'thik Scentlayer|r.
*Use |T135815:0|t[Shado-Pan Flare] near moving red dust to make |cRXP_ENEMY_Krik'thik Scentlayer|r visible.
.complete 30888,1 
.mob krik'thik scentlayer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r and |cRXP_FRIENDLY_Mao the Lookout|r.
.turnin 30888 >>Turn in Breach in the Defenses
.turnin 30890 >>Turn in The Restless Watch
.accept 30960 >>Accept Returning from the Pass
.goto 388,79.46,84.47
.turnin 30889 >>Turn in Trap Setting
.goto 388,79.39,84.46
.target Mao the Lookout
.target Taoshi
step
.goto 388,76.41,82.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.turnin 30960 >>Turn in Returning from the Pass
.accept 30893 >>Accept The Endless Swarm
.target Taran Zhu
step
.goto 388,75.86,83.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Septi the Herbalist|r.
.turnin 30891 >>Turn in Treatment for the Troops
.target Septi the Herbalist
step
#xprate <2.4
.goto 388,75.86,83.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Septi the Herbalist|r.
.accept 30892 >>Accept Back on Their Feet
.accept 30894 >>Accept Rummaging Through the Remains
.target Septi the Herbalist
step
#completewith Krik'thik Limbpincer
#hidewindow
#loop
.goto 388,73.68,86.64,40,0
.goto 388,73.53,88.82,40,0
.goto 388,74.50,90.48,40,0
.goto 388,75.25,89.01,40,0
.goto 388,74.78,87.34,40,0
.goto 388,74.72,85.84,40,0
.goto 388,73.68,86.64,0
.goto 388,73.53,88.82,0
.goto 388,74.50,90.48,0
.goto 388,75.25,89.01,0
.goto 388,74.78,87.34,0
.goto 388,74.72,85.84,0
+1
step
.isOnQuest 30893,30894
#completewith next
>>Kill |cRXP_ENEMY_Krik'thik Limbpincer|r and |cRXP_ENEMY_Krik'thik Locust-Guard|r and |TInterface/cursor/crosshair/interact.blp:20|tClick on their |cRXP_PICK_Krik'thik Limbs|r.
.complete 30893,1 
.complete 30894,1 
.mob Krik'thik Limbpincer
.mob Krik'thik Locust-Guard
step
.isOnQuest 30892
>>Use |T237266:0|t[Citron-Infused Bandages] on |cRXP_FRIENDLY_Injured Gao-ran Blackguards|r.
*|cRXP_WARN_Prioritize your own healing spells, if you have any|r.
.complete 30892,1 
.use 82787
.target Injured Gao-ran Blackguards
step
.isOnQuest 30893,30894
#label Krik'thik Limbpincer
>>Kill |cRXP_ENEMY_Krik'thik Limbpincer|r and |cRXP_ENEMY_Krik'thik Locust-Guard|r and |TInterface/cursor/crosshair/interact.blp:20|tClick on their |cRXP_PICK_Krik'thik Limbs|r.
.complete 30893,1 
.complete 30894,1 
.mob Krik'thik Limbpincer
.mob Krik'thik Locust-Guard
step
.goto 388,75.86,83.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Septi the Herbalist|r.
.turnin -30892 >>Turn in Back on Their Feet
.turnin -30894 >>Turn in Rummaging Through the Remains
.target Septi the Herbalist
step
.goto 388,76.42,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.turnin -30893 >>Turn in The Endless Swarm
.target Taran Zhu
step
#xprate <2.4
.isQuestTurnedIn 30893
.goto 388,76.42,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.accept 30895 >>Accept Improvised Ammunition
.target Taran Zhu
step
#xprate <2.4
.isQuestTurnedIn 30893
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Feng|r and |cRXP_FRIENDLY_Initiate Chao|r.
.accept 30896 >>Accept Thieves and Troublemakers
.goto 388,70.46,86.37
.accept 30897 >>Accept In the Wrong Hands
.goto 388,70.33,86.67
.target Initiate Feng
.target Initiate Chao
step
#completewith next
.isOnQuest 30896,30895
>>Kill |cRXP_ENEMY_Agitated Nettleskins|r and |cRXP_ENEMY_Agitated Seedstealer|r. Loot them for [|cRXP_LOOT_Volatile Dread Orbs|r].
.complete 30896,1 
.complete 30895,1 
.mob Agitated Nettleskin
.mob Agitated Seedstealer
step
.isOnQuest 30897
.goto 388,63.07,87.65
>>Kill |cRXP_ENEMY_Needlebottom|r. Loot them for [|cRXP_LOOT_Chao's Sword|r].
.complete 30897,1 
.mob Needlebottom
step
.isOnQuest 30896,30895
#loop
.goto 388,65.27,87.95,40,0
.goto 388,67.00,87.12,40,0
.goto 388,68.90,89.21,40,0
.goto 388,68.65,85.72,40,0
.goto 388,69.97,84.44,40,0
.goto 388,65.27,87.95,0
.goto 388,67.00,87.12,0
.goto 388,68.90,89.21,0
.goto 388,68.65,85.72,0
.goto 388,69.97,84.44,0
>>Kill |cRXP_ENEMY_Agitated Nettleskins|r and |cRXP_ENEMY_Agitated Seedstealer|r. Loot them for [|cRXP_LOOT_Volatile Dread Orbs|r. |cRXP_WARN_Additionally |TInterface/cursor/crosshair/interact.blp:20|tClick on them|r].
.complete 30896,1 
.complete 30895,1 
.mob Agitated Nettleskin
.mob Agitated Seedstealer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Feng|r and |cRXP_FRIENDLY_Initiate Chao|r.
.turnin -30897 >>Turn in In the Wrong Hands
.goto 388,70.34,86.67
.turnin -30896 >>Turn in Thieves and Troublemakers
.goto 388,70.46,86.38
.target Initiate Chao
.target Initiate Feng
step
.goto 388,76.41,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.turnin -30895 >>Turn in Improvised Ammunition
.target Taran Zhu
step
#xprate <2.4
.isQuestTurnedIn 30895
.goto 388,76.41,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.accept 30898 >>Accept Cutting the Swarm
.target Taran Zhu
step
.goto 388,74.8,84.72
.isOnQuest 30898
.vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Dragon Launcher|r.
.target Dragon Launcher
step
.isOnQuest 30898
>>Use |T135597:0|t[Dragon Cannon] to kill incoming |cRXP_ENEMY_Krik'thik Drones|r.
.complete 30898,1 
.mob krik'thik drone
step
.goto 388,74.22,85.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r.
.turnin -30898 >>Turn in Cutting the Swarm
.target Taoshi
step
#xprate <2.4
.isQuestTurnedIn 30898
.goto 388,74.22,85.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r.
.accept 30900 >>Accept Terror of the Dread Wastes
.target Taoshi
step
.isOnQuest 30900
.goto 388,74.24,86.86
>>Kill |cRXP_ENEMY_Norvakess|r who emerges through dirt.
.complete 30900,1 
.mob norvakess
step
.goto 388,76.42,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.turnin -30900 >>Turn in Terror of the Dread Wastes
.target Taran Zhu
step
#xprate <2.4
.isQuestTurnedIn 30900
.goto 388,76.42,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r.
.accept 30901 >>Accept Along the Southern Front
.target Taran Zhu
step
.goto 388,67.31,80.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r.
.turnin 30901 >>Turn in Along the Southern Front
.target Taoshi
.accept 30970 >>Accept Enraged By Hatred
step
.goto 388,67.36,80.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Pao-Me|r.
.accept 30971 >>Accept Taking Stock
.target Initiate Pao-Me
step
#completewith Seething Fleshripper
#hidewindow
#loop
.goto 388,64.17,82.63,40,0
.goto 388,66.69,83.71,40,0
.goto 388,66.65,81.43,40,0
.goto 388,64.17,82.63,0
.goto 388,66.69,83.71,0
.goto 388,66.65,81.43,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Seething Fleshripper|r.
.complete 30970,1 
.mob seething fleshripper
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Shado-Pan Fire Arrows|r.
.complete 30971,1 
step
#label Seething Fleshripper
>>Kill |cRXP_ENEMY_Seething Fleshripper|r.
.complete 30970,1 
.mob seething fleshripper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r and |cRXP_FRIENDLY_Initiate Pao-Me|r.
.turnin 30970 >>Turn in Enraged By Hatred
.goto 388,67.32,80.86
.turnin 30971 >>Turn in Taking Stock
.accept 30972 >>Accept Joining the Fight
.goto 388,67.37,80.67
.target Taoshi
.target Initiate Pao-Me
step
#label Joining the Fight
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r and |cRXP_FRIENDLY_Taran Zhu|r.
.turnin 30972 >>Turn in Joining the Fight
.goto 388,61.59,79.36
.accept 30973 >>Accept Up In Flames
.goto 388,61.64,79.33
.target Taran Zhu
.target Lao-Chin the Iron Belly
step
#loop
.goto 388,61.24,79.28,40,0
.goto 388,60.77,78.83,40,0
.goto 388,62.14,79.64,40,0
.goto 388,60.58,81.01,40,0
.goto 388,61.24,79.28,0
.goto 388,60.77,78.83,0
.goto 388,62.14,79.64,0
.goto 388,60.58,81.01,0
>>Kill |cRXP_ENEMY_Kor'thik Timberhusk|r.
.complete 30973,1 
.mob kor'thik timberhusk
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r and |cRXP_FRIENDLY_Lao-Chin the Iron Belly|r.
.turnin 30973 >>Turn in Up In Flames
.goto 388,61.64,79.32
.accept 30975 >>Accept The Taking of Dusklight Bridge
.goto 388,61.6,79.35
.target Lao-Chin the Iron Belly
.target Taran Zhu
]])

