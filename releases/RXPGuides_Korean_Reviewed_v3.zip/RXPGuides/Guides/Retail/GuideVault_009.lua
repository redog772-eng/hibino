if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#subweight 998
#name cab) Eversong Woods Route 5 (H)
#displayname |cFFFCDC002|r - Eversong Woods
#next cb) Arator Route 5 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#completewith Recruit Lothraxion
+This guide is for multiboxers or players skipping side quests, while incorporating Delves. The idea is to do Siren Isles at the start and crafting at the end with some additional prepared quests.
step
#include a) Eversong Woods Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name cb) Arator Route 5 (H)
#displayname |cFFFCDC003|r - Arator
#next cc) Harandar Route 5 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Arator Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name cc) Harandar Route 5 (H)
#displayname |cFFFCDC004|r - Harandar
#next cd) Zul'Aman Route 5 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Harandar Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name cd) Zul'Aman Route 5 (H)
#displayname |cFFFCDC005|r - Zul'Aman
#next ce) Voidstorm Route 5 (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Zul'Aman Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name ce) Voidstorm Route 5 (H)
#displayname |cFFFCDC006|r - Voidstorm
#next RestedXP Midnight\a) 90 Unlocking Systems (H)
<< Horde
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) Voidstorm Route Delve
step
+You can do your first crafts now! Start the Adventure Mode Guide if you still need more experience to hit 90.
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name c) Turnin Route Horde 4 (H)
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 4 (H)
#internal
<< Horde
step
#include RestedXP Midnight\a) Turnin Route Horde
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name ca) Midnight DMF Route 4 (H)
#displayname |cFF9D9D9D0|r - Darkmoon Faire
#next caa) Midnight Intro Route 4 (H)
<< Horde
step
#include RestedXP Midnight\a) DMF
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name caa) Midnight Intro Route 4 (H)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 4 (H)
<< Horde
step
#completewith TheLightsSummonsB
+This guide is for players leveling their alts to 90. |cRXP_WARN_Remember you can do first crafts for 80-100% of level 89.|r
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#subweight 997
#name cab) Eversong Woods Route 4 (H)
#displayname |cFFFCDC002|r - Eversong Woods 1
#next cac) Harandar Voidstorm Delves (H)
<< Horde
step
#completewith EversongWoodsAdventureModeA
+This guide is for players leveling their alts to 90. |cRXP_WARN_Remember you can do first crafts for 80-100% of level 89.|r
step
#include RestedXP Midnight\a) Eversong Woods Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#subweight 997
#name cac) Harandar Voidstorm Delves (H)
#displayname |cFFFCDC003|r - Harandar & Voidstorm Delves
#next cad) Eversong Woods Route 4 (H) 2
<< Horde
step
#include RestedXP Midnight\a) Harandar Voidstorm Delves
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#subweight 997
#name cad) Eversong Woods Route 4 (H) 2
#displayname |cFFFCDC004|r - Eversong Woods 2
#next cb) Zul'Aman Route 4 (H)
<< Horde
step
#include RestedXP Midnight\a) Eversong Woods Adventure Mode 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name cb) Zul'Aman Route 4 (H)
#displayname |cFFFCDC005|r - Zul'Aman
#next cca) Harandar Route 4 (H)
<< Horde
step
#include RestedXP Midnight\a) Zul'Aman Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name cca) Harandar Route 4 (H)
#displayname |cFFFCDC006|r - Harandar 1
#next ccb) Harandar Route 4 (H) 2
<< Horde
step
#include RestedXP Midnight\a) Harandar Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name ccb) Harandar Route 4 (H) 2
#displayname |cFFFCDC007|r - Harandar 2
#next cd) Voidstorm Route 4 (H)
<< Horde
step
#include RestedXP Midnight\a) Harandar Adventure Mode 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name cd) Voidstorm Route 4 (H)
#displayname |cFFFCDC008|r - Voidstorm
#next RestedXP Midnight\a) 90 Unlocking Systems (H)
<< Horde
step
#include RestedXP Midnight\a) Voidstorm Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#subweight 995.5
#name a) Eversong Woods Sojourner (H)
#displayname |cFFFCDC001|r - 1
#internal
<< Horde
step
#completewith Trials and TabulationsZ
+This guide is for players who want to complete all storylines as quickly as possible in one go (for levels 80-90).
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#name a) Zul'Aman Sojourner (H)
#displayname 2
#internal
<< Horde
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#name a) Harandar Sojourner (H)
#displayname 3
#internal
<< Horde
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#name a) Voidstorm Sojourner (H)
#displayname 4
#internal
<< Horde
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#subweight 995.6
#name a) ASilvermoon & Voidstorm (H)
#displayname |cFFFCDC001|r - Silvermoon & Voidstorm Part 1
#next a) BVoidstorm Part 2 (H)
<< Horde
step
#completewith Trials and TabulationsZ
+This guide is for players who want to complete all campaigns & storylines as quickly as possible in one go (for levels 80-90).
step
#include a) Silvermoon & Voidstorm
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) BVoidstorm Part 2 (H)
#displayname |cFFFCDC002|r - Voidstorm Part 2
#next a) CEversong & Harandar Part 1 (H)
<< Horde
step
#include a) Voidstorm Part 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) CEversong & Harandar Part 1 (H)
#displayname |cFFFCDC003|r - Eversong & Harandar Part 1
#next a) EEversong Woods Part 2 (H)
<< Horde
step
#include a) Eversong & Harandar Part 1
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) EEversong Woods Part 2 (H)
#displayname |cFFFCDC004|r - Eversong Part 2
#next a) FHarandar & Eversong Part 2 (H)
<< Horde
step
#include a) Eversong Woods Part 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) FHarandar & Eversong Part 2 (H)
#displayname |cFFFCDC005|r - Harandar & Eversong Part 2
#next a) GHarandar Part 3 & Eversong Woods (H)
<< Horde
step
#include a) Harandar & Eversong Part 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) GHarandar Part 3 & Eversong Woods (H)
#displayname |cFFFCDC006|r - Harandar & Eversong Part 3
#next a) HZul'aman Part 1 (H)
<< Horde
step
#include a) Harandar Part 3 & Eversong Woods
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) HZul'aman Part 1 (H)
#displayname |cFFFCDC007|r - Zul'aman Part 1
#next a) IZul'aman Part 2 & Arathor (H)
<< Horde
step
#include a) Zul'aman Part 1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) IZul'aman Part 2 & Arathor (H)
#displayname |cFFFCDC008|r - Zul'aman Part 2 & Arathor
#next a) Foothold (H)
<< Horde
step
#include a) Zul'aman Part 2 & Arathor
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup Treasures & Renown
#subweight 991
#name a) Lore Hunter (H)
#displayname Renown Treasures Worldtour
<< Horde
step
#include RestedXP Midnight\a) Lore Hunter
]])

RXPGuides.RegisterGuide([[
#version 1
#retail
#group RestedXP Midnight
#subgroup Treasures & Renown
#name a) Skyriding Glyphs Worldtour (H)
#displayname Skyriding Glyphs Worldtour
<< Horde
step
#include RestedXP Miscellaneous\a) Eversong Woods Glyphs
step
#include RestedXP Miscellaneous\a) Zul'aman Glyphs
step
#include RestedXP Miscellaneous\a) Harandar Glyphs
step
#include RestedXP Miscellaneous\a) Voidstorm Glyphs
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Treasures & Renown
#name a) Profession Knowledge Worldtour (H)
#displayname Profession Knowledge Worldtour
<< Horde
step
#include RestedXP Miscellaneous\a) Eversong Woods Knowledge
step
#include RestedXP Miscellaneous\a) Zul'aman Knowledge
step
#include RestedXP Miscellaneous\a) Harandar Knowledge
step
#include RestedXP Miscellaneous\a) Voidstorm Knowledge
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) ARitual Sites (H)
#displayname Ritual Sites
<< Horde
step
#include a) Ritual Sites
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-84)|r Delves Worldtour
#subweight 994.999
#name a) Delves Worldtour (H)
#displayname Just Delve Quests
<< Horde
step
#completewith next
+This guide is for players wanting to do a delve worldtour.
*|cRXP_WARN_NOTE:|r This guide requires you to have unlocked the adventure mode or at least access to all zones.
step
#include RestedXP Midnight\a) The Light's Summons@TheLightsSummonsA-TheLightsSummonsB
step
#include RestedXP Midnight\a) Eversong Woods Route Delve Worldtour
step
#include RestedXP Midnight\a) Zul'Aman Route Delve Worldtour
step
#include RestedXP Midnight\a) Harandar Route Delve Worldtour
step
#include RestedXP Midnight\a) Voidstorm Route Delve Worldtour
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Isle of Quel'danas Delves (H)
#displayname Isle of Quel'Danas
#chapters a) Parhelion Plaza (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Parhelion Plaza (H)
#displayname Parhelion Plaza
#next a) The Darkway (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Parhelion Plaza
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#subweight 990
#name ab) Eversong Forest Delves (H)
#displayname Eversong Forest
#chapters a) The Shadow Enclave (H);a) Collegiate Calamity (H);a) The Darkway (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Shadow Enclave (H)
#displayname The Shadow Enclave
#next a) Collegiate Calamity (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Shadow Enclave
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Collegiate Calamity (H)
#displayname Collegiate Calamity
#next a) The Darkway (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Collegiate Calamity
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Darkway (H)
#displayname The Darkway
#next a) The Shadow Enclave (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Darkway
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name ac) Zul'aman Delves
#displayname Zul'Aman
#chapters a) Twilight Crypts (H);a) Atal'Aman (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Twilight Crypts (H)
#displayname Twilight Crypts
#next a) Atal'Aman(H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Twilight Crypts
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Atal'Aman (H)
#displayname Atal'Aman
#next a) Twilight Crypts (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Atal'Aman
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name ad) Harandar Delves
#displayname Harandar
#chapters a) The Grudge Pit (H);a) The Gulf of Memory (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Grudge Pit (H)
#displayname The Grudge Pit
#next a) The Gulf of Memory (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Grudge Pit
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Gulf of Memory (H)
#displayname The Gulf of Memory
#next a) The Grudge Pit (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Gulf of Memory
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name ae) Voidstorm Delves (H)
#displayname Voidstorm
#chapters a) Sunkiller Sanctum (H);a) Shadowguard Point (H);a) Torment’s Rise (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Sunkiller Sanctum (H)
#displayname Sunkiller Sanctum
#next a) Shadowguard Point (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Sunkiller Sanctum
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Shadowguard Point (H)
#displayname Shadowguard Point
#next a) Sunkiller Sanctum (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Shadowguard Point
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name af) The Coiled Isle Delves (H)
#displayname The Coiled Isle
#chapters a) The Ring of Glory (H);a) Gnarldor Isle (H)
<< Horde
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) The Ring of Glory (H)
#displayname The Ring of Glory
#next a) Gnarldor Isle (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) The Ring of Glory
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Delves & Ritual Sites
#name a) Gnarldor Isle (H)
#displayname Gnarldor Isle
#next a) The Ring of Glory (H)
#chapter
<< Horde
step
#include RestedXP Midnight\a) Gnarldor Isle
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Pre-Expansion Preparations
#name a1) Quest Preparations (A)
#displayname |cFF00FF001|r - Quests
#chapters a) Quest Booklet (A);a) Furniture Favor (A);a) Fishing (A);a) Cooking (A);a) Balloon (A);a) Selfie Cam (A);a) Warbanding Together (A);a) Squally (A);a) Blade in Twilight (A);a) Delve Quests (A);a) Burning Steppes Prep (A);a) Gidwin (A);a) Tirisfal Midnight Prep (A);a) Alterac Valley Quests (A);a) Pet Battle Setup (A);a) Human Heritage Quests (A);a) Night Elf Heritage Quests (A);a) Dwarf Heritage Quests (A);a) Gnome Heritage Quests (A);a) Draenei Heritage Quests (A);a) Worgen Heritage Quests (A);a) Heritage Pandaren (A);a) Trading Post (A);a) Begin Your Training: Master Cheng (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subweight 1001
#name a) Endeavor (H)
#displayname Endeavor |cRXP_WARN_30+ Quest Setup(NEW)|r
#subgroup Pre-Expansion Preparations
<< Alliance
step
#include a) Endeavor
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Quest Booklet (A)
#displayname |cFFFCDC00How to Use(MUST READ)|r
#chapter
#next a) Furniture Favor (A)
<< Alliance
step
#include RestedXP Midnight\a) Quest Booklet
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Furniture Favor (A)
#displayname Furniture Favor
#next a) Fishing (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Furniture Favor
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Fishing (A)
#displayname Fishing
#next a) Cooking (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Fishing
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Cooking (A)
#displayname Cooking
#next a) Balloon (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Cooking
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Balloon (A)
#displayname Balloon
#next a) Selfie Cam (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Balloon
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Selfie Cam (A)
#displayname Selfie Cam
#next a) Warbanding Together (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Selfie Cam
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Warbanding Together (A)
#displayname Warbands
#next a) Squally (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up 2 quests that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
+This sets up a 2 quests that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Warbanding Together
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Squally (A)
#displayname Squally
#next a) Blade in Twillight (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_it can be completed once per day, even if you’ve done it before|r.
*|cRXP_WARN_Estimate Setup Time: 10minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Squally
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Blade in Twillight (A)
#displayname Xalatath Lorewalking
#next a) Delve Quests (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up one quest that rewards XP equivalent to up to five quests from levels 80–90 and unlocks an item we’ll also make use of.
*|cRXP_WARN_It can be done at any time|r.
*|cRXP_WARN_Estimate Setup Time: 10 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up one quest that rewards XP equivalent to up to five quests from levels 80–90 and unlocks an item we’ll also make use of.
*|cRXP_WARN_It can be done at any time|r.
*|cRXP_WARN_Estimate Setup Time: 10 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Xal'atath@LoreWalkingPrepStart-LoreWalkingPrepEnd
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Delve Quests (A)
#displayname Delve Quests
#next a) Gidwin (A)
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up |cRXP_WARN_13|r quests that rewards full XP on level 80
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up |cRXP_WARN_13|r quests that rewards full XP on level 80
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Delve Quests
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Gidwin (A)
#next a) Alterac Valley Quests (A)
#displayname Eastern Plaguelands
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This unlocks the quest Journey’s End and keeps it in your quest log so a teleport item can be used during the 80–90 campaign, saving a significant amount of time.
*|cRXP_WARN_You may have already completed this quest; if so, the item is no longer obtainable|r
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zoneskip 23
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This unlocks the quest Journey’s End and keeps it in your quest log so a teleport item can be used during the 80–90 campaign, saving a significant amount of time.
*|cRXP_WARN_You may have already completed this quest; if so, the item is no longer obtainable|r
*|cRXP_WARN_Estimate Setup Time: 1 hour|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Gidwin
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Alterac Valley Quests (A)
#next a) Pet Battle Setup (A)
#displayname Alterac Valley
#chapter
<< Alliance
step
#completewith next
#label WarningText
+This sets up a |cRXP_WARN_6|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per character, you may have already completed it|r.
*This takes time depending on what your current reputation standing is with the Stormpike Guard
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zoneskip 25
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a |cRXP_WARN_6|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per character, you may have already completed it|r.
*This takes time depending on what your current reputation standing is with the Stormpike Guard
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Alterac Valley Quests
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Pet Battle Setup (A)
#displayname Pet Battles
#chapter
<< Alliance
step
#completewith next
#label WarningText
+This sets up |cRXP_WARN_30-40|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 3-5 hours|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up |cRXP_WARN_30-40|r quests that rewards full XP from levels 80–90
*|cRXP_WARN_they can be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 3-5 hours|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Pet Battle Setup
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Human Heritage Quests (A)
#next a) Trading Post (A)
#displayname Heritage Armor
#chapter
<< Alliance Human
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Human Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Dwarf Heritage Quests (A)
#next a) Trading Post (A)
#displayname Heritage Armor
#chapter
<< Alliance Dwarf
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Dwarf Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Nightelf Heritage Quests (A)
#next a) Trading Post (A)
#displayname Heritage Armor
#chapter
<< Alliance NightElf
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Nightelf Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Gnome Heritage Quests (A)
#next a) Trading Post (A)
#displayname Heritage Armor
#chapter
<< Alliance Gnome
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Gnome Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Draenei Heritage Quests (A)
#next a) Trading Post (A)
#displayname Heritage Armor
#chapter
<< Alliance Draenei
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Draenei Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Worgen Heritage Quests (A)
#next a) Trading Post (A)
#displayname Heritage Armor
#chapter
<< Alliance Worgen
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Miscellaneous\a) Worgen Heritage Armor@StartIncludePrepGuide-EndIncludePrepGuide
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Heritage Pandaren (A)
#next a) Trading Post (A)
#displayname Pandaren
#chapter
<< Alliance Pandaren
step
#completewith next
#label WarningText
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a multiple quests that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 30 minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Heritage Pandaren
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Trading Post (A)
#next a) Begin Your Training: Master Cheng (A)
#displayname Trading Post
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Midnight\a) Trading Post
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Begin Your Training: Master Cheng (A)
#displayname Monk Quests
#chapter
<< Alliance Monk
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
*|cRXP_WARN_Skip this step when done reading to see the arrow|r.
step
#include RestedXP Speed Leveling\a) Monk Quests@Master Cheng-MonkIncludePrepEnd
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete and don't turn in the quest until xp is unlocked.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Pre-Expansion Preparations
#name a2) Item Preparations (A)
#displayname |cFF00FF002|r - Items
#chapters a) Item Information (A);a) Shopping List (A);a) Guild Items (A);a) Shadowberries (A);a) Bivigosa's Blood Sausages (A) << Alliance
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Item Booklet (A)
#displayname |cFFFCDC00How to Use(MUST READ)|r
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Item Booklet
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shopping List (A)
#displayname Shopping
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#include RestedXP Midnight\a) Shopping List
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Guild Items (A)
#displayname XP Banners & Teleport Cloaks
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#include RestedXP Midnight\a) Guild Items
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Shadowberries (A)
#displayname Shadowberries
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#include RestedXP Midnight\a) Shadowberries
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Bivigosa's Blood Sausages (A)
#displayname Bivigosa's Blood Sausages
#chapter
<< Alliance
step
#completewith next
#label WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#completewith WarningText
.zone 84 >>Go to Stormwind
step
#requires WarningText
#title |cFFFCDC00Skip this step to proceed|r
+This sets up a single quest that rewards full XP from levels 80–90
*|cRXP_WARN_but it can only be completed once per account, you may have already completed it|r.
*|cRXP_WARN_Estimate Setup Time: 1-5minutes|r.
step
#include RestedXP Midnight\a) Bivigosa's Blood Sausages
step
#title |cFFFCDC00Skip this step to proceed|r
+This section of the guide is complete.
*|cRXP_WARN_Manually skip this step to proceed|r
]])

