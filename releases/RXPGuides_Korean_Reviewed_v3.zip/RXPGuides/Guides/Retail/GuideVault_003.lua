if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#groupweight 999
#name a) The Light's Summons
#internal
step
#label TheLightsSummonsA
>>This will automatically appear in your questlog. If not then port to Orgrimmar/Stormwind.
.accept 91281 >>Accept Midnight
step
.goto 84,53.26,54.33,-1 << Alliance
.goto 85,53.48,77.31,-1 << Horde
.goto 2339,44.23,34.80,-1
.goto 2393,46.69,80.24,-1
>>Meet |cRXP_FRIENDLY_Lady Liadrin|r in Stormwind or Silvermoon << Alliance
>>Meet |cRXP_FRIENDLY_Lady Liadrin|r in Orgrimmar or Silvermoon << Horde
.complete 91281,1 
.mob Image of Lady Liadrin
step
#label TheLightsSummonsAA
#arrowtext Talk to\n|cRXP_FRIENDLY_Image of Lady Liadrin|r
.goto 84,53.26,54.33,-1 << Alliance
.goto 85,53.48,77.31,-1 << Horde
.goto 2339,44.23,34.80,-1
.goto 2393,46.69,80.24,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lady Liadrin|r.
.turnin 91281 >>Turn in Midnight
.accept 88719 >>Accept A Voice from the Light
.target Image of Lady Liadrin
step << Alliance
#optional
#completewith next
#hidewindow
.isQuestTurnedIn account,86522
.gossipoption 138201 >>1
.skipto step,Imperatus
.skipgossipid 138201
step << Horde
#optional
#completewith next
#hidewindow
.isQuestTurnedIn account,86522
.gossipoption 138201 >>1
.skipto step,Imperatus
step
#label TheLightsSummonsB
#arrowtext Talk to\n|cRXP_FRIENDLY_Image of Lady Liadrin|r
.goto 84,53.26,54.33 << Alliance
.goto 85,53.48,77.31 << Horde
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Lady Liadrin|r.
.complete 88719,1 
.target Image of Lady Liadrin
.skipgossipid 133523
step
#arrowtext |cFFFCDC00Wait for the Roleplay|r
.goto 2537,26.36,13.16
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88719,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2432,48.49,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 88719 >>Turn in A Voice from the Light
.accept 86769 >>Accept Last Bastion of the Light
.timer 29,Roleplay Duration
.target Lady Liadrin
step
#completewith next
#label Skitter
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r |cRXP_WARN_after the roleplay|r.
.turnin 86769 >>Turn in Last Bastion of the Light
.accept 86770 >>Accept Champions of Quel'Danas
.target Lady Liadrin
step
#completewith Skitter
.goto 2565,75.96,38.24
.gossipoption 132887 >>Talk to |cRXP_FRIENDLY_Skitter|r
.target Skitter
step
#requires Skitter
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2432,46.00,44.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r |cRXP_WARN_after the roleplay|r.
.turnin 86769 >>Turn in Last Bastion of the Light
.accept 86770 >>Accept Champions of Quel'Danas
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2432,45.98,44.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.accept 86780 >>Accept Where Heroes Hold
.target High Exarch Turalyon
.accept 89271 >>Accept My Son
step
#completewith Recruit Lothraxion
>>Kill |cRXP_ENEMY_Voidbeings|r
*|cRXP_ENEMY_Conjurers|r and |cRXP_ENEMY_Defilers|r on sight.
.complete 86780,1 
.mob Voidmarked Reserve
.mob Voidgorged Reserve
.mob Voidswarm Reserve
.mob Voidfront Conjurer
.mob Voidfront Pummeler
.mob Voidfront Defiler
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Faerin Lothar|r
.goto 2565,70.33,17.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faerin Lothar|r.
.complete 86770,1 
.target Faerin Lothar
.skipgossipid 132513
step
#completewith next
#label Recruit Lothraxion
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2565,65.20,50.10,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.complete 86770,3 
.target Lothraxion
.skipgossipid 132514
step
#completewith Recruit Lothraxion
#hidewindow
#arrowtext |cFFFCDC00Follow the Arrow|r
.goto 2565,51.23,50.09,100 >>Follow the Arrow
step
#requires Recruit Lothraxion
#label Recruit Lothraxion 2
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2565,51.23,50.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.complete 86770,3 
.target Lothraxion
.skipgossipid 132514
step
.isOnQuest 86780
#arrowtext |cFFFCDC00Drop down|r
.goto 2565,66.61,78.65,25 >>|cRXP_WARN_Drop down|r.
.itemcount 109076,<1
step
.isOnQuest 86780
#arrowtext Use |T133632:0|t[Goblin Glider Kit]
.cooldown item,109076,>0,1
.itemcount 109076,1
.goto 2565,65.43,87.64
.cast 126389 >>Use |T133632:0|t[Goblin Glider Kit] to glide off the building.
.use 109076
step
.goto 2565,64.19,74.61
>>Kill |cRXP_ENEMY_Voidbeings|r
*|cRXP_ENEMY_Conjurers|r and |cRXP_ENEMY_Defilers|r on sight.
.complete 86780,1,70 
.mob Voidmarked Reserve
.mob Voidgorged Reserve
.mob Voidfront Conjurer
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2565,65.43,87.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.complete 89271,1 
.skipgossipid 122916
.skipgossipid 132388
.target Arator
step
#label Recruit Alonsus Faol
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2565,54.12,84.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.complete 86770,2 
.target Alonsus Faol
.skipgossipid 132515
step
.goto 2565,31.96,85.3,25,0
.goto 2565,20.38,67.8,25,0
.goto 2432,35.04,45.4
>>Kill |cRXP_ENEMY_Voidbeings|r
*|cRXP_ENEMY_Conjurers|r and |cRXP_ENEMY_Defilers|r on sight.
.complete 86780,1 
.mob Voidmarked Reserve
.mob Voidgorged Reserve
.mob Voidfront Conjurer
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r and |cRXP_FRIENDLY_Lor'themar Theron|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r and |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86780 >>Turn in Where Heroes Hold
.turnin 89271 >>Turn in My Son
.goto 2432,35.34,43.77
.target +High Exarch Turalyon
.turnin 86770 >>Turn in Champions of Quel'Danas
.accept 86805 >>Accept The Hour of Need
.goto 2432,35.38,44.05
.target +Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2432,35.52,44.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 89012 >>Accept A Safe Path
.target Arator
step
#arrowtext |cFFFCDC00Drop down|r\nCivilian Rescued (3/20)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2565,23.91,45.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scared Civilian|r.
.complete 86805,1,3 
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.skipgossipid 132653
.skipgossipid 132686
.skipgossipid 132685
.skipgossipid 132670
.skipgossipid 132656
.skipgossipid 132655
.target Scared Civilian
step
#arrowtext Civilian Rescued (4/20)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2565,28.01,46.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Citizen|r(|cRXP_WARN_or heal them|r).
.complete 86805,1,4 
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.target Injured Citizen
step
#arrowtext Civilian Rescued (8/20)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2565,33.4,45.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scared Civilian|r.
.complete 86805,1,8 
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.skipgossipid 132653
.skipgossipid 132686
.skipgossipid 132685
.skipgossipid 132670
.skipgossipid 132656
.skipgossipid 132655
.target Scared Civilian
step
#arrowtext Civilian Rescued (12/20)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2565,35.41,54.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scared Civilian|r.
.complete 86805,1,12 
.skipgossipid 132653
.skipgossipid 132686
.skipgossipid 132685
.skipgossipid 132670
.skipgossipid 132656
.skipgossipid 132655
.target Scared Civilian
step
#arrowtext Civilian Rescued (13/20)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2565,39.06,58.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Citizen|r(|cRXP_WARN_or heal them|r).
.complete 86805,1,13 
.target Injured Citizen
step
#arrowtext Civilian Rescued (16/20)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2565,40.14,63.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scared Civilian|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86805,1,16 
.skipgossipid 132653
.skipgossipid 132686
.skipgossipid 132685
.skipgossipid 132670
.skipgossipid 132656
.skipgossipid 132655
.target Scared Civilian
step
#arrowtext Civilian Rescued (17/20)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2565,42.51,65.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Citizen|r(|cRXP_WARN_or heal them|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86805,1,17 
.target Injured Citizen
step
#completewith next
>>Kill |cRXP_ENEMY_Gloomstress|r.
.complete 89012,1 
.mob Gloomstress
step
#arrowtext Civilian Rescued (20/20)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2565,46.29,74.43,15,0
.goto 2565,50.45,65.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scared Civilian|r.
.complete 86805,1,20 
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.skipgossipid 132653
.skipgossipid 132686
.skipgossipid 132685
.skipgossipid 132670
.skipgossipid 132656
.skipgossipid 132655
.target Scared Civilian
step
#arrowtext Kill |cRXP_ENEMY_Gloomstress|r
.goto 2565,46.29,74.43
>>Kill |cRXP_ENEMY_Gloomstress|r.
.complete 89012,1 
.mob Gloomstress
step
#completewith next
#hidewindow
.itemcount 153123,1
#arrowtext Use |T628559:0|t[Cracked Radinax Control Gem]
.goto 2432,41.31,56.81,50 >>1
step
.goto 2432,41.31,56.81
>>Follow the Arrow
.complete 86805,2 
.use 153123
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2432,41.31,56.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86805 >>Turn in The Hour of Need
.turnin 89012 >>Turn in A Safe Path
.accept 86806 >>Accept Luminous Wings
.target Lor'themar Theron
step
#arrowtext Click on the\n|cRXP_PICK_Empowered Dragonhawk|r
.goto 2432,41.02,58.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Empowered Dragonhawk|r.
.complete 86806,1 
.target Empowered Dragonhawk
step
#completewith next
>>Aim at |cRXP_ENEMY_Void Invaders|r and use |T876916:0|t[Spiraling Light] to kill them.
.complete 86806,2 
.mob Void Invaders
step
#arrowtext Use |T460953:0|t[Speed of Light]\n|cRXP_WARN_|T1119937:0|t[Grappling Rope]|r near |cRXP_FRIENDLY_Civilian|r\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2432,36.22,67.56,30,0
.goto 2432,29.35,70.44,30,0
.goto 2432,28.80,75.81,30,0
.goto 2432,32.63,79.74,30,0
.goto 2432,33.95,75.6,30,0
>>Use |T1119937:0|t[Grappling Rope] near the |cRXP_FRIENDLY_Civilian|r and |T460953:0|t[Speed of Light] for a boost.
.complete 86806,3 
.target Distressed Civilian 1
.target Distressed Civilian 3
.target Distressed Civilian 2
step
#arrowtext Kill the |cRXP_ENEMY_Void Invaders|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,26.67,71.66
>>Aim at |cRXP_ENEMY_Void Invaders|r and use |T876916:0|t[Spiraling Light] to kill them.
.complete 86806,2 
.mob Void Invaders
step
#completewith next
#label Luminous Wings
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86806 >>Turn in Luminous Wings
.target Lor'themar Theron
step
#completewith Luminous Wings
.exitvehicle >>Press the Macro to leave the vehicle.
*It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >> /leavevehicle
step
#requires Luminous Wings
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2432,41.32,56.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86806 >>Turn in Luminous Wings
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2432,41.30,56.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86807 >>Accept The Gate
.target Arator
step
#completewith NorthGate
#hidewindow
#arrowtext Use |T1405809:0|t[Gunshoes]
.cooldown item,132516,>0,1
.itemcount 132516,1
.goto 2565,50.85,73.57,25,0
.goto 2565,60.00,50.70,25,0
.goto 2565,49.03,22.24,50 >>1
.use 132516
step
#completewith NorthGate
#hidewindow
#arrowtext Use |T628559:0|t[Cracked Radinax Control Gem]
.itemcount 153123,1
.goto 2565,50.85,73.57,25,0
.goto 2565,60.00,50.70,25,0
.goto 2565,49.03,22.24,50 >>1
.use 153123
step
#label NorthGate
.goto 2565,49.03,22.24
#title |cFFFCDC00Follow the Arrow|r
.complete 86807,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2565,49.03,22.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.turnin 86807 >>Turn in The Gate
.target High Exarch Turalyon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2565,49.70,21.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 91274 >>Accept Severing the Void
.accept 86834 >>Accept Voidborn Banishing
.target Arator

step
#completewith Severing the Void
+|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Spears|r for an extra damage button.
step
#arrowtext Sentinels activated (1/5)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2432,42.81,35.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sentinel|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91274,1,1 
.target Quel'Danas Sentinel
step
#arrowtext Sentinels activated (2/5)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2432,44.43,35.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sentinel|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91274,1,2 
.target Quel'Danas Sentinel
step
#arrowtext Kill |cRXP_ENEMY_Blightclaw|r
.goto 2432,46.40,33.69
>>Kill |cRXP_ENEMY_Blightclaw|r.
.complete 86834,2 
.mob Blightclaw
step
#arrowtext Sentinels activated (3/5)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2432,43.26,29.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sentinel|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91274,1,3 
.target Quel'Danas Sentinel
step
#completewith next
>>Kill |cRXP_ENEMY_The Wasting|r.
.complete 86834,1 
.mob The Wasting
step
#arrowtext Sentinels activated (4/5)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
.goto 2432,42.47,25.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sentinel|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91274,1,4 
.target Quel'Danas Sentinel
step
#arrowtext Patrolling around the building
#loop
.goto 2432,40.72,27.52,25,0
.goto 2432,41.82,29.2,25,0
.goto 2432,42.47,27.22,25,0
>>Kill |cRXP_ENEMY_The Wasting|r.
.complete 86834,1 
.mob The Wasting
step
.goto 2432,37.17,29.99
>>Kill |cRXP_ENEMY_Latrunculon|r.
.complete 86834,3 
.mob Latrunculon
step
#arrowtext Sentinels activated (5/5)\n|cFFFCDC00(Read Note)|r|cRXP_FRIENDLY_(SHARED)|r
#label Severing the Void
.goto 2432,38.85,31.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sentinel|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91274,1 
.complete 91274,2 
.target Quel'Danas Sentinel
step
#completewith next
#arrowtext Use |T1405809:0|t[Gunshoes]
.goto 2432,45.40,27.01,30,0
.itemcount 132516,1
.cooldown item,132516,>0,1
.cast 202844 >>Use |T1405809:0|t[Gunshoes]. Activate RP-Walk next to the NPCs to talk to them.
.use 132516
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2432,45.40,27.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.turnin 91274 >>Turn in Severing the Void
.turnin 86834 >>Turn in Voidborn Banishing
.accept 86811 >>Accept Ethereal Eradication
.target High Exarch Turalyon
.macro Cancel Gunshoes,1405809 >>/cancelaura Gunshoes
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2432,45.23,26.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 86848 >>Accept Light's Arsenal
.target Lady Liadrin
step
#completewith Shadowguard forces
.aura 1241625 >>|TInterface/cursor/crosshair/interact.blp:15|tClick on a |cRXP_PICK_Scroll|r for a buff.
step
#completewith LightsArsenalA
>>Kill |cRXP_ENEMY_Shadowguards|r.
.complete 86811,1 
.mob Shadowguard Spoiler
.mob Shadowguard Fatestealer
.mob Shadowguard Pillager
step
#arrowtext Weapons collected (1/7)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,44.84,24.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,1 
step
#completewith next
#label Weapons collected
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,2 
step
#completewith Weapons collected
#arrowtext Click on the\n|cFFDB2EEFTranslocation Portal|r.
.goto 2432,44.87,23.14,8,0
.goto 2432,44.49,23.96,8,0
.goto 2432,44.78,23.85
.cast 29129 >>Click on the |cRXP_PICK_Translocation Portal|r.
step
#requires Weapons collected
#arrowtext Weapons collected (2/7)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,45.10,23.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,2 
step
#completewith next
#label Norkonahl the Looter
#arrowtext |cFFFCDC00Drop Down|r
.goto 2432,44.76,24.14,5,0
.goto 2432,45.35,24.51,5,0
>>Kill |cRXP_ENEMY_Norkonahl the Looter|r.
.complete 86811,2 
.mob Norkonahl the Looter
step
#completewith Norkonahl the Looter
.goto 2432,49.17,22.17,132 >>Leave the building
step
#requires Norkonahl the Looter
.goto 2432,49.17,22.17
>>Kill |cRXP_ENEMY_Norkonahl the Looter|r.
.complete 86811,2 
.mob Norkonahl the Looter
step
#arrowtext |cRXP_WARN_Upstairs|r\nWeapons collected (3/7)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,50.14,22.46,10,0
.goto 2432,49,23.52,10,0
.goto 2432,49.17,23.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,3 
step
#completewith next
#label 4/7 Weapons
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,4 
step
#completewith 4/7 Weapons
#arrowtext Use |T133632:0|t[Goblin Glider Kit]
.cooldown item,109076,>0,1
.itemcount 109076,1
.goto 2432,47.33,28.2
.cast 126389 >>Use |T133632:0|t[Goblin Glider Kit] to glide off the building.
.use 109076
step
#requires 4/7 Weapons
#arrowtext |cRXP_WARN_Enter the building|r\nWeapons collected (4/7)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,47.33,28.2,10,0
.goto 2432,47.95,28.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,4 
step
#arrowtext Weapons collected (5/7)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,47.15,28.14,8,0
.goto 2432,47.20,29.45,8,0
.goto 2432,47.73,28.90
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,5 
step
#arrowtext Weapons collected (6/7)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,48.67,28.00,8,0
.goto 2432,48.65,30.13,8,0
.goto 2432,48.11,28.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,6 
step
#arrowtext Weapons collected (7/7)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
#label LightsArsenalA
.goto 2432,47.29,28.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r(|cRXP_WARN_adds an extra damage button|r).
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86848,1,7 
step
#label Shadowguard forces
#loop
.goto 2432,47.16,27.93,10,0
.goto 2432,44.72,23.59,10,0
.goto 2432,45.47,24.64,10,0
.goto 2432,46.59,23.27,20,0
.goto 2432,48.38,23.47,20,0
>>Kill |cRXP_ENEMY_Shadowguard forces|r.
.complete 86811,1 
.mob Shadowguard forces
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_High Exarch Turalyon|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_High Exarch Turalyon|r.
.turnin 86848 >>Turn in Light's Arsenal
.goto 2432,45.24,26.92
.target +Lady Liadrin
.turnin 86811 >>Turn in Ethereal Eradication
.accept 86849 >>Accept Wrath Unleashed
.goto 2432,45.39,27.00
.target +High Exarch Turalyon
step
#completewith next
#label Voidwake Behemoth
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.complete 86849,1 
.target High Exarch Turalyon
.skipgossipid 133285
step
#completewith Voidwake Behemoth
#arrowtext Run around the area\n|cFFFCDC00(avoid mobs)|r
.goto 2432,44.81,26.49,10,0
.goto 2432,43.63,24.26,15,0
.goto 2432,41.63,17.44,20,0
.goto 2432,42.1,12.74,20,0
.goto 2432,43.64,9.67,20,0
.goto 2432,45.65,11.27,60 >>Run around the Area
.itemcount 132516,<1
step
#completewith AidTuralyionVoidwakeBehemothA
#hidewindow
#requires Voidwake Behemoth
#arrowtext Use |T1405809:0|t[Gunshoes]
.goto 2432,45.65,11.27,50 >>1
.cooldown item,132516,>0,1
.itemcount 132516,1
step
#completewith AidTuralyionVoidwakeBehemothA
#hidewindow
#requires Voidwake Behemoth
#arrowtext Use |T628559:0|t[Cracked Radinax Control Gem]
.goto 2432,45.65,11.27,50 >>1
.itemcount 153123,1
step
#label AidTuralyionVoidwakeBehemothA
#requires Voidwake Behemoth
#arrowtext Talk to |cRXP_FRIENDLY_High Exarch Turalyon|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,45.65,11.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.complete 86849,1 
.macro Cancel Gunshoes,1405809 >>/cancelaura Gunshoes
.use 132516
.use 153123
.target High Exarch Turalyon
.skipgossipid 133285
step
#arrowtext Use |T612968:0|t[|cRXP_WARN_ExtraActionButton|r]\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,45.77,11.36
>>Stand within the circle and use the |T612968:0|t[|cRXP_WARN_ExtraActionButton|r] and cancel it right after.
*|cRXP_WARN_NOTE:|r You can't do this in combat.
.complete 86849,2 
step
>>Press the Macro to leave the vehicle.
*It's in the "Active Items" window.
.complete 86849,3 
.macro Cancel Buff,612968 >>/cancelaura Channel Light
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2432,45.84,11.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 86849 >>Turn in Wrath Unleashed
.accept 86850 >>Accept Broken Sun
.target Lady Liadrin
step
#arrowtext Click on |cRXP_PICK_Empowered Dragonhawk|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2432,39.73,16.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Empowered Dragonhawk|r.
.complete 86850,1 
.timer 30,Flight Duration
.target Empowered Dragonhawk
step
.goto 2432,51.57,56.40
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86850,2 
.timer 20,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2566,51.74,81.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r |cRXP_WARN_after the roleplay|r.
.turnin 86850 >>Turn in Broken Sun
.accept 86852 >>Accept Light's Last Stand
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2566,51.74,81.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.complete 86852,1 
.skipgossipid 132924
.target Lady Liadrin
step
#completewith Imperatus
+Step into |cRXP_WARN_Orbs|r for a buff.
.mob Sun's Ember
step
#arrowtext Avoid Imperatus & Berserker
#loop
.goto 2566,68.24,67.00,35,0
.goto 2566,65.39,46.37,35,0
.goto 2566,61.71,30.27,35,0
.goto 2566,34.82,42.62,35,0
.goto 2566,41.69,63.61,35,0
.goto 2566,38.73,76.37,35,0
.goto 2566,66.49,68.4,35,0
>>Kill |cRXP_ENEMY_Voidbeings|r.
*|cRXP_WARN_Avoid Imperatus; need after|r.
.complete 86852,2 
.mob Void-Runed Disruptor
.mob Voidmarked Intruder
.mob Voidswarm Reserve
step
#label Imperatus
.goto 2566,51.29,21.23
>>Kill |cRXP_ENEMY_Imperatus|r.
.complete 86852,4 
.mob Imperatus
step
#label TheLightsSummonsZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2424,52.66,88.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 86852 >>Turn in Light's Last Stand
.target Lady Liadrin
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Whispers in the Twilight
#internal
step
#optional
.isQuestAvailable 86769
+|cRXP_WARN_You have to do the "The Light's Summons" Chapter first|r
.clicknext RestedXP Midnight\a) The Light's Summons (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) The Light's Summons (H) >>CLICK HERE FOR GUIDE << Horde
step
.isQuestTurnedIn account,86522
#label WhispersInTheTwilightA
#completewith next
#hidewindow
.acceptmap 94871
.accept 94871 >>Accept Eversong
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
step
.isQuestTurnedIn account,86522
.goto 2393,45.61,70.36
#arrowtext Click on the\n|cRXP_PICK_Scouting Map|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 94871 >>Accept Eversong
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2424,52.54,88.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 86733 >>Accept Silvermoon Negotiations
.target Lor'themar Theron

step
.goto 2393,45.92,69.68
>>Enter the Sanctum
.complete 86733,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.45,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86733 >>Turn in Silvermoon Negotiations
.accept 86734 >>Accept Diplomacy
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.45,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86733 >>Turn in Silvermoon Negotiations
.accept 86734 >>Accept Diplomacy
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.complete 86734,1 
.target Lor'themar Theron
.skipgossipid 132632
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.convertquest 86735,86736 << Horde
.goto 2393,45.44,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86734 >>Turn in Diplomacy
.accept 86735 >>Accept Paved in Ash
.target Lor'themar Theron
step
#completewith next
#label Vanguard
#arrowtext |cRXP_WARN_Leave the house|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Amias Bellamy|r.
.complete 86735,7 
.target General Amias Bellamy
.skipgossipid 135224
step
#completewith Vanguard
.goto 2393,45.69,62.84,78 >>Leave the House
step
#requires Vanguard
#completewith next
+|cRXP_WARN_You can skyride again|r.
step
#requires Vanguard
#arrowtext Talk to\n|cRXP_FRIENDLY_General Amias Bellamy|r\n|cRXP_ENEMY_(NOT SHARED)|r
#label WhispersInTheTwilightB
.goto 2393,45.69,62.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Amias Bellamy|r.
.complete 86735,7 
.target General Amias Bellamy
.skipgossipid 135224
step
#completewith next
#label PavedInAshA
#arrowtext |cRXP_WARN_Enter the bank|r
.goto 2393,50.27,66.03,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ceera|r |cRXP_WARN_inside the bank|r.
.complete 86735,4 
.target Ceera
.skipgossipid 134013
step
#completewith PavedInAshA
.goto 2393,50.81,65.22,25 >>Follow the Arrow.
step
#requires PavedInAshA
#arrowtext Talk to\n|cRXP_FRIENDLY_Ceera|r
.goto 2393,50.81,65.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ceera|r |cRXP_WARN_inside the bank|r.
.complete 86735,4 
.target Ceera
.skipgossipid 134013
.skipgossipid 132676
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Skymaster of Silvermoon|r
.goto 2393,50.98,71.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Skymaster of Silvermoon|r.
.complete 86735,3 
.target the Skymaster of Silvermoon
.skipgossipid 134010
.skipgossipid 132674
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2393,52.46,78.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r |cRXP_WARN_inside a building|r.
.complete 86735,5 
.target Valeera Sanguinar
.skipgossipid 133099
step
#completewith next
#label PavedInAshB
#arrowtext Enter the portal room
.goto 2393,53.24,66.16,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Narinth|r.
.complete 86735,2 
.target Magistrix Narinth
.skipgossipid 134011
step
#completewith PavedInAshB
#arrowtext Enter the portal room
.goto 2393,52.64,65.20,25 >>Follow the Arrow
step
#requires PavedInAshB
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Narinth|r
.goto 2393,52.64,65.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Narinth|r.
.complete 86735,2 
.target Magistrix Narinth
.skipgossipid 134011
.skipgossipid 132678
step
#completewith next
#label Wayfarer's Rest
#arrowtext Enter the inn
.goto 2393,53.26,66.16,5,0
.goto 2393,55.41,70.37,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Jovia|r |cRXP_WARN_twice|r.
.complete 86735,1 
.target Innkeeper Jovia
step
#completewith Wayfarer's Rest
.goto 2393,56.28,70.36,25 >>Enter the Inn
step
#requires Wayfarer's Rest
#arrowtext Talk to\n|cRXP_FRIENDLY_Innkeeper Jovia|r
.goto 2393,56.28,70.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Jovia|r |cRXP_WARN_twice|r.
.complete 86735,1 
.target Innkeeper Jovia
.skipgossipid 134012
.skipgossipid 132666
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Innkeeper Jovia|r
#label WhispersInTheTwilightBb
.isOnQuest 86735
.goto 2393,56.28,70.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Jovia|r.
.home >>Set your Hearthstone to Wayfarer's Rest
.target Innkeeper Jovia
.skipgossipid 134012
.skipgossipid 132666
.skipgossipid 132668
step << Alliance
#completewith next
#label Captain Goldblade
#arrowtext Leave the inn
.goto 2393,56.11,71.89,10,0
.goto 2393,56.67,70.36,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard Captain Goldblade|r.
.complete 86735,6 
.skipgossipid 132828
.target Guard Captain Goldblade
step << Alliance
#completewith Captain Goldblade
.goto 2393,60.20,70.35,100 >>Leave the Inn from the Top-Exit
step << Alliance
#requires Captain Goldblade
#arrowtext Talk to\n|cRXP_FRIENDLY_Guard Captain Goldblade|r
.goto 2393,60.20,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard Captain Goldblade|r.
.complete 86735,6 
.skipgossipid 132828
.target Guard Captain Goldblade
step << Horde
#completewith next
#label Captain Goldblade
#arrowtext Leave the inn
.goto 2393,56.11,71.89,10,0
.goto 2393,56.67,70.36,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Nizara|r.
.complete 86735,6 
.target Magistrix Nizara
.skipgossipid 134014
step << Horde
#completewith Captain Goldblade
.goto 2393,60.20,70.35,100 >>Leave the Inn from the Top-Exit
step << Horde
#requires Captain Goldblade
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Nizara|r
.goto 2393,69.19,67.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Nizara|r.
.complete 86735,6 
.target Magistrix Nizara
.skipgossipid 134014
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r inside a building
.goto 2393,52.46,78.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r inside a building.
.complete 86735,5 
.target Valeera Sanguinar
.skipgossipid 133099
step
.goto 2393,45.45,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86735 >>Turn in Paved in Ash
.accept 86737 >>Accept Fair Breeze, Light Bloom
.target Lor'themar Theron
step
#label arcane projector
#arrowtext Click on |cRXP_PICK_Arcane Projector|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,45.32,70.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Projector|r.
.complete 86737,1 
step
.isOnQuest 94871
#label WhispersInTheTwilightC
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r
.goto 2395,46.71,45.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r.
.turnin 94871 >>Turn in Eversong
.target Magistrix Landra Dawnstrider
step
#completewith next
#label WhispersInTheTwilightCA
#arrowtext |cRXP_WARN_Leave the building|r
#hidewindow
.goto 2393,45.17,74.5,15,0
.complete 86737,3 
step
#completewith WhispersInTheTwilightCA
.goto 2395,46.71,45.75,1150 >>Leave the building
step
#requires WhispersInTheTwilightCA
.goto 2395,46.71,45.75
#title |cFFFCDC00Follow the Arrow|r
.complete 86737,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r
.goto 2395,46.71,45.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r.
.turnin 86737 >>Turn in Fair Breeze, Light Bloom
.accept 86738 >>Accept Sharpmaw
.accept 86739 >>Accept Fairbreeze Favors
.target Magistrix Landra Dawnstrider
step
#label DisplacedDenizensA
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,46.66,45.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 86740 >>Accept Displaced Denizens
.target Orweyna
step
#completewith WhispersInTheTwilightD
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
#completewith WhispersInTheTwilightD
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
#completewith WhispersInTheTwilightD
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#arrowtext Citizens helped (1/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,46.52,45.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Pet|r.
.complete 86739,4,1 
.target Injured Pet
step
#arrowtext Bush investigated (1/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.21,46.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,1,1 
step
#arrowtext Plants examined (1/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.64,46.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_plant|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,2,1 
step
.goto 2395,45.82,47.9
#title |cFFFCDC00Follow the Arrow|r
.complete 86738,1 
step
.goto 2395,45.82,47.9
#arrowtext Click on the\n|cRXP_PICK_Sharpmaw|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Sharpmaw|r.
.complete 86738,2 
.target Sharpmaw
step
#arrowtext Plants examined (2/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,45.60,46.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Plant|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,2,2 
step
#arrowtext Nest investigated (2/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,45.50,46.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nest|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,1,2 
step
#arrowtext Chair investigated (2/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,45.94,45.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chair|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,1,3 
step
#completewith next
#label Mr. Fluffy
#hidewindow
.complete 86739,4,2 
step
#completewith Mr. Fluffy
.goto 2395,45.64,45.47
#arrowtext Cat helped (2/3)\n|cFFFCDC00(Read Note)|r
.cast 1234073 >>Click on |cRXP_PICK_Mr. Fluff|r on the statue.
step
#requires Mr. Fluffy
#arrowtext Citizens helped (3/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,44.72,44.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tomes|r.
.complete 86739,4,3 
step
#label WhispersInTheTwilightD
#arrowtext Plants examined (3/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,44.83,44.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Plant|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,2 
step
#label WhispersInTheTwilightE
#hidewindow
#completewith Hawkstriders shooed
#loop
.goto 2395,44.5,43.84,40,0
.goto 2395,45.29,43.52,40,0
.goto 2395,45.95,44.56,40,0
.goto 2395,46.39,45.6,40,0
.goto 2395,46.81,44.78,40,0
.goto 2395,47.36,46.57,40,0
.goto 2395,46.29,46.83,40,0
+1
step
#completewith Erratic Light Wyrm
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r
.complete 86739,2 
.target Displaced Hawkstrider
step
#completewith Erratic Light Wyrm
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#label Erratic Light Wyrm
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
#completewith next
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
#arrowtext Click on the\n|cRXP_PICK_Displaced Lynx|r
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#label Hawkstriders shooed
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
#label WhispersInTheTwilightEA
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r
.goto 2395,46.71,45.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r.
.turnin 86738 >>Turn in Sharpmaw
.turnin 86739 >>Turn in Fairbreeze Favors
.target Magistrix Landra Dawnstrider
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,46.66,45.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86740 >>Turn in Displaced Denizens
.accept 86741 >>Accept Lightbloom Looming
.target Orweyna
step
#label WhispersInTheTwilightF
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,46.66,45.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86741,1 
.target Orweyna
.skipgossipid 133725
step
#label WhispersInTheTwilightG
.goto 2395,41.67,47.44
#arrowtext |cFFFCDC00Follow the Arrow|r\n|cRXP_ENEMY_EVERY CHARACTER SEPARATELY|r
*|cRXP_WARN_NOTE:|r If a character sits on a another persons mount then he will get stuck and you have to relog.
.complete 86741,2 
step
.goto 2395,39.72,49.67
#arrowtext |cFFFCDC00Follow the Arrow|r\n|cRXP_ENEMY_EVERY CHARACTER SEPARATELY|r
*|cRXP_WARN_NOTE:|r If a character sits on a another persons mount then he will get stuck and you have to relog.
.complete 86741,3 
.complete 86741,4 
step
.goto 2395,39.73,50.79
>>Kill |cRXP_ENEMY_Lightbloom Monstrosity|r.
.complete 86741,5 
.mob Lightbloom Monstrosity
step
.goto 2395,39.67,51.55
#title |cFFFCDC00Follow the Arrow|r
.complete 86741,6 
.timer 5.5,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,39.67,51.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_after a roleplay|r.
.turnin 86741 >>Turn in Lightbloom Looming
.accept 86743 >>Accept Trimming the Lightbloom
.accept 86742 >>Accept Curious Cultivation
.target Orweyna
step
#completewith SojournerCampaignTrail
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86743,1 
.mob Lightbloom Lasher
.mob Light Wyrm
.mob Lightbloom Petalwing
.mob Lightbloom Hydra
.mob Lightfed Growth
step
#arrowtext Growths examined (1/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,40.71,53.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightbloom Flower Growth|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86742,1,1 
step
#label SojournerCampaignGrowth
#arrowtext Growths examined (2/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,40.07,55.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Infested Lynx|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86742,1,2 
.mob Infested Lynx
step
#label SojournerCampaignGrowth2
#arrowtext Growths examined (3/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,42.27,55.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Magister|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86742,1 
.target Lightbloated Magister
step
.goto 2395,43.85,56.55
#title |cFFFCDC00Follow the Arrow|r
.complete 86742,2 
step
#label CuriousCultivationA
.goto 2395,43.85,56.55
>>Kill |cRXP_ENEMY_Lightblinded Rutaani Grovewarden|r.
*Loot it for the |T656439:0|t[|cRXP_LOOT_Light-pulsing Seed|r].
.complete 86742,3 
.complete 86742,4 
.mob Lightblinded Rutaani Grovewarden
step
#label SojournerCampaignTrail
.goto 2395,45.74,55.61
#title |cFFFCDC00Follow the Arrow|r
.complete 86742,5 
.timer 13.2,RP
step
#loop
.goto 2395,44.78,54.72,40,0
.goto 2395,43.86,53.85,40,0
.goto 2395,43.46,56.04,40,0
.goto 2395,42.78,57.91,40,0
.goto 2395,44.74,59,40,0
.goto 2395,45.21,56.93,40,0
.goto 2395,41.28,55.31,60,0
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86743,1 
.mob Lightbloom Lasher
.mob Light Wyrm
.mob Lightbloom Petalwing
.mob Lightbloom Hydra
.mob Lightfed Growth
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.89,55.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_after the roleplay|r.
.turnin 86742 >>Turn in Curious Cultivation
.turnin 86743 >>Turn in Trimming the Lightbloom
.accept 86744 >>Accept Seeking Truth
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.89,55.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86744,1 
.target Orweyna
.skipgossipid 132833
step
.goto 2395,46.1,55.11
>>Kill |cRXP_ENEMY_Lightfused|r.
.complete 86744,2 
.timer 18,RP
.mob Lightfused Defender
.mob Lightfused Leafmancer
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,47.36,55.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_after the roleplay|r.
.turnin 86744 >>Turn in Seeking Truth
.target Orweyna
step
#label Contact Silvermoon
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,47.35,55.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86745 >>Accept Silvermoon Must Know
.complete 86745,1 
.target Arator

.skipgossipid 136284 
step
#label WhispersInTheTwilightZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,47.35,55.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86745 >>Turn in Silvermoon Must Know
.accept 86621 >>Accept The Wayward Magister
.target Arator
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Shadowfall
#internal
step
#optional
.isQuestAvailable 86745
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label ShadowfallA
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,47.35,55.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86621 >>Accept The Wayward Magister
.target Arator
step
#label SojournerCampaignShadowfall1
.goto 2395,49.24,58.94
#title |cFFFCDC00Follow the Arrow|r
.complete 86621,1 
step
#arrowtext Click on the |cRXP_PICK_Corpse|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,49.24,58.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Corpse|r.
.complete 86621,3 
step
.goto 2395,47.69,69.79
#title |cFFFCDC00Follow the Arrow|r
.complete 86621,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,47.69,69.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86621 >>Turn in The Wayward Magister
.accept 86623 >>Accept Appeal to the Void
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,47.68,69.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86624 >>Accept Rational Explanation
.target Arator
step
#arrowtext Click on |cRXP_PICK_Flyer|r (10%)\n|cFFFCDC00(Read Note)|r
.goto 2395,48.84,69.50
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2,10 
step
#arrowtext Townsfolk questioned (1/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,48.86,69.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Belonis|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,1,1 
.target Ranger Belonis
.skipgossipid 132894
step
#arrowtext Click on the |cRXP_PICK_Book|r (25%)\n|cFFFCDC00(Read Note)|r
.goto 2395,48.85,69.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2,25 
step
#arrowtext Click on the |cRXP_PICK_Focus|r.
.goto 2395,48.87,72.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Umbric's Channeling Focus|r.
*Kill |cRXP_ENEMY_Coalescing Shadows|r and |cRXP_ENEMY_Seeping Darkness|r.
.complete 86623,1 
.mob Coalescing Shadow
.mob Seeping Darkness
step
#arrowtext Click on the |cRXP_PICK_Focus|r.
.goto 2395,46.75,71.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Umbric's Channeling Focus|r.
*Kill |cRXP_ENEMY_Coalescing Shadows|r and |cRXP_ENEMY_Looming Darkness|r.
.complete 86623,2 
.mob Coalescing Shadow
.mob Looming Darkness
step
#arrowtext Click on the |cRXP_PICK_Focus|r.
.goto 2395,45.42,67.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Umbric's Channeling Focus|r.
*Kill |cRXP_ENEMY_Coalescing Shadows|r and |cRXP_ENEMY_Spiraling Darkness|r.
.complete 86623,3 
.mob Coalescing Shadow
.mob Spiraling Darkness
step
#arrowtext Click on the |cRXP_PICK_Book|r (40%)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.73,65.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFBook|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2,40 
step
#arrowtext Townsfolk questioned (2/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.71,65.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Matron Narsilla|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,1,2 
.skipgossipid 133913
.target Matron Narsilla
step
#arrowtext Click on the |cRXP_PICK_Leaflets|r (50%)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.84,65.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFLeaflet|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2,50 
step
#arrowtext Click on the |cRXP_PICK_Scrolls|r (60%)\n|cFFFCDC00(Read Note)|r
.goto 2395,48.7,66.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFScroll|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2,60 
step
#arrowtext Click on the |cRXP_PICK_Chest|r (75%)\n|cFFFCDC00(Read Note)|r
.goto 2395,48.91,66.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFCrate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2,75 
step
#arrowtext Townsfolk questioned (3/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,48.93,66.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quartermaster Lymel|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,1,3 
.target Quartermaster Lymel
.skipgossipid 133888
step
#arrowtext Click on the |cRXP_PICK_Books|r (85%)\n|cFFFCDC00(Read Note)|r
.goto 2395,49.16,67.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFNotes|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2,85 
step
#completewith next
#label RationalExplanationA
#arrowtext Enter the house
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quartermaster Lymel|r.
.complete 86624,1 
.target Quartermaster Lymel
.skipgossipid 133888
step
#completewith RationalExplanationA
#arrowtext Enter house
.goto 2395,49.28,67.57,6 >>|cRXP_WARN_Enter the House|r
step
#requires RationalExplanationA
#arrowtext Townsfolk questioned (4/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,49.32,67.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard Captain Leonic|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,1 
.target Guard Captain Leonic
.skipgossipid 132706
step
#label SojounerCampaignMagister
#arrowtext Click on the |cRXP_PICK_Book|r (100%)\n|cFFFCDC00(Read Note)|r
.goto 2395,49.44,67.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFBook|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86624,2 
step
#completewith next
#label RationalExplanationB
#hidewindow
#arrowtext Enter the inn
.goto 2395,49.25,67.6,5,0
.goto 2395,48.96,68.41,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Kalarin|r.
.complete 86624,3 
.complete 86624,4 
.target Innkeeper Kalarin
.skipgossipid 132744
step
#completewith RationalExplanationB
.goto 2395,48.96,68.58,10 >>Enter the Inn
step
#requires RationalExplanationB
#arrowtext Talk to\n|cRXP_FRIENDLY_Innkeeper Kalarin|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,48.96,68.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Kalarin|r.
.complete 86624,3 
.target Innkeeper Kalarin
.skipgossipid 132744
step
#completewith next
#label RationalExplanationE
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Journal|r.
.complete 86624,4 
step
#completewith RationalExplanationE
#arrowtext Leave the inn
.goto 2395,48.95,68.33,6 >>|cRXP_WARN_Leave the Inn|r
step
#requires RationalExplanationE
#arrowtext |cRXP_WARN_On the second floor|r\nClick on the |cRXP_PICK_Journal|r
.goto 2395,49.00,68.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Journal|r.
.complete 86624,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,47.68,69.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86624 >>Turn in Rational Explanation
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,47.69,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86623 >>Turn in Appeal to the Void
.accept 90907 >>Accept The First to Know
.target Magister Umbric
step
#completewith next
#label TheFirstToKnowA
#arrowtext |cFFFCDC00Follow the Arrow|r
#hidewindow
.complete 90907,1 
step
#completewith TheFirstToKnowA
#arrowtext Enter building
.goto 2395,47.31,68.30,6 >>|cRXP_WARN_Enter the building|r.
step
#requires TheFirstToKnowA
.goto 2395,47.28,68.30
#arrowtext |cFFFCDC00Follow the Arrow|r
.complete 90907,1 
.timer 5,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Secretary Faloria|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.19,68.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Secretary Faloria|r |cRXP_WARN_after the roleplay|r.
.complete 90907,2 
.target Secretary Faloria
.skipgossipid 132741
step
#arrowtext Click on the |cRXP_PICK_Crate|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.14,68.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
.complete 90907,3 
.timer 10,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lord Antenorian|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.20,68.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Antenorian|r.
.complete 90907,4 
.target Lord Antenorian
.skipgossipid 134001
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lord Antenorian|r
.goto 2395,47.20,68.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Antenorian|r.
.turnin 90907 >>Turn in The First to Know
.accept 86622 >>Accept Chance Meeting
.target Lord Antenorian
step
#completewith next
#label ChanceMeetingA
#arrowtext |cFFFCDC00Follow the Arrow|r
#hidewindow
.complete 86622,1 
step
#completewith ChanceMeetingA
#arrowtext Leave the building
.goto 2395,47.37,68.29,6 >>|cRXP_WARN_Leave the building|r
step
#requires ChanceMeetingA
.goto 2395,46.76,63.57
#title |cFFFCDC00Follow the Arrow|r
.complete 86622,1 
step
#arrowtext Kill |cRXP_ENEMY_Cultist Ambusher|r
.goto 2395,46.72,63.92
>>Kill |cRXP_ENEMY_Cultist Ambusher|r.
*Loot him for the |T4549181:0|t[|cRXP_LOOT_Suspicious Missive|r].
.complete 86622,2 
.complete 86622,3 
.mob Cultist Ambusher
step
#completewith next
#label ChanceMeetingB
#arrowtext Enter the building
.goto 2395,47.74,69.65,6,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86622 >>Turn in Chance Meeting
.target Arator
step
#completewith ChanceMeetingB
.goto 2395,47.71,69.70,5 >>|cRXP_WARN_Enter the building|r
step
#requires ChanceMeetingB
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,47.71,69.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86622 >>Turn in Chance Meeting
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,47.71,69.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 86626 >>Accept The Ransacked Lab
.target Magister Umbric
step
#completewith next
#label Void Samples1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r underneath the paper.
.complete 86626,1,1 
step
#completewith Void Samples1
#arrowtext |cFFFCDC00Correct Paper|r
.goto 2395,47.7,69.92
.cast 1286603 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_WARN_correct|r |cRXP_PICK_Paper Stack|r.
step
#requires Void Samples1
#arrowtext Click on the |cRXP_PICK_Shard|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.7,69.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r underneath the paper.
.complete 86626,1,1 
step
#completewith next
#label Void Samples2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r underneath the paper.
.complete 86626,1,2 
step
#completewith Void Samples2
#arrowtext |cFFFCDC00Correct Paper|r
.goto 2395,47.6,69.82
.cast 1286603 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_WARN_correct|r |cRXP_PICK_Paper Stack|r.
step
#requires Void Samples2
#arrowtext Click on the |cRXP_PICK_Shard|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.6,69.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r underneath the paper.
.complete 86626,1,2 
step
#completewith next
#label Void Samples3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r underneath the paper.
.complete 86626,1,3 
step
#completewith Void Samples3
#arrowtext |cFFFCDC00Correct Paper |r
.goto 2395,47.66,69.7
.cast 1286603 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_WARN_correct|r |cRXP_PICK_Paper Stack|r.
step
#requires Void Samples3
#arrowtext Click on the |cRXP_PICK_Shard|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.66,69.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r underneath the paper.
.complete 86626,1,3 
step
.goto 2395,47.77,69.86
#arrowtext Click on the\n|cRXP_PICK_Pendant|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pendant|r on the table.
.complete 86626,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,47.72,69.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86626 >>Turn in The Ransacked Lab
.accept 86632 >>Accept The Battle for Tranquillien
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,47.69,69.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 90509 >>Accept The Traitors of Tranquillien
.accept 90493 >>Accept The Heart of Tranquillien
.target Arator
step
#completewith TheHeartOfTranquillienB
>>Kill |cRXP_ENEMY_Twilight's Blade forces|r
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r
.complete 86632,1 
.mob Twilight's Blade Adherent
.mob Unfettered Shadow
.mob Twilight's Blade Recruit
step
#completewith next
#label TheHeartOfTranquillienA
#arrowtext Leave the building
.goto 2395,47.78,69.58,6,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Citizen|r.
.complete 90493,1,1 
.target Tranquillien Citizen
step
#completewith TheHeartOfTranquillienA
.goto 2395,47.72,69.32,19 >>|cRXP_WARN_Leave the building|r
step
#requires TheHeartOfTranquillienA
#arrowtext Citizens rescued (1/8)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.72,69.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Citizen|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90493,1,1 
.target Tranquillien Citizen
step
#arrowtext Citizens rescued (2/8)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.63,67.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Citizen|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90493,1,2 
.target Tranquillien Citizen
step
#arrowtext Kill |cRXP_ENEMY_Ranger Lethvalin|r
.goto 2395,47.61,67.56
>>Kill |cRXP_ENEMY_Ranger Lethvalin|r.
.complete 90509,1 
.mob Ranger Lethvalin
step
#arrowtext Citizens rescued (4/8)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.45,67.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Citizens|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90493,1,4 
.target Eralan
.target Pathstalker Lontral
.target Dame Auriferous
step
#arrowtext Kill |cRXP_ENEMY_Matron Narsilla|r
.goto 2395,47.72,65.19
>>Kill |cRXP_ENEMY_Matron Narsilla|r.
.complete 90509,2 
.mob Matron Narsilla
step
#arrowtext Citizens rescued (5/8)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.79,65.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Eralan|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90493,1,5 
.target Eralan
step
#arrowtext Citizens rescued (6/8)\n|cFFFCDC00(Read Note)|r
.goto 2395,48.80,66.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Paniar|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90493,1,6 
.target Paniar
step
#completewith next
#label TheTraitorsOfTranquillienA
>>Kill |cRXP_ENEMY_Guard Captain Leonic|r.
.complete 90509,3 
.mob Guard Captain Leonic
step
#completewith TheTraitorsOfTranquillienA
#arrowtext Enter the building
.goto 2395,49.38,67.45,15 >>|cRXP_WARN_Enter the building|r
step
#requires TheTraitorsOfTranquillienA
#arrowtext Kill |cRXP_ENEMY_Guard Captain Leonic|r
.goto 2395,49.38,67.45
>>Kill |cRXP_ENEMY_Guard Captain Leonic|r.
.complete 90509,3 
.mob Guard Captain Leonic
step
#label TheHeartOfTranquillienB
#arrowtext Citizens rescued (8/8)\n|cFFFCDC00(Read Note)|r
.goto 2395,49.39,67.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Provisioner Vredigar|r and |cRXP_PICK_Master Chef Mouldier|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90493,1 
.target Provisioner Vredigar
.target Master Chef Mouldier
step
#loop
.goto 2395,49.2,67.65,5,0
.goto 2395,49.11,68.33,40,0
.goto 2395,48.49,67.47,40,0
.goto 2395,47.57,67.57,40,0
.goto 2395,48.01,69.64,40,0
.goto 2395,48.79,66.64,40,0
.goto 2395,48.82,65.69,40,0
.goto 2395,48.4,65.55,40,0
.goto 2395,48.16,66.44,40,0
.goto 2395,47.7,65.73,40,0
>>Kill the |cRXP_ENEMY_Twilight's Blade forces|r |cRXP_WARN_and ignore |cRXP_PICK_Objects|r|r.
.complete 86632,1 
.mob Twilight's Blade Adherent
.mob Unfettered Shadow
.mob Twilight's Blade Recruit
step
#completewith next
#label BattleTraitorsHeartTranquillienA
#arrowtext Enter the building
.goto 2395,48.95,68.46,6,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86632 >>Turn in The Battle for Tranquillien
.turnin 90509 >>Turn in The Traitors of Tranquillien
.turnin 90493 >>Turn in The Heart of Tranquillien
.accept 90494 >>Accept The Missing Magister
.target Arator
step
#completewith BattleTraitorsHeartTranquillienA
.goto 2395,48.95,68.52,10 >>|cRXP_WARN_Enter the building|r
step
#requires BattleTraitorsHeartTranquillienA
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,48.95,68.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86632 >>Turn in The Battle for Tranquillien
.turnin 90509 >>Turn in The Traitors of Tranquillien
.turnin 90493 >>Turn in The Heart of Tranquillien
.accept 90494 >>Accept The Missing Magister
.target Arator
step
#completewith next
#label TheMissingMagisterA
#arrowtext Leave the building
#hidewindow
.goto 2395,48.95,68.33,8,0
.complete 90494,1 
.target Magister Umbric
step
#completewith TheMissingMagisterA
#arrowtext Leave the building
.goto 2395,47.18,68.32,166 >>|cRXP_WARN_Leave the building|r
step
#requires TheMissingMagisterA
.goto 2395,47.18,68.32
#title |cFFFCDC00Enter the building|r
.complete 90494,1 
.target Magister Umbric
step
#arrowtext Kill |cRXP_ENEMY_Secretary Faloria|r
.goto 2395,47.18,68.32
>>Kill |cRXP_ENEMY_Secretary Faloria|r.
*Loot her for the |T134242:0|t[|cRXP_LOOT_Jeweled Key|r].
.complete 90494,2 
.complete 90494,3 
.mob Secretary Faloria
step
#arrowtext Click on the |cRXP_PICK_Crate|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.13,68.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.complete 90494,4 
step
#completewith next
#label TheMissingMagisterB
#arrowtext |cRXP_WARN_Leave the building|r
.goto 2395,47.35,68.31,9,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 90494 >>Turn in The Missing Magister
.accept 86781 >>Accept Face the Past
.disablecheckbox
.target Magister Umbric
step
#completewith TheMissingMagisterB
#arrowtext |cRXP_WARN_Leave the building|r
.goto 2395,47.71,69.77,98 >>Leave the building
step
#requires TheMissingMagisterB
#label SojounerCampaignMagister2
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,47.71,69.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r |cRXP_WARN_inside the building|r.
.turnin 90494 >>Turn in The Missing Magister
.accept 86781 >>Accept Face the Past
.target Magister Umbric
step
#completewith next
#label Windrunner Village
#hidewindow
.complete 86781,2 
step
#completewith Windrunner Village
#label ShadowfallB
#arrowtext |cRXP_WARN_Leave the building|r
.goto 2395,47.79,69.55,6 >>|cRXP_WARN_Leave the building|r
step
#requires Windrunner Village
#label ShadowfallC
.goto 2395,36.99,74.01
#title |cFFFCDC00Follow the Arrow|r
.complete 86781,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,36.99,74.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86781 >>Turn in Face the Past
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,36.98,74.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86634 >>Accept The Past Keeps Watch
.target Arator
step
#arrowtext Click on the |cRXP_PICK_Construct|r\n|cFFFCDC00Spam Mount during cast|r\n|cRXP_ENEMY_(Read note if grouped)|r
#loop
.goto 2395,36.52,72.43,20,0
.goto 2395,35.65,72.22,20,0
.goto 2395,35.75,73.97,20,0
.goto 2395,36.10,75.41,20,0
.goto 2395,37.4,75.82,20,0
.goto 2395,38.13,75.24,20,0
.goto 2395,38.50,73.67,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Construct|r.
*|cRXP_WARN_NOTE:|r You can click on the |cRXP_PICK_Constructs|r while sitting on another persons mount.
.complete 86634,1 
.target Decrepit Ranger Construct
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,36.98,74.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86634 >>Turn in The Past Keeps Watch
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,36.99,74.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 86633 >>Accept Comprehend the Void
.target Magister Umbric
step
.goto 2395,37.43,74.70
#arrowtext On the second floor\n|cFFFCDC00Follow the arrow|r
>>Follow the Arrow
.complete 86633,1 
step
#completewith next
#label ComprehendTheVoidA
#arrowtext Shards subsumed (1/4)
>>Bring a |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3,1 
step
#completewith ComprehendTheVoidA
#arrowtext Click on a |cRXP_PICK_Void Shard|r
#loop
.goto 2395,37.31,74.43,6,0
.goto 2395,37.56,74.62,6,0
.goto 2395,37.49,75.11,6,0
.goto 2395,37.12,74.88,6,0
.cast 1286607 >>Click on a |cRXP_PICK_Void Shard|r.
step
#requires ComprehendTheVoidA
#arrowtext Shards subsumed (1/4)
.goto 2395,37.39,74.72
>>Bring the |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3,1 
step
#completewith next
#label ComprehendTheVoidB
#arrowtext Shards subsumed (2/4)
>>Bring a |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3,2 
step
#completewith ComprehendTheVoidB
#arrowtext Click on a |cRXP_PICK_Void Shard|r
#loop
.goto 2395,37.56,74.62,6,0
.goto 2395,37.49,75.11,6,0
.goto 2395,37.12,74.88,6,0
.goto 2395,37.31,74.43,6,0
.cast 1286607 >>Click on a |cRXP_PICK_Void Shard|r.
step
#requires ComprehendTheVoidB
#arrowtext Shards subsumed (2/4)
.goto 2395,37.39,74.72
>>Bring the |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3,2 
step
#completewith next
#label ComprehendTheVoidC
#arrowtext Shards subsumed (3/4)
>>Bring a |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3,3 
step
#completewith ComprehendTheVoidC
#arrowtext Click on a |cRXP_PICK_Void Shard|r
#loop
.goto 2395,37.49,75.11,6,0
.goto 2395,37.12,74.88,6,0
.goto 2395,37.31,74.43,6,0
.goto 2395,37.56,74.62,6,0
.cast 1286607 >>Click on a |cRXP_PICK_Void Shard|r.
step
#requires ComprehendTheVoidC
#arrowtext Shards subsumed (3/4)
.goto 2395,37.39,74.72
>>Bring the |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3,3 
step
#completewith next
#label ComprehendTheVoidD
#arrowtext Shards subsumed (4/4)
>>Bring a |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3 
step
#completewith ComprehendTheVoidD
#arrowtext Click on a |cRXP_PICK_Void Shard|r
#loop
.goto 2395,37.12,74.88,6,0
.goto 2395,37.31,74.43,6,0
.goto 2395,37.56,74.62,6,0
.goto 2395,37.49,75.11,6,0
.cast 1286607 >>Click on a |cRXP_PICK_Void Shard|r.
step
#requires ComprehendTheVoidD
#arrowtext Shards subsumed (4/4)
.goto 2395,37.39,74.72
>>Bring the |cRXP_PICK_Void Shard|r back to the middle.
.complete 86633,3 
.timer 6.5,Umbric Roleplay
step
#label SojournerCampaignDeatholme
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,37.33,74.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86633 >>Turn in Comprehend the Void
.accept 86635 >>Accept To Deatholme
.target Magister Umbric
step
#label SojournerCampaignDeatholme2
.goto 2395,44.34,84.71
#arrowtext |cRXP_ENEMY_DISMOUNT BEFORE|r\n|cFFFCDC00Follow the Arrow|r
*|cRXP_WARN_NOTE:|r If a character sits on a mount of another character then he will get stuck and you have to relog.
.complete 86635,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r\n|cRXP_ENEMY_DISMOUNT|r
.goto 2395,44.34,84.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r.
*|cRXP_WARN_NOTE:|r If a character sits on a mount of another character then he will get stuck and you have to relog.
.complete 86635,2 
.target Valeera Sanguinar

.multibox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r\n|cRXP_ENEMY_DISMOUNT|r
.goto 2395,44.34,84.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r.
.complete 86635,2 
.target Valeera Sanguinar
.skipgossipid 136049
.singlebox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,44.34,84.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86635 >>Turn in To Deatholme
.accept 86636 >>Accept Void Walk With Me
.target Magister Umbric
step
#label ShadowfallY
.isOnQuest 86636
.isQuestNotComplete 86636
.goto 2395,45.54,86.29
>>Enter |cRXP_PICK_The Shadow Enclave|r Delve at Tier 1.
.complete 86636,1 
step
#include RestedXP Midnight\a) The Shadow Enclave
step
#label ShadowfallZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,44.65,85.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86636 >>Turn in Void Walk With Me
.target Magister Umbric
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Ripple Effects
#internal
step
#optional
.isQuestAvailable 86636
+|cRXP_WARN_You have to do the "Shadowfall" Chapter first|r
.clicknext RestedXP Midnight\a) Shadowfall (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Shadowfall (H) >>CLICK HERE FOR GUIDE << Horde
step
#label RippleEffectsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,44.64,85.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86637 >>Accept Anything but Reprieve
.target Arator
step
#label RippleEffectsB
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,44.64,85.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.complete 86637,1 
.skipgossipid 133785
step
#label RippleEffectsBA
#label RippleEffectsBA
#arrowtext Talk to |cRXP_FRIENDLY_Lady Liadrin|r\nand |cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Arator|r.
.turnin 86637 >>Turn in Anything but Reprieve
.accept 86639 >>Accept What's Left
.goto 2395,52.67,61.55
.target +Lady Liadrin
.accept 86638 >>Accept Choking Tendrils
.goto 2395,52.65,61.59
.target +Arator
step
#label RippleEffectsC
#completewith WhatsLeftA
>>Kill |cRXP_ENEMY_Lightblooms|r and |cRXP_ENEMY_Bloom Propagator|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Survivors|r and |cRXP_PICK_Choking Roots|r.
.complete 86638,1 
.mob Bloom Propagator
.mob Bloom Dominator
.mob Incubating Lasher
.mob Lightfrenzied Lasher
.mob Infused Seedling
.mob Lucent Hookbeak
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Silanna|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,54.67,60.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Silanna|r.
.complete 86639,3 
.target Magistrix Silanna
.skipgossipid 132680
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Apprentice Erilia|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,53.54,59.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Erilia|r |cRXP_WARN_inside the building|r.
.complete 86639,2 
.target Apprentice Erilia
.skipgossipid 132652
step
#loop
.goto 2395,54.15,59.35,20,0
.goto 2395,54.53,59.12,20,0
.goto 2395,54.37,58.59,20,0
.goto 2395,53.84,58.57,20,0
.goto 2395,54.6,58.11,20,0
.goto 2395,54.93,58.8,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Suncrown Survivor|r
.complete 86639,1,7 
.target Suncrown Survivor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Trainee Solanin|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,54.85,57.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trainee Solanin|r |cRXP_WARN_inside the building|r.
.complete 86639,5 
.target Trainee Solanin
.skipgossipid 132684
step
#completewith next
#label Suncrown
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Suncrown Survivor|r
.complete 86639,1,10 
.target Suncrown Survivor
step
#completewith Suncrown
.goto 2395,55.52,58.07,15 >>Enter the building through the middle floor.
step
#requires Suncrown
.goto 2395,55.68,58.3,10,0
.goto 2395,55.71,58.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Suncrown Survivor|r
.complete 86639,1,10 
.target Suncrown Survivor
step
#label WhatsLeftA
#arrowtext |cFFFCDC00On the second floor|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,55.86,57.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Outrunner Alarion|r.
.complete 86639,4 
.target Outrunner Alarion
.skipgossipid 135781
step
#loop
.goto 2395,55.05,59.68,40,0
.goto 2395,54.04,60.02,40,0
.goto 2395,53.46,57.06,40,0
.goto 2395,53.35,58.46,40,0
>>Kill the |cRXP_ENEMY_Lightblooms|r and |cRXP_ENEMY_Bloom Propagator|r.
#arrowtext Click on the\n|cRXP_PICK_Survivors|r and |cRXP_PICK_Choking Roots|r
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Survivors|r and |cRXP_PICK_Choking Roots|r.
.complete 86638,1 
.target Suncrown Survivor
.mob Bloom Propagator
.mob Bloom Dominator
.mob Incubating Lasher
.mob Lightfrenzied Lasher
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Arator|r.
.turnin 86639 >>Turn in What's Left
.goto 2395,53.60,54.60
.target Lady Liadrin
.turnin 86638 >>Turn in Choking Tendrils
.goto 2395,53.55,54.63
.target +Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2395,53.50,54.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 86640 >>Accept Premonition
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2395,59.18,51.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86640 >>Turn in Premonition
.accept 86641 >>Accept Old Scars
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,59.13,51.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86642 >>Accept A Foe Unseen
.target Arator
step
#completewith AFoeUnseenA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Structures|r.
>>Kill the |cRXP_ENEMY_Amani forces|r.
.complete 86641,1 
.mob Amani Feller
.mob Amani Watcher
.mob Amani Enforcer
step
#arrowtext |cFFFCDC00Follow the Arrow|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,60.76,51.85
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86642,1,1 
step
#arrowtext Operations investigated (2/5)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,60.63,52.40
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86642,1,2 
step
#arrowtext Operations investigated (3/5)\n|cFFFCDC00(Read Note)|r
.goto 2395,63.01,53.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Amani|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86642,1,3 
step
#arrowtext Operations investigated (4/5)\n|cFFFCDC00(Read Note)|r
.goto 2395,62.11,50.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Missive|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86642,1,4 
step
#label AFoeUnseenA
#arrowtext Operations investigated (5/5)\n|cFFFCDC00(Read Note)|r
.goto 2395,63.33,48.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lumber|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86642,1 
step
#label RippleEffectsT
#loop
.goto 2395,64.03,47.42,30,0
.goto 2395,65.04,47.9,30,0
.goto 2395,64.63,49.05,30,0
.goto 2395,63.56,51.68,30,0
.goto 2395,62.08,51.94,30,0
.goto 2395,60.43,52.34,30,0
#arrowtext Click on the\n|cRXP_PICK_Structures|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Structures|r.
>>Kill |cRXP_ENEMY_Amanis|r.
.complete 86641,1 
.mob Amani Feller
.mob Amani Watcher
.mob Amani Enforcer
step
#label RippleEffectsTA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2395,64.46,48.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86641 >>Turn in Old Scars
.target Lor'themar Theron
step
#label Foe Unseen
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,64.53,48.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86642 >>Turn in A Foe Unseen
.accept 86643 >>Accept Following the Root
.target Arator
step
#label AratorCrypts
.goto 2395,56.76,65.78,10,0
.goto 2395,56.70,65.75
#arrowtext |cFFFCDC00Follow the Arrow|r
>>Enter the Crypts
.complete 86643,1 
step
#arrowtext Totems destroyed (2/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2579,86.64,34.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totems|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86643,3,2 
step
#arrowtext Totems destroyed (3/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2579,64.75,29.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86643,3,3 
step
#arrowtext Totems destroyed (4/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2579,55.79,27.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86643,3 
.timer 3,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r\nDon't run into the fog
.goto 2579,52.39,27.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r |cRXP_WARN_after the roleplay|r.
.complete 86643,4 
.timer 27,Arator Roleplay
.target Arator
.skipgossipid 132886
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2579,43.73,30.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r |cRXP_WARN_after the roleplay|r.
.turnin 86643 >>Turn in Following the Root
.accept 86644 >>Accept Gods Before Us
.target Arator
step
.goto 2579,38.91,29.00
#arrowtext Click on the\n|cRXP_PICK_Tablet|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r.
.complete 86644,2 
step
#loop
.goto 2579,41.28,52.17,30,0
.goto 2579,42.6,41.36,8,0
.goto 2579,52.3,38.1,8,0
.goto 2579,58.21,42.01,8,0
.goto 2579,58.56,52.05,25,0
>>Kill |cRXP_ENEMY_Spawn of Shadra|r and |cRXP_ENEMY_Child of Hir'eek|r.
*Loot them for |T134298:0|t[|cRXP_LOOT_Bonecarapace Fangs|r] and |T4554435:0|t[|cRXP_LOOT_Bloodvein Clot|r].
*|cRXP_WARN_If already collected but not shown complete, skip this step|r
.collect 244143,1,86644,1,,2
.collect 244144,1,86644,1,2
.mob Spawn of Shadra
.mob Child of Hir'eek
.skipgossipid 133889
.skipgossipid 133890
step
.goto 2579,54.93,38.36,10,0
.goto 2579,38.65,28.95
#arrowtext Click on the\n|cRXP_PICK_Vases|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vases|r.
*|cRXP_WARN_If nothing happens you are missing the items|r.
.complete 86644,3 
.mob Spawn of Shadra
.mob Child of Hir'eek
.skipgossipid 133889
.skipgossipid 133890
step
.goto 2579,30.52,20.98,5,0
.goto 2579,24.7,29.65
#title |cFFFCDC00Follow the Arrow|r
.complete 86644,4 
step
#loop
.goto 2579,19.73,32.32,3,0
.goto 2579,17.56,27.75,4,0
.goto 2579,13.89,31.05,3,0
.goto 2579,16.77,31.55,3,0
.goto 2579,13.49,34.58,3,0
.goto 2579,13.13,38.04,3,0
.goto 2579,19.3,36.03,3,0
.goto 2579,18.85,39.57,3,0
.goto 2579,15.95,38.96,3,0
#arrowtext |cRXP_WARN_Memory Game!|r\nClick the |cRXP_PICK_Tile|r |cRXP_WARN_at the waypoint|r\nAvoid middle tile
>>Click the |cRXP_PICK_Tile|r marked by the waypoint.
*|cRXP_WARN_If you missclick, keep matching colors and ignore the arrow|r.
.complete 86644,5 
.target Carved Tile
step
.goto 2579,15.09,59.84
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r |cRXP_WARN_next to you|r.
.turnin 86644 >>Turn in Gods Before Us
.accept 86646 >>Accept An Impasse
.target Arator
step
#completewith next
#label Vanatha
.goto 2579,15.09,59.84,15,0
>>Kill |cRXP_ENEMY_Vanatha|r.
.complete 86646,1 
.mob Vanatha
step
#completewith Vanatha
#hidewindow
.goto 2579,24.11,61.64,30 >>Follow the Arrow
step
#requires Vanatha
.goto 2579,24.11,61.64
>>Kill |cRXP_ENEMY_Vanatha|r.
.complete 86646,1 
.mob Vanatha
step
#completewith next
#label AnImpasseA
.goto 2579,45.76,68.36,12,0
.goto 2579,44.63,67.09,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86646 >>Turn in An Impasse
.accept 86647 >>Accept Beat of Blood
.target Arator
step
#completewith AnImpasseA
#arrowtext Leave the crypt
.goto 2395,54.74,68.20,20 >>|cRXP_WARN_Leave the crypt|r.
step
#label RippleEffectsU
#requires AnImpasseA
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,54.74,68.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86646 >>Turn in An Impasse
.accept 86647 >>Accept Beat of Blood
.target Arator
step
#label RippleEffectsUA
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,55.18,81.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86647 >>Turn in Beat of Blood
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2395,55.12,81.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 86648 >>Accept Light Guide Us
.target Lor'themar Theron
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,55.55,81.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Eversong Farstrider|r.
.complete 86648,2,1 
.target Eversong Farstrider
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,55.88,81.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Eversong Spellbreaker|r.
.complete 86648,2,2 
.target Eversong Spellbreaker
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,56.07,81.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Eversong Arch Magister|r.
.complete 86648,2,3 
.target Eversong Arch Magister
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,56.22,81.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Eversong Spellbreaker|r.
.complete 86648,2,4 
.target Eversong Spellbreaker
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,57.3,81.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Veteran Blood Knight|r.
.complete 86648,2,5 
.target Veteran Blood Knight
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,57.6,81.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Blessed Lightbringer|r.
.complete 86648,2,6 
.target Blessed Lightbringer
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,58.14,81.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Eversong Magister|r.
.complete 86648,2,7 
.target Eversong Magister
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
#arrowtext Talk to |cRXP_FRIENDLY_Eversong Farstrider|r\n|cFFFCDC00Ignore banners|r\n|cRXP_ENEMY_NOT SHARED|r
.goto 2395,59,81.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Veteran Blood Knight|r.
.complete 86648,2,8 
.target Veteran Blood Knight
.skipgossipid 137985
.skipgossipid 137986
.skipgossipid 137987
.skipgossipid 137988
.skipgossipid 137989
.skipgossipid 137990
.skipgossipid 137991
.skipgossipid 137992
step
.goto 2395,59.52,81.44
#title |cFFFCDC00Follow the Arrow|r
.complete 86648,4 
step
.goto 2395,60.25,81.45
#title |cFFFCDC00Follow the Arrow|r
.complete 86648,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2395,60.25,81.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86648 >>Turn in Light Guide Us
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2395,60.23,81.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.accept 86649 >>Accept Past Redemption
.timer 6,Roleplay Duration
.target High Exarch Turalyon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Turalyon|r
.goto 2395,60.23,81.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turalyon|r.
.complete 86649,1 
.target Turalyon
.skipgossipid 132931
step
#label RippleEffectsV
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2395,60.59,81.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86649 >>Turn in Past Redemption
.accept 86650 >>Accept Fractured
.target Lor'themar Theron
step
#completewith next
#label RippleEffectsW
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar|r.
.complete 86650,1 
.target Lor'themar
step
#completewith RippleEffectsW
.hs >>Hearth to Silvermoon City
.cooldown item,6948,>0,1
.use 6948
step
#requires RippleEffectsW
#label RippleEffectsX
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar|r
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar|r.
.complete 86650,1 
.timer 50,Roleplay
.target Lor'themar
.skipgossipid 134143
step
#label RippleEffectsY
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.33
*|cRXP_WARN_Relog to skip the roleplay; saves 50seconds|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86650 >>Turn in Fractured
.target Lor'themar Theron
.macro ,Logout >>/logout
step
#label RippleEffectsZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.61,70.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89402
.accept 89402 >>Accept Harandar
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Path of Light
#internal
step
#optional
.isQuestAvailable account,86650
+|cRXP_WARN_You have to do the "Ripple Effects" Chapter first|r
.clicknext RestedXP Midnight\a) Ripple Effects (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Ripple Effects (H) >>CLICK HERE FOR GUIDE << Horde
step
#label ThePathOfLightA
#completewith Scouting Map
#hidewindow
+1
step
#completewith Scouting Map
#hidewindow
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
.acceptmap 94871
.accept 94871 >>Accept Eversong
step
#label Scouting Map
.goto 2393,45.61,70.36
#arrowtext Click on the\n|cRXP_PICK_Scouting Map|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 89193 >>Accept Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2393,45.78,65.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 89193 >>Turn in Arator
.target Alonsus Faol
.accept 86837 >>Accept Meet at the Sunwell
step
#label ThePathOfLightB
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2393,45.28,60.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.complete 86837,1 
.skipgossipid 133853
.skipgossipid 133856
.target Arator
step
#label ThePathOfLightC
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2424,52.88,55.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 86837 >>Turn in Meet at the Sunwell
.target Alonsus Faol
.accept 86838 >>Accept Renewal for the Weary
step
#completewith next
+Don't step into the sunwell you'll die.
step
#arrowtext Use|T135167:0|t[Faol's Benediction]\n on |cRXP_FRIENDLY_champions|r.\n |cRXP_WARN_Move while casting|r\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2424,52.95,45.81,10,0
.goto 2424,53.45,45.32,10,0
.goto 2424,53.51,44.55,10,0
.goto 2424,53.41,43.89,10,0
.goto 2424,52.9,43.17,10,0
.goto 2424,52.26,43.25,10,0
.goto 2424,51.85,43.72,10,0
.goto 2424,51.71,44.44,10,0
.goto 2424,51.69,45.17,10,0
.goto 2424,52.06,45.63,10,0
>>Use |T135167:0|t[Faol's Benediction] on the |cRXP_FRIENDLY_Champions|r.
*|cRXP_WARN_Move while casting|r
.complete 86838,1 
.target Taelia Fordragon
.target Valunei
.target Anduin Wrynn
.target Captain Fareeya
.target Tahu Sagewind
.target Nolaki
.target Faerin Lothar
.target Mariella Ward
.target Mehlar Dawnblade
.target Salandria
.use 237811
step
#completewith next
#label Renewal for the Weary
.goto 2424,52.63,52.21,25,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r twice.
.turnin 86838 >>Turn in Renewal for the Weary
.target Alonsus Faol
step
#completewith Renewal for the Weary
.goto 2424,52.89,55.19,65 >>Leave the sunwell
step
#requires Renewal for the Weary
#label SojournerArathor1
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2424,52.89,55.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r twice.
.turnin 86838 >>Turn in Renewal for the Weary
.accept 86839 >>Accept Relics of Light's Hope
.complete 86839,2 
.skipgossipid 138693
.target Alonsus Faol




















step
.isNotOnQuest 27527
.isQuestAvailable 38566
.isQuestAvailable account,56491
.goto 23,73.91,53.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r.
.turnin 86839 >>Turn in Relics of Light's Hope
.target Lord Maxwell Tyrosus
.accept 86840 >>Accept Flickering Hope
step << Paladin
.isNotOnQuest 27527
.isOnQuest 86839
.isQuestTurnedIn 38566
.use 140192
.cooldown item,140192,>0,1
.zone 627 >>Use Dalaran Hearthstone
*|cRXP_WARN_If you can; skip otherwise|r
.collecttoy 140192,3
step << Paladin
.isNotOnQuest 27527
.isQuestTurnedIn 38566
.isOnQuest 86839
.zoneskip 24
.goto 627,32.66,69.88 << Alliance
.goto 627,58.65,30.03,15,0 << Horde
.goto 627,61.81,13.66 << Horde
#arrowtext Click on the\n|cRXP_PICK_Portal to Sanctum of Light|r
.zone 23 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Sanctum of Light|r
.collecttoy 140192,3
step << !Paladin
.isNotOnQuest 27527
.isOnQuest 86839
.isQuestTurnedIn account,56491
.use 140192
.cooldown item,140192,>0,1
.zone 627 >>Use Dalaran Hearthstone
*|cRXP_WARN_If you can; skip otherwise|r
.collecttoy 140192,3
step << !Paladin
.isNotOnQuest 27527
.isQuestTurnedIn account,56491
.isOnQuest 86839
.goto 627,57.57,40.99,5,0
.goto 627,58.62,39.35
.zone 23 >>Talk to |cRXP_FRIENDLY_Manapoof|r
*|cRXP_WARN_Skip if you couldn't use the legion hearthstone|r
.skipgossipid 47010
.target Manapoof
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.isOnQuest 27527
#completewith next
#label Relics of Light's Hope2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r |cRXP_WARN_outside the chapel in Eastern Plaguelands|r.
.turnin 86839 >>Turn in Relics of Light's Hope
.target Lord Maxwell Tyrosus
.accept 86840 >>Accept Flickering Hope
.disablecheckbox
step
.isOnQuest 27527
#completewith Relics of Light's Hope2
.subzone 2268 >>Use |T413582:0|t[Gidwin's Hearthstone]
.use 61379
step
#requires Relics of Light's Hope2
#arrowtext Talk to\n|cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.goto 23,73.91,53.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r |cRXP_WARN_outside the chapel in Eastern Plaguelands|r.
.turnin 86839 >>Turn in Relics of Light's Hope
.target Lord Maxwell Tyrosus
.accept 86840 >>Accept Flickering Hope
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.isNotOnQuest 27527
.goto 23,73.91,53.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r |cRXP_WARN_outside the chapel in Eastern Plaguelands|r.
.turnin 86839 >>Turn in Relics of Light's Hope
.target Lord Maxwell Tyrosus
.accept 86840 >>Accept Flickering Hope
step
#label SojournerCampaignUndeads
#loop
.goto 23,74.84,55.87,30,0
.goto 23,73.06,57.64,30,0
.goto 23,71.97,49.01,30,0
.goto 23,73.48,49.21,30,0
>>Kill |cRXP_ENEMY_Undeads|r
.complete 86840,1,100 
.mob Ravaging Abomination
.mob Scourge Remnant
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.goto 23,73.90,53.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r.
.turnin 86840 >>Turn in Flickering Hope
.target Lord Maxwell Tyrosus
.accept 86841 >>Accept Relics of Paladins Past
step
.goto 23,75.71,54.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Snowcrown|r.
.turnin 8650 >>Turn in Snowcrown the Elder
.holiday Lunar Festival
.target Elder Snowcrown
step
.goto 23,75.42,52.67,5,0
.goto 24,42.85,88.04
#title |cFFFCDC00Follow the Arrow|r
.complete 86841,1 
step
#completewith next
#label Meditation Crystal
.goto 24,45.44,82.95,15,0
.goto 24,41.41,72.73,15,0
.goto 24,64.14,39.72,10,0
#arrowtext Click on the |cRXP_PICK_Crystal|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r.
.complete 86841,3 
step
#completewith Meditation Crystal
#hidewindow
.goto 24,70.32,42.05,30 >>Follow the Arrow
step
#requires Meditation Crystal
.goto 24,70.32,42.05
#arrowtext Click on the |cRXP_PICK_Crystal|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r.
.complete 86841,3 
step
.goto 24,76.23,32.45
#arrowtext Click on the |cRXP_PICK_Hammer|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hammer|r.
.complete 86841,5 
step
.goto 24,78.79,23.45
#arrowtext Click on the |cRXP_PICK_Book|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 86841,6 
step
.goto 24,72.29,14.14
#arrowtext Click on the |cRXP_PICK_Healing Kit|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Healing Kit|r.
.complete 86841,4 
step
.goto 24,60.44,27.66
#arrowtext Click on the |cRXP_PICK_Mug|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mug|r.
.complete 86841,2 
step
#completewith next
#label Relics of Paladins Past
#arrowtext Leave the chapel
.goto 24,63.94,36.45,25,0
.goto 24,41.26,74.39,10,0
.goto 24,45.76,83.74,10,0
.goto 23,75.37,52.71,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r and |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 86841 >>Turn in Relics of Paladins Past
.target +Lord Maxwell Tyrosus
.accept 86842 >>Accept Scarlet Power
.disablecheckbox
.target +Alonsus Faol
step
#completewith Relics of Paladins Past
.goto 23,73.9,53.56,65 >>Leave the chapel
step
#requires Relics of Paladins Past
#label ArathorEnd1
#arrowtext Talk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r\nand |cRXP_FRIENDLY_Alonsus Faol|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r and |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 86841 >>Turn in Relics of Paladins Past
.goto 23,73.9,53.56
.target +Lord Maxwell Tyrosus
.accept 86842 >>Accept Scarlet Power
.goto 23,73.81,53.51
.target +Alonsus Faol
step
#completewith next
#label AratorMonasteryA
#hidewindow
.complete 86842,3 
step
#completewith AratorMonasteryA
.train 131231,3
.zone 19 >>Use |T133154:0|t[Path of the Scarlet Blade]
.usespell 131231
step
#requires AratorMonasteryA
.train 131231,3
.goto 19,78.79,59.37
#title |cFFFCDC00Follow the Arrow|r
.complete 86842,3 
.usespell 131231
step
#completewith next
#label Path of the Scarlet Mitre
#hidewindow
.complete 86842,3 
step
#completewith Path of the Scarlet Mitre
.train 131229,3
.zone 19 >>Use |T133154:0|t[Path of the Scarlet Blade]
.usespell 131229
step
#requires Path of the Scarlet Mitre
.train 131229,3
.goto 19,78.79,59.37
#title |cFFFCDC00Follow the Arrow|r
.complete 86842,3 
.usespell 131229
step
.zoneskip 19
.goto 18,82.35,32.64,10,0
.goto 19,18.32,75.29
#title |cFFFCDC00Follow the Arrow|r
.complete 86842,2 
step
.goto 19,50.7,56.22,10,0
.goto 19,78.79,59.37
>>Go to Scarlet Halls
.complete 86842,3 
step
.goto 19,79.55,62.01
>>Enter the Dungeon Portal.
.complete 86842,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2438,46.97,89.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86842 >>Turn in Scarlet Power
.target Arator
step
#completewith next
#label Light Miswielded
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.accept 86843 >>Accept Light Miswielded
.target Alonsus Faol
.accept 86844 >>Accept Light Repurposed
step
#completewith Light Miswielded
#arrowtext Enter the Scarlet Halls
.zone 2438 >>Enter the Scarlet Halls
step
#requires Light Miswielded
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2438,47.33,90.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.accept 86843 >>Accept Light Miswielded
.target Alonsus Faol
.accept 86844 >>Accept Light Repurposed
step
#completewith Abbot Benthar
>>Kill |cRXP_ENEMY_Scarlets|r
.complete 86843,1 
.mob Scarlet Initiate
.mob Scarlet Footman
.mob Scarlet Cleric
.mob Scarlet Mage
step
.goto 2438,55.08,79.51
#arrowtext Kill |cRXP_ENEMY_Instructor Meyer|r
>>Kill |cRXP_ENEMY_Instructor Meyer|r
*Loot him for |T4064726:0|t[|cRXP_LOOT_Meyer's Rod of Castigation|r].
.complete 86844,1 
.mob Instructor Meyer
step
.goto 2438,61.7,67.68,10,0
.goto 2438,61.71,45.35
#arrowtext Damage |cRXP_ENEMY_Champion Aelyse|r to 30%;\n|cRXP_WARN_Hit her with every character|r
>>Damage |cRXP_ENEMY_Champion Aelyse|r to 30%.
*|cRXP_WARN_At 30% move on to |cRXP_ENEMY_Abbot Benthar|r|r
.complete 86844,2 
.mob Abbot Benthar
step
.goto 2438,39.17,15.91
#label Abbot Benthar
#arrowtext Kill |cRXP_ENEMY_Abbot Benthar|r
>>Kill |cRXP_ENEMY_Abbot Benthar|r
*Loot him for |T4280644:0|t[|cRXP_LOOT_Benthar's Scarlet Spire|r].
.complete 86844,3 
.mob Abbot Benthar
step
#loop
.goto 2438,39.18,52.69,15,0
.goto 2438,43.86,54.03,15,0
.goto 2438,48.59,54.28,10,0
.goto 2438,48.71,59.67,10,0
.goto 2438,61.73,59.79,10,0
.goto 2438,61.5,70.33,10,0
.goto 2438,52.09,87.19,10,0
>>Kill |cRXP_ENEMY_Scarlets|r
.complete 86843,1 
.mob Scarlet Initiate
.mob Scarlet Footman
.mob Scarlet Cleric
.mob Scarlet Mage
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2438,41.35,28.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 86843 >>Turn in Light Miswielded
.target Alonsus Faol
.turnin 86844 >>Turn in Light Repurposed
.accept 92136 >>Accept Infusion of Hope
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2438,41.37,28.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.complete 92136,1 
.timer 6.4,RP
.skipgossipid 132903
.target Alonsus Faol
step
.goto 2438,40.88,28.85
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 92136,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2424,52.56,55.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r
.turnin 92136 >>Turn in Infusion of Hope
.target Alonsus Faol
.accept 86902 >>Accept Relinquishing Relics
step
#completewith RemainingVelen
+Don't step into the sunwell you'll die
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Taelia Fordragon|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2424,52.93,45.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taelia Fordragon|r
.complete 86902,2 
.skipgossipid 134818
.target Taelia Fordragon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valunei|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2424,53.46,45.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valunei|r
.complete 86902,3 
.skipgossipid 134855
.target Valunei
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2424,52.07,45.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.complete 86902,4 
.skipgossipid 134853
.target Salandria
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2424,51.69,44.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.complete 86902,5 
.skipgossipid 134854
.target Mehlar Dawnblade
step
#label RemainingVelen
#arrowtext Talk to\n|cRXP_FRIENDLY_Prophet Velen|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2424,52.47,45.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prophet Velen|r
.complete 86902,6 
.skipgossipid 136038
.target Prophet Velen
step
#completewith next
#label Relinquishing Relics
#arrowtext Leave the sunwell
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 86902 >>Turn in Relinquishing Relics
.target Alonsus Faol
.accept 86845 >>Accept The Sunwalker Path
.disablecheckbox
step
#completewith Relinquishing Relics
.goto 2424,52.56,55.87,80 >>Leave the sunwell
step
#requires Relinquishing Relics
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2424,52.56,55.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 86902 >>Turn in Relinquishing Relics
.target Alonsus Faol
.accept 86845 >>Accept The Sunwalker Path
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2424,52.55,55.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.complete 86845,1 

.skipgossipid 135480
.target Alonsus Faol
step
.goto 2424,52.51,55.98
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 86845,2 
.use 257240
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sunwalker Dezco|r
.goto 2372,68.93,37.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sunwalker Dezco|r.
.turnin 86845 >>Turn in The Sunwalker Path
.target Sunwalker Dezco
.accept 91000 >>Accept A Humble Servant
.accept 86846 >>Accept Resupplying Our Suppliers
step
#completewith Mu'uta
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r; Kill pests.
.complete 91000,1,100 
.mob Disgusting Cockroach
.mob Hungry Rat
.target Injured Peon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jun'ha|r\n|cRXP_ENEMY_(NOT SHARED)|r




.goto 2372,68.72,38.06,7,0
.goto 2372,69.39,38.39,7,0
.goto 2372,69.53,37.48,7,0
.goto 2372,68.05,37.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jun'ha|r.
.complete 86846,1 
.skipgossipid 134006
.target Jun'ha
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tunkk|r\n|cRXP_ENEMY_(NOT SHARED)|r







.goto 2372,68.49,36.56,11,0
.goto 2372,67.96,36.64,11,0
.goto 2372,67.81,35.84,11,0
.goto 2372,67.38,35.31,11,0
.goto 2372,68.15,35.04,11,0
.goto 2372,68.98,35.87,11,0
.goto 2372,69.98,36.85,11,0
.goto 2372,70.08,35.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tunkk|r.
.complete 86846,3 
.skipgossipid 134008
.target Tunkk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Slagg|r\n|cRXP_ENEMY_(NOT SHARED)|r


.goto 2372,69.57,35.99,10,0
.goto 2372,69.2,34.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slagg|r.
.complete 86846,2 
.skipgossipid 134003
.target Slagg
step
#arrowtext |cRXP_WARN_Above you|r\nTalk to |cRXP_FRIENDLY_Keena|r\n|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,69.26,33.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keena|r.
.complete 86846,5 
.skipgossipid 138704
.target Keena
step
#label Mu'uta
#arrowtext Talk to\n|cRXP_FRIENDLY_Mu'uta|r\n|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,68.35,31.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mu'uta|r.
.complete 86846,4 
.skipgossipid 134042
.target Mu'uta
step
#loop





.goto 2372,69.08,31.78,20,0
.goto 2372,67.69,33,20,0
.goto 2372,70.15,33.66,20,0
#arrowtext |cRXP_ENEMY_Some objectives are\nnot shared|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r; Kill pests.
.complete 91000,1,100 
.mob Disgusting Cockroach
.mob Hungry Rat
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sunwalker Dezco|r

.goto 2372,68.54,32.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sunwalker Dezco|r.
.turnin 91000 >>Turn in A Humble Servant
.target Sunwalker Dezco
.turnin 86846 >>Turn in Resupplying Our Suppliers
.accept 89338 >>Accept Gathering Plowshares
step
#arrowtext Forgotten Skullcleaver (1/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,65.93,33.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,3,1 
step
#arrowtext Fallen Longsword (1/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,65.49,33.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,2,1 
step
#arrowtext Forgotten Skullcleaver (2/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,64.63,34.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,3,2 
step
#arrowtext Fallen Longsword (2/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,64.29,36.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,2,2 
step
#arrowtext Forgotten Skullcleaver (3/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,63.89,37.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,3,3 
step
#arrowtext Fallen Longsword (3/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,65.67,37.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,2,3 
step
#arrowtext Forgotten Skullcleaver (4/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,65.95,36.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,3,4 
step
#arrowtext Fallen Longsword (4/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r

.goto 2372,66.09,35.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89338,2,4 
step
#label ArathorEnd2
#arrowtext Talk to\n|cRXP_FRIENDLY_Sunwalker Dezco|r

.goto 2372,68.55,32.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sunwalker Dezco|r.
.turnin 89338 >>Turn in Gathering Plowshares
.target Sunwalker Dezco
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Regrets of the Past
#internal
step
#optional
.isQuestAvailable account,89338
+|cRXP_WARN_You have to do the "The Path of Light" Chapter first|r
.clicknext RestedXP Midnight\a) The Path of Light (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) The Path of Light (H) >>CLICK HERE FOR GUIDE << Horde
step
#label ArathorStart3
#arrowtext |cFFFCDC00NPC Patrols|r\nTalk to |cRXP_FRIENDLY_Alonsus Faol|r


.goto 2372,68.72,32.35,5,0
.goto 2372,68.66,32.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.accept 86822 >>Accept One Final Relic
.target Alonsus Faol
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2372,68.66,32.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.complete 86822,1 
.skipgossipid 132918
.target Alonsus Faol
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 36,33.41,48.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r |cRXP_WARN_after the roleplay|r.
.complete 86822,2 
.skipgossipid 138705
.target Alonsus Faol
step
#arrowtext Talk to |cRXP_FRIENDLY_Danath Trollbane|r\nand |cRXP_FRIENDLY_Eitrigg|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danath Trollbane|r and |cRXP_FRIENDLY_Eitrigg|r.
.turnin 86822 >>Turn in One Final Relic
.goto 36,33.45,48.61
.target +Danath Trollbane
.accept 86823 >>Accept The Dark Horde
.accept 86824 >>Accept None Left Standing
.accept 86825 >>Accept Faithful Servant, Faithless Cause
.goto 36,33.54,48.62
.target +Eitrigg
step
#completewith next
>>Kill |cRXP_ENEMY_Mar'kag|r, |cRXP_ENEMY_Ogres|r and |cRXP_ENEMY_Orcs|r.
*Loot him for |T132358:0|t[|cRXP_LOOT_Mar'kag's Buckle|r].
.complete 86825,1 
.complete 86825,2 
.complete 86823,1 
.mob Mar'kag
.mob Firegut Reaver
.mob Blackrock Sorcerer
.mob Blackrock Slayer
.mob Smolderthorn Shaman
step
#arrowtext Use |T4201760:0|t[Torch] |cRXP_WARN_on banners|r\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 36,35.52,49.17,20,0
.goto 36,36.81,50.71,20,0
.goto 36,40.5,52.27,20,0
.goto 36,45.93,51.6,20,0
.goto 36,39.34,55.12,20,0
.goto 36,35.03,55.13,20,0
>>Use |T4201760:0|t[Torch] on the Banners.
.complete 86824,1 
.use 239130
step
#loop
.goto 36,29.79,52.91,35,0
.goto 36,37.01,49.68,35,0
.goto 36,41.03,51.79,35,0
.goto 36,45.6,55.13,35,0
.goto 36,39.65,55.02,35,0
#arrowtext Kill |cRXP_ENEMY_Mar'kag|r
>>Kill |cRXP_ENEMY_Mar'kag|r, |cRXP_ENEMY_Ogres|r and |cRXP_ENEMY_Orcs|r.
*Loot him for |T132358:0|t[|cRXP_LOOT_Mar'kag's Buckle|r].
.complete 86825,1 
.complete 86825,2 
.complete 86823,1 
.mob Mar'kag
.mob Firegut Reaver
.mob Blackrock Sorcerer
.mob Blackrock Slayer
.mob Smolderthorn Shaman
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Eitrigg|r
.goto 36,33.54,48.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eitrigg|r.
.turnin 86824 >>Turn in None Left Standing
.turnin 86825 >>Turn in Faithful Servant, Faithless Cause
.turnin 86823 >>Turn in The Dark Horde
.accept 91391 >>Accept Still Scouting
.target Eitrigg
step
#label ArathorEnd3
#arrowtext Talk to\n|cRXP_FRIENDLY_Kurdran Wildhammer|r
.goto 36,21.14,39.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.turnin 91391 >>Turn in Still Scouting
.accept 86827 >>Accept Due Recognition
.accept 91842 >>Accept Disarm the Dark Horde
.accept 86826 >>Accept Nagosh the Scarred
.target Kurdran Wildhammer
step
#label ArathorStart4
#completewith WeapoRackDestroyedA
>>Kill |cRXP_ENEMY_Ogres|r, |cRXP_ENEMY_Orcs|r and |cRXP_ENEMY_Nagosh the Scarred|r
*> Loot them for |T1017862:0|t[|cRXP_LOOT_Stone Guard's Badges|r] and |T132358:0|t[|cRXP_LOOT_Nagosh's Relic Fragment|r].
*> Use the |T133038:0|t|cRXP_WARN_[ExtraActionButton]|r for an extra damage.
.complete 86827,1 
.complete 86826,1 
.complete 86826,2 
.mob Dark Horde Warrior
.mob Hulking Crusher
step
#completewith next
#label Weapon Rack destroyed
#arrowtext Enter the Blackrock\nMountains
.goto 33,49.84,88.8,10,0
.goto 33,46.05,86.44,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r.
.complete 91842,1,1 
step
#completewith Weapon Rack destroyed
.goto 33,46.32,82.42,25 >>Enter the Blackrock Mountains
step
#requires Weapon Rack destroyed
.goto 33,46.32,82.42
#arrowtext Click on the\n|cRXP_PICK_Weapon Rack|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r.
.complete 91842,1,1 
step
#label WeapoRackDestroyedA
#loop
.goto 33,38.13,66.36,15,0
.goto 33,34.91,49.71,15,0
.goto 33,41.85,35.41,15,0
.goto 33,46.28,32.86,15,0
.goto 33,64.43,46.21,15,0
.goto 33,63.95,55.9,15,0
.goto 34,40.61,84.77,15,0
#arrowtext Click on the\n|cRXP_PICK_Weapon Rack|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r.
.complete 91842,1 
step
#loop
.goto 33,54.49,77.15,25,0
.goto 33,44.74,77.3,25,0
.goto 33,36.08,60.74,25,0
.goto 33,40.75,39.77,25,0
.goto 33,53.87,35.22,25,0
.goto 33,64.4,52.78,25,0
#arrowtext \n|cRXP_ENEMY_(LOOT NOT SHARED)|r
>>Kill |cRXP_ENEMY_Ogres|r, |cRXP_ENEMY_Orcs|r and |cRXP_ENEMY_Nagosh the Scarred|r
*Loot them for |T1017862:0|t[|cRXP_LOOT_Stone Guard's Badges|r] and |T132358:0|t[|cRXP_LOOT_Nagosh's Relic Fragment|r].
*Use the |T133038:0|t|cRXP_WARN_[ExtraActionButton]|r for an extra damage.
.complete 86827,1 
.complete 86826,1 
.complete 86826,2 
.mob Dark Horde Warrior
.mob Hulking Crusher
step
#completewith next
#label Due Recognition
#arrowtext Leave Blackrock Mountains
.goto 33,47.21,87.99,15,0
.goto 33,50.88,91.26,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.turnin 86827 >>Turn in Due Recognition
.target Kurdran Wildhammer
.turnin 86826 >>Turn in Nagosh the Scarred
.turnin 91842 >>Turn in Disarm the Dark Horde
.accept 86828 >>Accept Not Just a Troll's Bane
.disablecheckbox
step
#completewith Due Recognition
.goto 36,21.14,39.77,30 >>Leave Blackrock Mountains
step
#requires Due Recognition
#arrowtext Talk to\n|cRXP_FRIENDLY_Kurdran Wildhammer|r
.goto 36,21.14,39.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.turnin 86827 >>Turn in Due Recognition
.target Kurdran Wildhammer
.turnin 86826 >>Turn in Nagosh the Scarred
.turnin 91842 >>Turn in Disarm the Dark Horde
.accept 86828 >>Accept Not Just a Troll's Bane
step
#arrowtext |cRXP_WARN_Leave the NO MOUNT zone|r\nTalk to\n|cRXP_FRIENDLY_Danath Trollbane|r
.goto 36,31.56,37.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danath Trollbane|r.
.turnin 86828 >>Turn in Not Just a Troll's Bane
.target Danath Trollbane
.accept 86831 >>Accept Warriors Without a Warlord
.accept 86830 >>Accept A True Horde of Dark Horde
step
#completewith Warlord Grazla
>>Kill |cRXP_ENEMY_Orcs|r
.complete 86830,1 
.complete 86830,2 
step
#completewith next
#label Dark Horde Leader
.goto 36,32.26,34.84,5,0
.goto 36,31.87,34.64,5,0
.goto 36,31.11,35.48,5,0
.goto 36,30.61,35.33,5,0
>>Kill |cRXP_ENEMY_Warlord Grazla|r.
*Loot her for |T132358:0|t[|cRXP_LOOT_Grazla's Relic Fragment|r].
.complete 86831,1 
.complete 86831,2 
.mob Warlord Grazla
step
#completewith Dark Horde Leader
#arrowtext |cRXP_WARN_Leave the NO MOUNT zone|r
.goto 36,31.08,34,30 >>Enter the building
step
#requires Dark Horde Leader
#label Warlord Grazla
#arrowtext Kill |cRXP_ENEMY_Warlord Grazla|r\n|cRXP_ENEMY_(LOOT NOT SHARED)|r
.goto 36,31.08,34
>>Kill |cRXP_ENEMY_Warlord Grazla|r
*Loot her for |T132358:0|t[|cRXP_LOOT_Grazla's Relic Fragment|r].
.complete 86831,1 
.complete 86831,2 
.mob Warlord Grazla
step
#completewith next
#label Dark Horde Troops
.goto 36,31.56,32.61,5,0
.goto 36,32.01,34.67,5,0
>>Kill |cRXP_ENEMY_Orcs|r
.complete 86830,1 
.complete 86830,2 
.mob Blackrock Sergeant
.mob Dark Horde Trainee
.mob Smolderthorn Cadet
step
#completewith Dark Horde Troops
.goto 36,35.36,34.36,95 >>Leave the building
step
#requires Dark Horde Troops
#loop
.goto 36,35.36,34.36,30,0
.goto 36,34.25,38.37,30,0
.goto 36,32.78,34.82,30,0
>>Kill |cRXP_ENEMY_Orcs|r
.complete 86830,1 
.complete 86830,2 
.mob Blackrock Sergeant
.mob Dark Horde Trainee
.mob Smolderthorn Cadet
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Danath Trollbane|r
.goto 36,31.58,37.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danath Trollbane|r.
.turnin 86831 >>Turn in Warriors Without a Warlord
.target Danath Trollbane
.turnin 86830 >>Turn in A True Horde of Dark Horde
.accept 86829 >>Accept A Landmark Moment
step
#arrowtext |cRXP_WARN_Leave the NO MOUNT zone|r\nTalk to |cRXP_FRIENDLY_Alonsus Faol|r\nand |cRXP_FRIENDLY_Kurdran Wildhammer|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r and |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.turnin 86829 >>Turn in A Landmark Moment
.goto 36,36.84,51.03
.target +Alonsus Faol
.accept 91726 >>Accept Unstoppable Force
.goto 36,36.78,51.07
.target +Kurdran Wildhammer
step
#completewith next
#hidewindow
#arrowtext |cRXP_ENEMY_DISMOUNT|r
.goto 36,36.78,51.07
+1
.multibox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kurdran Wildhammer|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 36,36.78,51.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.complete 91726,1 
.skipgossipid 134709
.target Kurdran Wildhammer
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 36,36.71,51.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.complete 91726,2 
.skipgossipid 136312
.target Arator
step
#arrowtext Talk to |cRXP_FRIENDLY_Kurdran Wildhammer|r\nand |cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r and |cRXP_FRIENDLY_Arator|r.
.turnin 91726 >>Turn in Unstoppable Force
.goto 36,36.78,51.08
.target +Kurdran Wildhammer
.accept 86832 >>Accept A Worthy Forge
.timer 10.5,RP
.goto 36,36.71,51.08
.target +Arator
step
.goto 36,36.76,50.89
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 86832,1 
step
#label A Worthy Forge
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2393,45.77,65.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 86832 >>Turn in A Worthy Forge
.target Alonsus Faol
.accept 86833 >>Accept A Bulwark Remade
step
#completewith next
#label A Bulwark
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86833,1 
.target Arator
step
.isOnQuest 86833
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r\n|cRXP_ENEMY_(NOT SHARED)|r
#completewith A Bulwark
.goto 2393,40.49,65.98
.gossipoption 133121 >>Talk to |cRXP_FRIENDLY_Arator|r.
.timer 3,RP
.target Arator
step
#requires A Bulwark
.goto 2393,40.48,66.21
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86833,1 
step
#arrowtext |cRXP_WARN_When prompted:|r\n 1: Wyrmdust 2: Water 3: Ingot 4: Feather\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,40.47,66.15
>>Follow the instructions |cRXP_WARN_when prompted|r:
*1: Wyrmdust 2: Water 3: Ingot 4: Feather
*|cRXP_WARN_If you fail talk to him again|r.
.complete 86833,2 
.skipgossipid 133121
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,40.48,65.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.complete 86833,3 
.skipgossipid 136685
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2393,40.48,65.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86833 >>Turn in A Bulwark Remade
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kurdran Wildhammer|r
.goto 2393,40.70,66.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.accept 86903 >>Accept The Arcantina
.target Kurdran Wildhammer
step
>>Use |T7322718:0|t[Key to the Arcantina]
.complete 86903,1 
.use 248131
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kurdran Wildhammer|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2541,60.86,67.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r and buy |T135999:0|t[A Round of Drinks].
.complete 86903,2 
.buy 254838,1
step
.goto 2541,50.79,59.1
#arrowtext Click on the\n|cRXP_PICK_Mugs|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mugs|r on the table.
.complete 86903,3 
step
#completewith next
#label DrinksServed
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86903,4 
step
#completewith DrinksServed
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2541,52.14,60.25
.gossipoption 136469 >>Talk to |cRXP_FRIENDLY_Arator|r
.timer 11.8,RP
.target Arator
step
#requires DrinksServed
.goto 2541,52.14,60.25
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86903,4 
.target Arator
step
#label SojournerCampaignJourneyEnds
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2541,52.14,60.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86903 >>Turn in The Arcantina
.target Arator
.accept 91787 >>Accept The Journey Ends
step
#label ArathorEnd4
.isOnQuest 91787
.zoneskip 2541,1
.collecttoy 253629 >>Learn |T7322718:0|t[Personal Key to the Arcantina]
.use 253629
step
#completewith next
#label The Journey Ends
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91787 >>Turn in The Journey Ends
.target Lor'themar Theron
step
#completewith The Journey Ends
.zoneskip 2541,1
.goto 2541,50.67,90.10
.zone 2393 >>Leave the instance portal
step
#requires The Journey Ends
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91787 >>Turn in The Journey Ends
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Of Caves and Cradles
#internal
step
#optional
.isQuestAvailable account,86650
+|cRXP_WARN_You have to do the "Ripple Effects" Chapter first|r
.clicknext RestedXP Midnight\a) Ripple Effects (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Ripple Effects (H) >>CLICK HERE FOR GUIDE << Horde
step
#completewith Scouting Map
#hidewindow
#label OfCavesAndCradlesA
+1
step
#completewith Scouting Map
#hidewindow
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
.acceptmap 94871
.accept 94871 >>Accept Eversong
step
#label Scouting Map
.goto 2393,45.61,70.36
#arrowtext Click on the\n|cRXP_PICK_Scouting Map|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 89402 >>Accept Harandar
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 89402 >>Turn in Harandar
.accept 86899 >>Accept The Root Cause
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86899,1 
.timer 25,RP
.skipgossipid 135559
.target Orweyna
step
#label SojournerCampaignHarandar
.goto 2395,45.13,46.94
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r |cRXP_WARN_after the roleplay|r.
.complete 86899,2 
step
#label OfCavesAndCradlesB
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,75.64,53.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86899 >>Turn in The Root Cause
.target Orweyna
.accept 86900 >>Accept To Har'athir
step
.goto 2413,75.38,51.75
#title |cFFFCDC00Follow the Arrow|r
.complete 86900,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ku'paal|r
.goto 2413,75.38,51.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ku'paal|r.
.complete 86900,2 
.skipgossipid 132537
.target Ku'paal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Danul|r
.goto 2413,74.43,52.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danul|r |cRXP_WARN_might spawn shortly after|r.
.complete 86900,4 
.skipgossipid 133726
.target Danul
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Oorla|r
.goto 2413,76.18,50.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oorla|r.
.complete 86900,3 
.skipgossipid 133721
.target Oorla
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to\n|cRXP_FRIENDLY_Orweyna|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,74.03,51.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
*|cRXP_WARN_NOTE:|r If a character sits on a another persons mount then he will get stuck and you have to relog.
.complete 86900,5 

.target Orweyna
.multibox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,74.03,51.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86900,5 
.skipgossipid 131842
.target Orweyna
.singlebox
step
#label OfCavesAndCradlesBA
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,73.99,50.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86900,6 
.skipgossipid 133774
.target Halduron Brightwing
step
#arrowtext Talk to |cRXP_FRIENDLY_Ruia|r\nand |cRXP_FRIENDLY_Orweyna|r
.goto 2413,70,51.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ruia|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 86900 >>Turn in To Har'athir
.accept 86901 >>Accept The Rift and the Den
.target Ruia
.target Orweyna
step
#label OfCavesAndCradlesBB
.goto 2413,54.79,51.21
#arrowtext |cFFFCDC00Follow the Arrow|r
>>Skyride to |cRXP_FRIENDLY_Halduron Brightwing|r
.complete 86901,2 
.target Halduron Brightwing
step
#label SojournerCampaignRift
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,54.79,51.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin 86901 >>Turn in The Rift and the Den
.target Halduron Brightwing
.accept 86929 >>Accept The Council Assembles
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to\n|cRXP_FRIENDLY_Halduron Brightwing|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,54.79,51.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r |cRXP_WARN_again|r.
*|cRXP_WARN_NOTE:|r If a character sits on a another persons mount then he will get stuck and you have to relog.
.complete 86929,1 

.target Halduron
.multibox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,54.79,51.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r |cRXP_WARN_again|r.
.complete 86929,1 
.skipgossipid 133792
.target Halduron
.singlebox
step
#label CouncilAssembles
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2576,43.77,54.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r.
.turnin 86929 >>Turn in The Council Assembles
.target Hagar
.accept 86907 >>Accept The Den of Echoes
step
#completewith next
#label The Den of Echoes
#arrowtext |cFFFCDC00Fly up through the opening|r\nTalk to |cRXP_FRIENDLY_Hagar|r
.goto 2413,51.15,52.4,25,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r.
.turnin 86907 >>Turn in The Den of Echoes
.accept 86911 >>Accept Echoes and Memories
.disablecheckbox
.target Hagar
step
#completewith The Den of Echoes
#arrowtext Talk to\n|cRXP_FRIENDLY_Yinaa|r
.goto 2413,50.86,55.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yinaa|r.
.home >>Set your Hearthstone to The Den
.skipgossipid 132729
.target Yinaa
step
#requires The Den of Echoes
#label SojournerCampaignDen
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,38.85,46.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r.
.turnin 86907 >>Turn in The Den of Echoes
.accept 86911 >>Accept Echoes and Memories
.target Hagar
step
#completewith next
#label Zur'ashar Kassameh
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
.goto 2413,37.35,47,30,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.complete 86911,2 
.skipgossipid 131932
.target Zur'ashar Kassameh
step
#completewith Zur'ashar Kassameh
.goto 2413,37.49,47.69,30 >>Travel around the rock.
step
#requires Zur'ashar Kassameh
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
.goto 2413,37.49,47.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.complete 86911,2 
.skipgossipid 131932
.target Zur'ashar Kassameh
step
#arrowtext Click on the |cRXP_PICK_Stone|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,37.57,47.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 86911,3 
step
#loop
.goto 2413,37.28,47.62,15,0
.goto 2413,37.28,47.21,15,0
.goto 2413,36.96,46.98,15,0
.goto 2413,36.54,45.78,15,0
.goto 2413,36.44,45.11,15,0
.goto 2413,36.29,44.48,15,0
#arrowtext Click on |cRXP_PICK_Iceberry Bushes|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Iceberry Bushes|r |cRXP_WARN_while dodging elites and transparent trees|r.
*|cRXP_WARN_If you get into combat with an elite, jump into the nearest |cRXP_PICK_Obscuring Bush|r|r.
.complete 86911,4 
.mob Obscuring Bush
.mob Freya
.mob Titanforged Seeker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
.goto 2413,36.11,44.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 86911 >>Turn in Echoes and Memories
.target Zur'ashar Kassameh
.accept 90094 >>Accept Echo of the Hunt
step
#arrowtext Click on the |cRXP_PICK_Stone|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,36.23,44.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 90094,1 
step
#loop
.goto 2413,35.35,45.01,35,0
.goto 2413,34.82,44.97,35,0
.goto 2413,33.97,45.53,35,0
.goto 2413,34.5,47.44,35,0
.goto 2413,35.35,49.22,35,0
.goto 2413,34.09,43.21,35,0
.goto 2413,36.84,45.94,40,0
.goto 2413,36.17,47.1,40,0
.goto 2413,36.49,47.85,40,0
.goto 2413,35.42,48.86,40,0
.goto 2413,34.65,48.06,40,0
.goto 2413,34.14,45.2,40,0
>>Use |T611425:0|t[Vicious Slash] and |T1033474:0|t[Flesh Rend] to deal damage.
*Use |T132130:0|t[Enraged Renewal] to heal yourself.
*|cRXP_WARN_Ignore|r |T132133:0|t[Deadly Pounce].
.complete 90094,3 
.complete 90094,2 
.mob Razorquill Remembrance
.mob Pangquill Reminiscence
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
.goto 2413,34.86,42.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 90094 >>Turn in Echo of the Hunt
.target Zur'ashar Kassameh
.accept 90095 >>Accept Echo of the Call
step
.goto 2413,34.86,42.71
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 90095,1 
step
.goto 2413,34.22,43.59
>>Use |T136100:0|t[Strangling Roots] |cRXP_WARN_once|r and spam |T5927623:0|t[Rending Slash]
*|cRXP_WARN_Ignore|r |T132318:0|t[Shattering Slam].
.complete 90095,2 
.mob Observer Talos
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
.goto 2413,33.93,44.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 90095 >>Turn in Echo of the Call
.target Zur'ashar Kassameh
.accept 86912 >>Accept Down the Rootways
step
#completewith next
#label Gulf of Memory
.goto 2413,35.52,45.05,35,0
.goto 2413,36.45,48.03,35,0
.goto 2413,36.21,49.26,35,0
>>Enter the |cRXP_PICK_Delve: Gulf of Memory|r at Tier 1.
.complete 86912,1 
step
.isOnQuest 86912
#completewith Gulf of Memory
.goto 2413,36.72,49.75,50 >>Enter the Cave
step
#requires Gulf of Memory
#label GulfofMemoryStartCampaign1
.goto 2413,36.72,49.75
>>Enter the |cRXP_PICK_Delve: Gulf of Memory|r at Tier 1.
.complete 86912,1 
step
#include RestedXP Midnight\a) The Gulf of Memory@GulfofMemoryStart1-GulfofMemoryEnd1
step
#label GulfofMemoryEndCampaign1
#arrowtext Click on the |cRXP_PICK_Stone|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2505,49.92,64.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 86912,2 
step
.zoneskip 2505,1
.goto 2505,50.51,65.11,-1
.zone 2413 >>Collect the |cRXP_PICK_Tresures|r
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
step
#completewith next
#label GulfLeave
#arrowtext |cFFFCDC00Fly through the opening upwards|r
.goto 2413,36.05,49.13,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86912,3 
.target Orweyna
step
.isOnQuest 86912
#completewith GulfLeave
#arrowtext |cFFFCDC00Fly through the opening upwards|r
.goto 2413,34.16,43.12,340 >>Go upstairs to leave the cave
step
#requires GulfLeave
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to |cRXP_FRIENDLY_Orweyna|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,34.16,43.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86912,3 

.target Orweyna
.multibox
step
#requires GulfLeave
#arrowtext |cFFFCDC00Fly through the opening upwards|r\nTalk to |cRXP_FRIENDLY_Orweyna|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,34.16,43.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86912,3 
.skipgossipid 136444
.target Orweyna
.singlebox
step
#label SojournerCampaignRootways1
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,34.81,25.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r.
.turnin 86912 >>Turn in Down the Rootways
.target Hagar
.accept 86913 >>Accept A Hut in Har'mara
step
#completewith next
#label A Hut in Har'mara
#arrowtext Enter on the first floor
.goto 2413,34.9,24.5,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86913 >>Turn in A Hut in Har'mara
.target Orweyna
step
#completewith A Hut in Har'mara
.goto 2413,35,23.9,10 >>Enter the building first floor
step
#requires A Hut in Har'mara
#arrowtext Talk to |cRXP_FRIENDLY_Orweyna|r, |cRXP_FRIENDLY_Hagar|r\nand |cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,34.88,25.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r, |cRXP_FRIENDLY_Hagar|r and |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin 86913 >>Turn in A Hut in Har'mara
.accept 86914 >>Accept Tending to Har'mara
.accept 86956 >>Accept The Traveling Flowers
.target Orweyna
.target Halduron Brightwing
.target Hagar
step
#completewith next
#label Tasks completed1
#hidewindow
.goto 2413,35.02,24.1,10,0
.complete 86956,1 
step
#completewith Tasks completed1
.goto 2413,35.85,24.4,67 >>Leave the building
step
#requires Tasks completed1
#completewith TheTravelingFlowersA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r.
.complete 86914,1 
.mob Swiftsting
.target Hungry Rotling
step
#requires Tasks completed1
#arrowtext Talk to\n|cRXP_FRIENDLY_Teetem|r
.goto 2413,35.85,24.4,15,0
.goto 2413,36.16,24.36,15,0
.goto 2413,36.46,24.36,15,0
.goto 2413,36.85,24.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Teetem|r
.complete 86956,2 
.target Teetem
.skipgossipid 132713
step
#label SojournerCampaignRizam
#arrowtext Talk to\n|cRXP_FRIENDLY_Rizam|r
.goto 2413,36.57,25.03,15,0
.goto 2413,36.49,25.24,15,0
.goto 2413,36.94,25.58,15,0
.goto 2413,36.97,25.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rizam|r
.complete 86956,1 
.target Rizam
.skipgossipid 132927
step
#label SojournerCampaignKeem
#arrowtext Talk to\n|cRXP_FRIENDLY_Keem|r
.goto 2413,36.71,26.93,15,0
.goto 2413,36.25,27.41,15,0
.goto 2413,35.73,27.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keem|r
.complete 86956,4 
.target Keem
.skipgossipid 133684
step
#label TheTravelingFlowersA
#arrowtext Talk to\n|cRXP_FRIENDLY_Eonka|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eonka|r
.complete 86956,3 
.goto 2413,34.94,27.38
.target Eonka
.skipgossipid 132714
step
#label Tasks completed
#loop
.goto 2413,35.85,24.4,15,0
.goto 2413,36.16,24.36,15,0
.goto 2413,36.46,24.36,15,0
.goto 2413,36.85,24.05,15,0
.goto 2413,36.57,25.03,15,0
.goto 2413,36.49,25.24,15,0
.goto 2413,36.94,25.58,15,0
.goto 2413,37.15,25.87,15,0
.goto 2413,36.91,26.37,15,0
.goto 2413,36.83,26.8,15,0
.goto 2413,36.71,26.93,15,0
.goto 2413,36.61,26.9,15,0
.goto 2413,36.39,26.81,15,0
.goto 2413,36.25,27.41,15,0
.goto 2413,34.94,27.38,25,0
#arrowtext Click on |cRXP_PICK_Objects|r\nBlooms are usable while mounted\n\n|cRXP_ENEMY_(SHROOMS NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r.
.complete 86914,1 
step
#completewith next
#label The Traveling Flowers
#arrowtext Enter the building
.goto 2413,34.71,25.73,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Hagar|r.
.turnin 86956 >>Turn in The Traveling Flowers
.turnin 86914 >>Turn in Tending to Har'mara
.accept 86910 >>Accept Koozat's Trample
.disablecheckbox
.target Halduron Brightwing
.target Hagar
step
#completewith The Traveling Flowers
.goto 2413,34.88,25.02,45 >>Enter the building
step
#requires The Traveling Flowers
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Hagar|r
.goto 2413,34.88,25.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Hagar|r.
.turnin 86956 >>Turn in The Traveling Flowers
.turnin 86914 >>Turn in Tending to Har'mara
.accept 86910 >>Accept Koozat's Trample
.target Halduron Brightwing
.target Hagar
step
.goto 2413,35.67,25.33
#title |cFFFCDC00Follow the Arrow|r
.complete 86910,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,35.67,25.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86910 >>Turn in Koozat's Trample
.accept 86973 >>Accept Halting Harm in Har'mara
.accept 86942 >>Accept Culling the Spread
.target Orweyna
step
#label Burning Bitterblooms
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,35.7,25.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.accept 89034 >>Accept Burning Bitterblooms
.target Halduron Brightwing
step
#hidewindow
#completewith next
#loop
.goto 2413,36.61,24.2,15,0
.goto 2413,36.94,24.06,25,0
.goto 2413,37.24,24.85,15,0
.goto 2413,36.98,25.63,20,0
.goto 2413,37.05,26.23,20,0
.goto 2413,36.42,26.56,10,0
.goto 2413,35.72,27.45,20,0
.goto 2413,35.18,26.95,20,0
.goto 2413,35.69,26.02,25,0
+1
step
#completewith Leaders
#label LightbloomBitterbloomsA
#hidewindow
.complete 89034,1 
.complete 86973,1 
step
#completewith Leaders
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86973,1 
.mob Lightbloom Thornguard
.mob Lightbloom Grovewarden
.mob Lightbloom Sap Weaver
step
#completewith Leaders
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Flowers|r.
.complete 89034,1 
step
#label Leaders
#loop
>>Kill the |cRXP_ENEMY_Leaders|r.
.complete 86942,2 
.complete 86942,1 
.goto 2413,35.72,27.45,15,0
.complete 86942,4 
.goto 2413,36.85,24.09,15,0
.complete 86942,3 
.goto 2413,36.96,25.62,15,0
.mob Rizam
.mob Teetem
.mob Keem
.mob Koozat
step
#hidewindow
#completewith Lightblooms
#loop
.goto 2413,35.69,25.28,30,0
.goto 2413,36.44,25.69,30,0
.goto 2413,36.41,24.21,30,0
.goto 2413,37.71,23.89,30,0
.goto 2413,36.74,26.77,30,0
.goto 2413,35.13,26.36,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86973,1 
.mob Lightbloom Thornguard
.mob Lightbloom Grovewarden
.mob Lightbloom Sap Weaver
step
#arrowtext Click on the\n|cRXP_PICK_Bloom|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bloom|r
.complete 89034,1 
step
#label Lightblooms
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86973,1 
.mob Lightbloom Thornguard
.mob Lightbloom Grovewarden
.mob Lightbloom Sap Weaver
step
#label SojournerCampaignHarm
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Orweyna|r
.goto 2413,35.68,25.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 89034 >>Turn in Burning Bitterblooms
.turnin 86973 >>Turn in Halting Harm in Har'mara
.turnin 86942 >>Turn in Culling the Spread
.accept 86944 >>Accept Seeds of the Rift
.target Halduron Brightwing
.target Orweyna
step
#completewith next
#label Eonka questioned
#arrowtext |cRXP_WARN_On the second floor|r
.goto 2413,34.89,24.53,10,0
.goto 2413,34.7,24.85,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eonka|r.
.complete 86944,1 
step
#arrowtext |cRXP_WARN_On the second floor|r
#completewith Eonka questioned
.goto 2413,34.86,25.13,15 >>Enter the building |cRXP_WARN_on the second floor|r
step
#requires Eonka questioned
#arrowtext Talk to\n|cRXP_FRIENDLY_Eonka|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,34.85,25.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eonka|r.
.complete 86944,1 
.skipgossipid 133712
.target Eonka
step
#arrowtext Click on the |cRXP_PICK_Bag|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,34.85,25.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
.complete 86944,2 
step
#completewith next
#label Seed Bag
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.complete 86944,3 
.skipgossipid 138702
step
#completewith Seed Bag
#arrowtext |cRXP_WARN_On the first floor|r
.goto 2413,34.99,23.92,20 >>Enter the building's first floor
step
#requires Seed Bag
#label OfCavesAndCradlesZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,34.89,25.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.complete 86944,3 
.skipgossipid 138702
.target Halduron Brightwing
step
#label SojournerAdventureSow
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,34.89,24.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86944 >>Turn in Seeds of the Rift
.accept 86930 >>Accept To Sow the Seed
.target Orweyna
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Call of the Goddess
#internal
step
#optional
.isQuestAvailable 86944
+|cRXP_WARN_You have to do the "Of Caves and Cradles" Chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#label CallOfTheGoddessA
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,34.89,24.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 86930 >>Accept To Sow the Seed
.target Orweyna
step
#completewith next
#label To Sow the Seed
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,35.54,25.27,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_in the den below|r.
.turnin 86930 >>Turn in To Sow the Seed
.accept 86864 >>Accept Watch the Den
step
#completewith To Sow the Seed
.goto 2576,44.18,52.59,1825 >>Leave the building
.cooldown item,6948,<0,1
step
#requires To Sow the Seed
#completewith next
#label To Sow the Seed2
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_in the den below|r.
.turnin 86930 >>Turn in To Sow the Seed
.accept 86864 >>Accept Watch the Den
step
#requires To Sow the Seed
#completewith To Sow the Seed2
.hs >>Hearth to the Den
.cooldown item,6948,>0,1
.use 6948
step
#requires To Sow the Seed2
#arrowtext |cRXP_WARN_In the den below|r
#label SojournerCampaignWatch1
.goto 2576,44.18,52.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_in the den below|r.
.turnin 86930 >>Turn in To Sow the Seed
.accept 86864 >>Accept Watch the Den
step
#label QuartermasterA
#arrowtext |cFFFCDC00Fly UP|r\nTalk to |cRXP_FRIENDLY_Naynar|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,50.95,50.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Naynar|r.
.complete 86864,2 
.skipgossipid 132852
.target Naynar
step
#completewith next
#label Speak to the Innkeeper
#arrowtext Talk to\n|cRXP_FRIENDLY_Yinaa|r
.goto 2413,51.05,55.41,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yinaa|r.
.complete 86864,1 
.target Yinaa
step
#completewith Speak to the Innkeeper
.goto 2413,50.86,55.60,10 >>Enter the Inn
step
#requires Speak to the Innkeeper
#label Speak to the Innkeeper2
#arrowtext Talk to\n|cRXP_FRIENDLY_Yinaa|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,50.86,55.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yinaa|r.
.complete 86864,1 
.skipgossipid 132851
.target Yinaa
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
#label DelversCallA
.goto 2413,54.18,53.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r |cRXP_WARN_in the building|r.
.turnin 93416 >>Turn in Delver's Call: The Gulf of Memory
.target Zur'ashar Kassameh
step
#completewith next
#label Doecha
#arrowtext Talk to\n|cRXP_FRIENDLY_Doecha|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doecha|r.
.complete 86864,3 
.target Doecha
step
#completewith Doecha
#arrowtext Leave the building
.goto 2413,54.41,54.03,10 >>Leave the building
step
#requires Doecha
#label WatchDen
#arrowtext |cFFFCDC00Fly DOWN|r\nTalk to\n|cRXP_FRIENDLY_Doecha|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,55.36,53.49,40,0
.goto 2576,70.72,53.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doecha|r |cRXP_WARN_below in the den|r.
.complete 86864,3 
.skipgossipid 133777
.target Doecha
step
#arrowtext |cFFFCDC00Fly UP|r\nTalk to |cRXP_FRIENDLY_Ku'paal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,54.28,55.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ku'paal|r.
.complete 86864,4 
.skipgossipid 132858
.target Ku'paal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Ku'paal|r
.goto 2413,54.28,55.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Ku'paal|r.
.turnin 86864 >>Turn in Watch the Den
.accept 86836 >>Accept The Hunter Awaits
.target Orweyna
.target Ku'paal
step
#label ShrineMists
.goto 2413,61.99,54.62
#title |cFFFCDC00Follow the Arrow|r
.complete 86836,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r
.goto 2413,61.99,54.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r.
.turnin 86836 >>Turn in The Hunter Awaits
.target Amarakk
.accept 86855 >>Accept Consequences of Our Duty
.accept 86851 >>Accept The Foundation of Aln
step
#hidewindow
#completewith Wounded Defender helped
#loop
.goto 2413,62.64,52.47,15,0
.goto 2413,61.64,53.63,15,0
.goto 2413,60.62,53.27,15,0
.goto 2413,59.43,56.8,15,0
.goto 2413,57.94,54.33,15,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Blighted Rift Spirit|r and |cRXP_ENEMY_Rift Shade|r
*Loot them for |T1778228:0|t[|cRXP_LOOT_Diminished Alndust|r].
.complete 86851,1 
.mob Blighted Rift Spirit
.mob Rift Shade
step
#arrowtext Click on |cRXP_PICK_Wounded Defenders|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Wounded Defenders|r
.complete 86855,1 
.target Wounded Defender
step
#arrowtext Kill |cRXP_ENEMY_Blighted Rift Spirit|r\nLoot for |T1778228:0|t[|cRXP_LOOT_Diminished Alndust|r]
#label Wounded Defender helped
>>Kill |cRXP_ENEMY_Blighted Rift Spirit|r
*Loot them for |T1778228:0|t[|cRXP_LOOT_Diminished Alndust|r].
.complete 86851,1 
.mob Blighted Rift Spirit
step
#loop
.goto 2413,58.87,54.34,35,0
.goto 2413,60.06,53.24,35,0
.goto 2413,61.55,53.99,35,0
.goto 2413,57.27,53.26,35,0
>>Kill |cRXP_ENEMY_Blighted Rift Spirit|r
*Loot them for |T1778228:0|t[|cRXP_LOOT_Diminished Alndust|r].
.complete 86851,1 
.mob Blighted Rift Spirit
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,61.92,54.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86851 >>Turn in The Foundation of Aln
.turnin 86855 >>Turn in Consequences of Our Duty
.accept 86856 >>Accept Dampening the Call
.target Orweyna
step
.goto 2413,61.96,54.52
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 86856,1 
.timer 12.7,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,61.92,54.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86856 >>Turn in Dampening the Call
.accept 86857 >>Accept Descent into the Rift
.target Orweyna
step
#arrowtext Click on the |cRXP_PICK_Banner|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,64.06,56.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r.
.complete 86857,1 
step
.goto 2413,63.98,58.43
#arrowtext |cFFFCDC00Underneath mushrooms|r\nClick on the |cRXP_PICK_Banner|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r.
.complete 86857,2 
step
.goto 2413,61.74,56.29
#title |cFFFCDC00Follow the Arrow|r
.complete 86857,3 
.timer 10.5,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r
.goto 2413,61.67,56.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r.
.turnin 86857 >>Turn in Descent into the Rift
.target Amarakk
.accept 86858 >>Accept The Madness Roots Deep
step
.goto 2413,59.86,57.48
>>Defeat |cRXP_ENEMY_On'hiea|r.
.complete 86858,1 
.mob On'hiea
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r
.goto 2413,61.10,57.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r.
.turnin 86858 >>Turn in The Madness Roots Deep
.target Amarakk
.accept 86861 >>Accept Herding Manifestations
.accept 86860 >>Accept Before They Grow
.accept 86859 >>Accept Grinding Out a Solution
step
#completewith next
>>Kill |cRXP_ENEMY_Decaying Essence|r and |cRXP_ENEMY_Rift Shades|r(|cRXP_WARN_Use item if off cooldown then kill |cRXP_ENEMY_mites|r|r)
*Kill |cRXP_ENEMY_Coalesced Spirits|r |cRXP_WARN_only with good gear or help|r.
.complete 86860,2 
.use 239131
.mob Coalesced Spirit
.mob Rift Shade
.mob Decaying Essence
step
#loop
.goto 2413,62.64,58,15,0
.goto 2413,62.53,59.25,15,0
.goto 2413,63.46,59.11,15,0
#arrowtext Click on the |cRXP_PICK_Banner|r\n|cRXP_ENEMY_(SOMETIMES SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r.
.complete 86861,1 
step
#hidewindow
#completewith Alngrown Fungus
#loop
.goto 2413,63.76,61.43,35,0
.goto 2413,65.27,62.01,35,0
.goto 2413,66.11,63.2,35,0
.goto 2413,65.9,60.71,35,0
.goto 2413,64.43,60.04,35,0
.goto 2413,64.91,58.91,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Decaying Essence|r and |cRXP_ENEMY_Rift Shades|r(|cRXP_WARN_Use item if off cooldown then kill |cRXP_ENEMY_mites|r|r)
*Kill |cRXP_ENEMY_Coalesced Spirits|r |cRXP_WARN_only with good gear or help|r.
.complete 86860,2 
.use 239131
.mob Coalesced Spirit
.mob Rift Shade
.mob Decaying Essence
step
#arrowtext Click on the |cRXP_PICK_Mushroom|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r.
.complete 86859,1 
step
#label Alngrown Fungus
>>Kill |cRXP_ENEMY_Decaying Essence|r and |cRXP_ENEMY_Rift Shades|r(|cRXP_WARN_Use item if off cooldown then kill |cRXP_ENEMY_mites|r|r)
*Kill |cRXP_ENEMY_Coalesced Spirits|r |cRXP_WARN_only with good gear or help|r.
.complete 86860,2 
.use 239131
.mob Coalesced Spirit
.mob Rift Shade
.mob Decaying Essence
step
#completewith next
#label Before They Grow
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r
.goto 2413,63.17,57.81,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r.
.turnin 86860 >>Turn in Before They Grow
.turnin 86861 >>Turn in Herding Manifestations
.turnin 86859 >>Turn in Grinding Out a Solution
.accept 86862 >>Accept The Greater They Aln
.disablecheckbox
.target Amarakk
step
.isOnQuest 86860
#completewith Before They Grow
.goto 2413,63.14,56.76,60 >>Enter the Cave
step
#requires Before They Grow
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r
.goto 2413,63.14,56.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r.
.turnin 86860 >>Turn in Before They Grow
.turnin 86861 >>Turn in Herding Manifestations
.turnin 86859 >>Turn in Grinding Out a Solution
.accept 86862 >>Accept The Greater They Aln
.target Amarakk
step
.goto 2413,64.96,57.35
>>Kill |cRXP_ENEMY_Lured Manifestation|r.
.complete 86862,1 
.mob Lured Manifestation
step
#arrowtext Click on the |cRXP_PICK_Glowing Orb|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,65.04,57.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Glowing Orb|r.
.complete 86862,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r and |cRXP_FRIENDLY_Orweyna|r
#label CallOfTheGoddessB
.goto 2413,63.13,56.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 86862 >>Turn in The Greater They Aln
.accept 86865 >>Accept In Search of the Problem
.target Amarakk
.target Orweyna
step
#completewith next
#label Search of the Problem
#arrowtext Talk to\n|cRXP_FRIENDLY_Byarc|r and |cRXP_FRIENDLY_Orweyna|r
.goto 2413,63.09,57.95,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Byarc|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 86865 >>Turn in In Search of the Problem
.accept 94677 >>Accept The Missing Rootwarden
.accept 86866 >>Accept Can We Heal This?
.target Orweyna
.target Byarc
step
.isOnQuest 86865
#completewith Search of the Problem
.goto 2413,31.4,64.9,2430 >>Leave the Cave
step
#requires Search of the Problem
#label CallOfTheGoddessC
#arrowtext Talk to\n|cRXP_FRIENDLY_Byarc|r and |cRXP_FRIENDLY_Orweyna|r
.goto 2413,31.4,64.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Byarc|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 86865 >>Turn in In Search of the Problem
.accept 94677 >>Accept The Missing Rootwarden
.accept 86866 >>Accept Can We Heal This?
.target Orweyna
.target Byarc
step
#completewith next
#label Ruia's notes
.goto 2413,31.14,64.94,9,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.complete 94677,1,1 
step
#completewith Ruia's notes
.goto 2413,30.97,64.74,20 >>Enter the building
step
#requires Ruia's notes
#arrowtext Click on the |cRXP_PICK_Chest|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,30.97,64.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.complete 94677,1,1 
step
#arrowtext Click on the |cRXP_PICK_Scroll|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,32.97,65.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.complete 94677,1,2 
step
#arrowtext Click on the |cRXP_PICK_Scroll|r\n|cRXP_ENEMY_(NOT SHARED)|r
#label Ruia's notes Z
.goto 2413,30.45,67.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.complete 94677,1,3 
step
#completewith next
#label Afflicted Rutaani
#arrowtext Enter the cave
.goto 2413,32.2,61.67,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Afflicted Rutaani|r
.complete 86866,1 
.mob Afflicted Rutaani
step
.isOnQuest 86866
#completewith Afflicted Rutaani
#arrowtext Enter the cave
.goto 2413,31.94,61.15,35 >>Enter the Cave
step
#requires Afflicted Rutaani
#arrowtext Click on the |cRXP_PICK_Afflicted Rutaani|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,31.96,61.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Afflicted Rutaani|r.
.complete 86866,1 
.mob Afflicted Rutaani
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,31.98,61.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 94677 >>Turn in The Missing Rootwarden
.target Orweyna
.turnin 86866 >>Turn in Can We Heal This?
.accept 86882 >>Accept Alndust in Right Hands
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Eager Volunteers|r\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2413,32.22,61.81,10,0
.goto 2413,32.27,62.71,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eager Volunteers|r.
.complete 86882,1,2 
.target Eager Volunteer
.skipgossipid 132939
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Eager Volunteers|r\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2413,32.26,62.71,10,0
.goto 2413,33.51,63.98,10,0
.goto 2413,32.84,65.1,10,0
.goto 2413,32.42,65.88,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eager Volunteers|r.
.complete 86882,1,4 
.target Eager Volunteer
.skipgossipid 132939
step
#label SojournerCampaignHaranir
#arrowtext |cFFFCDC00NPC Patrols|r\nTalk to |cRXP_FRIENDLY_Eager Volunteer|r\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2413,32.61,65.95,30,0
.goto 2413,31.89,66,25,0
.goto 2413,31.82,67.08,25,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eager Volunteer|r.
.complete 86882,1,5 
.target Eager Volunteer
.skipgossipid 132939
step
#label SojournerCampaignHannan
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to\n|cRXP_FRIENDLY_Hannan|r
.goto 2413,33.18,75.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannan|r.
.complete 86882,2 

.target Hannan
.multibox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hannan|r
.goto 2413,33.18,75.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannan|r.
.complete 86882,2 
.skipgossipid 132933
.target Hannan
.singlebox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,33.20,76.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86882 >>Turn in Alndust in Right Hands
.target Orweyna
.accept 86867 >>Accept Into the Lightbloom
step
.goto 2413,33.27,75.88
#arrowtext Click on the\n|cRXP_PICK_Haranir Petalwing|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Petalwing|r
.complete 86867,1 
.mob Haranir Petalwing
step
.goto 2413,33.27,75.88
#arrowtext Destroy shield and |cRXP_ENEMY_Lightblooms|r\n|cRXP_ENEMY_(SHIELDS NOT SHARED)|r
>>Use |T2032579:0|t[Alndust Toss] on |cRXP_ENEMY_Lightblooms|r and the big pink flowers.
.complete 86867,3 
.complete 86867,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,30.58,77.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86867 >>Turn in Into the Lightbloom
.accept 86874 >>Accept Culling the Light
.accept 86881 >>Accept At the Root
.accept 86877 >>Accept Righteous Pruning
.accept 86880 >>Accept Our Beloved, Returned
.target Orweyna
step
#arrowtext Click on the |cRXP_PICK_Pink Flower|r
.goto 2413,29.25,78.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pink Flower|r.
.complete 86881,1,1 
step
#arrowtext Click on the |cRXP_PICK_Pink Flower|r
.goto 2413,30.4,79.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pink Flower|r.
.complete 86881,1,2 
step
#arrowtext |cFFFCDC00Fly UP|r\nClick on the |cRXP_PICK_Heirloom|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,29.94,81.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Heirloom|r.
.complete 86880,1,1 
step
#arrowtext Click on the |cRXP_PICK_Heirloom|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,31.5,81.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Heirloom|r |cRXP_WARN_inside the building|r.
.complete 86880,1,2 
step
#arrowtext Click on the |cRXP_PICK_Heirloom|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,31.67,83.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Heirloom|r.
.complete 86880,1,3 
step
#arrowtext Click on the |cRXP_PICK_Pink Flower|r
#arrowtext |cFFFCDC00Fly down|r
.goto 2413,32.59,82.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pink Flower|r.
.complete 86881,1,3 
step
#arrowtext |cFFFCDC00Fly UP|r\nClick on the |cRXP_PICK_Heirloom|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,33.66,83.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Heirloom|r in the building.
.complete 86880,1,4 
step
#arrowtext |cFFFCDC00Fly down|r\nClick on the |cRXP_PICK_Pink Flower|r
.goto 2413,35.6,83.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pink Flower|r.
.complete 86881,1,4 
step
#arrowtext |cFFFCDC00Fly UP|r\nClick on the |cRXP_PICK_Heirloom|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,35.35,81.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Heirloom|r in the building.
.complete 86880,1,5 
step
#arrowtext Click on the |cRXP_PICK_Pink Flower|r
.goto 2413,33.37,80.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pink Flowers|r.
.complete 86881,1,5 
step
#arrowtext |cFFFCDC00Fly UP|r\nClick on the |cRXP_PICK_Heirloom|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,32.99,79.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Heirloom|r.
.complete 86880,1,6 
step
#loop
.goto 2413,33.06,79.09,20,0
.goto 2413,32.93,77.7,20,0
.goto 2413,31.95,78.55,20,0
.goto 2413,32.27,75.02,20,0
.goto 2413,31.74,75.37,20,0
#arrowtext Kill |cRXP_ENEMY_Lightblinded Sap Weavers|r
>>Kill |cRXP_ENEMY_Lightblinded Sap Weavers|r.
.complete 86877,1 
.mob Lightblinded Sap Weaver
step
.isOnQuest 86874
#loop
.goto 2413,28.68,83.35,40,0
.goto 2413,33.06,79.09,40,0
>>Kill the |cRXP_ENEMY_Lightblooms|r.
.complete 86874,1 
.mob Lightblinded Sap Spinner
.mob Glimmering Thornmaw
.mob Lightblinded Grovewarden
.mob Blinding Thornmaw
.mob Lightblinded Sap Weaver
.mob Lightbloom Petalwing
.mob Lightblinded Thornguard
step
#label Tell the People
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,30.59,77.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86881 >>Turn in At the Root
.turnin 86877 >>Turn in Righteous Pruning
.turnin 86880 >>Turn in Our Beloved, Returned
.accept 86890 >>Accept Tell the People What You Have Seen
.target Orweyna
step
#completewith next
#label Return to the Den
#hidewindow
.complete 86890,1 
step
#completewith Return to the Den
.hs >>Hearth to The Den
.cooldown item,6948,>0,1
.use 6948
step
#requires Return to the Den
.goto 2413,50.1,54.13
#title |cFFFCDC00Follow the Arrow|r
.complete 86890,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,50.1,54.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.complete 86890,2 

.target Halduron Brightwing
.multibox
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,50.1,54.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.complete 86890,2 
.skipgossipid 135501
.target Halduron Brightwing
.singlebox
step
#label CallOfTheGoddessZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2576,63.43,71.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86890 >>Turn in Tell the People What You Have Seen
.target Orweyna
.accept 86883 >>Accept The Frenzied March
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Emergence
#internal
step
#optional
.isQuestAvailable 86890
+|cRXP_WARN_You have to do the "Call of the Goddess" Chapter first|r
.clicknext RestedXP Midnight\a) Call of the Goddess (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Call of the Goddess (H) >>CLICK HERE FOR GUIDE << Horde
step
#label EmergenceA
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2576,63.43,71.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86890 >>Turn in Tell the People What You Have Seen
.target Orweyna
.accept 86883 >>Accept The Frenzied March
step
#label Emergency
.goto 2576,64.73,71.12
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 86883,1 
step
#label FrenziedMarch
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2395,62.25,59.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin 86883 >>Turn in The Frenzied March
.accept 86884 >>Accept Cull and Burn
.accept 86885 >>Accept Stem the Tides
.target Orweyna
.target Halduron Brightwing
step
#hidewindow
#completewith Lightfrenzy Portalway
#loop
.goto 2395,61.72,60,15,0
.goto 2395,61.34,60.87,15,0
.goto 2395,60.69,59.95,15,0
.goto 2395,61.08,59.91,15,0
.goto 2395,61.35,59.15,15,0
.goto 2395,62.22,59.2,35,0
.goto 2395,62,58.28,35,0
.goto 2395,61.48,57.33,35,0
.goto 2395,61.17,58.87,35,0
.goto 2395,60.13,60.28,35,0
.goto 2395,59.58,57.41,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Lash'ra Thornguards|r, |cRXP_ENEMY_Lightmad Saptors|r, |cRXP_ENEMY_Invasive Shinesippers|r and |cRXP_ENEMY_Lash'ra Mistcallers|r.
*Loot them for |T3613630:0|t[|cRXP_LOOT_Lightbleached Rootbone|r].
.complete 86884,1 
.mob Lash'ra Thornguard
.mob Lightmad Saptor
.mob Invasive Shinesipper
.mob Lash'ra Mistcaller
step
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r.
.complete 86885,1 
step
#label Lightfrenzy Portalway
>>Kill |cRXP_ENEMY_Lash'ra Thornguards|r, |cRXP_ENEMY_Lightmad Saptors|r, |cRXP_ENEMY_Invasive Shinesippers|r and |cRXP_ENEMY_Lash'ra Mistcallers|r.
*Loot them for |T3613630:0|t[|cRXP_LOOT_Lightbleached Rootbone|r].
.complete 86884,1 
.mob Lash'ra Thornguard
.mob Lightmad Saptor
.mob Invasive Shinesipper
.mob Lash'ra Mistcaller
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2395,62.25,59.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin 86884 >>Turn in Cull and Burn
.turnin 86885 >>Turn in Stem the Tides
.accept 86887 >>Accept Expeditious Retreat
.accept 86891 >>Accept A Last Resort
.target Halduron Brightwing
.target Orweyna
step
#completewith Barksnarl Runestone
>>Kill |cRXP_ENEMY_Lightsaptor|r, |cRXP_ENEMY_Shinesipper|r and |cRXP_ENEMY_Shinemaw|r.
*|cRXP_WARN_|cRXP_ENEMY_Swarming Shinesipper|r roams the sky|r
.complete 86887,2 
.complete 86887,1 
.complete 86887,3 
.mob Swarming Lightsaptor
.mob Swarming Shinesipper
.mob Swarming Shinemaw
step
.goto 2395,61.5,59.71
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 86891,1 
step
#completewith next
#arrowtext Check for |cRXP_ENEMY_Lightsaptor|r
.goto 2395,61.56,60.5,20 >>Check for |cRXP_ENEMY_Lightsaptor|r
step
.goto 2395,60.11,59.05
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 86891,2 
step
#completewith next
#arrowtext Check for |cRXP_ENEMY_Swarming Shinesipper|r
.goto 2395,59.91,58.49,20 >>Check for |cRXP_ENEMY_Swarming Shinesipper|r |cRXP_WARN_on the branch|r
.mob Swarming Shinesipper
step
#label Barksnarl Runestone
.goto 2395,60.5,57.39
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 86891,3 
step
#label Lightsaptor
#loop
.goto 2395,60.33,56.98,25,0
.goto 2395,59.69,58.56,25,0
.goto 2395,60.33,56.98,25,0
.goto 2395,61.62,60.35,25,0
>>Kill |cRXP_ENEMY_Lightsaptor|r, |cRXP_ENEMY_Shinesipper|r and |cRXP_ENEMY_Shinemaw|r.
.complete 86887,2 
.complete 86887,1 
.complete 86887,3 
.mob Swarming Lightsaptor
.mob Swarming Shinesipper
.mob Swarming Shinemaw
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Orweyna|r
.goto 2395,58.67,57.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 86887 >>Turn in Expeditious Retreat
.turnin 86891 >>Turn in A Last Resort
.accept 86892 >>Accept Survive
.target Halduron Brightwing
.target Orweyna
step
#completewith next
#arrowtext Talk to\n|cRXP_FRIENDLY_Grand Magister Rommath|r
.goto 2395,58.62,57.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r |cRXP_WARN_if noone has yet|r.
*Switch to Warmode/Non Warmode if it can't be started
.complete 86892,1 
.skipgossipid 132750
.target Grand Magister Rommath
step
.goto 2395,58.77,57.15
>>Kill the incoming waves.
.complete 86892,2 
.mob Lash'ra Thornguard
.mob Lightmad Saptor
.mob Lash'ra Mistcaller
.mob Lightblanched Ancient
step
#label Survive
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2395,58.67,57.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin 86892 >>Turn in Survive
.accept 86894 >>Accept The Gift of Aln'hara
.accept 86896 >>Accept Light Finds a Way
.target Orweyna
.target Halduron Brightwing
step
#label Raptor
#hidewindow
#completewith Lightfrenzy Tyrannosaptor
#loop
.goto 2395,60.38,55.45,30,0
.goto 2395,62.37,53.99,30,0
.goto 2395,61.98,56.19,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Lightfrenzy Tyrannosaptor|r.
*Use the |T3015743:0|t|cRXP_WARN_[ExtraActionButton]|r to weaken them.
.complete 86896,1 
.mob Lightfrenzy Tyrannosaptor
step
#arrowtext |cRXP_ENEMY_Pods are not shared|r
>>Use the |T3015743:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Lash'ra Protector|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Pods|r
.complete 86894,1 
.target Lash'ra Protector
.mob Lightfrenzy Devourer
.mob Lightfrenzy Demolisher
step
#label Lightfrenzy Tyrannosaptor
>>Kill |cRXP_ENEMY_Lightfrenzy Tyrannosaptor|r.
*Use the |T3015743:0|t|cRXP_WARN_[ExtraActionButton]|r to weaken them.
.complete 86896,1 
.mob Lightfrenzy Tyrannosaptor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Orweyna|r
.goto 2395,60.75,56.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 86896 >>Turn in Light Finds a Way
.turnin 86894 >>Turn in The Gift of Aln'hara
.accept 86897 >>Accept Quelling the Frenzy
.target Halduron Brightwing
.target Orweyna
step
.goto 2395,62.88,55.36
>>Kill |cRXP_ENEMY_Lightwarden Ruia|r.
.complete 86897,1 
.timer 3,RP
.mob Lightwarden Ruia
step
#label EmergenceY
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,58.38,55.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86897 >>Turn in Quelling the Frenzy
.target Orweyna
.accept 86898 >>Accept Rise of the Haranir
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Dis Was Our Land
#internal
step
#optional
.isQuestAvailable account,86650
+|cRXP_WARN_You have to do the "Ripple Effects " Chapter first|r
.clicknext RestedXP Midnight\a) Ripple Effects (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Ripple Effects (H) >>CLICK HERE FOR GUIDE << Horde
step
#completewith next
#label DisWasOurLandA
#hidewindow
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
.acceptmap 94871
.accept 94871 >>Accept Eversong
step
#label DisWasOurLandAA
.goto 2393,45.61,70.36
#arrowtext Click on the\n|cRXP_PICK_Scouting Map|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 86708 >>Accept The Gates of Zul'Aman
step
#label DisWasOurLandAB
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2395,60.14,81.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 86708 >>Turn in The Gates of Zul'Aman
.accept 86710 >>Accept The Line Must be Drawn Here
.target Lady Liadrin
step
#label DisWasOurLandBA
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,60.28,81.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.complete 86710,1 
.timer 21,Roleplay Duration
.target Zul'jan
.skipgossipid 135099
step
#label DisWasOurLandBBA
.goto 2395,60.38,81.49
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86710,2 
step
#label DisWasOurLandBAA
.goto 2395,60.38,81.49
>>Kill |cRXP_ENEMY_Void Beast|r.
.complete 86710,3 
.mob Void Beast
step
#label DisWasOurLandB
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2395,60.14,81.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 86710 >>Turn in The Line Must be Drawn Here
.target Lady Liadrin
.accept 90749 >>Accept Our Mutual Enemy
step
#label DisWasOurLandC
.goto 2536,5.47,46.99
#title |cFFFCDC00Follow the Arrow|r
.complete 90749,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2536,5.47,46.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 90749 >>Turn in Our Mutual Enemy
.accept 86868 >>Accept Goodwill Tour
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2536,5.66,47.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 86711 >>Accept Amani Clarion Call
.target Zul'jarra
step
#completewith DisWasOurLandCAA
>>Kill |cRXP_ENEMY_Invading Shadows|r.
.complete 86868,1 
.mob Invading Shadow
step
#arrowtext Drum sounded (1/3)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,16.58,47.70
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drum|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86711,1,1 
step
#arrowtext Drum sounded (2/3)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,24.82,48.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drum|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86711,1,2 
step
#label DisWasOurLandCAA
#arrowtext Drum sounded (3/3)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,35.93,49.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drum|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86711,1 
step
#label GoodwillTourA
#loop
.goto 2536,35.48,56.80,35,0
.goto 2536,37.68,44.88,35,0
.goto 2536,7.30,47.31,35,0
>>Kill |cRXP_ENEMY_Invading Shadows|r.
.complete 86868,1 
.mob Invading Shadow
step
#label DisWasOurLandCA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2536,46.04,48.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 86868 >>Turn in Goodwill Tour
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2536,46.29,48.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86711 >>Turn in Amani Clarion Call
.accept 86717 >>Accept Show Us Your Worth
.target Zul'jarra
step
#label Important Amani
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,46.29,48.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.accept 86719 >>Accept Important Amani
.target Zul'jan
step
#label ElderDoruA
#completewith next
>>Kill |cRXP_ENEMY_Twilight Cultists|r and |cRXP_ENEMY_Untethered Shadows|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Structures|r and |cRXP_PICK_Injured Amani|r.
.complete 86717,1 
.mob Twilight Slasher
.mob Untethered Shadow
.mob Twilight Lynxskinner
.mob Twilight Spellmaster
.mob Twilight Acolyte
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Doru|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,50.64,19.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.complete 86719,1 
.target Elder Doru
.skipgossipid 132579
step
#completewith next
>>Kill |cRXP_ENEMY_Twilight Cultists|r and |cRXP_ENEMY_Untethered Shadows|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Structures|r and |cRXP_PICK_Injured Amani|r.
.complete 86717,1 
.mob Twilight Slasher
.mob Untethered Shadow
.mob Twilight Lynxskinner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Torundo the Grizzled|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,35.66,24.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torundo the Grizzled|r.
.complete 86719,2 
.target Torundo the Grizzled
.skipgossipid 132582
step
#loop
.goto 2536,34.81,14.08,35,0
.goto 2536,29.89,18.68,35,0
.goto 2536,28.7,26.68,35,0
.goto 2536,19.69,34.09,35,0
.goto 2536,37.19,37,35,0
.goto 2536,43.25,28.9,35,0
.goto 2536,51.08,21.41,35,0
.goto 2536,47.36,15.38,35,0
>>Kill |cRXP_ENEMY_Twilight Cultists|r and |cRXP_ENEMY_Untethered Shadows|r.
#arrowtext Click on the\n|cRXP_PICK_Structures|r and |cRXP_PICK_Injured Amani|r
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Structures|r and |cRXP_PICK_Injured Amani|r.
.complete 86717,1 
.mob Twilight Slasher
.mob Untethered Shadow
.mob Twilight Lynxskinner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kinduru|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,16.86,20.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kinduru|r.
.complete 86719,3 
.target Kinduru
.skipgossipid 132584
step
#arrowtext Click on the |cRXP_PICK_Crates|r
.goto 2536,17.07,19.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crates|r.
.complete 86719,4 
step
#arrowtext Click on the |cRXP_PICK_Crate|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,16.50,20.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
.complete 86719,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,16.65,20.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 86719 >>Turn in Important Amani
.turnin 86717 >>Turn in Show Us Your Worth
.accept 86716 >>Accept Armed by Light
.accept 86721 >>Accept Everything We Worked For
.target Zul'jan
step
#completewith EverythingWeWorkedForA
>>Kill |cRXP_ENEMY_Twilight Thieves|r and |cRXP_ENEMY_Twilight Lightburner|r.
*Loot them for |T1379247:0|t[|cRXP_LOOT_Lightwood Weapons|r].
.complete 86716,1 
.mob Twilight Thief
.mob Twilight Lightburner
step
#arrowtext Fires extinguished (1/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,16.46,59.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86721,1,1 
step
#arrowtext |cFFFCDC00On the ground floor|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,22.29,61.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86721,1,2 
step
#arrowtext Fires extinguished (3/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,23.71,67.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86721,1,3 
step
#label EverythingWeWorkedForA
#arrowtext Fires extinguished (4/4)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,17.96,76.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86721,1 
step
#loop
.goto 2536,16.71,63.68,30,0
.goto 2536,24.68,67.24,30,0
.goto 2536,21.97,72.23,30,0
.goto 2536,16.2,57.98,30,0
>>Kill |cRXP_ENEMY_Twilight Thieves|r and |cRXP_ENEMY_Twilight Lightburner|r.
*Loot them for the |T1379247:0|t[|cRXP_LOOT_Lightwood Weapons|r].
.complete 86716,1 
.mob Twilight Thief
.mob Twilight Lightburner
step
#arrowtext Click on the |cRXP_PICK_Wood|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2536,22.60,80.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood|r.
.complete 86721,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,22.61,79.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 86721 >>Turn in Everything We Worked For
.turnin 86716 >>Turn in Armed by Light
.accept 86712 >>Accept The Amani Stand Strong
.target Zul'jan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r and |cRXP_FRIENDLY_Lady Liadrin|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r and |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 86718 >>Accept Twilight Bled
.goto 2536,22.94,79.48
.target +Zul'jarra
.accept 86715 >>Accept Rituals Cut Short
.goto 2536,23.12,79.87
.target +Lady Liadrin
step
#completewith Benvis Bladespatter
>>Kill |cRXP_ENEMY_Twilight Ritualist|r and |cRXP_ENEMY_Twilight Trollbreaker|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on an |cRXP_PICK_Axe|r for an extra damage button.
.complete 86715,1 
.complete 86715,2 
.mob Twilight Trollbreaker
.mob Twilight Ritualist
step
#completewith Benvis Bladespatter
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Defender|r.
.complete 86712,1 
step
#label Benvis Bladespatter
#loop
.goto 2536,27.5,80.11,15,0
.goto 2536,31.26,79.44,15,0
.goto 2536,36.36,80.95,15,0
.goto 2536,36.38,79.03,15,0
.goto 2536,32.81,79.11,15,0
>>Kill |cRXP_ENEMY_Benvis Bladespatter|r.
.complete 86718,1 
.mob Benvis Bladespatter
step
#hidewindow
#completewith Twilight Ritualist slain
#loop
.goto 2536,37.14,77.35,15,0
.goto 2536,33.19,75.03,15,0
.goto 2536,35.66,69.46,15,0
.goto 2536,35.88,64.34,15,0
.goto 2536,36.55,60.28,15,0
.goto 2536,32.02,60.13,30,0
.goto 2536,27.16,66.47,30,0
.goto 2536,31.6,68.83,30,0
.goto 2536,35.98,75.18,30,0
.goto 2536,38.81,68.5,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Twilight Ritualist|r and |cRXP_ENEMY_Twilight Trollbreaker|r.
.complete 86715,1 
.complete 86715,2 
.mob Twilight Trollbreaker
.mob Twilight Ritualist
step
#arrowtext Click on the |cRXP_PICK_Defender|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Defender|r.
.complete 86712,1 
.mob Demoralized Defender
step
#label Twilight Ritualist slain
>>Kill |cRXP_ENEMY_Twilight Ritualist|r and |cRXP_ENEMY_Twilight Trollbreaker|r.
.complete 86715,1 
.complete 86715,2 
.mob Twilight Trollbreaker
.mob Twilight Ritualist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,49.07,46.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 86712 >>Turn in The Amani Stand Strong
.target Zul'jan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Zul'jarra|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86715 >>Turn in Rituals Cut Short
.goto 2536,47.23,46.90
.target +Lady Liadrin
.turnin 86718 >>Turn in Twilight Bled
.accept 86720 >>Accept Break the Blade
.goto 2536,47.54,46.79
.target +Zul'jarra
step
.goto 2536,49.10,47.09
#arrowtext Click on the\n|cRXP_PICK_Ballista|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ballista|r.
.complete 86720,1 
.timer 8.5,RP
step
.goto 2536,57.08,47.4
#arrowtext Use |T132317:0|t[Arrow] (1) on |cRXP_ENEMY_Empowering Shadows|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>Use |T132333:0|t[Obliteration](3) once available.
*Use |T134952:0|t[Protection] if needed
.complete 86720,2 
step
#label Break the Blade
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2536,47.76,47.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86720 >>Turn in Break the Blade
.accept 86722 >>Accept Heart of the Amani
.target Zul'jarra
step
#label Heart of the Amani
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,42.64,66.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86722 >>Turn in Heart of the Amani
.accept 86723 >>Accept Isolation
.target Zul'jarra
step
#label DisWasOurLandE
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,45.75,65.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86723,1 
.target Zul'jarra
.skipgossipid 138031
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.75,65.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86723 >>Turn in Isolation
.accept 86652 >>Accept Left in the Shadows
.target Zul'jarra
step
#completewith next
#label Torundo
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r.
.complete 86652,1 
step
#completewith Torundo
.goto 2437,46.86,67.32,85 >>Leave the building
step
#requires Torundo
#arrowtext Click on the |cRXP_PICK_Cauldron|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,46.86,67.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r.
.complete 86652,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,45.14,67.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.complete 86652,2 
.target Lilaju
.skipgossipid 132891
step
#completewith next
#label Shadowpine Shamans
#arrowtext Enter the building
.goto 2437,44.03,65.35,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.complete 86652,3 
.target Tak'lejo
step
#completewith Shadowpine Shamans
#arrowtext Enter the building
.goto 2437,43.97,65.07,18 >>Enter the building
step
#requires Shadowpine Shamans
#arrowtext Talk to\n|cRXP_FRIENDLY_Tak'lejo|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.97,65.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.complete 86652,3 
.target Tak'lejo
.skipgossipid 135286
step
#completewith next
#label Speak with Kinduru
#arrowtext Leave the building
.goto 2437,43.98,65.45,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kinduru|r.
.complete 86652,4 
.target Kinduru
step
#completewith Speak with Kinduru
#arrowtext Leave the building
.goto 2437,43.78,68.41,180 >>Leave the building
step
#requires Speak with Kinduru
#arrowtext Talk to\n|cRXP_FRIENDLY_Kinduru|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.78,68.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kinduru|r.
.complete 86652,4 
.target Kinduru
.skipgossipid 133822
step
#label DisWasOurLandZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.80,68.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86652 >>Turn in Left in the Shadows
.accept 86653 >>Accept The Path of the Amani
.target Zul'jarra
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Path of de Hash'ey
#internal
step
#optional
.isQuestAvailable 86652
+|cRXP_WARN_You have to do the "Dis Was Our Land" Chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#label PathOfDeHasheyA
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.80,68.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 86653 >>Accept The Path of the Amani
.target Zul'jarra
step
.isOnQuest 86653
#arrowtext Talk to\n|cRXP_FRIENDLY_Tavikko|r
.goto 2437,45.43,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r |cRXP_WARN_inside the building|r.
.home >>Set your Hearthstone to Amani'Zar Village
.skipgossipid 132699
.target Tavikko
step
#label PathOfDeHasheyB
.goto 2437,51.63,70.80
#title |cFFFCDC00Follow the Arrow|r
.complete 86653,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,51.63,70.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86653 >>Turn in The Path of the Amani
.accept 86655 >>Accept De Ancient Path
.accept 89334 >>Accept Ahead of the Issue
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2437,51.61,70.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 86654 >>Accept Gnarldin Bashing
.target Lady Liadrin
step
#completewith DeAncientPathA
>>Kill |cRXP_ENEMY_Gnarldins|r.
.complete 86654,1 
.mob Gnarldin Clubfist
.mob Gnarldin Nestcrusher
step
#arrowtext Shrine lit (1/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,55.29,70.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,1 
step
#arrowtext Shrine lit (2/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,56.26,73.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,2 
step
#completewith next
#label AheadOfTheIssueA
#arrowtext Enter the cave
.goto 2437,55.92,74.38,8,0
>>Kill |cRXP_ENEMY_Brulagh the Crusher|r.
*Loot him for |T133639:0|t[|cRXP_LOOT_Head of Brulagh the Crusher|r].
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89334,1 
.mob Brulagh the Crusher
step
#completewith AheadOfTheIssueA
#title Enter the cave
.goto 2437,56.15,74.88,30 >>|cRXP_WARN_Enter the cave|r.
step
#requires AheadOfTheIssueA
#arrowtext Kill |cRXP_ENEMY_Brulagh the Crusher|r\nLoot for |T133639:0|t[|cRXP_LOOT_Head of Brulagh the Crusher|r]
.goto 2437,56.15,74.88
>>Kill |cRXP_ENEMY_Brulagh the Crusher|r.
*Loot him for the |T133639:0|t[|cRXP_LOOT_Head of Brulagh the Crusher|r].
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89334,1 
.mob Brulagh the Crusher
step
#completewith next
#label Shrine lit
#arrowtext Shrine lit (3/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,55.78,74.61,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,3 
step
#completewith Shrine lit
.goto 2437,55.24,76.26,110 >>Leave the Cave
step
#requires Shrine lit
#arrowtext Shrine lit (3/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,55.24,76.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,3 
step
#arrowtext Kill |cRXP_ENEMY_Pulverizer Helthra|r\nLoot for |T133639:0|t[|cRXP_LOOT_Head of Pulverizer Helthra|r]
.goto 2437,55.24,77.82
>>Kill |cRXP_ENEMY_Pulverizer Helthra|r.
*Loot him for the |T133639:0|t[|cRXP_LOOT_Head of Pulverizer Helthra|r].
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89334,3 
.mob Pulverizer Helthra
step
#arrowtext Shrine lit (4/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,53.67,72.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1 
step
#label DeAncientPathA
#arrowtext Kill |cRXP_ENEMY_Cragward Gaahl|r\nLoot for |T133639:0|t[|cRXP_LOOT_Head of Cragward Gaahl|r]
.goto 2437,53.32,74.27
>>Kill |cRXP_ENEMY_Cragward Gaahl|r
*Loot him for the |T133639:0|t[|cRXP_LOOT_Head of Cragward Gaahl|r].
.complete 89334,2 
.mob Cragward Gaahl
step
#label PathOfDeHasheyBA
#loop
.goto 2437,55.02,72.96,35,0
.goto 2437,52.32,70.55,35,0
.goto 2437,53.99,71.83,35,0
.goto 2437,55.69,74.15,35,0
.goto 2437,54.98,77.36,35,0
#arrowtext Kill |cRXP_ENEMY_Gnarldins|r
>>Kill |cRXP_ENEMY_Gnarldins|r.
.complete 86654,1 
.mob Gnarldin Clubfist
.mob Gnarldin Nestcrusher
step
#label PathOfDeHasheyBB
.goto 2437,51.90,76.03
#arrowtext Click on the\n|cRXP_PICK_Incense|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
.complete 86655,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Zul'jarra|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86654 >>Turn in Gnarldin Bashing
.goto 2437,51.97,76.03
.target +Lady Liadrin
.turnin 89334 >>Turn in Ahead of the Issue
.turnin 86655 >>Turn in De Ancient Path
.accept 86656 >>Accept Brutal Feast
.goto 2437,51.91,75.95
.target +Zul'jarra
step
#arrowtext |cFFFCDC00Fly Up|r
.goto 2437,52.37,81.01
>>Follow the Arrow
.complete 86656,1 
.timer 7,RP
step
#arrowtext Click on the |cRXP_PICK_Sack|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,52.40,81.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sack|r |cRXP_WARN_after the roleplay|r.
.complete 86656,2 
step
#loop
.goto 2437,52.39,82.39,10,0
.goto 2437,53.19,81.08,10,0
.goto 2437,53.25,80.66,10,0
#arrowtext Click on the |cRXP_PICK_Sacks|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sacks|r.
.complete 86656,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,52.36,81.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86656 >>Turn in Brutal Feast
.accept 86809 >>Accept Test of Conviction
.target Zul'jarra
step
.goto 2437,51.08,79.03
#arrowtext |cRXP_ENEMY_DISMOUNT|r\n|cFFFCDC00Follow the Arrow|r
.complete 86809,1 
.multibox
step
.goto 2437,51.08,79.03
#title |cFFFCDC00Follow the Arrow|r
.complete 86809,1 
.singlebox
step
#arrowtext |cRXP_ENEMY_DISMOUNT/n It's Safe|r
.goto 2437,50.84,78.67
>>|cRXP_WARN_Drop down from the cliff|r.
.complete 86809,2 
.multibox
step
#arrowtext |cRXP_WARN_It's Safe|r
.goto 2437,50.84,78.67
>>|cRXP_WARN_Drop down from the cliff|r.
.complete 86809,2 
.singlebox
step
#label Shadebasin Watch
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,52.36,81.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86809 >>Turn in Test of Conviction
.target Zul'jarra
.accept 86657 >>Accept Shadebasin Watch


step
.isOnQuest 86657
.train 124559,3
.cast 1254559 >>Use |T7322719:0|t[Path of Cavernous Depths]
.use 1254559
step
.goto 2437,44.08,34.50
#title |cFFFCDC00Follow the Arrow|r
.complete 86657,2 
step
#label PathOfDeHasheyC
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,44.08,34.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86657 >>Turn in Shadebasin Watch
.accept 86658 >>Accept The Crypt in the Mist
.accept 86660 >>Accept Rescue from the Shadows
.target Zul'jarra
step
#label PathOfDeHasheyD
#completewith RescueFromTheMistA
>>Kill |cRXP_ENEMY_Trolls|r.
.complete 86658,2 
step
#completewith next
#label RescueFromTheMistA
.goto 2437,39.13,39.03,8,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Witherbarks|r.
.complete 86660,1,1 
.target Captured Witherbark
.target Captured Witherbark Lynx
step
#completewith RescueFromTheMistA
#arrowtext Enter the crypt
.goto 2437,38.14,37.55,120 >>|cRXP_WARN_Enter the crypt|r.
step
#requires RescueFromTheMistA
#hidewindow
#completewith Vilebranch Trolls
#loop
#requires RescueFromTheMistA
.goto 2437,38.14,37.55,30,0
.goto 2437,37.98,37.72,12,0
.goto 2437,37.78,37.97,12,0
.goto 2437,37.63,37.38,12,0
.goto 2437,36.81,37.76,12,0
.goto 2437,36.79,37.54,12,0
.goto 2437,37.05,37.2,12,0
.goto 2437,36.91,37.36,12,0
.goto 2437,36.75,37.12,12,0
.goto 2437,37.7,38.53,30,0
.goto 2437,37.31,37.97,12,0
.goto 2437,38.34,36.26,20,0
.goto 2437,38.5,36.65,20,0
.goto 2437,37.73,37.81,20,0
.goto 2437,37.27,37.08,20,0
+1
step
#requires RescueFromTheMistA
#completewith next
>>Kill |cRXP_ENEMY_Trolls|r.
.complete 86658,2 
.mob Vilebranch Hexwarder
.mob Risen Witherbark
.mob Vilebranch Siphoner
step
#requires RescueFromTheMistA
#arrowtext Click on the\n|cRXP_PICK_Witherbarks|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Witherbarks|r.
.complete 86660,1 
.target Captured Witherbark
step
#label Vilebranch Trolls
>>Kill |cRXP_ENEMY_Trolls|r.
.complete 86658,2 
.mob Vilebranch Hexwarder
.mob Risen Witherbark
.mob Vilebranch Siphoner
step
#completewith next
#label Ritualist Zongha
.goto 2437,36.92,37.39,8,0
.goto 2437,36.84,37.15,8,0
#arrowtext Go upstairs
>>Kill |cRXP_ENEMY_Ritualist Zongha|r.
.complete 86658,3 
.mob Ritualist Zongha
step
#completewith Ritualist Zongha
#arrowtext Go upstairs
.goto 2437,37.56,36,30 >>Go upstairs
step
#requires Ritualist Zongha
.goto 2437,37.56,36
#arrowtext Kill |cRXP_ENEMY_Ritualist Zongha|r
>>Kill |cRXP_ENEMY_Ritualist Zongha|r.
.complete 86658,3 
.mob Ritualist Zongha
step
#completewith next
#label RescueFromTheMistB
#arrowtext Leave the crypt
.goto 2437,37.45,35.77,8,0
.goto 2437,37.86,35.53,8,0
.goto 2437,37.52,34.96,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86658 >>Turn in The Crypt in the Mist
.turnin 86660 >>Turn in Rescue from the Shadows
.accept 86659 >>Accept Breaching the Mist
.target Zul'jarra
step
#completewith RescueFromTheMistB
#arrowtext |cFFFCDC00Leave the crypt|r
.goto 2437,36.76,34.97,70 >>Leave the crypt.
step
#requires RescueFromTheMistB
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,36.76,34.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86658 >>Turn in The Crypt in the Mist
.turnin 86660 >>Turn in Rescue from the Shadows
.accept 86659 >>Accept Breaching the Mist
.target Zul'jarra
step
.goto 2437,35.46,36.10
#arrowtext Click on the\n|cRXP_PICK_Incense|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
.complete 86659,1 
step
.isOnQuest 91040
#completewith next
>>Kill |cRXP_ENEMY_Vilebranch forces|r.
.complete 91040,1 
.mob Shambling Berserker
.mob Vilebranch Enthraller
.mob Vilebranch Lynxstalker
.mob Rotting Vilefeaster
step
#label SojournerCampaignFinalIncense
#loop
.goto 2437,33.40,34.48,15,0
.goto 2437,33.96,32.02,15,0
.goto 2437,34.84,30.91,15,0
#arrowtext Click on the\n|cRXP_PICK_Incense|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
.complete 86659,2 
step

#loop
.goto 2437,35.23,32.85,35,0
.goto 2437,32.07,33.76,35,0
.goto 2437,34.25,31.12,35,0
>>Kill |cRXP_ENEMY_Vilebranch forces|r.
.complete 91040,1 
.mob Shambling Berserker
.mob Vilebranch Enthraller
.mob Vilebranch Lynxstalker
.mob Rotting Vilefeaster
step
.goto 2437,32.83,32.62
#arrowtext Click on the\n|cRXP_PICK_Incense|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
.complete 86659,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,32.40,31.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86659 >>Turn in Breaching the Mist
.accept 92084 >>Accept Halazzi's Guile
.target Zul'jarra
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r.
.complete 92084,1 
.target Loa Speaker Tobui

.multibox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r.
.complete 92084,1 
.target Loa Speaker Tobui
.skipgossipid 135472
.singlebox
step
#label PathOfDeHasheyE
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,32.40,31.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 92084 >>Turn in Halazzi's Guile
.accept 86661 >>Accept Coals of a Dead Loa
.target Zul'jarra
step
#label PathOfDeHasheyF
#arrowtext |cFFFCDC00Fly Up|r\nTalk to |cRXP_FRIENDLY_Vun'zarah|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,38.57,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vun'zarah|r.
.complete 86661,1 
.target Vun'zarah
.skipgossipid 134081
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,38.53,22.47
#label PathOfDeHasheyG
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86661 >>Turn in Coals of a Dead Loa
.accept 86808 >>Accept The Riddled Speaker
.target Zul'jarra
step
#completewith next
#label PathOfDeHasheyGA
#hidewindow
.goto 2437,38.75,22.63,8,0
.complete 86808,1 
step
#completewith PathOfDeHasheyGA
.goto 2437,55.00,18.35,1480 >>Jump out the Window
step
#requires PathOfDeHasheyGA
#label PathOfDeHasheyH
.goto 2437,55.00,18.35
#title |cFFFCDC00Follow the Arrow|r
.complete 86808,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,55.00,18.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86808 >>Turn in The Riddled Speaker
.accept 86663 >>Accept Embers to a Flame
.target Zul'jarra
step
#arrowtext Click on the |cRXP_PICK_Coal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,55.08,18.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coal|r.
.complete 86663,2 
step
#loop
.goto 2437,55.64,21.64,45,0
.goto 2437,54.89,23.61,50,0
.goto 2437,51.88,21.89,45,0
.goto 2437,52.84,20.03,45,0
#arrowtext Kill |cRXP_ENEMY_Amazards|r
>>Kill |cRXP_ENEMY_Amazards|r until the bar reaches 100%.
.complete 86663,3 
.mob Cinderscale Amazard
.mob Cinderdig Amazard
step
#arrowtext Click on the |cRXP_PICK_Infused Coal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,55.08,18.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Infused Coal|r.
.complete 86663,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,55.00,18.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86663 >>Turn in Embers to a Flame
.accept 86664 >>Accept Seer or Sear
.target Zul'jarra
step
#completewith next
#label Zul'jin1
>>Kill the |cRXP_ENEMY_Manifestation of Zul'jin|r.
.complete 86664,1 
.mob Manifestation of Zul'jin
step
#completewith Zul'jin1
#arrowtext Click on the |cRXP_PICK_Coal|r
.goto 2437,54.90,21.55
.cast 1226758 >>Click on the |cRXP_PICK_Coal|r.
step
#requires Zul'jin1
#arrowtext Kill the |cRXP_ENEMY_Manifestation of Zul'jin|r
.goto 2437,54.91,21.36
*Kill the |cRXP_ENEMY_Manifestation of Zul'jin|r.
.complete 86664,1 
.mob Manifestation of Zul'jin
step
#completewith next
#label Zul'jin2
>>Kill the |cRXP_ENEMY_Manifestation of Zul'jin|r.
.complete 86664,2 
.mob Manifestation of Zul'jin
step
#completewith Zul'jin2
#arrowtext Click on the |cRXP_PICK_Coal|r
.goto 2437,52.92,18.56
.cast 1226761 >>Click on the |cRXP_PICK_Coal|r.
step
#requires Zul'jin2
>>Kill the |cRXP_ENEMY_Manifestation of Zul'jin|r.
.goto 2437,53.09,18.56
.complete 86664,2 
.mob Manifestation of Zul'jin
step
#arrowtext Click on the |cRXP_PICK_Coal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,55.11,18.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coal|r.
.complete 86664,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,55.00,18.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86664 >>Turn in Seer or Sear
.accept 86665 >>Accept Face in the Fire
.target Zul'jarra
step
#arrowtext Click on the |cRXP_PICK_Coal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,55.11,18.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coal|r.
.complete 86665,1 
.mob Manifestation of Zul'jarra
step
#arrowtext Kill the |cRXP_ENEMY_Manifestation of Zul'jarra|r
.goto 2437,55.19,18.1
>>Kill |cRXP_ENEMY_Manifestation of Zul'jarra|r.
.complete 86665,2 
.mob Manifestation of Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,55.01,18.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86665 >>Turn in Face in the Fire
.accept 90772 >>Accept The Flames Rise Higher
.target Zul'jarra
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to\n|cRXP_FRIENDLY_Loa Speaker Brek|r
.goto 2437,55.11,18.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Brek|r.
.complete 90772,1 
.target Loa Speaker Brek

.multibox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Brek|r
.goto 2437,55.11,18.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Brek|r.
.complete 90772,1 
.target Loa Speaker Brek
.skipgossipid 134196
.singlebox
step
#label PathOfDeHasheyX
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,55.00,18.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 90772 >>Turn in The Flames Rise Higher
.accept 86666 >>Accept In the Shadow of Rebirth
.target Zul'jarra
step
.isOnQuest 86666
.hs >>Hearth to Amani'Zar Village
.cooldown item,6948,>0,1
.use 6948
step
#label PathOfDeHasheyZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.14,64.99,20,0
.goto 2437,43.83,68.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86666 >>Turn in In the Shadow of Rebirth
.accept 86681 >>Accept Den of Nalorakk: A Taste of Vengeance
.target Zul'jarra
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Where War Slumbers
#internal
step
#optional
.isQuestAvailable 86666
+|cRXP_WARN_You have to do the "Path of de Hash'ey" Chapter first|r
.clicknext RestedXP Midnight\a) Path of de Hash'ey (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Path of de Hash'ey (H) >>CLICK HERE FOR GUIDE << Horde
step
#label SlumbersA
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.83,68.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 86681 >>Accept Den of Nalorakk: A Taste of Vengeance
.target Zul'jarra
step
#arrowtext |cFFFCDC00Cancel it right after|r\nClick on the |cRXP_PICK_Bowl|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.57,68.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bowl|r |cRXP_WARN_cancel it right after|r.
.complete 86681,1 
step
#arrowtext Use the |T571694:0|t[ExtraActionButton]\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.57,68.28
>>Stand within the circle and use the |T571694:0|t[|cRXP_WARN_ExtraActionButton|r].
.complete 86681,2,1 
step
#label DeathRitesZ
#arrowtext Use the |T571694:0|t[ExtraActionButton]\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.67,68.55
>>Stand within the circle and use the |T571694:0|t[|cRXP_WARN_ExtraActionButton|r].
.complete 86681,2,2 
step
#arrowtext Use the |T571694:0|t[ExtraActionButton]\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.86,68.66
>>Stand within the circle and use the |T571694:0|t[|cRXP_WARN_ExtraActionButton|r].
.complete 86681,2,3 
step
#label SlumbersAA
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.83,68.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86681 >>Turn in Den of Nalorakk: A Taste of Vengeance
.accept 86682 >>Accept Den of Nalorakk: Waking de Bear
.target Zul'jarra
step
#label SlumbersB
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,33.59,78.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.complete 86682,1 
.target Lilaju
.skipgossipid 134139
step
#completewith next
+If you are DPS, queue for Den of Nalorakk (Normal) now to reduce wait time, but do not enter the dungeon until you have the quest.
*|cRXP_WARN_It’s often faster than the follower dungeon run, provided the queue pops quickly|r.
.macro Queue Den of Nalorakk(Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3089, true); LFGEnabledList[3089] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
#label SlumbersC
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,33.61,78.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86682 >>Turn in Den of Nalorakk: Waking de Bear
.accept 91958 >>Accept Den of Nalorakk: Unforgiven
.target Zul'jarra
step
#completewith next
#label Speak with Zul'jarra
#hidewindow
.complete 91958,4 
step
#completewith Speak with Zul'jarra
.goto 2437,33.61,78.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r to start the Follower Dungeon, or queue through the Dungeon Finder instead.
.enterScenario 3118 >>Queue for the |cRXP_PICK_Den of Nalorakk|r on (Normal) difficulty
.skipgossipid 134140
.target Zul'jarra
step
#requires Speak with Zul'jarra
#completewith DungeonLeave
+|cRXP_WARN_The Arrow cannot be displayed here; coordinates are unavailable|r.
step
#requires Speak with Zul'jarra
#completewith DungeonLeave
.goto 2437,33.61,78.77
>>Kill |cRXP_ENEMY_Nalorakk, Loa of War|r at the end of Den of Nalorakk.
.complete 91958,3 
.skipgossipid 134140
step
#requires Speak with Zul'jarra
#label The Hoardmonger
.isInScenario 3118
#arrowtext Click on the\n|cRXP_PICK_Campfire|r
>>Click on the |cRXP_PICK_Campfire|r, complete tasks for offerings and place them infront of the|TInterface/cursor/crosshair/attack.blp:12|t|cRXP_ENEMY_The Hoardmonger|r.
.scenario 15950,1
.skipgossipid 135009
.mob The Hoardmonger
step
.isInScenario 3118
#arrowtext Click on the\n|cRXP_PICK_Eye|r
>>Click on the |cRXP_PICK_Eye|r to summon |TInterface/cursor/crosshair/attack.blp:15|t|cRXP_ENEMY_Sentinel of Winter|r.
*|cRXP_WARN_Hide behind structures when confronted with harsh winds|r
.scenario 15950,2
.mob Sentinel of Winter
step
.isInScenario 3118
#arrowtext Click on the\n|cRXP_PICK_Campfire|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Campfire|r and kill |cRXP_ENEMY_Nalorakk|r.
.scenario 15950,3
.skipgossipid 135010
.mob Nalorakk
step
#completewith next
#label Zul'jarra
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 91958,4 
.target Zul'jarra
step
#completewith Zul'jarra
#label DungeonLeave
.zone 2437 >>Click the macro in the "Active Items Frame"
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#requires Zul'jarra
#arrowtext |cRXP_ENEMY_DISMOUNT\nTalk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,31.58,83.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 91958,4 
.target Zul'jarra

.multibox
step
#requires Zul'jarra
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,31.58,83.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 91958,4 
.target Zul'jarra
.skipgossipid 138171
.singlebox
step
#label SlumbersD
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,31.58,83.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r
.turnin 91958 >>Turn in Den of Nalorakk: Unforgiven
.target Zul'jarra
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) De Amani Never Die
#internal
step
#optional
.isQuestAvailable 91958
+|cRXP_WARN_You have to do the "Where War Slumbers" Chapter first|r
.clicknext RestedXP Midnight\a) Where War Slumbers (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Where War Slumbers (H) >>CLICK HERE FOR GUIDE << Horde
step
#label DeAmaniNeverDieA
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,31.58,83.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 86683 >>Accept Hash'ey Away
.target Zul'jarra





step
#label DeAmaniNeverDieB
.goto 2437,43.80,68.68
#title |cFFFCDC00Follow the Arrow|r
.complete 86683,1 
step
#label DeAmaniNeverDieC
#arrowtext |cRXP_ENEMY_DISMOUNT|r\nTalk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.80,68.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86683,2 
.target Zul'jarra

.multibox
step
#label DeAmaniNeverDieCA
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.80,68.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86683,2 
.target Zul'jarra
.skipgossipid 132827
.singlebox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.49,68.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86683 >>Turn in Hash'ey Away
.accept 86684 >>Accept The Blade's Edge
.target Zul'jarra
step
#label Broken Throne
.goto 2437,28.35,77.38
#title |cFFFCDC00Follow the Arrow|r
.complete 86684,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,28.35,77.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86684 >>Turn in The Blade's Edge
.accept 86687 >>Accept Conduit Crisis
.accept 86685 >>Accept Chip and Shatter
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2437,28.41,77.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 86686 >>Accept Light Indiscriminate
.target Lady Liadrin
step
#completewith LightIndiscriminateA
>>Kill |cRXP_ENEMY_Twilight Cultists|r.
.complete 86685,1 
.mob Twilight Breaker
.mob Void Ascendant
.mob Shadowy Stalker
.mob Bound Shadow
.mob Flittering Shadow
.mob Ogre Hexwright
.mob Ogre Rampager
.mob Umbral Force
.mob Lurking Shadeblade
.mob Twilight Sage
step
#arrowtext Amani healed (3/10)\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2437,27.87,77.1,10,0
.goto 2437,27.85,77.74,10,0
.goto 2437,27.27,78.88,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Amani|r.
.complete 86686,1,3 
.target Injured Amani Warrior
step
#loop
.goto 2437,27.29,80.87,15,0
.goto 2437,27.65,81.76,15,0
.goto 2437,26.89,81.64,15,0
#arrowtext Click on the |cRXP_PICK_Void Conduit|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Conduit|r.
.complete 86687,4 
step
#loop
.goto 2437,24.35,80.53,15,0
.goto 2437,24.11,79.78,15,0
.goto 2437,23.12,79.88,15,0
#arrowtext Click on the |cRXP_PICK_Void Conduit|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Conduit|r.
.complete 86687,3 
step
#loop
.goto 2437,23.21,75.40,15,0
.goto 2437,23.76,74.33,15,0
.goto 2437,24.73,74.51,15,0
#arrowtext Click on the |cRXP_PICK_Void Conduit|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Conduit|r.
.complete 86687,2 
step
#loop
.goto 2437,23.94,71.43,10,0
.goto 2437,25.20,70.00,10,0
.goto 2437,26.21,71.97,10,0
#arrowtext Click on the |cRXP_PICK_Void Conduit|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Conduit|r.
.complete 86687,1 
step
#label LightIndiscriminateA
#loop
.goto 2437,26.11,76.04,10,0
.goto 2437,26.48,76.26,10,0
.goto 2437,26.19,76.69,10,0
.goto 2437,26.36,77.05,10,0
.goto 2437,26.5,77.34,10,0
.goto 2437,26.82,77.35,10,0
.goto 2437,26.28,77.94,10,0
#arrowtext Click on the\n|cRXP_PICK_Injured Amanis|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Amanis|r.
.complete 86686,1 
.target Injured Amani Warrior
step
#loop
.goto 2437,25.98,78.73,30,0
.goto 2437,25.31,79.2,30,0
.goto 2437,24.84,78.04,30,0
.goto 2437,25.19,76.22,30,0
.goto 2437,26.48,76.81,30,0
>>Kill |cRXP_ENEMY_Twilight Cultists|r.
.complete 86685,1 
.mob Twilight Breaker
.mob Void Ascendant
.mob Shadowy Stalker
.mob Bound Shadow
.mob Flittering Shadow
.mob Ogre Hexwright
.mob Ogre Rampager
.mob Umbral Force
step
#label Light Indiscriminate
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Zul'jarra|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86686 >>Turn in Light Indiscriminate
.goto 2437,25.70,77.67
.target +Lady Liadrin
.turnin 86685 >>Turn in Chip and Shatter
.turnin 86687 >>Turn in Conduit Crisis
.accept 91001 >>Accept Clear de Way
.goto 2437,25.70,77.62
.target Zul'jarra
step
.goto 2437,22.53,77.38
#title |cFFFCDC00Follow the Arrow|r
.complete 91001,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,22.53,77.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 91001 >>Turn in Clear de Way
.accept 86692 >>Accept Blade Shattered
.target Zul'jarra
step
#label DeAmaniNeverDieCampaignSojourner2
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,22.53,77.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86692,1 
.timer 32,Roleplay Duration
.target Zul'jarra
.skipgossipid 135208
step
.goto 2437,21.37,77.38
>>Kill |cRXP_ENEMY_Mor'duun|r.
.complete 86692,2 
.mob Mor'duun
step
#label DeAmaniNeverDieX
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,21.44,77.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86692 >>Turn in Blade Shattered
.accept 86693 >>Accept De Legend of de Hash'ey
.target Zul'jarra
step
.isOnQuest 86683
.hs >>Hearth to Amani'Zar Village
.cooldown item,6948,>0,1
.use 6948
step
#label DeAmaniNeverDieY
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.27,66.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86693,1 
.target Zul'jarra
.skipgossipid 134131
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.76,65.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86693 >>Turn in De Legend of de Hash'ey
.accept 91062 >>Accept Broken Bridges
.target Zul'jarra
step
#completewith next
#label Check on Zul'jan
#arrowtext Leave through the window
.goto 2437,45.81,65.11,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r |cRXP_WARN_on the bridge|r.
.complete 91062,1 
.timer Lady Liadrin Roleplay
.target Zul'jan
step
#completewith Check on Zul'jan
#arrowtext Leave through the window
.goto 2437,51.26,54.36,806 >>Leave through the Window
step
#requires Check on Zul'jan
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2437,51.26,54.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r |cRXP_WARN_on the bridge|r.
.complete 91062,1 
.timer Lady Liadrin Roleplay
.target Zul'jan
.skipgossipid 134133
step
#label DeAmaniNeverDieZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2437,50.52,54.98,10,0
.goto 2437,50.75,54.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
*Turn in the quest midair using |T5003205:0|t[Aerial Halt] |cRXP_WARN_next to |cRXP_FRIENDLY_Lady Liadrin|r in the sky|r.
.turnin 91062 >>Turn in Broken Bridges
.accept 91087 >>Accept Reports Returned
.target Lady Liadrin
step
#completewith next
#label Lightbloom Roots 1
#hidewindow
.turnin 86898 >>Turn in Rise of the Haranir
.target Orweyna
step
#completewith Lightbloom Roots 1
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires Lightbloom Roots 1
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2393,36.60,68.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 86898 >>Turn in Rise of the Haranir
.accept 93651 >>Accept The Blinding Vale: Lightbloom Roots
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Hagar|r
.goto 2393,36.57,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Hagar|r.
.accept 91084 >>Accept Looming Shadows
.accept 95324 >>Accept The War Beyond the Roots
.target Elder Hagar
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91087 >>Turn in Reports Returned
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91084 >>Turn in Looming Shadow
.turnin 95324 >>Turn in The War Beyond the Roots
.timer 50,RP
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Darkening Sky
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.goto 2393,45.37,70.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Koruth Mountainfist|r.
.accept 91854 >>Accept Deepening Shadows
.target Commander Koruth Mountainfist
step
#label DarkeningSkyB
#arrowtext Talk to\n|cRXP_FRIENDLY_Sin'dorei Fruit Vendor|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,47.18,59.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sin'dorei Fruit Vendor|r.
.complete 91854,1 
.skipgossipid 135112
.target Sin'dorei Fruit Vendor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Doomsayers|r
#loop
.goto 2393,46.54,58.88,15,0
.goto 2393,45.64,58.05,15,0
.goto 2393,43.86,58.41,15,0
.goto 2393,44.83,61.91,15,0
.goto 2393,42.31,63.93,15,0
.goto 2393,42.26,68.14,15,0
.goto 2393,42.30,72.64,15,0
.goto 2393,42.77,76.78,15,0
.goto 2393,46.19,76.57,15,0
.goto 2393,48.06,76.95,15,0
.goto 2393,51.54,70.19,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doomsayers|r.
*|cRXP_WARN_Kill the ones turning into |cRXP_ENEMY_Cultists|r|r.
*|cRXP_WARN_NOTE:|r You can gamble by flying to the next one of the current one starts casting.
.complete 91854,3 
.skipgossipid 135048
.target Doomsayer
.target Twilight's Blade Cultist
.mob Twilight's Blade Cultist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Venel Lightblood|r
.goto 2393,45.77,81.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Venel Lightblood|r.
.complete 91854,2 
.skipgossipid 135203
.skipgossipid 135204
.target Commander Venel Lightblood
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.goto 2393,45.37,70.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Koruth Mountainfist|r.
.turnin 91854 >>Turn in Deepening Shadows
.target Commander Koruth Mountainfist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.accept 91967 >>Accept You Know This Evil?
.target Lor'themar Theron
step
#completewith next
#label DarkeningSkyD
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.complete 91967,1 
.target Magister Umbric
step
#completewith DarkeningSkyD
.goto 2393,45.54,36.57,559 >>Leave the building
step
#requires DarkeningSkyD
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2393,45.54,36.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.complete 91967,1 
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hero's|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,45.65,36.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Hero's|r.
.complete 91967,2 
.complete 91967,3 
.complete 91967,4 
.skipgossipid 135139
.skipgossipid 135140
.skipgossipid 135148
.skipgossipid 135147
.skipgossipid 135149
.skipgossipid 135157
.skipgossipid 135156
.target Magister Umbric
.target Lothraxion
.target War Chaplain Senn
.mob Grand Magister Rommath
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Anduin Wrynn|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,45.56,36.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r.
.complete 91967,5 
.skipgossipid 135179
.skipgossipid 135178
.target Anduin Wrynn
step
#completewith DarkeningSkyZ
+If you are DPS, queue for Magister’s Terrace (Normal) now to reduce wait time, but do not enter the dungeon until you meet Umbric.
*|cRXP_WARN_It’s often faster than the follower dungeon run, provided the queue pops quickly|r.
.macro Queue Magister’s Terrace (Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeSpecificDungeon(); SetLFGDungeonEnabled(3085, true); LFGEnabledList[3085] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
.goto 2393,45.43,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.complete 91967,6 
.target Lor'themar Theron
step
#label DarkeningSkyZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91967 >>Turn in You Know This Evil?
.timer 60,RP
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Into the Abyss
#internal
step
#optional
.isQuestAvailable account,91967
+|cRXP_WARN_You have to do the "Darkening Sky" Chapter first|r
.clicknext RestedXP Midnight\a) Darkening Sky (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Darkening Sky (H) >>CLICK HERE FOR GUIDE << Horde
step
.xp 86 >>The voidstorm campaign unlocks at level 86
step
#label IntoTheAbyssA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 92061 >>Accept Rising Storm
.target Lor'themar Theron
step
#completewith IntoTheAbyssE
+If you are DPS, queue for Magister’s Terrace (Normal) now to reduce wait time, but do not enter the dungeon until you meet Umbric.
*|cRXP_WARN_It’s often faster than the follower dungeon run, provided the queue pops quickly|r.
.macro Queue Magister’s Terrace (Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeSpecificDungeon(); SetLFGDungeonEnabled(3085, true); LFGEnabledList[3085] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Vanguard of Light|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,45.65,46.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Vanguard of Light|r.
.complete 92061,2 
.skipgossipid 135530
.target Vanguard of Light
step
#label IntoTheAbyssB
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,38.77,47.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.complete 92061,1 
.skipgossipid 135523
.target High Exarch Turalyon
step
#label IntoTheAbyssC
#arrowtext |cRXP_WARN_Fly into the Dome|r\nTalk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 92061 >>Turn in Rising Storm
.target Lor'themar Theron
step
#label IntoTheAbyssD
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2393,45.30,70.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 86543 >>Accept Magisters' Terrace: Homecoming
.target Magister Umbric
step
#label IntoTheAbyssE

.train 1254572,3
.cast 1254572>>Use |T7439625:0|t[Path of Devoted Magistry]
.use 1254572
step
.goto 2424,62.10,14.56
#title |cFFFCDC00Follow the Arrow|r
.complete 86543,1 
.target Magister Umbric
step
.isOnQuest 86543
.goto 2424,62.10,14.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r to start the Follower Dungeon, or queue through the Dungeon Finder instead.
.enterScenario 2651 >>Queue for Magister's Terrace on (Normal) difficulty.
.skipgossipid 131939
step
#completewith next
+|cRXP_WARN_The Arrow cannot be displayed here; coordinates are unavailable|r.
step
.isInScenario 2651
>>Kill |cRXP_ENEMY_Blazing Pyromancer|r and |cRXP_ENEMY_Arcanotron Custos|r
*|cRXP_WARN_Avoid NPC's with a circle around them they teleport you away|r.
.scenario 8244,1 
.mob Arcanotron Custos
.mob Blazing Pyromancer
step
.isInScenario 2651
>>Kill |cRXP_ENEMY_Seranel Sunlash|r
.scenario 8244,2 
.mob Seranel Sunlash
step
.isInScenario 2651
#arrowtext Click on the\n|cRXP_PICK_Staff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Staff|r and complete the channel
>>Kill |cRXP_ENEMY_Devouring Tyrant|r, |cRXP_ENEMY_Shadowrift Voidcaller|r and |cRXP_ENEMY_Gemellus|r
.scenario 8244,3 
.mob Devouring Tyrant
.mob Shadowrift Voidcaller
.mob Gemellus
step
.goto 2424,62.10,14.56
>>Kill |cRXP_ENEMY_Degentrius|r (end boss) inside |cRXP_PICK_Magisters' Terrace|r.
.complete 86543,3 
.mob Degentrius
step
#completewith next
#label Magisters' Terrace: Homecoming
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86543 >>Turn in Magisters' Terrace: Homecoming
.accept 86549 >>Accept No Fear of the Dark
.disablecheckbox
.target Magister Umbric
step
#completewith Magisters' Terrace: Homecoming
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629

step
.zoneskip 2393
#completewith Magisters' Terrace: Homecoming
.zone 2424 >>Leave the instance
.cooldown item,6948,<0,1
step
#requires Magisters' Terrace: Homecoming
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2393,35.15,65.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86543 >>Turn in Magisters' Terrace: Homecoming
.accept 86549 >>Accept No Fear of the Dark
.target Magister Umbric
step
#loop
.goto 2393,35.01,65.45,6,0
.goto 2393,35.42,65.12,6,0
.goto 2393,35.44,65.99,6,0
#arrowtext Click on the |cRXP_PICK_Shadow Focus|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadow Focus|r and then on the next one.
*|cRXP_WARN_NOTE:|r You can optimize it by clicking on the orbs at maximum range.
.complete 86549,1 
step
#label Shadow Foci1
.goto 2393,35.28,66.16
#arrowtext Click on the\n|cRXP_PICK_Portal to Voidstorm|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Voidstorm|r.
.complete 86549,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,34.25,60.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86549 >>Turn in No Fear of the Dark
.accept 86558 >>Accept Save a Piece of Mind
.timer 14,RP
.target Magister Umbric
step
#arrowtext Click on the |cRXP_PICK_Shadestar Locus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,34.67,58.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadestar Locus|r.
.complete 86558,1,1 
step
#label A Matter of Strife and Death
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,34.38,60.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.accept 86557 >>Accept A Matter of Strife and Death
.target Lothraxion
step
#completewith next
>>Kill |cRXP_ENEMY_Voidbeings|r.
.complete 86557,1 
.mob Hungry Kilvore
.mob Cunning Harrower
.mob Ravenous Shredclaw
step
#loop
.goto 2405,36.21,60.10,15,0
.goto 2405,36.20,57.98,15,0
.goto 2405,34.67,58.78,15,0
#arrowtext Click on the |cRXP_PICK_Shadestar Locus|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadestar Loci|r.
.complete 86558,1 
step
#loop
.goto 2405,36.14,59.85,30,0
.goto 2405,35.11,58.93,30,0
.goto 2405,36.74,58.34,45,0
>>Kill |cRXP_ENEMY_Voidbeings|r.
.complete 86557,1 
.mob Hungry Kilvore
.mob Cunning Harrower
.mob Ravenous Shredclaw
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,36.95,58.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86557 >>Turn in A Matter of Strife and Death
.turnin 86558 >>Turn in Save a Piece of Mind
.accept 86559 >>Accept The Far, Far Frontier
.target Lothraxion
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,36.95,58.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.complete 86559,1 
.target Lothraxion
.skipgossipid 132585
step
#label IntoTheAbyssF
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,36.94,58.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria|r.
.complete 86559,2 
.target Alleria
.skipgossipid 132609

step
#completewith next
#label The Far, Far Frontier
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,36.77,58.61,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86559 >>Turn in The Far, Far Frontier
.accept 86562 >>Accept Dancing with Death
.disablecheckbox
.target Lothraxion
step
#completewith The Far, Far Frontier
.goto 2405,31.28,54.40,631 >>Go out of the NO Mount Zone
step
#requires The Far, Far Frontier
#label IntoTheAbyssG
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,31.28,54.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86559 >>Turn in The Far, Far Frontier
.accept 86562 >>Accept Dancing with Death
.target Lothraxion
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,31.34,54.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.accept 86561 >>Accept A Strange, Different World
.target Alleria Windrunner
step
#completewith next
#hidewindow
#arrowtext |cRXP_WARN_Leave the No Mount Zone|r
.goto 2405,26.28,51.04,540 >>1
step
#completewith next
>>Kill the |cRXP_ENEMY_Nexus Point forces|r.
*Loot them for |T459044:0|t[|cRXP_LOOT_Shadowgraft Fragments|r].
.complete 86561,1 
.mob Clawing Voiwalker
.mob Towering Ultradon
.mob Hovering Siphoid
.mob Lurking Creepling
.mob Whipwind Shredclaw
.mob Duskcry Voidwalker
step
#loop
.goto 2405,27.85,53.58,30,0
.goto 2405,26.05,53.11,30,0
.goto 2405,28.06,50.34,30,0
>>Kill |cRXP_ENEMY_Scytheryp the Slicer|r, |cRXP_ENEMY_Vathen the Rebel|r, and |cRXP_ENEMY_Voidgrasper|r.
.complete 86562,3 
.mob +Scytheryp the Slicer
.complete 86562,2 
.mob +Vathen the Rebel
.complete 86562,1 
.mob +Voidgrasper
step
#loop
.goto 2405,30.23,49.97,35,0
.goto 2405,30.03,54.72,45,0
.goto 2405,26.04,52.81,45,0
#arrowtext Kill |cRXP_ENEMY_Voidbeings|r\nLoot for |T459044:0|t[|cRXP_LOOT_Shadowgraft Fragments|r]
>>Kill the |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T459044:0|t[|cRXP_LOOT_Shadowgraft Fragments|r].
.complete 86561,1 
.mob Clawing Voiwalker
.mob Towering Ultradon
.mob Hovering Siphoid
.mob Lurking Creepling
.mob Whipwind Shredclaw
.mob Duskcry Voidwalker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,27.44,50.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86561 >>Turn in A Strange, Different World
.turnin 86562 >>Turn in Dancing with Death
.accept 86565 >>Accept No Prayer for the Wicked
.target Lothraxion
step
#completewith next
#label NoPrayerForTheWickedA
>>Leave the no-mount zone and fly to the waypoint
*Reduce |cRXP_ENEMY_Sinewshredder|r to low health, |cRXP_WARN_but do not kill it yet|r.
.complete 86565,1 
step
#completewith NoPrayerForTheWickedA
.goto 2405,27.44,51.02
#arrowtext Click on the |cRXP_PICK_Metal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.cast 1233238 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Metal|r.
.timer 16.5,Roleplay Duration
step
#requires NoPrayerForTheWickedA
.goto 2405,27.24,51.03,7,0
.goto 2405,26.29,51.42
#arrowtext |cFFFCDC00Follow the Arrow|r
*Reduce |cRXP_ENEMY_Sinewshredder|r to low health, |cRXP_WARN_but do not kill it yet|r.
.complete 86565,1 
step
.goto 2405,26.29,51.42
>>Kill |cRXP_ENEMY_Sinewshredder|r.
.complete 86565,2 
.mob Sinewshredder
step
#arrowtext Click on the |cRXP_PICK_Orb|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,26.41,51.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
.complete 86565,3 
step
#label IntoTheAbyssZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,35.37,59.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86565 >>Turn in No Prayer for the Wicked
.target Lothraxion
.accept 86536 >>Accept Reliable Enemies
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Night's Veil
#internal
step
#optional
.isQuestAvailable 86565
+|cRXP_WARN_You have to do the "Into the Abyss" Chapter first|r
.clicknext RestedXP Midnight\a) Into the Abyss (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Into the Abyss (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TheNightsVeilA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,35.37,59.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.accept 86536 >>Accept Reliable Enemies
.target Lothraxion
step
#label TheNightsVeilB
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,35.37,58.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86536,1 
.target Decimus
.skipgossipid 132848
step
#completewith next
#label TheNightsVeilC
#hidewindow
#arrowtext Leave the NO MOUNT zone
.goto 2405,35.52,59.19,5,0
.complete 86536,2 
step
#completewith TheNightsVeilC
.goto 2405,35.37,59.26,937 >>Leave the No Mount Zone
step
#requires TheNightsVeilC
#label Ethereum Refinery
.goto 2405,36.72,72.93
#title |cFFFCDC00Follow the Arrow|r
.complete 86536,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,36.72,72.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86536,3 
.target Decimus
.skipgossipid 135460
.skipgossipid 135469
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,36.64,72.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86536 >>Turn in Reliable Enemies
.accept 86531 >>Accept Work Disruption
.target Alleria Windrunner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,36.71,73.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.accept 86530 >>Accept First, The Shells
.target Lothraxion
step
#loop
.goto 2405,36.29,73.57,35,0
.goto 2405,38.03,78.18,35,0
.goto 2405,35.82,79.06,35,0
.goto 2405,34.62,75.48,45,0
#arrowtext Kill |cRXP_ENEMY_Manaforge forces|r\nLoot for |T236874:0|t[|cRXP_LOOT_Empty Manacells|r]\nClick on |cRXP_PICK_Objects|r
>>Kill |cRXP_ENEMY_Manaforge forces|r.
*> Loot them for the |T236874:0|t[|cRXP_LOOT_Empty Manacells|r].
*> |TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Unstable Collector|r and |cRXP_PICK_Vulnerable Piping|r.
.complete 86530,1 
.complete 86531,1 
.accept 86528 >>Accept A Cracked Holokey
.mob Recommissioned Mech
.mob Manaforge Siphoner
.mob Manaforge Netherdrifter
.mob Manaforge Warder
.mob Devouring Enforcer
.use 241000
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Lothraxion|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86531 >>Turn in Work Disruption
.turnin 86528 >>Turn in A Cracked Holokey
.goto 2405,36.28,80.43
.target +Alleria Windrunner
.turnin 86530 >>Turn in First, The Shells
.accept 86538 >>Accept Second, The Fuel
.goto 2405,36.26,80.59
.target +Lothraxion
.accept 86537 >>Accept Network Insecurity
.goto 2405,36.28,80.43
.target +Alleria Windrunner
step
#completewith NetworkInsecurityA2
>>Kill |cRXP_ENEMY_Voidbeings|r.
*> Loot them for the |T132854:0|t[|cRXP_LOOT_Arcane Remnants|r].
*> |TInterface/cursor/crosshair/interact.blp:15|tClick on the |cRXP_PICK_Arcane Remnants|r.
.complete 86538,1 
.mob Forge Manacapturer
.mob Manaforge Engineer
.mob Conflux Monstrosity
.mob Mana Coalescence
step
#arrowtext Click on the |cRXP_PICK_Console|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,34.20,80.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r.
.complete 86537,1 
step
#arrowtext Click on the |cRXP_PICK_Console|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,33.53,81.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r.
.complete 86537,2 
step
#arrowtext Click on the |cRXP_PICK_Console|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,33.65,79.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r.
.complete 86537,3 
step
#arrowtext Click on the |cRXP_PICK_Console|r
.goto 2405,34.61,77.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r |cRXP_WARN_inside the building|r.
.complete 86537,4 
step
#label NetworkInsecurityA2
.goto 2405,34.56,78.00
#arrowtext Kill the |cRXP_ENEMY_Tempest Keeper|r\nLoot for |T6361900:0|t[|cRXP_LOOT_Encrypted Device|r]
>>Kill the |cRXP_ENEMY_Tempest Keeper|r.
*> Loot him for the |T6361900:0|t[|cRXP_LOOT_Encrypted Device|r].
.complete 86537,5 
.mob Tempest Keeper
step
#loop
.goto 2405,35.70,80.96,35,0
.goto 2405,33.11,80.41,35,0
.goto 2405,33.35,77.09,35,0
.goto 2405,34.18,79.01,35,0
#arrowtext Kill |cRXP_ENEMY_Manaforge Refinery forces|r\nLoot for |T132854:0|t[|cRXP_LOOT_Arcane Remnants|r]
>>Kill the |cRXP_ENEMY_Manaforge Refinery forces|r.
*> Loot them for the |T132854:0|t[|cRXP_LOOT_Arcane Remnants|r].
*> |TInterface/cursor/crosshair/interact.blp:15|tClick on the |cRXP_PICK_Arcane Remnants|r.
.complete 86538,1 
.mob Forge Manacapturer
.mob Manaforge Engineer
.mob Conflux Monstrosity
.mob Mana Coalescence
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,36.27,80.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86538 >>Turn in Second, The Fuel
.target Lothraxion
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,36.28,80.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86537 >>Turn in Network Insecurity
.timer 16.5,RP
.target Alleria Windrunner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,36.27,80.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r after the roleplay.
.accept 86539 >>Accept A Naaru!
.target Lothraxion
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,39.35,82.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86539 >>Turn in A Naaru!
.accept 86540 >>Accept Third, Blow It Up
.target Lothraxion
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Decimus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Decimus|r.
.accept 88768 >>Accept Agents of Darkness
.goto 2405,39.40,82.19
.target +Alleria Windrunner
.accept 86541 >>Accept Just In Case...
.goto 2405,39.45,82.14
.target +Decimus
step
#completewith Darkened Unbound
>>Kill the |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T6012006:0|t[|cRXP_LOOT_Fragmented Keystone|r].
.complete 86541,1 
.mob Collapsing Voidcaller
.mob Entropy Orbiter
.mob Assimilated Netherdrifter
step
#completewith Darkened Unbound
#arrowtext Click on the\n|cRXP_PICK_Manacells|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Manacells|r.
.complete 86540,1 
step
#completewith next
#label Darkened Unbound
>>Kill |cRXP_ENEMY_Insatiable Watcher|r, |cRXP_ENEMY_Darkened Unbound|r and |cRXP_ENEMY_Nethermade Protector|r.
*|cRXP_WARN_Ignore |cRXP_ENEMY_Assimilated Ultradons|r|r
.complete 88768,1 
.complete 88768,2 
.mob Darkened Unbound
.mob Insatiable Watcher
.mob Nethermade Protector
step
#completewith Darkened Unbound
#hidewindow
.goto 2405,38.73,87.41,25 >>1
step
#requires Darkened Unbound
#loop
.goto 2405,37.43,88.79,25,0
.goto 2405,37.33,88.47,10,0
.goto 2405,37.13,88.43,10,0
#arrowtext Click on the |cRXP_PICK_Manacell|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Manacells|r.
.complete 86540,1 
step
#hidewindow
#completewith Fragmented Keystone
#loop
.goto 2405,37.77,85.45,25,0
.goto 2405,41.15,85.02,25,0
.goto 2405,38.77,87.35,25,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T6012006:0|t[|cRXP_LOOT_Fragmented Keystone|r].
.complete 86541,1 
step
>>Kill |cRXP_ENEMY_Insatiable Watcher|r, |cRXP_ENEMY_Darkened Unbound|r and |cRXP_ENEMY_Nethermade Protector|r.
.complete 88768,1 
.complete 88768,2 
.complete 88768,3 
.mob Darkened Unbound
.mob Insatiable Watcher
.mob Nethermade Protector
step
#label Fragmented Keystone
>>Kill the |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T6012006:0|t[|cRXP_LOOT_Fragmented Keystone|r].
.complete 86541,1 
step
>>Use the |T6012006:0|t[Fragmented Keystone].
.complete 86541,2 
.use 237895
step
#completewith next
#label AgentsOfDarknessA
#arrowtext |cRXP_WARN_Enter the tunnel|r
.goto 2405,38.52,83.74,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 88768 >>Turn in Agents of Darkness
.target Alleria Windrunner
step
#completewith AgentsOfDarknessA
#arrowtext |cRXP_WARN_Enter the tunnel|r
.goto 2405,37.96,83.35,65 >>|cRXP_WARN_Enter the tunnel|r.
step
#requires AgentsOfDarknessA
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,37.96,83.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 88768 >>Turn in Agents of Darkness
.target Alleria Windrunner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,37.92,83.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 86541 >>Turn in Just In Case...
.target Decimus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,37.97,83.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86540 >>Turn in Third, Blow It Up
.accept 86542 >>Accept Flicker in the Dark
.target Lothraxion
step
#arrowtext Click on the |cRXP_PICK_Console|r
.goto 2405,37.92,83.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r.
.complete 86542,1 
step
.goto 2405,38.51,83.70
#title |cFFFCDC00Leave the tunnel|r
.complete 86542,2 
step
#loop
.goto 2405,39.03,85.74,30,0
.goto 2405,38.48,85.74,30,0
.goto 2405,38.68,85.19,30,0
>>Kill |cRXP_ENEMY_Dark Splinter|r.
.complete 86542,3 
.mob Dark Splinter
step
#arrowtext Damage |cRXP_ENEMY_T'era|r\nuntil 25%
.goto 2405,38.7,85.55
>>Defeat |cRXP_ENEMY_T'era|r.
.complete 86542,4 
.mob T'era
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,41.60,78.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86542 >>Turn in Flicker in the Dark
.target Alleria Windrunner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
#label Overwhelmed2
.goto 2405,41.63,78.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 89249 >>Accept Overwhelmed
.target Arator
step
#completewith next
#label Overwhelmed
#arrowtext Leave the No Mount Zone
.goto 2405,41.68,78.58,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 89249 >>Turn in Overwhelmed
.accept 86544 >>Accept Post-Mortem
.disablecheckbox
.target Arator
step
#completewith Overwhelmed
.goto 2405,41.72,74.71,262 >>Leave the No Mount Zone
step
#requires Overwhelmed
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,41.72,74.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 89249 >>Turn in Overwhelmed
.accept 86544 >>Accept Post-Mortem
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Hieron|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.84,74.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Hieron|r.
.complete 86544,2 
.target Riftwalker Hieron
.skipgossipid 132751
step
#label Overwhelmed Scouts
#loop
.goto 2405,42.11,75.27,10,0
.goto 2405,42.34,75.44,10,0
#arrowtext Scouts assisted (2/3)\n|cRXP_ENEMY_(FRIENDLY NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scout|r.
*> Defeat them if they turn hostile.
.complete 86544,4,2 
.target Overwhelmed Scout
.mob Overwhelmed Scout
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,42.18,74.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.complete 86544,3 
.target Riftblade Maella
.skipgossipid 132752
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.64,73.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86544,6 
.target Decimus
.skipgossipid 132757
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.46,73.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.complete 86544,5 
.target Lothraxion
.skipgossipid 132756
step
#label Maella's Report
#arrowtext Scouts assisted (3/3)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(FRIENDLY NOT SHARED)|r
.goto 2405,41.66,74.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scout|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86544,4 
.target Overwhelmed Scout
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,41.72,74.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86544 >>Turn in Post-Mortem
.timer 5,RP
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,41.72,74.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86545 >>Accept The Light's Brand
.target Arator
step
#completewith next
#hidewindow
#arrowtext |cRXP_WARN_Leave the No Mount Zone|r
.goto 2405,41.73,74.53,7 >>1
step
.goto 2405,40.76,72.37
#title |cFFFCDC00Follow the Arrow|r
.complete 86545,1 
step
#label TheNightsVeilZYX
#loop
.goto 2405,40.76,72.37,30,0
.goto 2405,41.2,71.86,30,0
.goto 2405,41.53,72.55,30,0
.goto 2405,41.05,72.75,10,0
>>Absorb orbs by running through them.
*> You can return up to 5 orbs at a time, and each pickup deals increasingly more damage.
*> |Tinterface/worldmap/chatbubble_64grey.blp:15|tTalk to |cRXP_FRIENDLY_Arator|r for |cRXP_WARN_healing|r.
.complete 86545,3 
.timer 9.5,RP
.skipgossipid 133892
step
#arrowtext Click on |cRXP_PICK_Decimus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.17,72.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Decimus|r after the roleplay.
.complete 86545,4 
.mob Decimus
.timer 6.8,RP
step
#label TheNightsVeilZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r after the roleplay
.goto 2405,41.14,72.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r after the roleplay.
.turnin 86545 >>Turn in The Light's Brand
.target Alleria Windrunner
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Dawn of Reckoning
#internal
step
#optional
.isQuestAvailable 86545
+|cRXP_WARN_You have to do the "The Night's Veil " Chapter first|r
.clicknext RestedXP Midnight\a) The Night's Veil (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) The Night's Veil (H) >>CLICK HERE FOR GUIDE << Horde
step
#label DawnOfReckoningA
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,41.17,72.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.accept 86509 >>Accept Friend or Fiend
.target Decimus
step
.goto 2405,51.41,72.86
#title |cFFFCDC00Follow the Arrow|r
.complete 86509,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.41,72.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 86509 >>Turn in Friend or Fiend
.accept 86510 >>Accept Domus Penumbra

.target Decimus
step
#label Researching the Storm
#arrowtext Talk to\n|cRXP_FRIENDLY_Void Researcher Anomander|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,52.58,72.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Void Researcher Anomander|r.
.complete 86510,1 
.accept 93970 >>Accept Researching the Storm
.target Void Researcher Anomander
.skipgossipid 138232
step
.goto 2405,52.62,72.87
#arrowtext Click on the\n|cRXP_PICK_Console|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r and select a trait.
.complete 93970,1 
.complete 93970,2 
.skipgossipid 137576
step
#label Process a Void Sample
.goto 2405,52.58,72.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Void Researcher Anomander|r.
.turnin 93970 >>Turn in Researching the Storm
.target Void Researcher Anomander
step
#completewith next
#label Innkeeper Hospitus
#arrowtext |cRXP_WARN_Enter the inn|r
.goto 2405,52.71,68.71,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Hospitus|r.
.complete 86510,2 
.target Innkeeper Hospitus
step
#completewith Innkeeper Hospitus
.goto 2405,53.15,68.18,60 >>Enter the Inn
step
#requires Innkeeper Hospitus
#arrowtext Talk to\n|cRXP_FRIENDLY_Innkeeper Hospitus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,53.15,68.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Hospitus|r.
.complete 86510,2 
.target Innkeeper Hospitus
step
#completewith next
#label Help Umbric establish a portal
#arrowtext |cRXP_WARN_Leave the inn|r
.goto 2405,52.65,68.75,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bones|r.
.complete 86510,3 
step
#completewith Help Umbric establish a portal
.goto 2405,51.62,70.04,140 >>Leave the Inn
step
#requires Help Umbric establish a portal
#arrowtext Click on the |cRXP_PICK_Bones|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,51.62,70.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bones|r.
.complete 86510,3 
step
#arrowtext Click on the |cRXP_PICK_Meat|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,51.23,69.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Meat|r.
.complete 86510,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.03,67.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 86510 >>Turn in Domus Penumbra
.accept 90571 >>Accept The Lay of the Beast
.target Decimus
step
#completewith next
#hidewindow
#label TheLayOfTheBeastA
.complete 90571,2 
step
#completewith TheLayOfTheBeastA
#arrowtext Click on the |cRXP_PICK_Jellyfish|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,50.97,68.00
.vehicle 238287 >>Click on the |cRXP_PICK_Jellyfish|r.
.timer 7.5,RP
step
#requires TheLayOfTheBeastA
#arrowtext |T965900:0|t[Void Rush] (2) |cRXP_WARN_speed|r\n|T1386549:0|t[Scry] (1) on |cRXP_WARN_arrow marker|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,47.51,61.56
>> Use |T1386549:0|t[Scry] (1) on the arrow marker.
*> Use |T965900:0|t[Void Rush] (2) for speed, |T132331:0|t[Ink Cloud] (3) to hide.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90571,2,1 
step
#arrowtext |T965900:0|t[Void Rush] (2) |cRXP_WARN_speed|r\n|T1386549:0|t[Scry] (1) on |cRXP_WARN_arrow marker|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,49.30,58.99
>>Use |T1386549:0|t[Scry] (1) on the arrow marker.
*> Use |T965900:0|t[Void Rush] (2) for speed, |T132331:0|t[Ink Cloud] (3) to hide.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90571,2,2 
step
#arrowtext |T965900:0|t[Void Rush] (2) |cRXP_WARN_speed|r\n|T1386549:0|t[Scry] (1) on |cRXP_WARN_arrow marker|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,51.44,55.91
>>Use |T1386549:0|t[Scry] (1) on the arrow marker.
*> Use |T965900:0|t[Void Rush] (2) for speed, |T132331:0|t[Ink Cloud] (3) to hide.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90571,2 
step
#completewith next
#label Lay of the Beast
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90571 >>Turn in The Lay of the Beast
.target Decimus
step
#completewith Lay of the Beast
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Lay of the Beast
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.03,67.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90571 >>Turn in The Lay of the Beast
.target Decimus
step
#label Edge of the Abyss
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,51.06,68.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.accept 86511 >>Accept Edge of the Abyss
.target Alleria Windrunner
step
#completewith next
#label Riftblade Maella
#arrowtext |cRXP_WARN_Leave No Mount Zone|r
.goto 2405,51.13,68.21,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.complete 86511,1 
.target Riftblade Maella
step
#completewith Riftblade Maella
#hidewindow
#arrowtext |cRXP_WARN_Leave No Mount Zone|r
.goto 2405,54.35,74.25,528 >>Leave the NO mount zone.
step
#requires Riftblade Maella
#completewith next
#hidewindow
.gossipoption 132535 >>1
.timer 11,Roleplay Duration
step
#requires Riftblade Maella
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,54.35,74.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r and wait for the roleplay.
.complete 86511,1 
.target Riftblade Maella
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,54.36,74.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86511 >>Turn in Edge of the Abyss
.target Alleria Windrunner
step
#label Harvest
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r and |cRXP_FRIENDLY_Arator|r
.goto 2405,54.32,74.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r and |cRXP_FRIENDLY_Arator|r.
.accept 86512 >>Accept The Harvest
.accept 86513 >>Accept Face the Tide
.target Decimus
.target Arator
step
#hidewindow
#completewith Torentia's attention
#arrowtext Click on |cRXP_PICK_Flesh|r\n|cRXP_PICK_Void Gates|r and |cRXP_PICK_Cages|r
#loop
.goto 2405,55.06,73.53,15,0
.goto 2405,55.02,73.34,15,0
.goto 2405,54.79,73.29,15,0
.goto 2405,55.03,72.99,15,0
.goto 2405,54.98,72.76,15,0
.goto 2405,56.5,70.69,15,0
.goto 2405,56.65,70.52,15,0
.goto 2405,56.67,70.93,15,0
.goto 2405,57.44,71.21,15,0
.goto 2405,57.26,71.34,15,0
.goto 2405,56.11,72.06,15,0
.goto 2405,55.96,71.97,15,0
.goto 2405,55.81,71.98,15,0
.goto 2405,55.92,72.51,15,0
.goto 2405,56.2,72.72,15,0
.goto 2405,56.09,73.4,15,0
.goto 2405,55.32,75.07,30,0
.goto 2405,54.82,74.46,30,0
.goto 2405,56.05,72.13,30,0
.goto 2405,56.14,69.74,30,0
.goto 2405,57.34,71.76,30,0
+1
step
#completewith Captives freed1
>>Kill |cRXP_ENEMY_Voidbeings|r
.complete 86512,1 
.mob Trench Shredclaw
.mob Scrabbling Voidspawn
.mob Hungering Voidwrath
.mob Ravenous Voidwalker
.mob Drifting Siphoid
.mob Marrowmouth Consumptor
step
#completewith Captives freed1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flesh|r.
.complete 86513,1 
step
#completewith Captives freed1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Gate|r.
.complete 86513,2 
step
#label Captives freed1
#arrowtext Click on the\n|cRXP_PICK_Cages|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cages|r.
.complete 86513,3 
step
#completewith Captives freed2
>>Kill |cRXP_ENEMY_Voidbeings|r
.complete 86512,1 
.mob Trench Shredclaw
.mob Scrabbling Voidspawn
.mob Hungering Voidwrath
.mob Ravenous Voidwalker
.mob Drifting Siphoid
.mob Marrowmouth Consumptor
step
#completewith Captives freed2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Gate|r.
.complete 86513,2 
step
#label Captives freed2
#arrowtext Click on the\n|cRXP_PICK_Flesh|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flesh|r.
.complete 86513,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Voidbeings|r
.complete 86512,1 
.mob Trench Shredclaw
.mob Scrabbling Voidspawn
.mob Hungering Voidwrath
.mob Ravenous Voidwalker
.mob Drifting Siphoid
.mob Marrowmouth Consumptor
step
#arrowtext Click on the\n|cRXP_PICK_Void Gate|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Gate|r.
.complete 86513,2 
step
#label Torentia's attention
>>Kill |cRXP_ENEMY_Voidbeings|r
.complete 86512,1 
.mob Trench Shredclaw
.mob Scrabbling Voidspawn
.mob Hungering Voidwrath
.mob Ravenous Voidwalker
.mob Drifting Siphoid
.mob Marrowmouth Consumptor
step
#label Torentia's attention
#loop
.goto 2405,56.16,73.09,20,0
.goto 2405,55.81,73.91,20,0
.goto 2405,55.53,72.87,20,0
.goto 2405,55.28,72.04,30,0
.goto 2405,56.62,71.34,30,0
.goto 2405,56.23,69.89,30,0
>>Kill |cRXP_ENEMY_Voidbeings|r
.complete 86512,1 
.mob Trench Shredclaw
.mob Scrabbling Voidspawn
.mob Hungering Voidwrath
.mob Ravenous Voidwalker
.mob Drifting Siphoid
step
#label Face the Tide
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,55.62,72.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86513 >>Turn in Face the Tide
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,55.57,72.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86512 >>Turn in The Harvest
.accept 86514 >>Accept Lady of the Pit
.target Alleria Windrunner
step
#arrowtext Use the ExtraActionButton
.goto 2405,55.54,76.56
>>Use the |T6035316:0|t[|cRXP_WARN_ExtraActionButton|r] |cRXP_WARN_if noone has yet & might have to wait on respawn|r.
*> Defeat |cRXP_ENEMY_Torentia|r.
.complete 86514,1 
.complete 86514,2 
.timer 10,RP
.mob Torentia
step
#arrowtext Click on |cRXP_PICK_Torentia|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,55.59,78.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Torentia|r after the roleplay.
.complete 86514,3 
step
#arrowtext Use the ExtraActionButton\n|cRXP_ENEMY_(NOT SHARED)|r
>>Use the |T5976939:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 86514,4 
step
#completewith next
#label LadyOfThePitA
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2405,60.77,74.31,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86514 >>Turn in Lady of the Pit
.accept 86516 >>Accept All Become Prey
.target Alleria Windrunner
step
#completewith LadyOfThePitA
#arrowtext Enter the cave
.goto 2405,60.79,73.62,50 >>|cRXP_WARN_Enter the cave.|r
step
#requires LadyOfThePitA
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,60.79,73.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86514 >>Turn in Lady of the Pit
.accept 86516 >>Accept All Become Prey
.target Alleria Windrunner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Lothraxion|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Lothraxion|r.
.accept 86517 >>Accept Vanished in the Void
.goto 2405,60.82,73.56
.target +Arator
.accept 86515 >>Accept Hollow Hunger
.goto 2405,60.71,73.62
.target +Lothraxion
step
#completewith next
#label Riftblade Maella found
#hidewindow
#arrowtext |cRXP_WARN_Leave the cave|r
.goto 2405,60.78,74.32,7,0
.complete 86517,1 
step
#completewith Riftblade Maella found
#arrowtext |cRXP_WARN_Leave the cave|r
.goto 2405,60.42,78.86,317 >>Leave the cave
step
#requires Riftblade Maella found
#completewith HollowHungerA
>>Weaken |cRXP_PICK_Ultradons|r with |T1386551:0|t[Essences] from |cRXP_PICK_|TInterface/cursor/crosshair/interact.blp:18|tSlain Beasts|r and |cRXP_ENEMY_|TInterface/cursor/crosshair/attack.blp:13|tVoidbeings|r, then kill them.
.complete 86516,2 
.collect 237807,5,86516,0x2,-1
.target Slain Beast
.mob Slavering Ultradon
step
#requires Riftblade Maella found
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,60.42,78.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.complete 86517,1 
.target Riftblade Maella
.skipgossipid 132554
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Darkglen|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,61.18,80.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.complete 86517,2 
.target Lady Darkglen
.skipgossipid 132555
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Hieron|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,62.42,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Hieron|r.
.complete 86517,3 
.target Riftwalker Hieron
.skipgossipid 132556
step
#label Riftwalker Hieron
#arrowtext Click on the |cRXP_PICK_Journal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,62.41,82.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Journal|r.
.complete 86517,4 
step
#arrowtext Kill |cRXP_ENEMY_Severum|r\nLoot for |T5976941:0|t[|cRXP_LOOT_Severum's Sigil|r]
.goto 2405,64.19,75.60
>>Kill |cRXP_ENEMY_Severum|r in the building.
*Loot him for |T5976941:0|t[|cRXP_LOOT_Severum's Sigil|r].
.complete 86515,1 
.mob Severum
step
#label HollowHungerA
#arrowtext Use the ExtraActionButton\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,64.19,75.60
>>Use the |T5976941:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 86515,2 
step
#loop
.goto 2405,57.72,73.48,50,0
.goto 2405,60.19,80.17,50,0
.goto 2405,63.46,74.85,50,0
#arrowtext Kill |cRXP_ENEMY_Ultradons|r\nWeaken them with |T1386551:0|t[Essences] first
>>Weaken |cRXP_PICK_Ultradons|r with |T1386551:0|t[Essences] from |cRXP_PICK_|TInterface/cursor/crosshair/interact.blp:18|tSlain Beasts|r and |cRXP_ENEMY_|TInterface/cursor/crosshair/attack.blp:13|tVoidbeings|r, then kill them.
.complete 86516,2 
.collect 237807,5,86516,0x2,-1
.target Slain Beast
.mob Slavering Ultradon
step
#completewith next
#label VanishedInHollowPreyA
#hidewindow
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2405,60.77,74.31,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r, |cRXP_FRIENDLY_Lothraxion|r, and |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86517 >>Turn in Vanished in the Void
.target +Arator
.turnin 86515 >>Turn in Hollow Hunger
.target +Lothraxion
.turnin 86516 >>Turn in All Become Prey
.target +Alleria Windrunner
step
#completewith VanishedInHollowPreyA
#arrowtext Enter the cave
.goto 2405,60.80,73.72,50 >>|cRXP_WARN_Enter the cave|r.
step
#requires VanishedInHollowPreyA
#arrowtext Talk to |cRXP_FRIENDLY_Arator|r,\n|cRXP_FRIENDLY_Lothraxion|r, and |cRXP_FRIENDLY_Alleria Windrunner|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r, |cRXP_FRIENDLY_Lothraxion|r, and |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86517 >>Turn in Vanished in the Void
.goto 2405,60.80,73.72
.target +Arator
.turnin 86515 >>Turn in Hollow Hunger
.goto 2405,60.71,73.62
.target +Lothraxion
.turnin 86516 >>Turn in All Become Prey
.accept 86518 >>Accept The Mantle of Predation
.goto 2405,60.79,73.61
.target +Alleria Windrunner
step
#label Xenas2
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,60.79,73.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.complete 86518,2 
.target Alleria Windrunner
.skipgossipid 132795
step
#completewith next
#label TheMantleOfPredictionA
#arrowtext |cRXP_WARN_Leave the cave|r
.goto 2405,60.82,74.37,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vault Seal|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86518,3,1 
step
#completewith TheMantleOfPredictionA
#arrowtext |cRXP_WARN_Leave the cave|r
.goto 2405,63.39,78.51,385 >>|cRXP_WARN_Leave the building|r.
step
#requires TheMantleOfPredictionA
#arrowtext Seals undone (1/2)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,63.39,78.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seal|r |cRXP_WARN_inside the building|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86518,3,1 
step
#arrowtext Seals undone (2/2)\n|cFFFCDC00(Read Note)|r|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,62.59,80.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seal|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86518,3 
step
#completewith next
#label TheMantleOfPredictionC
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86518,4 
step
#completewith TheMantleOfPredictionC
#arrowtext Click on the |cRXP_PICK_Chest|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,64.39,80.85
.cast 1228485 >>|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Chest|r.
.timer 29.5,Roleplay Duration
step
#requires TheMantleOfPredictionC
.goto 2405,64.39,80.85
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86518,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,60.34,76.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86518 >>Turn in The Mantle of Predation
.accept 86519 >>Accept Abyssus, Abyssum
.target Alleria Windrunner
step
#loop
.goto 2405,60.96,76.13,35,0
.goto 2405,60.99,77.15,35,0
.goto 2405,60.03,76.99,35,0
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Use the |T5927636:0|t|cRXP_WARN_[ExtraActionButton]|r for damage and healing.
.complete 86519,1 
.mob Gaunt Harrower
.mob Starved Voidwalker
.mob Dwindling Wraith
.mob Enraged Ultradon
.mob Swarming Pitspawn
.mob Offworld Pitfighter
step
#completewith Kasreth
+If you are DPS, queue for Nexus-Point Xenas (Normal) now to reduce wait time, but do not enter the dungeon until you have the quest.
*|cRXP_WARN_It’s often faster than the follower dungeon run, provided the queue pops quickly|r.
.macro Queue Nexus-Point Xenas (Normal) Dungeon,1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeSpecificDungeon(); SetLFGDungeonEnabled(3056, true); LFGEnabledList[3056] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
#arrowtext Damage |cRXP_ENEMY_Alleria Windrunner|r to 30%
.goto 2405,60.92,76.89
>>Damage |cRXP_ENEMY_Alleria Windrunner|r to 30%.
*|cRXP_WARN_NOTE:|r Interrupt |cRXP_PICK_Voidstalker Sting|r as often as possible
.complete 86519,2 
.mob Alleria Windrunner
step
#label Abyssus
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,60.09,76.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86519 >>Turn in Abyssus, Abyssum
.accept 86520 >>Accept Hunt the Light
.target Alleria Windrunner

step
.isOnQuest 86521

.train 124563,3
.cast 1254563 >>Use |T7553062:0|t[Path of the Fractured Core]
.use 1254563
step
#label XenasZ
.goto 2405,64.10,61.84
#title |cFFFCDC00Follow the Arrow|r
.complete 86520,1 
step
#label Hunt the Light
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,64.10,61.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86520 >>Turn in Hunt the Light
.accept 86521 >>Accept Nexus-Point Xenas: Eclipse
.target Alleria Windrunner
step
#label XenasZZ
.isOnQuest 86521
.goto 2405,64.10,61.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r to start the Follower Dungeon, or queue through the Dungeon Finder instead.
.enterScenario 3132 >>Queue for Nexus-Point Xenas on (Normal) difficulty
.macro Queue Nexus-Point Xenas (Normal) Dungeon,1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeSpecificDungeon(); SetLFGDungeonEnabled(3056, true); LFGEnabledList[3056] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
.skipgossipid 132672
step
#label Kasreth
.isInScenario 3132
>>Kill |cRXP_ENEMY_Kasreth|r (left side), then click the console behind him.
.scenario 15982,1 
.mob Kasreth
step
.isInScenario 3132
>>Kill |cRXP_ENEMY_Kasreth|r (right side), then click the console behind him.
.scenario 15982,2 
.mob Corewarden Nysarra
step
#label DawnOfReckoningX
#arrowtext Click on the\n|cRXP_PICK_Console|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r near the entrance and complete the channel.
*> Kill |cRXP_ENEMY_Lothraxion|r.
.complete 86521,3 
.mob Lothraxion
step
#completewith next
#label NexusPointXenasEclipseA
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86521,4 
.target Decimus
step
#completewith NexusPointXenasEclipseA
#label DecimusXenas
#arrowtext Leave the instance
.zone 2405 >>Click the macro under the "Active Items Frame"
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#requires NexusPointXenasEclipseA
#label DawnOfReckoningY
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,45.94,64.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86521,4 
.target Decimus
.skipgossipid 132673
step
#label Xenas
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,45.96,64.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86521 >>Turn in Nexus-Point Xenas: Eclipse
.accept 86522 >>Accept Daylight is Breaking
.target Alleria Windrunner
step
#completewith next
#label DawnOfReckoningYA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86522 >>Turn in Daylight is Breaking
.target Lor'themar Theron
step
#completewith DawnOfReckoningYA
.zoneskip 2405,1
.zone 2393 >>Click on the |cRXP_PICK_Portal to Silvermoon|r
.goto 2405,51.56,70.29
step
#requires DawnOfReckoningYA
.goto 2393,45.45,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86522 >>Turn in Daylight is Breaking
.target Lor'themar Theron
step
#label DawnOfReckoningZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.45,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86522 >>Turn in Daylight is Breaking
.accept 95276 >>Accept The Last Push
.turnin 95276 >>Turn in The Last Push
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Regent's Request
#internal
step
#label TheRegentsRequestA
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2393,52.55,78.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 91822 >>Accept The Regent's Request
.target Valeera Sanguinar
step
#label TheRegentsRequestB
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,33.55,36.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.complete 91822,1 
.skipgossipid 135475
.target Lor'themar Theron
step
#label Dead Men Keep No Secrets
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2395,61.89,68.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 91822 >>Turn in The Regent's Request
.target Valeera Sanguinar
.accept 91823 >>Accept Lines Cut, Tongues Silenced
.accept 91825 >>Accept Dead Men Keep No Secrets
.accept 91824 >>Accept The Thieves' Trail
step
#completewith Communications Orb
>>Kill |cRXP_ENEMY_Twilight Cultists|r
*Loot them for |T4555667:0|t[|cRXP_LOOT_Quel'dorei Artifact|r].
.complete 91824,1 
.mob Twilight Agent
.mob Twilight Voidcaster
.mob Twilight Bonebreaker
step
#arrowtext Orb destroyed (1/4)\n|cFFFCDC00(Read Note)|r
.goto 2395,62.77,69.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91823,1,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Gareth the Listener|r
*Loot them for |T1001980:0|t[|cRXP_LOOT_Infiltrator's Cache|r].
.complete 91825,1 
.mob Gareth the Listener
step
#arrowtext Orb destroyed (2/4)\n|cFFFCDC00(Read Note)|r
.goto 2395,63.11,70.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91823,1,2 
step
.goto 2395,63.11,70.71
>>Kill |cRXP_ENEMY_Gareth the Listener|r
*Loot them for |T1001980:0|t[|cRXP_LOOT_Infiltrator's Cache|r].
.complete 91825,1 
.mob Gareth the Listener
step
#arrowtext Orb destroyed (3/4)\n|cFFFCDC00(Read Note)|r
.goto 2395,62.59,71.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91823,1,3 
step
#label Communications Orb
#arrowtext Orb destroyed (4/4)\n|cFFFCDC00(Read Note)|r
.goto 2395,61.99,70.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91823,1,4 
step
#loop
.goto 2395,61.05,72.64,30,0
.goto 2395,62.05,69.31,30,0
.goto 2395,62.85,71.88,30,0
>>Kill |cRXP_ENEMY_Twilight Cultists|r
*Loot them for |T4555667:0|t[|cRXP_LOOT_Quel'dorei Artifact|r].
.complete 91824,1 
.mob Twilight Agent
.mob Twilight Voidcaster
.mob Twilight Bonebreaker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2395,61.89,68.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 91823 >>Turn in Lines Cut, Tongues Silenced
.target Valeera Sanguinar
.turnin 91824 >>Turn in The Thieves' Trail
.turnin 91825 >>Turn in Dead Men Keep No Secrets
.accept 91826 >>Accept Tripwire Tango
step
#completewith next
#label Trap mechanism disarmed
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cogwheel|r that rotates differently.
.complete 91826,1 
step
#completewith Trap mechanism disarmed
#arrowtext Click on the |cRXP_PICK_Chest|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,61.91,68.37
.cast 6478 >>Click on the |cRXP_PICK_Chest|r
step
#requires Trap mechanism disarmed
.goto 2395,61.91,68.37
#arrowtext Click on the\n|cRXP_PICK_Cogwheel|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cogwheel|r that rotates differently.
.complete 91826,1 
step
#arrowtext Click on the |cRXP_PICK_Chest|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,61.91,68.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.complete 91826,2 
step
#label TheRegentsRequestC
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2395,61.89,68.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 91826 >>Turn in Tripwire Tango
.target Valeera Sanguinar
.accept 91827 >>Accept No Loose Ends
step
.goto 2393,45.43,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.turnin 91827 >>Turn in No Loose Ends
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Favor for the Lion
#internal
step
#optional
.isQuestAvailable 91827
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) The Regent's Request (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) The Regent's Request (H) >>CLICK HERE FOR GUIDE << Horde
step
.xp 90 >>Skip this for now, come back once you hit level 90.
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2393,52.47,78.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 91828 >>Accept A Favor for the Lion
.target Valeera Sanguinar
step
.goto 2393,52.68,78.63
#arrowtext Click on the\n|cRXP_PICK_Letter|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Letter|r
.complete 91828,1 
step
#label One by One
.goto 2437,40.42,71.68
#title |cFFFCDC00Follow the Arrow|r
.complete 91828,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2437,40.42,71.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 91828 >>Turn in A Favor for the Lion
.target Valeera Sanguinar
.accept 91829 >>Accept One by One
.accept 91830 >>Accept Intercepted
.accept 91831 >>Accept Keys Are Optional
step
#completewith Mordrag the Tainted
>>Kill |cRXP_ENEMY_Twilight Cultists|r
.complete 91829,1 
.mob Twilight Dreadblade
.mob Twilight Mindshaper
.mob Twilight Soulbinder
.mob Shadowstalker
.mob Twilight Zealot
step
.goto 2437,39.81,71.79
#arrowtext Click on the\n|cRXP_PICK_Pillar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillar|r.
.complete 91831,1,1 
step
.goto 2437,39.79,71.34
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 91830,1,1 
step
.goto 2437,38.21,70.81
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 91830,1,2
step
.goto 2437,37.62,71.17
#arrowtext Click on the\n|cRXP_PICK_Pillar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillar|r.
.complete 91831,1,2 
step
.goto 2437,37.35,71.13
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 91830,1,3 
step
.goto 2437,36.33,71.44
#arrowtext Click on the\n|cRXP_PICK_Pillar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillar|r.
.complete 91831,1,3 
step
.goto 2437,36.47,72.38
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 91830,1,4 
step
.goto 2437,36.59,73.5
#arrowtext Click on the\n|cRXP_PICK_Pillar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillar|r.
.complete 91831,1,4 
step
.goto 2437,36.8,73.68
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 91830,1,5
step
.goto 2437,37.23,73.76
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 91830,1,6
step
#label Mordrag the Tainted
.goto 2437,38.29,73.74
>>Kill |cRXP_ENEMY_Mordrag the Tainted|r
.complete 91829,2 
.mob Mordrag the Tainted
step
#loop
.goto 2437,37.89,74.54,30,0
.goto 2437,36.76,73.95,30,0
.goto 2437,35.92,73.51,30,0
.goto 2437,35.94,71.93,30,0
.goto 2437,37.61,70.08,30,0
.goto 2437,39.04,72,30,0
>>Kill |cRXP_ENEMY_Twilight Cultists|r
.complete 91829,1 
.mob Twilight Dreadblade
.mob Twilight Mindshaper
.mob Twilight Soulbinder
.mob Shadowstalker
.mob Twilight Zealot
step
#label Cut Once
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r |cRXP_WARN_next to you|r.
.turnin 91831 >>Turn in Keys Are Optional
.target Valeera Sanguinar
.turnin 91830 >>Turn in Intercepted
.turnin 91829 >>Turn in One by One
.accept 91918 >>Accept Delves: Measure Once, Cut Twice
step
#include a) Twilight Crypts
step
.goto 2393,52.55,78.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 91918 >>Turn in Delves: Measure Once, Cut Twice
.target Valeera Sanguinar
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Drinking Debt
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TheDrinkingDebtA
#arrowtext Talk to\n|cRXP_FRIENDLY_Tarenar Sunstrike|r
.goto 2393,57.64,68.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
#completewith next
#label TheDrinkingDebtB
#arrowtext Talk to\n|cRXP_FRIENDLY_Gidwin Goldbraids|r
.goto 2393,33.4,88.72,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.turnin 87455 >>Turn in Trials and Tabulations
.target Gidwin Goldbraids
.accept 87456 >>Accept Souvenirs Scattered
.disablecheckbox
.accept 87457 >>Accept What We Do Best
.disablecheckbox
step
.isOnQuest 87455
#completewith TheDrinkingDebtB
#title Enter the building
.goto 2393,33.38,89.37,12 >>|cRXP_WARN_Enter the building.|r
step
#requires TheDrinkingDebtB
#arrowtext Talk to\n|cRXP_FRIENDLY_Gidwin Goldbraids|r
.goto 2393,33.38,89.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.turnin 87455 >>Turn in Trials and Tabulations
.timer 9.5,RP
.target Gidwin Goldbraids
step
#requires Trials and Tabulations
#label Souvenirs Scattered
#arrowtext Talk to\n|cRXP_FRIENDLY_Gidwin Goldbraids|r
.goto 2393,33.38,89.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r |cRXP_WARN_after the roleplay|r.
.target Gidwin Goldbraids
.accept 87456 >>Accept Souvenirs Scattered
.accept 87457 >>Accept What We Do Best
step
#arrowtext Click on the |cRXP_PICK_Bag|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,33.05,89.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
.complete 87456,2 
step
#arrowtext Kill |cRXP_ENEMY_Squatter|r\nLoot for |T1360027:0|t[|cRXP_LOOT_Antique Necklace|r]
.goto 2393,33.62,89.97
>>Kill |cRXP_ENEMY_Squatter|r |cRXP_WARN_on the second floor.|r
*Loot it for the |T1360027:0|t[|cRXP_LOOT_Antique Necklace|r].
.complete 87457,1 
.mob Squatter
step
#arrowtext Click on the |cRXP_PICK_Bottle|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,33.57,89.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bottle|r
.complete 87456,3 
step
#label TheDrinkingDebtC
#arrowtext Click on the |cRXP_PICK_Book|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,33.72,90.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 87456,1 
step
#label TheDrinkingDebtD
#arrowtext Talk to\n|cRXP_FRIENDLY_Gidwin Goldbraids|r
.goto 2393,33.32,90.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.turnin 87456 >>Turn in Souvenirs Scattered
.turnin 87457 >>Turn in What We Do Best
.accept 87458 >>Accept Debts Paid
.target Gidwin Goldbraids
step
#completewith next
#label Turn in Debts Paid
.goto 2393,33.4,88.73,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r |cRXP_WARN_infront of a building|r.
.turnin 87458 >>Turn in Debts Paid
.target Tarenar Sunstrike
step
#completewith Turn in Debts Paid
.goto 2393,57.63,68.83,775 >>Leave the building
step
#requires Turn in Debts Paid
#label TheDrinkingDebtZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Tarenar Sunstrike|r
.goto 2393,57.63,68.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r |cRXP_WARN_infront of a building|r.
.turnin 87458 >>Turn in Debts Paid
.target Tarenar Sunstrike
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Drinking Debt2
#internal
step
.goto 2393,41.74,76.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hawkrancher Saman|r.
.accept 94012 >>Accept Lost Lil' Strider
.target Hawkrancher Saman
step
.goto 2393,36.72,70.74
#arrowtext Click on the\n|cRXP_PICK_Tiff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tiff|r
.complete 94012,1 
.target Tiff
step
.goto 2393,30.88,66.93
#arrowtext Click on the\n|cRXP_PICK_Tiff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tiff|r
.complete 94012,2 
.target Tiff
step
.goto 2393,36.33,66.49
#arrowtext Click on the\n|cRXP_PICK_Tiff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tiff|r
.complete 94012,3 
.target Tiff
step
.goto 2393,41.75,76.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hawkrancher Saman|r.
.turnin 94012 >>Turn in Lost Lil' Strider
.accept 93965 >>Accept Pet Wranglin'
.target Hawkrancher Saman
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Fear and Fel
#internal
step
#label FearAndFelA
#label FearAndFelA
#arrowtext Talk to\n|cRXP_FRIENDLY_Avara|r
.goto 2393,55.99,63.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Avara|r.
.accept 90835 >>Accept Murder Row: Rumors Abound
.target Avara
step
#label FearAndFelB
#arrowtext |cRXP_WARN_On the highest platform|r\nTalk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,51.73,64.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90835 >>Turn in Murder Row: Rumors Abound
.target Belath Dawnblade
.accept 90818 >>Accept Murder Row: Loose Lips
.accept 90837 >>Accept Murder Row: Traces of Fel
step
#arrowtext |cFFFCDC00Descend straight down|r\nUse |T237382:0|t|cRXP_WARN_[ExtraActionButton]|r\n cancel right after
.goto 2393,52.44,63.54
>>Stand within the circle and use the |T237382:0|t|cRXP_WARN_[ExtraActionButton]|r cancel the cast right after.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90818,1,1 
step
#label FearAndFelC
#arrowtext Click |cRXP_PICK_Rags|r\nFel Magic discovered (1/5) |cFFFCDC00(Read Note)|r
.goto 2393,54.83,61.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rags|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,1 
step
#label FearAndFelD
#arrowtext Information gathered (2/3) |cFFFCDC00(Read Note)|r\n Use |T133639:0|t|cRXP_WARN_[ExtraActionButton]|r\n cancel right after
.goto 2393,52.31,60.63
>>Stand within the circle and use the |T133639:0|t|cRXP_WARN_[ExtraActionButton]|r cancel the cast right after.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90818,1,2 
step
#arrowtext Click |cRXP_PICK_Crate|r\nFel Magic discovered (2/5) |cFFFCDC00(Read Note)|r
.goto 2393,51.96,60.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,2 
step
#completewith next
#label fel magic1
.goto 2393,50.73,57.46,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 90837,1,3 
step
.isOnQuest 90837
#completewith fel magic1
.goto 2393,51.1,56.19,25 >>Enter the building
step
#requires fel magic1
.goto 2393,51.1,56.19
#arrowtext Click |cRXP_PICK_Book|r\n|cRXP_WARN_on the table|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,3 
step
#completewith next
#label fel magic2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,4 
step
.isOnQuest 90837
#completewith fel magic2
#arrowtext |cRXP_WARN_Leave building|r
.goto 2393,50.71,57.52,15 >>Leave the building
step
#requires fel magic2
#arrowtext Skyride straight up\n|cFFFCDC00to the platform above|r\nClick |cRXP_PICK_Bag|r
.goto 2393,50.54,58.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,4 
step
#arrowtext Use |T132789:0|t|cRXP_WARN_[ExtraActionButton]|r\n cancel right after\n Information gathered (3/3) |cFFFCDC00(Read Note)|r
.goto 2393,51.38,57.1
>>Stand within the circle and use the |T132789:0|t|cRXP_WARN_[ExtraActionButton]|r cancel the cast right after.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90818,1,3 
step
#label SojournerFelMagic1
#arrowtext Click |cRXP_PICK_Bottle|r\nFel Magic discovered (5/5) |cFFFCDC00(Read Note)|r
.goto 2393,52.2,55.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bottle|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,5 
step
#label SojournerLooseLips1
#arrowtext Talk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,56.14,56.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90818 >>Turn in Murder Row: Loose Lips
.target Belath Dawnblade
.turnin 90837 >>Turn in Murder Row: Traces of Fel
.accept 90819 >>Accept Murder Row: Acting the Part
step
#arrowtext Click |cRXP_PICK_Core|r
.goto 2393,56.18,56.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Core|r
.complete 90819,1 
step
#arrowtext Merchants questioned (1/3) |cFFFCDC00(Read Note)|r\nTalk to\n|cRXP_FRIENDLY_Miss Len'dali|r
.goto 2393,53.01,52.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miss Len'dali|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90819,2,1 
.skipgossipid 133938
.target Miss Len'dali
step
#completewith next
#label Murder Row2
#arrowtext Enter Building
.goto 2393,52.52,48.44,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thiel|r.
.complete 90819,2,2 
.target Thiel
step
.isOnQuest 90819
#completewith Murder Row2
#arrowtext Enter Building
.goto 2393,50.65,47.97,20 >>Enter the building
step
#requires Murder Row2
#arrowtext Merchants questioned (2/3) |cFFFCDC00(Read Note)|r\nTalk to\n|cRXP_FRIENDLY_Thiel|r
.goto 2393,50.65,47.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thiel|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90819,2,2 
.skipgossipid 133946
.target Thiel
step
#completewith next
#label Murder Row1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Denorin|r.
.complete 90819,2,3 
.target Denorin
step
.isOnQuest 90819
#completewith Murder Row1
#arrowtext Enter building
.goto 2393,56.47,48.64,25 >>Enter the building
step
#requires Murder Row1
#label SojournerMerchant
#arrowtext Merchants questioned (3/3) |cFFFCDC00(Read Note)|r\nTalk to\n|cRXP_FRIENDLY_Denorin|r
.goto 2393,56.47,48.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Denorin|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90819,2,3 
.skipgossipid 133942
.target Denorin
step
#completewith next
#label Den of Indulgence
#hidewindow
.goto 2393,55.79,48.51,5,0
.goto 2393,53.82,52.18,45,0
.complete 90819,3 
step
.isOnQuest 90819
#completewith Den of Indulgence
.goto 2393,56.29,54.15,75 >>Follow the arrow
step
#requires Den of Indulgence
#label Sojourner Den of Indulgence
.goto 2393,56.29,54.15
>>Enter the building
.complete 90819,3 
step
.goto 2393,57.73,52.05
#arrowtext Talk to\n|cRXP_FRIENDLY_Vira|r
>>Approach |cRXP_FRIENDLY_Vira|r
.complete 90819,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Vira|r
.goto 2393,57.73,52.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vira|r.
.complete 90819,5 
.skipgossipid 133969
.target Vira
step
.goto 2393,57.97,51.98
#arrowtext Click |cRXP_PICK_Crate|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 90819,6 
step
#completewith next
#label Acting the Part
#arrowtext Leave building
.goto 2393,56.25,54.21,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90819 >>Turn in Murder Row: Acting the Part
.target Belath Dawnblade
.accept 90821 >>Accept Murder Row: Harbored Secrets
.disablecheckbox
step
.isOnQuest 90819
#completewith Acting the Part
#arrowtext Leave building
.goto 2393,54.51,54.82,54 >>Leave the building
step
#label FearAndFelE
#requires Acting the Part
#arrowtext Talk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,54.51,54.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90819 >>Turn in Murder Row: Acting the Part
.accept 90821 >>Accept Murder Row: Harbored Secrets
.target Belath Dawnblade
step
#label FearAndFelF
#title |cFFFCDC00Follow the Arrow|r
.goto 2393,32.21,26
>>Follow the arrow.
.complete 90821,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tarelin|r
.goto 2393,33.98,26.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarelin|r.
*|cRXP_WARN_If he was already spoken to, kill him|r
.complete 90821,2 
.skipgossipid 134044
.target Tarelin
step
#label FearAndFelG
.goto 2393,33.98,26.46
>>Kill |cRXP_ENEMY_Tarelin|r
*Loot him for |T133471:0|t[|cRXP_LOOT_Folded Receipt|r].
.complete 90821,3 
.skipgossipid 134044
.mob Tarelin
step
#label SojournerDungeon
#arrowtext Talk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,32.19,26.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r |cRXP_WARN_after the roleplay|r.
.turnin 90821 >>Turn in Murder Row: Harbored Secrets
.target Belath Dawnblade
.accept 90822 >>Accept Murder Row: One Fel Swoop
step
#completewith next
+|cRXP_WARN_The Arrow cannot be displayed in dungeons; coordinates are unavailable|r.
step
.enterScenario 2926 >>Queue for Magister's Terrace
.macro Queue Magister's Terrace(Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeSpecificDungeon(); SetLFGDungeonEnabled(3051, true); LFGEnabledList[3051] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
.macro Queue Follower Dungeon,1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3089, true); LFGEnabledList[3089] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
.isInScenario 2926
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Row Snitches|r
*Repeatedly kill |cRXP_ENEMY_Nibbles|r for a damage amplification effect on |cRXP_ENEMY_Kystia Manaheart|r
.scenario 13227,1 
.mob Row Snitch
step
.isInScenario 2926
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r
*Kill |cRXP_ENEMY_Zaen Bladesorrow|r
.scenario 13227,2 
.skipgossipid 137021
.mob Zaen Bladesorrow
.target Belath Dawnblade
step
.isInScenario 2926
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gateway|r
*Kill |cRXP_ENEMY_Xathuux the Annihilator|r
.scenario 13227,3 
.mob Xathuux the Annihilator
step
>>Kill |cRXP_ENEMY_Lithiel Cinderfury|r
.complete 90822,1 
.mob Lithiel Cinderfury
step
#label FearAndFelZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
|cFFFCDC00Don't leave|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90822 >>Turn in Murder Row: One Fel Swoop
.target Belath Dawnblade
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Lesser Evil
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label LesserEvilA
#arrowtext Talk to\n|cRXP_FRIENDLY_Sarvi|r
.goto 2393,54.53,61.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarvi|r.
.accept 90669 >>Accept Gold is Gold
.target Sarvi
step
#completewith next
#label LesserEvilB
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Aradis|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Aradis|r.
.turnin 90669 >>Turn in Gold is Gold
.accept 89199 >>Accept A Small Task
.target Magister Aradis
.disablecheckbox
step
.isOnQuest 90669
#completewith LesserEvilB
#arrowtext Enter building
.goto 2393,53.38,32.61,20 >>|cRXP_WARN_Enter the building.|r
step
#requires LesserEvilB
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Aradis|r
.goto 2393,54.00,34.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Aradis|r.
.turnin 90669 >>Turn in Gold is Gold
.target Magister Aradis
.accept 89199 >>Accept A Small Task
step
.goto 2393,54.01,33.93
#arrowtext Click on the\n|cRXP_PICK_Staff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Staff|r
.complete 89199,1 
step
#arrowtext Click |cRXP_PICK_Crystals|r \n from range
.goto 2393,54.28,33.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystals|r |cRXP_WARN_from a distance|r.
.complete 89199,2,2 
step
#label LesserEvilC
#arrowtext Click |cRXP_PICK_Crystals|r \n from range
.goto 2393,53.85,33.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystals|r |cRXP_WARN_from a distance|r.
.complete 89199,2,4 
step
#label LesserEvilD
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Aradis|r
.goto 2393,54.11,33.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Aradis|r.
.turnin 89199 >>Turn in A Small Task
.target Magister Aradis
.accept 89200 >>Accept Unraveling Wards
step
.goto 2393,53.63,33.84
#arrowtext Click |cRXP_PICK_Conduit|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r.
.complete 89200,1,1 
step
#completewith next
#label Warded Conduits1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r |cRXP_WARN_on a pillar|r.
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 89200,1,2 
step
#completewith Warded Conduits1
#arrowtext Leave building
.goto 2393,53.54,33.02,7 >>|cRXP_WARN_Leave the building.|r
step
#requires Warded Conduits1
#arrowtext |cFFFCDC00At the top of a tower|r\nClick |cRXP_PICK_Conduit|r\n Spam mount during cast
.goto 2393,49.34,42.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r |cRXP_WARN_on a pillar|r.
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 89200,1,2 
.mob Ward Fragment
step
#label Sojourner Warded Conduits
#arrowtext Click |cRXP_PICK_Conduit|r\n|cFFFCDC00A level above|r\n Spam mount during cast
.goto 2393,52.81,44.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r |cRXP_WARN_on a pillar; level above|r.
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 89200,1,3 
.mob Conjured Defense
step
#label SojournerConduit
#arrowtext |cFFFCDC00At the same height|r\nClick |cRXP_PICK_Conduit|r\nClick on the\n|cRXP_PICK_Conduit|r
.goto 2393,53.61,76.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r |cRXP_WARN_on a pillar; same level|r.
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 89200,1,4 
.mob Ward Fragment
.mob Conjured Defense
step
#arrowtext Click |cRXP_PICK_Conduit|r
.goto 2393,31.58,67.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r |cRXP_WARN_on a pillar; level below|r
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 89200,1,5 
.mob Stationed Sentry
step
#label SojournerUnraveling Wards
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Aradis|r
.goto 2393,37.41,74.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Aradis|r.
.turnin 89200 >>Turn in Unraveling Wards
.accept 89201 >>Accept Outschemed
.target Magister Aradis
step
#arrowtext Use |T2830970:0|t|cRXP_WARN_[ExtraActionButton]|r
.goto 2393,37.85,75.16
>>Stand within the circle and use the |T2830970:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 89201,1 
step
#arrowtext Click |cRXP_PICK_Chest|r
.goto 2393,38.34,75.76,5,0
.goto 2393,38.88,75.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.complete 89201,2 
.timer 12.5,RP
step
#label SojournerOutschemed
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Dawnblaze|r
.goto 2393,38.75,75.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Dawnblaze|r.
.turnin 89201 >>Turn in Outschemed
.target Magister Dawnblaze
.accept 89202 >>Accept Stir the Nest
step
#completewith next
#label Row Rats
#arrowtext Leave building
#hidewindow
.goto 2393,38.27,75.65,7,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Row Rats|r.
.complete 89202,1 
step
#completewith Row Rats
#arrowtext Leave building
.goto 2393,37.94,75.16,7 >>|cRXP_WARN_Leave the building.|r
step
#requires Row Rats
#completewith next
#label Row Rats2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Row Rats|r.
*|cRXP_WARN_kill them if they turn hostile|r
.complete 89202,1 
.skipgossipid 132989
.target Row Rat
step
#requires Row Rats
#completewith Row Rats2
#hidewindow
.goto 2393,37.6,72.79,30,0
.goto 2393,39.16,69.84,40,0
.goto 2393,50.44,57.55,400 >>Follow the Arrow
step
#requires Row Rats2
#arrowtext Rats question (1/8) |cFFFCDC00(Read Note)|r\nTalk to\n|cRXP_FRIENDLY_Row Rats|r
#loop
.goto 2393,50.44,57.55,20,0
.goto 2393,50.76,59.59,20,0
.goto 2393,51.53,59.91,20,0
.goto 2393,51.92,57.87,20,0
.goto 2393,53.2,59.77,20,0
.goto 2393,54.17,61.21,20,0
.goto 2393,53.5,62.64,20,0
.goto 2393,54.65,63.62,20,0
.goto 2393,55.85,62.87,20,0
.goto 2393,56.16,61.58,20,0
.goto 2393,55.63,60.18,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Row Rats|r.
*|cRXP_WARN_kill them if they turn hostile|r
.complete 89202,1 
.skipgossipid 132989
.target Row Rat
step
#completewith next
#label Mutual Benefit
#arrowtext Enter the building
.goto 2393,52.9,62.24,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89202 >>Turn in Stir the Nest
.accept 89203 >>Accept Mutual Benefit
.target Jaeth
.disablecheckbox
step
#completewith Mutual Benefit
#arrowtext Enter the building
.goto 2393,51.85,63.78,40 >>|cRXP_WARN_Enter the building|r.
step
#requires Mutual Benefit
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
.goto 2393,51.85,63.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89202 >>Turn in Stir the Nest
.accept 89203 >>Accept Mutual Benefit
.target Jaeth
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
.goto 2393,51.85,63.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.complete 89203,1 
.timer 16.5,RP
.skipgossipid 132992
step
#label SojournerMutualBenefit
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
.goto 2393,51.85,63.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r |cRXP_WARN_after the roleplay|r.
.turnin 89203 >>Turn in Mutual Benefit
.accept 89204 >>Accept Five Finger Discount
.target Jaeth
step
#completewith next
#label Lendranil distracted
#arrowtext Leave the building
.goto 2393,52.2,63.94,10,0
.goto 2393,51.74,64.12,10,0
.goto 2393,51.82,63.38,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lendranil|r |cRXP_WARN_to become a thief; avoid being caught|r.
.complete 89204,1 
.target Lendranil
step
#completewith Lendranil distracted
#arrowtext Leave the building
.goto 2393,52.93,61.62,10 >>Leave the building
step
#requires Lendranil distracted
#arrowtext Talk to\n|cRXP_FRIENDLY_Lendranil|r
.goto 2393,48.65,61.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lendranil|r |cRXP_WARN_to become a thief; avoid being caught|r.
.complete 89204,1 
.skipgossipid 133247
.target Lendranil
step
#label SojournerThrumming
.goto 2393,49.53,62.26
#arrowtext Use |T132307:0|t[Sprint] \n Click |cRXP_PICK_Amulet|r\nClick on the\n|cRXP_PICK_Amulet|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amulet|r |cRXP_WARN_afterwards|r |T132303:0|t[Teleport Back].
*|cRXP_WARN_Avoid getting caught|r
.complete 89204,2 
step
#completewith next
#label Lothene
#arrowtext Enter the building
.goto 2393,36.07,62.97,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothene|r
.complete 89204,3 
.target Lothene
step
#completewith Lothene
#arrowtext Enter the building
.goto 2393,35.91,61.99,15 >>|cRXP_WARN_Enter the building|r
step
#requires Lothene
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothene|r
.goto 2393,35.91,61.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothene|r
.complete 89204,3 
.skipgossipid 133298
.target Lothene
step
#arrowtext Use |T132307:0|t[Sprint] \n Click |cRXP_PICK_Basket|r\nClick on the\n|cRXP_PICK_Basket|r
.goto 2393,36.18,62.21,5,0
.goto 2393,36.31,61.57,5,0
.goto 2393,35.73,61.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket|r |cRXP_WARN_upstairs|r |cRXP_WARN_afterwards|r |T132303:0|t[Teleport Back].
*|cRXP_WARN_Avoid getting caught|r
.complete 89204,4 
step
#completewith next
#label Belil
#arrowtext Enter the building
.goto 2393,36.06,62.91,8,0
.goto 2393,43.38,52.85,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belil|r
.complete 89204,5 
.target Belil
step
#completewith Belil
#arrowtext Enter the building
.goto 2393,42.64,52.87,18 >>|cRXP_WARN_Enter the building|r
step
#requires Belil
#arrowtext Talk to\n|cRXP_FRIENDLY_Belil|r
.goto 2393,42.64,52.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belil|r
.complete 89204,5 
.skipgossipid 133290
.target Belil
step
#completewith next
#label Arcane Sword
#arrowtext Use |T132307:0|t[Sprint] \n Click |cRXP_PICK_Sword|r
.goto 2393,43,52.66,10,0
.goto 2393,41.73,52.16,10,0
.goto 2393,41,52.82,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r |cRXP_WARN_afterwards|r |T132303:0|t[Teleport Back].
*|cRXP_WARN_Avoid getting caught|r
.complete 89204,6 
step
#completewith Arcane Sword
#hidewindow
#arrowtext Use |T132307:0|t[Sprint] \n Click |cRXP_PICK_Sword|r
.goto 2393,40.49,52.54,17 >>Follow the Arrow
step
#requires Arcane Sword
#arrowtext Use |T132307:0|t[Sprint] \n Click |cRXP_PICK_Sword|r
.goto 2393,40.48,52.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r |cRXP_WARN_afterwards|r |T132303:0|t[Teleport Back].
*|cRXP_WARN_Avoid getting caught|r
.complete 89204,6 
step
#completewith next
#label Five Finger Discount
#arrowtext Enter the building
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89204 >>Turn in Five Finger Discount
.target Jaeth
.accept 89205 >>Accept Cutting a Key
.disablecheckbox
step
#completewith Five Finger Discount
#arrowtext Enter the building
.goto 2393,50.59,59.83,5 >>|cRXP_WARN_Enter the building|r.
step
#requires Five Finger Discount
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
.goto 2393,50.31,61.1,5,0
.goto 2393,50.80,61.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89204 >>Turn in Five Finger Discount
.accept 89205 >>Accept Cutting a Key
.target Jaeth
step
.goto 2393,50.91,60.92
#arrowtext Click |cRXP_PICK_Staff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Staff|r.
.complete 89205,1 
step
.goto 2393,50.81,61.22
#arrowtext Click |cRXP_PICK_Amulet|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amulet|r.
.complete 89205,2 
step
.goto 2393,50.84,60.94
#arrowtext Click |cRXP_PICK_Sword|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r.
.complete 89205,3 
step
.goto 2393,50.76,61.22
#arrowtext Click |cRXP_PICK_Basket|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket|r.
.complete 89205,4 
step
.goto 2393,50.91,60.92
#arrowtext Click |cRXP_PICK_Staff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Staff|r.
.complete 89205,5 
step
#completewith next
#label Cutting a Key
#arrowtext Enter the building\nat the harbor
.goto 2393,50.59,59.74,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89205 >>Turn in Cutting a Key
.target Jaeth
.accept 89206 >>Accept Break and Enter
.disablecheckbox
step
#completewith Cutting a Key
#arrowtext Enter the building\nat the harbor
.goto 2393,53.44,32.62,10 >>|cRXP_WARN_Enter the building|r
step
#requires Cutting a Key
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
.goto 2393,54.27,33.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89205 >>Turn in Cutting a Key
.target Jaeth
.accept 89206 >>Accept Break and Enter
step
.goto 2393,54.27,33.77
#arrowtext Use |T2830970:0|t|cRXP_WARN_[ExtraActionButton]|r
>>Use the |T2830970:0|t|cRXP_WARN_[ExtraActionButton]|r within the circle.
.complete 89206,1 
step
#completewith next
#label BreakAndEnterA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r.
*|cRXP_WARN_Kill the spawning monsters|r
.complete 89206,2,1 
.mob Released Imp
.mob Sayaadi Guard
step
#completewith BreakAndEnterA
#arrowtext |cFFFCDC00Drop Down|r
.goto 2393,54.87,34.38,5 >>Jump down the stairs.
step
#requires BreakAndEnterA
#loop
.goto 2393,54.42,33.34,6,0
.goto 2393,54.35,32.95,6,0
.goto 2393,53.94,32.72,6,0
.goto 2393,53.69,33.19,6,0
.goto 2393,53.85,33.71,6,0
.goto 2393,54.18,33.78,6,0
#arrowtext Click on the\n|cRXP_PICK_Crystal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r.
.complete 89206,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
.goto 2393,54.25,33.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89206 >>Turn in Break and Enter
.accept 89207 >>Accept Rats Can Bite
.target Jaeth
step
#label Sojourner What We're Owed
.goto 2393,54.05,33.22
>>Kill |cRXP_ENEMY_Magister Aradis|r.
.complete 89207,1 
.mob Magister Aradis
step
#completewith next
#label Rats Can Bite
#arrowtext Leave building
.goto 2393,55.01,34.07,7,0
.goto 2393,54.85,34.65,7,0
.goto 2393,54.29,34,7,0
.goto 2393,53.54,33.09,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89207 >>Turn in Rats Can Bite
.accept 89208 >>Accept What We're Owed
.target Jaeth
.disablecheckbox
step
#completewith Rats Can Bite
#arrowtext Leave building
.goto 2393,53.01,33.20,15 >>Go upstairs and leave the building
step
#requires Rats Can Bite
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
.goto 2393,53.01,33.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89207 >>Turn in Rats Can Bite
.accept 89208 >>Accept What We're Owed
.target Jaeth
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Dawnblaze|r
.goto 2393,37.37,74.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Dawnblaze|r.
.complete 89208,1 
.skipgossipid 133545
.target Magister Dawnblaze
step
#label LesserEvilZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Dawnblaze|r
.goto 2393,37.37,74.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Dawnblaze|r.
.turnin 89208 >>Turn in What We're Owed
.target Magister Dawnblaze
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Tailor Troubles
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TailorTroublesA
#arrowtext Talk to\n|cRXP_FRIENDLY_Solwin Brightstitch|r
.goto 2393,48.40,54.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Solwin Brightstitch|r.
.accept 91386 >>Accept Mad to Measure
.target Solwin Brightstitch
step
.goto 2393,48.56,54.43
#arrowtext Click on the\n|cRXP_PICK_Shears|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shears|r
.complete 91386,1 
step
.goto 2393,48.86,54.01
#arrowtext Click on the\n|cRXP_PICK_Fabric|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fabric|r.
.complete 91386,2 
step
.goto 2393,48.65,54.80
#arrowtext Click on the\n|cRXP_PICK_Fabric|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fabric|r.
.complete 91386,3 
step
.goto 2393,48.83,54.02
#arrowtext Click on the\n|cRXP_PICK_Fabric|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fabric|r.
.complete 91386,4 
step
.goto 2393,48.84,54.26
#arrowtext Click on the\n|cRXP_PICK_Boards|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boards|r.
.complete 91386,5 
.timer 6,RP
step
#label TailorTroublesAA
#arrowtext Talk to\n|cRXP_FRIENDLY_Gaari|r
.goto 2393,48.73,54.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gaari|r.
.complete 91386,6 
.skipgossipid 135588
.target Gaari
step
#label TailorTroublesB
#arrowtext Talk to\n|cRXP_FRIENDLY_Solwin Brightstitch|r
.goto 2393,49.18,55.03,5,0
.goto 2393,48.85,55.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Solwin Brightstitch|r.
.turnin 91386 >>Turn in Mad to Measure
.target Solwin Brightstitch
.accept 92408 >>Accept Material Gains
step
#label TailorTroublesC
#arrowtext Talk to\n|cRXP_FRIENDLY_Solwin Brightstitch|r
.goto 2395,46.93,35.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Solwin Brightstitch|r.
.turnin 92408 >>Turn in Material Gains
.accept 91388 >>Accept Uncommon Threads
.target Solwin Brightstitch
step
#loop
.goto 2395,47.18,36.18,30,0
.goto 2395,46.63,35.99,30,0
.goto 2395,46.32,35.17,30,0
.goto 2395,47.2,35.23,30,0
.goto 2395,47.55,33.75,30,0
.goto 2395,46.4,34.19,30,0
#arrowtext Kill |cRXP_ENEMY_Wyrms|r\nClick their |cRXP_PICK_Corpses|r
>>Kill |cRXP_ENEMY_Wyrms|r then click their corpses.
.complete 91388,1 
.target Engorged Silk Wyrm
.mob Engorged Silk Wyrm
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Solwin Brightstitch|r
.goto 2395,46.93,35.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Solwin Brightstitch|r.
.turnin 91388 >>Turn in Uncommon Threads
.target Solwin Brightstitch
.accept 91389 >>Accept Clothes Make the Man
step
#completewith next
#label Arcanoweave
>>Kill the waves of |cRXP_ENEMY_enemies|r.
.complete 91389,2 
.mob Arcane Manifestation
.mob Manifested Memory
step
#completewith Arcanoweave
#arrowtext Talk to\n|cRXP_FRIENDLY_Solwin Brightstitch|r
.goto 2395,46.53,34.71,5,0
.goto 2395,46.26,34.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Solwin Brightstitch|r |cRXP_WARN_if noone else did|r.
.complete 91389,1 
.skipgossipid 135911
.target Solwin Brightstitch
step
#requires Arcanoweave
.goto 2395,46.3,34.68
>>Kill the waves of enemies.
.complete 91389,2 
.skipgossipid 135911
.mob Arcane Manifestation
.mob Manifested Memory
step
#completewith next
#label Gaari found
#hidewindow
.goto 2395,46.57,34.68,8,0
.complete 91389,3 
step
#completewith Gaari found
#arrowtext Leave the building
.goto 2395,46.63,34.45,19 >>|cRXP_WARN_Leave the building|r.
step
#requires Gaari found
.goto 2395,45.11,34.35
#title |cFFFCDC00Follow the Arrow|r
.complete 91389,3 
step
#label TailorTroublesZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Solwin Brightstitch|r
.goto 2395,45.11,34.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Solwin Brightstitch|r.
.turnin 91389 >>Turn in Clothes Make the Man
.target Solwin Brightstitch
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Scootin' Through Silvermoon
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label ScootinThroughSilvermoonA
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Telenus|r
.goto 2393,35.68,69.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Telenus|r.
.accept 92729 >>Accept Hounded and Hassled
.target Ranger Telenus
step
#label SojournerHassled
#arrowtext |cFFFCDC00NPC Patrols|r\nTalk to\n|cRXP_FRIENDLY_Magistrix Zaedana|r
.goto 2393,35.42,57.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Zaedana|r.
.turnin 92729 >>Turn in Hounded and Hassled
.target Magistrix Zaedana
.accept 92728 >>Accept Dogged Disturbances
step
#loop
.goto 2393,35.42,59.91,30,0
.goto 2393,33.42,58.97,30,0
.goto 2393,34.57,58.06,30,0
.goto 2393,34.01,56.68,30,0
>>Kill |cRXP_ENEMY_Elementals|r.
.complete 92728,1 
.mob Rowdy Spark
step
#label ScootinThroughSilvermoonB
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Zaedana|r
.goto 2393,35.44,57.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Zaedana|r.
.turnin 92728 >>Turn in Dogged Disturbances
.target Magistrix Zaedana
.accept 92868 >>Accept He Went Thataway
step
#label ScootinThroughSilvermoonC
#arrowtext Talk to\n|cRXP_FRIENDLY_Drathen|r
.goto 2393,44.83,60.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drathen|r.
.turnin 92868 >>Turn in He Went Thataway
.accept 92869 >>Accept Fishy Dis-pondencies
.target Drathen
step
#label SojournerFish
#loop
.goto 2393,45.66,62.02,15,0
.goto 2393,46.35,60.26,15,0
.goto 2393,45.65,58.74,15,0
.goto 2393,44.86,60.38,15,0
#arrowtext Click on the\n|cRXP_PICK_Fish|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fish|r
.complete 92869,1 
.target Displaced Sunwhisker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Drathen|r
.goto 2393,44.83,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drathen|r.
.turnin 92869 >>Turn in Fishy Dis-pondencies
.accept 92870 >>Accept Scoot Along Now
.target Drathen
step
#label SojournerScoots
#arrowtext |cFFFCDC00NPC Patrols|r\nClick on the\n|cRXP_PICK_Dog|r
#loop
.goto 2393,42.13,61.8,20,0
.goto 2393,41.12,62.63,20,0
.goto 2393,41.79,63.69,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dog|r
.complete 92870,1 
.target Lil' Scoots
step
#label ScootinThroughSilvermoonZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Telenus|r
.goto 2393,35.69,69.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Telenus|r.
.turnin 92870 >>Turn in Scoot Along Now
.target Ranger Telenus
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) How to Train Your Protege
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label HowToTrainYourProtegeA
#arrowtext Talk to\n|cRXP_FRIENDLY_Instructor Thalendir|r
.goto 2393,33.23,74.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.accept 94393 >>Accept Career Counseling
.accept 94396 >>Accept Down a Peg
.target Instructor Thalendir
step
#label HowToTrainYourProtegeB
#arrowtext Talk to\n|cRXP_FRIENDLY_Kyltus Bloodburn|r
.goto 2395,42.59,14.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kyltus Bloodburn|r.
.turnin 94393 >>Turn in Career Counseling
.target Kyltus Bloodburn
.accept 91284 >>Accept A Path Not Yet Chosen
step
#completewith next
#label A Test of the Arcane
#arrowtext Enter building
.goto 2395,43.08,14.54,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Jaronis|r.
.accept 91292 >>Accept A Test of the Arcane
.target Magister Jaronis
step
.isOnQuest 91284
#arrowtext Enter building
#completewith A Test of the Arcane
.goto 2395,43.21,14.69,17 >>Enter the building
step
#requires A Test of the Arcane
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Jaronis|r
.goto 2395,43.21,14.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Jaronis|r.
.accept 91292 >>Accept A Test of the Arcane
.target Magister Jaronis
step
#completewith next
#label A Test of Blood 1
#arrowtext Leave building
.goto 2395,43.02,14.55,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jesthenis Sunstriker|r.
.accept 91291 >>Accept A Test of Blood
.target Jesthenis Sunstriker
step
.isOnQuest 91292
#completewith A Test of Blood 1
#arrowtext Leave building
.goto 2395,42.96,13.76,50 >>Leave the building
step
#requires A Test of Blood 1
#arrowtext Talk to\n|cRXP_FRIENDLY_Jesthenis Sunstriker|r
.goto 2395,42.96,13.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jesthenis Sunstriker|r.
.accept 91291 >>Accept A Test of Blood
.target Jesthenis Sunstriker
step
#label A Test of the Hunt
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Hannovia|r
.goto 2395,42.18,13.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Hannovia|r.
.accept 91288 >>Accept A Test of the Hunt
.target Ranger Hannovia
step
#label SojournerLynx
#completewith next
>>Kill |cRXP_ENEMY_Lynx|r
*Loot them for the |T134367:0|t[|cRXP_LOOT_Invasive Lynx Pelts|r].
.complete 91288,1 
.mob Encroaching Lynx
.mob Invasive Lynx
step
#loop
.goto 2395,42,20.13,10,0
.goto 2395,41.85,20.27,10,0
.goto 2395,41.98,20.47,10,0
.goto 2395,42.16,20.33,10,0
#arrowtext Click on the\n|cRXP_PICK_Crystals|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystals|r.
.complete 91292,1 
step
#label HowToTrainYourProtegeC
#loop
.goto 2395,42.57,18.67,35,0
.goto 2395,42.84,16.61,35,0
.goto 2395,42.06,15.71,35,0
.goto 2395,41.06,17,35,0
>>Kill |cRXP_ENEMY_Lynx|r
*Loot them for the |T134367:0|t[|cRXP_LOOT_Invasive Lynx Pelts|r].
.complete 91288,1 
.mob Encroaching Lynx
.mob Invasive Lynx
step
#completewith next
#label HowToTrainYourProtegeD
>>Kill |cRXP_ENEMY_Jesthenis Sunstriker|r
.complete 91291,2 
step
#completewith HowToTrainYourProtegeD
#arrowtext At the top\nTalk to |cRXP_FRIENDLY_Jesthenis Sunstriker|r.
.goto 2395,43.43,14.72
.gossipoption 134482 >>Talk to |cRXP_FRIENDLY_Jesthenis Sunstriker|r.
step
#requires HowToTrainYourProtegeD
.goto 2395,43.43,14.72
#arrowtext stay in the middle \ to not get knocked off
>>Kill |cRXP_ENEMY_Jesthenis Sunstriker|r
*|cRXP_WARN_Don't get knocked off the tower|r
.complete 91291,2 
step
#completewith next
#label Test of the Arcane
#arrowtext Enter building
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Jaronis|r.
.turnin 91292 >>Turn in A Test of the Arcane
.target Magister Jaronis
.complete 91284,3 
.disablecheckbox
step
.isOnQuest 91292
#arrowtext Enter building
#completewith Test of the Arcane
.goto 2395,42.94,14.61,10 >>Enter the building
step
#requires Test of the Arcane
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Jaronis|r in the building
.goto 2395,43.21,14.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Jaronis|r.
.turnin 91292 >>Turn in A Test of the Arcane
.target Magister Jaronis
.complete 91284,3 
step
#completewith next
#label A Test of Blood
#arrowtext Leave building
.goto 2395,43.01,14.52,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jesthenis Sunstriker|r.
.turnin 91291 >>Turn in A Test of Blood
.target Jesthenis Sunstriker
.complete 91284,2 
step
.isOnQuest 91291
#arrowtext Leave building
#completewith A Test of Blood
.goto 2395,42.96,13.77,50 >>Leave the building
step
#requires A Test of Blood
#arrowtext Talk to\n|cRXP_FRIENDLY_Jesthenis Sunstriker|r
.goto 2395,42.96,13.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jesthenis Sunstriker|r.
.turnin 91291 >>Turn in A Test of Blood
.target Jesthenis Sunstriker
.complete 91284,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Hannovia|r
.goto 2395,42.18,13.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Hannovia|r.
.turnin 91288 >>Turn in A Test of the Hunt
.target Ranger Hannovia
.complete 91284,1 
step
#label HowToTrainYourProtegeX
#arrowtext Talk to\n|cRXP_FRIENDLY_Kyltus Bloodburn|r
.goto 2395,42.60,14.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kyltus Bloodburn|r.
.turnin 91284 >>Turn in A Path Not Yet Chosen
.target Kyltus Bloodburn
.accept 91301 >>Accept How to Train Your Protege
.complete 91301,1 
.skipgossipid 134090
step
#label HowToTrainYourProtegeY
#arrowtext Talk to\n|cRXP_FRIENDLY_Instructor Thalendir|r
.goto 2393,33.26,74.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.complete 91301,2 
.skipgossipid 134484
.target Instructor Thalendir
step
#label HowToTrainYourProtegeZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Instructor Thalendir|r
.goto 2393,33.24,74.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.turnin 91301 >>Turn in How to Train Your Protege
.target Instructor Thalendir
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Aspiring Academic
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label AspiringAcademicA
#arrowtext Talk to\n|cRXP_FRIENDLY_Instructor Thalendir|r
.goto 2393,33.25,74.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.accept 94393 >>Accept Career Counseling
.accept 94396 >>Accept Down a Peg
.target Instructor Thalendir
step
#label AspiringAcademicB
#arrowtext Talk to\n|cRXP_FRIENDLY_Tytalor Goldenblade|r
.goto 2395,39.42,17.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tytalor Goldenblade|r.
.turnin 94396 >>Turn in Down a Peg
.target Tytalor Goldenblade
.accept 86997 >>Accept Spellbook Scuffle
step
#loop
.goto 2395,38.64,17.31,15,0
.goto 2395,38.37,16.93,20,0
.goto 2395,38.39,17.6,15,0
.goto 2395,38.16,18.7,15,0
.goto 2395,38.24,19.13,15,0
.goto 2395,37.92,19.09,15,0
.goto 2395,37.98,18.77,15,0
#arrowtext Click on the\n|cRXP_PICK_Books|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Books|r.
*Kill |cRXP_ENEMY_Fiendish Inkbound Codex|r.
*Loot them for |T1505955:0|t[|cRXP_LOOT_Torn Spellbook Page|r].
.complete 86997,1 
.mob Fiendish Inkbound Codex
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tytalor Goldenblade|r
.goto 2395,37.40,18.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tytalor Goldenblade|r.
.turnin 86997 >>Turn in Spellbook Scuffle
.target Tytalor Goldenblade
.accept 86998 >>Accept Training Arc
step
#loop
#arrowtext Talk to\n|cRXP_FRIENDLY_Followers|r\nDefeat them
.goto 2395,37.81,18.03,10,0
.goto 2395,37.99,17.82,10,0
.goto 2395,38.17,18.08,10,0
.goto 2395,37.97,18.39,10,0
.goto 2395,38.46,18.46,10,0
.goto 2395,38.31,18.73,10,0
.goto 2395,38.34,19.51,10,0
.goto 2395,38.49,19.79,10,0
.goto 2395,38.57,19.45,10,0
>>Defeat |cRXP_ENEMY_Followers|r |cRXP_WARN_talk to them first if noone else did|r.
.complete 86998,1 
.skipgossipid 132313
.target Brutish Follower
.target Mage Follower
.target Magus Superior
.mob Magus Superior
.mob Mage Follower
.mob Brutish Follower
step
#arrowtext On the platform above\nTalk to\n|cRXP_FRIENDLY_Tytalor Goldenblade|r
.goto 2395,38.56,18.49,10,0
.goto 2395,38.51,18.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tytalor Goldenblade|r.
.turnin 86998 >>Turn in Training Arc
.target Tytalor Goldenblade
.accept 87002 >>Accept Academic Aspirations
step
#completewith next
#label Training Arc 2
>>Kill |cRXP_ENEMY_Tytalor Goldenblade|r |cRXP_WARN_on a platform above|r.
.complete 87002,2 
.target Tytalor Goldenblade
step
.isOnQuest 87002
#completewith Training Arc 2
#arrowtext Leave building
.goto 2395,38.57,18.48,8 >>|cRXP_WARN_Leave the building|r.
step
#requires Training Arc 2
#title Above you
.goto 2395,38.16,18.37
>>Kill |cRXP_ENEMY_Tytalor Goldenblade|r |cRXP_WARN_on a platform above|r.
.complete 87002,2 
.target Tytalor Goldenblade
step
#label AspiringAcademicZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Tytalor Goldenblade|r
.goto 2395,39.32,17.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tytalor Goldenblade|r.
.turnin 87002 >>Turn in Academic Aspirations
.target Tytalor Goldenblade
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) One Adventurous Hatchling
#internal
step
#optional
.isQuestAvailable 86650
+|cRXP_WARN_You have to do another chapter first|r
.clicknext RestedXP Midnight\a) Ripple Effects (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Ripple Effects (H) >>CLICK HERE FOR GUIDE << Horde
step
#label OneAdventurousHatchlingA
#arrowtext Talk to\n|cRXP_FRIENDLY_Vaelith Sunplume|r
.goto 2395,56.84,35.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vaelith Sunplume|r.
.accept 89383 >>Accept One Adventurous Hatchling
.target Vaelith Sunplume
.accept 89384 >>Accept A Hungry Flock
.accept 89386 >>Accept A Roost-ed Development
step
#completewith Hawkstrider Fledgling
>>Kill |cRXP_ENEMY_Frogs|r
*Loot them for |T1509617:0|t[|cRXP_LOOT_Juicy Frog Leg|r].
.complete 89384,1 
.mob Gloombelly Toad
step
#arrowtext Sunleaf collected (6/6)\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2395,53.25,36.39,20,0
.goto 2395,52.69,35.97,20,0
.goto 2395,52.8,35.58,20,0
.goto 2395,53.28,35.14,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r
.complete 89386,1 
step
#label Hawkstrider Fledgling
.goto 2395,53.67,35.20
#arrowtext Click on the\n|cRXP_PICK_Hawkstrider|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hawkstrider|r
.complete 89383,1 
.target Lost Hawkstrider Fledgling
step
#label OneAdventurousHatchlingY
#loop
.goto 2395,53.54,35.73,30,0
.goto 2395,53.68,37.22,30,0
.goto 2395,52.75,35.75,30,0
.goto 2395,52.78,34.6,30,0
#arrowtext Kill |cRXP_ENEMY_Frogs|r\n|cRXP_ENEMY_(LOOT NOT SHARED)|r
>>Kill |cRXP_ENEMY_Frogs|r
*Loot them for |T1509617:0|t[|cRXP_LOOT_Juicy Frog Leg|r].
.complete 89384,1 
step
#label OneAdventurousHatchlingZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Vaelith Sunplume|r
.goto 2395,56.84,35.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vaelith Sunplume|r.
.turnin 89384 >>Turn in A Hungry Flock
.target Vaelith Sunplume
.turnin 89383 >>Turn in One Adventurous Hatchling
.turnin 89386 >>Turn in A Roost-ed Development
.turnin 89385 >>Turn in First Step Into Parenthood
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Far Striding
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label FarStridingA
.isOnQuest 94371
.goto 2395,57.42,39.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 94371 >>Turn in A Ranger's Dream
.target Arcanist Taemin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,57.42,39.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
*|cRXP_WARN_NOTE:|r Skip this step if the second quest is not available.
.accept 91452 >>Accept Range of Knowledge
.accept 91342 >>Accept If You Want It Done Right
.target Arcanist Taemin
step
#optional
#completewith Farstrider Library
.isOnQuest 91342
>>Kill |cRXP_ENEMY_Ornery Sweepers|r.
.complete 91342,1 
.mob Ornery Sweeper
step
#arrowtext Click on the |cRXP_PICK_Book|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,57.23,42.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 91452,1 
step
#arrowtext Click on the |cRXP_PICK_Book|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,56.90,43.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 91452,3 
step
#arrowtext Click on the |cRXP_PICK_Book|r\n|cRXP_ENEMY_(NOT SHARED)|r
#loop
.goto 2395,56.5,40.65,10,0
.goto 2395,56.90,43.08,10,0
.goto 2395,57.23,42.17,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 91452,2 
step
#label Farstrider Library
#arrowtext Use the |T133739:0|t|cRXP_WARN_[ExtraActionButton]|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,56.7,40.74,15,0
.goto 2395,56.66,40.97
>>Use the |T133739:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Arcanist Taemin|r.
.complete 91452,4 
.target Arcanist Taemin
step
#optional
.isOnQuest 91342
#loop
.goto 2395,56.7,40.43,30,0
.goto 2395,56.26,40.69,30,0
.goto 2395,56.78,41.87,30,0
.goto 2395,57.11,41.67,30,0
.goto 2395,57.28,40.05,30,0
>>Kill |cRXP_ENEMY_Ornery Sweepers|r.
.complete 91342,1 
.mob Ornery Sweeper
step
#label RangeOfKnowledgeA
.goto 2395,56.66,40.97
#arrowtext Click on the\n|cRXP_PICK_Book|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 91452,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,56.67,41.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91452 >>Turn in Range of Knowledge
.target Arcanist Taemin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,56.7,40.63,15,0
.goto 2395,57.43,39.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.accept 91342 >>Accept If You Want It Done Right
.target Arcanist Taemin
step
#loop
.goto 2395,56.7,40.43,30,0
.goto 2395,56.26,40.69,30,0
.goto 2395,56.78,41.87,30,0
.goto 2395,57.11,41.67,30,0
.goto 2395,57.28,40.05,30,0
>>Kill |cRXP_ENEMY_Ornery Sweepers|r.
.complete 91342,1 
.mob Ornery Sweeper
step
#label FarStridingB
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,56.67,41.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91342 >>Turn in If You Want It Done Right
.target Arcanist Taemin
step
#label SojournerTowers
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Dawnrunner|r
.goto 2395,56.71,40.66,10,0
.goto 2395,56.68,40.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Dawnrunner|r.
.accept 91345 >>Accept To the North Tower
.accept 91462 >>Accept To the Central Tower
.target Captain Dawnrunner
step
#completewith next
#label FarStridingC
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Valsarin|r
.goto 2395,56.78,41.19,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Valsarin|r.
.turnin 91345 >>Turn in To the North Tower
.target Ranger Valsarin
.accept 91347 >>Accept Strider Stampede
.disablecheckbox
step
#completewith FarStridingC
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Valsarin|r
.goto 2395,49.66,48.29,800 >>Follow the Arrow
step
#requires FarStridingC
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Valsarin|r
.goto 2395,49.66,48.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Valsarin|r.
.turnin 91345 >>Turn in To the North Tower
.target Ranger Valsarin
.accept 91347 >>Accept Strider Stampede
step
#label SojournerValsarin
#arrowtext Talk to\n|cRXP_FRIENDLY_Recruit Valsarin|r
.goto 2395,50.42,48.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Valsarin|r.
.complete 91347,1 
.skipgossipid 134809
.target Recruit Valsarin
step
#loop
.goto 2395,50.45,48.96,10,0
.goto 2395,50.77,48.82,20,0
.goto 2395,50.82,48.52,10,0
.goto 2395,50.6,48.41,10,0
.goto 2395,50.77,48.2,10,0
.goto 2395,50.99,48.19,10,0
.goto 2395,50.99,47.84,10,0
.goto 2395,51.43,48.12,10,0
.goto 2395,51.42,48.48,10,0
.goto 2395,51.23,48.39,10,0
.goto 2395,51.33,48.66,10,0
.goto 2395,51.04,48.59,10,0
.goto 2395,50.99,48.92,10,0
.goto 2395,51.27,49.4,10,0
.goto 2395,50.92,49.77,10,0
>>Run over the |cRXP_ENEMY_objects|r.
.complete 91347,2 
step
.goto 2395,50.41,48.50
#title |cFFFCDC00Follow the Arrow|r
>>Press the Macro to leave the vehicle.
*> It's in the "Active Items" window.
.complete 91347,3 
.macro Leave Vehicle,6656430 >> /leavevehicle
step
.goto 2395,50.44,48.58
#arrowtext Click on the\n|cRXP_PICK_Flower|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r.
.complete 91347,4 
step
#label FarStridingD
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Valsarin|r
.goto 2395,50.41,48.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Valsarin|r.
.turnin 91347 >>Turn in Strider Stampede
.target Ranger Valsarin
step
#label FarStridingE
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Asterae|r
.goto 2395,48.59,57.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Asterae|r.
.turnin 91462 >>Turn in To the Central Tower
.target Ranger Asterae
.accept 91348 >>Accept See a Mana 'bout a Wyrm
step
#label AgiWyrms
#loop
.goto 2395,47.75,57.41,40,0
.goto 2395,47.86,56.06,40,0
.goto 2395,49.05,55.78,40,0
.goto 2395,48.87,56.84,40,0
>>Kill |cRXP_ENEMY_Agitated Wyrms|r
.complete 91348,1 
.mob Agitated Wyrm
step
.goto 2395,48.62,57.63
#title |cFFFCDC00Follow the Arrow|r
.complete 91348,2 
step
#label FarStridingF
.goto 2395,48.62,57.63
#arrowtext Click on the\n|cRXP_PICK_Flower|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r
.complete 91348,3 
step
#label FarStridingG
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Asterae|r
.goto 2395,48.59,57.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Asterae|r.
.turnin 91348 >>Turn in See a Mana 'bout a Wyrm
.target Ranger Asterae
.accept 91463 >>Accept To the South Tower
step
#label FarStridingEE
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,43.87,75.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91463 >>Turn in To the South Tower
.target Arcanist Taemin
.accept 91349 >>Accept The Dark Part of the Woods
step
#loop
.goto 2395,44.49,77.06,40,0
.goto 2395,45.25,76.08,40,0
.goto 2395,46.02,79.66,40,0
.goto 2395,44.5,80.75,40,0
.goto 2395,43.31,79.35,40,0
#arrowtext Click on\n|cRXP_PICK_Animals|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Animals|r |cRXP_WARN_sometimes you can click them twice|r.
.complete 91349,1 
step
.goto 2395,42.86,79.16
#title |cFFFCDC00Follow the Arrow|r
.complete 91349,2 
step
.goto 2395,42.87,79.16
#arrowtext Click on the\n|cRXP_PICK_Cubs|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cubs|r
.complete 91349,3 
.timer 3.5,RP
.mob Wandering Cub
step
.goto 2395,42.85,79.24
#arrowtext Click on the\n|cRXP_PICK_Flower|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r |cRXP_WARN_after the roleplay|r.
.complete 91349,4 
step
#label SojournerWoods
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,43.47,75.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91349 >>Turn in The Dark Part of the Woods
.target Arcanist Taemin
.accept 91350 >>Accept A Real Assignment
step
#label A Real Assignment
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Dawnrunner|r and |cRXP_FRIENDLY_Arcanist Taemin|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Dawnrunner|r and |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91350 >>Turn in A Real Assignment
.accept 91384 >>Accept Recovery Mission
.target +Captain Dawnrunner
.goto 2395,59.36,68.82
.accept 91383 >>Accept Tidy Up
.goto 2395,59.4,68.9
.target Arcanist Taemin
step
#completewith Webs swept
>>Kill |cRXP_ENEMY_Enclave Lurkers|r and |cRXP_ENEMY_Watchful Striker|r
*Loot them for |T236995:0|t[|cRXP_LOOT_Scattered Supplies|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Crates|r
.complete 91384,1 
.mob Watchful Striker
.mob Enclave Lurker
.mob Forest Forager
step
#arrowtext Webs swept (1/5) \n Click |cRXP_PICK_Crates|r
.goto 2395,59.55,68.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webs|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91383,2,1 
step
#arrowtext Webs swept (2/5) \n Click |cRXP_PICK_Crates|r
.goto 2395,59.35,68.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webs|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91383,2,2 
step
#arrowtext Webs swept (5/5) \n Click |cRXP_PICK_Crates|r
#loop
.goto 2395,59.56,67.78,10,0
.goto 2395,59.32,68.13,10,0
.goto 2395,59.04,67.91,10,0
.goto 2395,59.55,68.45,10,0
.goto 2395,59.35,68.42,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webs|r
.complete 91383,2 
step
#label Webs swept
#arrowtext Nests cleared (5/5) \n Click |cRXP_PICK_Crates|r
#loop
.goto 2395,58.66,67.78,10,0
.goto 2395,58.75,69.09,10,0
.goto 2395,59.01,69.34,10,0
.goto 2395,59.43,69.76,10,0
.goto 2395,59.24,68.85,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nest|r
.complete 91383,1,5 
step
#loop
.goto 2395,59.93,68.03,35,0
.goto 2395,59.47,67.26,35,0
.goto 2395,59.15,68.07,35,0
.goto 2395,59.44,69.54,35,0
>>Kill |cRXP_ENEMY_Enclave Lurkers|r, |cRXP_ENEMY_Forest Forager|r and |cRXP_ENEMY_Watchful Striker|r
*Loot them for |T236995:0|t[|cRXP_LOOT_Scattered Supplies|r].
#arrowtext Click on\n|cRXP_PICK_Crates|r
*|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Crates|r
.complete 91384,1 
.mob Watchful Striker
.mob Forest Forager
.mob Enclave Lurker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Dawnrunner|r
.goto 2395,59.36,68.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Dawnrunner|r.
.turnin 91383 >>Turn in Tidy Up
.target Captain Dawnrunner
.turnin 91384 >>Turn in Recovery Mission
.accept 91385 >>Accept A Ranger's Spirit
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Dawnrunner|r
.goto 2395,59.5,67.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Dawnrunner|r.
.complete 91385,1 
.skipgossipid 135184
.target Arcanist Taemin
step
.goto 2395,59.44,66.55
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,2 
step
.goto 2395,59.19,66.25
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,3 
step
.goto 2395,58.88,65.94
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,4 
step
.goto 2395,59.09,65.44
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,5 
step
.goto 2395,58.88,64.90
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,6 
step
.goto 2395,58.95,64.35
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,7 
step
.goto 2395,59.17,64.05
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,8 
step
.goto 2395,59.35,63.79
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,9 
step
.goto 2395,59.51,63.50
#title |cFFFCDC00Follow the Arrow|r
.complete 91385,10 
step
#label FarStridingZZ
.goto 2395,59.49,62.99
#arrowtext Click on the\n|cRXP_PICK_Spirit of Lake Elrendar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spirit of Lake Elrendar|r
.complete 91385,11 
.target Spirit of Lake Elrendar
step
#label FarStridingZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,59.49,67.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91385 >>Turn in A Ranger's Spirit
.target Arcanist Taemin
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Runestone Rumbles
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Terel Bloodfate|r
.goto 2395,50.13,34.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Terel Bloodfate|r.
.accept 92396 >>Accept Calling in the Cavalry
.target Terel Bloodfate
step
#label SojournerPackage
.goto 2395,50.12,34.28
#arrowtext Click on the\n|cRXP_PICK_Crate|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 92396,1 
step
.goto 2395,39.26,56.72
#arrowtext Use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
>>Stand within the circle and use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92396,2 
step
.goto 2395,53.38,54.25
#arrowtext Use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
>>Stand within the circle and use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92396,3 
step
#label SojournerDawnstar
.goto 2395,61.59,62.76
#arrowtext Use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
>>Stand within the circle and use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92396,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alesil Dawnblood|r
.goto 2395,61.74,62.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alesil Dawnblood|r.
.turnin 92396 >>Turn in Calling in the Cavalry
.accept 92397 >>Accept Dawnstar Defense
.target Alesil Dawnblood
step
#loop
.goto 2395,62.13,62.77,25,0
.goto 2395,61.53,62.24,25,0
.goto 2395,61.42,63.31,25,0
#arrowtext Click on the\n|cRXP_PICK_Weapon Racks|r, |cRXP_PICK_Barricades|r, and |cRXP_PICK_Elixirs|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Racks|r, |cRXP_PICK_Barricades|r, and |cRXP_PICK_Elixirs|r.
.complete 92397,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alesil Dawnblood|r
.goto 2395,61.74,62.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alesil Dawnblood|r.
.turnin 92397 >>Turn in Dawnstar Defense
.target Alesil Dawnblood
.accept 92398 >>Accept And Then They Came
step
#completewith next
#label Protect Alesil Dawnblood
>>Defend |cRXP_FRIENDLY_Alesil Dawnblood|r
.complete 92398,2 
.target Alesil Dawnblood
step
#completewith Protect Alesil Dawnblood
#arrowtext Talk to\n|cRXP_FRIENDLY_Alesil|r
.goto 2395,60.71,62.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alesil|r |cRXP_WARN_if noone has|r.
.complete 92398,1 
.skipgossipid 136288
.target Alesil
step
#requires Protect Alesil Dawnblood
.goto 2395,60.71,62.38
>>Defend |cRXP_FRIENDLY_Alesil Dawnblood|r
.complete 92398,2 
.mob Advancing Prismonia
.mob Lightfrenzied Devourer
.mob Intruding Shinesipper
.mob Rampaging Lightbloom Ent
step
#label Then They Came
#arrowtext Talk to\n|cRXP_FRIENDLY_Alesil Dawnblood|r
.goto 2395,61.73,62.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alesil Dawnblood|r.
.turnin 92398 >>Turn in And Then They Came
.target Alesil Dawnblood
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Theft Tracking
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TheftTrackingA
.isOnQuest 94388
.goto 2395,41.12,38.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Meledor|r.
.turnin 94388 >>Turn in Second Time's a Choice
.target Magister Meledor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Meledor|r and |cRXP_FRIENDLY_Ranger Vardis|r
.goto 2395,41.11,38.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Meledor|r and |cRXP_FRIENDLY_Ranger Vardis|r.
.accept 88977 >>Accept Reenact the Crime
.accept 88978 >>Accept Tracking the Trail
.target Magister Meledor
.target Ranger Vardis
step
#completewith Frozen Moments
>>Kill |cRXP_ENEMY_Wyrms|r and |cRXP_ENEMY_Lynx|r.
*Loot them for the |T237245:0|t[|cRXP_LOOT_Digested Objects|r].
.complete 88978,1 
.mob Encroaching Mana Wyrm
.mob Encroaching Forest Lynx
step
#arrowtext Use |T134377:0|t[Arcane Timepiece]\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,41.11,38.5
>>Use |T134377:0|t[Arcane Timepiece].
.complete 88977,1 
.use 238730
step
#arrowtext Moments investigated (1/3) |cFFFCDC00(Read Note)|r\nTalk to\n|cRXP_FRIENDLY_Magister Meledor|r
.goto 2395,41.17,39.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Meledor|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 88977,2,1 
.target Magister Meledor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Meledor|r
.goto 2395,40.32,38.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Meledor|r
.complete 88977,2,2 
.target Magister Meledor
step
#label Frozen Moments
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Meledor|r
.goto 2395,39.66,38.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Meledor|r
.complete 88977,2,3 
.target Magister Meledor
step
#loop
.goto 2395,40.91,39.91,30,0
.goto 2395,41.47,38.38,30,0
.goto 2395,41.19,37.46,30,0
.goto 2395,40.08,38.58,30,0
>>Kill |cRXP_ENEMY_Wyrms|r and |cRXP_ENEMY_Lynx|r.
*Loot them for |T237245:0|t[|cRXP_LOOT_Half-Eaten Diplomatic Letter|r].
.complete 88978,1 
.mob Encroaching Mana Wyrm
.mob Encroaching Forest Lynx
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Vardis|r and |cRXP_FRIENDLY_Magister Meledor|r
.goto 2395,39.63,39.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Vardis|r and |cRXP_FRIENDLY_Magister Meledor|r.
.turnin 88978 >>Turn in Tracking the Trail
.turnin 88977 >>Turn in Reenact the Crime
.target Ranger Vardis
.target Magister Meledor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Meledor|r
.goto 2395,38.51,39.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Meledor|r.
.accept 88979 >>Accept Caught Red-Handed
.target Magister Meledor
step
#title |cFFFCDC00NPC Patrols|r
.goto 2395,38.16,39.11
>>Kill |cRXP_ENEMY_Hot-Headed Lynx|r.
.complete 88979,1 
.mob Hot-Headed Lynx
step
.goto 2395,38.09,39.19
#arrowtext Click on the\n|cRXP_PICK_Book|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 88979,2 
step
#label TheftTrackingB
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Meledor|r
.goto 2395,39.76,39.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Meledor|r
.turnin 88979 >>Turn in Caught Red-Handed
.target Magister Meledor
step
#label SojournerBark
#arrowtext Talk to\n|cRXP_FRIENDLY_Luma|r
.goto 2395,39.89,39.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r.
.accept 90544 >>Accept Thief at Bark
.timer 37.5,RP
.target Luma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Cute Doggo|r
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cute Doggo|r |cRXP_WARN_after the roleplay|r.
.complete 90544,1 
.timer 7.3,RP
.skipgossipid 133262
.target Luma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Luma|r
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r |cRXP_WARN_after the roleplay|r.
.turnin 90544 >>Turn in Thief at Bark
.target Luma
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Port Detective
#internal
step
#optional
.isQuestAvailable account,86735
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label PortDetectiveA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,46.91,45.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.accept 87392 >>Accept Cargo Conspiracy
.target Lyssara Duskmourne
step
#label PortDetectiveB
#arrowtext Click on the |cRXP_PICK_Bush|r\n|cRXP_WARN_Cancel the channel|r
.goto 2395,46.25,44.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r.
.complete 87392,1 
step
#label PortDetectiveC
#arrowtext Click on the |cRXP_PICK_Dummy|r\n|cRXP_WARN_Cancel the channel|r
.goto 2395,45.92,45.09
*|cRXP_WARN_Open and close the Game Menu to cancel the cast and restore all actions immediately|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dummy|r.
.complete 87392,2 
step
#label PortDetectiveD
#arrowtext Click on the |cRXP_PICK_Fake Bush|r\n|cRXP_WARN_Cancel the channel|r
.goto 2395,47.00,46.03
*|cRXP_WARN_Open and close the Game Menu to cancel the cast and restore all actions immediately|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fake Bush|r
.complete 87392,3 
step
#arrowtext Click on the |cRXP_PICK_Notes|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.06,46.27
*|cRXP_WARN_Open and close the Game Menu to cancel the cast and restore all actions immediately|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Notes|r
.complete 87392,4 
step
#label PortDetectiveDA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,46.91,45.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.turnin 87392 >>Turn in Cargo Conspiracy
.target Lyssara Duskmourne
.accept 87393 >>Accept Warranted Search
.accept 87394 >>Accept Supplier Surveillance
step
#label PortDetectiveDB
#completewith Front View
>>Kill |cRXP_ENEMY_Tidebornes|r
.complete 87393,1 
.mob Tideborne Deckwalker
.mob Freight Barker
.mob Tideborne Freight Runner
step
.goto 2395,40.52,44.28
#arrowtext Click on the\n|cRXP_PICK_Telescope|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,1 
step
#arrowtext At the top\nClick on the\n|cRXP_PICK_Telescope|r
.goto 2395,39.46,45.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,2 
step
.goto 2395,39.62,44.13
#arrowtext Click on the\n|cRXP_PICK_Telescope|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,3 
step
#label Front View
.goto 2395,39.28,44.45
#title |cFFFCDC00Follow the Arrow|r
.complete 87394,4 
step
#loop
.goto 2395,38.08,45.19,30,0
.goto 2395,40.29,44.94,30,0
>>Kill |cRXP_ENEMY_Tidebornes|r
.complete 87393,1 
.mob Tideborne Deckwalker
.mob Freight Barker
.mob Tideborne Freight Runner
step
#arrowtext On the second floor\nAt the top\nTalk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,39.45,44.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.turnin 87393 >>Turn in Warranted Search
.target Lyssara Duskmourne
.turnin 87394 >>Turn in Supplier Surveillance
.accept 87395 >>Accept Below the Brine
step
.goto 2395,39.44,43.69
#title |cFFFCDC00Follow the Arrow|r
>>Jump into the Water
.complete 87395,1 
step
#loop
.goto 2395,37.78,43.30,35,0
.goto 2395,40.09,43.62,35,0
#arrowtext Kill |cRXP_ENEMY_Nagas|r\nLoot for |T134856:0|t[|cRXP_LOOT_Unstable Arcana|r]
>>Kill |cRXP_ENEMY_Nagas|r
*Loot them for |T134856:0|t[|cRXP_LOOT_Unstable Arcana|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Crates|r.
*Use |T134853:0|t[Elixir] for swimspeed & breathing
.complete 87395,2 
.mob Tideborne Courier
.use 239022
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,35.80,43.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.turnin 87395 >>Turn in Below the Brine
.target Lyssara Duskmourne
.accept 87396 >>Accept Dead to Rights
.accept 87397 >>Accept Cargo Collateral
step
#completewith next
>>Kill |cRXP_ENEMY_Naga|r.
.complete 87396,1 
.mob Tideborne Smuggler
.mob Tideborne Freighter
step
#loop
.goto 2395,35.34,42.99,30,0
.goto 2395,34.55,43.56,30,0
.goto 2395,35.04,43.88,30,0
.goto 2395,35.18,44.36,30,0
.goto 2395,35.22,44.72,30,0
#arrowtext Click on the\n|cRXP_PICK_Crate|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 87397,1 
step
#loop
.goto 2395,33.99,47.65,30,0
.goto 2395,34.25,44.48,30,0
.goto 2395,34.7,43.28,30,0
>>Kill |cRXP_ENEMY_Naga|r.
.complete 87396,1 
.mob Tideborne Smuggler
.mob Tideborne Freighter
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,35.80,43.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.turnin 87397 >>Turn in Cargo Collateral
.target Lyssara Duskmourne
.turnin 87396 >>Turn in Dead to Rights
.accept 87398 >>Accept Smuggler Showdown
step
.goto 2395,37.49,44.36
>>Kill |cRXP_ENEMY_Captain Dorynth Bloodwake|r on the ship.
.complete 87398,2 
.timer 12,RP
.mob Captain Dorynth Bloodwake
step
#label PortDetectiveZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,37.76,44.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r |cRXP_WARN_after the roleplay|r.
.turnin 87398 >>Turn in Smuggler Showdown
.target Lyssara Duskmourne
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Daggerspine Landing
#internal
step
#optional
.isQuestAvailable 90494
+|cRXP_WARN_You have to do the "Shadowfall" Chapter first|r
.clicknext RestedXP Midnight\a) Shadowfall (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Shadowfall (H) >>CLICK HERE FOR GUIDE << Horde
step
#label DaggerspineLandingA
.isQuestAvailable 91493
#arrowtext Talk to\n|cRXP_FRIENDLY_Fern Shadestar|r
.goto 2395,37.29,73.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fern Shadestar|r.
.accept 94370 >>Accept Slithering Closer
.target Fern Shadestar
step
#label DaggerspineLandingB
.isOnQuest 94370
#arrowtext Talk to\n|cRXP_FRIENDLY_Numia Golden|r
.goto 2395,38.96,61.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Numia Golden|r.
.turnin 94370 >>Turn in Slithering Closer
.target Numia Golden
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hathvelion Sungaze|r
.goto 2395,38.96,61.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.accept 91493 >>Accept Not What I Ordered
.target Hathvelion Sungaze
step
#label DaggerspineLandingC
#arrowtext Click on the |cRXP_PICK_Crates|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,38.94,61.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crates|r.
.complete 91493,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hathvelion Sungaze|r, |cRXP_FRIENDLY_Numia Golden|r, and |cRXP_FRIENDLY_Ranger Krenn'an|r
.goto 2395,38.97,61.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r, |cRXP_FRIENDLY_Numia Golden|r and |cRXP_FRIENDLY_Ranger Krenn'an|r.
.turnin 91493 >>Turn in Not What I Ordered
.accept 91505 >>Accept Daggers in My Spine
.accept 91494 >>Accept One Elf's Trash, Another Elf's Treasure
.accept 91495 >>Accept Familiar Faces in Peril
.target Hathvelion Sungaze
.target Numia Golden
.target Ranger Krenn'an
step
.goto 2395,38.99,61.58
#arrowtext Click on the\n|cRXP_PICK_Container|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Container|r.
.complete 91494,1 
step
#completewith Apprentice Varnis
>>Kill |cRXP_ENEMY_Naga|r.
.complete 91505,1 
.mob Daggerspine Infuser
.mob Daggerspine Myrmidon
step
#completewith Apprentice Varnis
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects & Infusers|r.
.complete 91494,2 
step
#arrowtext Talk to |cRXP_FRIENDLY_Apothecary Enith|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,36.88,60.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Enith|r.
.complete 91495,1 
.skipgossipid 134652
.target Apothecary Enith
step
#arrowtext Talk to |cRXP_FRIENDLY_Ranger Vedoran|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,37.55,65.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Vedoran|r.
.complete 91495,3 
.skipgossipid 134653
.target Ranger Vedoran
step
#label Apprentice Varnis
#arrowtext Talk to |cRXP_FRIENDLY_Apprentice Varnis|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,35.63,67.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Varnis|r.
.complete 91495,2 
.skipgossipid 134654
.target Apprentice Varnis
step
#hidewindow
#completewith Daggerspine naga
#loop
.goto 2395,34.42,68.57,40,0
.goto 2395,35.24,65.05,40,0
.goto 2395,37.5,62.67,40,0
.goto 2395,36.93,60.71,40,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Naga|r.
.complete 91505,1 
.mob Daggerspine Myrmidon
.mob Daggerspine Infuser
step
#arrowtext Click on\n|cRXP_PICK_Objects & Infusers|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects & Infusers|r.
.complete 91494,2 
step
#label Daggerspine naga
>>Kill |cRXP_ENEMY_Naga|r.
.complete 91505,1 
.mob Daggerspine Myrmidon
.mob Daggerspine Infuser
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Krenn'an|r, |cRXP_FRIENDLY_Hathvelion Sungaze|r, and |cRXP_FRIENDLY_Numia Golden|r
.goto 2395,38.98,61.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Krenn'an|r, |cRXP_FRIENDLY_Hathvelion Sungaze|r, |cRXP_FRIENDLY_Numia Golden|r, and |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.turnin 91495 >>Turn in Familiar Faces in Peril
.turnin 91505 >>Turn in Daggers in My Spine
.turnin 91494 >>Turn in One Elf's Trash, Another Elf's Treasure
.accept 91504 >>Accept Arcane Amassing
.target Ranger Krenn'an
.target Hathvelion Sungaze
.target Numia Golden
step
#label DaggerspineLandingD
.goto 2395,33.45,65.38
#arrowtext Click on\n|cRXP_PICK_Princess Naz'jena|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Princess Naz'jena|r
*Kill |cRXP_ENEMY_Princess Naz'jena|r.
.complete 91504,1 
.complete 91504,2 
.mob Princess Naz'jena
step
#completewith next
#label Arcane Amassing
#arrowtext Talk to\n|cRXP_FRIENDLY_Hathvelion Sungaze|r
.goto 2395,40.13,61.33,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.turnin 91504 >>Turn in Arcane Amassing
.target Hathvelion Sungaze
step
#completewith Arcane Amassing
.goto 2395,40.21,61.35,15 >>Enter the building
step
#requires Arcane Amassing
#label DaggerspineLandingZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Hathvelion Sungaze|r
.goto 2395,40.21,61.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.turnin 91504 >>Turn in Arcane Amassing
.target Hathvelion Sungaze
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Flowers for Amalthea
#internal
step
#optional
.isQuestAvailable 90494
+|cRXP_WARN_You have to do the "Shadowfall" Chapter first|r
.clicknext RestedXP Midnight\a) Shadowfall (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Shadowfall (H) >>CLICK HERE FOR GUIDE << Horde
step
#label SojournerBlossom
#arrowtext Talk to\n|cRXP_FRIENDLY_Talandra Dawnsprite|r
.goto 2395,37.50,72.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.accept 92021 >>Accept Graveblossom Gardening
.accept 92022 >>Accept A Venomous Vocation
.target Talandra Dawnsprite
step
#hidewindow
#completewith SojournerMournbat
#loop
.goto 2395,38.25,72.44,10,0
.goto 2395,39.43,72.9,10,0
.goto 2395,38.55,74.01,10,0
.goto 2395,39.56,74.72,10,0
.goto 2395,39.85,76.35,10,0
.goto 2395,39.54,76.68,10,0
.goto 2395,39.14,77.06,10,0
.goto 2395,38.86,76.46,10,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Bats|r.
*Loot them for the |T6011929:0|t[|cRXP_LOOT_Potent Mournbat Venom|r].
.complete 92022,1 
.mob Venomous Mournbat
.mob Elder Mournbat
step
#arrowtext Click on the\n|cRXP_PICK_Flowers|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flowers|r
.complete 92021,1 
step
#label SojournerMournbat
>>Kill |cRXP_ENEMY_Bats|r
*Loot them for |T6011929:0|t[|cRXP_LOOT_Potent Mournbat Venom|r].
.complete 92022,1 
.mob Venomous Mournbat
.mob Elder Mournbat
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Talandra Dawnsprite|r
.goto 2395,37.50,72.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.turnin 92021 >>Turn in Graveblossom Gardening
.turnin 92022 >>Turn in A Venomous Vocation
.accept 92023 >>Accept Suspicious Sundries
.target Talandra Dawnsprite
step
#label SojournerCampaignVial1
#arrowtext Talk to\n|cRXP_FRIENDLY_Vehn Sorrelstride|r
.goto 2395,39.25,61.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vehn Sorrelstride|r and buy |T236211:0|t[Vial of Quicksilver].
.complete 92023,1 
.buy 254280,1
.skipgossipid 136321
.target Vehn Sorrelstride
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nara Fadebranch|r
.goto 2395,39.59,60.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nara Fadebranch|r and buy |T6011930:0|t[Flask of Dragon's Blood].
.complete 92023,2 
.buy 254281,1
.target Nara Fadebranch
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Limien Bountcask|r
.goto 2395,40.72,60.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limien Bountcask|r and buy |T132797:0|t[Bottle of Magister's Reserve].
.complete 92023,3 
.buy 254282,1
.skipgossipid 136323
.target Limien Bountcask
step
#label SojournerSundries
#arrowtext Talk to\n|cRXP_FRIENDLY_Limien Bountcask|r
.goto 2395,40.71,60.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limien Bountcask|r.
.turnin 92023 >>Turn in Suspicious Sundries
.accept 92024 >>Accept House Call
.target Limien Bountcask
step
#completewith next
#label First clue found
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r.
.complete 92024,1 
step
#completewith First clue found
#arrowtext Enter building
.goto 2395,37.53,72.34,5 >>|cRXP_WARN_Enter the building.|r
step
#requires First clue found
.goto 2395,37.65,72.16
#arrowtext Click on the\n|cRXP_PICK_Weapon Rack|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r.
.complete 92024,1 
.skipgossipid 136353
step
.goto 2395,37.5,72.29
#arrowtext Click on the\n|cRXP_PICK_Vase|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vase|r.
.complete 92024,2 
.skipgossipid 136354
step
.goto 2395,37.45,72.06
#arrowtext Click on the\n|cRXP_PICK_Book|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 92024,3 
.skipgossipid 136355
step
.goto 2395,37.46,72.06
#arrowtext Click on the\n|cRXP_PICK_Tome|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tome|r.
.turnin 92024 >>Turn in House Call
.accept 92025 >>Accept Flowers for Amalthea
step
#completewith next
#label Talandra Dawnsprite
#arrowtext Leave building
.goto 2395,37.54,72.35,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.complete 92025,1 
step
#completewith Talandra Dawnsprite
#arrowtext Leave building
.goto 2395,32.82,78.79,600 >>|cRXP_WARN_Leave the building.|r
step
#requires Talandra Dawnsprite
#arrowtext Talk to\n|cRXP_FRIENDLY_Talandra Dawnsprite|r
.goto 2395,32.82,78.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.complete 92025,1 
.skipgossipid 136372
step
.goto 2395,32.82,78.79
#arrowtext Click on the\n|cRXP_PICK_Candles|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Candles|r.
.complete 92025,2 
step
.goto 2395,32.82,78.79
#arrowtext Use |T236875:0|t|cRXP_WARN_[ExtraActionButton]|r
>>Use the |T236875:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 92025,3 
.timer 8,RP
step
.goto 2395,32.82,78.78
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 92025,4 
step
#label SojournerFlowers
#arrowtext Talk to\n|cRXP_FRIENDLY_Talandra Dawnsprite|r
.goto 2395,32.82,78.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.turnin 92025 >>Turn in Flowers for Amalthea
.target Talandra Dawnsprite
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Sunbath, Take Me Away
#internal
step
#optional
.isQuestAvailable 86745
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valdekar Solaar|r
.goto 2395,48.76,76.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r.
.accept 91271 >>Accept A Fish!
.target Valdekar Solaar
step
#label Fish!SojournerCampaign1
.goto 2395,48.68,76.1
.train 7620 >>Talk to |cRXP_FRIENDLY_Melandra|r to train |cRXP_PICK_Fishing|r.
.target Melandra
.skipgossipid 38266
step
.goto 2395,49.76,75.12
>>Use |T4620674:0|t[Fishing] make sure it lands inside the Sunbath School.
.complete 91271,1 
.usespell 131474
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valdekar Solaar|r
.goto 2395,48.76,76.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r.
.complete 91271,2 
.target Valdekar Solaar
.skipgossipid 134361
step
.goto 2395,49.23,76.22
>>Use |T4620674:0|t[Fishing] make sure it lands inside the Sunbath School.
.complete 91271,3 
.usespell 131474
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valdekar Solaar|r
.goto 2395,48.76,76.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r.
.complete 91271,4 
.target Valdekar Solaar
.skipgossipid 134506
step
.goto 2395,48.72,75.34
>>Use |T4620674:0|t[Fishing] make sure it lands inside the Sunbath School.
.complete 91271,5 
.usespell 131474
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valdekar Solaar|r
.goto 2395,48.75,76.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r.
.complete 91271,6 
.skipgossipid 134505
.target Valdekar Solaar
step
.goto 2395,48.68,76.01
>>Use |T4620674:0|t[Fishing] make sure it lands inside the Sunbath School.
.complete 91271,7 
.usespell 131474
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valdekar Solaar|r and |cRXP_FRIENDLY_Kaliel Solaar|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r and |cRXP_FRIENDLY_Kaliel Solaar|r.
.turnin 91271 >>Turn in A Fish!
.goto 2395,48.76,76.73
.target +Valdekar Solaar
.accept 91090 >>Accept Pesky Pests
.timer 5.5,RP
.goto 2395,48.78,76.71
.accept 91328 >>Accept Secret Ingredients
.goto 2395,48.76,76.73
.target +Kaliel Solaar
step
#completewith Sinara Berry
>>Kill |cRXP_ENEMY_Sungrub|r.
.complete 91090,2 
.mob Sungrub
step
#arrowtext Blossom (6/6) | Berries (5/5)\nClick on the\n|cRXP_PICK_Flowers|r and |cRXP_PICK_Vines|r
#loop
.goto 2395,48.71,77.00,10,0
.goto 2395,48.61,76.91,10,0
.goto 2395,48.33,77.37,10,0
.goto 2395,48.24,76.97,10,0
.goto 2395,48.34,76.87,10,0
.goto 2395,48.23,76.45,10,0
.goto 2395,48.05,76.02,10,0
.goto 2395,48.08,75.76,10,0
.goto 2395,48.14,75.61,10,0
.goto 2395,47.63,75.54,10,0
.goto 2395,47.52,75.44,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flowers|r and |cRXP_PICK_Vines|r.
.complete 91328,1 
.complete 91328,2 
step
#label Sinara Berry
#loop
.goto 2395,48.41,74,40,0
.goto 2395,48.55,77.3,40,0
>>Fly through the Butterflies
.complete 91090,1 
.mob Persistent Butterfly
step
#loop
.goto 2395,48.26,77.32,25,0
.goto 2395,48.15,76.16,25,0
.goto 2395,47.72,75.24,25,0
.goto 2395,48.5,74.6,25,0
.goto 2395,48.84,75.39,30,0
>>Kill |cRXP_ENEMY_Sungrub|r.
.complete 91090,2 
.mob Sungrub
step
#label Fish!SojournerCampaign2
#arrowtext Talk to\n|cRXP_FRIENDLY_Valdekar Solaar|r and |cRXP_FRIENDLY_Kaliel Solaar|r
.goto 2395,48.76,76.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r and |cRXP_FRIENDLY_Kaliel Solaar|r.
.turnin 91328 >>Turn in Secret Ingredients
.turnin 91090 >>Turn in Pesky Pests
.accept 91137 >>Accept Lost in Light
.target Valdekar Solaar
.target Kaliel Solaar
step
.goto 2395,50.20,74.05
>>Kill |cRXP_ENEMY_Liya Waterbloom|r.
.complete 91137,1 
.mob Liya Waterbloom
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kaliel Solaar|r
.goto 2395,48.77,76.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaliel Solaar|r.
.turnin 91137 >>Turn in Lost in Light
.target Kaliel Solaar
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Blinding Sun
#internal
step
#optional
.isQuestAvailable 86745
+|cRXP_WARN_You have to do the "Whispers in the Twilight" Chapter first|r
.clicknext RestedXP Midnight\a) Whispers in the Twilight (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Whispers in the Twilight (H) >>CLICK HERE FOR GUIDE << Horde
step
#label BlindingSunA
#arrowtext Talk to\n|cRXP_FRIENDLY_Farstrider Sedina|r
.goto 2395,50.52,78.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farstrider Sedina|r.
.accept 87399 >>Accept Facing the Sun
.target Farstrider Sedina
step
#loop
.goto 2395,51.79,76.96,35,0
.goto 2395,51.61,75.46,35,0
.goto 2395,50.76,77.23,35,0
>>Kill |cRXP_ENEMY_Wyrms|r and |cRXP_ENEMY_Dragonhawks|r
.complete 87399,1 
.mob Agitated Wyrm
.mob Territorial Dragonhawk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Farstrider Sedina|r and |cRXP_FRIENDLY_Harris Lightsbreath|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farstrider Sedina|r and |cRXP_FRIENDLY_Harris Lightsbreath|r.
.turnin 87399 >>Turn in Facing the Sun
.target Farstrider Sedina
.accept 87400 >>Accept Scattered in Sunbeams
.goto 2395,50.52,78.17
.accept 87401 >>Accept Gardener Mishap
.goto 2395,50.5,78.11
.target Harris Lightsbreath
step
#arrowtext Kill |cRXP_ENEMY_Automated Gardener|r\n|cRXP_ENEMY_(LOOT NOT SHARED)|r
.goto 2395,52.43,75.90
>>Kill the |cRXP_ENEMY_Automated Gardener|r.
*Loot him for the |T134336:0|t[|cRXP_LOOT_Humming Core|r].
.complete 87401,1 
.mob Automated Gardener
step
#label Evidence of researchers found
#arrowtext Click on the |cRXP_PICK_Objects|r\n|cRXP_ENEMY_(FLOWER NOT SHARED)|r
#loop
.goto 2395,52.34,74.83,10,0
.goto 2395,53.22,73.93,10,0
.goto 2395,51.54,73.49,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Objects|r
.complete 87400,1 
step
#label Sunbeams
#arrowtext Talk to\n|cRXP_FRIENDLY_Farstrider Sedina|r and |cRXP_FRIENDLY_Harris Lightsbreath|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farstrider Sedina|r and |cRXP_FRIENDLY_Harris Lightsbreath|r.
.turnin 87400 >>Turn in Scattered in Sunbeams
.goto 2395,50.53,78.16
.target +Farstrider Sedina
.turnin 87401 >>Turn in Gardener Mishap
.accept 87402 >>Accept The Light Provides
.goto 2395,50.49,78.11
.target +Harris Lightsbreath
step
.goto 2395,51.29,76.72
>>Use the |T6891026:0|t[Humming Core] infront of the door.
.complete 87402,1 
.use 246441
step
.goto 2395,51.45,76.40
#arrowtext Fly up\nEnter through the Dome
>>Kill |cRXP_ENEMY_Hungering Lightroot|r.
*|cRXP_WARN_NOTE:|r Kite him out of the building if you can't use certain abilities or your pet doesn't help you.
.complete 87402,2 
.mob Hungering Lightroot
step
#label BlindingSunZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Harris Lightsbreath|r
.goto 2395,50.49,78.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harris Lightsbreath|r.
.turnin 87402 >>Turn in The Light Provides
.target Harris Lightsbreath
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Paladin Rescue
#internal
#chapter
step
.xp 90 >>Skip this for now, come back once you hit level 90.
step << Alliance
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Taelia Fordragon|r
.goto 2393,53.15,69.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taelia Fordragon|r
.accept 90546 >>Accept Missing Paladins
.target Taelia Fordragon
step << Horde
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.goto 2393,53.21,69.52
.accept 90547 >>Accept Missing Paladins
.target Salandria
step
.xp <90,1
#label Struggle
#arrowtext Talk to\n|cRXP_FRIENDLY_Taelia Fordragon|r and |cRXP_FRIENDLY_Salandria|r
.goto 2395,44.05,66.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taelia Fordragon|r and |cRXP_FRIENDLY_Salandria|r.
.turnin 90546 >>Turn in Missing Paladins << Alliance
.turnin 90547 >>Turn in Missing Paladins << Horde
.accept 90549 >>Accept Signs of the Struggle
.accept 90548 >>Accept Twilight Missive
.target Taelia Fordragon
.target Salandria
step
.xp <90,1
#completewith Arms found2
>>Kill |cRXP_ENEMY_Twilight Shadecaster|r and |cRXP_ENEMY_Twilight Blade|r.
*Loot them for |T254296:0|t[|cRXP_LOOT_Twilight's Blade Missive|r].
.complete 90548,1 
.mob Twilight Shadecaster
.mob Twilight Blade
step
.xp <90,1
.goto 2395,44.38,69.68
#arrowtext Click on the\n|cRXP_PICK_Shield|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shield|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90549,1,1 
step
.xp <90,1
.goto 2395,43.99,69.49
#arrowtext Click on the\n|cRXP_PICK_Shield|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shield|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90549,1,2 
step
.xp <90,1
#completewith next
#label Arms found
#arrowtext Enter Building
.goto 2395,43.3,69.38,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shield|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90549,1,3 
step
.xp <90,1
#completewith Arms found
#arrowtext Enter Building
.goto 2395,43.11,69.73,30 >>Enter the building
step
.xp <90,1
#requires Arms found
.goto 2395,43.11,69.73,10,0
.goto 2395,43.29,69.85
#arrowtext Click on the\n|cRXP_PICK_Shield|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shield|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90549,1,3 
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Crusader Sombersun|r
.goto 2395,43.28,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crusader Sombersun|r.
.accept 90550 >>Accept A Somber Sun
.target Crusader Sombersun
step
.xp <90,1
.goto 2395,43.31,69.13
#arrowtext Click on the\n|cRXP_PICK_Weapon|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90549,1,4 
step
.xp <90,1
.goto 2395,42.87,68.6
#arrowtext Click on the\n|cRXP_PICK_Shield|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shield|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90549,1,5 
step
.xp <90,1
#label Arms found2
.goto 2395,43.15,68
#arrowtext Click on the\n|cRXP_PICK_Weapon|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90549,1,6 
step
.xp <90,1
#loop
.goto 2395,43.8,67.99,30,0
.goto 2395,44.27,70.47,30,0
.goto 2395,42.19,68.92,30,0
>>Kill |cRXP_ENEMY_Twilight Shadecaster|r and |cRXP_ENEMY_Twilight Blade|r.
*Loot them for |T254296:0|t[|cRXP_LOOT_Twilight's Blade Missive|r].
.complete 90548,1 
.mob Twilight Shadecaster
.mob Twilight Blade
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Taelia Fordragon|r and |cRXP_FRIENDLY_Salandria|r
.goto 2395,44.04,66.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taelia Fordragon|r and |cRXP_FRIENDLY_Salandria|r.
.turnin 90549 >>Turn in Signs of the Struggle
.turnin 90550 >>Turn in A Somber Sun
.turnin 90548 >>Turn in Twilight Missive
.accept 90551 >>Accept Captured Information
.target Salandria
.target Taelia Fordragon
step
.xp <90,1
.goto 2395,42.17,69.30
#arrowtext Click on the\n|cRXP_PICK_Isolated Shadecaster|r
>>Defeat |cRXP_ENEMY_Isolated Shadecaster|r and click on him.
.complete 90551,1 
.target Isolated Shadecaster
step
.xp <90,1
.goto 2395,41.58,72.15
#title |cFFFCDC00Follow the Arrow|r
.complete 90551,2 
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
.goto 2395,41.58,72.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.turnin 90551 >>Turn in Captured Information
.target Salandria
.accept 90552 >>Accept Interrogation
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
.goto 2395,41.59,72.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.complete 90552,1 
.skipgossipid 135497
.target Salandria
step
.xp <90,1
.goto 2395,41.59,72.16
>>Spam the abilities
.complete 90552,2 
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
.goto 2395,41.58,72.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.turnin 90552 >>Turn in Interrogation
.target Salandria
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
.goto 2395,41.58,72.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.turnin 90552 >>Turn in Interrogation
.target Salandria
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Taelia Fordragon|r and |cRXP_FRIENDLY_Salandria|r
.goto 2395,44.42,81.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taelia Fordragon|r and |cRXP_FRIENDLY_Salandria|r.
.accept 90570 >>Accept To the Ruins of Deatholme
.turnin 90570 >>Turn in To the Ruins of Deatholme
.accept 90555 >>Accept Blessing of Freedom
.accept 90553 >>Accept Executing the Blades
.accept 90554 >>Accept Leave Ashes in Your Wake
.target Taelia Fordragon
.target Salandria
step
.xp <90,1
#completewith Crusader Lightspear2
>>Kill |cRXP_ENEMY_Cultists|r
.complete 90553,1 
.mob Twilight Death-Dealer
.mob Dark Caller
.mob Darkness Evoker
step
.xp <90,1
#completewith Crusader Lightspear2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r.
.complete 90554,1 
step
.xp <90,1
#completewith next
#label Bloodknight Ithelis
#hidewindow
.complete 90555,7 
step
.xp <90,1
#completewith Bloodknight Ithelis
.goto 2395,45.16,87.40
.cast 461749 >>Click on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
step
.xp <90,1
#requires Bloodknight Ithelis
.goto 2395,44.09,88.35
>>Go to the next |cRXP_PICK_Cage|r
.complete 90555,7 
step
.xp <90,1
#completewith next
#label Motega Firemane
#hidewindow
.complete 90555,8 
step
.xp <90,1
#completewith Motega Firemane
.goto 2395,44.09,88.35
.cast 461749 >>Click on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
step
.xp <90,1
#requires Motega Firemane
.goto 2395,43.24,87.93
>>Go to the next |cRXP_PICK_Cage|r
.complete 90555,8 
step
.xp <90,1
#completewith next
#label Crusader Dawnheart
#arrowtext Enter Cave
.goto 2395,43.24,87.93,30,0
.goto 2395,42.86,88.19,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r inside the cave.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90555,9 
step
.xp <90,1
#completewith Crusader Dawnheart
#arrowtext Enter Cave
.goto 2395,42.46,88.99,65 >>Enter the Cave
step
.xp <90,1
#requires Crusader Dawnheart
.goto 2395,42.46,88.99
#arrowtext Click on the\n|cRXP_PICK_Cage|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r inside the cave.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90555,9 
step
.xp <90,1
#completewith next
#label Crusader Newbery
#hidewindow
.complete 90555,5 
step
.xp <90,1
#completewith Crusader Newbery
.goto 2395,41.96,86.27,20,0
.goto 2395,41.64,86.27
.cast 461749 >>Click on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
step
.xp <90,1
#requires Crusader Newbery
.goto 2395,42,86.25
>>Go to the next cage
.complete 90555,5 
step
.xp <90,1
#completewith next
#label Crusader Flaresong
#hidewindow
.goto 2395,42.47,85.84,20,0
.complete 90555,3 
step
.xp <90,1
#completewith Crusader Flaresong
.goto 2395,42.34,85.18
.cast 461749 >>Click on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
step
.xp <90,1
#requires Crusader Flaresong
.goto 2395,42.63,85.98
>>Go to the next cage
.complete 90555,3 
step
.xp <90,1
#arrowtext On a platform above\nTalk to\n|cRXP_FRIENDLY_Crusader Whitney|r
.goto 2395,43.39,85.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crusader Whitney|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90555,6 
.skipgossipid 134237
.target Crusader Whitney
step
.xp <90,1
#completewith next
#label Archivist Colin
#hidewindow
.complete 90555,2 
step
.xp <90,1
#completewith Archivist Colin
.goto 2395,42.17,83.73
.cast 461749 >>Click on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
step
.xp <90,1
#requires Archivist Colin
.goto 2395,41.81,82.96
>>Go to the next Cage
.complete 90555,2 
step
.xp <90,1
#completewith next
#label Sunwalker Atohmo
#hidewindow
.complete 90555,1 
step
.xp <90,1
#completewith Sunwalker Atohmo
.goto 2395,41.81,82.96
.cast 461749 >>Click on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
step
.xp <90,1
#requires Sunwalker Atohmo
.goto 2395,41.32,85.88
#arrowtext Click on the\n|cRXP_PICK_Cage|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90555,1 
step
.xp <90,1
#completewith next
#label Crusader Lightspear
#hidewindow
.complete 90555,4 
step
.xp <90,1
#completewith Crusader Lightspear
.goto 2395,41.32,85.88
.cast 461749 >>Click on the |cRXP_PICK_Cage|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
step
.xp <90,1
#requires Crusader Lightspear
#label Crusader Lightspear2
.goto 2395,41.73,88.41
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 90555,4 
step
.xp <90,1
#hidewindow
#completewith Cultists
#loop
.goto 2395,41.73,88.41,30,0
.goto 2395,42.94,88.8,30,0
.goto 2395,44.22,88.11,30,0
.goto 2395,45.19,86.7,30,0
.goto 2395,44.14,83.24,30,0
.goto 2395,42.87,82.8,30,0
+1
step
.xp <90,1
#completewith next
>>Kill |cRXP_ENEMY_Cultists|r
.complete 90553,1 
.mob Cultists
step
.xp <90,1
#arrowtext Click on the\n|cRXP_PICK_Objects|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Objects|r.
.complete 90554,1 
step
.xp <90,1
#label Cultists
>>Kill |cRXP_ENEMY_Cultists|r
.complete 90553,1 
.mob Cultists
step
.xp <90,1
.goto 2395,41.32,88.47
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r and |cRXP_FRIENDLY_Taelia Fordragon| |cRXP_WARN_next to you|r.
.turnin 90555 >>Turn in Blessing of Freedom
.turnin 90553 >>Turn in Executing the Blades
.turnin 90554 >>Turn in Leave Ashes in Your Wake
.accept 90556 >>Accept Cutting off the Head
.target Salandria
.target Taelia Fordragon
step
.xp <90,1
.goto 2395,41.32,88.47
>>Kill |cRXP_ENEMY_Overseer Mognak|r
.complete 90556,1 
.mob Overseer Mognak
step
.xp <90,1
.goto 2395,44.42,81.25
#title |cFFFCDC00Follow the Arrow|r
.complete 90556,2 
step
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
#label the Head
.goto 2395,44.41,81.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r |cRXP_WARN_next to you|r.
.turnin 90556 >>Turn in Cutting off the Head
.target Salandria
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bitter Honor
#internal
step
#optional
.isQuestAvailable account,86652
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#label BitterHonorA
#arrowtext Talk to\n|cRXP_FRIENDLY_Kel'vujo|r
.goto 2437,28.93,33.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kel'vujo|r.
.accept 93093 >>Accept Gnarldin Trophies
.target Kel'vujo
.accept 93094 >>Accept Scavenged Victory
step

#completewith next
>>Kill |cRXP_ENEMY_Scaly Scratcher|r and |cRXP_ENEMY_Bark Skullcracker|r
*Loot them for |T646679:0|t[|cRXP_LOOT_Chewed Remains|r].
.complete 93093,1 
.mob Scaly Scratcher
.mob Bark Skullcracker
.mob Bark Breaker
step
#loop
.goto 2437,27.57,35.06,12,0
.goto 2437,26.8,36.2,12,0
.goto 2437,28.1,36.98,12,0
.goto 2437,28.53,38.27,12,0
.goto 2437,28.97,36.42,12,0
.goto 2437,28.65,35.28,10,0
.goto 2437,28.41,35.04,12,0
#arrowtext Click on the\n|cRXP_PICK_Fallen Hunters|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fallen Hunters|r
.complete 93094,1 
step
#loop
.goto 2437,29.05,35.61,30,0
.goto 2437,29.06,33.58,30,0
.goto 2437,27.37,34.96,30,0
.goto 2437,27.14,38.63,30,0
.goto 2437,28.45,38.81,30,0
>>Kill |cRXP_ENEMY_Scaly Scratcher|r and |cRXP_ENEMY_Bark Skullcracker|r
*Loot them for |T646679:0|t[|cRXP_LOOT_Chewed Remains|r].
.complete 93093,1 
.mob Scaly Scratcher
.mob Bark Skullcracker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kel'vujo|r
.goto 2437,28.92,33.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kel'vujo|r.
.turnin 93094 >>Turn in Scavenged Victory
.turnin 93093 >>Turn in Gnarldin Trophies
.accept 93095 >>Accept Bitter Fury
.target Kel'vujo
step
#completewith next
#label Tusk Taker
#hidewindow
.goto 2437,26.28,37.41,10,0
.complete 93095,2 
step
.isOnQuest 93095
#completewith Tusk Taker
.goto 2437,25.87,37.41,60 >>Enter the Cave
step
#requires Tusk Taker
#completewith next
.goto 2437,25.62,37.49,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tusk|r |cRXP_WARN_if noone has yet|r.
.complete 93095,1 
step
#requires Tusk Taker
.goto 2437,26.06,37.51
>>Kill |cRXP_ENEMY_Tusk Taker|r and his minions.
.complete 93095,2 
.mob Tusk Taker
.mob Bark Breaker
.mob Bark Skullcracker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kel'vujo|r
.goto 2437,28.93,33.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kel'vujo|r.
.turnin 93095 >>Turn in Bitter Fury
.target Kel'vujo
.accept 93096 >>Accept Amani Honor
step
#completewith next
#arrowtext Talk to\n|cRXP_FRIENDLY_Kel'vujo|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kel'vujo|r |cRXP_WARN_if noone has yet|r.
.complete 93096,1 
.skipgossipid 138683
.skipgossipid 137658
.skipgossipid 137659
.skipgossip
.target Kel'vujo
step
#label BitterHonorY
.goto 2437,29.38,41.42
>>Damage |cRXP_ENEMY_Kel'vujo|r below 50%.
.complete 93096,2 
.mob Kel'vujo
step
#label BitterHonorZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Huntmaster Jinki|r
.goto 2437,44.26,66.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntmaster Jinki|r.
.turnin 93096 >>Turn in Amani Honor
.target Huntmaster Jinki
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Sawdust to Sawdust
#internal
step
#optional
.isQuestAvailable account,86652
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#label SawdustToSawdustA
.isOnQuest 88985
.goto 2437,28.37,27.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woodcrafter Azai|r.
.turnin 88985 >>Turn in Recuperating Returns
.target Woodcrafter Azai
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Woodcrafter Azai|r
.goto 2437,28.37,27.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woodcrafter Azai|r.
.accept 88986 >>Accept Blind the Bandits
.target Woodcrafter Azai
.accept 88987 >>Accept Salvaged Sabotage
step
#completewith next
>>Kill |cRXP_ENEMY_Twilight Cultists|r
*Use |T1003593:0|t[Lightwood Supplies] to stun them.
.complete 88986,2 
.use 238962
step
#loop
.goto 2437,28.64,28.35,10,0
.goto 2437,28.93,29.31,10,0
.goto 2437,28.95,29.75,10,0
.goto 2437,29.29,29.01,10,0
.goto 2437,29.29,28.37,10,0
#arrowtext Click on the\n|cRXP_PICK_Equipment|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Equipment|r
.complete 88987,1 
step
#label SawdustToSawdustB
#loop
.goto 2437,29.98,27.64,35,0
.goto 2437,29.95,29.32,35,0
.goto 2437,31.15,28.38,35,0
.goto 2437,30.44,27.1,35,0
.goto 2437,29.24,30.8,40,0
>>Kill |cRXP_ENEMY_Twilight Cultists|r.
*Use |T1003593:0|t[Lightwood Supplies] to stun them.
.complete 88986,2 
.use 238962
step
#label SawdustToSawdustC
#arrowtext Talk to\n|cRXP_FRIENDLY_Woodcrafter Azai|r
.goto 2437,28.44,27.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woodcrafter Azai|r.
.turnin 88986 >>Turn in Blind the Bandits
.target Woodcrafter Azai
.turnin 88987 >>Turn in Salvaged Sabotage
.accept 88988 >>Accept The Artisan's Apprentice
step
.goto 2437,28.58,27.60
#arrowtext Click on the\n|cRXP_PICK_Wood|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood|r.
.complete 88988,1 
step
.goto 2437,28.55,27.51
#arrowtext Click on the\n|cRXP_PICK_Wheel|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wheel|r.
.complete 88988,2 
step
.goto 2437,28.48,27.55
#arrowtext Click on the\n|cRXP_PICK_Javelin|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Javelin|r.
.complete 88988,3 
step
.goto 2437,28.48,27.55
>>Use the |T134789:0|t|cRXP_WARN_[ExtraActionButton]|r on the |cRXP_PICK_Javelin|r.
.complete 88988,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Woodcrafter Azai|r
.goto 2437,28.44,27.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woodcrafter Azai|r.
.turnin 88988 >>Turn in The Artisan's Apprentice
.target Woodcrafter Azai
.accept 88989 >>Accept Another One Bites the Sawdust
step
.goto 2437,28.44,27.51
#arrowtext Click on the\n|cRXP_PICK_Javelin|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Javelin|r.
.complete 88989,1 
step
.goto 2437,31.36,29.68,10,0
.goto 2437,31.74,29.84
>>Kill |cRXP_ENEMY_Covert Commander Tofir|r inside the cave.
*Use the |T1508065:0|t|cRXP_WARN_[ExtraActionButton]|r to stun him.
.complete 88989,3 
.use 241612
.mob Covert Commander Tofir
step
#completewith next
#label Another One Bites the Sawdust
#arrowtext Talk to\n|cRXP_FRIENDLY_Woodcrafter Azai|r
.goto 2437,31.42,29.71,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woodcrafter Azai|r.
.turnin 88989 >>Turn in Another One Bites the Sawdust
.target Woodcrafter Azai
step
.isOnQuest 88989
#completewith Another One Bites the Sawdust
.goto 2437,28.44,27.51,297 >>Leave the Cave
step
#requires Another One Bites the Sawdust
#label SawdustToSawdustZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Woodcrafter Azai|r
.goto 2437,28.44,27.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woodcrafter Azai|r.
.turnin 88989 >>Turn in Another One Bites the Sawdust
.target Woodcrafter Azai
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Venomous History
#internal
step
#label AVenomousHistoryA
#arrowtext Talk to\n|cRXP_FRIENDLY_Nija Torntusk|r
.goto 2437,36.10,24.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r.
.accept 91406 >>Accept Far from the Hinterlands
.target Nija Torntusk
step
.goto 2437,37.13,26.25
#arrowtext Click on the\n|cRXP_PICK_Spear|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r.
.complete 91406,1,1 
step
.goto 2437,38.08,24.11
#arrowtext Click on the\n|cRXP_PICK_Hammer|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hammer|r.
.complete 91406,1,2 
step
.goto 2437,37.13,23.48
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r |cRXP_WARN_on the second floor of the building|r.
.complete 91406,1,3 
step
#label SojournerHinterlands
#arrowtext Talk to\n|cRXP_FRIENDLY_Nija Torntusk|r
.goto 2437,36.09,24.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r.
.turnin 91406 >>Turn in Far from the Hinterlands
.target Nija Torntusk
.accept 91407 >>Accept The Eye of the Loa
step
.goto 2437,35.98,24.77
>>Stand within the circle and use the |T4667415:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 91407,1 
step
#loop
.goto 2437,35.95,25.37,15,0
.goto 2437,36.17,24.53,15,0
.goto 2437,37.21,23.39,15,0
.goto 2437,37.34,23.72,10,0
>>Fly and run into |cRXP_ENEMY_Spiders|r.
.complete 91407,2 
.mob Spying Spiderling
step
#label AVenomousHistoryAA
#arrowtext Talk to\n|cRXP_FRIENDLY_Nija Torntusk|r
.goto 2437,36.09,24.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r.
.turnin 91407 >>Turn in The Eye of the Loa
.target Nija Torntusk
.accept 91563 >>Accept Halazzi's Hunt
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r inside the temple.
.turnin 91563 >>Turn in Halazzi's Hunt
.target Loa Speaker Tobui
.accept 91403 >>Accept Probable Paralytic
.accept 91404 >>Accept A Most Vile Venom
step
#label AVenomousHistoryAB
#completewith next
.goto 2437,38.47,31.5,35,0
.goto 2437,38.94,34.13,35,0
.goto 2437,39.42,35.86,35,0
>>Kill |cRXP_ENEMY_Frogs|r
*Loot them for |T1418495:0|t[|cRXP_LOOT_Venomous Horn|r].
.complete 91403,1 
step
.goto 2437,40.3,35.74
>>Kill |cRXP_ENEMY_Venomhexxer Raxxis|r.
.complete 91404,1 
.mob Venomhexxer Raxxis
step
.goto 2437,40.42,36.04
#arrowtext Click on the\n|cRXP_PICK_Crate|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 91404,2 
step
#loop
.goto 2437,39.43,33.33,30,0
.goto 2437,38.08,33.67,30,0
.goto 2437,39.68,36.03,30,0
>>Kill |cRXP_ENEMY_Frogs|r
*Loot them for |T1418495:0|t[|cRXP_LOOT_Venomous Horn|r].
.complete 91403,1 
.mob Horned Frog
step
#label AVenomousHistoryProbable
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r.
.turnin 91403 >>Turn in Probable Paralytic
.target Loa Speaker Tobui
.turnin 91404 >>Turn in A Most Vile Venom
.accept 91405 >>Accept Validating the Venom
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chief Vun'zarah|r
.goto 2437,38.57,22.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Vun'zarah|r |cRXP_WARN_inside the building|r.
.complete 91405,1 
.skipgossipid 134561
.target Chief Vun'zarah
step
#completewith next
#label Mixer Jamanga
>>Move to the next Objective.
.complete 91405,2 
.target Mixer Jamanga
step
#completewith Mixer Jamanga
.goto 2437,37.18,23.46
.gossipoption 134564 >>Talk to |cRXP_FRIENDLY_Mixer Jamanga|r |cRXP_WARN_on the second floor of the building|r.
.timer 13.5,RP
step
#requires Mixer Jamanga
.goto 2437,36.56,24.72
#arrowtext Don't move \n beyond the arrow.
>>Move to the next Objective and wait for the roleplay.
.complete 91405,2 
.target Mixer Jamanga
step
#requires Mixer Jamanga
#arrowtext Talk to\n|cRXP_FRIENDLY_Daki|r
.goto 2437,36.26,25.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daki|r
.complete 91405,3 
.skipgossipid 136586
.target Daki
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nija Torntusk|r
.goto 2437,36.09,24.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r.
.turnin 91405 >>Turn in Validating the Venom
.target Nija Torntusk
.accept 91408 >>Accept Seeking Shadra
step
.goto 2437,39.7,23.12,10,0
.goto 2583,74.57,79.72
>>Enter the Temple
.complete 91408,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Mixer Jamanga|r
.goto 2437,39.14,22.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mixer Jamanga|r.
.complete 91408,2 
.skipgossipid 134622
.target Mixer Jamanga
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nija Torntusk|r and |cRXP_FRIENDLY_Mixer Jamanga|r
.goto 2437,39.14,22.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r and |cRXP_FRIENDLY_Mixer Jamanga|r.
.turnin 91408 >>Turn in Seeking Shadra
.accept 91630 >>Accept Stolen Sight
.target Nija Torntusk
.target Mixer Jamanga
step
#completewith next
#label Venomhexxer Iki
.goto 2583,64.63,51.8,8,0
>>Kill |cRXP_ENEMY_Venomhexxer Iki|r.
*Loot him for |T3528296:0|t[|cRXP_LOOT_Eye of Shadra|r].
.complete 91630,1 
.mob Venomhexxer Iki
step
#completewith Venomhexxer Iki
.goto 2583,50.91,30.89,50 >>Follow the Arrow
step
#requires Venomhexxer Iki
.goto 2583,50.91,30.89
>>Kill |cRXP_ENEMY_Venomhexxer Iki|r.
*Loot him for |T3528296:0|t[|cRXP_LOOT_Eye of Shadra|r].
.complete 91630,1 
.mob Venomhexxer Iki
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Mixer Jamanga|r
.goto 2437,39.14,22.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mixer Jamanga|r.
.turnin 91630 >>Turn in Stolen Sight
.target Mixer Jamanga
.accept 91409 >>Accept Dreaming of Spiders
step
#completewith next
#label Fang of Shadra
.goto 2583,49.74,76.87,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fang|r.
.complete 91409,1 
step
#completewith Fang of Shadra
.goto 2437,38.50,22.52,40 >>Follow the Arrow
step
#requires Fang of Shadra
.goto 2437,38.50,22.52
#arrowtext Click on the\n|cRXP_PICK_Fang|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fang|r.
.complete 91409,1 
step
.goto 2437,38.58,22.40
#arrowtext Click on the\n|cRXP_PICK_Eye|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eye|r
.complete 91409,2 
.timer 6.5,RP
step
#label AVenomousHistoryB
#arrowtext Talk to\n|cRXP_FRIENDLY_Mixer Jamanga|r and |cRXP_FRIENDLY_Nija Torntusk|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mixer Jamanga|r and |cRXP_FRIENDLY_Nija Torntusk|r |cRXP_WARN_after the roleplay|r.
.turnin 91409 >>Turn in Dreaming of Spiders
.goto 2437,38.66,22.72
.target +Mixer Jamanga
.accept 91411 >>Accept Maisara Caverns: Deep in Maisara
.goto 2583,46.49,71.85
.target Nija Torntusk
step
.isOnQuest 91411
.enterScenario 3127 >>Queue for the dungeon Maisara Caverns|cRXP_WARN_(any difficulty, not m+)|r.
.macro Queue Follower Dungeon,1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3101, true); LFGEnabledList[3101] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
#completewith Vordaza
+|cRXP_WARN_The Arrow cannot be displayed here; coordinates are unavailable|r.
step
.isInScenario 3127
>>Free 8 Prisoners to unlock the first boss.
.scenario 15977,1 
step
#label Vordaza
.isInScenario 3127
>>Kill |cRXP_ENEMY_Vordaza|r
*Loot him for |T134321:0|t[|cRXP_LOOT_Shell of Shadra|r].
.complete 91411,1 
step
#label SojournerDeep
#title|cFFFCDC00Leave or finish dungeon|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r and |cRXP_FRIENDLY_Mixer Jamanga|r |cRXP_WARN_outside the dungeon|r.
.turnin 91411 >>Turn in Deep in Maisara
.goto 2437,38.76,22.72
.target Nija Torntusk
.accept 91412 >>Accept Return of the Venom Queen
.goto 2583,43.05,71.92
.target Mixer Jamanga
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#label Shadra Ritual
.goto 2437,38.64,22.60
>>Stand within the circle and use the |T5764932:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 91412,1 
step
.goto 2437,38.59,22.53
#arrowtext Click on the\n|cRXP_PICK_Egg|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r.
.complete 91412,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nija Torntusk|r and |cRXP_FRIENDLY_Mixer Jamanga|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r and |cRXP_FRIENDLY_Mixer Jamanga|r.
.turnin 91412 >>Turn in Return of the Venom Queen
.goto 2437,38.76,22.72
.target Nija Torntusk
.accept 91410 >>Accept Shared Loa
.goto 2583,43.05,71.92
.target Mixer Jamanga
step
#completewith next
#label Shared Loa
#arrowtext Talk to\n|cRXP_FRIENDLY_Vun'zarah|r
.goto 2583,51.45,75.63,15,0
.goto 2583,61.34,63.68,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vun'zarah|r.
.turnin 91410 >>Turn in Shared Loa
.target Vun'zarah
step
#completewith Shared Loa
.goto 2437,39.69,23.11,8 >>Leave the Temple
step
#label AVenomousHistoryZ
#requires Shared Loa
#arrowtext Talk to\n|cRXP_FRIENDLY_Vun'zarah|r
.goto 2437,38.72,22.62,5,0
.goto 2437,38.57,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vun'zarah|r.
.turnin 91410 >>Turn in Shared Loa
.target Vun'zarah
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Sound of Her Voice
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nerunda|r
.goto 2437,36.78,25.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r |cRXP_WARN_inside the house|r.
.accept 93178 >>Accept A Quiet Walk Interrupted
.target Nerunda
step
#label SojournerVoice
#arrowtext Talk to\n|cRXP_FRIENDLY_Haz'kel|r
.goto 2437,38.37,26.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haz'kel|r.
.complete 93178,1 
.skipgossipid 137297
.target Haz'kel
step
.goto 2437,41.49,31.62
#title |cFFFCDC00Follow the Arrow|r
.complete 93178,2 
step
.goto 2437,41.49,31.62
#arrowtext Click on the\n|cRXP_PICK_Dagger|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dagger|r.
.complete 93178,3 
step
#label SojournerNerunda
.goto 2437,43.20,32.44
#arrowtext Click on the\n|cRXP_PICK_Basket|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket|r.
.complete 93178,4 
step
.goto 2437,45.83,33.96
#arrowtext Click on the\n|cRXP_PICK_Teapot|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Teapot|r.
.complete 93178,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nerunda|r
.goto 2437,36.78,25.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r.
.turnin 93178 >>Turn in A Quiet Walk Interrupted
.target Nerunda
.accept 93179 >>Accept Child-like Devotion
step
#label SojournerKanza
#arrowtext Talk to\n|cRXP_FRIENDLY_Kanza|r
.goto 2437,52.30,32.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kanza|r.
.complete 93179,2 
.skipgossipid 137771
.target Kanza
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kanza|r
.goto 2437,52.30,32.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kanza|r.
.turnin 93179 >>Turn in Child-like Devotion
.target Kanza
.accept 93180 >>Accept Shrine Preparations
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kanza|r
.goto 2437,50.77,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kanza|r.
.complete 93180,1 
.skipgossipid 137820
.target Kanza
step
#label SojournerKanza2
#arrowtext Talk to\n|cRXP_FRIENDLY_Kanza|r
.goto 2437,51.45,30.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kanza|r.
.complete 93180,2 
.skipgossipid 137830
.target Kanza
step
#hidewindow
#completewith ThornCapsZ
#loop
.goto 2437,51.34,30.51,10,0
.goto 2437,51.95,30.64,10,0
.goto 2437,52.18,30.96,10,0
.goto 2437,52.96,30.21,25,0
.goto 2437,51.72,29.7,30,0
.goto 2437,50.74,29.7,30,0
.goto 2437,50.04,31.35,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Stinger Matriarch|r and |cRXP_ENEMY_Stinger Hatchling|r.
.complete 93180,4 
.complete 93180,3 
.mob Stinger Hatchling
.mob Stinger Matriarch
step
#arrowtext Click on the\n|cRXP_PICK_Mushroom|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushroom|r
.complete 93180,5 
step
#label ThornCapsZ
>>Kill |cRXP_ENEMY_Stinger Matriarch|r and |cRXP_ENEMY_Stinger Hatchling|r.
.complete 93180,4 
.complete 93180,3 
.mob Stinger Hatchling
.mob Stinger Matriarch
step
#label SojournerShrine
#arrowtext Talk to\n|cRXP_FRIENDLY_Kanza|r
.goto 2437,51.45,30.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kanza|r.
.turnin 93180 >>Turn in Shrine Preparations
.accept 93181 >>Accept Temple and a Teapot
.target Kanza
step
#label SojournerHonnu
#arrowtext Talk to\n|cRXP_FRIENDLY_Honnu|r
.goto 2437,47.18,24.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honnu|r.
.complete 93181,1 
.buy 265401,1
.target Honnu
step
#label SojournerCampaignKanza
#arrowtext Talk to\n|cRXP_FRIENDLY_Kanza|r
.goto 2437,52.33,32.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kanza|r.
.complete 93181,2 
.skipgossipid 137968
.target Kanza
step
.goto 2437,52.29,32.06
#arrowtext Click on the\n|cRXP_PICK_Teapot|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Teapot|r.
.complete 93181,3 
step
#label SojournerTeapot
#arrowtext Talk to\n|cRXP_FRIENDLY_Kanza|r
.goto 2437,52.34,32.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kanza|r.
.turnin 93181 >>Turn in Temple and a Teapot
.target Kanza
.accept 93182 >>Accept Healing Homeward
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nerunda|r
.goto 2437,36.61,25.22,10,0
.goto 2437,36.73,25.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r.
*|cRXP_WARN_If she isn't there, try joining a Zul'Aman quest group; it may make her appear|r.
.turnin 93182 >>Turn in Healing Homeward
.target Nerunda
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Unlikely Friends
#internal
step
#optional
.isQuestAvailable account,86652,86657
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Path of de Hash'ey (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Path of de Hash'ey (H) >>CLICK HERE FOR GUIDE << Horde
step
#label UnlikelyFriendsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Zel'kanra|r
.goto 2437,44.17,33.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Zel'kanra|r.
.accept 93667 >>Accept Camp Stonewash
.target Scout Zel'kanra
step
#label UnlikelyFriendsB
#arrowtext Talk to\n|cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 93667 >>Turn in Camp Stonewash
.accept 90481 >>Accept I Have a Permit
.target Seeker Crikkash
.target Amaxi
step
#label UnlikelyFriendsC
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Ren'zen|r
.goto 2437,38.30,20.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Ren'zen|r.
.complete 90481,1 
.skipgossipid 133102
.skipgossipid 133101
.target Elder Ren'zen
step
#label UnlikelyFriendsD
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r
.turnin 90481 >>Turn in I Have a Permit
.timer 25,RP
.target Seeker Crikkash
step
#label Sightseeing Stegadon1
#arrowtext Talk to\n|cRXP_FRIENDLY_Trishe|r
.goto 2437,47.27,26.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trishe|r |cRXP_WARN_after the roleplay|r.
.accept 90484 >>Accept Sightseeing Stegadon
.target Trishe
step
.goto 2437,45.43,23.82
>>Kill |cRXP_ENEMY_Hidegorger the Everburning|r.
.complete 90484,1 
.mob Hidegorger the Everburning
step
.goto 2437,45.36,23.95
#arrowtext Click on\n|cRXP_PICK_Steggy|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Steggy|r
.complete 90484,2 
.target Steggy
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Trishe|r
.goto 2437,47.28,26.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trishe|r.
.turnin 90484 >>Turn in Sightseeing Stegadon
.target Trishe
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amaxi|r
.goto 2437,47.17,24.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r.
.accept 90482 >>Accept Cuisine Connection
.target Amaxi
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,47.26,24.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r.
.accept 90483 >>Accept A Witherbark Story
.target Seeker Crikkash
.accept 90485 >>Accept Afterthought Artifacts
step
#label UnlikelyFriendsE
#loop
.goto 2437,47.09,24.77,30,0
.goto 2437,47.7,24.5,30,0
.goto 2437,47.59,25.4,30,0
.goto 2437,47.9,25.92,30,0
.goto 2437,47.24,26.12,30,0
#arrowtext Talk to\n|cRXP_FRIENDLY_Witherbark Visitor|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witherbark Visitor|r and kill them.
.complete 90483,1 
.target Witherbark Visitor
.mob Witherbark Visitor
.skipgossipid 133188
step
#completewith Old Amani Pot
>>Kill |cRXP_ENEMY_Eels|r
*Loot them for |T237414:0|t[|cRXP_LOOT_Zapgut Eel Stomach|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Depthsroot|r for a swimspeed buff.
.complete 90482,2 
.mob Zapgut Lunker
.mob Zapgut Eel
step
#completewith Old Amani Pot
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kelp|r
.complete 90482,3 
step
.goto 2437,48.37,28.34
#arrowtext Click on the\n|cRXP_PICK_Shovel|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shovel|r.
.complete 90485,2 
step
.goto 2437,49.53,27.75
#arrowtext Click on the\n|cRXP_PICK_Trinket|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trinket|r.
.complete 90485,3 
step
.goto 2437,48.91,28.39
#arrowtext Click on the\n|cRXP_PICK_Stick|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stick|r.
.complete 90485,1 
step
.goto 2437,48.65,28.67
#arrowtext Click on the\n|cRXP_PICK_Rubble|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r.
.complete 90485,4 
step
#label Old Amani Pot
.goto 2437,48.66,28.69
#arrowtext Click on the\n|cRXP_PICK_Pot|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pot|r.
.complete 90485,5 
step
#hidewindow
#completewith Zapgut Eel Stomach
#loop
.goto 2437,48.35,29.39,25,0
.goto 2437,47.97,28.46,30,0
.goto 2437,48.87,26.08,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Eels|r
*Loot them for |T237414:0|t[|cRXP_LOOT_Zapgut Eel Stomach|r].
*|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Depthsroot|r for a swimspeed buff.
.complete 90482,2 
.mob Zapgut Lunker
.mob Zapgut Eel
step
#arrowtext Click on the\n|cRXP_PICK_Kelp|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Kelp|r
.complete 90482,3 
step
#label Zapgut Eel Stomach
>>Kill |cRXP_ENEMY_Eels|r
*Loot them for |T237414:0|t[|cRXP_LOOT_Zapgut Eel Stomach|r].
.complete 90482,2 
.mob Zapgut Lunker
.mob Zapgut Eel
step
#label SojournerStegadon
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,47.26,24.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 90483 >>Turn in A Witherbark Story
.target Seeker Crikkash
.turnin 90485 >>Turn in Afterthought Artifacts
step
#label SojournerConnection
#arrowtext Talk to\n|cRXP_FRIENDLY_Amaxi|r
.goto 2437,47.16,24.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r.
.turnin 90482 >>Turn in Cuisine Connection
.target Amaxi
.accept 90486 >>Accept Dangerous Delicacies
step
#label SojournerPrepped
.goto 2437,47.10,24.51
#arrowtext Click on the\n|cRXP_PICK_Fish|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fish|r
.complete 90486,1 
step
.goto 2437,47.04,24.63
#arrowtext Jump on Kelp
>>Jump on the Kelp
.complete 90486,2 
step
.goto 2437,47.14,24.79
#arrowtext Click on the\n|cRXP_PICK_Boars|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boars|r
.complete 90486,3 
.target Prepared Saltleaf Boar
step
.goto 2437,47.14,24.68
#arrowtext Click on the\n|cRXP_PICK_Skewer|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Skewer|r
.complete 90486,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gushu|r
.goto 2437,47.14,24.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gushu|r.
.turnin 90486 >>Turn in Dangerous Delicacies
.target Gushu
step
#label SojournerDelicacies
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,47.25,24.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r.
.accept 90568 >>Accept Unlikely Friends
.target Seeker Crikkash
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Ren'zen|r
.goto 2437,38.30,20.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Ren'zen|r.
.turnin 90568 >>Turn in Unlikely Friends
.target Elder Ren'zen
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Loa of Murlocs
#internal
step
.isOnQuest 92163
.goto 2437,52.88,60.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r.
.turnin 92163 >>Turn in The Loa of Murlocs
.target King Mrgl-Mrgl
step
#arrowtext Talk to\n|cRXP_FRIENDLY_King Mrgl-Mrgl|r
#label TheLoaOfMurlocsA
.goto 2437,52.88,60.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r.
.accept 92164 >>Accept Murloc Madness
.target King Mrgl-Mrgl
.accept 92165 >>Accept Fish Are Food, Not Friends
.accept 92166 >>Accept Following Suit
step
#completewith AssistantGrglGrglSavedA
>>Kill |cRXP_ENEMY_Murlocs|r.
.complete 92164,1 
.mob Deepfin Snatcher
.mob Deepfin Invader
.mob Deepfin Necromancer
step
#arrowtext Lynxfish (3/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,52.11,60.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,3 
step
#arrowtext Lynxfish (6/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,51.9,60.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,6 
step
#arrowtext Click on the |cRXP_PICK_Bag|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,50.54,62.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r.
.complete 92166,1 
.skipgossipid 137476
step
#arrowtext Lynxfish (9/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,49.96,61.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,9 
step
#arrowtext Lynxfish (12/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,49.95,61.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,12 
step
#arrowtext Click on the |cRXP_PICK_Paper|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,49.85,59.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Papers|r.
.complete 92166,2 
.skipgossipid 137477
step
#arrowtext Lynxfish (18/30)\n|cFFFCDC00(Read Note)|r
.goto 2437,49.87,59.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,18 
step
#arrowtext Lynxfish (21/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,48.65,59.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,21 
step
#arrowtext Lynxfish (24/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,48.92,59.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,24 
step
#arrowtext Lynxfish (27/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,48.59,59.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,27 
step
#arrowtext Lynxfish (30/30)\n|cFFFCDC00(Read Note)|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,48.6,58.5
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spike|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 92165,1,30 
step
.goto 2437,47.81,56.2
#title |cFFFCDC00Follow the Arrow|r
.complete 92166,3 
step
#label AssistantGrglGrglSavedA
#arrowtext Talk to |cRXP_FRIENDLY_Assistant Grgl-Grgl|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,47.81,56.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Assistant Grgl-Grgl|r.
.complete 92166,4 
.skipgossipid 137485
.target Assistant Grgl-Grgl
step
#loop
.goto 2437,47.5,57.35,30,0
.goto 2437,49.44,56.16,30,0
.goto 2437,50.87,58.94,30,0
.goto 2437,52.87,58.98,30,0
.goto 2437,51.36,63.03,30,0
>>Kill |cRXP_ENEMY_Murlocs|r.
.complete 92164,1 
.mob Deepfin Snatcher
.mob Deepfin Invader
.mob Deepfin Necromancer
step
#arrowtext Talk to\n|cRXP_FRIENDLY_King Mrgl-Mrgl|r and |cRXP_FRIENDLY_Assistant Grgl-Grgl|r
.goto 2437,52.92,60.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r and |cRXP_FRIENDLY_Assistant Grgl-Grgl|r.
.turnin 92164 >>Turn in Murloc Madness
.turnin 92165 >>Turn in Fish Are Food, Not Friends
.turnin 92166 >>Turn in Following Suit
.accept 92167 >>Accept There Can Be Only One
.target King Mrgl-Mrgl
.target Assistant Grgl-Grgl
step
.goto 2437,56.99,59.73
>>Use |T134169:0|t[Spare Murloc Suit]
.complete 92167,1 
.use 263446
step
#completewith DeepfinLeaderA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fish|r |cRXP_WARN_if noone has yet|r.
.complete 92167,2 
.use 263446
step
#completewith next
#label Deepfin leader
#arrowtext |cRXP_ENEMY_DON'T FLY DIRECTLY\nINTO THE WATER|r
.goto 2437,56.99,59.73,30,0
>>Kill |cRXP_ENEMY_Lightwalker|r.
.complete 92167,3 
.mob Deepfin leader
step
.isOnQuest 92167
#completewith Deepfin leader
#arrowtext |cRXP_ENEMY_DON'T FLY DIRECTLY\nINTO THE WATER|r
.goto 2437,57.41,59.64,30 >>Beneath the Water
step
#requires Deepfin leader
#label DeepfinLeaderA
.goto 2437,57.41,59.65,15,0
.goto 2437,57.17,59.68
>>Kill |cRXP_ENEMY_Lightwalker|r.
.complete 92167,3 
.mob Lightwalker
step
#label TheLoaOfMurlocsZ
#arrowtext Talk to\n|cRXP_FRIENDLY_King Mrgl-Mrgl|r
.goto 2437,52.89,60.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r.
.turnin 92167 >>Turn in There Can Be Only One
.target King Mrgl-Mrgl
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Vengeance for Tolbani
#internal
step
#optional
.isQuestAvailable account,86652
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#label VengeanceForTolbaniA
#arrowtext Talk to\n|cRXP_FRIENDLY_Vakala|r
.goto 2437,45.05,68.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vakala|r.
.accept 94867 >>Accept Lost in Atal'Abasi
.target Vakala
step
#label SojournerCampaignMenace
#arrowtext Talk to\n|cRXP_FRIENDLY_Jehnira|r
.goto 2437,53.12,62.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jehnira|r.
.turnin -94867 >>Turn in Lost in Atal'Abasi
.target Jehnira
.accept 91069 >>Accept Vengeance for Tolbani
.accept 91070 >>Accept Reclaim the Goods
.accept 91071 >>Accept The Menace of Atal'Abasi
step
#label SojournerMenance
#completewith Food ProvisionsZ
>>Kill |cRXP_ENEMY_Murlocs|r.
.complete 91069,1 
.mob Bogfin Tidechanter
.mob Murloc Fistfin
.mob Murloc Dredgecaller
.mob Murloc Behemoth
.mob Murloc Reefstalker
.mob Murloc Scaleguard
step
#arrowtext Provisions collected (1/6)\n|cFFFCDC00(Read Note)|r\n|cRXP_WARN_Good spot for Murlocs|r.
.goto 2437,53.99,66.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91070,1,1 
step
#completewith next
#label Mrruk the Musclefin
>>Kill |cRXP_ENEMY_Mrruk the Musclefin|r.
.complete 91071,1 
.mob Mrruk the Musclefin
step
.isOnQuest 91071
#completewith Mrruk the Musclefin
#arrowtext |cRXP_ENEMY_Mrruk the Musclefin|r
.goto 2437,52.35,65.95,10 >>Inside a small opening
step
#requires Mrruk the Musclefin
#arrowtext Kill |cRXP_ENEMY_Mrruk the Musclefin|r
.goto 2437,52.35,65.95
>>Kill |cRXP_ENEMY_Mrruk the Musclefin|r.
.complete 91071,1 
.mob Mrruk the Musclefin
step
#arrowtext Provisions collected (2/6)\n|cFFFCDC00(Read Note)|r
.goto 2437,50.3,66.6
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r |cRXP_WARN_on a tree stump|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91070,1,2 
step
#label VengeanceForTolbaniB
#arrowtext Provisions collected (3/6)\n|cFFFCDC00(Read Note)|r
.goto 2437,48.44,67.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r |cRXP_WARN_on a tree stump|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91070,1,3 
step
#label VengeanceForTolbaniC
#arrowtext Provisions collected (4/6)\n|cFFFCDC00(Read Note)|r\n|cRXP_WARN_on a rock|r
.goto 2437,48.8,64.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r |cRXP_WARN_on a rock|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91070,1,4 
step
#label Food ProvisionsZ
#arrowtext Provisions collected (6/6)\n|cFFFCDC00(Read Note)|r
#loop
.goto 2437,50.55,64.38,10,0
.goto 2437,52.58,62.28,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r |cRXP_WARN_in the Water|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91070,1 
step
#loop
.goto 2437,52.58,65.48,30,0
.goto 2437,54.47,66.15,30,0
.goto 2437,49.38,64.14,30,0
>>Kill |cRXP_ENEMY_Murlocs|r.
.complete 91069,1 
.mob Bogfin Tidechanter
.mob Murloc Fistfin
.mob Murloc Dredgecaller
.mob Murloc Behemoth
.mob Murloc Reefstalker
.mob Murloc Scaleguard
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jehnira|r
.goto 2437,53.12,62.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jehnira|r.
.turnin 91070 >>Turn in Reclaim the Goods
.turnin 91071 >>Turn in The Menace of Atal'Abasi
.turnin 91069 >>Turn in Vengeance for Tolbani
.accept 91556 >>Accept Loa's Flame
.target Jehnira
step
.goto 2437,53.08,62.74
#arrowtext Click on the\n|cRXP_PICK_Boat|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boat|r
.complete 91556,1 
step
.goto 2437,53.08,62.74
#arrowtext Click on the\n|cRXP_PICK_Bonfire|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boat|r
.complete 91556,2 
step
#label VengeanceForTolbaniZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Jehnira|r
.goto 2437,53.13,62.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jehnira|r.
.turnin 91556 >>Turn in Loa's Flame
.target Jehnira
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Between Two Trolls
#internal
step
#optional
.isQuestAvailable 86693
+|cRXP_WARN_You have to do the "De Amani Never Die" Chapter first|r
.clicknext RestedXP Midnight\a) De Amani Never Die (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) De Amani Never Die (H) >>CLICK HERE FOR GUIDE << Horde
step
#label BetweenTwoTrollsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Kagara|r
.goto 2437,44.04,66.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kagara|r.
.accept 89230 >>Accept A Lover Not a Fighter
.target Kagara
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zak'kash|r
.goto 2437,43.89,65.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zak'kash|r.
.accept 89231 >>Accept A Fighter Not a Lover
.target Zak'kash
step
#label SojournerEagle
#completewith next
>>Kill |cRXP_ENEMY_Gnarldins|r.
*Loot them for |T1535070:0|t[|cRXP_LOOT_Threshadon Tooth Necklace|r].
.complete 89230,1 
.mob Gnarldin Nestcrusher
.mob Gnarldin Clubfist
step
#loop
.goto 2437,52.27,71.3,12,0
.goto 2437,52.48,70.75,12,0
.goto 2437,53.21,70.76,12,0
.goto 2437,53.32,69.84,12,0
.goto 2437,54.06,71.25,12,0
.goto 2437,54.56,72.39,12,0
.goto 2437,54,72.48,12,0
.goto 2437,53.32,71.87,12,0
#arrowtext Click on the\n|cRXP_PICK_Feather|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feather|r
.complete 89231,1 
step
#loop
.goto 2437,52.05,71.02,30,0
.goto 2437,53.4,70.15,30,0
.goto 2437,54.73,70.31,30,0
.goto 2437,55.65,72.87,30,0
.goto 2437,55.01,74.64,30,0
>>Kill |cRXP_ENEMY_Gnarldins|r.
*Loot them for |T1535070:0|t[|cRXP_LOOT_Threshadon Tooth Necklace|r].
.complete 89230,1 
.mob Gnarldin Nestcrusher
.mob Gnarldin Clubfist
step
#label SojournerHeaddress
.goto 2437,44.44,65.74
>>Use |T2103839:0|t[Eagle Feather]
.complete 89231,2 
.use 249231
step
#label BetweenTwoTrollsB
#arrowtext Talk to\n|cRXP_FRIENDLY_Namaji|r
.goto 2437,44.44,65.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Namaji|r.
.turnin 89231 >>Turn in A Fighter Not a Lover
.turnin 89230 >>Turn in A Lover Not a Fighter
.accept 89233 >>Accept Love Triangle
.target Namaji
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Namaji|r
.goto 2437,44.44,65.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Namaji|r select a partner.
.complete 89233,1 
.target Namaji
.skipgossipid 135137
step
#label BetweenTwoTrollsZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Namaji|r
.goto 2437,44.44,65.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Namaji|r.
.turnin 89233 >>Turn in Love Triangle
.target Namaji
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Healing the Spirit
#internal
step
#optional
.isQuestAvailable 86693
+|cRXP_WARN_You have to do the "De Amani Never Die" Chapter first|r
.clicknext RestedXP Midnight\a) De Amani Never Die (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) De Amani Never Die (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Doru|r
.goto 2437,43.12,67.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.accept 91206 >>Accept Loa Disturbance
.target Elder Doru
step
#label SojournerCurseCleanse
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Sij'ta|r
.goto 2437,40.46,49.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Sij'ta|r |cRXP_WARN_inside the cave|r.
.turnin 91206 >>Turn in Loa Disturbance
.target Loa Speaker Sij'ta
.accept 87254 >>Accept Curse Cleanse
.accept 87256 >>Accept Alternative Medicine
step
#hidewindow
#completewith Pango
#loop
.goto 2437,40.53,50,10,0
.goto 2437,39.33,47.78,30,0
.goto 2437,39.35,46.24,30,0
.goto 2437,38.95,47.81,30,0
.goto 2437,37.9,47.5,30,0
.goto 2437,39.23,50.58,30,0
.goto 2437,40.38,51.09,30,0
.goto 2437,39.48,53.59,30,0
.goto 2536,76.38,28.14,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Pangos|r
*Loot them for |T4672178:0|t[|cRXP_LOOT_Large Pango Liver|r].
.complete 87254,1 
.mob Shrine Pango
.mob Pango Matriarch
step
.goto 2437,40.19,51.74
#arrowtext Click on\n|cRXP_PICK_Bushes|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Bushes|r.
.complete 87256,1 
step
#label Pango
>>Kill |cRXP_ENEMY_Pangos|r
*Loot them for |T4672178:0|t[|cRXP_LOOT_Large Pango Liver|r].
.complete 87254,1 
.mob Shrine Pango
.mob Pango Matriarch
step
#completewith next
#label Warlord Akutu
#arrowtext Talk to\n|cRXP_FRIENDLY_Warlord Akutu|r
.goto 2437,40.53,49.86,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Akutu|r.
.complete 87254,2 
.mob Warlord Akutu
step
.isOnQuest 87254
#completewith Warlord Akutu
.goto 2437,40.45,49.31,30 >>Enter the Cave
step
#requires Warlord Akutu
#arrowtext Talk to\n|cRXP_FRIENDLY_Warlord Akutu|r
.goto 2437,40.45,49.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Akutu|r.
.complete 87254,2 
.skipgossipid 134247
.mob Warlord Akutu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Sij'ta|r
.goto 2437,40.46,49.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Sij'ta|r.
.turnin 87254 >>Turn in Curse Cleanse
.target Loa Speaker Sij'ta
.turnin 87256 >>Turn in Alternative Medicine
.accept 87267 >>Accept Demands Unmet
step
#completewith next
#label Burn incense to summon Kulzi
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r
.complete 87267,1 
step
.isOnQuest 87267
#completewith Burn incense to summon Kulzi
.goto 2437,40.51,49.96,10 >>Leave the Cave
step
#requires Burn incense to summon Kulzi
.goto 2437,38.92,44.81
#arrowtext Click on the\n|cRXP_PICK_Incense|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r
.complete 87267,1 
.timer 7.3,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kulzi|r
.goto 2437,38.79,44.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kulzi|r.
.complete 87267,2 
.skipgossipid 134375
.target Kulzi
step
.goto 2437,39.41,44.88
#arrowtext Click on the\n|cRXP_PICK_Staff|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Staff|r
.complete 87267,3 
step
#completewith next
#label Demands Unmet
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Sij'ta|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Sij'ta|r.
.turnin 87267 >>Turn in Demands Unmet
.target Loa Speaker Sij'ta
.accept 87268 >>Accept Required Repentance
.disablecheckbox
step
.isOnQuest 87267
#completewith Demands Unmet
.goto 2437,40.53,49.89,5 >>Enter the Cave
step
#requires Demands Unmet
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Sij'ta|r
.goto 2437,40.46,49.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Sij'ta|r.
.turnin 87267 >>Turn in Demands Unmet
.target Loa Speaker Sij'ta
.accept 87268 >>Accept Required Repentance
step
#loop
.goto 2437,40.45,51.35,30,0
.goto 2437,40.94,51.39,30,0
.goto 2437,40.8,49.19,30,0
.goto 2437,40.55,47.02,30,0
.goto 2437,39.59,44.9,30,0
#arrowtext Click on the\n|cRXP_PICK_Forgetful Ghost|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forgetful Ghost|r and kill them.
.complete 87268,1 
.target Forgetful Ghost
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Sij'ta|r
.goto 2437,40.47,49.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Sij'ta|r |cRXP_WARN_inside the cave|r.
.turnin 87268 >>Turn in Required Repentance
.target Loa Speaker Sij'ta
.accept 87317 >>Accept Denial Denied
step
.goto 2437,40.45,49.31
#arrowtext Click on the\n|cRXP_PICK_Warlord Akutu|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Warlord Akutu|r.
.complete 87317,1 
.mob Warlord Akutu
step
#completewith next
#label Find Warlord Akutu
#hidewindow
.complete 87317,2 
step
.isOnQuest 87317
#completewith Find Warlord Akutu
.goto 2437,40.52,49.95,5 >>Leave the Cave
step
#requires Find Warlord Akutu
.goto 2437,38.93,44.76
#title |cFFFCDC00Follow the Arrow|r
.complete 87317,2 
.timer 21.5,RP
step
#label SojournerMedicineCampaign0
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Sij'ta|r
.goto 2437,38.92,44.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Sij'ta|r.
.complete 87317,3 
.timer 24,RP
.skipgossipid 135825
.mob Loa Speaker Sij'ta
step
#label SojournerMedicine0
#arrowtext Talk to\n|cRXP_FRIENDLY_Warlord Akutu|r and |cRXP_FRIENDLY_Kulzi|r
.goto 2437,38.82,44.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Akutu|r and |cRXP_FRIENDLY_Kulzi|r.
.turnin 87317 >>Turn in Denial Denied
.accept 92531 >>Accept The Medicine Loa's Shrine
.target Warlord Akutu
.target Kulzi
step
#label SojournerMedicine
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Doru|r
.goto 2437,43.12,67.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.turnin 92531 >>Turn in The Medicine Loa's Shrine
.target Elder Doru
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Beyond the Walls
#internal
step
#optional
.isQuestAvailable account,86652
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#include a) The Final Exam
step
#include a) Altar History@SojournerAltarHistory1-AltarLoa
step
#include a) Blessings of the Loa
step
#include a) Altar History@AltarLoa2-SojournerAltarHistory2
step
#include a) Butchery Basics
step
#include a) Homework Support
step
#include a) Got No Rhythm
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Butchery Basics
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.58,69.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r
.accept 93047 >>Accept Butchery Basics
.target Gijaniji
step
#loop
.goto 2437,46.27,72.15,35,0
.goto 2437,47.1,73.67,35,0
.goto 2437,46.49,75.39,35,0
.goto 2437,45.26,74.18,35,0
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
.goto 2437,45.54,69.52
#arrowtext Click on the\n|cRXP_PICK_Boar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boar|r.
.complete 93047,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.58,69.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r
.turnin 93047 >>Turn in Butchery Basics
.target Gijaniji
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Got No Rhythm
#internal
step
#label SojournerRhythm
#arrowtext Talk to\n|cRXP_FRIENDLY_Iklani|r
.goto 2437,46.79,66.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iklani|r
.accept 93048 >>Accept Got No Rhythm
.target Iklani
step
#completewith next
#label how to dance for Kovu
.goto 2437,46.76,66.79,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kovu|r
.complete 93048,1 
.target Kovu
step
#completewith how to dance for Kovu
.goto 2437,46.88,66.75,12 >>Leave the Hut
step
#requires how to dance for Kovu
.goto 2437,46.88,66.75
#arrowtext Click on\n|cRXP_PICK_Kovu|r\n|cRXP_WARN_while inside the circle|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kovu|r.
*If it doesn't work /dance at |cRXP_FRIENDLY_Kovu|r
.complete 93048,1 
.emote DANCE,257807
.target Kovu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kovu|r
.goto 2437,46.88,66.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kovu|r
.complete 93048,2 
.skipgossipid 137451
.target Kovu
step
#completewith next
#label Dance with Kovu
.goto 2437,46.76,66.73,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kovu|r.
*If it doesn't work /dance at |cRXP_FRIENDLY_Kovu|r
.complete 93048,3 
.emote DANCE,254938
.target Kovu
step
#completewith Dance with Kovu
.goto 2437,46.82,66.33,30 >>Enter the Hut
step
#requires Dance with Kovu
.goto 2437,46.82,66.33
#arrowtext Click on\n|cRXP_PICK_Kovu|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kovu|r.
*If it doesn't work /dance at |cRXP_FRIENDLY_Kovu|r
.complete 93048,3 
.emote DANCE,254938
.target Kovu
step
#label SojournerRythm2
#arrowtext Talk to\n|cRXP_FRIENDLY_Iklani|r
.goto 2437,46.79,66.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iklani|r
.turnin 93048 >>Turn in Got No Rhythm
.target Iklani
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Homework Support
#internal
step
#label SojournerSupport
#arrowtext Talk to\n|cRXP_FRIENDLY_An'jali|r
.goto 2437,46.66,67.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_An'jali|r
.accept 93049 >>Accept Homework Support
.target An'jali
step
#completewith Dragonhawk Fern Frond
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shade Lilies|r
.complete 93049,1 
step
.goto 2437,46.77,67.64
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,1 
step
.goto 2437,46.48,67.66
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,2 
step
#label SojournerCampaignSupport
.goto 2437,46.38,67.09
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,3 
step
#completewith next
#label Dragonhawk Fern FrondZ
.goto 2437,46.99,66.56,10,0
.goto 2437,46.71,66.1,10,0
.goto 2437,46.96,65.87,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,4 
step
#completewith Dragonhawk Fern FrondZ
#hidewindow
.isOnQuest 93049
.goto 2437,46.43,65.88,15 >>Follow the Arrow
step
#requires Dragonhawk Fern FrondZ
.goto 2437,46.43,65.88
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,4 
step
#completewith next
#label Dragonhawk Fern Frond2
.goto 2437,45.93,65.83,10,0
.goto 2437,45.74,65.07,10,0
.goto 2437,45.44,65.95,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,5 
step
#completewith Dragonhawk Fern Frond2
#hidewindow
.goto 2437,45.53,66.47,15 >>Follow the Arrow
step
#requires Dragonhawk Fern Frond2
#label SojournerSupport1.5
.goto 2437,45.53,66.47
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,5 
step
#label SojournerSupport1.75
.goto 2437,45.78,67.13
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,6 
step
.goto 2437,45.42,67.78
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,7 
step
#label Dragonhawk Fern Frond3
.goto 2437,46.26,68.34
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,8 
step
#label SojournerSupport2
#arrowtext Talk to\n|cRXP_FRIENDLY_An'jali|r
#loop
.goto 2437,46.43,68.05,5,0
.goto 2437,46.66,67.96,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_An'jali|r
.turnin 93049 >>Turn in Homework Support
.target An'jali
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Altar History
#internal
step
#label SojournerAltarHistory1
#arrowtext Talk to\n|cRXP_FRIENDLY_Rakan|r
.goto 2437,43.48,68.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakan|r
.accept 93050 >>Accept Altar History
.target Rakan
step
.goto 2437,43.9,69.34
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,1 
step
.goto 2437,43.08,67.99
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,2 
step
#label AltarLoa
.goto 2437,43.08,68.39
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,3 
step
#label AltarLoa2
.goto 2437,43.46,68.89,10,0
.goto 2437,43.35,69.02
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,4 
step
#label SojournerAltarHistory2
#arrowtext Talk to\n|cRXP_FRIENDLY_Rakan|r
.goto 2437,43.37,69.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakan|r inside the temple.
.turnin 93050 >>Turn in Altar History
.target Rakan
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Final Exam
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Recruit Dar'rak|r
.goto 2437,43.15,67.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Dar'rak|r
.accept 93051 >>Accept The Final Exam
.target Recruit Dar'rak
step
#label Sojournerbegin1
#arrowtext Talk to\n|cRXP_FRIENDLY_Ri'kari|r
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r.
.complete 93051,1 
.skipgossipid 137188
.target Ri'kari
step
.goto 2437,43.83,64.98
>>Kill |cRXP_ENEMY_Recruit Dar'rak|r
.complete 93051,2 
.mob Recruit Dar'rak
step
#label Sojournerbegin2
#arrowtext Talk to\n|cRXP_FRIENDLY_Ri'kari|r
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r
.turnin 93051 >>Turn in The Final Exam
.target Ri'kari
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Blessings of the Loa
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Du'gal|r
.goto 2437,43.14,69.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Du'gal|r
.accept 93792 >>Accept Blessings of the Loa
.target Du'gal
step
.goto 2437,43.22,69.23
#arrowtext Click on the\n|cRXP_PICK_Altar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r
.complete 93792,1 
.skipgossipid 133887
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Du'gal|r
.goto 2437,43.14,69.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Du'gal|r
.turnin 93792 >>Turn in Blessings of the Loa
.target Du'gal
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) No Fear
#internal
step
#optional
.isQuestAvailable account,86652
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#label NoFearA
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.accept 92450 >>Accept Growing Up is Hard
.target Ani
step
#label NoFearB
.goto 2437,48.07,67.73
#title |cFFFCDC00Follow the Arrow|r
.complete 92450,1 
.target Ani
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,48.11,67.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.turnin 92450 >>Turn in Growing Up is Hard
.accept 92451 >>Accept I Think I Can
.target Ani
.timer 6.5,RP
step
#completewith next
#label Ani cheered on
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 92451,1 
step
#completewith Ani cheered on
#label BoarCarcass
.goto 2437,48.11,67.61
.cast 1260017 >>Use the |T3750311:0|t|cRXP_WARN_[ExtraActionButton]|r |cRXP_WARN_after the roleplay|r.
.timer 13,RP
step
#requires Ani cheered on
#label NoFearBA
.goto 2437,48.11,67.61
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 92451,1 
step
#label NoFearC
#arrowtext |cRXP_ENEMY_DISMOUNT|r
>>Use the |T237554:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92451,2 
.timer 10.3,RP
step
#label NoFearCA
#title |cFFFCDC00Follow the Arrow|r
.goto 2437,48.71,66.07
.complete 92451,3 
step
#label NoFearD
.goto 2437,48.71,66.07
#arrowtext Click on the\n|cRXP_PICK_Bag|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r.
.turnin 92451 >>Turn in I Think I Can
.target Ani's Trinket Bag
.accept 92452 >>Accept Not According to Plan
step
#arrowtext |cRXP_WARN_Very small totem|r
.goto 2437,47.46,63.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 92452,1,33 
step
.goto 2437,45.98,62.01
#arrowtext Click on the\n|cRXP_PICK_Acorn|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Acorn|r.
.complete 92452,1,66 
step
.goto 2437,45.26,61.07
#arrowtext Click on the\n|cRXP_PICK_Effigy|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Effigy|r.
.complete 92452,1,99 
step
#label NoFearE
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,44.62,60.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.turnin 92452 >>Turn in Not According to Plan
.target Ani
.accept 92453 >>Accept Fearless
step
#label NoFearF
.goto 2437,45.18,69.72
#title |cFFFCDC00Follow the Arrow|r
.complete 92453,1 
.timer 15.5,RP
step
#label NoFearZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.turnin -92453 >>Turn in Fearless
.target Ani
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Sorrowing Kin
#internal
step
#optional
.isQuestAvailable account,86652
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#label SorrowingKinA
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
.goto 2437,45.35,69.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.accept 89565 >>Accept The Path of Mourning
.target Chana
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
.goto 2437,45.87,72.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.turnin 89565 >>Turn in The Path of Mourning
.accept 89503 >>Accept Somber Siblings
.target Chana
step
#label SorrowingKinB
#loop
.goto 2437,46.04,72.65,15,0
.goto 2437,45.75,72.98,15,0
.goto 2437,46.12,73.62,15,0
.goto 2437,46.07,73.97,15,0
.goto 2437,46.3,74.69,15,0
.goto 2437,46.7,75.84,15,0
.goto 2437,47.55,76.02,15,0
.goto 2437,47.6,74.07,15,0
.goto 2437,46.44,72.28,15,0
#arrowtext Click on the |cRXP_PICK_Mushrooms|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r.
*Kill |cRXP_ENEMY_Boars|r |cRXP_WARN_but only if they attack you|r.
*Loot them for |T134389:0|t[|cRXP_LOOT_Weeping Spores|r].
.complete 89503,1 
.mob Tearful Boar
.mob Weeping Swine
step
#label SorrowingKinC
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r |cRXP_WARN_next to you|r.
.turnin 89503 >>Turn in Somber Siblings
.accept 89506 >>Accept Strong Ties
.target Chana
step
#loop
.goto 2437,46.95,79.58,30,0
.goto 2437,47.57,83.01,30,0
.goto 2437,47.12,76.54,30,0
>>Kill |cRXP_ENEMY_Giants|r
*Loot them for |T3586022:0|t[|cRXP_LOOT_Resilient Sinew|r].
.complete 89506,1 
.mob Valley Giant
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r |cRXP_WARN_next to you|r.
.turnin 89506 >>Turn in Strong Ties
.accept 89513 >>Accept Kindling Aplenty
.target Chana
step
#loop
.goto 2437,48.34,84.09,10,0
.goto 2437,48.53,84.37,10,0
.goto 2437,48.77,84.79,10,0
.goto 2437,48.74,85.44,10,0
#arrowtext Click on the |cRXP_PICK_Branches|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Branch|r.
.complete 89513,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r |cRXP_WARN_next to you|r.
.turnin 89513 >>Turn in Kindling Aplenty
.accept 89559 >>Accept Reasonless Worship
.target Chana
step
.goto 2437,47.36,87.61
#arrowtext Click on the\n|cRXP_PICK_Stones|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stones|r
.complete 89559,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r |cRXP_WARN_next to you|r.
.turnin 89559 >>Turn in Reasonless Worship
.target Chana
.accept 89560 >>Accept A Quiet Farewell
step
.goto 2437,46.29,91.29
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 89560,1 
step
.goto 2437,46.29,91.29
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 89560,2 
step
.goto 2437,46.29,91.29
#arrowtext Click on the\n|cRXP_PICK_Branches|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Branches|r.
.complete 89560,3 
step
.goto 2437,46.29,91.29
#arrowtext Click on the\n|cRXP_PICK_Bonfire|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bonfire|r.
.complete 89560,4 
step
.goto 2437,46.29,91.29
#arrowtext Click on the\n|cRXP_PICK_Bonfire|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bonfire|r.
.complete 89560,5 
step
#label SorrowingKinZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
.goto 2437,46.31,91.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.turnin 89560 >>Turn in A Quiet Farewell
.target Chana
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) River-Walkers of the Prowl
#internal
step
#optional
.isQuestAvailable account,86652
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dis Was Our Land (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dis Was Our Land (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jak'zari|r
.goto 2437,45.90,70.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jak'zari|r.
.accept 93257 >>Accept Revantusk at Risk
.target Jak'zari
step
#label SojournerRevantusk
#arrowtext Talk to\n|cRXP_FRIENDLY_Kahanea|r
.goto 2437,40.23,79.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93257 >>Turn in Revantusk at Risk
.target Kahanea
.accept 93258 >>Accept Crab Clues
step
.goto 2437,39.63,80.09
#arrowtext Click on the\n|cRXP_PICK_Debris|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Debris|r.
.complete 93258,1 
.skipgossipid 137687
step
.goto 2437,38.34,79.34
#arrowtext Click on the\n|cRXP_PICK_Basket|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket|r.
*Kill incoming |cRXP_ENEMY_Crabs|r
.complete 93258,3 
.mob Void-Crazed Crawler
step
#label SojournerRevantusk2
.goto 2437,38.77,81.72
#arrowtext Click on the\n|cRXP_PICK_Corpse|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Corpse|r
.complete 93258,2 
.skipgossipid 137685
.mob Crawler Corpse
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kahanea|r
.goto 2437,40.22,79.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93258 >>Turn in Crab Clues
.target Kahanea
.accept 93260 >>Accept Caging Crawlers
.accept 93259 >>Accept Clobbering Crawlers
step
#label SojournerCampaignMouth
#completewith next
>>Kill |cRXP_ENEMY_Crabs|r
*Loot them for |T645112:0|t[|cRXP_LOOT_Mouthwatering Crab Meat|r].
.complete 93259,1 
.mob Juvenile Crawler
.mob Void-Crazed Crawler
.mob Prowl Crawler
step
#loop
.goto 2437,37.49,81.2,12,0
.goto 2437,36.31,81.15,12,0
.goto 2437,35.62,81.69,12,0
.goto 2437,34.76,82.22,12,0
.goto 2437,33.72,83.28,12,0
.goto 2437,32.26,84.22,12,0
#arrowtext Click on the\n|cRXP_PICK_Trap|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trap|r.
.complete 93260,1 
step
#loop
.goto 2437,32.69,82.85,30,0
.goto 2437,34.59,82.5,30,0
.goto 2437,35.85,81.09,30,0
.goto 2437,37.96,81.25,30,0
>>Kill |cRXP_ENEMY_Crabs|r
*Loot them for |T645112:0|t[|cRXP_LOOT_Mouthwatering Crab Meat|r].
.complete 93259,1 
.mob Juvenile Crawler
.mob Void-Crazed Crawler
.mob Prowl Crawler
step
#label Clobbering Crawlers
#arrowtext Talk to\n|cRXP_FRIENDLY_Kahanea|r
.goto 2437,32.21,83.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93259 >>Turn in Clobbering Crawlers
.target Kahanea
.turnin 93260 >>Turn in Caging Crawlers
.accept 93261 >>Accept A Crab of Unusual Size
step
#completewith next
#label Mania-Crab
.goto 2437,33.61,85.57,5,0
>>Kill |cRXP_ENEMY_Mania-Crab|r.
*Loot them for |T1273724:0|t[|cRXP_LOOT_Chipped Twilight's Blade Artifact|r].
.complete 93261,1 
.complete 93261,2 
.mob Mania-Crab
step
.isOnQuest 93261
#completewith Mania-Crab
.goto 2437,33.53,85.92,30 >>Enter the Cave
step
#requires Mania-Crab
.goto 2437,33.53,85.92
>>Kill |cRXP_ENEMY_Mania-Crab|r.
*Loot them for |T1273724:0|t[|cRXP_LOOT_Chipped Twilight's Blade Artifact|r].
.complete 93261,1 
.complete 93261,2 
.mob Mania-Crab
step
#completewith next
#label Crab of Unusual Size
#arrowtext Talk to\n|cRXP_FRIENDLY_Kahanea|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93261 >>Turn in A Crab of Unusual Size
.target Kahanea
step
.isOnQuest 93261
#completewith Crab of Unusual Size
.goto 2437,33.49,78.8,10 >>Enter the Cave
step
#requires Crab of Unusual Size
#label SojournerCrab
#arrowtext Talk to\n|cRXP_FRIENDLY_Kahanea|r
.goto 2437,33.10,79.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93261 >>Turn in A Crab of Unusual Size
.target Kahanea
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Voice of Nalorakk
#internal
step
#optional
.isQuestAvailable account, 91958
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Where War Slumbers (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Where War Slumbers (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TheVoiceOfNalorakkA
#arrowtext Talk to\n|cRXP_FRIENDLY_Pel'na Torntusk|r
.goto 2437,33.61,78.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pel'na Torntusk|r.
.accept 91813 >>Accept The Spiritpaw
.target Pel'na Torntusk
step
#label SojournerCampaignSpiritpaw
#arrowtext Talk to\n|cRXP_FRIENDLY_Furgh|r and |cRXP_FRIENDLY_Fleeg|r
.goto 2437,41.33,80.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Furgh|r and |cRXP_FRIENDLY_Fleeg|r.
.turnin 91813 >>Turn in The Spiritpaw
.accept 91747 >>Accept Not Quite Nalorakk
.accept 91748 >>Accept Too Much Twilight
.target Furgh
.target Fleeg
step
#completewith next
>>Kill |cRXP_ENEMY_Spiritpaws|r.
*Loot them for |T4532351:0|t[|cRXP_LOOT_Nalorakk Trinket|r].
.complete 91747,1 
.mob Spiritpaw Chosen
.mob Spiritpaw Den Watcher
step
#loop
.goto 2437,41.69,80.97,10,0
.goto 2437,42.96,82.81,10,0
.goto 2437,42.91,80.11,10,0
.goto 2437,42.41,79,10,0
#arrowtext Click on the\n|cRXP_PICK_Totems|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totems|r.
.complete 91748,1 
step
#loop
.goto 2437,43.92,79.33,40,0
.goto 2437,44.41,80.59,40,0
.goto 2437,42.88,82.63,40,0
.goto 2437,41.49,80.6,40,0
>>Kill |cRXP_ENEMY_Spiritpaws|r.
*Loot them for |T4532351:0|t[|cRXP_LOOT_Nalorakk Trinket|r].
.complete 91747,1 
.mob Spiritpaw Chosen
.mob Spiritpaw Den Watcher
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Fleeg|r and |cRXP_FRIENDLY_Furgh|r
.goto 2437,41.34,80.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleeg|r and |cRXP_FRIENDLY_Furgh|r.
.turnin 91748 >>Turn in Too Much Twilight
.turnin 91747 >>Turn in The Clarion Call
.accept 91749 >>Accept It's Just Not Right
.target Fleeg
.target Furgh
step
.goto 2437,44.38,79.38
>>Kill |cRXP_ENEMY_Groffa the Guzzler|r.
.complete 91749,1 
.mob Groffa the Guzzler
step
.goto 2437,44.5,79.32
#arrowtext Click on the\n|cRXP_PICK_Chest|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.complete 91749,2 
step
#label SojournerCampaignJustNotRight
#arrowtext Talk to\n|cRXP_FRIENDLY_Furgh|r
.goto 2437,41.36,80.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Furgh|r.
.turnin 91749 >>Turn in It's Just Not Right
.target Furgh
.accept 93734 >>Accept Precious Trinkets
.timer 20,RP
step
.goto 2437,41.28,79.9
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 93734,1 
step
.goto 2437,41.28,79.9
#arrowtext Click on the\n|cRXP_PICK_Bag|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r.
.complete 93734,2 
.timer 15,RP
step
#label FakeVoice
#arrowtext Talk to\n|cRXP_FRIENDLY_Furgh|r and |cRXP_FRIENDLY_Fleeg|r
.goto 2437,41.33,80.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Furgh|r and |cRXP_FRIENDLY_Fleeg|r.
.turnin 93734 >>Turn in Precious Trinkets
.accept 91750 >>Accept Perils of Trust
.target Furgh
.target Fleeg
step
.goto 2437,43.97,82.26
>>Kill |cRXP_ENEMY_Fake Voice of Nalorakk|r |cRXP_WARN_inside the cave|r.
.complete 91750,1 
.mob Voice of Nalorakk
step
#completewith next
#label Perils of Trust
#arrowtext Talk to\n|cRXP_FRIENDLY_Fleeg|r
.goto 2437,43.65,81.95,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleeg|r.
.turnin 91750 >>Turn in Perils of Trust
.target Fleeg
step
.isOnQuest 91750
#completewith Perils of Trust
.goto 2437,41.31,80.10,238 >>Leave the Cave
step
#label TheVoiceOfNalorakkZ
#requires Perils of Trust
#arrowtext Talk to\n|cRXP_FRIENDLY_Fleeg|r
.goto 2437,41.31,80.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleeg|r.
.turnin 91750 >>Turn in Perils of Trust
.target Fleeg
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Reclaiming de Honor
#internal
step
#optional
.isQuestAvailable 86693
+|cRXP_WARN_You have to do the "De Amani Never Die" Chapter first|r
.clicknext RestedXP Midnight\a) De Amani Never Die (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) De Amani Never Die (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r
.goto 2437,33.59,78.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.accept 92492 >>Accept Honorin' de Sacrifice
.target Lilaju
step
#label SojournerSacrifice
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r
.goto 2437,26.08,64.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.turnin 92492 >>Turn in Honorin' de Sacrifice
.accept 92493 >>Accept What Remains of Idago
.accept 92495 >>Accept Disruptin' de Blade
.target Lilaju
step
#label SojournerCampaignShadowmage
#completewith Idago's Banner
>>Kill |cRXP_ENEMY_Baleful Darkspawn|r, |cRXP_ENEMY_Enforcer|r and |cRXP_ENEMY_Shadowmages|r.
.complete 92495,3 
.complete 92495,1 
.complete 92495,2 
.mob Baleful Darkspawn
.mob Twilight Enforcer
.mob Twilight Shadowmage
step
#completewith next
#label Idago's Warspear
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r.
.complete 92493,1 
step
#completewith Idago's Warspear
.goto 2437,24.87,63.11,10 >>Enter the hut
step
#requires Idago's Warspear
.goto 2437,25.00,63.24
#arrowtext Click on the\n|cRXP_PICK_Spear|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r.
.complete 92493,1 
step
.goto 2437,24.06,59.72
#arrowtext Click on the\n|cRXP_PICK_Sand|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sand|r.
.complete 92493,3 
step
#label Idago's Banner
.goto 2437,23.35,60.41
#arrowtext Click on the\n|cRXP_PICK_Banner|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r |cRXP_WARN_on the second floor of the building|r.
.complete 92493,2 
step
#loop
.goto 2437,23.74,63.5,40,0
.goto 2437,25.83,63.45,40,0
.goto 2437,26.51,61.92,40,0
.goto 2437,24.46,59.81,40,0
>>Kill |cRXP_ENEMY_Baleful Darkspawn|r, |cRXP_ENEMY_Enforcer|r and |cRXP_ENEMY_Shadowmages|r.
.complete 92495,3 
.complete 92495,1 
.complete 92495,2 
.mob Baleful Darkspawn
.mob Twilight Enforcer
.mob Twilight Shadowmage
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r
.goto 2437,22.56,63.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.turnin 92493 >>Turn in What Remains of Idago
.target Lilaju
.turnin 92495 >>Turn in Disruptin' de Blade
.accept 92496 >>Accept Spears Against de Shadow
step
#completewith next
#label Simply Magical1
#arrowtext Talk to\n|cRXP_FRIENDLY_Idago|r
.goto 2584,88.1,39.57,8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Idago|r.
.accept 92497 >>Accept Simply Magical
.target Idago
step
#completewith Simply Magical1
.goto 2437,21.17,63.43,60 >>Enter the Temple
step
#requires Simply Magical1
#arrowtext Talk to\n|cRXP_FRIENDLY_Idago|r
.goto 2437,21.17,63.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Idago|r.
.accept 92497 >>Accept Simply Magical
.target Idago
step
#completewith next
#label Page of Pain
.goto 2584,59.43,28.6,10,0
.goto 2584,43.58,32.68,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 92497,2 
step
#completewith Page of Pain
.goto 2437,20.54,63.36,30 >>Follow the Arrow
step
#requires Page of Pain
.goto 2437,20.54,63.36
#arrowtext Click on the\n|cRXP_PICK_Book|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 92497,2 
step
#completewith next
#label Page of Binding
.goto 2584,28.89,28.96,10,0
.goto 2584,29.58,69.63,10,0
.goto 2584,40.7,68.65,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 92497,1 
step
#completewith Page of Binding
.goto 2437,20.80,64.35,30 >>Follow the Arrow
step
#requires Page of Binding
.goto 2437,20.80,64.35
#arrowtext Click on the\n|cRXP_PICK_Book|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
*Don't kill |cRXP_ENEMY_Deathchanter Mish'mosh|r yet
.complete 92497,1 
step
.goto 2437,20.91,64.24
>>Kill |cRXP_ENEMY_Deathchanter Mish'mosh|r.
.complete 92496,1 
.mob Deathchanter Mish'mosh
step
#completewith next
#label Runic Bindings
.goto 2584,63.61,59.61,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bindings|r.
.complete 92497,3 
step
#completewith Runic Bindings
.goto 2584,61.24,39.98,40 >>Follow the Arrow
step
#requires Runic Bindings
.goto 2584,61.24,39.98
#arrowtext Click on the\n|cRXP_PICK_Bindings|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bindings|r.
.complete 92497,3 
step
#completewith next
#label Simply Magical
#arrowtext Talk to\n|cRXP_FRIENDLY_Idago|r and |cRXP_FRIENDLY_Lilaju|r
.goto 2437,21.89,63.43,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Idago|r and |cRXP_FRIENDLY_Lilaju|r.
.turnin 92497 >>Turn in Simply Magical
.turnin 92496 >>Turn in Spears Against de Shadow
.accept 92499 >>Accept The Wisest Leaders Follow
.disablecheckbox
.target Idago
.target Lilaju
step
#completewith Simply Magical
.goto 2437,22.56,63.92,66 >>Leave the Temple
step
#requires Simply Magical
#arrowtext Talk to\n|cRXP_FRIENDLY_Idago|r and |cRXP_FRIENDLY_Lilaju|r
.goto 2437,22.56,63.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Idago|r and |cRXP_FRIENDLY_Lilaju|r.
.turnin 92497 >>Turn in Simply Magical
.turnin 92496 >>Turn in Spears Against de Shadow
.accept 92499 >>Accept The Wisest Leaders Follow
.target Idago
.target Lilaju
step
#label SojournerLeaders
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r
.goto 2437,33.59,78.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r
.turnin 92499 >>Turn in The Wisest Leaders Follow
.target Lilaju
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bloodstains
#internal
step
.isQuestTurnedIn account,86522
.isNotOnQuest 94957
.isQuestAvailable 86693
.goto 2393,55.65,69.8
.gossipoption 138327 >>Talk to |cRXP_FRIENDLY_Soridormi|r to skip the level-up campaign, or complete it to unlock this storyline.
.skipgossipid 138326
.target Soridormi
step
.isOnQuest 94957
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2424,53.12,58.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
*|cRXP_WARN_This will skip the Level-UP Campaign|r
.complete 94957,1 
.skipgossipid 138308
.skipgossipid 138306
.mob Lady Liadrin
step
#optional
.isQuestAvailable 86693
+|cRXP_WARN_You have to do the "De Amani Never Die" Chapter first|r
.clicknext RestedXP Midnight\a) De Amani Never Die (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) De Amani Never Die (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.76,65.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 93440 >>Accept Personal History
.target Zul'jarra
step
#label Personal History
#arrowtext Talk to\n|cRXP_FRIENDLY_Torundo the Grizzled|r and |cRXP_FRIENDLY_Elder Doru|r
.goto 2536,46.04,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torundo the Grizzled|r and |cRXP_FRIENDLY_Elder Doru|r.
.turnin 93440 >>Turn in Personal History
.accept 93432 >>Accept Swords to Plowshares
.accept 93433 >>Accept Shrine, Sealed, Delivered
.target Torundo the Grizzled
.target Elder Doru
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Vu'lona|r
.goto 2536,35.32,65.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Vu'lona|r |cRXP_WARN_from afar|r.
.complete 93433,3 
.skipgossipid 137195
.target Elder Vu'lona
step
#loop
.goto 2536,38,72.77,30,0
.goto 2536,34.45,74.27,30,0
.goto 2536,30.95,72.06,30,0
.goto 2536,30.29,65.45,30,0
.goto 2536,34.4,56.6,30,0
>>Kill |cRXP_ENEMY_Raiders|r
*Loot them for |T237286:0|t[|cRXP_LOOT_Raider Ash Remains|r].
.complete 93432,1 
.mob Raiding Warrior
.mob Raiding Rogue
.mob Raiding Caster
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Thak|r
.goto 2536,25.80,66.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Thak|r
.complete 93433,2 
.skipgossipid 137197
.target Elder Thak
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Eagletender Rhyd|r
.goto 2536,20.76,13.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eagletender Rhyd|r
.complete 93433,1 
.skipgossipid 137198
.target Eagletender Rhyd
step
#completewith next
#label Elder Shimarra
#arrowtext Talk to\n|cRXP_FRIENDLY_Eagletender Rhyd|r
.goto 2536,32.52,24.01,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eagletender Rhyd|r
.complete 93433,4 
.target Elder Shimarra
step
#completewith Elder Shimarra
.goto 2536,34.44,23.21,30 >>Enter the Temple
step
#requires Elder Shimarra
#arrowtext Talk to\n|cRXP_FRIENDLY_Eagletender Rhyd|r
.goto 2536,34.44,23.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eagletender Rhyd|r
.complete 93433,4 
.skipgossipid 137196
.target Elder Shimarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Torundo the Grizzled|r and |cRXP_FRIENDLY_Elder Doru|r
.goto 2536,45.31,44.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torundo the Grizzled|r and |cRXP_FRIENDLY_Elder Doru|r.
.turnin 93432 >>Turn in Swords to Plowshares
.turnin 93433 >>Turn in Shrine, Sealed, Delivered
.accept 93435 >>Accept Four Instigators
.accept 93436 >>Accept Hex the Innocent, Disrupt the Guilty
.target Torundo the Grizzled
.target Elder Doru
step
.goto 2536,67.58,47.3
#arrowtext Click on the\n|cRXP_PICK_Chest|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.complete 93436,3 
step
.goto 2536,52.06,30.61
#arrowtext Click on\n|cRXP_PICK_Kaldrick|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kaldrick|r
.complete 93436,2,1 
.mob Kaldrick
step
.goto 2536,52.07,19.23
#arrowtext Click on the\n|cRXP_PICK_Feast|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feast|r.
.complete 93436,1,1 
step
#completewith next
#label Zungam
.goto 2536,44.75,30.88,5,0
>>Kill |cRXP_ENEMY_Zungam|r.
.complete 93435,2 
.mob Zungam
step
#completewith Zungam
.goto 2536,44.1,32.54,20 >>Enter the building through the window
step
#requires Zungam
.goto 2536,44.12,31.98
>>Kill |cRXP_ENEMY_Zungam|r.
.complete 93435,2 
.mob Zungam
step
#completewith next
#label Feasts poisoned
.goto 2536,42.95,30.71,5,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feast|r.
.complete 93436,1,2 
step
#completewith Feasts poisoned
.goto 2536,7.95,9.07,582 >>Leave the Hut
step
#requires Feasts poisoned
.goto 2536,7.95,9.07
#arrowtext Click on the\n|cRXP_PICK_Feast|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feast|r.
.complete 93436,1,2 
step
.goto 2536,9.12,20.41
#arrowtext Click on\n|cRXP_PICK_Gunter|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Gunter|r
.complete 93436,2,2 
.mob Gunter
step
.goto 2536,10.45,27.57
>>Kill |cRXP_ENEMY_Budd Nedreck|r.
.complete 93435,3 
.mob Budd Nedreck
step
.goto 2536,11.38,34.99
#arrowtext Click on\n|cRXP_PICK_Galathryn|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Galathryn|r |cRXP_WARN_behind the building|r.
.complete 93436,2,3 
.mob Galathryn
step
.goto 2536,8.58,40.56
#arrowtext Click on the\nbarrel
>>Kill |cRXP_ENEMY_Harrison Jones|r |cRXP_WARN_click on the barrel next to him for a buff|r.
.complete 93435,4 
.mob Harrison Jones
step
.goto 2536,18.55,77.03
#arrowtext Click on\n|cRXP_PICK_Arinoth|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Arinoth|r
.complete 93436,2,4 
.mob Arinoth
step
.goto 2536,22.58,80.74
#arrowtext Click on the\n|cRXP_PICK_Feast|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feast|r.
.complete 93436,1,3 
step
.goto 2536,26.81,80.11
#arrowtext Click on\n|cRXP_PICK_Melissa|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Melissa|r
.complete 93436,2,5
.mob Melissa
step
.goto 2536,31.89,77.07
#arrowtext Click on\n|cRXP_PICK_Mawago|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mawago|r
.complete 93436,2,6 
.mob Mawago
step
.goto 2536,34.61,81.09
>>Kill |cRXP_ENEMY_Prigmon|r.
.complete 93435,1 
.mob Prigmon
step
.goto 2536,37.48,79.65
#arrowtext Click on\n|cRXP_PICK_Mannuth|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mannuth|r
.complete 93436,2,7 
.mob Mannuth
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Torundo the Grizzled|r and |cRXP_FRIENDLY_Elder Doru|r
.goto 2536,45.89,47.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torundo the Grizzled|r, |cRXP_FRIENDLY_Elder Doru|r and |cRXP_FRIENDLY_Torundo the Grizzled|r.
.turnin 93435 >>Turn in Four Instigators
.turnin 93436 >>Turn in Hex the Innocent, Disrupt the Guilty
.accept 93437 >>Accept In Their Own Blood
.target Torundo the Grizzled
.target Elder Doru
.target Torundo the Grizzled
step
#completewith next
#label Inhabit a Loa Avatar
>>Stand within the circle and use the |T135265:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93437,1 
step
#completewith Inhabit a Loa Avatar
.goto 2536,34.42,65.08,15 >>Enter the Temple
step
#requires Inhabit a Loa Avatar
.goto 2536,34.42,65.08
>>Stand within the circle and use the |T135265:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93437,1 
step
#completewith next
#label Slay Echoes
>>Kill |cRXP_ENEMY_Raiders|r
*|cRXP_WARN_Usually faster to kill them outside of the Loa Form|r
.complete 93437,2 
step
#completewith Slay Echoes
.exitvehicle >>Press the Macro to leave the vehicle.
*It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Slay Echoes
#loop
.goto 2536,31.69,47.42,30,0
.goto 2536,26.59,47.37,30,0
.goto 2536,19.54,47.4,30,0
>>Kill |cRXP_ENEMY_Raiders|r
*|cRXP_WARN_Usually faster to kill them outside of the Loa Form|r
.complete 93437,2 
step
.goto 2536,64.07,47.27
>>Kill |cRXP_ENEMY_Raid Leader|r.
.complete 93437,4 
.mob Raid Leader
step
#label Their Own Blood
#arrowtext Talk to\n|cRXP_FRIENDLY_Torundo the Grizzled|r
.goto 2536,45.89,47.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torundo the Grizzled|r.
.turnin 93437 >>Turn in In Their Own Blood
.target Torundo the Grizzled
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Something Vile This Way Comes
#internal
#chapter
step
.xp 90 >>Skip this for now, come back once you hit level 90.
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Vun'zarah|r
.goto 2437,38.57,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vun'zarah|r
.accept 91833 >>Accept Dirty Deeps
.target Vun'zarah
step
#label Send Dem Home
#arrowtext Talk to\n|cRXP_FRIENDLY_Dak'zor|r and |cRXP_FRIENDLY_Tan'zin|r
.goto 2437,44.88,36.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r and |cRXP_FRIENDLY_Tan'zin|r.
.turnin 91833 >>Turn in Dirty Deeps
.accept 91835 >>Accept Send Dem Home
.accept 91836 >>Accept Respect de Totem
.accept 91838 >>Accept De Vile Diminished
.target Dak'zor
.target Tan'zin
step
#completewith Vile Orb destroyed
>>Kill |cRXP_ENEMY_Vile Tormentor|r, |cRXP_ENEMY_Hex Guardian|r, |cRXP_ENEMY_Wild Guardian|r and |cRXP_ENEMY_Vile Boneservant|r.
*Loot them for |T5927651:0|t[|cRXP_LOOT_Totem Remnant]|r].
*Use the |T5764922:0|t|cRXP_WARN_[ExtraActionButton]|r for extra damage.
.complete 91836,1 
.mob Vile Tormentor
.mob Hex Guardian
.mob Wild Guardian
.mob Vile Boneservant
.mob Vilebranch Souleater
step
.goto 2437,46.07,39.3
#arrowtext Click on the\n|cRXP_PICK_Orb|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
.complete 91838,1,1 
step
.goto 2437,46.01,39.14
#arrowtext Click on the\n|cRXP_PICK_Prisoners|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prisoners|r.
.complete 91835,1,2 
.target Witherbark Prisoner
step
.goto 2437,46.47,38.82
#arrowtext Click on the\n|cRXP_PICK_Prisoners|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prisoners|r.
.complete 91835,1,4 
.target Witherbark Prisoner
step
.goto 2437,46.54,37.53
#arrowtext Click on the\n|cRXP_PICK_Orb|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
.complete 91838,1,2 
step
.goto 2437,47.25,39.52
#arrowtext Click on the\n|cRXP_PICK_Prisoners|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prisoners|r.
.complete 91835,1,5 
.target Witherbark Prisoner
step
.goto 2437,47.31,40.11
#arrowtext Click on the\n|cRXP_PICK_Prisoners|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prisoners|r.
.complete 91835,1,6 
.target Witherbark Prisoner
step
.goto 2437,47.19,39.85
#arrowtext Click on the\n|cRXP_PICK_Orb|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
.complete 91838,1,3 
step
.goto 2437,46.39,40.71
#arrowtext Click on the\n|cRXP_PICK_Orb|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
.complete 91838,1,4 
step
.goto 2437,46.39,40.71
#arrowtext Click on the\n|cRXP_PICK_Prisoners|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prisoners|r.
.complete 91835,1,8 
.target Witherbark Prisoner
step
#label Vile Orb destroyed
.goto 2437,45.53,42.26
#arrowtext Click on the\n|cRXP_PICK_Orb|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orb|r.
.complete 91838,1,5 
step
#loop
.goto 2437,46.21,39.95,30,0
.goto 2437,45.82,38.63,30,0
.goto 2437,44.61,39.39,30,0
>>Kill |cRXP_ENEMY_Vile Tormentor|r, |cRXP_ENEMY_Hex Guardian|r, |cRXP_ENEMY_Wild Guardian|r and |cRXP_ENEMY_Vile Boneservant|r.
*Loot them for |T5927651:0|t[|cRXP_LOOT_Totem Remnant]|r].
*Use the |T5764922:0|t|cRXP_WARN_[ExtraActionButton]|r for extra damage.
.complete 91836,1 
.mob Vile Tormentor
.mob Hex Guardian
.mob Wild Guardian
.mob Vile Boneservant
.mob Vilebranch Souleater
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tan'zin|r
.goto 2437,47.16,41.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tan'zin|r
.turnin 91838 >>Turn in De Vile Diminished
.target Tan'zin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Dak'zor|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r |cRXP_WARN_next to you|r.
.turnin 91836 >>Turn in Respect de Totem
.turnin 91835 >>Turn in Send Dem Home
.accept 91840 >>Accept One Will Not Rise
.target Dak'zor
step
.goto 2437,48.39,43.08
>>Kill |cRXP_ENEMY_Knife Priestess Hezzia|r.
*Loot her for |T134171:0|t[|cRXP_LOOT_Knife Priestess Hezzia's Head]|r].
.complete 91840,1 
.mob Knife Priestess Hezzia
step
#completewith next
#label One Will Not Rise
#arrowtext Talk to\n|cRXP_FRIENDLY_Vun'zarah|r
.goto 2437,38.44,22.62,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vun'zarah|r
.turnin 91840 >>Turn in One Will Not Rise
.target Vun'zarah
step
#completewith One Will Not Rise
.goto 2437,38.57,22.41,15 >>Enter the building
step
#requires One Will Not Rise
#arrowtext Talk to\n|cRXP_FRIENDLY_Vun'zarah|r
.goto 2437,38.57,22.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vun'zarah|r
.turnin 91840 >>Turn in One Will Not Rise
.target Vun'zarah
step
#label Sacrifice Denied
#arrowtext Talk to\n|cRXP_FRIENDLY_Dak'zor|r
.goto 2437,38.53,22.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r
.accept 91839 >>Accept Sacrifice Denied
.target Dak'zor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Bin'zin|r
.goto 2437,37.31,25.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bin'zin|r
.complete 91839,1 
.skipgossipid 136456
.target Bin'zin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Bin'zin|r
.goto 2437,37.31,25.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bin'zin|r
.turnin 91839 >>Turn in Sacrifice Denied
.target Bin'zin
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Goblin in Harandar
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Monte Gazlowe|r
.goto 2413,47.08,45.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Monte Gazlowe|r
.accept 90533 >>Accept Go Get Orweyna!
.target Monte Gazlowe
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,54.18,55.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.complete 90533,1 
.skipgossipid 133239
.skipgossipid 138671
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Imhayo|r
.goto 2413,53.91,55.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Imhayo|r and buy |T4048814:0|t[Handcrafted Plush]
.complete 90533,2 
.skipgossipid 138674
.buy 241125,1
.target Imhayo
step
.goto 2413,47.09,45.85
#arrowtext Click on \n|cRXP_PICK_Nahuut|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Nahuut|r
.complete 90533,3 
.target Nahuut
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,47.17,45.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 90533 >>Turn in Go Get Orweyna!
.target Orweyna
.accept 90534 >>Accept The Home of the Haranir
step
.goto 2413,51.82,50.47
#arrowtext Click on\n|cRXP_PICK_Robot|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Robot|r
.complete 90534,1 
.target Monte Gazlowe
step
#completewith next
#label Pick up Hand Claws
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r
.complete 90534,2 
step
#completewith Pick up Hand Claws
.goto 2576,46.05,84.72,30 >>Enter the Den
step
#requires Pick up Hand Claws
.goto 2576,45.86,79.65
#arrowtext Click on the\n|cRXP_PICK_Weapon Rack|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r
.complete 90534,2 
step
.goto 2576,65.90,59.83
#arrowtext Click on the\n|cRXP_PICK_Bowl|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bowl|r
.complete 90534,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Monte Gazlowe|r
.goto 2576,48.01,22.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Monte Gazlowe|r |cRXP_WARN_in the den|r.
.turnin 90534 >>Turn in The Home of the Haranir
.accept 90535 >>Accept Leave Your Mark
.target Monte Gazlowe
step
.goto 2576,48.00,23.21
#arrowtext Click on the\n|cRXP_PICK_Bowl|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bowl|r
.complete 90535,1 
step
.goto 2576,48.26,22.96
#arrowtext Click on the\n|cRXP_PICK_Wall|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wall|r
.complete 90535,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
#label LeaveMark
.goto 2576,48.01,22.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 90535 >>Turn in Leave Your Mark
.target Orweyna
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Legend of Aln'sharan
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TheLegendOfAlnsharanA
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,67.79,27.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r
.accept 90467 >>Accept Tales of the Sky
.target Kuri
.accept 90468 >>Accept Ugh, Chores!
step
#label Cascades FenhunterZ
#hidewindow
#completewith Cascades Fenhunter
#loop
.goto 2413,67.06,30.78,30,0
.goto 2413,68.44,31.72,10,0
.goto 2413,69.24,32.71,20,0
.goto 2413,69.92,31.02,30,0
.goto 2413,69.25,29.4,30,0
.goto 2413,71.25,32.66,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Cascades Fenhunter|r
*Loot them for |T237425:0|t[|cRXP_LOOT_Intact Saptor Frond|r].
.complete 90468,1 
.mob Cascades Fenhunter
step
#arrowtext Click on\n|cRXP_PICK_Shards|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Shards|r
.complete 90467,1 
step
#label Cascades Fenhunter
>>Kill |cRXP_ENEMY_Cascades Fenhunter|r
*Loot them for |T237425:0|t[|cRXP_LOOT_Intact Saptor Frond|r].
.complete 90468,1 
.mob Cascades Fenhunter
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kamari|r
.goto 2413,69.40,29.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kamari|r
.turnin 90468 >>Turn in Ugh, Chores!
.target Kamari
.turnin 90467 >>Turn in Tales of the Sky
.accept 90469 >>Accept Carry On, Wayward Kuri
step
#label TheLegendOfAlnsharanB
.goto 2413,69.69,26.56
#title |cFFFCDC00Follow the Arrow|r
.complete 90469,1 
step
#label TheLegendOfAlnsharanC
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,69.69,26.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r
.turnin 90469 >>Turn in Carry On, Wayward Kuri
.target Kuri
.accept 90470 >>Accept Skyglass Scavenging
step
#loop
.goto 2413,70.11,26.46,30,0
.goto 2413,70.39,25.9,30,0
.goto 2413,70.96,26.11,30,0
.goto 2413,70.84,26.87,30,0
.goto 2413,71.14,27.2,30,0
.goto 2413,71.13,28.2,30,0
.goto 2413,71.28,28.73,30,0
.goto 2413,71.53,28.75,30,0
.goto 2413,71.46,28.34,30,0
.goto 2413,71.34,27.07,30,0
>>Use the |T5948153:0|t|cRXP_WARN_[ExtraActionButton]|r on the circles of green shards.
*Kill the incoming monsters.
#arrowtext Click on the\n|cRXP_PICK_Shards|r
*|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shards|r
.complete 90470,1 
.mob Oozing Rootmuck
.mob Agitated Rootbat
.mob Disgruntled Lashroom
.mob Mildewed Enmity
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,69.70,26.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r |cRXP_WARN_outside the cave|r.
.turnin 90470 >>Turn in Skyglass Scavenging
.target Kuri
.accept 90474 >>Accept The Legend of Aln'sharan
step
#label TheLegendOfAlnsharanZZZ
.goto 2413,66.15,25.50
>>Use the |T132875:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 90474,1 
.timer 8,RP
step
#label TheLegendOfAlnsharanZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,66.16,25.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r after the roleplay
.turnin 90474 >>Turn in The Legend of Aln'sharan
.target Kuri
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Late Bloomers
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#label LateBloomersA
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'leia|r
.goto 2413,36.96,25.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r
.accept 90537 >>Accept Late Bloomers
.target Ney'leia
step
.goto 2413,48.69,31.98
#title |cFFFCDC00Follow the Arrow|r
.complete 90537,1 
step
#loop
.goto 2413,48.69,31.98,5,0
.goto 2413,48.73,32.19,5,0
#arrowtext Click on the\n|cRXP_PICK_Mushroom|r and |cRXP_PICK_Sack|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushroom|r and the |cRXP_PICK_Sack|r
.complete 90537,2 
.complete 90537,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'leia|r
.goto 2413,48.81,32.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r
.complete 90537,4 
.skipgossipid 133929
.target Ney'leia
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'leia|r
.goto 2413,48.94,29.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r
.turnin 90537 >>Turn in Late Bloomers
.target Ney'leia
.accept 90540 >>Accept Rutaani Rescue
.accept 90569 >>Accept Back in the Bag
step
#hidewindow
#completewith Stolen Seeds
#loop
.goto 2413,48.48,27.32,10,0
.goto 2413,48.44,26.38,10,0
.goto 2413,47.36,27.47,10,0
.goto 2413,46.75,28.32,10,0
.goto 2413,48.09,28.87,10,0
.goto 2413,46.74,25.68,30,0
.goto 2413,47.19,23.6,30,0
.goto 2413,48.25,24.02,30,0
.goto 2413,49.05,28.29,25,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Mushrooms|r
*Loot them for |T656440:0|t[|cRXP_LOOT_Stolen Seeds|r].
.complete 90569,1 
.mob Mycotic Moldstalker
.mob Spiteful Sporecaller
.mob Rancid Rotslasher
step
#arrowtext Click on\n|cRXP_PICK_Captured Rutaanis|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Captured Rutaanis|r
.complete 90540,1 
.target Captured Rutaani
step
#label Stolen Seeds
>>Kill |cRXP_ENEMY_Mushrooms|r
*Loot them for |T656440:0|t[|cRXP_LOOT_Stolen Seeds|r].
.complete 90569,1 
.mob Mycotic Moldstalker
.mob Spiteful Sporecaller
.mob Rancid Rotslasher
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'leia|r
.goto 2413,48.94,29.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r
.turnin 90540 >>Turn in Rutaani Rescue
.turnin 90569 >>Turn in Back in the Bag
.accept 90963 >>Accept Caves of the Cleft
.target Ney'leia
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'leia|r
.goto 2413,49.69,23.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r
.turnin 90963 >>Turn in Caves of the Cleft
.accept 90601 >>Accept Gathering Glowshrooms
.accept 90602 >>Accept Gomphusta
.target Ney'leia
step
#completewith Gomphusta's Chest
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r
.complete 90601,1 
step
#completewith next
#label Gomphusta
.goto 2413,48.94,23.33,15,0
>>Kill |cRXP_ENEMY_Gomphusta|r
*Loot him for |T4909720:0|t[|cRXP_LOOT_Carved Key|r].
.complete 90602,1 
.collect 246117,1,90602,1
.mob Gomphusta
step
.isOnQuest 90602
#completewith Gomphusta
.goto 2413,49.2,22.62,40 >>Enter the Cave
step
#requires Gomphusta
.goto 2413,49.2,22.62,10,0
.goto 2413,48.94,22.02,10,0
.goto 2413,48.67,21.67
>>Kill |cRXP_ENEMY_Gomphusta|r
*Loot him for |T4909720:0|t[|cRXP_LOOT_Carved Key|r].
.complete 90602,1 
.collect 246117,1,90602,1
.mob Gomphusta
step
#label Gomphusta's Chest
.goto 2413,48.62,22.42
#arrowtext Click on the\n|cRXP_PICK_Chest|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.complete 90602,2 
step
#loop
.goto 2413,49.38,21.88,15,0
.goto 2413,49.36,22.55,15,0
.goto 2413,49,22.68,15,0
.goto 2413,48.81,21.88,15,0
.goto 2413,48.62,21.55,15,0
.goto 2413,48.63,22.32,15,0
#arrowtext Click on the\n|cRXP_PICK_Mushrooms|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r
.complete 90601,1 
step
#completewith next
#label Gathering Glowshrooms
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'leia|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r
.turnin 90601 >>Turn in Gathering Glowshrooms
.target Ney'leia
.turnin 90602 >>Turn in Gomphusta
step
.isOnQuest 90601
#completewith Gathering Glowshrooms
.goto 2413,49.02,23.45,15 >>Leave the Cave
step
#requires Gathering Glowshrooms
#label LateBloomersZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'leia|r
.goto 2413,49.70,23.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r
.turnin 90601 >>Turn in Gathering Glowshrooms
.target Ney'leia
.turnin 90602 >>Turn in Gomphusta
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Greenspeaker's Vigil
#internal
step
.isQuestTurnedIn account,86522
.isNotOnQuest 94957
.isQuestAvailable 86930
.goto 2393,55.65,69.8
.gossipoption 138327 >>Talk to |cRXP_FRIENDLY_Soridormi|r to skip the level-up campaign, or complete it to unlock this storyline.
.skipgossipid 138326
.target Soridormi
step
.isOnQuest 94957
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2424,53.12,58.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
*|cRXP_WARN_This will skip the Level-UP Campaign|r
.complete 94957,1 
.skipgossipid 138308
.skipgossipid 138306
.mob Lady Liadrin
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Greenspeaker Cyenna|r
.goto 2413,65.45,28.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greenspeaker Cyenna|r
.accept 91346 >>Accept Supplicants to the Goddess
.target Greenspeaker Cyenna
step
#label Waters1
.goto 2413,65.45,28.06
#arrowtext Click on the\n|cRXP_PICK_Bucket|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bucket|r
.complete 91346,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Greenspeaker Cyenna|r
.goto 2413,65.45,28.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greenspeaker Cyenna|r
.turnin 91346 >>Turn in Supplicants to the Goddess
.target Greenspeaker Cyenna
.accept 91359 >>Accept Fungal Lashers B Gone
.accept 91360 >>Accept Weeding Out the Unwanted
step
#hidewindow
#completewith Harmonious Lash gathered
#loop
.goto 2413,63.8,28.95,30,0
.goto 2413,59.57,26.61,30,0
.goto 2413,60.51,31.18,30,0
.goto 2413,62.19,30.18,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Lashers|r
*Loot them for |T237424:0|t[|cRXP_LOOT_Harmonious Lash|r].
.complete 91359,1 
.mob Feasting Lashroom
step
#arrowtext Click on the\n|cRXP_PICK_Weed|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weed|r and pull them out.
.complete 91360,1 
step
#label Harmonious Lash gathered
>>Kill |cRXP_ENEMY_Lashers|r
*Loot them for |T237424:0|t[|cRXP_LOOT_Harmonious Lash|r].
.complete 91359,1 
.mob Feasting Lashroom
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Greenspeaker Cyenna|r
.goto 2413,65.45,28.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greenspeaker Cyenna|r
.turnin 91360 >>Turn in Weeding Out the Unwanted
.target Greenspeaker Cyenna
.turnin 91359 >>Turn in Fungal Lashers B Gone
.accept 91361 >>Accept Back on Duty?
step
#label Riverscales
#loop
.goto 2413,67.01,27.42,30,0
.goto 2413,66.96,25.41,30,0
.goto 2413,65.25,26.04,30,0
>>Kill |cRXP_ENEMY_Aggressive Potatoad|r and |cRXP_ENEMY_Harmonious Petalwing|r
.complete 91361,1 
.mob Aggressive Potatoad
.mob Harmonious Petalwing
step
#label Waters2
#arrowtext Talk to\n|cRXP_FRIENDLY_Greenspeaker Cyenna|r
.goto 2413,65.45,28.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greenspeaker Cyenna|r
.turnin 91361 >>Turn in Back on Duty?
.target Greenspeaker Cyenna
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Peril Among Petals
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#label PerilAmongPetalsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Su'meera|r
.goto 2413,65.38,22.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Su'meera|r
.accept 91063 >>Accept The Blooming Lattice
.target Su'meera
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Su'meera|r
.goto 2413,60.82,29.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Su'meera|r
.turnin 91063 >>Turn in The Blooming Lattice
.accept 91065 >>Accept Purloining Petals
.accept 91086 >>Accept Nipping the Buds
.accept 91085 >>Accept Petal Bristles
.target Su'meera
step
#completewith Splattered Scroll
>>|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Feathers|r
*Kill |cRXP_ENEMY_Pilfering Petalwings|r
*Loot them for |T959796:0|t[|cRXP_LOOT_Petalwing Plumes|r].
.complete 91085,1 
.mob Pilfering Petalwing
step
#completewith Splattered Scroll
>>Kill |cRXP_ENEMY_Rutaanis|r
.complete 91086,1 
.mob Lattice Sap Weaver
.mob Lattice Mistcaller
.mob Lattice Grovewarden
step
#completewith next
#label Well-Worn Ladle
#hidewindow
.complete 91065,1 
step
#completewith Well-Worn Ladle
#arrowtext Click on |cRXP_PICK_Feathers|r
.goto 2413,58.9,28.24,20,0
.goto 2413,56.83,29.8,20,0
.goto 2413,57.44,28.14,20,0
.goto 2413,56.22,28.17,20,0
.goto 2413,55.31,28.32,75 >>Follow the Arrow
step
#requires Well-Worn Ladle
#label
.goto 2413,55.31,28.32
#arrowtext |cFFFCDC00On a platform above|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ladle|r |cRXP_WARN_on a platform above|r.
.complete 91065,1 
step
.goto 2413,54.53,28.29
#arrowtext Click on the\n|cRXP_PICK_Drill|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drill|r
.complete 91065,2 
step
.goto 2413,55.32,30.62
#arrowtext Click on the\n|cRXP_PICK_Gourd|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gourd|r
.complete 91065,4 
step
.goto 2413,54.91,31.54
>>Kill |cRXP_ENEMY_Prime Bloodwarden Kazat|r |cRXP_WARN_inside the building|r.
.complete 91086,2 
.mob Prime Bloodwarden Kazat
step
#label Splattered Scroll
.goto 2413,54.86,32.07
#arrowtext Click on the\n|cRXP_PICK_Scroll|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r |cRXP_WARN_behind the building|r.
.complete 91065,3 
step
#hidewindow
#completewith Petalwing Plumes
#loop
.goto 2413,55.51,32.13,30,0
.goto 2413,56.13,30.96,30,0
.goto 2413,56.81,29.86,30,0
.goto 2413,58.09,28.86,30,0
.goto 2413,58.85,28.18,30,0
.goto 2413,56.98,28.14,30,0
.goto 2413,55.49,28.31,30,0
.goto 2413,54.67,29.28,30,0
.goto 2413,52.51,29.16,30,0
.goto 2413,54.87,30.9,30,0
.goto 2413,54.77,27.66,30,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Feathers|r
*Kill |cRXP_ENEMY_Pilfering Petalwings|r
*Loot them for |T959796:0|t[|cRXP_LOOT_Petalwing Plumes|r].
.complete 91085,1 
.mob Pilfering Petalwing
step
>>Kill |cRXP_ENEMY_Rutaanis|r
.complete 91086,1 
.mob Lattice Sap Weaver
.mob Lattice Mistcaller
.mob Lattice Grovewarden
step
#label Petalwing Plumes
#arrowtext Click on\n|cRXP_PICK_Feathers|r
>>|TInterface/cursor/crosshair/interact.blp:17|tClick on |cRXP_PICK_Feathers|r
*Kill |cRXP_ENEMY_Pilfering Petalwings|r
*Loot them for |T959796:0|t[|cRXP_LOOT_Petalwing Plumes|r].
.complete 91085,1 
.mob Pilfering Petalwing
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Su'meera|r
.goto 2413,60.82,29.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Su'meera|r
.turnin 91086 >>Turn in Nipping the Buds
.target Su'meera
.turnin 91085 >>Turn in Petal Bristles
.turnin 91065 >>Turn in Purloining Petals
.accept 91088 >>Accept Behind the Falls
step
#completewith next
#label Behind the Falls
#arrowtext Talk to\n|cRXP_FRIENDLY_Su'meera|r
.goto 2413,55.85,25.96,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Su'meera|r
.turnin 91088 >>Turn in Behind the Falls
.target Su'meera
.accept 91136 >>Accept Memories in Stone
.disablecheckbox
step
.isOnQuest 91088
#completewith Behind the Falls
.goto 2413,56.10,24.83,55 >>Enter the cave |cRXP_WARN_high up, near the top of the waterfall|r.
step
#requires Behind the Falls
#arrowtext Talk to\n|cRXP_FRIENDLY_Su'meera|r
.goto 2413,56.10,24.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Su'meera|r
.turnin 91088 >>Turn in Behind the Falls
.target Su'meera
.accept 91136 >>Accept Memories in Stone
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Su'meera|r
.goto 2413,56.10,24.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Su'meera|r
.complete 91136,1 
.skipgossipid 134219
.target Su'meera
step
#label PerilAmongPetalsZZ
#loop
.goto 2413,56.10,24.83,10,0
.goto 2413,55.93,25.62,10,0
>>Kill the incoming waves of enemies
.complete 91136,2 
.mob Perturbed Petalwing
.mob Neekat
.mob Wrathful Sap Weaver
.mob Indignant Grovewarden
.mob Perturbed Petalwing
.mob Lasher
.mob Enraged Thornguard
step
#label PerilAmongPetalsZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Su'meera|r
.goto 2413,55.71,26.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Su'meera|r outside the cave |cRXP_WARN_on a rock below after the roleplay|r.
.turnin 91136 >>Turn in Memories in Stone
.target Su'meera
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Haranir Never Say Die
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#label HaranirNeverSayDieA
#arrowtext Talk to\n|cRXP_FRIENDLY_Shao'mal|r
.goto 2413,48.76,44.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shao'mal|r
.accept 91550 >>Accept A Game of Silence and Shadow
.target Shao'mal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Shao'mal|r
.goto 2413,48.76,44.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shao'mal|r
.complete 91550,1 
.skipgossipid 134812
.target Shao'mal
step
.goto 2413,49.55,43.11
#arrowtext Click on the\n|cRXP_PICK_Wenalo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wenalo|r |cRXP_WARN_behind a flower|r.
.complete 91550,3,1 
.target Wenalo
step
.goto 2413,50.38,40.79
#arrowtext Click on\n|cRXP_PICK_Ilomai|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ilomai|r.
.complete 91550,3,2 
.target Ilomai
step
.goto 2413,51.37,41.55
#arrowtext Click on\n|cRXP_PICK_Shao'mal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Shao'mal|r |cRXP_WARN_on the first layer of the mushroom in a corner|r.
.complete 91550,3,3 
.target Shao'mal
step
.goto 2413,51.73,39.54
#arrowtext Click on\n|cRXP_PICK_Nayeli|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Nayeli|r |cRXP_WARN_behind and under a mushroom|r.
.complete 91550,3,4 
.target Nayeli
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nayeli|r
.goto 2413,53.90,41.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nayeli|r
.turnin 91550 >>Turn in A Game of Silence and Shadow
.target Nayeli
.accept 91551 >>Accept De-nest-stration
.accept 91552 >>Accept Feathered Fury
step
#hidewindow
#completewith Petalwings
#loop
.goto 2413,54.7,42.75,30,0
.goto 2413,55.66,44.36,30,0
.goto 2413,55.15,45.95,30,0
.goto 2413,55.31,47.93,30,0
.goto 2413,56.42,47.71,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Petalwings|r
.complete 91552,1 
.mob Territorial Petalwing
.mob Pernicious Petalwing
step
#arrowtext Click on the\n|cRXP_PICK_Nests|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nests|r
.complete 91551,1 
step
#label Petalwings
>>Kill |cRXP_ENEMY_Petalwings|r
.complete 91552,1 
.mob Territorial Petalwing
.mob Pernicious Petalwing
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nayeli|r
.goto 2413,57.30,49.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nayeli|r
.turnin 91551 >>Turn in De-nest-stration
.target Nayeli
.turnin 91552 >>Turn in Feathered Fury
.accept 91553 >>Accept Haranir Never Say Die!
step
.goto 2413,57.85,49.61
>>Kill |cRXP_ENEMY_Behemoth Petalwing|r
.complete 91553,1 
.mob Behemoth Petalwing
step
#label HaranirNeverSayDieZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Shao'mal|r
.goto 2413,58.44,49.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shao'mal|r
.turnin 91553 >>Turn in Haranir Never Say Die!
.target Shao'mal
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Harandar's Kitchen
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#label FreshGarden
#arrowtext Talk to\n|cRXP_FRIENDLY_Yu'relen|r
.goto 2413,40.87,23.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yu'relen|r
.accept 91585 >>Accept Fresh from the Garden
.target Yu'relen
.accept 91586 >>Accept Soil-Based Alternatives
.accept 91587 >>Accept Carcass Cuisine
step
#hidewindow
#completewith Frillfish
#loop
.goto 2413,40.24,23,10,0
.goto 2413,39.61,22.96,10,0
.goto 2413,38.98,22.62,30,0
.goto 2413,39.7,24.51,30,0
.goto 2413,40.09,25.92,30,0
.goto 2413,40.76,24.14,20,0
+1
step
#completewith Sporeglider Bloomterror
>>Kill |cRXP_ENEMY_Frothing Frillfish|r and |cRXP_ENEMY_Delectable Root Drifter|r
*Loot them for |T970840:0|t[|cRXP_LOOT_Frillfish Fillet|r] and |T3007472:0|t[|cRXP_LOOT_Root Drift Jelly|r].
.complete 91585,1 
.complete 91585,2 
.mob Frothing Frillfish
.mob Delectable Root Drifter
step
#completewith Sporeglider Bloomterror
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r
.complete 91586,1 
step
#label Sporeglider Bloomterror
>>Kill |cRXP_ENEMY_Sporeglider Bloomterror|r
*Loot it for |T133719:0|t[|cRXP_LOOT_Corpse Rind|r].
.complete 91587,1 
.complete 91587,2 
.mob Sporeglider Bloomterror
step
#completewith next
>>Kill |cRXP_ENEMY_Frothing Frillfish|r and |cRXP_ENEMY_Delectable Root Drifter|r
*Loot them for |T970840:0|t[|cRXP_LOOT_Frillfish Fillet|r] and |T3007472:0|t[|cRXP_LOOT_Root Drift Jelly|r].
.complete 91585,1 
.complete 91585,2 
.mob Frothing Frillfish
.mob Delectable Root Drifter
step
#arrowtext Click on the\n|cRXP_PICK_Soil|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r
.complete 91586,1 
step
#label Frillfish
>>Kill |cRXP_ENEMY_Frothing Frillfish|r and |cRXP_ENEMY_Delectable Root Drifter|r
*Loot them for |T970840:0|t[|cRXP_LOOT_Frillfish Fillet|r] and |T3007472:0|t[|cRXP_LOOT_Root Drift Jelly|r].
.complete 91585,1 
.complete 91585,2 
.mob Frothing Frillfish
.mob Delectable Root Drifter
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Yu'relen|r
.goto 2413,40.88,23.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yu'relen|r
.turnin 91585 >>Turn in Fresh from the Garden
.target Yu'relen
.turnin 91586 >>Turn in Soil-Based Alternatives
.turnin 91587 >>Turn in Carcass Cuisine
.accept 91588 >>Accept Harandar's Kitchen
step
.goto 2413,41.05,23.53
#arrowtext Click on the\n|cRXP_PICK_Campfire|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Campfire|r
.complete 91588,3 
step
.goto 2413,40.19,22.66
#arrowtext Click on the\n|cRXP_PICK_Knife|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Knife|r
.complete 91588,2 
step
.goto 2413,39.72,21.92
#arrowtext Click on the\n|cRXP_PICK_Salad|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Salad|r
.complete 91588,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Yu'relen|r
.goto 2413,40.87,23.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yu'relen|r.
.turnin 91588 >>Turn in Harandar's Kitchen
.accept 91589 >>Accept Root Dash Delivery
.target Yu'relen
step
#label RootDash
.goto 2413,40.76,23.16
#arrowtext Click on the\n|cRXP_PICK_Crate|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 91589,1 
step
#loop
.goto 2413,36.54,26.85,5,0
.goto 2413,36.68,26.9,5,0
#arrowtext Click on the\n|cRXP_PICK_Food|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Food|r
.complete 91589,4 
.complete 91589,5 
.complete 91589,3 
.complete 91589,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Yu'relen|r
.goto 2413,36.66,26.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yu'relen|r
.turnin 91589 >>Turn in Root Dash Delivery
.target Yu'relen
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Silence at Fungara Village
#internal
step
.isOnQuest 91375
.goto 2413,43.91,71.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghikal|r.
.turnin 91375 >>Turn in The Silence at Fungara Village
.target Ghikal
step
#label Little Monsters
#arrowtext Talk to\n|cRXP_FRIENDLY_Ghikal|r
.goto 2413,43.91,71.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghikal|r
.accept 91376 >>Accept Little Monsters
.target Ghikal
.accept 91377 >>Accept Spawn of the Dead
step
#hidewindow
#completewith Strange Mycelium
#loop
.goto 2413,44.71,71.27,30,0
.goto 2413,45.37,70.36,30,0
.goto 2413,46.69,70.28,30,0
.goto 2413,46.67,68.58,30,0
.goto 2413,44.71,67.07,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Mushrooms|r
*Loot them for |T236158:0|t[|cRXP_LOOT_Strange Mycelium|r].
.complete 91376,1 
.mob Decanimated Rotseeker
.mob Decanimated Blightbringer
.mob Decanimated Rotling
step
#arrowtext Click on the\n|cRXP_PICK_Blooming Corpse|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blooming Corpse|r
*|cRXP_WARN_Kill the ones turning hostile|r
.complete 91377,1 
.mob Blooming Corpse
step
#label Strange Mycelium
>>Kill |cRXP_ENEMY_Mushrooms|r
*Loot them for |T236158:0|t[|cRXP_LOOT_Strange Mycelium|r].
.complete 91376,1 
.mob Decanimated Rotseeker
.mob Decanimated Blightbringer
.mob Decanimated Rotling
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ghikal|r
.goto 2413,44.13,66.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghikal|r
.turnin 91376 >>Turn in Little Monsters
.target Ghikal
.turnin 91377 >>Turn in Spawn of the Dead
.accept 91378 >>Accept You Are Legend
.accept 91379 >>Accept Decayed Land
step
#hidewindow
#completewith Decanimated creatures
#loop
.goto 2413,43.67,65.5,15,0
.goto 2413,42.66,65.92,15,0
.goto 2413,42.2,66.47,15,0
.goto 2413,42.25,67.24,15,0
.goto 2413,42.87,67.44,15,0
.goto 2413,43.81,66.85,15,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Mushrooms|r
.complete 91378,1 
.mob Hulking Husk
.mob Fruiting Mycelium
.mob Shambling Rot-Husk
.mob Limping Spore-Husk
step
#arrowtext Click on the\n|cRXP_PICK_Mushrooms|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r
.complete 91379,1 
step
#label Decanimated creatures
>>Kill |cRXP_ENEMY_Mushrooms|r
.complete 91378,1 
.mob Hulking Husk
.mob Fruiting Mycelium
.mob Shambling Rot-Husk
.mob Limping Spore-Husk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ghikal|r
.goto 2413,44.13,66.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghikal|r
.turnin 91379 >>Turn in Decayed Land
.turnin 91378 >>Turn in You Are Legend
.accept 91381 >>Accept Reticent Evil
.target Ghikal
step
.goto 2413,45.77,66.80
#arrowtext Click on the\n|cRXP_PICK_Mushroom|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushroom|r inside the water.
.complete 91381,1 
step
.goto 2413,45.77,66.80
>>Kill |cRXP_ENEMY_Zombified Guardian|r
.complete 91381,2 
.mob Zombified Guardian
step
#label Reticent Evil
#arrowtext Talk to\n|cRXP_FRIENDLY_Ghikal|r
.goto 2413,44.12,66.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghikal|r
.turnin 91381 >>Turn in Reticent Evil
.target Ghikal
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Cultivating Hope
#internal
step
#label SojournerCampaignFormerRootwarden
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,34.88,24.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r
.accept 91872 >>Accept The Former Rootwarden
.target Hagar
step
#completewith next
#label Former Rootwarden
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,35.54,25.21,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r
.turnin 91872 >>Turn in The Former Rootwarden
.accept 91873 >>Accept Buffer Zone
.disablecheckbox
.target Hagar
step
#completewith Former Rootwarden
.goto 2413,42.55,34.11,700 >>Leave the building
step
#requires Former Rootwarden
#label The Former Rootwarden2
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,42.55,34.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r
.turnin 91872 >>Turn in The Former Rootwarden
.accept 91873 >>Accept Buffer Zone
.target Hagar
step
#loop
.goto 2413,42.78,35.49,30,0
.goto 2413,43.66,31.43,30,0
.goto 2413,40.78,33.15,30,0
>>Kill |cRXP_ENEMY_Pests|r
.complete 91873,1 
.mob Wandering Stalker
.mob Foraging Potatoad
.mob Insatiable Saptor
.mob Voracious Thornmaw
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,42.32,34.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r
.turnin 91873 >>Turn in Buffer Zone
.target Hagar
.accept 91875 >>Accept Natural Remedy
step
#loop
.goto 2413,41.51,34.16,30,0
.goto 2413,42.17,35.92,30,0
.goto 2413,43.08,33.55,30,0
.goto 2413,41.74,30.68,30,0
.goto 2413,40.88,27.59,30,0
>>Kill |cRXP_ENEMY_Wandering Stalker|r
*Loot them for |T5929743:0|t[|cRXP_LOOT_Verdant Stalker Sludge|r].
.complete 91875,1 
.mob Wandering Stalker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,42.44,34.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r
.turnin 91875 >>Turn in Natural Remedy
.target Hagar
.accept 91874 >>Accept Flare Up
step
#loop
.goto 2413,38.56,38.41,30,0
.goto 2413,38.19,38.98,30,0
.goto 2413,38.93,39.43,30,0
.goto 2413,37.54,40.45,30,0
.goto 2413,36.7,40.8,30,0
.goto 2413,34.1,41.32,30,0
.goto 2413,33.88,44.04,30,0
.goto 2413,35.1,45.48,30,0
.goto 2413,35.6,45.47,30,0
.goto 2413,36.32,44.16,30,0
.goto 2413,35.77,45.48,30,0
.goto 2413,36.28,45.51,30,0
.goto 2413,36.84,47,30,0
.goto 2413,36.96,47.64,30,0
.goto 2413,37.69,46.41,30,0
.goto 2413,36.97,45.93,30,0
.goto 2413,37.27,44.7,30,0
>>Fly over the branches fire
.complete 91874,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,42.58,33.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r
.turnin 91874 >>Turn in Flare Up
.accept 91876 >>Accept Tending Hope
.target Hagar
step
#loop
.goto 2413,42.71,33.92,10,0
.goto 2413,42.62,33.52,10,0
.goto 2413,42.4,33.6,10,0
.goto 2413,42.25,33.99,10,0
.goto 2413,42.41,34.31,10,0
.goto 2413,42.67,34.41,10,0
#arrowtext Click on the\n|cRXP_PICK_Root Segments|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Root Segments|r
.complete 91876,1 
step
#label TendingHope
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,42.58,33.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r
.turnin 91876 >>Turn in Tending Hope
.target Hagar
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Hunter's Rights
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ketan|r
.goto 2413,69.42,52.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ketan|r
.accept 92882 >>Accept A Hunter's Plight
.target Ketan
step
#completewith next
#label Elder Akazi
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Akazi|r
.goto 2413,70.3,50.86,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Akazi|r
.complete 92882,1 
.target Elder Akazi
step
#completewith Elder Akazi
.goto 2413,70.47,50.71,15 >>Enter the building
step
#requires Elder Akazi
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Akazi|r
.goto 2413,70.47,50.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Akazi|r
.complete 92882,1 
.target Elder Akazi
.skipgossipid 136773
.skipgossipid 136774
step
#label SojournerCampaignPlightEnd1
#arrowtext Talk to\n|cRXP_FRIENDLY_Akazi|r
.goto 2413,70.47,50.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akazi|r
.turnin 92882 >>Turn in A Hunter's Plight
.target Akazi
.accept 92883 >>Accept A Hunter's Duty
step
#hidewindow
#completewith Grovecrawler Fangs
#loop
.goto 2413,68.73,47.13,30,0
.goto 2413,68.26,44.14,30,0
.goto 2413,69.83,41.23,30,0
.goto 2413,71.59,41.77,30,0
.goto 2413,71.07,43.49,30,0
+1
step
#completewith Tail Spore
>>Kill |cRXP_ENEMY_Slithering Grovecrawler|r
*Loot them for |T134298:0|t[|cRXP_LOOT_Grovecrawler Fangs|r].
.complete 92883,2 
.mob Slithering Grovecrawler
step
#completewith Tail Spore
>>Kill |cRXP_ENEMY_Violet Chloroceros|r
*Loot them for |T3586015:0|t[|cRXP_LOOT_Chloroceros Bone|r].
.complete 92883,1 
.mob Violet Chloroceros
step
#label Tail Spore
#arrowtext Click on the\n|cRXP_PICK_Tails|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tails|r
.complete 92883,4 
step
#completewith next
>>Kill |cRXP_ENEMY_Slithering Grovecrawler|r
*Loot them for |T134298:0|t[|cRXP_LOOT_Grovecrawler Fangs|r].
.complete 92883,2 
.mob Slithering Grovecrawler
step
>>Kill |cRXP_ENEMY_Violet Chloroceros|r
*Loot them for |T3586015:0|t[|cRXP_LOOT_Chloroceros Bone|r].
.complete 92883,1 
.mob Violet Chloroceros
step
#label Grovecrawler Fangs
>>Kill |cRXP_ENEMY_Slithering Grovecrawler|r
*Loot them for |T134298:0|t[|cRXP_LOOT_Grovecrawler Fangs|r].
.complete 92883,2 
.mob Slithering Grovecrawler
step
#loop
.goto 2413,72.17,40.83,30,0
.goto 2413,72.55,38.18,30,0
.goto 2413,71.69,36.21,30,0
.goto 2413,71.29,38.9,30,0
>>Kill |cRXP_ENEMY_Lashers|r
*Loot them for |T134218:0|t[|cRXP_LOOT_Lasher Vines|r].
.complete 92883,3 
.mob Spiteful Lasher
step
#label SojournerCampaignAHuntersDuty
#arrowtext Talk to\n|cRXP_FRIENDLY_Ketan|r
.goto 2413,69.99,52.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ketan|r
.turnin 92883 >>Turn in A Hunter's Duty
.target Ketan
.accept 92884 >>Accept A Hunter's Weapon
step
.goto 2413,70.02,52.7
#arrowtext Click on the\n|cRXP_PICK_Bone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bone|r
.complete 92884,1 
step
#completewith next
#label Sporeglider's Tail Spore
>>Move to the next position
.complete 92884,2 
step
#completewith Sporeglider's Tail Spore
.goto 2413,70.02,52.66
.cast 1266399 >>Click on the |cRXP_PICK_Tail Spore|r
step
#requires Sporeglider's Tail Spore
.goto 2413,69.96,52.79
>>Move to the next position
.complete 92884,2 
step
.goto 2413,69.96,52.79
#arrowtext Click on the\n|cRXP_PICK_Spear|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r
.complete 92884,3 
step
#completewith next
#hidewindow
.gossipoption 136842 >>1
.timer 10,RP
step
#completewith next
#label Ka'dani Spear
#arrowtext Talk to\n|cRXP_FRIENDLY_Akazi|r
.goto 2413,70.27,50.89,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akazi|r
.complete 92884,4 
.target Akazi
step
#completewith Ka'dani Spear
.goto 2413,70.48,50.71,15 >>Enter the House
step
#requires Ka'dani Spear
#completewith next
#hidewindow
.gossipoption 136842 >>1
.timer 7,RP
step
#requires Ka'dani Spear
#arrowtext Talk to\n|cRXP_FRIENDLY_Akazi|r
.goto 2413,70.48,50.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akazi|r
.complete 92884,4 
.target Akazi
step
#label Hunter's Weapon
#arrowtext Talk to\n|cRXP_FRIENDLY_Akazi|r
.goto 2413,70.47,50.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akazi|r
.turnin 92884 >>Turn in A Hunter's Weapon
.target Akazi
.accept 92885 >>Accept A Hunter's Prey
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ketan|r
.goto 2413,69.02,54.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ketan|r
.complete 92885,1 
.skipgossipid 136855
.target Ketan
step
.goto 2413,68.59,54.03
>>Kill |cRXP_ENEMY_Radooni|r
.complete 92885,2 
.mob Radooni
step
#label SojournerCampaignAHuntersDuty2
#arrowtext Talk to\n|cRXP_FRIENDLY_Akazi|r
.goto 2413,70.47,50.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akazi|r inside the building.
.turnin 92885 >>Turn in A Hunter's Prey
.target Akazi
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Palette of Feelings
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#label SojournerCampaignPigment1
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Shay'neia|r
.goto 2413,70.53,51.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Shay'neia|r
.accept 92694 >>Accept Dusk Among Pigments
.target Zur'ashar Shay'neia
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orn'shan|r
.goto 2413,74.03,53.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orn'shan|r
.turnin 92694 >>Turn in Dusk Among Pigments
.target Orn'shan
.accept 92695 >>Accept The Stroke of Storms
step
.goto 2413,72.28,55.69
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 92695,1 
step
#loop
.goto 2413,73.42,53.57,30,0
.goto 2413,71.53,53.66,30,0
.goto 2413,71.59,55.44,30,0
>>Kill |cRXP_ENEMY_Paint-Crazed|r
#arrowtext Click on\n|cRXP_PICK_Objects|r
>>|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Objects|r
.complete 92695,2 
.mob Paint-Crazed Lasher
.mob Paint-Crazed Potatoad
.mob Paint-Crazed Skipper
step
.goto 2413,72.28,55.69
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 92695,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orn'shan|r
.goto 2413,72.38,55.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orn'shan|r
.turnin 92695 >>Turn in The Stroke of Storms
.target Orn'shan
.accept 92696 >>Accept Colors Born Anew
step
#hidewindow
#completewith Mushroom Pigment
#loop
.goto 2413,72.72,57.16,30,0
.goto 2413,72.15,58.77,30,0
.goto 2413,71.02,58.17,30,0
.goto 2413,71.63,55.97,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Mushrooms|r
*Loot them for |T134524:0|t[|cRXP_LOOT_Mushroom Pigment|r].
.complete 92696,1 
.mob Invasive Lashroom
.mob Noxious Lashroom
step
#arrowtext Click on the\n|cRXP_PICK_Flower|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r and pull them out.
.complete 92696,2 
step
#label Mushroom Pigment
>>Kill |cRXP_ENEMY_Mushrooms|r
*Loot them for |T134524:0|t[|cRXP_LOOT_Mushroom Pigment|r].
.complete 92696,1 
.mob Invasive Lashroom
.mob Noxious Lashroom
step
#label SojournerCampaignColors1
#arrowtext Talk to\n|cRXP_FRIENDLY_Orn'shan|r
.goto 2413,72.38,55.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orn'shan|r
.turnin 92696 >>Turn in Colors Born Anew
.target Orn'shan
.accept 92697 >>Accept Hues of Tomorrow
step
#completewith next
#label Paintings created
>>Click on the tiles to move the brush through each dot
.complete 92697,1 
step
#completewith Paintings created
.goto 2413,74.01,53.21
.cast 298624 >>Click on the |cRXP_PICK_Cauldron|r
step
#requires Paintings created
#arrowtext Click on the\ntiles
>>Click on the tiles to move the brush through each dot
.complete 92697,1 
step
#completewith next
#label Hues of Tomorrow
#arrowtext Talk to\n|cRXP_FRIENDLY_Orn'shan|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orn'shan|r
.turnin 92697 >>Turn in Hues of Tomorrow
.target Orn'shan
step
#completewith Hues of Tomorrow
.goto 2413,74.00,53.15
.aura -1257125 >>Use |T4200126:0|t[Exit]
step
#requires Hues of Tomorrow
#label SojournerCampaignPigment2
#arrowtext Talk to\n|cRXP_FRIENDLY_Orn'shan|r
.goto 2413,74.00,53.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orn'shan|r
.turnin 92697 >>Turn in Hues of Tomorrow
.target Orn'shan
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Predator Reintroduction
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'tar|r
.goto 2413,69.54,50.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'tar|r
.accept 92864 >>Accept Drift Them Away
.target Ney'tar
.accept 92865 >>Accept Feeding the Buds
step
#loop
.goto 2413,70.59,44.21,30,0
.goto 2413,70.6,41.66,30,0
.goto 2413,69.01,41.58,30,0
.goto 2413,68.29,44.54,30,0
.goto 2413,69.42,45.93,30,0
>>Kill |cRXP_ENEMY_Violet Chloroceros|r
*Loot them for |T1029740:0|t[|cRXP_LOOT_Chloroceros Buds|r].
.complete 92865,1 
.mob Violet Chloroceros
step
#hidewindow
#label SojournerCampaignDrifterStart1
#completewith Cascade Drifter
#loop
.goto 2413,70.3,39.9,10,0
.goto 2413,70.12,39.47,10,0
.goto 2413,69.77,39.56,10,0
.goto 2413,69.72,39.18,10,0
.goto 2413,69.28,39.53,10,0
.goto 2413,68.83,39.3,10,0
.goto 2413,68.8,37.9,30,0
.goto 2413,70.53,38.6,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Cascade Drifter|r
.complete 92864,1 
.mob Cascade Drifter
step
#arrowtext Click on the\n|cRXP_PICK_Sacks|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sacks|r
.complete 92864,2 
step
#label Cascade Drifter
>>Kill |cRXP_ENEMY_Cascade Drifter|r
.complete 92864,1 
.mob Cascade Drifter
step
#label SojournerCampaignfed1
.goto 2413,69.55,50.57
>>Use the |T4573082:0|t|cRXP_WARN_[ExtraActionButton]|r and aim it on the |cRXP_FRIENDLY_Hydra's|r.
.complete 92865,5 
.complete 92865,4 
.complete 92865,3 
.complete 92865,2 
.target Grumpy
.target F'liks
.target T'omm
.target N'ala
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'tar|r
.goto 2413,69.54,50.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'tar|r
.turnin 92865 >>Turn in Feeding the Buds
.target Ney'tar
.turnin 92864 >>Turn in Drift Them Away
.accept 92866 >>Accept Re-Hydra-ted
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hydra's|r
.goto 2413,69.51,50.51,5,0
.goto 2413,69.37,50.72,10,0
.goto 2413,69.86,50.46,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hydra's|r
.complete 92866,1 
.skipgossipid 137321
.skipgossipid 137325
.skipgossipid 137324
.skipgossipid 137323
.target Grumpy
.target F'liks
.target T'omm
.target N'ala
step
.goto 2413,69.92,45.44
#arrowtext |cFFFCDC00Mount right after|r\nClick on\n|cRXP_PICK_T'omm|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_T'omm|r
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 92866,4 
.target T'omm
step
.goto 2413,71.26,41.11
#arrowtext |cFFFCDC00Mount right after|r\nClick on\n|cRXP_PICK_F'liks|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_F'liks|r
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 92866,3 
.target F'liks
step
.goto 2413,71.19,40.32
#arrowtext |cFFFCDC00Mount right after|r\nClick on\n|cRXP_PICK_N'ala|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_N'ala|r
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 92866,5 
.target N'ala
step
.goto 2413,68.96,42.09
#arrowtext |cFFFCDC00Mount right after|r\nClick on\n|cRXP_PICK_Grumpy|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Grumpy|r
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 92866,2 
.target Grumpy
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ney'tar|r
#label ReHydrated
.goto 2413,69.54,50.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'tar|r
.turnin 92866 >>Turn in Re-Hydra-ted
.target Ney'tar
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bloomtown
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hannan|r
.goto 2413,31.40,64.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannan|r
.accept 92732 >>Accept Light Disturbance
.target Hannan
step
#label Light Disturbance
#arrowtext Talk to\n|cRXP_FRIENDLY_Luminescent Corpse|r
.goto 2413,40.64,62.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luminescent Corpse|r
.turnin 92732 >>Turn in Light Disturbance
.target Luminescent Corpse
.accept 92736 >>Accept Light Stroll
step
.goto 2413,40.86,64.01
#arrowtext Click on the\n|cRXP_PICK_Paw|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Paw|r
.complete 92736,1,1 
step
.goto 2413,40.84,65.29
#arrowtext Click on the\n|cRXP_PICK_Spores|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spores|r
.complete 92736,1,2 
step
.goto 2413,41.23,66.66
#arrowtext Click on the\n|cRXP_PICK_Earth|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Earth|r
.complete 92736,1,3 
step
.goto 2413,41.66,67.44
#arrowtext Click on the\n|cRXP_PICK_Fallen Potatoad|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fallen Potatoad|r
.complete 92736,1,4 
.target Fallen Potatoad
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hannan|r
.goto 2413,41.68,67.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannan|r
.turnin 92736 >>Turn in Light Stroll
.target Hannan
.accept 92737 >>Accept Light Carnage
.accept 92738 >>Accept Potatoad Tots
step
#hidewindow
#completewith Lightfrenzied Potatoad
#loop
.goto 2413,39.7,69.1,30,0
.goto 2413,37.74,69.95,30,0
.goto 2413,38.18,72.07,30,0
.goto 2413,37.55,73.58,30,0
.goto 2413,39.79,69.08,30,0
.goto 2413,41.37,68.33,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Lightfrenzied Potatoad|r
.complete 92737,1 
.mob Lightfrenzied Potatoad
step
#arrowtext Click on the\n|cRXP_PICK_Lightspored Potadpole|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightspored Potadpole|r
.complete 92738,1 
.mob Lightspored Potadpole
step
#label Lightfrenzied Potatoad
>>Kill |cRXP_ENEMY_Lightfrenzied Potatoad|r
.complete 92737,1 
.mob Lightfrenzied Potatoad
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hannan|r
.goto 2413,37.34,72.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannan|r
.turnin 92738 >>Turn in Potatoad Tots
.turnin 92737 >>Turn in Light Carnage
.accept 92739 >>Accept O.K. Bloomer
.target Hannan
step
.goto 2413,36.01,74.23
>>Kill |cRXP_ENEMY_Adzikel|r inside the cave.
.complete 92739,1 
.mob Adzikel
step
#label O.K. Bloomer
#arrowtext Talk to\n|cRXP_FRIENDLY_Hannan|r
.goto 2413,31.40,64.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannan|r
.turnin 92739 >>Turn in O.K. Bloomer
.target Hannan
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Grudge Pit 2
#internal
step
#optional
.isQuestAvailable account,86930
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Of Caves and Cradles (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Of Caves and Cradles (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Motta|r
.goto 2413,70.33,52.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Motta|r
.accept 90615 >>Accept Be Grudge You
.target Motta
step
#completewith next
#label You Strong?
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90615 >>Turn in Be Grudge You
.target Boletus
.accept 90616 >>Accept You Strong?
.disablecheckbox
step
#completewith You Strong?
.goto 2413,72.09,64.01,15 >>Enter the Roots
step
#requires You Strong?
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.77,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90615 >>Turn in Be Grudge You
.target Boletus
.accept 90616 >>Accept You Strong?
step
#label YouStrong?Start1
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.77,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.target Boletus
.accept 90616 >>Accept You Strong?
step
#loop
.goto 2413,72.07,65.43,30,0
.goto 2413,71.92,66.79,30,0
.goto 2413,70.98,66.4,30,0
.goto 2413,71.46,64.81,30,0
>>Kill |cRXP_ENEMY_Mushrooms|r
.complete 90616,1 
.mob Battling Rotseeker
.mob Battling Mycomancer
.mob Battling Moldstalker
.mob Opportunistic Sporeglider
step
#completewith next
#label A Few Fun Guys
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90616 >>Turn in You Strong?
.target Boletus
.accept 90617 >>Accept A Few Fun Guys
.disablecheckbox
step
#completewith A Few Fun Guys
.goto 2413,72.05,64.07,15 >>Enter the Roots
step
#requires A Few Fun Guys
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.78,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90616 >>Turn in You Strong?
.target Boletus
.accept 90617 >>Accept A Few Fun Guys
step
#loop
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r, |cRXP_FRIENDLY_Ziny|r, and |cRXP_FRIENDLY_Brakko|r
.goto 2413,71.44,64.89,15,0
.goto 2413,70.71,66.01,15,0
.goto 2413,70.91,66.57,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r, |cRXP_FRIENDLY_Ziny|r and |cRXP_FRIENDLY_Brakko|r.
.complete 90617,2 
.skipgossipid 135601
.skipgossipid 135600
.skipgossipid 135599
.target Brakko
.target Ziny
.target Tuktuk
step
#completewith next
#label What Doesn't Kill Them
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90617 >>Turn in A Few Fun Guys
.target Boletus
.accept 90619 >>Accept What Doesn't Kill Them
.disablecheckbox
step
#completewith What Doesn't Kill Them
.goto 2413,72.04,64.05,15 >>Enter the Roots
step
#requires What Doesn't Kill Them
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.79,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90617 >>Turn in A Few Fun Guys
.target Boletus
.accept 90619 >>Accept What Doesn't Kill Them
step
#loop
#arrowtext Talk to\n|cRXP_FRIENDLY_Brakko|r, |cRXP_FRIENDLY_Ziny|r, and |cRXP_FRIENDLY_Tuktuk|r
.goto 2413,72.14,62.88,10,0
.goto 2413,72.07,62.53,10,0
.goto 2413,71.89,62.67,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakko|r, |cRXP_FRIENDLY_Ziny|r and |cRXP_FRIENDLY_Tuktuk|r and defeat them.
*|cRXP_WARN_Switch to WM/WM Off if the npcs are bugged|r
.complete 90619,1 
.complete 90619,2 
.complete 90619,3 
.skipgossipid 135664
.skipgossipid 135666
.skipgossipid 135663
.target Brakko
.target Ziny
.target Tuktuk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Brakko|r
.goto 2413,72.13,62.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakko|r
.turnin 90619 >>Turn in What Doesn't Kill Them
.target Brakko
.accept 91450 >>Accept We Ready Now
step
#completewith next
#label We Ready Now
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 91450 >>Turn in We Ready Now
.target Boletus
step
.isOnQuest 91450
#completewith We Ready Now
.goto 2413,72.05,63.9,15 >>Enter the Roots
step
#requires We Ready Now
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.78,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 91450 >>Turn in We Ready Now
.target Boletus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r
.goto 2413,72.43,63.44,10,0
.goto 2413,71.81,63.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r
.accept 91270 >>Accept The Most Important Thing
.target Tuktuk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Brakko|r, |cRXP_FRIENDLY_Ziny|r, and |cRXP_FRIENDLY_Tuktuk|r
.goto 2413,71.81,63.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakko|r, |cRXP_FRIENDLY_Ziny|r and |cRXP_FRIENDLY_Tuktuk|r and defeat them.
.complete 91270,3 
.complete 91270,2 
.complete 91270,1 
.skipgossipid 136989
.skipgossipid 136986
.skipgossipid 136991
.target Brakko
.target Ziny
.target Tuktuk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r
.goto 2413,71.81,63.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r
.complete 91270,4 
.skipgossipid 136990
.skipgossipid 135673
.target Tuktuk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r
.goto 2413,71.80,63.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r
.turnin 91270 >>Turn in The Most Important Thing
.target Tuktuk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.78,64.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.accept 90620 >>Accept To the Ring
.target Boletus
step
#completewith next
.goto 2413,72.27,65.19,15,0
>>Go through the tunnel
.complete 90620,2 
step
.goto 2413,71.12,65.72
>>Kill the waves of enemies
.complete 90620,3 
.mob Sporko
.mob Vubvub
.mob Vonto
.mob Jomjom
.mob Kipkip
.mob Tuffcap
.mob Skullcap
.mob Fizzcap
.mob Glimmercap
step
#completewith next
#label To the Ring
#arrowtext Talk to\n|cRXP_FRIENDLY_Brakko|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakko|r
.turnin 90620 >>Turn in To the Ring
.target Brakko
step
.isOnQuest 90620
#completewith To the Ring
.goto 2413,72.06,64.06,15 >>Enter the Cave
step
#requires To the Ring
#arrowtext Talk to\n|cRXP_FRIENDLY_Brakko|r
.goto 2413,71.76,63.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakko|r
.turnin 90620 >>Turn in To the Ring
.target Brakko
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.79,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.accept 90621 >>Accept Tiny Heroes' Journeys
.target Boletus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r, |cRXP_FRIENDLY_Brakko|r, and |cRXP_FRIENDLY_Ziny|r
.goto 2413,71.81,63.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r, |cRXP_FRIENDLY_Brakko|r and |cRXP_FRIENDLY_Ziny|r
.accept 92618 >>Accept Mushrooming Confidence
.accept 92616 >>Accept Mushrooming Courage
.accept 92617 >>Accept Mushrooming Resilience
.target Tuktuk
.target Brakko
.target Ziny
step
#loop
.goto 2413,73.22,62.38,40,0
.goto 2413,71.15,62.28,40,0
.goto 2413,70.03,64.51,40,0
.goto 2413,68.09,63.67,40,0
.goto 2413,68.35,67.92,40,0
.goto 2413,71.06,68.48,40,0
>>Kill |cRXP_ENEMY_Sporegliders|r, |cRXP_ENEMY_Grazing Root Drifter|r, |cRXP_ENEMY_Decomposing Shambler|r and |cRXP_ENEMY_Scavenging Stalker|r
.complete 92616,1 
.complete 92617,1 
.mob Grazing Root Drifter
.mob Foraging Sporeglider
.mob Decomposing Shambler
.mob Scavenging Stalker
step
.goto 2413,67.67,67.37
#title |cFFFCDC00Follow the Arrow|r
.complete 92618,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r
.goto 2413,67.67,67.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r
.complete 92618,2 
.skipgossipid 136164
.skipgossipid 136163
.skipgossipid 136162
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r
.goto 2413,67.67,67.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r
.complete 92618,3 
.skipgossipid 136164
.target Tuktuk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tuktuk|r, |cRXP_FRIENDLY_Brakko|r, and |cRXP_FRIENDLY_Ziny|r
.goto 2413,67.66,67.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tuktuk|r, |cRXP_FRIENDLY_Brakko|r and |cRXP_FRIENDLY_Ziny|r.
.turnin 92618 >>Turn in Mushrooming Confidence
.turnin 92616 >>Turn in Mushrooming Courage
.turnin 92617 >>Turn in Mushrooming Resilience
.target Ziny
.target Tuktuk
.target Brakko
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.78,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90621 >>Turn in Tiny Heroes' Journeys
.target Boletus
.accept 90622 >>Accept Not-Yet Defeated Champions
step
.goto 2413,71.14,65.72
#title |cFFFCDC00Follow the Arrow|r
.complete 90622,3 
step
.goto 2413,71.14,65.72
>>Kill |cRXP_ENEMY_Mushrooms|r
.complete 90622,4 
.mob Strongcap
.mob Binli
.mob Gangan
.mob Merbo
.mob Nizniz
step
#completewith next
#label Not-Yet Defeated Champions
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90622 >>Turn in Not-Yet Defeated Champions
.target Boletus
step
.isOnQuest 90622
#completewith Not-Yet Defeated Champions
.goto 2413,72,64.06,15 >>Enter the Roots
step
#requires Not-Yet Defeated Champions
#label YouStrong?End1
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.78,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r
.turnin 90622 >>Turn in Not-Yet Defeated Champions
.target Boletus
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Trials of the Shul'ka
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chua|r
.goto 2413,52.19,55.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chua|r
.accept 90824 >>Accept My Brother's Alive!
.target Chua
step
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2413,43.05,61.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r
.turnin 90824 >>Turn in My Brother's Alive!
.target En'liahn
.accept 90827 >>Accept Only the Poisonous Parts
.accept 90826 >>Accept The Healing Waters of Ahl'ua
step
#label My Brother's Alive!
#hidewindow
#completewith Phytogenic Poison Part
#loop
.goto 2413,41,57.94,10,0
.goto 2413,40.32,56.32,10,0
.goto 2413,40.38,54.54,10,0
.goto 2413,39.69,53.12,10,0
.goto 2413,40.98,52.24,10,0
.goto 2413,42.34,52.47,10,0
.goto 2413,41.48,57.52,30,0
.goto 2413,42.57,52.71,30,0
.goto 2413,44.12,59.2,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Pests|r
*Loot them for |T6012071:0|t[|cRXP_LOOT_Phytogenic Poison Part|r].
.complete 90827,1 
.mob Lethal Lasher
.mob Toxic Potatotoad
.mob Ahl'ua Chloroceros
.mob Toxic Potatotoadling
step
#arrowtext Click on the\n|cRXP_PICK_Water Fountains|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Water Fountains|r.
.complete 90826,1 
step
#label Phytogenic Poison Part
>>Kill |cRXP_ENEMY_Pests|r
*Loot them for |T6012071:0|t[|cRXP_LOOT_Phytogenic Poison Part|r].
.complete 90827,1 
.mob Lethal Lasher
.mob Toxic Potatotoad
.mob Ahl'ua Chloroceros
.mob Toxic Potatotoadling
step
#label Meeting My Mentor
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2413,43.04,61.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r
.turnin 90826 >>Turn in The Healing Waters of Ahl'ua
.target En'liahn
.turnin 90827 >>Turn in Only the Poisonous Parts
.accept 90829 >>Accept Meeting My Mentor
step
#label Turn in Meeting My Mentor
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r and |cRXP_FRIENDLY_En'liahn|r
.goto 2413,63.85,54.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r and |cRXP_FRIENDLY_En'liahn|r
.turnin 90829 >>Turn in Meeting My Mentor
.accept 90830 >>Accept The Path Will Reveal Itself
.accept 90831 >>Accept Doing Is Becoming
.target En'liahn
.target Amarakk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2413,63.86,54.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r
.complete 90830,1 
.skipgossipid 133898
.target En'liahn
step
#completewith Final Guide found
>>Kill |cRXP_ENEMY_Decaying Essence|r, |cRXP_ENEMY_Rift Shade|r and |cRXP_ENEMY_Coalesced Spirit|r.
*|TInterface/cursor/crosshair/interact.blp150|tClick on |cRXP_PICK_Portals|r and pull them away.
.complete 90831,1 
.mob Rift Shade
.mob Decaying Essence
.mob Coalesced Spirit
step
.goto 2413,63.01,55.03
#title |cFFFCDC00Follow the Arrow|r
.complete 90830,2 
step
.goto 2413,65.90,58.47
#title |cFFFCDC00Follow the Arrow|r
.complete 90830,3 
step
.goto 2413,64.50,58.52
#title |cFFFCDC00Follow the Arrow|r
.complete 90830,4 
step
.goto 2413,62.60,58.88
#title |cFFFCDC00Follow the Arrow|r
.complete 90830,5 
step
.goto 2413,61.93,59.77
#title |cFFFCDC00Follow the Arrow|r
.complete 90830,6 
step
#label Final Guide found
.goto 2413,63.49,59.98
#title |cFFFCDC00Follow the Arrow|r
.complete 90830,7 
step
#loop
.goto 2413,61.85,60.37,30,0
.goto 2413,61.2,58.22,30,0
.goto 2413,62,56.7,30,0
.goto 2413,65.01,59.84,30,0
.goto 2413,66.06,61.83,30,0
.goto 2413,65.23,63.08,30,0
>>Kill |cRXP_ENEMY_Decaying Essence|r, |cRXP_ENEMY_Rift Shade|r and |cRXP_ENEMY_Coalesced Spirit|r.
#arrowtext Click on\n|cRXP_PICK_Portals|r
*|TInterface/cursor/crosshair/interact.blp150|tClick on |cRXP_PICK_Portals|r and pull them away.
.complete 90831,1 
.mob Rift Shade
.mob Decaying Essence
.mob Coalesced Spirit
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r
.goto 2413,62.94,62.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r
.turnin 90830 >>Turn in The Path Will Reveal Itself
.target Amarakk
.turnin 90831 >>Turn in Doing Is Becoming
.accept 90832 >>Accept As Her Voice Goes Silent
step
#loop
.goto 2413,63.01,62.06,5,0
.goto 2413,62.81,62.06,5,0
#arrowtext Click on the\n|cRXP_PICK_Banners|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banners|r
.complete 90832,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2413,62.97,62.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r
.complete 90832,2 
.skipgossipid 133930
.target En'liahn
step
.goto 2413,62.87,61.13
>>Use |T2065605:0|t[Shul'ka Warding](1) on the onslaught of enemies
.complete 90832,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amarakk|r
.goto 2413,62.93,62.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amarakk|r
.turnin 90832 >>Turn in As Her Voice Goes Silent
.target Amarakk
.accept 90833 >>Accept The Final Rite
step
#completewith next
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2413,61.03,60.66,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r to assist you in combat.
.complete 90833,1 
.skipgossipid 134053
.target En'liahn
step
.goto 2413,60.77,60.70
>>Kill |cRXP_ENEMY_Morta'ka the Sundered Echo|r
.complete 90833,2 
.mob Morta'ka the Sundered Echo
step
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2413,61.55,60.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r outside the cave.
.turnin 90833 >>Turn in The Final Rite
.target En'liahn
.accept 90834 >>Accept From This Point Forward
step
#label Point Forward
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2413,63.85,54.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r
.turnin 90834 >>Turn in From This Point Forward
.target En'liahn
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Void Peers Back
#internal
step
#optional
.isQuestAvailable account,86565
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Into the Abyss (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Into the Abyss (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TheVoidPeersBackA
#arrowtext Talk to\n|cRXP_FRIENDLY_Kelia Everglow|r
.goto 2405,35.79,58.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelia Everglow|r.
.accept 88755 >>Accept Scholarly Pursuits
.target Kelia Everglow
step
#label Scholarly Pursuits
#arrowtext Talk to\n|cRXP_FRIENDLY_Matrean Dawnfall|r
.goto 2405,41.14,61.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Matrean Dawnfall|r |cRXP_WARN_after the roleplay|r.
.turnin 88755 >>Turn in Scholarly Pursuits
.accept 87388 >>Accept A Bigger Beast
.target Matrean Dawnfall
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kelia Everglow|r
.goto 2405,41.16,61.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelia Everglow|r.
.accept 87391 >>Accept Sampling the Local Fare
.target Kelia Everglow
step
#loop
.goto 2405,42.63,63.14,35,0
.goto 2405,42.13,67.00,35,0
.goto 2405,38.28,66.79,35,0
>>Kill |cRXP_ENEMY_Vicious Karion|r.
*Kill the |cRXP_ENEMY_Shredclaws|r, |cRXP_ENEMY_Ultradons|r, and |cRXP_ENEMY_Consumptor|r.
*Loot them for the |T4639592:0|t[|cRXP_LOOT_Exotic Tissue Samples|r].
.complete 87388,1 
.complete 87391,1 
.mob Vicious Karion
.mob Restless Consumptor
.mob Seeting Shredclaw
.mob Hulking Ultradon
step
.goto 2405,41.13,61.52
#arrowtext Click on the\n|cRXP_PICK_Exotic Tissue Sample|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Exotic Tissue Sample|r.
.complete 87391,2 
.timer 6.5,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Matrean Dawnfall|r and |cRXP_FRIENDLY_Kelia Everglow|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Matrean Dawnfall|r and |cRXP_FRIENDLY_Kelia Everglow|r.
.turnin 87388 >>Turn in A Bigger Beast
.goto 2405,41.14,61.54
.target +Matrean Dawnfall
.turnin 87391 >>Turn in Sampling the Local Fare
.accept 87672 >>Accept Void is in the Air
.goto 2405,41.16,61.50
.target +Kelia Everglow
.accept 88653 >>Accept Yolks on You
.goto 2405,41.14,61.54
.target +Matrean Dawnfall
step
#completewith next
#label VoidIsInTheAirA
.goto 2405,41.08,64.03,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Surge|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 87672,1,1 
step
.isOnQuest 87672
#completewith VoidIsInTheAirA
#title Enter the cave
.goto 2405,40.02,65.11,130 >>|cRXP_WARN_Enter the cave|r.
step
#requires VoidIsInTheAirA
#completewith next
>>Run over the |cRXP_PICK_eggs|r.
.complete 88653,1 
step
#requires VoidIsInTheAirA
#arrowtext Void Surges captured (1/3) |cFFFCDC00(Read Note)|r\nClick on the\n|cRXP_PICK_Void Surge|r
.goto 2405,40.02,65.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Surge|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 87672,1,1 
step
#loop
.goto 2405,40.56,65.47,12,0
.goto 2405,40.06,64.99,12,0
.goto 2405,40.50,65.00,12,0
>>Run over the |cRXP_PICK_eggs|r.
.complete 88653,1,9 
step
#completewith VoidIsInTheAirD
#label VoidIsInTheAirB
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Surge|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 87672,1,2 
step
.isOnQuest 87672
#completewith VoidIsInTheAirB
#label VoidIsInTheAirC
#title Leave the cave
.goto 2405,41.08,64.03,10 >>|cRXP_WARN_Leave the cave|r.
step
.isOnQuest 87672
#requires VoidIsInTheAirC
#completewith VoidIsInTheAirB
#label VoidIsInTheAirD
#title Enter the cave
.goto 2405,42.27,63.43,10 >>|cRXP_WARN_Enter the cave|r.
step
#requires VoidIsInTheAirB
#arrowtext Void Surges captured (2/3) |cFFFCDC00(Read Note)|r\nClick on the\n|cRXP_PICK_Void Surge|r
.goto 2405,41.53,64.14,20,0
.goto 2405,41.33,63.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Surge|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 87672,1,2 
step
#completewith VoidIsInTheAirG
#label VoidIsInTheAirE
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Surge|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 87672,1 
step
.isOnQuest 87672
#completewith VoidIsInTheAirE
#label VoidIsInTheAirF
#title Leave the cave
.goto 2405,41.51,65.34,10 >>|cRXP_WARN_Leave the cave|r.
step
.isOnQuest 87672
#requires VoidIsInTheAirF
#completewith VoidIsInTheAirE
#label VoidIsInTheAirG
#title Enter the cave
.goto 2405,41.61,66.10,10 >>|cRXP_WARN_Enter the cave|r.
step
#requires VoidIsInTheAirE
#arrowtext Void Surges captured (3/3) |cFFFCDC00(Read Note)|r\nClick on the\n|cRXP_PICK_Void Surge|r
.goto 2405,40.38,66.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Surge|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 87672,1 
step
#loop
.goto 2405,40.54,66.20,5,0
.goto 2405,40.62,66.96,12,0
>>Run over the |cRXP_PICK_eggs|r.
.complete 88653,1 
step
#completewith next
#label VoidIsInTheAirH
#arrowtext Talk to\n|cRXP_FRIENDLY_Matrean Dawnfall|r and |cRXP_FRIENDLY_Kelia Everglow|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Matrean Dawnfall|r and |cRXP_FRIENDLY_Kelia Everglow|r.
.turnin 88653 >>Turn in Yolks on You
.target +Matrean Dawnfall
.turnin 87672 >>Turn in Void is in the Air
.accept 88708 >>Accept Violent Conclusions
.disablecheckbox
.target +Kelia Everglow
step
.isOnQuest 88653,87672
#completewith VoidIsInTheAirH
#title Leave the cave
.goto 2405,41.61,66.10,10 >>|cRXP_WARN_Leave the cave|r.
step
#requires VoidIsInTheAirH
#arrowtext Talk to\n|cRXP_FRIENDLY_Matrean Dawnfall|r and |cRXP_FRIENDLY_Kelia Everglow|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Matrean Dawnfall|r and |cRXP_FRIENDLY_Kelia Everglow|r.
.turnin 88653 >>Turn in Yolks on You
.goto 2405,41.14,61.54
.target +Matrean Dawnfall
.turnin 87672 >>Turn in Void is in the Air
.accept 88708 >>Accept Violent Conclusions
.goto 2405,41.16,61.50
.target +Kelia Everglow
step
#completewith next
#label Matrean
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88708,1 
step
.isOnQuest 88708
#completewith Matrean
.goto 2405,41.14,61.54
.gossipoption 132965 >>Talk to |cRXP_FRIENDLY_Matrean Dawnfall|r.
.timer 30,RP
.target Matrean Dawnfall
step
#requires Matrean
.goto 2405,41.13,61.81
>>|cRXP_WARN_Wait for the Roleplay at the waypoint location|r.
.complete 88708,1 
step
#completewith next
#label ViolentConclusionsA
>>Kill |cRXP_ENEMY_Matrean|r.
.complete 88708,2 
.mob Matrean
step
.isOnQuest 88708
#completewith ViolentConclusionsA
#title Enter the cave
.goto 2405,39.03,67.02,10 >>|cRXP_WARN_Enter the cave|r.
step
#requires ViolentConclusionsA
.goto 2405,39.38,68.31
>>Kill |cRXP_ENEMY_Matrean|r.
.complete 88708,2 
.mob Matrean
step
#completewith next
#label ViolentConclusionsB
#arrowtext Talk to\n|cRXP_FRIENDLY_Kelia Everglow|r
.goto 2405,39.03,67.02,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelia Everglow|r.
.turnin 88708 >>Turn in Violent Conclusions
.target Kelia Everglow
step
.isOnQuest 88708
#completewith ViolentConclusionsB
#title Leave the cave
.goto 2405,41.16,61.50,435 >>|cRXP_WARN_Leave the cave.|r
step
#label TheVoidPeersBackZ
#requires ViolentConclusionsB
#arrowtext Talk to\n|cRXP_FRIENDLY_Kelia Everglow|r
.goto 2405,41.16,61.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelia Everglow|r.
.turnin 88708 >>Turn in Violent Conclusions
.target Kelia Everglow
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Shadow Puppets
#internal
step
#label ShadowPuppetsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Knight Anais|r
.goto 2405,51.82,71.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight Anais|r
.accept 91145 >>Accept The Conquered Heroes
.target Knight Anais
step
#label ShadowPuppetsB
.goto 2405,46.78,56.55
#title |cFFFCDC00Follow the Arrow|r
.complete 91145,1 
step
#loop
.goto 2405,46.78,56.55,10,0
.goto 2405,46.95,56.26,10,0
.goto 2405,46.82,56.01,10,0
#arrowtext Click on the\n|cRXP_PICK_Bodies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bodies|r
.complete 91145,2 
.target Confessor Revik
.target Scout Danna
.target Knight Riandron
step
#label Anais
.goto 2405,47.05,54.42
#title |cFFFCDC00Follow the Arrow|r
.complete 91145,3 
step
#label Turn in The Conquered Heroes
.goto 2444,53.97,84.03
#arrowtext |cFFFCDC00Fly UP|r\nTalk to\n|cRXP_FRIENDLY_Knight Anais|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight Anais|r
.turnin 91145 >>Turn in The Conquered Heroes
.target Knight Anais
.accept 91147 >>Accept Cut Her Strings
.accept 91146 >>Accept Flickering Light
step
#completewith next
>>Kill |cRXP_ENEMY_Voidcrawlers|r and |cRXP_ENEMY_Ultradons|r and click on them.
.complete 91147,1 
.mob Alloyed Ultradon
.mob Alloyed Voidcrawler
step
#loop
.goto 2444,50.84,77.98,10,0
.goto 2444,47.46,75,10,0
.goto 2444,51.64,73.36,10,0
#arrowtext Click on the\n|cRXP_PICK_Box|r, |cRXP_PICK_Necklace|r, and |cRXP_PICK_Shield|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Box|r, |cRXP_PICK_Necklace|r and |cRXP_PICK_Shield|r
.complete 91146,1 
step
#loop
.goto 2444,53.7,81.26,30,0
.goto 2444,52.18,85.05,30,0
.goto 2444,47.72,78.44,30,0
.goto 2444,50.98,72.95,30,0
#arrowtext Click on the\n|cRXP_PICK_Voidcrawlers|r and |cRXP_PICK_Ultradons|r
>>Kill |cRXP_ENEMY_Voidcrawlers|r and |cRXP_ENEMY_Ultradons|r then click on them(|cRXP_WARN_you can cancel the cast|r).
.complete 91147,1 
.mob Alloyed Ultradon
.mob Alloyed Voidcrawler
step
.isOnQuest 92641
#loop
.goto 2444,43.63,74.18,45,0
.goto 2444,55.54,75.80,45,0
.goto 2444,49.76,85.15,55,0
>>Kill the |cRXP_ENEMY_Bloodplains creatures|r
.complete 92641,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Knight Anais|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight Anais|r |cRXP_WARN_next to you|r.
.turnin 91147 >>Turn in Cut Her Strings
.target Knight Anais
.turnin 91146 >>Turn in Flickering Light
.accept 91148 >>Accept Strung Along
step
.goto 2444,53.98,83.91
#title |cFFFCDC00Follow the Arrow|r
.complete 91148,1 
.timer 3,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Anais|r
.goto 2444,53.97,83.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anais|r
.complete 91148,2 
.skipgossipid 136581
.target Anais
step
.goto 2444,44.50,86.95
#title |cFFFCDC00Follow the Arrow|r
.complete 91148,3 
.timer 8,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Knight Anais|r
.goto 2444,44.07,87.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight Anais|r |cRXP_WARN_after the roleplay|r.
.turnin 91148 >>Turn in Strung Along
.target Knight Anais
.accept 91149 >>Accept Bury Me Not
step
.goto 2444,44.09,87.15
#arrowtext Click on the\n|cRXP_PICK_Book|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 91149,1 
step
.goto 2444,44.41,87.40
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 91149,2 
step
.goto 2444,41.95,72.56
>>Damage |cRXP_ENEMY_Callum Ashvow|r to 50%.
.complete 91149,3 
.mob Callum Ashvow
step
.goto 2444,42.02,72.51
#arrowtext Click on the\n|cRXP_PICK_Imperia|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Imperia|r
.complete 91149,4 
.mob Imperia
step
#label ShadowPuppetsZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Knight Anais|r
.goto 2444,44.06,87.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight Anais|r
.turnin 91149 >>Turn in Bury Me Not
.target Knight Anais
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Nethersent
#internal
step
#optional
.isQuestAvailable account,86509
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dawn of Reckoning (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dawn of Reckoning (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Juras the Nethersent|r
.goto 2405,56.22,71.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Juras the Nethersent|r.
.accept 90782 >>Accept The Nethersent
.target Juras the Nethersent
step
.goto 2405,56.22,71.86
#arrowtext Click on the\n|cRXP_PICK_Cage|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 90782,1 
step
#completewith next
#label TheNethersentA
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2405,40.19,49.11,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90782 >>Turn in The Nethersent
.accept 90866 >>Accept Universal Language
.target Tul'amar, Twice-Exiled
step
.isOnQuest 90782
#completewith next
#title Enter the cave
.goto 2405,39.87,48.98,35 >>|cRXP_WARN_Enter the cave|r.
step
#requires TheNethersentA
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2405,39.87,48.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90782 >>Turn in The Nethersent
.accept 90866 >>Accept Universal Language
.target Tul'amar, Twice-Exiled
step
#completewith next
#label UniversalLanguageA
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T1129420:0|t[|cRXP_LOOT_Predator Blood|r].
.complete 90866,1 
.mob Shredclaw Packhunter
.mob Hunting Netherwasp
.mob Ultradon Tyrant
step
.isOnQuest 90866
#completewith UniversalLanguageA
#title Leave the cave
.goto 2405,40.19,49.11,10 >>|cRXP_WARN_Leave the cave|r.
step
#requires UniversalLanguageA
#label Predator Blood
#loop
.goto 2405,40.76,45.34,35,0
.goto 2405,40.83,37.01,35,0
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T1129420:0|t[|cRXP_LOOT_Predator Blood|r].
.complete 90866,1 
.mob Shredclaw Packhunter
.mob Hunting Netherwasp
.mob Ultradon Tyrant
step
#completewith next
#label UniversalLanguageB
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90866 >>Turn in Universal Language
.target Tul'amar, Twice-Exiled
step
.isOnQuest 90866
#completewith UniversalLanguageB
#title Enter the cave
.goto 2405,40.19,49.11,10 >>|cRXP_WARN_Enter the cave|r.
step
#requires UniversalLanguageB
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2405,39.51,48.53,10,0
.goto 2405,39.37,47.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90866 >>Turn in Universal Language
.timer 5,Roleplay Duration
.accept 90872 >>Accept Drenched In It
.target Tul'amar, Twice-Exiled
step
#loop
.goto 2405,39.44,47.99,8,0
.goto 2405,39.26,48.13,8,0
.goto 2405,39.25,47.88,8,0
#arrowtext Click on the\n|cRXP_PICK_Offworlder Refugees|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Offworlder Refugees|r.
.complete 90872,1 
.target Offworlder Refugee
.skipgossipid 134193
.skipgossip
step
.goto 2405,39.36,47.92
#arrowtext Click on the\n|cRXP_PICK_Waygate|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Waygate|r.
.complete 90872,2 
step
#completewith next
#label DrenchedInItA
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90872 >>Turn in Drenched In It
.accept 90873 >>Accept These Violent Delights
.accept 90874 >>Accept Their Violent Ends
.target Tul'amar, Twice-Exiled
step
.isOnQuest 90872
#completewith next
#title Leave the cave
.goto 2405,40.19,49.11,10 >>|cRXP_WARN_Leave the cave|r.
step
#completewith DrenchedInItA
#hidewindow
.goto 2444,35.05,88.54,300 >>1
step
#requires DrenchedInItA
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2444,35.05,88.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90872 >>Turn in Drenched In It
.accept 90873 >>Accept These Violent Delights
.accept 90874 >>Accept Their Violent Ends
.target Tul'amar, Twice-Exiled
step
#completewith TheirViolentEndsA
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T5872033:0|t[|cRXP_LOOT_Abductor's Mark|r].
.complete 90874,1 
.mob Despair Watcher
.mob Dark Abductor
step
#completewith TheirViolentEndsA
>>Use the |T458240:0|t[Relic of Liberation] and aim at the |cRXP_PICK_Master's Prospects|r.
.complete 90873,1 
.use 244173
step
.goto 2444,32.90,87.57
#arrowtext Click on the\n|cRXP_PICK_Draenei|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Draenei|r.
.complete 90873,2,1 
.mob Unwilling Summon
step
.goto 2444,35.69,87.48,15,0
.goto 2444,36.41,88.17,15,0
.goto 2444,36.76,89.75,15,0
.goto 2444,37.43,90.43
#arrowtext Click on the\n|cRXP_PICK_Draenei|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Draenei|r.
.complete 90873,2,2 
.mob Unwilling Summon
step
#label TheirViolentEndsA
.goto 2444,41.03,86.76,15,0
.goto 2444,40.77,88.35,15,0
.goto 2444,41.62,89.77,15,0
.goto 2444,41.50,90.70,6,0
.goto 2444,37.43,90.43,15,0
.goto 2444,32.90,87.57,15,0
#arrowtext Click on the\n|cRXP_PICK_Draenei|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Draenei|r.
.complete 90873,2 
.mob Unwilling Summon
step
#hidewindow
#completewith Abductor's Mark
#loop
.goto 2444,41.19,87.69,35,0
.goto 2444,35.90,87.89,35,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T5872033:0|t[|cRXP_LOOT_Abductor's Mark|r].
.complete 90874,1 
.mob Despair Watcher
.mob Dark Abductor
step
>>Use the |T458240:0|t[Relic of Liberation] and aim at the |cRXP_PICK_Master's Prospects|r.
.complete 90873,1 
.use 244173
step
#label Abductor's Mark
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T5872033:0|t[|cRXP_LOOT_Abductor's Mark|r].
.complete 90874,1 
.mob Despair Watcher
.mob Dark Abductor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2444,35.06,88.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90873 >>Turn in These Violent Delights
.turnin 90874 >>Turn in Their Violent Ends
.accept 90875 >>Accept Across Worlds
.target Tul'amar, Twice-Exiled
step
.goto 2444,33.11,81.15
>>Kill |cRXP_ENEMY_Snaerius|r.
*Loot him for the |T338783:0|t[|cRXP_LOOT_Lodestar of the Great Dark|r].
.complete 90875,1 
.mob Snaerius
step
#completewith next
#label AcrossWorldsA
#hidewindow
.complete 90875,2 
step
.isOnQuest 90875
#completewith AcrossWorldsA
#title Enter the cave
.goto 2405,40.19,49.11,10 >>|cRXP_WARN_Enter the cave.|r
step
#requires AcrossWorldsA
#title |cFFFCDC00Follow the Arrow|r
.goto 2405,39.51,48.53,10,0
.goto 2405,39.52,48.54
.complete 90875,2 
step
.goto 2405,39.36,48.03
#arrowtext Click on the\n|cRXP_PICK_Lodestar|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lodestar|r.
.complete 90875,3 
.timer 10,Roleplay Duration
step
#label Across Worlds
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2405,39.34,48.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90875 >>Turn in Across Worlds
.target Tul'amar, Twice-Exiled
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Nightbreaker
#internal
step
#optional
.isQuestAvailable account,86565
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Into the Abyss (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Into the Abyss (H) >>CLICK HERE FOR GUIDE << Horde
step
#label TheNightbreakerA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2405,42.39,75.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.accept 90910 >>Accept Overwhelming Darkness
.target Lucia Nightbreaker
step
.goto 2405,42.41,75.35
#arrowtext Click on\n|cRXP_PICK_Kalgorg|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kalgorg|r
.complete 90910,1 
.target Kalgorg
step
#label TheNightbreakerB
#arrowtext Talk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2405,47.93,78.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.turnin 90910 >>Turn in Overwhelming Darkness
.accept 91339 >>Accept Smothered in the Crib
.accept 91340 >>Accept For Violence's Sake
.target Lucia Nightbreaker
step
#completewith SmotheredInTheCribA
>>Kill |cRXP_ENEMY_Wildlife|r.
*Focus on killing |cRXP_ENEMY_Scavenging Biledrinker|r.
.complete 91340,1 
.mob Scavenging Biledrinker
.mob Netherhunter Infestor
.mob Trigore Denguard
step
#arrowtext Wildlife drained (3/9)\n|cFFFCDC00(Read Note)|r\nClick on the\n|cRXP_PICK_Netherhunter Hatchlings|r
.goto 2405,48.70,77.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Netherhunter Hatchlings|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91339,1,3 
.target Netherhunter Hatchling
step
#arrowtext Wildlife drained (6/9)\n|cFFFCDC00(Read Note)|r\nClick on the\n|cRXP_PICK_Netherhunter Hatchlings|r
.goto 2405,47.54,76.90
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Netherhunter Hatchlings|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91339,1,6 
.target Netherhunter Hatchling
step
#label SmotheredInTheCribA
#arrowtext Wildlife drained (9/9)\n|cFFFCDC00(Read Note)|r\nClick on the\n|cRXP_PICK_Netherhunter Hatchlings|r
.goto 2405,46.91,77.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Netherhunter Hatchlings|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 91339,1 
.target Netherhunter Hatchling
step
#loop
.goto 2405,46.46,78.51,35,0
.goto 2405,48.34,80.01,35,0
.goto 2405,48.50,77.58,35,0
>>Kill |cRXP_ENEMY_Wildlife|r.
*Focus on killing |cRXP_ENEMY_Scavenging Biledrinker|r.
.complete 91340,1 
.mob Scavenging Biledrinker
.mob Netherhunter Infestor
.mob Trigore Denguard
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2405,47.94,78.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.turnin 91339 >>Turn in Smothered in the Crib
.turnin 91340 >>Turn in For Violence's Sake
.accept 91341 >>Accept Unlimited
.target Lucia Nightbreaker
step
#completewith next
.goto 2527,59.94,47.27
>>|cRXP_WARN_If needed, jump into the big void puddle to launch back into the air|r.
.complete 91341,2 
step
>>Fly through discs.
.complete 91341,1 
step
#arrowtext Fly through discs.\nClick on the\n|cRXP_PICK_Void Tears|r
#loop
.goto 2526,56.99,29.65,10,0
.goto 2526,51.1,45.06,10,0
.goto 2526,57.79,70.06,10,0
.goto 2526,69.1,58.36,10,0
.goto 2526,71,40.88,10,0
.goto 2527,57.32,39.24,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Tears|r.
*Fly through discs.
.complete 91341,1 
step
#arrowtext |cFFFCDC00At the bottom|r\nTalk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2527,51.08,45.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.turnin 91341 >>Turn in Unlimited
.accept 91343 >>Accept Ambition's Reward
.target Lucia Nightbreaker
step
.goto 2527,30.24,72.66
>>Kill |cRXP_ENEMY_Kalgorg|r.
.complete 91343,1 
.mob Kalgorg
step
#completewith next
#label AmibtionsRewardA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2527,44.36,48.99,10,0
.goto 2527,59.6,47.04,15,0
.goto 2526,64.4,14.44,10,0
.goto 2405,48.06,78.77,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.turnin 91343 >>Turn in Ambition's Reward
.target Lucia Nightbreaker
step
.isOnQuest 91343
#completewith AmibtionsRewardA
#title Leave the cave
.goto 2405,47.93,78.49,10 >>|cRXP_WARN_Leave the cave|r.
step
#label TheNightbreakerZ
#requires AmibtionsRewardA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2405,42.44,75.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.turnin 91343 >>Turn in Ambition's Reward
.target Lucia Nightbreaker
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Pathogenic Problem
#internal
step
#optional
.isQuestAvailable account,86565
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Into the Abyss (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Into the Abyss (H) >>CLICK HERE FOR GUIDE << Horde
step
#label PathogenicProblemA
.isOnQuest 91557
.goto 2405,35.90,48.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin 91557 >>Turn in Message to the Molt
.target Lady Darkglen
step
#label Pestilent Petals
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Darkglen|r
.goto 2405,35.90,48.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.accept 91558 >>Accept Pestilent Petals
.accept 91559 >>Accept Virulent Vermin
.target Lady Darkglen
step
#hidewindow
#completewith Specialized Liver
#loop
.goto 2405,35.92,48.07,8,0
.goto 2405,35.57,47.81,20,0
.goto 2405,35.28,48.17,10,0
.goto 2405,35.38,48.56,10,0
.goto 2405,35.54,49,20,0
.goto 2405,35.19,49.13,20,0
.goto 2405,34.97,48.32,15,0
.goto 2405,34.7,47.77,15,0
.goto 2405,34.76,47.03,15,0
.goto 2405,35.29,47.36,15,0
.goto 2405,35.82,47.13,15,0
.goto 2405,35.6,46.44,15,0
.goto 2405,35.65,46.48,15,0
.goto 2405,35.4,46.12,15,0
.goto 2405,35.09,45.63,15,0
.goto 2405,34.42,45.53,15,0
.goto 2405,34.29,45.9,15,0
.goto 2405,34.15,46.44,15,0
.goto 2405,34.75,44.95,20,0
.goto 2405,34.94,48.29,20,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Ambush Consumptors|r and |cRXP_ENEMY_Kilivore Hunters|r.
*Loot them for the |T237328:0|t[|cRXP_LOOT_Specialized Livers|r].
.complete 91559,1 
.mob Ambush Consumptor
.mob Kilivore Hunter
step
#arrowtext Click on the\n|cRXP_PICK_Blood Petals|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blood Petals|r.
.complete 91558,1 
step
#label Specialized Liver
>>Kill |cRXP_ENEMY_Ambush Consumptors|r and |cRXP_ENEMY_Kilivore Hunters|r.
*Loot them for the |T237328:0|t[|cRXP_LOOT_Specialized Livers|r].
.complete 91559,1 
.mob Ambush Consumptor
.mob Kilivore Hunter
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Darkglen|r
.goto 2405,34.62,43.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin 91558 >>Turn in Pestilent Petals
.turnin 91559 >>Turn in Virulent Vermin
.accept 91560 >>Accept Expunging Explorers
.target Lady Darkglen
step
.goto 2405,34.57,43.83
#arrowtext Click on the\n|cRXP_PICK_Blood Petal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blood Petal|r.
.complete 91560,1 
step
.goto 2405,34.60,43.85
#arrowtext Click on the\n|cRXP_PICK_Liver|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Liver|r.
.complete 91560,2 
step
.goto 2405,34.60,43.82
#arrowtext Click on the\n|cRXP_PICK_Cooking Pot|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cooking Pot|r.
.complete 91560,3 
step
#label Antidote administered
.goto 2405,34.66,43.87
#arrowtext Click on the\n|cRXP_PICK_Scout|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scout|r.
.complete 91560,4 
.timer 11.5,RP
.target Infected Scout Philanas
step
#label Calculated Culling
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Philanas|r
.goto 2405,34.66,43.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Philanas|r.
.accept 93801 >>Accept Calculated Culling
.target Scout Philanas
step
#completewith ExpungingExplorersA
>>Kill the |cRXP_ENEMY_Drones|r, |cRXP_ENEMY_Ultradons|r and |cRXP_ENEMY_Blisters|r.
.complete 93801,1 
.mob Netherwasp Dron
.mob Rampaging Ultradon
.mob Sanguineous Blistercreep
step
#loop
.goto 2405,33.69,45.47,15,0
.goto 2405,33.98,46.03,15,0
.goto 2405,34.19,47.33,15,0
.goto 2405,33.69,48.33,15,0
.goto 2405,32.94,47.34,15,0
.goto 2405,33.16,46.41,15,0
#arrowtext Click on the\n|cRXP_PICK_Scout|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scout|r.
.complete 91560,5 
.target Infected Ren'dorei
step
#label ExpungingExplorersA
.goto 2405,33.29,43.98
#arrowtext Click on the\n|cRXP_PICK_Riftwalker Lorn|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Riftwalker Lorn|r.
.complete 91560,6 
.target Riftwalker Lorn
step
#loop
.goto 2405,34.12,46.35,35,0
.goto 2405,32.79,48.17,35,0
.goto 2405,32.44,45.15,35,0
>>Kill the |cRXP_ENEMY_Drones|r, |cRXP_ENEMY_Ultradons|r and |cRXP_ENEMY_Blisters|r.
.complete 93801,1 
.mob Netherwasp Dron
.mob Rampaging Ultradon
.mob Sanguineous Blistercreep
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Darkglen|r
.goto 2405,34.62,43.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin 93801 >>Turn in Calculated Culling
.turnin 91560 >>Turn in Expunging Explorers
.accept 91561 >>Accept Bloodborne Pathogen
.target Lady Darkglen
step
.goto 2405,32.18,44.62
>>Kill |cRXP_ENEMY_Mutated Pathogen|r.
.complete 91561,1 
.mob Mutated Pathogen
step
#label PathogenicProblemZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Darkglen|r
.goto 2405,34.62,43.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin 91561 >>Turn in Bloodborne Pathogen
.target Lady Darkglen
]])

