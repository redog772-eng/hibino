if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name f) The Call of the Void (H)
#displayname |cFF00CCFF6|r - The Call of the Void
<< Horde
step
#include f) The Call of the Void
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name xb) Val Zone Unlock (H)
#displayname Val Zone Unlock (12.0.7)
<< Horde
step
#include xb) Val Zone Unlock
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name xc) Naigtal Zone Unlock (H)
#displayname Naigtal Zone Unlock (12.0.7)
<< Horde
step
#include xc) Naigtal Zone Unlock
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Storylines
#name adb) The Coiled Isle Storylines (A)
#displayname |cFF00FF005|r - The Coiled Isle Sojourner
#chapters a) The Monster's Mother (A);a) Don't be Afrayed (A);a) Living Legend (A);a) Tokka's Crew (A);a) Somethin' Bad Inside (A);a) The Troubles of Mlurkkr Mine (A);a) Strange Friends in Odd Places (A);a) A Bond of Brothers (A);a) Ancient Anthropology (A);a) Bone Deep (A);a) The Honored Med'jai (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Monster's Mother (A)
#displayname |cFF00CCFF1|r - The Monster's Mother
#next a) Don't be Afrayed (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Monster's Mother
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Don't be Afrayed (A)
#displayname |cFF00CCFF2|r - Don't be Afrayed
#next a) Living Legend (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Don't be Afrayed
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Living Legend (A)
#displayname |cFF00CCFF3|r - Living Legend
#next a) Tokka's Crew (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Living Legend
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Tokka's Crew (A)
#displayname |cFF00CCFF4|r - Tokka's Crew
#next a) Somethin' Bad Inside (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Tokka's Crew
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Somethin' Bad Inside (A)
#displayname |cFF00CCFF5|r - Somethin' Bad Inside
#next a) The Troubles of Mlurkkr Mine (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Somethin' Bad Inside
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Troubles of Mlurkkr Mine (A)
#displayname |cFF00CCFF6|r - The Troubles of Mlurkkr Mine
#next a) Strange Friends in Odd Places (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Troubles of Mlurkkr Mine
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Strange Friends in Odd Places (A)
#displayname |cFF00CCFF7|r - Strange Friends in Odd Places
#next a) A Bond of Brothers (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Strange Friends in Odd Places
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Bond of Brothers (A)
#displayname |cFF00CCFF8|r - A Bond of Brothers
#next a) Ancient Anthropology (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Bond of Brothers
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Ancient Anthropology (A)
#displayname |cFF00CCFF9|r - Ancient Anthropology
#next a) Bone Deep (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Ancient Anthropology
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Bone Deep (A)
#displayname |cFF00CCFF10|r - Bone Deep
#next a) The Honored Med'jai (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Bone Deep
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Honored Med'jai (A)
#displayname |cFF00CCFF11|r - The Honored Med'jai (Group)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Honored Med'jai
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) 90 Unlocking Systems (A)
#displayname |cFF00CCFF0|r - 90 Intro Unlocking Systems
#next a) Foothold (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) 90 Unlocking Systems
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name a) Delve Campaign (A)
#subweight 993.99
#displayname Delve Campaign
<< Alliance
step
#include a) Delve Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 993.98
#name a) Prey Campaign (A)
#displayname Prey Campaign
<< Alliance
step
#include a) Prey Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 993.97
#name a) Saltheril's Haven (A)
#displayname Saltheril's Haven Campaign
<< Alliance
step
#include a) Saltheril's Haven
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name a) ZAbundance Campaign (A)
#subweight 993.96
#displayname Abundance Campaign
<< Alliance
step
#include a) Abundance Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name a) 12.0.5 Campaign (A)
#displayname 12.0.5 Campaign
<< Alliance
step
#include a) 12.0.5 Campaign
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 994
#name A) The War of Light and Shadow Campaign (A)
#displayname The War of Light and Shadow
#chapters a) 90 Unlocking Systems (A);a) Foothold (A);a) The Voidspire (A);a) Gathering of the Elves (A);a) The Battle of the Bridge (A);a) The Darkwell (A);a) Dawn of a New Well (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Foothold (A)
#displayname |cFF00CCFF1|r - Foothold
#next a) The Voidspire (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Foothold
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Voidspire (A)
#displayname |cFF00CCFF2|r - The Voidspire
#next a) Gathering of the Elves(A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Voidspire
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Gathering of the Elves (A)
#displayname |cFF00CCFF3|r - Gathering of the Elves
#next a) The Battle of the Bridge (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Gathering of the Elves
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Battle of the Bridge (A)
#displayname |cFF00CCFF4|r - The Battle of the Bridge
#next a) The Darkwell (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Battle of the Bridge
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Darkwell (A)
#displayname |cFF00CCFF5|r - The Darkwell
#next a) Dawn of a New Well (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Darkwell
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Dawn of a New Well (A)
#displayname |cFF00CCFF6|r - Dawn of a New Well
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Dawn of a New Well
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#subweight 995
#name Y) The Curse of Ula'tek (A)
#displayname The Curse of Ula'tek (12.1)
#chapters a) Legacy of the Amani (A);b) An Island of Fangs (A);c) Ghosts of the Past (A);d) Original Sin (A);e) The Battle of Atal'Utek (A);f) The Call of the Void (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name a) Legacy of the Amani (A)
#displayname |cFF00CCFF1|r - Legacy of the Amani
#next b) An Island of Fangs (A)
<< Alliance
step
#include a) Legacy of the Amani
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name b) An Island of Fangs (A)
#displayname |cFF00CCFF2|r - An Island of Fangs
#next c) Ghosts of the Past (A)
<< Alliance
step
#include b) An Island of Fangs
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name c) Ghosts of the Past (A)
#displayname |cFF00CCFF3|r - Ghosts of the Past
#next d) Original Sin (A)
<< Alliance
step
#include c) Ghosts of the Past
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name d) Original Sin (A)
#displayname |cFF00CCFF4|r - Original Sin
#next e) The Battle of Atal'Utek (A)
<< Alliance
step
#include d) Original Sin
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name e) The Battle of Atal'Utek (A)
#displayname |cFF00CCFF5|r - The Battle of Atal'Utek
#next f) The Call of the Void (A)
<< Alliance
step
#include e) The Battle of Atal'Utek
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#chapter
#name f) The Call of the Void (A)
#displayname |cFF00CCFF6|r - The Call of the Void
<< Alliance
step
#include f) The Call of the Void
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name xb) Val Zone Unlock (A)
#displayname Val Zone Unlock (12.0.7)
<< Alliance
step
#include xb) Val Zone Unlock
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFFE74C3C(90)|r Max-Level Campaigns
#name xc) Naigtal Zone Unlock (A)
#displayname Naigtal Zone Unlock (12.0.7)
<< Alliance
step
#include xc) Naigtal Zone Unlock
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Monster's Mother
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ulantu|r
.goto 2512,44.67,30.06,10,0
.goto 2640,80.67,46.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ulantu|r.
.accept 96450 >>Accept Sideways
.target Ulantu
step
#arrowtext Click on\n|cRXP_PICK_Notes|r
.goto 2640,58.39,23.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Notes|r.
.complete 96450,1 
step
#arrowtext Click on\n|cRXP_PICK_Missive|r
.goto 2640,35.95,19.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Missive|r.
.complete 96450,3 
step
#arrowtext Click on\n|cRXP_PICK_Ledger|r
.goto 2640,29.65,40.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ledger|r.
.complete 96450,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ulantu|r
.goto 2640,19.93,36.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ulantu|r.
.turnin 96450 >>Turn in Sideways
.accept 96451 >>Accept A Child of Ula'tek
.target Ulantu
step
#arrowtext Kill\n|cRXP_ENEMY_Naj'kula|r
.goto 2640,22.57,73.37
>>Kill |cRXP_ENEMY_Naj'kula|r.
.complete 96451,1 
.mob Naj'kula
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ulantu|r
.goto 2640,40.49,72.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ulantu|r.
.turnin 96451 >>Turn in A Child of Ula'tek
.accept 96457 >>Accept Nothing Must Remain
.target Ulantu
step
#arrowtext Use\n|T1:0|t[ExtraActionButton]
.goto 2640,47.91,72.28
>>Use the |T1:0|t[ExtraActionButton].
.complete 96457,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ulantu|r
.goto 2640,40.37,72.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ulantu|r.
.turnin 96457 >>Turn in Nothing Must Remain
.accept 96458 >>Accept Last Promise
.target Ulantu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kul'amara the Fierce|r
.goto 2512,57.87,46.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kul'amara the Fierce|r.
.turnin 96458 >>Turn in Last Promise
.target Kul'amara the Fierce
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Ancient Anthropology
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kul'amara the Fierce|r
.goto 2512,57.87,46.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kul'amara the Fierce|r.
.accept 96467 >>Accept Thirst for Knowledge
.target Kul'amara the Fierce
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zei'ka|r
.goto 2512,75.00,62.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zei'ka|r.
.turnin 96467 >>Turn in Thirst for Knowledge
.accept 96469 >>Accept The Crypt of the Disgraced
.target Zei'ka
step
#arrowtext Follow the arrow
.goto 2644,48.07,33.79,8,0
.goto 2644,41.36,43.40
>>Follow the arrow.
.complete 96469,1 
step
#completewith TheCryptOfTheDisgracedZ
#label TheCryptOfTheDisgracedA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_objects|r in the order: Charm > Mortar & Pestle > Urn > Bones.
*Only casts are tracked. If you click on them in the wrong order then the waypoint will be wrong.
.complete 96469,2 
step
#completewith TheCryptOfTheDisgracedA
#label TheCryptOfTheDisgracedB
#arrowtext Click on\n|cRXP_PICK_Charm|r
.goto 2644,45.47,49.68
.cast 277995 >>Click on the |cRXP_PICK_Charm|r.
step
#requires TheCryptOfTheDisgracedB
#completewith TheCryptOfTheDisgracedA
#label TheCryptOfTheDisgracedC
#arrowtext Click on\n|cRXP_PICK_Mortar and Pestle|r
.goto 2644,37.44,37.74
.cast 277995 >>Click on the |cRXP_PICK_Mortar and Pestle|r.
step
#requires TheCryptOfTheDisgracedC
#completewith TheCryptOfTheDisgracedA
#label TheCryptOfTheDisgracedD
#arrowtext Click on\n|cRXP_PICK_Urn|r
.goto 2644,30.60,47.79
.cast 277995 >>Click on the |cRXP_PICK_Urn|r.
step
#requires TheCryptOfTheDisgracedD
#completewith TheCryptOfTheDisgracedA
#label TheCryptOfTheDisgracedZ
#arrowtext Click on\n|cRXP_PICK_Bones|r
.goto 2644,38.74,59.95
.cast 277995 >>Click on the |cRXP_PICK_Bones|r.
step
#requires TheCryptOfTheDisgracedA
#arrowtext Click on\n|cRXP_PICK_objects|r
.goto 2644,41.36,43.40
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_objects|r in the order: Charm > Mortar & Pestle > Urn > Bones.
*Only casts are tracked. If you click on them in the wrong order then the waypoint will be wrong.
.complete 96469,2 
step
#arrowtext Follow the arrow
.goto 2644,35.70,66.07,8,0
.goto 2644,49.41,80.03,8,0
.goto 2644,57.88,64.71
>>Follow the arrow
.complete 96469,4 
step
#arrowtext Click on\n|cRXP_PICK_Tablets|r
.goto 2644,66.04,62.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablets|r.
.complete 96469,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zei'ka|r
.goto 2644,61.02,59.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zei'ka|r.
.turnin 96469 >>Turn in The Crypt of the Disgraced
.accept 96471 >>Accept Crumble and Tumble
.target Zei'ka
step
#arrowtext Follow the arrow
.goto 2644,43.57,80.72,8,0
.goto 2644,32.29,55.89,8,0
.goto 2644,55.85,28.31,8,0
.goto 2512,74.68,62.75
>>Follow the arrow.
.complete 96471,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jun'ka|r
.goto 2512,74.82,62.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jun'ka|r.
.turnin 96471 >>Turn in Crumble and Tumble
.target Jun'ka
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Don't be Afrayed
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Olawu|r
.goto 2512,58.53,47.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Olawu|r.
.accept 93841 >>Accept Ghosts of the Ring
.target Olawu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ja'bonu|r
.goto 2512,66.13,53.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ja'bonu|r.
.turnin 93841 >>Turn in Ghosts of the Ring
.accept 93843 >>Accept Ectoplasmic Extractions
.accept 93842 >>Accept Bloom and Fade
.target Ja'bonu
step
#arrowtext Click on |cRXP_PICK_Bloom|r\nBlooms (1/6)\n|cRXP_WARN_(Hardcoded)|r
.goto 2512,65.89,53.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bloom|r.
.complete 93842,1,1 
step
#completewith EctoplasmicExtractionsA
#hidewindow
#arrowtext Kill\n|cRXP_ENEMY_Frayed|r\nCollect |cRXP_PICK_Blooms|r
#loop
.goto 2512,66.68,55.08,35,0
.goto 2512,66.98,58.77,35,0
.goto 2512,71.31,59.92,35,0
.goto 2512,71.66,55.44,35,0
.goto 2512,67.94,52.26,35,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Frayed|r. Loot them for the |T135864:0|t[|cRXP_LOOT_Ectoplasm|r].
.complete 93843,1 
.mob Soulcoiler Cultist
.mob Frayed Spellslinger
.mob Frayed Defender
.mob Frayed Priestess
.mob Frayed Scout
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bloom|r.
.complete 93842,1 
step
#label EctoplasmicExtractionsA
>>Kill the |cRXP_ENEMY_Frayed|r. Loot them for the |T135864:0|t[|cRXP_LOOT_Ectoplasm|r].
.complete 93843,1 
.mob Soulcoiler Cultist
.mob Frayed Spellslinger
.mob Frayed Defender
.mob Frayed Priestess
.mob Frayed Scout
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ja'bonu|r
.goto 2512,69.41,53.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ja'bonu|r.
.turnin 93843 >>Turn in Ectoplasmic Extractions
.turnin 93842 >>Turn in Bloom and Fade
.accept 93849 >>Accept Ectoplasmic Emporium
.target Ja'bonu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Mab'jul|r
.goto 2512,69.25,52.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mab'jul|r and buy the |T463543:0|t[|cRXP_LOOT_Spectral Brew|r].
.complete 93849,1 
.target Mab'jul
.skipgossipid 138019
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Eshaye|r
.goto 2512,69.84,54.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eshaye|r.
.complete 93849,2 
.skipgossipid 137427
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ja'bonu|r
.goto 2512,69.41,53.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ja'bonu|r.
.turnin 93849 >>Turn in Ectoplasmic Emporium
.accept 93851 >>Accept Communing with Ghosts
.target Ja'bonu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Mab'jul|r
.goto 2512,69.25,52.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mab'jul|r.
.complete 93851,1 
.target Mab'jul
.skipgossipid 138038
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kir'bo|r
.goto 2512,70.39,52.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kir'bo|r.
.complete 93851,4 
.target Kir'bo
.skipgossipid 138034
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ja'bonu|r
.goto 2512,69.41,53.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ja'bonu|r.
.turnin 93851 >>Turn in Communing with Ghosts
.accept 93906 >>Accept Untethering the Two
.target Ja'bonu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Eshaye|r
.goto 2512,73.06,53.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eshaye|r and defeat her.
.complete 93906,1 
.target Eshaye
.mob Eshaye
.skipgossipid 138057
step
#arrowtext Follow the arrow
.goto 2512,69.55,53.43
>>Follow the arrow.
.complete 93906,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Eshaye|r
.goto 2512,69.46,53.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eshaye|r.
.turnin 93906 >>Turn in Untethering the Two
.target Eshaye
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Troubles of Mlurkkr Mine
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ra'kamu|r
.goto 2512,57.50,47.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ra'kamu|r.
.accept 93449 >>Accept Trouble in the Swamp
.target Ra'kamu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zawadi|r
.goto 2512,63.00,44.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zawadi|r.
.turnin 93449 >>Turn in Trouble in the Swamp
.accept 93229 >>Accept Fried Eggs
.accept 93199 >>Accept Slithering in the Mire
.target Zawadi
step
#completewith SliterhingInTheMireA
#hidewindow
#arrowtext Kill\n|cRXP_ENEMY_Children of Ula'tek|r\nBurn |cRXP_PICK_Eggs|r
#loop
.goto 2512,64.01,43.69,35,0
.goto 2512,63.81,37.31,35,0
.goto 2512,66.45,36.45,35,0
.goto 2512,65.80,44.40,35,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Children of Ula'tek|r.
.complete 93199,1 
.mob Vilescar Slasher
.mob Vilescar Acolyte
.mob Vilescar Stalker
.mob Vilescar Harrier
step
>>Use the [ExtraActionButton] and aim it at the |cRXP_PICK_Eggs|r
*|cRXP_WARN_NOTE:|r Don't run over them otherwise you will destroy them which doesn't count.
.complete 93229,1 
step
#label SliterhingInTheMireA
>>Kill the |cRXP_ENEMY_Children of Ula'tek|r.
.complete 93199,1 
.mob Vilescar Slasher
.mob Vilescar Acolyte
.mob Vilescar Stalker
.mob Vilescar Harrier
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zawadi|r
.goto 2512,66.03,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zawadi|r.
.turnin 93199 >>Turn in Slithering in the Mire
.turnin 93229 >>Turn in Fried Eggs
.accept 93576 >>Accept The Search for Wa'kani
.target Zawadi
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wa'kani|r
.goto 2512,65.08,37.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wa'kani|r.
.complete 93576,1 
.target Wa'kani
.skipgossipid 136934
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wa'kani|r
.goto 2512,64.66,37.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wa'kani|r.
.turnin 93576 >>Turn in The Search for Wa'kani
.accept 94447 >>Accept Ophidia the Broodmother
.target Wa'kani
step
#arrowtext Kill\n|cRXP_ENEMY_Ophidia|r
.goto 2512,63.60,36.06
>>Kill |cRXP_ENEMY_Ophidia|r.
.complete 94447,1 
.mob Ophidia
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wa'kani|r
.goto 2512,64.66,37.88
>>137271
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wa'kani|r
.goto 2512,64.66,37.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wa'kani|r.
.complete 94447,2 
.target Wa'kani
.skipgossipid 137271
step
#arrowtext Follow the arrow
.goto 2512,66.01,39.03
>>Follow the arrow.
.complete 94447,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zawadi|r
.goto 2512,66.03,38.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zawadi|r.
.turnin 94447 >>Turn in Ophidia the Broodmother
.accept 93239 >>Accept Scouts in the Swamp
.accept 93233 >>Accept Savagery Among the Ruins
.target Zawadi
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wa'kani|r
.goto 2512,66.00,39.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wa'kani|r.
.accept 93339 >>Accept Trinket Trading
.target Wa'kani
step
#completewith ScoutsInTheSwampA
>>Kill the |cRXP_ENEMY_Murkfen forces|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Curious Murpoles|r.
.complete 93233,1 
.complete 93233,2 
.target Curious Murpoles
.mob Murkfen Bonesmasher
.mob Murkfen Shellseer
.mob Murkfen Mystic
step
#completewith ScoutsInTheSwampA
.goto 2512,67.19,37.55,0
.goto 2512,67.40,38.08,0
.goto 2512,68.24,36.71,0
.goto 2512,67.44,36.45,0
.goto 2512,67.31,36.00,0
.goto 2512,69.30,35.23,0
.goto 2512,69.16,34.01,0
.goto 2512,69.12,32.54,0
.goto 2512,70.03,32.77,0
.goto 2512,71.01,33.04,0
.goto 2512,71.15,31.80,0
.goto 2512,69.32,36.06,0
.goto 2512,68.31,39.55,0
.goto 2512,67.35,40.56,0
.goto 2512,67.88,38.05,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trinkets|r. Very hard to see.
*|cRXP_WARN_NOTE:|r The spots are marked on your minimap.
.complete 93339,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Abaano|r
.goto 2512,67.41,40.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abaano|r.
.complete 93239,2 
.target Abaano
.skipgossipid 136933
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tefokal|r
.goto 2512,66.85,33.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tefokal|r.
.complete 93239,3 
.target Tefokal
.skipgossipid 136935
step
#label ScoutsInTheSwampA
#arrowtext Click on\n|cRXP_PICK_Ndamu|r
.goto 2512,68.19,34.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ndamu|r.
.complete 93239,1 
.target Ndamu
step
#completewith SavageryAmongTheRuinsA
#hidewindow
#arrowtext Kill\n|cRXP_ENEMY_Murloc forces|r\nShoo |cRXP_PICK_Curious Murpoles|r
#loop
.goto 2512,70.66,31.47,55,0
.goto 2512,68.02,36.75,45,0
.goto 2512,68.41,39.67,45,0
.goto 2512,66.78,34.88,45,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Murloc forces|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Curious Murpoles|r.
.complete 93233,1 
.complete 93233,2 
.target Curious Murpoles
.mob Murkfen Bonesmasher
.mob Murkfen Shellseer
.mob Murkfen Mystic
step
.goto 2512,67.19,37.55,0
.goto 2512,67.40,38.08,0
.goto 2512,68.24,36.71,0
.goto 2512,67.44,36.45,0
.goto 2512,67.31,36.00,0
.goto 2512,69.30,35.23,0
.goto 2512,69.16,34.01,0
.goto 2512,69.12,32.54,0
.goto 2512,70.03,32.77,0
.goto 2512,71.01,33.04,0
.goto 2512,71.15,31.80,0
.goto 2512,69.32,36.06,0
.goto 2512,68.31,39.55,0
.goto 2512,67.35,40.56,0
.goto 2512,67.88,38.05,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trinkets|r. Very hard to see.
*|cRXP_WARN_NOTE:|r The spots are marked on your minimap.
.complete 93339,1 
step
#label SavageryAmongTheRuinsA
>>Kill the |cRXP_ENEMY_Murloc forces|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Curious Murpoles|r.
.complete 93233,1 
.complete 93233,2 
.target Curious Murpoles
.mob Murkfen Bonesmasher
.mob Murkfen Shellseer
.mob Murkfen Mystic
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zawadi|r
.goto 2512,68.87,37.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zawadi|r.
.turnin 93233 >>Turn in Savagery Among the Ruins
.turnin 93239 >>Turn in Scouts in the Swamp
.target Zawadi
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wa'kani|r
.goto 2512,68.86,37.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wa'kani|r.
.turnin 93339 >>Turn in Trinket Trading
.accept 93340 >>Accept The Shadow Shard
.target Wa'kani
step
#arrowtext Kill\n|cRXP_ENEMY_Smrglemrgl|r
.goto 2512,71.16,38.28
>>Kill |cRXP_ENEMY_Smrglemrgl|r.
.complete 93340,1 
.mob Smrglemrgl
step
#arrowtext Click on\n|cRXP_PICK_Shard|r
.goto 2512,71.24,38.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shard|r.
.complete 93340,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wa'kani|r
.goto 2512,68.86,37.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wa'kani|r.
.turnin 93340 >>Turn in The Shadow Shard
.target Wa'kani
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Strange Friends in Odd Places
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi the Sly|r
#loop
.goto 2512,61.28,32.84,12,0
.goto 2512,60.82,32.91,12,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi the Sly|r.
.accept 93387 >>Accept Dealing with Pests
.target Ofi the Sly
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jelvik|r
#loop
.goto 2512,61.28,32.84,12,0
.goto 2512,60.82,32.91,12,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jelvik|r.
.complete 93387,1 
.target Jelvik
.skipgossipid 138831
.skipgossipid 138828
.skipgossipid 138825
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi the Sly|r
#loop
.goto 2512,61.28,32.84,12,0
.goto 2512,60.82,32.91,12,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi the Sly|r.
.turnin 93387 >>Turn in Dealing with Pests
.accept 93388 >>Accept Unusual Alchemy
.target Ofi the Sly
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jelvik|r
#loop
.goto 2512,61.28,32.84,12,0
.goto 2512,60.82,32.91,12,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jelvik|r.
.accept 93389 >>Accept Rocksblood
.target Jelvik
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Wavemaster Mavani|r
.goto 2512,71.53,37.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wavemaster Mavani|r.
.complete 93389,1 
.target Wavemaster Mavani
.skipgossipid 138779
step
#arrowtext Click on\n|cRXP_PICK_Bones|r
.goto 2512,72.00,33.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bones|r.
.complete 93389,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Maka the Trawler|r
.goto 2512,64.04,45.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maka the Trawler|r.
.complete 93388,1 
.target Maka the Trawler
.skipgossipid 139210
step
#arrowtext Click on\n|cRXP_PICK_Innards|r
.goto 2512,64.08,45.80
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Innards|r.
.complete 93388,2 
step
#arrowtext Kill\n|cRXP_ENEMY_Vilescars|r
#loop
.goto 2512,64.42,43.88,35,0
.goto 2512,63.56,41.61,35,0
.goto 2512,67.10,35.61,35,0
.goto 2512,63.71,36.43,35,0
>>Kill the |cRXP_ENEMY_Vilescars|r. Loot them for the |T1:0|t[|cRXP_LOOT_Undamaged Serpent Scales|r].
.complete 93388,4 
.mob Vilescar Slasher
.mob Vilescar Acolyte
.mob Vilescar Stalker
.mob Vilescar Harrier
step
#arrowtext Click on\n|cRXP_PICK_Pearl|r
.goto 2512,69.01,32.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pearl|r.
.complete 93388,3 
step
#arrowtext Click on\n|cRXP_PICK_Band|r
.goto 2512,62.37,30.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Band|r.
.complete 93389,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jelvik|r
.goto 2512,60.94,32.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jelvik|r.
.turnin 93389 >>Turn in Rocksblood
.target Jelvik
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi the Sly|r
.goto 2512,60.43,33.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi the Sly|r.
.turnin 93388 >>Turn in Unusual Alchemy
.accept 93390 >>Accept Acceptable Apprentice
.target Ofi the Sly
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi|r
.goto 2512,60.43,33.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi|r.
.complete 93390,1 
.target Ofi
.skipgossipid 138839
step
#arrowtext Choose an ingredient
.goto 2512,60.37,33.04
>>Listen the |cRXP_FRIENDLY_Ofi|r and click on the |cRXP_PICK_Guts|r, |cRXP_PICK_Scales|r or |cRXP_PICK_Pearl|r.
.complete 93390,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi the Sly|r
.goto 2512,60.48,33.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi the Sly|r.
.turnin 93390 >>Turn in Acceptable Apprentice
.accept 93391 >>Accept Make it Stinky
.target Ofi the Sly
step
#arrowtext Click on\n|cRXP_PICK_Deterrent|r
.goto 2512,62.02,34.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Deterrent|r.
.complete 93391,1 
step
#arrowtext Click on\n|cRXP_PICK_Deterrent|r
.goto 2512,62.53,33.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Deterrent|r.
.complete 93391,2 
step
#arrowtext Click on\n|cRXP_PICK_Deterrent|r
.goto 2512,62.99,32.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Deterrent|r.
.complete 93391,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi the Sly|r
.goto 2512,60.38,32.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi the Sly|r.
.turnin 93391 >>Turn in Make it Stinky
.target Ofi the Sly
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jelvik|r
.goto 2512,60.94,32.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jelvik|r.
.accept 93392 >>Accept Recovering Memories
.target Jelvik
step
#arrowtext Defeat\n|cRXP_ENEMY_Lonely Beast|r
.goto 2512,65.02,16.81
>>Defeat the |cRXP_ENEMY_Lonely Beast|r.
.complete 93392,1 
.mob Lonely Beast
step
#arrowtext Click on\n|cRXP_PICK_Rocksblood|r
.goto 2512,64.86,16.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rocksblood|r.
.complete 93392,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jelvik|r
.goto 2512,60.94,32.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jelvik|r.
.turnin 93392 >>Turn in Recovering Memories
.accept 93393 >>Accept A Little Kindness
.target Jelvik
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi the Sly|r
.goto 2512,60.39,32.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi the Sly|r.
.complete 93393,1 
.target Ofi the Sly
.skipgossipid 138838
step
#arrowtext Click on\n|cRXP_PICK_Egg|r
.goto 2512,61.08,32.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r.
.complete 93393,2 
step
#arrowtext Click on\n|cRXP_PICK_Egg|r
.goto 2512,63.25,28.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r.
.complete 93393,3 
step
#arrowtext Wait for the roleplay
.goto 2512,63.25,28.21
>>Wait for the roleplay.
.complete 93393,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ofi the Sly|r
.goto 2512,60.99,32.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ofi the Sly|r.
.turnin 93393 >>Turn in A Little Kindness
.target Ofi the Sly
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) A Bond of Brothers
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Aol'ggin|r
.goto 2512,56.48,43.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aol'ggin|r.
.accept 94936 >>Accept A Bond of Brothers
.target Aol'ggin
step
#arrowtext Click on\n|cRXP_PICK_Tunnel|r
.goto 2512,55.65,40.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tunnel|r.
.complete 94936,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tekkan|r
.goto 2512,55.32,39.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tekkan|r.
.complete 94936,2 
.target Tekkan
.skipgossipid 138561
step
#arrowtext Click on\n|cRXP_PICK_Tunnel|r
.goto 2512,55.03,39.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tunnel|r.
.complete 94936,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tekkan|r
.goto 2512,53.20,37.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tekkan|r.
.complete 94936,4 
.target Tekkan
.skipgossipid 138562
step
#arrowtext Click on\n|cRXP_PICK_Tunnel|r
.goto 2512,53.24,36.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tunnel|r.
.complete 94936,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Aol'ggin|r
.goto 2512,53.25,35.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aol'ggin|r.
.turnin 94936 >>Turn in A Bond of Brothers
.target Aol'ggin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tekkan|r
.goto 2512,53.24,35.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tekkan|r.
.accept 94937 >>Accept Too Quiet on the Northern Front
.target Tekkan
step
#arrowtext Click on\n|cRXP_PICK_Burrow|r
.goto 2512,52.80,34.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Burrow|r.
.complete 94937,1 
step
#arrowtext Kill\n|cRXP_ENEMY_ambush|r
.goto 2512,52.95,34.18
>>Kill the |cRXP_ENEMY_ambush|r.
.complete 94937,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tekkan|r
.goto 2512,53.38,33.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tekkan|r.
.turnin 94937 >>Turn in Too Quiet on the Northern Front
.target Tekkan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Aol'ggin|r
.goto 2512,53.40,33.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aol'ggin|r.
.accept 94941 >>Accept Saving Recruit Jabat
.target Aol'ggin
step
#arrowtext Defeat\n|cRXP_ENEMY_Hiss'mir|r
.goto 2512,52.93,33.23
>>Defeat |cRXP_ENEMY_Hiss'mir|r.
.complete 94941,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Aol'ggin|r
.goto 2512,56.49,43.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aol'ggin|r.
.turnin 94941 >>Turn in Saving Recruit Jabat
.target Aol'ggin
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Living Legend
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2512,59.38,50.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.accept 96523 >>Accept Living Legend
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2512,59.38,50.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.complete 96523,1 
.target Kehiah
.skipgossipid 140619
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,45.56,48.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.turnin 96523 >>Turn in Living Legend
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,45.56,48.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.accept 96539 >>Accept Last Resort
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hungry Villager|r
.goto 2437,45.53,48.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Hungry Villager|r.
.complete 96539,1 
.target Hungry Villager
.skipgossipid 140621
step
#arrowtext Follow the arrow
.goto 2437,44.46,47.99
>>Follow the arrow.
.complete 96539,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,44.41,48.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.turnin 96539 >>Turn in Last Resort
.accept 96540 >>Accept Strong Hands
.target Kehiah
step
#arrowtext Click on\n|cRXP_PICK_Prowling Lynx|r
.goto 2437,44.20,48.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prowling Lynx|r.
.complete 96540,1 
step
#arrowtext Follow the arrow
.goto 2437,43.87,47.94
>>Follow the arrow.
.complete 96540,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,43.63,47.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.turnin 96540 >>Turn in Strong Hands
.accept 96541 >>Accept Strong Mind
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sly Fox|r
.goto 2437,43.72,47.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sly Fox|r.
.complete 96541,1 
.target Sly Fox
.skipgossipid 140622
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sly Fox|r
.goto 2437,43.72,47.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sly Fox|r.
.complete 96541,2 
.target Sly Fox
.skipgossipid 140649
.skipgossipid 140650
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,45.57,48.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.turnin 96541 >>Turn in Strong Mind
.accept 96543 >>Accept Root of Survival
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hungry Villager|r
.goto 2437,45.53,48.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Hungry Villager|r.
.complete 96543,1 
.target Hungry Villager
.skipgossipid 140651
step
#completewith RootOfSurvivalA
#hidewindow
#arrowtext Kill\n|cRXP_ENEMY_Critters|r\nCollect |cRXP_PICK_Withered Roots|r
#loop
.goto 2437,45.54,47.26,28,0
.goto 2437,44.83,48.22,28,0
.goto 2437,44.88,47.23,28,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Critter|r. Loot them for the |T1:0|t[|cRXP_LOOT_Critter Meat|r].
.complete 96543,3 
.mob Scavenging Critter
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mound of Dirt|r.
.complete 96543,2 
step
#label RootOfSurvivalA
>>Kill the |cRXP_ENEMY_Critter|r. Loot them for the |T1:0|t[|cRXP_LOOT_Critter Meat|r].
.complete 96543,3 
.mob Scavenging Critter
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hungry Villager|r
.goto 2437,45.53,48.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Hungry Villager|r.
.turnin 96543 >>Turn in Root of Survival
.target Hungry Villager
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,45.57,48.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.accept 96544 >>Accept Bravely Burning
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Teho|r
.goto 2437,45.67,49.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Teho|r.
.complete 96544,2 
.target Teho
.skipgossipid 140652
step
#arrowtext Kill\n|cRXP_ENEMY_Enraged Dragonhawks|r
#loop
.goto 2437,44.53,49.12,35,0
.goto 2437,44.91,46.91,35,0
.goto 2437,46.00,47.68,35,0
>>Kill the |cRXP_ENEMY_Enraged Dragonhawks|r.
.complete 96544,1 
.mob Enraged Dragonhawk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,45.70,49.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.turnin 96544 >>Turn in Bravely Burning
.accept 96545 >>Accept Strong Voice
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Angry Raider|r
.goto 2437,45.35,48.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Angry Raider|r and defeat them.
.complete 96545,1 
.target Angry Raider
.mob Angry Raider
.skipgossipid 140655
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,45.27,48.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.turnin 96545 >>Turn in Strong Voice
.accept 96546 >>Accept Strong Heart
.target Kehiah
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sly Fox|r
.goto 2437,45.32,48.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sly Fox|r.
.complete 96546,1 
.target Sly Fox
.skipgossipid 140657
step
#arrowtext Click on\n|cRXP_PICK_Boon|r
.goto 2437,45.35,48.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boon|r.
.complete 96546,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sly Fox|r
.goto 2437,45.31,48.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sly Fox|r.
.complete 96546,3 
.target Sly Fox
.skipgossipid 140656
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2437,45.28,48.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.complete 96546,4 
.target Kehiah
.skipgossipid 141523
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kehiah|r
.goto 2512,59.38,50.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kehiah|r.
.turnin 96546 >>Turn in Strong Heart
.target Kehiah
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Somethin' Bad Inside
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Oma'mema|r
.goto 2512,56.99,48.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Oma'mema|r.
.accept 96089 >>Accept Somethin's Not Right
.target Scout Oma'mema
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Medic La'una|r
.goto 2512,57.01,48.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Medic La'una|r.
.complete 96089,1 
.target Medic La'una
.skipgossipid 139834
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Oma'ema|r
.goto 2512,56.98,48.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Oma'ema|r.
.complete 96089,2 
.target Scout Oma'ema
.skipgossipid 140217
step
#completewith next
#hidewindow
.gossipoption 139837 >>1
.timer 20,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Apothecary Dezi|r
.goto 2512,57.20,48.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Dezi|r.
.complete 96089,3 
.target Apothecary Dezi
.skipgossipid 139837
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Apothecary Dezi|r
.goto 2512,57.20,48.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Dezi|r.
.turnin 96089 >>Turn in Somethin's Not Right
.accept 96090 >>Accept Venemetic
.target Apothecary Dezi
step
#arrowtext Kill\n|cRXP_ENEMY_Vilescar forces|r
#loop
.goto 2512,53.20,46.72,35,0
.goto 2512,57.09,35.06,35,0
.goto 2512,51.94,33.47,35,0
.goto 2512,53.90,39.02,35,0
>>Kill the |cRXP_ENEMY_Vilescar forces|r. Loot them for the |T136016:0|t[|cRXP_LOOT_Virulent Ula'tek Venom|r].
.complete 96090,1 
.mob Vilescar Ambusher
.mob Vilescar Serpentmaster
.mob Vilescar Skirmisher
.mob Vilescar Venomspitter
.mob Vilescar Harrier
.mob Vilescar Poacher
.mob Venom-Sated Snatcher
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Apothecary Dezi|r
.goto 2512,57.20,48.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Dezi|r.
.turnin 96090 >>Turn in Venemetic
.accept 96091 >>Accept Get the Balance Right
.target Apothecary Dezi
step
#arrowtext Use\n[ExtraActionButton]
.goto 2512,57.49,48.78
>>Use the [ExtraActionButton].
*Use the three buttons to balance the three bars. You can use all buttons at the same time.
.complete 96091,1 
step
#arrowtext Click on\n|cRXP_PICK_Medic La'una|r
.goto 2512,57.01,48.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Medic La'una|r.
.complete 96091,2 
.target Medic La'una
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Medic La'una|r
.goto 2512,57.01,48.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Medic La'una|r.
.complete 96091,3 
.target Medic La'una
.skipgossipid 140267
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Oma'ema|r
.goto 2512,56.98,48.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Oma'ema|r.
.complete 96091,4 
.target Scout Oma'ema
.skipgossipid 140269
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Apothecary Dezi|r
.goto 2512,57.20,48.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Dezi|r.
.turnin 96091 >>Turn in Get the Balance Right
.accept 96092 >>Accept That Fool, Ruma
.target Apothecary Dezi
step
#arrowtext Follow the arrow
.goto 2512,64.63,77.25
>>Follow the arrow.
.complete 96092,1 
step
#arrowtext Click on\n|cRXP_PICK_Scrollmaster Ruma|r
.goto 2512,64.53,77.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Scrollmaster Ruma|r.
.complete 96092,2 
.target Scrollmaster Ruma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,64.53,77.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.turnin 96092 >>Turn in That Fool, Ruma
.accept 96093 >>Accept It's a Satchel, Not a Bag
.target Scrollmaster Ruma
step
#include RestedXP Midnight\a) Gnarldor Isle
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,64.54,77.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.turnin 96093 >>Turn in It's a Satchel, Not a Bag
.accept 96094 >>Accept To the Forum
.target Scrollmaster Ruma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,23.84,64.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.turnin 96094 >>Turn in To the Forum
.accept 96095 >>Accept Sampling the Local Wildlife
.target Scrollmaster Ruma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Oma'ema|r
.goto 2512,23.83,64.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Oma'ema|r.
.accept 96096 >>Accept Scout Team Seven
.target Scout Oma'ema
step
#completewith ScoutTeamSevenA
>>Kill the |cRXP_ENEMY_Infected Wildlife|r. Loot them for |T136070:0|t[|cRXP_LOOT_Infectious Wildlife Samples|r].
.complete 96095,1 
.mob Implanted Boar
.mob Tainted Dart Frog
.mob Infected Eagle
.mob Newborn Corpseburster
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Kamaina|r
.goto 2512,24.92,61.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Kamaina|r.
.complete 96096,2 
.target Scout Kamaina
.skipgossipid 139882
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Uha'ne|r
.goto 2512,26.65,56.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Uha'ne|r.
.complete 96096,4 
.target Scout Uha'ne
.skipgossipid 139887
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Dusk Prowler Hano'mon|r
.goto 2512,29.51,62.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dusk Prowler Hano'mon|r.
.complete 96096,1 
.target Dusk Prowler Hano'mon
.skipgossipid 139879
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Ko'ruku|r
.goto 2512,29.70,66.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Ko'ruku|r.
.complete 96096,3 
.target Scout Ko'ruku
.skipgossipid 139883
step
#label ScoutTeamSevenA
#arrowtext Talk to\n|cRXP_FRIENDLY_Wartusk A'pone|r
.goto 2512,26.74,66.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wartusk A'pone|r.
.complete 96096,5 
.target Wartusk A'pone
.skipgossipid 139886
step
#arrowtext Kill\n|cRXP_ENEMY_Infected Wildlife|r
#loop
.goto 2512,25.47,69.17,35,0
.goto 2512,25.22,64.98,35,0
.goto 2512,25.60,61.09,35,0
.goto 2512,28.28,62.67,35,0
.goto 2512,27.48,68.65,35,0
>>Kill the |cRXP_ENEMY_Infected Wildlife|r. Loot them for |T136070:0|t[|cRXP_LOOT_Infectious Wildlife Samples|r].
.complete 96095,1 
.mob Implanted Boar
.mob Tainted Dart Frog
.mob Infected Eagle
.mob Newborn Corpseburster
step
#completewith next
#hidewindow
.gossipoption 140401 >>1
.timer 14,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,23.83,64.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.complete 96095,2 
.target Scrollmaster Ruma
.skipgossipid 140401
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Oma'ema|r
.goto 2512,23.83,64.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Oma'ema|r.
.turnin 96096 >>Turn in Scout Team Seven
.target Scout Oma'ema
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,23.83,64.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.turnin 96095 >>Turn in Sampling the Local Wildlife
.target Scrollmaster Ruma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,23.84,64.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.accept 96097 >>Accept What the Scouts Saw
.target Scrollmaster Ruma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Ko'ruku|r
.goto 2512,23.91,64.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Ko'ruku|r.
.complete 96097,2 
.target Scout Ko'ruku
.skipgossipid 140436
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Kamaina|r
.goto 2512,23.88,64.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Kamaina|r.
.complete 96097,1 
.target Scout Kamaina
.skipgossipid 140435
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Oma'ema|r
.goto 2512,23.84,64.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Oma'ema|r.
.turnin 96097 >>Turn in What the Scouts Saw
.accept 96098 >>Accept The Final Reagents
.target Scout Oma'ema
step
#arrowtext Kill\n|cRXP_ENEMY_Summoner Tsssaani|r
.goto 2512,27.27,59.74
>>Kill |cRXP_ENEMY_Summoner Tsssaani|r. Loot him for |T1526608:0|t[|cRXP_LOOT_Tsssaani's Scales of Summoning|r].
.complete 96098,2 
.mob Summoner Tsssaani
step
#arrowtext Kill\n|cRXP_ENEMY_Conjurer Tetla'ketl|r
.goto 2512,27.46,70.43
>>Kill |cRXP_ENEMY_Conjurer Tetla'ketl|r. Loot him for |T2103797:0|t[|cRXP_LOOT_Tetla'ketl's Conjuring Crest|r].
.complete 96098,1 
.mob Conjurer Tetla'ketl
step
#completewith next
#hidewindow
.gossipoption 140441 >>1
.timer 19,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,23.84,64.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.complete 96098,3 
.target Scrollmaster Ruma
.skipgossipid 140441
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scrollmaster Ruma|r
.goto 2512,23.84,64.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scrollmaster Ruma|r.
.turnin 96098 >>Turn in The Final Reagents
.accept 96099 >>Accept La'una's Fate
.target Scrollmaster Ruma
step
#arrowtext Click on\n|cRXP_PICK_Medic La'una|r
.goto 2512,57.01,48.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Medic La'una|r.
.complete 96099,1 
.target Medic La'una
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Oma'ema|r
.goto 2512,56.99,48.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Oma'ema|r.
.turnin 96099 >>Turn in La'una's Fate
.target Scout Oma'ema
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Bone Deep
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Yl'mul|r
.goto 2512,59.10,68.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Yl'mul|r.
.accept 94031 >>Accept Bones of My Soul
.accept 94035 >>Accept Meat for the Bones
.accept 94036 >>Accept One Final Prisoner
.target Loa Speaker Yl'mul
step
#arrowtext Click on\n|cRXP_PICK_Gillfish|r
.goto 2512,58.92,67.90
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gillfish|r.
.complete 94035,1 
step
#completewith BonesOfMySoulB
>>Kill the |cRXP_ENEMY_Sea Creatures|r. Loot them for the |T970840:0|t[|cRXP_LOOT_Sea Creature Meat|r].
.complete 94035,2 
.mob Depthseeker Threshadon
.mob Aspfrill Grouper
.mob Venomsick Finnow
step
#arrowtext Click on\n|cRXP_PICK_Yl'mul's Skull|r
.goto 2512,58.22,66.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Yl'mul's Skull|r.
.complete 94031,1 
step
#completewith next
#label OneFinalPrisonerA
>>Kill |cRXP_ENEMY_Captain Sal'chatah|r.
.complete 94036,1 
.mob Captain Sal'chatah
step
#completewith OneFinalPrisonerA
#arrowtext Enter the wreck
.goto 2512,57.32,66.53,10 >>Enter the wreck
step
#requires OneFinalPrisonerA
#arrowtext Kill\n|cRXP_ENEMY_Captain Sal'chatah|r
.goto 2512,57.07,66.13
>>Kill |cRXP_ENEMY_Captain Sal'chatah|r.
.complete 94036,1 
.mob Captain Sal'chatah
step
#completewith next
#label BonesOfMySoulA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Yl'mul's Ribcage|r.
.complete 94031,3 
step
#completewith BonesOfMySoulA
#arrowtext Leave the wreck
.goto 2512,57.61,65.85,10 >>Leave the wreck
step
#requires BonesOfMySoulA
#arrowtext Click on\n|cRXP_PICK_Yl'mul's Ribcage|r
.goto 2512,56.94,65.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Yl'mul's Ribcage|r.
.complete 94031,3 
step
#label BonesOfMySoulB
#arrowtext Click on\n|cRXP_PICK_Yl'mul's Other Arm|r
.goto 2512,57.03,67.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Yl'mul's Other Arm|r.
.complete 94031,2 
step
#arrowtext Kill\n|cRXP_ENEMY_Sea Creatures|r
#loop
.goto 2512,57.74,67.79,35,0
.goto 2512,58.44,65.33,35,0
.goto 2512,57.24,64.67,35,0
>>Kill the |cRXP_ENEMY_Sea Creatures|r. Loot them for the |T970840:0|t[|cRXP_LOOT_Sea Creature Meat|r].
.complete 94035,2 
.mob Depthseeker Threshadon
.mob Aspfrill Grouper
.mob Venomsick Finnow
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Yl'mul|r
.goto 2512,59.10,68.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Yl'mul|r.
.turnin 94035 >>Turn in Meat for the Bones
.turnin 94036 >>Turn in Meat for the Bones
.turnin 94031 >>Turn in Meat for the Bones
.accept 94040 >>Accept Meat and Bone and Soul
.target Loa Speaker Yl'mul
step
#arrowtext Follow the arrow
.goto 2512,68.40,82.45
>>Follow the arrow.
.complete 94040,1 
step
#arrowtext Click on\n|cRXP_PICK_Bones|r
.goto 2512,68.40,82.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bones|r.
.complete 94040,3 
.complete 94040,4 
.complete 94040,2 
step
#arrowtext Click on\n|cRXP_PICK_Meat|r
.goto 2512,68.31,82.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Meat|r.
.complete 94040,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Yl'mul|r
.goto 2512,68.37,82.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Yl'mul|r.
.turnin 94040 >>Turn in Meat and Bone and Soul
.target Loa Speaker Yl'mul
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Honored Med'jai
#internal
step
#completewith next
#label TheMedjaiMedallionA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faintly Glowing Gem|r.
.accept 95521 >>Accept The Med'jai Medallion
.target Faintly Glowing Gem
step
#completewith next
#arrowtext Enter\n|cRXP_PICK_Vaults of Atal'Utek|r
.goto 2512,45.78,64.93,22,0
.goto 2512,42.59,64.57,22,0
.goto 2512,42.49,62.41,20,0
.goto 2512,41.48,62.30,20,0
.goto 2509,50.52,86.33,15,0
.goto 2509,48.72,85.93,25,0
.goto 2509,47.24,70.44,20 >>Follow the arrow into the |cRXP_PICK_Vaults of Atal'Utek|r.
*Skip this step if you're already there
step
#hidewindow
#completewith TheMedjaiMedallionA
.goto 2509,47.96,51.82,80 >>1
step
#requires TheMedjaiMedallionA
#arrowtext Talk to\n|cRXP_FRIENDLY_Faintly Glowing Gem|r
.goto 2509,47.96,51.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faintly Glowing Gem|r.
.accept 95521 >>Accept The Med'jai Medallion
.target Faintly Glowing Gem
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Me'si|r
.goto 2509,48.91,64.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Me'si|r.
.turnin 95521 >>Turn in The Med'jai Medallion
.accept 95522 >>Accept Guardians of Death, Guardians in Stone
.target Me'si
step
#completewith next
#label GuardiansOfDeathGuardiansInStoneA
#hidewindow
.complete 95522,1 
step
#completewith GuardiansOfDeathGuardiansInStoneA
#arrowtext Talk to\n|cRXP_FRIENDLY_Amani Windcaller|r
.goto 2509,49.92,61.89
.gossipoption 141705 >>Talk to the |cRXP_FRIENDLY_Amani Windcaller|r
step
#requires GuardiansOfDeathGuardiansInStoneA
#arrowtext Follow the arrow
.goto 2509,38.43,33.05
>>Follow the arrow.
.complete 95522,1 
step
#arrowtext Click on\n|cRXP_PICK_Thaze'ala|r
.goto 2509,38.37,34.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the statue of |cRXP_PICK_Thaze'ala|r.
.complete 95522,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Thaze'ala|r
.goto 2509,38.37,34.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaze'ala|r.
.turnin 95522 >>Turn in Guardians of Death, Guardians in Stone
.accept 95523 >>Accept Worthy of the Past
.accept 95524 >>Accept The Unremembered
.target Thaze'ala
step
#arrowtext Click on\n|cRXP_PICK_Let'aka|r and |cRXP_PICK_Incenses|r
.goto 2509,39.34,49.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the statue of |cRXP_PICK_Let'aka|r and the |cRXP_PICK_Incenses|r.
.complete 95524,1 
step
#arrowtext Kill |cRXP_ENEMY_Soulcoilers|r\nClick on |cRXP_PICK_Sarcophagus|r and |cRXP_PICK_Souls|r
#loop
.goto 2509,39.20,48.20,10,0
.goto 2636,53.25,30.55,10,0
.goto 2636,22.15,36.60,10,0
.goto 2636,27.05,74.69,10,0
.goto 2636,22.15,36.60,10,0
.goto 2636,53.25,30.55,10,0
.goto 2509,39.20,48.20,10,0
.goto 2509,40.76,46.95,25,0
.goto 2509,40.89,35.48,25,0
>>Kill the |cRXP_ENEMY_Soulcoilers|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sarcophagus|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Souls|r.
.complete 95523,1 
.mob Soulcoiler Revenant
.mob Soulcoiler Hierophant
.mob Soulcoiler Hierophant
step
#arrowtext Click on\n|cRXP_PICK_Gal'fon|r and |cRXP_PICK_Bow|r
#loop
.goto 2509,44.06,56.29,8,0
.goto 2509,43.77,56.58,6,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the statue of |cRXP_PICK_Gal'fon|r and the |cRXP_PICK_Bow|r.
.complete 95524,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Thaze'ala|r
.goto 2509,43.93,56.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaze'ala|r.
.turnin 95523 >>Turn in Worthy of the Past
.turnin 95524 >>Turn in The Unremembered
.accept 95954 >>Accept An Ancient Foe
.target Thaze'ala
step
#arrowtext Kill\n|cRXP_ENEMY_High Priest Jin'tal|r
.goto 2509,39.20,48.20,10,0
.goto 2636,53.25,30.55,10,0
.goto 2636,22.15,36.60,10,0
.goto 2636,27.05,74.69,10,0
.goto 2636,48.66,72.76
>>Kill the |cRXP_ENEMY_High Priest Jin'tal|r.
.complete 95954,1 
.mob High Priest Jin'tal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Thaze'ala|r
.goto 2636,60.82,65.98,10,0
.goto 2636,67.04,40.95,8,0
.goto 2636,82.89,45.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaze'ala|r.
.turnin 95954 >>Turn in An Ancient Foe
.accept 95525 >>Accept A Worthy Vigil
.target Thaze'ala
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Me'si|r
.goto 2509,48.92,64.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Me'si|r.
.turnin 95525 >>Turn in A Worthy Vigil
.target Me'si
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Tokka's Crew
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Tokka|r
.goto 2512,57.18,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Tokka|r.
.accept 96110 >>Accept Venom Fishing: Proof is in the Ooze
.target Captain Tokka
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Second Mate Sluggs|r
.goto 2512,51.64,49.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Second Mate Sluggs|r to learn fishing.
.complete 96110,1 
.target Second Mate Sluggs
step
#arrowtext Use\n|T4620674:0|t[Fishing]
.goto 2512,48.05,50.00
>>Use |T4620674:0|t[Fishing].
.complete 96110,2 
.usespell 131474
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Tokka|r
.goto 2512,57.17,48.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Tokka|r.
.turnin 96110 >>Turn in Venom Fishing: Proof is in the Ooze
.accept 98343 >>Accept Venom Fishing: My Second-Best
.target Captain Tokka
step
#arrowtext Follow the arrow
.goto 2512,51.69,49.77
>>Follow the arrow.
.complete 98343,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Second Mate Sluggs|r
.goto 2512,51.64,49.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Second Mate Sluggs|r.
.turnin 98343 >>Turn in Venom Fishing: My Second-Best
.accept 98414 >>Accept A Request from the Captain
.target Second Mate Sluggs
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Tokka|r
.goto 2512,57.17,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Tokka|r.
.turnin 98414 >>Turn in A Request from the Captain
.accept 96111 >>Accept Venom Fishing: Shell of Yourself
.target Captain Tokka
step
#arrowtext Click on\n|cRXP_PICK_Wood Debris|r
#loop
.goto 2512,61.10,76.33,45,0
.goto 2512,62.93,82.43,45,0
.goto 2512,59.01,82.40,45,0
.goto 2512,60.30,76.72,45,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood Debris|r.
.complete 96111,1 
step
#arrowtext Click on\n|cRXP_PICK_Wood Debris Pile|r
.goto 2512,54.69,78.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood Debris Pile|r.
.complete 96111,2 
step
#arrowtext Click on\n|cRXP_PICK_Wood Debris Pile|r
.goto 2512,54.69,78.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wood Debris Pile|r.
.complete 96111,3 
step
#arrowtext Kill\n|cRXP_ENEMY_Master Grenadier Birdie|r
.goto 2512,54.69,78.74
>>Kill |cRXP_ENEMY_Master Grenadier Birdie|r. Loot for [|cRXP_LOOT_Birdie's Bombardment Pack|r].
.complete 96111,4 
.mob Master Grenadier Birdie
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Tokka|r
.goto 2512,57.17,48.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Tokka|r.
.turnin 96111 >>Turn in Venom Fishing: Shell of Yourself
.target Captain Tokka
step
+Not sure yet where the rest of the quest are. Probably locked behind reputation.
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) 90 Unlocking Systems
#internal
step
.isOnQuest 94993
.goto 2393,45.65,70.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Enhushune|r.
.turnin 94993 >>Turn in Adventuring in Midnight
step
.isOnQuest 95008
.goto 2393,45.65,70.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Enhushune|r.
.turnin 95008 >>Turn in Adventuring in Midnight
step
.goto 2393,45.49,70.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r or |Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.acceptmultiple 94957,90777 >>Accept War of Light and Shadow or Feeding the Flame
.acceptmap 94957
.target Lor'themar Theron
step
.isQuestAvailable 95245
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.accept 95245 >>Accept Midnight: World Tour
.target Lor'themar Theron
step
.isOnQuest 93519
.goto 2393,52.55,78.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 93519 >>Turn in Midnight Delves!
.target Valeera Sanguinar
step
.goto 2393,52.55,78.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.target Valeera Sanguinar
.accept 93501 >>Accept The Season Starts: Midnight
step
.goto 2393,52.55,78.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 93501,1 
.skipgossipid 136916
step
.goto 2393,52.43,78.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r
.complete 93501,3 
.target Naleidea Rivergleam
step
.goto 2393,52.54,78.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telemancer Astrandis|r and buy |T5160585:0|t[Delver's Cosmetic Surprise Bag]
.complete 93501,2 
.buy 263179,1
.target Telemancer Astrandis
.use
step
.goto 2393,52.54,78.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 93501 >>Turn in The Season Starts: Midnight
.target Valeera Sanguinar
step
.goto 2393,52.4,78.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reno Jackson|r
.accept 93511 >>Accept A Missing Member
.target Reno Jackson
step
.goto 2393,52.39,78.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reno Jackson|r
.complete 93511,1 
.skipgossipid 137116
step
.goto 2393,52.55,78.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 93511 >>Turn in A Missing Member
.target Valeera Sanguinar
.accept 93525 >>Accept Nulling Nullaeus
step
.isQuestAvailable 92926
.goto 2393,47.65,71.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Astalor Bloodsworn|r
.accept 95114 >>Accept Prey: A Crimson Summons
.target Image of Astalor Bloodsworn
step
#completewith next
#label A Crimson Summons
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin -95114 >>Turn in Prey: A Crimson Summons
.target Astalor Bloodsworn
.accept 92926 >>Accept Prey: Astalor's Initiative
step
#completewith A Crimson Summons
.goto 2393,55.06,63.56,10 >>Enter the House
step
#requires A Crimson Summons
.goto 2393,56.72,65.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin -95114 >>Turn in Prey: A Crimson Summons
.target Astalor Bloodsworn
.accept 92926 >>Accept Prey: Astalor's Initiative
step
.goto 2393,50.34,65.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vaultkeeper Elysa|r.
.accept 94474 >>Accept The Great Vault
.target Vaultkeeper Elysa
step
.goto 2393,48.56,62.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vaskarn|r.
.accept 94430 >>Accept Adventuring Gear
.target Vaskarn









step
.goto 2393,36.57,68.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Hagar|r.
.accept 95324 >>Accept The War Beyond the Roots
.target Elder Hagar
step
.goto 2393,45.43,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 95324 >>Turn in The War Beyond the Roots
.target Lor'themar Theron
step
.isQuestAvailable account,91627
.goto 2393,45.66,62.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jonas Everdawn|r
.accept 91627 >>Accept Saltheril's Haven
.target Jonas Everdawn
step
#completewith next
#label Astalor's Initiative
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin 92926 >>Turn in Prey: Astalor's Initiative
.accept 92945 >>Accept The Power of Anguish
.disablecheckbox
.target Astalor Bloodsworn
step
#completewith Astalor's Initiative
.goto 2395,42.99,10.41,15 >>Enter the House
step
#requires Astalor's Initiative
.goto 2395,42.55,10.59,10,0
.goto 2395,42.81,10.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin 92926 >>Turn in Prey: Astalor's Initiative
.accept 92945 >>Accept The Power of Anguish
.timer 15,RP
.target Astalor Bloodsworn
step
.goto 2395,42.89,10.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r.
.complete 92945,1 
step
.goto 2395,42.94,10.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trap|r.
.complete 92945,2 
step
.goto 2395,42.93,10.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trap|r.
.complete 92945,3 
step
.goto 2395,42.93,10.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Remnant|r
.complete 92945,4 
.timer 7,RP
step
.goto 2395,42.96,10.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ball|r after the roleplay.
.complete 92945,5 
step
.goto 2395,42.80,10.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin 92945 >>Turn in The Power of Anguish
.target Astalor Bloodsworn
.accept 93043 >>Accept When Predator Becomes Prey
step
.goto 2395,43.07,10.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Door|r
.complete 93043,1 
step
.goto 2395,42.87,10.46
>>Kill |cRXP_ENEMY_Captured Gnarldin|r
.complete 93043,2 
.mob Captured Gnarldin
step
#label Predator Becomes Prey
.goto 2395,42.81,10.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin 93043 >>Turn in When Predator Becomes Prey
.target Astalor Bloodsworn
.accept 93086 >>Accept To the Sanctum!
step
.goto 2395,42.51,10.44,10,0
.goto 2395,43.08,10.48,10,0
.goto 2393,55.06,63.56,10,0
.goto 2393,56.72,65.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r inside the building.
.turnin 93086 >>Turn in To the Sanctum!
.accept 92177 >>Accept One Hero's Prey
step
.goto 2393,56.77,65.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Table|r and accept a quest.
.complete 92177,1 
step
.isOnQuest 91627
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91627 >>Turn in Saltheril's Haven
.target Lord Saltheril
.accept 91628 >>Accept Honored Guests
step
.isQuestAvailable account,91628
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.target Lord Saltheril
.accept 91628 >>Accept Honored Guests
step
.isOnQuest 91628
.goto 2393,44.66,71.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight-Lord Sunguard|r
.complete 91628,3 
.skipgossipid 134635
.target Knight-Lord Sunguard
step
.isOnQuest 91628
#completewith next
#label Vyrin the Supplier
.goto 2393,45.5,74.24,10,0
.goto 2393,53.02,62.02,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vyrin the Supplier|r
.complete 91628,5 
.target Vyrin the Supplier
step
#completewith Vyrin the Supplier
.goto 2393,52.79,63.41,30 >>Enter the House|cRXP_WARN_(on the lowest level)|r
step
.isOnQuest 91628
#requires Vyrin the Supplier
.goto 2393,52.79,63.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vyrin the Supplier|r
.complete 91628,5 
.skipgossipid 134638
.target Vyrin the Supplier
step
.isOnQuest 91628
#completewith next
#label Magistrix Bloodflame
.goto 2393,52.96,62,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Bloodflame|r inside the house.
.complete 91628,2 
.target Magistrix Bloodflame
step
#completewith Magistrix Bloodflame
.goto 2393,33.65,51.26,578 >>Leave the building
step
.isOnQuest 91628
#requires Magistrix Bloodflame
.goto 2393,33.65,51.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Bloodflame|r inside the house.
.complete 91628,2 
.skipgossipid 134637
.target Magistrix Bloodflame
step
.isOnQuest 91628
.goto 2393,24.36,71.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger-Captain Dawnfletch|r
.complete 91628,4 
.skipgossipid 134636
.target Ranger-Captain Dawnfletch
step
.isOnQuest 91628
.goto 2395,42.68,47.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91628 >>Turn in Honored Guests
.target Lord Saltheril
step
.isQuestAvailable account,91629
.goto 2395,42.68,47.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.target Lord Saltheril
.accept 91629 >>Accept High Esteem
step
.isOnQuest 91629
#loop
.goto 2395,43.45,47.57,5,0
.goto 2395,43.52,47.68,5,0
.goto 2395,43.55,47.48,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Vendors|r.
.complete 91629,3 
.complete 91629,4 
.complete 91629,1 
.complete 91629,2 
.target Ranger Allorn
.target Neriv
.target Apprentice Diell
.target Armorer Goldcrest
step
.isOnQuest 91629
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Lord Saltheril|r and select faction.
.complete 91629,5 
.skipgossipid 132893
.target Lord Saltheril
step
.isOnQuest 91629
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91629 >>Turn in High Esteem
.target Lord Saltheril
step
.isQuestAvailable account,91963
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.target Lord Saltheril
.accept 91693 >>Accept The Subtle Game
step
.isOnQuest 91693
#loop
.goto 2395,42.88,46.4,15,0
.goto 2395,42.81,45.62,15,0
.goto 2395,42.56,46.23,15,0
.goto 2395,42.43,46.7,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Npcs|r you want to aid this week.
.complete 91693,1 




step
#completewith next
+Dailies unlocked
step
.isOnQuest 91693
.goto 2395,42.68,47.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91693 >>Turn in The Subtle Game
.target Lord Saltheril
step
.goto 2395,43.46,47.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caeris Fairdawn|r
.accept 93930 >>Accept Courting Success
.target Caeris Fairdawn
step
.goto 2437,43.14,69.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Du'gal|r.
.turnin 94909 >>Turn in Blessings of Pestilence
.target Du'gal
.accept 93792 >>Accept Blessings of the Loa
step
.goto 2437,43.19,69.23
.complete 93792,1 
.skipgossipid 133887
step
.goto 2437,43.14,69.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Du'gal|r.
.turnin 93792 >>Turn in Blessings of the Loa
.target Du'gal
step
.goto 2437,45.06,67.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r
.accept 91930 >>Accept The Abundant Lands
.target Chel the Chip
step
.goto 2437,31.56,26.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r
.turnin 91930 >>Turn in The Abundant Lands
.target Chel the Chip
.accept 91932 >>Accept The Abundant Awakening
step
.goto 2437,31.60,26.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dundun|r
.complete 91932,1 
.target Dundun
.skipgossipid 135092
step
.goto 2580,75.95,70.61
>>Step into the Orb
.complete 91932,2 
step
.goto 2580,68.78,61.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,3,1 
step
.goto 2580,67.63,56.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,3,2 
step
.goto 2580,64.03,61.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,3,3 
step
.goto 2580,60.56,80.40
>>Kill |cRXP_ENEMY_Passive Abundant Combatant|r
.complete 91932,4 
.mob Passive Abundant Combatant
step
.goto 2580,47.35,83.87
>>Step on the Altar
.complete 91932,5 
step
#loop
.goto 2580,37.49,86.49,30,0
.goto 2580,42.25,72.61,30,0
.goto 2580,29.74,63.23,30,0
.goto 2580,24.32,76.24,30,0
>>Kill |cRXP_ENEMY_Loanites|r and step on the abundances.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,6 
.mob Loanite Pebble
.mob Loanite Stone
step
.goto 2580,24.54,66.98
>>Step on the Altar
.complete 91932,7 
.scenario 16039,1
step
.goto 2580,24.54,66.98
>>Return more Abundance until removal
.complete 91932,8 
step
.goto 2437,31.60,26.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dundun|r.
.turnin 91932 >>Turn in The Abundant Awakening
.target Dundun
.accept 91933 >>Accept The Abundant Honor
step
.goto 2437,31.57,26.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r.
.complete 91933,2 
.skipgossipid 134905
.target Chel the Chip
step
.goto 2437,31.61,26.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dundun|r.
.turnin 91933 >>Turn in The Abundant Honor
.accept 94361 >>Accept The Abundant Life
.target Dundun
step
.goto 2437,31.56,26.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r.
.accept 89507 >>Accept Abundant Offerings
.target Chel the Chip
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Saltheril's Haven
#internal
step
.goto 2393,45.66,62.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jonas Everdawn|r
.accept 91627 >>Accept Saltheril's Haven
.target Jonas Everdawn
step
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91627 >>Turn in Saltheril's Haven
.target Lord Saltheril
.accept 91628 >>Accept Honored Guests
step
.goto 2393,44.66,71.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight-Lord Sunguard|r
.complete 91628,3 
.skipgossipid 134635
.target Knight-Lord Sunguard
step
#completewith next
#label Vyrin the Supplier
.goto 2393,45.5,74.24,10,0
.goto 2393,53.02,62.02,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vyrin the Supplier|r
.complete 91628,5 
.target Vyrin the Supplier
step
#completewith Vyrin the Supplier
.goto 2393,52.79,63.41,30 >>Enter the House|cRXP_WARN_(on the lowest level)|r
step
#requires Vyrin the Supplier
.goto 2393,52.79,63.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vyrin the Supplier|r
.complete 91628,5 
.skipgossipid 134638
.target Vyrin the Supplier
step
#completewith next
#label Magistrix Bloodflame
.goto 2393,52.96,62,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Bloodflame|r inside the house.
.complete 91628,2 
.target Magistrix Bloodflame
step
#completewith Magistrix Bloodflame
.goto 2393,33.65,51.26,578 >>Leave the building
step
#requires Magistrix Bloodflame
.goto 2393,33.65,51.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Bloodflame|r inside the house.
.complete 91628,2 
.skipgossipid 134637
.target Magistrix Bloodflame
step
.goto 2393,24.36,71.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger-Captain Dawnfletch|r
.complete 91628,4 
.skipgossipid 134636
.target Ranger-Captain Dawnfletch
step
.goto 2395,42.68,47.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91628 >>Turn in Honored Guests
.target Lord Saltheril
.accept 91629 >>Accept High Esteem
step
#loop
.goto 2395,43.45,47.57,5,0
.goto 2395,43.52,47.68,5,0
.goto 2395,43.55,47.48,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Vendors|r.
.complete 91629,3 
.complete 91629,4 
.complete 91629,1 
.complete 91629,2 
.target Ranger Allorn
.target Neriv
.target Apprentice Diell
.target Armorer Goldcrest
step
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Lord Saltheril|r and select faction.
.complete 91629,5 
.skipgossipid 132893
.target Lord Saltheril
step
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91629 >>Turn in High Esteem
.target Lord Saltheril
.accept 91966 >>Accept Saltheril's Soiree
.accept 91693 >>Accept The Subtle Game
step
#loop
.goto 2395,42.88,46.4,15,0
.goto 2395,42.81,45.62,15,0
.goto 2395,42.56,46.23,15,0
.goto 2395,42.43,46.7,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Npcs|r you want to aid this week.
.complete 91693,1 
step
#completewith next
+Daillies unlocked
step
.goto 2395,42.68,47.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r
.turnin 91693 >>Turn in The Subtle Game
.target Lord Saltheril
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Delve Campaign
#internal
step
.goto 2393,52.55,78.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 93501 >>Accept The Season Starts: Midnight
.target Valeera Sanguinar
step
.goto 2393,52.55,78.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 93519 >>Turn in Midnight Delves!
.target Valeera Sanguinar
.accept 93501 >>Accept The Season Starts: Midnight
step
.goto 2393,52.55,78.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 93501,1 
.skipgossipid 136916
step
.goto 2393,52.43,78.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telemancer Astrandis|r
.complete 93501,3 
.target Telemancer Astrandis
step
.goto 2393,52.76,77.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r and buy |T5160585:0|t[Delver's Cosmetic Surprise Bag]
.complete 93501,2 
.skipgossipid 137442
.buy 263179,1
.target Naleidea Rivergleam
step
#label The Season Starts: Midnight1
.goto 2393,52.54,78.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 93501 >>Turn in The Season Starts: Midnight
.target Valeera Sanguinar
step
.goto 2393,52.4,78.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reno Jackson|r
.accept 93511 >>Accept A Missing Member
.target Reno Jackson
step
.goto 2393,52.39,78.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Reno Jackson|r
.complete 93511,1 
.skipgossipid 137116
step
#label The Season Starts: Midnight2
.goto 2393,52.55,78.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 93511 >>Turn in A Missing Member
.target Valeera Sanguinar
.accept 93525 >>Accept Nulling Nullaeus
step
.goto 2507,45.74,66.98
>>Kill |cRXP_ENEMY_Nullaeus|r.
.complete 93525,1 
.mob Nullaeus
step
.goto 2393,52.55,78.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r.
.turnin 93525 >>Turn in Nulling Nullaeus
.target Valeera Sanguinar
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Prey Campaign
#internal
step
.goto 2393,47.65,71.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Astalor Bloodsworn|r
.accept 95114 >>Accept Prey: A Crimson Summons
.target Image of Astalor Bloodsworn
step
#completewith next
#label A Crimson Summons
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin -95114 >>Turn in Prey: A Crimson Summons
.target Astalor Bloodsworn
.accept 92926 >>Accept Prey: Astalor's Initiative
step
#completewith A Crimson Summons
.goto 2393,55.06,63.56,10 >>Enter the House
step
#requires A Crimson Summons
.goto 2393,56.72,65.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin -95114 >>Turn in Prey: A Crimson Summons
.target Astalor Bloodsworn
.accept 92926 >>Accept Prey: Astalor's Initiative
step
.goto 2395,42.51,10.44,10,0
.goto 2395,43.08,10.48,10,0
.goto 2393,55.06,63.56,10,0
.goto 2393,56.72,65.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r inside the building.
.turnin 93086 >>Turn in To the Sanctum!
.accept 92177 >>Accept One Hero's Prey
step
.goto 2393,56.77,65.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Table|r and accept a quest.
.complete 92177,1 
step
>>Complete A Prey
.complete 92177,4
step
.goto 2393,55.05,63.56,10,0
.goto 2393,56.72,65.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin 92177 >>Turn in One Hero's Prey
.target Astalor Bloodsworn
.accept 92178 >>Accept Practical Magic
step
.goto 2393,57.25,64.03,10,0
.goto 2393,56.44,63.61,10,0
.goto 2393,57.16,64.05,10,0
.goto 2393,57.02,60.49,10,0
.goto 2393,56.10,59.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.complete 92178,1 
.target Astalor Bloodsworn
.skipgossipid 135889
step
.goto 2393,55.92,59.12
#arrowtext Click on the\n|cRXP_PICK_Weapon Rack|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r
.complete 92178,2 
step
.goto 2393,56.01,60.02,10,0
.goto 2393,55.4,59.83,10,0
.goto 2393,55.38,59.17
#arrowtext Click on the\n|cRXP_PICK_Arcane Construct|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Construct|r
.complete 92178,3 
step
.goto 2393,56.11,61.10
#arrowtext Click on the\n|cRXP_PICK_Wyrm|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wyrm|r
.complete 92178,4 
.mob Anguish-Imbued Wyrm
step
.goto 2393,56.95,60.43,10,0
.goto 2393,57.16,63.98,10,0
.goto 2393,56.54,64.1,10,0
.goto 2393,56.97,63.41,10,0
.goto 2393,56.73,65.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin 92178 >>Turn in Practical Magic
.target Astalor Bloodsworn
step
.goto 2393,56.73,65.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r.
.accept 92179 >>Accept Dark Mending
.target Astalor Bloodsworn
step
.goto 2393,57.12,60.51,10,0
.goto 2393,55.20,60.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r below.
.complete 92179,1 
.skipgossipid 137748
step
.goto 2393,55.60,61.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bottle|r
.complete 92179,2 
step
.goto 2393,55.35,61.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r
.complete 92179,3 
step
.goto 2393,55.35,61.27
>>Use |T3743197:0|t[Channel Anguish]
.complete 92179,4 
step
.goto 2393,56.71,65.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r upstairs
.turnin 92179 >>Turn in Dark Mending
.target Astalor Bloodsworn
.accept 92180 >>Accept Precious Jewels
step
#loop
.goto 2393,53.85,62.8,15,0
.goto 2393,46.5,58.86,15,0
.goto 2393,54.49,67.55,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Silvermoon Resident|r, |cRXP_FRIENDLY_Blood Knight Adept|r and |cRXP_ENEMY_Blood Knight|r
.complete 92180,1
.skipgossipid 135594
.skipgossipid 135595
.skipgossipid 135596
.target Silvermoon Resident
.target Blood Knight Adept
.mob Blood Knight
step
.goto 2393,55.03,63.43,10,0
.goto 2393,56.71,65.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r.
.turnin 92180 >>Turn in Precious Jewels
.target Astalor Bloodsworn
step
.goto 2393,56.70,65.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r.
*|cRXP_WARN_Unlocks Renown 3|r
.accept 92181 >>Accept Garden Variety Sacrifices
.target Astalor Bloodsworn
step
.goto 2393,34.55,69.9,30,0
.goto 2393,33.61,67.79,30,0
.goto 2393,32.66,72.4,30,0
.goto 2393,35.07,73.95,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elves|r
.complete 92181,2 
.complete 92181,1 
.mob Coalesced Anguish
.target Silvermoon Resident
.target Blood Knight Adept
step
.goto 2393,55.03,63.43,10,0
.goto 2393,56.70,65.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r.
.turnin 92181 >>Turn in Garden Variety Sacrifices
.target Astalor Bloodsworn
.accept 92182 >>Accept The Sheep or the Wolf
step
.goto 2393,56.70,65.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r.
.complete 92182,1 
.skipgossipid 137759
step
.goto 2393,55.60,61.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bottle|r
.complete 92182,2 
step
.goto 2393,55.35,61.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r
.complete 92182,3 
step
.goto 2393,55.35,61.27
>>Use |T3743197:0|t[Channel Anguish]
.complete 92182,4 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r upstairs
.goto 2393,56.72,65.45
.turnin 92182 >>Turn in The Sheep or the Wolf
.target Astalor Bloodsworn
.accept 94446 >>Accept A Nightmarish Task
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Abundance Campaign
#internal
step
.goto 2437,45.06,67.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r
.accept 91930 >>Accept The Abundant Lands
.target Chel the Chip
step
#label Abundant Awakening1
.goto 2437,31.56,26.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r
.turnin 91930 >>Turn in The Abundant Lands
.target Chel the Chip
.accept 91932 >>Accept The Abundant Awakening
step
.goto 2437,31.60,26.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dundun|r
.complete 91932,1 
.target Dundun
.skipgossipid 135092
step
.goto 2580,75.95,70.61
>>Step into the Orb
.complete 91932,2 
step
.goto 2580,68.78,61.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,3,1 
step
.goto 2580,67.63,56.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,3,2 
step
.goto 2580,64.03,61.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,3,3 
step
.goto 2580,60.56,80.40
>>Kill |cRXP_ENEMY_Passive Abundant Combatant|r
.complete 91932,4 
.mob Passive Abundant Combatant
step
.goto 2580,47.35,83.87
>>Step on the Altar
.complete 91932,5 
step
#loop
.goto 2580,37.49,86.49,30,0
.goto 2580,42.25,72.61,30,0
.goto 2580,29.74,63.23,30,0
.goto 2580,24.32,76.24,30,0
>>Kill |cRXP_ENEMY_Loanites|r and step on the abundances.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ore|r
.complete 91932,6 
.mob Loanite Pebble
.mob Loanite Stone
step
.goto 2580,24.54,66.98
>>Step on the Altar
.complete 91932,7 
.scenario 16039,1
step
.goto 2580,24.54,66.98
>>|cRXP_WARN_Wait until removal|r
.complete 91932,8 
step
.goto 2437,31.60,26.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dundun|r.
.turnin 91932 >>Turn in The Abundant Awakening
.target Dundun
.accept 91933 >>Accept The Abundant Honor
step
.goto 2437,31.57,26.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r.
.complete 91933,2 
.skipgossipid 134905
.target Chel the Chip
step
.goto 2437,31.61,26.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dundun|r.
.turnin 91933 >>Turn in The Abundant Honor
.accept 94361 >>Accept The Abundant Life
.target Dundun
step
#label Abundant Awakening2
.goto 2437,31.56,26.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r.
.accept 89507 >>Accept Abundant Offerings
.target Chel the Chip
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Foothold
#internal
step
.isOnQuest 94993
#arrowtext Talk to\n|cRXP_FRIENDLY_Enhushune|r
.goto 2393,45.65,70.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Enhushune|r.
.turnin 94993 >>Turn in Adventuring in Midnight
.target Enhushune
step
.isOnQuest 95008
.goto 2393,45.65,70.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Enhushune|r.
.turnin 95008 >>Turn in Adventuring in Midnight
step
.goto 2393,45.49,70.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r or |Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.acceptmultiple 94957,90777 >>Accept War of Light and Shadow or Feeding the Flame
.acceptmap 94957
.target Lor'themar Theron
step
.isOnQuest 90777
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2424,53.12,58.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
.complete 90777,1 
.skipgossipid 133700
.skipgossipid 138306
.mob Lady Liadrin
step
.isOnQuest 90777
.goto 2424,54.12,58.08
>>Defeat |cRXP_ENEMY_Commander Venel Lightblood|r
*Talk to him |cRXP_WARN_if noone has already|r
.complete 90777,4 
.skipgossipid 134511
.mob Commander Venel Lightblood
step
.isOnQuest 90777
#arrowtext Talk to\n|cRXP_FRIENDLY_War Chaplain Senn|r
#loop
.goto 2424,51.51,57.19,15,0
.goto 2424,51.52,55.24,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_War Chaplain Senn|r |cRXP_WARN_if noone has already|r.
.complete 90777,3 
.skipgossipid 134509
.target War Chaplain Senn
step
.isOnQuest 90777
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.goto 2424,50.19,58.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.complete 90777,2 
.skipgossipid 134577
.target Commander Koruth Mountainfist
step
.isOnQuest 90777
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2424,53.12,58.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
.turnin 90777 >>Turn in Feeding the Flame
.target Lady Liadrin
.accept 88696 >>Accept The Devouring Citadel
step
.isOnQuest 94957
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2424,53.12,58.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
*|cRXP_WARN_This will skip the Level-UP Campaign|r
.complete 94957,1 
.skipgossipid 138308
.skipgossipid 138306
.mob Lady Liadrin


























step
.isOnQuest 94957
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2424,53.12,58.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
.turnin 94957 >>Turn in War of Light and Shadow
.target Lady Liadrin
.accept 88696 >>Accept The Devouring Citadel
step
#arrowtext Click on the\n|cRXP_PICK_Teleporter|r
.goto 2424,51.94,56.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Teleporter|r
.complete 88696,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2405,45.41,63.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r
.turnin 88696 >>Turn in The Devouring Citadel
.target High Exarch Turalyon
.accept 88697 >>Accept Clarity of Purpose
step
#completewith next
#label Clarity of Purpose1
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88697,1 
step
#completewith Clarity of Purpose1
#arrowtext Talk to\n|cRXP_FRIENDLY_Umbric|r
.goto 2405,45.39,63.15
.gossipoption 133258 >>Talk to |cRXP_FRIENDLY_Umbric|r
.timer 4,RP
.target Umbric
step
#requires Clarity of Purpose1
.goto 2405,45.36,63.18
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88697,1 
step
#arrowtext Click on the\n|cRXP_PICK_Void Scryer|r
.goto 2405,45.36,63.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Scryer|r
.complete 88697,2 
step
.isOnQuest 88697
.cast vehicle,1246639 >>Use |T1386549:0|t[Scrying Activation]
step
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88697,3 
step
.isOnQuest 88697
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >> /leavevehicle
step
.isOnQuest 88697
#arrowtext Click on the\n|cRXP_PICK_Void Scryer|r
.goto 2405,45.36,63.18
.cast 1231305 >>Click on the |cRXP_PICK_Void Scryer|r
step
.isOnQuest 88697
.cast vehicle,1246639 >>Use |T1386549:0|t[Scrying Activation]
step
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88697,4 
step
.isOnQuest 88697
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >> /leavevehicle
step
.isOnQuest 88697
#arrowtext Click on the\n|cRXP_PICK_Void Scryer|r
.goto 2405,45.36,63.18
.cast 1231305 >>Click on the |cRXP_PICK_Void Scryer|r
step
.isOnQuest 88697
.cast vehicle,1246639 >>Use |T1386549:0|t[Scrying Activation]
step
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88697,5 
step
.isOnQuest 88697
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >> /leavevehicle
step
#completewith next
#label Clarity of Purpose 2
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r
.turnin 88697 >>Turn in Clarity of Purpose
.target Magister Umbric
step
#completewith Clarity of Purpose 2
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Clarity of Purpose 2
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,45.39,63.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r
.turnin 88697 >>Turn in Clarity of Purpose
.accept 88698 >>Accept Master of Mayhem
.accept 88699 >>Accept Powerless
.target Magister Umbric
step
#completewith Overcrofts
>>Kill |cRXP_ENEMY_Overcrofts|r
.complete 88698,1 
.mob Overcroft Technician
.mob Overcroft Inquisitor
.mob Overcroft Automaton
.mob Overcroft Militant
step
#completewith next
#label Leona Darkstrider
#hidewindow
.complete 88699,1 
step
#completewith Leona Darkstrider
#arrowtext Click on the\n|cRXP_PICK_Cage|r
.goto 2405,45.89,67.72
.cast 1247229 >>Click on the |cRXP_PICK_Cage|r
step
#requires Leona Darkstrider
#completewith next
#label Lady Darkglen
#hidewindow
.complete 88699,2 
step
#requires Leona Darkstrider
#completewith Lady Darkglen
#arrowtext Click on the\n|cRXP_PICK_Cage|r
.goto 2405,47.89,68.67
.cast 1247229 >>Click on the |cRXP_PICK_Cage|r
step
#requires Lady Darkglen
#completewith next
#label Riftblade Kelain freed
#hidewindow
.complete 88699,3 
step
#requires Lady Darkglen
#completewith Riftblade Kelain freed
#arrowtext Click on the\n|cRXP_PICK_Cage|r
.goto 2405,46.87,72.76
.cast 1247229 >>Click on the |cRXP_PICK_Cage|r
step
#requires Riftblade Kelain freed
#label Overcrofts
#arrowtext Click on the\n|cRXP_PICK_Console|r
.goto 2405,46.84,70.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r
.complete 88699,4 
step
#loop
.goto 2405,47.12,67.65,30,0
.goto 2405,46.09,68.32,30,0
.goto 2405,46.51,70.41,30,0
.goto 2405,46.12,72.63,30,0
.goto 2405,47.25,72.24,30,0
.goto 2405,47.97,71.14,30,0
>>Kill |cRXP_ENEMY_Overcrofts|r
.complete 88698,1 
.mob Overcroft Technician
.mob Overcroft Inquisitor
.mob Overcroft Automaton
.mob Overcroft Militant
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,45.39,63.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r
.turnin 88698 >>Turn in Master of Mayhem
.target Magister Umbric
.turnin 88699 >>Turn in Powerless
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2405,45.41,63.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r
.accept 88700 >>Accept Two Tons of Metal and Holy Fire
.target High Exarch Turalyon
step
#arrowtext Click on the\n|cRXP_PICK_Robot|r
.goto 2405,45.12,63.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Robot|r
.complete 88700,1 
.timer 10,RP
.target Assault Warframe
step
>>Use |T5764902:0|t[Purifying Blast] on cooldown; otherwise |T135972:0|t[Light Dart] on |cRXP_ENEMY_Voidbeings|r
*> |cRXP_WARN_Hit as many targets as possible with each cast|r.
*> |cRXP_WARN_Abandon and reaccept the quest if you don't start flying.|r
.complete 88700,2 
step
#completewith next
#label Holy Fire
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r
.turnin 88700 >>Turn in Two Tons of Metal and Holy Fire
.target High Exarch Turalyon
.accept 91417 >>Accept Seek out Arator
.disablecheckbox
step
#completewith Holy Fire
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >> /leavevehicle
step
#requires Holy Fire
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2405,45.40,63.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r
.turnin 88700 >>Turn in Two Tons of Metal and Holy Fire
.target High Exarch Turalyon
.accept 91417 >>Accept Seek out Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,46.00,64.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r
.turnin 91417 >>Turn in Seek out Arator
.target Arator
.accept 88701 >>Accept The Memory Remains
.accept 88702 >>Accept Aegis of the Redeemer
step
#hidewindow
#completewith Subjugator
#loop
.goto 2405,47.62,62.4,20,0
.goto 2405,48.24,62.42,20,0
.goto 2405,46.7,61.2,20,0
.goto 2405,46.57,59.89,20,0
.goto 2405,46.26,58.85,20,0
.goto 2405,45.84,60.2,20,0
.goto 2405,46.37,61.3,30,0
.goto 2405,46.7,62.98,30,0
.goto 2405,47.6,63.41,30,0
+1
step
#completewith next
#arrowtext Click on the\n|cRXP_PICK_Dead Scouts|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Scouts|r
.complete 88701,1 
step
#arrowtext Click on the\n|cRXP_PICK_Vanguard Scouts|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vanguard Scouts|r |cRXP_WARN_if noone has already|r
*Kill the waves of enemies.
.complete 88702,1 
.mob Relentless Ultradon
.mob Obscurion Subjugator
.mob Obscurion Stalker
.target Vanguard Scout
step
#label Subjugator
#arrowtext Click on the\n|cRXP_PICK_Dead Scouts|r
.goto 2405,46.39,61.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dead Scouts|r
.complete 88701,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r |cRXP_WARN_next to you|r.
.turnin 88702 >>Turn in Aegis of the Redeemer
.turnin 88701 >>Turn in The Memory Remains
.accept 91426 >>Accept The People's Champion
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,46.33,63.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r |cRXP_WARN_after the roleplay|r.
.turnin 91426 >>Turn in The People's Champion
.accept 88703 >>Accept The Night Before
.target Arator
step
.goto 2405,51.68,64.96
#title |cFFFCDC00Follow the Arrow|r
.complete 88703,1 
step
#completewith next
#label Alleria assisted
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88703,2 
step
#completewith Alleria assisted
#arrowtext Click on the\n|cRXP_PICK_Voidstalker|r
.goto 2405,51.69,64.96
.cast 1242709 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Voidstalker|r.
.timer 20.1,RP
.target Voidstalker
step
#requires Alleria assisted
.goto 2405,51.66,64.95
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 88703,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,51.66,64.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r
.turnin 88703 >>Turn in The Night Before
.target Alleria Windrunner
.accept 88704 >>Accept The Patient Hunter
step
#arrowtext Click on the\n|cRXP_PICK_Corpse|r
.goto 2405,52.49,65.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Corpse|r.
.complete 88704,1 
.target Dead Vanguard
step
#arrowtext Click on the\n|cRXP_PICK_Corpse|r
.goto 2405,53.27,65.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Corpse|r.
.complete 88704,2 
.target Vanguard Medic
step
#arrowtext Click on the\n|cRXP_PICK_Blood|r
.goto 2405,53.98,65.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blood|r.
.complete 88704,3 
step
.goto 2405,55.15,64.25
#title |cFFFCDC00Follow the Arrow|r
>>If this doesn't progress when you reach the waypoint, move in and out of the area.
.complete 88704,4 
step
.goto 2405,55.4,64.35
>>Kill the waves of enemies
.complete 88704,5 
.mob Voidstalker Patriarch
.mob Voidstalker
step
#arrowtext Click on the\n|cRXP_PICK_Portal|r
.goto 2405,55.4,64.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 88704,6 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nadia Brighton|r
.goto 2405,56.29,65.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nadia Brighton|r
.turnin 88704 >>Turn in The Patient Hunter
.target Nadia Brighton
.accept 88705 >>Accept Killing Blow
step
#arrowtext Click on\n|cRXP_PICK_Nadia Brighton|r
.goto 2405,56.29,65.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Nadia Brighton|r
.complete 88705,1 
.target Nadia Brighton
step
.goto 2405,56.75,64.95,10,0
.goto 2405,56.25,65.31
#title |cFFFCDC00Drop down|r
>>Leave the Cave
.complete 88705,2 
step
.goto 2405,56.04,65.41
>>Kill |cRXP_ENEMY_Voidstalker Patriarch|r
.complete 88705,3 
.timer 23,RP
.mob Voidstalker Patriarch
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,55.93,64.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r
.turnin 88705 >>Turn in Killing Blow
.target Alleria Windrunner
.accept 88706 >>Accept Nothing Stands Forever
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Turalyon|r
.goto 2405,45.19,62.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turalyon|r.
.complete 88706,1 
.skipgossipid 138593
.target Turalyon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_High Exarch Turalyon|r
.goto 2405,45.19,62.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r
.turnin 88706 >>Turn in Nothing Stands Forever
.target High Exarch Turalyon
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Voidspire
#internal
#chapter
step
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 90690 >>Accept Charge of the Vanguard
.target Lor'themar Theron
step
.goto 2405,45.40,63.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Exarch Turalyon|r.
.turnin 90690 >>Turn in Charge of the Vanguard
.target High Exarch Turalyon
.accept 88709 >>Accept The Voidspire
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar|r.
.turnin 88709 >>Turn in The Voidspire
.accept 92520 >>Accept Wake of the Darkwell
.target High Exarch Turalyon
step
#completewith next
.goto 2405,44.55,66.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Venzilion the Reality Cracker|r to Queue for story mode.
.complete 88709,2 
.skipgossipid 137728
.target Venzilion the Reality Cracker
step
>>Kill |cRXP_ENEMY_Alleria Windrunner|r inside the Voidspire Raid.
.complete 88709,3 
.mob Alleria Windrunner
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 88709 >>Turn in The Voidspire
.target Arator
.accept 90724 >>Accept The Broken Sky
step
#completewith next
.gossipoption 139331 >>Talk to |cRXP_FRIENDLY_Arator|r to teleport to silvermoon.
.target Arator
step
.goto 2393,45.45,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 90724 >>Turn in The Broken Sky
.accept 92520 >>Accept Wake of the Darkwell
.target Lor'themar Theron
step
.goto 2424,49.71,81.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Anduin Wrynn|r
.complete 92520,1 
.target Anduin Wrynn
step
.goto 2424,45.78,68.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prophet Velen|r
.complete 92520,2 
.target Prophet Velen
step
.goto 2424,51.34,62.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Moira Thaurissan|r
.complete 92520,4,1 
.target Moira Thaurissan
step
.goto 2424,47.84,61.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Calia Menethil|r
.complete 92520,4,2 
.target Calia Menethil
step
.goto 2424,41.05,57.6
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_High Prelate Rata|r
.complete 92520,4,3 
.target High Prelate Rata
step
.goto 2424,35.57,45.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tahu Sagewind|r
.complete 92520,4,4 
.target Tahu Sagewind
step
.goto 2424,45.20,38.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Faerin Lothar|r
.complete 92520,3 
.target Faerin Lothar
step
#completewith next
#label Wake of the Darkwell
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 92520 >>Turn in Wake of the Darkwell
.target Lor'themar Theron
step
#completewith Wake of the Darkwell
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires Wake of the Darkwell
.goto 2393,45.44,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 92520 >>Turn in Wake of the Darkwell
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Gathering of the Elves
#internal
#chapter
step
.goto 2393,45.85,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 88920 >>Accept The Kaldorei
.target Arator
step
.goto 2393,45.44,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arathor|r.
.complete 88920,1 
.skipgossipid 136564
.target Arathor
step
.goto 2393,47.54,69.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 88920,2 
step
.goto 2239,48.33,70.66
#title |cFFFCDC00Follow the Arrow|r
.complete 88920,3 
step
.goto 2239,48.33,70.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shandris Feathermoon|r.
.turnin 88920 >>Turn in The Kaldorei
.accept 88923 >>Accept Children of the Stars
.target Shandris Feathermoon
step
.goto 2239,48.36,70.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.complete 88923,1 
.skipgossipid 135655
.target Lor'themar Theron
step
.goto 2239,48.27,70.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.complete 88923,2 
.skipgossipid 135656
.target Magister Umbric
step
.goto 2239,48.40,70.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.complete 88923,3 
.skipgossipid 135657
.target First Arcanist Thalyssra
step
.goto 2239,48.33,70.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shandris Feathermoon|r.
.turnin 88923 >>Turn in Children of the Stars
.target Shandris Feathermoon
.accept 88925 >>Accept Awaken the Ancient of War
.accept 88927 >>Accept Awaken the Ancient Protector
.accept 88937 >>Accept Awaken the Ancient of Lore
step
.goto 2239,44.99,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uylian|r.
.complete 88927,1 
.target Uylian
step
#loop
.goto 2239,45.5,70.27,15,0
.goto 2239,43.61,67.15,15,0
.goto 2239,42.3,67.44,15,0
.goto 2239,41.11,68.8,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boulders|r
.complete 88927,2 
step
.goto 2239,45.15,72.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Verdantbark|r.
.complete 88927,3 
.skipgossipid 137249
.target Elder Verdantbark
step
.goto 2239,50.72,51.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Venlinal|r.
.complete 88925,1 
.target Venlinal
step
.goto 2239,50.36,51.52,15,0
.goto 2239,50.69,49.61,15,0
.goto 2239,51.18,52.84,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Roots|r
.complete 88925,2 
step
.goto 2239,51.05,51.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Root|r
.complete 88925,3 
step
.goto 2239,56.86,65.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malastral|r.
.complete 88937,1 
.target Malastral
.skipgossipid 137236
step
#loop
.goto 2239,63.08,57.93,30,0
.goto 2239,68.03,67.52,30,0
.goto 2239,62.75,75.33,30,0
>>Fly through Wisps
.complete 88937,2 
step
.goto 2239,56.95,64.99
#title |cFFFCDC00Follow the Arrow|r
.complete 88937,3 
step
.goto 2239,48.33,70.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shandris Feathermoon|r.
.turnin 88927 >>Turn in Awaken the Ancient Protector
.turnin 88937 >>Turn in Awaken the Ancient of Lore
.turnin 88925 >>Turn in Awaken the Ancient of War
.target Shandris Feathermoon
step
.goto 2239,48.32,70.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 88922 >>Accept The Quel'dorei
.target Arator
step
.goto 2537,15.29,78.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 88922,2 
step
.goto 2395,31.22,91.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 88922 >>Turn in The Quel'dorei
.target Arator
step
.goto 2395,31.18,91.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r.
.accept 88939 >>Accept Rest for the Restless
.target Vereesa Windrunner
.accept 88938 >>Accept Symbols of the Past
step
.goto 2395,30.22,90.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crown|r
.complete 88938,2 
step
.goto 2395,30.38,92.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 88938,3 
step
#loop
.goto 2395,31.06,92.54,30,0
.goto 2395,31,94.26,30,0
.goto 2395,29.86,94.37,30,0
.goto 2395,29.82,92.75,30,0
>>Kill |cRXP_ENEMY_Purged of Dalarans|r
.complete 88939,1 
.mob Purged of Dalaran
step
.goto 2395,31.18,91.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r.
.turnin 88939 >>Turn in Rest for the Restless
.target Vereesa Windrunner
.turnin 88938 >>Turn in Symbols of the Past
.accept 88941 >>Accept For Quel'Thalas
step
#completewith next
#label Meet Vereesa
#hidewindow
.complete 88941,1 
step
#completewith Meet Vereesa
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires Meet Vereesa
.goto 2395,50.57,34.52
#title |cFFFCDC00Follow the Arrow|r
.complete 88941,1 
step
.goto 2395,50.57,34.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r.
.complete 88941,2 
.skipgossipid 136655
.target Archmage Aethas Sunreaver
step
.goto 2393,45.79,70.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r.
.turnin 88941 >>Turn in For Quel'Thalas
.target Vereesa Windrunner
step
.goto 2393,45.70,70.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.accept 88928 >>Accept The Shal'dorei
.target First Arcanist Thalyssra
step
.goto 2393,47.53,69.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 88928,1 
step
.goto 680,70.54,74.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seneschal Ulen|r.
.turnin 88928 >>Turn in The Shal'dorei
.target Seneschal Ulen
.accept 88930 >>Accept Drained Mana
step
.goto 680,70.60,74.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.accept 88929 >>Accept An Illusion!
.target First Arcanist Thalyssra
step
#completewith Strange Smell
>>Use |T1354190:0|t[Nightwatch Mask] next to |cRXP_ENEMY_Nighthold Citizen|r
.target Nighthold Citizen
.use 248920
.mob Twilight Voidcaller
step
.goto 680,70.15,76.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drained Protector|r
.complete 88930,1 
.target Drained Protector
step
.goto 680,70.63,79.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillar|r
.complete 88930,2 
step
.goto 680,71.62,79.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Seneschal Ulen|r
.complete 88930,3 
.target Seneschal Ulen
step
#loop
.goto 680,71.79,80.04,30,0
.goto 680,70.55,78.32,30,0
.goto 680,70.7,75.44,30,0
.goto 680,69.93,77.66,30,0
>>Use |T1354190:0|t[Nightwatch Mask] next to |cRXP_ENEMY_Nighthold Citizen|r
*Kill |cRXP_ENEMY_Twilight Voidcaller|r
.target Nighthold Citizen
.use 248920
.mob Twilight Voidcaller
step
.goto 680,70.15,74.94,30,0
.goto 680,70.58,74.26
#title |cFFFCDC00Follow the Arrow|r
.complete 88930,4 
.timer 10,RP
step
.goto 680,70.59,74.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.turnin 88930 >>Turn in Drained Mana
.target First Arcanist Thalyssra
.turnin 88929 >>Turn in An Illusion!
.accept 88919 >>Accept Into the Darkway
step
.goto 680,70.58,74.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Darkway|r
.complete 88919,1 
step
#include RestedXP Midnight\a) The Darkway@DarkwayA-DarkwayB
step
.goto 2393,40.42,32.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.turnin 88919 >>Turn in Into the Darkway
.target First Arcanist Thalyssra
.accept 88942 >>Accept The Elves are Going to War
step
.goto 2393,45.76,70.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 88942 >>Turn in The Elves are Going to War
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Battle of the Bridge
#internal
#chapter
step
.goto 2393,45.85,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 88769 >>Accept The Battle of the Bridge
.target Arator
step
.goto 2393,45.85,70.34
.enterScenario 2943 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.skipgossipid 133560
.target Arator
step
.isInScenario 2943
.goto 2393,45.85,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.scenario 13282,1 
.target Arator
.skipgossipid 133407
step
.isInScenario 2943
#loop
.goto 2443,45.24,47.18,25,0
.goto 2443,43.26,44.08,25,0
.goto 2443,31.92,34.76,35,0
.goto 2443,30.47,28.56,30,0
>>Use |T236168:0|t[ExtraActionButton] on |cRXP_ENEMY_Twilights|r
*|cRXP_WARN_Make sure to tag them first|r
.scenario 14282,1,100
.mob Twilight Shadowblade
.mob Twilight Void Swarmer
.mob Twilight Void Caller
.mob Twilight Duskwarden
.mob Twilight Living Shadow
step
.isInScenario 2943
.goto 2443,32.27,25.26
>>Kill |cRXP_ENEMY_Udor Eyestabber|r and |cRXP_ENEMY_Bleck the Voidspitter|r
.scenario 13283,1
.scenario 13283,2
.mob Udor Eyestabber
.mob Bleck the Voidspitter
step
.isInScenario 2943
#loop
.goto 2443,28.49,27.48,40,0
.goto 2443,27.31,23.38,20,0
.goto 2443,27.71,18.96,20,0
.goto 2443,25.55,18.15,25,0
.goto 2443,24.85,13.84,30,0
.goto 2443,28.81,11.68,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Turrets|r
.scenario 13284,1
step
.isInScenario 2943
>>Use the |T135815:0|t|cRXP_WARN_[ExtraActionButton]|r
.scenario 15955,1 
step
.isInScenario 2943
#arrowtext |cRXP_WARN_You can skyride now|r
.goto 2443,45.66,35.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.scenario 14355,1 
.skipgossipid 133517
.target Arator at the bridge
step
.isInScenario 2943
.goto 2443,45.68,10.23
>>Kill |cRXP_ENEMY_Devourings|r at cross the bridge with the team
.scenario 13285,1 
.mob Devouring Remnant
.mob Devouring Voidripper
.mob Devouring Colossus
step
.goto 2443,45.64,6.14
.isInScenario 2943
>>Kill |cRXP_ENEMY_Imperator Nocturnius|r
*|cRXP_WARN_Move out of the Aoe|r
.scenario 13287,1 
.mob Imperator Nocturnius
step
.isInScenario 2943
.goto 2443,45.64,3.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r |cRXP_WARN_after the roleplay|r.
.complete 88769,1 
.skipgossipid 133531
.target Arathor
step
.goto 2424,52.59,90.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 88769 >>Turn in The Battle of the Bridge
.target Arator
.accept 88710 >>Accept March on Quel'Danas
step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tactical Telemancer Seralia|r.
.complete 88710,1 
.skipgossipid 137768
.target Tactical Telemancer Seralia
step
.goto 2424,49.72,87.53
>>Kill |cRXP_ENEMY_L'ura|r inside the March of Quel'danas Raid
.complete 88710,2
.mob L'ura
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r inside the March of Quel'danas Raid.
.turnin 88710 >>Turn in March on Quel'Danas
.target Arator
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) The Darkwell
#internal
#chapter





step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tactical Telemancer Seralia|r.
.complete 88710,1 
.skipgossipid 137768
.target Tactical Telemancer Seralia
step
.goto 2424,49.72,87.53
>>Kill |cRXP_ENEMY_L'ura|r inside the March of Quel'danas Raid
.complete 88710,2
.mob L'ura
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r inside the March of Quel'danas Raid.
.turnin 88710 >>Turn in March on Quel'Danas
.target Arator
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Dawn of a New Well
#internal
#chapter
step
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 92689 >>Accept A Path Forward
.target Lor'themar Theron
step
.goto 2393,53.44,60.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r.
.accept 90876 >>Accept Reluctant Hand
.target Grand Magister Rommath
step
.goto 2393,54.23,59.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Harmonial|r
.complete 90876,1 
step
.goto 2393,53.79,58.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lab Bench|r
.complete 90876,2 
step
.goto 2393,54.27,58.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 90876,3 
step
.goto 2393,54.17,59.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 90876 >>Turn in Reluctant Hand
.target Magister Umbric
.complete 92689,1 
step
.goto 2393,40.15,89.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r.
.accept 90871 >>Accept The Silversun Compact
.target Vereesa Windrunner
step
.goto 2393,39.70,87.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 90871,1 
step
.goto 2393,41.47,86.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r
.complete 90871,2 
step
.goto 2393,41.03,87.51,10,0
.goto 2393,41.22,88.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.complete 90871,3 
step
.goto 2393,41.23,88.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r.
.turnin 90871 >>Turn in The Silversun Compact
.target Vereesa Windrunner
.complete 92689,2 
step
.goto 2393,45.45,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 90861 >>Accept Those Left Behind
.target Lor'themar Theron
step
.goto 2424,52.71,58.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 90861 >>Turn in Those Left Behind
.accept 90862 >>Accept In Times of Need
.target Arator
step
.goto 2424,56.21,60.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.complete 90862,2 
.skipgossipid 133843
.mob First Arcanist Thalyssra
step
.goto 2424,52.63,67.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r.
.complete 90862,4 
.skipgossipid 133852
.target Vereesa Windrunner
step
.goto 2424,48.36,64.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.complete 90862,3 
.skipgossipid 133846
.target Magister Umbric
step
.goto 2424,38.18,57.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shandris Feathermoon|r.
.complete 90862,1 
.target Shandris Feathermoon
step
.goto 2424,52.62,46.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 90862 >>Turn in In Times of Need
.target Lady Liadrin
.accept 90867 >>Accept From Darkness, Light
step
.goto 2424,52.62,46.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liadrin|r.
.complete 90867,1 
.skipgossipid 134464
.target Liadrin to begin the Ritual
step
.goto 2424,52.60,45.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 90867 >>Turn in From Darkness, Light
.target Lady Liadrin
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) 12.0.5 Campaign
#internal
step
.goto 2393,48.06,49.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Captain Lilatha|r.
.accept 96080 >>Accept Void Strike
.target Ranger Captain Lilatha
step
>>Complete A Void Strike they are labeled with an indicator on your map
.complete 96080,1 
step
.goto 2393,48.07,49.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Captain Lilatha|r.
.turnin 96080 >>Turn in Void Strike
.target Ranger Captain Lilatha
step
.goto 2393,48.07,49.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Captain Lilatha|r.
.accept 94381 >>Accept Outfitting and Allies
.target Ranger Captain Lilatha
step
.goto 2393,48.05,49.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kul'amara the Fierce|r.
.complete 94381,2 
.accept 94383 >>Accept Ritual Interest
.target Kul'amara the Fierce
step
.goto 2393,47.69,50.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rae'ana|r.
.complete 94381,4 
.target Rae'ana
step
.goto 2393,47.68,49.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin 94383 >>Turn in Ritual Interest
.target Lady Darkglen
.accept 94382 >>Accept Ritual Problems
step
.goto 2393,47.84,49.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tome|r
.complete 94382,1 
step
.goto 2393,48.04,49.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maren Silverwing|r.
.complete 94381,1 
.target Maren Silverwing
step
.goto 2393,48.06,49.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Captain Lilatha|r.
.turnin 94381 >>Turn in Outfitting and Allies
.target Ranger Captain Lilatha
step
#include a) Ritual Sites
step
#completewith next
#label Questionable Power
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin -95547 >>Turn in Ritual Site Challenge Report: Tendrils
.accept 95549 >>Accept Raising Magical Alarms
.accept 95552 >>Accept Dark Obelisk Investigation
.target Lady Darkglen
step
#completewith Questionable Power
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629

step
#requires Questionable Power
.goto 2393,47.69,49.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin 95547 >>Turn in Ritual Site Challenge Report: Tendrils
.turnin 94382 >>Turn in Ritual Problems
.accept 95549 >>Accept Raising Magical Alarms
.accept 95552 >>Accept Dark Obelisk Investigation
.target Lady Darkglen
step
.isQuestComplete 95554
.goto 2393,47.69,49.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.turnin 95554 >>Turn in Questionable Power
.target Lady Darkglen
step
.goto 2393,48.07,49.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Captain Lilatha|r.
.accept 95553 >>Accept Manifested Density
.accept 95550 >>Accept Thin Their Ranks
.target Ranger Captain Lilatha
step
.goto 2437,68.23,20.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Depthdiver Jeju|r.
.accept 96388 >>Accept Joining the Abyss Anglers
.target Depthdiver Jeju
step
.goto 2437,68.24,20.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Depthdiver Jeju|r.
.complete 96388,1 
.skipgossipid 139814
.target Depthdiver Jeju














step
#hidewindow
#completewith Fish Caught
#loop
.goto 2437,72.59,17.24,40,0
.goto 2437,71.76,18.78,40,0
.goto 2437,71.82,19.92,40,0
.goto 2437,73.53,19.68,40,0
+1
step
#completewith next
>>Use and aim |T1376040:0|t[Fire Harpoon] on Fish
*Use |T1698701:0|t[Dash] for a speedboost
.complete 96388,2 
.mob Zipperfish
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Relic|r
.complete 96388,3 
step
#label Fish Caught
>>Use and aim |T1376040:0|t[Fire Harpoon] on Fish
.complete 96388,2 
step
>>Use |T4622460:0|t[Surface!] to return to the surface and accept the prompt.
.complete 96388,4 
step
.goto 2437,68.24,20.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Depthdiver Jeju|r.
.turnin 96388 >>Turn in Joining the Abyss Anglers
.target Depthdiver Jeju
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Legacy of the Amani
#internal
step
.isQuestTurnedIn account,93417
.goto 2393,45.38,70.06
.gossipoption 142319 >>Talk to |cRXP_FRIENDLY_Orweyna|r to skip chapter 1.
.target Orweyna
step
.isOnQuest 92897
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2393,45.39,70.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92897 >>Turn in The Preparations Are Complete
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2393,45.38,70.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 92895 >>Accept Hagar's Invitation
.target Orweyna
step
#arrowtext Click on the\n|cRXP_PICK_Rootway to Harandar|r
.goto 2393,36.92,68.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rootway to Harandar|r.
.complete 92895,1 
step
#title Follow the arrow
.goto 2576,44.24,53.11
.complete 92895,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2576,43.91,53.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92895 >>Turn in Hagar's Invitation
.accept 92899 >>Accept History Lesson
.target Orweyna
step
#loop
#arrowtext Talk to\n|cRXP_FRIENDLY_delegates|r
.goto 2576,44.45,56.94,10,0
.goto 2576,48.62,54.03,10,0
.goto 2576,50.01,41.91,10,0
.goto 2576,45.54,43.96,10,0
.goto 2576,42.44,43.06,10,0
.goto 2576,41.93,49.22,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_delegates|r.
.complete 92899,1 
.skipgossipid 137855
.skipgossipid 137842
.skipgossipid 137814
.skipgossipid 137843
.skipgossipid 137922
.skipgossipid 137861
.target Shandris Feathermoon
.target Vereesa Windrunner
.target Rokhan
.target Queen Talanji
.target First Arcanist Thalyssra
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2576,43.92,53.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 92899,2 
.target Orweyna
.skipgossipid 138840
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Kinduru|r
.goto 2576,43.52,51.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Kinduru|r.
.turnin 92899 >>Turn in History Lesson
.accept 92900 >>Accept A Favor for Kinduru
.target Loa Speaker Kinduru
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2413,54.43,52.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.complete 92900,3 
.target Zul'jan
.skipgossipid 137073
step
#title Fly up. Follow the arrow
.goto 2413,38.78,46.78
.complete 92900,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2413,38.77,46.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 92900 >>Turn in A Favor for Kinduru
.target Zul'jan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,38.73,46.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 92901 >>Accept Revisionist History
.target Orweyna
step
#arrowtext Click on the\n|cRXP_PICK_Ancient Visionstone|r
.goto 2413,37.56,47.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Visionstone|r
.complete 92901,1 
step
#loop
#arrowtext Click on |cRXP_PICK_Injured Amani Warrior|r\nKill |cRXP_ENEMY_Enemies of the Amani|r
.goto 2413,36.08,46.12,25,0
.goto 2413,35.50,45.89,25,0
.goto 2413,35.06,44.03,25,0
.goto 2413,33.97,44.51,30,0
.goto 2413,37.18,48.48,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Injured Amani Warrior|r.
>>Kill the |cRXP_ENEMY_Enemies of the Amani|r.
.complete 92901,2 
.mob Enemy of the Amani
step
#arrowtext Use |T136070:0|t[ExtraActionButton]
.goto 2413,34.97,43.84
>>Use the |T136070:0|t[ExtraActionButton]
.complete 92901,3 
.timer 18,Orweyna Roleplay
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,34.88,43.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_after the roleplay|r.
.turnin 92901 >>Turn in Revisionist History
.timer 8,Zul'jan Roleplay
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2413,34.89,44.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r |cRXP_WARN_after the roleplay|r.
.accept 92904 >>Accept Return to Zul'Aman
.timer 21,Portal Roleplay
.target Zul'jan
step
#arrowtext Click on the\n|cRXP_PICK_Rootway to Zul'Aman|r
.goto 2413,34.79,43.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rootway to Zul'Aman|r |cRXP_WARN_after the roleplay.|r
.complete 92904,1 
step
#title Follow the arrow
.goto 2536,16.67,20.82
.complete 92904,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,16.47,20.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 92904 >>Turn in Return to Zul'Aman
.accept 92907 >>Accept Amani Answers
.target Zul'jan
step
#arrowtext Click on the\n|cRXP_PICK_Box of Scrolls|r
.goto 2536,17.25,19.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Box of Scrolls|r.
.complete 92907,1 
.skipgossipid 137308
step
#arrowtext Click on the\n|cRXP_PICK_Box of Scrolls|r
.goto 2536,15.79,22.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Box of Scrolls|r.
.complete 92907,2 
.skipgossipid 138044
step
#arrowtext Click on the\n|cRXP_PICK_Box of Scrolls|r
.goto 2536,19.50,17.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Box of Scrolls|r.
.complete 92907,3 
.timer 6,Amani Mask Roleplay
.skipgossipid 137310
step
#arrowtext Click on the\n|cRXP_PICK_Befuddled Amani Mask|r
.goto 2536,18.55,19.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Befuddled Amani Mask|r |cRXP_WARN_after the roleplay|r.
.complete 92907,4 
.target Befuddled Amani Mask
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kinduru|r
.goto 2536,16.82,20.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kinduru|r.
.complete 92907,5 
.target Kinduru
.skipgossipid 137365
step
#arrowtext Click on the\n|cRXP_PICK_Woodworking Supplies|r
.goto 2536,19.67,19.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Woodworking Supplies|r.
.complete 92907,7 
step
#arrowtext Click on the\n|cRXP_PICK_Woodworking Tool|r
.goto 2536,14.37,18.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Woodworking Tool|r.
.complete 92907,6 
step
#arrowtext Click on the\n|cRXP_PICK_Befuddled Amani Mask|r
.goto 2536,16.99,20.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Befuddled Amani Mask|r.
.complete 92907,8 
.target Befuddled Amani Mask
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,16.87,20.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 92907 >>Turn in Amani Answers
.accept 92955 >>Accept The Tablets of Numazon
.target Zul'jan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2437,39.00,38.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 92955 >>Turn in The Tablets of Numazon
.accept 92957 >>Accept There's the Rub
.target Zul'jan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Befuddled Amani Mask|r
.goto 2437,38.98,38.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Befuddled Amani Mask|r.
.accept 92958 >>Accept Brain Drain
.target Befuddled Amani Mask
step
#arrowtext Tablet Rubbing (1/6)
.goto 2437,38.55,38.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Amani Tablet|r.
.complete 92957,1,1 
step
#arrowtext Tablet Rubbing (2/6)
.goto 2437,38.18,38.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Amani Tablet|r.
.complete 92957,1,2 
step
#completewith BrainDrainA
#hidewindow
#loop
.goto 2437,37.97,36.76,18,0
.goto 2437,37.77,37.96,18,0
.goto 2437,37.32,36.93,18,0
.goto 2437,36.74,36.98,18,0
.goto 2437,36.90,37.89,18,0
+1
step
#completewith next
#arrowtext Kill |cRXP_ENEMY_Vilebranches|r\nLoot for |T443381:0|t[|cRXP_LOOT_Vilebranch Hex Fetish|r]
>>Kill the |cRXP_ENEMY_Vilebranches|r. Loot them for the |T443381:0|t[|cRXP_LOOT_Vilebranch Hex Fetish|r].
.complete 92958,1 
.mob Vilebranch Hexwarder
.mob Vilebranch Siphoner
step
#arrowtext Tablet Rubbing (6/6)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Amani Tablet|r.
.complete 92957,1 
step
#label BrainDrainA
#arrowtext Kill |cRXP_ENEMY_Vilebranches|r\nLoot for |T443381:0|t[|cRXP_LOOT_Vilebranch Hex Fetish|r]
>>Kill the |cRXP_ENEMY_Vilebranches|r. Loot them for the |T443381:0|t[|cRXP_LOOT_Vilebranch Hex Fetish|r].
.complete 92958,1 
.mob Vilebranch Hexwarder
.mob Vilebranch Siphoner
step
#label TheresTheRubA
#completewith next
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Kinduru|r
.goto 2437,38.08,37.46,15,0
.goto 2437,38.95,38.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Kinduru|r.
.turnin 92957 >>Turn in There's the Rub
.target Loa Speaker Kinduru
step
#hidewindow
#completewith TheresTheRubA
.goto 2437,38.95,38.93,50 >>1
step
#requires TheresTheRubA
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Kinduru|r
.goto 2437,38.95,38.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Kinduru|r.
.turnin 92957 >>Turn in There's the Rub
.target Loa Speaker Kinduru
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Befuddled Amani Mask|r
.goto 2437,38.99,38.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Befuddled Amani Mask|r.
.turnin 92958 >>Turn in Brain Drain
.accept 92952 >>Accept Mission to Maisara
.target Befuddled Amani Mask
step
#title Follow the arrow
.goto 2437,44.52,36.67
.complete 92952,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Enchanted Amani Mask|r
.goto 2437,44.51,36.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Enchanted Amani Mask|r.
.turnin 92952 >>Turn in Mission to Maisara
.accept 92953 >>Accept Memories of Malacrass
.target Enchanted Amani Mask
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2437,44.46,36.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.accept 92951 >>Accept Digging Deeper
.target Zul'jan
step
#completewith HexMasterMemoriesA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vilebranch Scrolls|r.
.complete 92951,1 
step
#arrowtext Kill |cRXP_ENEMY_Hex Master Uy'okan|r\nUse |T2576087:0|t[ExtraActionButton]
.goto 2437,45.34,38.11
>>Kill |cRXP_ENEMY_Hex Master Uy'okan|r. Use the |T2576087:0|t[ExtraActionButton].
.complete 92953,3 
.mob Hex Master Uy'okan
step
#completewith next
#label HexMasterJintaggaA
>>Kill |cRXP_ENEMY_Hex Master Jintagga|r. Use the |T2576087:0|t[ExtraActionButton].
.complete 92953,1 
.mob Hex Master Jintagga
step
#completewith HexMasterJintaggaA
#arrowtext Enter the cave
.goto 2437,46.50,37.95,8 >>|cRXP_WARN_Enter the cave.|r
step
#requires HexMasterJintaggaA
#arrowtext Kill |cRXP_ENEMY_Hex Master Jintagga|r\nUse |T2576087:0|t[ExtraActionButton]
.goto 2437,46.56,37.51
>>Kill |cRXP_ENEMY_Hex Master Jintagga|r. Use the |T2576087:0|t[ExtraActionButton].
.complete 92953,1 
.mob Hex Master Jintagga
step
#label HexMasterMemoriesA
#arrowtext Kill |cRXP_ENEMY_Hex Master Soye'mal|r\nUse |T2576087:0|t[ExtraActionButton]
.goto 2437,46.55,38.91,15,0
.goto 2437,46.49,41.31
>>Kill |cRXP_ENEMY_Hex Master Soye'mal|r. Use the |T2576087:0|t[ExtraActionButton].
.complete 92953,2 
.mob Hex Master Soye'mal
step
#arrowtext Click on the\n|cRXP_PICK_Vilebranch Scrolls|r
#loop
.goto 2437,46.97,40.99,20,0
.goto 2437,46.78,40.03,20,0
.goto 2437,46.05,39.07,20,0
.goto 2437,45.95,40.68,20,0
.goto 2437,45.56,42.38,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vilebranch Scrolls|r.
.complete 92951,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Kinduru|r
.goto 2437,44.46,36.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Kinduru|r.
.turnin 92953 >>Turn in Memories of Malacrass
.turnin 92951 >>Turn in Digging Deeper
.target Loa Speaker Kinduru
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2437,44.46,36.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.accept 92954 >>Accept Maisara Caverns: Master of Souls
.target Zul'jan
step
.isOnQuest 92954
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2437,44.48,36.63
.enterScenario 3127 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.complete 92954,2 
.target Zul'jan
.skipgossipid 138427
step
#completewith RaktulVesselOfSoulsA
+|cRXP_WARN_The Arrow cannot be displayed here; coordinates are unavailable|r.
step
.isInScenario 3127
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on 8 |cRXP_PICK_Prisoners|r to freem them and to unlock the first boss.
*Kill |cRXP_ENEMY_Muro'jin|r and |cRXP_ENEMY_Nekraxx|r roughly at the same time.
.scenario 15977,1 
.mob Muro'jin
.mob Nekraxx
step
.isInScenario 3127
>>Kill |cRXP_ENEMY_Rokh'zal|r to unlock the way to the second boss.
*Kill |cRXP_ENEMY_Vordaza|r. Loot her for |T329513:0|t[|cRXP_LOOT_Malacrass's Note|r].
.scenario 15977,2 
.complete 92954,3 
.mob Rokh'zal
.mob Vordaza
step
#label RaktulVesselOfSoulsA
.isInScenario 3127
>>Kill |cRXP_ENEMY_Rak'tul|r.
.complete 92954,4 
.mob Rak'tul
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2437,44.46,36.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r |cRXP_WARN_outside the dungeon|r.
.turnin 92954 >>Turn in Maisara Caverns: Master of Souls
.accept 93010 >>Accept The Serpent Shrine
.target Zul'jan
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,67.75,47.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.turnin 93010 >>Turn in The Serpent Shrine
.accept 93011 >>Accept Legacy of the Amani
.target Zul'jan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2536,67.75,47.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.complete 93011,1 
.target Zul'jan
.skipgossipid 138526
step
#arrowtext Kill |cRXP_ENEMY_Risen Amani Warrior|r\nand |cRXP_ENEMY_Strongblood Jak'mo|r
.goto 2536,62.31,47.33
>>Kill the |cRXP_ENEMY_Risen Amani Warrior|r and |cRXP_ENEMY_Strongblood Jak'mo|r.
.complete 93011,2 
.mob Risen Amani Warrior
.mob Strongblood Jak'mo
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Kinduru|r
.goto 2536,67.59,47.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Kinduru|r.
.complete 93011,3 
.target Loa Speaker Kinduru
.skipgossipid 139407
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2437,44.35,66.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 93011 >>Turn in Legacy of the Amani
.accept 93012 >>Accept Dead End
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.79,68.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 93012,1 
.target Zul'jarra
.skipgossipid 137417
step
#arrowtext Click on |cRXP_PICK_Kinduru's Mortar|r
.goto 2437,43.57,68.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kinduru's Mortar|r.
.complete 93012,2 
step
#loop
#arrowtext Use the |T571694:0|t[ExtraActionButton]
.goto 2437,43.58,68.25,8,0
.goto 2437,43.67,68.55,8,0
.goto 2437,43.86,68.66,8,0
>>Use the |T571694:0|t[ExtraActionButton] while on the glowing circles.
.complete 93012,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.79,68.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 93012 >>Turn in Dead End
.target Zul'jarra
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name b) An Island of Fangs
#internal
step
.isOnQuest 98218
.goto 2437,43.71,68.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 98218 >>Turn in Return to Amani'Zar
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2437,43.71,68.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 92916 >>Accept A Call for Aid
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2437,37.00,23.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 92916 >>Turn in A Call for Aid
.accept 92917 >>Accept Saving Those Bound
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2437,36.97,23.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 92919 >>Accept All Bark, All Bite
.target Orweyna
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ensnared Villagers|r.
>>Kill |cRXP_ENEMY_Invaders|r.
.complete 92917,1 
.complete 92919,1 
.mob Fanged Abductor
.mob Binding Hexspitter
step
#arrowtext Click on |cRXP_PICK_Dak'zor|r
.goto 2437,38.06,25.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Dak'zor|r.
.complete 92917,2 
.target Dak'zor
step
#arrowtext Rescue |cRXP_PICK_Ensnared Villagers|r\nand kill |cRXP_ENEMY_Invaders|r
#loop
.goto 2437,35.96,25.14,35,0
.goto 2437,38.09,26.62,35,0
.goto 2437,39.13,25.38,35,0
.goto 2437,37.87,23.30,35,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ensnared Villagers|r.
>>Kill |cRXP_ENEMY_Invaders|r.
.complete 92917,1 
.complete 92919,1 
.target Ensnared Villagers
.mob Fanged Abductor
.mob Binding Hexspitter

step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,37.49,23.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 92917 >>Turn in Saving Those Bound
.turnin 92919 >>Turn in All Bark, All Bite
.accept 93265 >>Accept Severing the Serpent's Head
.target Zul'jarra
step
#arrowtext Kill\n|cRXP_ENEMY_Nutek the Abductor|r
.goto 2437,38.58,22.40
>>Kill |cRXP_ENEMY_Nutek the Abductor|r.
.complete 93265,1 
.mob Nutek the Abductor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,37.49,23.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 93265,2 
.target Zul'jarra
.skipgossipid 138570
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,37.44,23.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 93265 >>Turn in Severing the Serpent's Head
.accept 92921 >>Accept To the Skybridge
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,44.07,54.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 92921 >>Turn in To the Skybridge
.accept 93266 >>Accept Drumming Up the Troops
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2437,44.07,54.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 93263 >>Accept It Just Had to Be...
.target Orweyna
step
#arrowtext Kill |cRXP_ENEMY_Snakes|r\nand click on |cRXP_PICK_Amani War Drums|r
#completewith ItJustHadToBeA
#hidewindow
#loop
.goto 2437,49.58,54.39,35,0
.goto 2437,44.60,54.44,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Snakes|r.
*Click on |cRXP_PICK_Weapon Racks|r to get an extra action button that kills them in one hit.
.complete 93263,1 
.mob Screeching Skyfiend
.mob Coiling Serpent
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani War Drums|r.
.complete 93266,1 
step
#label ItJustHadToBeA
>>Kill |cRXP_ENEMY_Snakes|r.
*Click on |cRXP_PICK_Weapon Racks|r to get an extra action button that kills them in one hit.
.complete 93263,1 
.mob Screeching Skyfiend
.mob Coiling Serpent
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,50.09,54.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 93266 >>Turn in Drumming Up the Troops
.turnin 93263 >>Turn in It Just Had to Be...
.accept 92920 >>Accept Down With the Skies
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
#completewith next
.goto 2437,50.64,54.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 92920,1 
.target Zul'jarra
.skipgossipid 139180
step
#arrowtext Talk to |cRXP_FRIENDLY_Zul'jarra|r\nand protect her
.goto 2437,50.75,54.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r and protect her.
.complete 92920,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,51.07,54.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 92920 >>Turn in Down With the Skies
.accept 92924 >>Accept What Lies Beyond the Fog
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,57.82,47.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 92924 >>Turn in What Lies Beyond the Fog
.accept 95804 >>Accept The Children of Ula'tek
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Tokka|r
.goto 2512,57.79,47.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Tokka|r.
.complete 95804,1 
.target Captain Tokka
.skipgossipid 139505
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,57.81,47.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 95804 >>Turn in The Children of Ula'tek
.accept 93019 >>Accept Situation Normal, All Snaked Up
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tak'lejo|r
.goto 2512,57.87,47.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.accept 95564 >>Accept The Serpent's Tail
.target Tak'lejo
step
#arrowtext Click on the\n|cRXP_PICK_Amani Banner|r
.goto 2512,55.68,44.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Banner|r.
.complete 95564,1 
step
#completewith TheSerpentsTailA
>>Kill the |cRXP_ENEMY_Vilescar forces|r.
.complete 93019,1 
.mob Vilescar Brawler
.mob Vilescar Acolyte
.mob Vilescar Harrier
.mob Vilescar Lurker
step
#arrowtext Click on the\n|cRXP_PICK_Ghastly Barricade|r
.goto 2512,52.22,38.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ghastly Barricade|r.
.complete 95564,2 
step
#arrowtext Click on the\n|cRXP_PICK_Pillar of Ruin|r
.goto 2512,53.16,36.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillar of Ruin|r.
.complete 95564,3 
step
#arrowtext Click on the\n|cRXP_PICK_Depraved Effigy|r
.goto 2512,51.07,33.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Depraved Effigy|r.
.complete 95564,4 
step
#arrowtext Kill\n|cRXP_ENEMY_Caustic Abductor|r
#label TheSerpentsTailA
.goto 2512,51.42,31.41
>>Kill |cRXP_ENEMY_Caustic Abductor|r.
.complete 95564,5 
.mob Caustic Abductor
step
#arrowtext Kill the\n|cRXP_ENEMY_Vilescar forces|r
#loop
.goto 2512,53.85,41.14,35,0
.goto 2512,51.07,33.09,35,0
>>Kill the |cRXP_ENEMY_Vilescar forces|r.
.complete 93019,1 
.mob Vilescar Brawler
.mob Vilescar Acolyte
.mob Vilescar Harrier
.mob Vilescar Lurker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tak'lejo|r
.goto 2512,47.05,31.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.turnin 95564 >>Turn in The Serpent's Tail
.target Tak'lejo
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,47.00,31.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 93019 >>Turn in Situation Normal, All Snaked Up
.accept 93018 >>Accept Them That Were Lost
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tak'lejo|r
.goto 2512,47.04,31.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.accept 93022 >>Accept Fire, the Only Way to Be Sure
.target Tak'lejo
step
#completewith FireTheOnlyWayToBeSureA
>>Use the |T524795:0|t[ExtraActionButton] to destroy eggs and kill |cRXP_ENEMY_Brood Watchers|r and |cRXP_ENEMY_Spiteful Broodsisters|r.
.complete 93022,1 
.complete 93022,2 
.mob Brood Watcher
.mob Spiteful Broodsister
step
#arrowtext Click on |cRXP_PICK_Barricade|r\nAmani released (4/12)\n|cRXP_WARN_(Hardcoded Waypoint)|r
.goto 2512,47.08,29.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barricade|r
.complete 93018,1,4 
step
#arrowtext Click on |cRXP_PICK_Barricade|r\nAmani released (8/12)\n|cRXP_WARN_(Hardcoded Waypoint)|r
.goto 2512,46.33,27.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barricade|r
.complete 93018,1,8 
step
#arrowtext Click on |cRXP_PICK_Barricade|r\nAmani released (12/12)\n|cRXP_WARN_(Hardcoded Waypoint)|r
#label FireTheOnlyWayToBeSureA
.goto 2512,44.65,30.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barricade|r
.complete 93018,1 
step
#arrowtext Use |T524795:0|t[ExtraActionButton]
#loop
.goto 2512,45.60,32.40,25,0
.goto 2512,47.01,30.46,25,0
.goto 2512,46.34,28.21,25,0
.goto 2512,45.41,30.06,25,0
>>Use the |T524795:0|t[ExtraActionButton] to destroy eggs and kill |cRXP_ENEMY_Brood Watchers|r and |cRXP_ENEMY_Spiteful Broodsisters|r.
.complete 93022,1 
.complete 93022,2 
.mob Brood Watcher
.mob Spiteful Broodsister
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tak'lejo|r
.goto 2512,45.87,29.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.turnin 93022 >>Turn in Fire, the Only Way to Be Sure
.target Tak'lejo
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,45.90,29.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 93018 >>Turn in Them That Were Lost
.accept 93023 >>Accept Death of Furies
.target Zul'jarra
step
#arrowtext Kill the\n|cRXP_ENEMY_Brood Furies|r
.goto 2512,45.31,28.58
>>Kill the |cRXP_ENEMY_Brood Furies|r.
.complete 93023,1 
.mob Brood Fury Teffith
.mob Brood Fury Lasha
.mob Brood Fury Ulia
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,44.82,27.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 93023 >>Turn in Death of Furies
.accept 93024 >>Accept Come With Me
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,44.62,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 93024,1 
.target Zul'jarra
.skipgossipid 137413
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,44.60,27.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 93024,2 
.target Zul'jarra
.skipgossipid 139126
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2512,58.34,46.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 93024 >>Turn in Come With Me
.target Lady Liadrin
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name c) Ghosts of the Past
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,58.37,46.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 93454 >>Accept Words to Hear
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,58.37,46.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 93454,1 
.target Zul'jarra
.skipgossipid 138170
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,58.45,45.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 93454 >>Turn in Words to Hear
.accept 92925 >>Accept The Glint of History
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,47.46,73.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 92925,1 
.target Orweyna
.skipgossipid 138956
step
#arrowtext Click on the\n|cRXP_PICK_Worldsoul Memory|r
.goto 2512,47.41,73.50
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Worldsoul Memory|r.
.complete 92925,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,47.46,73.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92925 >>Turn in The Glint of History
.accept 92927 >>Accept Echoed Steps
.target Orweyna
step
#arrowtext Click on the |cRXP_PICK_Worldsoul Memory|r\nand kill |cRXP_ENEMY_Memory of Empire|r
.goto 2512,46.91,73.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Worldsoul Memory|r.
*Kill the |cRXP_ENEMY_Memory of Empire|r.
.complete 92927,1 
.mob Memory of Empire
step
#arrowtext Click on the |cRXP_PICK_Worldsoul Memory|r\nand kill |cRXP_ENEMY_Memory of Escalation|r
.goto 2512,46.30,74.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Worldsoul Memory|r.
*Kill the |cRXP_ENEMY_Memory of Escalation|r.
.complete 92927,2 
.mob Memory of Escalation
step
#arrowtext Click on the\n|cRXP_PICK_Worldsoul Memory|r
.goto 2512,45.76,75.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Worldsoul Memory|r.
.complete 92927,3 
step
#arrowtext Click on the\n|cRXP_PICK_Door|r
.goto 2512,45.36,75.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Door|r.
.complete 92927,4 
.timer 9,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2639,69.93,13.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92927 >>Turn in Echoed Steps
.accept 92928 >>Accept What Was Buried
.accept 92929 >>Accept Lurking in the Dark
.target Orweyna
step
#completewith LurkingInTheDarkA
>>Kill the |cRXP_ENEMY_Summoners|r, |cRXP_ENEMY_Spiders|r and |cRXP_ENEMY_Risen|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Sarcophagi|r.
.complete 92929,1 
.mob Entombed Summoner
.mob Tortured Risen
.mob Crypt Spider
step
#arrowtext Click on the\n|cRXP_PICK_Mural|r
.goto 2639,29.35,21.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mural|r.
.complete 92928,2 
step
#arrowtext Click on the\n|cRXP_PICK_Forgotten Urn|r
.goto 2639,42.55,49.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forgotten Urn|r.
.complete 92928,3 
step
#arrowtext Click on the\n|cRXP_PICK_Mural|r
#label LurkingInTheDarkA
.goto 2639,73.96,62.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mural|r.
.complete 92928,1 
step
#arrowtext Kill |cRXP_ENEMY_Summoners|r, |cRXP_ENEMY_Spiders|r and |cRXP_ENEMY_Risen|r\nClick on |cRXP_PICK_Sarcophagi|r
#loop
.goto 2639,53.34,59.31,20,0
.goto 2639,66.93,41.38,20,0
.goto 2639,50.12,14.61,20,0
.goto 2639,40.81,28.52,20,0
>>Kill the |cRXP_ENEMY_Summoners|r, |cRXP_ENEMY_Spiders|r and |cRXP_ENEMY_Risen|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Sarcophagi|r.
.complete 92929,1 
.mob Entombed Summoner
.mob Tortured Risen
.mob Crypt Spider
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2639,73.96,62.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92929 >>Turn in Lurking in the Dark
.turnin 92928 >>Turn in What Was Buried
.accept 92930 >>Accept Written by the Victors
.target Orweyna
step
#arrowtext Kill\n|cRXP_ENEMY_Yan'ti the Bold|r
.goto 2639,42.53,82.74
>>Kill |cRXP_ENEMY_Yan'ti the Bold|r.
.complete 92930,1 
.mob Yan'ti the Bold
step
#arrowtext Click on the\n|cRXP_PICK_Mural|r
.goto 2639,25.02,74.70
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mural|r.
.complete 92930,2 
step
#completewith next
#label WrittenByTheVictorsA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92930 >>Turn in Written by the Victors
.target Orweyna
step
#completewith WrittenByTheVictorsA
#title Leave the crypt
.goto 2639,45.43,63.12,10,0
.goto 2639,53.24,53.84,10,0
.goto 2639,64.59,37.50,10,0
.goto 2639,62.65,27.57,10,0
.goto 2639,72.46,12.93,10 >>|cRXP_WARN_Leave the crypt.|r
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
#requires WrittenByTheVictorsA
.goto 2512,57.47,49.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92930 >>Turn in Written by the Victors
.target Orweyna
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name d) Original Sin
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2512,57.48,49.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 92931 >>Accept Delay the Venom
.target Lady Liadrin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Raz'taka|r
.goto 2512,57.55,49.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raz'taka|r.
.complete 92931,1 
.target Raz'taka
.skipgossipid 138362
step
#arrowtext Click on\n|cRXP_PICK_Zul'jarra|r
.goto 2512,57.50,49.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Zul'jarra|r.
.complete 92931,2 
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tak'lejo|r
.goto 2512,57.53,48.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.complete 92931,3 
.target Tak'lejo
.skipgossipid 138366
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Tokka|r
.goto 2512,57.33,48.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Tokka|r.
.complete 92931,5 
.target Captain Tokka
.skipgossipid 137235
step
#arrowtext Talk to |cRXP_FRIENDLY_Dak'zor|r\nand click on the |cRXP_PICK_Beatin' Man|r
.goto 2512,57.55,47.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Beatin' Man|r.
.complete 92931,4 
.target Dak'zor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,64.01,56.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92931 >>Turn in Delay the Venom
.accept 92932 >>Accept Clear the Swamp
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Dak'zor|r
.goto 2512,64.02,56.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r.
.accept 92933 >>Accept Haunted Shore
.target Dak'zor
step
#completewith HauntedShoreA
>>Kill |cRXP_ENEMY_Swamp beasts|r.
.complete 92932,1 
.mob Snapping Prowler
step
#arrowtext Talk to\n|cRXP_FRIENDLY_First Mate Nama|r
.goto 2512,64.68,59.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Mate Nama|r.
.complete 92933,1 
.target First Mate Nama
.skipgossipid 137305
step
#arrowtext Free the\n|cRXP_PICK_Lost Tortollan|r
#label HauntedShoreA
#loop
.goto 2512,66.46,58.63,35,0
.goto 2512,63.90,60.04,35,0
.goto 2512,64.73,66.07,35,0
.goto 2512,66.59,63.53,35,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on and kill the |cRXP_PICK_Lost Tortollan|r.
.complete 92933,2 
step
#arrowtext Kill\n|cRXP_ENEMY_Swamp beasts|r
#loop
.goto 2512,63.99,66.73,35,0
.goto 2512,63.90,60.04,35,0
.goto 2512,64.73,66.07,35,0
>>Kill |cRXP_ENEMY_Swamp beasts|r.
.complete 92932,1 
.mob Snapping Prowler
.mob Snapping Matriarch
.mob Bog Tyrant
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Dak'zor|r
.goto 2512,67.46,62.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r.
.turnin 92933 >>Turn in Haunted Shore
.target Dak'zor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,67.46,62.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92932 >>Turn in Clear the Swamp
.timer 10,Roleplay Duration
.target Orweyna
step
#arrowtext Talk to |cRXP_FRIENDLY_Dak'zor|r\nand |cRXP_FRIENDLY_Orweyna|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r and |cRXP_FRIENDLY_Orweyna|r.
.accept 93063 >>Accept Broken Spears
.goto 2512,67.46,62.31
.target +Dak'zor
.accept 92938 >>Accept Site of Terror
.goto 2512,67.46,62.26
.target +Orweyna
step
#completewith SiteOfTerrorA
>>Kill the |cRXP_ENEMY_Risen|r. Loot them for the |T7474699:0|t[|cRXP_LOOT_Ancient Amani Weapons|r].
.complete 93063,1 
.mob Tortured Defender
.mob Risen Tormentor
.mob Fallen Hunter
step
#arrowtext Click on the\n|cRXP_PICK_Mound|r
.goto 2512,67.24,66.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mound|r.
.complete 92938,1 
step
#arrowtext Click on the\n|cRXP_PICK_Shrine|r
.goto 2512,71.23,64.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shrine|r.
.complete 92938,2 
step
#arrowtext Click on the\n|cRXP_PICK_Remains|r
#label SiteOfTerrorA
.goto 2512,70.51,62.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Remains|r.
.complete 92938,3 
step
#arrowtext Kill the |cRXP_ENEMY_Risen|r\nand loot |cRXP_LOOT_Ancient Amani Weapons|r
#loop
.goto 2512,68.58,61.22,35,0
.goto 2512,67.13,65.73,35,0
.goto 2512,69.00,64.92,35,0
.goto 2512,70.90,62.49,35,0
>>Kill the |cRXP_ENEMY_Risen|r. Loot them for the |T7474699:0|t[|cRXP_LOOT_Ancient Amani Weapons|r].
.complete 93063,1 
.mob Tortured Defender
.mob Risen Tormentor
.mob Fallen Hunter
step
#arrowtext Click on the\n|cRXP_PICK_Altar|r
.goto 2512,70.33,65.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r.
.complete 92938,4 
.timer 15,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Dak'zor|r
.goto 2512,70.31,65.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r.
.turnin 93063 >>Turn in Broken Spears
.target Dak'zor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,70.25,65.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 92938 >>Turn in Site of Terror
.accept 93064 >>Accept Awe of She
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,70.25,65.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 93064,1 
.target Orweyna
.skipgossipid 136552
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Strongblood Jak'mo|r
.goto 2512,69.24,64.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Strongblood Jak'mo|r.
.turnin 93064 >>Turn in Awe of She
.accept 92935 >>Accept Pushed to the Brink
.target Strongblood Jak'mo
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Summoner Jawae|r
.goto 2512,69.29,64.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Summoner Jawae|r.
.accept 92934 >>Accept Fuel the Calling
.target Summoner Jawae
step
#completewith PushedToTheBrinkA
+|cRXP_WARN_MOVEMENT:|r Use |T348567:0|t[Regenerative Speed] (3) and |T135736:0|t[Darkstep] (4) on cooldown.
*|cRXP_WARN_DAMAGE:|r Alternate between |T5764922:0|t[Venom] (2) and |T136189:0|t[Carve] (1).
step
#completewith FuelTheCallingA
>>Kill the |cRXP_ENEMY_Aqir forces|r.
.complete 92935,1 
.mob Aqir Destroyer
.mob Aqir Shadowcaster
.mob N'raqi Commander
.mob Winged Ruin
step
#arrowtext Click on |cRXP_PICK_Injured Hunters|r\nHunter sacrificed (2/12)\n|cRXP_WARN_(Hardcoded)|r
.goto 2512,70.46,62.46
.complete 92934,1,2 
step
#arrowtext Click on |cRXP_PICK_Injured Hunters|r\nand talk to |cRXP_FRIENDLY_Jaz'di Wiseman|r
.goto 2512,68.65,62.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Hunters|r.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaz'di Wiseman|r.
.complete 92934,2 
.target Injured Hunter
.skipgossipid 137615
step
#arrowtext Click on |cRXP_PICK_Injured Hunters|r\nHunter sacrificed (5/12)\n|cRXP_WARN_(Hardcoded)|r
.goto 2512,68.65,62.73
.complete 92934,1,5 
step
#arrowtext Click on |cRXP_PICK_Injured Hunters|r\nHunter sacrificed (7/12)\n|cRXP_WARN_(Hardcoded)|r
.goto 2512,68.32,63.37
.complete 92934,1,7 
step
#arrowtext Click on |cRXP_PICK_Injured Hunters|r\nHunter sacrificed (9/12)\n|cRXP_WARN_(Hardcoded)|r
.goto 2512,68.07,64.51
.complete 92934,1,9 
step
#arrowtext Click on |cRXP_PICK_Injured Hunters|r\nHunter sacrificed (12/12)\n|cRXP_WARN_(Hardcoded)|r
#label FuelTheCallingA
.goto 2512,67.98,66.78
.complete 92934,1 
step
#arrowtext Kill the\n|cRXP_ENEMY_Aqir forces|r
#loop
.goto 2512,70.46,62.46,40,0
.goto 2512,68.00,62.31,40,0
.goto 2512,67.98,66.78,40,0
>>Kill the |cRXP_ENEMY_Aqir forces|r.
.complete 92935,1 
.mob Aqir Destroyer
.mob Aqir Shadowcaster
.mob N'raqi Commander
.mob Winged Ruin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Summoner Jawae|r
.goto 2512,69.29,64.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Summoner Jawae|r.
.turnin 92934 >>Turn in Fuel the Calling
.target Summoner Jawae
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Strongblood Jak'mo|r
.goto 2512,69.24,64.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Strongblood Jak'mo|r.
.turnin 92935 >>Turn in Pushed to the Brink
.accept 92936 >>Accept The Summoning of Ula'tek
.target Strongblood Jak'mo
step
#arrowtext Use the |T2576089:0|t[ExtraActionButton]
.goto 2512,69.13,64.03
>>Use the |T2576089:0|t[ExtraActionButton].
.complete 92936,1 
step
#label PushedToTheBrinkA
#arrowtext Talk to\n|cRXP_FRIENDLY_Dak'zor|r
.goto 2512,70.31,65.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dak'zor|r.
.turnin 92936 >>Turn in The Summoning of Ula'tek
.accept 92937 >>Accept Awakened Evil
.target Dak'zor
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2512,70.25,65.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 92937,1 
.target Orweyna
.skipgossipid 137388
step
#arrowtext Defeat\n|cRXP_ENEMY_"Orweyna"|r
.goto 2512,69.05,63.94
>>Defeat |cRXP_ENEMY_"Orweyna"|r.
.complete 92937,2 
.mob Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2512,57.48,49.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 92937 >>Turn in Awakened Evil
.target Lady Liadrin
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name e) The Battle of Atal'Utek
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2512,57.48,49.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 93417 >>Accept The Vaults of Atal'Utek: Altar of Fangs
.target Lady Liadrin
step
#completewith next
#label TheVaultsOfAtalUtetkA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warleader Abdumati|r.
.accept 98388 >>Accept Into the Vaults of Atal'Utek
.target Warleader Abdumati
step
#completewith next
.goto 2512,45.78,64.93,22,0
.goto 2512,42.59,64.57,22,0
.goto 2512,42.49,62.41,20,0
.goto 2512,41.48,62.30,20,0
.goto 2509,50.52,86.33,15,0
.goto 2509,48.72,85.93,25,0
.goto 2509,47.24,70.44,20 >>Follow the arrow into the |cRXP_PICK_Vaults of Atal'Utek|r.
*Skip this step if you're already there
step
#completewith TheVaultsOfAtalUtetkA
#hidewindow
.goto 2509,47.23,60.76,50 >>1
step
#requires TheVaultsOfAtalUtetkA
#arrowtext Talk to\n|cRXP_FRIENDLY_Warleader Abdumati|r
.goto 2509,47.23,60.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warleader Abdumati|r.
.accept 98388 >>Accept Into the Vaults of Atal'Utek
.target Warleader Abdumati
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Warleader Abdumati|r
.goto 2509,47.23,60.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warleader Abdumati|r.
.complete 93417,1 
.target Warleader Abdumati
.skipgossipid 141865
step
#arrowtext Walk onto the\nSpiritwing Gust
.goto 2509,47.22,60.24
>>Walk on top of the gust.
.complete 98388,1 
step
#arrowtext Kill the\n|cRXP_ENEMY_Writhing Coiler|r
.goto 2509,46.80,51.81
>>Kill the |cRXP_ENEMY_Writhing Coiler|r.
.complete 98388,2 
.mob Writhing Coiler
step
#arrowtext Click on the\n|cRXP_PICK_Spiritwing Feather|r
.goto 2509,46.84,51.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spiritwing Feather|r.
.complete 98388,3 
step
#arrowtext Talk to the\n|cRXP_FRIENDLY_Amani Windcaller|r
.goto 2509,49.93,61.88
>>Use the [ExtraActionButton].
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Amani Windcaller|r.
.complete 98388,4 
.target Amani Windcaller
.skipgossipid 1411753
step
#arrowtext Talk to the\n|cRXP_FRIENDLY_Amani Windcaller|r
.goto 2509,54.31,39.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Amani Windcaller|r.
.complete 98388,5 
.target Amani Windcaller
.skipgossipid 141935
step
#arrowtext Click on\n|cRXP_PICK_Hawkeye Socho|r
.goto 2509,50.42,39.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Hawkeye Socho|r.
.complete 98388,6 
.target Hawkeye Socho
step
#arrowtext Talk to the\n|cRXP_FRIENDLY_Amani Windcaller|r
.goto 2509,54.33,39.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Amani Windcaller|r.
.complete 98388,7 
.target Amani Windcaller
.skipgossipid 141737
step
#arrowtext Click on\n|cRXP_PICK_Commander Gazba|r
.goto 2509,39.63,18.11,15,0
.goto 2509,42.32,14.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Commander Gazba|r.
.complete 98388,8 
.target Commander Gazba
step
#arrowtext Click on the\n|cRXP_PICK_Broken Urn|r
.goto 2509,42.32,14.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Broken Urn|r.
.complete 98388,9 
step
#completewith next
#label IntoTheVaultsOfAtalUtekA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warleader Abdumati|r.
.turnin 98388 >>Turn in Into the Vaults of Atal'Utek
.target Warleader Abdumati
step
#arrowtext Talk to the\n|cRXP_FRIENDLY_Amani Windcaller|r
#completewith IntoTheVaultsOfAtalUtekA
.goto 2509,41.60,23.40
.gossipoption 141760 >>Talk to the |cRXP_FRIENDLY_Amani Windcaller|r.
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Warleader Abdumati|r
#requires IntoTheVaultsOfAtalUtekA
.goto 2509,47.23,60.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warleader Abdumati|r.
.turnin 98388 >>Turn in Into the Vaults of Atal'Utek
.target Warleader Abdumati
step
#title Follow the arrow
.goto 2509,47.07,68.34
.complete 93417,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
#completewith next
.goto 2509,47.07,68.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.complete 93417,4 
.target Lady Liadrin

step
.isOnQuest 93417
.isQuestNotComplete 93417
.enterScenario 3312 >>Enter the dungeon |cRXP_PICK_Altar of Fangs|r. |cRXP_WARN_DON'T LEAVE AFTER THE ENDBOSS.|r
step
.isOnQuest 93417
.isInScenario 3312
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totems|r to destroy the barrier.
>>Kill |cRXP_ENEMY_Rav'i|r.
.scenario 16651,1 
.mob Rav'i
step
.isOnQuest 93417
.isInScenario 3312
>>Kill |cRXP_ENEMY_The Writhing Coil|r.
.scenario 16651,2 
.mob The Writihng Coil
step
.isOnQuest 93417
.isInScenario 3312
>>Kill |cRXP_ENEMY_Zul'jan|r
.complete 93417,3 
.mob Zul'jan
step
#arrowtext Talk to |cRXP_FRIENDLY_Lady Liadrin|r\ninside the dungeon
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.complete 93417,5 
.target Lady Liadrin
.skipgossipid 139918
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Warleader Abdumati|r
.goto 2509,47.23,60.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warleader Abdumati|r.
.accept 97640 >>Accept Vaults of Atal'Utek: One Coin Too Many
.accept 98515 >>Accept Vaults of Atal'Utek: A Toxic Tour
.accept 95520 >>Accept Purging the Vaults
.target Warleader Abdumati
step
#arrowtext Find\n|cRXP_FRIENDLY_Er'inye|r
.goto 2509,50.41,63.01
>>Follow the arrow.
.complete 97640,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Er'inye|r
.goto 2509,51.17,62.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Er'inye|r.
.turnin 97640 >>Turn in Vaults of Atal'Utek: One Coin Too Many
.accept 98428 >>Accept Vaults of Atal'Utek: The Altar of Corrosion
.target Er'inye
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Er'inye|r
.goto 2509,51.17,62.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Er'inye|r.
.complete 98428,1 
.target Er'inye
.skipgossipid 141688
step
#arrowtext Click on the\n|cRXP_PICK_Altar|r
.goto 2509,51.24,62.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Altar|r.
.complete 98428,2 
.skipgossipid 141208
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Er'inye|r
.goto 2509,51.15,62.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Er'inye|r.
.turnin 98428 >>Turn in Vaults of Atal'Utek: The Altar of Corrosion
.target Er'inye
step
#completewith next
#label NatureOfHerWoundsA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 93417 >>Turn in The Vaults of Atal'Utek: Altar of Fangs
.accept 93419 >>Accept Nature of Her Wounds
.target Lady Liadrin
step
#completewith NatureOfHerWoundsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Eagletender Mal'Tiki|r
.goto 2509,44.43,62.20
.fly Tokka's Landing >>Fly to Tokka's Landing
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eagletender Mal'Tiki|r.
.target Eagletender Mal'Tiki
step
#requires NatureOfHerWoundsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2512,57.27,48.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 93417 >>Turn in The Vaults of Atal'Utek: Altar of Fangs
.accept 93419 >>Accept Nature of Her Wounds
.target Lady Liadrin
step
#arrowtext Click twice on the\n|cRXP_PICK_Fang of Ula'tek|r
.goto 2512,57.35,48.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fang of Ula'tek|r twice.
.complete 93419,1 
.complete 93419,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2512,57.27,48.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 93419 >>Turn in Nature of Her Wounds
.accept 93418 >>Accept The Venomous Abyss
.target Zul'jarra
]])

RXPGuides.RegisterGuide([[
#retail
#version 2
#group RestedXP Midnight
#name f) The Call of the Void
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 93420 >>Turn in Lor'themar's Judgement
.accept 95973 >>Accept Echoes of the Darkwell
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2393,46.20,47.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r by the Shining Span.
.turnin 95973 >>Turn in Echoes of the Darkwell
.accept 94519 >>Accept What Hope in the Light?
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2424,52.27,48.69
>>Travel to the Dawnwell and talk to |cRXP_FRIENDLY_Magister Umbric|r to check on |cRXP_FRIENDLY_Arator|r.
.skipgossipid 138179
.complete 94519,1
.target Magister Umbric
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2424,52.33,48.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r after the conversation.
.turnin 94519 >>Turn in What Hope in the Light?
.accept 94520 >>Accept Resurgence in Deatholme
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,43.77,82.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r at the Ruins of Deatholme.
.turnin 94520 >>Turn in Resurgence in Deatholme
.accept 94521 >>Accept The Direct Method
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,43.77,82.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 94522 >>Accept They Always Write It Down
.target Magister Umbric
step
#arrowtext Talk to the\n|cRXP_FRIENDLY_Pathetic Voidling|r
.goto 2395,42.91,85.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Pathetic Voidling|r.
.accept 94523 >>Accept My Poor Beautiful Self
.target Pathetic Voidling
step
.goto 2395,43.39,84.57
>>Investigate the |cRXP_PICK_Pilfered Amani Tablet|r.
.complete 94522,1
step
.goto 2395,42.61,85.00
>>Kill Twilight's Blade cultists and collect 10 |cRXP_LOOT_Twilight Clues|r.
.complete 94521,1
.mob Dark Caller
.mob Dark Elemental
.mob Twilight Bruiser
.mob Twilight Death-Dealer
.mob Darkness Evoker
step
.goto 2395,41.44,86.21
>>Investigate the |cRXP_PICK_Loa-Speaker's Mask|r.
.complete 94522,2
step
.goto 2395,41.66,88.12
>>Investigate the |cRXP_PICK_Damaged Amani Tablet|r.
.complete 94522,3
step
.goto 2395,44.05,88.60
>>Kill |cRXP_ENEMY_Aspirant Commander Glaivh|r.
.complete 94523,1
.mob Aspirant Commander Glaivh
step
.goto 2395,45.03,87.44
>>Investigate the |cRXP_PICK_Amani Chisel|r.
.complete 94522,4
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,42.91,85.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 94521 >>Turn in The Direct Method
.turnin 94522 >>Turn in They Always Write It Down
.accept 94524 >>Accept Under New Management
.target Arator
.target Magister Umbric
step
#arrowtext Talk to the\n|cRXP_FRIENDLY_Pathetic Voidling|r
.goto 2395,42.95,84.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Pathetic Voidling|r.
.turnin 94523 >>Turn in My Poor Beautiful Self
.accept 94525 >>Accept A Comeback Story
.target Pathetic Voidling
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,42.91,85.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r and choose the |cRXP_WARN_Stay awhile and listen|r option.
.skipgossipid 139197
.complete 94524,1
.target Arator
step
.goto 2395,42.64,86.10
>>Interact with 7 |cRXP_PICK_Latent Voidrifts|r to empower the Voidling.
.complete 94525,1
step
.goto 2395,43.43,87.77
>>Kill |cRXP_ENEMY_Aspirant Commander Mynra|r.
.complete 94524,2
.mob Aspirant Commander Mynra
step
.goto 2395,43.45,86.28
>>Kill |cRXP_ENEMY_Aspirant Commander Tai'ko|r.
.complete 94524,3
.mob Aspirant Commander Tai'ko
step
.goto 2395,41.71,86.15
>>Kill |cRXP_ENEMY_Aspirant Commander Thornheel|r.
.complete 94524,4
.mob Aspirant Commander Thornheel
step
#arrowtext Find\n|cRXP_FRIENDLY_Arator|r
.goto 2395,42.75,88.59
>>Follow the |cRXP_FRIENDLY_Empowered Voidling|r and find |cRXP_FRIENDLY_Arator|r in the lower Ruins of Deatholme.
.complete 94525,1
.target Empowered Voidling
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,42.75,88.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 94524 >>Turn in Under New Management
.turnin 94525 >>Turn in A Comeback Story
.accept 94526 >>Accept Verifiably Untrustworthy
.target Arator
.target Magister Umbric
step
#arrowtext Use\n|cRXP_PICK_Benthar's Scarlet Spire|r
.goto 2395,42.60,88.86
>>Use |cRXP_PICK_Benthar's Scarlet Spire|r on |cRXP_ENEMY_Lord Antenorian|r.
.complete 94526,1
.mob Lord Antenorian
step
.goto 2395,42.60,88.86
>>Defeat |cRXP_ENEMY_Lord Antenorian|r.
.complete 94526,2
.mob Lord Antenorian
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,42.45,89.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 94526 >>Turn in Verifiably Untrustworthy
.accept 94527 >>Accept Null Space
.target Magister Umbric
step
#arrowtext Enter the Rift
.goto 2395,42.38,89.32
>>Enter the rift and follow |cRXP_ENEMY_Lord Antenorian|r into the Unknown.
.complete 94527,1
step
.goto 2395,42.37,89.32
>>Survive Null Space. Use |cRXP_WARN_Brace|r during heavy damage, then use |cRXP_FRIENDLY_Arator's|r shield when it becomes available.
.complete 94527,2
.mob Lord Antenorian
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Magister Umbric|r
.goto 2437,38.84,74.09
>>After escaping Null Space, talk to |cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Magister Umbric|r at Speaker's Rest.
.turnin 94527 >>Turn in Null Space
.accept 94528 >>Accept Carving Out Room
.target Arator
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2437,38.88,74.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 94529 >>Accept A Dark Shadow Looms
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2437,38.84,74.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r and choose the |cRXP_WARN_Stay awhile and listen|r option.
.skipgossipid 139497
.complete 94529,1
.target Arator
step
.goto 2437,38.55,71.97
>>Kill |cRXP_ENEMY_Twilight's Blade|r cultists as you move through Speaker's Rest and investigate the first |cRXP_PICK_Twilight Correspondence|r.
.complete 94529,2,1
.mob Mordrag the Tainted
.mob Twilight Zealot
.mob Twilight Voidtongue
.mob Twilight Bonecrusher
.mob Twilight Mindshaper
.mob Twilight Soulbinder
.mob Twilight Dreadblade
.mob Shadowstalker
step
.goto 2437,37.00,69.80
>>Continue killing |cRXP_ENEMY_Twilight's Blade|r cultists while moving to the second |cRXP_PICK_Twilight Correspondence|r.
.complete 94529,2,2
.mob Mordrag the Tainted
.mob Twilight Zealot
.mob Twilight Voidtongue
.mob Twilight Bonecrusher
.mob Twilight Mindshaper
.mob Twilight Soulbinder
.mob Twilight Dreadblade
.mob Shadowstalker
step
.goto 2437,35.69,73.47
>>Continue killing |cRXP_ENEMY_Twilight's Blade|r cultists while moving to the third |cRXP_PICK_Twilight Correspondence|r.
.complete 94529,2
.mob Mordrag the Tainted
.mob Twilight Zealot
.mob Twilight Voidtongue
.mob Twilight Bonecrusher
.mob Twilight Mindshaper
.mob Twilight Soulbinder
.mob Twilight Dreadblade
.mob Shadowstalker
step
.goto 2437,37.56,71.91
>>Finish killing 12 |cRXP_ENEMY_Twilight's Blade|r cultists around Speaker's Rest.
.complete 94528,1
.mob Mordrag the Tainted
.mob Twilight Zealot
.mob Twilight Voidtongue
.mob Twilight Bonecrusher
.mob Twilight Mindshaper
.mob Twilight Soulbinder
.mob Twilight Dreadblade
.mob Shadowstalker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2437,38.84,74.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 94528 >>Turn in Carving Out Room
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2437,38.88,74.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 94529 >>Turn in A Dark Shadow Looms
.accept 94530 >>Accept The Call of the Void
.target Magister Umbric
step
#arrowtext Enter\n|cRXP_FRIENDLY_Umbric's Portal|r
.goto 2437,38.94,73.99
>>Enter |cRXP_FRIENDLY_Umbric's Portal|r to the Tomb of Mun'jin.
.complete 94530,1
step
.goto 2437,38.04,73.16
>>Permanently defeat |cRXP_ENEMY_Lord Antenorian|r.
.complete 94530,2
.mob Lord Antenorian
step
.goto 2437,38.71,73.99
>>Use the portal to leave the Tomb of Mun'jin.
.complete 94530,3
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2437,38.84,74.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r after returning to Speaker's Rest.
.turnin 94530 >>Turn in The Call of the Void
.accept 94531 >>Accept Like Mother, Like Son
.target Arator
step
#title Use Hearthstone
>>If your Hearthstone is set to |cRXP_WARN_Wayfarer's Rest|r, use the Hearthstone button in the Active Items frame to return to Silvermoon. Otherwise, travel back to Silvermoon.
.hs >>Hearth to Wayfarer's Rest
.cooldown item,6948,>0,1
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.46,70.34
>>Return to Silvermoon and talk to |cRXP_FRIENDLY_Lor'themar Theron|r upstairs inside the Sanctum of Light.
.turnin 94531 >>Turn in Like Mother, Like Son
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name xb) Val Zone Unlock
#internal
step
.isOnQuest 96048
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.59,51.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96048 >>Turn in The Time to Strike
.target Riftblade Maella
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.59,51.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.accept 96049 >>Accept Stalkers of the Stars
.accept 96703 >>Accept Veterans of the Great Dark
.target Riftblade Maella
step
#title Follow the arrow
#arrowtext |cFFFCDC00Follow the Arrow|r
.goto 2393,51.27,61.10
.complete 96049,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Allari the Souleater|r and |cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,51.43,60.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Allari the Souleater|r and |cRXP_FRIENDLY_Belath Dawnblade|r.
.complete 96049,3 
.target Allari the Souleater
.skipgossipid 139484
.complete 96049,2 
.target Belath Dawnblade
.skipgossipid 139905
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2393,51.29,61.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.complete 96049,4 
.target Leona Darkstrider
.skipgossipid 139507
step
#loop
.goto 2393,49.59,60.09,20,0
.goto 2393,49.74,55.70,20,0
.goto 2393,51.90,56.89,20,0
.goto 2393,54.05,59.30,20,0
.goto 2393,52.43,63.17,20,0
>>Run through the |cRXP_PICK_Shadows|r.
.complete 96049,5 
step
#title Follow the arrow
#arrowtext |cFFFCDC00Follow the Arrow|r
.goto 2393,51.33,61.66
.complete 96049,6 
step
#title Follow the arrow
#arrowtext |cFFFCDC00Follow the Arrow|r
.goto 2393,49.68,41.07
.complete 96703,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Baraat the Longshot|r
.goto 2393,50.50,41.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baraat the Longshot|r.
.complete 96703,3 
.target Baraat the Longshot
.skipgossipid 139901
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Tala'saan|r
.goto 2393,49.90,40.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Tala'saan|r.
.complete 96703,2 
.target Commander Tala'saan
.skipgossipid 139483
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Fareeya|r and |cRXP_FRIENDLY_Archmage Y'mera|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Fareeya|r and |cRXP_FRIENDLY_Archmage Y'mera|r.
.complete 96703,4 
.goto 2393,49.82,40.39
.target Captain Fareeya
.skipgossipid 140523
.complete 96703,5 
.goto 2393,49.85,41.02
.target Archmage Y'mera
.skipgossipid 140038
step
#completewith next
#label VeteransOfTheGreatDarkA
#hidewindow
.complete 96703,6 
step
#completewith VeteransOfTheGreatDarkA
#arrowtext Click on the\n|cRXP_PICK_Beacon|r
.goto 2393,49.95,41.00
.cast 1290653 >>Click on the |cRXP_PICK_Beacon|r and run away.
step
#requires VeteransOfTheGreatDarkA
#arrowtext Click on the\n|cRXP_PICK_Beacon|r
.goto 2393,49.25,41.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Beacon|r and run away.
.complete 96703,6 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.60,51.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96049 >>Turn in Stalkers of the Stars
.turnin 96703 >>Turn in Veterans of the Great Dark
.accept 96708 >>Accept To the Voidstorm and Beyond!
.target Riftblade Maella
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.60,51.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella (Optional)|r.
.complete 96708,1 
.target Riftblade Maella (Optional)
.skipgossipid 140046
step
#completewith next
#label VoidstormAndBeyondA
#hidewindow
.complete 96708,2 
step
#completewith VoidstormAndBeyondA
#arrowtext Click on the\n|cRXP_PICK_Portal to Voidstorm|r
.goto 2393,35.27,66.20
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r.
step
#requires VoidstormAndBeyondA
#arrowtext Click on the\n|cRXP_PICK_Portal to Voidstorm|r
.goto 2393,35.27,66.20,-1
.goto 2405,51.56,71.03,-1
>>Click on the |cRXP_PICK_Portal to Voidstorm|r
.complete 96708,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2405,51.55,71.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96708 >>Turn in To the Voidstorm and Beyond!
.accept 96051 >>Accept Through the Cold Rift
.target Riftblade Maella
step
#arrowtext Click on the\n|cRXP_PICK_Cynosure|r
.goto 2405,51.49,71.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cynosure|r.
.complete 96051,1 
step
#arrowtext Use the ExtraActionButton
>>Use the ExtraActionButton
.complete 96051,2 
step
#arrowtext Click on the\n|cRXP_PICK_Rift|r
.goto 2405,51.43,71.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rift|r.
.complete 96051,3 
step
#arrowtext |cFFFCDC00Wait for the Roleplay|r
.goto 2599,62.58,16.43
.complete 96051,4 
.timer 15,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2599,59.27,19.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96051 >>Turn in Through the Cold Rift
.accept 96053 >>Accept Surveying the Frozen Wastes
.daily 96713,96714,96716 >>Accept Showdown on Val
.target Riftblade Maella
step
#loop
#arrowtext Click on the\n|cRXP_PICK_Surveillance Beacons|r
.goto 2599,50.87,39.75,10,0
.goto 2599,44.17,63.95,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Surveillance Beacons|r.
.complete 96053,2 
step
#arrowtext Click on the\n|cRXP_PICK_Final Beacon|r
.goto 2599,41.04,75.91,12,0
.goto 2599,45.60,80.81,10,0
.goto 2599,41.97,84.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Surveillance Beacon|r.
.complete 96053,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2599,41.66,84.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 96053 >>Turn in Surveying the Frozen Wastes
.accept 96473 >>Accept Imperator Pertinax
.accept 97071 >>Accept A Frigid Welcome to Val
.target Belath Dawnblade
step
#arrowtext Click on the\n|cRXP_PICK_Portal|r
.goto 2599,49.57,97.00
>>|cRXP_WARN_NOTE:|r This quest requires multiple people and at least a tank. It's also optional so you can skip it.
.complete 96473,1 
step
#arrowtext Kill |cRXP_ENEMY_Imperator Pertinax|r
.goto 2618,84.38,69.58,12,0
.goto 2618,42.60,81.31
>>Kill |cRXP_ENEMY_Imperator Pertinax|r.
>>|cRXP_WARN_NOTE:|r This quest requires multiple people and at least a tank. It's also optional so you can skip it.
.complete 96473,2 
.mob Imperator Pertinax
step
#arrowtext Use |T1711324:0|t[Lightveil Recall Beacon]\nTalk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2599,59.46,22.06
>>Use the |T1711324:0|t[Lightveil Recall Beacon].
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 97071 >>Turn in A Frigid Welcome to Val
.target Riftblade Maella
.use 276373
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2599,59.75,22.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 96473 >>Turn in Imperator Pertinax
.target Decimus
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name xc) Naigtal Zone Unlock
#internal
step
#label NaigtalZoneUnlockA
.isOnQuest 96048
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.59,51.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96048 >>Turn in The Time to Strike
.target Riftblade Maella
step
#label NaigtalZoneUnlockB
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.59,51.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.accept 96049 >>Accept Stalkers of the Stars
.accept 96703 >>Accept Veterans of the Great Dark
.target Riftblade Maella
step
#label NaigtalZoneUnlockC
#title Follow the arrow
#arrowtext |cFFFCDC00Follow the Arrow|r
.goto 2393,51.27,61.10
.complete 96049,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Allari the Souleater|r and |cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,51.43,60.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Allari the Souleater|r and |cRXP_FRIENDLY_Belath Dawnblade|r.
.complete 96049,3 
.target Allari the Souleater
.skipgossipid 139484
.complete 96049,2 
.target Belath Dawnblade
.skipgossipid 139905
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2393,51.29,61.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.complete 96049,4 
.target Leona Darkstrider
.skipgossipid 139507
step
#loop
.goto 2393,49.59,60.09,20,0
.goto 2393,49.74,55.70,20,0
.goto 2393,51.90,56.89,20,0
.goto 2393,54.05,59.30,20,0
.goto 2393,52.43,63.17,20,0
>>Run through the |cRXP_PICK_Shadows|r.
.complete 96049,5 
step
#label NaigtalZoneUnlockD
#title Follow the arrow
#arrowtext |cFFFCDC00Follow the Arrow|r
.goto 2393,51.33,61.66
.complete 96049,6 
step
#label NaigtalZoneUnlockE
#title Follow the arrow
#arrowtext |cFFFCDC00Follow the Arrow|r
.goto 2393,49.68,41.07
.complete 96703,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Baraat the Longshot|r
.goto 2393,50.50,41.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baraat the Longshot|r.
.complete 96703,3 
.target Baraat the Longshot
.skipgossipid 139901
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Tala'saan|r
.goto 2393,49.90,40.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Tala'saan|r.
.complete 96703,2 
.target Commander Tala'saan
.skipgossipid 139483
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Captain Fareeya|r and |cRXP_FRIENDLY_Archmage Y'mera|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Fareeya|r and |cRXP_FRIENDLY_Archmage Y'mera|r.
.complete 96703,4 
.goto 2393,49.82,40.39
.target Captain Fareeya
.skipgossipid 140523
.complete 96703,5 
.goto 2393,49.85,41.02
.target Archmage Y'mera
.skipgossipid 140038
step
#completewith next
#label VeteransOfTheGreatDarkA
#hidewindow
.complete 96703,6 
step
#completewith VeteransOfTheGreatDarkA
#arrowtext Click on the\n|cRXP_PICK_Beacon|r
.goto 2393,49.95,41.00
.cast 1290653 >>Click on the |cRXP_PICK_Beacon|r and run away.
step
#requires VeteransOfTheGreatDarkA
#label NaigtalZoneUnlockF
#arrowtext Click on the\n|cRXP_PICK_Beacon|r
.goto 2393,49.25,41.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Beacon|r and run away.
.complete 96703,6 
step
#label NaigtalZoneUnlockG
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.60,51.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96049 >>Turn in Stalkers of the Stars
.turnin 96703 >>Turn in Veterans of the Great Dark
.accept 96708 >>Accept To the Voidstorm and Beyond!
.target Riftblade Maella
step
#label NaigtalZoneUnlockH
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.60,51.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella (Optional)|r.
.complete 96708,1 
.target Riftblade Maella (Optional)
.skipgossipid 140046
step
#completewith next
#label VoidstormAndBeyondA
#hidewindow
.complete 96708,2 
step
#completewith VoidstormAndBeyondA
#arrowtext Click on the\n|cRXP_PICK_Portal to Voidstorm|r
.goto 2393,35.27,66.20
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r.
step
#requires VoidstormAndBeyondA
#label NaigtalZoneUnlockI
#arrowtext Click on the\n|cRXP_PICK_Portal to Voidstorm|r
.goto 2393,35.27,66.20,-1
.goto 2405,51.56,71.03,-1
>>Click on the |cRXP_PICK_Portal to Voidstorm|r
.complete 96708,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2405,51.55,71.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96708 >>Turn in To the Voidstorm and Beyond!
.accept 96052 >>Accept Through the Mana Rift
.target Riftblade Maella
step
#arrowtext Click on the\n|cRXP_PICK_Cynosure|r
.goto 2405,51.49,71.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cynosure|r.
.complete 96052,1 
step
#arrowtext Use the ExtraActionButton
>>Use the ExtraActionButton
.complete 96052,2 
step
#arrowtext Click on the\n|cRXP_PICK_Rift|r
.goto 2405,51.43,71.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rift|r.
.complete 96052,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2600,48.07,81.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96052 >>Turn in Through the Mana Rift
.accept 96054 >>Accept Surveying the Mana-Bog
.target Riftblade Maella
step
.goto 2600,48.18,81.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.daily 96717,96718,96720 >>Accept Showdown on Naigtal
.target Decimus
step
#arrowtext Beacon activated (1/2)\n|cFFFCDC00(Read Note)|r
.goto 2600,44.09,52.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Surveillance Beacon|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 96054,2,1 
step
#arrowtext Beacon activated (2/2)\n|cFFFCDC00(Read Note)|r
.goto 2600,60.11,43.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Surveillance Beacons|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 96054,2 
step
#arrowtext Final Beacon activated
.goto 2600,70.91,62.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Surveillance Beacon|r.
.complete 96054,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Tala'saan|r
.goto 2600,70.8,62.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Tala'saan|r.
.turnin 96054 >>Turn in Surveying the Mana-Bog
.accept 96472 >>Accept The Nexus-Captain
.accept 97072 >>Accept A Swampy Welcome to Naigtal
.target Belath Dawnblade
step
#arrowtext Kill |cRXP_ENEMY_Nexus-Captain Leth'ir|r\n|cRXP_WARN_(OPTIONAL)|r
.goto 2600,77.33,70.88
>>Kill |cRXP_ENEMY_Nexus-Captain Leth'ir|r.
>>|cRXP_WARN_NOTE:|r This quest requires multiple people or at least a tank. It's also optional so you can skip it.
.complete 96472,1 
.mob Nexus-Captain Leth'ir
step
#arrowtext Use |T1711324:0|t[Lightveil Recall Beacon]\nTalk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2600,48.53,81.99
>>Use the |T1711324:0|t[Lightveil Recall Beacon].
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 97072 >>Turn in A Swampy Welcome to Naigtal
.target Riftblade Maella
.use 276372
step
#label NaigtalZoneUnlockZ
.isOnQuest 96472
.isQuestComplete 96472
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2600,48.53,81.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96472 >>Turn in The Nexus-Captain
.target Riftblade Maella
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Legacy of the Amani2
#internal
step
.goto 2393,45.43,70.33019
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.accept 95973 >>Accept Echoes of the Darkwell
.target Lor'themar Theron
step
.goto 2393,46.22,47.22075
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 95973 >>Turn in Echoes of the Darkwell
.target Magister Umbric
.accept 94519 >>Accept What Hope in the Light?
step
.goto 2424,52.24,48.62093
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric at the Dawnwell|r.
.complete 94519,1 
.target Magister Umbric at the Dawnwell
.skipgossipid 138179
step
.goto 2424,52.34,48.68070
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 94519 >>Turn in What Hope in the Light?
.target Arator

step
.goto 2424,52.26,48.70062
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 94520 >>Accept Resurgence in Deatholme
.target Magister Umbric
step
.goto 2395,43.78,82.44043
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 94520 >>Turn in Resurgence in Deatholme
.target Arator
.accept 94521 >>Accept The Direct Method
step
.goto 2395,43.74,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 94522 >>Accept They Always Write It Down
.target Magister Umbric
step
.goto 2395,43.4,84.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r
.complete 94522,1 
step
.goto 2395,42.95,85.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pathetic Voidling|r.
.accept 94523 >>Accept My Poor Beautiful Self
.target Pathetic Voidling
step
.goto 2395,41.44,86.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mask|r
.complete 94522,2 
step
.goto 2395,41.65,88.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tablet|r
.complete 94522,3 
step
.goto 2395,44.11,88.65
>>Kill |cRXP_ENEMY_Aspirant Commander Glaivh|r.
.complete 94523,1 
.mob Aspirant Commander Glaivh
step
.goto 2395,45.04,87.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chisel|r
.complete 94522,4 
step
.goto 2395,44.12,85.75
.complete 94521,1 
step
.goto 2395,42.96,84.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pathetic Voidling|r.
.turnin 94523 >>Turn in My Poor Beautiful Self
.target Pathetic Voidling
step
.goto 2395,42.91,85.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 94521 >>Turn in The Direct Method
.target Arator
.turnin 94522 >>Turn in They Always Write It Down
.accept 94524 >>Accept Under New Management
step
.goto 2395,42.96,84.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pathetic Voidling|r.
.accept 94525 >>Accept A Comeback Story
.target Pathetic Voidling
step
.goto 2395,43.45,86.30
>>Kill |cRXP_ENEMY_Aspirant Commander Tai'ko|r.
.complete 94524,3 
.mob Aspirant Commander Tai'ko
step
.goto 2395,43.41,87.75
>>Kill |cRXP_ENEMY_Aspirant Commander Mynra|r.
.complete 94524,2 
.mob Aspirant Commander Mynra
step
.goto 2395,41.69,86.15
>>Kill |cRXP_ENEMY_Aspirant Commander Thornheel|r.
.complete 94524,4 
.mob Aspirant Commander Thornheel
step
.goto 2395,42.96,86.48
.complete 94525,1 
step
.goto 2395,42.75,88.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 94524 >>Turn in Under New Management
.target Arator
step
.goto 2395,42.69,88.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 94525 >>Turn in A Comeback Story
.target Magister Umbric
step
.goto 2395,42.69,88.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 94526 >>Accept Verifiably Untrustworthy
.target Magister Umbric
step
.goto 2395,42.57,88.84
>>Use the |T237382:0|t|cRXP_WARN_[ExtraActionButton]|r on |cRXP_ENEMY_Lord Antenorian|r
.complete 94526,1 
.mob Lord Antenorian
step
.goto 2395,42.57,88.84
>>Kill |cRXP_ENEMY_Lord Antenorian|r
.complete 94526,2 
.mob Lord Antenorian
step
.goto 2395,42.46,89.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 94526 >>Turn in Verifiably Untrustworthy
.target Magister Umbric
.accept 94527 >>Accept Null Space
step
.goto 2395,42.37,89.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 94527,1 
]])

