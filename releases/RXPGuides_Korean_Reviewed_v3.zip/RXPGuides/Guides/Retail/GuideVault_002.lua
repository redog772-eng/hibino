if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) DF Horde Intro Midnight
#internal
step << !Evoker
.isQuestAvailable 87562
*|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r.
.goto 85,44.08,38.01
.accept 65435 >>Accept The Dragon Isles Await
.target Ebyssian
step << !Evoker
.isQuestAvailable 87562
.subzoneskip 11402 
>>Use the |T134309:0|t[Lost Dragonscale]
.complete 65435,1 
.use 205458
step << !Evoker
.isQuestAvailable 87562
.goto 85,44.08,37.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r.
.complete 65435,2 
.target Ebyssian
step << !Evoker
.isQuestAvailable 87562
.goto 85,44.08,37.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r.
.turnin 65435 >>Turn in The Dragon Isles Await
.target Ebyssian
step << !Evoker
.isQuestAvailable 87562
.goto 85,44.06,37.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r.
.accept 65437 >>Accept Aspectral Invitation
.complete 65437,1 
.turnin 65437 >>Turn in Aspectral Invitation
.target Ebyssian
.skipgossipid 55582
step << Dracthyr !Evoker
.goto 85,44.06,37.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r.
.accept 65613 >>Accept An Iconic, Draconic Look
.target Ebyssian
.skipgossipid 55863
step << Dracthyr !Evoker
.goto 85,44.06,37.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r.
.complete 65613,1 
.timer 23,Roleplay Duration
.target Ebyssian
.skipgossipid 55863
step << Dracthyr !Evoker
.goto 85,44.06,37.98
>>|cRXP_WARN_Wait for the roleplay|r.
.complete 65613,2 
.target Ebyssian
step << Dracthyr !Evoker
.goto 85,44.06,37.98
>>Use the ExtraActionButton.
.complete 65613,3 
.target Ebyssian
step << Dracthyr !Evoker
.goto 85,44.06,37.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r.
.turnin 65613 >>Turn in An Iconic, Draconic Look
.target Ebyssian
step
.isQuestAvailable 87562
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r and |cRXP_FRIENDLY_Scalecommander Cindrethresh|r.
.accept 65443 >>Accept Expeditionary Coordination
.goto 85,44.19,37.79
.accept 72256 >>Accept The Dark Talons
.goto 85,44.04,38.25
.target Naleidea Rivergleam
.target Scalecommander Cindrethresh
step
.isQuestAvailable 87562
#completewith next
#label Pathfinder Tacha
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pathfinder Tacha|r.
.complete 65443,2 
.target Pathfinder Tacha
step
.isQuestAvailable 87562
#completewith Pathfinder Tacha
.goto 85,44.03,38.81
.zone 1 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Dranosh'ar Blockade|r.
step
.isQuestAvailable 87562
#requires Pathfinder Tacha
.goto 1,54.02,13.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pathfinder Tacha|r.
.complete 65443,2 
.target Pathfinder Tacha
.skipgossipid 53882
step
.isQuestAvailable 87562
.goto 1,54.13,9.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodethi|r.
.complete 72256,1 
.skipgossipid 107450
.target Kodethi
step
.isQuestAvailable 87562
.goto 1,55.17,11.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss Magor|r.
.complete 65443,1 
.target Boss Magor
.skipgossipid 53883
step
.isQuestAvailable 87562
.goto 1,55.97,13.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cataloger Coralie|r behind the tower.
.complete 65443,3 
.target Cataloger Coralie
.skipgossipid 54035
step
.isQuestAvailable 87562
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r and |cRXP_FRIENDLY_Archmage Khadgar|r |cRXP_WARN_on top of the tower|r.
.turnin 65443 >>Turn in Expeditionary Coordination
.turnin 72256 >>Turn in The Dark Talons
.timer 2.5,Roleplay Duration
.goto 1,55.81,12.66
.accept 65439 >>Accept Whispers on the Winds
.complete 65439,1 
.skipgossipid 55626
.goto 1,55.92,12.61
.target Naleidea Rivergleam
.target Archmage Khadgar
step
.isQuestAvailable 87562
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ebyssian|r and |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin -65439 >>Turn in Whispers on the Winds
.turnin -70198 >>Turn in The Call of the Isles
.goto 1,55.85,12.74
.target +Ebyssian
.accept 65444 >>Accept To the Dragon Isles!
.goto 1,55.81,12.66
.target +Naleidea Rivergleam
step
.isQuestAvailable 87562
.goto 1,55.77,12.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r.
.complete 65444,1 
.target Sharukaru
step
.isQuestAvailable 87562
.goto 2022,80.63,27.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 65444 >>Turn in To the Dragon Isles!
.target +Naleidea Rivergleam
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r, |cRXP_FRIENDLY_Scalecommander Cindrethresh|r and |cRXP_FRIENDLY_Boss Magor|r.
.accept 65452 >>Accept Explorers in Peril
.goto 2022,80.62,27.60
.target +Naleidea Rivergleam
.accept 65453 >>Accept Primal Pests
.goto 2022,80.65,27.60
.target +Scalecommander Cindrethresh
.accept 65451 >>Accept Practice Materials
.goto 2022,80.60,27.65
.target +Boss Magor
step
#completewith next
#label Pathfinder Poppy
#hidewindow
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rib Cage|r.
.complete 65452,1 
step
#completewith Pathfinder Poppy
.goto 2022,80.76,27.42,5 >>Go out of the |cRXP_WARN_NO MOUNT ZONE|r
step
#requires Pathfinder Poppy
#completewith WakingShoresExplorersInPeril
.goto 2022,79.24,25.84,0,0
>>Kill |cRXP_ENEMY_Primal Proto-Drakes|r.
.complete 65453,1 
.mob Primal Proto-Drake
step
#requires Pathfinder Poppy
#completewith WakingShoresExplorersInPeril
>>Kill |cRXP_ENEMY_Primal Proto-Whelps|r.
*Loot them for |T134309:0|t[|cRXP_LOOT_Proto-Whelp Scale|r].
.complete 65451,1 
.mob Primal Proto-Whelp
step
#requires Pathfinder Poppy
.goto 2022,80.37,26.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rib Cage|r.
.complete 65452,1 
step
.goto 2022,78.71,24.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Archivist Spearblossom|r.
.complete 65452,2 
.target Archivist Spearblossom
step
#label WakingShoresExplorersInPeril
.goto 2022,77.37,29.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Spelunker Lazee|r hanging on the chain.
.complete 65452,3 
.target Spelunker Lazee
step
#hidewindow
#completewith Primal Proto-drakesH
#loop
.goto 2022,77.9,30.8,20,0
.goto 2022,78.56,28.70,20,0
.goto 2022,78.11,27.76,20,0
.goto 2022,77.03,28.74,20,0
.goto 2022,79.39,29.93,20,0
.goto 2022,80.31,28.77,20,0
.goto 2022,77.7,26.4,20,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Primal Proto-Drakes|r.
.complete 65453,1 
.mob Primal Proto-Drake
step
>>Kill |cRXP_ENEMY_Primal Proto-Whelps|r.
*Loot them for |T134309:0|t[|cRXP_LOOT_Proto-Whelp Scale|r].
.complete 65451,1 
.mob Primal Proto-Whelp
step
#label Primal Proto-drakesH
>>Kill |cRXP_ENEMY_Primal Proto-Drakes|r.
.complete 65453,1 
.mob Primal Proto-Drake
step
.goto 2022,76.61,33.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 65452 >>Turn in Explorers in Peril
.accept 69910 >>Accept Where is Wrathion?
.target Naleidea Rivergleam
step
#completewith next
#label TalkToSendraxInquire
#hidewindow
.goto 2022,76.58,33.66,0,0
.complete 69910,1 
step
#completewith TalkToSendraxInquire
.goto 2022,76.58,33.66
.gossipoption 55636 >>Talk to |cRXP_FRIENDLY_Sendrax|r. 
.timer 22,Roleplay Duration
.target Sendrax
step
#requires TalkToSendraxInquire
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scalecommander Cindrethresh|r and |cRXP_FRIENDLY_Warlord Breka Grimaxe|r.
.accept 66110 >>Accept Give Peace a Chance
.goto 2022,76.36,33.09
.target +Scalecommander Cindrethresh
.turnin 65453 >>Turn in Primal Pests
.goto 2022,76.28,33.02
.target +Warlord Breka Grimaxe
step
.goto 2022,75.94,33.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss Magor|r.
.turnin 65451 >>Turn in Practice Materials
.target Boss Magor
step
.goto 2022,76.41,34.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haephesta|r
.accept 70148 >>Accept Without Purpose << Evoker
.target Haephesta
step << Evoker
.goto 2022,76.44,34.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kholmar Sunrunner|r.
.complete 70148,1 
.skipgossipid 56060
.skipgossipid 56061
.target Kholmar Sunrunner
step << Evoker
.goto 2022,76.69,34.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toninaar|r
.complete 70148,2 
.skipgossipid 56063
.skipgossipid 56064
.target Toninaar
step
.goto 2022,76.73,34.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Garrick|r.
.turnin 66110 >>Turn in Give Peace a Chance
.accept 66111 >>Accept Encroaching Elementals
.target Captain Garrick
step
#title |cFFFCDC00Follow the Arrow|r
.goto 2022,76.58,33.66
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 69910,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.goto 2022,76.58,33.66
.turnin 69910 >>Turn in Where is Wrathion?
.target Sendrax
step
.goto 2022,76.58,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.accept 69911 >>Accept Excuse the Mess
.target Sendrax
.achievementIncomplete 15394,0
.achievementIncomplete 16336,0
.achievementIncomplete 16363,0
.achievementIncomplete 16334,0
step
.goto 2022,76.58,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r
.accept 72293 >>Accept Adventuring in the Dragon Isles
.target Sendrax
.achievementComplete 15394,1
.achievementComplete 16336,1
.achievementComplete 16363,1
.achievementComplete 16334,1
step
.goto 2022,76.52,34.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.turnin 72293 >>Turn in Adventuring in the Dragon Isles
.acceptmap 72266
.accept 72266 >>Accept The Waking Shores
.acceptmap 72267
.accept 72267 >>Accept Ohn'ahran Plains
.acceptmap 72268
.accept 72268 >>Accept Azure Span
.acceptmap 72269
.accept 72269 >>Accept Thaldraszus
.achievementComplete 15394,1
.achievementComplete 16336,1
.achievementComplete 16363,1
.achievementComplete 16334,1
step
.goto 2022,76.58,33.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r
.turnin 72266 >>Turn in The Waking Shores
.target Sendrax
.accept 69911 >>Accept Excuse the Mess
.achievementComplete 15394,1
.achievementComplete 16336,1
.achievementComplete 16363,1
.achievementComplete 16334,1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) DF Alliance Intro Midnight
#internal
step
.isQuestAvailable 87562
.goto 84,79.81,27.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.accept 65436 >>Accept The Dragon Isles Await
.target Wrathion
step
.isQuestAvailable 87562
#completewith next
#label WaytoWrathion
.subzoneskip 6292
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.complete 65436,2 
.turnin 65436 >>Turn in The Dragon Isles Await
.accept 66577 >>Accept Aspectral Invitation
.disablecheckbox
step
#completewith WaytoWrathion
.isQuestAvailable 87562
.subzoneskip 6292
>>Use the |T134309:0|t[Lost Dragonscale] to teleport to stormwind infront of |cRXP_FRIENDLY_Wrathion|r.
.complete 65436,1 
.use 205456
step
.isQuestAvailable 87562
#requires WaytoWrathion
.goto 84,79.93,27.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r in Stormwind.
.complete 65436,2 
.turnin 65436 >>Turn in The Dragon Isles Await
.accept 66577 >>Accept Aspectral Invitation
.target Wrathion
step
.isQuestAvailable 87562
.goto 84,79.93,27.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r
.complete 66577,1 
.skipgossipid 55659
.target Wrathion
step
.isQuestAvailable 87562
.goto 84,79.81,27.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r
.turnin 66577 >>Turn in Aspectral Invitation
.target Wrathion
step << Dracthyr
.goto 84,79.84,27.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.target Wrathion
.turnin 66577 >>Turn in Aspectral Invitation
.accept 65101 >>Accept An Iconic, Draconic Look
step << Dracthyr
.goto 84,82.61,23.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.complete 65101,1 
.timer 32,RP
.skipgossipid 55882
.target Wrathion
step << Dracthyr
.goto 84,82.53,23.96
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 65101,2 
step << Dracthyr
.goto 84,82.53,23.96
>>Use the [ExtraActionButton]
.complete 65101,3 
step << Dracthyr
.goto 84,82.53,23.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r
.turnin 65101 >>Turn in An Iconic, Draconic Look
.target Wrathion
step
.isQuestAvailable 87562
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scalecommander Azurathel|r and |cRXP_FRIENDLY_Toddy Whiskers|r.
.accept 72240 >>Accept The Obsidian Warders
.goto 84,79.95,26.95
.target +Scalecommander Azurathel
.accept 66589 >>Accept Expeditionary Coordination
.goto 84,79.73,27.35
.target +Toddy Whiskers
step
.isQuestAvailable 87562
#completewith next
#label Pathfinder Jeb
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pathfinder Jeb|r.
.complete 66589,2 
.target Pathfinder Jeb
step
.isQuestAvailable 87562
#completewith Pathfinder Jeb
.goto 84,80.31,27.34
.cast 459750 >>Click on the |cRXP_PICK_Portal to Stormwind Harbor|r.
step
#requires Pathfinder Jeb
.isQuestAvailable 87562
.goto 84,38.26,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pathfinder Jeb|r.
.complete 66589,2 
.skipgossipid 55649
.target Pathfinder Jeb
step
.isQuestAvailable 87562
.goto 84,39.25,41.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dervishian|r.
.complete 72240,1 
.skipgossipid 107417
.target Dervishian
step
.isQuestAvailable 87562
.goto 84,38.1,35.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r.
.complete 66589,1 
.skipgossipid 55651
.target Thaelin Darkanvil
step
.isQuestAvailable 87562
.goto 84,32.89,34.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cataloger Wulferd|r.
.complete 66589,3 
.skipgossipid 55650
.target Cataloger Wulferd
step
.isQuestAvailable 87562
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toddy Whiskers|r.
.goto 84,22.70,55.66
.turnin 66589 >>Turn in Expeditionary Coordination
.turnin 72240 >>Turn in The Obsidian Warders
.timer 2.5,RP
.target Toddy Whiskers
step
.isQuestAvailable 87562
.goto 84,22.94,56.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.accept 66596 >>Accept Whispers on the Winds
.complete 66596,1 
.skipgossipid 55739
.target Archmage Khadgar
step
.isQuestAvailable 87562
.goto 84,22.92,56.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.turnin 66596 >>Turn in Whispers on the Winds
.target Wrathion
step
.isQuestAvailable 87562
.goto 84,22.73,55.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toddy Whiskers|r.
.turnin -70197 >>Turn in The Call of the Isles
.accept 67700 >>Accept To the Dragon Isles!
.target Toddy Whiskers
step
.isQuestAvailable 87562
.goto 84,23.22,55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r.
.complete 67700,1 
step
.isQuestAvailable 87562
.goto 2022,82.13,31.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toddy Whiskers|r
.turnin 67700 >>Turn in To the Dragon Isles!
.timer 20,RP
.target Toddy Whiskers
step
#completewith next
#label Kalecgos123
.isQuestTurnedIn 63012
#hidewindow
.zoneskip 84,1
.accept 87547 >>Accept What's Your Specialty?
step
#completewith Kalecgos123
.goto 84,48.89,93.42
.zone 2112 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Valdrakken|r.
step
#requires Kalecgos123
#completewith next
#label Kalecgos321
.isQuestTurnedIn 63012
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.target Kalecgos
.accept 87547 >>Accept What's Your Specialty?
step
#completewith Kalecgos321
.goto 2112,61.87,32.31
.cast 387905 >>Click on the |cRXP_PICK_Teleporter|r
step
#requires Kalecgos321
.isQuestTurnedIn 63012
.goto 2022,81.98,31.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.target Kalecgos
.accept 87547 >>Accept What's Your Specialty?
step
.isQuestTurnedIn 63012
.goto 2022,81.98,31.46
>>Open your Talents(Default: N) and Select any specialization.
*|cRXP_WARN_If you already have your desired one, switch to another and back|r.
.complete 87547,1 
.macro Open Talents,611426 >>/run ToggleTalentFrame()
step
.isQuestTurnedIn 63012
.goto 2022,81.97,31.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 87547 >>Turn in What's Your Specialty?
.target Kalecgos
.accept 87555 >>Accept Home Is Where the Hearth Is
step
.isQuestTurnedIn 63012
.goto 2022,81.31,31.90
>>Mount up on any mount. |cRXP_WARN_Not Travelform|r.
.complete 87555,1 
.macro Summon Random Favorite Mount,413588 >>/run C_MountJournal.SummonByID(0)
.target Happy Hal
step
.isQuestTurnedIn 63012
.goto 2022,81.31,31.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Happy Hal|r.
.complete 87555,2 
.skipgossipid 54925
.target Happy Hal
step
.isQuestTurnedIn 63012
.goto 2022,81.98,31.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 87555 >>Turn in Home Is Where the Hearth Is
.target Kalecgos
.accept 87562 >>Accept Aiding the Dragon Isles
step
.isQuestTurnedIn 63012
.goto 2022,82.12,31.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toddy Whiskers|r
.turnin 87562 >>Turn in Aiding the Dragon Isles
.target Toddy Whiskers
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r and |cRXP_FRIENDLY_Scalecommander Azurathel|r.
.accept 70122 >>Accept Explorers in Peril
.goto 2022,82.13,31.88
.target +Toddy Whiskers
.accept 70124 >>Accept Practice Materials
.goto 2022,82.09,31.89
.target +Thaelin Darkanvil
.accept 70123 >>Accept Primal Pests
.goto 2022,82.16,31.86
.target +Scalecommander Azurathel
step
#completewith next
#label Professor Cogcatcher
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Professor Cogcatcher|r.
.complete 70122,1 
.target Professor Cogcatcher
step
#completewith Professor Cogcatcher
.goto 2022,82.27,32.11,5 >>Go out of the |cRXP_WARN_NO MOUNT ZONE|r
step
#requires Professor Cogcatcher
#completewith WakingShoresExplorersInPerilAlliance
>>Kill |cRXP_ENEMY_Primal Proto-Drake|r.
.complete 70123,1 
.mob Primal Proto-Drake
step
#requires Professor Cogcatcher
#completewith WakingShoresExplorersInPerilAlliance
>>Kill |cRXP_ENEMY_Primal Proto-Whelps|r.
*Loot them for |T134309:0|t[|cRXP_LOOT_Proto-Whelp Scale|r].
.complete 70124,1 
step
#requires Professor Cogcatcher
.goto 2022,83.55,33.59
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Professor Cogcatcher|r.
.complete 70122,1 
.target Professor Cogcatcher
step
.goto 2022,83.01,36.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Archivist Rellid|r.
.complete 70122,2 
.target Archivist Rellid
step
.goto 2022,81.14,37.94
>>Enter the Cave
.accept 66074 >>Accept Primal Scythid Queen
step
.goto 2022,81.14,37.93
>>Kill |cRXP_ENEMY_Primal Scythid Queen|r
.complete 66074,1 
.turnin 66074 >>Turn in Primal Scythid Queen
.mob Primal Scythid Queen
step
#completewith next
#label Lockeye
.goto 2022,81.64,37.06,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spelunker Lockeye|r.
.complete 70122,3 
.target Spelunker Lockeye
step
#completewith Lockeye
.goto 2022,79.54,35.35,190 >>Leave the Cave
step
#requires Lockeye
#label WakingShoresExplorersInPerilAlliance
.goto 2022,79.54,35.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spelunker Lockeye|r.
.complete 70122,3 
.target Spelunker Lockeye
step
#hidewindow
#completewith Primal Proto-drakesA
#loop
.goto 2022,78.89,34.28,25,0
.goto 2022,79.51,33.5,25,0
.goto 2022,79.39,32.35,25,0
.goto 2022,80.04,31.97,25,0
.goto 2022,80.49,33.73,25,0
.goto 2022,80.53,34.86,25,0
.goto 2022,80.16,35.52,25,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Primal Proto-Drake|r.
.complete 70123,1 
step
>>Kill |cRXP_ENEMY_Primal Proto-Whelps|r.
*Loot them for |T134309:0|t[|cRXP_LOOT_Proto-Whelp Scale|r].
.complete 70124,1 
step
#label Primal Proto-drakesA
>>Kill |cRXP_ENEMY_Primal Proto-Drake|r.
.complete 70123,1 
step
.goto 2022,76.63,33.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toddy Whiskers|r.
.turnin 70122 >>Turn in Explorers in Peril
.accept 70125 >>Accept Where is Wrathion?
.target Toddy Whiskers
step
#completewith next
#label TalkToSendraxInquire
#hidewindow
.goto 2022,76.58,33.66,0,0
.complete 70125,1 
step
#completewith TalkToSendraxInquire
.goto 2022,76.58,33.66
.gossipoption 55636 >>Talk to |cRXP_FRIENDLY_Sendrax|r. 
.timer 22,Roleplay Duration
.target Sendrax
step
#requires TalkToSendraxInquire
.goto 2022,76.49,34.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaelin Darkanvil|r.
.turnin 70124 >>Turn in Practice Materials
.target Thaelin Darkanvil
step << Evoker
.goto 2022,76.41,34.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haephesta|r
.accept 70148 >>Accept Without Purpose
.target Haephesta
step << Evoker
.goto 2022,76.44,34.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kholmar Sunrunner|r.
.complete 70148,1 
.skipgossipid 56060
.skipgossipid 56061
.target Kholmar Sunrunner
step << Evoker
.goto 2022,76.69,34.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toninaar|r
.complete 70148,2 
.skipgossipid 56063
.skipgossipid 56064
.target Toninaar
step
.goto 2022,76.73,34.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Garrick|r.
.accept 67053 >>Accept Give Peace a Chance
.target Captain Garrick
step
.goto 2022,76.75,34.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scalecommander Azurathel|r.
.turnin 70123 >>Turn in Primal Pests
.target Scalecommander Azurathel
step
.goto 2022,76.36,33.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Breka Grimaxe|r.
.turnin 67053 >>Turn in Give Peace a Chance
.accept 70135 >>Accept Encroaching Elementals
.target Warlord Breka Grimaxe
step
.goto 2022,76.58,33.66
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 70125,1 
step
.goto 2022,76.58,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.turnin 70125 >>Turn in Where is Wrathion?
.target Sendrax
step
#label Accept Quest
.goto 2022,76.58,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.acceptmultiple 69911,72293 >>Accept Quest
.target Sendrax
step
.isOnQuest 72293
.goto 2022,76.52,34.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.turnin 72293 >>Turn in Adventuring in the Dragon Isles
.acceptmap 72266
.accept 72266 >>Accept The Waking Shores
.acceptmap 72267
.accept 72267 >>Accept Ohn'ahran Plains
.acceptmap 72268
.accept 72268 >>Accept Azure Span
.acceptmap 72269
.accept 72269 >>Accept Thaldraszus
step
.isOnQuest 72293
.goto 2022,76.58,33.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r
.turnin 72266 >>Turn in The Waking Shores
.target Sendrax
.accept 69911 >>Accept Excuse the Mess
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) The Waking Shores Midnight
#internal
step
#label WakingShoresStart
#optional
.convertquest 70135,66111 << Horde
step
.goto 2022,76.58,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.acceptmultiple 69911,72293 >>Accept Quest
.target Sendrax
step
.isOnQuest 72293
.goto 2022,76.52,34.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.turnin 72293 >>Turn in Adventuring in the Dragon Isles
.acceptmap 72266
.accept 72266 >>Accept The Waking Shores
.acceptmap 72267
.accept 72267 >>Accept Ohn'ahran Plains
.acceptmap 72268
.accept 72268 >>Accept Azure Span
.acceptmap 72269
.accept 72269 >>Accept Thaldraszus
step
.isOnQuest 72266
.goto 2022,76.58,33.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r
.turnin 72266 >>Turn in The Waking Shores
.target Sendrax
.accept 69911 >>Accept Excuse the Mess
step
.goto 2022,76.33,35.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Fastrasz|r.
.complete 69911,1 
.skipgossipid 55674
.target Ambassador Fastrasz
step
.goto 2022,76.28,35.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 69911,2 
.skipgossipid 55746
.skipgossipid 55758
.skipgossipid 55767
.skipgossipid 55781
step
.goto 2022,75.61,34.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 69911,3 
step
.goto 2022,78.43,31.80
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Brazier|r.
.complete 69911,4 
step
.goto 2022,76.58,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.turnin 69911 >>Turn in Excuse the Mess
.accept 69912 >>Accept My First Real Emergency!
.target Sendrax
step
#completewith next
#label Signal flare sent
#hidewindow
.complete 69912,1 
step
#completewith Signal flare sent
.goto 2022,76.58,33.67
.gossipoption 55637 >>Talk to |cRXP_FRIENDLY_Sendrax|r.
.timer 37,RP
.target Sendrax
step
#requires Signal flare sent
.goto 2022,75.84,33.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aster Cloudgaze|r.
.accept 66101 >>Accept From Such Great Heights
.target Aster Cloudgaze
step << Evoker
.goto 2022,75.84,33.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aster|r
.complete 70148,3 
.skipgossipid 56065
.skipgossipid 56066
.target Aster
step << Evoker
.goto 2022,75.05,33.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Note|r
.complete 70148,4 
step
.goto 2022,76.36,34.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grun Ashbeard|r.
.accept 66112 >>Accept Always Be Crafting
.target Grun Ashbeard
step
.goto 2022,76.41,34.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haephesta|r
.accept 69965 >>Accept Quality Assurance
.target Haephesta
step
.goto 2022,76.27,34.41
#title |cFFFCDC00Follow the Arrow|r
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 69912,1 
step
#completewith next
#label dragonsarrival1
#hidewindow
.complete 69912,2 
step
#completewith dragonsarrival1
#title |cFFFCDC00Read Text|r
.goto 2022,76.27,34.41,3 >>|cRXP_WARN_Only after he stops moving,|r go near |cRXP_FRIENDLY_Sendrax|r to trigger additional roleplay.
*|cRXP_WARN_If you do it before him the roleplay might not trigger|r.
.target Sendrax
.timer 60,RP
step << !Evoker
#requires dragonsarrival1
#completewith Volcanic Geodes1
>>Kill |cRXP_ENEMY_Lava Elementals|r.
*Ignore |cRXP_WARN_Earth Elementals|r.
.complete 70135,1 
.mob Primal Lava Elemental
step << Evoker
#requires dragonsarrival1
#completewith Volcanic Geodes2
>>Kill |cRXP_ENEMY_Lava Elementals|r.
*Ignore |cRXP_WARN_Earth Elementals|r.
.complete 70135,1 
.mob Primal Lava Elemental
step
#requires dragonsarrival1
#title Geodes Excavated 1
.goto 2022,74.57,33.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 69965,1,1 
step
#title Geodes Excavated 2
.goto 2022,73.93,33.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 69965,1,2 
step
#title Geodes Excavated 3
.goto 2022,73.56,32.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 69965,1,3 
step
>>Kill |cRXP_ENEMY_Baron Ashflow|r.
.goto 2022,72.91,32.97
*Loot them for |T451164:0|t[|cRXP_LOOT_Primal Molten Core|r].
.complete 66112,1 
.mob Baron Ashflow
step
#title Geodes Excavated 4
.goto 2022,72.88,33.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 69965,1,4 
step
#title Geodes Excavated 5
.goto 2022,72.94,34.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 69965,1,5 
step
#title Geodes Excavated 6
#label Volcanic Geodes1
.goto 2022,73.63,33.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r.
.complete 69965,1 
step << Evoker
#label Volcanic Geodes2
.goto 2022,74.93,35.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talon Ethrethi|r in the tent.
.complete 70148,5 
.skipgossipid 56027
.target Talon Ethrethi
step
#loop
.goto 2022,74.69,34.38,30,0
.goto 2022,74.19,35.54,30,0
.goto 2022,75.3,35.77,30,0
.goto 2022,73.33,33.5,30,0
>>Kill |cRXP_ENEMY_Lava Elementals|r.
*Ignore |cRXP_WARN_Earth Elementals|r.
.complete 70135,1 
.mob Encroaching Lava
.mob Primal Lava Elemental
step
.goto 2022,76.18,34.50
>>|cRXP_WARN_Wait for the Roleplay at the arrow's location|r.
.complete 69912,2 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 69912 >>Turn in My First Real Emergency!
.goto 2022,76.18,34.50
.target +Wrathion
.accept 69914 >>Accept The Djaradin Have Awoken
.goto 2022,76.23,34.54
.target +Majordomo Selistra
step
#completewith next
#label Majordomo Selistra1
#hidewindow
.complete 69914,1 
step
#completewith Majordomo Selistra1
.goto 2022,76.23,34.54
.gossipoption 55872 >>Talk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.timer 50,Roleplay Duration
.target Majordomo Selistra
step
#requires Majordomo Selistra1
.goto 2022,76.35,34.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grun Ashbeard|r.
.turnin 66112 >>Turn in Always Be Crafting
.target Grun Ashbeard
step
.goto 2022,76.41,34.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haephesta|r.
.turnin 69965 >>Turn in Quality Assurance
.turnin 70148 >>Turn in Without Purpose << Evoker
.target Haephesta
step << Horde
.goto 2022,76.73,34.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Garrick|r.
.turnin 66111 >>Turn in Encroaching Elementals
.target Captain Garrick
step << Alliance
.goto 2022,76.37,33.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Breka Grimaxe|r.
.turnin 70135 >>Turn in Encroaching Elementals
.target Warlord Breka Grimaxe
step
.goto 2022,75.9,33.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Surveyor's Disc|r.
.complete 66101,1 
step
>>Use |T4630464:0|t[Search for Power][1], |T3750314:0|t[Search for Allies][2] and |T2065621:0|t[Search for Danger][3].
*Afterwards press escape to cancel the cutscene.
.complete 66101,2 
.complete 66101,3 
.complete 66101,4 
step
#completewith next
#label Such Great Heights
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aster Cloudgaze|r.
.turnin 66101 >>Turn in From Such Great Heights
.target Aster Cloudgaze
step
#completewith Such Great Heights
.exitvehicle >>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Such Great Heights
.goto 2022,75.84,33.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aster Cloudgaze|r.
.turnin 66101 >>Turn in From Such Great Heights
.target Aster Cloudgaze
step
.goto 2022,76.27,34.42
>>|cRXP_WARN_Wait for the Roleplay at the arrow's location|r.
.complete 69914,1 
step
.goto 2022,76.27,34.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r
.turnin 69914 >>Turn in The Djaradin Have Awoken
.accept 65760 >>Accept Reporting for Duty
.target Sendrax
step << Evoker
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talon Ethrethi|r.
.goto 2022,74.93,34.98
.complete 70148,5 
.target Talon Ethrethi
step << Evoker
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talon Ethrethi|r.
.goto 2022,74.93,34.98
.complete 70148,5 
.target Talon Ethrethi
step
.goto 2022,71.21,40.77
#title |cFFFCDC00Follow the Arrow|r
.complete 65760,1 
.target Sendrax
step
.goto 2022,71.21,40.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Lethanak|r.
.turnin 65760 >>Turn in Reporting for Duty
.accept 65990 >>Accept Deliver Whelps From Evil
.accept 65989 >>Accept Invader Djaradin
.target Commander Lethanak
step
#completewith DfChests
+|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Chests|r |cRXP_WARN_(they spawn randomly in DF zones and grant decent XP)|r.
step
#completewith WhimperingWhelplingsSaved
>>Kill |cRXP_ENEMY_Qalashi Scavengers|r.
.complete 65989,1 
.mob Qalashi Scavenger
.mob Qalashi Djaradin
step
.goto 2022,71.36,44.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Whimpering Whelpling|r behind the tent.
.complete 65990,1,1 
.target Whimpering Whelping
step
.goto 2022,71.33,46.25,10,0
.goto 2022,70.97,46.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Whimpering Whelpling|r in the tower.
.complete 65990,1,2 
.target Whimpering Whelpling
step
.goto 2022,69.86,45.3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Whimpering Whelpling|r behind the tent.
.complete 65990,1,3 
.target Whimpering Whelpling
step
#label WhimperingWhelplingsSaved
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Whimpering Whelpling|r.
.goto 2022,69.38,43.26
.complete 65990,1 
.target Whimpering Whelpling
step
#loop
.goto 2022,70.61,43.86,25,0
.goto 2022,70.95,46.06,25,0
.goto 2022,70,45.58,25,0
>>Kill |cRXP_ENEMY_Qalashi Scavengers|r.
.complete 65989,1 
.mob Qalashi Scavenger
.mob Qalashi Djaradin
step
.goto 2022,71.20,40.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Lethanak|r.
.turnin 65989 >>Turn in Invader Djaradin
.turnin 65990 >>Turn in Deliver Whelps From Evil
.accept 65991 >>Accept Time for a Reckoning
.target Commander Lethanak
step
.goto 2022,66.59,34.58
>>Fly ontop of the Tower
.complete 65991,1 
.timer 11.7,RP
step
.goto 2022,66.65,36.86
>>Kill |cRXP_ENEMY_Qalashis|r.
.accept 65994 >>Accept Djaradin Djustice (Bonus Objective)
.complete 65994,1,15 
.mob Qalashi Scoundrel
.mob Qalashi Ragetamer
.mob Qalashi Skirmisher
.mob Qalashi Flameshatter
.mob Qalashi Flamemuzzler
step
.goto 2022,66.36,35.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.turnin 65991 >>Turn in Time for a Reckoning
.accept 65993 >>Accept Killjoy
.accept 65992 >>Accept Blacktalon Intel
.target Wrathion
step
#completewith Djaradin Djustice
>>Kill |cRXP_ENEMY_Qalashis|r.
.accept 65994 >>Accept Djaradin Djustice (Bonus Objective)
.complete 65994,1,100 
.mob Qalashi Scoundrel
.mob Qalashi Ragetamer
.mob Qalashi Skirmisher
.mob Qalashi Flameshatter
.mob Qalashi Flamemuzzler
step
.goto 2022,65.09,29.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Right|r.
.complete 65992,3 
.skipgossipid 55298
.target Right
step
#label DfChests
.goto 2022,63.43,28.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Left|r.
.complete 65992,2 
.target Left
.skipgossipid 55297
step
.goto 2022,62.96,29.43
>>Kill |cRXP_ENEMY_Meatgrinder Sotok|r.
*Loot him for the |T237451:0|t[|cRXP_LOOT_Qalashi Plans|r].
.complete 65993,1 
.collect 193874,1,65995,1
.accept 65995 >>Accept The Obsidian Citadel
.mob Meatgrinder Sotok
step
.goto 2022,64.16,32.99
>>Kill |cRXP_ENEMY_Dragonhunter Igordan|r
.complete 66956,1 
.accept 66956 >>Accept Dragonhunter Igordan
.turnin 66956 >>Turn in Dragonhunter Igordan
.mob Dragonhunter Igordan
step
.goto 2022,63.03,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talonstalker Kavia|r.
.complete 65992,1 
.skipgossipid 55335
.target Talonstalker Kavia
step
.goto 2022,62.65,33.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r on the tower.
.turnin 65993 >>Turn in Killjoy
.turnin 65992 >>Turn in Blacktalon Intel
.turnin 65995 >>Turn in The Obsidian Citadel
.target Wrathion
step
#label Djaradin Djustice
.goto 2022,62.76,33.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.accept 65996 >>Accept Veteran Reinforcements
step
#loop
.goto 2022,64.13,33.02,30,0
.goto 2022,62.68,35.28,30,0
.goto 2022,61.64,35.71,30,0
.goto 2022,61.51,34.48,30,0
>>Kill |cRXP_ENEMY_Qalashis|r.
.accept 65994 >>Accept Djaradin Djustice (Bonus Objective)
.complete 65994,1,100 
.mob Qalashi Scoundrel
.mob Qalashi Ragetamer
.mob Qalashi Skirmisher
.mob Qalashi Flameshatter
.mob Qalashi Flamemuzzler
step
.goto 2022,60.99,35.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Drakonid|r or heal them.
.complete 65996,1,1 
.use 193917
.target Injured Drakonid
step
.goto 2022,61.11,36.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Drakonid|r or heal them.
.complete 65996,1,2 
.use 193917
.target Injured Drakonid
step
.goto 2022,59.04,34.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Drakonid|r or heal them.
.complete 65996,1,3 
.use 193917
.target Injured Drakonid
step
.goto 2022,59.11,34.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caretaker Ventraz|r.
.accept 66998 >>Accept Fighting Fire with... Water
.target Caretaker Ventraz
step
#loop
.goto 2022,59.03,33.74,20,0
.goto 2022,59.16,32.95,20,0
.goto 2022,58.94,32.37,20,0
.goto 2022,59.58,32.99,20,0
.goto 2022,59.49,33.88,20,0
.goto 2022,59.04,34.47,20,0
>>Kill |cRXP_ENEMY_Lava Elementals|r.
.complete 66998,1 
.use 194441
.mob Erupting Droplet
.mob Erupting Lasher
step
.goto 2022,59.10,34.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caretaker Ventraz|r.
.turnin 66998 >>Turn in Fighting Fire with... Water
.target Caretaker Ventraz
step
.goto 2022,54.97,30.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Drakonid|r or heal them.
.complete 65996,1,4 
.complete 65996,2 
.use 193917
.target Injured Drakonid
step
.goto 2022,54.99,30.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caretaker Azkra|r.
.turnin 65996 >>Turn in Veteran Reinforcements
.accept 65997 >>Accept Chasing Sendrax
.target Caretaker Azkra
step
.goto 2022,55.18,24.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.complete 65997,1 
.target Sendrax
.skipgossipid 55225
step
.goto 2022,55.18,24.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.turnin 65997 >>Turn in Chasing Sendrax
.accept 65998 >>Accept Future of the Flights
.accept 65999 >>Accept Red in Tooth and Claw
.target Sendrax
step
.goto 2022,55.26,24.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.accept 66000 >>Accept Library of Alexstrasza
step
#completewith Primalists1
>>Kill |cRXP_ENEMY_Primalists|r
.complete 65999,1 
.mob Primal Revenant
.mob Tarasek Elementalist
.mob Molten Elementalist
.mob Unleashed Lavaburst
.mob Swelling Fire Elemental
step
.goto 2022,53.36,22.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r inside the building.
.complete 66000,1,1 
step
.goto 2022,53.47,21.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r inside the building.
.complete 66000,1,2 
step
.goto 2022,54.15,21.99
#title |cFFFCDC00Follow the Arrow|r
.complete 65998,1 
step
>>Kill |cRXP_ENEMY_Infused Ruby Whelplings|r.
.complete 65998,2,3 
.mob Infused Ruby Whelpling
step
.goto 2022,54.44,21.34
>>Kill |cRXP_ENEMY_Firava the Rekindler|r
*|cRXP_WARN_Beaware of his Knockback|r.
.complete 70648,1 
.mob Firava the Rekindler
step
.goto 2022,54.67,20.97,10,0
.goto 2022,54.61,20.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r |cRXP_WARN_inside the tower on the second floor|r.
.complete 66000,1,3 
step
.goto 2022,54.81,20.37,5,0
.goto 2022,54.62,20.36
#label Primalists1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r |cRXP_WARN_inside the tower on the first floor|r.
.complete 66000,1,4 
step
#completewith Red in Tooth and Claw
+Don't turn in the quests yet.
step
#completewith next
#label Infused Ruby Whelpling
.goto 2022,54.99,21.05,10,0
>>Kill |cRXP_ENEMY_Primalists|r and |cRXP_ENEMY_Infused Ruby Whelplings|r.
.complete 65998,2 
.complete 65999,1 
.mob Infused Ruby Whelpling
.mob Primal Revenant
.mob Tarasek Elementalist
.mob Molten Elementalist
.mob Unleashed Lavaburst
.mob Swelling Fire Elemental
step
#completewith Infused Ruby Whelpling
.goto 2022,54.9,21.36,10 >>Leave the House
step
#requires Infused Ruby Whelpling
#loop
.goto 2022,54.9,21.36,20,0
.goto 2022,55.98,21.6,20,0
.goto 2022,56.27,22.1,20,0
.goto 2022,55.2,22.71,20,0
>>Kill |cRXP_ENEMY_Primalists|r and |cRXP_ENEMY_Infused Ruby Whelplings|r.
.complete 65998,2 
.complete 65999,1 
.mob Infused Ruby Whelpling
.mob Primal Revenant
.mob Tarasek Elementalist
.mob Molten Elementalist
.mob Unleashed Lavaburst
.mob Swelling Fire Elemental
step
#completewith next
#label Red in Tooth and Claw
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r on the waypoint location.
.turnin 65998 >>Turn in Future of the Flights
.turnin 65999 >>Turn in Red in Tooth and Claw
.turnin 66000 >>Turn in Library of Alexstrasza
.accept 66001 >>Accept A Last Hope
.disablecheckbox
step
#completewith Red in Tooth and Claw
.goto 2022,56.24,22.14 >>Turn in the quest at the waypoint location to skip |cRXP_FRIENDLY_Sendrax|r travel time.
step
#requires Red in Tooth and Claw
.goto 2022,56.24,22.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r on the waypoint location.
.turnin 65998 >>Turn in Future of the Flights
.turnin 65999 >>Turn in Red in Tooth and Claw
.turnin 66000 >>Turn in Library of Alexstrasza
.accept 66001 >>Accept A Last Hope
step
.goto 2022,56.24,22.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sendrax|r.
.complete 66001,1 
.skipgossipid 55259
.timer 20,Roleplay Duration
step
.goto 2022,56.92,21.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Egg|r
.complete 66001,2 
step
.goto 2022,54.99,30.77
>>Mount up and fly to the waypoint location.
.complete 66001,3 
.timer 17,Roleplay Duration
step
.goto 2022,55.10,31.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 66001 >>Turn in A Last Hope
.accept 66114 >>Accept For the Benefit of the Queen
.target Majordomo Selistra
step
#completewith next
#label Ride with Majordomo Selistra
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66114,1 
step
#completewith Ride with Majordomo Selistra
.goto 2022,55.10,31.03
.gossipoption 54941 >>Talk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.timer 67,Ride to the Ruby Lifeshrine
step
#requires Ride with Majordomo Selistra
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66114,1 
.skipgossipid 54941
step
.goto 2022,62.34,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.complete 66114,2 
.skipgossipid 107094
.target Alexstraza the Life-Binder
step
.goto 2022,62.34,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 66114 >>Turn in For the Benefit of the Queen
.accept 66115 >>Accept The Mandate of the Red
.accept 68795 >>Accept Dragonriding
.target Alexstraza the Life-Binder
step
.goto 2022,60.70,74.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xius|r.
.complete 66115,1 
.skipgossipid 55288
.target Xius
step
.goto 2022,59.36,72.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akxall|r.
.complete 66115,2 
.skipgossipid 55289
.target Akxali
step
.goto 2022,57.93,68.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haephesta|r.
.accept 67564 >>Accept Artisan's Courier
.target Haephesta
step
.goto 2022,58.37,67.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Andestrasz|r.
.complete 68795,1 
.skipgossipid 55643
.timer 26,Roleplay Duration
.target Lord Andestrasz
step
.goto 2022,61.6,68.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mother Elion|r.
.complete 66115,3 
.skipgossipid 55258
.target Mother Elion
step
.goto 2022,62.78,70.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zahkrana|r.
.complete 66115,4 
.skipgossipid 55290
.turnin 66115 >>Turn in The Mandate of the Red
.target Zahkrana
step
.goto 2022,62.18,70.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amella|r.
.accept 70061 >>Accept Training Wings
.target Amella
step
.goto 2022,60.23,72.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thomas Bright|r.
.turnin 67564 >>Turn in Artisan's Courier
.accept 67100 >>Accept A Gift for Miguel
.target Thomas Bright
step
.goto 2022,60.23,72.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thomas Bright|r.
.complete 67100,1 
.target Thomas Bright
.skipgossipid 55060
.skipgossipid 55065
.skipgossipid 55066
step
.goto 2022,57.66,66.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Andestrasz|r.
.turnin 68795 >>Turn in Dragonriding
.accept 65118 >>Accept How to Glide with Your Dragon
.target Lord Andestrasz
step
.goto 2022,57.64,64.94,10,0
.goto 2022,57.6,64,10,0
.goto 2022,57.55,62.84,10,0
.goto 2022,57.5,61.76,10,0
.goto 2022,57.45,60.45,10,0
.goto 2022,57.48,59.10
>>Fly through the rings.
.complete 65118,2 
.complete 65118,3 
step
.goto 2022,57.48,59.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celormu|r.
.turnin 65118 >>Turn in How To Glide with Your Dragon
.target Celormu
step
.goto 2022,57.66,66.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celormu|r.
.accept 65120 >>Accept How to Dive with Your Dragon
.target Celormu
step
.goto 2022,57.68,66.33,10,0
.goto 2022,57.67,65.68,10,0
.goto 2022,57.61,64.16,10,0
.goto 2022,57.56,62.17,10,0
.goto 2022,57.47,59.11
>>Fly through the rings.
.complete 65120,2 
.complete 65120,3 
step
.goto 2022,57.47,59.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celormu|r
.turnin 65120 >>Turn in How to Dive with Your Dragon
.target Celormu
step
.goto 2022,57.66,66.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Andestrasz|r.
.accept 65133 >>Accept How to Use Momentum with Your Dragon
.target Lord Andestrasz
step
.goto 2022,57.68,66.33,10,0
.goto 2022,57.68,66.05,10,0
.goto 2022,57.64,65.31,10,0
.goto 2022,57.54,62.99,10,0
.goto 2022,57.47,60.52,10,0
.goto 2022,57.48,59.09
>>Fly through the rings.
.complete 65133,2 
.complete 65133,3 
step
.goto 2022,57.48,59.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celormu|r.
.turnin 65133 >>Turn in How to Use Momentum with Your Dragon
.target Celormu
step
.goto 2022,57.66,66.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Andestrasz|r.
.accept 77345 >>Accept The Need For Higher Velocities
.target Lord Andestrasz
step
.goto 2022,57.77,63.49,10,0
.goto 2022,57.65,60.28,10,0
.goto 2022,56.1,56.68,10,0
.goto 2022,53.22,56.9,10,0
.goto 2022,51.71,60.36,10,0
.goto 2022,52.42,63.94,10,0
.goto 2022,54.72,64.95,10,0
.goto 2022,56.74,63.02,10,0
.goto 2022,57.47,59.10
>>Fly through the rings.
.complete 77345,2 
.complete 77345,3 
step
.goto 2022,57.47,59.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celormu|r.
.turnin 77345 >>Turn in The Need For Higher Velocities
.target Celormu
step
.goto 2022,57.66,66.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Andestrasz|r.
.accept 68796 >>Accept The Skytop Observatory
.timer 10,RP
.target Lord Andestrasz
step
.goto 2022,57.85,66.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veritistrasz|r.
.accept 70132 >>Accept Stay a While
.target Veritistrasz
step
#completewith next
#label Sit and look
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veritistrasz|r.
.complete 70132,1 
.target Veritistrasz
step
#completewith Sit and look
.goto 2022,57.85,66.80
.cast 404338 >>Use the [ExtraActionButton]
step
#requires Sit and look
.goto 2022,57.85,66.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veritistrasz|r |cRXP_WARN_again|r.
.complete 70132,1 
.skipgossipid 63862
.target Veritistrasz
step
.goto 2022,57.85,66.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veritistrasz|r.
.turnin 70132 >>Turn in Stay a While
.target Veritistrasz
step
.goto 2022,57.72,66.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celormu|r.
.complete 68796,1 
.skipgossipid 107284
.timer 11,Roleplay Duration
.target Celormu
step
.goto 2022,57.91,66.61,10,0
.goto 2022,57.87,66.65,10,0
.goto 2022,59.11,65.45,10,0
.goto 2022,61.59,63.09,10,0
.goto 2022,63.59,61.17,10,0
.goto 2022,65.65,59.53,10,0
.goto 2022,68.15,58.05,10,0
.goto 2022,72.96,55.65,10,0
.goto 2022,75.18,54.97
>>Fly through every ring.
.complete 68796,2 
step
.goto 2022,75.18,54.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Andestrasz|r.
.turnin 68796 >>Turn in The Skytop Observatory
.accept 68797 >>Accept A New Set of Horns
.accept 68798 >>Accept Skyriding Talents and You
.target Lord Andestrasz
step
.goto 2022,74.57,56.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lithragosa|r
.complete 68798,1 
.complete 68798,2 
.skipgossipid 55584
.target Lithragosa
step
.goto 2022,74.11,57.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Glensera|r.
.complete 68797,1 
.target Glensera
step
.goto 2022,74.11,57.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rostrum of Transformation|r |cRXP_WARN_(the pentagon on the ground)|r and cancel it.
*|cRXP_WARN_You might have to manually skip this step afterwards|r.
.complete 68797,2 
step
.goto 2022,73.25,52.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celormu|r.
.complete 68798,3 
.target Celormu
step
.goto 2022,75.17,54.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Andestrasz|r.
.turnin 68797 >>Turn in A New Set of Horns
.turnin 68798 >>Turn in Skyriding Talents and You
.accept 68799 >>Accept Return to the Ruby Lifeshrine
.target Lord Andestrasz
step
.goto 2022,75.03,55.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Relastrasza|r.
.complete 68799,1 
.timer 22,RP
.target Relastrasza
step
#include RestedXP Speed Leveling\a) Beyond the Barrier Midnight@BeyondBarrierStart1-BeyondBarrierEnd1
step
.goto 2022,70.49,56.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zikkori|r.
.accept 70994 >>Accept Drainage Solutions
.target Zikkori
step
#completewith next
>>Use |T3610505:0|t[Zikkori's Water Siphoning Device] around |cRXP_FRIENDLY_Glittery Streams|r.
.complete 70994,1 
.use 200747
step
.goto 2022,72.17,56.71
>>Kill |cRXP_ENEMY_Acequian|r inside the Cave.
*Loot them for |T1020349:0|t[|cRXP_LOOT_Orb of Primal Waves|r].
.complete 66441,1 
.mob Acequian
step
#loop
.goto 2022,72.18,57.3,20,0
.goto 2022,72.15,56.25,20,0
.goto 2022,71.74,56.71,20,0
.goto 2022,72.65,57.05,20,0
>>Use |T3610505:0|t[Zikkori's Water Siphoning Device] around |cRXP_FRIENDLY_Glittery Streams|r.
.complete 70994,1 
.use 200747
step
.goto 2022,70.50,56.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zikkori|r.
.turnin 70994 >>Turn in Drainage Solutions
.target Zikkori
step
#loop
.goto 2022,68.40,63.15,30,0
.goto 2022,68.26,64.59,30,0
.goto 2022,69.35,64.39,30,0
.goto 2022,69.84,65.71,30,0
>>Kill |cRXP_ENEMY_Primalist Forces|r.
*Loot them for |T1445240:0|t[|cRXP_LOOT_Fiery Spirits|r] and |T135821:0|t[|cRXP_LOOT_Primal Flame Fragment|r].
.complete 67100,2 
.complete 66439,1 
.mob Primalist Magmashaper
.mob Destructive Flames
.mob Ashen Spark
step
#include RestedXP Speed Leveling\a) Beyond the Barrier Midnight@BeyondBarrierStart2-BeyondBarrierEnd2
step
#completewith next
#label Ruby Whelpling
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ruby Whelpling|r.
.complete 70061,1 
.target Ruby Whelpling
step
#completewith Ruby Whelpling
.goto 2022,58.54,53.03
.turnin 65646 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r for a 34 slot Bag.
*|cRXP_WARN_It's inside the upper part of the middle waterfall|r.
step
#requires Ruby Whelpling
.goto 2022,61.09,71.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ruby Whelpling|r.
.complete 70061,1 
.use 202194
.target Ruby Whelpling
step
>>Spam |T135808:0|t[Burning Bark] (1) to kill |cRXP_ENEMY_Pests|r |cRXP_WARN_(Aimed forward)|r.
*Use |T2103883:0|t[Speed of Flight] (2) for flightspeed.
.complete 70061,4 
.complete 70061,3 
.complete 70061,2 
step
#completewith next
#label Return to the Ruby Lifeshrine
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 70061 >>Turn in Training Wings
.target +Majordomo Selistra
step
#completewith Return to the Ruby Lifeshrine
.exitvehicle >>|cRXP_WARN_Exit the vehicle|r
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Return to the Ruby Lifeshrine
.goto 2022,62.32,72.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 70061 >>Turn in Training Wings
.target Majordomo Selistra
step
.goto 2022,62.34,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 68799 >>Turn in Return to the Ruby Lifeshrine
.accept 66931 >>Accept Who Brought the Ruckus?
.target Alexstrasza the Life-Binder
step
.goto 2022,60.22,72.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thomas Bright|r.
.turnin 67100 >>Turn in A Gift for Miguel
.target Thomas Bright
step
.goto 2022,59.46,72.72
#title |cFFFCDC00Follow the Arrow|r
.complete 66931,1 
step
.goto 2022,59.49,72.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 66931 >>Turn in Who Brought the Ruckus?
.accept 66116 >>Accept The Primary Threat
.target Majordomo Selistra
step
.goto 2022,59.41,75.88
#title |cFFFCDC00Follow the Arrow|r
.complete 66116,2 
.target Commander Lethanak
step
.goto 2022,59.41,75.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Lethanak|r.
.turnin 66116 >>Turn in The Primary Threat
.accept 66118 >>Accept Basalt Assault
.accept 66117 >>Accept Clear the Battlefield (Bonus Objective)
.target Commander Lethanak
step
#completewith WakingShoreCutOfftheHead
>>Kill |cRXP_ENEMY_Primalists|r
.complete 66117,1 
.mob Primal Avalanche
.mob Galestrike Primalist
.mob Water Primalist
.mob Frozen Revenant
.mob Rockslide Rider
step
#loop
.goto 2022,59.29,78.49,15,0
.goto 2022,59.88,78.7,15,0
.goto 2022,61.11,79.19,15,0
.goto 2022,61.55,78.98,15,0
.goto 2022,60.91,77.53,15,0
>>Kill |cRXP_ENEMY_Enraged Cliffs|r.
.complete 66118,1 
.mob Enraged Cliff
step
.goto 2022,60.64,83.01
>>Kill |cRXP_ENEMY_Terillod|r.
*|cRXP_WARN_Beaware of his knockback|r.
.accept 70751 >>Accept Terillod the Devout (Elite Objective)
.complete 70751,1 
.mob Terillod the Devout
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Lethanak|r and |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 66118 >>Turn in Basalt Assault
.accept 66122 >>Accept Proto-Fight
.target +Commander Lethanak
.goto 2022,59.41,75.88
.accept 66121 >>Accept Egg Evac
.goto 2022,59.49,76.16
.target +Majordomo Selistra
step
#completewith WakingShoreEggEvac
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Proto-Dragons|r to pull them towards you and weaken them.
*Kill |cRXP_ENEMY_Proto-Dragons|r
.complete 66122,2 
.use 192436
.mob Galestrike Proto-Dragon
.mob Rumbling Proto-Dragon
step
.goto 2022,56.13,81.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bronze Egg|r.
.complete 66121,1 
step
.goto 2022,57.35,83.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Azure Egg|r.
.complete 66121,2 
step
.goto 2022,55.32,83.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Emerald Egg|r.
.complete 66121,3 
step
.goto 2022,54.77,82.22
>>Kill |cRXP_ENEMY_Klozicc the Ascended|r.
.accept 66960 >>Accept Klozicc the Ascended (Elite Objective)
.complete 66960,1 
.mob Klozicc the Ascended
step
#label WakingShoreEggEvac
.goto 2022,54.99,80.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ruby Egg|r.
.complete 66121,4 
step
#loop
.goto 2022,56.62,80.90,40,0
.goto 2022,55.51,83.37,40,0
.goto 2022,54.55,79.83,40,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Proto-Dragons|r to pull them towards you and weaken them.
*Kill |cRXP_ENEMY_Proto-Dragons|r
.complete 66122,2 
.use 192436
.mob Galestrike Proto-Dragon
step
.goto 2022,53.68,80.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 66122 >>Turn in Proto-Fight
.turnin 66121 >>Turn in Egg Evac
.accept 66123 >>Accept Cut Off the Head
.target Majordomo Selistra
step
.goto 2022,53.68,83.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Jadzigeth|r to weaken him.
*Kill |cRXP_ENEMY_Jadzigeth|r
.complete 66123,1 
.use 192436
.mob Jadzigeth
step
#label WakingShoreCutOfftheHead
.goto 2022,53.67,80.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.turnin 66123 >>Turn in Cut Off the Head
.accept 66124 >>Accept Exeunt, Triumphant
.target Majordomo Selistra
step
#loop
.goto 2022,55.05,80.79,30,0
.goto 2022,56.34,81.15,30,0
.goto 2022,55.33,83.13,30,0
.goto 2022,57.26,83.14,30,0
>>Kill |cRXP_ENEMY_Primalists|r
.complete 66117,1 
.mob Primal Avalanche
.mob Galestrike Primalist
.mob Water Primalist
.mob Frozen Revenant
.mob Rockslide Rider
step
#include RestedXP Speed Leveling\a) Professional Protographer Midnight@OutForDeliveryAccept-OutForDeliveryAccept
step
.goto 2022,46.14,78.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r.
.complete 66124,1 
.skipgossipid 107159
.target Majordomo Selistra
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Majordomo Selistra|r and |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 66124 >>Turn in Exeunt, Triumphant
.goto 2022,46.14,78.51
.target +Majordomo Selistra
.accept 66079 >>Accept Wrathion Awaits
.goto 2022,46.09,78.29
.target +Alexstrasza the Life-Binder
step
#completewith ProfessionalProtographerEnd1
>>Kill |cRXP_ENEMY_Dragons|r
.complete 70196,1
step
#include RestedXP Speed Leveling\a) Professional Protographer Midnight@OutForDeliveryTurnin-OutForDeliveryTurnin
step
#include RestedXP Speed Leveling\a) Professional Protographer Midnight@ProfessionalProtographerStart1-ProfessionalProtographerEnd1
step
#loop
.goto 2022,41,82.67,40,0
.goto 2022,43.05,82.54,40,0
.goto 2022,43.8,79.06,40,0
.goto 2022,43.69,76.67,40,0
>>Kill |cRXP_ENEMY_Dragons|r
.complete 70196,1
step
#completewith next
#label Wrathion Awaits
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Scalecommander Emberthal|r.
.turnin 66079 >>Turn in Wrathion Awaits
.target +Wrathion
.accept 72241 >>Accept Lessons from Our Past
.disablecheckbox
.target +Scalecommander Emberthal
step
#completewith Wrathion Awaits
.goto 2022,42.47,66.84,10 >>Trigger the RP.
.timer 15,RP
step
#requires Wrathion Awaits
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Scalecommander Emberthal|r.
.turnin 66079 >>Turn in Wrathion Awaits
.goto 2022,42.47,66.84
.target +Wrathion
.accept 72241 >>Accept Lessons from Our Past
.goto 2022,42.47,66.78
.target +Scalecommander Emberthal
step
.goto 2022,42.47,66.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Scalecommander|r.
.complete 72241,1 
.skipgossipid 107399
.target Scalecommander Emberthal
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scalecommander Emberthal|r and |cRXP_FRIENDLY_Wrathion|r.
.turnin 72241 >>Turn in Lessons from Our Past
.accept 66048 >>Accept Best Plans and Intentions
.goto 2022,42.47,66.78
.target +Scaleecommander Emberthal
.accept 66078 >>Accept Sharp Practice
.goto 2022,42.47,66.84
.target Wrathion
step
#completewith next
#label Fao the Relentless
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Battle Plans|r.
.complete 66048,1 
.target Fao the Relentless
step
#completewith Fao the Relentless
.goto 2022,42.41,66.18
.gossipoption 55311 >>Talk to |cRXP_FRIENDLY_Fao the Relentless|r.
.target Fao the Relentless
step
#requires Fao the Relentless
.goto 2022,42.41,66.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Battle Plans|r.
.complete 66048,1 
.target Fao the Relentless
.skipgossipid 55311
step
#title |cFFFCDC00NPC Patrols|r
.goto 2022,42.82,66.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forgemaster Bazentus|r.
.complete 66048,4 
.target Forgemaster Bazentus
.skipgossipid 55309
.skipgossipid 55310
step
#completewith next
#label ArchivistEdresConsulted
#hidewindow
.complete 66048,2 
step
#completewith ArchivistEdresConsulted
.goto 2022,43.76,67.28
.gossipoption 55307 >>Talk to |cRXP_FRIENDLY_Archivist Edress|r.
.timer 34,RP
.target Archivist Edress
step
#requires ArchivistEdresConsulted
#completewith next
#label Scouting Scope
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Scope|r.
.complete 66048,3 
step
#requires ArchivistEdresConsulted
#completewith Scouting Scope
.goto 2022,42.3,69.3
.gossipoption 54996 >>Talk to |cRXP_FRIENDLY_Talonstalker Kavia|r
.target Talonstalker Kavia
step
#requires Scouting Scope
.goto 2022,42.30,69.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Scope|r.
.complete 66048,3 
step
#loop
.goto 2022,42.56,69.17,10,0
.goto 2022,42.45,68.29,25,0
.goto 2022,42.52,67.46,25,0
.goto 2022,42.75,67.64,25,0
.goto 2022,42.94,67.07,25,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blacktalons|r and defeat them.
*|cRXP_WARN_You can aggro multiple at once|r.
.complete 66078,1 
.skipgossipid 54628
.target Blacktalon Assassin
.target Blacktalon Avenger
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fao the Relentless|r, |cRXP_FRIENDLY_Forgemaster Bazentus|r, |cRXP_FRIENDLY_Archivist Edress|r, and |cRXP_FRIENDLY_Talonstalker Kavia|r at the waypoint locations.
.complete 66048,1 
.goto 2022,42.41,66.06
.target +Fao the Relentless
.complete 66048,4 
.goto 2022,42.82,66.86
.target +Forgemaster Bazentus
.complete 66048,2 
.goto 2022,43.76,67.28
.target +Archivist Edress
.complete 66048,3 
.goto 2022,42.23,69.33
.target +Talonstalker Kavia
.skipgossipid 55307
.skipgossipid 55311
.skipgossipid 55309
.skipgossipid 55310
.skipgossipid 54996
step
.goto 2022,42.47,66.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.turnin 66048 >>Turn in Best Plans and Intentions
.turnin 66078 >>Turn in Sharp Practice
.timer 21,Roleplay Duration
.target Wrathion
step
.goto 2022,42.47,66.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.accept 65957 >>Accept No Time For Heroes
.accept 65956 >>Accept Talon Strike
step
.goto 2022,37.45,71.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthcaller Yevaa|r.
.accept 66003 >>Accept Rings To Bind Them
.target Earthcaller Yevaa
step
#loop
.goto 2022,37.99,71.58,28,0
.goto 2022,38.15,73.04,28,0
.goto 2022,37.12,71.84,28,0
.goto 2022,38.05,69.42,28,0
>>Kill |cRXP_ENEMY_Blazing Manifestations|r.
*Loot them for |T514950:0|t[|cRXP_LOOT_Molten Binding Rings|r].
.complete 66003,1 
.mob Blazing Manifestation
step
.goto 2022,37.46,71.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthcaller Yevaa|r.
.turnin 66003 >>Turn in Rings To Bind Them
.target Earthcaller Yevaa
step
.goto 2022,37.46,71.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthcaller Yevaa|r.
.accept 66369 >>Accept The Earthen Ward
.target Earthcaller Yevaa
step
.goto 2022,37.54,71.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Earthen Ward|r.
.complete 66369,1 
step
.goto 2022,37.45,71.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthcaller Yevaa|r.
.turnin 66369 >>Turn in The Earthen Ward
.target Earthcaller Yevaa
step
.goto 2022,37.45,71.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthcaller Yevaa|r.
.accept 66368 >>Accept Island In A Storm
.target Earthcaller Yevaa
step
#completewith next
>>Kill |cRXP_ENEMY_Blazing Manifestations|r.
.complete 66368,1 
.mob Blazing Manifestations
step
.goto 2022,37.62,75.10
>>Kill |cRXP_ENEMY_Melter Igneous|r.
.complete 66368,2 
.mob Melter Igneous
step
#loop
.goto 2022,37.98,76.02,25,0
.goto 2022,39.58,74.41,25,0
.goto 2022,39.14,73.14,25,0
.goto 2022,38.01,71.79,25,0
.goto 2022,36.55,71.79,25,0
.goto 2022,36.95,73.62,25,0
>>Kill |cRXP_ENEMY_Blazing Manifestations|r.
.complete 66368,1 
step
.goto 2022,37.46,71.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthcaller Yevaa|r.
.turnin -66368 >>Turn in Island In A Storm
.target Earthcaller Yevaa
step
#completewith WakingShoreNoTimeForHeroes
#title |cFFFCDC00Ignore Elites|r
*Kill |cRXP_ENEMY_non-elites|r.
*Use the |cRXP_WARN_[ExtraActionButton|r for extra damage.
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Objects|r
.complete 65956,1 
.mob Qalashi Necksnapper
.mob Qalashi Crustshaper
.mob Qalashi Steelcrafter
.mob Qalashi Boltthrower
.mob Qalashi Skullhauler
step
.goto 2022,35.53,68.47
>>Kill |cRXP_ENEMY_Piercer Gigra|r.
.complete 65957,1 
.mob Piercer Gigra
step
.goto 2022,34.79,66.86
>>Kill |cRXP_ENEMY_Olphis the Molten|r.
.complete 65957,3 
.mob Olphis the Molten
step
#label WakingShoreNoTimeForHeroes
.goto 2022,35.67,60.73
>>Kill |cRXP_ENEMY_Modak Flamespit|r.
.complete 65957,2 
.mob Modak Flamespit
step
.goto 2022,37.11,55.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthmender Govrum|r.
.accept 70414 >>Accept Shaky Grounds
.target Earthmender Govrum
step
.goto 2022,36.61,55.90
>>Use the |T136108:0|t[Shattering Totem] on the |cRXP_PICK_Trapped Cavestones|r in the lava.
.complete 70414,1 
.target Trapped Cavestone
.use 198980
step
.goto 2022,37.11,55.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthmender Govrum|r.
.turnin 70414 >>Turn in Shaky Grounds
.target Earthmender Govrum
step
#include RestedXP Speed Leveling\a) The Shadow of His Wings Midnight
step
#loop
.goto 2022,36.44,59.46,25,0
.goto 2022,37.2,60.74,25,0
.goto 2022,37.7,62.79,25,0
.goto 2022,37.71,64.51,25,0
.goto 2022,35.9,62.05,25,0
.goto 2022,34.01,62.25,25,0
#title |cFFFCDC00Ignore Elites|r
*Kill |cRXP_ENEMY_non-elites|r.
*Use the |cRXP_WARN_[ExtraActionButton|r for extra damage.
*|TInterface/cursor/crosshair/interact.blp:17|tClick on the |cRXP_PICK_Objects|r.
.complete 65956,1 
.mob Qalashi Necksnapper
.mob Qalashi Crustshaper
.mob Qalashi Steelcrafter
.mob Qalashi Boltthrower
.mob Qalashi Skullhauler
step
#label The Courage of One's Convictions
.goto 2022,33.99,61.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.turnin 65957 >>Turn in No Time For Heroes
.turnin 65956 >>Turn in Talon Strike
.accept 65939 >>Accept The Courage of One's Convictions
.target Wrathion
step
.isOnQuest 40519
.subzone 10523 >>Use |T135975:0|t[Stormwind Portal Stone]
.cooldown item,132120,>0,1
.use 132120
step
.zoneskip 84
.zone 2352 >>Teleport to a Neighborhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.goto 2352,57.43,26.65
.zone 84 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.zoneskip 2352,1
step
.pve
+You can enable War Mode to gain 10–30% bonus experience and additional PvP talents; however, this makes you hostile to the opposing faction and you’ll remain attackable at all times until War Mode is turned off in a rested area.
*To turn on Warmode press the macro in the "Active Items Frame"
.macro Enable Warmode,1965766 >>/run C_PvP.ToggleWarMode();
step
.isNotOnQuest 40519
.isQuestTurnedIn 55991
#completewith next
#label The Legion Returns
.goto 84,49.29,86.85,5,0
.goto 84,49.05,87.82,5,0
.goto 84,48.85,86.89,5,0
.goto 84,49.05,87.75,5,0
.goto 84,49.52,86.63,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r |cRXP_WARN_[2]|r.
.accept 40519 >>Accept Legion: The Legion Returns
.chromietime 10
.skipgossipid 51901
.skipgossipid 51902
.target Chromie
step << Alliance
#completewith The Legion Returns
.goto 84,56.257,17.311,810 >>Leave Mage Tower
step << Alliance
#requires The Legion Returns
#label WakingShoresEndSpeedrun
.isNotOnQuest 40519
.isQuestTurnedIn 55991
.goto 84,56.257,17.311
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r |cRXP_WARN_[2]|r.
.accept 40519 >>Accept Legion: The Legion Returns
.chromietime 10
.skipgossipid 51901
.skipgossipid 51902
.target Chromie
step
#label MissingEndStart
.goto 2022,33.99,61.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.complete 65939,1 
.skipgossipid 55405
.target Wrathion
step
.goto 2022,33.18,61.92,40,0
.goto 2022,30.51,60.88
#title |cFFFCDC00Follow the Arrow|r
.complete 65939,2 
step
#completewith WakingShoreAShatteredPast
>>Kill |cRXP_ENEMY_Qalashi Forces|r
.complete 65939,3 
.mob Qalashi Necksnapper
.mob Qalashi Boltthrower
.mob Qalashi Flamelobber
.mob Qalashi Flametamer
.mob Qalashi Stonebinder
.mob Qalashi Pillager
.mob Qalashi Gatecrasher
step
.goto 2022,29.14,58.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.accept 66044 >>Accept Taking the Walls
.target Wrathion
step
.goto 2022,29.14,58.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.complete 66044,1 
.timer 20,RP
.skipgossipid 54627
.target Wrathion
step
.goto 2022,26.81,59.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Catapult|r.
.complete 66044,2 
step
.goto 2022,29.51,60.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Catapult|r.
.complete 66044,3 
step
#label WakingShoreTakingTheWalls
.goto 2022,27.79,56.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Catapult|r.
.complete 66044,4 
step
.goto 2022,27.02,57.57
>>Kill |cRXP_ENEMY_Champion Choruk|r.
.complete 66044,5 
.mob Champion Choruk
step
.goto 2022,26.42,58.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.turnin 66044 >>Turn in Taking the Walls
.accept 66049 >>Accept Obsidian Oathstone
.target Wrathion
step
.goto 2022,27.30,62.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.complete 66049,1 
.skipgossipid 55423
.target Wrathion
step
.goto 2022,27.62,63.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obsidian Oathstone|r.
.complete 66049,2 
.timer 20,Roleplay Duration
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Forgemaster Bazentus|r.
.turnin 66049 >>Turn in Obsidian Oathstone
.goto 2022,27.30,62.59
.target +Wrathion
.accept 66055 >>Accept A Shattered Past
.goto 2022,27.26,62.80
.target +Forgemaster Bazentus
step
.goto 2022,27.1,61.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Oathstone Fragments|r.
.complete 66055,2,1 
step
#label WakingShoreAShatteredPast
.goto 2022,27.09,60.61
#title |cFFFCDC00Follow the Arrow|r
.complete 66055,1 
step
#hidewindow
#completewith Oathstone Fragment
#loop
.goto 2022,27.11,60.51,10,0
.goto 2022,25.6,59.49,10,0
.goto 2022,24.97,58.17,10,0
.goto 2022,25.15,57.05,10,0
.goto 2022,25.09,56.32,10,0
.goto 2022,25.95,56.04,10,0
.goto 2022,26.38,55.95,10,0
.goto 2022,26.01,55.3,10,0
.goto 2022,24.99,54.68,10,0
.goto 2022,24.48,54.55,10,0
.goto 2022,24.8,55.76,10,0
.goto 2022,24.66,56.33,10,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Qalashi Forces|r
.complete 65939,3 
.mob Qalashi Necksnapper
.mob Qalashi Boltthrower
.mob Qalashi Flamelobber
.mob Qalashi Flametamer
.mob Qalashi Stonebinder
.mob Qalashi Pillager
.mob Qalashi Gatecrasher
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Oathstone Fragments|r.
.complete 66055,2 
step
#label Oathstone Fragment
>>Kill |cRXP_ENEMY_Qalashi Forces|r
.complete 65939,3 
.mob Qalashi Necksnapper
.mob Qalashi Boltthrower
.mob Qalashi Flamelobber
.mob Qalashi Flametamer
.mob Qalashi Stonebinder
.mob Qalashi Pillager
.mob Qalashi Gatecrasher
step
#completewith next
#label A Shattered Past
.goto 2022,27.15,60.86,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Forgemaster Bazentus|r.
.turnin 65939 >>Turn in The Courage of One's Convictions
.target +Wrathion
.turnin 66055 >>Turn in A Shattered Past
.accept 66056 >>Accept Forging A New Future
.disablecheckbox
.target +Forgemaster Bazentus
step
#completewith A Shattered Past
.goto 2022,27.30,62.58,100 >>Leave the vault
step
#requires A Shattered Past
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Forgemaster Bazentus|r.
.turnin 65939 >>Turn in The Courage of One's Convictions
.goto 2022,27.30,62.58
.target +Wrathion
.turnin 66055 >>Turn in A Shattered Past
.accept 66056 >>Accept Forging A New Future
.goto 2022,27.25,62.81
.target +Forgemaster Bazentus
step
.goto 2022,24.62,60.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forge|r.
.complete 66056,1 
step
#loop
.goto 2022,24.48,61.51,10,0
.goto 2022,24.90,61.86,15,0
.goto 2022,25.05,61.43,10,0
.goto 2022,24.79,60.29,10,0
.goto 2022,24.63,59.69,10,0
.goto 2022,25.43,60.57,20,0
.goto 2022,24.48,61.51,10,0
.goto 2022,24.90,61.86,15,0
.goto 2022,24.87,60.80,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cindershard Coal|r.
>>Kill |cRXP_ENEMY_Animated Cindershards|r
*Loot them for |T134568:0|t[|cRXP_LOOT_Cindershard Coal|r].
.complete 66056,2 
step
.goto 2022,24.68,61.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forgemaster Bazentus|r.
.turnin 66056 >>Turn in Forging A New Future
.accept 66354 >>Accept The Spark
.target Forgemaster Bazentus
step
.goto 2022,24.60,60.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fragments|r on the forge.
.complete 66354,1 
.timer 16,Roleplay Duration
step
.goto 2022,24.60,60.97
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66354,2 
step
.goto 2022,24.60,60.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Reformed Oathstone Fragments|r.
.complete 66354,3 
step
.goto 2022,24.68,61.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forgemaster Bazentus|r.
.turnin 66354 >>Turn in The Spark
.accept 66057 >>Accept Restoring the Faith
.target Forgemaster Bazentus
step
.goto 2022,27.30,62.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r.
.complete 66057,1 
.timer 6.5,RP
.target Wrathion
.skipgossipid 56143
step
.goto 2022,27.09,62.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Wrathion|r.
.complete 66057,2 
.timer 29,RP
step
.goto 2022,24.42,55.49
#title |cFFFCDC00Follow the Arrow|r
.complete 66057,3 
.target Wrathion
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Sabellian|r.
.turnin 66057 >>Turn in Restoring the Faith
.accept 66780 >>Accept Claimant to the Throne
.goto 2022,24.42,55.49
.target +Wrathion
.accept 66779 >>Accept Heir Apparent
.goto 2022,24.25,55.87
.target +Sabellian
step
.goto 2022,24.38,57.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forgemaster Bazentus|r.
.complete 66779,2 
.target Forgemaster Bazentus
.skipgossipid 55566
step
.goto 2022,24.32,58.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baskilan|r.
.complete 66779,1 
.target Baskilan
.skipgossipid 55358
step
.goto 2022,25.11,56.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archivist Edress|r |cRXP_WARN_twice|r.
.complete 66779,3 
.complete 66780,3 
.skipgossipid 55565
.skipgossipid 55564
.target Archivist Edress
step
.goto 2022,26.40,54.61
#title |cFFFCDC00NPC Patrols|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talonstalker Kavia|r.
.complete 66780,1 
.target Talonstalker Kavia
.skipgossipid 55354
step
.goto 2022,25.02,55.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Left|r or |cRXP_FRIENDLY_Right|r.
.complete 66780,2 
.target Left
.target Right
.skipgossipid 55355
.skipgossipid 55356
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wrathion|r and |cRXP_FRIENDLY_Sabellian|r.
.turnin 66780 >>Turn in Claimant to the Throne
.goto 2022,24.42,55.47
.target +Wrathion
.turnin 66779 >>Turn in Heir Apparent
.accept 65793 >>Accept Black Wagon Flight
.goto 2022,24.24,55.87
.target +Sabellian
step
.goto 2022,43.84,66.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sabellian|r.
.complete 65793,2 
.skipgossipid 55381
.target Sabellion
step
#title |cFFFCDC00Follow the Carriage|r
>>Kill the incoming waves of |cRXP_ENEMY_monsters|r.
.complete 65793,3 
.mob Tarasek Snatcher
.mob Primal Avalanche
step
.goto 2022,57.96,67.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sabellian|r.
.turnin 65793 >>Turn in Black Wagon Flight
.accept 66785 >>Accept The Last Eggtender
.target Sabellian
step
.goto 2022,61.60,68.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mother Elion|r.
.turnin 66785 >>Turn in The Last Eggtender
.accept 66788 >>Accept Egg-cited for the Future
.target Mother Elion
step
.goto 2022,61.52,68.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_leaves|r.
.complete 66788,1,1 
step
#completewith next
#label Overgrown Weeds1
>>Pull the Weed out.
.complete 66788,2,1 
step
#completewith Overgrown Weeds1
.goto 2022,61.58,68.9
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weed|r
step
#requires Overgrown Weeds1
.goto 2022,61.44,69.03
>>Pull the Weed out.
.complete 66788,2,1 
step
.goto 2022,61.44,69.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ruby Shrineguard|r.
.complete 66788,3 
.target Ruby Shrineguard
step
#completewith next
#label Overgrown Weeds2
>>Pull the Weed out.
.complete 66788,2,2 
step
#completewith Overgrown Weeds2
.goto 2022,61.46,68.63
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weed|r
step
#requires Overgrown Weeds2
.goto 2022,61.4,68.33
>>Pull the Weed out.
.complete 66788,2,2 
step
.goto 2022,61.4,68.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_leaves|r.
.complete 66788,1,2 
step
#completewith next
#label Overgrown Weeds3
>>Pull the Weed out.
.complete 66788,2,3 
step
#completewith Overgrown Weeds3
.goto 2022,61.67,68.34
.cast 6478 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weed|r
step
#requires Overgrown Weeds3
.goto 2022,61.6,68.72
>>Pull the Weed out.
.complete 66788,2,3 
step
.goto 2022,61.60,68.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mother Elion|r.
.turnin 66788 >>Turn in Egg-cited for the Future
.accept 65791 >>Accept Life-Binder on Duty
.target Mother Elion
step
.goto 2022,62.34,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 65791 >>Turn in Life-Binder on Duty
.accept 65794 >>Accept A Charge of Care
.target Alexstrasza the Life-Binder
step
.goto 2022,62.34,73.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstraza the Life-Binder|r.
.complete 65794,1 
.skipgossipid 55380
.target Alexstrasza the Life-Binder
step
.goto 2022,61.57,68.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 65794 >>Turn in A Charge of Care
.accept 65795 >>Accept Next Steppes
.target Alexstrasza the Life-Binder
step
.goto 2022,48.28,88.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Taurasza|r.
.turnin 65795 >>Turn in Next Steppes
.accept 65779 >>Accept Into the Plains
.target Ambassador Taurasza
.achievementIncomplete 15394,0
.achievementIncomplete 16336,0
.achievementIncomplete 16363,0
.achievementIncomplete 16334,0
step
#label MissingEndEnd
.goto 2022,48.28,88.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Taurasza|r.
.turnin 65795 >>Turn in Next Steppes
.turnin 72267 >>Turn in Ohn'ahran Plains
.accept 65779 >>Accept Into the Plains
.achievementComplete 15394,1
.achievementComplete 16336,1
.achievementComplete 16363,1
.achievementComplete 16334,1
.target Ambassador Taurasza
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Ohn'ahran Plains Midnight
#internal
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.goto 2023,77.72,23.93
.turnin 65779 >>Turn in Into the Plains
.accept 65780 >>Accept Proving Oneself
.target Scout Tomul
step
.goto 2023,78.50,27.21
>>Kill the |cRXP_ENEMY_Blazing Proto-Dragon|r.
.complete 65780,1 
.mob Blazing Proto-Dragon
step
.goto 2023,78.63,25.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.turnin 65780 >>Turn in Proving Oneself
.accept 65783 >>Accept Welcome at Our Fire
.target Scout Tomul
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.goto 2023,85.31,25.41
.turnin 65783 >>Turn in Welcome at Our Fire
.accept 70174 >>Accept The Shikaar
.target Scout Tomul
step
.goto 2023,85.74,25.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sansok Khan|r.
.complete 70174,1 
.skipgossipid 56190
.target Sansok Khan
step
.goto 2023,85.73,25.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sansok Khan|r.
.turnin 70174 >>Turn in The Shikaar
.accept 65802 >>Accept Supplies for the Journey
.accept 65801 >>Accept Making Introductions
.target Sansok Khan
step
#title Provision (1/4)
.goto 2023,86.17,25.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bundle of Pelts|r.
.complete 65802,2,1 
step
.goto 2023,85.76,26.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aru|r or |cRXP_FRIENDLY_Belika|r.
.complete 65801,2 
.target Aru
.target Belika
.skipgossipid 55270
.skipgossipid 54840
step
#title Pod (1/5)
.goto 2023,85.51,26.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Medicinal Feralbloom|r.
.complete 65802,1,1 
step
#title Pod (2/5)
.goto 2023,84.98,26.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Medicinal Feralbloom|r.
.complete 65802,1,2 
step
#title Pod (3/5)
.goto 2023,84.59,27.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Medicinal Feralbloom|r.
.complete 65802,1,3 
step
#title Provisions (2/4)
.goto 2023,84.31,27.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket of Dried Fish|r.
.complete 65802,2,2 
step
#title Pod (4/5)
.goto 2023,84.29,25.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Medicinal Feralbloom|r.
.complete 65802,1,4 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beastmaster Nuqut|r.
.goto 2023,83.93,25.88
.complete 65801,3 
.target Beastmaster Nuqut
.skipgossipid 55228
step
#title Pod (5/5)
.goto 2023,83.76,25.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Medicinal Feralbloom|r.
.complete 65802,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Ehri|r and |cRXP_FRIENDLY_Farrier Roscha|r.
.accept 65951 >>Accept Sole Supplier
.goto 2023,84.34,25.00
.target +Apprentice Ehri
.accept 65950 >>Accept Thieving Gorlocs
.goto 2023,84.40,25.01
.target +Farrier Roscha
step
#loop
.goto 2023,82.29,29.02,25,0
.goto 2023,82.41,30.53,25,0
.goto 2023,81.29,32.17,25,0
.goto 2023,80.15,32.28,25,0
.goto 2023,80.6,29.51,25,0
>>Kill |cRXP_ENEMY_Mudfins|r |cRXP_WARN_(avoid shamans)|r
*Loot them for |T132765:0|t[|cRXP_LOOT_Supplies|r].
.complete 65950,1 
.mob Mudfin Mudrunner
.mob Mudfin Shaman
.mob Mudfin Salamancer
step
.goto 2023,80.65,30.87
#title |cFFFCDC00Follow the Arrow|r
.complete 65951,1 
step
.goto 2023,80.56,30.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khasar|r.
.turnin 65951 >>Turn in Sole Supplier
.turnin 65950 >>Turn in Thieving Gorlocs
.accept 65953 >>Accept The Ora-cull
.accept 65954 >>Accept Release the Hounds
.accept 65955 >>Accept A Centaur's Best Friend
.target Khasar
step
.goto 2023,80.56,30.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Cage|r.
.complete 65955,1 
step
#completewith OhnahranPlainsReleaseTheHounds4
>>Kill |cRXP_ENEMY_Mudfin Shamans|r.
*Loot them for |T1020304:0|t[|cRXP_LOOT_Mudfin Totem|r].
.complete 65953,1 
.mob Mudfin Shaman
step
.goto 2023,80.63,30.69
#title Bakar Collar (1/2)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Batu|r.
.complete 65954,2,1 
.target Batu
step
.goto 2023,81.16,29.77
#title Bakar Freed (1/5)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 65954,1,1 
step
.goto 2023,81.43,29.69
#title Bakar Freed (2/5)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 65954,1,2 
step
.goto 2023,82.22,30.27
#title Bakar Freed (3/5)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 65954,1,3 
step
.goto 2023,82.22,30.43
#title Bakar Collar (2/2)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Sarnai|r.
.complete 65954,2 
.target Sarnai
step
#title Bakar Freed (4/5)
.goto 2023,82.36,30.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 65954,1,4 
step
#title Bakar Freed (5/5)
#label OhnahranPlainsReleaseTheHounds4
.goto 2023,81.25,31.70
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 65954,1 
step
#loop
.goto 2023,81,32.1,20,0
.goto 2023,81.97,32.14,20,0
.goto 2023,82.63,31.17,20,0
.goto 2023,82.19,30.24,20,0
.goto 2023,80.57,30.69,20,0
>>Kill |cRXP_ENEMY_Mudfins|r
*Loot them for |T132765:0|t[|cRXP_LOOT_Supplies|r].
.complete 65953,1 
.mob Mudfin Shaman
step
#completewith next
#label FreeBaba
.goto 2023,83.08,32.06,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Cage|r.
.complete 65955,2 
step
#title Enter Cave
#completewith FreeBaba
.goto 2023,83.38,32.40,38 >>Enter the cave
step
#requires FreeBaba
.goto 2023,83.38,32.40
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Cage|r.
.complete 65955,2 
step
.goto 2023,83.43,32.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khasar|r.
.turnin 65955 >>Turn in A Centaur's Best Friend
.turnin 65953 >>Turn in The Ora-cull
.turnin 65954 >>Turn in Release the Hounds
.accept 65952 >>Accept A Chief of Legends
.target Khasar
step
#completewith next
#label ChiefGrrlgllmeshSlain
.goto 2023,83.08,32.06,10,0
>>Kill |cRXP_ENEMY_Chief Grrlgllmesh|r.
*Loot him for |T1013266:0|t[|cRXP_LOOT_Medallion of a Fallen Friend|r].
.complete 65952,1 
step
#title Leave Cave
#completewith ChiefGrrlgllmeshSlain
.goto 2023,82.10,31.44,85 >>Leave the cave
step
#requires ChiefGrrlgllmeshSlain
.goto 2023,82.10,31.44
>>Kill |cRXP_ENEMY_Chief Grrlgllmesh|r.
*Loot him for |T1013266:0|t[|cRXP_LOOT_Medallion of a Fallen Friend|r].
.complete 65952,1 
.accept 66005 >>Accept Medallion of a Fallen Friend
.mob Chief Grrlgllmesh
step
#completewith next
#label AChiefMedallionSoleRoscha
.goto 2023,83.1,32.01,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khasar|r.
.turnin 65952 >>Turn in A Chief of Legends
.turnin 66005 >>Turn in Medallion of a Fallen Friend
.accept 65949 >>Accept The Sole Mender
.accept 66006 >>Accept Return to Roscha
.target Khasar
step
#title Enter Cave
#completewith AChiefMedallionSoleRoscha
.goto 2023,83.44,32.33,31 >>Enter the cave
step
#requires AChiefMedallionSoleRoscha
.goto 2023,83.44,32.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khasar|r.
.turnin 65952 >>Turn in A Chief of Legends
.turnin 66005 >>Turn in Medallion of a Fallen Friend
.accept 65949 >>Accept The Sole Mender
.accept 66006 >>Accept Return to Roscha
.target Khasar
step
.goto 2023,83.51,32.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shikaar Supplies|r.
.complete 66006,1 
step
#completewith next
#label SoleRoscha
.goto 2023,83.08,32.06,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farrier Roscha|r.
.turnin 65949 >>Turn in The Sole Mender
.turnin 66006 >>Turn in Return to Roscha
.target Farrier Roscha
step
#title Leave Cave
#completewith SoleRoscha
.goto 2023,84.40,25.02,360 >>Leave the cave
step
#requires SoleRoscha
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farrier Roscha|r.
.goto 2023,84.40,25.02
.turnin 65949 >>Turn in The Sole Mender
.turnin 66006 >>Turn in Return to Roscha
.target Farrier Roscha
step
#title Supply (3/4)
.goto 2023,84.34,24.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
.complete 65802,2,3 
step
#title Supply (4/4)
.goto 2023,84.37,23.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r.
.complete 65802,2 
step
.goto 2023,85.63,20.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ohn Seshteng|r.
.complete 65801,1 
.skipgossipid 54838
.target Ohn Seshteng
step
.goto 2023,84.69,22.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r inside the hut.
.turnin 65801 >>Turn in Making Introductions
.turnin 65802 >>Turn in Supplies for the Journey
.accept 65803 >>Accept Toward the City
.target Scout Tomul
step
.goto 2023,83.15,23.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.complete 65803,1 
.skipgossipid 55267
.target Scout Tomul
step
.goto 2023,75.66,31.68
#title |cFFFCDC00Follow the Arrow|r
.complete 65803,3 
step
.goto 2023,75.66,31.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.turnin 65803 >>Turn in Toward the City
.accept 65804 >>Accept For Food and Rivalry
.target Scout Tomul
step
.goto 2023,76.73,31.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mysterious Paw Print|r.
.accept 70185 >>Accept Mysterious Beast
step
#completewith next
#label Fresh Game Meat
.goto 2023,77.78,35.39,10,0
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T3671885:0|t[|cRXP_LOOT_Fresh Game Meat|r].
*|cRXP_WARN_The best source of meat are |cRXP_ENEMY_Plainswalker|r and |cRXP_ENEMY_Sunhide Stomphooves|r|r.
.complete 65804,1 
.mob Plainswalker Mammoth
.mob Plainswalker Calf
.mob Plainswalker Bull
.mob Sunhide Stomphoof
.mob Feelcepelt Argali
step
#completewith Fresh Game Meat
.goto 2023,78.22,35.24,30 >>Enter the cave
step
#requires Fresh Game Meat
.goto 2023,78.22,35.24
>>Kill |cRXP_ENEMY_Konkhular|r.
*Loot him for the |T3586020:0|t[|cRXP_LOOT_Pelt of Konkhular|r].
.complete 70185,1 
.mob Konkhular
step
#completewith next
#label Fresh Game Meat2
.goto 2023,77.78,35.39,10,0
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T3671885:0|t[|cRXP_LOOT_Fresh Game Meat|r].
*|cRXP_WARN_The best source of meat are |cRXP_ENEMY_Plainswalker|r and |cRXP_ENEMY_Sunhide Stomphooves|r|r.
.complete 65804,1 
.mob Plainswalker Mammoth
.mob Plainswalker Calf
.mob Plainswalker Bull
.mob Sunhide Stomphoof
.mob Feelcepelt Argali
step
#title Leave Cave
#completewith Fresh Game Meat2
.goto 2023,79.22,30.63,240 >>Leave the cave
step
#requires Fresh Game Meat2
#loop
.goto 2023,79.22,30.63,40,0
.goto 2023,77.89,29.57,40,0
.goto 2023,74.62,29.06,40,0
.goto 2023,76.08,34.27,40,0
.goto 2023,77.47,32.21,40,0
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T3671885:0|t[|cRXP_LOOT_Fresh Game Meat|r].
*|cRXP_WARN_The best source of meat are |cRXP_ENEMY_Plainswalker|r and |cRXP_ENEMY_Sunhide Stomphooves|r|r.
.complete 65804,1 
.mob Plainswalker Mammoth
.mob Plainswalker Calf
.mob Plainswalker Bull
.mob Sunhide Stomphoof
.mob Feelcepelt Argali
step
.goto 2023,75.67,31.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.turnin 65804 >>Turn in For Food and Rivalry
.turnin 70185 >>Turn in Mysterious Beast
.accept 65940 >>Accept By Broken Road
.target Scout Tomul
step
.goto 2023,70.07,37.84
#title |cFFFCDC00Follow the Arrow|r
.complete 65940,2 
step
.goto 2023,69.97,37.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ohn Seshteng|r.
.turnin 65940 >>Turn in By Broken Road
.accept 65805 >>Accept Connection to Ohn'ahra
.target Ohn Seshteng
step
#completewith RiverReeds1
>>Kill |cRXP_ENEMY_Mudwalker Salamanthers|r.
*Loot them for the |T134338:0|t[|cRXP_LOOT_Salamather Heart|r].
.complete 65805,3 
.mob Mudwalker Salamanther
step
#completewith RiverReeds1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ducks|r.
*Kill |cRXP_ENEMY_Ducks|r |cRXP_WARN_only if they attack you|r.
*Loot them for |T132924:0|t[|cRXP_LOOT_Fowl Tailfeathers|r].
.complete 65805,2 
.mob Jadethroat Mallard
step
#label RiverReeds1
.goto 2023,69.45,37.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_River Reeds|r.
.complete 65805,1,1 
step
#completewith RiverReeds2
>>Kill |cRXP_ENEMY_Mudwalker Salamanthers|r.
*Loot them for the |T134338:0|t[|cRXP_LOOT_Salamather Heart|r].
.complete 65805,3 
.mob Mudwalker Salamanther
step
#completewith RiverReeds2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ducks|r.
*Kill |cRXP_ENEMY_Ducks|r |cRXP_WARN_only if they attack you|r.
*Loot them for |T132924:0|t[|cRXP_LOOT_Fowl Tailfeathers|r].
.complete 65805,2 
.mob Jadethroat Mallard
step
#label RiverReeds2
.goto 2023,69.88,36.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_River Reeds|r.
.complete 65805,1,2 
step
#completewith RiverReeds3
>>Kill |cRXP_ENEMY_Mudwalker Salamanthers|r.
*Loot them for the |T134338:0|t[|cRXP_LOOT_Salamather Heart|r].
.complete 65805,3 
.mob Mudwalker Salamanther
step
#completewith RiverReeds3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ducks|r.
*Kill |cRXP_ENEMY_Ducks|r |cRXP_WARN_only if they attack you|r.
*Loot them for |T132924:0|t[|cRXP_LOOT_Fowl Tailfeathers|r].
.complete 65805,2 
.mob Jadethroat Mallard
step
#label RiverReeds3
.goto 2023,70.35,35.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_River Reeds|r.
.complete 65805,1,3 
step
#completewith RiverReeds4
>>Kill |cRXP_ENEMY_Mudwalker Salamanthers|r.
*Loot them for |T134338:0|t[|cRXP_LOOT_Salamather Heart|r].
.complete 65805,3 
.mob Mudwalker Salamanther
step
#completewith RiverReeds4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ducks|r.
*Kill |cRXP_ENEMY_Ducks|r |cRXP_WARN_only if they attack you|r.
*Loot them for |T132924:0|t[|cRXP_LOOT_Fowl Tailfeathers|r].
.complete 65805,2 
.mob Jadethroat Mallard
step
#label RiverReeds4
.goto 2023,70.54,37.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_River Reeds|r.
.complete 65805,1,4 
step
#completewith SalamantherHeart
#hidewindow
#loop
.goto 2023,68.69,39.38,25,0
.goto 2023,68.36,40.48,25,0
.goto 2023,70.33,41.07,25,0
.goto 2023,70.8,36.76,25,0
.goto 2023,70.38,34.42,25,0
.goto 2023,69.05,34.18,25,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ducks|r.
*Kill |cRXP_ENEMY_Ducks|r |cRXP_WARN_only if they attack you|r.
*Loot them for |T132924:0|t[|cRXP_LOOT_Fowl Tailfeathers|r].
.complete 65805,2 
.mob Jadethroat Mallard
step
>>Kill |cRXP_ENEMY_Mudwalker Salamanthers|r.
*Loot them for the |T134338:0|t[|cRXP_LOOT_Salamather Heart|r].
.complete 65805,3 
.mob Mudwalker Salamanther
step
#label SalamantherHeart
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ducks|r.
*Kill |cRXP_ENEMY_Ducks|r |cRXP_WARN_only if they attack you|r. Loot them for the |T132924:0|t[|cRXP_LOOT_Fowl Tailfeathers|r].
.complete 65805,2 
.mob Jadethroat Mallard
step
.goto 2023,69.96,37.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ohn Seshteng|r.
.turnin 65805 >>Turn in Connection to Ohn'ahra
.accept 66848 >>Accept Omens on the Wind
.target Ohn Seshteng
step
.goto 2023,69.96,37.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ohn Seshteng|r.
.complete 66848,1 
.skipgossipid 64063
.target Ohn Seshteng
step
.goto 2023,69.93,37.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totems|r.
.complete 66848,2 
.timer 18,Roleplay Duration
step
.goto 2023,69.96,37.94
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66848,3 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ohn Seshteng|r and |cRXP_FRIENDLY_Sansok Khan|r.
.turnin 66848 >>Turn in Omens on the Wind
.goto 2023,69.96,37.94
.target +Ohn Seshteng
.accept 65806 >>Accept Maruukai
.goto 2023,70.02,38.01
.target +Sansok Khan
step
.goto 2023,61.44,39.52
#title |cFFFCDC00Follow the Arrow|r
.complete 65806,2 
step
.goto 2023,61.44,39.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sansok Khan|r.
.turnin 65806 >>Turn in Maruukai
.accept 66018 >>Accept Clan Nokhud
.accept 66017 >>Accept Clan Ohn'ir
.accept 66016 >>Accept Clan Teerai
.target Sansok Khan
step
.goto 2023,62.12,36.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windsage Kven|r.
.accept 70337 >>Accept Emberwatch
.target Windsage Kven
step
.goto 2023,62.99,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ohn Seshteng|r.
.turnin 66017 >>Turn in Clan Ohn'ir
.accept 66020 >>Accept Omens and Incense
.target Ohn Seshteng
step
.goto 2023,63.12,34.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windsage Ordven|r.
.accept 65906 >>Accept A Disgruntled Initiate
.target Windsage Ordven
step
#completewith next
#label Sweetsuckle Incense
.goto 2023,62.84,34.34,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r.
.collect 191160,1,66020,1
step
#completewithSweetsuckle Incense
.goto 2023,63.12,34.05,30 >>Leave the building
step
.isOnQuest 66020
#title Sweetsuckle Bloom (1/5)
.goto 2023,63.42,33.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r.
.collect 191160,1,66020,1
step
.isOnQuest 66020
#title Sweetsuckle Bloom (2/5)
.goto 2023,63.77,34.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r.
.collect 191160,2,66020,1
step
.isOnQuest 66020
#title Sweetsuckle Bloom (3/5)
.goto 2023,63.57,34.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r.
.collect 191160,3,66020,1
step
.isOnQuest 66020
#title Sweetsuckle Bloom (5/5)
.goto 2023,63.39,34.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r.
.collect 191160,5,66020,1
step
.goto 2023,62.82,33.69
>>Use |T458235:0|t[Sweetsuckle Bloom].
.complete 66020,1 
.use 191160
step
.goto 2023,62.82,33.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense Burner|r.
.complete 66020,2 
step
.goto 2023,62.99,33.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ohn Seshteng|r.
.turnin 66020 >>Turn in Omens and Incense
.target Ohn Seshteng
step
.goto 2023,59.16,37.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Qariin Dotur|r.
.turnin 66016 >>Turn in Clan Teerai
.accept 66019 >>Accept Honoring Our Ancestors
.target Quariin Dotur
step
.goto 2023,59.39,37.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Meat|r.
.complete 66019,1 
step
.goto 2023,59.13,37.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Meat|r.
.complete 66019,2 
step
.goto 2023,59.31,37.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Jar|r.
.complete 66019,3 
step
.goto 2023,59.14,37.61
>>Use the |cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Qariin Dotur|r.
.complete 66019,4 
.target Qariin Dotur
step
.goto 2023,59.39,37.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket|r.
.complete 66019,5 
step
.goto 2023,59.16,37.57
>>Use the |cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Qariin Dotur|r.
.complete 66019,6 
.target Qariin Dotur
step
.goto 2023,59.05,37.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pot|r.
.complete 66019,7 
step
.goto 2023,59.14,37.58
>>Use the |cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Qariin Dotur|r.
.complete 66019,8 
.target Qariin Dotur
step
.goto 2023,59.14,37.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Meat|r.
.complete 66019,9 
step
.goto 2023,58.90,37.26
>>Use the |cRXP_WARN_[ExtraActionButton]|r at the forge.
.complete 66019,10 
step
.goto 2023,59.16,37.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Meat|r.
.complete 66019,11 
step
.goto 2023,59.16,37.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Qariin Dotur|r.
.turnin 66019 >>Turn in Honoring Our Ancestors
.target Qariin Dotur
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r and |cRXP_FRIENDLY_Guard Bahir|r.
.turnin 66018 >>Turn in Clan Nokhud
.goto 2023,60.38,40.69
.target +Scout Tomul
.accept 66021 >>Accept Unwelcome Outsider
.goto 2023,60.31,40.75
.target +Guard Bahir
step
#loop
.goto 2023,59.76,42.14,20,0
.goto 2023,60.23,42.44,20,0
.goto 2023,60.08,41.29,20,0
.goto 2023,59.26,41.37,20,0
.goto 2023,58.71,42.75,20,0
.goto 2023,59.38,43.29,20,0
>>Kill |cRXP_ENEMY_Centaurs|r.
.complete 66021,1 
.mob Nokhud Fighter
.mob Nokhud Brute
.mob Nokhud Spearthrower
step
.goto 2023,61.98,41.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beastmaster Tirren|r.
.accept 65837 >>Accept Trouble In The Pines
.target Beastmaster Tirren
step
.goto 2023,62.43,41.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.turnin 66021 >>Turn in Unwelcome Outsider
.target Scout Tomul
step
.goto 2023,62.43,41.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aru|r |cRXP_WARN_next to you|r.
.accept 66969 >>Accept Clans of the Plains
.target Aru
step
.goto 2023,61.44,39.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sansok Khan|r.
.complete 66969,1 
.target Sansok Khan
step
.goto 2023,61.43,39.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sansok Khan|r.
.complete 66969,2 
.target Sansok Khan
.skipgossipid 56528 
.skipgossipid 56515 
.skipgossipid 56537 
.skipgossipid 56549 
.skipgossipid 56554 
step
.goto 2023,61.44,39.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sansok Khan|r.
.turnin 66969 >>Turn in Clans of the Plains
.timer 30,RP
.target Sansok Khan
step
.goto 2023,61.03,40.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gemisath|r |cRXP_WARN_after the roleplay|r.
.accept 66948 >>Accept The Emissary's Arrival
.target Gemisath
step
.goto 2023,61.03,40.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gemisath|r.
.complete 66948,1 
.skipgossipid 56585
.target Gemisath
step
.goto 2023,61.03,40.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gemisath|r.
.turnin 66948 >>Turn in The Emissary's Arrival
.accept 66022 >>Accept The Khanam Matra
.target Gemisath
step
.goto 2023,60.29,37.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Akato|r |cRXP_WARN_on the building|r.
.complete 66022,1 
.target Khansguard Akato
.skipgossipid 54895
step
.goto 2023,60.35,38.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Akato|r |cRXP_WARN_on the building|r.
.turnin 66022 >>Turn in The Khanam Matra
.accept 66023 >>Accept Trucebreakers
.target Khansguard Akato
step
.goto 2023,59.52,38.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Tomul|r.
.accept 66024 >>Accept Covering Their Tails
.target Scout Tomul
step
#completewith next
>>Kill |cRXP_ENEMY_Centaurs|r
.complete 66023,1 
.mob Nokhud Betrayer
.mob Nokhud Reaver
.mob Nokhud Storm Adept
step
.goto 2023,58.06,39.37
>>Kill |cRXP_ENEMY_Guard Bahir|r.
.complete 66024,1 
.mob Guard Bahir
step
#loop
.goto 2023,58.84,39.63,25,0
.goto 2023,59.15,37.15,25,0
.goto 2023,59.56,38.52,25,0
.goto 2023,59.87,40.27,25,0
>>Kill |cRXP_ENEMY_Centaurs|r.
.complete 66023,1 
.mob Nokhud Betrayer
.mob Nokhud Reaver
.mob Nokhud Storm Adept
step
.goto 2023,60.36,38.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Akato|r and |cRXP_FRIENDLY_Khanam Matra Sarest|r |cRXP_WARN_on the building|r.
.turnin 66023 >>Turn in Trucebreakers
.turnin 66024 >>Turn in Covering Their Tails
.accept 66025 >>Accept The Nokhud Threat
.timer 23,Roleplay Duration
.target Khansguard Akato
.target Khanam Matra Sarest
step
.goto 2023,60.00,37.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r |cRXP_WARN_after the roleplay|r.
.turnin 66025 >>Turn in The Nokhud Threat
.accept 66201 >>Accept Hooves of War
.target Khanam Matra Sarest
step
.goto 2023,63.47,48.63,10,0
.goto 2023,63.03,48.54
>>Kill |cRXP_ENEMY_Sunscale Behemoth|r |cRXP_WARN_in the cave under a waterfall|r.
.accept 69837 >>Accept Sunscale Behemoth
.complete 69837,1 
.mob Sunscale Behemoth
step
.goto 2023,41.96,61.54,10,0
.goto 2023,41.89,61.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Jebotai|r inside the building
.turnin 66201 >>Turn in Hooves of War
.accept 66222 >>Accept The Calm Before the Storm
.target Khansguard Jebotai
step
.goto 2023,41.89,61.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Jebotai|r inside the building
.turnin 66201 >>Turn in Hooves of War
.accept 66222 >>Accept The Calm Before the Storm
.target Khansguard Jebotai
step
.goto 2023,41.62,56.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Nazuun|r.
.accept 66688 >>Accept Signs of the Wind
.target Elder Nazuun
step
.goto 2023,41.62,56.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Nazuun|r.
.accept 66687 >>Accept Land of the Apex
.target Elder Nazuun
step
.goto 2023,40.72,56.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quartermaster Gensai|r.
.complete 66222,2 
.target Quartermaster Gensai
.skipgossipid 54937
step
.goto 2023,39.44,55.4
#title |cFFFCDC00NPC Patrols|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Hojin|r.
.complete 66222,3 
.target Khansguard Hojin
.skipgossipid 56252
step
.goto 2023,39.56,56.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wanted: Poster|r
.accept 71027 >>Accept WANTED: Mara'nar the Thunderous
step
.goto 2023,38.49,57.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Herbalist Agura|r.
.complete 66222,1 
.skipgossipid 87457
.target Herbalist Agura
step
.goto 2023,37.57,59.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Khenyug|r.
.complete 66222,4 
.skipgossipid 55139
.target Scout Khenyug
step
.goto 2023,41.89,61.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Jebotai|r.
.turnin 66222 >>Turn in The Calm Before the Storm
.accept 70229 >>Accept Boku the Mystic
.target Khansguard Jebotai
step
.goto 2023,36.81,57.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Boku|r.
.turnin 70229 >>Turn in Boku the Mystic
.accept 66254 >>Accept Pessimistic Mystic
.target Initiate Boku
step
#title Totem (1/4)
.goto 2023,36.71,57.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66254,1,1 
step
#title Totem (2/4)
.goto 2023,36.66,57.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66254,1,2 
step
#title Totem (3/4)
.goto 2023,37.11,57.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66254,1,3 
step
#title Totem (4/4)
.goto 2023,37.20,57.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66254,1 
step
.goto 2023,36.81,57.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Boku|r.
.turnin 66254 >>Turn in Pessimistic Mystic
.accept 66224 >>Accept Mystic Mystery
.target Initiate Boku
step
.goto 2023,42.26,47.13
>>Kill |cRXP_ENEMY_Mara'nar the Thunderous|r.
*Loot him for |T134309:0|t[|cRXP_LOOT_Mara'nar's Thunderous Plate|r].
.complete 71027,1 
.mob Mara'nar the Thunderous
step
#loop
.goto 2023,41.89,46.35,20,0
.goto 2023,41.6,47.26,20,0
.goto 2023,42.42,48.45,20,0
.goto 2023,43.56,47.33,20,0
.goto 2023,43.55,45.81,20,0
.goto 2023,41.88,44.91,20,0
>>Kill |cRXP_ENEMY_Nimblewing Slyvern|r.
*Loot them for the |T1508517:0|t[|cRXP_LOOT_Slyvern Talons|r].
.complete 66687,2 
.mob Nimbleswing Slyvern
step
#completewith next
#label ShadespinnerWeb
>>Kill |cRXP_ENEMY_Spiders|r and the |cRXP_ENEMY_Spider Eggs|r.
*Loot them for |T237431:0|t[|cRXP_LOOT_Shadespinner's Webs|r].
.complete 66687,1 
.mob Rustfang Creeper
.mob Spiderling
.mob Spider Egg
step
#title Enter Cave
#completewith ShadespinnerWeb
.goto 2023,43.65,48.07
.subzone 14447 >>Enter the cave
step
#requires ShadespinnerWeb
#loop
.goto 2023,44.23,48.37,20,0
.goto 2023,44.25,49.36,20,0
.goto 2023,43.76,49.26,20,0
.goto 2023,43.88,50.25,20,0
.goto 2023,43.94,51.18,20,0
>>Kill |cRXP_ENEMY_Spiders|r and |cRXP_ENEMY_Eggs|r.
*Loot them for |T237431:0|t[|cRXP_LOOT_Shadespinner's Webs|r].
.complete 66687,1 
.mob Rustfang Creeper
.mob Spiderling
.mob Spider Egg
step
#completewith FlyUpToSkaara
#label SkaaraSlain
.goto 2023,44.91,49.21
>>Kill |cRXP_ENEMY_Skaara|r.

.complete 70783,1 

.mob Skaara
step
#completewith SkaaraSlain
#label LeaveTheCaveSkaara
.goto 2023,43.53,47.95,20 >>Leave the cave
step
#requires LeaveTheCaveSkaara
#label FlyUpToSkaara
#completewith SkaaraSlain
.goto 2023,45.19,48.66,10 >>Fly up and enter Skaara's cave
step
#requires SkaaraSlain
.goto 2023,44.91,49.21
>>Kill |cRXP_ENEMY_Skaara|r.
.complete 70783,1 
.mob Skaara
step
#completewith next
>>Kill the |cRXP_ENEMY_Thunderspines|r.
*Loot them for the |T2032170:0|t[|cRXP_LOOT_Thunderspine Scales|r].
.complete 66687,3 
.mob Thunderspine Crasher
.mob Thunderspine Rumbler
step
.goto 2023,46.64,51.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Feather|r.
.complete 66688,1,1 
step
.goto 2023,46.77,51.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Feather|r.
.complete 66688,1,2 
step
.goto 2023,47.11,51.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Feather|r.
.complete 66688,1,3 
step
.goto 2023,47.96,51.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Feather|r.
.complete 66688,1,4 
step
.goto 2023,48.37,51.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Hollow Reed|r.
.complete 66688,1,5 
step
.goto 2023,49.07,52.1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Hollow Reed|r.
.complete 66688,1,6 
step
.goto 2023,49.12,52.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Hollow Reed|r.
.complete 66688,1,7 
step
.goto 2023,49.48,52.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Hollow Reed|r.
.complete 66688,1,8 
step
.goto 2023,49.34,49.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Offering Vessel|r.
.turnin 66688 >>Turn in Signs of the Wind
step
.goto 2023,49.34,49.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Himia, the Blessed|r.
.accept 70374 >>Accept Himia, the Blessed
.target Himia, the Blessed
.skipgossipid 56476
step
.goto 2023,49.34,49.41
>>Kill the incoming |cRXP_ENEMY_Elementals|r.
.complete 70374,1 
.mob Primal Fire Elemental
.mob Water Fury
.mob Elementary Drop
.mob Earth Elemental
.skipgossipid 56476
step
#loop
.goto 2023,50.57,50.14,30,0
.goto 2023,51.33,48.78,30,0
.goto 2023,51.08,47.44,30,0
.goto 2023,50.57,50.14,30,0
>>Kill the |cRXP_ENEMY_Thunderspines|r.
*Loot them for the |T2032170:0|t[|cRXP_LOOT_Thunderspine Scales|r].
.complete 66687,3 
.mob Thunderspine Crasher
.mob Thunderspine Rumbler
step
.goto 2023,41.63,56.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Nazuun|r.
.turnin 66687 >>Turn in Land of the Apex
.turnin 70374 >>Turn in Himia, the Blessed
.target Elder Nazuun
step
.goto 2023,41.89,61.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khansguard Jebotai|r.
.turnin 71027 >>Turn in WANTED: Mara'nar the Thunderous
.target Khansguard Jebotai
step
.goto 2023,40.93,61.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Yuvari|r.
.accept 66651 >>Accept Up to No-khud
.target Elder Yuvari
step
.goto 2023,39.04,66.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Zorig|r.
.turnin 66651 >>Turn in Up to No-khud
.accept 66652 >>Accept Return to Mender
.target Initiate Zorig
step
.goto 2023,37.07,65.70
>>Kill |cRXP_ENEMY_Tombcaller Ganzaya|r.
.complete 66652,1 
.mob Tombcaller Ganzaya
step
.goto 2023,37.03,65.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r.
.complete 66652,2 
step
.goto 2023,39.05,66.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Zorig|r.
.turnin 66652 >>Turn in Return to Mender
.accept 66654 >>Accept Desecrator Annihilator
.accept 66655 >>Accept Reagents of De-Necromancy
.target Initiate Zorig
step
#completewith OhnahranPlainsClumpofSacredSoil
>>Kill the |cRXP_ENEMY_Risens|r.
*Loot them for the |T236946:0|t[|cRXP_LOOT_Intact Skull|r].
.complete 66655,1 
.mob Risen Bakar
.mob Risen Ohuna
step
#completewith OhnahranPlainsClumpofSacredSoil
>>Kill |cRXP_ENEMY_Centaurs|r.
*Loot them for the [|cRXP_LOOT_Hero Weapons|r].
.complete 66654,2 
.complete 66654,1 
.mob Nokhud Desecrator
.mob Ukhel Gravestirrer
step
#title Sacred Soil (1/6)
.goto 2023,36.88,64.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r.
.complete 66655,2,1 
step
#title Sacred Soil (2/6)
.goto 2023,35.92,64.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r.
.complete 66655,2,2 
step
#title Sacred Soil (3/6)
.goto 2023,35.38,65.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r.
.complete 66655,2,3 
step
#title Sacred Soil (4/6)
.goto 2023,34.45,65.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r.
.complete 66655,2,4 
step
#title Sacred Soil (5/6)
.goto 2023,34.33,67.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r.
.complete 66655,2,5 
step
#label OhnahranPlainsClumpofSacredSoil
#title Sacred Soil (6/6)
.goto 2023,35.07,67.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r.
.complete 66655,2 
step
#completewith RisenSkull
#hidewindow
#loop
.goto 2023,34.87,69.06,38,0
.goto 2023,36.43,67.85,38,0
.goto 2023,36.41,64.20,38,0
.goto 2023,33.06,67.29,38,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Rise|r.
*Loot them for the |T236946:0|t[|cRXP_LOOT_Intact Skull|r].
.complete 66655,1 
.mob Nokhud Desecrator
.mob Risen Bakar
.mob Risen Ohuna
.mob Ukhel Gravestirrer
step
>>Kill |cRXP_ENEMY_Centaurs|r.
*Loot them for the [|cRXP_LOOT_Hero Weapons|r].
.complete 66654,1 
.complete 66654,2 
.mob Nokhud Desecrator
.mob Ukhel Gravestirrer
step
#label RisenSkull
>>Kill the |cRXP_ENEMY_Rise|r.
*Loot them for the |T236946:0|t[|cRXP_LOOT_Intact Skull|r].
.complete 66655,1 
.mob Nokhud Desecrator
.mob Risen Bakar
.mob Risen Ohuna
.mob Ukhel Gravestirrer
step
.goto 2023,33.76,65.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Zorig|r.
.turnin 66655 >>Turn in Reagents of De-Necromancy
.turnin 66654 >>Turn in Desecrator Annihilator
.accept 69936 >>Accept Zambul, Head Vandal
.target Initiate Zorig
step
#title |cFFFCDC00NPC Patrols|r
#loop
.goto 2023,35.60,65.06,35,0
.goto 2023,36.83,67.88,35,0
.goto 2023,33.91,69.38,35,0
.goto 2023,34.13,66.12,35,0
>>Kill |cRXP_ENEMY_Overseer Zambul|r.
.complete 69936,1 
.mob Overseer Zambul
step
.goto 2023,33.76,65.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Zorig|r.
.turnin 69936 >>Turn in Zambul, Head Vandal
.accept 66656 >>Accept Definitely Eternal Slumber
.target Initiate Zorig
step
.goto 2023,31.2,69.02
#title |cFFFCDC00NPC Patrols|r
>>Kill |cRXP_ENEMY_Cathan the Determined|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Corpse|r.
.complete 66656,1 
.mob Cathan the Determined
step
#loop
.goto 2023,30.99,70.63,40,0
.goto 2023,32.51,71.37,40,0
.goto 2023,33.65,71.51,40,0
.goto 2023,33.37,69.74,40,0
.goto 2023,31.61,69.76,40,0
>>Kill |cRXP_ENEMY_Ganmat the Wise|r, |cRXP_ENEMY_Dihar the Unyielding|r and |cRXP_ENEMY_Zaphil the Defiant|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on their |cRXP_PICK_Corpses|r.
.complete 66656,2 
.complete 66656,3 
.complete 66656,4 
.mob Ganmat the Wise
.mob Dihar the Unyielding
.mob Zaphil the Defiant
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Zorig|r |cRXP_WARN_next to you|r.
.turnin 66656 >>Turn in Definitely Eternal Slumber
.accept 66657 >>Accept And Stay Dead!
.target Initiate Zorig
step
#completewith next
#label AndStayDead
.goto 2023,31.36,71.03,0,0
.goto 2023,31.81,70.21,10,0
>>Kill |cRXP_ENEMY_Tombcaller Arban|r.
.complete 66657,1 
.mob Tombcaller Arban
step
#completewith AndStayDead
#title Enter Tomb
.goto 2023,31.68,70.43,6 >>Enter the tomb
step
#requires AndStayDead
.goto 2023,31.36,71.03
>>Kill |cRXP_ENEMY_Tombcaller Arban|r.
.complete 66657,1 
.mob Tombcaller Arban
step
.goto 2023,31.16,71.05
#title |cFFFCDC00Follow the Arrow|r
.complete 66657,2 
step
.goto 2023,31.44,71.42
#title |cFFFCDC00Follow the Arrow|r
.complete 66657,3 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Zorig|r |cRXP_WARN_next to you|r.
.turnin 66657 >>Turn in And Stay Dead!
.target Initiate Zorig
step
.goto 2023,44.33,61.78
#title |cFFFCDC00Follow the Arrow|r
.complete 66224,1 
step
#completewith next
#label Boku's
.goto 2023,31.74,70.37,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Boku's Belongings|r.
.complete 66224,2 
step
#completewith Boku's
.goto 2023,44.55,61.94,1055 >>Leave the Tomb
step
#requires Boku's
.goto 2023,44.55,61.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Boku's Belongings|r.
.complete 66224,2 
.skipgossipid 56253
step
.goto 2023,46.35,63.15
#title |cFFFCDC00Follow the Arrow|r
.complete 66224,3 
step
.goto 2023,46.52,63.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unidentified Centaur|r.
>>Kill the incoming |cRXP_ENEMY_Centaurs|r.
.complete 66224,4 
.mob Nokhud Marauder
.skipgossipid 55390
step
.goto 2023,49.31,63.22
#title |cFFFCDC00Follow the Arrow|r
.complete 66224,5 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Boku|r and |cRXP_FRIENDLY_Tigari Khan|r.
.turnin 66224 >>Turn in Mystic Mystery
.goto 2023,49.31,63.22
.target +Initiate Boku
.accept 70195 >>Accept Taken By Storm
.accept 66225 >>Accept Toting Totems
.goto 2023,49.36,63.14
.target +Tigari Khan
step
#completewith next
>>Kill |cRXP_ENEMY_Centaurs|r.
*Loot them for the |T538576:0|t[|cRXP_LOOT_Bundle of Totems|r].
.complete 66225,1 
.mob Nokhud Mystic-Hunter
.mob Nokhud Marauder
step
.goto 2023,48.90,69.03
>>Kill |cRXP_ENEMY_Shela the Windbinder|r.
*Loot her for the |T1500873:0|t[|cRXP_LOOT_Ridgewater Retreat Orders|r].
.complete 70195,1 
.complete 70195,2 
.mob Shela the Windbinder
step
#loop
.goto 2023,49.55,67.38,25,0
.goto 2023,50.16,67.61,25,0
.goto 2023,50.7,66.48,25,0
.goto 2023,51.29,67.87,25,0
.goto 2023,48.8,66.91,25,0
>>Kill |cRXP_ENEMY_Centaurs|r.
*Loot them for the |T538576:0|t[|cRXP_LOOT_Bundle of Totems|r].
.complete 66225,1 
.mob Nokhud Mystic-Hunter
.mob Nokhud Marauder
step
.goto 2023,49.36,63.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigari Khan|r.
.turnin 66225 >>Turn in Toting Totems
.turnin 70195 >>Turn in Taken By Storm
.accept 66236 >>Accept Catching Wind
.target Tigari Khan
step
.goto 2023,56.26,75.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Radiya|r.
.turnin 65906 >>Turn in A Disgruntled Initiate
.accept 65901 >>Accept Sneaking Out
.target Initiate Radiya
step
#title Totems placed (1/3)
.goto 2023,56.67,76.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wind Totem|r.
.complete 65901,1,1 
step
#title Totems placed (2/3)
.goto 2023,57.36,76.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wind Totem|r.
.complete 65901,1,2 
step
#title Totems placed (3/3)
.goto 2023,57.00,75.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wind Totem|r.
.complete 65901,1 
step
.goto 2023,56.25,75.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Radiya|r.
.complete 65901,2 
.skipgossipid 55343
.target Initiate Radiya
step
.goto 2023,54.78,66.41
#title |cFFFCDC00Follow the Arrow|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Radiya|r.
.turnin 65901 >>Turn in Sneaking Out
.accept 65907 >>Accept Favorite Fruit
.target Initiate Radiya
step
.goto 2023,54.52,70.18
.goto 2023,54.55,71.09
.goto 2023,54,71.53
.goto 2023,53.57,71.18
.goto 2023,53.29,70.66
.goto 2023,53.8,70.3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r
.complete 65907,1 
step
.goto 2023,54.52,70.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r
.complete 65907,1,1 
step
.goto 2023,54.55,71.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r
.complete 65907,1,2 
step
.goto 2023,54,71.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r
.complete 65907,1,3 
step
.goto 2023,53.57,71.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r
.complete 65907,1,4 
step
.goto 2023,53.29,70.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r
.complete 65907,1,5 
step
.goto 2023,53.8,70.3
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r
.complete 65907,1,6 
step
#loop
.goto 2023,54.51,68.36,25,0
.goto 2023,54.47,66.27,25,0
.goto 2023,52.84,65.12,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hippos|r.
.complete 65907,2 
.use 192743
.mob Mudstomper Calf
.mob Lounging Mudstomper
step
.goto 2023,54.78,66.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Radiya|r.
.turnin 65907 >>Turn in Favorite Fruit
.accept 65770 >>Accept A Promise Is A Promise
.target Initiate Radiya
step
.goto 2023,54.78,66.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Radiya|r.
.complete 65770,1 
.skipgossipid 55344
step
.goto 2023,52.98,63.88
#title |cFFFCDC00Follow the Arrow|r
.complete 65770,2 
step
.goto 2023,51.47,62.63,10,0
.goto 2023,52.02,63.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Godoloto|r.
.turnin 65770 >>Turn in A Promise Is A Promise
.target Godoloto






step
.goto 2023,58.11,68.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Boku|r.
.turnin 66236 >>Turn in Catching Wind
.accept 66242 >>Accept Weather Control
.accept 66256 >>Accept Eagle-itarian
.accept 66257 >>Accept Fowl Sorcery
.target Initiate Boku
step
#completewith OhnahranPlainsChildWagons
>>Kill |cRXP_ENEMY_Primalists|r, |cRXP_ENEMY_Essences|r, and |cRXP_ENEMY_Initiates|r.
.goto 2023,59.95,66.08,0,0
.complete 66256,2 
.complete 66242,1 
.complete 66242,2 
.mob Primalist Instructor
.mob Stormcaller Initiate
.mob Stormbound Essence
step
.goto 2023,58.07,67.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66256,1,1 
.complete 66257,1,1 
step
.goto 2023,58.67,64.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66256,1,2 
step
.goto 2023,58.81,61.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totems|r.
.complete 66256,1,3 
.complete 66257,1,3 
step
.goto 2023,59.66,64.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66256,1,4 
step
.goto 2023,59.39,64.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66256,1,5 
step
.goto 2023,59.22,65.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totems|r.
.complete 66257,1,3 
step
.goto 2023,59.88,66.94
>>Kill |cRXP_ENEMY_Prozela Galeshot|r
.accept 69968 >>Accept Prozela Galeshot
.complete 69968,1 
.turnin 69968 >>Turn in Prozela Galeshot
.mob Prozela Galeshot
step
.goto 2023,61.26,67.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66256,1,5 
step
.goto 2023,60.77,66.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66256,1,6 
step
#label OhnahranPlainsChildWagons
.goto 2023,61.76,66.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totem|r.
.complete 66257,1,4 
step
#loop
.goto 2023,61.54,65.23,25,0
.goto 2023,59.64,66.74,25,0
.goto 2023,61.48,67.45,25,0
.goto 2023,58.61,68.89,25,0
>>Kill |cRXP_ENEMY_Primalists|r, |cRXP_ENEMY_Essences|r, and |cRXP_ENEMY_Initiates|r.
.complete 66256,2 
.complete 66242,1 
.complete 66242,2 
step
.goto 2023,60.66,63.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Boku|r.
.turnin 66242 >>Turn in Weather Control
.turnin 66256 >>Turn in Eagle-itarian
.turnin 66257 >>Turn in Fowl Sorcery
.accept 66258 >>Accept Oh No, Ohn'ahra!
.target Initiate Boku
step
#loop
.goto 2023,60.83,65.41,25,0
.goto 2023,59.91,65.62,25,0
.goto 2023,60.42,64.06,25,0
>>Kill |cRXP_ENEMY_Elementals|r and |cRXP_ENEMY_Centaurs|r.
.complete 66258,1 
.timer 5,RP
.mob Agitated Initiate
.mob Agitated Goliath
.mob Agitated Stormsmith
step
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66258,2 
step
.goto 2023,61.42,62.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Initiate Boku|r.
.turnin 66258 >>Turn in Oh No, Ohn'ahra!
.accept 66259 >>Accept A Storm of Ill Tidings
.target Initiate Boku
step
.goto 2023,60.00,37.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.complete 66259,1 
.skipgossipid 56420
.target Khanam Matra Sarest
step
.goto 2023,60.00,37.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.turnin 66259 >>Turn in A Storm of Ill Tidings
.accept 66327 >>Accept Chasing the Wind
.timer 48.7,Report Duration
.target Khanam Matra Sarest
step
.goto 2023,60.01,37.48
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 66327,1 
step
#completewith next
#label Emberwatch
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to to |cRXP_FRIENDLY_Telemancer Aerilyn|r.
.turnin 70337 >>Turn in Emberwatch
.accept 65890 >>Accept The Nelthazan Ruins
.target Telemancer Aerilyn
step
#completewith Emberwatch
.goto 2023,60.01,37.48
.gossipoption 56419 >>Talk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
step
#requires Emberwatch
.goto 2023,66.00,25.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to to |cRXP_FRIENDLY_Telemancer Aerilyn|r.
.turnin 70337 >>Turn in Emberwatch
.accept 65890 >>Accept The Nelthazan Ruins
.target Telemancer Aerilyn
step
.goto 2023,64.00,18.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Skyscribe Adenedal|r.
.turnin 65890 >>Turn in The Nelthazan Ruins
.accept 65891 >>Accept Tools of the Tirade
.accept 65893 >>Accept The Relic Inquiry
.target Skyscribe Adenedal
step
#completewith OhnahranPlainsToolsoftheTirade
.goto 2023,63.03,17.67,0,0
>>Kill |cRXP_ENEMY_Dragonkins|r.
*Loot them for the |T442739:0|t[|cRXP_LOOT_Fragments|r].
.complete 65893,1 
.complete 65892,1 
.mob Sundered Runebinder
.mob Sundered Enforcer
.mob Tarasek Laborer
step
#title Tool Deployed (1/5)
.goto 2023,64.37,15.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r.
.complete 65891,1,1 
step
#title Tool Deployed (2/5)
.goto 2023,64.1,14.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r.
.complete 65891,1,2 
step
#title Tool Deployed (3/5)
.goto 2023,63.93,14.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r.
.complete 65891,1,3 
step
#title Tool Deployed (4/5)
.goto 2023,63.15,14.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r.
.complete 65891,1,4 
step
#label OhnahranPlainsToolsoftheTirade
#title Tool Deployed (5/5)
.goto 2023,63.43,16.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rubble|r.
.complete 65891,1 
step
#loop
.goto 2023,63.01,18.13,25,0
.goto 2023,62.18,17.35,25,0
.goto 2023,63.43,14.62,25,0
.goto 2023,64.34,14.76,25,0
.goto 2023,64.06,17,25,0
>>Kill |cRXP_ENEMY_Dragonkins|r.
*Loot them for the |T442739:0|t[|cRXP_LOOT_Fragments|r].
.complete 65893,1 
.complete 65892,1 
.mob Sundered Runebinder
.mob Sundered Enforcer
.mob Tarasek Laborer
step
.goto 2023,64.01,18.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Skyscribe Adenedal|r.
.turnin -65891 >>Turn in Tools of the Tirade
.turnin -65893 >>Turn in The Relic Inquiry
.target Skyscribe Adenadal
step
.goto 2023,60.00,37.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.complete 66327,2 
.target Khanam Matra Sarest
step
.goto 2023,73.04,40.54
#title |cFFFCDC00Follow the Arrow|r
.complete 66327,4 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.goto 2023,73.03,40.58
.turnin 66327 >>Turn in Chasing the Wind
.accept 70244 >>Accept Nokhud Can Come of This
.target Khanam Matra Sarest
step
#loop
.goto 2023,74.91,41.13,20,0
.goto 2023,74.79,39.48,25,0
.goto 2023,76.00,41.59,20,0
.goto 2023,74.91,41.13,25,0
>>Kill the |cRXP_ENEMY_Centaurs|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Survivors|r.
.complete 70244,1 
.mob Nokhud Stormlasher
.mob Nokhud Raider
.mob Nokhud Tempest
.mob Nokhud Warhound
.mob Nokhud Scavenger
step
.goto 2023,76.14,40.87
>>Kill |cRXP_ENEMY_Warmonger Kharad|r.
.complete 70244,2 
.mob Warmonger Kharad
step
.goto 2023,76.70,40.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
*|cRXP_WARN_If you can't turn in the quest, relog|r.
.turnin 70244 >>Turn in Nokhud Can Come of This
.accept 66329 >>Accept Blowing of the Horn
.target Khanam Matra Sarest
step
.goto 2023,76.70,40.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.complete 66329,1 
.skipgossipid 54892
.target Khanam Matra Sarest
step
.goto 2023,76.70,40.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.turnin 66329 >>Turn in Blowing of the Horn
.accept 66328 >>Accept Green Dragon Down
.target Khanam Matra Sarest
step
.goto 2023,72.34,50.33
#title |cFFFCDC00Follow the Arrow|r
.complete 66328,1 
step
.goto 2023,72.34,50.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.complete 66328,2 
.timer 50,Listen
.target Khanam Matra Sarest
.skipgossipid 56207
step
.goto 2023,81.03,58.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sentinel Olekk|r and |cRXP_FRIENDLY_Scout Watu|r.
.turnin -65837 >>Turn in Trouble In The Pines
.accept 66681 >>Accept Tempests Abound
.accept 66680 >>Accept Counting Sheep
.target Sentinel Olekk
.target Scout Watu
step
.goto 2023,80.64,58.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sondo|r and buy 1 |T350570:0|t[Diced Meat]
.buy 193890,1 
.complete 66680,1 
.skipgossipid 55373
.target Sondo
step
.goto 2023,81.03,59.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wish|r.
.complete 66680,2 
.skipgossipid 55180
.target Wish
step
#completewith OhnahranPlainsCountingSheep
>>Kill |cRXP_ENEMY_Stags|r, |cRXP_ENEMY_Does|r and |cRXP_ENEMY_Vultures|r.
*Loot it for |T4554450:0|t[|cRXP_LOOT_Stormtouched Shards|r].
.complete 66681,1 
.accept 66689 >>Accept More Than a Rock
.mob Pinehoof Doe
.mob Insatiable Vulture
.mob Craggy Stag
step
#title Argali Saved (1/5)
.goto 2023,82.1,63.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goat|r.
.complete 66680,3,1 
.use 193892
.target Lost Argali
step
#title Argali Saved (2/5)
.goto 2023,83.51,64.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goat|r.
.complete 66680,3,2 
.use 193892
step
#title Argali Saved (3/5)
.goto 2023,81.84,66.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goat|r.
.complete 66680,3,3 
.use 193892
step
#title Argali Saved (4/5)
.goto 2023,81.57,63.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goat|r.
.complete 66680,3,4 
.use 193892
step
#label OhnahranPlainsCountingSheep
#title Argali Saved (5/5)
.goto 2023,82.45,64.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goat|r.
.complete 66680,3 
.use 193892
step
#loop
.goto 2023,83.3,66.04,30,0
.goto 2023,81.84,64.22,30,0
.goto 2023,80.2,64.53,30,0
.goto 2023,79.41,63.34,30,0
>>Kill |cRXP_ENEMY_Stags|r, |cRXP_ENEMY_Does|r and |cRXP_ENEMY_Vultures|r.
*Loot it for |T4554450:0|t[|cRXP_LOOT_Stormtouched Shards|r].
.complete 66681,1 
.accept 66689 >>Accept More Than a Rock
.mob Pinehoof Doe
.mob Insatiable Vulture
.mob Craggy Stag
step
.goto 2023,81.03,58.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Watu|r.
.turnin 66680 >>Turn in Counting Sheep
.turnin 66681 >>Turn in Tempests Abound
.turnin 66689 >>Turn in More Than A Rock
.accept 66683 >>Accept Last Resort Analysis
.target Scout Watu
step
.goto 2023,80.96,59.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Basran|r.
.complete 66683,1 
.skipgossipid 55375
.target Basran
step
.goto 2023,80.64,58.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sondo|r.
.complete 66683,3 
.skipgossipid 55374
.target Sondo
step
.goto 2023,80.44,57.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nakeena|r.
.complete 66683,2 
.skipgossipid 55376
.target Nakeena
step
.goto 2023,81.03,58.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Watu|r.
.turnin 66683 >>Turn in Last Resort Analysis
.accept 65836 >>Accept Show of Storm
.target Scout Watu
step
.goto 2023,83.62,60.66
#title |cFFFCDC00Follow the Arrow|r
.complete 65836,1 
step
.goto 2023,83.99,60.79
>>Kill |cRXP_ENEMY_Stormed Blackpaw|r.
.complete 65836,2 
.mob Stormed Blackpaw
step
.goto 2023,83.98,60.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Watu|r after a roleplay.
.turnin 65836 >>Turn in Show of Storm
.accept 66684 >>Accept Storm Chasing
.target Scout Watu
step
.goto 2023,85.03,64.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r.
.complete 66684,1 
step
#completewith next
#label Storm Chasing
.goto 2023,84.84,63.32,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Watu|r.
.turnin 66684 >>Turn in Storm Chasing
.target Scout Watu
step
#completewith Storm Chasing
.goto 2023,80.85,58.96,377 >>Leave the Cave
step
#requires Storm Chasing
.goto 2023,80.85,58.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Watu|r.
.turnin 66684 >>Turn in Storm Chasing
.target Scout Watu
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r and |cRXP_FRIENDLY_Merithra|r.
.turnin 66328 >>Turn in Green Dragon Down
.goto 2023,72.35,50.33
.target +Khanam Matra Sarest
.accept 66344 >>Accept With the Wind at Our Backs
.goto 2023,72.46,50.77
.target +Merithra
step
.goto 2023,72.31,50.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gerithus|r.
.complete 66344,1 
.skipgossipid 54859
.target Gerithus
step
#completewith next
#label Our Backs
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.turnin 66344 >>Turn in With the Wind at Our Backs
.accept 70220 >>Accept Shady Sanctuary
.target Merithra
step
#completewith Our Backs
.exitvehicle >>|cRXP_WARN_Leave the vehicle|r
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#requires Our Backs
.goto 2023,28.26,57.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.turnin 66344 >>Turn in With the Wind at Our Backs
.accept 70220 >>Accept Shady Sanctuary
.target Merithra
step
.goto 2023,29.08,55.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard-Captain Alowen|r.
.complete 70220,1 
.skipgossipid 56367
.target Guard-Captain Alowen
step
.goto 2023,30.19,55.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Isidra|r.
.complete 70220,3 
.skipgossipid 56204
.target Isidra the Mender
step
.goto 2023,29.83,57.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sariosa|r.
.complete 70220,2 
.skipgossipid 56235
.target Sariosa
step
.goto 2023,30.02,60.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Viranikus|r.
.complete 70220,5 
.skipgossipid 56205
.target Viranikus
step
.goto 2023,28.26,57.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.turnin 70220 >>Turn in Shady Sanctuary
.accept 66331 >>Accept The Primalist Front
.target Merithra
step
.goto 2023,27.56,46.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belika|r.
.complete 66331,3 
.skipgossipid 55238
.target Belika
step
.goto 2023,25.71,44.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boku|r.
.complete 66331,2 
.skipgossipid 55239
.target Boku
step
#completewith next
#label report heard
#hidewindow
.complete 66331,4 
.target Ohn Seshteng
step
#completewith report heard
.goto 2023,26.19,40.07
.gossipoption 55240 >>Talk to |cRXP_FRIENDLY_Merithra|r.
step
#requires report heard
>>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.complete 66331,4 
.macro Leave Vehicle,6656430 >>/leavevehicle
step
.goto 2023,25.64,40.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r
.complete 66331,5 
.skipgossipid 55241
.target Merithra
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r and |cRXP_FRIENDLY_Merithra|r.
.turnin 66331 >>Turn in The Primalist Front
.goto 2023,25.67,40.43
.target +Khanam Matra Sarest
.accept 66333 >>Accept Justice for Solethus
.goto 2023,25.63,40.52
.target +Merithra
step
#completewith OhnahranPlainsDeconstructAdditionalPylons
>>Kill |cRXP_ENEMY_Centaurs|r, |cRXP_ENEMY_Primalists|r, and |cRXP_ENEMY_Elementals|r.
.complete 66421,1 
.mob Nokhud Warmonger
.mob Nokhud Skirmisher
.mob Nokhud Spearman
.mob Primalist Stormsurger
.mob Invading Storm Elemental
.mob Invading Stormling
.mob Stormbound Colossus
step
#completewith OhnahranPlainsJusticeForSelthus
.goto 2023,24.67,41.17,0
.goto 2023,24.03,40.74,0
.goto 2023,24.21,39.85,0
.goto 2023,24.90,39.76,0
.goto 2023,24.41,38.42,0
.goto 2023,25.45,37.64,0
>>Kill |cRXP_ENEMY_Nokhud Warmonger|r.
*|cRXP_WARN_Possible Warmonger spawn points are marked on your (Mini)map|r.
.complete 66333,1 
.mob Nokhud Warmonger
step
.goto 2023,24.81,39.89
#title Ballista destroyed (1/3)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ballista|r.
.complete 66333,2,1 
step
.goto 2023,24.36,38.48
#title Ballista (2/3)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ballista|r.
.complete 66333,2,2 
step
#label OhnahranPlainsJusticeForSelthus
.goto 2023,25.44,37.74
#title Ballista (3/3)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ballista|r.
.complete 66333,2 
step
#loop
.goto 2023,24.56,40.41,30,0
.goto 2023,24.06,40.75,30,0
.goto 2023,24.20,37.65,30,0
.goto 2023,25.47,37.86,30,0
.goto 2023,24.56,40.41,30,0
.goto 2023,24.06,40.75,30,0
.goto 2023,24.20,37.65,30,0
.goto 2023,25.47,37.86,30,0
.goto 2023,24.56,40.41,30,0
>>Kill the |cRXP_ENEMY_Nokhud Warmonger|r.
.complete 66333,1 
.mob Nokhud Warmonger
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r |cRXP_WARN_next to you|r.
.turnin 66333 >>Turn in Justice for Solethus
.accept 66335 >>Accept Deconstruct Additional Pylons
.accept 66784 >>Accept Starve the Storm
.target Khanam Matra Sarest
step
.goto 2023,23.93,39.47
>>Use the |cRXP_WARN_[ExtraActionButton]|r next to the pylon.
.complete 66335,1 
step
#completewith next
#label Storm Corridor
>>Kill |cRXP_ENEMY_Primalist Storm-Summoner|r in front of the portal.
.complete 66784,1 
.mob Primalist Storm-Summoner
step
#completewith Storm Corridor
.goto 2023,24.76,35.09,60 >>Enter the Cave
step
#requires Storm Corridor
.goto 2023,24.76,35.09
>>Kill |cRXP_ENEMY_Primalist Storm-Summoner|r in front of the portal.
.complete 66784,1 
.mob Primalist Storm-Summoner
step
#completewith next
#label Pylon marked1
.goto 2023,23.97,35.89,10,0
>>Use the |cRXP_WARN_[ExtraActionButton]|r next to the pylon.
.complete 66335,2 
step
#completewith Pylon marked1
.goto 2023,23.11,37.53,105 >>Leave the cave
step
#requires Pylon marked1
.goto 2023,23.11,37.53
>>Use the |cRXP_WARN_[ExtraActionButton]|r next to the pylon.
.complete 66335,2 
step
#label OhnahranPlainsDeconstructAdditionalPylons
.goto 2023,21.43,37.53
>>Use the |cRXP_WARN_[ExtraActionButton]|r next to the pylon.
.complete 66335,3 
step
#loop
.goto 2023,25.71,38.33,40,0
.goto 2023,23.93,39.47,40,0
.goto 2023,23.11,37.53,40,0
.goto 2023,21.43,37.53,40,0
>>Kill the |cRXP_ENEMY_Nokhud|r, |cRXP_ENEMY_Primalists|r, and |cRXP_ENEMY_Storm Elementals|r in the area.
.complete 66421,1 
.mob Nokhud Warmonger
.mob Nokhud Skirmisher
.mob Nokhud Spearman
.mob Primalist Stormsurger
.mob Invading Storm Elemental
.mob Invading Stormling
.mob Stormbound Colossus
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r |cRXP_WARN_next to you|r.
.turnin 66335 >>Turn in Deconstruct Additional Pylons
.turnin 66784 >>Turn in Starve the Storm
.accept 66337 >>Accept Stormbreaker
.target Khanam Matra Sarest
step
.goto 2023,22.37,39.81
>>Kill |cRXP_ENEMY_Stormbound Proto-Drake|r and |cRXP_ENEMY_Koroleth|r.
.complete 66337,1 
.mob Stormbound Proto-Drake
.mob Koroleth
step
#completewith next
#label Gerithus
>>Leave the Vehicle
.complete 66337,2 
step
#completewith Gerithus
.goto 2023,22.92,40.21
.gossipoption 63840 >>Talk to |cRXP_FRIENDLY_Gerithus|r.
.target Gerithus
step
#requires Gerithus
.goto 2023,22.92,40.23
>>Press the Macro to leave the vehicle. It's in the "Active Items" window.
.complete 66337,2 
.macro Leave Vehicle,6656430 >>/leavevehicle
step
.goto 2023,25.65,48.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.turnin 66337 >>Turn in Stormbreaker
.accept 66336 >>Accept The Isle of Emerald
.target Merithra
step
.goto 2023,22.14,50.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.turnin 66336 >>Turn in The Isle of Emerald
.accept 66783 >>Accept Renewal of Vows
.target Merithra
step
#completewith next
#label Sansok Khans offering1
#hidewindow
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.complete 66783,1 
step
#completewith Sansok Khans offering1
.goto 2023,22.26,50.91
.gossipoption 54952 >>Talk to |cRXP_FRIENDLY_Sansok Khan|r.
step
#requires Sansok Khans offering1
#completewith next
#label Sansok Khans offering2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.complete 66783,1 
step
#requires Sansok Khans offering1
#completewith Sansok Khans offering2
.goto 2023,22.26,50.91
.cast 375466 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r.
step
#requires Sansok Khans offering2
.goto 2023,22.14,50.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.complete 66783,1 
.skipgossipid 56430
.target Merithra
step
#completewith next
#label TigariKhans
#hidewindow
.complete 66783,2 
step
#completewith TigariKhans
.goto 2023,22.36,51.05
.gossipoption 54951 >>Talk to |cRXP_FRIENDLY_Tigari Khan|r.
.target Tigari Khan
step
#requires TigariKhans
#completewith next
#label TigariKhans2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.complete 66783,2 
.target Merithra
step
#requires TigariKhans
#completewith TigariKhans2
.goto 2023,22.34,51.05
.cast 375472 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feather|r.
step
#requires TigariKhans2
.goto 2023,22.14,50.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.complete 66783,2 
.skipgossipid 56431
.target Merithra
step
#completewith next
#label KhanamMatras
#hidewindow
.complete 66783,3 
step
#completewith KhanamMatras
.goto 2023,22.34,50.96
.gossipoption 54948 >>Talk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.target Khanam Matra Sarest
.timer 5,Roleplay Duration
step
#requires KhanamMatras
#completewith next
#label KhanamMatras2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.complete 66783,3 
step
#requires KhanamMatras
#completewith KhanamMatras2
.goto 2023,22.34,50.96
.cast 375470 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Horn|r
step
#requires KhanamMatras2
.goto 2023,22.14,50.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.complete 66783,3 
.skipgossipid 56432
.target Merithra
step
#completewith next
#label OhnahranPlainsRenewalofVowsB
.goto 2023,22.33,50.96,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.complete 66783,4 
.target Khanam Matra Sarest
step
#completewith OhnahranPlainsRenewalofVowsB
.goto 2023,22.14,50.98
.cast 391289 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Everblooming Soil|r.
step
#requires OhnahranPlainsRenewalofVowsB
#label OhnahranPlainsRenewalofVows
.goto 2023,22.33,50.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khanam Matra Sarest|r.
.complete 66783,4 
.target Khanam Matra Sarest
.skipgossipid 63841
step
.goto 2023,22.14,50.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merithra|r.
.turnin 66783 >>Turn in Renewal of Vows
.accept 66340 >>Accept Into the Azure
.target Merithra
step
.goto 2023,71.65,80.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Masud the Wise|r.
.turnin 66340 >>Turn in Into the Azure
.turnin 72268 >>Turn in Azure Span
.accept 65686 >>Accept To the Azure Span
.achievementComplete 15394,1
.achievementComplete 16336,1
.achievementComplete 16363,1
.achievementComplete 16334,1
.target Masud the Wise
step
.goto 2023,71.65,80.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Masud the Wise|r.
.turnin 66340 >>Turn in Into the Azure
.accept 65686 >>Accept To the Azure Span
.achievementIncomplete 15394,0
.achievementIncomplete 16336,0
.achievementIncomplete 16363,0
.achievementIncomplete 16334,0
.target Masud the Wise
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) The Azure Span Midnight
#internal
step << !Evoker
.goto 2024,41.44,35.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Glania of the Blessed Ones|r.
.turnin 65686 >>Turn in To the Azure Span
.accept 66228 >>Accept Camp Antonidas
.target Glania of the Blessed Ones
step << Evoker
.goto 2024,41.44,35.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Glania of the Blessed Ones|r and |cRXP_FRIENDLY_Scalecommander Emberthal|r.
.turnin 65686 >>Turn in To the Azure Span
.accept 70746 >>Accept Shades of Blue
.target Glania of the Blessed Ones
.target Scalecommander Emberthal
step
.goto 2024,41.23,35.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miva Star-Eye|r.
.accept 67174 >>Accept Arcane Detection
.target Miva Star-Eye
step
.goto 2024,41.39,35.70
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flask|r.
.complete 67174,1 
step
.goto 2024,41.41,35.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Teapot|r.
.complete 67174,2 
step
.goto 2024,41.42,36.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shala|r.
.accept 67177 >>Accept WANTED: Gorger
.target Shala
step
.goto 2024,41.23,36.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Toy Boat|r.
.complete 67174,3 
step
.goto 2024,41.22,35.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miva Star-Eye|r.
.turnin 67174 >>Turn in Arcane Detection
.accept 67175 >>Accept How To Stop An Exploding Toy Boat
.target Miva Star-Eye
step
#completewith next
#label Julk
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 67175,1 
step
#completewith Julk
.goto 2024,41.21,35.86
.gossipoption 55247 >>Talk to |cRXP_FRIENDLY_Julk|r.
.timer 15,RP
.target Julk
step
#requires Julk
step
.goto 2024,39.66,37.24
>>Kill |cRXP_ENEMY_Gorger|r.
*Loot him for the |T237398:0|t[|cRXP_LOOT_Curved Horns|r].
.complete 67177,1 
.mob Gorger
step
.goto 2024,41.2,35.92
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 67175,1 
.target Julk
step
.goto 2024,41.19,35.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wand|r.
.complete 67175,2 
step
.goto 2024,40.59,36.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Toy Boat|r.
.complete 67175,3 
step
.goto 2024,41.21,35.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miva Star-Eye|r.
.turnin 67175 >>Turn in How To Stop An Exploding Toy Boat
.target Miva Star-Eye
step
.goto 2024,41.42,36.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shala|r.
.turnin 67177 >>Turn in WANTED: Gorger
.target Shala
step << Dracthyr

.goto 2024,45.00,41.00
>>|cRXP_WARN_Follow the arrow|r to |cRXP_FRIENDLY_Emberthal|r.
.complete 70746,1 
step << Dracthyr
.goto 2024,45.00,41.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scalecommander Emberthal|r.
.turnin 70746 >>Turn in Shades of Blue
.target Scalecommander Emberthal
step << Dracthyr

.goto 2024,45.65,41.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telash Greywing|r.
.accept 70747 >>Accept The Azure Wizard
.target Telash Greywing
step << Dracthyr
.goto 2024,46.63,40.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.complete 70747,1 
.target Archmage Khadgar
.skipgossip 192091,1
step << Dracthyr
.goto 2024,46.63,40.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 70747 >>Turn in The Azure Wizard
.target Archmage Khadgar
step << !Dracthyr
.goto 2024,46.64,40.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noriko the All-Remembering|r.
.turnin 66228 >>Turn in Camp Antonidas
.target Noriko the All-Remembering
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noriko the All-Remembering|r and |cRXP_FRIENDLY_Althanus|r.
.accept 67033 >>Accept Assemble the Defenses
.goto 2024,46.69,39.77
.target +Noriko the All-Remembering
.accept 67035 >>Accept Preservation of Knowledge
.goto 2024,46.68,39.73
.target +Althanus
step
#title |T1041232:0:0|tDevice (1/3)
.goto 2024,46.15,39.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Broken Arcane Device|r.
.complete 67033,1,1 
step
#title |T1041232:0:0|tDevice (1/3)
.goto 2024,46.13,39.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 67035,1,1 
step
#title |T1499566:0:0|tTome (2/4)
.goto 2024,45.73,39.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 67035,1,2 
step
#title |T1499566:0:0|tTome (3/4)
.goto 2024,46.03,39.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 67035,1,3 
step
#title |T1041232:0:0|tDevice (2/3)
.goto 2024,45.86,40.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Broken Arcane Device|r.
.complete 67033,1,2 
step
#title |T1499566:0:0|tTome (4/4) + |T1041232:0:0|tDevice (3/3)
.goto 2024,46.07,40.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Discarded Book|r and |cRXP_PICK_Broken Arcane Device|r.
.complete 67035,1 
.complete 67033,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noriko the All-Remembering|r and |cRXP_FRIENDLY_Althanus|r.
.turnin 67033 >>Turn in Assemble the Defenses
.goto 2024,46.68,39.74
.target +Noriko the All-Remembering
.turnin 67035 >>Turn in Preservation of Knowledge
.accept 67036 >>Accept Wrath of the Kirin Tor
.goto 2024,46.69,39.77
.target +Althanus
step
#completewith next
#label PrimalistArmyRepelled
>>Use |T429383:0:0|t[Arcane Blast] (1) to kill all |cRXP_ENEMY_Proto-Drakes|r and |T132309:0|t[Arcane Stasis] (2) to reduce their momentum.
*|cRXP_WARN_If you manually exit the Arcane Blaster, re-enter and repeat the event until you are thrown out|r.
.complete 67036,1 
step
#completewith PrimalistArmyRepelled
.goto 2024,46.32,38.85
.vehicle 192331 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Blaster|r.
step
#requires PrimalistArmyRepelled
.goto 2024,46.32,38.85
>>Use |T429383:0:0|t[Arcane Blast] (1) to kill all |cRXP_ENEMY_Proto-Drakes|r and |T132309:0|t[Arcane Stasis] (2) to reduce their momentum.
*|cRXP_WARN_If you manually exit the Arcane Blaster, re-enter and repeat the event until you are thrown out|r.
.complete 67036,1 
step
.goto 2024,46.64,40.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noriko the All-Remembering|r.
.turnin 67036 >>Turn in Wrath of the Kirin Tor
.target Noriko the All-Remembering
step
.goto 2024,46.63,40.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.accept 65688 >>Accept Meeting Kalecgos
.target Archmage Khadgar
step
#completewith next
#label BagOfHelpfulGoods
.goto 2024,45.95,38.90,0,0
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 65688,1 
step
#completewith BagOfHelpfulGoods
.goto 2024,45.99,38.79
.gossipoption 55328 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.timer 8,Roleplay Duration
step
#requires BagOfHelpfulGoods
.goto 2024,45.95,38.90
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 65688,1 
step
.goto 2024,45.95,38.90
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r.
.complete 65688,2 
step
.goto 2024,46.17,39.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_WANTED: Poster|r.
.accept 66488 >>Accept WANTED: Frigellus
step
#completewith next
#label Meeting Kalecgos
.goto 2024,41.01,55.04,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65688 >>Turn in Meeting Kalecgos
.accept 65689 >>Accept The Many Images of Kalecgos
.disablecheckbox
.target Kalecgos
step
#completewith Meeting Kalecgos
.goto 2024,40.92,55.00,10 >>Enter the House
step
#requires Meeting Kalecgos
.goto 2024,40.92,55.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65688 >>Turn in Meeting Kalecgos
.accept 65689 >>Accept The Many Images of Kalecgos
.target Kalecgos
step
.goto 2024,40.74,59.04
#title |cFFFCDC00Follow the Arrow|r
.complete 65689,2 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65689 >>Turn in The Many Images of Kalecgos
.accept 65702 >>Accept Driven Mad
.goto 2024,40.74,59.04
.target +Kalecgos
.accept 65709 >>Accept Arcane Pruning
.goto 2024,40.69,59.10
.target +Kalecgos
step
>>Use the |cRXP_WARN_[ExtraActionButton]|r and wait.
.complete 65709,1 
.use 191953
step
#completewith North arcane field
>>Kill |cRXP_ENEMY_Elementals|r.
*Loot them for the |T236222:0|t[|cRXP_LOOT_Unstable Arcana|r].
.complete 65702,1 
.mob Destabilized Elemental
.mob Uncontrolled Guardian
.mob Unbound Attendant
step
.goto 2024,41.18,62.26
>>Use the |T1379242:0:0|t[Ley Scepter] inside the arcane field.
.complete 65709,3 
.use 191952
step
#label North arcane field
.goto 2024,39.6,60.06
>>Use the |T1379242:0:0|t[Ley Scepter] inside the arcane field.
.complete 65709,2 
.use 191952
step
#completewith next
#label ForgottenCreationSlain
>>Kill the |cRXP_ENEMY_Forgotten Creation|r.
.accept 69864 >>Accept Forgotten Creation
.complete 69864,1 
.turnin 69864 >>Turn in Forgotten Creation
.goto 2024,38.18,59.03,0,0
.mob Forgotten Creation
step
#completewith ForgottenCreationSlain
#title Fly up
.goto 2024,38.57,59.68,10,0
.goto 2024,38.19,59.04,60 >>Enter the building.
step
#requires ForgottenCreationSlain
.goto 2024,38.19,59.04
.accept 69864 >>Accept Forgotten Creation
.complete 69864,1 
.turnin 69864 >>Turn in Forgotten Creation
step
#loop
.goto 2024,39.93,59.25,30,0
.goto 2024,39.95,60.09,30,0
.goto 2024,39.55,60.22,30,0
.goto 2024,40.2,61.38,30,0
.goto 2024,40.89,60.83,30,0
.goto 2024,40.64,59.77,30,0
.goto 2024,41.74,61.93,30,0
.goto 2024,40.79,63.08,30,0
>>Kill |cRXP_ENEMY_Elementals|r.
*Loot them for the |T236222:0|t[|cRXP_LOOT_Unstable Arcana|r].
.complete 65702,1 
.mob Destabilized Elemental
.mob Uncontrolled Guardian
.mob Unbound Attendant
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65709 >>Turn in Arcane Pruning
.goto 2024,40.69,59.10
.target +Kalecgos
.turnin 65702 >>Turn in Driven Mad
.accept 65852 >>Accept Straight to the Top
.goto 2024,40.74,59.04
.target +Kalecgos
step
.goto 2024,39.61,60.19
>>Use the |T133622:0:0|t[Bag of Helpful Goods] inside the aura.
.complete 65852,1 
.use 191978
step
.goto 2024,39.96,61.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.complete 65852,2 
.turnin 65852 >>Turn in Straight to the Top
.accept 65751 >>Accept Platform Adjustments
.accept 65752 >>Accept Arcane Annoyances
.target Kalecgos
step
#completewith PlatformAdjustments
.goto 2024,39.91,61.66,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wyrms|r to pull them towards you.
*Kill |cRXP_ENEMY_Wyrms|r
.complete 65752,1 
.use 194891
.mob Feasting Wyrm
step
#title Energy (1/3)
.goto 2024,40.23,62.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unstable Arcane Energy|r.
.complete 65751,1,1 
step
#title Energy (2/3)
.goto 2024,39.58,62.72
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unstable Arcane Energy|r.
.complete 65751,1,2 
step
#label PlatformAdjustments
#title Energy (3/3)
.goto 2024,39.51,61.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unstable Arcane Energy|r.
.complete 65751,1,3 
step
#loop
.goto 2024,39.93,61.57,10,0
.goto 2024,39.93,61.61,30,0
.goto 2024,39.97,62.58,30,0
.goto 2024,39.31,62.11,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wyrms|r to pull them down.
*Kill |cRXP_ENEMY_Wyrms|r
.complete 65752,1 
.use 194891
.mob Feasting Wyrm
step
.goto 2024,39.97,61.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65751 >>Turn in Platform Adjustments
.turnin 65752 >>Turn in Arcane Annoyances
.accept 65854 >>Accept Reclaiming the Oathstone
.target Kalecgos
step
.goto 2024,39.44,63.18
#title |cFFFCDC00Fly down|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.complete 65854,1 
.skipgossipid 54821
.target Kalecgos
step
.goto 2024,39.48,63.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sindragosa|r.
.turnin 65854 >>Turn in Reclaiming the Oathstone
.accept 65855 >>Accept Aiding Azure Span
.target Sindragosa

















step
.goto 2024,46.64,40.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noriko the All-Remembering|r.
.turnin 65855 >>Turn in Aiding Azure Span
.accept 66699 >>Accept Ask the Locals
.accept 69904 >>Accept Suspiciously Quiet
.target Noriko the All-Remembering
step
.goto 2024,47.67,40.26
#title |cFFFCDC00Follow the Arrow|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Scrumpy|r.
.complete 69904,1 
.target Apprentice Scrumpy
.skipgossip
step
.goto 2024,47.67,40.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Scrumpy|r.
.turnin 69904 >>Turn in Suspiciously Quiet
.accept 66500 >>Accept Ways of Seeing
.target Apprentice Scrumpy
step
.goto 2024,47.77,39.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lingering Image|r.
.complete 66500,1 
.skipgossipid 54980
step
.goto 2024,47.95,38.09
>>Kill |cRXP_ENEMY_Frigellus|r.
.complete 66488,1 
.mob Frigellus
step
.goto 2024,46.76,38.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korrikunit the Whalebringer|r.
.complete 66699,1 
.target Korrikunit the Whalebringer
.skipgossipid 55417
step
.goto 2024,46.34,38.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jokomuupat|r.
.complete 66699,2 
.target Jokomuupat
.skipgossipid 55418
step
.goto 2024,46.01,38.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Custodian Cynegos|r.
.turnin 66488 >>Turn in WANTED: Frigellus
.target Custodian Cynegos
step
.goto 2024,45.99,38.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Enchanter Celeste|r.
.accept 66489 >>Accept Setting the Defense
.target Arch Enchanter Celeste
step
.goto 2024,46.02,38.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lingering Image|r on the pillar.
.complete 66500,4 
.skipgossipid 55184
step
.goto 2024,46.17,38.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Azure Defender|r.
.complete 66489,1 
.use 192471
step
.goto 2024,46.00,38.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Enchanter Celeste|r.
.turnin 66489 >>Turn in Setting the Defense
.target Arch Enchanter Celeste
step
.goto 2024,45.73,38.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Babunituk|r.
.complete 66699,3 
.target Babunituk
.skipgossipid 55419
step
.goto 2024,45.73,38.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Babunituk|r.
.turnin 66699 >>Turn in Ask the Locals
.accept 65864 >>Accept Catch the Caravan
.target Babunituk
step
.goto 2024,45.69,39.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caddy Scattershot|r.
.accept 66671 >>Accept Path to Nowhere
.target Caddy Scattershot
step
.goto 2024,46.03,40.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lingering Rune|r.
.complete 66500,3 
.skipgossipid 55183
step
.goto 2024,47.13,40.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lingering Rune|r.
.complete 66500,2 
.skipgossipid 55182
step
.goto 2024,47.67,40.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Scrumpy|r.
.turnin 66500 >>Turn in Ways of Seeing
.target Apprentice Scrumpy
step
.goto 2024,46.64,40.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noriko the All-Remembering|r.
.accept 66503 >>Accept For The Love of Others
.complete 66503,1 
.target Noriko the All-Remembering
.skipgossipid 54965
step
.goto 2024,47.14,40.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Remains|r.
.complete 66503,2 
step
.goto 2024,47.02,40.40
>>Jump down and kill the |cRXP_ENEMY_Echo of Loss|r.
.complete 66503,3 
.mob Echo of Loss
step
.goto 2024,46.64,40.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tGlide down with your dragonriding mount and talk to |cRXP_FRIENDLY_Noriko the All-Remembering|r.
.turnin 66503 >>Turn in For The Love of Others
.target Noriko the All-Remembering
step
#completewith next
.goto 2024,35.25,36.98,20 >>Fly to Brena using your dragonriding mount
step
.goto 2024,35.25,36.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r.
.complete 65864,1 
.target Brena
.skipgossip 186224,1
.timer 19,Roleplay Duration
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r and |cRXP_FRIENDLY_Elder Poa|r after the roleplay.
.turnin 65864 >>Turn in Catch the Caravan
.timer 10,Roleplay Duration
.goto 2024,35.25,36.97
.target +Brena
.accept 65868 >>Accept Those Aren't for Chewing
.goto 2024,35.36,36.94
.target +Elder Poa
step
.goto 2024,35.25,36.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r after the roleplay.
.accept 65867 >>Accept Howling in the Big Tree Hills
.accept 65866 >>Accept Snap the Traps
.goto 2024,35.28,36.94
.target Brena
step
#completewith TheAzureSpanHowlingtheBigTreeHills
>>Kill |cRXP_ENEMY_Shadepaw Gnolls|r in the area. Loot them for the offerings
.goto 2024,35.34,33.07,0,0
.complete 65868,1 
.mob Shadepaw Bandit
.mob Shadepaw Bruiser
.mob Shadepaw Trainer
.mob Trained Hyena
step
#completewith TheAzureSpanHowlingtheBigTreeHills
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bladejaw Traps|r.
.complete 65866,1 
step
.goto 2024,35.66,34.73
>>Kill |cRXP_ENEMY_Hyenamaster Durgun|r.
.complete 65867,1 
.mob Hyenamaster Durgun
step
#completewith next
#label TrapLayerKerwalSlain
>>Kill |cRXP_ENEMY_Trap-Layer Kerwal|r.
.goto 2024,34.99,32.18,0,0
.complete 65867,2 
.unitscan Trap-Layer Kerwal
step
#completewith TrapLayerKerwalSlain
#title Enter Cave
.goto 2024,34.95,32.59,10 >>Enter the cave
step
#requires TrapLayerKerwalSlain
>>Kill |cRXP_ENEMY_Trap-Layer Kerwal|r.
.goto 2024,34.99,32.18
.complete 65867,2 
.mob Trap-Layer Kerwal
step
#label TheAzureSpanHowlingtheBigTreeHills
.goto 2024,33.96,33.18
>>Kill |cRXP_ENEMY_Bakra the Bully|r.
.complete 65867,3 
.mob Bakra the Bully
step
#completewith TrapsSprung
#hidewindow
#loop
.goto 2024,33.78,34.66,30,0
.goto 2024,34.37,35.38,30,0
.goto 2024,35.11,35.23,30,0
.goto 2024,35.74,35.29,30,0
.goto 2024,35.79,33.37,30,0
.goto 2024,34.96,33.88,30,0
.goto 2024,35.34,33.07,30,0
+1
step
#completewith next
>>Interact with traps on the ground
.goto 2024,35.34,33.07,0,0
.complete 65866,1 
step
>>Kill |cRXP_ENEMY_Gnolls|r in the area. Loot them for the offerings.
.complete 65868,1 
step
#label TrapsSprung
>>Interact with traps on the ground
.complete 65866,1 
step
#requires TheAzureSpanThoseArentForChewing
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hanu|r.
.goto 2024,34.26,31.30
.turnin 65868 >>Turn in Those Aren't for Chewing
.turnin 65867 >>Turn in Howling in the Big Tree Hills
.turnin 65866 >>Turn in Snap the Traps
.timer 17,Roleplay Duration
.target Hanu
step
.goto 2024,34.38,31.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hanu|r, |cRXP_FRIENDLY_Brena|r and |cRXP_FRIENDLY_Elder Poa|r |cRXP_WARN_after the roleplay|r.
.accept 65871 >>Accept Gnoll Way Out
.accept 65872 >>Accept Ill Gnolls with Ill Intent
.accept 65873 >>Accept Leader of the Shadepaw Pack
.accept 65870 >>Accept Supplies!
.target Hanu
.target Brena
.target Elder Poa
step
#completewith next
.goto 2132,45.88,50.78,0,0
>>Kill |cRXP_ENEMY_Gnolls|r in the cave.
.complete 65872,1 
step
#completewith next
#label HuntingGameCalls
.goto 2132,36.31,93.16,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket of Hunting Game Calls|r.
.complete 65870,3 
step
#completewith HuntingGameCalls
#title Enter Cave
.goto 2024,33.95,30.64,12 >>Enter the cave
step
#requires HuntingGameCalls
#completewith TheAzureSpanLeaderoftheShadepawPack
.goto 2132,45.88,50.78,0,0
>>Kill |cRXP_ENEMY_Gnolls|r in the cave.
.complete 65872,1 
.mob Sickly Ambusher
.mob Sickly Shaman
.mob Sickly Grunt
.mob Sickly Brute
step
#requires HuntingGameCalls
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Basket of Hunting Game Calls|r.
.goto 2132,36.31,93.16
.complete 65870,3 
step
.goto 2132,29.17,75.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel of Salt|r.
.complete 65870,1 
step
#title Tuskarr rescued (1/3)
.goto 2132,30.36,59.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crude Cage|r.
.complete 65871,1,1 
step
.goto 2132,41.42,63.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Norukk|r.
.complete 65871,2 
.target Norukk
step
#title Tuskarr rescued (2/3)
.goto 2132,46.26,40.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crude Cage|r.
.complete 65871,1,2 
step
.goto 2132,51.40,36.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel of Skinning Tools|r.
.complete 65870,2 
step
#title Tuskarr rescued (3/3)
.goto 2132,38.10,32.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crude Cage|r.
.complete 65871,1 
step
#label TheAzureSpanLeaderoftheShadepawPack
.goto 2132,42.27,14.47
>>Kill |cRXP_ENEMY_Kargpaw the Fetid|r. Loot him for |T136008:0|[|cRXP_LOOT_Kargpaw's Totem|r].
.complete 65873,1 
.mob Kargpaw the Fetid
step
#loop
.goto 2132,37.06,36.14,20,0
.goto 2132,44.64,36.89,20,0
.goto 2132,48.99,26.78,20,0
.goto 2132,61.47,40.78,20,0
.goto 2132,64.62,21.19,20,0
.goto 2132,61.47,40.78,20,0
.goto 2132,43.73,42.03,20,0
.goto 2132,36.65,34.61,20,0
.goto 2132,28.82,48.53,20,0
.goto 2132,29.37,60.34,20,0
.goto 2132,38.45,52.88,20,0
.goto 2132,47.14,55.14,20,0
.goto 2132,46.56,36.26,20,0
.goto 2132,61.09,39.17,20,0
.goto 2132,65.72,24.58,20,0
>>Kill |cRXP_ENEMY_Gnolls|r in the cave.
.complete 65872,1 
.mob Sickly Ambusher
.mob Sickly Shaman
.mob Sickly Grunt
.mob Sickly Brute
step
#completewith next
#label SuppliesGnollsShadepawOut
.goto 2024,34.38,31.06,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hanu|r, |cRXP_FRIENDLY_Brena|r and |cRXP_FRIENDLY_Elder Poa|r.
.turnin 65870 >>Turn in Supplies!
.turnin 65872 >>Turn in Ill Gnolls with Ill Intent
.turnin 65873 >>Turn in Leader of the Shadepaw Pack
.turnin 65871 >>Turn in Gnoll Way Out
.accept 66239 >>Accept Spreading Decay
.target Hanu
.target Brena
.target Elder Poa
step
#completewith SuppliesGnollsShadepawOut
#title Leave Cave
.goto 2024,34.92,30.03,10 >>Leave the cave
step
#requires SuppliesGnollsShadepawOut
.goto 2024,34.38,31.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hanu|r, |cRXP_FRIENDLY_Brena|r and |cRXP_FRIENDLY_Elder Poa|r.
.turnin 65870 >>Turn in Supplies!
.target +Hanu
.turnin 65871 >>Turn in Gnoll Way Out
.target +Elder Poa
.turnin 65872 >>Turn in Ill Gnolls with Ill Intent
.turnin 65873 >>Turn in Leader of the Shadepaw Pack
.accept 66239 >>Accept Spreading Decay
.target +Brena
step
.goto 2024,28.69,34.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r.
.turnin 66239 >>Turn in Spreading Decay
.accept 65869 >>Accept Another Ambush
.target Brena
step
.goto 2024,28.68,34.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akiun|r.
.complete 65869,1 
.target Akiun
.skipgossipid 55220
step
#title Bodies examined (1/4)
.goto 2024,29.25,33.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tuskarr Fisherman|r while mounted.
.complete 65869,2,1 
.target Tuskarr Fisherman
.skipgossipid 55691
step
#title Bodies examined (2/4)
.goto 2024,29.17,32.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tuskarr Hunter|r while mounted.
.complete 65869,2,2 
.target Tuskarr Hunter
.skipgossipid 55692
step
#title Bodies examined (3/4)
.goto 2024,28.20,31.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tuskarr Craftsman|r while mounted.
.complete 65869,2,3 
.target Tuskarr Craftsman
.skipgossipid 55693
step
#title Bodies examined (4/4)
.goto 2024,27.97,32.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Festering Gnoll|r while mounted.
.complete 65869,2 
.target Festering Gnoll
.skipgossipid 55694
step
.goto 2024,28.78,34.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r.
.turnin 65869 >>Turn in Another Ambush
.accept 66026 >>Accept Urgent Action Required
.target Brena
step
.goto 2024,28.47,35.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Unkimi|r.
.accept 71233 >>Accept Falling Water
.target Unkimi
step
.goto 2024,22.72,41.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Detry Hornswald|r.
.accept 66262 >>Accept Waste Water Cleanup
.target Detry Hornswald
step
#loop
.goto 2024,22.45,41.96,30,0
.goto 2024,22.04,41.66,30,0
.goto 2024,21.87,41.45,30,0
.goto 2024,22.27,41.20,30,0
.goto 2024,22.83,41.18,30,0
.goto 2024,23.22,41.16,30,0
.goto 2024,23.60,41.40,30,0
.goto 2024,22.81,42.15,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rotting Piles|r and kill the spawning |cRXP_ENEMY_Muck Elementals|r.
.complete 66262,1 
.mob Muck Elemental
step
.goto 2024,22.72,41.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Detry Hornswald|r.
.turnin 66262 >>Turn in Waste Water Cleanup
.accept 66263 >>Accept A Precision Approach
.accept 66264 >>Accept Disarmed and Docile
.target Detry Hornswald
step
#completewith next
>>Kill |cRXP_ENEMY_Gnawbone Gnolls|r. Loot them for the |T464820:0|t[|cRXP_LOOT_Gnawbone Armaments|r].
>>Or |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawbone Weapon Racks|r.
.complete 66264,1 
.mob Gnawbone Brawler
.mob Gnawbone Totemchewer
.mob Gnawbone Chainchewer
.mob Gnawbone Grunt
.mob Gnawbone Underboss
.mob Gnawbone Splintershield
step
#completewith next
#label TheAzureSpanAPrecisionApproach
.goto 2024,24.80,39.03
>>Kill |cRXP_ENEMY_Flayfist|r.
.complete 66263,1 
.mob Flayfist
step
#completewith TheAzureSpanAPrecisionApproach
#title Enter Cave
.goto 2024,24.40,39.56,20 >>Enter the cave
step
#requires TheAzureSpanAPrecisionApproach
.goto 2024,24.80,39.03
>>Kill |cRXP_ENEMY_Flayfist|r.
.complete 66263,1 
.mob Flayfist
step
#loop
.goto 2024,24.40,39.56,35,0
.goto 2024,23.33,39.87,35,0
.goto 2024,22.47,39.95,35,0
.goto 2024,22.09,40.67,35,0
.goto 2024,23.85,40.50,35,0
>>Kill |cRXP_ENEMY_Gnawbone Gnolls|r. Loot them for the |T464820:0|t[|cRXP_LOOT_Gnawbone Armaments|r].
>>Or |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawbone Weapon Racks|r.
.complete 66264,1 
.mob Gnawbone Brawler
.mob Gnawbone Totemchewer
.mob Gnawbone Chainchewer
.mob Gnawbone Grunt
.mob Gnawbone Underboss
step
.goto 2024,22.74,41.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Detry Hornswald|r.
.turnin 66263 >>Turn in A Precision Approach
.turnin 66264 >>Turn in Disarmed and Docile
.accept 66265 >>Accept Who's Next?
.accept 66266 >>Accept Filthy Mongrels
.target Detry Hornswald
step
.goto 2024,23.48,41.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Illusory Mage|r.
.accept 66267 >>Accept M.E.T.A.
.target Illusory Mage
step
#completewith TheAzureSpanMETA
>>Kill |cRXP_ENEMY_Mongrels|r and |cRXP_ENEMY_Matriarchs|r.
*|cRXP_WARN_You can use the [ExtraActionButton] to disguise yourself|r.
.complete 66266,2 
.complete 66266,1 
.mob Hyena Mongrel
.mob Hyena Matriarch
step
.goto 2024,24.20,41.81
>>Kill |cRXP_ENEMY_Cracktooth|r inside the small cave.
.complete 66265,1 
.mob Cracktooth
step
#completewith HyenaMongrelMatriarch
#hidewindow
#loop
.goto 2024,23.50,42.43,30,0
.goto 2024,23.73,43.25,30,0
.goto 2024,24.32,42.91,30,0
.goto 2024,23.94,42.02,30,0
+1
step
#label TheAzureSpanMETA
>>Kill |cRXP_ENEMY_Gnolls|r in the area. Loot them for |T134245:0|[|cRXP_LOOT_Duskpaw Keys|r]. You can also pick up the keys around the tents
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Trapped animals|r to free them.
.collect 191736,6,66267,0x1,-1
.complete 66267,1 
step
#label HyenaMongrelMatriarch
>>Kill the |cRXP_ENEMY_Mongrels|r and |cRXP_ENEMY_Matriarchs|r.
.complete 66266,2 
.complete 66266,1 
.mob Hyena Mongrel
.mob Hyena Matriarch
step
.goto 2024,22.73,41.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Detry Hornswald|r.
.turnin 66266 >>Turn in Filthy Mongrels
.turnin 66265 >>Turn in Who's Next?
.turnin 66267 >>Turn in M.E.T.A.
.accept 66268 >>Accept Third Try's the Charm
.accept 66269 >>Accept Just To Be Sure
.target Detry Hornswald
step
#completewith TheAzureSpanThirdTrystheCharm
>>Kill |cRXP_ENEMY_Stormfang Elementalists|r.
.complete 66269,1 
.mob Stormfang Hexspiter
.mob Stormfang Bonecaster
.mob Stormfang Dustcaller
.mob Stormfang Shaman
step
#label TheAzureSpanThirdTrystheCharmB
.goto 2024,22.27,43.20,0,0
>>Kill |cRXP_ENEMY_Bloodclaw|r.
.complete 66268,1 
.mob Bloodclaw
step
#completewith TheAzureSpanThirdTrystheCharmB
#title Enter Cave
.goto 2024,22.16,43.51,10 >>Enter the cave
step
#requires TheAzureSpanThirdTrystheCharmB
#label TheAzureSpanThirdTrystheCharm
.goto 2024,22.27,43.20
>>Kill |cRXP_ENEMY_Bloodclaw|r.
.complete 66268,1 
.mob Bloodclaw
step
#loop
.line 2024,22.27,42.50,23.17,42.67,23.32,43.28,23.22,44.28,22.52,43.54
.goto 2024,22.27,42.50,30,0
.goto 2024,23.17,42.67,30,0
.goto 2024,23.32,43.28,30,0
.goto 2024,23.22,44.28,30,0
.goto 2024,22.52,43.54,30,0
>>Kill |cRXP_ENEMY_Stormfang Elementalists|r.
.complete 66269,1 
.mob Stormfang Hexspiter
.mob Stormfang Bonecaster
.mob Stormfang Dustcaller
.mob Stormfang Shaman
step
.goto 2024,22.74,41.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Detry Hornswald|r.
.turnin 66269 >>Turn in Just To Be Sure
.turnin 66268 >>Turn in Third Try's the Charm
.target Detry Hornswald
step
>>Kill |cRXP_ENEMY_Cascade|r.
.goto 2024,23.33,33.60
.accept 72358 >>Accept Cascade (Elite Objective)
.complete 72358,1 
.mob Cascade
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r.
.goto 2024,20.59,35.67
.turnin 66026 >>Turn in Urgent Action Required
.timer 24,Roleplay Duration
.target Brena
step
.goto 2024,18.73,24.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Willa Stronghinge|r.
.turnin 71233 >>Turn in Falling Water
.accept 66837 >>Accept Nothing for Breakfast
.accept 66838 >>Accept It's Cold Up Here
.target Willa Stronghinge
step
.goto 2024,19.04,23.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zon'Wogi|r.
.accept 66844 >>Accept The Great Shokhari
.target Zon'Wogi
step
.goto 2024,19.04,23.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Modurun Sixtoes|r.
.accept 66839 >>Accept It's Brew Time!
.target Modurun Sixtoes
step
#completewith ThickBearPelts
#hidewindow
#loop
.goto 2024,20.46,25.93,35,0
.goto 2024,21.16,25.65,35,0
.goto 2024,21.70,25.54,35,0
.goto 2024,22.23,26.04,35,0
.goto 2024,22.76,26.05,35,0
.goto 2024,22.87,26.70,35,0
.goto 2024,23.23,26.82,35,0
.goto 2024,22.42,27.73,35,0
.goto 2024,21.91,27.83,35,0
.goto 2024,20.85,27.94,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Thickmane Bears|r in the area. Loot them for the |T134353:0|t[|cRXP_LOOT_Thick Bear Pelt|r].
.complete 66838,1 
.mob Thickmane Matriarch
.mob Thickmane Bear
.mob Juvenile Thickmane Bear
step
>>|cRXP_WARN_Focus on clicking on |cRXP_PICK_Dragon Foil|r and |cRXP_PICK_Blood Berries|r|r.
.complete 66839,1 
step
#label ThickBearPelts
>>Kill |cRXP_ENEMY_Thickmane Bears|r in the area. Loot them for the |T134353:0|t[|cRXP_LOOT_Thick Bear Pelt|r].
.complete 66838,1 
.mob Thickmane Matriarch
.mob Thickmane Bear
.mob Juvenile Thickmane Bear
step
.goto 2024,19.24,26.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Branor Broadbraw|r.
.accept 66843 >>Accept Out of Lukh
.target Branor Broadbraw
step
#completewith next
#label MooseFlankVorquinMeatA
#hidewindow
.goto 2024,18.42,27.94,32,0
.goto 2024,18.30,26.71,32,0
.goto 2024,17.52,26.92,32,0
.goto 2024,16.95,27.55,32,0
.goto 2024,16.13,27.81,32 >>1
step
#completewith MooseFlankVorquinMeatA
>>Kill |cRXP_ENEMY_Vorquins|r and |cRXP_ENEMY_Bruffalons|r. Loot them for the |T133961:0|t[|cRXP_LOOT_Vorquin Meat|r and |T644277:0|t[|cRXP_LOOT_Moose Flank|r].
.complete 66837,2 
.complete 66837,1 
.mob Vorquin Strider
.mob Vorquin Foal
.mob Striped Bruffalon
step
#requires MooseFlankVorquinMeatA
>>Kill |cRXP_ENEMY_Gloomfur Sasquatch|r inside the cave.
.goto 2024,16.01,27.25
.complete 66843,1 
.mob Gloomfur Sasquatch
step
#loop
.goto 2024,18.30,26.71,30,0
.goto 2024,17.52,26.92,30,0
.goto 2024,16.95,27.55,30,0
.goto 2024,16.13,27.81,30,0
.goto 2024,15.98,26.06,30,0
.goto 2024,17.39,25.96,30,0
>>Kill |cRXP_ENEMY_Vorquins|r and |cRXP_ENEMY_Bruffalons|r. Loot them for the |T133961:0|t[|cRXP_LOOT_Vorquin Meat|r] and |T644277:0|t[|cRXP_LOOT_Moose Flank|r].
.complete 66837,2 
.complete 66837,1 
.mob Vorquin Strider
.mob Vorquin Foal
.mob Striped Bruffalon
step
>>Kill |cRXP_ENEMY_Sky Vixen Shokhari|r.
.goto 2024,13.15,26.29
.complete 66844,1 
.mob Sky Vixen Shokhari
step
.goto 2024,18.75,24.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Willa Stronghinge|r.
.turnin 66837 >>Turn in Nothing for Breakfast
.turnin 66838 >>Turn in It's Cold Up Here
.target Willa Stronghinge
step
.goto 2024,19.03,23.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zon'Wogi|r.
.turnin 66844 >>Turn in The Great Shokhari
.target Zon'Wogi
step
.goto 2024,18.98,23.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Modurun Sixtoes|r.
.turnin 66839 >>Turn in It's Brew Time!
.target Modurum Sixtoes
step
.goto 2024,18.54,23.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Manny Read|r.
.accept 66840 >>Accept Water Safety
.target Manny Read
step
#title Sample collected (1/3)
.goto 2024,19.38,23.95
>>Use the |T134864:0|t[Water Testing Flask] at the waypoint location
.complete 66840,1,1 
.use 193569
step
.goto 2024,19.16,24.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gannar Fullpack|r.
.accept 66841 >>Accept A Shard of the Past
.target Gannar Fullpack
step
#title Sample collected (2/3)
.goto 2024,20.01,24.18
>>Use the |T134864:0|t[Water Testing Flask] at the waypoint location
.complete 66840,1,2 
.use 193569
step
.goto 2024,19.24,26.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Branor Broadbraw|r.
.turnin 66843 >>Turn in Out of Lukh
.target Branor Broadbraw
step
.goto 2024,17.61,28.23
>>Land on the rock and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Artifact|r.
.complete 66841,1 
step
#title Sample collected (3/3)
.goto 2024,17.30,23.20
>>Use the |T134864:0|t[Water Testing Flask] at the waypoint location
*Kill the |cRXP_ENEMY_Deep Wyrm|r.
.complete 66840,1 
.use 193569
.mob Deep Wyrm
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Manny Read|r and |cRXP_FRIENDLY_Thanessa Silverbloom|r.
.turnin 66840 >>Turn in Water Safety
.goto 2024,18.54,23.67
.target +Manny Read
.turnin 66841 >>Turn in A Shard of the Past
.goto 2024,18.65,23.67
.target +Thanessa Silverbloom
step
.goto 2024,18.74,24.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guo-Hee Calmwater|r.
.accept 66845 >>Accept Legendary Foil
.target Guo-Hee Calmwater
step
.goto 2024,17.26,26.21
>>Defeat the |cRXP_ENEMY_Mysterious Apparition|r.
.complete 66845,1 
.mob Mysterious Apparition
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guo-Hee Calmwater|r and the |cRXP_FRIENDLY_Mysterious Apparition|r.
.turnin 66845 >>Turn in Legendary Foil
.goto 2024,18.74,24.42
.target +Guo-Hee Calmwater
.accept 66846 >>Accept The Heart of the Deck
.goto 2024,18.77,24.43
.target +Mysterious Apparition
step
.goto 2024,18.77,24.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Mysterious Apparition|r and wait for the roleplay.
.skipgossip 191741,1
.timer 35,Roleplay Duration
.complete 66846,1 
.target Mysterious Apparition
step
.goto 2024,18.77,24.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mysterious Apparition|r.
.turnin 66846 >>Turn in The Heart of the Deck
.target Mysterious Apparition
step
.goto 2024,20.53,35.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r after a short roleplay.
.accept 65838 >>Accept Breaching the Brackenhide
.target Kalecgos
step
#completewith RottingRoots
>>Kill |cRXP_ENEMY_Brackenhides forces|r and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decay Totems|r. (Bonus Objective). |cRXP_WARN_Don't finish this right now|r.
.complete 65841,1 
.mob Brackenhide Scrapper
.mob Brackenhide Deadeye
.mob Oozing Decay
step
.goto 2024,18.89,36.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rotting Root|r.
.complete 65838,2 
.skipgossipid 54967
step
.goto 2024,18.38,34.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rotting Root|r.
.complete 65838,1 
.skipgossipid 55350
step
#label RottingRoots
.goto 2024,17.59,36.99
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rotting Root|r.
.complete 65838,3 
.skipgossipid 54968
step
#completewith TheAzureSpanLeyLitter
>>Kill |cRXP_ENEMY_Brackenhides forces|r and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decay Totems|r. (Bonus Objective). |cRXP_WARN_Don't finish this right now|r.
.complete 65841,1 
.mob Brackenhide Rotflinger
.mob Brackenhide Scrapper
.mob Rotting Treant
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r, |cRXP_FRIENDLY_Norukk|r and |cRXP_FRIENDLY_Brena|r.
.turnin 65838 >>Turn in Breaching the Brackenhide
.accept 65846 >>Accept Ley Litter
.goto 2024,16.75,37.31
.target +Kalecgos
.accept 65844 >>Accept Cut Out the Rot
.goto 2024,16.76,37.25
.target +Norukk
.accept 65845 >>Accept Echoes of the Fallen
.goto 2024,16.75,37.22
.target +Brena
step
#completewith TheAzureSpanLeyLitter
.goto 2024,17.69,37.74,0,0
>>Kill the |cRXP_ENEMY_Brackenhide Rotflinger|r and |cRXP_ENEMY_Rotting Treants|r.
.complete 65844,2 
.complete 65844,1 
.mob Rotting Treant
.mob Brackenhide Rotflinger
step
#title Ley Crystals (1/7)
.goto 2024,16.99,36.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawed Ley Crystals|r.
.complete 65846,1,1 
step
#title Spirit contacted (1/5)
.goto 2024,17.47,37.07
>>Use |T971076:0:0|t[Brena's Totem] next to the corpses
.complete 65845,1,1 
.use 191928
step
#title Ley Crystals (2/7)
.goto 2024,17.34,37.17
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawed Ley Crystals|r.
.complete 65846,1,2 
step
#title Ley Crystals (3/7)
.goto 2024,17.71,37.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawed Ley Crystals|r.
.complete 65846,1,3 
step
#title Ley Crystals (4/7)
.goto 2024,17.75,37.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawed Ley Crystals|r.
.complete 65846,1,4 
step
#title Ley Crystals (5/7)
.goto 2024,18.01,37.70
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawed Ley Crystals|r.
.complete 65846,1,5 
step
#title Ley Crystals (6/7)
.goto 2024,18.35,37.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawed Ley Crystals|r.
.complete 65846,1,6 
step
#title Ley Crystals (7/7)
.goto 2024,18.26,38.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnawed Ley Crystals|r.
.complete 65846,1 
step
#title Spirit contacted (2/5)
.goto 2024,18.13,37.67
>>Use |T971076:0:0|t[Brena's Totem] next to the corpses
.complete 65845,1,2 
.use 191928
step
#title Spirit contacted (3/5)
.goto 2024,18.52,37.26
>>Use |T971076:0:0|t[Brena's Totem] next to the corpses
.complete 65845,1,3 
.use 191928
step
#title Spirit contacted (4/5)
.goto 2024,17.54,37.93
>>Use |T971076:0:0|t[Brena's Totem] next to the corpses
.complete 65845,1,4 
.use 191928
step
#label TheAzureSpanEchoesoftheFallen
#title Spirit contacted (5/5)
.goto 2024,17.41,38.65
>>Use |T971076:0:0|t[Brena's Totem] next to the corpses
.complete 65845,1 
.use 191928
step
#completewith BrackenhideDecaySpreadContained
#hidewindow
#loop
.goto 2024,17.17,39.64,40,0
.goto 2024,18.76,39.21,40,0
.goto 2024,18.56,37.26,40,0
.goto 2024,16.97,36.88,40,0
.goto 2024,18.68,34.75,40,0
+1
step
#compeltewith next
>>Kill |cRXP_ENEMY_Brackenhides forces|r and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decay Totems|r. (Bonus Objective). |cRXP_WARN_Don't finish this right now|r.
.complete 65841,1 
.mob Brackenhide Rotflinger
.mob Brackenhide Scrapper
.mob Rotting Treant
step
>>|cRXP_WARN_Possible treant locations are marked on your map|r.
.goto 2024,17.2,37.0,0
.goto 2024,17.4,37.8,0
.goto 2024,17.4,39.2,0
.goto 2024,17.6,37.2,0
.goto 2024,17.8,38.8,0
.goto 2024,18.4,38.0,0
.goto 2024,18.6,38.0,0
.goto 2024,18.6,38.6,0
.goto 2024,18.8,36.6,0
.goto 2024,17.2,37.0,0
.unitscan Rotting Treant
.complete 65844,2 
.complete 65844,1 
step
#label BrackenhideDecaySpreadContained
>>Kill |cRXP_ENEMY_Brackenhides forces|r and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decay Totems|r. (Bonus Objective). |cRXP_WARN_Don't finish this right now|r.
.complete 65841,1 
.mob Brackenhide Rotflinger
.mob Brackenhide Scrapper
.mob Rotting Treant
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Norukk|r, |cRXP_FRIENDLY_Brena|r, and |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65844 >>Turn in Cut Out the Rot
.goto 2024,16.76,37.25
.target +Norukk
.turnin 65845 >>Turn in Echoes of the Fallen
.goto 2024,16.75,37.22
.target +Brena
.turnin 65846 >>Turn in Ley Litter
.accept 65848 >>Accept Tome-ward Bound
.goto 2024,16.74,37.32
.target +Kalecgos
.skipgossipid 55002
step
.goto 2024,16.74,37.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r and wait for the roleplay.
.complete 65848,1 
.target Kalecgos
.timer 21,Roleplay Duration
.skipgossipid 55002
step
.goto 2024,16.71,37.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tome of Spellflinging|r.
.complete 65848,2 
.target Tome of Spellflinging
step
.goto 2024,16.02,38.49
>>Spam |T134917:0:0|tTome Charge (1) to move faster
>>Use |T135753:0:0|tArcane Blast (2) to kill the |cRXP_ENEMY_Putrifiers|r.
.complete 65848,3,1 
.mob Brackenhide Putrifier
step
.goto 2024,15.64,37.42
>>Spam |T134917:0:0|tTome Charge (1) to move faster
>>Use |T135753:0:0|tArcane Blast (2) to kill the |cRXP_ENEMY_Putrifiers|r.
.complete 65848,3,2
.mob Brackenhide Putrifier
step
.goto 2024,15.22,37.95
>>Spam |T134917:0:0|tTome Charge (1) to move faster
>>Use |T135753:0:0|tArcane Blast (2) to kill the |cRXP_ENEMY_Putrifiers|r.
.complete 65848,3,3 
.mob Brackenhide Putrifier
step
.goto 2024,15.40,37.73
>>Use |T429383:0:0|tArcane Spirit Beam (1) to kill the |cRXP_ENEMY_Twisted Ancient|r.
.complete 65848,4 
.timer 10,Roleplay Duration
.mob Twisted Ancient
step
.goto 2024,15.30,39.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65848 >>Turn in Tome-ward Bound
.accept 65847 >>Accept Realignment
.target Kalecgos
step
.goto 2024,15.35,39.50
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ley Crystal|r.
.complete 65847,1 
step
#title Infection destroyed (1/3)
.goto 2024,15.51,39.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decay Infection|r.
.complete 65847,2,1 
step
#title Infection destroyed (2/3)
.goto 2024,15.30,39.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decay Infection|r.
.complete 65847,2,2 
step
#title Infection destroyed (3/3)
.goto 2024,15.07,39.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decay Infection|r.
.complete 65847,2 
step
#completewith next
#label RealignmentIskaara
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r and |cRXP_FRIENDLY_Brena|r.
.turnin 65847 >>Turn in Realignment
.goto 2024,16.11,41.40,0,0
.target +Kalecgos
.accept 65849 >>Accept To Iskaara
.goto 2024,16.08,41.45,0,0
.target +Brena
step
#completewith RealignmentIskaara
#title Leave Cave
.goto 2024,14.97,38.77,15 >>Leave the cave
step
#requires RealignmentIskaara
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Kalecgos and Brena
.turnin 65847 >>Turn in Realignment
.goto 2024,16.11,41.40
.accept 65849 >>Accept To Iskaara
.goto 2024,16.08,41.45
.target Kalecgos
.target Brena
step
>>Kill |cRXP_ENEMY_Vakril, the Strongest Tuskarr|r.
.goto 2024,17.23,41.46
.accept 69872 >>Accept Vakril, the Strongest Tuskarr
.complete 69872,1 
step
.goto 2024,13.24,49.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r.
.turnin 65849 >>Turn in To Iskaara
.accept 66210 >>Accept Gather the Family
.target Brena
step
.goto 2024,13.14,49.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Roki|r.
.accept 72435 >>Accept Orientation: Iskaara
.target Roki
step
.goto 2024,13.76,47.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auntie Kaunnie|r.
.accept 66558 >>Accept Rowie
.target Auntie Kaunnie
step
.goto 2024,16.11,50.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rowie|r.
.complete 66558,1 
.target Rowie
.skipgossipid 55005
.skipgossipid 55006
step
.goto 2024,16.11,50.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rowie|r.
.turnin 66558 >>Turn in Rowie
.accept 70129 >>Accept Toejam the Terrible
.target Rowie
step
#completewith next
#label ToejamTheTerrible
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toejam the Terrible|r.
.complete 70129,1 
.target Toejam the Terrible
.skipgossipid 55904
.skipgossipid 55905
.skipgossipid 55906
.skipgossipid 55907
.skipgossipid 55908
.skipgossipid 55909
.skipgossipid 55910
.skipgossipid 55911
step
#completewith ToejamTheTerrible
#title Enter Cave
.goto 2024,16.55,50.24,6 >>Enter the cave
step
#requires ToejamTheTerrible
.goto 2024,16.95,49.88,10,0
.goto 2024,16.99,49.39,10,0
.goto 2024,16.74,49.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toejam the Terrible|r.
.complete 70129,1 
.target Toejam the Terrible
.skipgossipid 55904
.skipgossipid 55905
.skipgossipid 55906
.skipgossipid 55907
.skipgossipid 55908
.skipgossipid 55909
.skipgossipid 55910
.skipgossipid 55911
step
#completewith next
#label ToejamTheTerribleB
.goto 2024,13.80,49.01,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auntie Kaunnie|r.
.turnin 70129 >>Turn in Toejam the Terrible
.target Auntie Kaunnie
step
#completewith ToejamTheTerribleB
#title Leave Cave
.goto 2024,16.49,50.26,10,0
.goto 2024,16.24,50.38,10 >>Leave the cave
step
#requires ToejamTheTerribleB
.goto 2024,13.80,49.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auntie Kaunnie|r.
.turnin 70129 >>Turn in Toejam the Terrible
.target Auntie Kaunnie
step
#completewith next
#label FuneralOfferingA
.goto 2024,12.49,49.45,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone Sculpture|r.
.complete 66210,1,1 
step
#completewith FuneralOfferingA
#title Enter Inn
.goto 2024,12.78,49.34,8 >>Enter the inn
step
#requires FuneralOfferingA
#title |T134450:0:0|tOffering collected (1/4)
.goto 2024,12.49,49.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone Sculpture|r.
.complete 66210,1,1 
step
.goto 2024,12.40,49.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Nappa|r.
.accept 66213 >>Accept The Weave of a Tale
.target Elder Nappa
step
.goto 2024,12.41,49.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Poa|r.
.complete 66213,1 
.target Elder Poa
.skipgossip 186448,1
step
.goto 2024,12.40,49.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Nappa|r.
.turnin 66213 >>Turn in The Weave of a Tale
.target Elder Nappa
step
#completewith next
#label FuneralOfferingA
.goto 2024,12.46,50.31,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ornamented Shield|r.
.complete 66210,1,2 
step
#completewith FuneralOfferingA
#title Leave Inn
.goto 2024,12.78,49.34,8 >>Leave the inn
step
#requires FuneralOfferingA
#title |T134989:0:0|tOffering collected (2/4)
.goto 2024,12.46,50.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ornamented Shield|r.
.complete 66210,1,2 
step
.goto 2024,13.91,50.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rokkutuk|r.
.complete 72435,2 
.target Rokkutuk
step
.goto 2024,14.07,49.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lukoturukk|r.
.accept 71234 >>Accept Nook News
.target Lukoturukk
step
#title |T1126431:0:0|tOffering collected (3/4)
.goto 2024,13.87,49.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handcrafted Boat|r.
.complete 66210,1,3 
step
#title |T132803:0:0|tOffering collected (4/4)
.goto 2024,13.48,48.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Decorated Teapot|r.
.complete 66210,1 
step
.goto 2024,13.14,48.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Funeral Boat|r.
.complete 66210,2 
step
.goto 2024,13.17,48.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arvik|r.
.complete 72435,1 
.target Arvik
step
#requires TheAzureSpanOrientationIskaarEquipment
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Norukk|r.
.goto 2024,12.96,48.64
.complete 72435,4 
.target Norukk
step
.goto 2024,12.89,48.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hanu|r.
.accept 66218 >>Accept Scampering Scamps
.target Hanu
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tatto|r.
.goto 2024,13.18,48.82
.complete 72435,3 
.target Tatto
step
.goto 2024,13.20,48.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bukarakikk|r.
.accept 66217 >>Accept WANTED: Krojek the Shoreprowler
.target Bukarakikk
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Murik|r.
.goto 2024,13.14,49.26
.turnin 72435 >>Turn in Orientation: Iskaara
.target Murik
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brena|r and |cRXP_FRIENDLY_Kalecgos|r.
.turnin 66210 >>Turn in Gather the Family
.goto 2024,13.24,49.56
.target +Brena
.accept 65850 >>Accept The Cycle of the Sea
.goto 2024,13.26,49.53
.target +Kalecgos
step
#completewith next
#label BoatPushedToSeaA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Funeral Boat|r after the roleplay.
.complete 65850,1 
.complete 65850,2 
step
#completewith BoatPushedToSeaA
.goto 2024,13.24,49.55
.gossipoption 55314 >> Talk to |cRXP_FRIENDLY_Brena|r.
.timer 72,Roleplay Duration
.target Brena
step
#requires BoatPushedToSeaA
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Funeral Boat|r after the roleplay.
.goto 2024,13.18,49.20,8,0
.goto 2024,13.06,49.52,10,0
.goto 2024,13.16,50.20
.complete 65850,1 
.complete 65850,2 
step
.goto 2024,12.94,50.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65850 >>Turn in Gather the Family
.accept 65911 >>Accept Azure Alignment
.target Kalecgos
step
.goto 2024,10.45,53.66
>>Kill |cRXP_ENEMY_Krojek The Shoreprowler|r. |cRXP_WARN_You can skip this quest. It is a very hard elite|r.
.complete 66217,1 
.mob Krojek The Shoreprowler
step
.isQuestComplete 66217
.goto 2024,12.51,49.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bukarakikk|r.
.turnin 66217 >>Turn in WANTED: Krojek the Shoreprowler
.target Bukarakikk
step
.abandon 66217 >>Abandon WANTED: Krojek the Shoreprowler
step
.goto 2024,10.59,46.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neelo|r.
.complete 66218,1 
.target Neelo
.skipgossipid 55003
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wayun|r.
.goto 2024,7.45,44.28
.turnin 71234 >>Turn in Nook News
.target Wayun
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mordigan Ironjaw|r.
.goto 2024,7.62,44.34
.accept 66781 >>Accept A Matter of Taste
.target Mordigan Ironjaw
step
.goto 2024,7.24,45.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Large Stone|r.
.complete 66781,1 
step
.goto 2024,7.62,44.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mordigan Ironjaw|r.
.turnin 66781 >>Turn in A Matter of Taste
.target Mordigan Ironjaw
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_LOU-C Fitzcog|r, |cRXP_FRIENDLY_Examiner Rowe|r and |cRXP_FRIENDLY_Aelnara|r.
.accept 66164 >>Accept Fishy Fingers
.goto 2024,7.65,44.32
.target +LOU-C Fitzcog
.accept 66154 >>Accept Salivatory Samples
.goto 2024,7.67,44.26
.target +Examiner Rowe
.accept 66147 >>Accept Crystals in the Water
.goto 2024,7.64,44.23
.target +Aelnara
step
#completewith TheAzureSpanCrystalsintheWater
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stolen Parts|r.
.complete 66164,1 
step
#completewith TheAzureSpanCrystalsintheWater
>>Kill |cRXP_ENEMY_Brinetooths|r. Loot them for the |T463570:0|t[|cRXP_LOOT_Saliva Samples|r].
.complete 66154,1 
step
#title Crystal Mined (1/4)
.goto 2024,9.86,43.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conspicuous Crystal|r.
.complete 66147,1,1 
step
#title Crystal Mined (2/4)
.goto 2024,10.36,43.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conspicuous Crystal|r.
.complete 66147,1,2 
step
#title Crystal Mined (3/4)
.goto 2024,10.68,42.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conspicuous Crystal|r.
.complete 66147,1,3 
step
#label TheAzureSpanCrystalsintheWater
#title Crystal Mined (4/4)
.goto 2024,10.18,42.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conspicuous Crystal|r.
.complete 66147,1 
step
#completewith StolenPartsRecovered
#hidewindow
#loop
.goto 2024,9.76,42.96,35,0
.goto 2024,9.77,43.71,35,0
.goto 2024,10.31,43.44,35,0
.goto 2024,10.95,43.44,35,0
.goto 2024,10.28,42.36,35,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stolen Parts|r.
.complete 66164,1 
step
>>Kill |cRXP_ENEMY_Brinetooths|r. Loot them for the |T463570:0|t[|cRXP_LOOT_Saliva Samples|r].
.complete 66154,1 
.mob Brinetooth Jabber
.mob Brinetooth Spawnwatcher
.mob Brinetooth Gnasher
step
#label StolenPartsRecovered
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stolen Parts|r.
.complete 66164,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Examiner Rowe|r, |cRXP_FRIENDLY_Aelnara|r and |cRXP_FRIENDLY_LOU-C Fitzcog|r.
.turnin 66154 >>Turn in Salivatory Samples
.goto 2024,7.67,44.26
.target +Examiner Rowe
.turnin 66147 >>Turn in Crystals in the Water
.goto 2024,7.64,44.23
.target +Aelnara
.turnin 66164 >>Turn in Fishy Fingers
.accept 66175 >>Accept Field Experiment
.goto 2024,7.65,44.32
.target +LOU-C Fitzcog
step
.goto 2024,7.64,44.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Geoscanner 289-07|r.
.complete 66175,1 
.timer 33,Roleplay Duration
step
.goto 2024,10.59,46.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neelo|r.
.turnin 66218 >>Turn in Scampering Scamps
.accept 66223 >>Accept Can We Keep It?
.target Neelo
step
.goto 2024,13.85,49.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jinkutuk|r and buy 7 |T237302:0|t[Frigidfish]
.complete 66223,1 
.buy 192153,7 
.target Jinkutuk
step
.goto 2024,10.59,46.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neelo|r.
.turnin 66223 >>Turn in Can We Keep It?
.target Neelo
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_LOU-C Fitzcog|r and |cRXP_FRIENDLY_Wayun|r.
.turnin 66175 >>Turn in Field Experiment
.accept 66177 >>Accept No Dwarf Left Behind
.goto 2024,7.65,44.35
.target +LOU-C Fitzcog
.accept 66232 >>Accept Afront 'Till A Salt
.goto 2024,7.46,44.28
.target Wayun
step
#completewith TheAzureSpanNoDwarfLeftBehind
>>Kill the |cRXP_ENEMY_Brinetooths|r in the area. Loot them for the |T1387651:0|t[|cRXP_LOOT_Crystal Flakes|r].
.complete 66232,1 
.mob Brinetooth Hunter
.mob Brinetooth Bruiser
.mob Brinetooth Wavecrasher
step
#title First clue found
.goto 2024,9.38,42.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mordigan's Field Notes|r.
.complete 66177,1 
step
#title Second clue found
.goto 2024,10.02,41.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mordigan's Flask|r.
.complete 66177,2 
step
#title Third clue found
.goto 2024,9.93,39.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mordigan's Boots|r.
.complete 66177,3 
step
#title Fourth clue found
.goto 2024,10.61,41.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Mordigan's Pants|r.
.complete 66177,4 
step
#loop
.goto 2024,10.22,41.79,30,0
.goto 2024,9.34,42.87,30,0
.goto 2024,9.72,40.64,30,0
.goto 2024,10.47,41.14,30,0
>>Kill the |cRXP_ENEMY_Brinetooths|r in the area. Loot them for the Crystal Flakes
.complete 66232,1 
.mob Brinetooth Hunter
.mob Brinetooth Bruiser
.mob Brinetooth Wavecrasher
step
.goto 2024,10.77,41.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aelnara|r.
.turnin 66177 >>Turn in No Dwarf Left Behind
.accept 66187 >>Accept Mad Mordigan & The Crystal King
.target Aelnara
step
.goto 2024,11.19,41.10
>>Kill |cRXP_ENEMY_Mordigan Ironjaw|r inside the cave.
.complete 66187,1 
.mob Mordigan Ironjaw
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Aelnara
.goto 2024,10.77,41.18
.turnin 66187 >>Turn in Mad Mordigan & The Crystal King
.accept 66559 >>Accept Back To Camp
.target Aelnara
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Examiner Rowe|r and |cRXP_FRIENDLY_Wayun|r.
.turnin 66559 >>Turn in Back To Camp
.goto 2024,7.67,44.27
.target +Examiner Rowe
.turnin -66232 >>Turn in Afront 'Till A Salt
.goto 2024,7.46,44.28
.target +Wayun
step
#completewith next
.hs >>Hearth to The Conjured Biscuit Inn
step
.goto 2024,39.48,63.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65911 >>Turn in Azure Alignment
.accept 66027 >>Accept Calling the Blue Dragons
.target Kalecgos
step
.goto 2024,39.48,63.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.complete 66027,1 
.target Kalecgos
.skipgossip 186280,1
step
.goto 2024,39.48,63.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 66027 >>Turn in Calling the Blue Dragons
.accept 65886 >>Accept To Rhonin's Shield
.target Kalecgos
step
>>Follow the arrow and use the |cRXP_WARN_[ExtraActionButton]|r.
.goto 2024,41.19,62.27,-1
.goto 2024,39.56,60.26,-1
.goto 2024,38.26,61.50,-1
.complete 65886,2 
step
.goto 2024,59.26,39.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_WARN_Follow the arrow|r. Talk to |cRXP_FRIENDLY_Old Grimtusk|r.
.accept 66709 >>Accept Field Medic 101
.target Old Grimtusk
step
.goto 2024,59.26,39.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Gnoll Spear|r.
.complete 66709,1 
step
.goto 2024,59.20,39.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Piles of Wood|r around the sled.
.complete 66709,2 
step
.goto 2024,59.25,39.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the shade of the |cRXP_PICK_Campfire|r.
.complete 66709,3 
step
.goto 2024,59.26,39.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Grimtusk|r.
.complete 66709,4 
.target Old Grimtusk
.skipgossipid 55063
step
.goto 2024,59.26,39.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Grimtusk|r.
.turnin 66709 >>Turn in Field Medic 101
.accept 66715 >>Accept The Extraction
.target Old Grimtusk
step
#completewith TheAzureSpanFrostbiteCausesandSymptoms
>>Kill the |cRXP_ENEMY_Snowhide Gnolls|r.
>>Or |TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Weapon Racks|r, |cRXP_PICK_Snowhide Shrines|r, or |cRXP_PICK_Snowhide Pennants|r.
.accept 66718 >>Accept Gnolls Must Die (Bonus Objective)
.complete 66718,1 
.mob Snowhide Brute
.mob Snowhide Mongrel
.mob Snowhide Yeti Hunter
step
.goto 2024,58.34,41.83
#title |cFFFCDC00Follow the Arrow|r
.complete 66715,1 
step
.goto 2024,58.38,41.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Frostbite|r.
.turnin 66715 >>Turn in The Extraction
.accept 66703 >>Accept Snowball Effect
.target Frostbite
step
#completewith next
.goto 2024,58.34,42.60,15,0
>>Kill |cRXP_ENEMY_Snowhide Shamans|r. Loot them for the |T135829:0|t[|cRXP_LOOT_Snowhide Totems|r].
.complete 66703,1 
.mob Snowhide Shaman
step
.goto 2024,57.90,44.82
>>Kill |cRXP_ENEMY_Snoll the Icebreaker|r.
.complete 66718,2 
.mob Snoll the Icebreaker
step
#loop
.goto 2024,58.34,42.64,20,0
.goto 2024,56.89,42.33,20,0
.goto 2024,57.64,41.53,20,0
.goto 2024,58.34,42.64,20,0
.goto 2024,56.89,42.33,20,0
.goto 2024,57.64,41.53,20,0
>>Kill |cRXP_ENEMY_Snowhide Shamans|r. Loot them for the totems.
.complete 66703,1 
.mob Snowhide Shaman
.mob Snowhide Brute
.mob Snowhide Mongrel
.mob Snoll the Icebreaker
.mob Snowhide Yeti Hunter
step
.goto 2024,58.42,41.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Frostbite|r.
.turnin 66703 >>Turn in Snowball Effect
.accept 67050 >>Accept Frostbite: Causes and Symptoms
.target Frostbite
step
#label TheAzureSpanFrostbiteCausesandSymptoms
.goto 2024,58.24,41.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the shade of the |cRXP_PICK_Snowhide Totems|r.
.complete 67050,1 
step
#loop
.goto 2024,58.11,43.08,32,0
.goto 2024,57.51,44.10,32,0
.goto 2024,57.21,42.10,32,0
.goto 2024,57.72,41.50,32,0
.goto 2024,58.37,41.56,32,0
.goto 2024,58.37,42.66,32,0
>>Kill the |cRXP_ENEMY_Snowhide Gnolls|r.
>>Or |TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Weapon Racks|r, |cRXP_PICK_Snowhide Shrines|r, or |cRXP_PICK_Snowhide Pennants|r.
.complete 66718,1 
.mob Snowhide Shaman
step
.goto 2024,58.48,40.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Grimtusk|r.
.complete 67050,2 
.target Old Grimtusk
step
.goto 2024,58.48,40.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Grimtusk|r.
.turnin 67050 >>Turn in Frostbite: Causes and Symptoms
.accept 66730 >>Accept True Survivors
.target Old Grimtusk
step
.goto 2024,58.79,34.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Grimtusk|r.
.turnin 66730 >>Turn in True Survivors
.target Old Grimtusk
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Callisto Windsor|r and |cRXP_FRIENDLY_Steria Duskgrove|r.
.accept 68639 >>Accept Prowling Polar Predators
.goto 2024,63.59,28.90
.target +Callisto Windsor
.accept 68641 >>Accept Mossing the Mark
.goto 2024,63.61,28.82
.target +Steria Duskgrove
step
#completewith TheAzureSpanMossingtheMark
>>Kill |cRXP_ENEMY_Infected Frigidpelts|r.
.complete 68639,1 
.mob Prowling Frigidpelt
.mob Prowling Matriarch
step
#title Drakmoss Clump (1/5)
.goto 2024,63.68,30.66
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drakmoss|r.
.complete 68641,1,1 
step
#title Drakmoss Clump (2/5)
.goto 2024,63.57,30.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drakmoss|r.
.complete 68641,1,2 
step
#title Drakmoss Clump (3/5)
.goto 2024,63.53,31.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drakmoss|r.
.complete 68641,1,3 
step
#title Drakmoss Clump (4/5)
.goto 2024,63.41,31.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drakmoss|r.
.complete 68641,1,4 
step
#label TheAzureSpanMossingtheMark
#title Drakmoss Clump (5/5)
.goto 2024,63.22,31.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Drakmoss|r.
.complete 68641,1 
step
#loop
.goto 2024,62.89,31.76,25,0
.goto 2024,62.51,30.50,25,0
.goto 2024,63.85,29.84,25,0
.goto 2024,63.79,31.03,25,0
.goto 2024,62.89,31.76,25,0
.goto 2024,62.51,30.50,25,0
.goto 2024,63.85,29.84,25,0
.goto 2024,63.79,31.03,25,0
>>Kill |cRXP_ENEMY_Infected Frigidpelts|r.
.complete 68639,1 
.mob Prowling Frigidpelt
.mob Prowling Matriarch
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Callisto Windsor|r and |cRXP_FRIENDLY_Steria Duskgrove|r.
.turnin 68639 >>Turn in Prowling Polar Predators
.goto 2024,63.59,28.90
.target +Callisto Windsor
.turnin 68641 >>Turn in Mossing the Mark
.goto 2024,63.61,28.82
.target +Steria Duskgrove
step
.goto 2024,65.81,25.33
#title |cFFFCDC00Follow the Arrow|r
.complete 65886,1 
step
.goto 2024,65.81,25.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drok Scrollstabber|r.
.turnin 65886 >>Turn in To Rhonin's Shield
.accept 65887 >>Accept To the Mountain
.target Drok Scrollstabber
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Drok Scrollstabber
.goto 2024,65.81,25.33
.accept 67299 >>Accept Drakes be Gone
.target Drok Scrollstabber
step
#completewith next
#label ProtoDrakeSlainArcaneBlaster
.goto 2024,65.71,25.56,0,0
>>Use |T429383:0|t[Arcane Blast] (1) to kill the |cRXP_ENEMY_Proto-Drakes|r.
>>You can use |T132309:0|t[Arcane Stasis] (2) to slow them
.complete 67299,1 
.mob Proto-Drake
step
#completewith ProtoDrakeSlainArcaneBlaster
.goto 2024,65.71,25.56,10,0
.goto 2024,65.85,26.75,10,0
.goto 2024,66.03,25.60,10,0
.vehicle 192872 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Blaster|r.
step
#requires ProtoDrakeSlainArcaneBlaster
.goto 2024,65.71,25.56
>>Use |T429383:0|t[Arcane Blast] (1) to kill the |cRXP_ENEMY_Proto-Drakes|r.
>>You can use |T132309:0|t[Arcane Stasis] (2) to slow them
.complete 67299,1 
.mob Proto-Drake
step
.goto 2024,65.81,25.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drok Scrollstabber|r.
.turnin 67299 >>Turn in Drakes be Gone
.target Drok Scrollstabber
step
.goto 2024,65.39,15.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sonova Snowden|r.
.accept 66553 >>Accept Hollow Up
.accept 66554 >>Accept Aggressive Self-Defence
.target Sonova Snowden
step
.goto 2024,65.56,16.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrnokos Sunstrike|r.
.accept 66622 >>Accept Wayward Tools
.target Tyrnokos Sunstrike
step
#loop
.goto 2024,65.96,16.51,25,0
.goto 2024,65.82,17.41,25,0
.goto 2024,65.25,17.23,25,0
.goto 2024,64.82,17.31,25,0
.goto 2024,64.71,16.83,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wayward Tools|r. (possible while mounted)
.complete 66622,1 
.target Wayward Tool
step
#completewith TheAzureSpanHollowUp
>>Defeat |cRXP_ENEMY_Winterpelt Furbolgs|r.
.complete 66554,1 
.mob Winterpelt Defender
.mob Winterpelt Snowspeaker
.mob Winterpelt Guardian
step
#title Clue uncovered (1/6)
.goto 2024,66.48,13.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Electrocuted Winterpelt|r.
.complete 66553,1,1 
step
#title Clue uncovered (2/6)
.goto 2024,66.56,12.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Electrocuted Winterpelt|r.
.complete 66553,1,2 
step
#title Clue uncovered (3/6)
.goto 2024,66.81,12.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Storm Shorn Stump|r.
.complete 66553,1,3 
step
#title Clue uncovered (4/6)
.goto 2024,66.53,12.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tumbled Standing Stone|r.
.complete 66553,1,4 
step
#title Clue uncovered (5/6)
.goto 2024,66.29,12.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Electrocuted Winterpelt|r.
.complete 66553,1,5 
step
#label TheAzureSpanHollowUp
#title Clue uncovered (6/6)
.goto 2024,66.11,13.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wind Felled Tree|r.
.complete 66553,1 
step
#loop
.goto 2024,65.85,12.78,35,0
.goto 2024,66.82,13.47,35,0
.goto 2024,66.96,11.89,35,0
.goto 2024,65.85,12.78,35,0
>>Defeat |cRXP_ENEMY_Winterpelt Furbolgs|r.
.complete 66554,1 
.mob Winterpelt Furbolg
step
.goto 2024,65.38,15.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sonova Snowden|r.
.turnin 66553 >>Turn in Hollow Up
.turnin 66554 >>Turn in Aggressive Self-Defence
.target Sonova Snowden
step
.goto 2024,65.38,15.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sonova Snowden|r.
.accept 66555 >>Accept Bear With Me
.target Sonova Snowden
step
.goto 2024,65.38,15.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sonova Snowden|r.
.complete 66555,1 
.target Sonova Snowden
.skipgossip 189401,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sonova Snowden|r and |cRXP_FRIENDLY_Tyrnokos Sunstrike|r.
.turnin 66555 >>Turn in Bear With Me
.goto 2024,65.38,15.95
.target +Sonova Snowden
.turnin 66622 >>Turn in Wayward Tools
.goto 2024,65.57,16.17
.target +Tyrnokos Sunstrike
step
.goto 2024,70.12,33.26
#title |cFFFCDC00Follow the Arrow|r Kill the |cRXP_ENEMY_Summoned Destroyer|r.
.accept 69895 >>Accept Summoned Destroyer (Elite Objective)
.complete 69895,1 
.mob Summoned Destroyer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r and |cRXP_FRIENDLY_Khadgar|r.
.turnin 65887 >>Turn in To the Mountain
.accept 65943 >>Accept Primal Offensive
.goto 2024,70.01,35.23
.target +Kalecgos
.accept 65944 >>Accept Lava Burst
.accept 66647 >>Accept Elemental Unfocus
.goto 2024,70.02,35.34
.target +Archmage Khadgar
step
#completewith LavaBurst
.goto 2024,72.44,37.27,0,0
>>Kill the |cRXP_ENEMY_Primalist forces|r in the area.
.complete 65943,1 
.mob Primal Fire Elemental
.mob Fiery Carver
.mob Mountain Shaper
step
#title Lava Orb destroyed (1/3)
.goto 2024,71.23,35.69,30,0
.goto 2024,72.26,37.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lava Orb|r.
.complete 65944,1,1 
step
>>Kill |cRXP_ENEMY_Ruvin Stonegrinder|r. Loot her for the |T1:0|t[|cRXP_LOOT_Elemental Focus|r].
.goto 2024,72.51,38.11,30,0
.goto 2024,72.90,38.71
.complete 66647,1 
.mob Ruvin Stonegrinder
step
#title Lava Orb destroyed (2/3)
.goto 2024,73.11,37.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lava Orb|r.
.complete 65944,1,2 
step
#label LavaBurst
#title Lava Orb destroyed (3/3)
.goto 2024,73.77,38.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lava Orb|r.
.complete 65944,1 
step
#loop
.goto 2024,74.06,38.19,35,0
.goto 2024,72.67,37.80,35,0
.goto 2024,71.13,35.49,45,0
>>Kill the |cRXP_ENEMY_Primalist forces|r in the area.
.complete 65943,1 
.mob Primal Fire Elemental
.mob Fiery Carver
.mob Mountain Shaper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r and |cRXP_FRIENDLY_Kalecgos|r.
.turnin 65944 >>Turn in Lava Burst
.turnin 66647 >>Turn in Elemental Unfocus
.goto 2024,74.46,37.84
.target +Archmage Khadgar
.turnin 65943 >>Turn in Primal Offensive
.accept 65958 >>Accept Primal Power
.goto 2024,74.47,37.81
.target +Kalecgos
.accept 65977 >>Accept Kirin Tor Recovery
.goto 2024,74.46,37.84
.target +Archmage Khadgar
step
#completewith TheAzureSpanKirinTorRecovery
.goto 2024,75.42,37.92,0,0
>>Use |T1769011:0:0|t[Elemental Focus] next to corpses of |cRXP_ENEMY_Primalists/Elementals|r.
>>|cRXP_WARN_Avoid killing |cRXP_ENEMY_ELEMENTAL PUNISHERS|r. if you're alone|r.
.complete 65958,1 
.use 192479
.mob Primal Lava Elemental
.mob Primalist Worshipper
step
#title Mage rescued (1/6)
.goto 2024,74.59,38.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elemental Drainer|r.
.complete 65977,1,1 
step
#title Mage rescued (2/6)
.goto 2024,75.27,37.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elemental Drainer|r.
.complete 65977,1,2 
step
#title Mage rescued (3/6)
.goto 2024,76.14,37.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elemental Drainer|r.
.complete 65977,1,3 
step
#title Mage rescued (4/6)
.goto 2024,75.63,38.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elemental Drainer|r.
.complete 65977,1,4 
step
#title Mage rescued (5/6)
.goto 2024,76.02,39.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elemental Drainer|r.
.complete 65977,1,5 
step
#label TheAzureSpanKirinTorRecovery
#title Mage rescued (6/6)
.goto 2024,76.57,38.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elemental Drainer|r.
.complete 65977,1 
step
#loop
.goto 2024,75.94,37.82,35,0
.goto 2024,75.01,37.74,35,0
.goto 2024,75.49,38.32,35,0
.goto 2024,75.83,39.22,35,0
.goto 2024,75.94,37.82,35,0
.goto 2024,75.01,37.74,35,0
.goto 2024,75.49,38.32,35,0
.goto 2024,75.83,39.22,35,0
.goto 2024,75.42,37.92,35,0
>>Use |T1769011:0:0|t[Elemental Focus] next to corpses of |cRXP_ENEMY_Primalists/Elementals|r.
>>|cRXP_WARN_Avoid killing ELEMENTAL PUNISHERS if you're alone|r.
.complete 65958,1 
.use 192479
step
.goto 2024,76.95,39.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.turnin 65958 >>Turn in Primal Power
.turnin 65977 >>Turn in Kirin Tor Recovery
.accept 66007 >>Accept Free Air
.target Archmage Khadgar
step
#hidewindow
#label LavaBeaconsDestroyedA
#completewith next
.complete 66007,1 
step
#completewith LavaBeaconsDestroyedA
.goto 2024,76.95,39.43
.cast 378814 >>Use the |cRXP_WARN_[ExtraActionButton]|r.
step
#requires LavaBeaconsDestroyedA
#completewith TheAzureSpanFreeAir
+You can |TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Lava Beacons|r while dug in.
step
#requires LavaBeaconsDestroyedA
#title Beacon destroyed (1/4)
.goto 2024,77.36,39.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lava Beacons|r.
>>Use |T538536:0:0|t[Ember Dash] (1) to charge forward
>>Use |T132331:0:0|t[Hide] (2) to hide from the |cRXP_ENEMY_Ritual Scouts|r.
.complete 66007,1,1 
.mob Ritual Scout
step
#title Beacon destroyed (2/4)
.goto 2024,77.34,38.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lava Beacons|r.
>>Use |T538536:0:0|t[Ember Dash] (1) to charge forward
>>Use |T132331:0:0|t[Hide] (2) to hide from the |cRXP_ENEMY_Ritual Scouts|r.
.complete 66007,1,2 
.mob Ritual Scout
step
#title Beacon destroyed (3/4)
.goto 2024,78.24,37.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lava Beacons|r.
>>Use |T538536:0:0|t[Ember Dash] (1) to charge forward
>>Use |T132331:0:0|t[Hide] (2) to hide from the |cRXP_ENEMY_Ritual Scouts|r.
.complete 66007,1,3 
.mob Ritual Scout
step
#label TheAzureSpanFreeAir
#title Beacon destroyed (4/4)
.goto 2024,78.55,39.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lava Beacons|r.
>>Use |T538536:0:0|t[Ember Dash] (1) to charge forward
>>Use |T132331:0:0|t[Hide] (2) to hide from the |cRXP_ENEMY_Ritual Scouts|r.
.complete 66007,1 
.mob Ritual Scout
step
#completewith next
#label FreeAirVakthros
.goto 2024,78.38,39.98,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 66007 >>Turn in Free Air
.accept 66009 >>Accept In Defense of Vakthros
.target Kalecgos
step
#completewith FreeAirVakthros
#title Enter Cave
.goto 2024,78.69,39.62,10 >>Enter the cave
step
#requires FreeAirVakthros
.goto 2024,78.38,39.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.turnin 66007 >>Turn in Free Air
.accept 66009 >>Accept In Defense of Vakthros
.target Kalecgos
step
.goto 2024,79.27,36.33
>>Kill |cRXP_ENEMY_Korthrox the Destroyer|r.
*|cRXP_WARN_During |T459027:0|tReaping Flame run through the |cRXP_PICK_Arcane Runes|r|r. They give you a damage immunity for 4s.
.complete 66009,1 
.mob Korthrox the Destroyer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Khadgar|r.
.goto 2024,77.99,32.47
.turnin 66009 >>Turn in In Defense of Vakthros
.accept 70041 >>Accept The Storm-Eater's Fury
.target Archmage Khadgar
step
.goto 2024,78.03,32.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Disc|r.
.complete 70041,1 
step
.goto 2024,78.06,32.73
>>Use |T134155:0|t[Kalecgos's Aid] (2) on cooldown
>>Spam |T135734:0:0|t[Arcane Blast] (1) to kill the primalists
.complete 70041,2 
step
.goto 2024,78.06,32.73
>>Use |T135739:0:0|t[Azure Dispel] (3) on the grey lightning tornadoes
.complete 70041,3 
step
.goto 2024,78.06,32.73
>>Use |T134155:0:0|t[Kalecgos's Aid] (2) on cooldown
>>Spam |T135734:0:0|t[Arcane Blast] (1)
.complete 70041,4
step
#completewith next
.exitvehicle >>|cRXP_WARN_Dismount early with (6)!|r.
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kalecgos|r.
.goto 2024,78.22,33.34
.turnin 70041 >>Turn in The Storm-Eater's Fury
.accept 66015 >>Accept The Blue Dragon Oathstone
.target Kalecgos
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kattigat|r and |cRXP_FRIENDLY_To'tik|r.
.accept 67111 >>Accept The Ailing Apprentice
.goto 2024,67.22,44.41
.target +Kattigat
.accept 67724 >>Accept The Fending Flames
.accept 70856 >>Accept Kill it with Fire
.goto 2024,67.34,44.35
.target +To'tik
step
#completewith TheAzureSpanTheFendingFlames
>>Use the |T135433:0|t[Flamethrower Torch] to burn the plunderer corpses on the ground
.complete 70856,1 
.use 199928
step
#completewith TheAzureSpanTheFendingFlames
>>Kill |cRXP_ENEMY_Shiverweb Crawlers|r. Loot them for their venom glands.
.complete 67111,1 
.mob Shiverweb Crawler
step
#title Silk (1/4)
.goto 2024,68.07,43.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spider Silk Cocoon|r.
.complete 67724,1,1 
step
#title Silk (2/4)
.goto 2024,68.50,43.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spider Silk Cocoon|r.
.complete 67724,1,2 
step
#title Silk (3/4)
.goto 2024,68.74,45.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spider Silk Cocoon|r.
.complete 67724,1,3 
step
#label TheAzureSpanTheFendingFlames
#title Silk (4/4)
.goto 2024,68.48,45.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spider Silk Cocoon|r.
.complete 67724,1 
step
#completewith InfectedPlunderersBurned
#hidewindow
#loop
.goto 2024,68.42,47.11,35,0
.goto 2024,69.00,44.06,45,0
.goto 2024,67.87,43.37,45,0
+1
step
#completewith next
>>Use the |T135433:0|t[Flamethrower Torch] to burn the plunderer corpses on the ground
.complete 70856,1 
.use 199928
step
.goto 2024,68.86,45.36
>>Kill |cRXP_ENEMY_Shiverweb Crawlers|r. Loot them for the |T237414:0|t[|cRXP_LOOT_Frozen Venom Glands|r].
.complete 67111,1 
.mob Shiverweb Crawler
step
#label InfectedPlunderersBurned
>>Use the |T135433:0|t[Flamethrower Torch] to burn the plunderer corpses on the ground
.complete 70856,1 
.target Infected Plunderers
.use 199928
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_To'tik|r and |cRXP_FRIENDLY_Kattigat|r.
.turnin 67724 >>Turn in The Fending Flames
.turnin 70856 >>Turn in Kill it with Fire
.goto 2024,67.34,44.35
.target +To'tik
.turnin 67111 >>Turn in The Ailing Apprentice
.accept 70858 >>Accept Back into the Action
.goto 2024,67.22,44.41
.target +Kattigat
step
.goto 2024,67.23,44.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Alia Sunsoar|r on the ground.
.complete 70858,1 
.target Alia Sunsoar
step
.goto 2024,67.30,44.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alia Sunsoar|r.
.turnin 70858 >>Turn in Back into the Action
.accept 70859 >>Accept What the Guardian Beholds
.target Alia Sunsoar
step
.goto 2024,69.53,43.18
>>Kill |cRXP_ENEMY_Edavix|r. Loot him for the |T132875:0|t[|cRXP_LOOT_Whispering Shard|r].
.complete 70859,1 
.mob Edavix
step
.goto 2024,67.30,44.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alia Sunsoar|r.
.turnin 70859 >>Turn in What the Guardian Beholds
.target Alia Sunsoar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r and |cRXP_FRIENDLY_Maddy Scattershot|r.
.accept 66391 >>Accept To the Ruins!
.goto 2024,63.44,57.99
.target +Rannan Korren
.turnin 66671 >>Turn in Path to Nowhere
.goto 2024,63.22,58.4
.target +Maddy Scattershot
step
.goto 2024,63.20,58.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garz|r.
.accept 66141 >>Accept Broken Traditions, Broken Bodies
.target Garz
step
.goto 2024,65.02,58.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 66391 >>Turn in To the Ruins!
.target Rannan Korren
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r and |cRXP_FRIENDLY_Lathos Sunband|r.
.accept 66353 >>Accept R.A.D. Anomalies
.goto 2024,65.02,58.61
.target +Rannan Korren
.accept 66352 >>Accept What the Enemy Knows
.goto 2024,65.00,58.62
.target +Lathos Sunband
step
#completewith TheAzureSpanRADAnomalies
>>Kill |cRXP_ENEMY_Tarasek Warriors|r and |cRXP_ENEMY_Arcane Manipulator|r. Loot them for the |T1103070:0|t[|cRXP_LOOT_Sundered Flames Expedition Orders|r].
.complete 66352,1 
.mob Tarasek Warrior
.mob Arcane Manipulator
step
#title Record (1/3)
>>Use |T134519:0|t[R.A.D] next to the anomalies
.use 191909
.goto 2024,65.52,58.82
.complete 66353,1,1 
step
#title Record (2/3)
>>Use |T134519:0|t[R.A.D] next to the anomalies
.use 191909
.goto 2024,66.31,59.37
.complete 66353,1,2 
step
#label TheAzureSpanRADAnomalies
#title Record (3/3)
>>Use |T134519:0|t[R.A.D] next to the anomalies
.goto 2024,66.39,59.72
.complete 66353,1 
.use 191909
step
>>Kill |cRXP_ENEMY_Tarasek Warriors|r and |cRXP_ENEMY_Arcane Manipulator|r. Loot them for the |T1103070:0|t[|cRXP_LOOT_Sundered Flames Expedition Orders|r].
.goto 2024,65.09,59.54,20,0
.goto 2024,66.35,59.56,20,0
.goto 2024,65.54,59.28
.complete 66352,1 
.mob Tarasek Warrior
.mob Arcane Manipulator
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r and |cRXP_FRIENDLY_Lathos Sunband|r.
.turnin 66353 >>Turn in R.A.D. Anomalies
.goto 2024,65.02,58.62
.target +Rannan Korren
.turnin 66352 >>Turn in What the Enemy Knows
.accept 66422 >>Accept The Expedition Continues!
.goto 2024,65.00,58.62
.target +Lathos Sunband
step
.goto 2024,65.64,60.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lathos Sunband|r.
.turnin 66422 >>Turn in The Expedition Continues!
.accept 66423 >>Accept Worries and Validations
.target Lathos Sunband
step
#title Clue Found (1/2)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ruined Draconic Tablet|r.
.goto 2024,65.32,60.80
.complete 66423,1,1 
step
#title Clue Found (2/2)
.goto 2024,65.86,60.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Time-Worn Draconic Tablet|r.
.complete 66423,1 
step
.goto 2024,65.64,60.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lathos Sunband|r.
.turnin 66423 >>Turn in Worries and Validations
.target Lathos Sunband
step
.goto 2024,65.63,60.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.accept 66425 >>Accept Arcane Overload
.target Rannan Korren
step
#title Bubble Dispelled (1/3)
.goto 2024,65.28,61.31
>>Use |T134519:0|t[R.A.D.D.E.R] to dispel the barriers
*Cancel Ghost Wolf as a Shaman <<Shaman
.complete 66425,1,1 
.use 192110
step
#title Bubble Dispelled (2/3)
.goto 2024,65.10,61.54
>>Use |T134519:0|t[R.A.D.D.E.R] to dispel the barriers
*Cancel Ghost Wolf as a Shaman <<Shaman
.complete 66425,1,2 
.use 192110
step
#title Bubble Dispelled (3/3)
.goto 2024,65.18,60.95,10,0
.goto 2024,65.00,61.24,10,0
.goto 2024,65.06,61.14
>>Use |T134519:0|t[R.A.D.D.E.R] to dispel the barriers on the second floor
*Cancel Ghost Wolf as a Shaman <<Shaman
.complete 66425,1 
.use 192110
step
.goto 2024,65.63,60.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 66425 >>Turn in Arcane Overload
.target Rannan Korren
step
.goto 2024,65.64,60.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lathos Sunband|r.
.accept 66426 >>Accept Running Out of Time
.target Lathos Sunband
step
.goto 2024,68.46,60.50
>>|cRXP_WARN_Follow the arrow and wait for the roleplay|r.
.complete 66426,1 
step
.goto 2024,68.46,60.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lathos Sunband|r.
.turnin 66426 >>Turn in Running Out of Time
.accept 66427 >>Accept A Looming Menace
.target Lathos Sunband
step
.goto 2024,68.07,61.59
>>Kill |cRXP_ENEMY_Arcane Manipulator Tharohn|r.
.complete 66427,1 
.mob Arcane Manipulator Tharohn
step
.goto 2024,68.46,60.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lathos Sunband|r.
.turnin 66427 >>Turn in A Looming Menace
.target Lathos Sunband
step
.goto 2024,68.48,60.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.accept 66428 >>Accept Friendship For Granted
.target Rannan Korren
step
.goto 2024,68.61,60.39
>>Use the |T134519:0|t[R.A.D.D.E.R.E.R] next to the console
.complete 66428,1 
.use 192475
step
.goto 2024,68.50,60.47
>>|cRXP_WARN_Wait for the roleplay|r.
.complete 66428,2 
step
.goto 2024,68.50,60.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 66428 >>Turn in Friendship For Granted
.accept 66429 >>Accept I Will Remember
.target Rannan Korren
step
.goto 2024,65.62,54.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narn|r.
.complete 66141,1 
.target Narn
.skipgossip
step
.goto 2024,63.51,52.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garz|r.
.turnin 66141 >>Turn in Broken Traditions, Broken Bodies
.target Garz
step
.goto 2024,63.51,52.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garz|r.
.accept 66150 >>Accept Rescuing Radza
.accept 66149 >>Accept Elemental Influence
.accept 66148 >>Accept Former Furbolg Family
.target Garz
step
#completewith next
>>Kill |cRXP_ENEMY_Furbolgs|r and |cRXP_ENEMY_Elementals|r.
.complete 66148,1 
.mob Stonegrabber Fragment
.mob Rustpine Immolator
.mob Rustpine Fireflinger
.mob Rustpine Loamcrafter
step
#title Totem destroyed (1/3)
.goto 2024,62.74,51.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primalist Earthbind Totem|r.
.complete 66149,1,1 
step
#completewith next
.goto 2024,62.71,51.28,15,0
>>Kill |cRXP_ENEMY_Furbolgs|r and |cRXP_ENEMY_Elementals|r.
.complete 66148,1 
.mob Stonegrabber Fragment
.mob Rustpine Immolator
.mob Rustpine Fireflinger
.mob Rustpine Loamcrafter
step
#title Totem destroyed (2/3)
.goto 2024,62.29,51.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primalist Earthbind Totem|r.
.complete 66149,1,2 
step
#completewith next
.goto 2024,62.21,50.66,15,0
>>Kill |cRXP_ENEMY_Furbolgs|r and |cRXP_ENEMY_Elementals|r.
.complete 66148,1 
.mob Stonegrabber Fragment
.mob Rustpine Immolator
.mob Rustpine Fireflinger
.mob Rustpine Loamcrafter
step
#title Totem destroyed (3/3)
.goto 2024,62.02,51.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primalist Earthbind Totem|r.
.complete 66149,1 
step
.goto 2024,60.94,51.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Radza Thunderclaw|r.
*Defeat the incoming waves of |cRXP_ENEMY_enemies|r.
.complete 66150,1 
.complete 66150,2 
.mob Stonegrabber Fragment
.mob Rustpine Loamcrafter
.mob Rustpine Rager
.mob Khargall Fivefangs
.target Radza Thunderclaw
.skipgossipid 54654
step
#loop
.goto 2024,61.51,52.07,15,0
.goto 2024,61.47,52.93,15,0
.goto 2024,61.58,54.22,25,0
.goto 2024,61.51,52.07,25,0
>>Kill |cRXP_ENEMY_Furbolgs|r and |cRXP_ENEMY_Elementals|r.
.complete 66148,1 
.mob Stonegrabber Fragment
.mob Rustpine Immolator
.mob Rustpine Fireflinger
.mob Rustpine Loamcrafter
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narn|r and |cRXP_FRIENDLY_Radza Thunderclaw|r. (you may have to wait for him)
.turnin 66148 >>Turn in Former Furbolg Family
.turnin 66149 >>Turn in Elemental Influence
.goto 2024,60.93,50.59
.target +Narn
.turnin 66150 >>Turn in Rescuing Radza
.accept 66151 >>Accept His Stone Heart
.goto 2024,60.91,50.51
.target +Radza Thunderclaw
step
.goto 2024,60.47,49.43
>>Kill |cRXP_ENEMY_Stoneheart|r. |cRXP_WARN_Stay away during his ability "Earth Torrent"|r.
.complete 66151,1 
.mob Stoneheart
step
.goto 2024,60.91,50.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Radza Thunderclaw|r.
.turnin 66151 >>Turn in His Stone Heart
.target Radza Thunderclaw
step
.goto 2024,60.99,50.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garz|r.
.accept 66152 >>Accept Nowhere to Go
.target Garz
step
.goto 2024,63.20,58.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garz|r.
.turnin 66152 >>Turn in Nowhere to Go
.target Garz
step
.goto 2024,63.68,58.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.turnin 66429 >>Turn in I Will Remember
.target Rannan Korren
step
.goto 2024,51.73,61.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilial Dawnburst|r.
.accept 65750 >>Accept Eight-Legged Menace
.accept 65769 >>Accept Icy Webs
.target Lilial Dawnburst
step
#completewith IcyWebs
>>Kill the |cRXP_ENEMY_Shiverwebs|r and |cRXP_ENEMY_Primalists|r.
.complete 65750,1 
.complete 65750,2 
.mob Shiverweb Creeper
.mob Shiverweb Crawler
.mob Primalist Tender
step
#title Survivor freed (1/6)
.goto 2024,51.07,61.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cocooned Survivor|r.
.complete 65769,1,1 
.target Cocooned Survivor
step
#title Survivor freed (2/6)
.goto 2024,50.45,61.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cocooned Survivor|r.
.complete 65769,1,2 
.target Cocooned Survivor
step
#title Survivor freed (3/6)
.goto 2024,49.86,61.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cocooned Survivor|r.
.complete 65769,1,3 
.target Cocooned Survivor
step
#title Survivor freed (4/6)
.goto 2024,49.62,61.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cocooned Survivor|r.
.complete 65769,1,4 
.target Cocooned Survivor
step
#title Survivor freed (5/6)
.goto 2024,49.96,60.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cocooned Survivor|r.
.complete 65769,1,5 
.target Cocooned Survivor
step
#label IcyWebs
#title Survivor freed (6/6)
.goto 2024,50.18,59.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cocooned Survivor|r.
.complete 65769,1 
.target Cocooned Survivor
step
#loop
.goto 2024,50.96,62.12,35,0
.goto 2024,49.73,61.32,35,0
.goto 2024,50.17,57.93,40,0
.goto 2024,51.60,61.14,40,0
>>Kill the |cRXP_ENEMY_Shiverwebs|r and |cRXP_ENEMY_Primalists|r.
.complete 65750,1 
.complete 65750,2 
.mob Shiverweb Creeper
.mob Shiverweb Crawler
.mob Primalist Tender
step
.goto 2024,51.73,61.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilial Dawnburst|r.
.turnin 65769 >>Turn in Icy Webs
.turnin 65750 >>Turn in Eight-Legged Menace
.accept 65758 >>Accept Grungir the Explorer
.target Lilial Dawnburst
step
.goto 2024,48.99,64.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grungir Ironspout|r.
.turnin 65758 >>Turn in Grungir the Explorer
.accept 65832 >>Accept Dwarven Antifreeze
.accept 65833 >>Accept Primalist Tampering
.target Grungir Ironspout
step
#completewith next
>>Kill |cRXP_ENEMY_Primalist Infusers|r or |cRXP_ENEMY_Shiverweb Spiders|r. Loot them for the |T2965290:0|t[|cRXP_LOOT_Flask of Dwarven Antifreeze|r].
.complete 65832,1 
.mob Primalist Infuser
.mob Shiverweb Cloaker
.mob Shiverweb Crusher
step
.goto 2024,49.07,66.06
>>Kill |cRXP_ENEMY_Frostcaller Sin'tia|r. Loot her for |T4643989:0|t[|cRXP_LOOT_Sin'tia's Runestone|r].
*|cRXP_WARN_Interrupt the|r Frozen Onslaught
.complete 65833,3 
.mob Frostcaller Sin'tia
step
#completewith next
#label NaijinsRunestone
.goto 2024,47.60,64.63
>>Kill |cRXP_ENEMY_Frostcaller Nai'jin|r. Loot her for |T4643989:0|t[|cRXP_LOOT_Nai'jin's Runestone|r].
*|cRXP_WARN_Interrupt the|r Frozen Onslaught
.complete 65833,2 
.mob Frostcaller Nai'jin
step
#completewith NaijinsRunestone
#title Enter Cave
.goto 2024,48.37,64.00,15 >>Enter the cave
step
#requires NaijinsRunestone
>>Kill |cRXP_ENEMY_Frostcaller Nai'jin|r. Loot her for |T4643989:0|t[|cRXP_LOOT_Nai'jin's Runestone|r].
*|cRXP_WARN_Interrupt the|r Frozen Onslaught
.goto 2024,47.60,64.63
.complete 65833,2 
.mob Frostcaller Nai'jin
step
.goto 2024,47.68,62.38
>>Kill |cRXP_ENEMY_Frostcaller Julh'ek|r. Loot him for |T4643989:0|t[|cRXP_LOOT_Julh'ek's Runestone|r].
.complete 65833,1 
.mob Frostcaller Julh'ek
step
#loop
.goto 2024,49.59,62.61,40,0
.goto 2024,50.23,63.70,40,0
.goto 2024,48.74,65.93,40,0
.goto 2024,47.52,64.19,35,0
.goto 2024,47.98,62.29,35,0
>>Kill |cRXP_ENEMY_Primalist Infusers|r or |cRXP_ENEMY_Shiverweb Spiders|r. Loot them for the |T2965290:0|t[|cRXP_LOOT_Flask of Dwarven Antifreeze|r].
.complete 65832,1 
.mob Primalist Infuser
.mob Shiverweb Cloaker
.mob Shiverweb Crusher
step
.goto 2024,48.99,64.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grungir Ironspout|r.
.turnin 65832 >>Turn in Dwarven Antifreeze
.turnin 65833 >>Turn in Primalist Tampering
.accept 65834 >>Accept Kill the Queen
.target Grungir Ironspout
step
.goto 2024,47.24,65.58
>>Kill |cRXP_ENEMY_Shiverweb Queen|r.
*|cRXP_WARN_Use|r |T4643990:0|t[Spider Squasher] |cRXP_WARN_to weaken her|r.
.complete 65834,1 
.mob Shiverweb Queen
step
.goto 2024,48.99,64.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grungir Ironspout|r.
.turnin 65834 >>Turn in Kill the Queen
.target Grungir Ironspout
step
#completewith next
.hs >>Hearth to The Conjured Biscuit Inn
step
.goto 2024,39.48,63.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sindragosa|r.
.complete 66015,1 
.target Sindragosa
.skipgossipid 55293
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sindragosa|r and |cRXP_FRIENDLY_Kalecgos|r.
.turnin 66015 >>Turn in The Blue Dragon Oathstone
.goto 2024,39.48,63.06
.target +Sindragosa
.accept 66244 >>Accept To Valdrakken
.goto 2024,39.47,63.05
.target +Kalecgos
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#name a) Thaldraszus Midnight
#internal
step
#completewith ThaldraszusToValdrakken
.goto 2024,37.07,60.82
.fly Pinewood Post >>Fly to Pinewood Post
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arc Tel XVII|r.
.target Arc Tel XVII
step
.goto 2112,48.09,59.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hot Springs Spa Promoter|r.
.accept 72067 >>Accept Relaxation Time!
.target Hot Springs Spa Promoter
step
#label ThaldraszusToValdrakken
.goto 2112,54.48,47.90
#title |cFFFCDC00Follow the Arrow|r
.complete 66244,1 
step
#completewith next
#label ToValdrakkenA
.goto 2112,58.15,34.90,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 66244 >>Turn in To Valdrakken
.accept 66159 >>Accept A Message Most Dire
.complete 66159,1 
.target Alexstrasza the Life-Binder
.skipgossip 187678,1
step
#completewith ToValdrakkenA
#title Use Teleporter
.goto 2112,61.95,32.10
.cast 387905 >>Use the teleporter
step
#requires ToValdrakkenA
.goto 2112,58.15,34.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 66244 >>Turn in To Valdrakken
.accept 66159 >>Accept A Message Most Dire
.complete 66159,1 
.target Alexstrasza the Life-Binder
.skipgossipid 55406
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r and |cRXP_FRIENDLY_Captain Drine|r.
.turnin 66159 >>Turn in A Message Most Dire
.goto 2112,58.15,34.90
.target +Alexstrasza the Life-Binder
.accept 66166 >>Accept Eyes and Ears
.accept 66163 >>Accept Nowhere to Hide
.goto 2112,59.39,34.83
.target +Captain Drine
step
.goto 2112,58.15,34.90
>>Use |T317244:0:0|t[Revealing Dragon's Eye]
.complete 66163,1 
.use 198859
step
#completewith EyesAndEars
>>Use |T317244:0:0|tRevealing Dragon's Eye
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdrakken Citizens|r. The spies are marked on your (mini)map (so open your map and look for the step number!)
.use 198859
.goto 2112,54.72,61.41,0
.goto 2112,51.12,62.54,0
.goto 2112,48.43,58.09,0
.goto 2112,50.54,50.77,0
.goto 2112,48.85,47.73,0
.goto 2112,35.85,56.65,0
.goto 2112,36.17,64.03,0
.goto 2112,41.60,65.28,0
.goto 2112,39.93,71.38,0
.goto 2112,37.98,71.29,0
.goto 2112,49.17,76.43,0
.goto 2112,52.35,76.87,0
.goto 2112,54.31,70.02,0
.goto 2112,40.11,51.80,0
.goto 2112,27.45,60.38,0
.goto 2112,25.16,64.89,0
.goto 2112,32.18,68.50,0
.goto 2112,31.40,62.95,0
.complete 66163,1 
.complete 66163,2 
.skipgossip
step
#completewith next
.goto 2112,55.50,57.34,15 >>Glide down with your dragonriding mount and enter the bank
step
.goto 2112,59.18,54.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Storage Chest|r.
.complete 66166,2 
step
#completewith next
#label InnInvestigated
.goto 2112,46.94,47.74,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goblet|r.
.complete 66166,3 
step
#completewith InnInvestigated
#title Enter Inn
.goto 2112,48.43,49.90,8 >>Enter the inn
step
#requires InnInvestigated
.goto 2112,46.94,47.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Goblet|r.
.complete 66166,3 
step
.goto 2112,47.45,46.22
.home >>Set your Hearthstone to The Roasted Ram
step
#completewith next
#label CratersConsortiumInvestigated
.goto 2112,34.66,61.30,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Consortium Ledger|r.
.complete 66166,1 
step
#completewith CratersConsortiumInvestigated
#title Leave Inn
.goto 2112,48.43,49.90,8 >>Leave the inn
step
#requires CratersConsortiumInvestigated
.goto 2112,34.66,61.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Consortium Ledger|r.
.complete 66166,1 
step
#loop
.goto 2112,35.87,56.71,18,0
.goto 2112,27.36,60.47,18,0
.goto 2112,40.31,71.99,18,0
.goto 2112,49.23,77.58,18,0
.goto 2112,54.30,69.97,18,0
.goto 2112,50.59,50.43,18,0
.goto 2112,40.97,47.24,18,0
.goto 2112,39.83,52.12,18,0
>>Use |T317244:0:0|tRevealing Dragon's Eye
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_WARN_glowing|r |cRXP_FRIENDLY_Valdrakken Citizens|r.
.complete 66163,1 
.complete 66163,2 
.target Valdrakken Citizen
.use 198859
.skipgossipid 55202
step
.goto 2112,54.72,47.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Drine|r.
.turnin 66163 >>Turn in Nowhere to Hide
.turnin 66166 >>Turn in Eyes and Ears
.accept 66167 >>Accept Southern Exposure
.target Captain Drine
step
.goto 2025,35.80,82.12
#title |cFFFCDC00Follow the Arrow|r
.complete 66167,1 
step
#label EyesAndEars
.goto 2025,35.85,82.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Guardian Velomir|r.
.complete 66167,2 
.target Guardian Velomir
step
.goto 2025,35.85,82.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guardian Velomir|r.
.turnin 66167 >>Turn in Southern Exposure
.accept 66169 >>Accept Vengeance, Served Hot
.accept 66246 >>Accept The Fog of Battle
.target Guardian Velomir
step
#completewith ThaldraszusLookoutMordren
.goto 2025,36.65,84.36,0,0
>>Kill |cRXP_ENEMY_Magmasworn Primalists|r.
.complete 66169,1 
.mob Magmaclaw Raider
.mob Magmasworn Lavablade
step
#title Unit Found (1/3)
.goto 2025,36.25,83.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Mangled Corpse|r.
.complete 66246,1,1 
.skipgossipid 54894
step
#title Unit Found (2/3)
.goto 2025,35.76,84.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Mangled Corpse|r.
.complete 66246,1,2 
.skipgossipid 54894
step
#title Unit Found (3/3)
.goto 2025,36.46,85.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Mangled Corpse|r.
.complete 66246,1,3 
.skipgossipid 54894
step
#label ThaldraszusLookoutMordren
.goto 2025,36.80,85.59
>>Fly up the tower and kill |cRXP_ENEMY_Lookout Mordren|r. Skip if you struggle with killing him.
.accept 69967 >>Accept Lookout Mordren
.complete 69967,1 
.mob Lookout Mordren
step
#loop
.goto 2025,36.67,83.38,32,0
.goto 2025,36.65,84.36,32,0
.goto 2025,36.08,84.59,32,0
.goto 2025,36.67,83.38,32,0
>>Kill |cRXP_ENEMY_Magmasworn Primalists|r.
.complete 66169,1 
.mob Magmaclaw Raider
.mob Magmasworn Lavablade
.mob Magmasworn Flameweaver
step
.goto 2025,37.62,83.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guardian Velomir|r.
.turnin 66169 >>Turn in Vengeance, Served Hot
.turnin 66246 >>Turn in The Fog of Battle
.accept 66245 >>Accept Remember the Fallen
.target Guardian Velomir
step
.goto 2025,37.85,83.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Magmasworn Spear|r.
.accept 66247 >>Accept Slightly Used Weapons
step
>>Glide down and talk to |cRXP_FRIENDLY_Private Shikzar|r.
*Look for him up & down the road. Skip if you deal low damage
.goto 2025,37.54,86.05,100,0
.goto 2025,37.44,82.26,100,0
.goto 2025,37.54,86.05,100,0
.goto 2025,37.44,82.26
.accept 70986 >>Accept Private Shikzar
.complete 70986,1 
.skipgossip
step
.goto 2025,38.56,83.41
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coil of Heavy Rope|r.
.accept 66248 >>Accept Tying Things Together
step
#completewith ThaldraszusRemembertheThingsTogether
.goto 2025,38.70,84.41,0,0
>>Kill |cRXP_ENEMY_Magmasworn Rockcleaver|r. Loot them for the |T135131:0|t[|cRXP_LOOT_Magmasworn Spears|r].
.complete 66247,1 
.mob Magmasworn Rockcleaver
step
#title |T1408443:0:0|tSignet (1/8)
.goto 2025,38.89,84.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1,1 
step
#title |T1119938:0:0|tRope (1/5)
.goto 2025,39.14,84.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coil of Heavy Rope|r.
.complete 66248,1,1 
step
#title |T1408443:0:0|tSignet (2/8)
.goto 2025,39.37,83.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1,2 
step
#title |T1119938:0:0|tRope (2/5)
.goto 2025,39.47,83.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coil of Heavy Rope|r.
.complete 66248,1,2 
step
#title |T1408443:0:0|tSignet (3/8)
.goto 2025,39.22,83.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1,3 
step
#title |T1408443:0:0|tSignet (4/8)
.goto 2025,39.21,83.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1,4 
step
#title |T1119938:0:0|tRope (3/5)
.goto 2025,39.45,82.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coil of Heavy Rope|r.
.complete 66248,1,3 
step
#title |T1408443:0:0|tSignet (5/8)
.goto 2025,39.69,82.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1,5 
step
#title |T1408443:0:0|tSignet (6/8)
.goto 2025,39.47,81.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1,6 
step
#title |T1408443:0:0|tSignet (7/8)
.goto 2025,39.00,81.90
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1,7 
step
#title |T1408443:0:0|tSignet (8/8) + |T1119938:0:0|tRope (4/5)
.goto 2025,39.09,82.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the corpse of |cRXP_FRIENDLY_South Hold Guardian|r.
.complete 66245,1 
.complete 66248,1,4 
step
#title |T1119938:0:0|tRope (5/5)
.goto 2025,38.74,82.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Coil of Heavy Rope|r.
.complete 66248,1 
step
#loop
.goto 2025,39.24,83.73,32,0
.goto 2025,39.05,86.20,32,0
.goto 2025,39.46,82.15,32,0
.goto 2025,38.47,83.06,32,0
.goto 2025,39.09,83.09,32,0
.goto 2025,38.56,84.65,32,0
>>Kill |cRXP_ENEMY_Magmasworn Rockcleaver|r. Loot them for the |T135131:0|t[|cRXP_LOOT_Magmasworn Spears|r].
.complete 66247,1 
.mob Magmasworn Rockcleaver
step
.goto 2025,37.63,83.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guardian Velomir|r.
.turnin 66245 >>Turn in Remember the Fallen
.turnin 66247 >>Turn in Slightly Used Weapons
.turnin 66248 >>Turn in Tying Things Together
.accept 66249 >>Accept Clear the Sky
.target Guardian Velomir
step
.goto 2025,40.88,83.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Siege Scorpion|r.
.complete 66249,1 
step
.goto 2025,40.88,83.88
>>Look around and spam |T1412205:0:0|t[Siege Bolt] (1) to kill |cRXP_ENEMY_Magmasworn Trueborn|r.
.complete 66249,2 
.mob Magmasworn Trueborn
step
.goto 2025,40.56,85.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guardian Velomir|r.
.turnin 66249 >>Turn in Clear the Sky
.accept 66250 >>Accept Where's The Chief?
.target Guardian Velomir
step
.goto 2025,40.19,85.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guardian Velomir|r.
.complete 66250,1 
.target Guardian Velomir
.skipgossip
step
.goto 2025,40.15,85.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guardian Velomir|r.
.turnin 66250 >>Turn in Where's The Chief?
.accept 66251 >>Accept Fire Fighter
.target Guardian Velomir
step
.goto 2025,40.12,86.61
>>Kill |cRXP_ENEMY_Magmatalon|r. |cRXP_WARN_Use a range ability to pull him down|r.
.complete 66251,1 
.mob Magmatalon
step
.goto 2025,40.15,85.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guardian Velomir|r.
.turnin 66251 >>Turn in Fire Fighter
.accept 66252 >>Accept Reporting In
.target Guardian Velomir
step
#completewith next
.cooldown item,6489,>0,1
.hs >>Hearth to Valdrakken
step
#completewith next
.goto 2112,61.95,32.10
.cast 387905 >>Use the teleporter
step
.goto 2112,55.94,39.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Drine|r.
.turnin 66252 >>Turn in Reporting In
.target Captain Drine
step
.goto 2112,61.56,39.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.accept 66320 >>Accept The Flow of Time
.target Nozdormu
step
.goto 2025,57.46,78.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r and wait for the roleplay.
.complete 66320,1 
.target Chromie
.skipgossip 187100,1
.timer 44,Roleplay Duration
step
.goto 2025,57.46,78.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
.turnin 66320 >>Turn in The Flow of Time
.target Chromie
step
.goto 2025,57.53,78.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r.
.accept 66080 >>Accept Temporal Difficulties
.target Andantenormu
step
.goto 2025,55.60,77.33
>>Kill |cRXP_ENEMY_Henlare|r. |cRXP_WARN_Be careful not to get knocked off|r.
.accept 69873 >>Accept Henlare (Elite Objective)
.complete 69873,1 
.mob Henlare
step
.goto 2025,54.99,75.64
#title |cFFFCDC00Follow the Arrow|r
.complete 66080,1 
step
.goto 2025,55.00,75.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siaszerathel|r.
.turnin 66080 >>Turn in Temporal Difficulties
.accept 70136 >>Accept Haven't Got Time For the Pain
.target Siaszerathel
step
#completewith next
.goto 2025,52.72,76.86,0,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Timewalker Staff|r.
.complete 70136,1 
step
.goto 2025,52.69,76.81
>>Kill the |cRXP_ENEMY_Crazed Alpha|r.
.complete 70136,3 
.mob Crazed Alpha
step
.goto 2025,52.72,76.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Timewalker Staff|r.
.complete 70136,1 
step
#requires ThaldraszusHaventGotTimeForStaff
.goto 2025,53.18,77.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Timewalker Notes|r.
.complete 70136,2 
step
.goto 2025,55.00,75.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siaszerathel|r.
.turnin 70136 >>Turn in Haven't Got Time For the Pain
.accept 66082 >>Accept Time in a Bottle
.accept 66081 >>Accept Time is Running Out
.target Siaszerathel
step
#completewith TimeIsRunningOut
.goto 2025,54.25,76.62,0,0
>>Kill |cRXP_ENEMY_Time-Charged enemies|r in the area and run through the appearing |cRXP_PICK_Time Motes|r. (glowing orbs)
.complete 66082,1 
.mob Time-Charged Ohuna
.mob Time-Charged Salamanther
.mob Time-Charged Vorquin
.mob Time-Charged Hornswog
step
#title Collector (1/8)
.goto 2025,55.07,76.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1,1 
step
#title Collector (2/8)
.goto 2025,55.57,76.80
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1,2 
step
#title Collector (3/8)
.goto 2025,56.48,78.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1,3 
step
#title Collector (4/8)
.goto 2025,55.60,78.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1,4 
step
#title Collector (5/8)
.goto 2025,55.02,78.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1,5 
step
#title Collector (6/8)
.goto 2025,55.20,77.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1,6 
step
#title Collector (7/8)
.goto 2025,54.34,77.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1,7 
step
#label TimeIsRunningOut
#title Collector (8/8)
.goto 2025,54.25,76.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66081,1 
step
#loop
.goto 2025,57.11,75.06,45,0
.goto 2025,57.41,77.78,40,0
.goto 2025,56.10,77.77,35,0
.goto 2025,55.17,79.33,35,0
.goto 2025,53.34,76.18,45,0
.goto 2025,54.95,76.56,45,0
>>Kill |cRXP_ENEMY_Time-Charged enemies|r in the area and run through the appearing |cRXP_PICK_Time Motes|r. (glowing orbs)
.complete 66082,1 
.mob Time-Charged Ohuna
.mob Time-Charged Salamanther
.mob Time-Charged Vorquin
.mob Time-Charged Hornswog
.mob Time-Charged Bear
step
.goto 2025,57.45,78.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siaszerathel|r.
.turnin 66081 >>Turn in Time is Running Out
.turnin 66082 >>Turn in Time in a Bottle
.timer 10,Roleplay Duration
.target Siaszerathel
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r after a short roleplay.
.goto 2025,57.52,78.79
.accept 66083 >>Accept Feels Like the First Time
.timer 20,Roleplay Duration
.target Andantenormu
step
.goto 2025,57.58,78.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tWait for |cRXP_FRIENDLY_Andantenormu|r and talk to him.
.complete 66083,1 
.target Andantenormu
.skipgossipid 55340
step
.goto 2025,57.68,78.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Collector|r.
.complete 66083,2 
step
.goto 2025,57.66,78.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal Focus|r.
.complete 66083,3 
step
.goto 2025,57.64,78.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Time-Lost Artifact|r.
.complete 66083,4 
.timer 90,Roleplay Duration
step
>>Wait until Andantenormu brings you back. |cRXP_WARN_You can also go through the time portal|r.
.complete 66083,5 
step
.goto 2025,57.52,78.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tWait for |cRXP_FRIENDLY_Andantenormu|r and talk to him.
.turnin 66083 >>Turn in Feels Like the First Time
.accept 66084 >>Accept Times Like These
.target Andantenormu
step
.goto 2025,57.45,78.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siaszerathel|r.
.accept 66085 >>Accept If We Could Turn Back Time
.target Siaszerathel
step
#completewith ThaldraszusIfWeCouldTurnBackTime
>>Kill the |cRXP_ENEMY_Time-Lost enemies|r. Loot them for the |T628267:0|t[|cRXP_LOOT_Temporal Residue|r].
*The |cRXP_ENEMY_Time-Lost Murlocs|r are the most efficient ones.
.complete 66084,1 
.mob Time-Lost Murloc
.mob Time-Lost Murhulk
.mob Time-Lost Thunderhide
.mob Time-Lost Raptor
.mob Time-Lost Devilsaur
step
.goto 2025,58.59,78.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Time Rift|r.
.complete 66085,1 
step
.goto 2025,59.80,79.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siaszerathel|r.
.complete 66085,2 
.target Siaszerathel
.skipgossip 187339,1
.timer 5,Roleplay Duration
step
.goto 2025,60.00,79.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Time Rift|r.
.complete 66085,3 
step
.goto 2025,59.98,77.20
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Time Rift|r.
.complete 66085,4 
step
#label ThaldraszusIfWeCouldTurnBackTime
.goto 2025,59.95,77.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aeonormu|r.
.complete 66085,5 
.target Aeonormu
.skipgossipid 55001
step
#loop
.goto 2025,59.81,78.84,32,0
.goto 2025,58.58,77.11,32,0
.goto 2025,58.30,78.80,32,0
.goto 2025,59.96,79.27,32,0
.goto 2025,59.43,78.17,32,0
>>Kill the |cRXP_ENEMY_Time-Lost enemies|r. Loot them for the |T628267:0|t[|cRXP_LOOT_Temporal Residue|r].
*The |cRXP_ENEMY_Time-Lost Murlocs|r are the most efficient ones.
.complete 66084,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r and |cRXP_FRIENDLY_Siaszerathel|r.
.turnin 66084 >>Turn in Times Like These
.goto 2025,57.52,78.79
.target +Andantenormu
.turnin 66085 >>Turn in If We Could Turn Back Time
.goto 2025,57.45,78.92
.target +Siaszerathel
step
.goto 2025,57.55,78.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aeonormu|r.
.accept 66087 >>Accept Closing Time
.target Aeonormu
step
#loop
.goto 2025,57.17,81.02,32,0
.goto 2025,57.74,81.17,32,0
.goto 2025,56.84,82.16,32,0
.goto 2025,56.95,84.29,32,0
.goto 2025,57.68,84.86,32,0
.goto 2025,57.88,83.81,32,0
.goto 2025,57.88,84.55,32,0
>>|cRXP_WARN_Focus on the clicking on the|r. |cRXP_PICK_Time Rifts|r and buffing |cRXP_FRIENDLY_Bronze Warders|r with the |cRXP_WARN_[ExtraActionButton]|r.
>>Or kill the |cRXP_ENEMY_Time-Lost Enemies|r.
.complete 66087,1 
.mob Time-Lost Geomancer
.mob Time-Lost Chieftain
.mob Time-Lost Briarback
.mob Time-Lost Bladewing
.mob Time-Lost Destroyer
.mob Time-Lost Sunseeker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aeonormu|r and |cRXP_FRIENDLY_Andantenormu|r.
.turnin 66087 >>Turn in Closing Time
.goto 2025,57.55,78.87
.target +Andantenormu
.accept 65935 >>Accept Catching Up to Chromie
.goto 2025,57.52,78.80
.target +Aeonormu
step
.goto 2025,59.64,81.51
#title |cFFFCDC00Follow the Arrow|r
.complete 65935,1 
.target Chromie
step
.goto 2025,59.57,81.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
.turnin 65935 >>Turn in Catching Up to Chromie
.accept 65947 >>Accept Time-Locked Timewalkers
.accept 65948 >>Accept Cracks in Time
.target Chromie
step
.goto 2025,59.54,82.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r.
.accept 66646 >>Accept Quelling Causalities
.target Andantenormu
step
#completewith ThaldraszusCracksInTime
>>Kill |cRXP_ENEMY_Timelings|r and |cRXP_ENEMY_Timeless Causalities|r.
.complete 66646,1 
.mob Timeling
.mob Timless Causality
step
#title Timewalker freed (1/8)
.goto 2025,59.01,82.77
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1,1 
step
#title Timewalker freed (2/8)
.goto 2025,58.72,82.44
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1,2 
step
#title Timewalker freed (3/8)
.goto 2025,58.38,82.14
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1,3 
step
#title Timewalker freed (4/8)
.goto 2025,58.15,82.86
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1,4 
step
.goto 2025,58.46,83.10
>>Use the |cRXP_WARN_[ExtraActionButton]|r and move away from the crystal.
.complete 65948,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Crystal Chunks|r on the ground to collect 50 energy.
.goto 2025,58.41,82.98
.complete 65948,3,50 
step
#title Timewalker freed (5/8)
.goto 2025,60.31,81.39
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1,5 
step
>>Use the |cRXP_WARN_[ExtraActionButton]|r and move away from the crystal.
.goto 2025,60.76,80.48
.complete 65948,2 
step
#completewith ThaldraszusTimeLockedTimewalkers
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Crystal Chunks|r on the ground to collect the missing 50 energy.
.goto 2025,60.68,80.37,0,0
.complete 65948,3 
step
#title Timewalker freed (6/8)
.goto 2025,60.87,80.02
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1,6 
step
#title Timewalker freed (7/8)
.goto 2025,60.46,79.74
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1,7 
step
#label ThaldraszusTimeLockedTimewalkers
#title Timewalker freed (8/8)
.goto 2025,60.27,80.40
>>Use the |cRXP_WARN_[ExtraActionButton]|r.
.complete 65947,1 
step
#label ThaldraszusCracksInTime
.goto 2025,60.68,80.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Temporal Crystals|r on the ground to collect the missing 50 energy.
.complete 65948,3 
step
#loop
.goto 2025,58.46,83.10,30,0
.goto 2025,60.25,80.16,30,0
.goto 2025,60.76,80.48,30,0
>>Kill |cRXP_ENEMY_Timelings|r. and |cRXP_ENEMY_Timeless Causalities|r.
.complete 66646,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r and |cRXP_FRIENDLY_Chromie|r.
.turnin 66646 >>Turn in Quelling Causalities
.goto 2025,59.56,82.67
.target +Andantenormu
.turnin 65947 >>Turn in Time-Locked Timewalkers
.turnin 65948 >>Turn in Cracks in Time
.accept 65938 >>Accept The Once and Future Team
.goto 2025,59.58,81.75
.target +Chromie
step
.goto 2025,60.49,83.26
>>Use the |cRXP_WARN_[ExtraActionButton]|r and walk down the ramp.
*|cRXP_WARN_Make sure to dismount|r.
.complete 65938,1 
step
.goto 2025,60.68,83.58
>>Kill the |cRXP_ENEMY_Giant Time Elemental|r.
.complete 65938,2 
.mob Giant Time Elemental
step
.goto 2025,59.58,81.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
.turnin 65938 >>Turn in The Once and Future Team
.accept 65962 >>Accept The Never-Final Countdown
.target Chromie
step
.goto 2025,59.58,81.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
.complete 65962,1 
.target Chromie
.skipgossipid 54696
step
.goto 2025,60.05,82.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.turnin 65962 >>Turn in The Never-Final Countdown
.accept 70040 >>Accept Tumbling Through Time
.target Nozdormu
step
.goto 2025,59.52,82.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Soridormi|r.
.complete 70040,1 
.target Soridormi
.skipgossipid 55789
step
.goto 2025,59.30,82.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siaszerathel|r.
.complete 70040,3 
.target Siaszerathel
.skipgossipid 55815
step
.goto 2025,60.19,81.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r.
.complete 70040,2 
.target Andantenormu
.skipgossipid 55814
step
.goto 2025,60.06,82.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r and wait for the roleplay.
.complete 70040,4 
.target Nozdormu
.skipgossipid 55840
.timer 24,Roleplay Duration
step
.goto 2025,60.06,82.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.turnin 70040 >>Turn in Tumbling Through Time
.accept 66028 >>Accept To the Future!
.accept 66029 >>Accept Temporal Tuning
.target Nozdormu
step
.goto 2025,59.83,82.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to the Primalist Future|r.
.complete 66028,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Soridormi|r and |cRXP_FRIENDLY_Possible Future You|r.
.turnin 66028 >>Turn in To the Future!
.accept 66030 >>Accept Resistance Isn't Futile
.goto 2085,61.10,50.82
.target +Soridormi
.accept 66031 >>Accept Making Time
.goto 2085,61.45,50.20
.target +Possible Future You
step
.goto 2085,47.86,41.16
>>Use the |T133240:0|t[Chrono Crystal] near |cRXP_FRIENDLY_Chromie|r and |cRXP_FRIENDLY_Eternus|r.
.complete 66029,1 
.use 192749
step
#completewith ThaldraszusResistanceIsntFutile
+Use the |cRXP_WARN_[ExtraActionButton]|r if you need help fighting.
step
#completewith ThaldraszusResistanceIsntFutile
>>Kill |cRXP_ENEMY_Hoary Icicles|r or |cRXP_ENEMY_Restless Icicles|r. Loot them for the |T538556:0|t[|cRXP_LOOT_Elemental Essence|r].
*|cRXP_WARN_Avoid killing elites|r.
.complete 66031,1 
.mob Hoary Icicle
.mob Restless Icicle
.mob Restless Pebble
step
#title Fighter Healed (1/10)
.goto 2085,44.72,43.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,1 
.use 192467
step
#title Fighter Healed (2/10)
.goto 2085,43.49,41.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,2 
.use 192467
step
#title Fighter Healed (3/10)
.goto 2085,44.32,38.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,3 
.use 192467
step
#title Fighter Healed (4/10)
.goto 2085,46.97,36.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,4 
.use 192467
step
#title Fighter Healed (5/10)
.goto 2085,46.04,32.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,5 
.use 192467
step
#title Fighter Healed (6/10)
.goto 2085,50.64,30.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,6 
.use 192467
step
#title Fighter Healed (7/10)
.goto 2085,52.77,30.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,7 
.use 192467
step
#title Fighter Healed (8/10)
.goto 2085,54.49,28.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,8 
.use 192467
step
#title Fighter Healed (9/10)
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.use 192467
.goto 2085,52.47,24.21
.complete 66030,1,9 
step
#label ThaldraszusResistanceIsntFutile
#title Fighter Healed (10/10)
.goto 2085,62.04,28.40
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Injured Resistance Fighters|r.
.complete 66030,1,10 
.use 192467
step
#loop
.goto 2085,57.87,25.26,30,0
.goto 2085,52.36,24.46,30,0
.goto 2085,56.61,28.14,30,0
>>Kill and LOOT |cRXP_ENEMY_Hoary Icicles|r or |cRXP_ENEMY_Restless Icicles|r. Loot them for the |T1:0|t[|cRXP_LOOT_Essences|r].
*|cRXP_ENEMY_Avoid killing elites|r.
.complete 66031,1 
.mob Hoary Icicle
.mob Restless Icicle
.mob Restless Pebble
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Possible Future You|r and |cRXP_FRIENDLY_Soridormi|r.
.turnin 66031 >>Turn in Making Time
.goto 2085,61.47,50.22
.target Possible Future You
.turnin 66030 >>Turn in Resistance Isn't Futile
.goto 2085,61.08,50.83
.target Soridormi
step
.goto 2085,61.09,50.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Soridormi|r.
.accept 66032 >>Accept Return to the Present
.target Soridormi
step
#completewith next
#label TemporalTuningPresent
.goto 2025,60.05,82.45,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.turnin 66029 >>Turn in Temporal Tuning
.turnin 66032 >>Turn in Return to the Present
.accept 72519 >>Accept Temporal Two-ning
.accept 66033 >>Accept To the... Past?
.target Nozdormu
step
#completewith TemporalTuningPresent
.goto 2085,61.01,50.55
.zone 2025 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Temporal Conflux|r.
step
#requires TemporalTuningPresent
.goto 2025,60.05,82.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.turnin 66029 >>Turn in Temporal Tuning
.turnin 66032 >>Turn in Return to the Present
.accept 72519 >>Accept Temporal Two-ning
.accept 66033 >>Accept To the... Past?
.target Nozdormu
step
.goto 2025,59.97,82.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Azmerloth|r.
.complete 66033,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r and |cRXP_FRIENDLY_Varian Wryngrrlgulgll|r. <<Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r and |cRXP_FRIENDLY_Thrallgrulgulgul|r. <<Horde
.turnin 66033 >>Turn in To the... Past?
.accept 66035 >>Accept Murloc Motes
.goto 2092,59.83,66.15
.target +Andantenormu
.accept 66036 >>Accept Mugurlglrlgl! << Alliance
.accept 66704 >>Accept Mugurlglrlgl! << Horde
.goto 2092,59.97,65.98
.target +Varian Wryngrrlgulgll << Alliance
.target +Thrallgrulgulgul << Horde
step
#completewith next
+|cRXP_WARN_You can only use normal ground mounts here!|r.
step
#completewith ThaldraszusMurlocMotes
>>Kill |cRXP_ENEMY_Deathling Destroyers|r and |cRXP_ENEMY_Deathlings|r.
.complete 66036,2 << Alliance 
.complete 66036,1 << Alliance 
.complete 66704,2 << Horde 
.complete 66704,1 << Horde 
.mob Deathling
.mob Deathling Destroyer
step
#title Motes collected (1/12)
.goto 2092,60.05,68.69
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,1 
step
#title Motes collected (2/12)
.goto 2092,60.62,68.39
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,2 
step
#title Motes collected (3/12)
.goto 2092,60.71,66.76
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,3 
step
#title Motes collected (4/12)
.goto 2092,61.27,67.05
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,4 
step
#title Motes collected (5/12)
.goto 2092,61.61,65.98
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,5 
step
#title Motes collected (6/12)
.goto 2092,62.54,66.16
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,6 
step
#title Motes collected (7/12)
.goto 2092,62.72,65.11
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,7 
step
#title Motes collected (8/12)
.goto 2092,61.85,63.81
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,8 
step
.goto 2092,61.49,61.76
>>Use |T133240:0|t[Chrono Crystal] near |cRXP_FRIENDLY_Chromie|r and |cRXP_FRIENDLY_Eternus|r.
.complete 72519,1 
.use 192749
step
#title Motes collected (9/12)
.goto 2092,61.22,63.50
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,9 
step
#title Motes collected (10/12)
.goto 2092,60.28,63.88
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,10 
step
#title Motes collected (11/12)
.goto 2092,59.25,63.30
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1,11 
step
#label ThaldraszusMurlocMotes
#title Motes collected (12/12)
.goto 2092,58.53,64.12
>>Run through the |cRXP_PICK_Motes|r. You may have to jump.
.complete 66035,1 
step
#loop
.goto 2092,58.57,64.94,32,0
.goto 2092,59.25,67.50,32,0
.goto 2092,60.77,67.83,32,0
.goto 2092,61.69,64.23,32,0
>>Kill |cRXP_ENEMY_Deathling Destroyers|r and |cRXP_ENEMY_Deathlings|r.
.complete 66036,2 << Alliance 
.complete 66036,1 << Alliance 
.complete 66704,2 << Horde 
.complete 66704,1 << Horde 
.mob Deathling
.mob Deathling Destroyer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r and |cRXP_FRIENDLY_Varian Wryngrrlgulgll|r. <<Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r and |cRXP_FRIENDLY_Thrallgrulgulgul|r. <<Horde
.turnin 66035 >>Turn in Murloc Motes
.goto 2092,59.84,66.14
.target +Andantenormu
.turnin 66036 >>Turn in Mugurlglrlgl! << Alliance
.turnin 66704 >>Turn in Mugurlglrlgl! << Horde
.accept 70373 >>Accept Deathwingurlugull! << Alliance
.accept 70371 >>Accept Deathwingurlugull! << Horde
.timer 5,Roleplay Duration
.goto 2092,59.98,65.98
.target +Varian Wryngrrlgulgll << Alliance
.target +Thrallgrulgulgul << Horde
step
.goto 2092,59.81,65.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Murloc Hopper|r after a short roleplay.
.complete 70373,1 <<Alliance 
.complete 70371,1 <<Horde 
.target Murloc Hopper
step
>>Spam |T651086:0|t[Fishbolts] (1).
>>Use |T988193:0|t[Toxic Puffersplosion] (2) and |T3004140:0|t[Charge of the Azmurlocs] (3) on cooldown.
>>Use |T3922897:0|t[Murky Bubble] (4) to heal
*|cRXP_WARN_Make sure to target Deathwingurlugull|r.
.complete 70373,2 <<Alliance 
.complete 70371,2 <<Horde 
.mob Deathwingurlugull
step
#completewith next
.exitvehicle >>|cRXP_WARN_Leave the vehicle early|r.
step <<Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varian Wryngrrlgulgll|r and |cRXP_FRIENDLY_Andantenormu|r.
.turnin 70373 >>Turn in Deathwingurlugull!
.goto 2092,59.91,65.99
.target +Andantenormu
.accept 66037 >>Accept Back to Reality
.goto 2092,59.83,66.14
.target +Varian Wryngrrlgulgll
step <<Horde
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrallgrulgulgul|r and |cRXP_FRIENDLY_Andantenormu|r.
.turnin 70371 >>Turn in Deathwingurlugull!
.goto 2092,59.97,65.99
.target +Andantenormu
.accept 66037 >>Accept Back to Reality
.goto 2092,59.83,66.14
.target +Thrallgrulgulgul
step
#completewith next
#label BackToTwoning
.goto 2025,60.06,82.45,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.turnin 66037 >>Turn in Back to Reality
.turnin 72519 >>Turn in Temporal Two-ning
.accept 66660 >>Accept On Your Mark... Get Set...
.target Nozdormu
step
#completewith BackToTwoning
.goto 2092,59.72,66.11
.zone 2025 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Temporal Conflux|r.
step
#requires BackToTwoning
.goto 2025,60.06,82.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.turnin 66037 >>Turn in Back to Reality
.turnin 72519 >>Turn in Temporal Two-ning
.accept 66660 >>Accept On Your Mark... Get Set...
.target Nozdormu
step
.goto 2025,59.92,82.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to the Gnoll War|r.
.complete 66660,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r.
.goto 2090,43.39,69.22
.turnin 66660 >>Turn in On Your Mark... Get Set...
.accept 66038 >>Accept Race Through Time!
.target Andantenormu
step
#completewith ThaldraszusRaceThroughTime
+|cRXP_WARN_Run through the speed boots to gain a movement speed buff and avoid the circles|r.
step
.isOnQuest 66038
.goto 2090,43.19,68.05,15,0
.goto 2090,42.97,66.93,15,0
.goto 2090,42.61,65.18,15,0
.goto 2090,41.96,63.82,15,0
.goto 2090,41.58,61.96,15,0
.goto 2090,40.63,59.71,15,0
.goto 2090,40.32,57.88,15,0
.goto 2090,39.65,56.46,15,0
.goto 2090,38.11,54.13,15,0
.goto 2090,37.08,53.36,15,0
.goto 2090,35.78,53.56,15,0
.goto 2090,34.68,53.16,15,0
.goto 2090,33.77,52.04,15,0
.goto 2090,32.83,50.54,15,0
.goto 2090,32.37,49.70
.zone 2091 >>Follow the arrow. Reach the first portal
step
.isOnQuest 66038
.goto 2091,47.16,66.66,15,0
.goto 2091,46.67,67.58,15,0
.goto 2091,45.90,68.25,15,0
.goto 2091,45.16,69.52,15,0
.goto 2091,44.47,69.63,15,0
.goto 2091,43.24,70.61,15,0
.goto 2091,42.02,72.21,15,0
.goto 2091,41.39,73.50,15,0
.goto 2091,40.97,75.02,15,0
.goto 2091,40.34,75.91,15,0
.goto 2091,39.52,76.78
.zone 2088 >>Follow the arrow. Reach the second portal
step
.isOnQuest 66038
.goto 2088,31.30,63.53,15,0
.goto 2088,30.14,63.46,25,0
.goto 2088,28.64,62.93,25,0
.goto 2088,27.67,62.74,25,0
.goto 2088,24.05,60.46,25,0
.goto 2088,22.84,59.25,25,0
.goto 2088,22.11,60.21,25,0
.goto 2088,21.42,59.20,25,0
.goto 2088,19.80,58.69,25,0
.goto 2088,17.92,59.28,25,0
.goto 2088,15.05,83.53
.zone 2089 >>Follow the arrow. Reach the third portal
step
#label ThaldraszusRaceThroughTime
.goto 2089,43.38,69.19
.complete 66038,1 
step
.goto 2089,52.36,73.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andantenormu|r.
.turnin 66038 >>Turn in Race Through Time!
.accept 66039 >>Accept Chromie Time
.target Andantenormu
step
#completewith TheBlackEmpireChromieTime
+|cRXP_WARN_You can only use normal mounts|r.
step
#completewith next
.goto 2089,57.08,69.02,20,0
.goto 2089,57.44,54.32,20,0
.goto 2089,53.76,43.23,20 >>|cRXP_WARN_Follow the arrow|r.
step
#label TheBlackEmpireChromieTime
.goto 2089,53.76,43.23
>>Use |T133240:0|t[Chrono Crystal] near |cRXP_FRIENDLY_Chromie|r and |cRXP_FRIENDLY_Eternus|r.
.complete 66039,1 
.use 192749
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
.goto 2089,53.41,43.93
.turnin 66039 >>Turn in Chromie Time
.accept 66040 >>Accept Back to the Future
.target Chromie
step
#completewith next
+Don't forget that you can use your |cRXP_WARN_[ExtraActionButton]|r.
step
.goto 2089,52.94,44.53
>>Kill the incoming waves of |cRXP_ENEMY_enemies|r.
.complete 66040,1 
.complete 66040,2 
.skipgossip
.mob Winged Rui
.mob Aqir Harbinger
.mob Grotesque Bulwark
step
.goto 2025,60.08,82.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r.
.complete 66040,3 
.target Chromie
.skipgossipid 55119
step
.goto 2025,60.05,82.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nozdormu|r.
.turnin 66040 >>Turn in Back to the Future
.accept 66221 >>Accept Moving On
.target Nozdormu
step
#completewith next
.hs >>Hearth to Valdrakken
step
#completewith next
.goto 2112,61.95,32.10
.cast 387905 >>Use the teleporter
step
.goto 2112,58.09,34.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza|r.
.complete 66221,1 
.target Alexstrasza the Life-Binder
.skipgossipid 107528
step
.goto 2112,58.09,34.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexstrasza the Life-Binder|r.
.turnin 66221 >>Turn in Moving On
.target Alexstrasza the Life-Binder
step
.xp 70,1
.goto 2025,50.27,67.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Szareth|r.
.accept 69932 >>Accept Every Life Counts
.accept 69933 >>Accept Curiosity's Price
.target Szareth
step
.xp 70,1
#completewith ThaldraszusCuriositysPrice
>>Kill |cRXP_ENEMY_Productive Pollinators|r. Loot them for the |T4631367:0|t[|cRXP_LOOT_Anesthetic Pollen|r].
>>Or |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Magnificent Flowers|r.
.complete 69932,2 
.mob Productive Pollinator
step
.xp 70,1
#title Sun-Basked Linens (1/6)
.goto 2025,49.60,67.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handwoven Basket|r.
.complete 69932,1,1 
step
.xp 70,1
#title Sun-Basked Linens (2/6)
.goto 2025,49.28,67.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handwoven Basket|r.
.complete 69932,1,2 
step
.xp 70,1
#title Sun-Basked Linens (3/6)
.goto 2025,49.00,67.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handwoven Basket|r.
.complete 69932,1,3 
step
.xp 70,1
#title Sun-Basked Linens (4/6)
.goto 2025,48.80,67.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handwoven Basket|r.
.complete 69932,1,4 
step
.xp 70,1
#title Sun-Basked Linens (5/6)
.goto 2025,48.79,67.30
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handwoven Basket|r.
.complete 69932,1,5 
step
.xp 70,1
#title Sun-Basked Linens (6/6)
.goto 2025,48.81,67.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handwoven Basket|r.
.complete 69932,1 
step
.xp 70,1
#label ThaldraszusCuriositysPrice
.goto 2025,48.97,66.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stubborn Vine|r and |cRXP_WARN_then pull it out by moving away|r.
>>Afterwards kill the |cRXP_ENEMY_Laden Lasher|r.
.complete 69933,1 
.complete 69933,2 
.target Stubborn Vine
.mob Laden Lasher
step
.xp 70,1
>>Kill |cRXP_ENEMY_Productive Pollinators|r. Loot them for the |T4631367:0|t[|cRXP_LOOT_Anesthetic Pollen|r].
>>Or |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Magnificent Flowers|r.
#loop
.goto 2025,49.26,66.42,30,0
.goto 2025,49.89,66.67,30,0
.goto 2025,49.31,66.83,30,0
.complete 69932,2 
step
.xp 70,1
.goto 2025,49.42,67.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Little Jetstream|r inside the building.
.complete 69932,3 
.target Little Jetstream
step
.xp 70,1
.goto 2025,50.28,67.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Szareth|r.
.turnin 69932 >>Turn in Every Life Counts
.turnin 69933 >>Turn in Curiosity's Price
.accept 69934 >>Accept Bleeding Hearts
.target Szareth
step
.xp 70,1
#completewith next
#label PotionsDelivered
.goto 2025,53.32,67.52,0,0
#title |cFFFCDC00Follow the Arrow|r
.complete 69934,1 
step
.xp 70,1
#completewith PotionsDelivered
#title Enter Cave
.goto 2025,52.99,67.56,15 >>Enter the cave
step
.xp 70,1
#requires PotionsDelivered
.goto 2025,53.32,67.52
#title |cFFFCDC00Follow the Arrow|r
.complete 69934,1 
step
.goto 2025,53.32,67.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the shade of the |cRXP_PICK_Medical Supplies|r.
.complete 69934,1 
step
.goto 2025,51.76,69.14
#title |cFFFCDC00Follow the Arrow|r
.complete 69934,3 
step
.xp 69,1
.goto 2025,51.69,69.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the shade of the |cRXP_PICK_Medical Supplies|r.
.complete 69934,4 
step
.xp 70,1
.goto 2025,51.70,69.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Timetender Athekk|r.
.turnin 69934 >>Turn in Bleeding Hearts
.target Timetender Athekk
step
.xp 70,1
.goto 2025,37.86,75.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryrmpech|r.
.accept 66134 >>Accept Azeroth Pest Control
.target Gryrmpech
step
.xp 70,1
#loop
.goto 2025,38.34,74.99,18,0
.goto 2025,18.00,38.33,18,0
.goto 2025,75.60,37.69,18,0
.goto 2025,76.04,37.23,18,0
.goto 2025,76.66,38.34,18,0
.goto 2025,74.99,18.00,18,0
.goto 2025,38.33,75.60,18,0
.goto 2025,37.69,76.04,18,0
.goto 2025,37.23,76.66,18,0
>>Kill |cRXP_ENEMY_Agitated Seedlings|r.
.complete 66134,1 
.mob Agitated Seedling
step
.xp 70,1
.goto 2025,37.86,75.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryrmpech|r.
.turnin 66134 >>Turn in Azeroth Pest Control
.accept 66135 >>Accept The Gardener's Apprentice
.target Gryrmpech
step
.xp 70,1
.goto 2025,38.91,74.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bronze Stopwatch|r on the ground.
.accept 66278 >>Accept One Drakonid's Junk
step
.xp 70,1
.goto 2025,38.94,74.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Storage Crates|r, |cRXP_PICK_Ruined Barrels|r, |cRXP_PICK_Garden Junk|r and |cRXP_PICK_Scrap Wood|r to clear the room.
.complete 66135,1 
step
.xp 70,1
.goto 2025,37.86,75.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryrmpech|r.
.turnin 66135 >>Turn in The Gardener's Apprentice
.turnin 66278 >>Turn in One Drakonid's Junk
.accept 66136 >>Accept Elemental Extract
.accept 66137 >>Accept Lashing Out
.accept 66279 >>Accept New Kid on the Clock
.target Gryrmpech
step
.xp 70,1
.goto 2025,37.88,75.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Lord Basilton|r on the ground.
.complete 66279,1 
step
.xp 70,1
.goto 2025,35.24,72.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orizmu|r.
.complete 66279,2 
.target Orizmu
step
.xp 70,1
.goto 2025,35.24,72.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orizmu|r.
.turnin 66279 >>Turn in New Kid on the Clock
.accept 66138 >>Accept Like Sands Through the Hourglass
.target Orizmu
step
.xp 70,1
#title Pile of Sand (1/8)
.goto 2025,35.52,72.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Windswept Time Sand|r.
.complete 66138,1,1 
step
.xp 70,1
#title Pile of Sand (2/8)
.goto 2025,35.69,72.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Windswept Time Sand|r.
.complete 66138,1,2 
step
.xp 70,1
#title Pile of Sand (4/8)
.goto 2025,35.83,72.77,-1
.goto 2025,35.81,72.48,-1
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Windswept Time Sand|r.
.complete 66138,1,4 
step
.xp 70,1
#title Pile of Sand (5/8)
.goto 2025,36.02,72.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Windswept Time Sand|r.
.complete 66138,1,5 
step
.xp 70,1
#title Pile of Sand (6/8)
.goto 2025,36.22,72.42
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Windswept Time Sand|r.
.complete 66138,1,6 
step
.xp 70,1
#title Pile of Sand (7/8)
.goto 2025,36.47,72.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Windswept Time Sand|r.
.complete 66138,1,7 
step
.xp 70,1
#title Pile of Sand (8/8)
.goto 2025,36.61,72.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pile of Windswept Time Sand|r.
.complete 66138,1 
step
.xp 70,1
.goto 2025,36.24,72.50
>>Kill |cRXP_ENEMY_Liskron the Dazzling|r.
.accept 72116 >>Accept Liskron the Dazzling (Elite Objective)
.complete 72116,1 
.mob Liskron the Dazzling
step
.xp 70,1
#loop
.goto 2025,37.51,71.73,25,0
.goto 2025,37.40,70.99,25,0
.goto 2025,37.32,69.70,25,0
.goto 2025,36.88,70.49,25,0
.goto 2025,36.88,71.21,25,0
>>Kill |cRXP_ENEMY_Churning Splashes|r and |cRXP_ENEMY_Hulking Waves|r. Loot them for the |T463570:0|t[|cRXP_LOOT_Watery Essence|r].
.complete 66136,1 
.mob Churning Splash
step
.xp 70,1
.goto 2025,35.24,72.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orizmu|r.
.turnin 66138 >>Turn in Like Sands Through the Hourglass
.target Orizmu
step
.xp 70,1
#loop
.goto 2025,34.73,72.95,20,0
.goto 2025,33.89,72.63,20,0
.goto 2025,34.16,71.85,20,0
.goto 2025,34.60,71.00,20,0
.goto 2025,67.00,34.79,20,0
>>Kill |cRXP_ENEMY_Deathblossoms|r in the area.
.complete 66137,1 
.mob Invasive Deathblossom
.mob Deathblossom Weedling
step
.xp 70,1
.goto 2025,37.86,75.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryrmpech|r.
.turnin 66136 >>Turn in Elemental Extract
.turnin 66137 >>Turn in Lashing Out
.accept 66139 >>Accept Flame at Last
.target Gryrmpech
step
.xp 70,1
>>Use |T236213:0|t[Concentrated Essence of Water] on the |cRXP_ENEMY_Blazing Inferno|r and kill it.
.goto 2025,35.58,75.16
.complete 66139,1 
.complete 66139,2 
.mob Blazing Inferno
step
.xp 70,1
.goto 2025,37.86,75.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryrmpech|r.
.turnin 66139 >>Turn in Flame at Last
.accept 66412 >>Accept Carry On, Basilton
.target Gryrmpech
step
.xp 70,1
.goto 2025,37.88,75.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Basilton|r.
.complete 66412,1 
.target Lord Basilton
.skipgossipid 55121
step
.xp 70,1
.goto 2025,37.86,75.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryrmpech|r.
.turnin 66412 >>Turn in Carry On, Basilton
.target Gryrmpech
step
.xp 70,1
.goto 2025,40.42,49.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spa Concierge|r.
.turnin 72067 >>Turn in Relaxation Time!
.accept 72246 >>Accept Serene Dreams
.target Spa Concierge
step
.xp 70,1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xijan Thornpaw|r and |cRXP_FRIENDLY_Quilius|r.
.turnin 72246 >>Turn in Serene Dreams
.accept 70738 >>Accept The You-ga Class
.goto 2025,40.49,48.93
.target Xijan Thornpaw
.accept 70740 >>Accept Steam Cleaning
.goto 2025,40.46,48.88
.target Quilius
step
.xp 70,1
#completewith ThaldraszusTheYougaClass
>>Kill |cRXP_ENEMY_Elementals|r in the area.
.complete 70740,1 
.mob Flame Blister
.mob Steam Scaulder
step
.xp 70,1
.goto 2025,41.47,47.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Misplaced Luggage|r.
.accept 70741 >>Accept Some Favorite Things
step
.xp 70,1
.goto 2025,41.17,47.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Youga Instructor|r.
.complete 70738,2 
.target Youga Instructor
step
.xp 70,1
#title Belongings Found (2/6)
.goto 2025,41.16,47.43
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.complete 70741,1,2 
step
.xp 70,1
#title Student Rescued (1/6)
.goto 2025,41.45,47.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Terrorized Spa Guest|r.
.complete 70738,1,1 
.target Terrorized Spa Guest
step
.xp 70,1
#title Student Rescued (2/6)
.goto 2025,41.06,46.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Terrorized Spa Guest|r.
.complete 70738,1,2 
.target Terrorized Spa Guest
step
.xp 70,1
#title Belongings Found (3/6)
.goto 2025,40.72,47.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lost S.E.L.F.I.E Camera|r.
.complete 70741,1,3 
step
.xp 70,1
#title Student Rescued (3/6)
.goto 2025,40.51,47.31
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Terrorized Spa Guest|r.
.complete 70738,1,3 
.target Terrorized Spa Guest
step
#title Student Rescued (4/6)
.goto 2025,40.18,46.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Terrorized Spa Guest|r.
.complete 70738,1,4 
.target Terrorized Spa Guest
step
.xp 70,1
#title Belongings Found (4/6)
.goto 2025,40.10,46.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stylish Umbrella|r.
.complete 70741,1,4 
step
.xp 70,1
#title Belongings Found (5/6)
.goto 2025,40.27,46.16
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Overturned Beach Chair|r.
.complete 70741,1,5 
step
.xp 70,1
#title Student Rescued (5/6)
.goto 2025,40.03,45.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Terrorized Spa Guest|r.
.complete 70738,1,5 
.target Terrorized Spa Guest
step
.xp 70,1
#title Student Rescued (6/6)
.goto 2025,40.81,46.09
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Terrorized Spa Guest|r.
.complete 70738,1 
.target Terrorized Spa Guest
step
.xp 70,1
#label ThaldraszusTheYougaClass
#title Belongings Found 6/6
.goto 2025,41.01,45.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soggy You-ga Pillow|r.
.complete 70741,1 
step
.xp 70,1
.goto 2025,40.49,45.34
>>Kill |cRXP_ENEMY_Mudgatu|r. Loot him for the |T3778311:0|t[|cRXP_LOOT_Derelict Sunglasses|r].
.collect 200586,1,70377,1
.accept 70377 >>Accept Derelict Fashion
step
.xp 70,1
#loop
.goto 2025,39.99,45.69,30,0
.goto 2025,39.46,47.37,30,0
.goto 2025,40.46,48.00,30,0
.goto 2025,41.48,47.33,30,0
.goto 2025,40.98,45.52,30,0
>>Kill |cRXP_ENEMY_Elementals|r.
.complete 70740,1 
.mob Flame Blister
.mob Steam Scaulder
step
.xp 70,1
.goto 2025,39.50,48.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zeldis|r.
.turnin 70377 >>Turn in Derelict Fashion
.target Zeldis
step
.xp 70,1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xijan Thornpaw|r and |cRXP_FRIENDLY_Quilius|r.
.turnin 70738 >>Turn in The You-ga Class
.turnin 70741 >>Turn in Some Favorite Things
.goto 2025,40.49,48.92
.target Xijan Thornpaw
.turnin 70740 >>Turn in Steam Cleaning
.goto 2025,40.46,48.88
.target Quilius
step
.xp 70,1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elzara|r.
.goto 2025,40.49,48.97
.accept 70743 >>Accept Precious Baby
.target Elzara
step
.xp 70,1
.goto 2025,38.90,45.22
#title |cFFFCDC00Follow the Arrow|r
.complete 70743,1 
step
.xp 70,1
.goto 2025,38.90,45.22
>>Wait for the roleplay and |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Baby|r.
.complete 70743,2 
.target Baby
step
.xp 70,1
.goto 2025,38.89,45.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Horrible Mess|r.
.accept 70744 >>Accept Look at the Bones!
step
.xp 70,1
#title Cleaned Mess (2/10)
.goto 2025,38.92,45.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,2 
step
.xp 70,1
#title Cleaned Mess (3/10)
.goto 2025,38.52,45.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,3 
step
.xp 70,1
#title Cleaned Mess (4/10)
.goto 2025,38.65,46.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,4 
step
.xp 70,1
#title Cleaned Mess (5/10)
.goto 2025,37.91,46.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,5 
step
.xp 70,1
#title Cleaned Mess (6/10)
.goto 2025,37.79,46.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,6 
step
.xp 70,1
#title Cleaned Mess (7/10)
.goto 2025,38.03,47.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,7 
step
.xp 70,1
#title Cleaned Mess (8/10)
.goto 2025,39.18,47.34
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,8 
step
.xp 70,1
#title Cleaned Mess (9/10)
.goto 2025,39.56,47.21
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1,9 
step
.xp 70,1
#title Cleaned Mess (10/10)
.goto 2025,39.70,47.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_More Horrible Mess|r.
.complete 70744,1 
step
.xp 70,1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elzara|r and |cRXP_FRIENDLY_Xijan Thornpaw|r.
.turnin 70743 >>Turn in Precious Baby
.goto 2025,40.49,48.97
.target +Elzara
.turnin 70744 >>Turn in Look at the Bones!
.goto 2025,40.49,48.92
.target +Xijan Thornpaw
step
.xp 70,1
.goto 2025,40.46,48.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quilius|r.
.accept 70745 >>Accept Enforced Relaxation
.target Quilius
step
.xp 70,1
#completewith next
.goto 2025,39.69,47.45,20,0
.goto 2025,39.89,48.45,15 >>Enter the cave below
step
.xp 70,1
>>Kill |cRXP_ENEMY_Vadne Bleakheart|r. Move out of the fire and water void zones.
.goto 2025,40.04,49.05
.complete 70745,1 
step
.xp 70,1
.goto 2025,40.46,48.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quilius|r.
.turnin 70745 >>Turn in Enforced Relaxation
.target Quilius
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) Isle of Dorn Route
#internal
step
#include RestedXP Speed Leveling\a) Isle of Dorn Campaign@StateUnionStart-BrannStart





step
.goto 2339,32.78,33.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Otwin|r.
.accept 78289 >>Accept To Rambleshire
.target Rooktender Otwin
step
#include RestedXP Speed Leveling\a) Isle of Dorn Campaign@StateUnionEndEnd-StateUnionEnd
step
.goto 2339,46.75,32.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannida|r.
.accept 82747 >>Accept Crossroads Plaza
.target Rannida
step
.goto 2339,62.71,21.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aldra|r.
.accept 80207 >>Accept How Scandalous!
.target Aldra
step
.goto 2248,58.79,28.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rannan Korren|r.
.accept 79724 >>Accept A Titanic Expedition!
.target Rannan Korren
step
#completewith next
#label StormscarredA
.goto 2248,58.38,28.33,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rancher Edidithet|r.
.accept 83337 >>Accept Stormscarred
.target Rancher Edidithet
step
#completewith StormscarredA
#title Enter House
.isQuestAvailable 83337
.goto 2248,58.41,28.25,6 >>Enter the House
step
#requires StormscarredA
.goto 2248,58.38,28.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rancher Edidithet|r.
.accept 83337 >>Accept Stormscarred
.target Rancher Edidithet
step
#completewith next
#label SpirebreakerMageSlayerB
.goto 2248,58.33,27.12,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Violet Warden|r.
.accept 83339 >>Accept The Spirebreaker
.accept 83338 >>Accept The Mage Slayer
.target Violet Warden
step
#title Enter House
#completewith SpirebreakerMageSlayerB
.isQuestAvailable 83338,83339
.goto 2248,58.64,27.75,6 >>Enter the House
step
#requires SpirebreakerMageSlayerB
.goto 2248,58.33,27.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Violet Warden|r.
.accept 83339 >>Accept The Spirebreaker
.accept 83338 >>Accept The Mage Slayer
.target Violet Warden
step
#completewith next
#label ToRambleshirePowerPredators
.goto 2248,61.45,31.66,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Lufsela|r.
.turnin 78289 >>Turn in To Rambleshire
.accept 78291 >>Accept Power Predators
.target Rooktender Lufsela
step
.isOnQuest 78289
#completewith ToRambleshirePowerPredators
#title Leave House
.goto 2248,58.7,27.82,10 >>Leave the House
step
#requires ToRambleshirePowerPredators
.goto 2248,61.45,31.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Lufsela|r.
.turnin 78289 >>Turn in To Rambleshire
.accept 78291 >>Accept Power Predators
.accept 78290 >>Accept Sleepy Sheep
.target Rooktender Lufsela
step
.goto 2248,62.37,31.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_Highlands Lodestone|r.
.complete 78290,1 
step
.goto 2248,61.51,31.62
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Shraubendre|r.
.complete 78290,2 
.target Shraubendre
step
.goto 2248,61.45,33.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dropped Package|r.
.accept 78754 >>Accept Lost Delivery
.target Dropped Package
step
.goto 2248,61.17,37.90
>>Kill |cRXP_ENEMY_Anub'esska|r.
.complete 83339,1 
.mob Anub'esska
step
.goto 2248,59.74,34.60
>>Kill |cRXP_ENEMY_Stormscar|r.
.complete 83337,1 
.mob Stormscar
step
#hidewindow
#completewith Shalemaw Young
#loop
.goto 2248,57.42,32.52,40,0
.goto 2248,59.95,32.68,40,0
.goto 2248,60.86,31.13,40,0
.goto 2248,61.28,29,40,0
.goto 2248,61.03,27.1,40,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Stormtop Shalemaws|r or |cRXP_ENEMY_Stormtop Terralisks|r.
.complete 78291,1 
.mob Stormtop Shalemaw Young
.mob Stormtop Shalemaw
.mob Stormtop Terralisk
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_ENEMY_Lethargic Mosswool|r.
.complete 78290,3 
.mob Lethargic Mosswool
step
#label Shalemaw Young
>>Kill |cRXP_ENEMY_Stormtop Shalemaws|r or |cRXP_ENEMY_Stormtop Terralisks|r.
.complete 78291,1 
.mob Stormtop Shalemaw Young
.mob Stormtop Shalemaw
.mob Stormtop Terralisk
step
.goto 2248,59.72,29.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rooktender Lufsela|r.
.turnin 78290 >>Turn in Sleepy Sheep
.turnin 78291 >>Turn in Power Predators
.target Rooktender Lufsela
step
.goto 2248,59.69,29.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.accept 78292 >>Accept Lost Lord of the Storm
.target Head Rancher Stenspor
step
.goto 2248,55.39,32.07
>>Kill |cRXP_ENEMY_Mage Slayer Phytethil|r.
.complete 83338,1 
.mob Mage Slayer Phytethil
step
#title |cFFFCDC00Follow the Arrow|r.
.goto 2248,55.55,28.79
.complete 78292,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbings|r.
.goto 2248,55.54,28.78
.complete 78292,3 
step
#label LostLordoftheStormG
.goto 2248,58.73,30.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.turnin 78292 >>Turn in Lost Lord of the Storm
.target Head Rancher Stenspor
step
.goto 2248,58.73,30.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.accept 78293 >>Accept Their Moss, Our Gain
.target Head Rancher Stenspor
step
#loop
.goto 2248,57.96,29.66,30,0
.goto 2248,58.11,30.35,30,0
.goto 2248,59.74,30.25,30,0
.goto 2248,60.24,28.85,30,0
.goto 2248,59.6,27.87,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Rambleshire Mosswools|r. kill them if they fight back.
.complete 78293,1 
.target Rambleshire Mosswool
.mob Rambleshire Mosswool
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Harvested Mosswool|r.
.goto 2248,58.79,30.36
.complete 78293,2 
step
.goto 2248,58.73,30.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Head Rancher Stenspor|r.
.turnin 78293 >>Turn in Their Moss, Our Gain
.target Head Rancher Stenspor
step
#completewith next
#label StormscarredB
.goto 2248,58.38,28.33,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rancher Edidithet|r.
.turnin 83337 >>Turn in Stormscarred
.target Rancher Edidithet
step
#completewith StormscarredB
#title Enter House
.isOnQuest 83337
.goto 2248,58.51,28.20,6 >>Enter the House
step
#requires StormscarredB
.goto 2248,58.38,28.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rancher Edidithet|r.
.turnin 83337 >>Turn in Stormscarred
.target Rancher Edidithet
step
#completewith next
#label SpirebreakerMageSlayer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Violet Warden|r.
.turnin 83339 >>Turn in The Spirebreaker
.turnin 83338 >>Turn in The Mage Slayer
.target Violet Warden
step
#title Enter House
#completewith SpirebreakerMageSlayer
.isOnQuest 83338,83339
.goto 2248,58.64,27.75,6 >>Enter the House
step
#requires SpirebreakerMageSlayer
.goto 2248,58.33,27.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Violet Warden|r.
.turnin 83339 >>Turn in The Spirebreaker
.turnin 83338 >>Turn in The Mage Slayer
.target Violet Warden
step
#include RestedXP Speed Leveling\a) Remember Me, Earthen@CandleKoboldsStart-RememberMeEarthenF
step
#include RestedXP Speed Leveling\a) The Hermit@TheHermitB-end
step
#include RestedXP Speed Leveling\a) A Titanic Expedition@Titanic ExpeditionStart-Titanic ExpeditionEnd
step
.isQuestAvailable 82747
.hs >>Hearth to Dornogal
step
#include RestedXP Speed Leveling\a) Behind Closed Doors@ForgegroundsStart-ForgegroundsEnd
step
.goto 2339,51.82,48.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ellerdin|r.
.accept 83275 >>Accept Gear Enchanting
.target Ellerdin
step
>>Use one of the Enchants to enchant a ring
.complete 83275,1 
.use 223657
.use 223663
.use 223666
.use 223669
.use 226245
step
.goto 2339,51.83,48.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ellerdin|r.
.turnin 83275 >>Turn in Gear Enchanting
.target Ellerdin
step
.goto 2248,55.21,55.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bondaz|r.
.turnin 82747 >>Turn in Crossroads Plaza
.target Bondaz
step
.goto 2248,55.25,55.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wanted: The Boroughbreaker|r.
.accept 83335 >>Accept Wanted: The Boroughbreaker
.target Wanted: The Boroughbreaker
step
.goto 2248,55.52,55.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Freysworn Etterca|r.
.accept 83336 >>Accept The Earthwound
.target Freysworn Etterca
step
.goto 2248,60.21,53.37
>>Kill |cRXP_ENEMY_Roth the Earthwound|r.
*Loot it for the |T348539:0|t[|cRXP_LOOT_Broken Stoneheart|r].
.complete 83336,1 
.mob Roth the Earthwound
step
.goto 2248,56.44,51.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stage Manager Huberta|r.
.accept 79150 >>Accept Thespians at the Proscenium
.target Stage Manager Huberta
step
.goto 2248,55.59,49.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brokfor|r.
.complete 79150,1 
.skipgossipid 122494
.target Brokfor
step
.goto 2248,55.76,50.18
.complete 79150,2 
step
.goto 2248,56.44,51.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stage Manager Huberta|r.
.turnin 79150 >>Turn in Thespians at the Proscenium
.target Stage Manager Huberta
step
.goto 2248,55.52,55.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Freysworn Etterca|r.
.turnin 83336 >>Turn in The Earthwound
.target Freysworn Etterca
step
#label SporesOfDreadC
.goto 2248,53.55,69.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.turnin -78570 >>Turn in Frayed Legacy
.accept 78571 >>Accept Mycomayhem
.target Woldtender Igris
step
.isQuestAvailable 78618
#completewith next
>>Kill the |cRXP_ENEMY_Boskroots|r, |cRXP_ENEMY_Infected Peafowls|r, |cRXP_ENEMY_Shalehorns|r, and |cRXP_ENEMY_Murmuring Trapcaps|r.
.complete 78618,1 
.mob Murmuring Trapcap
step
#loop
.goto 2248,52.27,70.55,37,0
.goto 2248,51.33,67.59,40,0
.goto 2248,53.58,65.18,40,0
.goto 2248,54.71,68.08,40,0
>>Kill the |cRXP_ENEMY_Boskroots|r, |cRXP_ENEMY_Infected Peafowls|r, and |cRXP_ENEMY_Shalehorns|r. Loot them for the |T1029746:0|t[|cRXP_LOOT_Boskroot Spores]
.complete 78571,1 
.mob Mycotic Shalehorn
.mob Infected Peafowls
.mob Boskroot Guardener
.mob Boskroot Lashbane
.mob Boskroot Brute
.mob Boskroot Button
.mob Boskroot Mycomancer
.mob Elder Shalehorn
.mob Murmuring Trapcap
step
#label SporesOfDreadD
.goto 2248,53.55,69.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Woldtender Igris|r.
.turnin 78571 >>Turn in Mycomayhem
.target Woldtender Igris
step
.isQuestAvailable 79667
>>Kill |cRXP_ENEMY_Sand Elementals|r.
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Swirling Debris|r.
.complete 79667,1 
step
.isQuestAvailable 81614
>>Kill the |cRXP_ENEMY_Pearlfin Gorlocs|r.
.complete 81614,1 
.mob Seaborne Colossus
.mob Pearlfin Clawclacker
.mob Pearlfin Waterweaver
.mob Pearlfin Sea-Shaman
.mob Pearlfin Sparkleseeker
step
#label FreywoldVillageLoveofGems
.goto 2248,43.04,70.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.accept 82441 >>Accept For The Love of Gems
.target Natalia Pearce
step
#label HopeAnAnomalyA
.goto 2248,41.74,70.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hreka|r.
.accept 78469 >>Accept Prairie Fever
.target Hreka
step
#label HopeAnAnomalyB
.goto 2248,41.62,70.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pottery Jars|r on the table.
.complete 78469,1 
.skipgossipid 121544
.skipgossipid 121673
.skipgossipid 121546
step
#completewith next
#label TalkToBettaA
.goto 2248,41.67,71.79,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betta|r.
.complete 82441,1 
.target Betta
step
#title Enter House
#completewith TalkToBettaA
.goto 2248,41.55,72.36,8 >>Enter the House
step
#requires TalkToBettaA
.goto 2248,41.64,72.37,0
.goto 2248,41.55,72.36,0
.goto 2248,41.67,71.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betta|r.
.complete 82441,1 
.target Betta
.skipgossipid 122466
step
.goto 2248,41.05,72.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Germira|r.
.accept 82792 >>Accept All Ore Nothing
.target Germira
step
.goto 2248,40.93,71.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurron|r.
.complete 82441,2 
.skipgossipid 122467
.target Kurron
step
#completewith next
#label TalkToMalucA
.goto 2248,41.63,74.95,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maluc|r.
.complete 82441,3 
.target Maluc
.skipgossipid 122463
step
#title Enter House
#completewith TalkToMalucA
.goto 2248,41.51,74.38,8 >>Enter the House
step
#requires TalkToMalucA
.goto 2248,41.63,74.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maluc|r.
.complete 82441,3 
.target Maluc
.skipgossipid 122463
step
#completewith next
#label HopeAnAnomalyC
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.goto 2248,42.26,73.34,0,0
.complete 78469,2 
.target Kodun
.skipgossipid 121126
step
#title Enter House
#completewith HopeAnAnomalyC
.isOnQuest 78469
.goto 2248,42.20,73.10,8 >>Enter the House
step
#requires HopeAnAnomalyC
.goto 2248,42.20,73.10,0
.goto 2248,42.26,73.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.complete 78469,2 
.target Kodun
.skipgossipid 121126
step
#label HopeAnAnomalyD
.goto 2248,42.26,73.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.turnin 78469 >>Turn in Prairie Fever
.accept 79691 >>Accept Monsters in the Dark
.accept 79692 >>Accept Buried, Not Forgotten
.target Kodun
step
.goto 2248,43.03,70.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82441 >>Turn in For The Love of Gems
.target Natalia Pearce
.accept 82465 >>Accept Precious Gems
step
.goto 2248,35.79,77.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_FRIENDLY_Discarded Botanist Notes|r.
.accept 79686 >>Accept Concerning Fungarians
.target Discarded Botanist Notes
step
#title |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFResearch notes|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Research notes|r.
.goto 2248,35.82,77.18
.complete 79686,1,1 
step
#title |TInterface/cursor/crosshair/interact.blp:20|tClick on the |cFFDB2EEFResearch notes|r |cRXP_WARN_[2]|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Research notes|r.
.goto 2248,35.66,76.94,6,0
.goto 2248,35.65,77.14
.complete 79686,1,2 
step
#title Go to the top
>>Kill the |cRXP_ENEMY_Mossbloom Hazewalker|r. Loot it for the |T237383:0|t[|cRXP_LOOT_Log Entry 893-03-9|r].
.goto 2248,35.64,77.06
.complete 79686,1 
.mob Mossbloom Hazewalker
step
#completewith next
#label HopeAnAnomalyE
#hidewindow
.complete 79691,1 
.complete 79692,1 
.complete 79692,2 
step
#title Enter Cave
#completewith HopeAnAnomalyE
.goto 2248,34.92,75.47,8 >>Enter the Cave
step
#requires HopeAnAnomalyE
#completewith next
>>Kill |cRXP_ENEMY_Acute Blightspores|r and |cRXP_ENEMY_Festering Sporemass|r. Loot them for |T4625027:0|t[|cRXP_LOOT_Modhina's Notes|r], |T1519428:0|t[|cRXP_LOOT_Modhina's Bag of Ore|r], and |T1519428:0|t[|cRXP_LOOT_Memory Gem Fragment|r].
*|cRXP_WARN_Don't kill too many at the same time. Only one of them can drop at the same time|r.
.complete 79692,1 
.mob Acute Blightspore
.mob Festering Sporemass
step
#requires HopeAnAnomalyE
#completewith next
>>Kill the |cRXP_ENEMY_Ashen Stonestalker|r.
.complete 79691,1 
.mob Ashen Stonestalker
step
#requires HopeAnAnomalyE
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_FRIENDLY_Modhina|r.
.goto 2248,34.61,76.01,10,0
.goto 2248,35.26,75.74,10,0
.goto 2248,34.60,74.32
.complete 79692,2 
step
#completewith next
>>Kill |cRXP_ENEMY_Acute Blightspores|r and |cRXP_ENEMY_Festering Sporemass|r. Loot them for |T4625027:0|t[|cRXP_LOOT_Modhina's Notes|r], |T1519428:0|t[|cRXP_LOOT_Modhina's Bag of Ore|r], and |T1519428:0|t[|cRXP_LOOT_Memory Gem Fragment|r].
*|cRXP_WARN_Don't kill too many at the same time. Only one of them can drop at the same time|r.
.complete 79692,1 
.mob Acute Blightspore
.mob Festering Sporemass
step
.goto 2248,34.82,74.02
>>Kill the |cRXP_ENEMY_Ashen Stonestalker|r.
.complete 79691,1 
.mob Ashen Stonestalker
step
.goto 2248,35.08,74.93
>>Kill |cRXP_ENEMY_Acute Blightspores|r and |cRXP_ENEMY_Festering Sporemass|r. Loot them for |T4625027:0|t[|cRXP_LOOT_Modhina's Notes|r], |T1519428:0|t[|cRXP_LOOT_Modhina's Bag of Ore|r], and |T1519428:0|t[|cRXP_LOOT_Memory Gem Fragment|r].
*|cRXP_WARN_Don't kill too many at the same time. Only one of them can drop at the same time|r.
.complete 79692,1 
.mob Acute Blightspore
.mob Festering Sporemass
step
.isOnQuest 79692
#label HopeAnAnomalyF
#title Leave Cave
.goto 2248,35.18,76.22,10,0
.goto 2248,34.55,75.88,10,0
.goto 2248,35.14,75.41
.subzone 15361,1 >>Leave the Cave
step
#loop
.goto 2248,33.42,81.21,50,0
.goto 2248,31.07,73.50,45,0
>>Kill |cRXP_ENEMY_Igneous Elementals|r. Loot them for the |T5341572:0|t[|cRXP_LOOT_Igneous Core|r].
.complete 82466,1 
.mob Igneous Elemental
step
#completewith next
#label WhatWeDoForGemsA
.goto 2248,33.87,79.59,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82466 >>Turn in What We Do For Gems
.accept 82467 >>Accept Gems Are Forever
.target Natalia Pearce
step
#title Enter Cave
#completewith WhatWeDoForGemsA
.isOnQuest 82466
.goto 2248,33.59,80.03,8 >>Enter the Cave
step
#requires WhatWeDoForGemsA
.goto 2248,33.59,80.03,0
.goto 2248,33.87,79.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82466 >>Turn in What We Do For Gems
.accept 82467 >>Accept Gems Are Forever
.target Natalia Pearce
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.79,79.38
.complete 82467,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.96,79.68
.complete 82467,2 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.88,79.38
.complete 82467,3 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Igneous Core|r.
.goto 2248,33.97,79.55
.complete 82467,4 
.timer 17,Roleplay Duration
step

>>Wait for the roleplay
.goto 2248,33.87,79.58
.complete 82467,5 
step
.goto 2248,33.87,79.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Natalia Pearce|r.
.turnin 82467 >>Turn in Gems Are Forever
.target Natalia Pearce
step
#completewith next
#label HopeAnAnomalyG
.goto 2248,42.26,73.34,0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.turnin 79691 >>Turn in Monsters in the Dark
.turnin 79692 >>Turn in Buried, Not Forgotten
.target Kodun
step
#title Enter House
#completewith HopeAnAnomalyG
.isOnQuest 79691,79692
.goto 2248,42.20,73.10,8 >>Enter the House
step
#requires HopeAnAnomalyG
#label HopeAnAnomalyH
.goto 2248,42.26,73.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kodun|r.
.turnin 79691 >>Turn in Monsters in the Dark
.turnin 79692 >>Turn in Buried, Not Forgotten
.timer 8,Roleplay Duration
.target Kodun
step
#label HopeAnAnomalyI
.goto 2248,42.29,73.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hreka|r.
.accept 79703 >>Accept Hope, An Anomaly
.target Hreka
step
.goto 2248,42.40,73.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Forge Vessel|r.
.complete 79703,1 
step
.goto 2248,42.32,73.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ball of Clay|r.
.complete 79703,2 
step
.goto 2248,42.32,73.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unfired Pot|r.
.complete 79703,3 
step
.goto 2248,42.39,73.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unfired Pot|r.
.complete 79703,4 
step
#label HopeAnAnomalyJ
.goto 2248,42.35,73.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hreka|r.
.turnin 79703 >>Turn in Hope, An Anomaly
.target Hreka
step
.goto 2248,41.46,71.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeonin|r.
.turnin 79686 >>Turn in Concerning Fungarians
.target Yeonin
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dagran Thaurissan II|r and |cRXP_FRIENDLY_Peacekeeper Hektare|r.
.accept 83081 >>Accept Not Enough Minerals
.goto 2248,44.82,64.41
.target +Dagran Thaurissan II
.accept 83082 >>Accept The Opalfront
.goto 2248,44.87,64.30
.target +Peacekeeper Hektare
step
#completewith OpalsCollectedA
>>Kill |cRXP_ENEMY_Nerubian Skirmisher|r and |cRXP_ENEMY_Nerubian Webspinner|r.
.complete 83082,1 
.mob +Nerubian Skirmisher
.complete 83082,2 
.mob +Nerubian Webspinner
step
#title Opal collected (1/6)
.goto 2248,45.01,63.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loose Opal Mounds|r.
.complete 83081,1,1 
step
#label OpalsCollectedA
#title Opal collected (2/6)
.goto 2248,45.73,62.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loose Opal Mounds|r.
.complete 83081,1,2 
step
.goto 2248,45.87,62.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alvegar|r.
.turnin 82792 >>Turn in All Ore Nothing
.accept 82796 >>Accept Third Mine Blind
.target Alvegar
step
#title Above the mine
.goto 2248,47.32,61.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alvegar|r |cRXP_WARN_above the mine|r.
.turnin 82796 >>Turn in Third Mine Blind
.target Alvegar
step
#loop
.goto 2248,45.46,55.34,30,0
.goto 2248,45.43,57.92,30,0
>>Kill |cRXP_ENEMY_Boroughbreaker Stik'kar|r.
.complete 83335,1 
.mob Boroughbreaker Stik'kar
step
.goto 2339,54.86,24.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Peacekeeper Alef|r.
.turnin 83335 >>Turn in Wanted: The Boroughbreaker
.target Peacekeeper Alef
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#name a) 70-80 First Crafts
#internal
step
#completewith End
+|cRXP_WARN_First Crafts can take you from 70 to 76 in ~5 minutes using cheap Auction House mats|r.
*|cRXP_WARN_Each recipe crafted once gives bonus XP (~1 quest), up to 30 First Crafts total across any professions|r.
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 3908,1
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.7,63.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kotag|r.
.train 423343 >>Train |T4620681:0|t[Khaz Algar Tailoring]
.train 423343,1
.train 2108,3
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Kotag
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 3908,3
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 2259,3
.train 3908,1
.train 2018,1
.train 25229,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 2018,3
.train 3908,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 25229,3
.train 3908,1
.train 2018,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 7411,3
.train 3908,1
.train 2018,1
.train 25229,1
.train 2259,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 4036,3
.train 3908,1
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 2366,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 2366,3
.train 3908,1
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2575,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 2575,3
.train 3908,1
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 8613,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 8613,3
.train 3908,1
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 45357,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 423340,1
.train 45357,3
.train 3908,1
.train 2018,1
.train 25229,1
.train 2259,1
.train 7411,1
.train 4036,1
.train 2366,1
.train 2575,1
.train 8613,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.32,58.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marbb|r.
.train 423340 >>Train |T4620678:0|t[Khaz Algar Leatherworking]
.train 2108,3
.train 423340,1
.target Marbb
step
.zoneskip 2339,1
.goto 2339,54.7,63.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kotag|r.
.train 423343 >>Train |T4620681:0|t[Khaz Algar Tailoring]
.train 3908,3
.train 423343,1
.target Kotag
step
.zoneskip 2339,1
.goto 2339,47.07,70.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarig|r.
.train 423321 >>Train |T4620669:0|t[Khaz Algar Alchemy] and buy |T443369:0|t[Gilded Vial]
.collect 211806,100
.train 2259,3
.train 423321,1
.target Tarig
step
.zoneskip 2339,1
.goto 2339,48.8,70.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brrigan|r.
.train 423338 >>Train |T4620676:0|t[Khaz Algar Inscription]
.train 45357,3
.train 423338,1
.target Brrigan
step
.zoneskip 2339,1
.goto 2339,49.48,70.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Makir|r.
.train 4620677 >>Train |T4620671:0|t[Khaz Algar Jewelcrafting]
.train 25229,3
.train 4620677,1
.target Makir
step
.zoneskip 2339,1
.goto 2339,52.92,71.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nagad|r.
.train 423334 >>Train |T4620672:0|t[Khaz Algar Enchanting]
.collect 211806,100
.train 7411,3
.train 423334,1
.target Nagad
step
.zoneskip 2339,1
.goto 2339,51.36,63.82,20,0
.goto 2339,49.18,63.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darean|r.
.train 423332 >>Train |T4620670:0|t[Khaz Algar Blacksmithing]
.train 2018,3
.train 423332,1
.target Darean
step
.zoneskip 2339,1
.goto 2339,49.23,55.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thermalseer Arhdas|r.
.train 423335 >>Train |T4620673:0|t[Khaz Algar Engineering]
.train 4036,3
.train 423335,1
.target Thermalseer Arhdas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Leatherworking + Tailoring:
*|cRXP_WARN_Mats are usually cheap, so this list overbuys slightly to avoid another Auction House trip|r.
.collect 1,1
.train 423340,3
.train 423343,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Leatherworking + Blacksmithing:
.train 423340,3
.train 423332,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Leatherworking + Alchemy:
.train 423340,3
.train 423321,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Leatherworking + Inscription:
.train 423340,3
.train 423338,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Leatherworking + Jewelcrafting:
.train 423340,3
.train 4620677,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Leatherworking + Engineering:
.train 423340,3
.train 423335,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Leatherworking + Enchanting:
.train 423340,3
.train 423334,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Tailoring + Leatherworking:
.train 423343,3
.train 423340,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Tailoring + Blacksmithing:
.train 423343,3
.train 423332,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Tailoring + Alchemy:
.train 423343,3
.train 423321,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Tailoring + Inscription:
.train 423343,3
.train 423338,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Tailoring + Jewelcrafting:
.train 423343,3
.train 4620677,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Tailoring + Engineering:
.train 423343,3
.train 423335,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Tailoring + Enchanting:
.train 423343,3
.train 423334,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Blacksmithing + Leatherworking:
.train 423332,3
.train 423340,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Blacksmithing + Tailoring:
.train 423332,3
.train 423343,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Blacksmithing + Alchemy:
.train 423332,3
.train 423321,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Blacksmithing + Inscription:
.train 423332,3
.train 423338,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Blacksmithing + Jewelcrafting:
.train 423332,3
.train 4620677,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Blacksmithing + Engineering:
.train 423332,3
.train 423335,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Blacksmithing + Enchanting:
.train 423332,3
.train 423334,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Alchemy + Leatherworking:
.train 423321,3
.train 423340,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Alchemy + Tailoring:
.train 423321,3
.train 423343,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Alchemy + Blacksmithing:
.train 423321,3
.train 423332,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Alchemy + Inscription:
.train 423321,3
.train 423338,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Alchemy + Jewelcrafting:
.train 423321,3
.train 4620677,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Alchemy + Engineering:
.train 423321,3
.train 423335,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Alchemy + Enchanting:
.train 423321,3
.train 423334,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Inscription + Leatherworking:
.train 423338,3
.train 423340,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Inscription + Tailoring:
.train 423338,3
.train 423343,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Inscription + Blacksmithing:
.train 423338,3
.train 423332,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Inscription + Alchemy:
.train 423338,3
.train 423321,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Inscription + Jewelcrafting:
.train 423338,3
.train 4620677,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Inscription + Engineering:
.train 423338,3
.train 423335,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Inscription + Enchanting:
.train 423338,3
.train 423334,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Jewelcrafting + Leatherworking:
.train 4620677,3
.train 423340,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Jewelcrafting + Tailoring:
.train 4620677,3
.train 423343,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Jewelcrafting + Blacksmithing:
.train 4620677,3
.train 423332,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Jewelcrafting + Alchemy:
.train 4620677,3
.train 423321,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Jewelcrafting + Inscription:
.train 4620677,3
.train 423338,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Jewelcrafting + Engineering:
.train 4620677,3
.train 423335,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Jewelcrafting + Enchanting:
.train 4620677,3
.train 423334,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Engineering + Leatherworking:
.train 423335,3
.train 423340,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Engineering + Tailoring:
.train 423335,3
.train 423343,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Engineering + Blacksmithing:
.train 423335,3
.train 423332,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Engineering + Alchemy:
.train 423335,3
.train 423321,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Engineering + Inscription:
.train 423335,3
.train 423338,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Engineering + Jewelcrafting:
.train 423335,3
.train 4620677,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Engineering + Enchanting:
.train 423335,3
.train 423334,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Enchanting + Leatherworking:
.train 423334,3
.train 423340,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Enchanting + Tailoring:
.train 423334,3
.train 423343,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Enchanting + Blacksmithing:
.train 423334,3
.train 423332,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Enchanting + Alchemy:
.train 423334,3
.train 423321,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Enchanting + Inscription:
.train 423334,3
.train 423338,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Enchanting + Jewelcrafting:
.train 423334,3
.train 4620677,3
.target Auctioneer Zyrgas
step
.goto 2339,56.81,47.49
>>Buy from the Auction House for Enchanting + Engineering:
.train 423334,3
.train 423335,3
.target Auctioneer Zyrgas
























































































step
step
#label End
+Take the portal to Dornogal from the Portal Room. Visit your Profession Trainer and begin crafting. Learn new recipes as your skill increases.
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name ba) DF Alliance Intro Midnight (A)
#displayname |cFF1EFF003|r - Dragonflight Intro << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Dragonflight Intro << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bb) The Waking Shores Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) DF Alliance Intro Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bb) The Waking Shores Midnight (A)
#displayname |cFF1EFF004|r - The Waking Shores << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF003|r - The Waking Shores << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bc) Val'sharah Speedrun Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@WakingShoresStart-WakingShoresEndSpeedrun
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bc) Val'sharah Speedrun Midnight (A)
#displayname |cFF1EFF005|r - Val'Sharah << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF004|r - Val'Sharah << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bd) Highmountain Speedrun Midnight 1 (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Val'sharah Speedrun Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bd) Highmountain Speedrun Midnight 1 (A)
#displayname |cFF1EFF006|r - Highmountain 1 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF005|r - Highmountain 1 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\be) Highmountain Speedrun 2 Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name be) Highmountain Speedrun 2 Midnight (A)
#displayname |cFF1EFF007|r - Highmountain 2 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Highmountain 2 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bf) Tiragarde Sound Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun 2 Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bf) Tiragarde Sound Midnight (A)
#displayname |cFF1EFF008|r - Tiragarde Sound << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Tiragarde Sound << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bg) Kun-Lai Summit 1 (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Tiragarde Sound Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bg) Kun-Lai Summit 1 (A)
#displayname |cFF1EFF009|r - Kunlai Summit 1 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF008|r - Kunlai Summit 1 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bh) Kun-Lai Summit 2 Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Kunlai Summit 1 Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bh) Kun-Lai Summit 2 Midnight (A)
#displayname |cFF1EFF0010|r - Kun-Lai Summit 2 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF009|r - Kun-Lai Summit 2 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\z) 70-80 First Crafts (A) 2

<< Alliance
step
#include RestedXP Speed Leveling\a) Kunlai Summit 2 Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name z) 70-80 First Crafts (A)
#displayname First Crafts << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname First Crafts << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#internal
<< Alliance
step
#include RestedXP Speed Leveling\a) 70-80 First Crafts
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name ba) DF Alliance Intro Midnight (A) 2
#displayname |cFF1EFF003|r - Dragonflight Intro << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Dragonflight Intro << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\bb) The Waking Shores Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) DF Alliance Intro Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bb) The Waking Shores Midnight (A) 2
#displayname |cFF1EFF004|r - The Waking Shores << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF003|r - The Waking Shores << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\bc) Val'sharah Speedrun Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@WakingShoresStart-WakingShoresEndSpeedrun
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bc) Val'sharah Speedrun Midnight (A) 2
#displayname |cFF1EFF005|r - Val'Sharah << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF004|r - Val'Sharah << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\bd) Highmountain Speedrun Midnight 1 (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) Val'sharah Speedrun Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bd) Highmountain Speedrun Midnight 1 (A) 2
#displayname |cFF1EFF006|r - Highmountain 1 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF005|r - Highmountain 1 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\be) Highmountain Speedrun 2 Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name be) Highmountain Speedrun 2 Midnight (A) 2
#displayname |cFF1EFF007|r - Highmountain 2 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Highmountain 2 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\bf) Tiragarde Sound Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun 2 Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bf) Tiragarde Sound Midnight (A) 2
#displayname |cFF1EFF008|r - Tiragarde Sound << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Tiragarde Sound << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\bg) Kun-Lai Summit 1 (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) Tiragarde Sound Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bg) Kun-Lai Summit 1 (A) 2
#displayname |cFF1EFF009|r - Kunlai Summit 1 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF008|r - Kunlai Summit 1 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\bh) Kun-Lai Summit 2 Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) Kunlai Summit 1 Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bh) Kun-Lai Summit 2 Midnight (A) 2
#displayname |cFF1EFF0010|r - Kun-Lai Summit 2 << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF009|r - Kun-Lai Summit 2 << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\z) 70-80 First Crafts (A) 2

<< Alliance
step
#include RestedXP Speed Leveling\a) Kunlai Summit 2 Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name z) 70-80 First Crafts (A) 2
#displayname First Crafts << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname First Crafts << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#internal
<< Alliance
step
#include RestedXP Speed Leveling\a) 70-80 First Crafts
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bq) DF Alliance Intro Midnight (A)
#displayname |cFF1EFF003|r - Dragonflight Intro << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Dragonflight Intro << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\br) The Waking Shores Midnight (A) 1
<< Alliance
step
#include RestedXP Speed Leveling\a) DF Alliance Intro Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name br) The Waking Shores Midnight (A) 1
#displayname |cFF1EFF004|r - The Waking Shores << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF003|r - The Waking Shores << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bs) Val'sharah Speedrun Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@WakingShoresStart-The Courage of One's Convictions
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@MissingEndStart-MissingEndEnd
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bs) Ohn'ahran Plains Midnight (A)
#displayname |cFF1EFF005|r - Ohn'ahran Plains << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF004|r - Ohn'ahran Plains << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bt) The Azure Span Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Ohn'ahran Plains Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bt) The Azure Span Midnight (A)
#displayname |cFF1EFF006|r - The Azure Span << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF005|r - The Azure Span << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bu) Thaldraszus Midnight (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) The Azure Span Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bu) Thaldraszus Midnight (A)
#displayname |cFF1EFF007|r - Thaldraszus << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Thaldraszus << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bv) War Within Recap (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Thaldraszus Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bv) Isle of Dorn (A)
#displayname |cFF1EFF008|r - Isle of Dorn << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Isle of Dorn << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\caa) Midnight Intro Route (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Isle of Dorn Route
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bw) War Within Recap (A)
#displayname War Within Recap |cRXP_ENEMY_(Alternative)|r
#next RestedXP Midnight\caa) Midnight Intro Route (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) The War Within Recap
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bq) DF Alliance Intro Midnight (A) 2
#displayname |cFF1EFF003|r - Dragonflight Intro << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Dragonflight Intro << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\br) The Waking Shores Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) DF Alliance Intro Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name br) The Waking Shores Midnight (A) 2
#displayname |cFF1EFF004|r - The Waking Shores << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF003|r - The Waking Shores << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\bs) Val'sharah Speedrun Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@WakingShoresStart-The Courage of One's Convictions
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@MissingEndStart-MissingEndEnd
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bs) Ohn'ahran Plains Midnight (A) 2
#displayname |cFF1EFF005|r - Ohn'ahran Plains << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF004|r - Ohn'ahran Plains << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bt) The Azure Span Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) Ohn'ahran Plains Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bt) The Azure Span Midnight (A) 2
#displayname |cFF1EFF006|r - The Azure Span << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF005|r - The Azure Span << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bu) Thaldraszus Midnight (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) The Azure Span Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bu) Thaldraszus Midnight (A) 2
#displayname |cFF1EFF007|r - Thaldraszus << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Thaldraszus << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Speed Leveling\bv) War Within Recap (A) 2
<< Alliance
step
#include RestedXP Speed Leveling\a) Thaldraszus Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bv) Isle of Dorn Route (A) 2
#displayname |cFF1EFF008|r - Isle of Dorn << Draenei !DK /Dwarf !DK/Gnome !DK/Human !DK /NightElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Isle of Dorn << VoidElf/KulTiran/LightforgedDraenei/Mechagnome/DarkIronDwarf/Dracthyr/Pandaren/DK/DemonHunter/Worgen/EarthenDwarf/Harronir
#next RestedXP Midnight\caa) Midnight Intro Route (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) Isle of Dorn Route
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bw) War Within Recap (A) 2
#displayname War Within Recap |cRXP_ENEMY_(Alternative)|r
#next RestedXP Midnight\caa) Midnight Intro Route (A)
<< Alliance
step
#include RestedXP Speed Leveling\a) The War Within Recap
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name b1) BfA Intro
#displayname |cFF1EFF003|r - Zuldazar << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Zuldazar << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next ba) Horde Val'sharah
<< Horde
step
#include RestedXP Speed Leveling\a) Battle for Azeroth
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name ba) Horde Val'sharah
#displayname |cFF1EFF004|r - Val'sharah << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF003|r - Val'sharah << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bb) Horde Highmountain
<< Horde
step
#include RestedXP Speed Leveling\a) Val'sharah Speedrun Midnight Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bb) Horde Highmountain
#displayname |cFF1EFF005.1|r - Highmountain << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF004.1|r - Highmountain << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bba) Horde Highmountain 2
<< Horde
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun Midnight Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bba) Horde Highmountain 2
#displayname |cFF1EFF005.2|r - Highmountain << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF004.2|r - Highmountain << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bc) Horde Kun-Lai Summit
<< Horde
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun 2 Midnight Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bc) Horde Kun-Lai Summit
#displayname |cFF1EFF006|r - Kun-Lai Summit (20+) << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF005|r - Kun-Lai Summit (20+) << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#title Kun-Lai Summit
#next bd) Horde Silverpine Forest
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Kun-Lai Summit
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bd) Horde Silverpine Forest
#displayname |cFF1EFF007|r - Silverpine Forest << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Silverpine Forest << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next be) Horde Hillsbrad Foothills
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Silverpine Forest
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name be) Horde Hillsbrad Foothills
#displayname |cFF1EFF008|r - Hillsbrad Foothills << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Hillsbrad Foothills << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bf) Horde Hinterlands
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Hillsbrad Foothills
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bf) Horde Hinterlands
#displayname |cFF1EFF009|r - Hinterlands << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF008|r - Hinterlands << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bg) Horde Draenor Scenario
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Hinterlands
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bg) Horde Draenor Scenario
#displayname |cFF1EFF0010|r - Draenor Scenario << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF009|r - Draenor Scenario << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bh) Horde Draenor Garrison
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Draenor Scenario
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bh) Horde Draenor Garrison
#displayname |cFF1EFF0011|r - Draenor Garrison Intro << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF0010|r - Draenor Garrison Intro << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bi) Horde Spires of Arak
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Draenor Garrison
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bi) Horde Spires of Arak
#displayname |cFF1EFF0012|r - Spires of Arak << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF0011|r - Spires of Arak << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bj) Horde Gorgrond
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Spires of Arak
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bj) Horde Gorgrond
#displayname |cFF1EFF0013|r - Gorgrond << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF0012|r - Gorgrond << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#name RestedXP Speed Leveling\z) 70-80 First Crafts (H)
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Gorgrond
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name z) 70-80 First Crafts (H)
#displayname First Crafts << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname First Crafts << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#internal
<< Horde
step
#include RestedXP Speed Leveling\a) 70-80 First Crafts
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#subweight 1002
#name b1) BfA Intro 2
#displayname |cFF1EFF003|r - Zuldazar << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Zuldazar << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next ba) Horde Val'sharah 2
<< Horde
step
#include RestedXP Speed Leveling\a) Battle for Azeroth
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name ba) Horde Val'sharah 2
#displayname |cFF1EFF004|r - Val'sharah << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF003|r - Val'sharah << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bb) Horde Highmountain 2
<< Horde
step
#include RestedXP Speed Leveling\a) Val'sharah Speedrun Midnight Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bb) Horde Highmountain 2
#displayname |cFF1EFF005.1|r - Highmountain << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF004.1|r - Highmountain << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bba) Horde Highmountain 2 2
<< Horde
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun Midnight Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bba) Horde Highmountain 2 2
#displayname |cFF1EFF005.2|r - Highmountain << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF004.2|r - Highmountain << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bc) Horde Silverpine Forest 2
<< Horde
step
#include RestedXP Speed Leveling\a) Highmountain Speedrun 2 Midnight Horde
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bc) Horde Silverpine Forest 2
#displayname |cFF1EFF006|r - Silverpine Forest << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF005|r - Silverpine Forest << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bd) Horde Hillsbrad Foothills 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Silverpine Forest
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bd) Horde Hillsbrad Foothills 2
#displayname |cFF1EFF007|r - Hillsbrad Foothills << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Hillsbrad Foothills << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next be) Horde Hinterlands 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Hillsbrad Foothills
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name be) Horde Hinterlands 2
#displayname |cFF1EFF008|r - Hinterlands << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Hinterlands << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bf) Horde Kun-Lai Summit 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Hinterlands
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bf) Horde Kun-Lai Summit 2
#displayname |cFF1EFF009|r - Kun-Lai Summit (20+) << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF008|r - Kun-Lai Summit (20+) << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#title Kun-Lai Summit
#next bg) Horde Draenor Scenario 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Kun-Lai Summit
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bg) Horde Draenor Scenario 2
#displayname |cFF1EFF0010|r - Draenor Scenario << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF009|r - Draenor Scenario << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bh) Horde Draenor Garrison 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Draenor Scenario
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bh) Horde Draenor Garrison 2
#displayname |cFF1EFF0011|r - Draenor Garrison Intro << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF0010|r - Draenor Garrison Intro << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bi) Horde Spires of Arak 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Draenor Garrison
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bi) Horde Spires of Arak 2
#displayname |cFF1EFF0012|r - Spires of Arak << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF0011|r - Spires of Arak << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next bj) Horde Gorgrond 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Spires of Arak
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bj) Horde Gorgrond 2
#displayname |cFF1EFF0013|r - Gorgrond << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF0012|r - Gorgrond << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\z) 70-80 First Crafts (H) 2
<< Horde
step
#include RestedXP Speed Leveling\a) Horde Gorgrond
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name z) 70-80 First Crafts (H) 2
#displayname First Crafts << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname First Crafts << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#internal
<< Horde
step
#include RestedXP Speed Leveling\a) 70-80 First Crafts
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bq) DF Horde Intro Midnight (H)
#displayname |cFF1EFF003|r - Dragonflight Intro << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Dragonflight Intro << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\br) The Waking Shores Midnight (H) 1
<< Horde
step
#include RestedXP Speed Leveling\a) DF Horde Intro Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name br) The Waking Shores Midnight (H) 1
#displayname |cFF1EFF004|r - The Waking Shores << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF003|r - The Waking Shores << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\bs) Val'sharah Speedrun Midnight (H)
<< Horde
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@WakingShoresStart-The Courage of One's Convictions
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@MissingEndStart-MissingEndEnd
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bs) Ohn'ahran Plains Midnight (H)
#displayname |cFF1EFF005|r - Ohn'ahran Plains << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF004|r - Ohn'ahran Plains << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\bt) The Azure Span Midnight (H)
<< Horde
step
#include RestedXP Speed Leveling\a) Ohn'ahran Plains Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bt) The Azure Span Midnight (H)
#displayname |cFF1EFF006|r - The Azure Span << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF005|r - The Azure Span << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\bu) Thaldraszus Midnight (H)
<< Horde
step
#include RestedXP Speed Leveling\a) The Azure Span Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bu) Thaldraszus Midnight (H)
#displayname |cFF1EFF007|r - Thaldraszus << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Thaldraszus << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\bv) War Within Recap (H) 2
<< Horde
step
#include RestedXP Speed Leveling\a) Thaldraszus Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bv) Isle of Dorn (H)
#displayname |cFF1EFF008|r - Isle of Dorn << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Isle of Dorn << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Midnight\caa) Midnight Intro Route (H)
<< Horde
step
#include RestedXP Speed Leveling\a) Isle of Dorn Route
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name bw) War Within Recap (H)
#displayname War Within Recap |cRXP_ENEMY_(Alternative)|r
#next RestedXP Midnight\caa) Midnight Intro Route (H)
<< Horde
step
#include RestedXP Speed Leveling\a) The War Within Recap
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bq) DF Horde Intro Midnight (H) 2
#displayname |cFF1EFF003|r - Dragonflight Intro << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF002|r - Dragonflight Intro << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Midnight\br) The Waking Shores Midnight (H) 2
<< Horde
step
#include RestedXP Speed Leveling\a) DF Horde Intro Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name br) The Waking Shores Midnight (H) 2
#displayname |cFF1EFF004|r - The Waking Shores << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF003|r - The Waking Shores << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Midnight\bs) Val'sharah Speedrun Midnight (H) 2
<< Horde
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@WakingShoresStart-The Courage of One's Convictions
step
#include RestedXP Speed Leveling\a) The Waking Shores Midnight@MissingEndStart-MissingEndEnd
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bs) Ohn'ahran Plains Midnight (H) 2
#displayname |cFF1EFF005|r - Ohn'ahran Plains << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF004|r - Ohn'ahran Plains << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\bt) The Azure Span Midnight (H) 2
<< Horde
step
#include RestedXP Speed Leveling\a) Ohn'ahran Plains Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bt) The Azure Span Midnight (H) 2
#displayname |cFF1EFF006|r - The Azure Span << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF005|r - The Azure Span << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\bu) Thaldraszus Midnight (H) 2
<< Horde
step
#include RestedXP Speed Leveling\a) The Azure Span Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bu) Thaldraszus Midnight (H) 2
#displayname |cFF1EFF007|r - Thaldraszus << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF006|r - Thaldraszus << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Speed Leveling\bv) War Within Recap (H) 2
<< Horde
step
#include RestedXP Speed Leveling\a) Thaldraszus Midnight
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bv) Isle of Dorn Route (H) 2
#displayname |cFF1EFF008|r - Isle of Dorn << Orc !DK/Troll !DK/Undead !DK/Tauren !DK/BloodElf !DK !DemonHunter
#displayname |cFF1EFF007|r - Isle of Dorn << Goblin/Pandaren/DK/Nightborne/HighmountainTauren/MagharOrc/EarthenDwarf/ZandalariTroll/Vulpera/Dracthyr/DemonHunter/Harronir
#next RestedXP Midnight\caa) Midnight Intro Route (H)
<< Horde
step
#include RestedXP Speed Leveling\a) Isle of Dorn Route
]])

RXPGuides.RegisterGuide([[
#retail
#version 3
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name bw) War Within Recap (H) 2
#displayname War Within Recap |cRXP_ENEMY_(Alternative)|r
#next RestedXP Midnight\caa) Midnight Intro Route (H)
<< Horde
step
#include RestedXP Speed Leveling\a) The War Within Recap
]])

