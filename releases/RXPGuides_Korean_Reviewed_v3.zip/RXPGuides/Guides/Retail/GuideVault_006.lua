if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Grudge Pit 2 (A)
#displayname |cFF00CCFF14|r - The Grudge Pit
#next a) Trials of the Shul'ka (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Grudge Pit 2
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Trials of the Shul'ka (A)
#displayname |cFF00CCFF15|r - Trials of the Shul'ka
#next a) Trials of the Shul'ka (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Trials of the Shul'ka
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Storylines
#name ada) Voidstorm Storylines (A)
#displayname |cFF00FF004|r - Voidstorm Sojourner
#chapters a) The Void Peers Back (A);a) Shadow Puppets (A);a) The Nethersent (A);a) The Nightbreaker (A);a) Pathogenic Problem (A);a) A Voice Inside (A);a) Shadowguard's Shadow (A);a) A Gift, Given Freely (A);a) Breaking the Triad (A);a) Go Low, Go Loud (A);a) Secrets in the Dark (A);a) Oaths to Family (A);a) To Be Changed (A);a) A Dance with the Devil (A);a) A Domanaar's Best Friend (A);a) A More Potent Foe (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Void Peers Back (A)
#displayname |cFF00CCFF1|r - The Void Peers Back
#next a) Shadow Puppets (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Void Peers Back
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Shadow Puppets (A)
#displayname |cFF00CCFF2|r - Shadow Puppets
#next a) The Nethersent (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Shadow Puppets
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Nethersent (A)
#displayname |cFF00CCFF3|r - The Nethersent
#next a) The Nightbreaker (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Nethersent
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Nightbreaker (A)
#displayname |cFF00CCFF4|r - The Nightbreaker
#next a) Pathogenic Problem (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Nightbreaker
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Pathogenic Problem (A)
#displayname |cFF00CCFF5|r - Pathogenic Problem
#next a) A Voice Inside (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Pathogenic Problem
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Voice Inside (A)
#displayname |cFF00CCFF6|r - A Voice Inside
#next a) Shadowguard's Shadow (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Voice Inside
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Shadowguard's Shadow (A)
#displayname |cFF00CCFF7|r - Shadowguard's Shadow
#next a) A Gift, Given Freely (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Shadowguard's Shadow
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Gift, Given Freely (A)
#displayname |cFF00CCFF8|r - A Gift, Given Freely
#next a) Breaking the Triad (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Gift, Given Freely
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Breaking the Triad (A)
#displayname |cFF00CCFF9|r - Breaking the Triad
#next a) Go Low, Go Loud (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Breaking the Triad
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Go Low, Go Loud (A)
#displayname |cFF00CCFF10|r - Go Low, Go Loud
#next a) Secrets in the Dark (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Go Low, Go Loud
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Secrets in the Dark (A)
#displayname |cFF00CCFF11|r - Secrets in the Dark
#next a) Oaths to Family (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Secrets in the Dark
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Oaths to Family (A)
#displayname |cFF00CCFF12|r - Oaths to Family
#next a) To Be Changed (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) Oaths to Family
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) To Be Changed (A)
#displayname |cFF00CCFF13|r - To Be Changed
#next a) A Dance with the Devil (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) To Be Changed
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Dance with the Devil (A)
#displayname |cFF00CCFF14|r - A Dance with the Devil
#next a) A Domanaar's Best Friend (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Dance with the Devil
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Domanaar's Best Friend (A)
#displayname |cFF00CCFF15|r - A Domanaar's Best Friend
#next a) A More Potent Foe (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Domanaar's Best Friend
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A More Potent Foe (A)
#displayname |cFF00CCFF16|r - A More Potent Foe |cFFFCDC00(90)|r
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A More Potent Foe
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Storylines
#name ae) Crimson Rogue (A)
#displayname The Crimson Rogue
#chapters a) The Regent's Request (A); a) A Favor for the Lion (A)
<< Alliance
step
+1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Regent's Request (A)
#displayname |cFF00CCFF1|r - The Regent's Request |cFFFCDC00(80+)|r
#next a) A Favor for the Lion (A)
#chapter
<< Alliance
step
#include RestedXP Midnight\a) The Regent's Request
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Favor for the Lion (A)
#displayname |cFF00CCFF2|r - A Favor for the Lion |cFFFCDC00(90)|r
#chapter
<< Alliance
step
#include RestedXP Midnight\a) A Favor for the Lion
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name af) Old Soldiers (A)
#subgroup Storylines
#displayname Arcantina Storylines
<< Alliance
step
#include a) Old Soldiers
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup Storylines
#name ag) Legends Never Die & The Empty Cradle (A)
#displayname Legend of the Haranir
<< Alliance
step
#include RestedXP Midnight\a) Legends Never Die & The Empty Cradle
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Pre-Turnins
#subweight 1000.5
#name a) 1Pre-Turnins Booklet (A)
#displayname Pre-Turnins Booklet|cRXP_WARN_(READ)|r
<< Alliance
step
#include a) Pre-Turnins Booklet
step
+Select next guide
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Pre-Turnins
#name a) 2Turnin Route Alliance (A)
#displayname Miscellaneous Turnins
<< Alliance
step
#include a) Turnin Route Alliance
step
+Select next guide
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Pre-Turnins
#name a) 4PoP-UP Quests Turnins (A)
#displayname First Crafts & Global Turnins
<< Alliance
step
#include a) PoP-UP Quests Turnins
step
+Select next guide
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name c) Turnin Route Alliance (A)
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route (A)
<< Alliance
step
#include a) Turnin Route Alliance
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name caa) Midnight Intro Route (A)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route (A)
<< Alliance
step
#hidewindow
#completewith TheLightsSummonsZ
+1
.use 6948
.use 223953
step
#completewith TheLightsSummonsB
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#subweight 1000
#name cab) Eversong Woods Route (A)
#displayname |cFFFCDC002|r - Eversong Woods 1
#next cac) Eversong Woods Route (A) 2
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Eversong Woods Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#subweight 1000
#name cac) Eversong Woods Route (A) 2
#displayname |cFFFCDC003|r - Eversong Woods 2
#next cb) Arator Route (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Eversong Woods Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cb) Arator Route (A)
#displayname |cFFFCDC004|r - Arator
#next cca) Harandar Route (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Arator Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cca) Harandar Route (A)
#displayname |cFFFCDC005|r - Harandar 1
#next ccb) Harandar Route (A) 2
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Harandar Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name ccb) Harandar Route (A) 2
#displayname |cFFFCDC006|r - Harandar 2
#next cd) Zul'Aman Route (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Harandar Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cd) Zul'Aman Route (A)
#displayname |cFFFCDC007|r - Zul'Aman
#next ce) Voidstorm Route (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Zul'Aman Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name ce) Voidstorm Route (A)
#displayname |cFFFCDC008|r - Voidstorm Part 1
#next cf) Voidstorm Route (A) 2
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Voidstorm Route 1
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name cf) Voidstorm Route (A) 2
#displayname |cFFFCDC009|r - Voidstorm Part 2
#next RestedXP Midnight\a) 90 Unlocking Systems (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Voidstorm Route 2
step
+If you're still not 90 then you can do your first crafts (in your crafting professions) now if you haven't done them already. Otherwise start the Adventure Mode guide or follow the next guide (by completing this step) to unlock the endgame systems.
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name c) Turnin Route Alliance 2 (A)
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 2 (A)
<< Alliance
step
#include RestedXP Midnight\a) Turnin Route Alliance
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name caa) Midnight Intro Route 2 (A)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 2 (A)
<< Alliance
step
#completewith TheLightsSummonsB
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cab) Eversong Woods Route 2 (A)
#displayname |cFFFCDC002|r - Eversong Woods
#next cac) Eversong Woods Route 2 (A) 2
<< Alliance
step
#completewith Recruit Lothraxion
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Eversong Woods Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cac) Eversong Woods Route 2 (A) 2
#displayname |cFFFCDC003|r - Eversong Woods 2
#next cb) Arator Route 2 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Eversong Woods Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cb) Arator Route 2 (A)
#displayname |cFFFCDC004|r - Arator
#next cca) Harandar Route 2 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Arator Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cca) Harandar Route 2 (A)
#displayname |cFFFCDC005|r - Harandar
#next ccb) Harandar Route 2 (A) 2
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Harandar Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name ccb) Harandar Route 2 (A) 2
#displayname |cFFFCDC006|r - Harandar
#next cd) Zul'Aman Route 2 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Harandar Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cd) Zul'Aman Route 2 (A)
#displayname |cFFFCDC007|r - Zul'Aman
#next ce) Voidstorm Route 2 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Zul'Aman Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name ce) Voidstorm Route 2 (A)
#displayname |cFFFCDC008|r - Voidstorm Part 1
#next cf) Voidstorm Route 2 (A) 2
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Voidstorm Route 1
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name cf) Voidstorm Route 2 (A) 2
#displayname |cFFFCDC009|r - Voidstorm Part 2
#next RestedXP Midnight\a) 90 Unlocking Systems (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include RestedXP Midnight\a) Voidstorm Route 2
step
+If you're still not 90 then you can do your first crafts (in your crafting professions) now if you haven't done them already. Otherwise start the Adventure Mode guide or follow the next guide (by completing this step) to unlock the endgame systems.
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Turnin Route Alliance 3 (A)
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 3 (A)
<< Alliance
step
#include a) Turnin Route Alliance
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name caa) Midnight Intro Route 3 (A)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 3 (A)
<< Alliance
step
#completewith TheLightsSummonsB
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#subweight 999
#name cab) Eversong Woods Route 3 (A)
#displayname |cFFFCDC002|r - Eversong Woods 1
#next cac) Eversong Woods Route 3 (A) 2
<< Alliance
step
#completewith Recruit Lothraxion
+This guide is for players who want to complete the campaign, best storylines and delves to level as quickly as possible.
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Eversong Woods Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#subweight 999
#name cac) Eversong Woods Route 3 (A) 2
#displayname |cFFFCDC003|r - Eversong Woods 2
#next cb) Arator Route 3 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Eversong Woods Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cb) Arator Route 3 (A)
#displayname |cFFFCDC004|r - Arator
#next cca) Harandar Route 3 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Arator Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cca) Harandar Route 3 (A)
#displayname |cFFFCDC005|r - Harandar 1
#next ccb) Harandar Route 3 (A) 2
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4(A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Harandar Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name ccb) Harandar Route 3 (A) 2
#displayname |cFFFCDC006|r - Harandar 2
#next cd) Zul'Aman Route 3 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Harandar Route 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cd) Zul'Aman Route 3 (A)
#displayname |cFFFCDC007|r - Zul'Aman
#next ce) Voidstorm Route 3 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Zul'Aman Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name ce) Voidstorm Route 3 (A)
#displayname |cFFFCDC008|r - Voidstorm Part 1
#next cf) Voidstorm Route 3 (A) 2
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Voidstorm Route 1
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Campaign & Sidequests
#name cf) Voidstorm Route 3 (A) 2
#displayname |cFFFCDC009|r - Voidstorm Part 2
#next RestedXP Midnight\a) 90 Unlocking Systems (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Voidstorm Route 2
step
+If you're still not 90 then you can do your first crafts (in your crafting professions) now if you haven't done them already. Otherwise start the Adventure Mode guide or follow the next guide (by completing this step) to unlock the endgame systems.
step

#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Turnin Route Alliance 4 (A)
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 4 (A)
<< Alliance
step
#include a) Turnin Route Alliance
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name caa) Midnight Intro Route 5 (A)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 5 (A)
<< Alliance
step
#completewith TheLightsSummonsB
+This guide is for players who want to finish the campaign, complete Delve quests, and level quickly to 90.
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#subweight 998
#name cab) Eversong Woods Route 5 (A)
#displayname |cFFFCDC002|r - Eversong Woods
#next cb) Arator Route 5 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#completewith Recruit Lothraxion
+This guide is for multiboxers or players skipping side quests, while incorporating Delves. The idea is to do Siren Isles at the start and crafting at the end with some additional prepared quests.
step
#include a) Eversong Woods Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name cb) Arator Route 5 (A)
#displayname |cFFFCDC003|r - Arator
#next cc) Harandar Route 5 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Arator Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name cc) Harandar Route 5 (A)
#displayname |cFFFCDC004|r - Harandar
#next cd) Zul'Aman Route 5 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Harandar Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name cd) Zul'Aman Route 5 (A)
#displayname |cFFFCDC005|r - Zul'Aman
#next ce) Voidstorm Route 5 (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Zul'Aman Route Delve
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-88)|r Campaign & Delves
#name ce) Voidstorm Route 5 (A)
#displayname |cFFFCDC006|r - Voidstorm
#next RestedXP Midnight\a) 90 Unlocking Systems (A)
<< Alliance
step
#optional
.isQuestTurnedIn account,86522
+|cRXP_WARN_Switch to the Alt Leveling Guide instead:|r
.clicknext RestedXP Midnight\cab) Eversong Woods Route 4 (A) >>CLICK HERE FOR GUIDE << Alliance
step
#include a) Voidstorm Route Delve
step
+You can do your first crafts now! Start the Adventure Mode Guide if you still need more experience to hit 90.
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name c) Turnin Route Alliance 4 (A)
#displayname |cFF9D9D9D0|r - Prepturnins (Requires prepped quests)
#next ca) Eversong Woods Route 4 (A)
#internal
<< Alliance
step
#include RestedXP Midnight\a) Turnin Route Alliance
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name ca) Midnight DMF Route 4 (A)
#displayname |cFF9D9D9D0|r - Darkmoon Faire
#next caa) Midnight Intro Route 4 (A)
<< Alliance
step
#include RestedXP Midnight\a) DMF
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name caa) Midnight Intro Route 4 (A)
#displayname |cFFFCDC001|r - Midnight Intro
#next cab) Eversong Woods Route 4 (A)
<< Alliance
step
#completewith TheLightsSummonsB
+This guide is intended for players leveling their alts to 90. |cRXP_WARN_Remember: first crafts can provide 80-100% of a level at 89.|r
step
#include RestedXP Midnight\a) Midnight Intro Route
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#subweight 997
#name cab) Eversong Woods Route 4 (A)
#displayname |cFFFCDC002|r - Eversong Woods 1
#next cac) Harandar Voidstorm Delves (A)
<< Alliance
step
#completewith EversongWoodsAdventureModeA
+This guide is for players leveling their alts to 90. |cRXP_WARN_Remember you can do first crafts for 80-100% of level 89.|r
step
#include RestedXP Midnight\a) Eversong Woods Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#subweight 997
#name cac) Harandar Voidstorm Delves (A)
#displayname |cFFFCDC003|r - Harandar & Voidstorm Delves
#next cad) Eversong Woods Route 4 (A) 2
<< Alliance
step
#include RestedXP Midnight\a) Harandar Voidstorm Delves
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#subweight 997
#name cad) Eversong Woods Route 4 (A) 2
#displayname |cFFFCDC004|r - Eversong Woods 2
#next cb) Zul'Aman Route 4 (A)
<< Alliance
step
#include RestedXP Midnight\a) Eversong Woods Adventure Mode 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name cb) Zul'Aman Route 4 (A)
#displayname |cFFFCDC005|r - Zul'Aman
#next cca) Harandar Route 4 (A)
<< Alliance
step
#include RestedXP Midnight\a) Zul'Aman Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name cca) Harandar Route 4 (A)
#displayname |cFFFCDC006|r - Harandar 1
#next ccb) Harandar Route 4 (A) 2
<< Alliance
step
#include RestedXP Midnight\a) Harandar Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name ccb) Harandar Route 4 (A) 2
#displayname |cFFFCDC007|r - Harandar 2
#next cd) Voidstorm Route 4 (A)
<< Alliance
step
#include RestedXP Midnight\a) Harandar Adventure Mode 2
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Alt Leveling
#name cd) Voidstorm Route 4 (A)
#displayname |cFFFCDC008|r - Voidstorm
#next RestedXP Midnight\a) 90 Unlocking Systems (A)
<< Alliance
step
#include RestedXP Midnight\a) Voidstorm Adventure Mode
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#subweight 995.5
#name a) Eversong Woods Sojourner (A)
#displayname |cFFFCDC001|r - 1
#internal
<< Alliance
step
#completewith Trials and TabulationsZ
+This guide is for players who want to complete all storylines as quickly as possible in one go (for levels 80-90).
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#name a) Zul'Aman Sojourner (A)
#displayname 2
#internal
<< Alliance
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#name a) Harandar Sojourner (A)
#displayname 3
#internal
<< Alliance
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner
#name a) Voidstorm Sojourner (A)
#displayname 4
#internal
<< Alliance
step
#include a) Eversong Woods Sojourner
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#subweight 995.6
#name a) ASilvermoon & Voidstorm (A)
#displayname |cFFFCDC001|r - Silvermoon & Voidstorm Part 1
#next a) BVoidstorm Part 2 (A)
<< Alliance
step
#completewith Trials and TabulationsZ
+This guide is for players who want to complete all campaigns and storylines as quickly as possible in one go (for levels 80-90).
step
#include a) Silvermoon & Voidstorm
step
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(80-90)|r Sojourner & Campaign
#name a) BVoidstorm Part 2 (A)
#displayname |cFFFCDC002|r - Voidstorm Part 2
#next a) CEversong & Harandar Part 1 (A)
<< Alliance
step
#include a) Voidstorm Part 2
step
#hidewindow
>>1
]])

