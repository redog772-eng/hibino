if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "RETAIL" then return end

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Voice Inside
#internal
step
#optional
.isQuestAvailable account,86565
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Into the Abyss (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Into the Abyss (H) >>CLICK HERE FOR GUIDE << Horde
step
.isOnQuest 91885
#label TheIllusionofMotionZ
.goto 2405,48.74,82.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Starving Voidwalker|r.
.turnin 91884 >>Turn in The Illusion of Motion
.target Starving Voidwalker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Starving Voidwalker|r
.goto 2405,48.75,82.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Starving Voidwalker|r.
.accept 91885 >>Accept Drain You
.target Starving Voidwalker
step
#loop
.goto 2405,49.27,81.55,35,0
.goto 2405,51.66,75.83,35,0
>>Kill |cRXP_ENEMY_Pests|r.
*Use the |T1003592:0|t[Void Splinter] next to their corpses.
.complete 91885,1 
.mob Bloodthirsty Killvore
.mob Corpsepicker Karion
.mob Albino Trigore
.mob Blistercreep Bottomfeeder
.use 249433
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sentient Voidwalker|r
.goto 2405,48.75,82.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sentient Voidwalker|r.
.turnin 91885 >>Turn in Drain You
.accept 91886 >>Accept Voices of Omens
.target Sentient Voidwalker
step
.goto 2405,43.36,86.19
#arrowtext Click on the\n|cRXP_PICK_Scrystone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scrystone|r.
.complete 91886,1 
step
.goto 2405,45.55,87.18
#arrowtext Click on the\n|cRXP_PICK_Scrystone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scrystone|r.
.complete 91886,2 
step
.goto 2405,47.54,89.27
#arrowtext Click on the\n|cRXP_PICK_Scrystone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scrystone|r |cRXP_WARN_and cancel the channel|r.
.complete 91886,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Nefina|r
.goto 2405,44.76,82.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Nefina|r.
.turnin 91886 >>Turn in Voices of Omens
.accept 91887 >>Accept Dominion of Deceit
.target Scout Nefina
step
#label Deceit
.goto 2405,42.91,83.32
>>Kill |cRXP_ENEMY_Deceitful Voidwalker|r.
.complete 91887,1 
.mob Deceitful Voidwalker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Nefina|r
.goto 2405,41.44,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Nefina|r.
.turnin 91887 >>Turn in Dominion of Deceit
.target Scout Nefina
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Shadowguard's Shadow
#internal
step
#optional
.isQuestAvailable account,86509
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dawn of Reckoning (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dawn of Reckoning (H) >>CLICK HERE FOR GUIDE << Horde
step
#label ShadowguardsShadowA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,39.75,84.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.accept 92390 >>Accept Risk for Research
.target Lanlae Noxa
step
#label ShadowguardsShadowB
#title |cFFFCDC00Follow the Arrow|r
.goto 2444,62.81,66.15
.complete 92390,1 
.timer 11,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,62.81,66.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.turnin 92390 >>Turn in Risk for Research
.accept 92155 >>Accept Object Exorcism
.target Lanlae Noxa
step
.goto 2444,65.38,64.97
#arrowtext Click on the\n|cRXP_PICK_Weapon Rack|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weapon Rack|r.
.complete 92155,3 
step
.goto 2444,65.12,61.01
#arrowtext Click on the\n|cRXP_PICK_Chair|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chair|r.
.complete 92155,1 
step
.goto 2444,64.13,60.95
*|cRXP_WARN_Press the Macro in the "Active Items" window to leave the vehicle|r.
#arrowtext Click on the\n|cRXP_PICK_Barrel|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrel|r.
.complete 92155,2 
.macro Leave Vehicle,6656430 >>/leavevehicle
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,64.66,64.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.turnin 92155 >>Turn in Object Exorcism
.target Lanlae Noxa
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Havazza|r
.goto 2444,64.73,64.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Havazza|r.
.accept 92156 >>Accept It Follows Me
.target Havazza
step
#loop
.goto 2444,65.14,58.06,35,0
.goto 2444,64.79,52.58,35,0
.goto 2444,69.19,51.19,35,0
.goto 2444,65.52,47.91,35,0
.goto 2444,61.16,51.48,35,0
>>Kill |cRXP_ENEMY_Shadowguards.
*Use the |T4226150:0|t[Consuming Brand] next to their corpses.
.complete 92156,1 
.mob Malignant Shadowguard
.mob Abhorrent Shadowguard
.use 251278
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Havazza|r
.goto 2444,64.73,64.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Havazza|r.
.turnin 92156 >>Turn in It Follows Me
.target Havazza
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,64.66,64.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.accept 92157 >>Accept Ritual Activity
.target Lanlae Noxa
step
.goto 2444,62.89,66.44
#arrowtext Click on the\n|cRXP_PICK_Book|r, |cRXP_PICK_Weapon|r, and |cRXP_PICK_Barrel|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r, |cRXP_PICK_Weapon|r, and |cRXP_PICK_Barrel|r.
.complete 92157,1 
step
.goto 2444,62.74,66.68
#arrowtext Click on the\n|cRXP_PICK_Chair|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chair|r.
.complete 92157,2 
.timer 29,Roleplay Duration
step
.goto 2444,62.84,66.49
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 92157,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,62.92,66.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
Loot them for |T463856:0|t[|cRXP_LOOT_Tiny Spider Eye|r].
.turnin 92157 >>Turn in Ritual Activity
.accept 92158 >>Accept Let It In
.target Lanlae Noxa
step
.goto 2444,69.02,62.04
>>Use the |T4226150:0|t[|cRXP_WARN_ExtraActionButton|r] if the |cRXP_ENEMY_Insidious Reflection|r is not there.
*|cRXP_WARN_If you can't use the ExtraActionButton try relogging|r
*Kill the |cRXP_ENEMY_Insidious Reflection|r.
.complete 92158,2 
.mob Insidious Reflection
step
.goto 2444,69.09,62.30
#arrowtext Click on the\n|cRXP_PICK_Weakened Entity|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Weakened Entity|r.
.complete 92158,3 
step
#label Let It In
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,69.17,62.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.turnin 92158 >>Turn in Let It In
.accept 92159 >>Accept A Final Destination
.target Lanlae Noxa
step
#label ShenzarRefinery
#title |cFFFCDC00Follow the Arrow|r
.goto 2444,57.38,47.39
.complete 92159,1 
step
.goto 2444,58.47,46.61
>>Kill |cRXP_ENEMY_Havazza|r.
.complete 92159,2 
.mob Havazza
step
#label ShadowguardsShadowZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,57.37,47.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.turnin 92159 >>Turn in A Final Destination
.target Lanlae Noxa
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Gift, Given Freely
#internal
step
#optional
.isQuestAvailable account,86509
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dawn of Reckoning (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dawn of Reckoning (H) >>CLICK HERE FOR GUIDE << Horde
step
#label AGiftGivenFreelyA
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,39.93,84.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.accept 92603 >>Accept O Lonely Star
.target Orin Straylight
step
.goto 2444,39.93,84.25
#arrowtext Click on\n|cRXP_PICK_Orin Straylight|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Orin Straylight|r.
.complete 92603,1 
.timer 2.5,RP
step
#label AGiftGivenFreelyB
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,39.93,84.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.complete 92603,2 
.target Orin Straylight
.skipgossipid 136761
step
#label AGiftGivenFreelyC
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,39.57,38.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.turnin 92603 >>Turn in O Lonely Star
.accept 92605 >>Accept Honest as Bone
.accept 92604 >>Accept Speak in Blood
.target Orin Straylight
step
#hidewindow
#completewith HonestAsBoneA
#loop
.goto 2444,38.25,37.21,10,0
.goto 2444,37.95,38.50,10,0
.goto 2444,37.56,39.45,10,0
.goto 2444,36.61,39.90,10,0
.goto 2444,35.71,39.72,10,0
.goto 2444,35.64,37.74,10,0
.goto 2444,35.82,36.78,10,0
.goto 2444,34.36,36.99,10,0
.goto 2444,31.71,39.18,45,0
.goto 2444,32.46,31.33,45,0
.goto 2444,37.79,39.13,45,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Netherwasps|r, |cRXP_ENEMY_Kilivore|r and the |cRXP_ENEMY_Klaxids|r.
*Loot them for the |T1500932:0|t[|cRXP_LOOT_Viscour Ichor|r].
.complete 92604,1 
.mob Scavenging Netherwasp
.mob Hoarding Klaxid
.mob Klaxid Moltling
.mob Marrowmaw Kilivore
step
#arrowtext Click on the\n|cRXP_PICK_Bones|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bones|r.
.complete 92605,1 
step
#label HonestAsBoneA
>>Kill the |cRXP_ENEMY_Netherwasps|r, |cRXP_ENEMY_Kilivore|r and the |cRXP_ENEMY_Klaxids|r.
*Loot them for the |T1500932:0|t[|cRXP_LOOT_Viscour Ichor|r].
.complete 92604,1 
.mob Scavenging Netherwasp
.mob Hoarding Klaxid
.mob Klaxid Moltling
.mob Marrowmaw Kilivore
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,33.15,36.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.turnin 92605 >>Turn in Honest as Bone
.turnin 92604 >>Turn in Speak in Blood
.accept 92606 >>Accept Take Up Your Gift
.target Orin Straylight
step
#title Run along the circles
.goto 2444,33.09,36.36
>>Run through the ground markings to color them.
.complete 92606,1 
step
.goto 2444,33.09,36.36
#arrowtext Click on the\n|cRXP_PICK_Void Rift|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Rift|r.
.complete 92606,2 
step
.goto 2444,32.88,38.00
#arrowtext Click on the\n|cRXP_PICK_Chisel|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chisel|r.
.complete 92606,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,33.09,36.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.turnin 92606 >>Turn in Take Up Your Gift
.accept 92607 >>Accept And Carve New Shapes
.target Orin Straylight
step
.goto 2444,33.09,36.37
#arrowtext Click on\n|cRXP_PICK_Orin Straylight|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Orin Straylight|r
.complete 92607,1 
step
#label Subdue Orin
.goto 2444,28.60,34.96
>>Damage |cRXP_ENEMY_Orin's Shade|r to 30%.
.complete 92607,2 
.mob Orin's Shade
step
#label AGiftGivenFreelyZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,33.29,37.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.turnin 92607 >>Turn in And Carve New Shapes
.target Orin Straylight
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Breaking the Triad
#internal
step
#optional
.isQuestAvailable account,86509
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dawn of Reckoning (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dawn of Reckoning (H) >>CLICK HERE FOR GUIDE << Horde
step << Alliance
#label BreakingTheTriadA
#arrowtext Talk to\n|cRXP_FRIENDLY_Amari Lyndon|r
.goto 2444,40.79,84.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amari Lyndon|r.
.accept 91565 >>Accept Voidscar Arena: The Grief Spire
.target Amari Lyndon
step << Alliance
.goto 2444,41.33,83.42
#arrowtext Click on the\n|cRXP_PICK_Portal to Grief Spire|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Grief Spire|r.
.complete 91565,1 
step << Alliance
#title |cFFFCDC00Follow the Arrow|r
.goto 2444,73.97,75.38
.complete 91565,2 
.timer 5,RP
step << Alliance
#arrowtext Talk to\n|cRXP_FRIENDLY_Vidious|r
.goto 2444,73.97,75.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vidious|r after the roleplay.
.turnin 91565 >>Turn in Voidscar Arena: The Grief Spire
.accept 91597 >>Accept Voidscar Arena: For My Alliance
.accept 91583 >>Accept Voidscar Arena: The Bastion of Valor
.target Vidious
step << Alliance
#hidewindow
#completewith BreakingTheTriadAA
#loop
.goto 2444,67.21,77.01,20,0
.goto 2444,65.29,74.46,20,0
.goto 2444,64.79,70.81,25,0
.goto 2444,64.63,68.68,30,0
.goto 2444,63.6,70.08,30,0
.goto 2444,58.48,69.94,30,0
.goto 2444,58.26,67.76,30,0
.goto 2444,56.23,68.27,30,0
+1
step << Alliance
#completewith next
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T459044:0|t[|cRXP_LOOT_Spiteful Shadowgrafts|r].
.complete 91583,1 
.mob Prowling Griefshredder
.mob Griefcrusher Harrower
.mob Griefcrusher Ultradon
step << Alliance
#arrowtext Click on the\n|cRXP_PICK_Griefbounds|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Griefbounds|r.
.complete 91597,1 
step << Alliance
#label BreakingTheTriadAA
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T459044:0|t[|cRXP_LOOT_Spiteful Shadowgrafts|r].
.complete 91583,1 
.mob Prowling Griefshredder
.mob Griefcrusher Harrower
.mob Griefcrusher Ultradon
step << Alliance
#label BreakingTheTriadB
#arrowtext Talk to\n|cRXP_FRIENDLY_Vidious|r
.goto 2444,50.80,58.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vidious|r |cRXP_WARN_on the bridge|r.
.turnin 91597 >>Turn in Voidscar Arena: For My Alliance
.turnin 91583 >>Turn in Voidscar Arena: The Bastion of Valor
.accept 91599 >>Accept Voidscar Arena: A Familiar Grudge
.accept 91598 >>Accept Voidscar Arena: Pre-Provoked Violence
.target Vidious
step << Alliance
#label BreakingTheTriadC
#completewith next
>>Kill |cRXP_ENEMY_Hatebounds|r or |cRXP_ENEMY_Enemy Players|r.
.complete 91598,1 
.mob Invasive Hatechewer
.mob Hatecrusher Ultradon
.mob Hatebound Voidwalker
.mob Hatebound Executor
.mob Hatebound Voidwrath
step << Alliance
.goto 2444,31.35,69.9
>>Kill |cRXP_ENEMY_Manus Deathwake|r.
.complete 91599,1 
.mob Manus Deathwake
step << Alliance
#label Hateboundss
#loop
.goto 2444,34.05,64.95,30,0
.goto 2444,35.54,63.57,30,0
.goto 2444,37.37,66.1,30,0
.goto 2444,41.03,64.95,30,0
.goto 2444,34.88,72.02,30,0
>>Kill |cRXP_ENEMY_Hatebounds|r or |cRXP_ENEMY_Enemy Players|r.
.complete 91598,1 
.mob Invasive Hatechewer
.mob Hatecrusher Ultradon
.mob Hatebound Voidwalker
.mob Hatebound Executor
.mob Hatebound Voidwrath
step << Alliance
#label BreakingTheTriadD
#arrowtext Talk to\n|cRXP_FRIENDLY_Vidious|r
.goto 2444,50.80,58.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vidious|r |cRXP_WARN_on the bridge|r.
.turnin 91599 >>Turn in Voidscar Arena: A Familiar Grudge
.turnin 91598 >>Turn in Voidscar Arena: Pre-Provoked Violence
.accept 91600 >>Accept Voidscar Arena: Setting It Aside
.target Vidious
step << Alliance
#label BreakingTheTriadE
#arrowtext Talk to\n|cRXP_FRIENDLY_Vidious|r
.goto 2444,53.69,21.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vidious|r.
.turnin 91600 >>Turn in Voidscar Arena: Setting It Aside
.target Vidious
step << Horde
#label BreakingTheTriadA
#arrowtext Talk to\n|cRXP_FRIENDLY_Dar'gul|r
.goto 2444,34.93,80.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dar'gul|r.
.accept 91566 >>Accept Voidscar Arena: The Hate Spire
.target Dar'gul
step << Horde
#arrowtext Click on the |cRXP_PICK_Portal|r
.goto 2444,34.18,79.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 91566,1 
step << Horde
#title Follow the arrow
.goto 2444,22.96,54.28
.complete 91566,2 
step << Horde
#arrowtext Talk to\n|cRXP_FRIENDLY_Ziadan|r
.goto 2444,23.43,54.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ziadan|r.
.turnin 91566 >>Turn in Voidscar Arena: The Hate Spire
.accept 94845 >>Accept Voidscar Arena: The Bastion of Might
.accept 94844 >>Accept Voidscar Arena: For My Horde
.target Ziadan
step << Horde
#completewith ForMyHordeA
#hidewindow
#loop
.goto 2444,30.67,62.25,35,0
.goto 2444,31.56,67.19,35,0
.goto 2444,35.20,60.97,35,0
.goto 2444,37.76,68.33,35,0
+1
step << Horde
#completewith next
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T459044:0|t[|cRXP_LOOT_Spiteful Shadowgrafts|r].
.complete 94844,1 
.mob Invasive Hatechewer
.mob Hatecrusher Ultradon
.mob Hatebound Voidwalker
.mob Hatebound Executor
.mob Hatebound Voidwrath
step << Horde
#arrowtext Click on the\n|cRXP_PICK_Griefbounds|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Griefbounds|r.
.complete 94845,1 
step << Horde
#label ForMyHordeA
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T459044:0|t[|cRXP_LOOT_Spiteful Shadowgrafts|r].
.complete 94844,1 
.mob Prowling Griefshredder
.mob Griefcrusher Harrower
.mob Griefcrusher Ultradon
step << Horde
.goto 2444,50.65,58.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ziadan|r.
.turnin 94845 >>Turn in Voidscar Arena: The Bastion of Might
.turnin 94844 >>Turn in Voidscar Arena: For My Horde
.accept 94848 >>Accept Voidscar Arena: Pre-Provoked Violence
.accept 94849 >>Accept Voidscar Arena: A Familiar Grudge
.target Ziadan
step << Horde
#completewith next
>>Kill |cRXP_ENEMY_Hatebounds|r or |cRXP_ENEMY_Enemy Players|r.
.complete 94848,1 
.mob Prowling Griefshredder
.mob Griefcrusher Harrower
.mob Griefcrusher Ultradon
step << Horde
.goto 2444,61.71,84.65
>>Kill |cRXP_ENEMY_Emrin Sparkpox|r.
.complete 94849,1 
.mob Emrin Sparkpox
step << Horde
#label BreakingTheTriadAA
#loop
.goto 2444,67.21,77.01,20,0
.goto 2444,65.29,74.46,20,0
.goto 2444,64.79,70.81,25,0
.goto 2444,64.63,68.68,30,0
.goto 2444,63.6,70.08,30,0
.goto 2444,58.48,69.94,30,0
.goto 2444,58.26,67.76,30,0
.goto 2444,56.23,68.27,30,0
>>Kill |cRXP_ENEMY_Hatebounds|r or |cRXP_ENEMY_Enemy Players|r.
.complete 94848,1 
.mob Prowling Griefshredder
.mob Griefcrusher Harrower
.mob Griefcrusher Ultradon
step << Horde
#label BreakingTheTriadD
#arrowtext Talk to |cRXP_FRIENDLY_Ziadan|r
.goto 2444,50.65,58.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ziadan|r.
.turnin 94848 >>Turn in Voidscar Arena: Pre-Provoked Violence
.turnin 94849 >>Turn in Voidscar Arena: A Familiar Grudge
.accept 94855 >>Accept Voidscar Arena: Setting It Aside
.target Ziadan
step << Horde
#label BreakingTheTriadE
#arrowtext Talk to |cRXP_FRIENDLY_Ziadan|r
.goto 2444,53.54,21.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ziadan|r.
.turnin 94855 >>Turn in Voidscar Arena: Setting It Aside
.target Ziadan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Vidious|r
.goto 2444,53.69,21.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vidious|r.
.accept 91605 >>Accept Voidscar Arena: The Wrong Side
.target Vidious
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ziadan|r
.goto 2444,53.54,21.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ziadan|r.
.accept 91603 >>Accept Voidscar Arena: Two Against One
.target Ziadan
step
#hidewindow
#completewith Spiteful monsters
#loop
.goto 2444,54.11,21.3,15,0
.goto 2444,53.11,21.26,15,0
.goto 2444,52.63,20.18,15,0
.goto 2444,52.23,19.39,15,0
.goto 2444,52.29,18.78,15,0
.goto 2444,53.17,18.30,15,0
.goto 2444,52.44,16.2,15,0
.goto 2444,50.66,12.56,9,0
.goto 2444,53.17,13.3,15,0
.goto 2444,54.25,13.19,15,0
.goto 2444,56.28,12.91,15,0
.goto 2444,56.72,12.71,6,0
.goto 2444,55.43,16.25,35,0
.goto 2444,51.89,15.88,35,0
+1
step
#completewith Orbs
>>Kill |cRXP_ENEMY_Voidbeings|r.
.complete 91605,1 
.mob Spiteful Mindwarden
.mob Coagulated Void
.mob Spiteful Minder
.mob Spiteful Consumptor
.mob Devouring Spawn
step
#completewith Orbs
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orbs|r.
.complete 91603,1 
.complete 91603,2 
step
#label Orbs
#arrowtext Click on\n|cRXP_PICK_Containers|r and |cRXP_PICK_Tools|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Containers|r and |cRXP_PICK_Tools|r.
.complete 91605,2 
.complete 91605,3 
step
#completewith next
>>Kill |cRXP_ENEMY_Voidbeings|r.
.complete 91605,1 
.mob Spiteful Mindwarden
.mob Coagulated Void
.mob Spiteful Minder
.mob Spiteful Consumptor
.mob Devouring Spawn
step
#arrowtext Click on the\n|cRXP_PICK_Orbs|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Orbs|r.
.complete 91603,1 
.complete 91603,2 
step
#label Spiteful monsters
>>Kill |cRXP_ENEMY_Voidbeings|r.
.complete 91605,1 
.mob Spiteful Mindwarden
.mob Coagulated Void
.mob Spiteful Minder
.mob Spiteful Consumptor
.mob Devouring Spawn
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ziadan|r and |cRXP_FRIENDLY_Vidious|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ziadan|r and |cRXP_FRIENDLY_Vidious|r.
.turnin 91603 >>Turn in Voidscar Arena: Two Against One
.goto 2444,53.50,11.31
.target +Ziadan
.turnin 91605 >>Turn in Voidscar Arena: The Wrong Side
.accept 91606 >>Accept Voidscar Arena: Clearing House
.goto 2444,53.74,11.32
.target +Vidious
step
#completewith next
#label Trelus the Grafter
.goto 2444,53.63,7.92,15,0
>>Kill |cRXP_ENEMY_Trelus the Grafter|r.
.complete 91606,1 
.mob Trelus the Grafter
step
#completewith Trelus the Grafter
.goto 2444,53.63,6.68,40 >>Enter the building
step
#requires Trelus the Grafter
.goto 2444,53.63,6.68
>>Kill |cRXP_ENEMY_Trelus the Grafter|r.
.complete 91606,1 
.mob Trelus the Grafter
step << Alliance
#completewith next
#label Vidious
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 91606,2 
step << Alliance
#completewith Vidious
.goto 2444,53.74,11.31
.gossipoption 138233 >>Talk to |cRXP_FRIENDLY_Vidious|r.
.timer 21,Roleplay Duration
.target Vidious
step << Alliance
#requires Vidious
.goto 2444,53.74,11.31
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 91606,2 
.target Vidious
step << Horde
.goto 2444,53.50,11.31
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 91606,2 
.skipgossip 256901,1
.target Vidious
step
#label BreakingTheTriadF
#arrowtext Talk to\n|cRXP_FRIENDLY_Vidious|r
.goto 2444,53.74,11.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vidious|r.
.turnin 91606 >>Turn in Voidscar Arena: Clearing House
.target Vidious
step
#label BreakingTheTriadG
#arrowtext Talk to\n|cRXP_FRIENDLY_Charonus|r
.goto 2444,53.60,10.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Charonus|r.
.accept 91694 >>Accept Voidscar Arena: Breaking the Triad
.target Charonus

step
#label BreakingTheTriadY
>>Complete the Voidscar Arena Dungeon on any difficulty.
.complete 91694,1
step
.goto 2444,40.79,84.04 << Alliance
.goto 2444,34.93,80.36 << Horde
.turnin 91694 >>Turn in Voidscar Arena: Breaking the Triad
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Go Low, Go Loud
#internal
step
#label GoLowGoLoudA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lysikas|r
.goto 2405,36.03,59.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r
.accept 92657 >>Accept The Brewing Storm
.target Lysikas
step
#label Turn in The Brewing Storm
#arrowtext Talk to\n|cRXP_FRIENDLY_Lysikas|r
.goto 2405,26.34,68.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r
.turnin 92657 >>Turn in The Brewing Storm
.accept 92658 >>Accept Tactical Acquisition
.accept 92659 >>Accept Resource Denial
.target Lysikas
step
#label GoLowGoLoudB
#hidewindow
#completewith VoidEnergy
#loop
.goto 2405,29.94,63.53,20,0
.goto 2405,30.76,63.8,20,0
.goto 2405,31.69,64.09,20,0
.goto 2405,31.82,65.18,20,0
.goto 2405,32.66,65.63,20,0
.goto 2405,33.56,65.66,20,0
.goto 2405,33.79,66.33,20,0
.goto 2405,32.47,66.41,30,0
.goto 2405,30.15,63.71,30,0
.goto 2405,27.08,62.85,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Voidbeings|r
*Loot them for |T132885:0|t[|cRXP_LOOT_Energy|r].
*|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Canisters|r
.complete 92658,1 
.mob Scavenging Voidspawn
.mob Seething Overseer
.mob Ragged Siphoner
.mob Laboring Voidwalker
step
#arrowtext Click on\n|cRXP_PICK_Orbs|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Orbs|r.
.complete 92659,1 
step
#label VoidEnergy
>>Kill |cRXP_ENEMY_Voidbeings|r
*Loot them for |T132885:0|t[|cRXP_LOOT_Energy|r].
#arrowtext Click on\n|cRXP_PICK_Canisters|r
*|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Canisters|r
.complete 92658,1 
.mob Scavenging Voidspawn
.mob Seething Overseer
.mob Ragged Siphoner
.mob Laboring Voidwalker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lysikas|r
.goto 2405,35.68,66.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r
.turnin 92658 >>Turn in Tactical Acquisition
.target Lysikas
.turnin 92659 >>Turn in Resource Denial
.accept 92660 >>Accept Null Implements
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2405,35.72,66.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r
.accept 92661 >>Accept Hammer Meet Anvil
.target Riftblade Maella
step
#hidewindow
#completewith Telumnus
#loop
.goto 2405,33.53,67.73,10,0
.goto 2405,32.89,67.57,10,0
.goto 2405,32.71,70.1,10,0
.goto 2405,32.33,70.99,10,0
.goto 2405,32.94,70.62,10,0
.goto 2405,33.61,69.61,30,0
.goto 2405,33.84,68.54,30,0
+1
step
#completewith Objects
>>Kill |cRXP_ENEMY_Telumnus|r
.complete 92661,1 
.mob Telumnus
step
#completewith Objects
>>Kill |cRXP_ENEMY_Stormarions|r
.complete 92661,2 
.mob Stormarion Subjugator
.mob Stormarion Attendant
.mob Clotted Creepling
.mob Stormarion Artificer
step
#label Objects
#arrowtext Click on the\n|cRXP_PICK_Null Stabilizer|r, |cRXP_PICK_Voidway Energist|r, and |cRXP_PICK_Singularity Forceps|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Null Stabilizer|r, |cRXP_PICK_Voidway Energist|r and |cRXP_PICK_Singularity Forceps|r.
.complete 92660,1 
.complete 92660,2 
.complete 92660,3 
step
#completewith next
>>Kill |cRXP_ENEMY_Telumnus|r
.complete 92661,1 
.mob Telumnus
step
>>Kill |cRXP_ENEMY_Stormarions|r
.complete 92661,2 
.mob Stormarion Subjugator
.mob Stormarion Attendant
.mob Clotted Creepling
.mob Stormarion Artificer
step
#label Telumnus
>>Kill |cRXP_ENEMY_Telumnus|r
.complete 92661,1 
.mob Telumnus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lysikas|r and |cRXP_FRIENDLY_Riftblade Maella|r
.goto 2405,31.2,68.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r and |cRXP_FRIENDLY_Riftblade Maella|r
.turnin 92660 >>Turn in Null Implements
.target Lysikas
.turnin 92661 >>Turn in Hammer Meet Anvil
.target Riftblade Maella
.accept 92662 >>Accept Core Collapse
step
#loop
.goto 2405,31.57,68.43,10,0
.goto 2405,31.69,68.26,10,0
.goto 2405,31.72,68.5,10,0
.goto 2405,31.59,68.66,10,0
#arrowtext Click on the\n|cRXP_PICK_Pylons|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylons|r
.complete 92662,1 
.choose 7272735
.choose 7272732
.choose 7272733
.target Defense Position
step
.goto 2405,31.17,68.23
#arrowtext Click on the\n|cRXP_PICK_Tools|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tools|r
.complete 92662,2 
step
.goto 2405,32.43,68.88
>>Use |T135753:0|t[Burst Shot] on cooldown; otherwise |T249176:0|t[Shoot] at |cRXP_ENEMY_Voidbeings|r
.complete 92662,3 
step
#label GoLowGoLoudZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2405,31.20,68.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r
.turnin 92662 >>Turn in Core Collapse
.target Riftblade Maella
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Secrets in the Dark
#internal
step
#optional
.isQuestAvailable account,86565
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Into the Abyss (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Into the Abyss (H) >>CLICK HERE FOR GUIDE << Horde
step
#label It's Not Just a Rock!
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Alayshen|r
.goto 2405,36.90,58.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Alayshen|r.
.accept 92939 >>Accept It's Not Just a Rock!
.target Riftwalker Alayshen
step
#loop
.goto 2405,37.79,57.86,15,0
.goto 2405,38.62,57.35,30,0
.goto 2405,38.75,58.61,30,0
.goto 2405,39.61,58.9,30,0
.goto 2405,39.7,58,30,0
.goto 2405,40.07,57.65,30,0
.goto 2405,39.49,56.29,30,0
.goto 2405,38.52,59.75,35,0
.goto 2405,37.28,61.66,35,0
.goto 2405,38.69,61.49,35,0
>>Kill the |cRXP_ENEMY_Ultradons|r and |cRXP_ENEMY_Consumptors|r.
*Loot them for the |T134422:0|t[|cRXP_LOOT_Ancient Rubble|r].
.complete 92939,1
.mob Voidcraven Consumptor
.mob Gluttonous Ultradon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Alayshen|r
.goto 2405,40.19,56.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Alayshen|r.
.turnin 92939 >>Turn in It's Not Just a Rock!
.accept 92944 >>Accept Sifting Through Void
.target Riftwalker Alayshen
step
#title |cFFFCDC00Follow the Arrow|r
.goto 2405,40.20,56.76
.complete 92944,1 
step
#title Fly through the discs
.goto 2405,40.20,56.76,-1
.goto 2405,38.95,59.02,-1
.goto 2405,37.99,60.79,-1
.goto 2405,38.23,62.12,-1
.goto 2405,40.02,58.35,-1
.goto 2405,39.22,57.74,-1
>>If you hit the ground before collecting enough discs, jump into any vortex again.
.complete 92944,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Alayshen|r
.goto 2405,40.19,56.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Alayshen|r.
.turnin 92944 >>Turn in Sifting Through Void
.target Riftwalker Alayshen
.accept 92946 >>Accept Buried in the Dark
step
#title |cFFFCDC00Follow the Arrow|r
.goto 2405,40.21,56.72
.complete 92946,1 
step
#completewith next
#label Tablet of Empire read
>>|cRXP_WARN_Move to the next location and wait for the roleplay|r.
.complete 92946,2 
step
#completewith Tablet of Empire read
.goto 2405,38.72,58.78
.gossipoption 138319 >>Click on the |cRXP_PICK_Tablet|r.
.timer 12.5,Roleplay Duration
step
#requires Tablet of Empire read
.goto 2405,39.34,57.9
>>|cRXP_WARN_Move to the next location and wait for the roleplay|r.
.complete 92946,2 
step
#completewith next
#label Tablet of Conquest
>>|cRXP_WARN_Move to the next location and wait for the roleplay|r.
.complete 92946,3 
step
#completewith Tablet of Conquest
.goto 2405,39.33,57.91
.gossipoption 138332 >>Click on the |cRXP_PICK_Tablet|r.
.timer 10,Roleplay Duration
step
#requires Tablet of Conquest
.goto 2405,39.69,58.33
>>|cRXP_WARN_Move to the next location and wait for the roleplay|r.
.complete 92946,3 
step
#completewith next
#label Tablet of Annihilation
>>|cRXP_WARN_Move to the next location and wait for the roleplay|r.
.complete 92946,4 
step
#completewith Tablet of Annihilation
.goto 2405,39.69,58.33
.gossipoption 138333 >>Click on the |cRXP_PICK_Tablet|r.
.timer 20,Roleplay Duration
step
#requires Tablet of Annihilation
#arrowtext Don't click portal yet
.goto 2405,39.38,58.36
>>|cRXP_WARN_Move to the next location and wait for the roleplay, don't click the portal yet|r.
.complete 92946,4 
.skipgossipid 138333
step
#completewith next
#label BuriedInTheDarkA
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Alayshen|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Alayshen|r.
.turnin 92946 >>Turn in Buried in the Dark
.accept 92948 >>Accept In Over My Head
.target Riftwalker Alayshen
step
#completewith BuriedInTheDarkA
#title Take the portal
.goto 2405,39.38,58.36
.subzone 15963 >>Click on the |cRXP_PICK_Portal|r.
step
#requires BuriedInTheDarkA
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Alayshen|r
.goto 2405,40.19,56.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Alayshen|r.
.turnin 92946 >>Turn in Buried in the Dark
.accept 92948 >>Accept In Over My Head
.target Riftwalker Alayshen
step
#title |cFFFCDC00Follow the Arrow|r
.goto 2405,40.21,56.77
.complete 92948,1 
step
.goto 2405,39.66,55.86
>>Kill |cRXP_ENEMY_Akintunde the Unstoppable|r.
.complete 92948,2 
.mob Akintunde the Unstoppable
step
#completewith next
#label InOverMyHeadA
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Alayshen|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Alayshen|r.
.turnin 92948 >>Turn in In Over My Head
.target Riftwalker Alayshen
step
#completewith InOverMyHeadA
#title Take the portal
.goto 2405,39.59,56.18
.subzone 15949 >>Click on the |cRXP_PICK_Portal|r.
step
#requires InOverMyHeadA
#label Over My HeadZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Alayshen|r
.goto 2405,37.06,58.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Alayshen|r.
.turnin 92948 >>Turn in In Over My Head
.target Riftwalker Alayshen
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Oaths to Family
#internal
step
#optional
.isQuestAvailable account,86509
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Dawn of Reckoning (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Dawn of Reckoning (H) >>CLICK HERE FOR GUIDE << Horde
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.isQuestTurnedIn 86521
.goto 2405,50.68,73.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.accept 90838 >>Accept Oaths and Heirlooms
.target Kifaan
step
#label OathsToFamilyA
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,44.69,68.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.turnin -90838 >>Turn in Oaths and Heirlooms
.accept 90845 >>Accept Distant Memories
.accept 90844 >>Accept Fits of Lucidity
.target Kifaan
step
#label OathsToFamilyB
#hidewindow
#completewith Interrogated Data
#loop
.goto 2405,46.34,67.99,30,0
.goto 2405,46.82,67.77,30,0
.goto 2405,47.55,67.94,30,0
.goto 2405,47.6,68.41,30,0
.goto 2405,48.19,69.16,30,0
.goto 2405,47.55,69.14,30,0
.goto 2405,47.15,68.86,30,0
.goto 2405,47.07,69.99,30,0
.goto 2405,46.23,70.25,30,0
.goto 2405,45.27,69.58,30,0
.goto 2405,46.57,71.85,30,0
.goto 2405,47.49,71.7,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Overcrofts|r |cRXP_WARN_Ignore Automatons|r.
*Loot them for the |T6012039:0|t[|cRXP_LOOT_Interrogated Data|r].
.complete 90844,1 
.mob Overcroft Inquisitor
.mob Overcroft Skypiercer
.mob Overcroft Technician
.mob Overcroft Militant
.mob Overcroft Ascendant
step
#arrowtext Click on the\n|cRXP_PICK_K'areshi Keepsake|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_K'areshi Keepsake|r.
.complete 90845,1 
step
#label Interrogated Data
>>Kill |cRXP_ENEMY_Overcrofts|r |cRXP_WARN_Ignore Automatons|r.
*Loot them for the |T6012039:0|t[|cRXP_LOOT_Interrogated Data|r].
.complete 90844,1 
.mob Overcroft Inquisitor
.mob Overcroft Skypiercer
.mob Overcroft Technician
.mob Overcroft Militant
.mob Overcroft Ascendant
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,44.69,68.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.complete 90844,2 
.skipgossipid 136789
.timer 12,Roleplay Duration
.target Kifaan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,44.69,68.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.turnin 90845 >>Turn in Distant Memories
.turnin 90844 >>Turn in Fits of Lucidity
.accept 90847 >>Accept Truth From Power
.target Kifaan
step
#completewith next
#label TruthFromPowerA
.goto 2405,45.92,70.73,10,0
.goto 2405,45.47,71.26,10,0
.goto 2405,45.24,71.41,10,0
>>Kill |cRXP_ENEMY_Questioner Xen'daan|r.
*Loot him for |T6011984:0|t[|cRXP_LOOT_Sombersong's Necklace|r].
.complete 90847,1 
.complete 90847,2 
.mob Questioner Xen'daan
step
.isOnQuest 90847
#completewith TruthFromPowerA
#title Enter the tunnel
.goto 2405,44.84,71.28,40 >>|cRXP_WARN_Enter the tunnel|r.
step
#requires TruthFromPowerA
#label Sombersong
.goto 2405,44.84,71.28
>>Kill |cRXP_ENEMY_Questioner Xen'daan|r.
*Loot him for |T6011984:0|t[|cRXP_LOOT_Sombersong's Necklace|r].
.complete 90847,1 
.complete 90847,2 
.mob Questioner Xen'daan
step
#completewith next
#label TruthFromPowerB
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,45.26,71.43,10,0
.goto 2405,45.49,71.19,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.turnin 90847 >>Turn in Truth From Power
.accept 90848 >>Accept She Started the Fire
.target Kifaan
step
.isOnQuest 90847
#completewith TruthFromPowerB
#title Leave the cave
.goto 2405,45.86,70.74,10 >>|cRXP_WARN_Leave the cave.|r
step
#requires TruthFromPowerB
#label Truth From Power
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,44.69,68.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.turnin 90847 >>Turn in Truth From Power
.accept 90848 >>Accept She Started the Fire
.target Kifaan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,37.68,48.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.turnin 90848 >>Turn in She Started the Fire
.accept 90852 >>Accept Techno-Magnetic Pulse
.accept 90851 >>Accept Eating Their Own
.target Kifaan
step
#label She Started the Fire
#completewith TechnoMagneticPulseA
>>Kill |cRXP_ENEMY_Shadowguard Engineers|r and |cRXP_ENEMY_Shadowguard Infusers|r.
.complete 90851,1 
.mob Shadowguard Engineer
.mob Shadowguard Infuser
step
.goto 2405,38.87,46.58
#arrowtext Click on the\n|cRXP_PICK_Crackling Energy Vessel|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crackling Energy Vessel|r.
.complete 90852,3 
step
#title Betrayers freed (1/3) |cFFFCDC00(Read Note)|r
.goto 2405,38.93,46.69
>>Use the |T5872060:0|t[|cRXP_WARN_ExtraActionButton|r] an aim at the |cRXP_PICK_Betrayer|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90852,1,1 
step
#completewith next
#label TechnoMagneticPulseB
>>Use the |T5872060:0|t[|cRXP_WARN_ExtraActionButton|r] an aim at the |cRXP_PICK_Betrayer|r.
.complete 90852,1,2 
step
.isOnQuest 90852
#completewith TechnoMagneticPulseB
.goto 2405,38.87,46.58
.cast 431489 >>Click on the |cRXP_PICK_Crackling Energy Vessel|r.
step
#requires TechnoMagneticPulseB
#title Betrayers freed (2/3) |cFFFCDC00(Read Note)|r
.goto 2405,38.98,45.19
>>Use the |T5872060:0|t[|cRXP_WARN_ExtraActionButton|r] an aim at the |cRXP_PICK_Betrayer|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90852,1,2 
step
#completewith next
#label TechnoMagneticPulseC
>>Use the |T5872060:0|t[|cRXP_WARN_ExtraActionButton|r] an aim at the |cRXP_PICK_Betrayer|r.
.complete 90852,1 
step
.isOnQuest 90852
#completewith TechnoMagneticPulseC
.goto 2405,38.93,45.11
.cast 431489 >>Click on the |cRXP_PICK_Crackling Energy Vessel|r.
step
#requires TechnoMagneticPulseC
#title Betrayers freed (3/3) |cFFFCDC00(Read Note)|r
.goto 2405,36.93,45.71
>>Use the |T5872060:0|t[|cRXP_WARN_ExtraActionButton|r] an aim at the |cRXP_PICK_Betrayer|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90852,1 
step
#completewith next
#label TechnoMagneticPulseD
>>Use the |T5872060:0|t[|cRXP_WARN_ExtraActionButton|r] an aim at the |cRXP_PICK_Betrayer|r.
.complete 90852,2 
step
.isOnQuest 90852
#completewith TechnoMagneticPulseD
.goto 2405,36.94,45.59
.cast 431489 >>Click on the |cRXP_PICK_Crackling Energy Vessel|r.
step
#requires TechnoMagneticPulseD
#label TechnoMagneticPulseA
#title Veraan freed
.goto 2405,36.85,45.09
>>Use the |T5872060:0|t[|cRXP_WARN_ExtraActionButton|r] an aim at |cRXP_PICK_Veraan|r.
.complete 90852,2 
step
#loop
.goto 2405,38.05,45.55,30,0
.goto 2405,38.95,45.28,30,0
.goto 2405,38.35,46.63,30,0
.goto 2405,37.13,47.11,30,0
>>Kill |cRXP_ENEMY_Shadowguard Engineers|r and |cRXP_ENEMY_Shadowguard Infusers|r.
.complete 90851,1 
.mob Shadowguard Engineer
.mob Shadowguard Infuser
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,36.30,43.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.turnin 90851 >>Turn in Eating Their Own
.turnin 90852 >>Turn in Techno-Magnetic Pulse
.accept 93396 >>Accept Bursting at the Seams
.target Kifaan
step
#label his sister
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,36.30,43.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.complete 93396,1 
.timer 27.5,Roleplay Duration
.target Kifaan
.skipgossipid 136988
step
#label Bursting at the Seams
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,36.30,43.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r after the roleplay.
.turnin 93396 >>Turn in Bursting at the Seams
.target Kifaan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Veraan|r
.goto 2405,36.33,44.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veraan|r.
.accept 90858 >>Accept Repress the Oppressors
.target Veraan
step
#label Shadowguard operation
#loop
.goto 2405,35.73,41.22,35,0
.goto 2405,39.08,40.89,35,0
.goto 2405,38.27,44.62,50,0
>>Kill |cRXP_ENEMY_Shadowguards|r.
#arrowtext Click on\n|cRXP_PICK_Reservoirs|r and |cRXP_PICK_Pipes|r
*|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Reservoirs|r, and |cRXP_PICK_Pipes|r.
.complete 90858,1 
.mob Shadowguard Automaton
.mob Shadowguard Voidweaver
.mob Shadowguard Technician
.mob Shadowguard Adept
.mob Arcane Elemental
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Veraan|r
.goto 2405,37.44,39.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veraan|r.
.turnin 90858 >>Turn in Repress the Oppressors
.accept 90860 >>Accept Shedding the Yoke
.target Veraan
step
#label Soulbinder D'zaar
.goto 2405,37.15,37.51
>>Kill |cRXP_ENEMY_Soulbinder D'zaar|r.
.complete 90860,1 
.mob Soulbinder D'zaar
step
#label OathsToFamilyZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Veraan|r
.goto 2405,50.98,68.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veraan|r.
.turnin 90860 >>Turn in Shedding the Yoke
.target Veraan
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) To Be Changed
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Sideras|r
.goto 2405,53.71,69.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Sideras|r
.accept 91533 >>Accept What We Leave Behind
.target Riftwalker Sideras
step
.goto 2405,53.73,69.94
#arrowtext Click on the\n|cRXP_PICK_Bag|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
.complete 91533,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,41.85,74.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91533 >>Turn in What We Leave Behind
.target Riftblade Astre
.accept 91535 >>Accept Home Sweet Grave
.accept 91536 >>Accept Like a Weed
step
#label Home Sweet Grave
#hidewindow
#completewith Locus Point
#loop
.goto 2405,41.15,77.14,30,0
.goto 2405,42.11,77.92,30,0
.goto 2405,42.7,76.84,30,0
.goto 2405,43.24,75.82,30,0
.goto 2405,43.7,75.99,30,0
.goto 2405,44.14,75.55,30,0
.goto 2405,44,74.64,30,0
.goto 2405,43.3,73.57,30,0
.goto 2405,42.71,71.58,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Ridge Consumptor|r, |cRXP_ENEMY_Ridge Scavenger|r and |cRXP_ENEMY_Predatory Voidscythe|r.
.complete 91536,1 
.mob Ridge Consumptor
.mob Predatory Voidscythe
.mob Ridge Scavenger
step
#arrowtext Click on the\n|cRXP_PICK_Flowers|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flowers|r
.complete 91535,1 
step
#label Locus Point
>>Kill |cRXP_ENEMY_Ridge Consumptor|r, |cRXP_ENEMY_Ridge Scavenger|r and |cRXP_ENEMY_Predatory Voidscythe|r.
.complete 91536,1 
.mob Ridge Consumptor
.mob Predatory Voidscythe
.mob Ridge Scavenger
step
#label TeapotZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,41.88,74.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91535 >>Turn in Home Sweet Grave
.target Riftblade Astre
.turnin 91536 >>Turn in Like a Weed
.accept 91537 >>Accept Confronting It
step
#label Shade of Grief
.goto 2405,41.88,74.55
#arrowtext Click on the\n|cRXP_PICK_Teapot|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Teapot|r
.complete 91537,1 
step
.goto 2405,39.57,76.29
>>Damage |cRXP_ENEMY_Shade of Grief|r to 50%.
.complete 91537,2 
.mob Shade of Grief
step
#label Confronting It
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,41.94,74.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91537 >>Turn in Confronting It
.target Riftblade Astre
.accept 91541 >>Accept Unchecked Emotions
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,52.12,69.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91541 >>Turn in Unchecked Emotions
.accept 91542 >>Accept The Town Inside Me
.target Riftblade Astre
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,52.17,69.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r
.complete 91542,1 
.skipgossipid 135019
.target Magister Umbric
step
#completewith next
#label Shade of Loss
>>Kill |cRXP_ENEMY_Shade of Loss|r after the roleplay.
.complete 91542,2 
.mob Shade of Loss
step
#completewith Shade of Loss
.goto 2405,53.41,70.32
.gossipoption 135020 >>Talk to |cRXP_FRIENDLY_Riftwalker Sideras|r
.timer 4.5,RP
.target Riftwalker Sideras
step
#requires Shade of Loss
.goto 2405,53.4,70.38
>>Kill |cRXP_ENEMY_Shade of Loss|r after the roleplay.
.complete 91542,2 
.mob Shade of Loss
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2405,52.53,72.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r
.complete 91542,3 
.skipgossipid 135018
.target Riftblade Maella
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,62.36,82.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91542 >>Turn in The Town Inside Me
.target Riftblade Astre
.accept 91544 >>Accept Familiar Energies
.accept 91963 >>Accept Running Amok
.accept 91543 >>Accept Retaking Control
step
#completewith Final Echo
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r to pull them near you.
.complete 91543,2 
.mob Siphoid Drone
.mob Obscurion Broodlord
.mob Prowling Harrower
.mob Scavenging Harrower
step
#completewith Final Echo
>>Kill |cRXP_ENEMY_Voidbeings|r
*Loot them for |T3072269:0|t[|cRXP_LOOT_Latent Shadowgraft|r].
.complete 91963,1 
.mob Obscurion Subjugator
.mob Void-Yoked Shredclaw
.mob Slavering Ultradon
step
.goto 2405,62.44,82.47
#arrowtext Click on the\n|cRXP_PICK_First Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_First Echo|r.
.complete 91544,1 
step
.goto 2405,61.06,80.60
#arrowtext Click on the\n|cRXP_PICK_Second Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Second Echo|r.
.complete 91544,2 
step
.goto 2405,59.57,79.07
#arrowtext Click on the\n|cRXP_PICK_Third Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Third Echo|r.
.complete 91544,3 
step
.goto 2405,59.42,77.24
#arrowtext Click on the\n|cRXP_PICK_Fourth Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fourth Echo|r.
.complete 91544,4 
step
#label Final Echo
.goto 2405,58.49,78.30
#arrowtext Click on the\n|cRXP_PICK_Final Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Final Echo|r.
.complete 91544,5 
step
#hidewindow
#completewith siphoids
#loop
.goto 2405,59.57,77.99,35,0
.goto 2405,59.27,75.46,35,0
.goto 2405,60.65,74.84,35,0
.goto 2405,61.77,74.61,35,0
.goto 2405,62.66,75.99,35,0
.goto 2405,61.13,79.25,35,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r to pull them near you.
.complete 91543,2 
.mob Siphoid Drone
.mob Obscurion Broodlord
.mob Prowling Harrower
.mob Scavenging Harrower
step
>>Kill |cRXP_ENEMY_Voidbeings|r
*Loot them for |T3072269:0|t[|cRXP_LOOT_Latent Shadowgraft|r].
.complete 91963,1 
.mob Obscurion Subjugator
.mob Void-Yoked Shredclaw
.mob Slavering Ultradon
step
#label siphoids
#arrowtext Click on\n|cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r to pull them near you.
.complete 91543,2 
.mob Siphoid Drone
.mob Obscurion Broodlord
.mob Prowling Harrower
.mob Scavenging Harrower
step
#label Familiar Energies
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,58.16,78.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r
.turnin 91544 >>Turn in Familiar Energies
.target Magister Umbric
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r |cRXP_WARN_next to you|r.
.turnin 91543 >>Turn in Retaking Control
.target Riftblade Astre
.turnin 91963 >>Turn in Running Amok
.accept 91545 >>Accept Stronger Than Before
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,58.16,78.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r
.complete 91545,1 
.skipgossipid 135182
step
#label Notatus
.goto 2405,57.18,78.73
>>Kill |cRXP_ENEMY_Notatus the Riftscarred|r
.complete 91545,2 
.mob Notatus the Riftscarred
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,52.13,69.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91545 >>Turn in Stronger Than Before
.target Riftblade Astre
.accept 91546 >>Accept To Be Changed
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Umbric|r
.goto 2405,52.18,69.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umbric|r
.complete 91546,1 
.skipgossipid 135195
.target Umbric
step
#completewith next
#label Talk to Astre
#hidewindow
.complete 91546,2 
.target Astre
step
#completewith Talk to Astre
.goto 2405,51.57,70.29
#arrowtext Click on the Portal
.zone 2393 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Silvermoon|r
step
#requires Talk to Astre
.goto 2393,32.33,87.29
#title |cFFFCDC00Follow the Arrow|r
.complete 91546,2 
.skipgossipid 135198
.target Astre
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Astre|r
.goto 2393,32.33,87.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astre|r
.complete 91546,3 
.skipgossipid 135198
.target Astre
step
.goto 2393,31.62,88.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91546 >>Turn in To Be Changed
.target Riftblade Astre
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Dance with the Devil
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.accept 90914 >>Accept A Born Killer
.target Decimus
step
#loop
.goto 2405,54.12,70.98,30,0
.goto 2405,55.91,68.7,30,0
.goto 2405,54.35,67.67,30,0
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T5976941:0|t[|cRXP_LOOT_Void Essences|r].
.complete 90914,1 
.mob Mature Consumptor
.mob Drifting Stormray
.mob Carrion Consumptor
.mob Trench Shredclaw
.mob Ravenous Voidwalker
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90914 >>Turn in A Born Killer
.accept 90915 >>Accept Artifice of Aggression
.timer 9,RP
.target Decimus
step
#label DecimusY
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.30,68.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 90915,1 
.skipgossipid 134880
.target Decimus
step
.goto 2405,51.29,68.65
>>Follow the instructions from |cRXP_FRIENDLY_Decimus|r.
.complete 90915,2 
.skipgossipid 134880
step
.goto 2405,50.91,68.70
#arrowtext Click on the\n|cRXP_PICK_Light Shard|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Light Shard|r.
.complete 90915,3 
step
#label DecimusZ
.goto 2405,51.34,68.65
#arrowtext Click on the\n|cRXP_PICK_Half-Formed Blade|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Half-Formed Blade|r.
.complete 90915,4 
.timer 13,Roleplay Duration
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90915 >>Turn in Artifice of Aggression
.accept 90916 >>Accept Seek to Destroy
.target Decimus
step
#label Harvester of Savagery
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,61.27,61.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90916 >>Turn in Seek to Destroy
.accept 90917 >>Accept Harvester of Savagery
.accept 90918 >>Accept The Unforgiven
.target Decimus
step
#hidewindow
#completewith Nascent Blade
#loop
.goto 2405,64.88,59.96,20,0
.goto 2405,66.19,60.71,45,0
.goto 2405,64.69,63.30,45,0
.goto 2405,63.26,62.72,35,0
.goto 2405,61.34,64.74,35,0
.goto 2405,62.96,59.66,35,0
.goto 2405,65.98,60.17,55,0
.goto 2405,65.28,64.25,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Use the |T6994479:0|t[Nascent Blade] next to their corpses.
.complete 90917,1 
.mob Rampant Shredclaw
.mob Marauding Trigore
.mob Scouring Voidshaper
.mob Encroaching Consumptor
.use 248593
step
>>Kill |cRXP_ENEMY_Tenebre|r, |cRXP_ENEMY_Noxian|r and |cRXP_ENEMY_Averus|r.
.complete 90918,3 
.complete 90918,1 
.complete 90918,2 
.mob Tenebre
.mob Noxian
.mob Averus
step
#label Nascent Blade
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Use the |T6994479:0|t[Nascent Blade] next to their corpses.
.complete 90917,1 
.mob Rampant Shredclaw
.mob Marauding Trigore
.mob Scouring Voidshaper
.mob Encroaching Consumptor
.use 248693
step
#label The Fiend That Failed
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,61.27,61.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90918 >>Turn in The Unforgiven
.turnin 90917 >>Turn in Harvester of Savagery
.accept 90919 >>Accept The Fiend That Failed
.target Decimus
step
#completewith next
#label TheFiendThatFailedA
.goto 2405,63.50,59.20,10,0
>>Kill |cRXP_ENEMY_Vortensiun|r.
.complete 90919,1 
.mob Vortensiun
step
.isOnQuest 90919
#completewith TheFiendThatFailedA
#title Enter the cave
.goto 2405,63.37,58.50,50 >>|cRXP_WARN_Enter the cave|r.
step
#requires TheFiendThatFailedA
.goto 2405,63.37,58.50
>>Kill |cRXP_ENEMY_Vortensiun|r.
.complete 90919,1 
.mob Vortensiun
step
#completewith next
#label TheFiendThatFailedB
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90919 >>Turn in The Fiend That Failed
.accept 90920 >>Accept Warmth for the Soul
.target Decimus
step
.isOnQuest 90919
#completewith TheFiendThatFailedB
#title Leave the cave
.goto 2405,63.47,59.35,10 >>|cRXP_WARN_Leave the cave|r.
step
#requires TheFiendThatFailedB
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,59.07,56.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90919 >>Turn in The Fiend That Failed
.accept 90920 >>Accept Warmth for the Soul
.target Decimus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,59.07,56.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 90920,1 
.target Decimus
.skipgossipid 135125
.skipgossipid 135135
.skipgossipid 135130
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,59.07,56.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90920 >>Turn in Warmth for the Soul
.accept 90923 >>Accept Shepherd of Fear
.target Decimus
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Essence Fonts|r for an Orb Rush; Jump to get Orbs in the air.
.complete 90923,1 
.mob Shadestep Kilivore
.mob Thrashing Consumptor
.mob Sulking Ultradon
.mob Glowering Siphoid
.mob Crawling Blistercreep
.mob Wallowing Harrower
.mob Vengeful Shade
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lingering Shade|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lingering Shade|r |cRXP_WARN_next to you|r.
.accept 90922 >>Accept The Fallen Wake
.target Lingering Shade
step
#hidewindow
#completewith Gnawing Reach
#loop
.goto 2405,58.89,57.3,15,0
.goto 2405,57.55,58.24,40,0
.goto 2405,57.85,54.79,15,0
.goto 2405,57.92,54.19,15,0
.goto 2405,58.19,53.22,20,0
.goto 2405,58,50.48,15,0
.goto 2405,58.43,48.93,20,0
.goto 2405,58.46,48.13,15,0
.goto 2405,57.4,46.74,20,0
.goto 2405,56.12,44.97,20,0
+1
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Familiar Shade|r.
.complete 90922,1 
.target Familiar Shade
step
#arrowtext |cFFFCDC00Collect Orbs|r\nClick on\n|cRXP_PICK_Essence Fonts|r
>>|TInterface/cursor/crosshair/interact.blp:15|tClick on |cRXP_PICK_Essence Fonts|r for an Orb Rush; Jump to get Orbs in the air.
.complete 90923,1 
.mob Shadestep Kilivore
.mob Thrashing Consumptor
.mob Sulking Ultradon
.mob Glowering Siphoid
.mob Crawling Blistercreep
.mob Wallowing Harrower
.mob Vengeful Shade
step
#label Gnawing Reach
#arrowtext Click on the\n|cRXP_PICK_Familiar Shade|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Familiar Shade|r.
.complete 90922,1 
.target Familiar Shade
step
.goto 2405,50.47,45.45
#arrowtext Click on the\n|cRXP_PICK_Glowering Shade|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Glowering Shade|r.
.complete 90922,2 
.target Familiar Shade
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,47.28,49.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 90923,3 
.target Decimus
.skipgossipid 136300
step
#label The Fallen Wake
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,47.28,49.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90923 >>Turn in Shepherd of Fear
.turnin 90922 >>Turn in The Fallen Wake
.accept 90924 >>Accept The Wicked End
.target Decimus
step
#completewith next
#label TheWickedEndA
#hidewindow
.goto 2405,46.39,49.51,10,0
.complete 90924,1 
step
.isOnQuest 90924
#completewith TheWickedEndA
#title Enter the cave
.goto 2405,46.06,50.00,50 >>|cRXP_WARN_Enter the cave|r.
step
#requires TheWickedEndA
#title |cFFFCDC00Follow the Arrow|r
.goto 2405,46.06,50.00
.complete 90924,1 
step
#label DecimusKill
.goto 2405,46.06,50.00
>>Kill |cRXP_ENEMY_Decimus|r.
.complete 90924,2 
.mob Decimus
step
#completewith next
#label TheWickedEndB
#hidewindow
.complete 90924,3 
step
.isOnQuest 90924
#completewith TheWickedEndB
#title Leave the cave
.goto 2405,46.49,49.45,10 >>|cRXP_WARN_Leave the cave|r.
step
#requires TheWickedEndB
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 90924,3 
.skipgossipid 136325
.target Decimus
step
#label The Wicked End
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90924 >>Turn in The Wicked End
.target Decimus
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A Domanaar's Best Friend
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ravenia|r
.goto 2405,52.06,67.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravenia|r.
.accept 91363 >>Accept Harvest of Darkness
.target Ravenia
step
#hidewindow
#completewith Void-Infused Morsel
#loop
.goto 2405,53.89,71.15,10,0
.goto 2405,54.25,70.67,10,0
.goto 2405,54.86,68.87,10,0
.goto 2405,55.05,67.65,10,0
.goto 2405,55.83,68.25,10,0
.goto 2405,55.88,69.34,10,0
.goto 2405,55.26,70.51,30,0
.goto 2405,54.61,71.65,30,0
.goto 2405,54.07,72.23,30,0
.goto 2405,53.3,72.11,30,0
.goto 2405,53.81,74.19,30,0
.goto 2405,54.34,67.87,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for |T237353:0|t[|cRXP_LOOT_Void-Infused Morsel|r].
.complete 91363,1 
.mob Mature Consumptor
.mob Larval Consumptor
.mob Drifting Stormray
.mob Infused Klaxid
step
#arrowtext Click on the\n|cRXP_PICK_Radiant Glowcap|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Radiant Glowcap|r.
.complete 91363,2 
step
#label Void-Infused Morsel
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for |T237353:0|t[|cRXP_LOOT_Void-Infused Morsel|r].
.complete 91363,1 
.mob Mature Consumptor
.mob Larval Consumptor
.mob Drifting Stormray
.mob Infused Klaxid
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ravenia|r
.goto 2405,52.06,67.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravenia|r.
.turnin 91363 >>Turn in Harvest of Darkness
.accept 91380 >>Accept Belly of the Beast
.target Ravenia
step
#label Harvest of Darkness1
.goto 2405,51.21,67.64
#arrowtext Click on the\n|cRXP_PICK_Uncooked Void Meat|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Uncooked Void Meat|r.
.complete 91380,1 
step
.goto 2405,51.15,67.74
#arrowtext Click on the\n|cRXP_PICK_Unprepared Glowcaps|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Unprepared Glowcaps|r.
.complete 91380,2 
step
#label Harvest of Darkness2
#arrowtext Talk to\n|cRXP_FRIENDLY_Fidoficus|r
.goto 2405,51.19,67.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fidoficus|r.
.complete 91380,3 
.target Fidoficus
.skipgossipid 134827
step
#label overprey1
#title Use the ExtraActionButton
.goto 2405,51.67,68.94
>>Stand within the circle and use the |T6012075:0|t[|cRXP_WARN_ExtraActionButton|r].
.complete 91380,4 
step
#title Use the ExtraActionButton
.goto 2405,52.43,69.45
>>Stand within the circle and use the |T6012075:0|t[|cRXP_WARN_ExtraActionButton|r].
.complete 91380,5 
step
#title Use the ExtraActionButton
.goto 2405,53.47,70.44
>>Stand within the circle and use the |T6012075:0|t[|cRXP_WARN_ExtraActionButton|r].
.complete 91380,6 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ravenia|r
.goto 2405,52.06,67.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravenia|r.
.turnin 91380 >>Turn in Belly of the Beast
.accept 91382 >>Accept Mighty and Superior
.target Ravenia
step
#completewith next
#label MightyAndSuperiorA
#hidewindow
.complete 91382,1 
step
.isOnQuest 91382
#completewith MightyAndSuperiorA
#title Enter the cave
.goto 2405,48.02,75.74,6 >>|cRXP_WARN_Enter the cave.|r
step
#requires MightyAndSuperiorA
.goto 2405,47.96,74.91
#title |cFFFCDC00Follow the Arrow|r
.complete 91382,1 
step
.goto 2405,47.96,74.91
>>Kill |cRXP_ENEMY_Den-Gorger Zitoc|r.
.complete 91382,2 
.mob Den-Gorger Zitoc
step
#completewith next
#label MightyAndSuperiorB
#hidewindow
.complete 91382,3 
step
.isOnQuest 91382
#completewith MightyAndSuperiorB
#title Leave the cave
.goto 2405,48.08,75.78,8 >>|cRXP_WARN_Leave the cave.|r
step
#requires MightyAndSuperiorB
#completewith next
#label Ravenia
#arrowtext Talk to\n|cRXP_FRIENDLY_Ravenia|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravenia|r.
.complete 91382,3 
.target Ravenia
step
#requires MightyAndSuperiorB
#label RaveniaTalk
#completewith Ravenia
.goto 2405,52.06,67.43
.gossipoption 134864 >>Talk to |cRXP_FRIENDLY_Ravenia|r.
.skipgossipid 134863
.timer 20,RP
.target Ravenia
step
#requires Ravenia
#label MightyZ
.goto 2405,52.06,67.43
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 91382,3 
step
#label Mighty
#arrowtext Talk to\n|cRXP_FRIENDLY_Ravenia|r
.goto 2405,52.06,67.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravenia|r.
.turnin 91382 >>Turn in Mighty and Superior
.target Ravenia
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) A More Potent Foe
#internal
step
.xp 90 >>Skip this for now, come back once you hit level 90.
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2405,53.23,70.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.accept 92505 >>Accept Truth of the Past
.timer 9,Portal Spawn
.target Leona Darkstrider
step
#label IllidariGateway
.goto 2405,53.18,70.45
#arrowtext Click on the\n|cRXP_PICK_Portal to Argus|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Argus|r.
.complete 92505,1 
step
.goto 882,53.21,13.48
>>Enter Argus
.complete 92505,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Allari the Souleater|r
.goto 882,52.87,14.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Allari the Souleater|r.
.turnin 92505 >>Turn in Truth of the Past
.accept 92506 >>Accept The Soul Price
.target Allari the Souleater
step
#loop
.goto 882,51.93,23.29,35,0
.goto 882,47.27,21.91,35,0
.goto 882,47.93,13.61,35,0
>>Kill |cRXP_ENEMY_Spirits|r.
.complete 92506,1 
.mob Forsaken Denizen
.mob Agitated Citizen
.mob Restless Novitiate
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Allari the Souleater|r
.goto 882,52.87,14.19,-1
.goto 2405,53.22,70.39,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Allari the Souleater|r.
.turnin 92506 >>Turn in The Soul Price
.accept 92507 >>Accept A More Potent Foe
.timer 20,Vision Duration
.target Allari the Souleater
step
#title |cFFFCDC00Don't use portal yet|r
.goto 882,53.25,13.41
>>|cRXP_WARN_Wait for the Roleplay at waypoint location|r.
.complete 92507,1 
step
.goto 882,53.25,13.41
#arrowtext Click on the\n|cRXP_PICK_Portal to Voidstorm|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Voidstorm|r.
.complete 92507,2 
step
.isOnQuest 92507
.goto 2405,53.19,70.47
#arrowtext Click on the\n|cRXP_PICK_Portal to Argus|r
.zone 882 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Argus|r
step
.isOnQuest 92507
.goto 882,53.25,13.41
#arrowtext Click on the\n|cRXP_PICK_Portal to Voidstorm|r
.zone 2405 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Voidstorm|r
step
#label Argus
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2405,53.23,70.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.turnin 92507 >>Turn in A More Potent Foe
.target Leona Darkstrider
step
#label Mark of Sacrifice
#arrowtext Talk to\n|cRXP_FRIENDLY_Allari the Souleater|r
.goto 2405,53.22,70.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Allari the Souleater|r.
.accept 92508 >>Accept The Mark of Sacrifice
.accept 92509 >>Accept One Cruel Implement
.target Allari the Souleater
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2405,31.18,52.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.complete 92508,1 
.skipgossipid 137244
.target Leona Darkstrider
step
#completewith OneCruelImplementA
#hidewindow
#loop
.goto 2405,29.25,49.44,35,0
.goto 2405,26.80,53.89,35,0
.goto 2405,30.49,54.61,35,0
.goto 2405,30.69,52.43,35,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Towering Ultradons|r.
*Loot them for the |T1508520:0|t[|cRXP_LOOT_Talon of the Towering Ultradon|r].
.complete 92509,2 
.mob Towering Ultradon
step
#title Use the ExtraActionButton
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Use the |T6011928:0|t[|cRXP_WARN_ExtraActionButton|r] next to their corpses.
.complete 92508,2 
.mob Clawing Voidwalker
.mob Whipwind Shredclaw
.mob Duskcry Voidwalker
.mob Hovering Siphoid
step
#label OneCruelImplementA
>>Kill |cRXP_ENEMY_Towering Ultradons|r.
*Loot them for the |T1508520:0|t[|cRXP_LOOT_Talon of the Towering Ultradon|r].
.complete 92509,2 
.mob Towering Ultradon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Allari the Souleater|r
.goto 2405,53.22,70.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Allari the Souleater|r.
.turnin 92508 >>Turn in The Mark of Sacrifice
.turnin 92509 >>Turn in One Cruel Implement
.accept 92510 >>Accept Dark Infusion
.target Allari the Souleater
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2405,60.20,44.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.complete 92510,1 
.target Leona Darkstrider
.skipgossipid 136449
step
#loop
.goto 2405,60.27,43.86,5,0
.goto 2405,60.29,44.17,5,0
.goto 2405,60.13,44.25,5,0
>>Kill the incoming |cRXP_ENEMY_Voidbeings|r
.complete 92510,2 
.timer 2,Portal Spawn
.mob Rabid Consumptor
.mob Wallowing Harrower
.mob Furion
step
.goto 2405,60.24,44.03
#arrowtext Click on the\n|cRXP_PICK_Void Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Portal|r.
.complete 92510,3 
step
.goto 2405,52.17,69.69
#title |cFFFCDC00Follow the Arrow|r
.complete 92510,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,52.17,69.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 92510 >>Turn in Dark Infusion
.accept 92511 >>Accept Event Horizon
.target Magister Umbric
step
#loop
.goto 2405,52.12,73.34,10,0
.goto 2405,53.87,69.70,10,0
.goto 2405,51.87,67.38,10,0
#arrowtext Click on the\n|cRXP_PICK_Beacons|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Beacons|r.
.complete 92511,3 
.complete 92511,2 
.complete 92511,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,52.17,69.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.complete 92511,4 
.target Magister Umbric
.skipgossipid 136686
step
.goto 2405,51.37,62.98
>>Fly outside the Ritual’s area to immediately complete the objective instead.
.complete 92511,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2405,52.12,69.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.turnin 92511 >>Turn in Event Horizon
.accept 92512 >>Accept Devourer
.target Leona Darkstrider
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Leona Darkstrider|r
.goto 2405,51.07,56.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.complete 92512,1 
.timer 14,RP
.target Leona Darkstrider
.skipgossipid 136784
step
.goto 2405,51.55,55.76
>>Defeat |cRXP_ENEMY_Ravenor|r
.complete 92512,2 
.mob Ravenor
step
.goto 2405,52.17,69.69
#title |cFFFCDC00Follow the Arrow|r
.complete 92512,3 
step
#label Devourer
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,52.17,69.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 92512 >>Turn in Devourer
.target Magister Umbric
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Old Soldiers
#internal
step
#optional
.isQuestTurnedIn account,91787
+|cRXP_WARN_You have to do the previous chapter first|r
.clicknext RestedXP Midnight\a) Regrets of the Past (A) >>CLICK HERE FOR GUIDE << Alliance
.clicknext RestedXP Midnight\a) Regrets of the Past (H) >>CLICK HERE FOR GUIDE << Horde
step
.zone 2541 >>Use |T7322718:0|t[Personal Key to Arcantina]
.use 253629
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gorgonna|r
.goto 2541,68.26,58.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorgonna|r
.accept 92325 >>Accept Hellscream's Heritage
.target Gorgonna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Danath Trollbane|r
.goto 2541,46.50,57.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danath Trollbane|r
.accept 92319 >>Accept A Favor to Axe
.target Danath Trollbane
step
.goto 2541,37.67,53.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.accept 92321 >>Accept A Frostbitten Tally
.target Gidwin Goldbraids
step
.goto 2541,58.97,78.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marius Felbane|r.
.accept 92320 >>Accept Still Behind Enemy Portals
.target Marius Felbane
step
.goto 2541,30.03,19.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r.
.accept 92322 >>Accept Timear Foresees a Proof of Demise!
.target Archmage Lan'dalock
step
.goto 2541,26.71,16.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to the Isle of Thunder|r
.complete 92322,1 
step
.goto 504,63.72,32.28
>>Enter Throne of Thunder, kill the first boss and pickup the |cRXP_PICK_scroll|r on the way to the second.
.complete 92322,2 
step
>>Kill the third boss in Thorne of Thunder.
*Loot them for |T134377:0|t[|cRXP_LOOT_Lan'dalock's Pocket Watch|r].
.complete 92322,3 
step
#completewith next
#label Timear
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r.
.turnin 92322 >>Turn in Timear Foresees a Proof of Demise!
.target Archmage Lan'dalock
step
#completewith Timear
.zone 2541 >>Use |T7322718:0|t[Personal Key to Arcantina].
.use 253629
.cooldown item,253629,>0,1
step
#requires Timear
.goto 2541,29.96,19.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r.
.turnin 92322 >>Turn in Timear Foresees a Proof of Demise!
.target Archmage Lan'dalock
step
.isOnQuest 92319
.goto 2541,46.37,54.68
#arrowtext Click on the\n|cRXP_PICK_Portal to Hellfire Peninsula|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Hellfire Peninsula|r
.complete 92319,1 
step
.isOnQuest 92319
#loop
.goto 100,60,48.78,30,0
.goto 100,60.23,50.44,30,0
.goto 100,55.06,51.11,30,0
.goto 100,54.66,49.1,30,0
.goto 100,50.5,49.17,30,0
.goto 100,49.02,50.91,30,0
.goto 100,50.37,53.24,30,0
.goto 100,53.11,52.03,30,0
#arrowtext Click on the\n|cRXP_PICK_Axes|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axes|r
*Kill |cRXP_ENEMY_Orcs|r
*Loot them for |T949872:0|t[|cRXP_LOOT_Rusty Axes|r].
.complete 92319,3 
step
#completewith next
#label A Favor to Axe
.isOnQuest 92319
#arrowtext Talk to\n|cRXP_FRIENDLY_Kurdran Wildhammer|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.turnin 92319 >>Turn in A Favor to Axe
.target Kurdran Wildhammer
step
#completewith A Favor to Axe
.zone 2541 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires A Favor to Axe
#arrowtext Talk to\n|cRXP_FRIENDLY_Kurdran Wildhammer|r
.isOnQuest 92319
.goto 2541,46.84,58.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurdran Wildhammer|r.
.turnin 92319 >>Turn in A Favor to Axe
.target Kurdran Wildhammer
step
.goto 2541,40.23,51.43
.isOnQuest 92321
#arrowtext Click on the\n|cRXP_PICK_Portal to Icecrown|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Icecrown|r
.complete 92321,1 
step
.goto 118,53.87,87.26
.isOnQuest 92321
#arrowtext Click on the\n|cRXP_PICK_Tabards|r
>>Enter Icecrown Citadel and click on the |cRXP_PICK_Tabards|r
*|cRXP_WARN_The arrow doesn't work in Icecrown Citadel|r
.complete 92321,3 
step
#completewith next
#label A Frostbitten Tally
.isOnQuest 92321
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.turnin 92321 >>Turn in A Frostbitten Tally
.target Gidwin Goldbraids
step
#completewith A Frostbitten Tally
.zone 2541 >>Use |T7322718:0|t[Personal Key to Arcantina].
.use 253629
.cooldown item,253629,>0,1
step
#requires A Frostbitten Tally
.isOnQuest 92321
.goto 2541,37.46,53.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.turnin 92321 >>Turn in A Frostbitten Tally
.target Gidwin Goldbraids
step
#completewith next
#label Hijacked Portal
#hidewindow
.complete 92320,1 
step
#completewith Hijacked Portal
.goto 2541,59.19,75.25
.zone 646 >>Click on the Portal
step
#requires Hijacked Portal
.goto 646,48.94,55.24
>>Walk into the portal
.complete 92320,1 
step
.goto 2558,39.05,71.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tehd|r.
.complete 92320,2 
.skipgossipid 47140
.target Tehd
step
#loop
.goto 2558,55.33,49.96,10,0
.goto 2557,37.95,35.09,10,0
.goto 2557,35.13,52.34,10,0
.goto 2557,36.17,70.72,10,0
.goto 2557,41.47,78.31,10,0
.goto 2557,46.24,56.93,10,0
.goto 2557,50.47,49.38,10,0
.goto 2557,46.05,45.19,10,0
.goto 2557,48.94,36.68,10,0
.goto 2557,57.05,43.02,10,0
.goto 2557,64.91,45.68,10,0
.goto 2557,63.97,31.81,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Treasure Chests|r
.complete 92320,4 
step
.goto 2557,59.85,28.03
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lantern|r
.complete 92320,3 
step
>>Use |T7322718:0|t[Personal Key to Arcantina]
.complete 92320,5 
.use 253629
step
.goto 2541,58.97,78.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marius Felbane|r.
.turnin 92320 >>Turn in Still Behind Enemy Portals
.target Marius Felbane
step
.goto 2541,76.06,39.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thisalee Crow|r.
.accept 92323 >>Accept Where the Fire Once Burned
.target Thisalee Crow
step
.goto 2541,75.17,41.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Firelands|r
.complete 92323,1 
step
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Lucifern|r inside Firelands
.complete 92323,3 
step
#completewith next
#label Fire Once Burned
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thisalee Crow|r.
.turnin 92323 >>Turn in Where the Fire Once Burned
.target Thisalee Crow
step
#completewith Fire Once Burned
.zone 2541 >>Use |T7322718:0|t[Personal Key to Arcantina].
.use 253629
.cooldown item,253629,>0,1
step
#requires Fire Once Burned
.goto 2541,76.20,39.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thisalee Crow|r.
.turnin 92323 >>Turn in Where the Fire Once Burned
.target Thisalee Crow
step
.goto 2541,68.17,58.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorgonna|r.
.accept 92325 >>Accept Hellscream's Heritage
.target Gorgonna
step
.goto 2541,70.29,61.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Nagrand|r
.complete 92325,1 
step
.goto 107,56.70,34.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greatmother Geyah|r.
.complete 92325,3 
.skipgossipid 137850
.target Greatmother Geyah
step
.goto 107,56.09,37.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Osrok the Immovable|r.
.complete 92325,4 
.skipgossipid 137853
.target Osrok the Immovable
step
.goto 107,56.03,37.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Armor|r
.complete 92325,5 
step
.goto 107,53.12,33.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Axe|r
.complete 92325,6 
step
.goto 107,53.89,33.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greatmother Geyah|r.
.complete 92325,7 
.skipgossipid 137921
.target Greatmother Geyah
step
#completewith next
#label Hellscream's Heritage
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorgonna|r.
.turnin 92325 >>Turn in Hellscream's Heritage
.target Gorgonna
step
#completewith Hellscream's Heritage
.zone 2541 >>Use |T7322718:0|t[Personal Key to Arcantina].
.use 253629
.cooldown item,253629,>0,1
step
#requires Hellscream's Heritage
.goto 2541,68.29,58.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorgonna|r.
.turnin 92325 >>Turn in Hellscream's Heritage
.target Gorgonna
step
.goto 2541,78.73,59.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelsey Steelspark|r.
.accept 92324 >>Accept Uncrowned's Cold Case
.target Kelsey Steelspark
step
.goto 2541,77.46,56.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Feralas|r
.complete 92324,1 
step
#loop
.goto 69,65.73,36.49,30,0
.goto 69,65.46,35.38,30,0
.goto 69,64.44,36.16,30,0
.goto 69,63.73,36.02,30,0
.goto 69,62.73,36.02,30,0
.goto 69,60.77,36.02,30,0
.goto 69,59.31,35.95,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Notes|r
.complete 92324,3 
step
#completewith next
#label Uncrowned's Cold Case
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelsey Steelspark|r.
.turnin 92324 >>Turn in Uncrowned's Cold Case
.target Kelsey Steelspark
step
#completewith Uncrowned's Cold Case
.zone 2541 >>Use |T7322718:0|t[Personal Key to Arcantina].
.use 253629
.cooldown item,253629,>0,1
step
#requires Uncrowned's Cold Case
.goto 2541,78.40,59.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelsey Steelspark|r.
.turnin 92324 >>Turn in Uncrowned's Cold Case
.target Kelsey Steelspark
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Legends Never Die & The Empty Cradle
#internal
step
#label LegendsNeverDieA
.goto 2413,54.19,53.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.accept 89268 >>Accept Lost Legends
.target Zur'ashar Kassameh
step
.goto 2413,54.47,53.10
#arrowtext Click on a\n|cRXP_PICK_Relic|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on a |cRXP_PICK_Relic|r.
*|cRXP_WARN_Note:|r If you can't select a Relic then you have to finish the "The Empty Cradle" questline on the character that you have started it.
.complete 89268,1 
step
.goto 2413,54.18,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 89268 >>Turn in Lost Legends
.target Zur'ashar Kassameh
step
#label LegendsNeverDieAA
.goto 2413,54.18,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.acceptmultiple 88997,88993,88994,88995,88996,88998 >>Accept Lost Legend Quest
.target Zur'ashar Kassameh

step
#label LegendsNeverDieB
.isOnQuest 88998
.goto 2413,44.27,38.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88998,1 
step
.isOnQuest 88998
.goto 2413,42.99,37.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Roots|r
step
.isOnQuest 91508,88998
.goto 2413,42.73,37.46
>>Use the |T5351059:0|t[ExtraActionButton]. Solve the puzzle.
.complete 91508,2 
step
.isOnQuest 91508,88998
#loop
.goto 2413,43.68,37.61,20,0
.goto 2413,43.78,37.84,20,0
.goto 2413,42.75,38.40,20,0
.goto 2413,43.08,39.49,20,0
.goto 2413,43.55,39.63,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lashers|r and |cRXP_PICK_Chloroceros|r.
*Run over the |cRXP_PICK_slimes|r.
.complete 91508,3 
.target Burning Lasher
.target Entangled Chloroceros
step
.isOnQuest 91508,88998
#completewith next
#hidewindow
#label RootwayToAzerothA
.complete 91508,4 
step
.isOnQuest 91508,88998
#completewith RootwayToAzerothA
#title Enter the cave
.goto 2413,43.09,36.77,10 >>Enter the cave.
step
.isOnQuest 91508,88998
#requires RootwayToAzerothA
#title Follow the arrow
.goto 2413,41.85,34.48,15,0
.goto 2413,42.40,34.70
.complete 91508,4 
step
.isOnQuest 91508,88998
.goto 2413,42.28,34.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Root of the World|r
.complete 91508,5 
.complete 88998,2 

step
.isOnQuest 88995
.goto 2413,54.66,65.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88995,1 
step
.isOnQuest 91492
#loop
.goto 2413,54.58,64.19,30,0
.goto 2413,53.66,65.01,30,0
.goto 2413,53.34,66.63,30,0
#arrowtext Click on the\n|cRXP_PICK_Wildlife|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wildlife|r

.scenario 15931,1
.target Rutaani Sapling
.target Auralight Moth
.target Whispering Petalwing
.target Rancidbloom Potatoad
step
.isOnQuest 91492
#completewith next
#label Resonance Stone
>>Use |T6238556:0|t[Harmonics] within the blue parts of the slider.
.complete 91492,2 
step
.isOnQuest 91492
#completewith Resonance Stone
.goto 2413,54.44,66.64
.cast 6477 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
step
.isOnQuest 91492
#requires Resonance Stone
.goto 2413,54.44,66.64
>>Use |T6238556:0|t[Harmonics] within the blue parts of the slider.
.complete 91492,2 
step
.isOnQuest 91492
#loop
.goto 2413,54.11,66.87,20,0
.goto 2413,54.77,67.01,20,0
.goto 2413,55.04,66.71,15,0
.goto 2413,55.72,66.77
>>Step in the spotlights
.complete 91492,3 
step
.isOnQuest 88995
.goto 2413,55.79,66.96
#arrowtext Click on the\n|cRXP_PICK_Flower|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flower|r

.scenario 15934,1
step
.isOnQuest 88995
.goto 2413,54.66,65.09
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88995,1 
.accept 91492 >>Accept The Tale of Aln'hara's Bloom

step
.isOnQuest 88996
.goto 2413,64.64,38.64
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88996,1 
.accept 91506 >>Accept Tale of the First Shul'ka and the Flame
step
.isOnQuest 91506
#completewith next
#label The Echoless Flame
#hidewindow
.complete 91506,1 
step
.isOnQuest 91506
#completewith The Echoless Flame
#arrowtext Enter Cave \n Can't skyride here
.goto 2413,61.5,38.27,20 >>Enter the Cave
step
.isOnQuest 91506
#requires The Echoless Flame
.goto 2413,62.07,35.83
#title |cFFFCDC00Follow the Arrow|r
.complete 91506,1 
step
.isOnQuest 91506
.goto 2413,62.20,35.71
#arrowtext Click on the\n|cRXP_PICK_Echoless Flame|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Echoless Flame|r and use |T6238556:0|t[Harmonics] within the blue parts of the slider.
.complete 91506,2 
step
.isOnQuest 91506
#loop
.goto 2413,61.55,35.29,30,0
.goto 2413,61.22,37.04,30,0
.goto 2413,61.49,38.34,30,0
.goto 2413,62.18,38.56,30,0
>>Kill |cRXP_ENEMY_Rift Manifestations|r
.complete 91506,3,100 
.mob Decaying Essence
.mob Aln Oozeling
.mob Rift Shade
step
.isOnQuest 91506
#loop
.goto 2413,62.09,38.6,30,0
.goto 2413,63.45,38.18,30,0
.goto 2413,62.86,37.08,30,0
#arrowtext Click on the\n|cRXP_PICK_Wards|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wards|r
.complete 91506,4 
.timer 10,RP
step
.isOnQuest 91506
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 91506,5 
.complete 88996,2 

step
.isOnQuest 88994
.goto 2413,61.64,20.59
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88994,1 
.accept 90889 >>Accept Tale of the Echoes of Sai'alyo
step
.isOnQuest 90889
#loop
.goto 2413,62.02,19.68,30,0
.goto 2413,61.3,18.03,30,0
.goto 2413,60.13,21.22,30,0
>>Kill |cRXP_ENEMY_Alnscorned Essence|r
*Loot them for |T1778228:0|t[|cRXP_LOOT_Alndust|r].
.complete 90889,1 
.mob Alnscorned Essence
step
.isOnQuest 90889
#completewith next
#label Paintings
.goto 2413,60.23,18.85,20,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r then move the brush through each dot.
.complete 90889,2 
step
.isOnQuest 90889
#completewith Paintings
.goto 2413,59.76,18.40,45 >>Enter the Cave
step
.isOnQuest 90889
#requires Paintings
.goto 2413,59.76,18.40
#arrowtext Click on the\n|cRXP_PICK_Cauldron|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r then move the brush through each dot.
.complete 90889,2 
step
.isOnQuest 90889
.goto 2413,60.62,16.56
>>Kill and run over |cRXP_ENEMY_Animated Paint|r
.complete 90889,3 
.mob Animated Paint
step
.isOnQuest 88994
#loop
.goto 2413,61.43,16.48,15,0
.goto 2413,61.4,16.19,15,0
.goto 2413,61.23,16.04,15,0
.goto 2413,61.05,16.09,15,0
>>Use the |T538559:0|t|cRXP_WARN_[ExtraActionButton]|r on the paint then bring the paint to the cauldron.
.complete 88994,2 

step
.isOnQuest 88993
#completewith next
#label WeynansWardA
.goto 2413,54.24,52.24,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88993,1 
.accept 90536 >>Accept The Tale of Wey'nan's Ward
.disablecheckbox
step
.isOnQuest 88993
#completewith WeynansWardA
.goto 2413,44.28,38.28,1035 >>Leave the building
step
.isOnQuest 88993
#requires WeynansWardA
.goto 2413,44.28,38.28
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88993,1 
.accept 90536 >>Accept The Tale of Wey'nan's Ward
step
.isOnQuest 90536
#loop
.goto 2413,43.03,39.04,30,0
.goto 2413,42.9,37.96,30,0
.goto 2413,43.65,37.77,30,0
>>Kill |cRXP_ENEMY_Zaratti Fanatic|r and |cRXP_ENEMY_Zaratti Bloombinder|r.
.complete 90536,1 
.mob Zaratti Fanatic
.mob Zaratti Bloombinder
step
.isOnQuest 90536
.goto 2413,43.03,36.6,15,0
.goto 2413,41.27,35.39
#arrowtext |cFFFCDC00Follow the Arrow|r\nClick on the\n|cRXP_PICK_Sword|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sword|r
.complete 90536,2 
step
.isOnQuest 90536
.goto 2413,41.36,34.94
#arrowtext Click on the\n|cRXP_PICK_Mushroom|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushroom|r
.complete 90536,3 
step
.isOnQuest 90536
.goto 2413,41.32,35.25
#arrowtext Click on the\n|cRXP_PICK_Wey'nan|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wey'nan|r
.complete 90536,4 
.target Wey'nan
step
.isOnQuest 90536
.goto 2413,41.3,35.22
#arrowtext Click on the\n|cRXP_PICK_Zarat|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Zarat|r
.complete 90536,5 
.target Zarat
step
.isOnQuest 88993
#completewith next
#label Wey'nan's Ward
#hidewindow
.complete 88993,2 
step
.isOnQuest 88993
#completewith Wey'nan's Ward
.goto 2413,42.11,36.11,15,0
.goto 2413,42.44,35.26
.cast 298624 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wey'nan's Ward|r
step
.isOnQuest 88993
#requires Wey'nan's Ward
>>Use |T5088833:0|t[Left], |T3566827:0|t[Middle] and |T134379:0|t[Right] to balance all sliders into the green
.complete 88993,2 

step
.isOnQuest 88997
#completewith next
#label Ancient Visionstone
.goto 2413,54.31,52.29,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88997,1 
.accept 91507 >>Accept The Tale of Russula
.disablecheckbox
step
.isOnQuest 88997
#completewith Ancient Visionstone
.goto 2413,64.64,38.65,1044 >>Leave the building
step
.isOnQuest 88997
#requires Ancient Visionstone
.goto 2413,64.64,38.65
#arrowtext Click on the\n|cRXP_PICK_Stone|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stone|r
.complete 88997,1 
.accept 91507 >>Accept The Tale of Russula
step
.isOnQuest 91507

#loop
.goto 2413,63.89,39.01,30,0
.goto 2413,63.41,38.69,30,0
.goto 2413,64.29,37.92,30,0
.goto 2413,63.96,37.32,30,0
.goto 2413,63.78,36.41,30,0
>>Kill |cRXP_ENEMY_Combatants|r.
.complete 91507,1 
.mob Rutaani Skirmisher
.mob Fungarian Brawler
step
.isOnQuest 91507
#loop
.goto 2413,63.5,37.44,25,0
.goto 2413,62.39,39.55,25,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Roonek|r and |cRXP_FRIENDLY_Pustulehelm|r.
.complete 91507,2 
.skipgossipid 135518
.skipgossipid 135517
.target Roonek
.target Pustulehelm
step
.isOnQuest 91507
.goto 2413,62.34,38.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Russula|r.
.complete 91507,3 
.skipgossipid 135556
.target Russula
step
.isOnQuest 91507
#loop
.goto 2413,61.48,38.96,25,0
.goto 2413,61.25,38.01,25,0
.goto 2413,60.89,37.75,25,0
.goto 2413,61.16,37.08,25,0
.goto 2413,61.43,37.01,25,0
#arrowtext Click on the\n|cRXP_PICK_Soil|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Soil|r
.complete 91507,4 
.target Rich Soil
step
#label LegendsNeverDieX
.isOnQuest 88997
#loop
.goto 2413,61.46,35.95,25,0
.goto 2413,61.84,35.88,25,0
.goto 2413,62.28,35.74,25,0
>>Use |T1500803:0|t[Subduing Blow] on |cRXP_ENEMY_Warbounds|r
.scenario 16026,1
.complete 88997,2 
.mob Warbound Rutaani
.mob Warbound Fungarian
step
#label LegendsNeverDieY
.isOnQuest 88997
.goto 2413,54.19,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 88997 >>Turn in Russula's Outreach
.target Zur'ashar Kassameh
step
.isOnQuest 88995
.goto 2413,54.18,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 88995 >>Turn in Aln'hara's Bloom
.target Zur'ashar Kassameh
step
.isOnQuest 88993
.goto 2413,54.19,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 88993 >>Turn in Wey'nan's Ward
.target Zur'ashar Kassameh
step
.isOnQuest 88994
.goto 2413,54.19,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 88994 >>Turn in The Cauldron of Echoes
.target Zur'ashar Kassameh
step
.isOnQuest 88996
.goto 2413,54.17,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 88996 >>Turn in The Echoless Flame
.target Zur'ashar Kassameh
step
#label LegendsNeverDieZ
.isOnQuest 88998
.goto 2413,54.18,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 88998 >>Turn in Root of the World
.target Zur'ashar Kassameh

step
#label TheEmptyCradleA
.goto 2413,54.19,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.accept 90733 >>Accept The Listener
.target Zur'ashar Kassameh
step
.isOnQuest 90733
.goto 2413,53.39,49.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem|r.
.turnin 90733 >>Turn in The Listener
.target Aksem
step
.isQuestTurnedIn 90733
.goto 2413,54.19,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.accept 90734 >>Accept In the Name of the Goddess
.target Zur'ashar Kassameh
step
.isQuestTurnedIn 90733
.goto 2413,53.38,49.40
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tea|r
.complete 90734,1 
step
.isQuestTurnedIn 90733
.goto 2413,53.39,49.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem|r.
.turnin 90734 >>Turn in In the Name of the Goddess
.target Aksem
step
.goto 2413,54.18,53.13
.accept 90735 >>Accept The Stolen Staff
step
.goto 2413,53.39,49.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem|r.
.turnin 90735 >>Turn in The Stolen Staff
.target Aksem
step
.goto 2413,53.39,49.43
.accept 90738 >>Accept To the Blossoming Terrace
step
.goto 2413,58.82,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shul'ka Seila|r.
.turnin 90738 >>Turn in To the Blossoming Terrace
.target Shul'ka Seila
.accept 90736 >>Accept That's Not Yours
.accept 90737 >>Accept Nested Clues
step
#completewith Nest searched
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Nests|r
>>Kill |cRXP_ENEMY_Blossoms|r
*Loot them for |T1519429:0|t[|cRXP_LOOT_Stolen Belongings|r].
.complete 90736,1 
.mob Blossoming Creeper
.mob Blossoming Sap Weaver
.mob Blossom-Bound Thiever
step
.goto 2413,59.70,44.54
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nest|r |cRXP_WARN_on a platform above|r
.complete 90737,1 
step
.goto 2413,60.76,45.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nest|r
.complete 90737,2 
step
#label Nest searched
.goto 2413,61.92,44.89
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nest|r
.complete 90737,3 
step
#loop
.goto 2413,59.9,45.31,40,0
.goto 2413,59.03,47.33,40,0
.goto 2413,59,45.23,40,0
.goto 2413,59.23,43.72,40,0
.goto 2413,60.34,44.52,40,0
.goto 2413,62.29,44.28,40,0
.goto 2413,60.12,43.6,40,0
*|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Nests|r
>>Kill |cRXP_ENEMY_Blossoms|r
*Loot them for |T1519429:0|t[|cRXP_LOOT_Stolen Belongings|r].
.complete 90736,1 
.mob Blossoming Creeper
.mob Blossoming Sap Weaver
.mob Blossom-Bound Thiever
step
.goto 2413,58.82,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shul'ka Seila|r.
.turnin 90736 >>Turn in That's Not Yours
.turnin 90737 >>Turn in Nested Clues
.accept 90739 >>Accept The Root of Things
.target Shul'ka Seila
step
.goto 2413,60.86,45.33
>>Fly into the Waterfall
.complete 90739,1 
step
#completewith next
#label Seila confronted
>>Defeat |cRXP_ENEMY_Shul'ka Seila|r
.complete 90739,2 
step
#completewith Seila confronted
.goto 2413,60.86,45.33
.gossipoption 134376 >>Talk to |cRXP_FRIENDLY_Shul'ka Seila|r
.target Shul'ka Seila
step
#requires Seila confronted
.goto 2413,60.86,45.33
>>Defeat |cRXP_ENEMY_Shul'ka Seila|r
.complete 90739,2 
step
.goto 2413,60.84,45.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Staff|r
.complete 90739,3 
step
.goto 2413,53.39,49.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem|r.
.turnin 90739 >>Turn in The Root of Things
.target Aksem
.accept 90740 >>Accept A Legend to Know
step
#label TheEmptyCradleZ
.goto 2413,54.19,53.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r.
.turnin 90740 >>Turn in A Legend to Know
.accept 90741 >>Accept Once More Into the Rift
.target Zur'ashar Kassameh
step
.goto 2413,53.39,49.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem|r.
.complete 90741,1 
.target Aksem
.skipgossipid 134391
step
.goto 2413,61.74,62.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 90741 >>Turn in Once More Into the Rift
.accept 90742 >>Accept Shrouded by Aln'hara
.target Orweyna
step
.goto 2413,61.72,62.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shul'ka Seila|r.
.accept 90743 >>Accept Ritual Reinforcement
.target Shul'ka Seila
step
.goto 2413,62.44,62.67
>>Use the |T132852:0|t[ExtraActionButton].
.complete 90742,1 
step
#arrowtext Click on |cRXP_PICK_Offering|r\nOfferings made (1/3)\n|cRXP_WARN_(Hardcoded Waypoint)|r
.goto 2413,62.90,60.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Offsering|r.
.complete 90743,1,1 
step
#arrowtext Click on |cRXP_PICK_Offering|r\nOfferings made (2/3)\n|cRXP_WARN_(Hardcoded Waypoint)|r
.goto 2413,62.12,58.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Offsering|r.
.complete 90743,1,2 
step
#arrowtext Click on |cRXP_PICK_Offering|r\nOfferings made (2/3)\n|cRXP_WARN_(Hardcoded Waypoint)|r
.goto 2413,65.81,63.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Offsering|r.
.complete 90743,1 
step
#loop
.goto 2413,62.01,59.45,35,0
.goto 2413,63.85,58.06,35,0
.goto 2413,66.00,62.80,35,0
>>Kill the |cRXP_ENEMY_Rift forces|r.
.complete 90742,2 
.mob Decaying Essence
.mob Rift Shade
step
.goto 2413,61.72,62.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shul'ka Seila|r.
.turnin 90743 >>Turn in Ritual Reinforcement
.target Shul'ka Seila
step
.goto 2413,61.74,62.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 90742 >>Turn in Shrouded by Aln'hara
.accept 90744 >>Accept The Dreamrift: Malformed Mystery
.target Orweyna
step
>>Enter the |cRXP_PICK_Dreamrift|r raid on any difficulty and kill |cRXP_ENEMY_Chimaerus|r.
.complete 90744,1 
.mob Chimaerus
step
.goto 2413,53.39,49.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem|r.
.turnin 90744 >>Turn in The Dreamrift: Malformed Mystery
.accept 90745 >>Accept The Empty Cradle
.target Aksem
step
.goto 2413,53.39,49.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem to learn the truth|r.
.complete 90745,1 
.target Aksem to learn the truth
.skipgossipid 134421
step
.goto 2413,53.39,49.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aksem|r.
.turnin 90745 >>Turn in The Empty Cradle
.target Aksem
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) World Quest Eversong Forest
#internal

step
.goto 2395,60.97,81.37
.complete 92139,1 
.complete 92139,2 
step
.goto 2395,60.94,83.07
.turnin 92139 >>Turn in *undefined*
step
.goto 2395,42.19,20.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 92138,1 
step
#loop
.goto 2395,42.41,20.1,30,0
.goto 2395,42.27,19.28,30,0
.goto 2395,41.72,18.64,30,0
.goto 2395,41.24,18.72,30,0
.goto 2395,40.69,20.04,30,0
>>Use |T135975:0|t[Recruitment Fliers] on |cRXP_FRIENDLY_Prospective Student|r
.target Prospective Student
step
#loop
.goto 2395,44.56,69.54,40,0
.goto 2395,43.92,70.34,40,0
.goto 2395,43.44,68.96,40,0
.goto 2395,42.17,68.58,40,0
>>Kill |cRXP_ENEMY_Twilight Cultists|r.
.complete 92153,1 
.mob Twilight Shadecaster
.mob Twilight Blade
step
#loop
.goto 2395,46.85,44.83,40,0
.goto 2395,47.6,46.38,40,0
.goto 2395,47.84,47.29,40,0
.goto 2395,45.25,47.37,40,0
.goto 2395,44.26,44.3,40,0
>>Kill |cRXP_ENEMY_Wyrms|r.
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 92150,1,100 
.mob Erratic Light Wyrm
.target Displaced Hawkstrider
.mob Displaced Lynx
step
.goto 2395,37.04,60.81
.complete 92143,1 
step
#loop
.goto 2395,45.04,54.52,40,0
.goto 2395,44.98,57.83,40,0
.goto 2395,43.02,58.24,40,0
.goto 2395,39.45,55.11,40,0
.goto 2395,39.74,53.27,40,0
.goto 2395,42.16,55.86,40,0
>>Kill |cRXP_ENEMY_Lightblooms|r
.complete 92152,1,100 
.mob Lightbloom Lasher
.mob Lightfed Growth
.mob Lightbloom Petalwing
.mob Lightbloom Hydra
.mob Light Wyrm
step
.goto 2395,39.46,45.07
#arrowtext Click on \n|cRXP_PICK_Emberstrike|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Emberstrike|r
.complete 92122,1 
.target Emberstrike
step
>>Use |T2065634:0|t[Bomb Toss] on |cRXP_ENEMY_Naga|r, |cRXP_ENEMY_Tide|r and |cRXP_PICK_Crates|r.
.complete 92122,2,100 
step
#loop
.goto 2395,44.21,82.88,30,0
.goto 2395,42.9,83.18,30,0
.goto 2395,41.93,85.07,30,0
.goto 2395,41.94,87.52,30,0
.goto 2395,43.99,88.1,30,0
#arrowtext Click on\n|cRXP_PICK_Objects|r
>>Kill |cRXP_ENEMY_Cultists|r and click on |cRXP_PICK_Objects|r
.complete 92149,1 
.complete 92149,2 
*|cRXP_WARN_Consider grouping up with the tool|r
.mob Twilight Bruiser
.mob Dark Caller
.mob Twilight Death-Dealer
.mob Darkness Evoker
step
#loop
.goto 2395,50.85,77.65,30,0
.goto 2395,50.62,75.81,30,0
.goto 2395,52.02,74.15,30,0
.goto 2395,52.7,75.19,30,0
.goto 2395,52.12,77.01,30,0
>>Kill |cRXP_ENEMY_Wyrms|r
#arrowtext Click on\n|cRXP_PICK_Wandering Leaftender|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Wandering Leaftender|r
.complete 92364,1 
.complete 92364,2
.mob Agitated Wyrm
.mob Wandering Leaftender
step
#loop
.goto 2395,54.14,62.49,40,0
.goto 2395,56.38,61.32,40,0
.goto 2395,56.38,59.43,40,0
.goto 2395,54.36,58.17,40,0
>>Kill |cRXP_ENEMY_Lightblooms|r
.complete 92146,1,100 
.mob Lightfrenzied Lasher
.mob Lightbloat Trampler
.mob Infused Seedling
.mob Bloom Propagator
.mob Bloom Dominator
step
.goto 2395,52.13,77.43
>>Kill |cRXP_ENEMY_Invading Wildlife|r.
.complete 92364,1 
.mob Invading Wildlife
step
.goto 2395,51.91,73.78
.complete 92364,2 

step
.goto 2395,53.88,62.01
.turnin 92146 >>Turn in *undefined*
step 
.goto 2393,36.21,56.10
.complete 92120,1 
step
.goto 2393,36.34,53.10
.complete 92120,2 
step
.goto 2393,33.95,57.99
.turnin 92120 >>Turn in *undefined*
step 
.goto 2393,32.49,68.19
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cataloger's Carpet|r
.complete 92105,1 
.target Cataloger's Carpet
step 
>>Use |T1109168:0|t[Catalog] to take pictures and |T133882:0|t[Reload Film] to reload.
.complete 92105,2,100
.target Cataloger's Carpet
step
.goto 2393,56.08,62.43
.turnin 92848 >>Turn in *undefined*
step -bad unless during CAMPAIGN MAYBE
.goto 2395,63.48,50.23
>>Kill |cRXP_ENEMY_Amani defectors|r.
.complete 92144,1 
.mob Amani defectors
step
.goto 2395,63.56,50.17
.complete 92144,2 
step 
.goto 2395,58.98,69.37
.complete 92121,1 
step
.goto 2395,58.98,69.37
.turnin 92121 >>Turn in WANTED: Gorebarb's Pincers
]])

RXPGuides.RegisterGuide([[222222222
#retail
#version 20
#group RestedXP Midnight
#name a) World Quest Zul'aman
#internal
step
.goto 2437,37.38,71.22
>>Kill |cRXP_ENEMY_Twilight's Blade|r.
.complete 91801,1 
.complete 91801,2 
.mob Twilight's Blade
step 
#loop
.goto 2437,29.98,27.64,35,0
.goto 2437,29.95,29.32,35,0
.goto 2437,31.15,28.38,35,0
.goto 2437,30.44,27.1,35,0
.goto 2437,29.24,30.8,40,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Equipment|r
.complete 91808,1 
step
.goto 2437,47.16,24.63
.turnin 91810 >>Turn in *undefined*
step
.goto 2437,47.16,24.63
.turnin 94866 >>Turn in *undefined*

step
.goto 2437,38.68,78.71
.complete 91798,1 
step
.goto 2437,38.68,78.71
.turnin 91798 >>Turn in *undefined*































































]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) World Quest Harandar
#internal

step
.goto 2413,53.71,59.78
.complete 91592,1 
step
.goto 2413,53.71,59.78
.turnin 91592 >>Turn in *undefined*

step
.goto 2413,57.92,51.94
.complete 91555,1 
step
.goto 2413,52.90,52.33
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Swift Grimlynx|r
.complete 92085,1 
.target Swift Grimlynx
step
#loop
.goto 2413,52.67,55.17,15,0
.goto 2413,53.54,55.72,15,0
.goto 2413,53.11,56.48,15,0
.goto 2413,52.04,56.27,15,0
.goto 2576,48.56,90.75,15,0
.goto 2413,51.55,55.99,15,0
.goto 2413,51.3,54.64,15,0
.goto 2413,50.72,54.16,15,0
.goto 2413,49.44,53.43,15,0
.goto 2413,50.04,51.9,15,0
.goto 2413,51.9,50.85,15,0
>>Run over |cRXP_ENEMY_Scurrying Vermin|r
.complete 92085,2 
.mob Scurrying Vermin
step
#loop
.goto 2413,33.01,84.66,30,0
.goto 2413,30.2,86.6,30,0
.goto 2413,32.08,87.35,30,0
.goto 2413,34.87,85.54,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nests|r
.complete 93046,1 
step
#loop
.goto 2413,41.51,34.16,30,0
.goto 2413,42.17,35.92,30,0
.goto 2413,43.08,33.55,30,0
.goto 2413,41.74,30.68,30,0
.goto 2413,40.88,27.59,30,0
>>Kill |cRXP_ENEMY_Wandering Stalker|r
*Loot them for |T5929743:0|t[|cRXP_LOOT_Verdant Stalker Sludge|r].
.complete 92582,1 
.mob Wandering Stalker
step
.goto 2413,42.56,33.71
>>Use the |T236153:0|t[ExtraActionButton] at waypoint location.
.complete 92582,2 
step
.goto 2413,36.36,46.34
.turnin 92162 >>Turn in Where Dust Dances
step 
.goto 2413,71.52,66.85
.complete 92583,1 
step

#arrowtext Click on |cRXP_PICK_Weary Defenders|r
#loop
.goto 2413,58.48,57.30,15,0
.goto 2413,57.78,56.90,15,0
.goto 2413,58.94,54.79,15,0
.goto 2413,59.44,53.94,15,0
.goto 2413,60.96,50.65,15,0
.goto 2413,60.37,50.68,15,0
.goto 2413,59.69,51.89,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Weary Defenders|r
.complete 91804,1 
.target Weary Defender
step

#arrowtext Click on |cRXP_PICK_Encroaching Bitterblooms|r
#loop
.goto 2413,35.60,60.18,45,0
.goto 2413,30.15,64.59,45,0
.goto 2413,32.57,69.09,45,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Encroaching Bitterblooms|r
.complete 92119,1 
step

#arrowtext Click on the\n|cRXP_PICK_Ancient Visionstone|r
.goto 2413,37.53,47.73
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ancient Visionstone|r
.complete 92162,1 
step

#arrowtext Use |T878213:0|t[Potadpounce] (1)
#loop
.goto 2413,37.31,47.75,35,0
.goto 2413,34.58,43.71,35,0
>>Use |T878213:0|t[Potadpounce] (1) and jump through |cRXP_ENEMY_Bugs|r
.complete 92162,2 
step

#loop
.goto 2413,54.72,32.36,45,0
.goto 2413,54.77,27.91,45,0
.goto 2413,57.00,28.45,45,0
.goto 2413,52.42,27.76,45,0
>>Kill the |cRXP_ENEMY_Lattice forces|r
.complete 91582,1 
.mob Lattice Mistcaller
.mob Lattice Crawler
.mob Lattice Thornguard
.mob Lattice Grovewarden
.mob Lattice Elder Root
.mob Lattice Sap Weaver
.mob Pilfering Petalwing
.mob Deenit
.mob Kazat
step
#loop
.goto 2413,67.51,41.36,25,0
.goto 2413,67.56,39.58,25,0
.goto 2413,68.86,38.19,25,0
.goto 2413,70.20,40.31,25,0
.goto 2413,68.41,39.88,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Frightened Potadpole|r.
*|cRXP_WARN_NOTE:|r Possible while mounted.
.complete 92184,1 
.target Frightened Potadpole
step
#loop
.goto 2413,45.73,64.24,35,0
.goto 2413,44.52,66.69,35,0
.goto 2413,44.70,69.67,35,0
.goto 2413,46.64,70.27,35,0
.goto 2413,46.52,64.64,35,0
>>Kill the |cRXP_ENEMY_Mushrooms|r.
.complete 93071,1 
.mob Decanimated Rotseeker
.mob Decanimated Rotling
.mob Decanimated Blightbringer
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) World Quest Voidstorm
#internal

step
.goto 2405,39.39,85.36
.complete 93244,1 
.complete 93244,5 
step
.goto 2405,38.87,86.57
.complete 93244,4 
step
.goto 2405,38.00,85.80
.complete 93244,3 
step
.goto 2405,38.55,84.55
.complete 93244,2 
step
.goto 2405,38.55,84.55
.turnin 93244 >>Turn in Harvesting the Void
step
.goto 2405,36.03,49.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Disc|r
.complete 93577,1 
step
>>Make pictures of Wildlife
.complete 93577,2 
step
.goto 2405,62.28,76.84

.complete 93397,1 
step
.goto 2405,61.11,79.05
.turnin 93397 >>Turn in *undefined*
step
.goto 2405,35.63,69.22
#arrowtext Click on the\n|cRXP_PICK_Wyrm|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wyrm|r
.complete 93438,1 
.target Esoti
step
>>Use |T249176:0|t[Shoot] on |cRXP_ENEMY_Voidbeings|r
.complete 93438,2 
step
>>Use |T249176:0|t[Shoot] on |cRXP_ENEMY_Voidbeings|r
.complete 93438,4 
.complete 93438,3 
step
>>Use |T249176:0|t[Shoot] on |cRXP_ENEMY_Voidbeings|r
.complete 93438,5 
.complete 93438,6 
step
#loop
.goto 2444,41.96,53.21,30,0
.goto 2444,40.44,49.76,30,0
.goto 2444,42.44,45.84,30,0
.goto 2444,44.8,48.68,30,0
>>Kill |cRXP_ENEMY_Enraged Bloodfeaster|r
.complete 88679,1,100
.mob Enraged Bloodfeaster
step
.goto 2444,53.69,28.45
>>Kill |cRXP_ENEMY_Rage-Riddled Drifter|r
.turnin 89347 >>Turn in *undefined*
.mob Rage-Riddled Drifter
step
#title |cFFFCDC00Follow the Arrow|r
.goto 2405,40.20,56.76
.complete 92746,1 
step
#title Fly through the discs
.goto 2405,40.20,56.76,-1
.goto 2405,38.95,59.02,-1
.goto 2405,37.99,60.79,-1
.goto 2405,38.23,62.12,-1
.goto 2405,40.02,58.35,-1
.goto 2405,39.22,57.74,-1
>>If you hit the ground before collecting enough discs, jump into any vortex again.
.complete 92746,2 
step
#loop
.goto 2405,37.95,77.65,30,0
.goto 2405,37.16,78.71,30,0
.goto 2405,36.09,78.67,30,0
.goto 2405,34.1,76.26,30,0
.goto 2405,35.73,74.15,30,0
#arrowtext Click on\n|cRXP_PICK_Captives|r
>>Kill |cRXP_ENEMY_Manaforge forces|r and click on |cRXP_PICK_Captives|r
.complete 93905,1,100
.mob Netherbreaker
.target Unraveling Captive
.mob Manaforge Warder
.mob Manaforge Siphoner
.mob Manaforge Netherdrifter
step
#loop
.goto 2444,69.92,71.27,35,0
.goto 2444,69.73,78.17,35,0
.goto 2444,77.91,79.07,35,0
.goto 2444,77.48,71.35,35,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Complacent Voidwalkers|r and defeat them.
.complete 92566,1 
.mob Complacent Voidwalker
.skipgossipid 136045
step
#loop
.goto 2444,46.28,47.42,30,0
.goto 2444,43.33,41.29,30,0
.goto 2444,44.16,37.37,30,0
.goto 2444,47.28,40.72,30,0
>>Kill |cRXP_ENEMY_Behemoths|r or |cRXP_ENEMY_Players|r
.complete 89377,1,100
.mob Bitter Beast
.mob Vicious Consumptor
step
.goto 2444,42.25,48.37
.turnin 94743 >>Turn in *undefined*
step
#loop
.goto 2444,35.77,56.6,35,0
.goto 2444,34.33,56.86,35,0
.goto 2444,31.88,56.69,35,0
.goto 2444,32.51,52.91,35,0
.goto 2444,34.13,50.37,35,0
.goto 2444,37.99,49.68,35,0
>>Kill |cRXP_ENEMY_Ethereals|r and |cRXP_ENEMY_Horde Players|r.
.complete 89267,1 
.mob Spiteful Shadowguard
.mob Malefic Engineer
.mob Accursed Elemental
.mob Malefic Engineer
step
.goto 2405,51.19,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus to begin|r.
.complete 92731,1 
.target Decimus to begin
step
.goto 2405,36.67,60.43
>>Kill |cRXP_ENEMY_Encroaching Shredclaw|r.
.complete 92546,1 
.mob Encroaching Shredclaw
step
.goto 2405,28.12,50.34
>>Kill |cRXP_ENEMY_Void-gorged monstrosities|r.
.complete 93571,1 
.mob Void-gorged monstrosities
step
.goto 2405,27.20,44.18
.complete 93579,1 
.complete 93579,2 
step
#loop
.goto 2444,62.02,53.06,35,0
.goto 2444,61.30,50.77,35,0
.goto 2444,69.62,50.40,35,0
.goto 2444,65.72,57.49,35,0
.goto 2444,64.99,51.87,35,0
>>Kill the |cRXP_ENEMY_Shadowguards|r or other |cRXP_ENEMY_players|r.
.complete 88992,1 
.mob Malignant Shadowguard
.mob Abhorrent Shadowguard
step
#loop
.goto 2444,62.59,59.62,35,0
.goto 2444,61.82,64.09,35,0
.goto 2444,58.11,60.17,35,0
.goto 2444,58.91,55.68,35,0
.goto 2444,61.15,55.90,35,0
>>Kill the |cRXP_ENEMY_Void beasts|r or other |cRXP_ENEMY_players|r
.complete 87759,1 
.mob Vengeful Shredclaw
.mob Heinous Klaxid
step
#loop
.goto 2444,52.39,36.39,22,0
.goto 2444,55.08,36.29,22,0
.goto 2444,54.84,31.03,22,0
.goto 2444,55.24,17.04,22,0
.goto 2444,52.10,17.15,22,0
.goto 2444,52.40,30.87,22,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banners|r
>>Kill the |cRXP_ENEMY_Domanaar Forces|r
.complete 92576,1 
.complete 92576,2 
.mob Spiteful Mindwarden
.mob Coagulated Void
.mob Spiteful Minder
.mob Spiteful Consumptor
.mob Devouring Spawn
step
#loop
.goto 2444,67.28,49.04,35,0
.goto 2444,67.35,55.55,35,0
.goto 2444,63.80,56.43,35,0
.goto 2444,62.49,50.64,35,0
.goto 2444,66.09,48.84,35,0
>>Step into a |cRXP_PICK_Anti-Gravity Area|r and use the |T4914668:0|t|cRXP_WARN_ExtraActionButton|r at the |cRXP_ENEMY_Nefarious Elementals|r.
.complete 91419,1 
.mob Nefarious Elemental
step
.goto 2405,65.06,61.77
>>Fly through the rings
.complete 92549,1 
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) World Quest Voidstorm23342342432432
#internal
step
.goto 2395,42.69,47.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r.
.accept 89289 >>Accept Favor of the Court
.target Lord Saltheril
step
.goto 2395,42.69,47.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r and select a Champion for.
.complete 89289,1 
.skipgossipid 132893
.target Lord Saltheril
step
.goto 2395,42.68,47.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Saltheril|r.
.turnin 89289 >>Turn in Favor of the Court
.target Lord Saltheril

step
.goto 2395,42.87,46.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger-Captain Dawnfletch|r.
.acceptmultiple 91988,90575,91983,91987,91986 >>Accept Quests
.target Ranger-Captain Dawnfletch
step
.goto 2395,42.82,45.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vyrin the Supplier|r.
.acceptmultiple 92005,92000,92002,90576,92006 >>Accept Quests
.target Vyrin the Supplier
step
.goto 2395,42.62,46.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Bloodflame|r.
.acceptmultiple 90573,91993,89276,89278 >>Accept Quests
.target Magistrix Bloodflame
step
.goto 2395,42.4,46.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight-Lord Sunguard|r.
.acceptmultiple 91979,90574,91972,91977,91976,91974 >>Accept Quests
.target Knight-Lord Sunguard
step
#loop
.goto 2395,42.75,46.37,10,0
.goto 2395,43,47.8,10,0
.goto 2395,43.06,47.51,10,0
.goto 2395,42.99,46.72,10,0
.goto 2395,42.75,46.37,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talenia Flamesong|r.
#arrowtext Click on the\n|cRXP_PICK_Objects|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Objects|r
.complete 91966,1,100
.skipgossipid 135221
.target Talenia Flamesong
step
#loop
.goto 2395,34.42,68.57,40,0
.goto 2395,35.24,65.05,40,0
.goto 2395,37.5,62.67,40,0
.goto 2395,36.93,60.71,40,0
>>Kill |cRXP_ENEMY_Nagas|r
*Loot them for |T1518093:0|t[|cRXP_LOOT_Naga Fang|r].
.complete 92005,1 
.mob Daggerspine Myrmidon
.mob Daggerspine Infuser
step
.isOnQuest 89276
#loop
.goto 2395,44.74,77.75,30,0
.goto 2395,46.71,81.3,30,0
.goto 2395,45.78,81.16,30,0
.goto 2395,44.24,80.2,30,0
#arrowtext Click on the\n|cRXP_PICK_Wyrms|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wyrms|r
.complete 89276,1 
.target Scintillant Wyrm
step
.isOnQuest 92002
.goto 2395,43.37,67.92
.complete 92002,1 
step
.isOnQuest 91986
.goto 2395,37.39,63.44
.complete 91986,1 
step
.isOnQuest 91983
#loop
.goto 2395,56.94,35.84,30,0
.goto 2395,56.71,35.07,30,0
#arrowtext Click on the\n|cRXP_PICK_Feathers|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feathers|r
.complete 91983,1 
step
.goto 2395,40.73,13.69
.isInScenario 3060
.scenario 15659,1 
step
.goto 2395,40.73,13.69
.complete 90573,2 
step
.goto 2395,43.45,47.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caeris Fairdawn|r.
.accept 93930 >>Accept Courting Success
.target Caeris Fairdawn
step
.goto 2395,43.45,47.42
.turnin 93930 >>Turn in Courting Success

step
.isOnQuest 91988,90575,91983,91987,91986
.goto 2395,42.87,46.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger-Captain Dawnfletch|r.
.turninmultiple 91988,90575,91983,91987,91986 >>Turnin Quests
.target Ranger-Captain Dawnfletch
step
.isOnQuest 92005,92000,92002,90576,92006
.goto 2395,42.82,45.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vyrin the Supplier|r.
.turninmultiple 92005,92000,92002,90576,92006 >>Turnin Quests
.target Vyrin the Supplier
step
.isOnQuest 90573,91993,89276,89278
.goto 2395,42.62,46.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Bloodflame|r.
.turninmultiple 90573,91993,89276,89278 >>Turnin Quests
.target Magistrix Bloodflame
step
.isOnQuest 91979,90574,91972,91977,91976,91974
.goto 2395,42.4,46.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight-Lord Sunguard|r.
.turninmultiple 91979,90574,91972,91977,91976,91974 >>Turnin Quests
.target Knight-Lord Sunguard


















]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) World Quest Voidstorm234234423243243423
#internal
step
.goto 2405,26.40,67.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xy'dax|r.
.accept 91700 >>Accept Darkness Unmade
.target Xy'dax
step
.goto 2405,25.76,66.87
.complete 92407,1 
step
.goto 2405,26.80,68.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Null-Theorist Selune|r.
.turnin 92407 >>Turn in Hidey-Hole
.target Null-Theorist Selune
step
.goto 2405,26.41,67.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Null-Theorist Selune|r.
.accept 92365 >>Accept Creating Defenses
.target Null-Theorist Selune
step
.goto 2405,25.79,68.67
.complete 92365,1 
step
.goto 2405,26.47,68.68
.complete 95245,5 
step
.goto 2405,25.33,69.00
.complete 92365,2 
step
.goto 2405,25.29,69.26
.complete 92365,3 
step
.goto 2405,26.42,67.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Null-Theorist Selune|r.
.turnin 92365 >>Turn in Creating Defenses
.accept 95175 >>Accept Anchoring the Defense
.target Null-Theorist Selune
step
.goto 2405,26.71,67.80
.isInScenario 3021
.scenario 15895,1 
.complete 90962,1 
step
.goto 2405,26.43,68.75
.isInScenario 3021
.scenario 14823,1 
step
.goto 2405,26.41,67.50
.isInScenario 3021
.scenario 15998,1 
step
.goto 2405,26.82,67.89
.isInScenario 3021
.scenario 14822,2 
step
.goto 2405,26.72,68.11
.isInScenario 3021
.scenario 15894,1 
step
.scenario 15895,1
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) World Quest Voidstorm2344232432432432
#internal
step
.goto 2579,82.28,33.43
.accept 91457 >>Accept Abundance: Watha'nan Crypts
step
.goto 2395,57.00,65.84
.complete 95245,3 
.complete 94361,1 
step
.goto 2437,31.60,26.06
.accept 87350 >>Accept Abundance: Loaknit Den
step
.goto 2580,48.96,18.33
.complete 87350,1 
.complete 89507,1 
.complete 94361,2 
step
.goto 2437,31.56,26.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r.
.turnin 89507 >>Turn in Abundant Offerings
.target Chel the Chip
step
.goto 2413,66.18,61.70
.accept 91302 >>Accept Abundance: Abundant Grove
step
.goto 2523,19.87,89.61
.complete 91302,1 
step
.goto 2413,66.09,61.68
.turnin 91302 >>Turn in *undefined*
.complete 94361,3 
step
.goto 2405,38.84,53.39
.accept 91475 >>Accept Abundance: Abundant Voidburrow
step
.goto 2581,37.86,25.08
.complete 94361,4 
step
.goto 2405,38.91,53.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r.
.turnin 94361 >>Turn in The Abundant Life
.target Chel the Chip
]])

RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Midnight
#name a) Prey
#internal
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#subgroup |cFF1EFF00(1-90)|r Default
#name c
#displayname |cFFFCDC00LEVEL 80-90|r
#disabled
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Speed Leveling
#subgroup |cFFFCDC00(1-90)|r Default
#name c 2
#displayname |cFFFCDC00LEVEL 80-90|r
#disabled
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name |cRXP_WARN_Before You Pick a Guide|r
step
+|cRXP_PICK_Default:|r This guide will do the campaign, delves and some side quests (identical to Campaign & Sidequests). It will skip side quests if you're overleveled. This is the fastest route if you don't want to use Warmode and are not crafting at the end.
step
+|cRXP_PICK_Campaign & Sidequests:|r This guide will do the campaign, delves and some side quests. It will skip side quests if you're overleveled. This is the fastest route if you don't want to use Warmode and are not crafting at the end.
step
+|cRXP_PICK_Campaign & Delves:|r This guide will do the campaign and all delves. It has no built in xp skips and expects you to craft at the end.
step
+|cRXP_PICK_Alt Leveling:|r This guide is for your alts after you have done the campaign once. You can do the chapters in any order and stop early if you want to craft for the last level.
step
+|cRXP_PICK_Sojourner:|r This guide is designed for completing all storylines efficiently in one go.
step
+|cRXP_PICK_Sojourner & Campaign:|r This guide is designed to complete all storylines and the campaign efficiently in one go.
step
+|cRXP_PICK_(80-87) Level-Up Campaigns:|r Allows progression through the campaign only.
step
+|cRXP_PICK_Delves:|r Allows you to pick individual delves or choose the Delves World Tour for a route through all delves and their quests.
step
+|cRXP_PICK_Storylines:|r This guide lets you select individual storylines required for the Sojourner achievement and more.
step
+If you want to use the multibox functionality, select any 80–90 route. Then open RestedXP Options under Guide Routing enable “Multibox Mode”.
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#subgroup Pre-Turnins
#name a) Pre-Turnins Booklet
#internal
step
+Stormwind Quests can be turned in at the start: under "Guide: Prepturnins" or "Miscellaneous Turnins"
*Expect heavy crowding in the Midnight intro at launch. Turning in some Pre-Quests before may reduce lag/DCs.
*In Retail, being far enough behind the pack is often manageable or even advantageous.






step
+Global Quests can be turned in from everywhere(some pet battles for example) ideally those are turned in an area with an XP Buff
*The guide will guide you to Ohn'ahran Plains for 5% extra XP when it's time to turn them in.
*If you want to do them at the start select "First Crafts & Global Turnins" keep in mind you will need to return to this guide if you want to do first crafts later.
step
+Should you ever be stuck in any prep guide and you do not want to waste any time manually skips the steps or select the chapter after turnins.
step
+We only cover Kun'lai Turnins, netherstorm is not supported
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Turnin Route Alliance
#internal
<< Alliance
step
#completewith PrepEnd
+If you get stuck on any step in the prep guide, manually skip it.




















































































step
.zone 2352 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
#completewith next
#label Morulu the Elder
.isQuestComplete 31925
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r.
.dailyturnin 31925 >>Turn in Morulu the Elder
.target Morulu the Elder
step
#completewith Morulu the Elder
.goto 84,44.89,85.78
.zone 111 >>Click on the |cRXP_PICK_Portal to Shattrath|r
step
#requires Morulu the Elder
.isQuestComplete 31925
.goto 111,59.51,69.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r.
.dailyturnin 31925 >>Turn in Morulu the Elder
.skipgossip
.target Morulu the Elder
step
.zoneskip 111,1
.goto 111,57.2,48.28
.zone 84 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Shattrath|r
step
.isQuestComplete 83493
#completewith next
#label Warbands: Rift Reader
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut|r.
.turnin 83493 >>Turn in Warbands: Rift Reader
step
#completewith Warbands: Rift Reader
.goto 84,43.75,85.44
.zone 74 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Caverns of Time|r
step
#requires Warbands: Rift Reader
.isQuestComplete 83493
.goto 71,52.6,27.19,10,0
.goto 71,52.51,26.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut|r.
.turnin 83493 >>Turn in Warbands: Rift Reader
step
.isQuestComplete 83494
.goto 71,52.51,26.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut|r.
.turnin 83494 >>Turn in Warbands: Space Ghosts by the Coast
.target Blue
step
.goto 74,59.02,26.75
.zone 84 >>Click on the |cRXP_PICK_Portal to Stormwind|r
step
#completewith next
#label A Keg-Stamped Package
.isQuestComplete 80384
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Da'kash Grimledger|r.
.turnin 80384 >>Turn in A Keg-Stamped Package
.target Da'kash Grimledger
step
#completewith A Keg-Stamped Package
.goto 84,48.83,93.47
.zone 2112 >>Click on the |cRXP_PICK_Portal to Valdrakken|r
step
#requires A Keg-Stamped Package
.isQuestComplete 80384
.goto 2112,48.33,49.6,10,0
.goto 2112,46.59,45.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Da'kash Grimledger|r.
.turnin 80384 >>Turn in A Keg-Stamped Package
.target Da'kash Grimledger
step
.zoneskip 2112,1
.goto 2112,59.77,41.67
.zone 84 >>Click on the |cRXP_PICK_Portal to Stormwind|r
step
#completewith next
#label Nearly Headless Jacob
.isQuestComplete 31932
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r and defeat them in a pet battle.
.dailyturnin 31932 >>Turn in Nearly Headless Jacob
.target Nearly Headless Jacob
step
#completewith Nearly Headless Jacob
.goto 84,44.39,88.7
.zone 125 >>Click on the |cRXP_PICK_Portal to Dalaran|r
step
#requires Nearly Headless Jacob
.isQuestComplete 31932
.goto 127,50.09,58.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r and defeat them in a pet battle.
.dailyturnin 31932 >>Turn in Nearly Headless Jacob
.skipgossip
.target Nearly Headless Jacob
step
.isQuestComplete 31934
.goto 121,13.25,66.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gutretch|r.
.dailyturnin 31934 >>Turn in Gutretch
.target Gutretch
step
.zoneskip 97,1
.zone 2352 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.isOnQuest 92572
.goto 84,56.08,77.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Second Chair Pawdo|r
.turnin 92572 >>Turn in Furniture Favor
.target Second Chair Pawdo







step << Human
.isOnQuest 72446,72449,
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal McBride,|r |cRXP_FRIENDLY_Master Mathias Shaw|r and |cRXP_FRIENDLY_Cecilia Clessington|r.
.turnin 72446 >>Turn in What's Their Problem?
.goto 425,27.68,66.66
.target +Marshal McBride
.turnin 72449 >>Turn in Knock It Off!
.goto 425,27.89,66.73
.target +Master Mathias Shaw
.turnin 72450 >>Turn in The Clessington Will
.goto 425,28.02,67.31
.target +Cecilia Clessington
step << Worgen
.isOnQuest 54981,54982
.goto 47,74.09,45.55,5,0
.goto 47,73.75,45.56,5,0
.goto 47,73.8,46.13,5,0
.goto 47,46.39,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vassandra Stormclaw|r.
.turnin 54981 >>Turn in Cry to the Moon
.target Vassandra Stormclaw
.turnin 54982 >>Turn in The Spirit of the Hunter
step
.isQuestTurnedIn 54982
.goto 47,46.39,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vassandra Stormclaw|r.
.target Vassandra Stormclaw
.accept 54983 >>Accept Waking a Dreamer
step << Worgen
.isOnQuest 54983
.goto 47,46.39,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vassandra Stormclaw|r.
.complete 54983,1 
.timer 56,RP
.skipgossip
.target Vassandra Stormclaw
step << Worgen
.isOnQuest 54983
.goto 47,46.60,36.98
>>Kill |cRXP_ENEMY_Spirit of Fury|r.
.complete 54983,2 
.mob Spirit of Fury
step << Worgen
.isOnQuest 54983
.goto 47,46.58,36.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goldrinn|r.
.turnin 54983 >>Turn in Waking a Dreamer
.target Goldrinn
step
.goto 84,50.66,73.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Robby Flay|r.
.dailyturnin 26153,26183,26190,26177,26192 >>Turn in the Cooking Daily
.target Robby Flay
step
.isQuestComplete 66858
.goto 84,50.98,71.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tawny Seabraid|r.
.turnin 66858 >>Turn in Tour the Trading Post
.target Tawny Seabraid
step
.goto 84,55.04,69.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Catherine Leland|r.
.dailyturnin 26414,26420,26442,26488,26536 >>Turn in the Fishing Daily
.target Catherine Leland
step
.isQuestComplete 29412
.goto 84,58.91,52.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vin|r.
.turnin 29412 >>Turn in Blown Away
.target Vin
step << LightforgedDraenei
#completewith next
#label Heritage of the Lightforged
.isOnQuest 49782
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Fareeya|r.
.turnin 49782 >>Turn in Heritage of the Lightforged
.target Captain Fareeya
step << LightforgedDraenei
#completewith Heritage of the Lightforged
.goto 84,48.04,11.1
.zone 940 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Beacon|r
step << LightforgedDraenei
#requires Heritage of the Lightforged
.isOnQuest 49782
.goto 940,49.21,43.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Fareeya|r.
.turnin 49782 >>Turn in Heritage of the Lightforged
.target Captain Fareeya
step << LightforgedDraenei
.zoneskip 941,1
.goto 941,43.25,25.07
.zone 84 >>Click on the |cRXP_PICK_Portal to Stormwind|r
step << VoidElf
.isOnQuest 49928
#completewith next
#label Heritage of the Void
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 49928 >>Turn in Heritage of the Void
.target Alleria Windrunner
step << LightforgedDraenei
#completewith Heritage of the Void
.goto 84,50.72,8.4
.zone 971 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
step << VoidElf
#requires Heritage of the Void
.isOnQuest 49928
.goto 971,28.53,22.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 49928 >>Turn in Heritage of the Void
.target Alleria Windrunner
step << DarkIronDwarf
#completewith next
#label Heritage of the Dark Iron
.isOnQuest 51483
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 51483 >>Turn in Heritage of the Dark Iron
.target Moira Thaurissan
step << DarkIronDwarf
#completewith Heritage of the Dark Iron
.goto 84,49.69,10.73
.zone 1186 >>Click on the |cRXP_PICK_Mole Machine|r
step << DarkIronDwarf
#requires Heritage of the Dark Iron
.isOnQuest 51483
.goto 1186,56.44,31.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 51483 >>Turn in Heritage of the Dark Iron
.target Moira Thaurissan
step << DarkIronDwarf
.zoneskip 1186,1
.goto 1186,59.28,26.47
.zone 84 >>Click on the |cRXP_PICK_Portal to Stormwind|r
step << Mechagnome
#completewith next
#label Heritage of the Mechagnome
.isOnQuest 58436
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prince Erazmin|r.
.turnin 58436 >>Turn in Heritage of the Mechagnome
.target Prince Erazmin
step << Mechagnome
#completewith Heritage of the Mechagnome
.goto 84,48.65,8.86
.zone 1573 >>Step on the teleporter
step << Mechagnome
#requires Heritage of the Mechagnome
.isOnQuest 58436
.goto 1573,18.67,67.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prince Erazmin|r.
.turnin 58436 >>Turn in Heritage of the Mechagnome
.target Prince Erazmin
step << Mechagnome
.zoneskip 1573,1
.goto 1573,20.43,59.64
.zone 84 >>Step on the teleporter
step << NightElf
.isOnQuest 76212
.goto 84,52.42,4.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysander Starshade|r.
.turnin 76212 >>Turn in A Mark For A Protector
.target Lysander Starshade
step << NightElf
.isQuestTurnedIn 76212
.goto 84,52.59,3.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maiev Shadowsong|r.
.accept 76213 >>Accept Honor of the Goddess
.timer 30,RP
.target Maiev Shadowsong
step << NightElf
.isOnQuest 76213
.goto 84,52.59,3.82
>>|cRXP_WARN_Wait for the roleplay|r.
*|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maiev Shadowsong|r.
.target Maiev Shadowsong
.turnin 76213 >>Turn in Honor of the Goddess
step
.isQuestComplete 32470
.goto 84,61.33,22.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arielle Snapflash|r.
.turnin 32470 >>Turn in Light Camera Action
.target Arielle Snapflash
step
.goto 84,64.27,16.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r in Stormwind and press continue the Xalatath Campaign then turn in the quest.
*|cRXP_WARN_Skip this step if you didn't setup this quest|r.
.turnin 40710 >>Turn in Blade in Twilight
.target Lorewalker Cho
step
.isQuestComplete 32863
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Audrey Burnhep|r.
.turnin 32863 >>Turn in What We've Been Training For
.target Audrey Burnhep
step
#completewith next
#label Brok
#hidewindow

>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r.
.turnin 29740 >>Turn in Evershade the Elder
.dailyturnin 31972 >>Turn in Brok
.target Brok
step
#completewith Brok
.goto 2239,55.42,64.91
.zone 198 >>Click on the |cRXP_PICK_Portal to Mount Hyjal|r
step
#requires Brok
.isQuestComplete 31972
.goto 198,61.39,32.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r.
.dailyturnin 31972 >>Turn in Brok
.target Brok







step
.zoneskip 198,1
.goto 198,62.63,23.11
.zone 198 >>Click on the |cRXP_PICK_Portal to Stormwind|r
step
.isQuestComplete 31973
#completewith next
#label Bordin Steadyfist
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r.
.dailyturnin 31973 >>Turn in Bordin Steadyfist
.target Bordin Steadyfist
step
#completewith Bordin Steadyfist
.goto 84,73.17,19.69
.zone 207 >>Use |T463898:0|t[Potion of Deepholm]
.use 58487
step
#requires Bordin Steadyfist
.isQuestComplete 31973
.goto 207,49.87,57.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r.
.dailyturnin 31973 >>Turn in Bordin Steadyfist
.target Bordin Steadyfist
step
.zoneskip 207,1
.goto 207,48.53,53.84
.zone 84 >>Click on the |cRXP_PICK_Portal to Stormwind|r
step
#completewith next
#label Goz Banefury
.isQuestComplete 31974
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r.
.dailyturnin 31974 >>Turn in Goz Banefury
.target Goz Banefury
step
#completewith Goz Banefury
.goto 84,75.34,16.45
.zone 241 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Twilight Highlands|r
step
#requires Goz Banefury
.isQuestComplete 31974
.goto 241,56.59,56.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r.
.dailyturnin 31974 >>Turn in Goz Banefury
.target Goz Banefury
step << DarkIronDwarf
#completewith next
#label Grand Master Antari
.isQuestComplete 31926
.isQuestTurnedIn 53599
.goto 104,30.51,41.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodknight Antari|r.
.dailyturnin 31926 >>Turn in Grand Master Antari
.target Bloodknight Antari
step <<DarkIronDwarf
#completewith Grand Master Antari
.isQuestComplete 31926
.isQuestTurnedIn 53599
.zone 104 >>Use the |T1786409:0|t[Mole Machine] to Shadowmoon Valley.
.use 265225
step << DarkIronDwarf
#requires Grand Master Antari
.isQuestComplete 31926
.isQuestTurnedIn 53599
.goto 104,30.51,41.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodknight Antari|r.
.dailyturnin 31926 >>Turn in Grand Master Antari
.target Bloodknight Antari
step
#completewith next
#label Gurgl and the Bandit
.isQuestComplete 64237
.goto 627,58.47,39.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breanni|r.
.turnin 64237 >>Turn in Gurgl and the Bandit
.target Breanni
step
#completewith Gurgl and the Bandit
.zone 627 >>Go to Legion Dalaran(Use the Legion HS if you got it)
step
#requires Gurgl and the Bandit
#label PrepEnd
.isQuestComplete 64237
.goto 627,58.47,39.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breanni|r.
.turnin 64237 >>Turn in Gurgl and the Bandit
.target Breanni
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Turnin Route Horde
#internal
<< Horde
step
#completewith PrepEnd
+If you get stuck on any step in the prep guide, manually skip it.





















































































step << Undead
#completewith next
#label Acid Beats Paper
.isOnQuest 72858,72856,72857
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dark Ranger Velonara|r and |cRXP_FRIENDLY_Master Apothecary Faranell|r.
.turnin 72858 >>Turn in Acid Beats Paper
.target +Dark Ranger Velonara
.turnin 72856 >>Turn in Nothing Like the Classic
.target +Master Apothecary Faranell
.turnin 72857 >>Turn in Boom Weed
step << Undead
#completewith Acid Beats Paper
.zone 21 >>Use |T135975:0|t[Tirisfal Camp Scroll]
step << Undead
#requires Acid Beats Paper
.isOnQuest 72858,72856,72857
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dark Ranger Velonara|r and |cRXP_FRIENDLY_Master Apothecary Faranell|r.
.turnin 72858 >>Turn in Acid Beats Paper
.goto 21,45.56,42.04
.target +Dark Ranger Velonara
.turnin 72856 >>Turn in Nothing Like the Classic
.target +Master Apothecary Faranell
.turnin 72857 >>Turn in Boom Weed
.goto 21,45.63,41.99
step
.zoneskip 110,1
.zone 2351 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Orgrimmar Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
#completewith next
#label A Keg-Stamped Package
.isQuestComplete 80384
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Da'kash Grimledger|r.
.turnin 80384 >>Turn in A Keg-Stamped Package
.target Da'kash Grimledger
step
#completewith A Keg-Stamped Package
.goto 85,57.13,87.39
.zone 2112 >>Click on the |cRXP_PICK_Portal to Valdrakken|r
step
#requires A Keg-Stamped Package
.isQuestComplete 80384
.goto 2112,48.33,49.6,10,0
.goto 2112,46.59,45.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Da'kash Grimledger|r.
.turnin 80384 >>Turn in A Keg-Stamped Package
.target Da'kash Grimledger
step
.zoneskip 2112,1
.goto 2112,56.66,38.35
.zone 85 >>Click on the |cRXP_PICK_Portal to Orgrimmar|r
step
#completewith next
#label Morulu the Elder
.isQuestComplete 31925
.goto 85,54.85,89.98,10,0
.goto 85,54.66,87.18,10,0
.goto 85,55.96,86.98,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r.
.dailyturnin 31925 >>Turn in Morulu the Elder
.target Morulu the Elder
step
#completewith Morulu the Elder
.goto 85,57.47,91.58
.zone 111 >>Click on the |cRXP_PICK_Portal to Shattrath|r
step
#requires Morulu the Elder
.isQuestComplete 31925
.goto 111,59.51,69.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Morulu the Elder|r.
.dailyturnin 31925 >>Turn in Morulu the Elder
.skipgossip
.target Morulu the Elder
step
.zoneskip 111,1
.goto 111,56.84,48.84
.zone 85 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Shattrath|r
step
.isQuestComplete 83493
#completewith next
#label Warbands: Rift Reader
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut|r.
.turnin 83493 >>Turn in Warbands: Rift Reader
step
#completewith Warbands: Rift Reader
.goto 85,56.4,92.54
.zone 74 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Caverns of Time|r
step
#requires Warbands: Rift Reader
.isQuestComplete 83493
.goto 71,52.6,27.19,10,0
.goto 71,52.51,26.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut|r.
.turnin 83493 >>Turn in Warbands: Rift Reader
step
.isQuestComplete 83494
.goto 71,52.51,26.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blue|r |cRXP_WARN_inside the hut|r.
.turnin 83494 >>Turn in Warbands: Space Ghosts by the Coast
.target Blue
step
.goto 74,58.24,26.74
.zone 85 >>Click on the |cRXP_PICK_Portal to Orgrimmar|r
step << ZandalariTroll
#completewith next
#label Heritage of the Zandalari
.isOnQuest 53721
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Queen Talanji|r.
.turnin 53721 >>Turn in Heritage of the Zandalari
.target Queen Talanji
step << ZandalariTroll
#completewith Heritage of the Zandalari
.goto 85,57.84,89.86
.zone 862 >>Click on the |cRXP_PICK_Portal to Zuldazar|r
step << ZandalariTroll
#requires Heritage of the Zandalari
.isOnQuest 53721
.goto 1165,49.93,46.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Queen Talanji|r.
.turnin 53721 >>Turn in Heritage of the Zandalari
.target Queen Talanji
step << ZandalariTroll
.zoneskip 1163,1
.goto 1163,73.94,69.9
.zone 85 >>Click on the |cRXP_PICK_Portal to Orgrimmar|r
step << BloodElf
#completewith next
#label Fall of the Sunwell
.isOnQuest 54096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 54096 >>Turn in The Fall of the Sunwell
.target Lor'themar Theron
step << BloodElf
#completewith Fall of the Sunwell
.goto 85,54.66,90.34
.zone 110 >>Click on the |cRXP_PICK_Portal to Old Silvermoon|r
step << BloodElf
#requires Fall of the Sunwell
.isOnQuest 54096
.goto 110,68.64,35.1,10,0
.goto 110,60.37,28.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 54096 >>Turn in The Fall of the Sunwell
.target Lor'themar Theron
step << BloodElf
.zoneskip 110,1
.goto 110,58.55,18.64
.zone 85 >>Click on the |cRXP_PICK_Portal to Orgrimmar|r
step
#completewith next
#label Nearly Headless Jacob
.isQuestComplete 31932
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r and defeat them in a pet battle.
.dailyturnin 31932 >>Turn in Nearly Headless Jacob
.target Nearly Headless Jacob
step
#completewith Nearly Headless Jacob
.goto 85,56.25,91.69
.zone 125 >>Click on the |cRXP_PICK_Portal to Dalaran|r
step
#requires Nearly Headless Jacob
.isQuestComplete 31932
.goto 127,50.09,58.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nearly Headless Jacob|r and defeat them in a pet battle.
.dailyturnin 31932 >>Turn in Nearly Headless Jacob
.skipgossip
.target Nearly Headless Jacob
step
.isQuestComplete 31934
.goto 121,13.25,66.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gutretch|r.
.dailyturnin 31934 >>Turn in Gutretch
.target Gutretch
step
.zoneskip 110,1
.zone 2351 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.isOnQuest 92572
.goto 85,52.94,89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Second Chair Pawdo|r
.turnin 92572 >>Turn in Furniture Favor
.target Second Chair Pawdo
step << Troll
.isOnQuest 77901,77902,77903
.goto 463,56.96,56.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rokhan|r.
.turnin 77901 >>Turn in Retraining the Trainees
.target Rokhan
.turnin 77902 >>Turn in Ritual Recovery
.turnin 77903 >>Turn in De Power of Death
step << Troll
.isQuestTurnedIn 77903
.goto 463,56.96,56.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rokhan|r.
.accept 77905 >>Accept Avatar of Mueh'zala
step << Troll
.isOnQuest 77905
.goto 463,56.27,56.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feather|r.
.complete 77905,1 
step << Troll
.isOnQuest 77905
.goto 463,58.55,56.29
>>Kill |cRXP_ENEMY_Summoned Visage|r on the pillar and |TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_PICK_Totems|r.
.complete 77905,3,1 
.mob Summoned Visage
step << Troll
.isOnQuest 77905
.goto 463,54.39,56.53
>>Kill |cRXP_ENEMY_Summoned Visage|r on the pillar and |TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_PICK_Totems|r.
.complete 77905,3,2 
.mob Summoned Visage
step << Troll
.isOnQuest 77905
.goto 463,54.49,47.04
>>Kill |cRXP_ENEMY_Summoned Visage|r on the pillar and |TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_PICK_Totems|r.
.complete 77905,3,3 
.mob Summoned Visage
step << Troll
.isOnQuest 77905
.goto 463,58.48,46.89
>>Kill |cRXP_ENEMY_Summoned Visage|r on the pillar and |TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_PICK_Totems|r.
*|cFFFF0000After completing the objective, you can skip the cutscene by pressing 'Escape' and accepting the prompt|r.
.complete 77905,3,4 
.mob Summoned Visage
step << Troll
.isQuestComplete 77905
.goto 463,58.50,65.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rokhan|r.
.turnin 77905 >>Turn in Avatar of Mueh'zala
.target Rokhan
step << Troll
.isQuestTurnedIn 77905
.goto 463,58.50,65.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rokhan|r.
.accept 77906 >>Accept De Darkspear Loa
.target Rokhan
step << Troll
.isOnQuest 77906
.goto 463,58.73,66.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Totem|r.
.complete 77906,1 
step << Troll
.isOnQuest 77906
.goto 463,58.73,66.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Loa Offering|r.
.complete 77906,2 
step << Troll
.isQuestComplete 77906
.goto 463,59.05,65.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Gadrin|r.
.turnin 77906 >>Turn in De Darkspear Loa
.target Master Gadrin
step << Orc
#label Orc
.goto 1,52.20,42.99
.isOnQuest 72467,74415,72475
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Aggralan|r.
.turnin 72467 >>Turn in The Blessing of the Clan
.turnin 74415 >>Turn in A Worthy Offering
.turnin 72475 >>Turn in Cornering Gor'krosh
.target Farseer Aggralan
step << Orc
.isQuestTurnedIn 72475
.goto 1,52.20,42.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Aggralan|r.
.accept 72478 >>Accept Honor and Glory
step << Orc
.isOnQuest 72478
#completewith Boss Magor
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on all the |cRXP_PICK_Food|r. Kill |cRXP_ENEMY_Rowdy Warlock|r and |cRXP_ENEMY_Rowdy Grunt|r.
.complete 72478,1 
.mob Rowdy Warlock
.mob Rowdy Grunt
step << Orc
.isOnQuest 72478
#completewith Boss Magor
.goto 1,52.48,40.95
.gossipoption 108372 >>Talk to |cRXP_FRIENDLY_Boss Magor|r.
.timer 10,RP
.target Boss Magor
step << Orc
#label Boss Magor
.isOnQuest 72478
.goto 1,52.06,42.15
>>Kill |cRXP_ENEMY_Boss Magor|r. Pickup a |cRXP_PICK_Booterang|r and use your |cRXP_WARN_ExtraActionButton|r when he casts |cRXP_WARN_Bootstorm|r.
.complete 72478,2 
.mob Boss Magor
.target Boss Magor
step << Orc
#loop
.isOnQuest 72478
.goto 1,52.2,42.31,30,0
.goto 1,52.5,41.5,30,0
.goto 1,52.95,42.85,30,0
.goto 1,52.33,43.32,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on all the |cRXP_PICK_Food|r. Kill |cRXP_ENEMY_Rowdy Warlock|r and |cRXP_ENEMY_Rowdy Grunt|r.
.complete 72478,1 
.mob Rowdy Warlock
.mob Rowdy Grunt
step << Orc
.isOnQuest 72478
.goto 1,52.25,43.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r.
.turnin 72478 >>Turn in Honor and Glory
.target Thrall
step << Orc
.isQuestTurnedIn 72478
.goto 1,52.25,43.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r.
.target Thrall
.accept 72479 >>Accept Aka'magosh
step << Orc
.isOnQuest 72479
.goto 1,52.26,43.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eitrigg|r.
.turnin 72479 >>Turn in Aka'magosh
.target Eitrigg
step << Tauren
#label Tauren
.isQuestComplete 54766
.goto 88,60.32,51.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baine Bloodhoof|r.
.turnin 54766 >>Turn in Answer the Call
.target Baine Bloodhoof
step << Tauren
.isQuestTurnedIn 54766
.goto 88,60.32,51.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baine Bloodhoof|r.
.target Baine Bloodhoof
.accept 54765 >>Accept Thank Your Guide
step << Tauren
.isOnQuest 54765
.goto 7,33.97,38.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Spirit Offering|r.
.complete 54765,1 
step << Tauren
.isQuestComplete 54765
.goto 7,34.00,38.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ceremonial Tauren Garb|r.
.turnin 54765 >>Turn in Thank Your Guide
.target Ceremonial Tauren Garb
step << Orc/Troll/Tauren
.zoneskip 110,1
.zone 2351 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step
.isQuestComplete 66959
.goto 85,48.9,76.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shiri|r.
.turnin 66959 >>Turn in Tour the Trading Post
.target Shiri
step << HighmountainTauren
#completewith next
#label Heritage of Highmountain
.isOnQuest 49783
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.turnin 49783 >>Turn in Heritage of Highmountain
.target Mayla Highmountain
step << HighmountainTauren
#completewith Heritage of Highmountain
.goto 85,38.17,75.27
.zone 652 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Highmountain|r
step << HighmountainTauren
#requires Heritage of Highmountain
.isOnQuest 49783
.goto 652,54.95,63.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayla Highmountain|r.
.turnin 49783 >>Turn in Heritage of Highmountain
.target Mayla Highmountain
step << HighmountainTauren
.zoneskip 652,1
.goto 652,46.01,63.88
.zone 85 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Orgrimmar|r
step << Nightborne
#completewith next
#label Heritage of the Nightborne
.isOnQuest 49784
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.turnin 49784 >>Turn in Heritage of the Nightborne
.target First Arcanist Thalyssra
step << Nightborne
#completewith Heritage of the Nightborne
.goto 85,38.6,75.91
.zone 680 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Suramar|r
step << Nightborne
#requires Heritage of the Nightborne
.isOnQuest 49784
.goto 680,59.33,85.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Arcanist Thalyssra|r.
.turnin 49784 >>Turn in Heritage of the Nightborne
.target First Arcanist Thalyssra
step << Nightborne
.zoneskip 680,1
.goto 680,58.18,87.33
.zone 85 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Orgrimmar|r
step
.isQuestComplete 32470
.goto 85,48.14,46.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaga|r.
.turnin 32470 >>Turn in Light Camera Action
.target Jaga
step
.isQuestComplete 29401
.goto 85,48.13,46.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaga|r.
.turnin 29401 >>Turn in Blown Away
.target Jaga







step
.isQuestComplete 32863
.goto 85,52.57,59.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varzok|r.
.turnin 32863 >>Turn in What We've Been Training For
.target Varzok
step
.goto 85,54.26,56.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r in Orgrimmar and press continue the Xalatath Campaign then turn in the quest.
*|cRXP_WARN_Skip this step if you didn't setup this quest|r.
.turnin 40710 >>Turn in Blade in Twilight
.target Lorewalker Cho
step
.goto 85,56.54,62.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marogg|r.
.dailyturnin 26227,26226,26235,26220,26234,26233 >>Turn in the Cooking Daily
.target Marogg
step << MagharOrc
.isOnQuest 51484
.goto 85,70.61,44.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overlord Geya'rah|r.
.turnin 51484 >>Turn in Heritage of the Mag'har
.target Overlord Geya'rah
step
.goto 85,65.67,41.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razgar|r.
.dailyturnin 26543,26556,26557,26588,26572 >>Turn in the Fishing Daily
.target Razgar
step
#completewith next
#label Brok
.isQuestComplete 31972
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r.
.dailyturnin 31972 >>Turn in Brok
.target Brok
step
#completewith Brok
.goto 2239,55.42,64.91
.zone 198 >>Click on the |cRXP_PICK_Portal to Mount Hyjal|r
step
#requires Brok
.isQuestComplete 31972
.goto 198,61.39,32.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brok|r.
.dailyturnin 31972 >>Turn in Brok
.target Brok







step
.isQuestComplete 31973
#completewith next
#label Bordin Steadyfist
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r.
.dailyturnin 31973 >>Turn in Bordin Steadyfist
.target Bordin Steadyfist
step
#completewith Bordin Steadyfist
.goto 84,73.17,19.69
.zone 207 >>Use |T463898:0|t[Potion of Deepholm]
.use 58487
step
#requires Bordin Steadyfist
.isQuestComplete 31973
.goto 207,49.87,57.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bordin Steadyfist|r.
.dailyturnin 31973 >>Turn in Bordin Steadyfist
.target Bordin Steadyfist
step
.zoneskip 207,1
.goto 207,50.92,53.09
.zone 85 >>Click on the |cRXP_PICK_Portal to Orgrimmar|r
step
#completewith next
#label Goz Banefury
.isQuestComplete 31974
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r.
.dailyturnin 31974 >>Turn in Goz Banefury
.target Goz Banefury
step
#completewith Goz Banefury
.goto 85,50.17,39.42
.zone 241 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Twilight Highlands|r
step
#requires Goz Banefury
.isQuestComplete 31974
.goto 241,56.59,56.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Goz Banefury|r.
.dailyturnin 31974 >>Turn in Goz Banefury
.target Goz Banefury
step
#completewith next
#label Gurgl and the Bandit
.isQuestComplete 64237
.goto 627,58.47,39.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breanni|r.
.turnin 64237 >>Turn in Gurgl and the Bandit
.target Breanni
step
#completewith Gurgl and the Bandit
.zone 627 >>Go to Legion Dalaran(Use the Legion HS if you got it)
step
#requires Gurgl and the Bandit
#label PrepEnd
.isQuestComplete 64237
.goto 627,58.47,39.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breanni|r.
.turnin 64237 >>Turn in Gurgl and the Bandit
.target Breanni
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) PoP-UP Quests Turnins
#internal













step
.zoneskip 84,1
.goto 84,48.71,95.13
.zone 2393 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silvermoon Portal|r in the Portalroom.
*|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
step
.zoneskip 85,1
.goto 85,56.01,88.26
.zone 2393 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silvermoon Portal|r in the Portalroom.
*|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
step
.zoneskip 2393,1
.goto 2393,48.2,54.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Galana|r.
.train 471015 >>Train |T4620681:0|t[Midnight Tailoring]
.train 3908,3
.target Galana
*|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
step
.zoneskip 2393,1
.goto 2393,43.65,51.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bemarrin|r.
.train 471004 >>Train |T4620670:0|t[Midnight Blacksmithing]
.train 2018,3
.target Bemarrin
*|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
step
.zoneskip 2393,1
.goto 2393,43.15,55.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talmar|r.
.train 471012 >>Train |T4620678:0|t[Midnight Leatherworking]
.train 2108,3
.target Talmar
*|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
step
.train 471015,3
.goto 2393,48.25,54.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talmar|r.
.collect 251665,120 
.collect 251691,100 
.target Talmar
*|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
step
.train 471004,3
.goto 2393,43.65,51.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eriden |r.
.collect 243060,81 
.target Eriden
*|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
step
>>|cRXP_WARN_LEATHERWORKING|r
*>Buy these Mats if you want to do Midnight First Crafts for an easy level.
*>|cRXP_WARN_We only cover Leatherworking, Blacksmithing and Tailoring at this time|r.
*>|cRXP_WARN_manually skip any items you do want to acquire, even just doing a few first crafts is good|r
*>|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
*|cRXP_WARN_AUCTION HOUSE:|r
.collect 238511,380 
.collect 238513,340 
.collect 236767,10 
*|cRXP_WARN_VENDOR:|r
.collect 251665,120 
step
>>|cRXP_WARN_BLACKSMITHING|r
*>Buy these Mats if you want to do Midnight First Crafts for an easy level.
*>|cRXP_WARN_We only cover Leatherworking, Blacksmithing and Tailoring at this time|r.
*>You can craft ore into ingots and bright linen into bolts instead of buying them; buying is faster but expensive.
*>|cRXP_WARN_manually skip any items you do want to acquire, even just doing a few first crafts is good|r
*>|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
*|cRXP_WARN_AUCTION HOUSE:|r
.collect 237359,510 
.collect 238197,100 
.collect 242788,9 
.collect 237362,6 
*|cRXP_WARN_VENDOR:|r
.collect 243060,81 
step
>>|cRXP_WARN_TAILORING|r
*>Buy these Mats if you want to do Midnight First Crafts for an easy level.
*>|cRXP_WARN_We only cover Leatherworking, Blacksmithing and Tailoring at this time|r.
*>You can craft ore into ingots and bright linen into bolts instead of buying them; buying is faster but expensive.
*>|cRXP_WARN_manually skip any items you do want to acquire, even just doing a few first crafts is good|r
*>|cRXP_WARN_Skip if you do not want to do midnight first crafts|r
*|cRXP_WARN_AUCTION HOUSE:|r
.collect 236963,93 
.collect 239701,34 
.collect 239702,14 
.collect 243600,14 
*|cRXP_WARN_VENDOR:|r
.collect 251665,120 
step
+If you are playing with War Mode enabled, complete your first crafts outside of major cities, as War Mode is disabled within city limits.
*|cRXP_WARN_You have to come back to train new skills it's only really recommended if you already have a plan|r.
*|cRXP_WARN_Skip this step manually|r
step << Alliance
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.achievementIncomplete 16641,1
.zone 2352 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step << Alliance
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.achievementIncomplete 16641,1
.goto 84,45.02,90.01,10,0
.goto 84,44.8,91.49,10,0
.goto 84,43.31,94.2,10,0
.goto 84,43.26,97.53
.zone 2239 >>Click on the |cRXP_PICK_Portal to Bel'ameth|r
step << Horde
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.achievementIncomplete 16641,1
.zone 2351 >>Teleport to a Neighbourhood with the House finder, not |T7252953:0|t[Teleport to Plot] then take the |cRXP_PICK_Stormwind Portal|r.
.link https://www.youtube.com/watch?v=uVkUB7z0njo >>CLICK HERE FOR VIDEO
.macro House Teleport, 975747 >>/run C_Housing.StartTutorial()
step << Horde
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.achievementIncomplete 16641,1
.goto 85,51.09,38.27
.zone 198 >>Click on the |cRXP_PICK_Portal to Mount Hyjal|r
step << Horde
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.achievementIncomplete 16641,1
.goto 198,62.47,22.73
.zone 2239 >>Click on the |cRXP_PICK_Portal to Bel'ameth|r
step
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.achievementComplete 16641,1
.zone 2023 >>Use [Dungeon Teleport: Nokhud Offensive] to Ohn'ahran Plains.
.use 396125
step
.goto 2023,40.04,61.26
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.zone 2023 >>Head to Ohn'ahran Plains to obtain the 5% Dreamsurge Buff before turning in the pop-up quests.
.aura 419239 >>Dreaming Winds Buff Acquired
step
.goto 2023,40.04,61.26
.isOnQuest 38934,31889,31919,31927,31966,31930,31952,31780,31850,31819,31851,54850,31781
.turnin 38934 >>Turn in Silas' Secret Stash
.turnin 31889 >>Turn in Battle Pet Tamers: Kalimdor Alliance
.turnin 31919 >>Turn in Battle Pet Tamers: Outland Alliance
.turnin 31927 >>Turn in Battle Pet Tamers: Northrend Alliance
.turnin 31966 >>Turn in Battle Pet Tamers: Cataclysm Alliance
.turnin 31930 >>Turn in Battle Pet Tamers: Pandaria Alliance
.turnin 31952 >>Turn in Battle Pet Tamers: Pandaria Horde
.turnin 31780 >>Turn in Old Macdonald
.turnin 31850 >>Turn in Eric Davidson
.turnin 31819 >>Turn in Dagra the Fierce
.turnin 31851 >>Turn in Bill Buckler
.turnin 54850 >>Turn in Operation: Troggageddon << Gnome
.turnin 31781 >>Turn in Lindsay
.macro 646148,Turnin Quest >>/run local info; for i=1, C_QuestLog.GetNumQuestLogEntries() do info = C_QuestLog.GetInfo(i) if info and info.isAutoComplete then ShowQuestComplete(info.questID) end end
step
#completewith next
#label Gryphons of a Feather
.achievementComplete 19030,1
.isQuestComplete 82809
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Squally|r.
.turnin 82809 >>Turn in Gryphons of a Feather
.target Squally
step
.achievementComplete 19030,1
#completewith Gryphons of a Feather
.isQuestComplete 82809
.goto 2023,40.04,61.26
.cast 420759 >>Summon the Pet:Squally
step
#requires Gryphons of a Feather
.achievementComplete 19030,1
.isQuestComplete 82809
.goto 2023,40.04,61.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Squally|r.
.turnin 82809 >>Turn in Gryphons of a Feather
.target Squally
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Midnight Intro Route
#displayname |cFFFCDC001|r - Midnight Intro
#internal
step
#include RestedXP Midnight\a) The Light's Summons
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Route
#displayname |cFFFCDC002|r - Eversong Woods
#internal
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightA-WhispersInTheTwilightB
step
.zoneskip 2393,1
.goto 2393,44.84,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drathen|r.
.train 471008 >>Train |T4620674:0|t[Midnight Fishing]
.train 7620,3
.target Drathen
step
.zoneskip 2393,1
.goto 2393,48.18,55.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amin|r.
.train 471011 >>Train |T4620671:0|t[Midnight Jewelcrafting]
.train 25229,3
.target Amin
step
.zoneskip 2393,1
.isQuestAvailable 89122
.goto 2393,50.71,57.7,10,0
.goto 2393,50.53,56.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Masterwork Chisel|r in the building.
.turnin 89122 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.zoneskip 2393,1
.isQuestAvailable 89127
.goto 2393,55.45,47.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vintage Soul Gem|r on the bottom floor.
.turnin 89127 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.zoneskip 2393,1
.goto 2393,48.2,54.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Galana|r.
.train 471015 >>Train |T4620681:0|t[Midnight Tailoring]
.train 3908,3
.target Galana
step
.train 471015,3
.goto 2393,48.25,54.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talmar|r.
.collect 251665,120 
.collect 251691,100 
.target Talmar
step
.zoneskip 2393,1
.goto 2393,48.01,53.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dolothos|r.
.train 471006 >>Train |T4620672:0|t[Midnight Enchanting]
.train 7411,3
.target Dolothos
step
.zoneskip 2393,1
.goto 2393,48.31,51.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Botanist Nathera|r.
.train 471009 >>Train |T4620675:0|t[Midnight Herbalism]
.train 2366,3
.target Botanist Nathera
step
.zoneskip 2393,1
.goto 2393,47.04,51.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Camberon|r.
.train 471003 >>Train |T4620669:0|t[Midnight Alchemy]
.train 2259,3
.target Camberon
step
.zoneskip 2393,1
.isQuestAvailable 89117
.goto 2393,47.75,51.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pristine Potion|r
.turnin 89117 >>Alchemy Knowledge Treasure
.train 471003,3
step
.zoneskip 2393,1
.goto 2393,46.92,51.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantasia|r.
.train 471010 >>Train |T4620669:0|t[Midnight Inscription]
.train 45357,3
.target Zantasia
step
.zoneskip 2393,1
.isQuestAvailable 89073
.goto 2393,49.11,75.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Songwriter's Pen|r
.turnin 89073 >>Inscription Knowledge Treasure
.train 471010,3
step
.zoneskip 2393,1
.goto 2393,43.65,51.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bemarrin|r.
.train 471004 >>Train |T4620670:0|t[Midnight Blacksmithing]
.train 2018,3
.target Bemarrin
step
.train 471004,3
.goto 2393,43.65,51.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eriden |r.
.collect 243060,81 
.target Eriden
step
.zoneskip 2393,1
.isQuestAvailable 89183
.goto 2393,49.17,61.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Master's Forgemace|r inside the building.
.turnin 89183 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2393,1
.goto 2393,42.59,52.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belil|r.
.train 471013 >>Train |T4620673:0|t[Midnight Mining]
.train 2575,3
.target Belil
step
.zoneskip 2393,1
.goto 2393,43.53,54.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danwe|r.
.train 471007 >>Train |T4620673:0|t[Midnight Engineering]
.train 4036,3
.target Danwe
step
.isQuestAvailable 89139
.goto 2393,51.21,57.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_What To Do When Nothing Works|r on the table.
.turnin 89139 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2393,1
.goto 2393,43.21,55.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyn|r.
.train 471014 >>Train |T4620673:0|t[Midnight Skinning]
.train 8613,3
.target Tyn
step
.zoneskip 2393,1
.isQuestAvailable 89171
.goto 2393,43.14,55.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Tanning Oil|r
.turnin 89171 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2393,1
.goto 2393,43.15,55.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talmar|r.
.train 471012 >>Train |T4620678:0|t[Midnight Leatherworking]
.train 2108,3
.target Talmar
step
.zoneskip 2393,1
.isQuestAvailable 89096
.goto 2393,44.77,56.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Artisan's Considered Order|r
.turnin 89096 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.goto 2393,45.00,55.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Flaresworn|r.
.accept 93723 >>Accept Crafters Needed
.target Captain Flaresworn
step
.goto 2393,44.99,55.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mar'nah|r.
.complete 93723,1 
.target Mar'nah





step
#include RestedXP Midnight\a) Whispers in the Twilight@PavedInAshA-WhispersInTheTwilightBb
step
.zoneskip 2393,1
.goto 2393,56.37,69.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sylann|r.
.train 471005 >>Train |T4620671:0|t[Midnight Cooking]
.target Sylann
step
#include RestedXP Midnight\a) Whispers in the Twilight@Captain Goldblade-arcane projector
step
.zoneskip 2393,1
.isQuestAvailable 89115
.goto 2393,49.11,75.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Freshly Plucked Peacebloom|r
.turnin 89115 >>Alchemy Knowledge Treasure
.train 471003,3
step
.zoneskip 2393,1
.isQuestAvailable 89184
.goto 2393,48.54,74.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silvermoon Blacksmith's Hammer|r
.turnin 89184 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2393,1
.isQuestAvailable 89133
.goto 2393,51.33,74.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_One Engineer's Junk|r inside the building.
.turnin 89133 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2393,1
.isQuestAvailable 89160
.goto 2393,49.01,75.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Simple Leaf Pruners|r.
.turnin 89160 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2393,1
.isQuestAvailable 89079
.goto 2393,35.78,61.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Really Nice Curtain|r
.turnin 89079 >>Tailoring Knowledge Treasure
.train 471015,3
step
.goto 2395,46.91,45.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.accept 87392 >>Accept Cargo Conspiracy
.target Lyssara Duskmourne
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightC-WhispersInTheTwilightD
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveB-PortDetectiveC
step
#hidewindow
#completewith HawkstridersShooedA
#loop
.goto 2395,46.39,45.6,45,0
.goto 2395,46.81,44.78,45,0
.goto 2395,47.36,46.57,45,0
.goto 2395,46.29,46.83,45,0
.goto 2395,44.5,43.84,45,0
.goto 2395,45.29,43.52,45,0
.goto 2395,45.95,44.56,45,0
+1
step
#completewith ErraticLightWyrmA
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r
.complete 86739,2 
.target Displaced Hawkstrider
step
#completewith ErraticLightWyrmA
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#label ErraticLightWyrmA
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
#completewith next
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#label HawkstridersShooedA
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightEA-WhispersInTheTwilightF
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveD-PortDetectiveDA
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightG-WhispersInTheTwilightZ
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Route 2
#displayname |cFFFCDC002|r - Eversong Woods
#internal
step
#include RestedXP Midnight\a) Shadowfall@ShadowfallA-ShadowfallB
step
#requires Windrunner Village
.goto 2395,38.96,61.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.accept 91493 >>Accept Not What I Ordered
.target Hathvelion Sungaze
step
#include RestedXP Midnight\a) Daggerspine Landing@DaggerspineLandingC-DaggerspineLandingZ
step
.isQuestAvailable 89074
.goto 2395,40.36,61.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Songwriter's Quill|r
.turnin 89074 >>Inscription Knowledge Treasure
.train 471010,3
step
#include RestedXP Midnight\a) Shadowfall@ShadowfallC-ShadowfallZ
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsA-RippleEffectsB
step
#include RestedXP Midnight\a) The Shadow Enclave 2
step
#include RestedXP Midnight\a) Blinding Sun@BlindingSunA-BlindingSunZ
step
#arrowtext Talk to |cRXP_FRIENDLY_Lady Liadrin|r\nand |cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Arator|r.
.turnin 86637 >>Turn in Anything but Reprieve
.accept 86639 >>Accept What's Left
.goto 2395,52.67,61.55
.target +Lady Liadrin
.accept 86638 >>Accept Choking Tendrils
.goto 2395,52.65,61.59
.target +Arator
step
.zoneskip 2395,1
.isQuestAvailable 89178
.goto 2395,48.37,75.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silvermoon Smithing Kit|r.
.turnin 89178 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2395,1
.isQuestAvailable 89069
.goto 2395,48.32,75.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spare Ink|r
.turnin 89069 >>Inscription Knowledge Treasure
.train 471010,3
step
.zoneskip 2395,1
.isQuestAvailable 89173
.goto 2395,48.4,76.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Thalassian Skinning Knife|r
.turnin 89173 >>Skinning Knowledge Treasure
.train 471014,3
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsC-RippleEffectsX
step
.goto 2393,52.55,78.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 91822 >>Accept The Regent's Request
.target Valeera Sanguinar
step
.goto 2393,52.78,77.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.target Naleidea Rivergleam
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsY-RippleEffectsZ
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Arator Route
#displayname |cFFFCDC003|r - Arator
#internal
step
#include RestedXP Midnight\a) The Path of Light@ThePathOfLightA-ThePathOfLightB
step
.isQuestAvailable 93384
.goto 2393,40.28,53.06
.enterScenario 3183,3187,3193 >>Enter the Collegiate Calamity Delve in Silvermoon.
step
.isQuestNotComplete 93384
.goto 2577,59.55,60.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.accept 93384 >>Accept Delver's Call: Collegiate Calamity
.target Agitated Tome
step
#include RestedXP Midnight\a) Collegiate Calamity@CollegiateCalamityA-CollegiateCalamityB
step
#arrowtext Fly UP\nTalk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,33.56,36.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.complete 91822,1 
.target Lor'themar Theron
.skipgossipid 135475
step
#include RestedXP Midnight\a) The Path of Light@ThePathOfLightC-ArathorEnd1


















step << Alliance
.reputation 730,neutral,<0,1

.isOnQuest 7162
.isQuestComplete 7162
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7162 >>Turn in Proving Grounds
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,friendly,<0,1
.isQuestAvailable 7168
.isQuestTurnedIn 7162
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7168 >>Turn in Rise and Be Recognized
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,honored,<0,1
.goto 25,44.67,46.2
.isQuestAvailable 7169
.isQuestTurnedIn 7168
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7169 >>Turn in Honored Amongst the Guard
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,revered,<0,1
.isQuestAvailable 7170
.isQuestTurnedIn 7169
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7170 >>Turn in Earned Reverence
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,exalted,<0,1
.isQuestAvailable 7171
.isQuestTurnedIn 7170
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7171 >>Turn in Legendary Heroes
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,exalted,<0,1
.isQuestAvailable 7172
.isQuestTurnedIn 7171
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7172 >>Turn in The Eye of Command
.target Lieutenant Haggerdin
step << Horde

.isOnQuest 7161
.isQuestComplete 7161
.reputation 729,friendly,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7161 >>Turn in Proving Grounds
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7163
.isQuestTurnedIn 7161
.reputation 729,friendly,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7163 >>Turn in Rise and Be Recognized
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7164
.isQuestTurnedIn 7163
.reputation 729,honored,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7164 >>Turn in Honored Amongst the Guard
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7165
.isQuestTurnedIn 7164
.reputation 729,revered,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7165 >>Turn in Earned Reverence
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7166
.isQuestTurnedIn 7165
.reputation 729,Exalted,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7166 >>Turn in Legendary Heroes
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7167
.isQuestTurnedIn 7166
.reputation 729,Exalted,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7167 >>Turn in The Eye of Command
.target Warmaster Laggrond
step
#include RestedXP Midnight\a) The Path of Light@AratorMonasteryA-ArathorEnd2
step
#include RestedXP Midnight\a) Regrets of the Past@ArathorStart3-ArathorEnd3
step
#include RestedXP Midnight\a) Regrets of the Past@ArathorStart4-ArathorEnd4
step
#completewith next
#label The Journey Ends
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91787 >>Turn in The Journey Ends
.target Lor'themar Theron






step
#completewith The Journey Ends
.zoneskip 2541,1
.goto 2541,50.67,90.10
.zone 2393 >>Leave the instance portal
step
#requires The Journey Ends
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91787 >>Turn in The Journey Ends
.target Lor'themar Theron
step
#arrowtext Talk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.goto 2393,57.72,68.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
.goto 2393,52.78,77.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93384 >>Turn in Delver's Call: Collegiate Calamity
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.target Naleidea Rivergleam
step
.isOnQuest 93784
.goto 2393,52.76,77.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93784 >>Turn in A Gnawing Void of Curiosity
.target Naleidea Rivergleam
step
.goto 2393,52.53,78.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telemancer Astrandis|r.
.turnin 93385 >>Turn in Delver's Call: The Darkway
.target Telemancer Astrandis
step
.goto 2393,57.64,68.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91787 >>Turn in The Journey Ends
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Route
#displayname |cFFFCDC004|r - Harandar
#internal
step << Monk
#include RestedXP Speed Leveling\a) Monk Quests












step << Monk
.zoneskip 379,1
.hs >>Hearth to Silvermoon City
*If on cooldown, take the Stormwind portal and then the Silvermoon portal in Stormwind.

step
#completewith Scouting Map
#hidewindow
+1
step
#completewith Scouting Map
#hidewindow
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
.acceptmap 94871
.accept 94871 >>Accept Eversong
step
#label Scouting Map
.goto 2393,45.61,70.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 89402 >>Accept Harandar
step
.zoneskip 2395,1
.isQuestAvailable 89107
.goto 2395,63.5,32.6
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Enchanting Rod|r
.turnin 89107 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2395,1
.isQuestAvailable 89158
.goto 2395,64.25,30.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Spade|r.
.turnin 89158 >>Herbalism Knowledge Treasure
.train 471009,3
step
#completewith PortDetectiveZ
#hidewindow
.xp 85
.skipto step,HarandarStartA
step
#include RestedXP Midnight\a) One Adventurous Hatchling@OneAdventurousHatchlingA-OneAdventurousHatchlingZ
step
#include RestedXP Midnight\a) Far Striding@FarStridingA-FarStridingB
step
.zoneskip 2395,1
.isQuestAvailable 89180
.goto 2395,56.84,40.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Metalworking Cheat Sheet|r inside the building.
.turnin 89180 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2395,1
.isQuestAvailable 89125
.goto 2395,56.63,40.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poorly Rounded Vial|r.
.turnin 89125 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.zoneskip 2395,1
.isQuestAvailable 89103
.goto 2395,60.76,53.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Everblazing Sunmote|r
.turnin 89103 >>Enchanting Knowledge Treasure
.train 471006,3






step
#include RestedXP Midnight\a) The Drinking Debt@TheDrinkingDebtB-TheDrinkingDebtD
step
#include RestedXP Midnight\a) Theft Tracking@TheftTrackingA-TheftTrackingB
step
.goto 2395,39.89,39.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r.
.accept 90544 >>Accept Thief at Bark
.timer 37.5,RP
.target Luma
step
.zoneskip 2395,1
.isQuestAvailable 89129
.goto 2395,39.65,38.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Gem Faceters|r.
.turnin 89129 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.goto 2395,40.52,44.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,1 
step
.zoneskip 2395,1
.isQuestAvailable 89135
.goto 2395,39.57,45.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Manual of Mistakes and Mishaps|r on the bottom floor.
.turnin 89135 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2395,1
.isQuestAvailable 89147
.goto 2395,37.99,45.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Solid Ore Punchers|r
.turnin 89147 >>Mining Knowledge Treasure
.train 471013,3
step
#title At the top
.goto 2395,39.46,45.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r on the upper floor.
.complete 87394,2 
step
.goto 2395,39.62,44.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,3 
step
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cute Doggo|r |cRXP_WARN_after the roleplay|r.
.complete 90544,1 
.timer 6.7,RP
.skipgossipid 133262
.target Luma
step
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r |cRXP_WARN_after the roleplay|r.
.turnin 90544 >>Turn in Thief at Bark
.target Luma
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveDB-PortDetectiveZ
step
#label HarandarStartA
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 89402 >>Turn in Harandar
.accept 86899 >>Accept The Root Cause
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86899,1 
.timer 25,RP
.skipgossipid 135559
.target Orweyna
step
#completewith next
#label HarandarPortal
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r after the roleplay.
.complete 86899,2 
step
#completewith HarandarPortal
.goto 2395,45.74,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Isilwen Starforge|r.
.vendor >>Vendor and Repair
.target Isilwen Starforge
step
#requires HarandarPortal
.goto 2395,45.13,46.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r after the roleplay.
.complete 86899,2 
step
#include RestedXP Midnight\a) Of Caves and Cradles@OfCavesAndCradlesB-OfCavesAndCradlesZ


step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,34.89,24.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86944 >>Turn in Seeds of the Rift
.accept 86930 >>Accept To Sow the Seed
.target Orweyna
step
.zoneskip 2413,1
.isQuestAvailable 89095
.goto 2413,36.11,25.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Leatherworking Knife|r
.turnin 89095 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.zoneskip 2413,1
.isQuestAvailable 89113
.goto 2413,34.78,24.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vial of Rootlands Oddities|r
.turnin 89113 >>Alchemy Knowledge Treasure
.train 471003,3
step
.zoneskip 2413,1
.isQuestAvailable 89159
.goto 2413,36.67,25.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightbloom Root|r.
.turnin 89159 >>Herbalism Knowledge Treasure
.train 471009,3
step
#include RestedXP Midnight\a) Call of the Goddess@CallOfTheGoddessA-QuartermasterA
step
#include RestedXP Midnight\a) Haranir Never Say Die@HaranirNeverSayDieA-HaranirNeverSayDieZ
step
#completewith TheLegendOfAlnsharanB
#hidewindow
.xp 86
.skipto step,HarandarKnowledgeLeatherworkingA
step
#include RestedXP Midnight\a) The Legend of Aln'sharan@TheLegendOfAlnsharanA-TheLegendOfAlnsharanB
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,69.69,26.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r
.turnin 90469 >>Turn in Carry On, Wayward Kuri
.target Kuri
step
#include RestedXP Midnight\a) Peril Among Petals@PerilAmongPetalsA-PerilAmongPetalsZ
step
#label HarandarKnowledgeLeatherworkingA
.zoneskip 2413,1
.isQuestAvailable 89094
.goto 2413,51.7,51.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Leatherworking Mallet|r
.turnin 89094 >>Leatherworking Knowledge Treasure
.train 471012,3
step
#include RestedXP Midnight\a) Call of the Goddess@Speak to the Innkeeper-Speak to the Innkeeper2
step
.zoneskip 2413,1
.isQuestAvailable 89155
.goto 2413,51.12,55.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Planting Shovel|r.
.turnin 89155 >>Herbalism Knowledge Treasure
.train 471009,3
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Route 2
#displayname |cFFFCDC004|r - Harandar
#internal
step
#include RestedXP Midnight\a) Call of the Goddess@DelversCallA-CallOfTheGoddessB
step
.isQuestAvailable 93421
.goto 2413,70.35,64.81,15,0
.goto 2413,71.01,65.6
.enterScenario 3097,3098,3099 >>Enter The Grudge Pit Delve in Harandar |cRXP_WARN_in a cave|r.
step
#include RestedXP Midnight\a) The Grudge Pit@GrudgeA-GrudgeZ
step
#completewith YouStrong?End1
#hidewindow
.xp 86
.skipto step,CallOfTheGoddessC
step
#completewith YouStrong?End1
+|cRXP_WARN_Complete this step if you can't continue this storyline because of a bug|r
.skipto step,YouStrongSkip
step
#include RestedXP Midnight\a) The Grudge Pit 2@YouStrong?Start1-YouStrong?End1
step
#label YouStrongSkip
.zoneskip 2413,1
.isQuestAvailable 89182
.goto 2413,66.35,50.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rutaani Floratender's Sword|r on the mushroom.
.turnin 89182 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2413,1
.isQuestAvailable 89081
.goto 2413,69.76,51.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wooden Weaving Sword|r
.turnin 89081 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2413,1
.isQuestAvailable 89078
.goto 2413,70.57,50.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Child's Stuffy|r in the building.
.turnin 89078 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2413,1
.isQuestAvailable 89105
.goto 2413,65.73,50.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primal Essence Orb|r on the mushroom.
.turnin 89105 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2413,1
.isQuestAvailable 89157
.goto 2413,76.14,51.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Harvester's Sickle|r.
.turnin 89157 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2413,1
.isQuestAvailable 89168
.goto 2413,69.53,49.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primal Hide|r in the cave.
.turnin 89168 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2413,1
.isQuestAvailable 89166
.goto 2413,76.08,51.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightbloom Afflicted Hide|r
.turnin 89166 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2413,1
.isQuestAvailable 89104
.goto 2413,37.75,65.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entropic Shard|r
.turnin 89104 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2413,1
.isQuestAvailable 89162
.goto 2413,38.33,67.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bloomed Bud|r.
.turnin 89162 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2413,1
.isQuestAvailable 89151
.goto 2413,38.85,65.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spare Expedition Torch|r
.turnin 89151 >>Mining Knowledge Treasure
.train 471013,3
step
#include RestedXP Midnight\a) Call of the Goddess@CallOfTheGoddessC-CallOfTheGoddessZ
step
#include RestedXP Midnight\a) Emergence@EmergenceA-EmergenceY
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Zul'Aman Route
#displayname |cFFFCDC005|r - Zul'Aman
#internal
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandA-DisWasOurLandAA
step
#include RestedXP Midnight\a) The Regent's Request@TheRegentsRequestB-TheRegentsRequestC
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandAB-DisWasOurLandBA
step
.goto 2395,63.81,81.9
>>Pick up the |cRXP_PICK_Skyriding Glyph|r during the roleplay
*Use |T4640490:0|t[Surge Forward] for a speed boost
*Use |T4640498:0|t[Skyward Ascent] for an uplift.
*Use |T4640489:0|t[Second Wind] to renew vigor charges.
*Use |T4640477:0|t[Whirling Surge] on cooldown.
.achievement 61581,9
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandBBA-DisWasOurLandB
step
.isQuestAvailable 93409
.goto 2395,63.8,80.02
.enterScenario 3117,3147,3148 >>Enter the Atal'Aman Delve inside the Amani Pass.
step
#include RestedXP Midnight\a) Atal'Aman@AtalAmanA-AtalAmanB
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandC-GoodwillTourA
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandCA-Important Amani
step
#include RestedXP Midnight\a) Dis Was Our Land@ElderDoruA-Break the Blade
step
.isQuestAvailable 89085
.goto 2437,40.53,49.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Artisan's Cover Comb|r in the cave.
.turnin 89085 >>Tailoring Knowledge Treasure
.train 471015,3
step
.isQuestAvailable 89106
.goto 2437,40.42,51.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loa-Blessed Dust|r
.turnin 89106 >>Enchanting Knowledge Treasure
.train 471006,3
step
.isQuestAvailable 89114
.goto 2437,40.39,51.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vial of Zul'Aman Oddities|r
.turnin 89114 >>Alchemy Knowledge Treasure
.train 471003,3
step
.isQuestAvailable 89068
.goto 2437,40.49,49.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Leather-Bound Techniques|r
.turnin 89068 >>Inscription Knowledge Treasure
.train 471010,3
step
.isQuestAvailable 89149
.goto 2536,33.31,65.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Expert's Chisel|r
.turnin 89149 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89170
.goto 2437,40.4,36.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Tanning Oil|r
.turnin 89170 >>Skinning Knowledge Treasure
.train 471014,3
step
#include RestedXP Midnight\a) Dis Was Our Land@Heart of the Amani-Heart of the Amani
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandE-DisWasOurLandZ
step
.goto 2437,43.80,68.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 86653 >>Accept The Path of the Amani
.target Zul'jarra
step
.goto 2437,43.15,67.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Dar'rak|r
.accept 93051 >>Accept The Final Exam
.target Recruit Dar'rak
step
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r.
.complete 93051,1 
.skipgossipid 137188
.target Ri'kari
step
.goto 2437,43.83,64.98
>>Kill |cRXP_ENEMY_Recruit Dar'rak|r
.complete 93051,2 
.mob Recruit Dar'rak
step
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r
.turnin 93051 >>Turn in The Final Exam
.target Ri'kari
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Vakala|r
.goto 2437,45.05,68.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vakala|r.
.accept 94867 >>Accept Lost in Atal'Abasi
.target Vakala
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.accept 92450 >>Accept Growing Up is Hard
.target Ani
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
.goto 2437,45.35,69.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.accept 89565 >>Accept The Path of Mourning
.target Chana
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.54,69.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r.
.accept 93047 >>Accept Butchery Basics
.target Gijaniji
step
#include RestedXP Midnight\a) No Fear@NoFearB-NoFearBA
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r
.goto 2437,48.11,67.61
>>Use the |T237554:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92451,2 
.timer 6,RP
step
.isOnQuest 92451
#arrowtext |cRXP_ENEMY_WAIT 'TIL TIMER ENDS|r
.goto 2437,48.11,67.61,10,0
.goto 2437,51.63,70.80
.countdown 6 >>You can leave when this timer ends
.complete 92451,3 
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyB-PathOfDeHasheyC
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyD-PathOfDeHasheyE
step
#completewith SawdustToSawdustZ
#hidewindow
.xp 87.5
.skipto step,PathOfDeHasheyF
step
#include RestedXP Midnight\a) Sawdust to Sawdust@SawdustToSawdustA-SawdustToSawdustZ
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyF-PathOfDeHasheyG
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyH-PathOfDeHasheyX


step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyZ-PathOfDeHasheyZ
step
#include RestedXP Midnight\a) Where War Slumbers@SlumbersA-SlumbersB
step
.zoneskip 2437,1
.isQuestAvailable 89089
.goto 2437,33.08,78.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Leatherworker's Tool|r in the cave.
.turnin 89089 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.zoneskip 2437,1
.isQuestAvailable 89172
.goto 2437,33.08,79.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Skinning Knife|r in the cave.
.turnin 89172 >>Skinning Knowledge Treasure
.train 471014,3
step
#include RestedXP Midnight\a) Where War Slumbers@SlumbersC-SlumbersD
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,31.58,83.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 86683 >>Accept Hash'ey Away
.target Zul'jarra
step
.zoneskip 2437,1
.isQuestAvailable 89091
.goto 2437,30.76,84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prestigiously Racked Hide|r in the building.
.turnin 89091 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.zoneskip 2437,1
.isQuestAvailable 89140
.goto 2437,34.21,87.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handy Wrench|r
.turnin 89140 >>Engineering Knowledge Treasure
.train 471007,3












step
#include RestedXP Midnight\a) De Amani Never Die@DeAmaniNeverDieA-DeAmaniNeverDieX
step
.isQuestAvailable 93410
.goto 2437,25.41,84.52
.enterScenario 3123,3124,3125 >>Enter the Twilight Crypts in Zul'aman.
step
#include RestedXP Midnight\a) Twilight Crypts@TwilightCryptsA-TwilightCryptsB











step

.goto 2437,45.44,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93410 >>Turn in Delver's Call: Twilight Crypts
.turnin 93409 >>Turn in Delver's Call: Atal'Aman
.target Tavikko
step
#include RestedXP Midnight\a) De Amani Never Die@DeAmaniNeverDieY-DeAmaniNeverDieZ
step
.zoneskip 2536,1
.isQuestAvailable 89138
.goto 2536,65.15,34.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Offline Helper Bot|r
.turnin 89138 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2536,1
.isQuestAvailable 89100
.goto 2536,48.78,22.5
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Enchanted Amani Mask|r
.turnin 89100 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2536,1
.isQuestAvailable 89116
.goto 2536,49.09,23.15
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Measured Ladle|r
.turnin 89116 >>Alchemy Knowledge Treasure
.train 471003,3
step
#completewith NoFearZ
#hidewindow
.xp 88.5
.skipto step,ZulAmanCampaignSpeedrunEndA
step
#include RestedXP Midnight\a) The Loa of Murlocs@TheLoaOfMurlocsA-TheLoaOfMurlocsZ
step
#include RestedXP Midnight\a) Vengeance for Tolbani@VengeanceForTolbaniA-VengeanceForTolbaniB
step
#include RestedXP Midnight\a) No Fear@NoFearD-NoFearE
step
#include RestedXP Midnight\a) Vengeance for Tolbani@VengeanceForTolbaniC-VengeanceForTolbaniZ
step
#include RestedXP Midnight\a) No Fear@NoFearF-NoFearF
step
.goto 2437,45.87,72.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.turnin 89565 >>Turn in The Path of Mourning
.accept 89503 >>Accept Somber Siblings
.target Chana
step
#completewith SorrowingKinB
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#include RestedXP Midnight\a) Sorrowing Kin@SorrowingKinA-SorrowingKinB
step
#loop
.goto 2437,46.27,72.15,35,0
.goto 2437,47.1,73.67,35,0
.goto 2437,46.49,75.39,35,0
.goto 2437,45.26,74.18,35,0
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#include RestedXP Midnight\a) Sorrowing Kin@SorrowingKinC-SorrowingKinZ
step
#arrowtext Click on the |cRXP_PICK_Boar|r
.goto 2437,45.54,69.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boar|r.
.complete 93047,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.58,69.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r
.turnin 93047 >>Turn in Butchery Basics
.target Gijaniji
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.turnin -92453 >>Turn in Fearless
.target Ani
step
#label ZulAmanCampaignSpeedrunEndA
.goto 2437,45.44,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93410 >>Turn in Delver's Call: Twilight Crypts
.turnin 93409 >>Turn in Delver's Call: Atal'Aman
.target Tavikko
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Voidstorm Route 1
#displayname |cFFFCDC006|r - Voidstorm
#internal

step
#completewith next
#label Reports Returned
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91087 >>Turn in Reports Returned
.turnin 91827 >>Turn in No Loose Ends
.target Lor'themar Theron






step
#completewith Reports Returned
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
*If on cooldown use your Dalaran Hearthstone or Stormwind/Orgrimmar cloaks or other ways to get to the main city and use the Silvermoon portal.
.use 253629






step
#requires Reports Returned
.goto 2541,50.67,90.10,-1
.goto 2393,45.45,70.32,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91087 >>Turn in Reports Returned
.turnin 91827 >>Turn in No Loose Ends
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.goto 2393,45.37,70.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Koruth Mountainfist|r.
.accept 91854 >>Accept Deepening Shadows
.target Commander Koruth Mountainfist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sin'dorei Fruit Vendor|r
.goto 2393,47.18,59.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sin'dorei Fruit Vendor|r.
.complete 91854,1 
.skipgossipid 135112
.target Sin'dorei Fruit Vendor
step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doomsayers|r.
*|cRXP_WARN_Kill the ones turning into |cRXP_ENEMY_Cultists|r|r.
*|cRXP_WARN_NOTE:|r They have a lot of HP. You can gamble by flying to the next one of the current one starts casting.
.complete 91854,3 
.skipgossipid 135048
.target Doomsayer
.target Twilight's Blade Cultist
.mob Twilight's Blade Cultist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Doomsayers|r and |cRXP_FRIENDLY_Orweyna|r
.goto 2393,46.54,58.88,15,0
.goto 2393,45.64,58.05,15,0
.goto 2393,43.86,58.41,15,0
.goto 2393,44.83,61.91,15,0
.goto 2393,42.31,63.93,15,0
.goto 2393,42.26,68.14,15,0
.goto 2393,36.60,68.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 86898 >>Turn in Rise of the Haranir
.accept 93651 >>Accept The Blinding Vale: Lightbloom Roots
.target Orweyna
step
#loop
#arrowtext Talk to\n|cRXP_FRIENDLY_Doomsayers|r
.goto 2393,42.30,72.64,15,0
.goto 2393,42.77,76.78,15,0
.goto 2393,46.19,76.57,15,0
.goto 2393,48.06,76.95,15,0
.goto 2393,51.54,70.19,15,0
.goto 2393,46.54,58.88,15,0
.goto 2393,45.64,58.05,15,0
.goto 2393,43.86,58.41,15,0
.goto 2393,44.83,61.91,15,0
.goto 2393,42.31,63.93,15,0
.goto 2393,42.26,68.14,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doomsayers|r.
*|cRXP_WARN_Kill the ones turning into |cRXP_ENEMY_Cultists|r|r.
*|cRXP_WARN_NOTE:|r They have a lot of HP. You can gamble by flying to the next one of the current one starts casting.
.complete 91854,3 
.skipgossipid 135048
.target Doomsayer
.target Twilight's Blade Cultist
.mob Twilight's Blade Cultist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Hagar|r
.goto 2393,36.57,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Hagar|r.
*|cRXP_WARN_Skip The War Beyond the Roots in Early Access|r
.accept 91084 >>Accept Looming Shadows

.target Elder Hagar
step
.zoneskip 2393,1
.isQuestAvailable 89177
.goto 2393,26.98,60.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Deconstructed Forge Techniques|r inside the building.
.turnin 89177 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2393,1
.isQuestAvailable 89079
.goto 2393,35.78,61.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Really Nice Curtain|r
.turnin 89079 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2393,1
.isQuestAvailable 89084
.goto 2393,31.8,68.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Particularly Enchanting Tablecloth|r
.turnin 89084 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2393,1
.isQuestAvailable 89124
.goto 2393,28.62,46.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dual-Function Magnifiers|r.
.turnin 89124 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Venel Lightblood|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,45.77,81.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Venel Lightblood|r.
.complete 91854,2 
.skipgossipid 135203
.skipgossipid 135204
.target Commander Venel Lightblood
step

#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.goto 2393,45.37,70.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Koruth Mountainfist|r.
.turnin 91854 >>Turn in Deepening Shadows
.target Commander Koruth Mountainfist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.accept 91967 >>Accept You Know This Evil?
.target Lor'themar Theron
step
.isOnQuest 91084
#optional
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
*|cRXP_WARN_This unlocks the Haranir Race; not available in early access skip it for now|r
.turnin 91084 >>Turn in Looming Shadow
.turnin 95324 >>Turn in The War Beyond the Roots
.timer 55,RP
.target Lor'themar Theron
step
#optional
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
*|cRXP_WARN_This unlocks the Haranir Race; not available in early access skip it for now|r
.turnin 95324 >>Turn in The War Beyond the Roots
.timer 55,RP
.target Lor'themar Theron
step
#include RestedXP Midnight\a) Darkening Sky@DarkeningSkyD-DarkeningSkyZ
step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssA-IntoTheAbyssB
step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssC-IntoTheAbyssD







step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssE-IntoTheAbyssF







step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssG-IntoTheAbyssZ
step
.zoneskip 2405,1
.isQuestAvailable 89156
.goto 2405,34.68,56.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Peculiar Lotus|r.
.turnin 89156 >>Herbalism Knowledge Treasure
.train 471009,3
step
#include RestedXP Midnight\a) The Night's Veil@TheNightsVeilA-TheNightsVeilB
step
.zoneskip 2405,1
.isQuestAvailable 89102
.goto 2405,35.47,58.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pure Void Crystal|r
.turnin 89102 >>Enchanting Knowledge Treasure
.train 471006,3
step
#include RestedXP Midnight\a) The Night's Veil
step
#include RestedXP Midnight\a) Dawn of Reckoning@DawnOfReckoningA-DawnOfReckoningX
step
#label NormalRouteEndA
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Voidstorm Route 2
#displayname |cFFFCDC006|r - Voidstorm
#internal

step
#completewith next
#label Sanctum Delve
#hidewindow
.complete 86521,4 
step
#completewith Sanctum Delve
#arrowtext Leave the instance
.zone 2405 >>Click the macro under the "Active Items Frame"
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#requires Sanctum Delve
.isQuestAvailable 93427
.goto 2405,54.87,46.7,10,0
.goto 2405,54.79,47.26
.enterScenario 3194,3201,3204 >>Enter the Sunkiller Sanctum Delve in Voidstorm.
step
#include RestedXP Midnight\a) Sunkiller Sanctum@SanctumA-SanctumB
step
.zoneskip 2444,1
.isQuestAvailable 89181
.goto 2444,30.52,69.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Voidstorm Defense Spear|r inside the building.
.turnin 89181 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2444,1
.isQuestAvailable 89093
.goto 2444,53.75,51.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Patterns: Beyond the Void|r in the building.
.turnin 89093 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.isQuestAvailable 89090
.goto 2405,34.72,56.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereal Leatherworking Knife|r.
.turnin 89090 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.isQuestAvailable 89083
.goto 2444,61.4,85.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Satin Throw Pillow|r in the building.
.turnin 89083 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2444,1
.isQuestAvailable 89092
.goto 2444,62.01,83.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book of Sin'dorei Stitches|r in the building.
.turnin 89092 >>Tailoring Knowledge Treasure
.train 471015,3
step
.isQuestAvailable 89139
.goto 2393,51.21,57.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_What To Do When Nothing Works|r
.turnin 89139 >>Engineering Knowledge Treasure
.train 471007,3
step
.isQuestAvailable 89139
.goto 2393,51.21,57.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_What To Do When Nothing Works|r
.turnin 89139 >>Engineering Knowledge Treasure
.train 471007,3
step
.isQuestAvailable 89127
.goto 2393,55.45,47.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vintage Soul Gem|r.
.turnin 89127 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.isQuestAvailable 89124
.goto 2393,28.62,46.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dual-Function Magnifiers|r.
.turnin 89124 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.isQuestAvailable 89124
.goto 2393,28.62,46.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dual-Function Magnifiers|r.
.turnin 89124 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.isQuestAvailable 89112
.goto 2444,41.97,40.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vial of Voidstorm Oddities|r
.turnin 89112 >>Alchemy Knowledge Treasure
.train 471003,3
step
.isQuestAvailable 89067
.goto 2444,60.7,84.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void-Touched Quill|r in the building.
.turnin 89067 >>Inscription Knowledge Treasure
.train 471010,3
step
.isQuestAvailable 89150
.goto 2405,41.84,38.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Star Metal Deposit|r
.turnin 89150 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89144
.goto 2444,30.48,69.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Miner's Guide to Voidstorm|r
.turnin 89144 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89148
.goto 2444,28.76,38.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Glimmering Void Pearl|r
.turnin 89148 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89146
.goto 2393,49.11,75.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lost Voidstorm Satchel|r
.turnin 89146 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89146
.goto 2444,54.24,51.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lost Voidstorm Satchel|r
.turnin 89146 >>Skinning Knowledge Treasure
.train 471014,3
step
.goto 2405,51.35,67.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perodius|r.
.turnin 93427 >>Turn in Delver's Call: Sunkiller Sanctum
.target Perodius
step
#include RestedXP Midnight\a) Dawn of Reckoning@DawnOfReckoningY-DawnOfReckoningZ
step
#completewith ThiefAtBarkA
#hidewindow
.xp 90
.skipto step,NormalRouteEndA
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tarenar Sunstrike|r
.goto 2393,57.64,68.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
#include RestedXP Midnight\a) Fear and Fel@FearAndFelA-FearAndFelC
step
#arrowtext Talk to |cRXP_FRIENDLY_Sarvi|r
.goto 2393,54.53,61.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarvi|r.
.accept 90669 >>Accept Gold is Gold
.target Sarvi
step
#include RestedXP Midnight\a) Fear and Fel@FearAndFelD-FearAndFelE
step
#include RestedXP Midnight\a) Tailor Troubles@TailorTroublesA-TailorTroublesB
step
#include RestedXP Midnight\a) Lesser Evil@LesserEvilB-LesserEvilC
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Aradis|r
.goto 2393,54.11,33.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Aradis|r.
.turnin 89199 >>Turn in A Small Task
.target Magister Aradis
step
#include RestedXP Midnight\a) Scootin' Through Silvermoon@ScootinThroughSilvermoonA-ScootinThroughSilvermoonZ
step
.goto 2393,33.25,74.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.accept 94396 >>Accept Down a Peg
.target Instructor Thalendir
step
.goto 2393,33.23,74.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.accept 94393 >>Accept Career Counseling
.target Instructor Thalendir
step
#include RestedXP Midnight\a) How to Train Your Protege@HowToTrainYourProtegeB-HowToTrainYourProtegeC
step
#include RestedXP Midnight\a) How to Train Your Protege@HowToTrainYourProtegeD-HowToTrainYourProtegeX
step
#include RestedXP Midnight\a) Aspiring Academic@AspiringAcademicB-AspiringAcademicZ
step
#include RestedXP Midnight\a) One Adventurous Hatchling@OneAdventurousHatchlingA-OneAdventurousHatchlingZ
step
#include RestedXP Midnight\a) Far Striding@FarStridingA-FarStridingB
step
#include RestedXP Midnight\a) The Drinking Debt@TheDrinkingDebtB-TheDrinkingDebtD
step
#include RestedXP Midnight\a) Theft Tracking@TheftTrackingA-TheftTrackingB
step
.goto 2395,39.89,39.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r.
.accept 90544 >>Accept Thief at Bark
.timer 37.5,RP
.target Luma
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveA-PortDetectiveC
step
.goto 2395,40.52,44.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,1 
step
#title At the top
.goto 2395,39.46,45.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,2 
step
.goto 2395,39.62,44.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,3 
step
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cute Doggo|r |cRXP_WARN_after the roleplay|r.
.complete 90544,1 
.timer 6.7,RP
.skipgossipid 133262
.target Luma
step
#label ThiefAtBarkA
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r |cRXP_WARN_after the roleplay|r.
.turnin 90544 >>Turn in Thief at Bark
.target Luma
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveDB-PortDetectiveZ
step
#label NormalRouteEndA
#hidewindow
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Midnight Intro Route Delve
#displayname |cFFFCDC001|r - Midnight Intro
#internal
step
#include RestedXP Midnight\a) The Light's Summons
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Route Delve
#displayname |cFFFCDC002|r - Eversong Woods
#internal
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightA-WhispersInTheTwilightB
step
.zoneskip 2393,1
.goto 2393,44.84,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drathen|r.
.train 471008 >>Train |T4620674:0|t[Midnight Fishing]
.train 7620,3
.target Drathen
step
.zoneskip 2393,1
.goto 2393,48.18,55.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amin|r.
.train 471011 >>Train |T4620671:0|t[Midnight Jewelcrafting]
.train 25229,3
.target Amin
step
.zoneskip 2393,1
.isQuestAvailable 89122
.goto 2393,50.71,57.7,10,0
.goto 2393,50.53,56.58
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Masterwork Chisel|r in the building.
.turnin 89122 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.zoneskip 2393,1
.isQuestAvailable 89127
.goto 2393,55.45,47.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vintage Soul Gem|r.
.turnin 89127 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.zoneskip 2393,1
.goto 2393,48.2,54.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Galana|r.
.train 471015 >>Train |T4620681:0|t[Midnight Tailoring]
.train 3908,3
.target Galana
step
.zoneskip 2393,1
.train 471015,3
.goto 2393,48.25,54.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talmar|r.
.collect 251665,120 
.collect 251691,100 
.target Talmar
step
.zoneskip 2393,1
.goto 2393,48.01,53.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dolothos|r.
.train 471006 >>Train |T4620672:0|t[Midnight Enchanting]
.train 7411,3
.target Dolothos
step
.zoneskip 2393,1
.goto 2393,48.31,51.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Botanist Nathera|r.
.train 471009 >>Train |T4620675:0|t[Midnight Herbalism]
.train 2366,3
.target Botanist Nathera
step
.zoneskip 2393,1
.goto 2393,47.04,51.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Camberon|r.
.train 471003 >>Train |T4620669:0|t[Midnight Alchemy]
.train 2259,3
.target Camberon
step
.zoneskip 2393,1
.isQuestAvailable 89117
.goto 2393,47.75,51.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pristine Potion|r
.turnin 89117 >>Alchemy Knowledge Treasure
.train 471003,3
step
.zoneskip 2393,1
.goto 2393,46.92,51.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zantasia|r.
.train 471010 >>Train |T4620669:0|t[Midnight Inscription]
.train 45357,3
.target Zantasia
step
.zoneskip 2393,1
.isQuestAvailable 89073
.goto 2393,49.11,75.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Songwriter's Pen|r
.turnin 89073 >>Inscription Knowledge Treasure
.train 471010,3
step
.zoneskip 2393,1
.goto 2393,43.65,51.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bemarrin|r.
.train 471004 >>Train |T4620670:0|t[Midnight Blacksmithing]
.train 2018,3
.target Bemarrin
step
.zoneskip 2393,1
.train 471004,3
.goto 2393,43.65,51.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eriden |r.
.collect 243060,81 
.target Eriden
step
.zoneskip 2393,1
.isQuestAvailable 89183
.goto 2393,49.17,61.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Master's Forgemace|r inside the building.
.turnin 89183 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2393,1
.goto 2393,42.59,52.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belil|r.
.train 471013 >>Train |T4620673:0|t[Midnight Mining]
.train 2575,3
.target Belil
step
.zoneskip 2393,1
.goto 2393,43.53,54.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danwe|r.
.train 471007 >>Train |T4620673:0|t[Midnight Engineering]
.train 4036,3
.target Danwe
step
.zoneskip 2393,1
.isQuestAvailable 89139
.goto 2393,51.21,57.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_What To Do When Nothing Works|r
.turnin 89139 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2393,1
.goto 2393,43.21,55.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyn|r.
.train 471014 >>Train |T4620673:0|t[Midnight Skinning]
.train 8613,3
.target Tyn
step
.zoneskip 2393,1
.isQuestAvailable 89171
.goto 2393,43.14,55.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Tanning Oil|r
.turnin 89171 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2393,1
.goto 2393,43.15,55.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talmar|r.
.train 471012 >>Train |T4620678:0|t[Midnight Leatherworking]
.train 2108,3
.target Talmar
step
.zoneskip 2393,1
.isQuestAvailable 89096
.goto 2393,44.77,56.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Artisan's Considered Order|r
.turnin 89096 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.goto 2393,45.00,55.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Flaresworn|r.
.accept 93723 >>Accept Crafters Needed
.target Captain Flaresworn
step
.goto 2393,44.99,55.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mar'nah|r.
.complete 93723,1 
.target Mar'nah





step
#include RestedXP Midnight\a) Whispers in the Twilight@PavedInAshA-WhispersInTheTwilightBb
step
.zoneskip 2393,1
.goto 2393,56.37,69.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sylann|r.
.train 471005 >>Train |T4620671:0|t[Midnight Cooking]
.target Sylann
step
#include RestedXP Midnight\a) Whispers in the Twilight@Captain Goldblade-arcane projector
step
.zoneskip 2393,1
.isQuestAvailable 89115
.goto 2393,49.11,75.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Freshly Plucked Peacebloom|r
.turnin 89115 >>Alchemy Knowledge Treasure
.train 471003,3
step
.zoneskip 2393,1
.isQuestAvailable 89184
.goto 2393,48.54,74.38
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silvermoon Blacksmith's Hammer|r
.turnin 89184 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2393,1
.isQuestAvailable 89133
.goto 2393,51.33,74.46
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_One Engineer's Junk|r
.turnin 89133 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2393,1
.isQuestAvailable 89160
.goto 2393,49.01,75.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Simple Leaf Pruners|r.
.turnin 89160 >>Herbalism Knowledge Treasure
.train 471009,3
step
.goto 2395,46.91,45.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.accept 87392 >>Accept Cargo Conspiracy
.target Lyssara Duskmourne
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightC-WhispersInTheTwilightZ
step
#include RestedXP Midnight\a) Shadowfall@ShadowfallA-ShadowfallZ
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsA-RippleEffectsB
step
#include RestedXP Midnight\a)The Shadow Enclave 2
step
#arrowtext Talk to |cRXP_FRIENDLY_Lady Liadrin|r\nand |cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Arator|r.
.turnin 86637 >>Turn in Anything but Reprieve
.accept 86639 >>Accept What's Left
.goto 2395,52.67,61.55
.target +Lady Liadrin
.accept 86638 >>Accept Choking Tendrils
.goto 2395,52.65,61.59
.target +Arator
step
.zoneskip 2395,1
.isQuestAvailable 89178
.goto 2395,48.37,75.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silvermoon Smithing Kit|r.
.turnin 89178 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2395,1
.isQuestAvailable 89069
.goto 2395,48.32,75.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spare Ink|r
.turnin 89069 >>Inscription Knowledge Treasure
.train 471010,3
step
.zoneskip 2395,1
.isQuestAvailable 89173
.goto 2395,48.4,76.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Thalassian Skinning Knife|r
.turnin 89173 >>Skinning Knowledge Treasure
.train 471014,3
step
#arrowtext Talk to |cRXP_FRIENDLY_Lady Liadrin|r\nand |cRXP_FRIENDLY_Arator|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r and |cRXP_FRIENDLY_Arator|r.
.turnin 86637 >>Turn in Anything but Reprieve
.accept 86639 >>Accept What's Left
.goto 2395,52.67,61.55
.target +Lady Liadrin
.accept 86638 >>Accept Choking Tendrils
.goto 2395,52.65,61.59
.target +Arator
step
.zoneskip 2395,1
.isQuestAvailable 89178
.goto 2395,48.37,75.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Silvermoon Smithing Kit|r.
.turnin 89178 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2395,1
.isQuestAvailable 89069
.goto 2395,48.32,75.55
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spare Ink|r
.turnin 89069 >>Inscription Knowledge Treasure
.train 471010,3
step
.zoneskip 2395,1
.isQuestAvailable 89173
.goto 2395,48.4,76.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Thalassian Skinning Knife|r
.turnin 89173 >>Skinning Knowledge Treasure
.train 471014,3
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsC-RippleEffectsZ
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Arator Route Delve
#displayname |cFFFCDC003|r - Arator
#internal
step
#include RestedXP Midnight\a) The Path of Light@ThePathOfLightA-ThePathOfLightB
step
.isQuestAvailable 93384
.isQuestNotComplete 93384
.goto 2393,40.28,53.06
.enterScenario 3183,3187,3193 >>Enter the Collegiate Calamity Delve in Silvermoon.
step
#include RestedXP Midnight\a) Collegiate Calamity@CollegiateCalamityA-CollegiateCalamityB
step
#include RestedXP Midnight\a) The Darkway
step
#include RestedXP Midnight\a) The Path of Light@ThePathOfLightC-ArathorEnd1


















step << Alliance
.reputation 730,neutral,<0,1

.isOnQuest 7162
.isQuestComplete 7162
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7162 >>Turn in Proving Grounds
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,friendly,<0,1
.isQuestAvailable 7168
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7168 >>Turn in Rise and Be Recognized
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,honored,<0,1
.goto 25,44.67,46.2
.isQuestAvailable 7169
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7169 >>Turn in Honored Amongst the Guard
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,revered,<0,1
.isQuestAvailable 7170
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7170 >>Turn in Earned Reverence
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,exalted,<0,1
.isQuestAvailable 7171
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7171 >>Turn in Legendary Heroes
.target Lieutenant Haggerdin
step << Alliance
.reputation 730,exalted,<0,1
.isQuestAvailable 7172
.goto 25,44.67,46.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Haggerdin|r.
.turnin 7172 >>Turn in The Eye of Command
.target Lieutenant Haggerdin
step << Horde

.isOnQuest 7161
.isQuestComplete 7161
.reputation 729,friendly,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7161 >>Turn in Proving Grounds
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7163
.reputation 729,friendly,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7163 >>Turn in Rise and Be Recognized
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7164
.reputation 729,honored,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7164 >>Turn in Honored Amongst the Guard
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7165
.reputation 729,revered,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7165 >>Turn in Earned Reverence
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7166
.reputation 729,Exalted,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7166 >>Turn in Legendary Heroes
.target Warmaster Laggrond
step << Horde
.isQuestAvailable 7167
.reputation 729,Exalted,<0,1
.goto 25,57.79,33.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmaster Laggrond|r.
.turnin 7167 >>Turn in The Eye of Command
.target Warmaster Laggrond
step
#include RestedXP Midnight\a) The Path of Light@AratorMonasteryA-ArathorEnd2
step
#include RestedXP Midnight\a) Regrets of the Past@ArathorStart3-ArathorEnd3
step
#include RestedXP Midnight\a) Regrets of the Past@ArathorStart4-ArathorEnd4
step
#completewith next
#label The Journey Ends
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91787 >>Turn in The Journey Ends
.target Lor'themar Theron






step
#completewith The Journey Ends
.zoneskip 2541,1
.goto 2541,50.67,90.10
.zone 2393 >>Leave the instance portal
step
#requires The Journey Ends
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,53.3,66.27,10,0
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91787 >>Turn in The Journey Ends
.target Lor'themar Theron
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Route Delve
#displayname |cFFFCDC004|r - Harandar
#internal
step << Monk
#include RestedXP Speed Leveling\a) Monk Quests












step << Monk
.zoneskip 379,1
.hs >>Hearth to Silvermoon City
*If on cooldown, take the Stormwind portal and then the Silvermoon portal in Stormwind.

step
#completewith Scouting Map
#hidewindow
+1
step
#completewith Scouting Map
#hidewindow
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
.acceptmap 94871
.accept 94871 >>Accept Eversong
step
#label Scouting Map
.goto 2393,45.61,70.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 89402 >>Accept Harandar
step
.zoneskip 2395,1
.isQuestAvailable 89107
.goto 2395,63.5,32.6
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Enchanting Rod|r
.turnin 89107 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2395,1
.isQuestAvailable 89158
.goto 2395,64.25,30.47
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Spade|r.
.turnin 89158 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2395,1
.isQuestAvailable 89180
.goto 2395,56.84,40.77
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Metalworking Cheat Sheet|r inside the building.
.turnin 89180 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2395,1
.isQuestAvailable 89125
.goto 2395,56.63,40.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Poorly Rounded Vial|r.
.turnin 89125 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.zoneskip 2395,1
.isQuestAvailable 89103
.goto 2395,60.76,53.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Everblazing Sunmote|r
.turnin 89103 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2395,1
.isQuestAvailable 89129
.goto 2395,39.65,38.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Gem Faceters|r.
.turnin 89129 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.zoneskip 2395,1
.isQuestAvailable 89135
.goto 2395,39.57,45.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Manual of Mistakes and Mishaps|r
.turnin 89135 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2395,1
.isQuestAvailable 89147
.goto 2395,37.99,45.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Solid Ore Punchers|r
.turnin 89147 >>Mining Knowledge Treasure
.train 471013,3
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 89402 >>Turn in Harandar
.accept 86899 >>Accept The Root Cause
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86899,1 
.timer 25,RP
.skipgossipid 135559
.target Orweyna
step
#completewith next
#label HarandarPortal
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r after the roleplay.
.complete 86899,2 
step
#completewith HarandarPortal
.goto 2395,45.74,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Isilwen Starforge|r.
.vendor >>Vendor and Repair
.target Isilwen Starforge
step
#requires HarandarPortal
.goto 2395,45.13,46.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r after the roleplay.
.complete 86899,2 
step
#include RestedXP Midnight\a) Of Caves and Cradles@OfCavesAndCradlesB-OfCavesAndCradlesZ


step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,34.89,24.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86944 >>Turn in Seeds of the Rift
.accept 86930 >>Accept To Sow the Seed
.target Orweyna
step
.zoneskip 2413,1
.isQuestAvailable 89095
.goto 2413,36.11,25.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Leatherworking Knife|r
.turnin 89095 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.zoneskip 2413,1
.isQuestAvailable 89113
.goto 2413,34.78,24.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vial of Rootlands Oddities|r
.turnin 89113 >>Alchemy Knowledge Treasure
.train 471003,3
step
.zoneskip 2413,1
.isQuestAvailable 89159
.goto 2413,36.67,25.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightbloom Root|r.
.turnin 89159 >>Herbalism Knowledge Treasure
.train 471009,3
step
#include RestedXP Midnight\a) Call of the Goddess@CallOfTheGoddessA-QuartermasterA
step
.zoneskip 2413,1
.isQuestAvailable 89094
.goto 2413,51.7,51.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Leatherworking Mallet|r
.turnin 89094 >>Leatherworking Knowledge Treasure
.train 471012,3
step
#include RestedXP Midnight\a) Call of the Goddess@Speak to the Innkeeper-Speak to the Innkeeper2
step
.zoneskip 2413,1
.isQuestAvailable 89155
.goto 2413,51.12,55.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Planting Shovel|r.
.turnin 89155 >>Herbalism Knowledge Treasure
.train 471009,3
step
#include RestedXP Midnight\a) Call of the Goddess@DelversCallA-CallOfTheGoddessB
step
.isQuestAvailable 93421
.goto 2413,71.01,65.6
.enterScenario 3097,3098,3099 >>Enter The Grudge Pit Delve in Harandar.
step
#include RestedXP Midnight\a) The Grudge Pit@GrudgeA-GrudgeZ
step
.zoneskip 2413,1
.isQuestAvailable 89182
.goto 2413,66.35,50.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rutaani Floratender's Sword|r on the mushroom.
.turnin 89182 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2413,1
.isQuestAvailable 89081
.goto 2413,69.76,51.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wooden Weaving Sword|r
.turnin 89081 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2413,1
.isQuestAvailable 89078
.goto 2413,70.57,50.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Child's Stuffy|r in the building.
.turnin 89078 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2413,1
.isQuestAvailable 89105
.goto 2413,65.73,50.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primal Essence Orb|r on the mushroom.
.turnin 89105 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2413,1
.isQuestAvailable 89157
.goto 2413,76.14,51.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Harvester's Sickle|r.
.turnin 89157 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2413,1
.isQuestAvailable 89168
.goto 2413,69.53,49.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primal Hide|r in the cave.
.turnin 89168 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2413,1
.isQuestAvailable 89166
.goto 2413,76.08,51.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightbloom Afflicted Hide|r
.turnin 89166 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2413,1
.isQuestAvailable 89104
.goto 2413,37.75,65.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entropic Shard|r
.turnin 89104 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2413,1
.isQuestAvailable 89162
.goto 2413,38.33,67.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bloomed Bud|r.
.turnin 89162 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2413,1
.isQuestAvailable 89151
.goto 2413,38.85,65.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spare Expedition Torch|r
.turnin 89151 >>Mining Knowledge Treasure
.train 471013,3
step
#include RestedXP Midnight\a) Call of the Goddess@CallOfTheGoddessC-CallOfTheGoddessZ
step
#include RestedXP Midnight\a) Emergence@EmergenceA-EmergenceY
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Zul'Aman Route Delve
#displayname |cFFFCDC005|r - Zul'Aman
#internal
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandA-DisWasOurLandAA
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandAB-DisWasOurLandB
step
#include RestedXP Midnight\a) Atal'Aman@AtalAmanA-AtalAmanB
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandC-Heart of the Amani
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandE-DisWasOurLandZ
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyB-PathOfDeHasheyC
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyD-PathOfDeHasheyE
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyF-PathOfDeHasheyG
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyH-PathOfDeHasheyX


step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyZ-PathOfDeHasheyZ
step
#include RestedXP Midnight\a) Where War Slumbers
step
#include RestedXP Midnight\a) De Amani Never Die@DeAmaniNeverDieA-DeAmaniNeverDieX
step
#include RestedXP Midnight\a) Twilight Crypts@TwilightCryptsA-TwilightCryptsB











step

.goto 2437,45.44,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93410 >>Turn in Delver's Call: Twilight Crypts
.turnin 93409 >>Turn in Delver's Call: Atal'Aman
.target Tavikko
step
#include RestedXP Midnight\a) De Amani Never Die@DeAmaniNeverDieY-DeAmaniNeverDieZ
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Voidstorm Route Delve
#displayname |cFFFCDC006|r - Voidstorm
#internal
step
#completewith next
#label Reports Returned
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91087 >>Turn in Reports Returned

.target Lor'themar Theron












step
#completewith Reports Returned
.hs >>Hearth to Silvermoon City
*If on cooldown use your Dalaran Hearthstone or Stormwind/Orgrimmar cloaks or other ways to get to the main city and use the Silvermoon portal.


step
#requires Reports Returned
.goto 2393,45.45,70.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 91087 >>Turn in Reports Returned

.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.goto 2393,45.37,70.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Koruth Mountainfist|r.
.accept 91854 >>Accept Deepening Shadows
.target Commander Koruth Mountainfist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Sin'dorei Fruit Vendor|r
.goto 2393,47.18,59.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sin'dorei Fruit Vendor|r.
.complete 91854,1 
.skipgossipid 135112
.target Sin'dorei Fruit Vendor
step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doomsayers|r.
*|cRXP_WARN_Kill the ones turning into |cRXP_ENEMY_Cultists|r|r.
*|cRXP_WARN_NOTE:|r They have a lot of HP. You can gamble by flying to the next one of the current one starts casting.
.complete 91854,3 
.skipgossipid 135048
.target Doomsayer
.target Twilight's Blade Cultist
.mob Twilight's Blade Cultist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Doomsayers|r and |cRXP_FRIENDLY_Orweyna|r
.goto 2393,46.54,58.88,15,0
.goto 2393,45.64,58.05,15,0
.goto 2393,43.86,58.41,15,0
.goto 2393,44.83,61.91,15,0
.goto 2393,42.31,63.93,15,0
.goto 2393,42.26,68.14,15,0
.goto 2393,36.60,68.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 86898 >>Turn in Rise of the Haranir
.accept 93651 >>Accept The Blinding Vale: Lightbloom Roots
.target Orweyna
step
#loop
#arrowtext Talk to\n|cRXP_FRIENDLY_Doomsayers|r
.goto 2393,42.30,72.64,15,0
.goto 2393,42.77,76.78,15,0
.goto 2393,46.19,76.57,15,0
.goto 2393,48.06,76.95,15,0
.goto 2393,51.54,70.19,15,0
.goto 2393,46.54,58.88,15,0
.goto 2393,45.64,58.05,15,0
.goto 2393,43.86,58.41,15,0
.goto 2393,44.83,61.91,15,0
.goto 2393,42.31,63.93,15,0
.goto 2393,42.26,68.14,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doomsayers|r.
*|cRXP_WARN_Kill the ones turning into |cRXP_ENEMY_Cultists|r|r.
*|cRXP_WARN_NOTE:|r They have a lot of HP. You can gamble by flying to the next one of the current one starts casting.
.complete 91854,3 
.skipgossipid 135048
.target Doomsayer
.target Twilight's Blade Cultist
.mob Twilight's Blade Cultist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Hagar|r
.goto 2393,36.57,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Hagar|r.

.accept 91084 >>Accept Looming Shadows

.target Elder Hagar
step
.zoneskip 2393,1
.isQuestAvailable 89177
.goto 2393,26.98,60.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Deconstructed Forge Techniques|r inside the building.
.turnin 89177 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2393,1
.isQuestAvailable 89079
.goto 2393,35.78,61.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Really Nice Curtain|r
.turnin 89079 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2393,1
.isQuestAvailable 89084
.goto 2393,31.8,68.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Particularly Enchanting Tablecloth|r
.turnin 89084 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2393,1
.isQuestAvailable 89124
.goto 2393,28.62,46.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dual-Function Magnifiers|r.
.turnin 89124 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Venel Lightblood|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2393,45.77,81.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Venel Lightblood|r.
.complete 91854,2 
.skipgossipid 135203
.skipgossipid 135204
.target Commander Venel Lightblood













step

#arrowtext Talk to\n|cRXP_FRIENDLY_Commander Koruth Mountainfist|r
.goto 2393,45.37,70.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Koruth Mountainfist|r.
.turnin 91854 >>Turn in Deepening Shadows
.target Commander Koruth Mountainfist
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.accept 91967 >>Accept You Know This Evil?
.target Lor'themar Theron
step
.isOnQuest 91084
#optional
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
*|cRXP_WARN_This unlocks the Haranir Race; not available in early access skip it for now|r
.turnin 91084 >>Turn in Looming Shadow
.turnin 95324 >>Turn in The War Beyond the Roots
.timer 55,RP
.target Lor'themar Theron
step
#optional
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
*|cRXP_WARN_This unlocks the Haranir Race; not available in early access skip it for now|r
.turnin 95324 >>Turn in The War Beyond the Roots
.timer 55,RP
.target Lor'themar Theron
step
#include RestedXP Midnight\a) Darkening Sky@DarkeningSkyD-DarkeningSkyZ
step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssA-IntoTheAbyssB
step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssC-IntoTheAbyssD
step
#include RestedXP Midnight\a) Parhelion Plaza@ParhelionPlazaA-ParhelionPlazaB
step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssE-IntoTheAbyssF














step
.isQuestAvailable 93428
.goto 2405,37.18,49.15,10,0
.goto 2405,37.39,47.75
.enterScenario 3126,3150,3149 >>Enter the Shadowguard Point Delve in Voidstorm.
step 
#include RestedXP Midnight\a) Shadowguard Point@ShadowguardPointA-ShadowguardPointB
step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssG-IntoTheAbyssZ
step
.zoneskip 2405,1
.isQuestAvailable 89156
.goto 2405,34.68,56.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Peculiar Lotus|r.
.turnin 89156 >>Herbalism Knowledge Treasure
.train 471009,3
step
#include RestedXP Midnight\a) The Night's Veil@TheNightsVeilA-TheNightsVeilB
step
.zoneskip 2405,1
.isQuestAvailable 89102
.goto 2405,35.47,58.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pure Void Crystal|r
.turnin 89102 >>Enchanting Knowledge Treasure
.train 471006,3
step
#include RestedXP Midnight\a) The Night's Veil
step
#include RestedXP Midnight\a) Dawn of Reckoning@DawnOfReckoningA-DawnOfReckoningX
step
#completewith next
#label Sanctum Delve
#hidewindow
.complete 86521,4 
step
#completewith Sanctum Delve
#arrowtext Leave the instance
.zone 2405 >>Click the macro under the "Active Items Frame"
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#requires Sanctum Delve
.isQuestAvailable 93427
.goto 2405,54.87,46.7,10,0
.goto 2405,54.79,47.26
.enterScenario 3194,3201,3204 >>Enter the Sunkiller Sanctum Delve in Voidstorm.
step
#include RestedXP Midnight\a) Sunkiller Sanctum@SanctumA-SanctumB
step
.isQuestAvailable 89181
.goto 2444,30.52,69.01
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Voidstorm Defense Spear|r inside the building.
.turnin 89181 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.isQuestAvailable 89093
.goto 2444,53.75,51.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Patterns: Beyond the Void|r in the building.
.turnin 89093 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.isQuestAvailable 89090
.goto 2405,34.72,56.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereal Leatherworking Knife|r.
.turnin 89090 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.isQuestAvailable 89083
.goto 2444,61.4,85.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Satin Throw Pillow|r in the building.
.turnin 89083 >>Tailoring Knowledge Treasure
.train 471015,3
step
.isQuestAvailable 89092
.goto 2444,62.01,83.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book of Sin'dorei Stitches|r in the building.
.turnin 89092 >>Tailoring Knowledge Treasure
.train 471015,3
step
.isQuestAvailable 89139
.goto 2393,51.21,57.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_What To Do When Nothing Works|r
.turnin 89139 >>Engineering Knowledge Treasure
.train 471007,3
step
.isQuestAvailable 89139
.goto 2393,51.21,57.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_What To Do When Nothing Works|r
.turnin 89139 >>Engineering Knowledge Treasure
.train 471007,3
step
.isQuestAvailable 89127
.goto 2393,55.45,47.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vintage Soul Gem|r.
.turnin 89127 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.isQuestAvailable 89124
.goto 2393,28.62,46.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dual-Function Magnifiers|r.
.turnin 89124 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.isQuestAvailable 89124
.goto 2393,28.62,46.4
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dual-Function Magnifiers|r.
.turnin 89124 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.isQuestAvailable 89112
.goto 2444,41.97,40.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vial of Voidstorm Oddities|r
.turnin 89112 >>Alchemy Knowledge Treasure
.train 471003,3
step
.isQuestAvailable 89067
.goto 2444,60.7,84.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void-Touched Quill|r in the building.
.turnin 89067 >>Inscription Knowledge Treasure
.train 471010,3
step
.isQuestAvailable 89150
.goto 2405,41.84,38.23
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Star Metal Deposit|r
.turnin 89150 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89144
.goto 2444,30.48,69.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Miner's Guide to Voidstorm|r
.turnin 89144 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89148
.goto 2444,28.76,38.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Glimmering Void Pearl|r
.turnin 89148 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89146
.goto 2393,49.11,75.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lost Voidstorm Satchel|r
.turnin 89146 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89146
.goto 2444,54.24,51.61
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lost Voidstorm Satchel|r
.turnin 89146 >>Skinning Knowledge Treasure
.train 471014,3
step
.goto 2405,51.35,67.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perodius|r.
.turnin 93427 >>Turn in Delver's Call: Sunkiller Sanctum
.target Perodius
step
#include RestedXP Midnight\a) Dawn of Reckoning@DawnOfReckoningY-DawnOfReckoningZ
step
.goto 2393,52.53,78.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telemancer Astrandis|r.
.turnin 93385 >>Turn in Delver's Call: The Darkway
.target Telemancer Astrandis
step
.goto 2393,52.78,77.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93384 >>Turn in Delver's Call: Collegiate Calamity
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.turnin 93386 >>Turn in Delver's Call: Parhelion Plaza
.target Naleidea Rivergleam
step
.isOnQuest 93784
.goto 2393,52.76,77.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93784 >>Turn in A Gnawing Void of Curiosity
.target Naleidea Rivergleam
step
+Do your first crafts now!
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Route Delve Worldtour
#displayname |cFFFCDC001|r - Eversong Woods
#internal
step
#include RestedXP Midnight\a) Collegiate Calamity
step
#include RestedXP Midnight\a) The Darkway
step
#include RestedXP Midnight\a) Parhelion Plaza@ParhelionPlazaA-ParhelionPlazaB
step
#include RestedXP Midnight\a) The Shadow Enclave
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Route Delve Worldtour
#displayname |cFFFCDC003|r - Harandar
#internal













step
.isQuestAvailable 93416,93421
.zoneskip 2393
.hs >>Hearth to Silvermoon City
*If on cooldown use your Dalaran Hearthstone or Stormwind/Orgrimmar cloaks or other ways to get to the main city and use the Silvermoon portal.


step
.isQuestAvailable 93416,93421
.zone 2576 >>Click on the |cRXP_PICK_Harandar Portal|r in Silvermoon City
.goto 2393,36.95,68.04
step
#include RestedXP Midnight\a) The Gulf of Memory
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
.goto 2413,54.18,53.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r |cRXP_WARN_in the building|r.
.turnin 93416 >>Turn in Delver's Call: The Gulf of Memory
.target Zur'ashar Kassameh
step
#include RestedXP Midnight\a) The Grudge Pit
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.79,64.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r inside the root.
.turnin 93421 >>Turn in Delver's Call: The Grudge Pit
.target Boletus
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Zul'Aman Route Delve Worldtour
#displayname |cFFFCDC004|r - Zul'Aman
#internal
step
.isQuestAvailable 93409
.isQuestNotComplete 93409
.goto 2395,63.8,80.02
.enterScenario 3117,3147,3148 >>Enter the Atal'Aman Delve inside the Amani Pass.
step
#include RestedXP Midnight\a) Atal'Aman@AtalAmanA-AtalAmanB
step
.isQuestAvailable 93410
.isQuestNotComplete 93410
.goto 2437,25.41,84.52
.enterScenario 3123,3124,3125 >>Enter the Twilight Crypts in Zul'aman.
step
#include RestedXP Midnight\a) Twilight Crypts@TwilightCryptsA-TwilightCryptsB
step
#arrowtext Talk to |cRXP_FRIENDLY_Tavikko|r
.goto 2437,45.44,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93410 >>Turn in Delver's Call: Twilight Crypts
.turnin 93409 >>Turn in Delver's Call: Atal'Aman
.target Tavikko
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Voidstorm Route Delve Worldtour
#displayname |cFFFCDC005|r - Voidstorm
#internal
step
#arrowtext Click on the |cRXP_PICK_Portal to Voidstorm|r
.goto 2393,35.29,66.16
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r
step
#include RestedXP Midnight\a) Shadowguard Point
step
#include RestedXP Midnight\a) Sunkiller Sanctum
step
.goto 2405,51.35,67.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perodius|r.
.turnin 93427 >>Turn in Delver's Call: Sunkiller Sanctum
.turnin 93428 >>Turn in Delver's Call: Shadowguard Point
.target Perodius
step
.goto 2393,52.53,78.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telemancer Astrandis|r.
.turnin 93385 >>Turn in Delver's Call: The Darkway
.target Telemancer Astrandis
step
#completewith next
#label SilvermoonDelveTurninA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93384 >>Turn in Delver's Call: Collegiate Calamity
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.turnin 93386 >>Turn in Delver's Call: Parhelion Plaza
.target Naleidea Rivergleam
step
#completewith SilvermoonDelveTurninA
.hs >>Hearth to Silvermoon City
.cooldown item,6948,>0,1
step
#completewith SilvermoonDelveTurninA
.zoneskip 2405,1
.zone 2393 >>Click on the |cRXP_PICK_Portal to Silvermoon|r
.goto 2405,51.56,70.29
.cooldown item,6948,<0,1
step
#requires SilvermoonDelveTurninA
.goto 2393,52.78,77.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93384 >>Turn in Delver's Call: Collegiate Calamity
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.turnin 93386 >>Turn in Delver's Call: Parhelion Plaza
.target Naleidea Rivergleam
step
.isOnQuest 93784
.goto 2393,52.76,77.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93784 >>Turn in A Gnawing Void of Curiosity
.target Naleidea Rivergleam
]])

RXPGuides.RegisterGuide([[
#retail
#version 4
#group RestedXP Midnight
#name a) DMF
#internal
step
>>Buy these items from the Auction House for an easy 120–200k XP.
*|cRXP_WARN_They may be expensive purchase at your discretion|r.
*|cRXP_WARN_Turn on Warmode for extra xp, no risk of dying in this section|r.
.collect 71953,1
.collect 71951,1
.collect 71952,1
.collect 71716,1
.collect 71635,1
.collect 71636,1
.collect 71637,1
.collect 71638,1
.collect 71715,1
.isQuestAvailable 29464
.isQuestAvailable 29451
.isQuestAvailable 29456
.isQuestAvailable 29457
.isQuestAvailable 29458
.isQuestAvailable 29443
.isQuestAvailable 29444
.isQuestAvailable 29445
.isQuestAvailable 29446
step
.itemcount 71716,1
.isQuestAvailable 29464
>>Press the macro "In the Active Items Frame"
.accept 29464 >>Accept Tools of Divination
.macro Soothsayer's Runes,441145 >>/use Soothsayer's Runes
step
.isQuestAvailable 29451
.itemcount 71715,1
>>Press the macro "In the Active Items Frame"
.accept 29451 >>Accept The Master Strategist
.macro A Treatise on Strategy,133740 >>/use A Treatise on Strategy
step
.itemcount 71951,1
.isQuestAvailable 29456
>>Press the macro "In the Active Items Frame"
.accept 29456 >>Accept A Captured Banner
.macro Banner of the Fallen,132487 >>/use Banner of the Fallen
step
.isQuestAvailable 29457
.itemcount 71952,1
>>Press the macro "In the Active Items Frame"
.accept 29457 >>Accept The Enemy's Insignia
.macro Captured Insignia,133330 >>/use Captured Insignia
step
.isQuestAvailable 29458
.itemcount 71953,1
>>Press the macro "In the Active Items Frame"
.accept 29458 >>Accept The Captured Journal
.macro Fallen Adventurer's Journal,133741 >>/use Fallen Adventurer's Journal
step
.isQuestAvailable 29443
.itemcount 71635,1
>>Press the macro "In the Active Items Frame"
.accept 29443 >>Accept A Curious Crystal
.macro Imbued Crystal,463518 >>/use Imbued Crystal
step
.isQuestAvailable 29444
.itemcount 71636,1
>>Press the macro "In the Active Items Frame"
.accept 29444 >>Accept An Exotic Egg
.macro Monstrous Egg,132834 >>/use Monstrous Egg
step
.isQuestAvailable 29445
.itemcount 71637,1
>>Press the macro "In the Active Items Frame"
.accept 29445 >>Accept An Intriguing Grimoire
.macro Mysterious Grimoire,133738 >>/use Mysterious Grimoire
step
.isQuestAvailable 29446
.itemcount 71638,1
>>Press the macro "In the Active Items Frame"
.accept 29446 >>Accept A Wondrous Weapon
.macro Ornate Weapon,294022 >>/use Ornate Weapon
step << Alliance
.isQuestAvailable 7905
.goto 84,62.26,72.95,-1
.goto 84,62.1,32.18,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkmoon Faire Mystic Mage|r.
.accept 7905 >>Accept The Darkmoon Faire
.target Darkmoon Faire Mystic Mage
step << Alliance
.zoneskip 407
.goto 84,62.26,72.95,-1
.goto 84,62.1,32.18,-1
.zone 37 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkmoon Faire Mystic Mage|r.
.skipgossipid 40457
.target Darkmoon Faire Mystic Mage
step << Alliance
.goto 37,41.78,69.55
.zone 407 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
step << Horde
.goto 85,48.22,62.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkmoon Faire Mystic Mage|r.
.accept 7926 >>Accept The Darkmoon Faire
.target Darkmoon Faire Mystic Mage
step << Horde
.zoneskip 407
.goto 85,48.24,62.18,-1
.zone 7 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkmoon Faire Mystic Mage|r.
.skipgossipid 40007
.target Darkmoon Faire Mystic Mage
step << Horde
.goto 7,36.86,35.86
.zone 407 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
step
#label TicketBookBoughtA
#completewith next
.zoneskip 407,1
.goto 407,52.78,28.82,20,0
.goto 407,52.99,38.99,20,0
.goto 407,53.37,45.81,20,0
.goto 407,55.66,52.34,20,0
.goto 407,50.44,59.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kae Ti|r and buy |T133734:0|t[Ride Ticket Book].
.collect 81055,1 
.buy 92794
.openitem 92784
.target Kae Ti
step
#hidewindow
#completewith TicketBookBoughtA
.goto 407,50.44,59.33,100 >>1
step
.zoneskip 407,1
.goto 407,49.44,57.4,10 >>Stand on the platform |T237554:0|t[WHEE!](10% XP for 60 min).
*|cRXP_WARN_Do this later if you don't want the xp buff for the turn ins.|r
.timer 15,Time until full duration
.countdown 15
.openitem 92794
step
.goto 407,49.44,57.4
.countdown 15 >>Wait until |T237554:0|t[WHEE!] reaches 60 minutes remaining.
step
#requires TicketBookBoughtA
.isOnQuest 29451
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29451 >>Turn in The Master Strategist
.target Professor Thaddeus Paleo
step
.isOnQuest 29456
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29456 >>Turn in A Captured Banner
.target Professor Thaddeus Paleo
step
.isOnQuest 29457
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29457 >>Turn in The Enemy's Insignia
.target Professor Thaddeus Paleo
step
.isOnQuest 29458
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29458 >>Turn in The Captured Journal
.target Professor Thaddeus Paleo
step
.isOnQuest 29443
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29443 >>Turn in A Curious Crystal
.target Professor Thaddeus Paleo
step
.isOnQuest 29443
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29443 >>Turn in A Curious Crystal
.target Professor Thaddeus Paleo
step
.isOnQuest 29464
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29464 >>Turn in Tools of Divination
.target Professor Thaddeus Paleo
step
.isOnQuest 29446
.zoneskip 407,1
.goto 407,51.9,60.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Paleo|r.
.turnin 29446 >>Turn in A Wondrous Weapon
.target Professor Thaddeus Paleo
step
.isOnQuest 7905
.zoneskip 407,1
.goto 407,47.76,64.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gelvas Grimegate|r
.turnin 7905 >>Turn in The Darkmoon Faire
.target Gelvas Grimegate
step
.train 2550,3
.itemcount 30817,5
.zoneskip 407,1
.goto 407,52.89,67.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stamp Thunderhorn|r.
.accept 29509 >>Accept Putting the Crunch in the Frog
.target Stamp Thunderhorn
step
.isOnQuest 29509
.train 2550,3
.zoneskip 407,1
.goto 407,52.88,67.96
>>Use |T133642:0|t[Plump Frogs].
.collect 72056,5,29509,1,-1 
.collect 30817,5,29509,1,-1 
.collect 72057,5,29509,1 
.use 72056 
step
.isOnQuest 29509
.train 2550,3
.zoneskip 407,1
.goto 407,52.88,67.96
>>Use |T237579:0|t[Breaded Frogs].
.collect 72057,5,29509,1,-1 
.complete 29509,1 
.use 72057 
step
.isOnQuest 29509
.train 2550,3
.zoneskip 407,1
.goto 407,52.88,67.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stamp Thunderhorn|r.
.turnin 29509 >>Turn in Putting the Crunch in the Frog
.target Stamp Thunderhorn
step
.train 2259,3
.zoneskip 407,1
.goto 407,50.54,69.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sylannia|r.
.accept 29506 >>Accept A Fizzy Fusion
.collect 19299,5,29506,1 
.buy 29506,5
.target Sylannia
step
.train 2259,3
.isOnQuest 29506
.zoneskip 407,1
.goto 407,50.54,69.56
>>Use |T132793:0|t[Cocktail Shaker].
.collect 1645,5,29506,1,-1 
.collect 19299,5,29506,1,-1 
.complete 29506,1 
.use 72043 
.itemcount 1645,5
step
.train 2259,3
.isOnQuest 29506
.zoneskip 407,1
.goto 407,50.53,69.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sylannia|r.
.turnin 29506 >>Turn in A Fizzy Fusion
.target Sylannia
step
.isOnQuest 29445
.zoneskip 407,1
.goto 407,53.24,75.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sayge|r [|cRXP_WARN_1|r].
.turnin 29445 >>Turn in An Intriguing Grimoire
.target Sayge
step
.train 45357,3
.zoneskip 407,1
.goto 407,53.23,75.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sayge|r [|cRXP_WARN_2|r].
.accept 29515 >>Accept Writing the Future
.target Sayge
step
.zoneskip 407,1
.goto 407,53.23,75.82
.aura 23768 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sayge|r [|cRXP_WARN_3|r].
.skipgossipid 31569
.skipgossipid 31565
.skipgossipid 30027
step
.isOnQuest 29515
.train 45357,3
.goto 407,53.23,75.82
>>Use |T413571:0|t[Bundle of Exotic Herbs].
.collect 71972,1,29515,1
.use 71971
.zoneskip 407,1
step
.train 45357,3
.isOnQuest 29515
.zoneskip 407,1
.goto 407,53.23,75.82
>>Use |T237061:0|t[Prophetic Ink].
.collect 39354,5,29515,1,-1 
.complete 29515,1 
.use 71972
step
.train 45357,3
.isOnQuest 29515
.zoneskip 407,1
.goto 407,53.23,75.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sayge|r.
.turnin 29515 >>Turn in Writing the Future
.target Sayge
step
.isOnQuest 29444
.zoneskip 407,1
.goto 407,51.11,82.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yebb Neblegear|r.
.turnin 29444 >>Turn in An Exotic Egg
.target Yebb Neblegear
step
.goto 407,47.78,64.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gelvas Grimegate|r and purchase as many |T669449:0|t[Darkmoon Top Hats] as needed.
*|cRXP_WARN_We recommend 4-8 for 80-90|r
*|cRXP_WARN_Note: They disappear after the Darkmoon Faire is over; hoarding them is pointless|r
.collect 171364,1 
step
.zoneskip 2393
.isQuestTurnedIn account,86852
.zone 84 >>Press the first macro and then the second macro "In the Active Items Frame".
*Enable "The Active Items Frame" if disabled
.macro Arathi Teleport,136243 >>/run C_EncounterJournal.StartArathiRPE()
.macro Teleport,236712 >>/run EventUtil.RegisterOnceFrameEventAndCallback("PLAYER_CHOICE_UPDATE",function() PlayerChoiceFrame:SetAlpha(0) if XXXXX then XXXXX:Cancel() end XXXXX=C_Timer.NewTimer(5,function() PlayerChoiceFrame:SetAlpha(1) end) end)\n/use spell:1258142
.choose 7389534
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Adventure Mode
#displayname |cFFFCDC001|r - Harandar
#internal
step << Monk
#include RestedXP Speed Leveling\a) Monk Quests






step
.zoneskip 2437,1
.hs >>Hearth to Silvermoon City
*If on cooldown use your Dalaran Hearthstone or Stormwind/Orgrimmar cloaks or other ways to get to the main city and use the Silvermoon portal.


step
#completewith Scouting Map
#hidewindow
+1
step
#completewith Scouting Map
#hidewindow
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
step
#label Scouting Map
.goto 2393,45.61,70.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 89402 >>Accept Harandar
step
.goto 2393,49.10,64.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin -95468 >>Turn in Hope in the Darkest Corners
.target Halduron Brightwing
step
.goto 2393,52.78,77.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93384 >>Turn in Delver's Call: Collegiate Calamity
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.turnin 93386 >>Turn in Delver's Call: Parhelion Plaza
.target Naleidea Rivergleam
step
.isOnQuest 93427,93385
#arrowtext Click on the |cRXP_PICK_Portal to Voidstorm|r
.goto 2393,35.28,66.12
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r
step
.isOnQuest 93427
.goto 2405,51.35,67.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perodius|r.
.turnin 93427 >>Turn in Delver's Call: Sunkiller Sanctum
.target Perodius
step
.isOnQuest 93385
.goto 2393,52.53,78.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telemancer Astrandis|r.
.turnin 93385 >>Turn in Delver's Call: The Darkway
.target Telemancer Astrandis
step
.zoneskip 2405,1
#arrowtext Click on the |cRXP_PICK_Portal to Silvermoon|r
.goto 2405,51.56,70.28
.zone 2393 >>Click on the |cRXP_PICK_Portal to Silvermoon|r
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 89402 >>Turn in Harandar
.accept 86899 >>Accept The Root Cause
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86899,1 
.timer 25,RP
.skipgossipid 135559
.target Orweyna
step
.goto 2395,45.13,46.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r after the roleplay.
.complete 86899,2 
step
#include RestedXP Midnight\a) Of Caves and Cradles@OfCavesAndCradlesB-OfCavesAndCradlesBA
step
.isOnQuest 93421
.isQuestComplete 93421
.goto 2413,71.78,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r.
.turnin 93421 >>Turn in Delver's Call: The Grudge Pit
.target Boletus
step
#include RestedXP Midnight\a) The Legend of Aln'sharan@TheLegendOfAlnsharanA-TheLegendOfAlnsharanB
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,69.69,26.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r
.turnin 90469 >>Turn in Carry On, Wayward Kuri
.target Kuri
step
#include RestedXP Midnight\a) Peril Among Petals@PerilAmongPetalsA-PerilAmongPetalsZ
step
#include RestedXP Midnight\a) Of Caves and Cradles@OfCavesAndCradlesBB-GulfofMemoryStartCampaign1
step
.isOnQuest 86912
.isQuestNotComplete 86912
.goto 2413,36.7,49.68
.enterScenario 3177,3242,3243 >>Enter The Gulf of Memory Delve in Harandar.
step
#include RestedXP Midnight\a) The Gulf of Memory@GulfofMemoryStart1-GulfofMemoryEnd1
step
#include RestedXP Midnight\a) Of Caves and Cradles@GulfofMemoryEndCampaign1-OfCavesAndCradlesZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,34.89,24.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86944 >>Turn in Seeds of the Rift
.accept 86930 >>Accept To Sow the Seed
.target Orweyna
step
.zoneskip 2413,1
.isQuestAvailable 89095
.goto 2413,36.11,25.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Leatherworking Knife|r
.turnin 89095 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.zoneskip 2413,1
.isQuestAvailable 89113
.goto 2413,34.78,24.71
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vial of Rootlands Oddities|r
.turnin 89113 >>Alchemy Knowledge Treasure
.train 471003,3
step
.zoneskip 2413,1
.isQuestAvailable 89159
.goto 2413,36.67,25.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightbloom Root|r.
.turnin 89159 >>Herbalism Knowledge Treasure
.train 471009,3
step
#completewith LateBloomersZ
#hidewindow
.xp 88
.skipto step,HaranirNeverSayDieA
step
#include RestedXP Midnight\a) Late Bloomers@LateBloomersA-LateBloomersZ
step
#include RestedXP Midnight\a) Haranir Never Say Die@HaranirNeverSayDieA-HaranirNeverSayDieZ
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Adventure Mode 2
#displayname |cFFFCDC001|r - Harandar
#internal
step
#include RestedXP Midnight\a) Call of the Goddess@CallOfTheGoddessA-QuartermasterA
step
.zoneskip 2413,1
.isQuestAvailable 89094
.goto 2413,51.7,51.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Haranir Leatherworking Mallet|r
.turnin 89094 >>Leatherworking Knowledge Treasure
.train 471012,3
step
#include RestedXP Midnight\a) Call of the Goddess@Speak to the Innkeeper-Speak to the Innkeeper2
step
.zoneskip 2413,1
.isQuestAvailable 89155
.goto 2413,51.12,55.7
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Planting Shovel|r.
.turnin 89155 >>Herbalism Knowledge Treasure
.train 471009,3
step
#include RestedXP Midnight\a) Call of the Goddess@DelversCallA-CallOfTheGoddessB
step
#label AdventureModeGrudgePitDelveA
#optional
.isQuestAvailable 93421
.isQuestNotComplete 93421
.goto 2393,36.95,67.99
.zone 2413 >>Click on the |cRXP_PICK_Portal to Harandar|r
step
#optional
#arrowtext Talk to\n|cRXP_FRIENDLY_Zur'ashar Kassameh|r
.goto 2413,54.18,53.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zur'ashar Kassameh|r |cRXP_WARN_in the building|r.
.turnin 93416 >>Turn in Delver's Call: The Gulf of Memory
.target Zur'ashar Kassameh
step
.isQuestAvailable 93421
.isQuestNotComplete 93421
.goto 2413,71.01,65.6
.enterScenario 3097,3098,3099 >>Enter The Grudge Pit Delve in Harandar.
step
#include RestedXP Midnight\a) The Grudge Pit@GrudgeA-GrudgeB
step
.goto 2413,71.78,64.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r.
.turnin 93421 >>Turn in Delver's Call: The Grudge Pit
.target Boletus
step
#completewith YouStrong?End1
+|cRXP_WARN_Complete this step if you can't continue this storyline because of a bug|r
.skipto step,YouStrongSkip
step
#include RestedXP Midnight\a) The Grudge Pit 2@YouStrong?Start1-YouStrong?End1
step
#label YouStrongSkip
.zoneskip 2413,1
.isQuestAvailable 89182
.goto 2413,66.35,50.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rutaani Floratender's Sword|r on the mushroom.
.turnin 89182 >>Blacksmithing Knowledge Treasure
.train 471004,3
step
.zoneskip 2413,1
.isQuestAvailable 89081
.goto 2413,69.76,51.05
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Wooden Weaving Sword|r
.turnin 89081 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2413,1
.isQuestAvailable 89078
.goto 2413,70.57,50.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_A Child's Stuffy|r in the building.
.turnin 89078 >>Tailoring Knowledge Treasure
.train 471015,3
step
.zoneskip 2413,1
.isQuestAvailable 89105
.goto 2413,65.73,50.2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primal Essence Orb|r on the mushroom.
.turnin 89105 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2413,1
.isQuestAvailable 89157
.goto 2413,76.14,51.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Harvester's Sickle|r.
.turnin 89157 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2413,1
.isQuestAvailable 89168
.goto 2413,69.53,49.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Primal Hide|r in the cave.
.turnin 89168 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2413,1
.isQuestAvailable 89166
.goto 2413,76.08,51.08
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lightbloom Afflicted Hide|r
.turnin 89166 >>Skinning Knowledge Treasure
.train 471014,3
step
.zoneskip 2413,1
.isQuestAvailable 89104
.goto 2413,37.75,65.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entropic Shard|r
.turnin 89104 >>Enchanting Knowledge Treasure
.train 471006,3
step
.zoneskip 2413,1
.isQuestAvailable 89162
.goto 2413,38.33,67.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bloomed Bud|r.
.turnin 89162 >>Herbalism Knowledge Treasure
.train 471009,3
step
.zoneskip 2413,1
.isQuestAvailable 89151
.goto 2413,38.85,65.87
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spare Expedition Torch|r
.turnin 89151 >>Mining Knowledge Treasure
.train 471013,3
step
#include RestedXP Midnight\a) Call of the Goddess@CallOfTheGoddessC-CallOfTheGoddessZ
step
#include RestedXP Midnight\a) Emergence@EmergenceA-EmergenceY



















step

#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2393,36.60,68.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 86898 >>Turn in Rise of the Haranir
.accept 93651 >>Accept The Blinding Vale: Lightbloom Roots
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Hagar|r
.goto 2393,36.57,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Hagar|r.
*|cRXP_WARN_Skip The War Beyond the Roots in Early Access|r
.accept 91084 >>Accept Looming Shadows

.target Elder Hagar
step
.isOnQuest 86650
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar|r.
.complete 86650,1 
.target Lor'themar
.skipgossipid 134143
step
.isOnQuest 86650
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.33
*|cRXP_WARN_Relog to skip the roleplay; saves 50seconds|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86650 >>Turn in Fractured
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.43,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
*|cRXP_WARN_This unlocks the Haranir Race; not available in early access skip step|r
.turnin 91084 >>Turn in Looming Shadow
.turnin 95324 >>Turn in The War Beyond the Roots
.timer 50,RP
.target Lor'themar Theron
step
.goto 2393,49.10,64.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin -95468 >>Turn in Hope in the Darkest Corners
.target Halduron Brightwing
step
.goto 2393,52.78,77.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93384 >>Turn in Delver's Call: Collegiate Calamity
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.turnin -93386 >>Turn in Delver's Call: Parhelion Plaza
.target Naleidea Rivergleam
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Adventure Mode
#displayname |cFFFCDC002|r - Eversong Woods
#internal
step
.isQuestAvailable 86649
#completewith next
#hidewindow
.acceptmap 94871
.accept 94871 >>Accept Eversong
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
step
.isQuestAvailable 86649
.goto 2393,45.61,70.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 94871 >>Accept Eversong
step
.goto 2393,49.10,64.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.accept 95468 >>Accept Hope in the Darkest Corners
.target Halduron Brightwing
step
#label EversongWoodsAdventureModeA
#arrowtext Talk to\n|cRXP_FRIENDLY_Innkeeper Jovia|r
.goto 2393,56.28,70.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Jovia|r twice.
.home >>Set your Hearthstone to Wayfarer's Rest
.target Innkeeper Jovia
.skipgossipid 134012
.skipgossipid 132666
.skipgossipid 132668
step
#arrowtext Talk to |cRXP_FRIENDLY_Tarenar Sunstrike|r
.goto 2393,57.72,68.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
#include RestedXP Midnight\a) Fear and Fel@FearAndFelA-FearAndFelC
step
#arrowtext Talk to |cRXP_FRIENDLY_Sarvi|r
.goto 2393,54.53,61.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarvi|r.
.accept 90669 >>Accept Gold is Gold
.target Sarvi
step
#include RestedXP Midnight\a) Fear and Fel@FearAndFelD-SojournerFelMagic1
step
#include RestedXP Midnight\xc) Naigtal Zone Unlock@NaigtalZoneUnlockA-NaigtalZoneUnlockD
step
#include RestedXP Midnight\a) Fear and Fel@SojournerLooseLips1-FearAndFelE
step
#include RestedXP Midnight\xc) Naigtal Zone Unlock@NaigtalZoneUnlockE-NaigtalZoneUnlockF
step
#include RestedXP Midnight\a) Lesser Evil@LesserEvilB-LesserEvilC
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Aradis|r
.goto 2393,54.11,33.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Aradis|r.
.turnin 89199 >>Turn in A Small Task
.target Magister Aradis
step
.isQuestAvailable 93384
.isQuestNotComplete 93384
.goto 2393,40.28,53.06
.enterScenario 3183,3187,3193 >>Enter the Collegiate Calamity Delve in Silvermoon.
step
#include RestedXP Midnight\a) Collegiate Calamity@CollegiateCalamityA-CollegiateCalamityB
step
.isQuestAvailable 93385
.isQuestNotComplete 93385
.goto 2393,39.31,31.69
.enterScenario 3184,3185,3256 >>Enter the Darkway Delve in Silvermoon.
step
#include RestedXP Midnight\a) The Darkway@DarkwayA-DarkwayB
step
.isQuestAvailable 93386
.isQuestNotComplete 93386
.goto 2424,47.74,41.54,10,0
.goto 2424,46.54,40.45
.enterScenario 3074,3100,3075 >>Enter the Parhelion Plaza Delve on the Isle of Quel'danas inside the tower.
step
#include RestedXP Midnight\a) Parhelion Plaza@ParhelionPlazaA-ParhelionPlazaB
step
.isQuestAvailable 91386
.zoneskip 2393
.hs >>Hearth to Silvermoon City
*If on cooldown use your Dalaran Hearthstone, Personal Key to the Arcantina, or Stormwind/Orgrimmar cloaks or other ways to get to the main city and use the Silvermoon portal.
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2393,47.60,51.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.turnin 96049 >>Turn in Stalkers of the Stars
.turnin 96703 >>Turn in Veterans of the Great Dark
.accept 96708 >>Accept To the Voidstorm and Beyond!
.target Riftblade Maella
step
#include RestedXP Midnight\a) Tailor Troubles@TailorTroublesA-TailorTroublesB
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Telenus|r
.goto 2393,35.67,69.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Telenus|r.
.accept 92729 >>Accept Hounded and Hassled
.target Ranger Telenus
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Voidstorm Delves
#displayname |cFFFCDC003|r - Harandar & Voidstorm Delves
#internal
step
.isQuestAvailable 93421
.isQuestNotComplete 93421
.goto 2393,36.94,68.03
.zone 2576 >>Click on the |cRXP_PICK_Portal to Harandar|r.
step
#include a) Legends Never Die & The Empty Cradle@LegendsNeverDieA-LegendsNeverDieAA
step
#xprate >1.15
.isQuestAvailable 93416
.isQuestNotComplete 93416
.goto 2413,36.7,49.68
.enterScenario 3177,3242,3243 >>Enter The Gulf of Memory Delve in Harandar.
step
#include RestedXP Midnight\a) The Gulf of Memory@GulfofMemoryStart1-GulfofMemoryEnd1
step
#include a) Legends Never Die & The Empty Cradle@LegendsNeverDieB-LegendsNeverDieX
step
.isQuestAvailable 93421
.isQuestNotComplete 93421
.goto 2413,71.01,65.6
.enterScenario 3097,3098,3099 >>Enter The Grudge Pit Delve in Harandar.
step
#include RestedXP Midnight\a) The Grudge Pit@GrudgeA-GrudgeB
step
#include RestedXP Midnight\a) The Grudge Pit 2@YouStrong?Start1-YouStrong?End1
step
#include a) Legends Never Die & The Empty Cradle@LegendsNeverDieY-LegendsNeverDieZ
step
.isQuestAvailable 93427
.isQuestNotComplete 93427
#arrowtext Fly into the cave\nClick on the |cRXP_PICK_Portal to Voidstorm|r
.goto 2576,61.75,73.45
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r
step
.isQuestAvailable 93428
.isQuestNotComplete 93428
#arrowtext Fly into the cave\nClick on the |cRXP_PICK_Portal to Voidstorm|r
.goto 2576,61.75,73.45
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r
step
.goto 2405,51.82,71.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight Anais|r.
.accept 91145 >>Accept The Conquered Heroes
.target Knight Anais
step
.isQuestAvailable 93427
.isQuestNotComplete 93427
.goto 2405,54.87,46.7,10,0
.goto 2405,54.79,47.26
.enterScenario 3194,3201,3204 >>Enter the Sunkiller Sanctum Delve in Voidstorm.
step
#include RestedXP Midnight\a) Sunkiller Sanctum@SanctumA-SanctumB
step
#include RestedXP Midnight\a) Shadow Puppets@ShadowPuppetsB-Anais
step
.isQuestAvailable 93428
.isQuestNotComplete 93428
.goto 2405,37.18,49.15,10,0
.goto 2405,37.39,47.75
.enterScenario 3126,3150,3149 >>Enter the Shadowguard Point Delve in Voidstorm.
step
#include RestedXP Midnight\a) Shadowguard Point@ShadowguardPointA-ShadowguardPointB
step
#include RestedXP Midnight\a) Shadow Puppets@Turn in The Conquered Heroes-ShadowPuppetsZ
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Adventure Mode 2
#displayname |cFFFCDC002|r - Eversong Woods
#internal
step
.zoneskip 2393
.hs >>Hearth to Silvermoon City
*If on cooldown use your Dalaran Hearthstone or Stormwind/Orgrimmar cloaks or other ways to get to the main city and use the Silvermoon portal.
.cooldown item,6948,>0,1
step
#include RestedXP Midnight\a) The Drinking Debt@TheDrinkingDebtB-TheDrinkingDebtD
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Instructor Thalendir|r
.goto 2393,33.23,74.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.accept 94393 >>Accept Career Counseling
.target Instructor Thalendir
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Instructor Thalendir|r
.goto 2393,33.25,74.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.accept 94396 >>Accept Down a Peg
.target Instructor Thalendir
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,46.91,45.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.accept 87392 >>Accept Cargo Conspiracy
.target Lyssara Duskmourne
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r
.goto 2395,46.71,45.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r.
.turnin 94871 >>Turn in Eversong
.target Magistrix Landra Dawnstrider
step
#label SharpmawFairbreezeFavorsA
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r
.goto 2395,46.71,45.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r.
.accept 86738 >>Accept Sharpmaw
.accept 86739 >>Accept Fairbreeze Favors
.target Magistrix Landra Dawnstrider
step
#include RestedXP Midnight\a) Whispers in the Twilight@DisplacedDenizensA-WhispersInTheTwilightD
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveB-PortDetectiveC
step
#hidewindow
#completewith HawkstridersShooedA
#loop
.goto 2395,46.39,45.6,45,0
.goto 2395,46.81,44.78,45,0
.goto 2395,47.36,46.57,45,0
.goto 2395,46.29,46.83,45,0
.goto 2395,44.5,43.84,45,0
.goto 2395,45.29,43.52,45,0
.goto 2395,45.95,44.56,45,0
+1
step
#completewith ErraticLightWyrmA
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r
.complete 86739,2 
.target Displaced Hawkstrider
step
#completewith ErraticLightWyrmA
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#label ErraticLightWyrmA
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
#completewith next
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#label HawkstridersShooedA
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
.isWorldQuestAvailable 2395,92150
#loop
.goto 2395,46.39,45.6,45,0
.goto 2395,46.81,44.78,45,0
.goto 2395,47.36,46.57,45,0
.goto 2395,46.29,46.83,45,0
.goto 2395,44.5,43.84,45,0
.goto 2395,45.29,43.52,45,0
.goto 2395,45.95,44.56,45,0
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 92150,1 
.mob Displaced Lynx
.target Displaced Lynx
.target Displaced Hawkstrider
.mob Erratic Light Wyrm
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightEA-WhispersInTheTwilightF
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveD-PortDetectiveDA
step
#include RestedXP Midnight\a) Theft Tracking@TheftTrackingA-TheftTrackingB
step
.goto 2395,39.89,39.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r.
.accept 90544 >>Accept Thief at Bark
.timer 37.5,RP
.target Luma
step
.zoneskip 2395,1
.isQuestAvailable 89129
.goto 2395,39.65,38.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sin'dorei Gem Faceters|r.
.turnin 89129 >>Jewelcrafting Knowledge Treasure
.train 471011,3
step
.goto 2395,40.52,44.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,1 
step
.zoneskip 2395,1
.isQuestAvailable 89135
.goto 2395,39.57,45.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Manual of Mistakes and Mishaps|r
.turnin 89135 >>Engineering Knowledge Treasure
.train 471007,3
step
.zoneskip 2395,1
.isQuestAvailable 89147
.goto 2395,37.99,45.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Solid Ore Punchers|r
.turnin 89147 >>Mining Knowledge Treasure
.train 471013,3
step
#title At the top
.goto 2395,39.46,45.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,2 
step
.goto 2395,39.62,44.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Telescope|r.
.complete 87394,3 
step
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cute Doggo|r |cRXP_WARN_after the roleplay|r.
.complete 90544,1 
.timer 6.7,RP
.skipgossipid 133262
.target Luma
step
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r |cRXP_WARN_after the roleplay|r.
.turnin 90544 >>Turn in Thief at Bark
.target Luma
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveDB-PortDetectiveZ
step
#include RestedXP Midnight\a) Whispers in the Twilight@WhispersInTheTwilightG-WhispersInTheTwilightZ
step
#include RestedXP Midnight\a) Shadowfall@ShadowfallA-ShadowfallB
step
#requires Windrunner Village
.goto 2395,38.96,61.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.accept 91493 >>Accept Not What I Ordered
.target Hathvelion Sungaze
step
#include RestedXP Midnight\a) Daggerspine Landing@DaggerspineLandingC-DaggerspineLandingZ
step
.zoneskip 2395,1
.isQuestAvailable 89074
.goto 2395,40.36,61.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Songwriter's Quill|r
.turnin 89074 >>Inscription Knowledge Treasure
.train 471010,3
step
#include RestedXP Midnight\a) Shadowfall@ShadowfallC-ShadowfallY
step
#include RestedXP Midnight\a)The Shadow Enclave 2
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2395,44.65,85.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86636 >>Turn in Void Walk With Me
.target Magister Umbric
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsA-RippleEffectsB
step
#include RestedXP Midnight\a) Blinding Sun@BlindingSunA-BlindingSunZ
step
.isOnQuest 86708
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2395,60.14,81.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 86708 >>Turn in The Gates of Zul'Aman
.target Lady Liadrin
step
.isQuestTurnedIn 86708
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2395,60.14,81.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 86710 >>Accept The Line Must be Drawn Here
.target Lady Liadrin
step
.isOnQuest 86710
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,60.28,81.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r.
.complete 86710,1 
.timer 21,Roleplay Duration
.target Zul'jan
.skipgossipid 135099
step
.isOnQuest 86710
.goto 2395,60.38,81.49
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 86710,2 
step
.isOnQuest 86710
.goto 2395,60.38,81.49
>>Kill |cRXP_ENEMY_Void Beast|r.
.complete 86710,3 
.mob Void Beast
step
.isOnQuest 86710
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2395,60.14,81.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.turnin 86710 >>Turn in The Line Must be Drawn Here
.target Lady Liadrin
step
.isQuestTurnedIn 86710
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2395,60.14,81.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 90749 >>Accept Our Mutual Enemy
.target Lady Liadrin
step
#completewith next
#label AdventureModeTheRegentsRequestA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 91822 >>Accept The Regent's Request
.target Valeera Sanguinar
step
.zoneskip 2393
#completewith AdventureModeTheRegentsRequestA
.hs >>Hearth to Silvermoon City

step
#requires AdventureModeTheRegentsRequestA
#arrowtext Talk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2393,52.55,78.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 91822 >>Accept The Regent's Request
.target Valeera Sanguinar
step
#arrowtext Fly UP\nTalk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,33.55,36.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.complete 91822,1 
.skipgossipid 135475
.target Lor'themar Theron
step
#include RestedXP Midnight\a) Fear and Fel@FearAndFelF-FearAndFelG
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,32.19,26.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90821 >>Turn in Murder Row: Harbored Secrets
.target Belath Dawnblade
step
#include RestedXP Midnight\a) How to Train Your Protege@HowToTrainYourProtegeB-HowToTrainYourProtegeC
step
#include RestedXP Midnight\a) How to Train Your Protege@HowToTrainYourProtegeD-HowToTrainYourProtegeX
step
#include RestedXP Midnight\a) Aspiring Academic@AspiringAcademicB-AspiringAcademicZ
step
#include RestedXP Midnight\a) Scootin' Through Silvermoon@ScootinThroughSilvermoonA-ScootinThroughSilvermoonB
step
#include RestedXP Midnight\a) Scootin' Through Silvermoon@ScootinThroughSilvermoonC-ScootinThroughSilvermoonZ
step
#include RestedXP Midnight\a) How to Train Your Protege@HowToTrainYourProtegeY-HowToTrainYourProtegeZ
step
#include RestedXP Midnight\a) One Adventurous Hatchling@OneAdventurousHatchlingA-OneAdventurousHatchlingZ
step
#include RestedXP Midnight\a) Far Striding@FarStridingA-FarStridingB
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsBA-RippleEffectsT
step
.isWorldQuestAvailable 2395,92144
#loop
.goto 2395,64.03,47.42,30,0
.goto 2395,65.04,47.9,30,0
.goto 2395,64.63,49.05,30,0
.goto 2395,63.56,51.68,30,0
.goto 2395,62.08,51.94,30,0
.goto 2395,60.43,52.34,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Supply Crates|r
*> Kill |cRXP_ENEMY_Amani Defectors|r
.complete 92144,1 
.complete 92144,2 
.mob Amani Defector
.mob Renegade Watcher
.mob Renegade Enforcer
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsTA-RippleEffectsU
step
#include RestedXP Midnight\a) The Regent's Request@TheRegentsRequestB-TheRegentsRequestC
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsUA-RippleEffectsV
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Zul'Aman Adventure Mode
#displayname |cFFFCDC003|r - Zul'Aman
#internal
step
#completewith next
#label Speak to Lor'themar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar|r.
.complete 86650,1 
.target Lor'themar








step
.isOnQuest 86650
.isNotOnQuest 90749
#completewith Speak to Lor'themar
.hs >>Hearth to Silvermoon City
.cooldown item,6948,>0,1
step
.isOnQuest 86650
.isNotOnQuest 90749
#requires Speak to Lor'themar
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar|r.
.complete 86650,1 
.target Lor'themar
.skipgossipid 134143
step
.isOnQuest 86650
.isNotOnQuest 90749
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.33
*|cRXP_WARN_Relog to skip the roleplay; saves 50seconds|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86650 >>Turn in Fractured
.target Lor'themar Theron
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandA-DisWasOurLandAA
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandAB-DisWasOurLandB
step
#label AdventureModeAtalAmanDelveA
.isQuestAvailable 93409
.isQuestNotComplete 93409
.goto 2395,63.8,80.02
.enterScenario 3117,3147,3148 >>Enter the Atal'Aman Delve inside the Amani Pass.
step
#include RestedXP Midnight\a) Atal'Aman@AtalAmanA-AtalAmanB
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandC-GoodwillTourA





























step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandCA-Important Amani





















step
#include RestedXP Midnight\a) Dis Was Our Land@ElderDoruA-Break the Blade
step
.isQuestAvailable 89085
.goto 2437,40.53,49.37
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Artisan's Cover Comb|r in the cave.
.turnin 89085 >>Tailoring Knowledge Treasure
.train 471015,3
step
.isQuestAvailable 89106
.goto 2437,40.42,51.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Loa-Blessed Dust|r
.turnin 89106 >>Enchanting Knowledge Treasure
.train 471006,3
step
.isQuestAvailable 89114
.goto 2437,40.39,51.18
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Vial of Zul'Aman Oddities|r
.turnin 89114 >>Alchemy Knowledge Treasure
.train 471003,3
step
.isQuestAvailable 89068
.goto 2437,40.49,49.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Leather-Bound Techniques|r
.turnin 89068 >>Inscription Knowledge Treasure
.train 471010,3
step
.isQuestAvailable 89149
.goto 2536,33.31,65.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Expert's Chisel|r
.turnin 89149 >>Mining Knowledge Treasure
.train 471013,3
step
.isQuestAvailable 89170
.goto 2437,40.4,36.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Tanning Oil|r
.turnin 89170 >>Skinning Knowledge Treasure
.train 471014,3
step
#include RestedXP Midnight\a) Dis Was Our Land@Heart of the Amani-Heart of the Amani
step
#include RestedXP Midnight\a) Dis Was Our Land@DisWasOurLandE-DisWasOurLandZ
step
.goto 2437,43.80,68.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.accept 86653 >>Accept The Path of the Amani
.target Zul'jarra
step
.goto 2437,43.15,67.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Dar'rak|r
.accept 93051 >>Accept The Final Exam
.target Recruit Dar'rak
step
.goto 2437,44.03,66.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kagara|r.
.accept 89230 >>Accept A Lover Not a Fighter
.target Kagara
step
.goto 2437,43.89,65.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zak'kash|r.
.accept 89231 >>Accept A Fighter Not a Lover
.target Zak'kash
step
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r.
.complete 93051,1 
.skipgossipid 137188
.target Ri'kari
step
.goto 2437,43.83,64.98
>>Kill |cRXP_ENEMY_Recruit Dar'rak|r
.complete 93051,2 
.mob Recruit Dar'rak
step
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r
.turnin 93051 >>Turn in The Final Exam
.target Ri'kari
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Vakala|r
.goto 2437,45.05,68.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vakala|r.
.accept 94867 >>Accept Lost in Atal'Abasi
.target Vakala
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.accept 92450 >>Accept Growing Up is Hard
.target Ani
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
.goto 2437,45.35,69.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.accept 89565 >>Accept The Path of Mourning
.target Chana
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.54,69.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r.
.accept 93047 >>Accept Butchery Basics
.target Gijaniji
step
#include RestedXP Midnight\a) No Fear@NoFearB-NoFearBA
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r
.goto 2437,48.11,67.61
>>Use the |T237554:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92451,2 
.timer 6,RP
step
.isOnQuest 92451
#arrowtext |cRXP_ENEMY_WAIT 'TIL TIMER ENDS|r
.goto 2437,48.11,67.61,10,0
.goto 2437,52.88,60.22
.countdown 6 >>You can leave when this timer ends
.complete 92451,3 

step
#include RestedXP Midnight\a) The Loa of Murlocs@TheLoaOfMurlocsA-TheLoaOfMurlocsZ
step
#include RestedXP Midnight\a) Vengeance for Tolbani@VengeanceForTolbaniA-VengeanceForTolbaniB
step
#include RestedXP Midnight\a) No Fear@NoFearD-NoFearE
step
#include RestedXP Midnight\a) Vengeance for Tolbani@VengeanceForTolbaniC-VengeanceForTolbaniZ
step
#completewith PathOfDeHasheyBA
>>Kill |cRXP_ENEMY_Gnarldin|r. Loot them for the |T1535070:0|t[|cRXP_LOOT_Threshadon Tooth Necklace|r]
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eagle Feathers|r
.complete 89230,1 
.complete 89231,1 
.mob Gnarldin Clubfist
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyB-PathOfDeHasheyBA
step
#loop
.goto 2437,55.02,72.96,35,0
.goto 2437,52.32,70.55,35,0
.goto 2437,53.99,71.83,35,0
.goto 2437,55.69,74.15,35,0
.goto 2437,54.98,77.36,35,0
>>Kill |cRXP_ENEMY_Gnarldin|r. Loot them for the |T1535070:0|t[|cRXP_LOOT_Threshadon Tooth Necklace|r]
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Eagle Feathers|r
.complete 89230,1 
.complete 89231,1 
.mob Gnarldin Clubfist
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyBB-PathOfDeHasheyC
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r.
.accept 90481 >>Accept I Have a Permit
.target Seeker Crikkash
.target Amaxi
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Ren'zen|r
.goto 2437,38.30,20.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Ren'zen|r.
.complete 90481,1 
.skipgossipid 133102
.skipgossipid 133101
.target Elder Ren'zen
step
#include RestedXP Midnight\a) A Venomous History@AVenomousHistoryA-AVenomousHistoryAA
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyD-PathOfDeHasheyE
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r.
.turnin 91563 >>Turn in Halazzi's Hunt
.accept 91404 >>Accept A Most Vile Venom
.target Loa Speaker Tobui
step
#include RestedXP Midnight\a) Sawdust to Sawdust@SawdustToSawdustA-SawdustToSawdustB
step
.isWorldQuestAvailable 2437,91808
#loop
.goto 2437,29.98,27.64,35,0
.goto 2437,29.95,29.32,35,0
.goto 2437,31.15,28.38,35,0
.goto 2437,30.44,27.1,35,0
.goto 2437,29.24,30.8,40,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Equipment|r
.complete 91808,1 
step
#include RestedXP Midnight\a) Sawdust to Sawdust@SawdustToSawdustC-SawdustToSawdustZ
step
#include RestedXP Midnight\a) Bitter Honor@BitterHonorA-BitterHonorY
step
.goto 2437,40.20,35.28
>>Kill |cRXP_ENEMY_Venomhexxer Raxxis|r.
.complete 91404,1 
.mob Venomhexxer Raxxis
step
.goto 2437,40.42,36.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 91404,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r.
.turnin 91404 >>Turn in A Most Vile Venom
.target Loa Speaker Tobui
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyF-PathOfDeHasheyG
step
#label UnlikelyFriendsD
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r |cRXP_WARN_after the roleplay|r.
.turnin 90481 >>Turn in I Have a Permit
.target Seeker Crikkash
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyH-PathOfDeHasheyX
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Ren'zen|r
.goto 2437,38.30,20.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Ren'zen|r.
.complete 90481,1 
.timer 60,RP
.skipgossipid 133102
.skipgossipid 133101
.target Elder Ren'zen
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r |cRXP_WARN_after the roleplay|r.
.turnin 90481 >>Turn in I Have a Permit
.target Seeker Crikkash
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,47.26,24.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r.
.accept 90483 >>Accept A Witherbark Story
.target Seeker Crikkash
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Trishe|r
.goto 2437,47.27,26.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trishe|r.
.accept 90484 >>Accept Sightseeing Stegadon
.target Trishe
step
#loop
#arrowtext Talk to\n|cRXP_FRIENDLY_Witherbark Visitor|r
.goto 2437,47.78,24.49,15,0
.goto 2437,47.3,25.97,15,0
.goto 2437,47.2,24.63,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witherbark Visitor|r and kill them.
.complete 90483,1 
.target Witherbark Visitor
.mob Witherbark Visitor
.skipgossipid 133188
step
.goto 2437,45.43,23.82
>>Kill |cRXP_ENEMY_Hidegorger the Everburning|r.
.complete 90484,1 
.mob Hidegorger the Everburning
step
.goto 2437,45.36,23.95
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Steggy|r
.complete 90484,2 
.target Steggy
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,47.26,24.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 90483 >>Turn in A Witherbark Story
.target Seeker Crikkash
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Trishe|r
.goto 2437,47.28,26.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trishe|r.
.turnin 90484 >>Turn in Sightseeing Stegadon
.target Trishe
step
#include RestedXP Midnight\a) Path of de Hash'ey@PathOfDeHasheyZ-PathOfDeHasheyZ
step
#include RestedXP Midnight\a) Where War Slumbers@SlumbersA-SlumbersAA
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Huntmaster Jinki|r
.goto 2437,44.26,66.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntmaster Jinki|r.
.turnin 93096 >>Turn in Amani Honor
.target Huntmaster Jinki
step
#arrowtext Use the |T2103839:0|t[Eagle Feathers]
.goto 2437,44.44,65.74
>>Use the |T2103839:0|t[Eagle Feathers]
.complete 89231,2 
.use 249231
step
#include RestedXP Midnight\a) Between Two Trolls@BetweenTwoTrollsB-BetweenTwoTrollsZ
step
#include RestedXP Midnight\a) No Fear@NoFearF-NoFearF
step
.goto 2437,45.87,72.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.turnin 89565 >>Turn in The Path of Mourning
.accept 89503 >>Accept Somber Siblings
.target Chana
step
#completewith SorrowingKinB
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#include RestedXP Midnight\a) Sorrowing Kin@SorrowingKinA-SorrowingKinB
step
#loop
.goto 2437,46.27,72.15,35,0
.goto 2437,47.1,73.67,35,0
.goto 2437,46.49,75.39,35,0
.goto 2437,45.26,74.18,35,0
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#include RestedXP Midnight\a) Sorrowing Kin@SorrowingKinC-SorrowingKinZ
step
.isQuestAvailable 89089
.goto 2437,33.08,78.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Leatherworker's Tool|r in the cave.
.turnin 89089 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.isQuestAvailable 89172
.goto 2437,33.08,79.07
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amani Skinning Knife|r in the cave.
.turnin 89172 >>Skinning Knowledge Treasure
.train 471014,3
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,33.59,78.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.complete 86682,1 
.target Lilaju
.skipgossipid 134139
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,33.61,78.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86682 >>Turn in Den of Nalorakk: Waking de Bear
.target Zul'jarra
step
.isQuestAvailable 89091
.goto 2437,30.76,84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prestigiously Racked Hide|r in the building.
.turnin 89091 >>Leatherworking Knowledge Treasure
.train 471012,3
step
.isQuestAvailable 89140
.goto 2437,34.21,87.81
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Handy Wrench|r
.turnin 89140 >>Engineering Knowledge Treasure
.train 471007,3
step
#label AdventureModeSpiritPawA
.goto 2437,33.61,78.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pel'na Torntusk|r.
.accept 91813 >>Accept The Spiritpaw
.target Pel'na Torntusk
step
#label AdventureModeTwilightCryptsDelveA
.isQuestAvailable 93410
.isQuestNotComplete 93410
.goto 2437,25.41,84.52
.enterScenario 3123,3124,3125 >>Enter the Twilight Crypts in Zul'aman.
step
#include RestedXP Midnight\a) Twilight Crypts@TwilightCryptsA-TwilightCryptsB
step
#include RestedXP Midnight\a) The Voice of Nalorakk@TheVoiceOfNalorakkA-TheVoiceOfNalorakkZ
step
#label AdventureModeFearlessA
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.turnin 92453 >>Turn in Fearless
.target Ani
step
#arrowtext Click on the |cRXP_PICK_Boar|r
.goto 2437,45.54,69.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boar|r.
.complete 93047,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.58,69.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r
.turnin 93047 >>Turn in Butchery Basics
.target Gijaniji
step
#label AdventureModeZulAmanDelveTurninA
.goto 2437,45.44,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93410 >>Turn in Delver's Call: Twilight Crypts
.turnin 93409 >>Turn in Delver's Call: Atal'Aman
.target Tavikko
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Voidstorm Adventure Mode
#displayname |cFFFCDC004|r - Voidstorm
#internal
step
#arrowtext Click on the |cRXP_PICK_Portal to Voidstorm|r
.goto 2393,35.29,66.16
.zone 2405 >>Click on the |cRXP_PICK_Portal to Voidstorm|r
step
#include RestedXP Midnight\a) A Gift, Given Freely@AGiftGivenFreelyA-AGiftGivenFreelyB
step << Alliance
#arrowtext Talk to\n|cRXP_FRIENDLY_Amari Lyndon|r
.goto 2444,40.79,84.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amari Lyndon|r.
.accept 91565 >>Accept Voidscar Arena: The Grief Spire
.target Amari Lyndon
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,39.75,84.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.accept 92390 >>Accept Risk for Research
.target Lanlae Noxa
step << Horde
#arrowtext Talk to\n|cRXP_FRIENDLY_Dar'gul|r
.goto 2444,34.93,80.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dar'gul|r.
.accept 91566 >>Accept Voidscar Arena: The Hate Spire
.target Dar'gul
step << Alliance
#include RestedXP Midnight\a) Breaking the Triad@BreakingTheTriadA-BreakingTheTriadAA
step << Horde
#include RestedXP Midnight\a) Breaking the Triad@BreakingTheTriadA-BreakingTheTriadAA
step
#include RestedXP Midnight\a) Shadowguard's Shadow@ShadowguardsShadowB-ShadowguardsShadowZ
step << Horde
#arrowtext Talk to |cRXP_FRIENDLY_Ziadan|r
.goto 2444,50.65,58.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ziadan|r.
.turnin 94848 >>Turn in Voidscar Arena: Pre-Provoked Violence
.turnin 94849 >>Turn in Voidscar Arena: A Familiar Grudge
.accept 94855 >>Accept Voidscar Arena: Setting It Aside
.target Ziadan
step << Alliance
#include RestedXP Midnight\a) Breaking the Triad@BreakingTheTriadB-BreakingTheTriadD
step
#include RestedXP Midnight\a) A Gift, Given Freely@AGiftGivenFreelyC-AGiftGivenFreelyZ
step
#include RestedXP Midnight\a) Breaking the Triad@BreakingTheTriadE-BreakingTheTriadF
step
#label AdventureModeVoidstormPartB
.isWorldQuestAvailable 2444,92576
#loop
.goto 2444,53.64,32.13,35,0
.goto 2444,53.54,21.47,55,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banners|r
>>Kill the |cRXP_ENEMY_Domanaar Forces|r
.complete 92576,1 
.complete 92576,2 
.mob Spiteful Mindwarden
.mob Coagulated Void
.mob Spiteful Minder
.mob Spiteful Consumptor
.mob Devouring Spawn
step
#include RestedXP Midnight\a) Pathogenic Problem@PathogenicProblemA-PathogenicProblemZ
step
.isWorldQuestAvailable 2405,93571
#loop
.goto 2405,27.85,53.58,30,0
.goto 2405,26.05,53.11,30,0
.goto 2405,28.06,50.34,30,0
>>Kill the |cRXP_ENEMY_Scytheryp the Slicer|r, |cRXP_ENEMY_Vathen the Rebel|r, and |cRXP_ENEMY_Voidgrasper|r.
.complete 93571,1 
.mob Scytheryp the Slicer
.mob Vathen the Rebel
.mob Voidgrasper
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lysikas|r
.goto 2405,36.03,59.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r
.accept 92657 >>Accept The Brewing Storm
.target Lysikas
step
#include RestedXP Midnight\a) The Void Peers Back@TheVoidPeersBackA-TheVoidPeersBackZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Null-Theorist Selune|r
.goto 2405,26.41,67.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Null-Theorist Selune|r
.accept 86810 >>Accept Harvesting the Void
.accept 92365 >>Accept Creating Defenses
.target Null-Theorist Selune
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lysikas|r
.goto 2405,26.34,68.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r
.turnin 92657 >>Turn in The Brewing Storm
.accept 92658 >>Accept Tactical Acquisition
.accept 92659 >>Accept Resource Denial
.target Lysikas
step
#arrowtext Click on the |cRXP_PICK_Chest|r
.goto 2405,25.78,68.68
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r.
.complete 92365,1 
step
#arrowtext Use the |T4638528:0|t[ExtraActionButton]
.goto 2405,25.33,69.01
>>Use the |T4638528:0|t[ExtraActionButton]
.complete 92365,2 
step
#arrowtext Click on the |cRXP_PICK_Defense Position|r
#loop
.goto 2405,25.28,69.25,10,0
.goto 2405,25.17,68.88,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Defense Position|r. Choose anything.
.complete 92365,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Null-Theorist Selune|r
.goto 2405,26.80,68.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Null-Theorist Selune|r.
.turnin 92365 >>Turn in Creating Defenses
.accept 95175 >>Accept Anchoring the Defense
.target Null-Theorist Selune
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Xy'dax|r
.goto 2405,26.39,67.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xy'dax|r.
.accept 91700 >>Accept Darkness Unmade
.target Xy'dax
step
#arrowtext Use the |T133002:0|t[ExtraActionButton]\non |cRXP_ENEMY_Oozelings|r and |cRXP_PICK_Barrels|r
#loop
.goto 2405,27.50,66.14,45,0
.goto 2405,28.50,65.13,45,0
.goto 2405,29.59,66.19,45,0
.goto 2405,27.77,68.27,45,0
>>Use the |T133002:0|t[ExtraActionButton] on |cRXP_ENEMY_Oozelings|r and |cRXP_PICK_Barrels|r
.complete 86810,1 
step
#include RestedXP Midnight\a) Go Low, Go Loud@GoLowGoLoudA-GoLowGoLoudZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Null-Theorist Selune|r
.goto 2405,26.80,68.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Null-Theorist Selune|r.
.turnin 86810 >>Turn in Harvesting the Void
.target Null-Theorist Selune
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2405,42.39,75.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.accept 90910 >>Accept Overwhelming Darkness
.target Lucia Nightbreaker
step
.goto 2405,42.41,75.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kalgorg|r
.complete 90910,1 
.target Kalgorg
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,44.69,68.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.accept 90845 >>Accept Distant Memories
.accept 90844 >>Accept Fits of Lucidity
.target Kifaan
step
#include RestedXP Midnight\a) Oaths to Family@OathsToFamilyB-OathsToFamilyZ
step
#include RestedXP Midnight\a) The Nightbreaker@TheNightbreakerB-TheNightbreakerZ
step
#label AdventureModeVoidDelveC
.goto 2405,51.35,67.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perodius|r.
.turnin 93427 >>Turn in Delver's Call: Sunkiller Sanctum
.turnin 93428 >>Turn in Delver's Call: Shadowguard Point
.target Perodius
step
#completewith DawnOfReckoningZ
#hidewindow
.xp 90
.skipto step,AdventureModeVoidstormEnd











step
.zoneskip 2405,1
.zone 2393 >>Click on the |cRXP_PICK_Portal to Silvermoon|r
.goto 2405,51.56,70.29
step
#include RestedXP Midnight\a) Into the Abyss@IntoTheAbyssA-IntoTheAbyssZ
step
#include RestedXP Midnight\a) The Night's Veil@TheNightsVeilA-TheNightsVeilZ
step
#include RestedXP Midnight\a) Dawn of Reckoning@DawnOfReckoningA-DawnOfReckoningZ
step
#label AdventureModeVoidstormEnd
>>1
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Sojourner
#internal
step
#completewith next
#label Trials and TabulationsZ
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
#completewith Trials and TabulationsZ
.goto 2393,56.28,70.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Jovia|r.
.home >>Set your Hearthstone to Wayfarer's Rest
.target Innkeeper Jovia
.skipgossipid 134012
.skipgossipid 132666
.skipgossipid 132668
step
#requires Trials and TabulationsZ
.goto 2393,56.11,71.78,10,0
.goto 2393,56.76,70.34,10,0
.goto 2393,57.64,68.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
.goto 2393,55.98,63.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Avara|r.
.accept 90835 >>Accept Murder Row: Rumors Abound
.target Avara
step
#arrowtext |cRXP_WARN_On the highest platform|r\nTalk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,51.73,64.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90835 >>Turn in Murder Row: Rumors Abound
.target Belath Dawnblade
.accept 90818 >>Accept Murder Row: Loose Lips
.accept 90837 >>Accept Murder Row: Traces of Fel
step
#title |cFFFCDC00Fly straight down|r
.goto 2393,52.44,63.54
>>Stand within the circle and use the |T237382:0|t|cRXP_WARN_[ExtraActionButton]|r and cancel it right after.
.complete 90818,1,1 
step
.goto 2393,54.52,61.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarvi|r.
.accept 90669 >>Accept Gold is Gold
.target Sarvi
step
#title Fel Magic discovered (1/5) |cFFFCDC00(Read Note)|r
.goto 2393,54.83,61.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rags|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,1 
step
#label SojournerStart1
#include a) Fear and Fel@FearAndFelD-SojournerFelMagic1
step
#include a) Tailor Troubles@TailorTroublesA-TailorTroublesB
step
#include a) Fear and Fel@SojournerLooseLips1-SojournerMerchant
step
#include a) Lesser Evil@LesserEvilB-Sojourner Warded Conduits
step
#include a) Fear and Fel@Sojourner Den of Indulgence-FearAndFelE
step
#title |cFFFCDC00on a platform high above|r
.goto 2393,53.61,76.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r |cRXP_WARN_on a pillar high above|r.
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 89200,1,4 
.mob Ward Fragment
.mob Conjured Defense
step
#include a) One Adventurous Hatchling@OneAdventurousHatchlingA-OneAdventurousHatchlingZ
step
#include a) Far Striding@FarStridingA-SojournerTowers
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Terel Bloodfate|r
.goto 2395,50.13,34.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Terel Bloodfate|r.
.accept 92396 >>Accept Calling in the Cavalry
.target Terel Bloodfate
step
.goto 2395,50.12,34.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r
.complete 92396,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Instructor Thalendir|r
.goto 2393,33.23,74.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Instructor Thalendir|r.
.accept 94393 >>Accept Career Counseling
.accept 94396 >>Accept Down a Peg
.target Instructor Thalendir
step
#arrowtext Click |cRXP_PICK_Conduit|r
.goto 2393,31.58,67.79
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Conduit|r |cRXP_WARN_on the tower|r
*|cRXP_WARN_Mount right after to avoid combat|r.
.complete 89200,1,5 
.mob Stationed Sentry
step
#include a) Lesser Evil@SojournerUnraveling Wards-SojournerOutschemed
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Telenus|r
.goto 2393,35.68,69.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Telenus|r.
.accept 92729 >>Accept Hounded and Hassled
.target Ranger Telenus
step
#include a) Scootin' Through Silvermoon@SojournerHassled-ScootinThroughSilvermoonB
step
#include a) Fear and Fel@FearAndFelF-SojournerDungeon
step
#sticky
>>Queue for the dungeon |cRXP_PICK_Murder Row|r and complete it.
.complete 90822,1 
.turnin 90822 >>Turn in Murder Row: One Fel Swoop
.macro Queue Magister's Terrace(Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeSpecificDungeon(); SetLFGDungeonEnabled(3051, true); LFGEnabledList[3051] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
.macro Queue Magister's Terrace(Follower),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3089, true); LFGEnabledList[3089] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
#include a) 90 Unlocking Systems@Astalor's Initiative-Predator Becomes Prey
step
#include a) How to Train Your Protege@HowToTrainYourProtegeA-A Test of the Hunt
step
#include a) Aspiring Academic@AspiringAcademicA-AspiringAcademicZ
step
#include a) How to Train Your Protege@SojournerLynx-HowToTrainYourProtegeX
step
#completewith next
#label SojournerRowRats
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Row Rats|r.
*|cRXP_WARN_kill them if they turn hostile|r
.complete 89202,1 
.skipgossipid 132989
.target Row Rat
step
#completewith SojournerRowRats
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires SojournerRowRats
#title Rats question (1/8) |cFFFCDC00(Read Note)|r
#arrowtext Talk to\n|cRXP_FRIENDLY_Row Rats|r
#loop
.goto 2393,54.64,63.7,15,0
.goto 2393,55.81,62.91,15,0
.goto 2393,56.21,61.54,15,0
.goto 2393,55.64,60.21,15,0
.goto 2393,54.45,61.76,15,0
.goto 2393,54.07,61.09,15,0
.goto 2393,53.55,62.59,15,0
.goto 2393,53.17,59.54,15,0
.goto 2393,52.56,58.94,15,0
.goto 2393,51.89,57.93,15,0
.goto 2393,51.42,59.87,15,0
.goto 2393,50.51,59.43,15,0
.goto 2393,50.45,57.58,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Row Rats|r.
*|cRXP_WARN_kill them if they turn hostile|r
.complete 89202,1 
.skipgossipid 132989
.target Row Rat
step
#include a) Lesser Evil@Mutual Benefit-SojournerMutualBenefit
step
.goto 2393,52.16,64,10,0
.goto 2393,51.71,63.99,10,0
.goto 2393,52.12,63.3,10,0
.goto 2393,52.89,61.84,10,0
.goto 2393,48.65,61.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lendranil|r |cRXP_WARN_to become a thief; avoid being caught|r.
.complete 89204,1 
.skipgossipid 133247
.target Lendranil
step
#label SojournerEnd1
.goto 2393,49.53,62.26
#title Use |T132307:0|t[Sprint]
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Amulet|r |cRXP_WARN_afterwards|r |T132303:0|t[Teleport Back].
.complete 89204,2 
step
#label SojournerStart2
#include a) Scootin' Through Silvermoon@ScootinThroughSilvermoonC-SojournerScoots
step
#include a) Lesser Evil@SojournerThrumming-Sojourner What We're Owed
step
#completewith next
#label Rats Can Bite
#arrowtext Leave building
.goto 2393,55.01,34.07,7,0
.goto 2393,54.85,34.65,7,0
.goto 2393,54.29,34,7,0
.goto 2393,53.54,33.09,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89207 >>Turn in Rats Can Bite
.accept 89208 >>Accept What We're Owed
.target Jaeth
.disablecheckbox
step
#completewith Rats Can Bite
#arrowtext Leave building
.goto 2393,53.01,33.20,15 >>Go upstairs and leave the building
step
#requires Rats Can Bite
#arrowtext Talk to\n|cRXP_FRIENDLY_Jaeth|r
#label SojournerEnd2
.goto 2393,53.01,33.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jaeth|r.
.turnin 89207 >>Turn in Rats Can Bite
.accept 89208 >>Accept What We're Owed
.target Jaeth
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Telenus|r
.goto 2393,35.69,69.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Telenus|r.
.turnin 92870 >>Turn in Scoot Along Now
.target Ranger Telenus
step
.goto 2393,37.37,74.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Dawnblaze|r.
.complete 89208,1 
.skipgossipid 133545
.target Magister Dawnblaze
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Dawnblaze|r
.goto 2393,37.37,74.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Dawnblaze|r.
.turnin 89208 >>Turn in What We're Owed
.target Magister Dawnblaze
step
#include a) How to Train Your Protege@HowToTrainYourProtegeY-HowToTrainYourProtegeZ
step
#include a) The Drinking Debt@TheDrinkingDebtA-TheDrinkingDebtD
step
#label SojournerStart3
#include a) Tailor Troubles@TailorTroublesC-TailorTroublesZ
step
#include a) Theft Tracking@TheftTrackingA-SojournerBark
step
#label SojournerEnd3
.goto 2395,46.91,45.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.accept 87392 >>Accept Cargo Conspiracy
.target Lyssara Duskmourne
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Cute Doggo|r
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cute Doggo|r |cRXP_WARN_after the roleplay|r.
.complete 90544,1 
.timer 7.7,RP
.skipgossipid 133262
.target Luma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Luma|r
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r |cRXP_WARN_after the roleplay|r.
.turnin 90544 >>Turn in Thief at Bark
.target Luma
step
#include a) Port Detective@PortDetectiveB-PortDetectiveZ
step
#label SojournerCampaignSupplies1
.goto 2395,39.26,56.72
>>Stand within the circle and use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92396,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Valsarin|r
.goto 2395,49.66,48.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Valsarin|r.
.turnin 91345 >>Turn in To the North Tower
.target Ranger Valsarin
.accept 91347 >>Accept Strider Stampede
step
#include a) Far Striding@SojournerValsarin-FarStridingD
step
#label SojournerCampaignSupplies2
.goto 2395,53.38,54.25
>>Stand within the circle and use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92396,3 
step
#include a) Far Striding@FarStridingE-SojournerWoods
step
#include a) Flowers for Amalthea@SojournerBlossom-SojournerMournbat
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Fern Shadestar|r
.goto 2395,37.29,73.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fern Shadestar|r.
.accept 94370 >>Accept Slithering Closer
.target Fern Shadestar
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Talandra Dawnsprite|r
.goto 2395,37.50,72.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.turnin 92021 >>Turn in Graveblossom Gardening
.turnin 92022 >>Turn in A Venomous Vocation
.accept 92023 >>Accept Suspicious Sundries
.target Talandra Dawnsprite
step
#include a) Daggerspine Landing@DaggerspineLandingB-DaggerspineLandingD
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Vehn Sorrelstride|r
.goto 2395,39.25,61.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vehn Sorrelstride|r and buy |T236211:0|t[Vial of Quicksilver].
.complete 92023,1 
.buy 254280,1
.skipgossipid 136321
.target Vehn Sorrelstride
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nara Fadebranch|r
.goto 2395,39.59,60.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nara Fadebranch|r and buy |T6011930:0|t[Flask of Dragon's Blood].
.complete 92023,2 
.buy 254281,1
.target Nara Fadebranch
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Limien Bountcask|r
.goto 2395,40.72,60.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limien Bountcask|r and buy |T132797:0|t[Bottle of Magister's Reserve].
.complete 92023,3 
.buy 254282,1
.skipgossipid 136323
.target Limien Bountcask
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Limien Bountcask|r
.goto 2395,40.71,60.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Limien Bountcask|r.
.turnin 92023 >>Turn in Suspicious Sundries
.accept 92024 >>Accept House Call
.target Limien Bountcask
step
#completewith next
#label Arcane Amassing
#arrowtext Talk to\n|cRXP_FRIENDLY_Hathvelion Sungaze|r
.goto 2395,40.21,61.01,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.turnin 91504 >>Turn in Arcane Amassing
.target Hathvelion Sungaze
step
#completewith Arcane Amassing
.goto 2395,40.21,61.35,15 >>Enter the building
step
#requires Arcane Amassing
#label DaggerspineLandingZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Hathvelion Sungaze|r
.goto 2395,40.21,61.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hathvelion Sungaze|r.
.turnin 91504 >>Turn in Arcane Amassing
.target Hathvelion Sungaze
step
#include a) Flowers for Amalthea@SojournerSundries-SojournerFlowers
step
.goto 2395,35.51,79.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Restless Spirit|r.
.accept 93850 >>Accept Windrunner Spire: Haunting Melodies
.target Restless Spirit
step
#include a) Sunbath, Take Me Away
step
#include a) Blinding Sun
step
#include a) Far Striding@A Real Assignment-FarStridingZZ
step
#include a) Runestone Rumbles@SojournerDawnstar-Then They Came
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,59.49,67.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91385 >>Turn in A Ranger's Spirit
.target Arcanist Taemin





















]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Zul'Aman Sojourner
#internal
step
#include a) Bitter Honor@BitterHonorA-BitterHonorY
step
#include a) Sawdust to Sawdust@SawdustToSawdustA-SawdustToSawdustZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nija Torntusk|r
.goto 2437,36.10,24.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r.
.accept 91406 >>Accept Far from the Hinterlands
.target Nija Torntusk
step
#include a) Abundance Campaign@Abundant Awakening1-Abundant Awakening2
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nerunda|r
.goto 2437,36.78,25.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r.
.accept 93178 >>Accept A Quiet Walk Interrupted
.target Nerunda
step
.goto 2437,37.13,23.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r |cRXP_WARN_on the second floor of the building|r.
.complete 91406,1,1 
step
.goto 2437,38.08,24.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hammer|r.
.complete 91406,1,2 
step
.goto 2437,37.13,26.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r.
.complete 91406,1,3 
step
#include a) The Sound of Her Voice@SojournerVoice-SojournerNerunda
step
.goto 2437,45.83,33.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Teapot|r.
.complete 93178,5 
step
.goto 2437,44.18,33.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Zel'kanra|r.
.accept 93667 >>Accept Camp Stonewash
.target Scout Zel'kanra
step
.goto 2437,44.14,34.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kul'amara the Fierce|r.
.accept 93575 >>Accept Maisara Caverns: Maisara Hungers
.target Kul'amara the Fierce
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nerunda|r
.goto 2437,36.78,25.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r.
.turnin 93178 >>Turn in A Quiet Walk Interrupted
.target Nerunda
.accept 93179 >>Accept Child-like Devotion
step
#include a) A Venomous History@SojournerHinterlands-AVenomousHistoryB
step
#sticky
>>Queue for the Dungeon "Maisara Caverns" on Normal Mode.
>>Kill |cRXP_ENEMY_Vordaza|r and |cRXP_ENEMY_Rak'tul|r
*Loot Vordaza for |T134321:0|t[|cRXP_LOOT_Shell of Shadra|r].
.complete 91411,1 
.complete 93575,1
.macro Queue Maisara Caverns(Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeSpecificDungeon(); SetLFGDungeonEnabled(3097, true); LFGEnabledList[3097] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
.macro Queue Maisara Caverns(Follower),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3101, true); LFGEnabledList[3101] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
#completewith next
#label Camp Stonewash
.goto 2583,52.9,73.54,10,0
.goto 2583,61.16,65.19,10,0
.goto 2583,65.95,67.28,10,0
.goto 2437,39.69,23.08,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 93667 >>Turn in Camp Stonewash
.accept 90481 >>Accept I Have a Permit
.disablecheckbox
.target Seeker Crikkash
.target Amaxi
step
#completewith Camp Stonewash
.goto 2437,46.27,26.12,620 >>Leave the Temple
step
#requires Camp Stonewash
#label Camp Stonewash2
#arrowtext Talk to\n|cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 93667 >>Turn in Camp Stonewash
.accept 90481 >>Accept I Have a Permit
.target Seeker Crikkash
.target Amaxi
step
#include a) Unlikely Friends@UnlikelyFriendsC-Zapgut Eel Stomach
step
#include a) The Sound of Her Voice@SojournerKanza-SojournerShrine
step
#include a) Unlikely Friends@SojournerStegadon-SojournerConnection
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Honnu|r
.goto 2437,47.18,24.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honnu|r.
.complete 93181,1 
.buy 265401,1
.target Honnu
step
#include a) Unlikely Friends@SojournerPrepped-SojournerDelicacies
step
#include a) The Sound of Her Voice@SojournerHonnu-SojournerTeapot
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Ren'zen|r
.goto 2437,38.30,20.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Ren'zen|r.
.turnin 90568 >>Turn in Unlikely Friends
.target Elder Ren'zen
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nerunda|r
.goto 2437,36.61,25.22,10,0
.goto 2437,36.73,25.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r.
.complete 93182,1 
.turnin 93182 >>Turn in Healing Homeward
.target Nerunda
step
#include a) The Loa of Murlocs@TheLoaOfMurlocsA-TheLoaOfMurlocsZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Jehnira|r
.goto 2437,53.12,62.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jehnira|r.
.target Jehnira
.accept 91069 >>Accept Vengeance for Tolbani
.accept 91070 >>Accept Reclaim the Goods
.accept 91071 >>Accept The Menace of Atal'Abasi
step
#include a) Vengeance for Tolbani@SojournerMenance-VengeanceForTolbaniZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Huntmaster Jinki|r
.goto 2437,44.26,66.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntmaster Jinki|r.
.turnin 93096 >>Turn in Amani Honor
.target Huntmaster Jinki
step
#include a) Got No Rhythm@SojournerRhythm-SojournerRythm2
step
#include a) Homework Support@SojournerSupport-SojournerSupport1.5
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tavikko|r
.goto 2437,45.43,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r inside the building.
.home >>Set your Hearthstone to Amani'Zar Village
.skipgossipid 132699
.target Tavikko
step
.goto 2437,43.91,65.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zak'kash|r.
.accept 89231 >>Accept A Fighter Not a Lover
.target Zak'kash
step
.goto 2437,44.03,66.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kagara|r.
.accept 89230 >>Accept A Lover Not a Fighter
.target Kagara
step
.goto 2437,43.14,67.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Dar'rak|r.
.accept 93051 >>Accept The Final Exam
.target Recruit Dar'rak
step
#include a) The Final Exam@Sojournerbegin1-Sojournerbegin2
step
.goto 2437,43.12,67.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.accept 91206 >>Accept Loa Disturbance
.target Elder Doru
step
#include a) Altar History@SojournerAltarHistory1-SojournerAltarHistory2
step
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.accept 92450 >>Accept Growing Up is Hard
.target Ani
step
#include a) Homework Support@SojournerSupport1.75-SojournerSupport2
step
#include a) No Fear@NoFearB-NoFearE
step
#include a) Healing the Spirit@SojournerCurseCleanse-SojournerMedicine0
step
.goto 2437,44.13,34.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kul'amara the Fierce|r.
.turnin 93575 >>Turn in Maisara Caverns: Maisara Hungers
.target Kul'amara the Fierce
step
#include a) A Venomous History@SojournerDeep-AVenomousHistoryZ
step
#completewith next
#label Loa's Shrine
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.turnin 92531 >>Turn in The Medicine Loa's Shrine
.target Elder Doru
step
#completewith Loa's Shrine
.hs >>Hearth to Amani'Zar Village
.cooldown item,6948,>0,1
step
#requires Loa's Shrine
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Doru|r
.goto 2437,43.12,67.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.turnin 92531 >>Turn in The Medicine Loa's Shrine
.target Elder Doru
step
.goto 2437,45.18,69.72
#title |cFFFCDC00Follow the Arrow|r
.complete 92453,1 
.timer 15,RP
step
.goto 2437,45.31,69.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.accept 89565 >>Accept The Path of Mourning
.target Chana
step
.goto 2437,45.58,69.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r.
.accept 93047 >>Accept Butchery Basics
.target Gijaniji
step
.goto 2437,45.90,70.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jak'zari|r.
.accept 93257 >>Accept Revantusk at Risk
.target Jak'zari
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
.goto 2437,45.87,72.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.turnin 89565 >>Turn in The Path of Mourning
.accept 89503 >>Accept Somber Siblings
.target Chana
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.turnin -92453 >>Turn in Fearless
.target Ani
step
#hidewindow
#completewith Boar Carcass
#loop
.goto 2437,46.04,72.65,15,0
.goto 2437,45.75,72.98,15,0
.goto 2437,46.12,73.62,15,0
.goto 2437,46.07,73.97,15,0
.goto 2437,46.3,74.69,15,0
.goto 2437,46.7,75.84,15,0
.goto 2437,47.55,76.02,15,0
.goto 2437,47.6,74.07,15,0
.goto 2437,46.44,72.28,15,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#arrowtext Click on the |cRXP_PICK_Mushrooms|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r.
*Kill |cRXP_ENEMY_Boars|r |cRXP_WARN_but only if they attack you|r.
*Loot them for |T134389:0|t[|cRXP_LOOT_Weeping Spores|r].
.complete 89503,1 
.mob Tearful Boar
.mob Weeping Swine
step
#label Boar Carcass
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#include a) Sorrowing Kin@SorrowingKinC-SorrowingKinZ
step
#include a) Between Two Trolls@SojournerEagle-SojournerHeaddress
step
.goto 2437,45.54,69.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boar|r.
.complete 93047,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.58,69.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r
.turnin 93047 >>Turn in Butchery Basics
.target Gijaniji
step
#include a) Between Two Trolls@BetweenTwoTrollsB-BetweenTwoTrollsZ
step
#include a) River-Walkers of the Prowl@SojournerRevantusk-Mania-Crab
step
.goto 2437,33.61,78.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pel'na Torntusk|r.
.accept 91813 >>Accept The Spiritpaw
.target Pel'na Torntusk
step
.goto 2437,33.58,78.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.accept 92492 >>Accept Honorin' de Sacrifice
.target Lilaju
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kahanea|r
.goto 2437,33.10,79.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93261 >>Turn in A Crab of Unusual Size
.target Kahanea
step
#include a) The Voice of Nalorakk@TheVoiceOfNalorakkA-TheVoiceOfNalorakkZ
step
#include a) Reclaiming de Honor@SojournerSacrifice-SojournerLeaders
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Sojourner
#internal
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Voidstorm Sojourner
#internal
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Silvermoon & Voidstorm
#internal
step
#include a) The Light's Summons@TheLightsSummonsA-TheLightsSummonsB
step
#completewith Scouting Map
#hidewindow
+1
step
#completewith Scouting Map
#hidewindow
.acceptmap 89402
.accept 89402 >>Accept Harandar
.acceptmap 89193
.accept 89193 >>Accept Arator
.acceptmap 86708
.accept 86708 >>Accept The Gates of Zul'Aman
.acceptmap 89388
.accept 89388 >>Accept Voidstorm
.acceptmap 94871
.accept 94871 >>Accept Eversong




step
.goto 2393,45.61,70.36
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scouting Map|r
.accept 94871 >>Accept Eversong
step
.goto 2393,45.31,70.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 89388 >>Turn in Voidstorm
.target Magister Umbric
.accept 86543 >>Accept Magisters' Terrace: Homecoming
step
#sticky
>>Queue for Magister Terrace on Normal Difficulty
.complete 86543,1 
.target Magister Umbric
step
#completewith next
#label Trials and TabulationsZ
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
#completewith Trials and TabulationsZ
.goto 2393,56.28,70.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Jovia|r.
.home >>Set your Hearthstone to Wayfarer's Rest
.target Innkeeper Jovia
.skipgossipid 134012
.skipgossipid 132666
.skipgossipid 132668
step
#requires Trials and TabulationsZ
.goto 2393,56.11,71.78,10,0
.goto 2393,56.76,70.34,10,0
.goto 2393,57.64,68.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r.
.accept 87455 >>Accept Trials and Tabulations
.target Tarenar Sunstrike
step
.goto 2393,55.98,63.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Avara|r.
.accept 90835 >>Accept Murder Row: Rumors Abound
.target Avara
step
#arrowtext |cRXP_WARN_On the highest platform|r\nTalk to\n|cRXP_FRIENDLY_Belath Dawnblade|r
.goto 2393,51.73,64.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belath Dawnblade|r.
.turnin 90835 >>Turn in Murder Row: Rumors Abound
.target Belath Dawnblade
.accept 90818 >>Accept Murder Row: Loose Lips
.accept 90837 >>Accept Murder Row: Traces of Fel
step
#title |cFFFCDC00Fly straight down|r
.goto 2393,52.44,63.54
>>Stand within the circle and use the |T237382:0|t|cRXP_WARN_[ExtraActionButton]|r and cancel it right after.
.complete 90818,1,1 
step
.goto 2393,54.52,61.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarvi|r.
.accept 90669 >>Accept Gold is Gold
.target Sarvi
step
#title Fel Magic discovered (1/5) |cFFFCDC00(Read Note)|r
.goto 2393,54.83,61.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rags|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 90837,1,1 
step
#completewith next
#label A Crimson Summons
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin -95114 >>Turn in Prey: A Crimson Summons
.target Astalor Bloodsworn
.accept 92926 >>Accept Prey: Astalor's Initiative
step
#completewith A Crimson Summons
.goto 2393,55.06,63.56,10 >>Enter the House
step
#requires A Crimson Summons
.goto 2393,56.72,65.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin -95114 >>Turn in Prey: A Crimson Summons
.target Astalor Bloodsworn
.accept 92926 >>Accept Prey: Astalor's Initiative
step
#include a) Eversong Woods Sojourner@SojournerStart1-SojournerEnd1
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
.goto 2393,45.78,65.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r.
.turnin 89193 >>Turn in Arator
.target Alonsus Faol
.accept 86837 >>Accept Meet at the Sunwell
step
#label ThePathOfLightB
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2393,45.28,60.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.complete 86837,1 
.skipgossipid 133853
.skipgossipid 133856
.target Arator
step
#include a) Eversong Woods Sojourner@SojournerStart2-SojournerEnd2
step
#include a) The Path of Light@ThePathOfLightC-SojournerArathor1
step
#completewith next
#label Homecoming
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86543 >>Turn in Magisters' Terrace: Homecoming
.target Magister Umbric
step
#completewith Homecoming
#title Use Hearthstone
.hs >>Hearth to Silvermoon City
.cooldown item,6948,>0,1
.use 6948
step
#requires Homecoming
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2393,35.15,65.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.turnin 86543 >>Turn in Magisters' Terrace: Homecoming
.target Magister Umbric
step
#completewith next
#label What We Leave Behind
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Sideras|r
.accept 91533 >>Accept What We Leave Behind
.target Riftwalker Sideras
step
#completewith What We Leave Behind
.goto 2393,35.28,66.29
.zone 2405 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Voidstorm|r
step
#requires What We Leave Behind
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Sideras|r
.goto 2405,53.71,69.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Sideras|r
.accept 91533 >>Accept What We Leave Behind
.target Riftwalker Sideras
step
.goto 2405,53.73,69.94
#arrowtext Click on the\n|cRXP_PICK_Bag|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
.complete 91533,1 
step
#completewith next
#label No Fear of the DarkZ
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 86549 >>Accept No Fear of the Dark
.target Magister Umbric
step
#completewith No Fear of the DarkZ
.goto 2405,51.57,70.3
.zone 2393 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Silvermoon|r
step
#requires No Fear of the DarkZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2393,35.15,65.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r.
.accept 86549 >>Accept No Fear of the Dark
.target Magister Umbric
step
#completewith next
#label Shadow Foci2
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadow Focus|r and then on the next one.
*|cRXP_WARN_NOTE:|r You can optimize it by clicking on the orbs at maximum range.
.complete 86549,1 
step
#completewith Shadow Foci2
.goto 2405,51.57,70.29
.zone 2393 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Voidstorm|r
step
#requires Shadow Foci2
#loop
.goto 2393,35.01,65.45,6,0
.goto 2393,35.42,65.12,6,0
.goto 2393,35.44,65.99,6,0
#arrowtext Click on the |cRXP_PICK_Shadow Focus|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadow Focus|r and then on the next one.
*|cRXP_WARN_NOTE:|r You can optimize it by clicking on the orbs at maximum range.
.complete 86549,1 
step
#include a) Into the Abyss@Shadow Foci1-A Matter of Strife and Death
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,34.38,60.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.accept 86557 >>Accept A Matter of Strife and Death
.target Lothraxion
step
#completewith LastLoci
>>Kill |cRXP_ENEMY_Voidbeings|r.
.complete 86557,1 
.mob Hungry Kilvore
.mob Cunning Harrower
.mob Ravenous Shredclaw
step
#arrowtext Click on the |cRXP_PICK_Shadestar Locus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,34.67,58.78
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadestar Locus|r.
.complete 86558,1,1 
step
.goto 2405,35.48,58.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Researcher Verigien|r.
.accept 91557 >>Accept Message to the Molt
.target Researcher Verigien
step
.goto 2405,35.79,58.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelia Everglow|r.
.accept 88755 >>Accept Scholarly Pursuits
.target Kelia Everglow
step
#arrowtext Locus activated (2/3) |cFFFCDC00(Read Note)|r
.goto 2405,36.20,57.98
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadestar Locus|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86558,1,2 
step
.goto 2405,36.03,59.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r.
.accept 92657 >>Accept The Brewing Storm
.target Lysikas
step
#label LastLoci
#arrowtext Locus activated (3/3) |cFFFCDC00(Read Note)|r
.goto 2405,36.21,60.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Shadestar Locus|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86558,1,3 
step
#loop
.goto 2405,36.14,59.85,30,0
.goto 2405,35.11,58.93,30,0
.goto 2405,36.74,58.34,45,0
>>Kill |cRXP_ENEMY_Voidbeings|r.
.complete 86557,1 
.mob Hungry Kilvore
.mob Cunning Harrower
.mob Ravenous Shredclaw
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r
.goto 2405,36.95,58.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.turnin 86557 >>Turn in A Matter of Strife and Death
.turnin 86558 >>Turn in Save a Piece of Mind
.accept 86559 >>Accept The Far, Far Frontier
.target Lothraxion
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,36.95,58.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.complete 86559,1 
.target Lothraxion
.skipgossipid 132585
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,36.94,58.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria|r.
.complete 86559,2 
.target Alleria
.skipgossipid 132609
step
#include a) Secrets in the Dark@It's Not Just a Rock!-Over My HeadZ
step
#include a) Into the Abyss@IntoTheAbyssG-IntoTheAbyssZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,35.37,58.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86536,1 
.target Decimus
.skipgossipid 132848
step
#include a) The Void Peers Back@Scholarly Pursuits-TheVoidPeersBackZ
step
#include a) Go Low, Go Loud@Turn in The Brewing Storm-GoLowGoLoudZ
step
#include a) The Night's Veil@Ethereum Refinery-Overwhelmed2
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,41.85,74.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91533 >>Turn in What We Leave Behind
.target Riftblade Astre
.accept 91535 >>Accept Home Sweet Grave
.accept 91536 >>Accept Like a Weed
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,41.72,74.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 89249 >>Turn in Overwhelmed
.accept 86544 >>Accept Post-Mortem
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Hieron|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.84,74.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Hieron|r.
.complete 86544,2 
.target Riftwalker Hieron
.skipgossipid 132751
step
#loop
.goto 2405,42.11,75.27,10,0
.goto 2405,42.34,75.44,10,0
#arrowtext Scouts assisted (2/3)\n|cRXP_ENEMY_(FRIENDLY NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scout|r.
*> Defeat them if they turn hostile.
.complete 86544,4,2 
.target Overwhelmed Scout
.mob Overwhelmed Scout
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lucia Nightbreaker|r
.goto 2405,42.39,75.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.accept 90910 >>Accept Overwhelming Darkness
.target Lucia Nightbreaker
step
.goto 2405,42.41,75.35
#arrowtext Click on\n|cRXP_PICK_Kalgorg|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Kalgorg|r
.complete 90910,1 
.target Kalgorg
step
#include a) To Be Changed@Home Sweet Grave-TeapotZ
step
#include a) The Nightbreaker@TheNightbreakerB-TheNightbreakerZ
step
#include a) A Voice Inside@TheIllusionofMotionZ-Deceit
step
.goto 2405,42.44,75.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucia Nightbreaker|r.
.turnin 91343 >>Turn in Ambition's Reward
.target Lucia Nightbreaker
step
#include a) To Be Changed@Shade of Grief-Confronting It
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,42.18,74.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.complete 86544,3 
.target Riftblade Maella
.skipgossipid 132752
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.64,73.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86544,6 
.target Decimus
.skipgossipid 132757
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lothraxion|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.46,73.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothraxion|r.
.complete 86544,5 
.target Lothraxion
.skipgossipid 132756
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Nefina|r
.goto 2405,41.44,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Nefina|r.
.turnin 91887 >>Turn in Dominion of Deceit
.target Scout Nefina
step
#include a) The Night's Veil@Maella's Report-TheNightsVeilZYX
step
#arrowtext Click on |cRXP_PICK_Decimus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,41.17,72.65
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Decimus|r after the roleplay.
.complete 86545,4 
.timer 6.8,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r after the roleplay
.goto 2405,41.14,72.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r after the roleplay.
.turnin 86545 >>Turn in The Light's Brand
.target Alleria Windrunner
step
.goto 2405,41.15,72.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.accept 86509 >>Accept Friend or Fiend
.target Decimus
step
#include a) Oaths to Family@OathsToFamilyA-Truth From Power
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Voidstorm Part 2
#internal
step
.goto 2405,51.41,72.86
#title |cFFFCDC00Follow the Arrow|r
.complete 86509,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.41,72.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.

.turnin 86509 >>Turn in Friend or Fiend
.accept 86510 >>Accept Domus Penumbra
.target Decimus
step
#include a) Dawn of Reckoning@Researching the Storm-Process a Void Sample
step
.goto 2405,51.82,71.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Knight Anais|r.
.accept 91145 >>Accept The Conquered Heroes
.target Knight Anais
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,52.12,69.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91541 >>Turn in Unchecked Emotions
.accept 91542 >>Accept The Town Inside Me
.target Riftblade Astre
step
#arrowtext Click on the |cRXP_PICK_Bones|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,51.62,70.04
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bones|r.
.complete 86510,3 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Umbric|r
.goto 2405,52.17,69.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Umbric|r after the roleplay.
.complete 91542,1 
.skipgossipid 135019
.target Magister Umbric
step
#completewith next
#label Innkeeper Hospitus
#arrowtext |cRXP_WARN_Enter the inn|r
.goto 2405,52.71,68.71,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Hospitus|r.
.complete 86510,2 
.target Innkeeper Hospitus
step
#completewith Innkeeper Hospitus
.goto 2405,53.15,68.18,60 >>Enter the Inn
step
#requires Innkeeper Hospitus
#arrowtext Talk to\n|cRXP_FRIENDLY_Innkeeper Hospitus|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,53.15,68.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Hospitus|r.
.complete 86510,2 
.target Innkeeper Hospitus
step
#arrowtext Click on the |cRXP_PICK_Meat|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,51.23,69.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Meat|r.
.complete 86510,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.03,67.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 86510 >>Turn in Domus Penumbra
.accept 90571 >>Accept The Lay of the Beast
.accept 90914 >>Accept A Born Killer
.target Decimus
step
.goto 2405,51.35,67.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perodius|r.
.accept 93810 >>Accept Masters' Perch
.target Perodius
step
.goto 2405,52.06,67.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravenia|r.
.accept 91363 >>Accept Harvest of Darkness
.target Ravenia
step
#include a) Dawn of Reckoning@TheLayOfTheBeastA-Edge of the Abyss
step
#completewith next
#label Shade of Loss
>>Kill |cRXP_ENEMY_Shade of Loss|r after the roleplay.
.complete 91542,2 
.mob Shade of Loss
step
#completewith Shade of Loss
.goto 2405,53.41,70.32
.gossipoption 135020 >>Talk to |cRXP_FRIENDLY_Riftwalker Sideras|r
.timer 4.5,RP
.target Riftwalker Sideras
step
#requires Shade of Loss
.goto 2405,53.4,70.38
>>Kill |cRXP_ENEMY_Shade of Loss|r after the roleplay.
.complete 91542,2 
.mob Shade of Loss
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2405,52.53,72.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r
.complete 91542,3 
.skipgossipid 135018
.target Riftblade Maella
step
#sticky
>>Kill |cRXP_ENEMY_Voidbeings|r.
*Loot them for the |T5976941:0|t[|cRXP_LOOT_Void Essences|r].
.complete 90914,1 
.mob Mature Consumptor
.mob Drifting Stormray
.mob Carrion Consumptor
.mob Trench Shredclaw
.mob Ravenous Voidwalker
step
#completewith next
#label Riftblade Maella2
#hidewindow
.complete 86511,1 
.target Riftblade Maella
step
#completewith Riftblade Maella2
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,54.35,74.25
.gossipoption 132535 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r and wait for the roleplay.
.timer 11,Roleplay Duration
step
#requires Riftblade Maella2
#hidewindow
#completewith Void-Infused Morsel
#loop
.goto 2405,53.89,71.15,10,0
.goto 2405,54.25,70.67,10,0
.goto 2405,54.86,68.87,10,0
.goto 2405,55.05,67.65,10,0
.goto 2405,55.83,68.25,10,0
.goto 2405,55.88,69.34,10,0
.goto 2405,55.26,70.51,30,0
.goto 2405,54.61,71.65,30,0
.goto 2405,54.07,72.23,30,0
.goto 2405,53.3,72.11,30,0
.goto 2405,53.81,74.19,30,0
.goto 2405,54.34,67.87,30,0
+1
step
#requires Riftblade Maella2
#completewith next
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for |T237353:0|t[|cRXP_LOOT_Void-Infused Morsel|r].
.complete 91363,1 
.mob Mature Consumptor
.mob Larval Consumptor
.mob Drifting Stormray
.mob Infused Klaxid
step
#requires Riftblade Maella2
#arrowtext Click on the\n|cRXP_PICK_Radiant Glowcap|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Radiant Glowcap|r.
.complete 91363,2 
step
#label Void-Infused Morsel
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for |T237353:0|t[|cRXP_LOOT_Void-Infused Morsel|r].
.complete 91363,1 
.mob Mature Consumptor
.mob Larval Consumptor
.mob Drifting Stormray
.mob Infused Klaxid
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,54.36,74.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86511 >>Turn in Edge of the Abyss
.target Alleria Windrunner
step
#include a) Dawn of Reckoning@Harvest-Torentia's attention
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Juras the Nethersent|r
.goto 2405,56.22,71.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Juras the Nethersent|r.
.accept 90782 >>Accept The Nethersent
.target Juras the Nethersent
step
.goto 2405,56.22,71.86
#arrowtext Click on the\n|cRXP_PICK_Cage|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cage|r.
.complete 90782,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2405,55.62,72.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.turnin 86513 >>Turn in Face the Tide
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,55.57,72.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86512 >>Turn in The Harvest
.accept 86514 >>Accept Lady of the Pit
.target Alleria Windrunner
step
#arrowtext Use the ExtraActionButton
.goto 2405,55.54,76.56
>>Use the |T6035316:0|t[|cRXP_WARN_ExtraActionButton|r] |cRXP_WARN_if noone has yet & might have to wait on respawn|r.
*> Defeat |cRXP_ENEMY_Torentia|r.
.complete 86514,1 
.complete 86514,2 
.timer 10,RP
.mob Torentia
step
#arrowtext Click on |cRXP_PICK_Torentia|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,55.59,78.64
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Torentia|r after the roleplay.
.complete 86514,3 
step
#arrowtext Use the ExtraActionButton\n|cRXP_ENEMY_(NOT SHARED)|r
>>Use the |T5976939:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 86514,4 
step
#completewith next
#label LadyOfThePitA
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2405,60.77,74.31,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86514 >>Turn in Lady of the Pit
.accept 86516 >>Accept All Become Prey
.target Alleria Windrunner
step
#completewith LadyOfThePitA
#arrowtext Enter the cave
.goto 2405,60.79,73.62,50 >>|cRXP_WARN_Enter the cave.|r
step
#requires LadyOfThePitA
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,60.79,73.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86514 >>Turn in Lady of the Pit
.accept 86516 >>Accept All Become Prey
.target Alleria Windrunner
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Lothraxion|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r and |cRXP_FRIENDLY_Lothraxion|r.
.accept 86517 >>Accept Vanished in the Void
.goto 2405,60.82,73.56
.target +Arator
.accept 86515 >>Accept Hollow Hunger
.goto 2405,60.71,73.62
.target +Lothraxion
step
#completewith next
#label Riftblade Maella found
#hidewindow
#arrowtext |cRXP_WARN_Leave the cave|r
.goto 2405,60.78,74.32,7,0
.complete 86517,1 
step
#completewith Riftblade Maella found
#arrowtext |cRXP_WARN_Leave the cave|r
.goto 2405,60.42,78.86,317 >>Leave the cave
step
#requires Riftblade Maella found
#completewith Riftwalker Hieron
>>Weaken |cRXP_PICK_Ultradons|r with |T1386551:0|t[Essences] from |cRXP_PICK_|TInterface/cursor/crosshair/interact.blp:18|tSlain Beasts|r and |cRXP_ENEMY_|TInterface/cursor/crosshair/attack.blp:13|tVoidbeings|r, then kill them.
.complete 86516,2 
.collect 237807,5,86516,0x2,-1
.target Slain Beast
.mob Slavering Ultradon
step
#requires Riftblade Maella found
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,60.42,78.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.complete 86517,1 
.target Riftblade Maella
.skipgossipid 132554
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Darkglen|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,61.18,80.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Darkglen|r.
.complete 86517,2 
.target Lady Darkglen
.skipgossipid 132555
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftwalker Hieron|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,62.42,82.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwalker Hieron|r.
.complete 86517,3 
.target Riftwalker Hieron
.skipgossipid 132556
step
#label Riftwalker Hieron
#arrowtext Click on the |cRXP_PICK_Journal|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,62.41,82.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Journal|r.
.complete 86517,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,62.36,82.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91542 >>Turn in The Town Inside Me
.target Riftblade Astre
.accept 91544 >>Accept Familiar Energies
.accept 91963 >>Accept Running Amok
.accept 91543 >>Accept Retaking Control
step
.goto 2405,62.44,82.47
#arrowtext Click on the\n|cRXP_PICK_First Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_First Echo|r.
.complete 91544,1 
step
#completewith Final Echo
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r to pull them near you.
.complete 91543,2 
.mob Siphoid Drone
.mob Obscurion Broodlord
.mob Prowling Harrower
.mob Scavenging Harrower
step
#completewith Final Echo
>>Kill |cRXP_ENEMY_Voidbeings|r
*Loot them for |T3072269:0|t[|cRXP_LOOT_Latent Shadowgraft|r].
.complete 91963,1 
.mob Obscurion Subjugator
.mob Void-Yoked Shredclaw
.mob Slavering Ultradon
step
#arrowtext Kill |cRXP_ENEMY_Severum|r\nLoot for |T5976941:0|t[|cRXP_LOOT_Severum's Sigil|r]
.goto 2405,64.19,75.60
>>Kill |cRXP_ENEMY_Severum|r in the building.
*Loot him for |T5976941:0|t[|cRXP_LOOT_Severum's Sigil|r].
.complete 86515,1 
.mob Severum
step
#completewith Final Echo
#arrowtext Kill |cRXP_ENEMY_Ultradons|r\nWeaken them with |T1386551:0|t[Essences] first
>>Weaken |cRXP_PICK_Ultradons|r with |T1386551:0|t[Essences] from |cRXP_PICK_|TInterface/cursor/crosshair/interact.blp:18|tSlain Beasts|r and |cRXP_ENEMY_|TInterface/cursor/crosshair/attack.blp:13|tVoidbeings|r, then kill them.
.complete 86516,2 
.collect 237807,5,86516,0x2,-1
.target Slain Beast
.mob Slavering Ultradon
step
#arrowtext Use the ExtraActionButton\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2405,64.19,75.60
>>Use the |T5976941:0|t[|cRXP_WARN_ExtraActionButton|r]
.complete 86515,2 
step
.goto 2405,61.06,80.60
#arrowtext Click on the\n|cRXP_PICK_Second Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Second Echo|r.
.complete 91544,2 
step
.goto 2405,59.57,79.07
#arrowtext Click on the\n|cRXP_PICK_Third Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Third Echo|r.
.complete 91544,3 
step
.goto 2405,59.42,77.24
#arrowtext Click on the\n|cRXP_PICK_Fourth Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fourth Echo|r.
.complete 91544,4 
step
#label Final Echo
.goto 2405,58.49,78.30
#arrowtext Click on the\n|cRXP_PICK_Final Echo|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Final Echo|r.
.complete 91544,5 
step
#hidewindow
#completewith siphoids
#loop
.goto 2405,57.72,73.48,50,0
.goto 2405,60.19,80.17,50,0
.goto 2405,63.46,74.85,50,0
+1
step
#completewith Slavering UltradonZ
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r to pull them near you.
.complete 91543,2 
.mob Siphoid Drone
.mob Obscurion Broodlord
.mob Prowling Harrower
.mob Scavenging Harrower
step
#completewith Slavering UltradonZ
>>Kill |cRXP_ENEMY_Voidbeings|r
*Loot them for |T3072269:0|t[|cRXP_LOOT_Latent Shadowgraft|r].
.complete 91963,1 
.mob Obscurion Subjugator
.mob Void-Yoked Shredclaw
.mob Slavering Ultradon
step
#label Slavering UltradonZ
#arrowtext Kill |cRXP_ENEMY_Ultradons|r\nWeaken them with |T1386551:0|t[Essences] first
>>Weaken |cRXP_PICK_Ultradons|r with |T1386551:0|t[Essences] from |cRXP_PICK_|TInterface/cursor/crosshair/interact.blp:18|tSlain Beasts|r and |cRXP_ENEMY_|TInterface/cursor/crosshair/attack.blp:13|tVoidbeings|r, then kill them.
.complete 86516,2 
.collect 237807,5,86516,0x2,-1
.target Slain Beast
.mob Slavering Ultradon
step
#completewith next
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r to pull them near you.
.complete 91543,2 
.mob Siphoid Drone
.mob Obscurion Broodlord
.mob Prowling Harrower
.mob Scavenging Harrower
step
>>Kill |cRXP_ENEMY_Voidbeings|r
*Loot them for |T3072269:0|t[|cRXP_LOOT_Latent Shadowgraft|r].
.complete 91963,1 
.mob Obscurion Subjugator
.mob Void-Yoked Shredclaw
.mob Slavering Ultradon
step
#label siphoids
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Harrowers|r and |cRXP_PICK_Squids|r to pull them near you.
.complete 91543,2 
.mob Siphoid Drone
.mob Obscurion Broodlord
.mob Prowling Harrower
.mob Scavenging Harrower
step
#include a) To Be Changed@Familiar Energies-Notatus
step
#completewith next
#label VanishedInHollowPreyA
#hidewindow
#arrowtext |cRXP_WARN_Enter the cave|r
.goto 2405,60.77,74.31,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r, |cRXP_FRIENDLY_Lothraxion|r, and |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86517 >>Turn in Vanished in the Void
.target +Arator
.turnin 86515 >>Turn in Hollow Hunger
.target +Lothraxion
.turnin 86516 >>Turn in All Become Prey
.target +Alleria Windrunner
step
#completewith VanishedInHollowPreyA
#arrowtext Enter the cave
.goto 2405,60.80,73.72,50 >>|cRXP_WARN_Enter the cave|r.
step
#requires VanishedInHollowPreyA
#arrowtext Talk to |cRXP_FRIENDLY_Arator|r,\n|cRXP_FRIENDLY_Lothraxion|r, and |cRXP_FRIENDLY_Alleria Windrunner|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r, |cRXP_FRIENDLY_Lothraxion|r, and |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86517 >>Turn in Vanished in the Void
.goto 2405,60.80,73.72
.target +Arator
.turnin 86515 >>Turn in Hollow Hunger
.goto 2405,60.71,73.62
.target +Lothraxion
.turnin 86516 >>Turn in All Become Prey
.accept 86518 >>Accept The Mantle of Predation
.goto 2405,60.79,73.61
.target +Alleria Windrunner
step
#include a) Dawn of Reckoning@Xenas2-Abyssus
step
#include a) To Be Changed@Familiar Energies-Notatus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90914 >>Turn in A Born Killer
.accept 90915 >>Accept Artifice of Aggression
.timer 9,RP
.target Decimus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ravenia|r
.goto 2405,52.06,67.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravenia|r.
.turnin 91363 >>Turn in Harvest of Darkness
.accept 91380 >>Accept Belly of the Beast
.target Ravenia
step
#include a) A Dance with the Devil@DecimusY-DecimusZ
step
#include a) A Domanaar's Best Friend@Harvest of Darkness1-Harvest of Darkness2
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90915 >>Turn in Artifice of Aggression
.accept 90916 >>Accept Seek to Destroy
.target Decimus
step
#include a) A Domanaar's Best Friend@overprey1-RaveniaTalk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Astre|r
.goto 2405,52.13,69.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91545 >>Turn in Stronger Than Before
.target Riftblade Astre
.accept 91546 >>Accept To Be Changed
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Umbric|r
.goto 2405,52.18,69.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umbric|r
.complete 91546,1 
.skipgossipid 135195
.target Umbric
step
#include a) A Domanaar's Best Friend@MightyZ-Mighty
step
#include a) A Dance with the Devil@Harvester of Savagery-Nascent Blade
step
#include a) Dawn of Reckoning@XenasZ-Hunt the Light
step
.isOnQuest 86521
.cast 1254563 >>Use |T7553062:0|t[Path of the Fractured Core]
.use 1254563
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,61.27,61.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90918 >>Turn in The Unforgiven
.turnin 90917 >>Turn in Harvester of Savagery
.accept 90919 >>Accept The Fiend That Failed
.target Decimus
step
#include a) Dawn of Reckoning@XenasZZ-DecimusXenas
step
#include a) A Dance with the Devil@TheFiendThatFailedA-DecimusKill
step
#include a) Shadow Puppets@ShadowPuppetsB-Anais
step
#completewith next
#label TheNethersentA
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2405,40.19,49.11,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90782 >>Turn in The Nethersent
.accept 90866 >>Accept Universal Language
.target Tul'amar, Twice-Exiled
step
.isOnQuest 90782
#completewith next
#title Enter the cave
.goto 2405,39.87,48.98,35 >>|cRXP_WARN_Enter the cave|r.
step
#requires TheNethersentA
#arrowtext Talk to\n|cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r
.goto 2405,39.87,48.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tul'amar, Twice-Exiled|r.
.turnin 90782 >>Turn in The Nethersent
.accept 90866 >>Accept Universal Language
.target Tul'amar, Twice-Exiled
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,40.26,49.19,20,0
.goto 2405,37.68,48.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r.
.turnin 90848 >>Turn in She Started the Fire
.accept 90852 >>Accept Techno-Magnetic Pulse
.accept 90851 >>Accept Eating Their Own
.target Kifaan
step
#include a) Oaths to Family@She Started the Fire-his sister
step
#include a) Pathogenic Problem@PathogenicProblemA-Antidote administered
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Philanas|r
.goto 2405,34.66,43.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Philanas|r.
.accept 93801 >>Accept Calculated Culling
.target Scout Philanas
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kifaan|r
.goto 2405,36.30,43.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kifaan|r after the roleplay.
.turnin 93396 >>Turn in Bursting at the Seams
.target Kifaan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Veraan|r
.goto 2405,36.33,44.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veraan|r.
.accept 90858 >>Accept Repress the Oppressors
.target Veraan
step
#include a) Pathogenic Problem@PathogenicProblemA-Antidote administered
step
#include a) Pathogenic Problem@Calculated Culling-PathogenicProblemZ
step
#include a) Oaths to Family@Shadowguard operation-Soulbinder D'zaar
step
#loop
.goto 2405,40.83,37.01,35,0
.goto 2405,40.76,45.34,35,0
>>Kill |cRXP_ENEMY_Beasts|r.
*Loot them for the |T1129420:0|t[|cRXP_LOOT_Predator Blood|r].
.complete 90866,1 
.mob Shredclaw Packhunter
.mob Hunting Netherwasp
.mob Ultradon Tyrant
step
#include a) The Nethersent@UniversalLanguageB-Across Worlds
step
.goto 2444,39.88,83.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftwarden Theremen|r.
.turnin 93810 >>Turn in Masters' Perch
.target Riftwarden Theremen
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,39.93,84.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.accept 92603 >>Accept O Lonely Star
.target Orin Straylight
step
.goto 2444,39.93,84.25
#arrowtext Click on\n|cRXP_PICK_Orin Straylight|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Orin Straylight|r.
.complete 92603,1 
.timer 2.5,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lanlae Noxa|r
.goto 2444,39.75,84.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanlae Noxa|r.
.accept 92390 >>Accept Risk for Research
.target Lanlae Noxa
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,39.93,84.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.complete 92603,2 
.target Orin Straylight
.skipgossipid 136761
step
#include a) Shadow Puppets@Turn in The Conquered Heroes-ShadowPuppetsZ
step << Alliance
#include a) Breaking the Triad@BreakingTheTriadA-Hateboundss
step << Alliance
#arrowtext Talk to\n|cRXP_FRIENDLY_Vidious|r
.goto 2444,50.80,58.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vidious|r |cRXP_WARN_on the bridge|r.
.turnin 91599 >>Turn in Voidscar Arena: A Familiar Grudge
.turnin 91598 >>Turn in Voidscar Arena: Pre-Provoked Violence
.accept 91600 >>Accept Voidscar Arena: Setting It Aside
.target Vidious
step << Horde
#include a) Breaking the Triad@BreakingTheTriadA-BreakingTheTriadAA
step << Horde
#include a) A Gift, Given Freely@AGiftGivenFreelyC-AGiftGivenFreelyZ
step
#include a) Shadowguard's Shadow@ShadowguardsShadowB-Let It In


step
#include a) Shadowguard's Shadow@ShenzarRefinery-ShadowguardsShadowZ
step
#include a) Breaking the Triad@BreakingTheTriadE-BreakingTheTriadG
step
#completewith Carve New Shapes
>>Complete the Voidscar Arena Dungeon on any difficulty.
.complete 91694,1

step << Alliance
#include a) A Gift, Given Freely@AGiftGivenFreelyC-Subdue Orin
step << Alliance
#label Carve New Shapes
#arrowtext Talk to\n|cRXP_FRIENDLY_Orin Straylight|r
.goto 2444,33.29,37.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orin Straylight|r.
.turnin 92607 >>Turn in And Carve New Shapes
.target Orin Straylight

step
>>Complete the Voidscar Arena Dungeon on any difficulty.
.complete 91694,1
step
#completewith next
#label Scoot Along Now2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Telenus|r.
.turnin 92870 >>Turn in Scoot Along Now
.target Ranger Telenus
step
#completewith Scoot Along Now2
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires Scoot Along Now2
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Telenus|r
.goto 2393,35.69,69.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Telenus|r.
.turnin 92870 >>Turn in Scoot Along Now
.target Ranger Telenus
step
.goto 2393,37.37,74.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Dawnblaze|r.
.complete 89208,1 
.skipgossipid 133545
.target Magister Dawnblaze
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magister Dawnblaze|r
.goto 2393,37.37,74.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Dawnblaze|r.
.turnin 89208 >>Turn in What We're Owed
.target Magister Dawnblaze
step
#include a) How to Train Your Protege@HowToTrainYourProtegeY-HowToTrainYourProtegeZ
step
#completewith next
#label TheDrinkingDebtB
#arrowtext Talk to\n|cRXP_FRIENDLY_Gidwin Goldbraids|r
.goto 2393,33.4,88.72,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.turnin 87455 >>Turn in Trials and Tabulations
.target Gidwin Goldbraids
.accept 87456 >>Accept Souvenirs Scattered
.disablecheckbox
.accept 87457 >>Accept What We Do Best
.disablecheckbox
step
.isOnQuest 87455
#completewith TheDrinkingDebtB
#title Enter the building
.goto 2393,33.38,89.37,12 >>|cRXP_WARN_Enter the building.|r
step
#requires TheDrinkingDebtB
#arrowtext Talk to\n|cRXP_FRIENDLY_Gidwin Goldbraids|r
.goto 2393,33.38,89.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gidwin Goldbraids|r.
.turnin 87455 >>Turn in Trials and Tabulations
.timer 9.5,RP
.target Gidwin Goldbraids
step
#completewith next
#label Talk to Astre
#hidewindow
.complete 91546,2 
.target Astre
step
#completewith Talk to Astre
.goto 2405,51.57,70.29
#arrowtext Click on the Portal
.zone 2393 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Silvermoon|r
step
#requires Talk to Astre
.goto 2393,32.33,87.29
#title |cFFFCDC00Follow the Arrow|r
.complete 91546,2 
.skipgossipid 135198
.target Astre
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Astre|r
.goto 2393,32.33,87.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astre|r
.complete 91546,3 
.skipgossipid 135198
.target Astre
step
#label Turn in To Be Changed
.goto 2393,31.62,88.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Astre|r
.turnin 91546 >>Turn in To Be Changed
.target Riftblade Astre
step
#include a) The Drinking Debt@Souvenirs Scattered-TheDrinkingDebtD
step
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong & Harandar Part 1
#internal
step
#include a) Eversong Woods Sojourner@SojournerStart3-SojournerEnd3
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r
.goto 2395,46.71,45.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r.
.turnin 94871 >>Turn in Eversong
.target Magistrix Landra Dawnstrider
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r
.goto 2395,46.71,45.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Landra Dawnstrider|r.
.accept 86738 >>Accept Sharpmaw
.accept 86739 >>Accept Fairbreeze Favors
.target Magistrix Landra Dawnstrider
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,46.66,45.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 86740 >>Accept Displaced Denizens
.target Orweyna
step
#arrowtext Citizens helped (1/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,46.52,45.91
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Injured Pet|r.
.complete 86739,4,1 
.target Injured Pet
step
#arrowtext Chair investigated (1/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,45.94,45.51
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chair|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,1,1 
step
#completewith next
#label Mr. Fluffy
#hidewindow
.complete 86739,4,2 
step
#completewith Mr. Fluffy
.goto 2395,45.64,45.47
#arrowtext Cat helped (2/3)\n|cFFFCDC00(Read Note)|r
.cast 1234073 >>Click on |cRXP_PICK_Mr. Fluff|r on the statue.
step
#requires Mr. Fluffy
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 89402 >>Turn in Harandar
.accept 86899 >>Accept The Root Cause
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.40,45.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86899,1 
.timer 25,RP
.skipgossipid 135559
.target Orweyna
step
#arrowtext Nest investigated (2/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,45.50,46.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nest|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,1,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Cute Doggo|r
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cute Doggo|r |cRXP_WARN_after the roleplay|r.
.complete 90544,1 
.timer 7.7,RP
.skipgossipid 133262
.target Luma
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Luma|r
.goto 2395,38.93,38.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luma|r |cRXP_WARN_after the roleplay|r.
.turnin 90544 >>Turn in Thief at Bark
.target Luma
step
#completewith CompleteWyrm
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
#completewith CompleteWyrm
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
#completewith CompleteWyrm
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#arrowtext Plants examined (1/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,44.83,44.00
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Plant|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,2,1 
step
#arrowtext Citizens helped (3/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,44.72,44.97
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tomes|r.
.complete 86739,4,3 
step
#arrowtext Click on the |cRXP_PICK_Bush|r\n|cRXP_WARN_Cancel the channel|r
.goto 2395,46.25,44.10
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r.
.complete 87392,1 
step
#arrowtext Click on the |cRXP_PICK_Dummy|r\n|cRXP_WARN_Cancel the channel|r
.goto 2395,45.92,45.09
*|cRXP_WARN_Open and close the Game Menu to cancel the cast and restore all actions immediately|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dummy|r.
.complete 87392,2 
step
#arrowtext Click on the |cRXP_PICK_Fake Bush|r\n|cRXP_WARN_Cancel the channel|r
.goto 2395,47.00,46.03
*|cRXP_WARN_Open and close the Game Menu to cancel the cast and restore all actions immediately|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fake Bush|r
.complete 87392,3 
step
#arrowtext Click on the |cRXP_PICK_Notes|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,47.06,46.27
*|cRXP_WARN_Open and close the Game Menu to cancel the cast and restore all actions immediately|r.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Notes|r
.complete 87392,4 
step
#arrowtext Bush investigated (3/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.21,46.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bush|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,1,3 
step
#arrowtext Plants examined (2/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,47.64,46.45
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_plant|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,2,2 
step
.goto 2395,45.82,47.9
#title |cFFFCDC00Follow the Arrow|r
.complete 86738,1 
step
.goto 2395,45.82,47.9
#arrowtext Click on the\n|cRXP_PICK_Sharpmaw|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Sharpmaw|r.
.complete 86738,2 
.target Sharpmaw
step
#label CompleteWyrm
#arrowtext Plants examined (3/3)\n|cFFFCDC00(Read Note)|r
.goto 2395,45.60,46.76
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Plant|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86740,2,3 
step
#include a) Of Caves and Cradles@SojournerCampaignHarandar-OfCavesAndCradlesBA
step
.goto 2413,70.33,52.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Motta|r.
.accept 90615 >>Accept Be Grudge You
.target Motta
step
.goto 2413,69.41,52.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ketan|r.
.accept 92882 >>Accept A Hunter's Plight
.target Ketan
step
#arrowtext Talk to |cRXP_FRIENDLY_Ruia|r\nand |cRXP_FRIENDLY_Orweyna|r
.goto 2413,70,51.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ruia|r and |cRXP_FRIENDLY_Orweyna|r.
.turnin 86900 >>Turn in To Har'athir
.accept 86901 >>Accept The Rift and the Den
.target Ruia
.target Orweyna







step
#include a) Hunter's Rights@Elder Akazi-SojournerCampaignPlightEnd1
step
.goto 2413,69.54,50.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'tar|r.
.accept 92865 >>Accept Feeding the Buds
.target Ney'tar
.accept 92864 >>Accept Drift Them Away
step
#hidewindow
#completewith Grovecrawler Fangs
#loop
.goto 2413,68.73,47.13,30,0
.goto 2413,68.26,44.14,30,0
.goto 2413,69.83,41.23,30,0
.goto 2413,71.59,41.77,30,0
.goto 2413,71.07,43.49,30,0
+1
step
#completewith Tail Spore
>>Kill |cRXP_ENEMY_Slithering Grovecrawler|r
*Loot them for |T134298:0|t[|cRXP_LOOT_Grovecrawler Fangs|r].
.complete 92883,2 
.mob Slithering Grovecrawler
step
#completewith Tail Spore
>>Kill |cRXP_ENEMY_Violet Chloroceros|r
*Loot them for |T3586015:0|t[|cRXP_LOOT_Chloroceros Bone|r] and |T1029740:0|t[|cRXP_LOOT_Chloroceros Buds|r].
.complete 92883,1 
.complete 92865,1 
.mob Violet Chloroceros
step
#label Tail Spore
#arrowtext Click on the\n|cRXP_PICK_Tails|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tails|r
.complete 92883,4 
step
#completewith next
>>Kill |cRXP_ENEMY_Slithering Grovecrawler|r
*Loot them for |T134298:0|t[|cRXP_LOOT_Grovecrawler Fangs|r].
.complete 92883,2 
.mob Slithering Grovecrawler
step
>>Kill |cRXP_ENEMY_Violet Chloroceros|r
*Loot them for |T3586015:0|t[|cRXP_LOOT_Chloroceros Bone|r] and |T1029740:0|t[|cRXP_LOOT_Chloroceros Buds|r].
.complete 92883,1 
.complete 92865,1 
.mob Violet Chloroceros
step
#label Grovecrawler Fangs
>>Kill |cRXP_ENEMY_Slithering Grovecrawler|r
*Loot them for |T134298:0|t[|cRXP_LOOT_Grovecrawler Fangs|r].
.complete 92883,2 
.mob Slithering Grovecrawler
step
#loop
.goto 2413,72.17,40.83,30,0
.goto 2413,72.55,38.18,30,0
.goto 2413,71.69,36.21,30,0
.goto 2413,71.29,38.9,30,0
>>Kill |cRXP_ENEMY_Lashers|r
*Loot them for |T134218:0|t[|cRXP_LOOT_Lasher Vines|r].
.complete 92883,3 
.mob Spiteful Lasher
step
#hidewindow
#label SojournerCampaignDrifterStart1
#completewith Cascade Drifter
#loop
.goto 2413,70.3,39.9,10,0
.goto 2413,70.12,39.47,10,0
.goto 2413,69.77,39.56,10,0
.goto 2413,69.72,39.18,10,0
.goto 2413,69.28,39.53,10,0
.goto 2413,68.83,39.3,10,0
.goto 2413,68.8,37.9,30,0
.goto 2413,70.53,38.6,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Cascade Drifter|r
.complete 92864,1 
.mob Cascade Drifter
step
#arrowtext Click on the\n|cRXP_PICK_Sacks|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Sacks|r
.complete 92864,2 
step
#label Cascade Drifter
>>Kill |cRXP_ENEMY_Cascade Drifter|r
.complete 92864,1 
.mob Cascade Drifter








step
#include a) Predator Reintroduction@SojournerCampaignfed1-ReHydrated
step
#include a) Hunter's Rights@SojournerCampaignAHuntersDuty-SojournerCampaignAHuntersDuty2
step
#include a) A Palette of Feelings@SojournerCampaignPigment1-Mushroom Pigment
step
#include a) Hunter's Rights@Hunter's Weapon-SojournerCampaignAHuntersDuty2
step
#include a) The Grudge Pit 2@You Strong?-YouStrong?End1
step
#include a) A Palette of Feelings@SojournerCampaignColors1-SojournerCampaignPigment2
step
.isOnQuest 86739
.zoneskip 2413,1
.goto 2413,75.68,53.62,10,0
.goto 2413,75.88,54.83
.zone 2393 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Eversong Woods|r
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Eversong Woods Part 2
#internal
step
#hidewindow
#completewith CompleteWyrmLoop
#loop
.goto 2395,44.64,45.15,40,0
.goto 2395,44.46,44.08,40,0
.goto 2395,45.62,44.44,40,0
.goto 2395,46.77,44.69,40,0
.goto 2395,47.53,46.45,40,0
.goto 2395,46.01,47.34,40,0
+1
step
#completewith CompleteLynx
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
#completewith CompleteLynx
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
#label CompleteLynx
>>Defeat |cRXP_ENEMY_Displaced Lynx|r and then click on them.
.complete 86739,3 
.mob Displaced Lynx
.target Displaced Lynx
step
#completewith next
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
>>Use the |T132270:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Hawkstriders|r.
.complete 86739,2 
.target Displaced Hawkstrider
step
#label CompleteWyrmLoop
>>Kill |cRXP_ENEMY_Wyrms|r.
.complete 86739,1 
.mob Erratic Light Wyrm
step
#include a) Whispers in the Twilight@WhispersInTheTwilightEA-WhispersInTheTwilightF
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lyssara Duskmourne|r
.goto 2395,46.91,45.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyssara Duskmourne|r.
.turnin 87392 >>Turn in Cargo Conspiracy
.target Lyssara Duskmourne
.accept 87393 >>Accept Warranted Search
.accept 87394 >>Accept Supplier Surveillance
step
#include RestedXP Midnight\a) Port Detective@PortDetectiveDB-PortDetectiveZ
step
#include a) Whispers in the Twilight@WhispersInTheTwilightG-SojournerCampaignGrowth
step
.goto 2395,39.26,56.72
#arrowtext Use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
>>Stand within the circle and use the |T132765:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92396,2 
step
#include a) Whispers in the Twilight@SojournerCampaignGrowth2-SojournerCampaignTrail
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.89,55.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_after the roleplay|r.
.turnin 86742 >>Turn in Curious Cultivation
.turnin 86743 >>Turn in Trimming the Lightbloom
.accept 86744 >>Accept Seeking Truth
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,45.89,55.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.complete 86744,1 
.target Orweyna
.skipgossipid 132833
step
.goto 2395,46.1,55.11
>>Kill |cRXP_ENEMY_Lightfused|r.
.complete 86744,2 
.timer 18,RP
.mob Lightfused Defender
.mob Lightfused Leafmancer
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ranger Asterae|r
.goto 2395,48.59,57.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ranger Asterae|r.
.turnin 91462 >>Turn in To the Central Tower
.target Ranger Asterae
.accept 91348 >>Accept See a Mana 'bout a Wyrm
step
#loop
.goto 2395,47.9,56.22,40,0
.goto 2395,48.01,57.37,40,0
.goto 2395,49.08,56.09,40,0
.goto 2395,48.74,54.65,40,0
>>Kill |cRXP_ENEMY_Agitated Wyrms|r
.complete 91348,1 
.mob Agitated Wyrm
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2395,47.36,55.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r |cRXP_WARN_after the roleplay|r.
.turnin 86744 >>Turn in Seeking Truth
.target Orweyna
step
#include a) Whispers in the Twilight@Contact Silvermoon-WhispersInTheTwilightZ
step
#include a) Eversong Woods Sojourner@SojournerCampaignSupplies1-SojournerCampaignSupplies2
step
#include a) Far Striding@AgiWyrms-FarStridingG
step
#include a) Shadowfall@SojournerCampaignShadowfall1-SojounerCampaignMagister
step
#completewith next
#label RationalExplanationB
#hidewindow
#arrowtext Enter the inn
.goto 2395,49.25,67.6,5,0
.goto 2395,48.96,68.41,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Kalarin|r.
.complete 86624,3 
.complete 86624,4 
.target Innkeeper Kalarin
.skipgossipid 132744
step
#completewith RationalExplanationB
.goto 2395,48.96,68.58,10 >>Enter the Inn
step
#requires RationalExplanationB
#arrowtext Talk to\n|cRXP_FRIENDLY_Innkeeper Kalarin|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2395,48.96,68.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Kalarin|r.
.complete 86624,3 
.home >>Set your Hearthstone to Tranquillien
.target Innkeeper Kalarin
.skipgossipid 132744
.skipgossipid 137856
step
#include a) Shadowfall@RationalExplanationE-SojounerCampaignMagister2
step
#include a) Far Striding@FarStridingEE-SojournerWoods
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Talandra Dawnsprite|r
.goto 2395,37.50,72.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.accept 92021 >>Accept Graveblossom Gardening
.accept 92022 >>Accept A Venomous Vocation
.target Talandra Dawnsprite
step
.goto 2395,37.30,73.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fern Shadestar|r.
.accept 94370 >>Accept Slithering Closer
.target Fern Shadestar
step
#include a) Shadowfall@ShadowfallC-SojournerCampaignDeatholme
step
#hidewindow
#completewith Potent
#loop
.goto 2395,37.88,76.32,30,0
.goto 2395,38.11,77.12,30,0
.goto 2395,38.89,76.44,30,0
.goto 2395,39.09,77.06,30,0
.goto 2395,39.58,76.65,30,0
.goto 2395,39.84,76.34,30,0
.goto 2395,40.18,75.01,30,0
.goto 2395,40.01,74.19,30,0
.goto 2395,39.52,74.72,30,0
.goto 2395,38.56,73.99,30,0
.goto 2395,38.25,72.45,30,0
+1
step
#completewith next
>>Kill the |cRXP_ENEMY_Bats|r.
*Loot them for the |T6011929:0|t[|cRXP_LOOT_Potent Mournbat Venom|r].
.complete 92022,1 
.mob Venomous Mournbat
.mob Elder Mournbat
step
#arrowtext Click on the\n|cRXP_PICK_Flowers|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Flowers|r
.complete 92021,1,8 
step
#label Potent
>>Kill |cRXP_ENEMY_Bats|r
*Loot them for |T6011929:0|t[|cRXP_LOOT_Potent Mournbat Venom|r].
.complete 92022,1 
.mob Venomous Mournbat
.mob Elder Mournbat
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Talandra Dawnsprite|r
.goto 2395,37.50,72.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talandra Dawnsprite|r.
.turnin 92021 >>Turn in Graveblossom Gardening
.turnin 92022 >>Turn in A Venomous Vocation
.accept 92023 >>Accept Suspicious Sundries
.target Talandra Dawnsprite
step
#include a) Daggerspine Landing@DaggerspineLandingB-DaggerspineLandingD
step
#include a) Flowers for Amalthea@SojournerCampaignVial1-SojournerSundries
step
#include a) Daggerspine Landing@Arcane Amassing-DaggerspineLandingZ
step
#include a) Flowers for Amalthea@First clue found-SojournerFlowers
step
.goto 2395,35.51,79.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Restless Spirit|r.
.accept 93850 >>Accept Windrunner Spire: Haunting Melodies
.target Restless Spirit
step
#include a) Shadowfall@SojournerCampaignDeatholme2-ShadowfallZ
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,44.64,85.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.accept 86637 >>Accept Anything but Reprieve
.target Arator
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arator|r
.goto 2395,44.64,85.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arator|r.
.complete 86637,1 
.skipgossipid 133785

step
.isOnQuest 87458
.enterScenario 2926 >>Use the macro in the "Active Items Frame" to Queue for Murder Row
.macro Queue Follower Dungeon,1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3089, true); LFGEnabledList[3089] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step << Alliance
.isOnQuest 87458
.isInScenario 2926
.zone 2352 >>Use |T7252953:0|t[Teleport to Plot] inside the follower dungeon.
step << Horde
.isOnQuest 87458
.isInScenario 2926
.zone 2351 >>Use |T7252953:0|t[Teleport to Plot] inside the follower dungeon.
step
.isOnQuest 87458
.zone 2393 >>Use |T7252953:0|t[Return to Previous Location] inside the follower dungeon.
step
.isQuestComplete 92177
.goto 2393,55.05,63.56,10,0
.goto 2393,56.72,65.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r
.turnin 92177 >>Turn in One Hero's Prey
.target Astalor Bloodsworn
.accept 92178 >>Accept Practical Magic
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Tarenar Sunstrike|r
.goto 2393,57.63,68.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tarenar Sunstrike|r |cRXP_WARN_infront of a building|r.
.turnin 87458 >>Turn in Debts Paid
.target Tarenar Sunstrike
step
.goto 2393,56.72,65.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Astalor Bloodsworn|r.
.turnin 93086 >>Turn in To the Sanctum!
.target Astalor Bloodsworn
step << Alliance
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Taelia Fordragon|r
.goto 2393,53.15,69.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taelia Fordragon|r
.accept 90546 >>Accept Missing Paladins
.target Taelia Fordragon
step << Horde
.xp <90,1
#arrowtext Talk to\n|cRXP_FRIENDLY_Salandria|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salandria|r
.goto 2393,53.21,69.52
.accept 90547 >>Accept Missing Paladins
.target Salandria
step
#arrowtext |cFFFCDC00down below in a building|r\nTalk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2393,52.55,78.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 91822 >>Accept The Regent's Request
.target Valeera Sanguinar
step
.goto 2393,52.77,77.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93372 >>Turn in Delver's Call: Shadow Enclave
.target Naleidea Rivergleam
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,33.55,36.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.complete 91822,1 
.skipgossipid 135475
.target Lor'themar Theron
step
.isOnQuest 90546 << Alliance
.isOnQuest 90547 << Horde
#title Use Hearthstone
.hs >>Hearth to Tranquillien
.cooldown item,6948,>0,1
.use 6948
step
#include a) Paladin Rescue@Struggle-the Head
step
#completewith next
#label A Fish!
.zoneskip 2393,1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r.
.accept 91271 >>Accept A Fish!
.target Valdekar Solaar
step
#completewith A Fish!
#title Use Hearthstone
.hs >>Hearth to Tranquillien
.cooldown item,6948,>0,1
.use 6948
step
#requires A Fish!
#arrowtext Talk to\n|cRXP_FRIENDLY_Valdekar Solaar|r
.goto 2395,48.76,76.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valdekar Solaar|r.
.accept 91271 >>Accept A Fish!
.target Valdekar Solaar
step
#include a) Sunbath, Take Me Away@Fish!SojournerCampaign1-Fish!SojournerCampaign2
step
#include a) Blinding Sun@BlindingSunA-Evidence of researchers found
step
.goto 2395,50.20,74.05
>>Kill |cRXP_ENEMY_Liya Waterbloom|r.
.complete 91137,1 
.mob Liya Waterbloom
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kaliel Solaar|r
.goto 2395,48.77,76.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaliel Solaar|r.
.turnin 91137 >>Turn in Lost in Light
.target Kaliel Solaar
step
#include a) Blinding Sun@Sunbeams-BlindingSunZ
step
#include a) Far Striding@A Real Assignment-FarStridingZZ
step
#include a) Runestone Rumbles@SojournerDawnstar-Then They Came
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Arcanist Taemin|r
.goto 2395,59.49,67.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Taemin|r.
.turnin 91385 >>Turn in A Ranger's Spirit
.target Arcanist Taemin
step
#include a) The Regent's Request@Dead Men Keep No Secrets-TheRegentsRequestC
step
#include a) Dis Was Our Land@DisWasOurLandAA-DisWasOurLandB
step
.isOnQuest 86901
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
.isOnQuest 86901
.goto 2393,36.95,68.02
.zone 2576 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Harandar|r
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar & Eversong Part 2
#internal
step
#completewith next
#label Halduron
#arrowtext |cFFFCDC00Follow the Arrow|r
#hidewindow
.complete 86901,2 
.target Halduron Brightwing
step
#completewith Halduron
.goto 2393,36.93,68.02
.zone 2576 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Harandar|r
step
#requires Halduron
.goto 2413,54.79,51.21
#arrowtext |cFFFCDC00Follow the Arrow|r
>>Skyride to |cRXP_FRIENDLY_Halduron Brightwing|r
.complete 86901,2 
.target Halduron Brightwing
step
#include a) Of Caves and Cradles@SojournerCampaignRift-CouncilAssembles
step
.isOnQuest 86907
#arrowtext |cFFFCDC00Fly up through the opening|r\nTalk to\n|cRXP_FRIENDLY_Yinaa|r
.goto 2413,51.23,53.47,25,0
.goto 2413,50.86,55.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yinaa|r.
.home >>Set your Hearthstone to The Den
.skipgossipid 132729
.target Yinaa
step
.goto 2413,50.75,55.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ravi|r.
.accept 93775 >>Accept Har'mara, Village of Balance
.target Ravi
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Monte Gazlowe|r
.goto 2413,51.05,55.35,10,0
.goto 2413,47.08,45.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Monte Gazlowe|r
.accept 90533 >>Accept Go Get Orweyna!
.target Monte Gazlowe
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Hagar|r
.goto 2413,38.85,46.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hagar|r.
.turnin 86907 >>Turn in The Den of Echoes
.accept 86911 >>Accept Echoes and Memories
.target Hagar
step
#include a) Of Caves and Cradles@Zur'ashar Kassameh-SojournerCampaignRootways1
step
#completewith next
#label A Hut in Har'mara
#arrowtext Enter on the first floor
.goto 2413,34.9,24.5,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86913 >>Turn in A Hut in Har'mara
.target Orweyna
step
#completewith A Hut in Har'mara
.goto 2413,35,23.9,10 >>Enter the building first floor
step
#requires A Hut in Har'mara
#arrowtext Talk to |cRXP_FRIENDLY_Orweyna|r, |cRXP_FRIENDLY_Hagar|r\nand |cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,34.88,25.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r, |cRXP_FRIENDLY_Hagar|r and |cRXP_FRIENDLY_Halduron Brightwing|r.
.turnin 93775 >>Turn in Har'mara, Village of Balance
.turnin 86913 >>Turn in A Hut in Har'mara
.accept 91872 >>Accept The Former Rootwarden
.accept 86914 >>Accept Tending to Har'mara
.accept 86956 >>Accept The Traveling Flowers
.target Orweyna
.target Halduron Brightwing
.target Hagar
step
#include a) Of Caves and Cradles@Tasks completed1-SojournerCampaignRizam
step
.goto 2413,36.96,25.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ney'leia|r.
.accept 90537 >>Accept Late Bloomers
.target Ney'leia
step
#include a) Of Caves and Cradles@SojournerCampaignKeem-Burning Bitterblooms
step
#completewith Teetem
#hidewindow
.complete 89034,1 
.complete 86973,1 
step
#completewith Teetem
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86973,1 
.mob Lightbloom Thornguard
.mob Lightbloom Grovewarden
.mob Lightbloom Sap Weaver
step
#completewith Teetem
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Flowers|r.
.complete 89034,1 
step
#label Teetem
.goto 2413,36.85,24.09
>>Kill |cRXP_ENEMY_Teetem|r.
.complete 86942,4 
.mob Teetem
step
#include a) Harandar's Kitchen@FreshGarden-RootDash
step
#hidewindow
#completewith next
#loop
.goto 2413,37.24,24.85,15,0
.goto 2413,36.98,25.63,20,0
.goto 2413,37.05,26.23,20,0
.goto 2413,36.42,26.56,10,0
.goto 2413,35.72,27.45,20,0
.goto 2413,35.18,26.95,20,0
.goto 2413,35.69,26.02,25,0
+1
step
#completewith Leaders
#label LightbloomBitterbloomsA
#hidewindow
.complete 89034,1 
.complete 86973,1 
step
#completewith Leaders
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86973,1 
.mob Lightbloom Thornguard
.mob Lightbloom Grovewarden
.mob Lightbloom Sap Weaver
step
#completewith Leaders
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Flowers|r.
.complete 89034,1 
step
#label Leaders
#loop
>>Kill the |cRXP_ENEMY_Leaders|r.
.complete 86942,2 
.complete 86942,1 
.goto 2413,35.72,27.45,15,0
.complete 86942,4 
.goto 2413,36.85,24.09,15,0
.complete 86942,3 
.goto 2413,36.96,25.62,15,0
.mob Rizam
.mob Teetem
.mob Keem
.mob Koozat
step
#hidewindow
#completewith Lightblooms
#loop
.goto 2413,35.69,25.28,30,0
.goto 2413,36.44,25.69,30,0
.goto 2413,36.41,24.21,30,0
.goto 2413,37.71,23.89,30,0
.goto 2413,36.74,26.77,30,0
.goto 2413,35.13,26.36,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86973,1 
.mob Lightbloom Thornguard
.mob Lightbloom Grovewarden
.mob Lightbloom Sap Weaver
step
#arrowtext Click on the\n|cRXP_PICK_Bloom|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bloom|r
.complete 89034,1 
step
#label Lightblooms
>>Kill |cRXP_ENEMY_Lightblooms|r.
.complete 86973,1 
.mob Lightbloom Thornguard
.mob Lightbloom Grovewarden
.mob Lightbloom Sap Weaver
step
#include a) Of Caves and Cradles@SojournerCampaignHarm-SojournerAdventureSow
step
#loop
.goto 2413,36.54,26.85,5,0
.goto 2413,36.68,26.9,5,0
#arrowtext Click on the\n|cRXP_PICK_Food|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Food|r
.complete 91589,4 
.complete 91589,5 
.complete 91589,3 
.complete 91589,2 
step
#label Ribs served
#arrowtext Talk to\n|cRXP_FRIENDLY_Yu'relen|r
.goto 2413,36.66,26.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yu'relen|r
.turnin 91589 >>Turn in Root Dash Delivery
.target Yu'relen
step
#include a) Call of the Goddess@To Sow the Seed-SojournerCampaignWatch1






step
.goto 2413,50.97,50.94
#arrowtext |cFFFCDC00Fly UP|r\nTalk to |cRXP_FRIENDLY_Kaleo|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaleo|r.
.accept 93771 >>Accept Har'kuai, Village of Rain
.target Kaleo
step
.goto 2413,50.95,50.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Naynar|r.
.complete 86864,2 
.skipgossipid 132852
step
#include a) Call of the Goddess@Speak to the Innkeeper-WatchDen
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Ku'paal|r
.goto 2413,54.28,55.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Ku'paal|r.
.complete 86864,4 
.turnin 86864 >>Turn in Watch the Den
.accept 86836 >>Accept The Hunter Awaits
.skipgossipid 133239
.skipgossipid 132858
.target Orweyna
.target Ku'paal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Ku'paal|r
.goto 2413,54.28,55.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r and |cRXP_FRIENDLY_Ku'paal|r.
.complete 90533,1 
.skipgossipid 138671
.target Orweyna
.target Ku'paal
step
#arrowtext |cFFFCDC00Fly UP|r\nTalk to\n|cRXP_FRIENDLY_Imhayo|r
.goto 2413,53.91,55.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Imhayo|r and buy |T4048814:0|t[Handcrafted Plush]
.collect 241125,1,90533,1 
.skipgossipid 138674
.buy 241125,1
.target Imhayo
step
.goto 2413,47.09,45.85
#arrowtext Click on the\n|cRXP_PICK_Nahuut|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Nahuut|r
.complete 90533,3 
.target Nahuut
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2413,47.17,45.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 90533 >>Turn in Go Get Orweyna!
.target Orweyna
.accept 90534 >>Accept The Home of the Haranir
step
#include a) Haranir Never Say Die@HaranirNeverSayDieA-HaranirNeverSayDieZ
step
#include a) Call of the Goddess@ShrineMists-CallOfTheGoddessB
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Greenspeaker Cyenna|r
.goto 2413,63.01,58.01,15,0
.goto 2413,65.45,28.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greenspeaker Cyenna|r
.accept 91346 >>Accept Supplicants to the Goddess
.target Greenspeaker Cyenna
step
#include a) The Greenspeaker's Vigil@Waters1-Riverscales
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,67.79,27.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r
.accept 90467 >>Accept Tales of the Sky
.target Kuri
.accept 90468 >>Accept Ugh, Chores!
step
#include a) The Legend of Aln'sharan@Cascades FenhunterZ-TheLegendOfAlnsharanZZZ
step
.goto 2413,65.26,26.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kamari|r.
.turnin 93771 >>Turn in Har'kuai, Village of Rain
.target Kamari
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Greenspeaker Cyenna|r
.goto 2413,65.45,28.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greenspeaker Cyenna|r
.turnin 91361 >>Turn in Back on Duty?
.target Greenspeaker Cyenna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kuri|r
.goto 2413,66.16,25.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuri|r |cRXP_WARN_after the roleplay|r.
.turnin 90474 >>Turn in The Legend of Aln'sharan
.target Kuri
step
#include a) Peril Among Petals@PerilAmongPetalsA-PerilAmongPetalsZ
step
#include a) Late Bloomers@LateBloomersA-LateBloomersZ
step
#include a) Cultivating Hope@The Former Rootwarden2-TendingHope
step
.goto 2413,31.34,64.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Byarc|r.
.turnin 86865 >>Turn in In Search of the Problem
.target Byarc
step
.goto 2413,31.40,64.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannan|r.
.accept 92732 >>Accept Light Disturbance
.target Hannan
step
.goto 2413,31.43,64.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.accept 86866 >>Accept Can We Heal This?
.target Orweyna
.accept 94677 >>Accept The Missing Rootwarden
step
#completewith next
#label Ruia's notes
.goto 2413,31.14,64.94,9,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.complete 94677,1,1 
step
#completewith Ruia's notes
.isOnQuest 94677
.goto 2413,30.97,64.74,20 >>Enter the building
step
#requires Ruia's notes
#arrowtext Click on the |cRXP_PICK_Chest|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,30.97,64.74
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.complete 94677,1,1 
step
#arrowtext Click on the |cRXP_PICK_Scroll|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2413,32.97,65.06
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.complete 94677,1,2 
step
#include a) Call of the Goddess@Ruia's notes Z-SojournerCampaignHaranir
step
.goto 2413,33.33,66.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghikal|r.
.accept 91375 >>Accept The Silence at Fungara Village
.target Ghikal
step
#include a) Call of the Goddess@SojournerCampaignHannan-Tell the People
step
#completewith next
#label Missing Paladins
#hidewindow
.turnin 91827 >>Turn in No Loose Ends
.target Taelia Fordragon
step
#completewith Missing Paladins
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires Missing Paladins
.goto 2393,53.15,69.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taelia Fordragon|r.
.accept 90546 >>Accept Missing Paladins
.target Taelia Fordragon
step
.goto 2393,45.43,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.turnin 91827 >>Turn in No Loose Ends
.target Lor'themar Theron
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Valeera Sanguinar|r
.goto 2393,52.47,78.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.accept 91828 >>Accept A Favor for the Lion
.accept 93501 >>Accept The Season Starts: Midnight
.target Valeera Sanguinar
step
.goto 2393,52.55,78.27
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r
.complete 93501,1 
.skipgossipid 136916
step
.goto 2393,52.43,78.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Telemancer Astrandis|r
.complete 93501,3 
.target Telemancer Astrandis
step
.goto 2393,52.68,78.63
#arrowtext Click on the\n|cRXP_PICK_Letter|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Letter|r
.complete 91828,1 
step
.goto 2393,52.76,77.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r and buy |T5160585:0|t[Delver's Cosmetic Surprise Bag]
.complete 93501,2 
.skipgossipid 137442
.buy 263179,1
.target Naleidea Rivergleam
step
#include a) Delve Campaign@The Season Starts: Midnight1-The Season Starts: Midnight2
step
#completewith next
#label Council addressed
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.complete 86890,2 
.target Halduron Brightwing
step
#completewith Council addressed
.goto 2393,36.95,68.02
.zone 2576 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Harandar|r
step
#requires Council addressed
#arrowtext |cRXP_WARN_Fly UP|r\nTalk to\n|cRXP_FRIENDLY_Halduron Brightwing|r
.goto 2413,50.1,54.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r.
.complete 86890,2 
.skipgossipid 135501
.target Halduron Brightwing
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2576,63.43,71.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r.
.turnin 86890 >>Turn in Tell the People What You Have Seen
.target Orweyna
.accept 86883 >>Accept The Frenzied March
step
.goto 2413,51.41,52.45,30,0
.goto 2413,51.82,50.47
#arrowtext Fly UP\nClick on\n|cRXP_PICK_Robot|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Robot|r
.complete 90534,1 
.target Monte Gazlowe
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chua|r
.goto 2413,52.19,55.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chua|r
.accept 90824 >>Accept My Brother's Alive!
.target Chua
step
#include a) A Goblin in Harandar@Pick up Hand Claws-LeaveMark
step
#arrowtext Talk to\n|cRXP_FRIENDLY_En'liahn|r
.goto 2576,47.06,15.27,30,0
.goto 2413,51.29,50.2,30,0
.goto 2413,43.05,61.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_En'liahn|r
.turnin 90824 >>Turn in My Brother's Alive!
.target En'liahn
.accept 90827 >>Accept Only the Poisonous Parts
.accept 90826 >>Accept The Healing Waters of Ahl'ua
step
#include a) Trials of the Shul'ka@My Brother's Alive!-Meeting My Mentor
step
#include a) Bloomtown@Light Disturbance-O.K. Bloomer
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Harandar Part 3 & Eversong Woods
#internal
step
.isOnQuest 91375
.goto 2413,43.91,71.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghikal|r.
.turnin 91375 >>Turn in The Silence at Fungara Village
.target Ghikal
step
#include a) Silence at Fungara Village@Little Monsters-Reticent Evil
step
#include a) Trials of the Shul'ka@Turn in Meeting My Mentor-Point Forward
step
.goto 2413,54.29,53.41,40,0
.goto 2576,60.4,64.67,40,0
.goto 2576,64.69,71.08
#arrowtext Click on the\n|cRXP_PICK_Portal|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.complete 86883,1 
step
#include a) Emergence@FrenziedMarch-Survive
step
#include a) Ripple Effects@RippleEffectsBA-Foe Unseen
step
#include a) Emergence@Raptor-EmergenceY
step
#include a) Ripple Effects@AratorCrypts-RippleEffectsU
step
#include a) Paladin Rescue@Struggle-the Head
step
#include a) Ripple Effects@RippleEffectsUA-RippleEffectsV
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Zul'aman Part 1
#internal
step
#include RestedXP Midnight\a) Ripple Effects@RippleEffectsUA-RippleEffectsV
step
#include a) Dis Was Our Land@DisWasOurLandC-Heart of the Amani
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Recruit Dar'rak|r
.goto 2437,43.15,67.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Dar'rak|r
.accept 93051 >>Accept The Final Exam
.target Recruit Dar'rak
step
#completewith next
#label Amani'Zar Village
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Teo'zan|r.
.accept 92163 >>Accept The Loa of Murlocs
.target Old Teo'zan
step
#completewith Amani'Zar Village
#arrowtext Talk to\n|cRXP_FRIENDLY_Tavikko|r
.goto 2437,45.43,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r inside the building.
.home >>Set your Hearthstone to Amani'Zar Village
.skipgossipid 132699
.target Tavikko
step
#requires Amani'Zar Village
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,45.73,65.06,10,0
.goto 2437,46.02,65.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Teo'zan|r.
.accept 92163 >>Accept The Loa of Murlocs
.target Old Teo'zan
step
.goto 2437,45.71,65.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torundo the Grizzled|r.
.accept 88985 >>Accept Recuperating Returns
.target Torundo the Grizzled
step
.goto 2437,45.75,65.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86723,1 
.target Zul'jarra
.skipgossipid 138031
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.75,65.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86723 >>Turn in Isolation
.accept 86652 >>Accept Left in the Shadows
.target Zul'jarra
step
#completewith next
#label Torundo
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r.
.complete 86652,1 
step
#completewith Torundo
.goto 2437,46.86,67.32,100 >>Leave the building
step
#requires Torundo
#arrowtext Click on the |cRXP_PICK_Cauldron|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,46.86,67.32
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cauldron|r.
.complete 86652,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_An'jali|r
.goto 2437,46.66,67.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_An'jali|r
.accept 93049 >>Accept Homework Support
.target An'jali
step
.goto 2437,46.76,67.63
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,1 
step
#include a) Got No Rhythm@SojournerRhythm-SojournerRythm2
step
#completewith Pristine Shade Lily Complete
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pristine Shade Lily|r
.complete 93049,1 
step
#completewith next
#label Pristine Shade Lily
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,2 
step
#completewith Pristine Shade Lily
.goto 2437,46.94,65.81,15 >>Exit through the Window
step
#requires Pristine Shade Lily
.goto 2437,46.91,65.99,10,0
.goto 2437,46.76,66.2,10,0
.goto 2437,46.9,66.66,10,0
.goto 2437,46.71,66.87,10,0
.goto 2437,46.39,67.1
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,2 
step
.goto 2437,46.49,67.66
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,3 
step
.goto 2437,45.42,67.78
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,45.14,67.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.complete 86652,2 
.target Lilaju
.skipgossipid 132891
step
.goto 2437,45.05,67.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chel the Chip|r.
.accept 91930 >>Accept The Abundant Lands
.target Chel the Chip
step
.goto 2437,45.05,68.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vakala|r.
.accept 94867 >>Accept Lost in Atal'Abasi
.target Vakala
step
.goto 2437,44.86,68
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,5 
step
.goto 2437,44.03,66.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kagara|r.
.accept 89230 >>Accept A Lover Not a Fighter
.target Kagara
step
#label Pristine Shade Lily Complete
.goto 2437,43.89,65.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zak'kash|r.
.accept 89231 >>Accept A Fighter Not a Lover
.target Zak'kash
step
#completewith next
#label Shadowpine Shamans
#arrowtext Enter the building
.goto 2437,44.03,65.35,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.complete 86652,3 
.target Tak'lejo
step
#completewith Shadowpine Shamans
#arrowtext Enter the building
.goto 2437,43.97,65.07,18 >>Enter the building
step
#requires Shadowpine Shamans
#arrowtext Talk to\n|cRXP_FRIENDLY_Tak'lejo|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.97,65.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tak'lejo|r.
.complete 86652,3 
.target Tak'lejo
.skipgossipid 135286
step
#completewith next
#label slowly dropdown
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pristine Shade Lily|r
.complete 93049,1 
step
#completewith slowly dropdown
.goto 2437,43.79,64.57,10 >>Leave through the Window and slowly dropdown
step
#requires slowly dropdown
#loop
.goto 2437,44.04,64.79,10,0
.goto 2437,43.68,64.96,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pristine Shade Lily|r
.complete 93049,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ri'kari|r\n|cRXP_WARN_Above|r
.goto 2437,44.04,65.48,10,0
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r |cRXP_WARN_above|r.
.complete 93051,1 
.skipgossipid 137188
.target Ri'kari
step
.goto 2437,43.83,64.98
>>Kill |cRXP_ENEMY_Recruit Dar'rak|r
.complete 93051,2 
.mob Recruit Dar'rak
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ri'kari|r
.goto 2437,43.85,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ri'kari|r
.turnin 93051 >>Turn in The Final Exam
.target Ri'kari
step
.goto 2437,43.5,66.2
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,6 
step
.goto 2437,43.63,66.59
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,7 
step
.goto 2437,43.51,67.48
#arrowtext Click on the\n|cRXP_PICK_Dragonhawk Fern Frond & Shade Lilies|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dragonhawk Fern Frond|r
.complete 93049,2,8 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kinduru|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.78,68.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kinduru|r.
.complete 86652,4 
.target Kinduru
.skipgossipid 133822
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.80,68.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86652 >>Turn in Left in the Shadows
.accept 86653 >>Accept The Path of the Amani
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Rakan|r
.goto 2437,43.48,68.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakan|r
.accept 93050 >>Accept Altar History
.target Rakan
step
.goto 2437,43.12,67.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.accept 91206 >>Accept Loa Disturbance
.target Elder Doru
step
.goto 2437,43.08,67.99
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,2 
step
.goto 2437,43.08,68.39
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,3 
step
#include a) Blessings of the Loa
step
.goto 2437,43.9,69.34
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,1 
step
.goto 2437,43.46,68.89,10,0
.goto 2437,43.35,69.02
>>Stand infront of the Altar and use the |T538570:0|t|cRXP_WARN_[ExtraActionButton]|r.
.complete 93050,4 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Rakan|r
.goto 2437,43.37,69.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rakan|r inside the temple.
.turnin 93050 >>Turn in Altar History
.target Rakan
step
.goto 2437,43.11,67.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruit Dar'rak|r.
.accept 93051 >>Accept The Final Exam
.target Recruit Dar'rak
step
.goto 2437,45.19,69.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.accept 92450 >>Accept Growing Up is Hard
.target Ani
step
.goto 2437,45.36,69.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.accept 89565 >>Accept The Path of Mourning
.target Chana
step
.goto 2437,45.57,69.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r.
.accept 93047 >>Accept Butchery Basics
.target Gijaniji
step
.goto 2437,45.90,70.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jak'zari|r.
.accept 93257 >>Accept Revantusk at Risk
.target Jak'zari
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Chana|r
.goto 2437,45.87,72.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chana|r.
.turnin 89565 >>Turn in The Path of Mourning
.accept 89503 >>Accept Somber Siblings
.target Chana
step
#hidewindow
#completewith Boar Carcass
#loop
.goto 2437,46.04,72.65,30,0
.goto 2437,45.75,72.98,30,0
.goto 2437,46.12,73.62,30,0
.goto 2437,46.07,73.97,30,0
.goto 2437,46.3,74.69,30,0
.goto 2437,46.7,75.84,30,0
.goto 2437,47.55,76.02,30,0
.goto 2437,47.6,74.07,30,0
.goto 2437,46.44,72.28,30,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#arrowtext Click on the |cRXP_PICK_Mushrooms|r\n|cRXP_ENEMY_(NOT SHARED)|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r.
*Kill |cRXP_ENEMY_Boars|r |cRXP_WARN_but only if they attack you|r.
*Loot them for |T134389:0|t[|cRXP_LOOT_Weeping Spores|r].
.complete 89503,1 
.mob Tearful Boar
.mob Weeping Swine
step
#label Boar Carcass
>>Kill |cRXP_ENEMY_Boars|r
*Loot them for |T1044799:0|t[|cRXP_LOOT_Boar Carcass|r].
.complete 93047,1 
.mob Tearful Boar
.mob Weeping Swine
step
#include a) Sorrowing Kin@SorrowingKinC-SorrowingKinZ
step
.goto 2437,51.63,70.80
#title |cFFFCDC00Follow the Arrow|r
.complete 86653,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,51.63,70.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86653 >>Turn in The Path of the Amani
.accept 86655 >>Accept De Ancient Path
.accept 89334 >>Accept Ahead of the Issue
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2437,51.61,70.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r.
.accept 86654 >>Accept Gnarldin Bashing
.target Lady Liadrin
step
#completewith DeAncientPathA
>>Kill |cRXP_ENEMY_Gnarldins|r.
*Loot them for |T1535070:0|t[|cRXP_LOOT_Threshadon Tooth Necklace|r].
.complete 86654,1 
.complete 89230,1 
.mob Gnarldin Clubfist
.mob Gnarldin Nestcrusher
step
#completewith DeAncientPathA
#arrowtext Click on the\n|cRXP_PICK_Feather|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feather|r
.complete 89231,1 
step
#arrowtext Shrine lit (1/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,55.29,70.86
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,1 
step
#arrowtext Shrine lit (2/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,56.26,73.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,2 
step
#completewith next
#label AheadOfTheIssueA
#arrowtext Enter the cave
.goto 2437,55.92,74.38,8,0
>>Kill |cRXP_ENEMY_Brulagh the Crusher|r.
*Loot him for |T133639:0|t[|cRXP_LOOT_Head of Brulagh the Crusher|r].
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89334,1 
.mob Brulagh the Crusher
step
#completewith AheadOfTheIssueA
#title Enter the cave
.goto 2437,56.15,74.88,30 >>|cRXP_WARN_Enter the cave|r.
step
#requires AheadOfTheIssueA
#arrowtext Kill |cRXP_ENEMY_Brulagh the Crusher|r\nLoot for |T133639:0|t[|cRXP_LOOT_Head of Brulagh the Crusher|r]
.goto 2437,56.15,74.88
>>Kill |cRXP_ENEMY_Brulagh the Crusher|r.
*Loot him for the |T133639:0|t[|cRXP_LOOT_Head of Brulagh the Crusher|r].
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89334,1 
.mob Brulagh the Crusher
step
#completewith next
#label Shrine lit
#arrowtext Shrine lit (3/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,55.78,74.61,10,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,3 
step
#completewith Shrine lit
.goto 2437,55.24,76.26,110 >>Leave the Cave
step
#requires Shrine lit
#arrowtext Shrine lit (3/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,55.24,76.26
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1,3 
step
#arrowtext Kill |cRXP_ENEMY_Pulverizer Helthra|r\nLoot for |T133639:0|t[|cRXP_LOOT_Head of Pulverizer Helthra|r]
.goto 2437,55.24,77.82
>>Kill |cRXP_ENEMY_Pulverizer Helthra|r.
*Loot him for the |T133639:0|t[|cRXP_LOOT_Head of Pulverizer Helthra|r].
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 89334,3 
.mob Pulverizer Helthra
step
#arrowtext Shrine lit (4/4)\n|cFFFCDC00(Read Note)|r
.goto 2437,53.67,72.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.complete 86655,1 
step
#arrowtext Kill |cRXP_ENEMY_Cragward Gaahl|r\nLoot for |T133639:0|t[|cRXP_LOOT_Head of Cragward Gaahl|r]
.goto 2437,53.32,74.27
>>Kill |cRXP_ENEMY_Cragward Gaahl|r
*Loot him for the |T133639:0|t[|cRXP_LOOT_Head of Cragward Gaahl|r].
.complete 89334,2 
.mob Cragward Gaahl
step
#hidewindow
#completewith Threshadon Tooth Necklace
#loop
.goto 2437,55.02,72.96,35,0
.goto 2437,52.32,70.55,35,0
.goto 2437,53.99,71.83,35,0
.goto 2437,55.69,74.15,35,0
.goto 2437,54.98,77.36,35,0
+1
step
#completewith next
#arrowtext Kill |cRXP_ENEMY_Gnarldins|r
*Loot them for |T1535070:0|t[|cRXP_LOOT_Threshadon Tooth Necklace|r].
.complete 86654,1 
.complete 89230,1 
.mob Gnarldin Clubfist
.mob Gnarldin Nestcrusher
step
#arrowtext Click on the\n|cRXP_PICK_Feather|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Feather|r
.complete 89231,1 
step
#label Threshadon Tooth Necklace
#arrowtext Kill |cRXP_ENEMY_Gnarldins|r
*Loot them for |T1535070:0|t[|cRXP_LOOT_Threshadon Tooth Necklace|r].
.complete 86654,1 
.complete 89230,1 
.mob Gnarldin Clubfist
.mob Gnarldin Nestcrusher
step
.goto 2437,44.44,65.74
>>Use |T2103839:0|t[Eagle Feather]
.complete 89231,2 
.use 249231
step
#include a) Path of de Hash'ey@PathOfDeHasheyBB-Shadebasin Watch
step
#arrowtext Talk to\n|cRXP_FRIENDLY_An'jali|r
.goto 2437,46.66,67.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_An'jali|r inside the house.
.turnin 93049 >>Turn in Homework Support
.target An'jali
step
#include RestedXP Midnight\a) No Fear@NoFearB-BoarCarcass
step
#requires Ani cheered on
.goto 2437,45.54,69.52
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Boar|r.
.complete 93047,2 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Gijaniji|r
.goto 2437,45.58,69.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gijaniji|r
.turnin 93047 >>Turn in Butchery Basics
.target Gijaniji
step
#arrowtext |cRXP_ENEMY_DISMOUNT|r
.goto 2437,48.11,67.61
>>Use the |T237554:0|t|cRXP_WARN_[ExtraActionButton]|r
.complete 92451,2 
.timer 6,RP
step
.isOnQuest 92451
#arrowtext |cRXP_ENEMY_WAIT 'TIL TIMER ENDS|r
.goto 2437,48.11,67.61,10,0
.goto 2437,53.12,62.83
.countdown 6 >>You can leave when this timer ends
.complete 92451,3 
step
#include a) Vengeance for Tolbani@SojournerCampaignMenace-VengeanceForTolbaniB
step
#include RestedXP Midnight\a) No Fear@NoFearD-NoFearE
step
#include RestedXP Midnight\a) Vengeance for Tolbani@VengeanceForTolbaniC-VengeanceForTolbaniZ
step
.isOnQuest 92163
.goto 2437,52.88,60.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r.
.turnin 92163 >>Turn in The Loa of Murlocs
.target King Mrgl-Mrgl
step
#include a) The Loa of Murlocs@TheLoaOfMurlocsA-TheLoaOfMurlocsZ
step
#include a) Healing the Spirit@SojournerCurseCleanse-SojournerMedicineCampaign0
step
.goto 2437,44.08,34.50
#title |cFFFCDC00Follow the Arrow|r
.complete 86657,2 
step
.goto 2437,44.14,34.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kul'amara the Fierce|r.
.accept 93575 >>Accept Maisara Caverns: Maisara Hungers
.target Kul'amara the Fierce
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,44.08,34.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86657 >>Turn in Shadebasin Watch
.accept 86658 >>Accept The Crypt in the Mist
.accept 86660 >>Accept Rescue from the Shadows
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Zel'kanra|r
.goto 2437,44.17,33.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Zel'kanra|r.
.accept 93667 >>Accept Camp Stonewash
.target Scout Zel'kanra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Warlord Akutu|r and |cRXP_FRIENDLY_Kulzi|r
.goto 2437,38.82,44.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Akutu|r and |cRXP_FRIENDLY_Kulzi|r.
.turnin 87317 >>Turn in Denial Denied
.accept 92531 >>Accept The Medicine Loa's Shrine
.target Warlord Akutu
.target Kulzi








step
#include a) Path of de Hash'ey@PathOfDeHasheyD-SojournerCampaignFinalIncense
step
.goto 2437,32.83,32.62
#arrowtext Click on the\n|cRXP_PICK_Incense|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Incense|r.
.complete 86659,3 
step
#include a) Bitter Honor@BitterHonorA-BitterHonorY
step
#include a) Sawdust to Sawdust@SawdustToSawdustA-SawdustToSawdustZ
step
#include a) Abundance Campaign@Abundant Awakening1-Abundant Awakening2
step
.goto 2437,36.09,24.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r.
.accept 91406 >>Accept Far from the Hinterlands
.target Nija Torntusk
step
.goto 2437,36.77,25.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r.
.accept 93178 >>Accept A Quiet Walk Interrupted
.target Nerunda
step
.goto 2437,37.13,23.48
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r |cRXP_WARN_on the second floor of the building|r.
.complete 91406,1,1 
step
.goto 2437,38.08,24.11
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hammer|r.
.complete 91406,1,2 
step
.goto 2437,37.13,26.25
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Spear|r.
.complete 91406,1,3 
step
#include a) The Sound of Her Voice@SojournerVoice-SojournerNerunda
step
.goto 2437,45.83,33.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Teapot|r.
.complete 93178,5 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Nerunda|r
.goto 2437,36.78,25.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r inside the house.
.turnin 93178 >>Turn in A Quiet Walk Interrupted
.target Nerunda
.accept 93179 >>Accept Child-like Devotion














step
#include a) A Venomous History@SojournerHinterlands-AVenomousHistoryAA
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,32.40,31.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86659 >>Turn in Breaching the Mist
.accept 92084 >>Accept Halazzi's Guile
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r.
.complete 92084,1 
.target Loa Speaker Tobui
.skipgossipid 135472
.singlebox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Loa Speaker Tobui|r
.goto 2437,32.25,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loa Speaker Tobui|r inside the temple.
.turnin 91563 >>Turn in Halazzi's Hunt
.target Loa Speaker Tobui
.accept 91403 >>Accept Probable Paralytic
.accept 91404 >>Accept A Most Vile Venom
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,32.40,31.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 92084 >>Turn in Halazzi's Guile
.accept 86661 >>Accept Coals of a Dead Loa
.target Zul'jarra
step
#include a) A Venomous History@AVenomousHistoryAB-AVenomousHistoryProbable
step
#arrowtext |cFFFCDC00Fly Up|r\nTalk to |cRXP_FRIENDLY_Vun'zarah|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,38.57,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vun'zarah|r.
.complete 86661,1 
.complete 91405,1 
.accept 91833 >>Accept Dirty Deeps
.target Vun'zarah
.skipgossipid 134561
.skipgossipid 134081
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,38.53,22.47
#label PathOfDeHasheyG
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86661 >>Turn in Coals of a Dead Loa
.accept 86808 >>Accept The Riddled Speaker
.target Zul'jarra
step
#include a) A Venomous History@Mixer Jamanga-Vordaza

step
>>Kill |cRXP_ENEMY_Rak'tul|r endboss of the dungeon
.complete 91411,1 
step
#title|cFFFCDC00Leave dungeon|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nija Torntusk|r and |cRXP_FRIENDLY_Mixer Jamanga|r |cRXP_WARN_outside the dungeon|r.
.turnin 91411 >>Turn in Deep in Maisara
.goto 2437,38.76,22.72
.target Nija Torntusk
.accept 91412 >>Accept Return of the Venom Queen
.goto 2583,43.05,71.92
.target Mixer Jamanga
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#include a) A Venomous History@Shadra Ritual-AVenomousHistoryZ
step
#completewith next
#label Camp Stonewash
.goto 2583,52.9,73.54,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 93667 >>Turn in Camp Stonewash
.accept 90481 >>Accept I Have a Permit
.disablecheckbox
.target Seeker Crikkash
.target Amaxi
step
#completewith Camp Stonewash
.goto 2437,46.27,26.12,690 >>Leave the Temple
step
#requires Camp Stonewash
#label Camp Stonewash2
#arrowtext Talk to\n|cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r and |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 93667 >>Turn in Camp Stonewash
.accept 90481 >>Accept I Have a Permit
.target Seeker Crikkash
.target Amaxi
]])

RXPGuides.RegisterGuide([[
#retail
#group RestedXP Midnight
#name a) Zul'aman Part 2 & Arathor
#internal
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Ren'zen|r
.goto 2437,38.30,20.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Ren'zen|r.
.complete 90481,1 
.skipgossipid 133102
.skipgossipid 133101
.target Elder Ren'zen
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,46.27,26.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r
.turnin 90481 >>Turn in I Have a Permit
.timer 25,RP
.target Seeker Crikkash
step
#include a) The Sound of Her Voice@SojournerKanza-SojournerKanza2
step
#include a) Unlikely Friends@Sightseeing Stegadon1-Zapgut Eel Stomach
step
#hidewindow
#completewith ThornCapsZ
#loop
.goto 2437,50.09,31.59,30,0
.goto 2437,50.65,29.73,30,0
.goto 2437,52.75,29.89,30,0
.goto 2437,52.13,30.94,20,0
.goto 2437,52,30.58,20,0
.goto 2437,51.76,30.62,20,0
.goto 2437,51.37,30.54,20,0
+1
step
#completewith next
#arrowtext Click on the\n|cRXP_PICK_Mushroom|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushroom|r
.complete 93180,5 
step
>>Kill |cRXP_ENEMY_Stinger Matriarch|r and |cRXP_ENEMY_Stinger Hatchling|r.
.complete 93180,4 
.complete 93180,3 
.mob Stinger Hatchling
.mob Stinger Matriarch
step
#label ThornCapsZ
#arrowtext Click on the\n|cRXP_PICK_Mushroom|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushroom|r
.complete 93180,5 
step
#include a) The Sound of Her Voice@SojournerShrine-SojournerShrine
step
#include a) Path of de Hash'ey@PathOfDeHasheyH-PathOfDeHasheyX
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Seeker Crikkash|r
.goto 2437,47.26,24.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seeker Crikkash|r.
.turnin 90483 >>Turn in A Witherbark Story
.target Seeker Crikkash
.turnin 90485 >>Turn in Afterthought Artifacts
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Honnu|r
.goto 2437,47.18,24.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honnu|r.
.complete 93181,1 
.buy 265401,1
.target Honnu
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Amaxi|r
.goto 2437,47.16,24.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaxi|r.
.turnin 90482 >>Turn in Cuisine Connection
.target Amaxi
.accept 90486 >>Accept Dangerous Delicacies
step
#include a) Unlikely Friends@SojournerPrepped-SojournerDelicacies
step
#include a) The Sound of Her Voice@SojournerCampaignKanza-SojournerTeapot
step
.goto 2437,44.14,34.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kul'amara the Fierce|r.
.turnin 93575 >>Turn in Maisara Caverns: Maisara Hungers
.target Kul'amara the Fierce
step
#include a) Something Vile This Way Comes@Send Dem Home-Sacrifice Denied
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Ren'zen|r
.goto 2437,38.30,20.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Ren'zen|r.
.turnin 90568 >>Turn in Unlikely Friends
.target Elder Ren'zen
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Bin'zin|r
.goto 2437,37.31,25.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bin'zin|r
.complete 91839,1 
.skipgossipid 136456
.target Bin'zin
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Bin'zin|r
.goto 2437,37.31,25.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bin'zin|r
.turnin 91839 >>Turn in Sacrifice Denied
.target Bin'zin
step
.goto 2437,36.73,25.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nerunda|r.
.turnin 93182 >>Turn in Healing Homeward
.target Nerunda
step
#completewith next
#label SojournerCampaignHS
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Namaji|r.
.turnin 89230 >>Turn in A Lover Not a Fighter
.target Namaji
.turnin 89231 >>Turn in A Fighter Not a Lover
.accept 89233 >>Accept Love Triangle
step
#completewith SojournerCampaignHS
.hs >>Hearth to Amani'Zar Village
.cooldown item,6948,>0,1
step
#requires SojournerCampaignHS
.goto 2437,44.44,65.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Namaji|r.
.turnin 89230 >>Turn in A Lover Not a Fighter
.target Namaji
.turnin 89231 >>Turn in A Fighter Not a Lover
.accept 89233 >>Accept Love Triangle
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Namaji|r
.goto 2437,44.44,65.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Namaji|r select a partner.
.complete 89233,1 
.target Namaji
.skipgossipid 135137
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Namaji|r
.goto 2437,44.44,65.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Namaji|r.
.turnin 89233 >>Turn in Love Triangle
.target Namaji
step
.goto 2437,44.27,66.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntmaster Jinki|r.
.turnin 93096 >>Turn in Amani Honor
.target Huntmaster Jinki
step
.goto 2437,45.18,69.72
#title |cFFFCDC00Follow the Arrow|r
.complete 92453,1 
.timer 15.5,RP
step
.goto 2437,43.84,68.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86666 >>Turn in In the Shadow of Rebirth
.target Zul'jarra
.accept 86681 >>Accept Den of Nalorakk: A Taste of Vengeance
step
#arrowtext |cFFFCDC00Cancel it right after|r\nClick on the |cRXP_PICK_Bowl|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.57,68.28
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bowl|r |cRXP_WARN_cancel it right after|r.
.complete 86681,1 
step
#arrowtext Use the |T571694:0|t[ExtraActionButton]\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.57,68.28
>>Stand within the circle and use the |T571694:0|t[|cRXP_WARN_ExtraActionButton|r].
.complete 86681,2,1 
step
.goto 2437,43.13,67.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Doru|r.
.turnin 92531 >>Turn in The Medicine Loa's Shrine
.target Elder Doru
step
#include a) Where War Slumbers@DeathRitesZ-SlumbersAA
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Ani|r
.goto 2437,45.19,69.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ani|r.
.turnin -92453 >>Turn in Fearless
.target Ani
step
.goto 2437,33.61,78.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pel'na Torntusk|r.
.accept 91813 >>Accept The Spiritpaw
.target Pel'na Torntusk
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,33.59,78.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.complete 86682,1 
.target Lilaju
.skipgossipid 134139
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r
.goto 2437,33.59,78.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.accept 92492 >>Accept Honorin' de Sacrifice
.target Lilaju
step
#completewith next
+If you are DPS, queue for Den of Nalorakk (Normal) now to reduce wait time, but do not enter the dungeon until you have the quest.
*|cRXP_WARN_It’s often faster than the follower dungeon run, provided the queue pops quickly|r.
.macro Queue Den of Nalorakk(Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3089, true); LFGEnabledList[3089] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,33.61,78.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86682 >>Turn in Den of Nalorakk: Waking de Bear
.accept 91958 >>Accept Den of Nalorakk: Unforgiven
.target Zul'jarra
step
#completewith next
#label Speak with Zul'jarra
#hidewindow
.complete 91958,3
step
#completewith Speak with Zul'jarra
.goto 2437,33.61,78.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r to start the Follower Dungeon, or queue through the Dungeon Finder instead.
.enterScenario 3118 >>Queue for |cRXP_PICK_Den of Nalorakk|r on (Normal) or (Follower) difficulty |cRXP_WARN_if you haven't yet|r
.macro Queue Den of Nalorakk(Normal),1379226>>/run PVEFrame_ToggleFrame(); LFDQueueFrame_SetTypeFollowerDungeon(); SetLFGDungeonEnabled(3089, true); LFGEnabledList[3089] = true; LFDQueueFrame_Update(); LFDQueueFrame_Join()
.skipgossipid 134140
.target Zul'jarra
step
#requires Speak with Zul'jarra
#completewith DungeonLeave
+|cRXP_WARN_The Arrow cannot be displayed here; coordinates are unavailable|r.
step
#requires Speak with Zul'jarra
#completewith DungeonLeave
.goto 2437,33.61,78.77
>>Kill |cRXP_ENEMY_Nalorakk, Loa of War|r at the end of Den of Nalorakk.
.complete 91958,3 
.skipgossipid 134140
step
#requires Speak with Zul'jarra
#label The Hoardmonger
.isInScenario 3118
#arrowtext Click on the\n|cRXP_PICK_Campfire|r
>>Click on the |cRXP_PICK_Campfire|r, complete tasks for offerings and place them infront of the|TInterface/cursor/crosshair/attack.blp:12|t|cRXP_ENEMY_The Hoardmonger|r.
.scenario 15950,1
.skipgossipid 135009
.mob The Hoardmonger
step
.isInScenario 3118
#arrowtext Click on the\n|cRXP_PICK_Eye|r
>>Click on the |cRXP_PICK_Eye|r to summon |TInterface/cursor/crosshair/attack.blp:15|t|cRXP_ENEMY_Sentinel of Winter|r.
*|cRXP_WARN_Hide behind structures when confronted with harsh winds|r
.scenario 15950,2
.mob Sentinel of Winter
step
.isInScenario 3118
#arrowtext Click on the\n|cRXP_PICK_Campfire|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Campfire|r and kill |cRXP_ENEMY_Nalorakk|r.
.scenario 15950,3
.skipgossipid 135010
.mob Nalorakk
step
#completewith next
#label Zul'jarra
#hidewindow
.turnin 91813 >>Turn in The Spiritpaw
.target Zul'jarra
step
#completewith Zul'jarra
#label DungeonLeave
.zone 2437 >>Click the macro in the "Active Items Frame"
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
step
#include a) The Voice of Nalorakk@SojournerCampaignSpiritpaw-SojournerCampaignJustNotRight
step
#include a) River-Walkers of the Prowl@SojournerRevantusk-SojournerRevantusk2
step
.goto 2437,41.28,79.9
>>|cRXP_WARN_Wait for the Roleplay|r.
.complete 93734,1 
step
.goto 2437,41.28,79.9
#arrowtext Click on the\n|cRXP_PICK_Bag|r
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r.
.complete 93734,2 
.timer 15,RP
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Kahanea|r
.goto 2437,40.22,79.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93258 >>Turn in Crab Clues
.target Kahanea
.accept 93260 >>Accept Caging Crawlers
.accept 93259 >>Accept Clobbering Crawlers
step
#include a) The Voice of Nalorakk@FakeVoice-TheVoiceOfNalorakkZ
step
#include a) River-Walkers of the Prowl@SojournerCampaignMouth-Clobbering Crawlers
step
#completewith next
#label ManiaCrab
.goto 2437,33.61,85.57,5,0
>>Kill |cRXP_ENEMY_Mania-Crab|r.
*Loot them for |T1273724:0|t[|cRXP_LOOT_Chipped Twilight's Blade Artifact|r].
.complete 93261,1 
.complete 93261,2 
.mob Mania-Crab
step
.isOnQuest 93261
#completewith ManiaCrab
.goto 2437,33.53,85.92,30 >>Enter the Cave
step
#requires ManiaCrab
.goto 2437,33.53,85.92
>>Kill |cRXP_ENEMY_Mania-Crab|r.
*Loot them for |T1273724:0|t[|cRXP_LOOT_Chipped Twilight's Blade Artifact|r].
.complete 93261,1 
.complete 93261,2 
.mob Mania-Crab
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,31.58,83.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 91958,4 
.target Zul'jarra
.skipgossipid 138171
.singlebox
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,31.58,83.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r
.turnin 91958 >>Turn in Den of Nalorakk: Unforgiven
.accept 86683 >>Accept Hash'ey Away
.target Zul'jarra
step
#completewith next
#label Flickering Hope
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.turnin 86839 >>Turn in Relics of Light's Hope
.target Lord Maxwell Tyrosus
.accept 86840 >>Accept Flickering Hope
step
#completewith Flickering Hope
.goto 23,84.92,43.05,10 >>Fly onto the skull of Acherus Ebonhold for a teleport
step
#requires Flickering Hope
#arrowtext Talk to\n|cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.goto 23,73.91,53.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r.
.turnin 86839 >>Turn in Relics of Light's Hope
.target Lord Maxwell Tyrosus
.accept 86840 >>Accept Flickering Hope
step
#include a) The Path of Light@SojournerCampaignUndeads-ArathorEnd2
step
#include a) Regrets of the Past@ArathorStart3-A Worthy Forge
step
.isOnQuest 93942
.goto 2393,40.18,64.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eldara Dawnrunner|r.
.turnin 93942 >>Turn in Spark of Radiance
.target Eldara Dawnrunner
step
#include a) Regrets of the Past@A Bulwark-SojournerCampaignJourneyEnds
step
#completewith next
#label SojournerCampaignHS2
#hidewindow
.complete 86683,1 
step
#completewith SojournerCampaignHS2
.hs >>Hearth to Amani'Zar Village
.cooldown item,6948,>0,1
step
#requires SojournerCampaignHS2
.goto 2437,45.13,64.96,10,0
.goto 2437,43.80,68.68
#title |cFFFCDC00Follow the Arrow|r
.complete 86683,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r\n|cRXP_ENEMY_(NOT SHARED)|r
.goto 2437,43.80,68.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86683,2 
.target Zul'jarra
.skipgossipid 132827
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,43.49,68.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86683 >>Turn in Hash'ey Away
.accept 86684 >>Accept The Blade's Edge
.target Zul'jarra
step
#include a) A Favor for the Lion@One by One-Cut Once
step
#include a) De Amani Never Die@Broken Throne-Light Indiscriminate
step
#include a) Twilight Crypts@1-TwilightCryptsB
step
.goto 2437,22.53,77.38
#title |cFFFCDC00Follow the Arrow|r
.complete 91001,1 
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,22.53,77.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 91001 >>Turn in Clear de Way
.accept 86692 >>Accept Blade Shattered
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,22.53,77.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86692,1 
.timer 32,Roleplay Duration
.target Zul'jarra
.skipgossipid 135208
step
.goto 2437,21.37,77.38
>>Kill |cRXP_ENEMY_Mor'duun|r.
.complete 86692,2 
.mob Mor'duun
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,21.44,77.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86692 >>Turn in Blade Shattered
.accept 86693 >>Accept De Legend of de Hash'ey
.target Zul'jarra
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lilaju|r
.goto 2437,26.08,64.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lilaju|r.
.turnin 92492 >>Turn in Honorin' de Sacrifice
.accept 92493 >>Accept What Remains of Idago
.accept 92495 >>Accept Disruptin' de Blade
.target Lilaju
step
#include a) Reclaiming de Honor@SojournerCampaignShadowmage-SojournerLeaders
step
.goto 2437,33.10,79.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kahanea|r.
.turnin 93261 >>Turn in A Crab of Unusual Size
.target Kahanea
step
#completewith next
.hs >>Hearth to Amani'Zar Village
.cooldown item,6948,>0,1
.use 6948
step
.goto 2437,45.44,65.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93410 >>Turn in Delver's Call: Twilight Crypts
.target Tavikko
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.27,66.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.complete 86693,1 
.target Zul'jarra
.skipgossipid 134131
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jarra|r
.goto 2437,45.76,65.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jarra|r.
.turnin 86693 >>Turn in De Legend of de Hash'ey
.accept 91062 >>Accept Broken Bridges
.accept 93440 >>Accept Personal History
.target Zul'jarra
step
#completewith next
#label Check on Zul'jan
#arrowtext Leave through the window
.goto 2437,45.81,65.11,5,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r |cRXP_WARN_on the bridge|r.
.complete 91062,1 
.timer Lady Liadrin Roleplay
.target Zul'jan
step
#completewith Check on Zul'jan
#arrowtext Leave through the window
.goto 2437,51.26,54.36,800 >>Leave through the Window
step
#requires Check on Zul'jan
#arrowtext Talk to\n|cRXP_FRIENDLY_Zul'jan|r
.goto 2437,51.26,54.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zul'jan|r |cRXP_WARN_on the bridge|r.
.complete 91062,1 
.timer Lady Liadrin Roleplay
.target Zul'jan
.skipgossipid 134133
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
.goto 2437,50.52,54.98,10,0
.goto 2437,50.75,54.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
*Turn in the quest midair using |T5003205:0|t[Aerial Halt] |cRXP_WARN_next to |cRXP_FRIENDLY_Lady Liadrin|r in the sky|r.
.turnin 91062 >>Turn in Broken Bridges
.accept 91087 >>Accept Reports Returned
.target Lady Liadrin
step
#include a) Bloodstains@Personal History-Their Own Blood
step
#completewith next
#label Measure Once
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 91918 >>Turn in Delves: Measure Once, Cut Twice
.target Valeera Sanguinar
step
#completewith Measure Once
.goto 2541,50.67,90.10
.zone 2393 >>Use |T7322718:0|t[Personal Key to Arcantina] and leave the instance portal.
.use 253629
.cooldown item,253629,>0,1
step
#requires Measure Once
.goto 2393,52.55,78.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Valeera Sanguinar|r
.turnin 91918 >>Turn in Delves: Measure Once, Cut Twice
.target Valeera Sanguinar
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Orweyna|r
.goto 2393,36.60,68.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orweyna|r
.turnin 86898 >>Turn in Rise of the Haranir
.accept 93651 >>Accept The Blinding Vale: Lightbloom Roots
.target Orweyna
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Elder Hagar|r
.goto 2393,36.57,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Hagar|r.
.accept 91084 >>Accept Looming Shadows
.target Elder Hagar
step
#completewith next
#label Truth of the Past
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.accept 92505 >>Accept Truth of the Past
.timer 9,Portal Spawn
.target Leona Darkstrider
step
#completewith Truth of the Past
.goto 2393,35.29,66.26
.zone 2405 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal to Voidstorm|r
step
#requires Truth of the Past
.goto 2405,53.23,70.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leona Darkstrider|r.
.accept 92505 >>Accept Truth of the Past
.timer 9,Portal Spawn
.target Leona Darkstrider
step
#include a) A More Potent Foe@IllidariGateway-Argus
step
.goto 2405,50.98,68.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veraan|r.
.turnin 90860 >>Turn in Shedding the Yoke
.target Veraan
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 90924,3 
.skipgossipid 136325
.target Decimus
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,51.20,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.turnin 90924 >>Turn in The Wicked End
.accept 94623 >>Accept Building the Voidforge
.target Decimus
step
#include a) A More Potent Foe@Mark of Sacrifice-Devourer
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Decimus|r
.goto 2405,45.94,64.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Decimus|r.
.complete 86521,4 
.target Decimus
.skipgossipid 132673
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
.goto 2405,45.96,64.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
.turnin 86521 >>Turn in Nexus-Point Xenas: Eclipse
.accept 86522 >>Accept Daylight is Breaking
.target Alleria Windrunner
step
#completewith next
#label DawnOfReckoningYA
#hidewindow
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
.turnin 86522 >>Turn in Daylight is Breaking
.target Lor'themar Theron
step
#completewith DawnOfReckoningYA
.zoneskip 2405,1
.goto 2405,51.56,70.29
.zone 2393 >>Click on the |cRXP_PICK_Portal to Silvermoon|r
step
#requires DawnOfReckoningYA
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar|r
.goto 2393,45.44,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar|r.
.complete 86650,1 
.timer 50,Roleplay
.target Lor'themar
.skipgossipid 134143
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
.goto 2393,45.44,70.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r.
*|cRXP_WARN_Relog to skip the roleplay; saves 50seconds|r
.turnin 91087 >>Turn in Reports Returned
.turnin 86650 >>Turn in Fractured
.turnin 91787 >>Turn in The Journey Ends
.turnin 91084 >>Turn in Looming Shadow
.turnin 86522 >>Turn in Daylight is Breaking
.accept 95276 >>Accept The Last Push
.turnin 95276 >>Turn in The Last Push

.target Lor'themar Theron
.macro ,Logout >>/logout
step
.goto 2393,50.34,65.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vaultkeeper Elysa|r.
.accept 94474 >>Accept The Great Vault
.target Vaultkeeper Elysa
step
.goto 2393,48.56,62.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vaskarn|r.
.accept 94430 >>Accept Adventuring Gear
.target Vaskarn
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Shadow Enclave
#internal

step
#arrowtext Enter the Shadow Enclave
.goto 2395,45.56,86.32
.enterScenario 3154,3262,3257,3301 >>Enter the Shadow Enclave Delve in Eversong Forest.
step
#label TheShadowEnclaveA
.isNotOnQuest 86636
.zoneskip 2502,1
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2502,29.07,73.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.accept 93372 >>Accept Delver's Call: Shadow Enclave
step
.isQuestTurnedIn account,86522
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2502,29.07,73.60
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.accept 93372 >>Accept Delver's Call: Shadow Enclave
step
.isOnQuest 86636
#arrowtext Click on\n|cRXP_PICK_Delver's Supplies|r
.goto 2502,34.12,69.69
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Delver's Supplies|r
.complete 86636,2 
.skipgossipid 135011
step
.isOnQuest 86636
#arrowtext Select healer
.goto 2502,34.12,69.69
>>Select "Combat Role Healer"
.complete 86636,3 
.skipgossipid 135011
step
#label TheShadowEnclaveB
.goto 2502,40.55,67.19
.isInScenario 3154,Shadowey Supplies
#title |cFFFCDC00Follow the Arrow|r
.scenario 16032,1 
step
#arrowtext Click on\n|cRXP_PICK_Void Focus|r
#loop
.goto 2502,40.55,67.19,10,0
.goto 2502,42.99,64.83,10,0
.isInScenario 3154
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Focus|r
.scenario 16028,1 
step
.isInScenario 3154
#completewith LastRitual
>>Kill |cRXP_ENEMY_Twilight Cultists|r
.scenario 16029,2,100
.mob Cult Adept
.mob Bladesworn Cultists
.mob Shadowstone Elemental
.mob Shadowspawn
.mob Abandoned Sentinel
.mob Shadowburn Vortex
.mob Ogre Bowbeater
.mob Shadowstone Elemental
step
.isInScenario 3154
#arrowtext Kill\n|cRXP_ENEMY_Twilight Cultists|r
.goto 2502,52.16,82.53
>>Kill the |cRXP_ENEMY_Twilight Cultists|r around the ritual area.
*Kill |cRXP_ENEMY_Darkcaller Lysaille|r and |cRXP_ENEMY_Summoned Voidbreaker|r.
.scenario 16029,1,1
.mob Summoned Voidbreaker
.mob Darkcaller Lysaille
step
.isInScenario 3154
#arrowtext Kill\n|cRXP_ENEMY_Twilight Cultists|r
.goto 2502,56.32,63.93,20,0
.goto 2502,63.67,53.65,20,0
.goto 2502,64.3,68.7,20,0
.goto 2502,74.29,72.17
>>Kill the |cRXP_ENEMY_Twilight Cultists|r around the ritual area.
*Kill |cRXP_ENEMY_Darkcaller Cimberon|r and |cRXP_ENEMY_Summoned Siphoid Prime|r.
.scenario 16029,1,2
.mob Darkcaller Cimberon
.mob Summoned Siphoid Prime
step
#label LastRitual
.isInScenario 3154
#arrowtext Kill\n|cRXP_ENEMY_Twilight Cultists|r
.goto 2502,79.47,59.26,20,0
.goto 2502,72.42,45.54
>>Kill the |cRXP_ENEMY_Twilight Cultists|r around the ritual area.
>>Kill |cRXP_ENEMY_Twilight Cultists|r, |cRXP_ENEMY_Darkcaller Thelamorn|r and |cRXP_ENEMY_Summoned Siphoid Prime|r.
.scenario 16029,1,3
.mob Darkcaller Thelamorn
.mob Summoned Voidbinder


















step
#label Antenorian's Devoted
#arrowtext Kill\n|cRXP_ENEMY_Antenorian's Devoted|r
#loop
.goto 2502,63.6,37.26,8,0
.goto 2502,60.57,37.6,8,0
.goto 2502,60.29,32.82,8,0
.isInScenario 3154
>>Kill |cRXP_ENEMY_Antenorian's Devoted|r
.scenario 16030,1 
step
#label 3154ScenarioEnd
#arrowtext Kill\n|cRXP_ENEMY_Lord Antenorian|r
.goto 2502,61.81,35.33
.isInScenario 3154
>>Kill |cRXP_ENEMY_Lord Antenorian|r
*|cRXP_WARN_Destroy the |cRXP_ENEMY_Shadow Orbs|r|r
.scenario 16031,1 
.mob Lord Antenorian
.mob Shadow Orb

step
#label Shadowey Supplies
.isInScenario 3257,MirrorShine
#arrowtext Talk to\n|cRXP_FRIENDLY_Doleana Silverstalk|r
.goto 2502,26.17,72.06,55,0
.goto 2502,35.43,64.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doleana Silverstalk|r.
.scenario 16447,1 
.skipgossipid 137619
.target Doleana Silverstalk
step
#arrowtext Click on\n|cRXP_PICK_Materials|r
#loop
.goto 2502,30.25,63.43,20,0
.goto 2502,30.7,49.44,25,0
.goto 2502,36.13,47.45,25,0
.goto 2502,34.79,53.67,20,0
.goto 2502,48.45,82.57,30,0
.goto 2502,53.42,79.21,30,0
.goto 2502,63.73,53.47,30,0
.goto 2502,65.19,70.16,30,0
.goto 2502,75.22,72.79,30,0
.goto 2502,78.67,57.58,30,0
.goto 2502,73.16,43.79,30,0
.goto 2502,65.45,40.85,30,0
.isInScenario 3257
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Materials|r
*|cRXP_WARN_Walk over materials dropped from slain foes.|r
.scenario 16448,1 
.mob Cult Adept
.mob Ogre Bowbeater
.mob Shadowspawn
.mob Shadowburn Vortex
.mob Twilight Ogre Mage
.mob Bladesworn Cultist
step
#label 3257ScenarioEnd
#arrowtext Kill\n|cRXP_ENEMY_Antenorian|r
.goto 2502,62.49,31.41
.isInScenario 3257
>>Kill |cRXP_ENEMY_Antenorian|r
*|cRXP_WARN_Destroy the |cRXP_ENEMY_Shadow Orbs|r|r
.scenario 16449,1 
.mob Antenorian

step
#label MirrorShine
.isInScenario 3262
#arrowtext Talk to\n|cRXP_FRIENDLY_Gabby Flashwiks|r
.goto 2502,34.62,66.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gabby Flashwiks|r.
.scenario 16460,1 
.skipgossipid 137580
.target Gabby Flashwiks
step
#arrowtext Click on\n|cRXP_PICK_Mirror|r
.goto 2502,34.36,65.07
.isInScenario 3262
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mirror|r
.scenario 16565,1 
step
#arrowtext Step into the light
.goto 2502,32.01,65.23
.isInScenario 3262
>>Step into the light with the mirror.
.scenario 16565,2 
step
#arrowtext Redirect the light
.goto 2502,35.16,65.18
.isInScenario 3262
>>Redirect the light onto the Luxmaster 5000
.scenario 16565,3 
step
#arrowtext Redirect light with mirrors
#loop
.goto 2502,34.76,63.68,10,0
.goto 2502,47.35,47.23,25,0
.goto 2502,46.5,28.84,25,0
.goto 2502,46.05,20.04,25,0
.goto 2502,50.94,20.71,25,0
.goto 2502,56.27,30.69,25,0
.goto 2502,62.9,34.38,25,0
.goto 2502,64.74,29.53,25,0
.goto 2502,70.91,45.05,30,0
.goto 2502,74.22,44.21,15,0
.goto 2502,81.06,60.77,30,0
.goto 2502,74.33,71.15,30,0
.goto 2502,76.22,72.09,15,0
.goto 2502,65.79,72.69,20,0
.goto 2502,63.59,53.93,30,0
.goto 2502,60.15,58.08,25,0
.goto 2502,53.69,67.05,25,0
.goto 2502,52.07,84.99,30,0
.goto 2502,42.45,67.99,30,0
.isInScenario 3262
>>Pick up Mirrors and redirect the light into other Mirrors & Orbs.
*|cRXP_WARN_Aim the beam at the Orb until it explodes.|r
.scenario 16461,1 
.mob Twilight Ogre Mage
.mob Shadowstone Elemental
.mob Shadowburn Vortex
.mob Umbral Skullcrusher
.mob Bladesworn Cultist
.mob Ogre Browbeater
.mob Shadowspawn
step
#label 3262ScenarioEnd
#arrowtext Kill\n|cRXP_ENEMY_Antenorian|r
.goto 2502,37.67,58.62
.isInScenario 3262
>>Kill |cRXP_ENEMY_Antenorian|r
*|cRXP_WARN_Destroy the |cRXP_ENEMY_Shadow Orbs|r|r
.scenario 16462,1 
.mob Antenorian

step
#label InfiltrateAndAmeliorateStageA
.isInScenario 3301
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Lok'aemon|r
.goto 2502,32.51,68.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Lok'aemon|r.
.scenario 16617,1 
.target Scout Lok'aemon
.skipgossipid 138690
step
#completewith InfiltrateAndAmeliorateStageB
#label UlatekSummonersKickedA
#hidewindow
.isInScenario 3301
.scenario 16618,1 
step
#completewith InfiltrateAndAmeliorateStageB
#label CauldronsSabotagedA
#hidewindow
.isInScenario 3301
.scenario 16618,3 
step
#completewith UlatekSummonersKickedA
#label UlatekSummonersKickedB
#arrowtext Click on |cRXP_PICK_Ula'tek Summoners|r\nSummoners kicked (1/5)\n|cRXP_WARN_(Hardcoded)|r
.isInScenario 3301
.goto 2502,49.57,43.53
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ula'tek Summoners|r
.scenario 16618,1,1 
step
#requires UlatekSummonersKickedB
#completewith UlatekSummonersKickedA
#label UlatekSummonersKickedC
#arrowtext Click on |cRXP_PICK_Ula'tek Summoners|r\nSummoners kicked (2/5)\n|cRXP_WARN_(Hardcoded)|r
.isInScenario 3301
.goto 2502,51.62,54.02
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ula'tek Summoners|r
.scenario 16618,1,2 
step
#requires UlatekSummonersKickedC
#completewith CauldronsSabotagedA
#label CauldronsSabotagedB
#arrowtext Click on\n|cRXP_PICK_Oddball "Ingredient"|r\nBring it to |cRXP_PICK_Cauldron|r
.goto 2502,55.16,46.48,12,0
.goto 2502,46.38,49.67,10,0
.goto 2502,45.29,55.57,10,0
.goto 2502,48.42,49.22
.isInScenario 3301
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Oddball "Ingredient"|r and bring it back to the |cRXP_PICK_Cauldron|r.
*You can look at the yellow dots on your minimap as well. For some you have to jump onto a mushroom.
.scenario 16618,3,1 
step
#requires CauldronsSabotagedB
#completewith UlatekSummonersKickedA
#label UlatekSummonersKickedD
#arrowtext Click on |cRXP_PICK_Ula'tek Summoners|r\nSummoners kicked (3/5)\n|cRXP_WARN_(Hardcoded)|r
.isInScenario 3301
.goto 2502,51.43,36.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ula'tek Summoners|r
.scenario 16618,1,3 
step
#requires UlatekSummonersKickedD
#completewith CauldronsSabotagedA
#label CauldronsSabotagedC
.isInScenario 3301
#arrowtext Click on\n|cRXP_PICK_Oddball "Ingredient"|r\nBring it to |cRXP_PICK_Cauldron|r
.goto 2502,50.28,29.39,8,0
.goto 2502,50.45,22.63,10,0
.goto 2502,41.28,16.24,10,0
.goto 2502,48.54,31.93,6,0
.goto 2502,50.28,29.39,8,0
.goto 2502,43.25,18.83
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Oddball "Ingredient"|r and bring it back to the |cRXP_PICK_Cauldron|r.
*You can look at the yellow dots on your minimap as well. For some you have to jump onto a mushroom.
.scenario 16618,3,2 
step
#requires CauldronsSabotagedC
#completewith UlatekSummonersKickedA
#label UlatekSummonersKickedD
#arrowtext Click on |cRXP_PICK_Ula'tek Summoners|r\nSummoners kicked (4/5)\n|cRXP_WARN_(Hardcoded)|r
.isInScenario 3301
.goto 2502,57.83,36.96
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ula'tek Summoners|r
.scenario 16618,1,4 
step
#requires UlatekSummonersKickedD
#completewith CauldronsSabotagedA
#label CauldronsSabotagedD
.isInScenario 3301
#arrowtext Click on\n|cRXP_PICK_Oddball "Ingredient"|r\nBring it to |cRXP_PICK_Cauldron|r
.goto 2502,56.39,36.00,8,0
.goto 2502,66.54,27.46,8,0
.goto 2502,63.84,35.26,6,0
.goto 2502,65.61,42.80,6,0
.goto 2502,62.39,33.67
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Oddball "Ingredient"|r and bring it back to the |cRXP_PICK_Cauldron|r.
*You can look at the yellow dots on your minimap as well. For some you have to jump onto a mushroom.
.scenario 16618,3,3 
step
#requires CauldronsSabotagedD
#completewith UlatekSummonersKickedA
#label UlatekSummonersKickedD
#arrowtext Click on |cRXP_PICK_Ula'tek Summoners|r\nSummoners kicked (5/5)\n|cRXP_WARN_(Hardcoded)|r
.isInScenario 3301
.goto 2502,61.13,40.57
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Ula'tek Summoners|r
.scenario 16618,1 
step
#requires UlatekSummonersKickedD
#completewith CauldronsSabotagedA
#label InfiltrateAndAmeliorateStageB
.isInScenario 3301
#arrowtext Click on\n|cRXP_PICK_Oddball "Ingredient"|r\nBring it to |cRXP_PICK_Cauldron|r
.goto 2502,81.49,61.96,8,0
.goto 2502,71.41,72.96,8,0
.goto 2502,71.55,69.09,8,0
.goto 2502,74.49,70.93
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Oddball "Ingredient"|r and bring it back to the |cRXP_PICK_Cauldron|r.
*You can look at the yellow dots on your minimap as well.
.scenario 16618,3 
step
#requires InfiltrateAndAmeliorateStageB
.isInScenario 3301
#arrowtext Jump onto the mushroom
.goto 2502,58.04,59.52,10,0
.goto 2502,48.03,46.24
>>Wait for the roleplay.
.scenario 17139,1 
step
.isInScenario 3301
#arrowtext Wait for the roleplay
.goto 2502,57.19,47.76
>>Wait for the roleplay.
.scenario 17138,1 
step
#label InfiltrateAndAmeliorateStageZ
.isInScenario 3301
#arrowtext Kill\n|cRXP_ENEMY_Abominable Blunder|r
.goto 2502,48.03,46.24
>>Kill the |cRXP_ENEMY_Abominable Blunder|r.
.scenario 16619,1 
.mob Abominable Blunder
step
.isOnQuest 86636
#arrowtext Kill\n|cRXP_ENEMY_Lord Antenorian|r
.goto 2502,61.81,35.33
>>Kill |cRXP_ENEMY_Lord Antenorian|r
*Loot him for the |T1506451:0|t[|cRXP_LOOT_Stolen Knowledge|r].
*|cRXP_WARN_Destroy the |cRXP_ENEMY_Shadow Orbs|r|r
.complete 86636,4 
.complete 86636,5 
.mob Lord Antenorian
step
.isOnQuest 93372
.isQuestNotComplete 93372
#arrowtext Complete the delve
.goto 2395,45.56,86.32
>>Complete the Shadow Enclave delve
.complete 93372,1 
step
#label DelveShadowEnclaveExit
.zoneskip 2502,1
#arrowtext Leave the delve
.goto 2502,67.99,26.02,-1 
.goto 2502,34.31,56.41,-1 
.zone 2395 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224





]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Shadow Enclave 2
#internal

step
.isQuestAvailable 93372
.isQuestNotComplete 93372
#arrowtext Enter the Shadow Enclave
.goto 2395,45.56,86.32
.enterScenario 3154,3262,3257,3301 >>Enter the Shadow Enclave Delve in Eversong Woods.
step
#include a) The Shadow Enclave@TheShadowEnclaveA-TheShadowEnclaveA
step
.goto 2502,40.55,67.19
.isInScenario 3154,Shadowey Supplies 2
#title |cFFFCDC00Follow the Arrow|r
.scenario 16032,1 
step
#include a) The Shadow Enclave@TheShadowEnclaveB-3154ScenarioEnd

step
#label Shadowey Supplies 2
.isInScenario 3257,MirrorShine 2
#arrowtext Talk to\n|cRXP_FRIENDLY_Doleana Silverstalk|r
.goto 2502,26.17,72.06,55,0
.goto 2502,35.43,64.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doleana Silverstalk|r.
.scenario 16447,1 
.skipgossipid 137619
.target Doleana Silverstalk
step
#include a) The Shadow Enclave@Shadowey Supplies-3257ScenarioEnd

step
#label MirrorShine 2
.isInScenario 3262, DelveShadowEnclaveExit 2
#arrowtext Talk to\n|cRXP_FRIENDLY_Gabby Flashwiks|r
.goto 2502,34.62,66.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gabby Flashwiks|r.
.scenario 16460,1 
.skipgossipid 137580
.target Gabby Flashwiks
step
#include a) The Shadow Enclave@MirrorShine-3262ScenarioEnd







step
#include a) The Shadow Enclave@InfiltrateAndAmeliorateStageA-InfiltrateAndAmeliorateStageZ
step
#label DelveShadowEnclaveExit 2
.zoneskip 2502,1
#arrowtext Leave the delve
.goto 2502,67.99,26.02,-1 
.goto 2502,34.31,56.41,-1 
.zone 2395 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Collegiate Calamity
#internal
step
#arrowtext Enter Collegiate Calamity
.goto 2393,40.28,53.06
.enterScenario 3183,3187,3193,3299 >>Enter the Collegiate Calamity Delve in Silvermoon.
step
#label CollegiateCalamityA
.isQuestTurnedIn account,86636
.zoneskip 2577,1
#arrowtext Click on\n|cRXP_PICK_Book|r
.goto 2577,59.55,60.12
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Book|r.
.accept 93384 >>Accept Delver's Call: Collegiate Calamity
.target Agitated Tome

step
.isInScenario 3183,Academy Under Siege
#arrowtext Talk to\n|cRXP_FRIENDLY_Bloomkeeper Thornflare|r
.goto 2577,44.1,42.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloomkeeper Thornflare|r
.scenario 16097,1 
.target Bloomkeeper Thornflare
.skipgossipid 135708
step
.isInScenario 3183
#arrowtext Click on\n|cRXP_PICK_Bombs|r
.goto 2577,44.32,44.13
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bombs|r
.scenario 16124,1
step
.isInScenario 3183
#arrowtext Use\n|T133712:0|t|cRXP_WARN_[ExtraActionButton]|r
#loop
.goto 2577,32.85,54.63,15,0
.goto 2577,31.27,40.18,15,0
.goto 2578,48.76,24.86,20,0
.goto 2578,64.51,48.91,20,0
.goto 2578,51.05,61.9,20,0
>>Use the |T133712:0|t|cRXP_WARN_[ExtraActionButton]|r on |cRXP_ENEMY_Lightbloom Weedling|r
.scenario 16120,1
.mob Lightbloom Weedling
step
.isInScenario 3183
#hidewindow
#completewith Thornmaw Briarblaze
#arrowtext Kill |cRXP_ENEMY_Lightblooms|r\nUse the button on |cRXP_ENEMY_Luminbulb|r
#loop
.goto 2578,36.17,55.46,10,0
.goto 2547,54.51,41.75,10,0
.goto 2547,62.02,60.75,30,0
.goto 2547,77,48.26,30,0
.goto 2547,60.43,78.18,30,0
.goto 2547,44.35,65.99,30,0
.goto 2547,32.47,67.88,30,0
.goto 2547,42.87,23.56,30,0
+1
step
.isInScenario 3183
#completewith Thornmaw Briarblaze
>>Kill |cRXP_ENEMY_Lightblooms|r
*|cRXP_WARN_Use the|r |T133712:0|t|cRXP_WARN_[ExtraActionButton]|r for extra damage.
.scenario 16098,1,100
.mob Thornmaw Briarblaze
.mob Thornblade
.mob Leafweaver
step
#completewith Thornmaw Briarblaze
.isInScenario 3183
>>Use the |T133712:0|t|cRXP_WARN_[ExtraActionButton]|r on |cRXP_ENEMY_Luminbulb|r
.scenario 16098,2
.mob Luminbulb
step
#label Thornmaw Briarblaze
#hidewindow
.isInScenario 3183
.scenario 16098,1
.scenario 16098,2
step
.isInScenario 3183
#arrowtext Kill\n|cRXP_ENEMY_Hydrangea|r
.goto 2547,34.03,50.61
>>Kill |cRXP_ENEMY_Hydrangea|r
.scenario 16099,1
.mob Hydrangea

step
#label Academy Under Siege
.isInScenario 3187
#completewith CollegiateCalamityAA
+Click on |cRXP_PICK_Scrolls|r for various extra abilities
step
#arrowtext Talk to\n|cRXP_FRIENDLY_Thalandri Fatesinger|r
.goto 2577,49.25,51.55
.isInScenario 3187
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thalandri Fatesinger|r.
.scenario 16112,1 
.skipgossipid 135798
.target Thalandri Fatesinger
step
#sticky
#label VoidbeingsKilledA
#arrowtext Kill\n|cRXP_ENEMY_Voidbeings|r
.goto 2547,30.88,36.9,0,0
.isInScenario 3187,Faculty of Fear
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 16113,1,100 
.mob Voidspawn
.mob Voidwalker Render
.mob Voidcaller Manipulator
.mob Voidcaller Obliviator
step
#arrowtext Click on\n|cRXP_PICK_Note|r
.goto 2577,40.02,46.04,20,0
.goto 2577,29.97,55.17,20,0
.goto 2577,34.15,35.35,20,0
.goto 2578,47.16,24.14,20,0
.goto 2578,63.2,47.27,20,0
.goto 2578,49.4,61.9,20,0
.goto 2578,35.84,41.45,15,0
.goto 2547,49.08,49.8
.isInScenario 3187
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Note|r
.scenario 16113,2,1 
step
#arrowtext Click on\n|cRXP_PICK_Portal|r
.goto 2547,56.41,49.42,10,0
.goto 2547,59.23,59.98
.isInScenario 3187
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.scenario 16113,3 
step
.isInScenario 3187
#arrowtext Click on\n|cRXP_PICK_Note|r
.goto 2547,60.87,45.75
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Note|r
.scenario 16113,2,2 
step
.isInScenario 3187
#arrowtext Click on\n|cRXP_PICK_Note|r
.goto 2547,62.2,36.45,10,0
.goto 2547,64.71,30.03,10,0
.goto 2547,55.17,32.49
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Note|r
.scenario 16113,2,3 
step
.isInScenario 3187
#arrowtext Click on\n|cRXP_PICK_Note|r
.goto 2547,38.1,34,10,0
.goto 2547,36.97,24.96,10,0
.goto 2547,31.61,28.17,10,0
.goto 2547,31.87,35.23,10,0
.goto 2547,30.88,36.9
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Note|r
.scenario 16113,2,4 
step
#requires VoidbeingsKilledA
#arrowtext Kill\n|cRXP_ENEMY_Voidscorned Vagrant|r
.goto 2547,40.94,55.99
.isInScenario 3187
>>Kill |cRXP_ENEMY_Voidscorned Vagrant|r
.scenario 16114,1 
.mob Voidscorned Vagrant

step
.isInScenario 3193
#label Faculty of Fear
#arrowtext Talk to\n|cRXP_FRIENDLY_Celoenus Blackflame|r
.goto 2577,55.8,51.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celoenus Blackflame|r.
.scenario 16121,1 
.skipgossipid 135865
.target Celoenus Blackflame
step
#arrowtext Use\n|T136155:0|t|cRXP_WARN_[ExtraActionButton]|r
#loop
.goto 2577,33.45,62.69,20,0
.goto 2577,30.23,43.8,15,0
.goto 2578,45.86,23.38,20,0
.goto 2578,57.61,30.19,20,0
.goto 2578,62.51,51.41,20,0
.goto 2578,47.75,63.21,20,0
.goto 2578,36.91,53.76,10,0
.goto 2547,54.21,43.54,15,0
.goto 2547,56.47,48.3,15,0
.goto 2547,62.43,60.43,20,0
.goto 2547,68.83,51.69,20,0
.goto 2547,70.8,57.41,15,0
.goto 2547,67.83,68.64,20,0
.goto 2547,64.87,73.37,20,0
.goto 2547,59.08,80.15,20,0
.goto 2547,53.36,64.93,20,0
.goto 2547,42.66,74.29,20,0
.goto 2547,47.21,53.57,20,0
.goto 2547,39.55,52.68,20,0
.goto 2547,31.91,63.77,20,0
.isInScenario 3193
>>Use the |T136155:0|t|cRXP_WARN_[ExtraActionButton]|r near |cRXP_FRIENDLY_Npcs|r to reveal them then kill them.
.scenario 16122,1,100 
.scenario 16122,2 
.target University Undergraduate
.target Thalassian Professor
.mob Twilight Adept
.mob Twilight Bladesworn
.mob Twilight's Voidcaster
.mob Shadowspawn
.mob Bladesworn Cultist
.mob Umbral Skullcrusher
.mob Ogre Bowbeater
.mob Shadowburn Vortex
step
#label CollegiateCalamityAA
#arrowtext Kill\n|cRXP_ENEMY_Infiltrator Garand|r
.goto 2547,53.03,58.75
.isInScenario 3193
>>Kill |cRXP_ENEMY_Infiltrator Garand|r
.scenario 16123,1 
.mob Infiltrator Garand

step

.isOnQuest 93384
>>Finish the delve.
.complete 93384,1 
step
#label CollegiateCalamityB
.zoneskip 2547,1
#arrowtext Leave the delve
.goto 2547,31.42,48.27,-1 
.goto 2547,57.01,62.38,-1 
.goto 2547,38.49,65.66,-1 
.zone 2393 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224








]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Darkway
#internal
step
#arrowtext Enter the Darkway
.goto 2393,39.31,31.69
.enterScenario 3184,3185,3256,3514 >>Enter the Darkway Delve in Silvermoon.

step
#arrowtext Talk to\n|cRXP_FRIENDLY_Technician Mireille|r
.goto 2525,48.56,17.40
.isInScenario 3184
#label DarkwayA
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Technician Mireille|r.
.scenario 16133,1 
.skipgossipid 136141
.target Technician Mireille
step
.isQuestTurnedIn account,86636
.zoneskip 2525,1
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2525,49.02,18.63
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.accept 93385 >>Accept Delver's Call: The Darkway
.target The Darkway
step
#arrowtext Click on\n|cRXP_PICK_Crystal|r
.goto 2525,47.74,42.82
.isInScenario 3184
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystal|r
.scenario 16100,1 
step
#arrowtext Kill\n|cRXP_ENEMY_Voidbreaker Oglok|r
.goto 2525,48.05,61.78
>>Kill |cRXP_ENEMY_Voidbreaker Oglok|r
.isInScenario 3184
.scenario 16102,1 
.mob Voidbreaker Oglok
step
#arrowtext Click on\n|cRXP_PICK_Crystals|r
#loop
.goto 2525,48.83,65.96,10,0
.goto 2525,47.24,67.07,10,0
.goto 2525,44.79,63.17,10,0
.goto 2525,42.51,68.55,10,0

.goto 2525,38.8,78.84,25,0

.goto 2525,42.7,63.57,10,0
.goto 2525,40.92,56.37,10,0
.goto 2525,38.98,47.21,10,0
.goto 2525,34.42,51.07,10,0
.goto 2525,34.02,33.66,10,0
.goto 2525,40.19,36.08,10,0
.goto 2525,55.58,36.62,25,0
.goto 2525,57.71,49.12,25,0
.goto 2525,50.38,63.46,25,0
.isInScenario 3184
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crystals|r
*|cRXP_WARN_They spawn differently each time|r
.scenario 16101,2 
.target Stolen Ley Line Focuser
step
#arrowtext Install Ley Line Focusers
#loop
.goto 2525,44.38,54.86,15,0
.goto 2525,42.75,49.2,15,0
.goto 2525,44.65,43.92,15,0
.goto 2525,52.03,43.47,15,0
.goto 2525,53.33,49.28,15,0
.goto 2525,51.65,55.03,15,0
.isInScenario 3184
>>Move around the center of Darkway
.scenario 16101,1 
step
#arrowtext Kill\n|cRXP_ENEMY_Infiltrator Gulkat|r
.goto 2525,48.35,81.14
.isInScenario 3184
>>Kill |cRXP_ENEMY_Infiltrator Gulkat|r
.scenario 16103,1 
.mob Infiltrator Gulkat

step
.isInScenario 3185
#arrowtext Talk to\n|cRXP_FRIENDLY_Technician Mireille|r
.goto 2525,47.71,22.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Technician Mireille|r.
.scenario 16104,1 
.skipgossipid 138009
step
#arrowtext Click on\n|cRXP_PICK_Pillar|r
.goto 2525,48.53,22.46
.isInScenario 3185
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillar|r
.scenario 16580,2 
step
.goto 2525,48.8,33.88
.isInScenario 3185
#title |cFFFCDC00Follow the Arrow|r
.scenario 16580,1 
step
#completewith Infiltrator Gulkat
>>Kill |cRXP_ENEMY_Twilight's Blade|r
.scenario 16105,1,100 
.mob Unstable Shadowsludge
.mob Shadowfused Sentinel
.mob Shadowscale Wyrm
.mob Shadowtaint Anomaly
.mob Cult Adept
.mob Bladesworn Cultist
step
#arrowtext Click on\n|cRXP_PICK_Pillars|r
.goto 2525,48.8,33.88,10,0
.goto 2525,44.82,36.92,10,0
.goto 2525,44.96,41.71,15,0
.goto 2525,43.01,44.09,10,0
.goto 2525,53.07,44.3,10,0
.goto 2525,53.16,54.11
.isInScenario 3185
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillars|r |cRXP_WARN_once|r.
.scenario 16105,2,1 
step
#arrowtext Click on\n|cRXP_PICK_Pillars|r
.goto 2525,52.23,48.06,30,0
.goto 2525,42.75,36.92,30,0
.goto 2525,34.29,38.06
.isInScenario 3185
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillars|r
.scenario 16105,2,2 
step
#arrowtext Click on\n|cRXP_PICK_Pillars|r
.goto 2525,31.51,47.1,10,0
.goto 2525,38.83,49.61,10,0
.goto 2525,43.6,60.66,10,0
.goto 2525,41.15,68.42,15,0
.goto 2525,38.27,70.71
.isInScenario 3185
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pillars|r
.scenario 16105,2 
step
#label Infiltrator Gulkat
#arrowtext Kill\n|cRXP_ENEMY_Infiltrator Gulkat|r
.goto 2525,44.86,63.21,15,0
.goto 2525,48.78,66.07,20,0
.goto 2525,48.06,79.39
.isInScenario 3185
>>Kill |cRXP_ENEMY_Infiltrator Gulkat|r
.scenario 16108,1 
.mob Infiltrator Gulkat

step
#arrowtext Talk to\n|cRXP_FRIENDLY_Technician Mireille|r
.goto 2525,48.59,17.34
.isInScenario 3256
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Technician Mireille|r.
.scenario 16445,1 
.skipgossipid 138317
.target Technician Mireille
step
.goto 2525,45.42,38.79
.isInScenario 3256
#title |cFFFCDC00Follow the Arrow|r
.scenario 16446,1 
step
#arrowtext Kill\n|cRXP_ENEMY_Unstable Aberrations|r
#loop
.goto 2525,45.42,38.79,20,0
.goto 2525,43.9,53.24,30,0
.goto 2525,51.47,54.26,30,0
.goto 2525,48.14,61.37,30,0
.goto 2525,48.35,66.89,30,0
.goto 2525,47.16,73.06,30,0
.goto 2525,48.96,80.54,30,0
.goto 2525,50.43,75.24,10,0
.goto 2525,57.73,75.15,10,0
.goto 2525,60.73,78.86,30,0
.goto 2525,64.02,73.14,30,0
.goto 2525,66.79,57.13,30,0
.goto 2525,67.19,43.58,30,0
.isInScenario 3256
>>Kill |cRXP_ENEMY_Unstable Aberrations|r
.scenario 16595,1 
.mob Unstable Aberrations
step
#arrowtext Kill\n|cRXP_ENEMY_Infiltrator Gulkat|r
.goto 2525,63.04,26.49
.isInScenario 3256
>>Kill |cRXP_ENEMY_Infiltrator Gulkat|r
.scenario 16596,1 
.mob Infiltrator Gulkat

step
.isInScenario 3514
#arrowtext Talk to\n|cRXP_FRIENDLY_Technician Mireille|r
.goto 2525,48.59,17.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Technician Mireille|r.
.scenario 17342,1 
.target Technician Mireille
.skipgossipid 141485
step
.isInScenario 3514
#arrowtext Click on |cRXP_PICK_Ley Lines|r\nRun over |cRXP_PICK_Eggs|r
#loop
.goto 2525,51.09,34.24,12,0
.goto 2525,44.70,34.36,12,0
.goto 2525,45.14,43.06,12,0
.goto 2525,43.19,49.18,12,0
.goto 2525,45.82,55.48,12,0
.goto 2525,50.60,55.29,12,0
.goto 2525,52.70,49.18,12,0
.goto 2525,50.72,43.34,12,0
.goto 2525,48.01,37.52,12,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ley Lines|r.
*Run over the |cRXP_PICK_eggs|r. Kill the |cRXP_ENEMY_serpents|r.
.scenario 17343,1 
.scenario 17343,2 
.scenario 17343,3 
step
#arrowtext Kill\n|cRXP_ENEMY_Replicating Venomborne|r
.goto 2525,63.37,28.67
.isInScenario 3514
>>Kill the |cRXP_ENEMY_Replicating Venomborne|r.
.scenario 17344,1 
.mob Replicating Venomborne
step
#label DarkwayB
.zoneskip 2525,1
#arrowtext Leave the delve
.goto 2525,47.96,82.47,-1 
.goto 2525,63.51,37.55,-1 
.zone 2393 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224





]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Twilight Crypts
#internal
step
#label 1
#arrowtext Enter the Twilight Crypts
.goto 2437,25.41,84.52
.enterScenario 3123,3124,3125,3293 >>Enter the Twilight Crypts in Zul'aman.
step
#label TwilightCryptsA
.isQuestTurnedIn account,86636
.zoneskip 2503,1
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2503,47.18,39.44
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.accept 93410 >>Accept Delver's Call: Twilight Crypts
.target Twilight Crypts
step
#completewith Blademaster Darza
+Dodge Traps and click on |cRXP_PICK_Masks|r
step
.isOnQuest 91918
#sticky
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tormented Deserters|r
.complete 91918,2
.target Tormented Deserter


step
#arrowtext Talk to\n|cRXP_FRIENDLY_Dulgor Legstuck|r
.goto 2503,49.6,49.8
.isInScenario 3123,Trapped!
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dulgor Legstuck|r.
.scenario 15960,1 
.skipgossipid 135239
.target Dulgor Legstuck
step
.goto 2504,75.04,39.91
.isInScenario 3123
#title |cFFFCDC00Follow the Arrow|r
.scenario 15961,1 
step
#arrowtext Summoners slain (1/4)\n|cRXP_WARN_(Read Note)|r
.goto 2504,74.96,54.8
.isInScenario 3123
>>Kill |cRXP_ENEMY_Twilight Summoner|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,1,1 
.mob Twilight Summoner
step
#arrowtext Levers pulled (1/7)\n|cRXP_WARN_(Read Note)|r
.goto 2504,74.95,62.78
.isInScenario 3123
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lever|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,2,1 
step
#arrowtext Levers pulled (2/7)\n|cRXP_WARN_(Read Note)|r
.goto 2504,48.56,54.1
.isInScenario 3123
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lever|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,2,2 
step
#arrowtext Summoners slain (2/4)\n|cRXP_WARN_(Read Note)|r
.goto 2504,51.88,72.25,10,0
.goto 2504,48.86,88.93
.isInScenario 3123
>>Kill |cRXP_ENEMY_Twilight Summoner|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,1,2 
.mob Twilight Summoner
step
#arrowtext Levers pulled (3/7)\n|cRXP_WARN_(Read Note)|r
.goto 2504,39.08,82.66
.isInScenario 3123
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lever|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,2,3 
step
#arrowtext Levers pulled (4/7)\n|cRXP_WARN_(Read Note)|r
.goto 2504,45.55,60.79
.isInScenario 3123
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lever|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,2,4 
step
#arrowtext |cRXP_ENEMY_MAX RANGE|r\nLevers pulled (5/7)\n|cRXP_WARN_(Read Note)|r
.goto 2504,33.68,61.23,15,0
.goto 2504,33.34,45.75
.isInScenario 3123
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lever|r through the gate.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,2,5 
.mob Twilight Summoner
step
#arrowtext Levers pulled (6/7)\nSummoners slain (4/4)\n|cRXP_WARN_(Read Note)|r
.goto 2504,15.34,48.51
.isInScenario 3123
>>Kill |cRXP_ENEMY_Twilight Summoner|r
*|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lever|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15962,1,4 
.scenario 15962,2,6 
.mob Twilight Summoner
step
#arrowtext Levers pulled (7/7)\n|cRXP_WARN_(Read Note)|r
.isInScenario 3123
.goto 2504,19.7,64.5
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lever|r
.scenario 15962,2,7 
.mob Twilight Summoner
step
#label Blademaster Darza
#arrowtext Kill\n|cRXP_ENEMY_Blademaster Darza|r
.goto 2504,33.26,49.15,10,0
.goto 2504,45.85,39.18,15,0
.goto 2504,39.45,21.43
.isInScenario 3123
>>Kill |cRXP_ENEMY_Blademaster Darza|r
.scenario 15964,1 
.mob Blademaster Darza

step
#label Trapped!
.isInScenario 3124,Loosed Loa
#arrowtext Talk to\n|cRXP_FRIENDLY_the Twilight Hostage|r
.goto 2503,50.12,49.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_the Twilight Hostage|r.
.scenario 15965,1 
.skipgossipid 135634
.target the Twilight Hostage
step
#arrowtext Click on\n|cRXP_PICK_Key|r
.goto 2503,47.23,57.25
.isInScenario 3124
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Key|r
.scenario 15966,1 
step
#arrowtext Wait for the roleplay
.goto 2504,48.7,80.51
.isInScenario 3124
>>|cRXP_WARN_Wait for the Roleplay|r.
.scenario 15966,2 
step
#arrowtext Click on\n|cRXP_PICK_Levers|r
.goto 2504,43.25,83.35,25,0
.goto 2504,54.19,82.05,25,0
.goto 2504,51.51,43.82,30,0
.goto 2504,45.72,41.9,30,0
.goto 2504,45.55,34.6,15,0
.goto 2504,38.52,31.83,15,0
.goto 2504,39.51,16.39,15,0
.goto 2504,38.33,34.39,25,0
.goto 2504,33.15,40.03,20,0
.goto 2504,19.43,40.39,20,0
.goto 2504,20.07,56.73,20,0
.goto 2504,32.88,54.28,20,0
.goto 2504,34.83,61.23,20,0
.goto 2504,45.33,62.22,20,0
.goto 2504,51.61,58.65,15,0
.goto 2504,51.9,53.27,15,0
.goto 2504,75.31,56.39
.isInScenario 3124
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Levers|r
*|cRXP_WARN_Click on |cRXP_PICK_Urns|r for a protector and Masks for a DMG Buff|r.
.scenario 15967,1 
step
#label Blademaster DarzaZ
#arrowtext Kill\n|cRXP_ENEMY_Blademaster Darza|r
.goto 2503,45.04,82.51
.isInScenario 3124
>>Kill |cRXP_ENEMY_Blademaster Darza|r
.scenario 15969,1 
.mob Blademaster Darza

step
#label Loosed Loa
#arrowtext Talk to\n|cRXP_FRIENDLY_Scout Lok'aemon|r
.goto 2503,48.06,52.34
.isInScenario 3125
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Lok'aemon|r.
.scenario 15970,1 
.target Scout Lok'aemon
.skipgossipid 135811
step
#arrowtext Click on\n|cRXP_PICK_Elixir|r
.goto 2503,48.75,51.46
.isInScenario 3125
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Elixir|r
.scenario 15971,1 
step
#arrowtext Totems destroyed (1/6)\n|cFFFCDC00(Read Note)|r
#loop
.goto 2503,50.91,88.20,10,0
.goto 2504,74.96,63.72,10,0
.isInScenario 3125
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hex Totem|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15972,2,1 
step
#completewith VilebranchSkeletonCharmersB
.isInScenario 3125
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hex Totem|r.
*|cRXP_WARN_NOTE:|r Totem spawn is random every time.
.scenario 15972,2 
step
#completewith next
#label TwilightCryptsLeverA
#arrowtext Click on the |cRXP_PICK_Lever|r
.goto 2504,74.96,62.67
.isInScenario 3125
.cast 1252748,1252753,1249848,1252209,1252732,1252510,1252518,1252749,1252523,1252750,1252531,1252751,1252533,1252752,1252538,1252674,1252754,1252693,1252755,1253972,1253971,1253777,1253776,1253976,1253975,1261034,1261033,1261021,1261020 >>Click on the |cRXP_PICK_Lever|r.
step
.isInScenario 3125
#completewith TwilightCryptsLeverA
#hidewindow
#arrowtext Follow the arrow
.goto 2504,63.55,53.06,15 >>1
step
#requires TwilightCryptsLeverA
#completewith next
#label VilebranchSkeletonCharmersA
#arrowtext Kill\n|cRXP_ENEMY_Vilebranch Skeleton Charmers|r
.goto 2504,51.30,53.06,15,0
.goto 2504,51.70,63.38,15,0
.goto 2504,32.23,63.63,15,0
.isInScenario 3125
>>Kill |cRXP_ENEMY_Vilebranch Skeleton Charmers|r
.scenario 15972,1 
.mob Vilebranch Skeleton Charmer
step
.isInScenario 3125
#requires TwilightCryptsLeverA
#completewith VilebranchSkeletonCharmersA
#hidewindow
#arrowtext Follow the arrow
.goto 2504,32.32,41.89,15 >>1
step
#requires VilebranchSkeletonCharmersA
#arrowtext Click on\n|cRXP_PICK_Lever|r
.goto 2504,39.45,46.30
.isInScenario 3125
.cast 1252748,1252753,1249848,1252209,1252732,1252510,1252518,1252749,1252523,1252750,1252531,1252751,1252533,1252752,1252538,1252674,1252754,1252693,1252755,1253972,1253971,1253777,1253776,1253976,1253975,1261034,1261033,1261021,1261020 >>Click on the |cRXP_PICK_Lever|r.
*|cRXP_WARN_NOTE:|r Skip this step if you're in the group with someone else who clicked it.
step
#label VilebranchSkeletonCharmersB
#arrowtext Kill\n|cRXP_ENEMY_Vilebranch Skeleton Charmers|r
#loop
.goto 2504,51.30,53.06,15,0
.goto 2504,51.70,63.38,15,0
.goto 2504,32.23,63.63,15,0
.goto 2504,32.32,41.89,15,0
.isInScenario 3125
>>Kill the |cRXP_ENEMY_Vilebranch Skeleton Charmers|r
.scenario 15972,1 
.mob Vilebranch Skeleton Charmer
step
#arrowtext Click on\n|cRXP_PICK_Hex Totem|r
#loop
.goto 2504,15.83,48.79,25,0
.goto 2504,20.00,64.27,25,0
.goto 2504,19.72,33.34,25,0
.goto 2504,45.70,43.68,15,0
.goto 2504,44.02,33.31,15,0
.goto 2504,32.43,34.62,15,0
.goto 2504,75.70,53.77,20,0
.isInScenario 3125
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Hex Totem|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 15972,2 
step
#completewith next
#label TwilightCryptsLeverB
.isInScenario 3125
#arrowtext Click on\n|cRXP_PICK_Lever|r
.goto 2504,45.70,42.95,10,0
.goto 2504,44.00,34.11,10,0
.goto 2504,39.43,37.39
.cast 1252748,1252753,1249848,1252209,1252732,1252510,1252518,1252749,1252523,1252750,1252531,1252751,1252533,1252752,1252538,1252674,1252754,1252693,1252755,1253972,1253971,1253777,1253776,1253976,1253975,1261034,1261033,1261021,1261020 >>Click on the |cRXP_PICK_Lever|r.
*|cRXP_WARN_NOTE:|r Skip this step if you're in the group with someone else who clicked it.
step
#completewith TwilightCryptsLeverB
#hidewindow
.isInScenario 3125
#arrowtext Follow the arrow
.goto 2504,39.45,24.44,10 >>1
step
#requires TwilightCryptsLeverB
#arrowtext Kill\n|cRXP_ENEMY_Blademaster Darza|r
.goto 2504,40.43,19.47
.isInScenario 3125
>>Kill |cRXP_ENEMY_Blademaster Darza|r.
*|cRXP_WARN_NOTE:|r Click the |cRXP_PICK_Lever|r in front of the boss room
.scenario 15974,1 
.mob Blademaster Darza

step

.isOnQuest 93410
>>Finish the delve.
.complete 93410,1 
step
#label TwilightCryptsB
.zoneskip 2504,1
#arrowtext Leave the delve
.goto 2504,39.54,12.75,-1 
.goto 2503,49.26,80.62,-1 
.zone 2437 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224
step
#label TwilightCryptsZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Tavikko|r
.goto 2437,45.44,64.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93410 >>Turn in Delver's Call: Twilight Crypts
.target Tavikko
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Atal'Aman
#internal
step
#arrowtext Enter Atal'Aman
.goto 2395,63.8,80.02
.enterScenario 3117,3147,3148,3300 >>Enter the Atal'Aman Delve inside the Amani Pass.
step
#label AtalAmanA
.isQuestTurnedIn account,86636
.zoneskip 2535,1
#arrowtext Click on\n|cRXP_PICK_Fallen Amani Scout|r
.goto 2535,24.90,43.14
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Fallen Amani Scout|r.
.accept 93409 >>Accept Delver's Call: Atal'Aman
.target Fallen Amani Scout

step
.isInScenario 3117,RitualInterrupted
#arrowtext Talk to\n|cRXP_FRIENDLY_Torundo The Grizzled|r
.goto 2535,31.27,44.41,10,0
.goto 2535,32.29,42.43,8,0
.goto 2535,33.27,42.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torundo The Grizzled|r.
.scenario 16159,1 
.skipgossipid 136317
.target Torundo The Grizzled
step
.isInScenario 3117
.zoneskip 2535,1
#arrowtext Click on\n|cRXP_PICK_Drum|r
.goto 2535,34.03,49.8
.aura 1263314 >>Click on the |cRXP_PICK_Drum|r for a movementspeed buff.
step
.isInScenario 3117
#hidewindow
#completewith Cursed Totems
#arrowtext Kill |cRXP_ENEMY_Vilebranches|r\nClick on |cRXP_PICK_Totems|r
#loop
.goto 2535,40.9,47.46,10,0
.goto 2535,47.48,39.49,15,0
.goto 2535,45.99,37.35,20,0
.goto 2535,49.55,36.62,15,0
.goto 2535,49.75,30.55,15,0
.goto 2535,43.94,32.9,15,0
.goto 2535,45.57,26.93,20,0
.goto 2535,40.66,27.58,20,0
.goto 2535,42.3,18.92,20,0
.goto 2535,48.44,19,20,0
+1






step
.isInScenario 3117
#completewith Cursed Totems
>>Kill |cRXP_ENEMY_Vilebranches|r
.scenario 15939,1,100
step
#completewith Cursed Totems
#arrowtext Click on\n|cRXP_PICK_Totems|r
.goto 2535,42.18,18.87
.isInScenario 3117
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Totems|r
.scenario 15939,2 
step
#label Cursed Totems
#hidewindow
.isInScenario 3117
.scenario 15939,1,100
.scenario 15939,2 
step
#arrowtext Kill\n|cRXP_ENEMY_Spiritflayer Jin'Ma|r
.goto 2535,48.93,25.6
.isInScenario 3117
>>Kill |cRXP_ENEMY_Spiritflayer Jin'Ma|r
.scenario 15941,1 
.mob Spiritflayer Jin'Ma

step
.isInScenario 3147,ToadlyUnbecoming
#label RitualInterrupted
#arrowtext Talk to\n|cRXP_FRIENDLY_Fleek|r
.goto 2535,31.03,44.2,20,0
.goto 2535,32.15,41.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleek|r.
.scenario 16161,1 
.skipgossipid 136318
.target Fleek
step
.isInScenario 3147
#arrowtext Click on\n|cRXP_PICK_Cages|r
#loop
.goto 2535,35.8,43.59,10,0
.goto 2535,35.22,47.77,10,0
.goto 2535,34.21,49.88,15,0
.goto 2535,37.07,51.89,15,0
.goto 2535,37.58,58.14,15,0
.goto 2535,34.15,65.33,15,0
.goto 2535,42.28,56.58,15,0
.goto 2535,46.83,53.3,15,0
.goto 2535,47.73,65.43,15,0
.goto 2535,42.64,70.99,15,0
.goto 2535,49.19,75.07,15,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Cages|r.
*|cRXP_WARN_Click on the Weapon Rack and a Drum for a damage and speed buff|r
.scenario 16163,1 
step
#arrowtext Kill\n|cRXP_ENEMY_Consumption of Nalorakk|r
.goto 2535,46.06,74.49,15,0
.goto 2535,47.34,81.86,15,0
.goto 2535,52.16,80.18
.isInScenario 3147
>>Kill the waves of enemies and |cRXP_ENEMY_Consumption of Nalorakk|r.
.scenario 16007,1 
.mob Hexbound Ritualist
.mob Necrohex Soulbinder
.mob Decrepit Skeleton
.mob Vilebranch Chainbinder
.mob Consumption of Nalorakk
step
.isInScenario 3147
#arrowtext Kill\n|cRXP_ENEMY_Spiritflayer Jin'Ma|r
.goto 2535,56.86,82.26
>>Kill |cRXP_ENEMY_Spiritflayer Jin'Ma|r2
*|cRXP_WARN_Run into your spirits|r
.scenario 16008,1 
.mob Spiritflayer Jin'Ma

step
#label ToadlyUnbecoming
.isInScenario 3148
#arrowtext Talk to\n|cRXP_FRIENDLY_Kasha|r
.goto 2535,31.27,44.41,10,0
.goto 2535,32.16,41.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kasha|r.
.scenario 16162,1 
.target Kasha
.skipgossipid 136385
step
#arrowtext Click on\n|cRXP_PICK_Crate|r
.goto 2535,32.61,41.67
.isInScenario 3148
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
.scenario 16166,1 
step
.isInScenario 3148
#arrowtext Click on\n|cRXP_PICK_Puddle-Jumper Shrine|r
.goto 2535,35.82,44.02,8,0
.goto 2535,34.04,49.82
.aura 1280207 >>Click on the |cRXP_PICK_Puddle-Jumper Shrine|r for a movement speed buff
.target Puddle-Jumper Shrine
step
.isInScenario 3148
#completewith next
#hidewindow
#arrowtext Use the |T135485:0|t[ExtraActionButton]
.scenario 16009,2 
step
#arrowtext Use the |T135485:0|t[ExtraActionButton]
#loop
.goto 2535,38.58,49.50,20,0
.goto 2535,42.75,42.76,25,0
.goto 2535,50.06,41.84,25,0
.goto 2535,45.65,34.03,25,0
.goto 2535,42.65,30.08,25,0
.goto 2535,37.49,31.25,25,0
.goto 2535,46.56,57.32,25,0
.goto 2535,45.63,73.10,25,0
.goto 2535,39.99,76.24,25,0
.isInScenario 3148
>>Kill the |cRXP_ENEMY_Vilebranch forces|r.
>>Use the |T135485:0|t[ExtraActionButton] to free |cRXP_FRIENDLY_Cursed Frogs|r.
.scenario 16009,1,100 
.scenario 16009,2 
.mob Apprentice Corpsecaller
.mob Leering Skulltaker
.mob Lurking Shadowcaller
.mob Giant Cursed Bullfrog
.mob Curse Mask
.mob Returned Warrior
step
#arrowtext Talk to |cRXP_FRIENDLY_Mojo|r\n|cRXP_WARN_NEXT TO YOU|r.
.goto 2535,54.84,57.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mojo|r.
.isInScenario 3148
.scenario 16010,2 
.skipgossipid 138496
step
#arrowtext Kill\n|cRXP_ENEMY_Spiritflayer Jin'Ma|r
.goto 2535,54.84,57.64
.isInScenario 3148
>>Kill |cRXP_ENEMY_Spiritflayer Jin'Ma|r
.scenario 16010,1 
.mob Spiritflayer Jin'Ma

step

.isOnQuest 93409
>>Finish the delve.
.complete 93409,1 
step
#label AtalAmanB
.zoneskip 2535,1
#arrowtext Leave the delve
.goto 2535,50.29,27.9,-1 
.goto 2535,56.83,82.5,-1 
.goto 2535,55.59,57.8,-1 
.zone 2395 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224
step
#label AtalAmanZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Tavikko|r
.goto 2437,45.44,64.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tavikko|r.
.turnin 93409 >>Turn in Delver's Call: Atal'Aman
.target Tavikko
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Gulf of Memory
#internal
step
#arrowtext Enter the Gulf of Memory
.goto 2413,36.7,49.68
.enterScenario 3177,3242,3243 >>Enter The Gulf of Memory Delve in Harandar.
step
#label GulfofMemoryStart1
.zoneskip 2505,1
.isQuestTurnedIn account,86636
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2505,50.76,17.24
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r on the wall.
.accept 93416 >>Accept Delver's Call: The Gulf of Memory
.target The Gulf of Memory

step
.isInScenario 3177,Alnmoth Munchies
#hidewindow
#completewith Unusual Treasure
#arrowtext Click on |cRXP_PICK_Treasures|r\nClick on |cRXP_PICK_Candles|r
#loop
.goto 2505,50.43,20.06,10,0
.goto 2505,48.49,23.27,10,0
.goto 2505,51.14,26.02,10,0
.goto 2505,55.44,26.81,12,0
.goto 2505,49.39,29.72,15,0
.goto 2505,47.82,33.38,25,0
.goto 2505,47.99,41.55,25,0
.goto 2505,50.02,47.87,25,0
.goto 2505,54.73,42.84,25,0
.goto 2505,53.96,33.54,25,0
+1
step
#completewith Unusual Treasure
.isInScenario 3177
*Kill |cRXP_ENEMY_Kobolds|r they sometimes let go of extra treasures.
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Treasures|r
.scenario 16081,2 
.mob Kobold Thwacker
.mob Kobold Mystic
step
#completewith Unusual Treasure
.isInScenario 3177
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Candles|r
.scenario 16081,1 
step
#label Unusual Treasure
#hidewindow
.isInScenario 3177
.scenario 16081,1 
.scenario 16081,2 
step
#arrowtext Click on\n|cRXP_PICK_Webbed Haranir|r
#loop
.goto 2505,58.49,44.19,30,0
.goto 2505,62.69,39.94,30,0
.goto 2505,65.81,29.13,15,0
.goto 2505,67.68,35.61,15,0
.isInScenario 3177
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Webbed Haranir|r
.scenario 16083,1 
.target Webbed Haranir
step
#arrowtext Kill\n|cRXP_ENEMY_Horrors|r
#loop
.goto 2505,70.2,52.55,25,0
.goto 2505,68.08,67.58,25,0
.goto 2505,64.76,67.04,25,0
.goto 2505,67.57,59.24,25,0
.goto 2505,74.19,61.36,25,0


.isInScenario 3177
>>Kill |cRXP_ENEMY_Horrors|r
*|cRXP_WARN_Be aware of possible knockbacks|r
.scenario 16084,1,100 
.mob Congealed Clot
.mob Corruption Parasite
.mob Silent Slitherer
.mob Tainted Feaster
.mob Dark Walker
step
#arrowtext Kill\n|cRXP_ENEMY_Mul'tha'ul|r
.goto 2575,61.67,59.38,15,0
.goto 2505,52.83,60.29,15,0
.goto 2505,51.92,69.86
.isInScenario 3177
>>Kill |cRXP_ENEMY_Mul'tha'ul|r
.scenario 16082,1 
.mob Mul'tha'ul

step
#label Alnmoth Munchies
.isInScenario 3242
#arrowtext Talk to\n|cRXP_FRIENDLY_Ashayo|r
.goto 2505,51.61,16.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ashayo|r.
.scenario 16413,1 
.skipgossipid 137248
.target Ashayo
step
.isInScenario 3242,Sporasaur Special
#completewith next
.isInScenario 3242
>>Kill |cRXP_ENEMY_Lightblooms|r
.scenario 16414,2,100 
.mob Sapshield Defender
.mob Leafweaver
.mob Thornmaw Briarblaze
.mob Thornblade
.mob Radiant Chloromancer
.mob Grovecrawler Lightleaf
step
.isInScenario 3242
#arrowtext Use\n|T5015304:0|t|cRXP_WARN_[ExtraActionButton]|r
#loop
.goto 2505,50.97,23.28,20,0
.goto 2505,52.3,47.52,30,0
.goto 2505,60.35,43.87,30,0
.goto 2505,63.38,34.05,30,0
.goto 2505,66.08,28.5,30,0
.goto 2505,66.62,40.11,30,0
.goto 2505,68.27,52.62,30,0
.goto 2505,72.64,57.82,30,0
.goto 2505,74.47,72.36,30,0
.goto 2505,69.85,73.22,30,0
.goto 2505,63.53,62.36,30,0
>>Use the |T5015304:0|t|cRXP_WARN_[ExtraActionButton]|r and run through the flower fields.
.scenario 16414,1 















step
#arrowtext Kill\n|cRXP_ENEMY_Lumenia|r
.goto 2575,62.27,59.8,20,0
.goto 2505,52.57,61.1,20,0
.goto 2505,52.67,68.28
.isInScenario 3242
>>Kill |cRXP_ENEMY_Lumenia|r
.scenario 16415,1 
.mob Lumenia

step
#label Sporasaur Special
#arrowtext Talk to\n|cRXP_FRIENDLY_Ashayo|r
.goto 2505,51.56,15.85
.isInScenario 3243
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ashayo|r.
.scenario 16416,1 
.skipgossipid 137389
.target Ashayo
step
#completewith Lightbloom Sporasaur
.isInScenario 3243
>>Kill |cRXP_ENEMY_Lightblooms|r
.scenario 16417,2,100 
.mob Lightcrazed Undergrowth
.mob Leafweaver
.mob Thornmaw Briarblaze
.mob Thornblade
step
#arrowtext Kill\n|cRXP_ENEMY_Lightbloom Sporasaur|r
#loop
.goto 2505,51.2,25.91,15,0
.goto 2505,51.14,39.87,30,0
.goto 2505,55.2,47.34,30,0
.isInScenario 3243
>>Kill |cRXP_ENEMY_Lightbloom Sporasaur|r
*|cRXP_WARN_You can pull them into traps|r
.scenario 16417,1,2 
.mob Lightbloom Sporasaur
step
.isInScenario 3243
#arrowtext Jump on the mushroom
.goto 2505,48.55,42.72,10,0
.goto 2505,46.77,44.29,10 >>Jump on the Mushroom to get up.
step
#label Lightbloom Sporasaur
.isInScenario 3243
#arrowtext Kill\n|cRXP_ENEMY_Lightbloom Sporasaur|r
.goto 2505,40.96,41.25,15,0
.goto 2505,41.93,52.95,30,0
.goto 2575,35.24,59.72,30,0
.goto 2575,40.19,77.74
>>Kill |cRXP_ENEMY_Lightbloom Sporasaur|r
*|cRXP_WARN_You can pull them into traps|r
.scenario 16417,1 
.mob Lightbloom Sporasaur
step
#arrowtext Kill\n|cRXP_ENEMY_Lightblooms|r
#loop
.goto 2575,45.1,69.72,30,0
.goto 2575,39.94,62.55,30,0
.goto 2575,38.84,58.33,30,0
.goto 2575,35.82,50.63,30,0
.isInScenario 3243
>>Kill |cRXP_ENEMY_Lightblooms|r
.scenario 16417,2,100 
.mob Lightcrazed Undergrowth
.mob Leafweaver
.mob Thornmaw Briarblaze
.mob Thornblade
step
#label GulfofMemoryEnd1
#arrowtext Kill\n|cRXP_ENEMY_Lumenia|r
.goto 2505,54.86,76.02
.isInScenario 3243
>>Kill |cRXP_ENEMY_Lumenia|r
.scenario 16418,1 
.mob Lumenia
step

.isOnQuest 93416
>>Finish the delve.
.complete 93416,1 
step
.zoneskip 2505,1
#arrowtext Leave the delve
.goto 2505,50.51,65.11,-1
.goto 2505,56.02,75.17,-1
.goto 2505,51.71,70.49,-1
.zone 2413 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224





]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Grudge Pit
#internal
step
#arrowtext Enter the Grudge Pit
.goto 2413,71.01,65.6
.enterScenario 3097,3098,3099,3297 >>Enter The Grudge Pit Delve in Harandar.
step
#label GrudgeA
.isQuestTurnedIn account,86636
.zoneskip 2510,1
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2510,39.69,43.35
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.accept 93421 >>Accept Delver's Call: The Grudge Pit
.target The Grudge Pit

step
.isInScenario 3097,Arena Champion
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2510,41.66,42.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r.
.scenario 15912,1 
.skipgossipid 134668
.target Boletus
step
#arrowtext Click on\n|cRXP_PICK_Bag|r
.goto 2510,40.61,43.29
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
.isInScenario 3097
.scenario 15913,1 
step
.isInScenario 3097
#hidewindow
#completewith Fan Favorite
#arrowtext Kill |cRXP_ENEMY_Fan Favorites|r\nClick on |cRXP_PICK_Adoring Fans|r
#loop
.goto 2510,52.26,33.41,30,0
.goto 2510,62.92,51.3,30,0
.goto 2510,43.62,63.5,30,0
.goto 2510,37.88,46.39,30,0
.goto 2510,50.46,47.43,15,0
+1
step
#completewith Fan Favorite
.isInScenario 3097
>>Kill |cRXP_ENEMY_Fan Favorites|r
.scenario 15896,1 
.mob Fan Favorite
step
#completewith Fan Favorite
.isInScenario 3097
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Adoring Fans|r
.scenario 15896,2 
.target Adoring Fans
step
#label Fan Favorite
#hidewindow
.isInScenario 3097
.scenario 15896,1 
.scenario 15896,2 
step
.isInScenario 3097
#hidewindow
#completewith Rowdy Fans
#arrowtext Use |T3750314:0|t|cRXP_WARN_[ExtraActionButton]|r\nMove with the Spotlight
#loop
.goto 2510,52.26,33.41,30,0
.goto 2510,62.92,51.3,30,0
.goto 2510,43.62,63.5,30,0
.goto 2510,37.88,46.39,30,0
.goto 2510,50.46,47.43,15,0
+1
step
#completewith Rowdy Fans
.isInScenario 3097
>>Kill |cRXP_ENEMY_Rowdy Fans|r
.scenario 15897,2,100 
.mob Rowdy Fan
.mob Furious Spectator
step
#completewith Rowdy Fans
.isInScenario 3097
>>Step into each spotlight and use the |T3750314:0|t|cRXP_WARN_[ExtraActionButton]|r until the bar reaches 100%.
.scenario 15897,1 
step
#label Rowdy Fans
#hidewindow
.isInScenario 3097
.scenario 15897,1 
.scenario 15897,2,100 




step
.isInScenario 3097
#hidewindow
#completewith next
#arrowtext Kill |cRXP_ENEMY_Competitors|r\nClick on |cRXP_PICK_Dirt Piles|r
#loop
.goto 2510,52.26,33.41,30,0
.goto 2510,62.92,51.3,30,0
.goto 2510,43.62,63.5,30,0
.goto 2510,37.88,46.39,30,0
.goto 2510,50.46,47.43,15,0
+1
step
.isInScenario 3097
#completewith Dig up fresh
>>Kill the |cRXP_ENEMY_Competitors|r.
.scenario 15930,1 
.mob Fan Favorite
.mob Carnivous Lasher
.mob Fungal Gutter
.mob Fungal Stabber
.mob Fungarian Flinger
.mob Fungal Gutter
.mob Fungal Rotspreader
step
#completewith Dig up fresh
.isInScenario 3097
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dirt Piles|r and kill |cRXP_ENEMY_Competitors|r.
.scenario 15930,2 
step
#label Dig up fresh
#hidewindow
.isInScenario 3097
.scenario 15930,1 
.scenario 15930,2 












step
#requires Dig Up Fresh
#arrowtext Click on\n|cRXP_PICK_Boletus|r
.goto 2510,51.38,50.09
.isInScenario 3097
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Boletus|r
.scenario 15942,1 
.target Boletus
step
#arrowtext Kill\n|cRXP_ENEMY_Mycomight|r
.goto 2510,51.69,48.87
.isInScenario 3097
>>Kill |cRXP_ENEMY_Mycomight|r
.scenario 15898,1 
.mob Mycomight

step
#label Arena Champion
.goto 2510,42.56,42.84
.isInScenario 3098
#title |cFFFCDC00Follow the Arrow|r
.scenario 15910,1 
step
.isInScenario 3098,Lightbloom Invasion
#arrowtext Click on\n|cRXP_PICK_Objects|r
#loop
.goto 2510,51.87,32.56,30,0
.goto 2510,63.83,44.57,30,0
.goto 2510,54.35,62.76,30,0
.goto 2510,39.46,57.2,30,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Objects|r
*Kill |cRXP_ENEMY_Mushrooms|r
.scenario 15899,1
.timer 10,RP
.mob Infected Beast
.mob Fungal Rotcaster
.mob Fungal Stabber
.mob Carnivorous Lasher
step
.isInScenario 3098
#hidewindow
#completewith next
#arrowtext Kill |cRXP_ENEMY_Moldrus|r and |cRXP_ENEMY_Bogdamp|r\nClick on |cRXP_PICK_Mushrooms|r
#loop
.goto 2510,51.87,32.56,30,0
.goto 2510,63.83,44.57,30,0
.goto 2510,54.35,62.76,30,0
.goto 2510,39.46,57.2,30,0
.goto 2510,50.99,49.01,30,0
+1
step
.isInScenario 3098
#hidewindow
#label MoldrusBogdampDeathcap
.scenario 15900,1 
.scenario 15900,2 
.scenario 15900,3 
step
#completewith MoldrusBogdampDeathcap
.isInScenario 3098
>>Kill |cRXP_ENEMY_Moldrus|r and |cRXP_ENEMY_Bogdamp|r
.scenario 15900,2 
.scenario 15900,1 
.mob Moldrus
.mob Bogdamp
step
#completewith MoldrusBogdampDeathcap
#arrowtext Click on\n|cRXP_PICK_Mushrooms|r
.goto 2510,43.82,57.90
.isInScenario 3098
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mushrooms|r
.scenario 15900,3 
step
#requires MoldrusBogdampDeathcap
#arrowtext Kill |cRXP_ENEMY_Moldering Fighters|r\nClick on their |cRXP_PICK_remains|r
#loop
.goto 2510,51.87,32.56,30,0
.goto 2510,63.83,44.57,30,0
.goto 2510,54.35,62.76,30,0
.goto 2510,39.46,57.2,30,0
.goto 2510,50.99,49.01,30,0
.isInScenario 3098
>>Kill |cRXP_ENEMY_Moldering Fighter|r and click on their |cRXP_PICK_remains|r
.scenario 15928,1 
.mob Moldering Fighter
step
#arrowtext Click on\n|cRXP_PICK_Banner|r
.goto 2510,51.34,49.79
.isInScenario 3098
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Banner|r
.scenario 15949,1 
.timer 10,RP
step
#arrowtext Kill\n|cRXP_ENEMY_Gyrospore|r
.goto 2510,53.94,51.86
.isInScenario 3098
>>Kill |cRXP_ENEMY_Gyrospore|r
.scenario 15902,1 
.mob Gyrospore

step
#label Lightbloom Invasion
#arrowtext Use the |cRXP_PICK_Mushrooms|r\nto jump up
#loop
.goto 2510,35.08,57.23,8,0
.goto 2510,31.60,53.22,10,0
.goto 2510,43.96,59.92,10,0
.goto 2510,59.55,56.16,10,0
.goto 2510,51.66,38.49,10,0
.goto 2510,48.85,23.10,10,0
.goto 2510,42.67,21.40,10,0
.goto 2510,59.38,21.81,10,0
.goto 2510,60.96,41.47,10,0
.isInScenario 3099
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Entangled Fighters|r
*Kill the |cRXP_ENEMY_Lightbloom forces|r.
.scenario 15943,1 
.scenario 15943,2 
.mob Thornblade
.mob Thornmaw Briarblaze
.mob Leafweaver
.mob Radiant Chloromancer
.mob Lightcrazed Undergrowth
step
.isInScenario 3099
#arrowtext Kill\n|cRXP_ENEMY_Lightbloom forces|r
.goto 2510,51.52,49.50
>>Kill the |cRXP_ENEMY_Lightbloom forces|r.
.scenario 15944,1 
.mob Thornblade
.mob Grovecrawler Lightleaf
.mob Lightcrazed Undergrowth
step
#arrowtext Use the |cRXP_PICK_Mushrooms|r\nto jump up
#loop
.goto 2510,45.54,21.98,10,0
.goto 2510,62.69,51.90,10,0
.goto 2510,34.49,59.63,10,0
.isInScenario 3099
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bombs|r.
.scenario 15946,1 
step
#arrowtext Kill\n|cRXP_ENEMY_Brightthorn|r
.goto 2510,48.91,41.39
.isInScenario 3099
>>Kill |cRXP_ENEMY_Brightthorn|r.
.scenario 15947,1 
.mob Brightthorn

step
#label FungalPharmaconA
.isInScenario 3297
#arrowtext Talk to Flustered Fungarian
.goto 2510,41.20,41.50
.scenario 16605,1 
.goto 2510,52.55,36.52,35,0
.skipgossipid 138234
step
#completewith RitualPillarsCleansedZ
#label RitualPillarsCleansedA
#hidewindow
.isInScenario 3297
.scenario 16606,2 
step
#completewith FungalPharmaconZ
.isInScenario 3297
+|cRXP_WARN_NOTE:|r If you don't strictly follow the arrow in this delve then it will be wrong.
*But the idea is relatively simple:
*- Go down into the burrows
*- Find Fungal Pharmacon to get the ExtraActionButton
*- Use the ExtraActionButton to destroy the |cRXP_PICK_Ritual Pillars|r
step

#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedAA
#arrowtext Click on |cRXP_PICK_Burrow|r
.isInScenario 3297
.goto 2510,52.37,36.73
.cast 1279939,1277927,1277930,1279032,1279033,1279036,1279037,1279038,1279039,1279940,1279941,1280138,1280139,1297301,1297303,1297734 >>Click on a |cRXP_PICK_Burrow|r.
step
#requires RitualPillarsCleansedAA
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedAB
#arrowtext Click on |cRXP_WARN_ALL|r\n|cRXP_PICK_Fungal Pharmacon|r\nWait if none is there
.isInScenario 3297
.goto 2510,64.84,0.09
.cast 1279438 >>Click on all |cRXP_PICK_Fungal Pharmacon|r.
step
#requires RitualPillarsCleansedAB
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedB
.isInScenario 3297
#arrowtext Use\n[ExtraActionButton]
.goto 2510,43.96,56.66,20,0
.goto 2510,71.58,53.43
>>Use the [ExtraActionButton].
.scenario 16606,2,1 
step
#requires RitualPillarsCleansedB
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedBA
#arrowtext Click on |cRXP_WARN_ALL|r\n|cRXP_PICK_Fungal Pharmacon|r
.isInScenario 3297
.goto 2510,64.84,0.09
.cast 1279438 >>Click on all |cRXP_PICK_Fungal Pharmacon|r.
.aura 1279438
step

#requires RitualPillarsCleansedBA
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedBB
.isInScenario 3297
#arrowtext Click on\n|cRXP_PICK_Burrow|r
.goto 2510,29.84,51.86
.cast 1279939,1277927,1277930,1279032,1279033,1279036,1279037,1279038,1279039,1279940,1279941,1280138,1280139,1297301,1297303,1297734 >>Click on a |cRXP_PICK_Burrow|r.
step
#requires RitualPillarsCleansedBB
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedBC
.isInScenario 3297
#arrowtext Use\n[ExtraActionButton]
.goto 2510,52.29,50.86
>>Use the [ExtraActionButton].
.scenario 16606,2,2 
step

#requires RitualPillarsCleansedBC
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedBD
#arrowtext Click on |cRXP_PICK_Burrow|r
.isInScenario 3297
.goto 2510,62.73,50.35
.cast 1279939,1277927,1277930,1279032,1279033,1279036,1279037,1279038,1279039,1279940,1279941,1280138,1280139,1297301,1297303,1297734 >>Click on a |cRXP_PICK_Burrow|r.
step
#requires RitualPillarsCleansedBD
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedD
.isInScenario 3297
#arrowtext Use\n[ExtraActionButton]
.goto 2510,53.73,42.65
>>Use the [ExtraActionButton].
.scenario 16606,2,3 
step
#requires RitualPillarsCleansedD
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedDDA
#arrowtext Click on \n|cRXP_PICK_Fungal Pharmacon|r
.isInScenario 3297
.goto 2510,64.05,47.06
.cast 1279438 >>Click on all |cRXP_PICK_Fungal Pharmacon|r.
.aura 1279438
step

#requires RitualPillarsCleansedDDA
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedDA
.isInScenario 3297
#arrowtext Click on\n|cRXP_PICK_Burrow|r
.goto 2510,53.95,67.21
.cast 1279939,1277927,1277930,1279032,1279033,1279036,1279037,1279038,1279039,1279940,1279941,1280138,1280139,1297301,1297303,1297734 >>Click on a |cRXP_PICK_Burrow|r.
step

#requires RitualPillarsCleansedDA
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedDB
.isInScenario 3297
#arrowtext Click on\n|cRXP_PICK_Burrow|r
.goto 2510,48.85,23.10,6,0
.goto 2510,48.85,22.81,10,0
.goto 2510,58.50,21.81
.cast 1279939,1277927,1277930,1279032,1279033,1279036,1279037,1279038,1279039,1279940,1279941,1280138,1280139,1297301,1297303,1297734 >>Click on a |cRXP_PICK_Burrow|r.
step
#requires RitualPillarsCleansedDB
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedC
.isInScenario 3297
#arrowtext Use\n[ExtraActionButton]
.goto 2510,73.89,30.57
>>Use the [ExtraActionButton].
.scenario 16606,2 
step
#requires RitualPillarsCleansedC
#completewith RitualPillarsCleansedA
#label RitualPillarsCleansedCA
.isInScenario 3297
#arrowtext Click on\n|cRXP_PICK_Fungal Pharmacon|r
.goto 2510,74.86,14.78
.cast 1279438 >>Click on |cRXP_PICK_Fungal Pharmacon|r.
step
#requires RitualPillarsCleansedCA
#completewith next
#label RitualPillarsCleansedCB
#hidewindow
.isInScenario 3297
.scenario 17153,1 
step

#requires RitualPillarsCleansedCA
#completewith RitualPillarsCleansedCB
#label RitualPillarsCleansedCB
.isInScenario 3297
#arrowtext Click on\n|cRXP_PICK_Burrow|r
.goto 2510,53.62,41.65
.cast 1279939,1277927,1277930,1279032,1279033,1279036,1279037,1279038,1279039,1279940,1279941,1280138,1280139,1297301,1297303,1297734 >>Click on a |cRXP_PICK_Burrow|r.
step
#requires RitualPillarsCleansedCB
#completewith UlatekdBurrowSnakesA
#label UlatekSummonersKickedB
.isInScenario 3297
#arrowtext Enter |cRXP_PICK_Burrows|r\nKill |cRXP_ENEMY_Ula'tek Snakes|r
.goto 2510,42.50,58.68
>>Go down into one of the remaining |cRXP_PICK_Burrows|r. Kill the |cRXP_ENEMY_Ula'tek Snakes|r.
.scenario 16606,3,100 
step
#requires UlatekSummonersKickedB
#label FungalPharmaconZ
#arrowtext Kill\n|cRXP_ENEMY_Replicating Venomborne|r
.goto 2510,51.15,49.31
.isInScenario 3297
>>Kill the |cRXP_ENEMY_Replicating Venomborne|r.
.scenario 16607,1 
.mob Replicating Venomborne
step
#label GrudgeB
.zoneskip 2510,1
#arrowtext Leave the delve
.goto 2510,61.27,51.07,-1
.zone 2413 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224
step
#label GrudgeZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Boletus|r
.goto 2413,71.79,64.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boletus|r.
.turnin 93421 >>Turn in Delver's Call: The Grudge Pit
.target Boletus
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Parhelion Plaza
#internal
step
#arrowtext Enter Parhelion Plaza
.goto 2424,47.74,41.54,10,0
.goto 2424,46.54,40.45
.enterScenario 3074,3100,3075,3298 >>Enter the Parhelion Plaza Delve on the Isle of Quel'danas inside the tower.
step
#label ParhelionPlazaA
.isQuestTurnedIn account,86636
.zoneskip 2545,1
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2545,74.49,27.84
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.accept 93386 >>Accept Delver's Call: Parhelion Plaza
.target Parhelion Plaza

step
.isInScenario 3074,March of the Arcane Brigade
#arrowtext Talk to\n|cRXP_FRIENDLY_Vindicator Xayann|r
.goto 2545,71.85,27.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Xayann|r.
.scenario 15844,1 
.skipgossipid 136446
.target Vindicator Xayann
step
#arrowtext Click on\n|cRXP_PICK_Blades|r
.goto 2545,70.89,28.17
.isInScenario 3074
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Blades|r
.scenario 15879,3 
step
.isInScenario 3074
#hidewindow
#completewith Voidbeings
#arrowtext Kill |cRXP_ENEMY_Voidbeings|r\nHeal |cRXP_FRIENDLY_Injured Soldiers|r\nClick on |cRXP_PICK_Barricades|r
#loop
.goto 2545,70.13,37.43,10,0
.goto 2545,62.83,18.29,10,0
.goto 2545,56.52,33.91,10,0
.goto 2545,59.42,39.01,10,0
.goto 2545,58.01,64.68,10,0
.goto 2545,43.48,73.64,10,0
.goto 2545,65.03,75.74,10,0
.goto 2545,66.96,52.61,10,0
.goto 2545,66.3,47.59,10,0
.goto 2545,82,50.32,25,0
.goto 2545,47.67,49.38,25,0
+1
step
#completewith next
.isInScenario 3074
>>Kill |cRXP_ENEMY_Voidbeings|r and heal |cRXP_FRIENDLY_Injured Soldiers|r
*Use the |T135682:0|t|cRXP_WARN_[ExtraActionButton]|r for extra damage.
.scenario 15879,1,100 
.target Injured Soldiers
step
.isInScenario 3074
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barricades|r
.scenario 15879,2 
step
#label Voidbeings
.isInScenario 3074
>>Kill |cRXP_ENEMY_Voidbeings|r and heal |cRXP_FRIENDLY_Injured Soldiers|r
*Use the |T135682:0|t|cRXP_WARN_[ExtraActionButton]|r for extra damage.
.scenario 15879,1,100 
.target Injured Soldiers
step
#arrowtext Kill\n|cRXP_ENEMY_Gladius Slaurna|r
.goto 2545,47.67,49.38
.isInScenario 3074
>>Kill |cRXP_ENEMY_Gladius Slaurna|r
.scenario 15847,1 
.mob Gladius Slaurna

step
#label March of the Arcane Brigade
.isInScenario 3075
#arrowtext Talk to\n|cRXP_FRIENDLY_Grand Artificer Romuul|r
.goto 2545,72.12,27.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Artificer Romuul|r.
.scenario 15848,1 
.skipgossipid 136477
.target Grand Artificer Romuul
step
#completewith Quel'Danas Sentinels
.isInScenario 3075,Bombing Run
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 15850,1,100 
step
#completewith Quel'Danas Sentinels
.isInScenario 3075
>>Let |cRXP_FRIENDLY_Quel'Danas Sentinels|r destroy Pylons
.scenario 15850,2
step
#label Quel'Danas Sentinels
#arrowtext Click on\n|cRXP_PICK_Quel'Danas Sentinels|r
#loop
.goto 2545,67.88,27.31,30,0
.goto 2545,62.91,20.08,30,0
.goto 2545,72.18,36.68,30,0
.goto 2545,72.6,62.54,30,0
.goto 2545,67.64,63.01,30,0
.goto 2545,63.25,75.22,30,0
.goto 2545,61.21,83.26,30,0
.goto 2545,44.46,82.88,30,0
.goto 2545,23.47,77.63,30,0
.goto 2545,17.96,69.96,30,0
.goto 2545,20.3,54.95,30,0
.goto 2545,16.78,43.49,30,0
.goto 2545,24.49,24.29,30,0
.goto 2545,31.07,27.99,30,0
.goto 2545,27.67,35.78,30,0
.goto 2545,27.75,49.38,30,0
.isInScenario 3075
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Quel'Danas Sentinels|r they'll attack the Pylons.
*|cRXP_WARN_Make sure the sentinels attack the pylons, not monsters|r.
.scenario 15850,3 
.mob Quel'Danas Sentinel
step
#completewith next
.isInScenario 3075
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 15850,1,100 
.mob Voidspawn
.mob Scouring Siphoid
.mob Voidlord Shadowshield
step
#arrowtext Let the Sentinels destroy pylons
#loop
.goto 2545,18.26,41.38,30,0
.goto 2545,18.98,60.44,30,0
.goto 2545,22.57,71.4,30,0
.goto 2545,30.58,78.34,30,0
.goto 2545,20.56,67.91,30,0
.goto 2545,18.98,55.48,30,0
.goto 2545,23.46,51.29,30,0
.goto 2545,47.83,52.24
.isInScenario 3075
>>Let |cRXP_FRIENDLY_Quel'Danas Sentinels|r destroy Pylons.
.scenario 15850,2
step
#arrowtext Kill\n|cRXP_ENEMY_Gladius Slaurna|r
.goto 2545,47.83,52.24
.isInScenario 3075
>>Kill |cRXP_ENEMY_Gladius Slaurna|r
.scenario 15851,1 
.mob Gladius Slaurna

step
#label Bombing Run
.isInScenario 3100
#arrowtext Talk to\n|cRXP_FRIENDLY_Grand Artificer Romuul|r
.goto 2545,72.24,27.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Artificer Romuul|r.
.scenario 15906,1 
.skipgossipid 134669
.target Grand Artificer Romuul
step
#arrowtext Click on\n|cRXP_PICK_Arcane Device|r
.goto 2545,71.23,24.39
.isInScenario 3100
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Device|r
.scenario 16808,1 
step
#arrowtext Click on\n|cRXP_PICK_Portal|r
.goto 2545,70.28,17.32
.isInScenario 3100
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.scenario 15907,1 
step
#arrowtext Use\n|T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r
.goto 2545,53.86,48.81
.isInScenario 3100
>>Use the |T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r, aim it at the stone and wait for the explosion near the exit portal.
.scenario 15907,2 
step
#arrowtext Click on\n|cRXP_PICK_Portal|r
.goto 2545,47.79,50.18
.isInScenario 3100
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
.scenario 15948,1 
step
#completewith next
#label Northwest Portal
#arrowtext Click on\n|cRXP_PICK_Arcane Device|r
.goto 2545,32.24,15.91,25,0
.isInScenario 3100
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Device|r
*|cRXP_WARN_Active Combat drops the device & it's on 50 seconds timer|r
.scenario 15908,4 
step
.isInScenario 3100
#completewith Northwest Portal
#arrowtext Click on\n|cRXP_PICK_Portal|r
.goto 2545,26.52,17.07
.cast 1245873 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
step
#requires Northwest Portal
.isInScenario 3100
#arrowtext Use\n|T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r
.goto 2545,41.68,54.84
>>Use the |T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r, aim it at the stone and wait for the explosion near the exit portal.
*|cRXP_WARN_Active Combat drops the device & it's on 50 seconds timer. Pick up a new one if you lose it.|r
.scenario 15908,4 
.mob Portal Stone
step
#completewith next
#label Southwest Portal
#arrowtext Click on\n|cRXP_PICK_Arcane Device|r
.goto 2545,16.9,48.84,30,0
.goto 2545,22.29,71.38,30,0
.goto 2545,31.86,75.73,30,0
.isInScenario 3100
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Device|r
*|cRXP_WARN_Active Combat drops the device & it's on 50 seconds timer. Pick up a new one if you lose it.|r
.scenario 15908,3 
step
.isInScenario 3100
#completewith Southwest Portal
#arrowtext Click on\n|cRXP_PICK_Portal|r
.goto 2545,26.38,83.43
.cast 1245882 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
step
#requires Southwest Portal
.isInScenario 3100
#arrowtext Use\n|T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r
.goto 2545,39.45,50.69
>>Use the |T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r, aim it at the stone and wait for the explosion near the exit portal.
*|cRXP_WARN_Active Combat drops the device & it's on 50 seconds timer. Pick up a new one if you lose it.|r
.scenario 15908,3 
.mob Portal Stone
step
#completewith next
#label Southeast Portal
.isInScenario 3100
#arrowtext Click on\n|cRXP_PICK_Arcane Device|r
.goto 2545,64.61,79.93,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Device|r
*|cRXP_WARN_Active Combat drops the device & it's on 50 seconds timer. Pick up a new one if you lose it.|r
.scenario 15908,2 
step
.isInScenario 3100
#completewith Southeast Portal
#arrowtext Click on\n|cRXP_PICK_Portal|r
.goto 2545,70.03,83.81
.cast 1245845 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r
step
#requires Southeast Portal
.isInScenario 3100
#arrowtext Use\n|T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r
.goto 2545,39.45,50.69
>>Use the |T2115307:0|t|cRXP_WARN_[ExtraActionButton]|r, aim it at the stone and wait for the explosion near the exit portal.
*|cRXP_WARN_Active Combat drops the device & it's on 50 seconds timer. Pick up a new one if you lose it.|r
.scenario 15908,2 
.mob Portal Stone
step
#arrowtext Kill\n|cRXP_ENEMY_Gladius Slaurna|r
.goto 2545,47.10,53.80
.isInScenario 3100
>>Kill |cRXP_ENEMY_Gladius Slaurna|r
.scenario 15909,1 
.mob Gladius Slaurna

step

.isOnQuest 93386
>>Finish the delve.
.complete 93386,1 
step
#label ParhelionPlazaB
.zoneskip 2545,1
#arrowtext Leave the delve
.goto 2545,51.38,45.52,-1
.goto 2545,51.12,45.18,-1
.zone 2424 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224
step
#label ParhelionPlazaZ
#arrowtext Talk to\n|cRXP_FRIENDLY_Naleidea Rivergleam|r
.goto 2393,52.78,77.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naleidea Rivergleam|r.
.turnin 93386 >>Turn in Delver's Call: Parhelion Plaza
.target Naleidea Rivergleam
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Sunkiller Sanctum
#internal
step
#arrowtext Enter Sunkiller Sanctum
.goto 2405,54.87,46.7,10,0
.goto 2405,54.79,47.26
.enterScenario 3194,3201,3204 >>Enter the Sunkiller Sanctum Delve in Voidstorm.

step
#label SanctumA
.isQuestTurnedIn account,86636
.zoneskip 2528,1
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2528,63.39,34.88
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r
.accept 93427 >>Accept Delver's Call: Sunkiller Sanctum
.target Sunkiller Sanctum
step
.isInScenario 3194,The Gravitaional Effect
#arrowtext Talk to\n|cRXP_FRIENDLY_Null-Theorist Selune|r
.goto 2528,64.37,39.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Null-Theorist Selune|r.
.scenario 16129,1 
.skipgossipid 136086
.target Null-Theorist Selune
step
#completewith Console
.isInScenario 3194
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 16130,1,100 
step
#completewith Console
.isInScenario 3194
>>Run through the glowing objects on the ground.
*|cRXP_WARN_Continue even when done for a buff|r.
.scenario 16130,4 
step
#label Console
#arrowtext Click on\n|cRXP_PICK_Console|r
.goto 2528,61.82,45.28,20,0
.goto 2528,58.51,47.62,20,0
.goto 2528,52.37,43.75,20,0
.goto 2528,49.78,47.53,20,0
.goto 2528,49.92,42.19,10,0
.goto 2528,44.58,33.08
.isInScenario 3194
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r
.scenario 16130,3 
step
.isInScenario 3194
#hidewindow
#completewith Energized Cores
#arrowtext Kill |cRXP_ENEMY_Voidbeings|r\nCollect Energized Cores
#loop
.goto 2528,42.04,35.73,20,0
.goto 2528,42.34,28.67,20,0
.goto 2571,44.66,16.97,15,0
.goto 2571,44.12,12.06,15,0
.goto 2571,47.28,11.05,15,0
.goto 2571,51.9,18.9,15,0
.goto 2571,57.51,16.8,15,0
.goto 2571,56.13,22.74,20,0
.goto 2571,55.02,34.09,20,0
.goto 2571,55.27,51.64,20,0
.goto 2571,48.38,56.91,20,0
.goto 2571,49.94,63.79,20,0
.goto 2571,55.54,61.16,20,0
.goto 2571,54.61,73.39,25,0
.goto 2571,63.6,72.25,25,0
.goto 2571,61.12,65.46,25,0
+1
step
#completewith next
.isInScenario 3194
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 16130,1,100 
step
.isInScenario 3194
>>Run through the glowing objects on the ground.
*|cRXP_WARN_Continue even when done for a buff|r.
.scenario 16130,4 
step
#label Energized Cores
.isInScenario 3194
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 16130,1,100 
step
#arrowtext Kill\n|cRXP_ENEMY_Esuritus|r
.goto 2571,58.86,67.22
.isInScenario 3194
>>Kill |cRXP_ENEMY_Esuritus|r
.scenario 16131,1 
.mob Esuritus

step
#label The Gravitaional Effect
.isInScenario 3201
#arrowtext Talk to\n|cRXP_FRIENDLY_Riftblade Maella|r
.goto 2528,63.18,39.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Riftblade Maella|r.
.scenario 16146,1 
.skipgossipid 136275
.target Riftblade Maella
step
#completewith Singularity Coils
.isInScenario 3201
+Kill all |cRXP_ENEMY_Voidbeings|r you encounter.
*|cRXP_WARN_You'll get progress for them now even if it doesn't say so|r
.mob Voidcaller Obliviator
.mob Voidwalker Render
.mob Voidspawn
step
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2528,62.04,50.24,30,0
.goto 2528,61.14,58.21
.isInScenario 3201,Not What I Expected
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r in the sky.
.scenario 16409,2 
step
#arrowtext Click on\n|cRXP_PICK_Singularity Coil|r
.goto 2528,61.76,59.69
.isInScenario 3201
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Singularity Coil|r
.scenario 16409,1,1 
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2528,58.58,73.88
.cast 1263403 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r |cRXP_WARN_infront of you|r
step
#arrowtext Click on\n|cRXP_PICK_Singularity Coil|r
.goto 2528,58.58,73.88
.isInScenario 3201
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Singularity Coil|r
.scenario 16409,1,2 
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2528,51.76,64.39
.cast 1263403 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r
step
#arrowtext Click on\n|cRXP_PICK_Singularity Coil|r
.goto 2528,50.45,65.01
.isInScenario 3201
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Singularity Coil|r
.scenario 16409,1,3 
step
#arrowtext Click on\n|cRXP_PICK_Singularity Coil|r
.goto 2571,52.02,60.74
.isInScenario 3201
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Singularity Coil|r |cRXP_WARN_below you|r.
.scenario 16409,1,4 
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2571,61.4,54.68
.cast 1263403 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r |cRXP_WARN_below|r
step
#label Singularity Coils
#arrowtext Click on\n|cRXP_PICK_Singularity Coil|r
.goto 2571,63.36,54.56
.isInScenario 3201
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Singularity Coil|r
.scenario 16409,1,5 
step
#completewith Stabilizers2
.isInScenario 3201
>>Kill all |cRXP_ENEMY_Voidbeings|r you encounter.
.scenario 16147,1,100 
.mob Voidcaller Obliviator
.mob Voidwalker Render
.mob Voidspawn
.mob Controlled Slaughterclaw
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2528,62.17,66.98
.cast 1263403 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r |cRXP_WARN_above|r
step
#arrowtext Click on\n|cRXP_PICK_Stabilizer|r
.goto 2571,63.44,63.89
.isInScenario 3201
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stabilizer|r
.scenario 16147,2,1 
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2528,62.38,51.51
.cast 1263403 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r |cRXP_WARN_above|r
step
#arrowtext Click on\n|cRXP_PICK_Stabilizer|r
.goto 2528,64.24,51.14
.isInScenario 3201
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stabilizer|r
.scenario 16147,2,2 
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2528,51.3,47.85
.cast 1263403 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Stabilizer|r
.goto 2528,51.3,47.85
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stabilizer|r
.scenario 16147,2,3 
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Micro Singularity|r
.goto 2528,51.18,54.7
.cast 1263403 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Micro Singularity|r
step
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Stabilizer|r
.goto 2571,42.56,48.92
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stabilizer|r
.scenario 16147,2,4 
step
#label Stabilizers2
.isInScenario 3201
#arrowtext Click on\n|cRXP_PICK_Stabilizer|r
.goto 2571,47.97,66.56
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Stabilizer|r
.scenario 16147,2,5 
step
#arrowtext Kill\n|cRXP_ENEMY_Voidbeings|r
#loop
.goto 2571,55.66,71.55,30,0
.goto 2571,64.35,72.76,30,0
.goto 2571,63.84,65.72,30,0
.isInScenario 3201
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 16147,1,100 
.mob Voidcaller Obliviator
.mob Voidwalker Render
.mob Voidspawn
.mob Controlled Slaughterclaw
step
#arrowtext Kill\n|cRXP_ENEMY_Esuritus|r
.goto 2571,59.64,67.86
.isInScenario 3201
>>Kill |cRXP_ENEMY_Esuritus|r
.scenario 16148,1 
.mob Esuritus

step
#label Not What I Expected
.isInScenario 3204
#arrowtext Talk to\n|cRXP_FRIENDLY_Darkmender Deremius Duskwalk|r
.goto 2571,63.86,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darkmender Deremius Duskwalk|r.
.scenario 16153,1 
.target Darkmender Deremius Duskwalk
.skipgossipid 136279
step
.isInScenario 3204
#completewith LightbloomCratesSealedA
>>Kill the |cRXP_ENEMY_Light and Void threats|r.
.scenario 16154,1,100 
.mob Leafweaver
.mob Lightcrazed Undergrowth
.mob Thornmaw Briarblaze
.mob Voidlord Shadowshield
.mob Voidcaller Manipulator
.mob Scouring Siphoid
step
#arrowtext Crates sealed (2/7)\n|cFFFCDC00(Read Note)|r
.goto 2571,63.58,50.76
.isInScenario 3204
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16154,2,2 
step
#arrowtext Crates sealed (3/7)\n|cFFFCDC00(Read Note)|r
.goto 2571,49.61,46.59
.isInScenario 3204
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16154,2,3 
step
#arrowtext Click on\n|cRXP_PICK_Console|r
.goto 2528,44.18,32.80
.isInScenario 3204
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Console|r.
.scenario 16154,3 
step
#arrowtext Crates sealed (4/7)\n|cFFFCDC00(Read Note)|r
.goto 2528,44.16,15.15
.isInScenario 3204
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16154,2,4 
step
#arrowtext Crates sealed (5/7)\n|cFFFCDC00(Read Note)|r
.goto 2571,47.28,12.34,10,0
.goto 2571,51.50,19.11
.isInScenario 3204
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16154,2,5 
step
#arrowtext Crates sealed (6/7)\n|cFFFCDC00(Read Note)|r
.goto 2571,58.05,19.19
.isInScenario 3204
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16154,2,6 
step
#label LightbloomCratesSealedA
#arrowtext Crates sealed (7/7)\n|cFFFCDC00(Read Note)|r
.goto 2571,52.73,35.55
.isInScenario 3204
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Crate|r.
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16154,2 
step
.isInScenario 3204
#arrowtext Kill\n|cRXP_ENEMY_Light and Void threats|r
#loop
.goto 2571,54.98,51.26,15,0
.goto 2571,46.57,59.89,15,0
.goto 2571,63.53,75.15,15,0
>>Kill |cRXP_ENEMY_Light and Void threats|r.
.scenario 16154,1,100 
.mob Leafweaver
.mob Lightcrazed Undergrowth
.mob Thornmaw Briarblaze
.mob Voidlord Shadowshield
.mob Voidcaller Manipulator
.mob Scouring Siphoid
.mob Voidspawn
step
#arrowtext Kill\n|cRXP_ENEMY_Corrupted Umbraroots|r
#loop
.goto 2571,60.67,84.40,35,0
.goto 2571,53.26,60.84,35,0
.isInScenario 3204
>>Kill |cRXP_ENEMY_Corrupted Umbraroots|r.
.scenario 16155,1 
.mob Corrupted Umbraroots
step

.isOnQuest 93427
>>Finish the delve.
.complete 93427,1 
step
#label SanctumB
.zoneskip 2571,1
#arrowtext Leave the delve
.goto 2571,57.78,81.99,-1 
.goto 2571,57.87,81.65,-1 
.goto 2571,56.23,90.48,-1
.zone 2405 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224





]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Shadowguard Point
#internal
step
#arrowtext Enter Shadowguard Point
.goto 2405,37.18,49.15,10,0
.goto 2405,37.39,47.75
.enterScenario 3126,3150,3149 >>Enter the Shadowguard Point Delve in Voidstorm.
step
#label ShadowguardPointA
.isQuestTurnedIn account,86636
.zoneskip 2506,1
#arrowtext Click on\n|cRXP_PICK_Scroll|r
.goto 2506,47.58,79.22
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
.accept 93428 >>Accept Delver's Call: Shadowguard Point
.target Shadowguard Point

step
.isInScenario 3126,Calamitous
#arrowtext Talk to\n|cRXP_FRIENDLY_Lysikas|r
.goto 2506,48.11,78.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lysikas|r.
.scenario 15987,1 
.skipgossipid 134949
.target Lysikas
step
#arrowtext Click on\n|cRXP_PICK_Rifle|r
.goto 2506,48.11,78.09
.isInScenario 3126
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Rifle|r
.scenario 15975,1 
step
.isInScenario 3126
#hidewindow
#completewith Mana Containers
#arrowtext Destroy Mana Containers\nClick on |cRXP_PICK_Mana Siphons|r
#loop
.goto 2506,49.56,69.9,15,0
.goto 2506,49.68,66.65,15,0
.goto 2506,44.47,66.85,15,0
.goto 2506,44.78,53.54,15,0
.goto 2506,42.41,51.18,15,0
.goto 2506,38.52,47.13,15,0
.goto 2506,38.6,45.13,15,0
.goto 2506,38.06,41.44,15,0
.goto 2506,36.09,39.04,15,0
.goto 2506,38.17,35.11,15,0
.goto 2506,40.66,34.27,15,0
.goto 2506,44.21,36.04,15,0
.goto 2506,45.33,39.83,15,0
.goto 2506,44.15,43.33,15,0
.goto 2506,47.32,43.66,30,0
.goto 2506,52.82,44.06,30,0
.goto 2506,59.12,36.41,30,0
.goto 2506,58.72,30.77,30,0
.goto 2506,55.84,33.46,30,0
+1
step
#completewith next
.isInScenario 3126
>>Use the |T236392:0|t|cRXP_WARN_[ExtraActionButton]|r to destroy Mana Containers.
.scenario 15976,2,100 
step
.isInScenario 3126
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Mana Siphon|r.
.scenario 15976,1 
step
#label Mana Containers
.isInScenario 3126
>>Use the |T236392:0|t|cRXP_WARN_[ExtraActionButton]|r to destroy Mana Containers.
.scenario 15976,2,100 
step
.isInScenario 3126
#arrowtext Click on\n|cRXP_PICK_Barrier|r
.goto 2506,47.54,27.82
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Barrier|r
.scenario 15985,1 
step
#arrowtext Kill\n|cRXP_ENEMY_Chief-Arcanist Patram|r
.goto 2506,46.12,14.63
.isInScenario 3126
>>Kill |cRXP_ENEMY_Chief-Arcanist Patram|r
.scenario 15986,1 
.mob Chief-Arcanist Patram

step
#label Calamitous
#arrowtext Kill\n|cRXP_ENEMY_Guard Captain Meti|r
.goto 2506,48.59,73.59
.isInScenario 3150
>>Kill |cRXP_ENEMY_Guard Captain Meti|r
.scenario 16075,1 
.mob Guard Captain Meti
step
.isInScenario 3150
#arrowtext Click on\n|cRXP_PICK_Arcane Charge|r
.goto 2506,50.24,71.25
.cast 1249971 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Charge|r
step
#arrowtext Run into the circle
.goto 2506,48.73,72.7
.isInScenario 3150,Captured Wildlife
>>Run into the circle
.scenario 16016,1 
step
#arrowtext Click on\n|cRXP_PICK_Waygate|r
.goto 2506,48.80,72.59
.isInScenario 3150
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Waygate|r
.scenario 16017,1 
step
#completewith Overlord
.isInScenario 3150
>>Kill |cRXP_ENEMY_Voidbeings|r
.scenario 16073,2,100
.mob Prowling Voidstalker
.mob Shadeye Observer
.mob Arcane Fragment
.mob Shadowguard Steelsoul
.mob Shadowguard Void Adept
.mob Shadowguard Phasecutter
step
.isInScenario 3150
#arrowtext Click on\n|cRXP_PICK_Arcane Charge|r
.goto 2506,38.84,47.43
.cast 1249971 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Charge|r
step
.isInScenario 3150
#arrowtext Run into the circle
.goto 2506,37.9,40.84
>>Run into the circle.
.scenario 16073,1,1 
step
.isInScenario 3150
#arrowtext Click on\n|cRXP_PICK_Arcane Charge|r
.goto 2506,44.15,44.47
.cast 1249971 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Charge|r
step
.isInScenario 3150
#arrowtext Run into the circle
.goto 2506,46.97,43.75,25,0
>>Run into the circle.
.scenario 16073,1,2 
step
.isInScenario 3150
#arrowtext Click on\n|cRXP_PICK_Arcane Charge|r
.goto 2506,52.28,43.84
.cast 1249971 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Charge|r
step
.isInScenario 3150
#arrowtext Run into the circle
.goto 2506,55.03,48.28
>>Run into the circle.
.scenario 16073,1,3 
step
.isInScenario 3150
#arrowtext Click on\n|cRXP_PICK_Arcane Charge|r
.goto 2506,55.26,38.03
.cast 1249971 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Charge|r
step
.isInScenario 3150
#arrowtext Run into the circle
.goto 2506,56.5,36.13
>>Run into the circle.
.scenario 16073,1,4 
step
.isInScenario 3150
#arrowtext Click on\n|cRXP_PICK_Arcane Charge|r
.goto 2506,52.87,34.29
.cast 1249971 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Arcane Charge|r
step
.isInScenario 3150
#label Overlord
#arrowtext Run into the circle
.goto 2506,49.27,36.46
>>Run into the circle.
.scenario 16073,1,5 
step
#arrowtext Kill\n|cRXP_ENEMY_Chief-Arcanist Patram|r
.goto 2506,46.56,16.52
.isInScenario 3150
>>Kill |cRXP_ENEMY_Chief-Arcanist Patram|r
.scenario 16074,1 
.mob Chief-Arcanist Patram

step
#label Captured Wildlife
#arrowtext Click on\n|cRXP_PICK_Restraints|r
#loop
.goto 2506,47.57,74.13,15,0
.goto 2506,52.49,74.69,15,0
.goto 2506,56.86,76.55,15,0
.goto 2506,56.18,72.62,15,0
.goto 2506,54.20,68.12,15,0
.goto 2506,57.14,67.41,15,0
.goto 2506,56.12,63.65,15,0
.goto 2506,50.88,63.18,15,0
.goto 2506,44.14,64.78,25,0
.isInScenario 3149
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Restraints|r.
.scenario 16015,1 
.scenario 16015,2,100 
.mob Arcane Fragment
.mob Shadowguard Void Adept
.mob Prowling Voidstalker
.mob Shadowguard Void Adept
.mob Shadowguard Null Bastion
.mob Shadeye Observer
.mob Shadowguard Phasecutter
step
#arrowtext Click on\n|cRXP_PICK_Worm Bait|r
.goto 2506,51.63,56.82
.isInScenario 3149
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Worm Bait|r.
.scenario 16020,1 
step
#arrowtext Researchers devoured (1/4)\n|cRXP_WARN_(Read Note)|r
.goto 2506,55.13,52.68,10,0
.goto 2506,53.36,51.60
.isInScenario 3149
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Researchers|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16021,1,1 
.mob Void Researchers
step
#arrowtext Researchers devoured (2/4)\n|cRXP_WARN_(Read Note)|r
.goto 2506,58.78,34.82
.isInScenario 3149
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Researchers|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16021,1,2 
.mob Void Researchers
step
#arrowtext Researchers devoured (3/4)\n|cRXP_WARN_(Read Note)|r
.goto 2506,52.41,35.97
.isInScenario 3149
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Researchers|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16021,1,3 
.mob Void Researchers
step
#arrowtext Researchers devoured (4/4)\n|cRXP_WARN_(Read Note)|r
.goto 2506,45.18,41.69
.isInScenario 3149
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Researchers|r
*|cRXP_WARN_NOTE:|r Objective order is fixed. Follow the route or waypoints will be incorrect.
.scenario 16021,1 
.mob Void Researchers
step
#arrowtext Kill\n|cRXP_ENEMY_Chief-Arcanist Patram|r
.goto 2506,46.54,15.57
.isInScenario 3149
>>Kill |cRXP_ENEMY_Chief-Arcanist Patram|r.
*|cRXP_WARN_Kill the Void Emissaries|r
.scenario 16022,1 
.mob Chief-Arcanist Patram

step

.isOnQuest 93428
>>Finish the delve.
.complete 93428,1 
step
#label ShadowguardPointB
.zoneskip 2506,1
#arrowtext Leave the delve
.goto 2506,45.95,11.82,-1 
.goto 2506,45.93,11.71,-1 
.zone 2405 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
.use 249221
.use 257768
.use 249226
.use 257755
.use 249225
.use 249220
.use 249222
.use 257866
.use 257683
.use 249224





]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) Ritual Sites
#internal




step
.areapoiexists 2437,8614
#arrowtext Click on\n|cRXP_PICK_Obelisk|r
.goto 2437,29.58,77.95
.enterScenario 3236 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obelisk|r and select any difficulty.
.target Curious Obelisk
step
#completewith Faithbreaker
.isOnQuest 95550
.isInScenario 3236
>>Kill |cRXP_ENEMY_Twilight Cultists|r
.complete 95550,1 
.mob Twilight Ritual Guard
.mob Twilight Ritual Overseer
.mob Twilight Ritual Scout
.mob Twilight Ritual Weaver
.mob Elemental Ritualist
step
.isQuestAvailable 95554
.isInScenario 3236
#completewith Faithbreaker
>>Kill |cRXP_ENEMY_Twilight Cultists|r
*Loot them for |T7658130:0|t[|cRXP_LOOT_Ember of Power|r].
.accept 95554 >>Accept Questionable Power
.complete 95554,1 
.mob Twilight Ritual Guard
.mob Twilight Ritual Overseer
.mob Twilight Ritual Scout
.mob Twilight Ritual Weaver
.mob Elemental Ritualist
step
.isInScenario 3236
#arrowtext Kill\n|cRXP_ENEMY_Apprentices|r
#loop
.goto 2585,57.91,53.66,30,0
.goto 2585,53.15,50.62,30,0
.goto 2585,52.92,47.22,30,0
>>Kill |cRXP_ENEMY_Apprentices|r
.scenario 16391,1,2 
.mob Apprentice Jezhren
.mob Apprentice Kurgsbane
.mob Apprentice Thentor
step
.isOnQuest 95549
#arrowtext Use\n|T135975:0|t[Lady Darkglen's Device]
.goto 2585,51.38,51.21,30,0
.goto 2585,44.15,46.76
>>Use |T135975:0|t[Lady Darkglen's Device] at the waypoint location.
.complete 95549,2 
.use 271094
step
.isOnQuest 95549
#arrowtext Kill\n|cRXP_ENEMY_Ritualist first|r
.goto 2585,47.88,44.33,30,0
.goto 2585,50.16,37.59
>>Use |T135975:0|t[Lady Darkglen's Device] at the waypoint location.
*|cRXP_WARN_You might have to kill the |cRXP_ENEMY_Ritualist first|r|r
.complete 95549,1 
.use 271094
step
.isInScenario 3236
#arrowtext Kill\n|cRXP_ENEMY_Apprentices|r
#loop
.goto 2585,47.65,55.55,30,0
.goto 2585,46.2,53.41,30,0
>>Kill |cRXP_ENEMY_Apprentices|r
.scenario 16391,1 
.mob Apprentice Jezhren
.mob Apprentice Kurgsbane
.mob Apprentice Thentor
step
.isInScenario 3236
.isOnQuest 95549
#arrowtext Use\n|T135975:0|t[Lady Darkglen's Device]
.goto 2585,49.31,58.36
>>Use |T135975:0|t[Lady Darkglen's Device] at the waypoint location.
.complete 95549,3 
.use 271094
step
.isInScenario 3236
#arrowtext Kill\n|cRXP_ENEMY_Void Entities|r
#loop
.goto 2585,53.29,60.54,30,0
.goto 2585,50.34,64.11,30,0
.goto 2585,49.26,60.99,30,0
.goto 2585,46.36,71.17,30,0
>>Kill |cRXP_ENEMY_Void Entities|r
.scenario 16391,2 
.mob Lithesome Wraith
.mob Lumbnering Malefactor
.mob Unbounbd Caller
step
.isInScenario 3236
.isOnQuest 95549
#arrowtext Use\n|T135975:0|t[Lady Darkglen's Device]
.goto 2585,50.49,72.74
>>Use |T135975:0|t[Lady Darkglen's Device] at the waypoint location.
.complete 95549,4 
step
.isInScenario 3236
#arrowtext Kill\n|cRXP_ENEMY_Corrupted Amani Dragonhawk|r
.goto 2585,41.90,59.04
>>Kill |cRXP_ENEMY_Corrupted Amani Dragonhawk|r
.scenario 16393,1 
.mob Corrupted Amani Dragonhawk
step
#label Faithbreaker
.isInScenario 3236
#arrowtext Kill\n|cRXP_ENEMY_Faithbreaker Ger'lok|r
.goto 2585,35.58,58.89
>>Kill |cRXP_ENEMY_Faithbreaker Ger'lok|r
.scenario 16394,1 
.mob Faithbreaker Ger'lok
step
.zoneskip 2585,1
#arrowtext Click on\n|cRXP_PICK_Chest|r
.goto 2585,34.26,58.94
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.scenario 17108,1 
.accept 95547 >>Accept Ritual Site Challenge Report: Tendrils
step
.zoneskip 2585,1
.zone 2437 >>Press the Macro in the "Active Items Frame" to leave the instance.
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()

step
.areapoiexists 2395,8615
#arrowtext Click on\n|cRXP_PICK_Obelisk|r
.goto 2395,37.57,65.26
.enterScenario 3267 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obelisk|r and select any difficulty.
.target Curious Obelisk
step
#completewith Lady
.isOnQuest 95550
.isInScenario 3267
>>Kill |cRXP_ENEMY_Twilight Cultists|r
.complete 95550,1 
.mob Twilight Ritual Guard
.mob Twilight Ritual Overseer
.mob Twilight Ritual Scout
.mob Twilight Ritual Weaver
.mob Elemental Ritualist
step
.isQuestAvailable 95554
.isInScenario 3267
#completewith Lady
>>Kill |cRXP_ENEMY_Nagas|r
*Loot them for |T7658130:0|t[|cRXP_LOOT_Ember of Power|r].
.accept 95554 >>Accept Questionable Power
.complete 95554,1 
.mob Daggerspine Infusers
.mob Deeplurk Snapdragon
.mob Daggerspine Myrmidon
.mob Deeplurk Shadowblade
.mob Deeplurk Sorceress
step
#arrowtext Kill\n|cRXP_ENEMY_Captains|r
#loop
.goto 2594,65.21,31.15,30,0
.goto 2594,57.76,43.42,30,0
.goto 2594,56.46,59.22,30,0
.isInScenario 3267
>>Kill |cRXP_ENEMY_Captains|r
.scenario 16530,1 
.mob Abyssal Vazir
.mob Tidecrusher Garazyn
step
#arrowtext Kill\n|cRXP_ENEMY_Void Creatures|r
#loop
.goto 2594,59.72,78.86,30,0
.goto 2594,47.45,76.8,30,0
.goto 2594,45.68,60.77,30,0
.isInScenario 3267
>>Kill |cRXP_ENEMY_Void Creatures|r
.scenario 16530,2 
.mob Mirebound Wraith
.mob Abyssal Slayer
.mob Sodden Voidbinder
step
#arrowtext Kill\n|cRXP_ENEMY_Void-Infused Mindbreaker|r
.goto 2594,49.69,51.13
.isInScenario 3267
>>Kill |cRXP_ENEMY_Void-Infused Mindbreaker|r
.scenario 16532,1 
.mob Void-Infused Mindbreaker
step
#label Lady
#arrowtext Kill\n|cRXP_ENEMY_Lady Selen'vjar|r
.goto 2594,40.09,51.62
.isInScenario 3267
>>Kill |cRXP_ENEMY_Lady Selen'vjar|r
.scenario 16533,1 
.mob Lady Selen'vjar
step
.zoneskip 2594,1
#arrowtext Click on\n|cRXP_PICK_Chest|r
.goto 2594,34.20,53.39
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
.scenario 17107,1 
.accept 95547 >>Accept Ritual Site Challenge Report: Tendrils
step
.zoneskip 2594,1
.zone 2395 >>Press the Macro in the "Active Items Frame" to leave the instance.
.macro Leave Instance,236367 >> /run C_PartyInfo.LeaveParty()
]])

RXPGuides.RegisterGuide([[
#retail
#version 20
#group RestedXP Midnight
#name a) The Ring of Glory
#internal
step
#arrowtext Enter\n|cRXP_PICK_The Ring of Glory|r
.goto 2512,71.13,56.55
.enterScenario 3386,3416,3417 >>Enter |cRXP_PICK_The Ring of Glory|r Delve in The Coiled Isle.

step
.isInScenario 3417
#arrowtext Click on |cRXP_PICK_Animals|r\nKill |cRXP_ENEMY_Souls|r
#loop
.goto 2633,47.90,85.22,25,0
.goto 2633,32.22,53.89,35,0
.goto 2633,54.05,32.05,25,0
.goto 2633,65.79,54.38,25,0
>>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Animals|r.
>>Kill the |cRXP_ENEMY_Souls|r, |cRXP_ENEMY_Specters|r and |cRXP_ENEMY_Slaves|r.
.scenario 17100,1 
.mob Frayed Remnant
.mob Stonesoul Specter
.mob Crumbling Soulslave
.mob Soulpledged Warrior
.mob Shadesoul Shaman
.mob Timeworn Golem
.mob Ancient Cursekeeper
step
.isInScenario 3417
#arrowtext Kill\n|cRXP_ENEMY_Gnok|r
.goto 2633,47.01,53.49
>>Kill |cRXP_ENEMY_Gnok|r.
.scenario 17101,1 
.mob Gnok

step
#arrowtext Kill\n|cRXP_ENEMY_spirits|r
#loop
.goto 2633,47.90,85.22,25,0
.goto 2633,32.22,53.89,35,0
.goto 2633,54.05,32.05,25,0
.goto 2633,65.79,54.38,25,0
.isInScenario 3416
>>Kill the |cRXP_ENEMY_spirits|r.
*Knock the |cRXP_PICK_Headballs|r into one of the four pillars.
.scenario 17097,1 
.scenario 17097,2 
.mob Shadesoul Shaman
.mob Restless Spiritcaller
.mob Frayed Remnant
.mob Crumbling Soulslave
.mob Soulpledged Warrior
step
.isInScenario 3416
#arrowtext Kill\n|cRXP_ENEMY_Draktha|r
.goto 2633,34.23,53.68
>>Kill |cRXP_ENEMY_Draktha|r.
.scenario 17098,1 

step
.isInScenario 3386
#arrowtext Kill Souls and Spectres
#loop
.goto 2633,55.66,76.05,35,0
.goto 2633,35.27,68.54,35,0
.goto 2633,36.09,36.07,35,0
.goto 2633,47.63,46.66,35,0
>>Kill the |cRXP_ENEMY_Souls|r and |cRXP_ENEMY_Spectres|r.
.scenario 16911,1 
.mob Arisen Warsinger
.mob Soulpledged Warrior
.mob Shadesoul Shaman
.mob Crumbling Soulslave
.mob Stonesoul Specter
step
.isInScenario 3386
#arrowtext Defeat\n|cRXP_ENEMY_Crushfoot|r
.goto 2633,61.65,53.95
>>Defeat |cRXP_ENEMY_Crushfoot|r.
.scenario 16912,1 
.mob Crushfoot
step
#arrowtext Defeat\n|cRXP_ENEMY_Bluegill Brothers|r
.goto 2633,53.95,74.67
.isInScenario 3386
>>Defeat the |cRXP_ENEMY_Bluegill Brothers|r.
.scenario 17156,1 
.mob Lurgle
.mob Smurgle
.mob Bluegill Tagteam
step
.isInScenario 3386
#arrowtext Defeat\n|cRXP_ENEMY_Brinebeater|r
.goto 2633,45.00,40.43
>>Defeat |cRXP_ENEMY_Brinebeater|r.
.scenario 17157,1 
.mob Brinebeater
step
.isInScenario 3386
#arrowtext Defeat\n|cRXP_ENEMY_Guth'kar the Bound|r
.goto 2633,49.58,54.17
>>Defeat |cRXP_ENEMY_Guth'kar the Bound|r.
.scenario 17158,1 
.mob Guth'kar the Bound
step
.isInScenario 3386
#arrowtext Defeat\n|cRXP_ENEMY_Arena champions|r
.goto 2633,59.94,53.52
>>Defeat the |cRXP_ENEMY_Arena champions|r.
.scenario 17159,1 
.mob Ka the Mad
.mob Za'rema the Slicer
.mob Hexspitter Zit'ka
step
.isInScenario 3386
#arrowtext Kill\n|cRXP_ENEMY_Drakta|r
.goto 2633,49.32,54.45
>>Kill |cRXP_ENEMY_Drakta|r.
.scenario 16913,1 
.mob Drakta
step
#label TheRingOfGloryZ
.zoneskip 2633,1
#arrowtext Leave the delve
.goto 2633,32.96,54.22
.zone 2512 >>Collect the |cRXP_PICK_Treasures|r and learn new curios.
*Press the Macro in the "Active Items Frame" to leave the Delve.
.macro Leave Delve,6025441 >>/run C_PartyInfo.DelveTeleportOut()
]])

