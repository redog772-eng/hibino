if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "WOTLK" then return end

RXPGuides.RegisterGuide([[#version 10
#wotlk
#tbc
#group RestedXP TBC Guide (H)
#subgroup RestedXP Horde 30-45
<< Horde
#name 38-40 Hillsbrad/Alterac/Arathi part 2
#next 40-41 Badlands
step
#sticky
#completewith EnterSM
.subzone 796,2 >> Now you should be looking for a group to Scarlet Monastery
.dungeon SM
step
#completewith next
.zone Durotar >> Leave Orgrimmar
.zoneskip Durotar
step
#label STVZepp2
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Stranglethorn Vale >>Take the Zeppelin to Stranglethorn Vale
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.turnin 1240 >> Turn in The Troll Witchdoctor
.target Kin'weelay
step
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.accept 1261 >> Accept Marg Speaks
.isQuestTurnedIn 1240
step << !Mage
.goto Stranglethorn Vale,31.6,29.1
.zone Tirisfal Glades >>Take the Zeppelin to Undercity
.zoneskip Tirisfal Glades
.zoneskip Undercity
step << Mage
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << Mage
#optional
.goto Undercity,85.13,10.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8413 >> Train your class spells
.target Anastasia Hartwell
.xp <38,1
.xp >40,1
step << Mage
#optional
.goto Undercity,85.13,10.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8423 >> Train your class spells
.target Anastasia Hartwell
.xp <40,1
.xp >42,1
step << Mage
.goto Undercity,85.13,10.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8423 >> Train your class spells
.target Anastasia Hartwell
.xp <42,1
step << Mage
.goto Undercity,84.20,15.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Lexington|r
.train 11418 >> Train |T135751:0|t[Portal: Undercity]
.target Lexington Mortaim
.xp <40,1
step << Mage
.goto Undercity,82.79,15.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Hannah|r|cRXP_BUY_. Buy two or more|r |T134419:0|t[Rune of Teleportation] |cRXP_BUY_from him|r
.collect 17031,2,503,1 
.target Hannah Akeley
step << Undead !Warlock
#optional
#completewith next
.subzone 159 >> Travel to Brill
.xp <30,1
.money <38
.skill riding,75,1
.dungeon !SM << Mage
step << Undead !Warlock
#optional
.goto Tirisfal Glades,60.09,52.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velma|r and |cRXP_FRIENDLY_Zachariah|r
.train 10906 >>Train |T136103:0|t[Undead Horsemanship]
.vendor >>|cRXP_BUY_Buy a|r |T132264:0|t[|cFF0070FFSkeletal Horse|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Velma Warnam
.target Zachariah Post
.dungeon !SM << Mage
step
#completewith UCVisit3
.goto Tirisfal Glades,61.80,65.06,20,0
.zone Undercity >> Enter Undercity
.zoneskip Undercity
.dungeon !SM << Mage
step << BloodElf !Warlock !Paladin
#optional
#completewith next
.goto Undercity,65.87,1.48,15,0
.goto Undercity,65.82,5.44,15,0
.goto Undercity,62.76,11.02,12,0
.goto Undercity,54.67,11.25
.zone Silvermoon City >> Take the Orb of Translocation to Silvermoon City
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
#completewith next
.goto Silvermoon City,62.89,31.20,20,0
.goto Silvermoon City,75.63,58.34,20,0
.goto Silvermoon City,73.22,59.91,20,0
.goto Eversong Woods,56.43,49.91
.zone Eversong Woods >>Exit Silvermoon
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
.goto Eversong Woods,61.08,54.15,12,0
.goto Eversong Woods,61.38,53.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perascamin|r and |cRXP_FRIENDLY_Winaestra|r
.train 33388 >> Train |T136103:0|t[Apprentice Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132228:0|t[|cFF0070FFHawkstrider|r]
.target Perascamin
.target Winaestra
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
#completewith UCVisit3
.goto Silvermoon City,51.83,17.91,30,0
.goto Silvermoon City,49.45,15.00
.zone Undercity >>Take the Orb of Translocation back to Undercity
.skill riding,<75,1
step
#completewith IntoSM
.goto Undercity,51.92,64.68,15 >>Travel toward |cRXP_FRIENDLY_Varimathras|r
.dungeon SM
step
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.turnin 6521 >>Turn in An Unholy Alliance
.target Varimathras
.isQuestComplete 6521
.dungeon RFD
step
#label IntoSM
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.accept 1048 >>Accept Into The Scarlet Monastery
.target Varimathras
.dungeon SM
step
#completewith next
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Zinge|r
step
.goto Undercity,50.15,67.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zinge|r
.accept 232 >> Accept Errand for Apothecary Zinge
.target Apothecary Zinge
step
.goto Undercity,48.80,69.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faranell|r
.accept 1113 >> Accept Hearts of Zeal
.target Master Apothecary Faranell
.isQuestTurnedIn 1109 
.dungeon SM
step
.goto Undercity,58.61,54.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alessandro|r
.turnin 232 >> Turn in Errand for Apothecary Zinge
.accept 238 >> Accept Errand for Apothecary Zinge
.target Alessandro Luca
step
#label IntoFieldPU
.goto Undercity,50.15,67.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zinge|r
.turnin 238 >> Turn in Errand for Apothecary Zinge
.accept 243 >> Accept Into the Field
.target Apothecary Zinge
step
.goto Undercity,74.05,33.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andrew|r
.turnin 3341 >>Turn in Bring the End
.target Andrew Brownell
.isQuestComplete 3341
.dungeon RFD
step
#optional
.abandon 6521 >> Abandon An Unholy Alliance
.dungeon RFD
step
#optional
.abandon 6626 >> Abandon A Host of Evil
.dungeon RFD
step
#optional
.abandon 3341 >> Abandon Bring the End
.dungeon RFD
step << Hunter
.goto Undercity,54.71,38.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abigail|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from her if it's available|r
.target Abigail Sawyer
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
step << Hunter
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_WARN_when you are level 42|r
.use 11307
.itemcount 11307,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
step << Hunter
.goto Undercity,58.66,33.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |cRXP_BUY_Buy a|r |T135424:0|t[Great Axe] |cRXP_BUY_from him if you're melee weaving. Otherwise, skip this step|r
.collect 2531,1,503,1 
.target Geoffrey Hartwell
.money <5.0552
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<31.2
step << Hunter
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135424:0|t[Great Axe] |cRXP_WARN_when you are level 39|r
.use 2531
.itemcount 2531,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<31.2
.xp >39,1
step << Hunter
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135424:0|t[Great Axe]
.use 2531
.itemcount 2531,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<31.2
.xp <39,1
step << Rogue
.goto Undercity,58.66,33.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135344:0|t[Falchion] |cRXP_BUY_from him|r
.collect 2528,1,503,1 
.money <4.6652
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.6
.target Geoffrey Hartwell
step << Rogue
.goto Undercity,58.66,33.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135341:0|t[Rondel] |cRXP_BUY_from him|r
.collect 2534,1,503,1 
.money <4.0888
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
.target Geoffrey Hartwell
step << Rogue
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135344:0|t[Falchion] |cRXP_WARN_when you are level 41|r
.use 2528
.itemcount 2528,1
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.6
step << Rogue
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135341:0|t[Rondel] |cRXP_WARN_in your off-hand when you are level 39|r
.use 2534
.itemcount 2534,1
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
step << Priest
.goto Undercity,69.54,26.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Zane|r|cRXP_BUY_. Buy a|r |T133718:0|t[Blackbone Wand] |cRXP_BUY_from him|r
.collect 5239,1,503,1 
.money <4.0769
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<35.3
.target Zane Bradford
step << Priest
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135344:0|t[Blackbone Wand] |cRXP_WARN_when you are level 41|r
.use 5239
.itemcount 5239,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<35.3
step << Undead Mage
#optional
#completewith next
.subzone 159 >> Travel to Brill
.xp <30,1
.money <38
.skill riding,75,1
.dungeon SM
step << Undead Mage
#optional
.goto Tirisfal Glades,60.09,52.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velma|r and |cRXP_FRIENDLY_Zachariah|r
.train 10906 >>Train |T136103:0|t[Undead Horsemanship]
.vendor >>|cRXP_BUY_Buy a|r |T132264:0|t[|cFF0070FFSkeletal Horse|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Velma Warnam
.target Zachariah Post
.dungeon SM
step
#label EnterSM
.goto Eastern Kingdoms,47.43,19.71,30,0
.goto Eastern Kingdoms,47.76,19.49
.subzone 796,2 >> Enter Scarlet Monastery. Start with Library so you can loot the [|cRXP_FRIENDLY_The Scarlet Key|r] at the end
.zoneskip 304
.zoneskip 305
.dungeon SM
step << !Undead
#completewith Bosses
>>Loot the |cRXP_LOOT_Compendium of the Fallen|r
>>|cRXP_WARN_It's located in a bookshelf on the left in the last corner of the dungeon|r
.complete 1049,1 
.dungeon SM
step
#completewith Compendium
>>Kill |cRXP_LOOT_Scarlet|r mobs. Loot them for their |cRXP_LOOT_Hearts of Zeal|r
.complete 1113,1 
.isOnQuest 1113
.dungeon SM
step
#label Bosses
>>Kill |cRXP_ENEMY_Houndmaster Loksey|r, |cRXP_ENEMY_Herod|r, |cRXP_ENEMY_High Inquisitor Whitemane|r and |cRXP_ENEMY_Scarlet Commander Mograine|r
>>|cRXP_ENEMY_Houndmaster Loksey|r |cRXP_WARN_is located in the Library|r
>>|cRXP_ENEMY_Herod|r |cRXP_WARN_is located in the Armory|r
>>|cRXP_ENEMY_High Inquisitor Whitemane|r |cRXP_WARN_and |cRXP_ENEMY_Scarlet Commander Mograine|r are located in the Cathedral|r
.complete 1048,4 
.complete 1048,3 
.complete 1048,1 
.complete 1048,2 
.isOnQuest 1048
.mob Houndmaster Loksey
.mob Herod
.mob High Inquisitor Whitemane
.mob Scarlet Commander Mograine
.dungeon SM
step << !Undead
#label Compendium
>>Loot the |cRXP_LOOT_Compendium of the Fallen|r
>>|cRXP_WARN_It's located in a bookshelf on the left in the last corner of the dungeon|r
.complete 1049,1 
.isOnQuest 1049
.dungeon SM
step << Mage
#completewith SMturnin
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
.dungeon SM
step << !Mage
#completewith SMturnin
.goto Undercity,66.07,9.18,150 >> Travel to Undercity
.zoneskip Undercity
.dungeon SM
step
#completewith SMturnin
.goto Undercity,51.92,64.68,15 >>Travel toward |cRXP_FRIENDLY_Varimathras|r
.isQuestComplete 1048
.dungeon SM
step
#label SMturnin
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.turnin 1048 >>Turn in Into The Scarlet Monastery
.isQuestComplete 1048
.target Varimathras
.dungeon SM
step
.goto Undercity,57.4,93.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sharlindra|r
.accept 495 >> Accept The Crown of Will
.target Sharlindra
.dungeon SM
.isQuestTurnedIn 1048
step
#completewith next
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Faranell|r
.isQuestComplete 1113
.dungeon SM
step
.goto Undercity,48.80,69.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faranell|r
.turnin 1113 >> Turn in Hearts of Zeal
.target Master Apothecary Faranell
.isQuestComplete 1113
.dungeon SM
step << Warrior
.goto Undercity,77.48,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Nathaniel|r|cRXP_BUY_Buy a|r |T135424:0|t[Gleaming Throwing Axe] |cRXP_BUY_from him|r
.collect 25876,1,1713,1 
.target Nathaniel Steenwick
step << Warrior
#ah
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r in the Trade Quarter
>>|cRXP_BUY_If you have money leftover after buying|r |T134717:0|t[Nature Protection Potions]|cRXP_BUY_, purchase the following items:|r
.collect 4480,8,1713,1 
.collect 4479,8,1713,1 
.collect 4481,8,1713,1 
.collect 3357,8,1712,1 
.target Auctioneer Stockton
step << Warrior
#ah
.goto Undercity,71.42,46.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r in the Trade Quarter
>>|cRXP_BUY_Buy|r |T134717:0|t[Nature Protection Potions] |cRXP_BUY_from the auction house|r
.collect 6052,2,1713,1 
.target Auctioneer Stockton
step
#ah
.goto Undercity,71.42,46.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r in the Trade Quarter
>>|cRXP_BUY_If you have money leftover, purchase the following items:|r
.collect 3829,1 
.collect 4389,1 
.collect 929,1 
.collect 3823,1 
.collect 4611,9 
.collect 3404,4 
.target Auctioneer Stockton
step
.goto Undercity,62.14,44.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eunice|r
.train 2550 >> Train cooking for a quest later
.target Eunice Burch
.itemcount 3712,10 
step
.goto Undercity,62.31,48.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Patrick|r
.accept 2342 >> Accept Reclaimed Treasures
.target Patrick Garrett
step
#optional
#label UCVisit3
step
#optional
.abandon 1048 >>Abandon Into The Scarlet Monastery
step
#optional
.abandon 1113 >>Abandon Hearts of Zeal
step << Warrior
#completewith next
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
>>|cRXP_ENEMY_Fly to Tarren Mill instead if you bought 8 Cresting, Thundering and Burning charms on the AH and skip the next 3 steps|r
.fly Hammerfall >> Fly to Hammerfall
.target Michael Garrett
.zoneskip Arathi Highlands
step << Warrior
#label Cresting
.goto Arathi Highlands,66.72,29.72
>>Kill |cRXP_ENEMY_Cresting Exiles|r. Loot them for their |T133438:0|t[Cresting Charms]
.collect 4481,8,1713,1 
.mob Cresting Exile
step << Warrior
.goto Arathi Highlands,52.06,50.60
>>Kill |cRXP_ENEMY_Thundering Exiles|r. Loot them for their |T133435:0|t[Thundering Charms]
>>|cRXP_WARN_Be careful!|r |cRXP_ENEMY_Thundering Exiles|r |cRXP_WARN_have high burst damage|r
.collect 4480,8,1713,1 
.mob Thundering Exile
step << Warrior
.goto Arathi Highlands,25.47,30.09
>>Kill |cRXP_ENEMY_Burning Exiles|r. Loot them for their |T133434:0|t[Burning Charms]
.collect 4479,8,1713,1 
.mob Burning Exile
step << Warrior
#completewith BracersofBinding
.goto Hillsbrad Foothills,62.06,20.19,120 >> Travel to Tarren Mill
.zoneskip Hillsbrad Foothills
step << !Warrior
#completewith BracersofBinding
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Michael Garrett
.zoneskip Hillsbrad Foothills
step
#optional
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.turnin 495 >> Turn in The Crown of Will
.accept 518 >> Accept The Crown of Will
.target Melisara
.isOnQuest 495
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.accept 518 >> Accept The Crown of Will
.target Melisara
step
.goto Hillsbrad Foothills,62.63,20.65
>>Click the |cRXP_PICK_WANTED: Baron Vardus|r poster next to |cRXP_FRIENDLY_Melisara|r
.accept 566 >> Accept WANTED: Baron Vardus
.target Melisara
.isQuestTurnedIn 549
step
.goto Hillsbrad Foothills,63.24,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.accept 503 >> Accept Gol'dir
.target Krusk
.isQuestTurnedIn 498
step
.goto Hillsbrad Foothills,62.3,19.1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Christoph Jeffcoat|r
>>|cRXP_BUY_Buy|r [Soothing Spices] |cRXP_BUY_from him|r
.collect 3713,1,7321,1 
.itemcount 3712,10 
.target Christoph Jeffcoat
step
.goto Hillsbrad Foothills,62.28,19.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Christoph|r inside the inn
.accept 7321 >> Accept Soothing Turtle Bisque
.turnin 7321 >> Turn in Soothing Turtle Bisque
.target Christoph Jeffcoat
.itemcount 3712,10 
step
#label BracersofBinding
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bel'varil|r and |cRXP_FRIENDLY_Wordeen|r
.accept 557 >> Accept Bracers of Binding
.target +Keeper Bel'varil
.goto Hillsbrad Foothills,61.60,20.86
.accept 545 >> Accept Dalaran Patrols
.target +Magus Wordeen Voidglare
.goto Hillsbrad Foothills,61.49,20.93
step << Warrior
#completewith Whirlwind
+|cRXP_WARN_It is VERY important to watch this video on how to cheese Cyclonian for the|r |T132403:0|t[Whirlwind Axe]
.link https://www.youtube.com/watch?v=BiuWeMSHEhA >> CLICK HERE
step << Warrior
#ah
#optional
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
.use 6052 >>|cRXP_WARN_While traveling, use a|r |T134717:0|t[Nature Protection Potion]
.turnin 1714 >> Turn in Essence of the Exile
.target Bath'rah the Windwatcher
.itemcount 6052,1
step << Warrior
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
.turnin 1714 >> Turn in Essence of the Exile
.target Bath'rah the Windwatcher
step << Warrior
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
.turnin 1712 >>Turn in Cyclonian
.accept 1713 >>Accept The Summoning
.target Bath'rah the Windwatcher
step << Warrior
#label Whirlwind
.goto Alterac Mountains,80.6,62.2
>>Wait for |cRXP_FRIENDLY_Bath'rah's|r roleplay, then kill |cRXP_ENEMY_Cyclonian|r and loot him for his |cRXP_LOOT_Heart|r
>>|cRXP_WARN_Equip your|r |T135424:0|t[Gleaming Throwing Axe] |cRXP_WARN_if you haven't|r
.complete 1713,1 
.unitscan Cyclonian
step << Warrior
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r and choose the |T132403:0|t[Whirlwind Axe]
.turnin 1713 >>Turn in The Summoning
.turnin 1792 >>Turn in Whirlwind Weapon
.target Bath'rah the Windwatcher
step << Warrior
#completewith Goldir
.destroy 6929 >>|cRXP_WARN_Destroy|r |T134327:0|t[Bath'rah's Parchment] |cRXP_WARN_as it's not needed for anything|r
step
#completewith next
.goto Alterac Mountains,42.2,77.8,90,0
.goto Alterac Mountains,46.2,78.2,90,0
>>Kill |cRXP_ENEMY_Mountain Lions|r. Loot them for a |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r]
>>|cRXP_WARN_The|r |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r] |cRXP_WARN_disappears after 30 minutes|r
.collect 5810,1,1136,1 
.mob Feral Mountain Lion
.mob Mountain Lion
.mob Starving Mountain Lion
.mob Hulking Mountain Lion
step
.goto Alterac Mountains,37.56,68.22
.use 5810 >> |cRXP_WARN_Use the|r |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r] |cRXP_WARN_inside Growless Cave to summon|r |cRXP_ENEMY_Frostmaw|r
>>Kill him and loot him for his |cRXP_LOOT_Mane|r
.complete 1136,1 
.unitscan Frostmaw
step
#label Ruins1
#completewith next
.goto Alterac Mountains,41.86,46.98,100 >>Travel to the Ruins of Alterac
step
#loop
.goto Alterac Mountains,46.1,46.6,0
.goto Alterac Mountains,41.4,48.7,50,0
.goto Alterac Mountains,38.1,40.3,50,0
.goto Alterac Mountains,46.1,46.6,50,0
>>Kill |cRXP_ENEMY_Crushridge Maulers|r in the area
>>|cRXP_WARN_They share spawns with other |cRXP_ENEMY_Ogres|r so kill them also if needed|r
.complete 518,1 
.mob Crushridge Mauler
step
#completewith Goldir
>>Kill |cRXP_ENEMY_Baron Vardus|r and loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_One of his spawnpoints is inside the inn in Strahnbrad. You will complete this quest later if he isn't there|r
.complete 566,1 
.unitscan Baron Vardus
.isQuestTurnedIn 549
step
#loop
.goto Alterac Mountains,60.55,43.91,0
.goto Alterac Mountains,63.10,43.47,0
.goto Alterac Mountains,62.67,40.16,0
.goto Alterac Mountains,61.77,43.88,8,0
.goto Alterac Mountains,60.55,43.91,8,0
.goto Alterac Mountains,63.10,43.47,8,0
.goto Alterac Mountains,62.31,41.59,8,0
.goto Alterac Mountains,62.67,40.16,12,0
>>Kill |cRXP_ENEMY_Jailor Borhuin|r. Loot him for his |cRXP_LOOT_Key|r
>>|cRXP_WARN_He has multiple spawn locations in Strahnbrad:|r
>>|cRXP_WARN_Inside the inn on the second floor|r
>>|cRXP_WARN_Inside the building opposite of the inn on the ground floor|r
>>|cRXP_WARN_Inside the town hall|r
.complete 503,1 
.unitscan Jailor Borhuin
.isQuestTurnedIn 498
step
#label Goldir
.goto Alterac Mountains,60.00,43.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gol'dir|r on the second floor of the inn
.turnin 503 >> Turn in Gol'dir
.accept 506 >> Accept Blackmoore's Legacy
.target Gol'dir
.isQuestTurnedIn 498
step
#completewith next
.goto Hillsbrad Foothills,62.37,20.32
.subzone 272 >> Travel to Tarren Mill
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Melisara|r
.turnin 518 >> Turn in The Crown of Will
.accept 519 >> Accept The Crown of Will
.target Melisara
step
.goto Hillsbrad Foothills,63.24,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.turnin 506 >> Turn in Blackmoore's Legacy
.accept 507 >> Accept Lord Aliden Perenolde
.target Krusk
.isQuestTurnedIn 498
step
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Darthalia|r
.turnin 566 >> Turn in WANTED: Baron Vardus
.target High Executor Darthalia
.isQuestComplete 566
step
.goto Hillsbrad Foothills,62.76,19.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shay|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Shay
.subzoneskip 272,1
step
#label Ruins2
#completewith TargsHead
.goto Alterac Mountains,41.86,46.98,100 >>Travel to the Ruins of Alterac
step
#requires Ruins2
#completewith TargsHead
+|cRXP_WARN_Be careful of |cRXP_ENEMY_Grel'borg the Miser|r (elite). He patrols around|r
.mob Grel'borg the Miser
step
.goto Alterac Mountains,39.49,41.82
>>Kill |cRXP_ENEMY_Glommus|r. Loot him for his |cRXP_LOOT_Head|r
.complete 519,3 
.unitscan Glommus
step
.goto Alterac Mountains,38.61,46.78
>>Kill |cRXP_ENEMY_Muckrake|r. Loot him for his |cRXP_LOOT_Head|r
.complete 519,2 
.unitscan Muckrake
step
#label TargsHead
.goto Alterac Mountains,39.59,52.86
>>Kill |cRXP_ENEMY_Targ|r. Loot him for his |cRXP_LOOT_Head|r
.complete 519,1 
.unitscan Targ
step
#loop
.goto Alterac Mountains,10.30,78.50,0
.goto Alterac Mountains,20.50,75.20,50,0
.goto Alterac Mountains,21.30,53.50,50,0
.goto Alterac Mountains,17.80,56.20,50,0
.goto Alterac Mountains,21.30,53.50,50,0
.goto Alterac Mountains,20.50,75.20,50,0
.goto Alterac Mountains,10.30,78.50,50,0
>>Kill |cRXP_ENEMY_Dalaran Summoners|r and |cRXP_ENEMY_Elemental Slaves|r. Loot them for their |cRXP_LOOT_Bracers|r
.complete 545,1 
.mob +Dalaran Summoner
.complete 545,2 
.mob +Elemental Slave
.complete 557,1 
.mob +Elemental Slave
step
.goto Alterac Mountains,39.28,14.52
>>Kill |cRXP_ENEMY_Lord Aliden Perenolde|r
>>|cRXP_WARN_Be mindful of |cRXP_ENEMY_Syndicate Assassins|r|cRXP_WARN_.|r |cRXP_ENEMY_Aliden|r |cRXP_WARN_uses Power Word: Shield, casts Renew, and will sleep pets and other players|r
.complete 507,1 
.unitscan Lord Aliden Perenolde
.mob Syndicate Assassin
.isQuestTurnedIn 506
step
.goto Alterac Mountains,39.30,14.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elysa|r
.turnin 507 >> Turn in Lord Aliden Perenolde
.accept 508 >> Accept Taretha's Gift
.target Elysa
.isQuestTurnedIn 506
step
#loop
.goto Alterac Mountains,47.8,17.1,0
.goto Alterac Mountains,53.6,20.6,0
.goto Alterac Mountains,56.2,26.8,0
.goto Alterac Mountains,58.1,29.9,0
.goto Alterac Mountains,59.7,43.9,0
.goto Alterac Mountains,47.8,17.1,70,0
.goto Alterac Mountains,53.6,20.6,70,0
.goto Alterac Mountains,56.2,26.8,70,0
.goto Alterac Mountains,58.1,29.9,70,0
.goto Alterac Mountains,59.7,43.9,70,0
>>Search for |cRXP_ENEMY_Baron Vardus|r in each camp and the Strahnbrad's inn. Kill him and loot him for his |cRXP_LOOT_Head|r
.complete 566,1 
.unitscan Baron Vardus
step
#completewith TMTurnins2
.goto Hillsbrad Foothills,62.37,20.32
.subzone 272 >> Travel to Tarren Mill
step
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Darthalia|r
.turnin 566 >> Turn in WANTED: Baron Vardus
.target High Executor Darthalia
.isQuestComplete 566
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.turnin 519 >> Turn in The Crown of Will
.accept 520 >> Accept The Crown of Will
.target Melisara
step
.goto Hillsbrad Foothills,63.20,20.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.turnin 508 >> Turn in Taretha's Gift
.target Krusk
.isOnQuest 508
step
#label TMTurnins2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wordeen|r and |cRXP_FRIENDLY_Bel'varil|r
.turnin 545 >> Turn in Dalaran Patrols
.target +Magus Wordeen Voidglare
.goto Hillsbrad Foothills,61.56,20.89
.turnin 557 >> Turn in Bracers of Binding
.target +Keeper Bel'varil
.goto Hillsbrad Foothills,61.49,20.93
step
#label Ruins3
#completewith MugtholsHead
.goto Alterac Mountains,41.86,46.98,100 >>Travel to the Ruins of Alterac
step
#xprate <1.5
.goto Alterac Mountains,37.9,52.2
.xp 39 >> Grind to 39 on |cRXP_ENEMY_Ogres|r in the area
step
#requires Ruins3
#completewith MugtholsHead
+|cRXP_WARN_Be careful of |cRXP_ENEMY_Grel'borg the Miser|r (elite). He patrols around|r
.mob Grel'borg the Miser
step
#label MugtholsHead
.goto Alterac Mountains,35.68,54.25
>>Kill |cRXP_ENEMY_Mug'thol|r. Loot him for his |cRXP_LOOT_Head|r and for the |cRXP_LOOT_Crown of Will|r
>>|cRXP_WARN_Be very careful of|r |cRXP_ENEMY_Crushridge Warmongers|r|cRXP_WARN_, who call for help at low HP|r
.complete 520,1 
.complete 520,2 
.unitscan Mug'thol
step
#completewith next
.subzone 272 >>Travel to Tarren Mill
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.turnin 520 >> Turn in The Crown of Will
.accept 521 >> Accept The Crown of Will
.target Melisara
step
#completewith Arathipt2Start
.goto Hillsbrad Foothills,60.14,18.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zarise|r
.fly Hammerfall >> Fly to Hammerfall
.target Zarise
.zoneskip Arathi Highlands
step
.goto Arathi Highlands,62.50,33.80
>>Click the |cRXP_PICK_Shards of Myzrael|r
.accept 642 >> Accept The Princess Trapped
step
.goto Arathi Highlands,73.80,33.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zengu|r
.turnin 638 >> Turn in Trollbane
.accept 639 >> Accept Sigil of Strom
.target Zengu
step
.goto Arathi Highlands,74.30,33.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drum Fel|r
.accept 678 >> Accept Call to Arms
.target Drum Fel
step
#label Arathipt2Start
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.accept 701 >> Accept Guile of the Raptor
.accept 673 >> Accept Foul Magics
.target Tor'gan
step
#loop
.goto Arathi Highlands,84.32,30.93,0
.goto Arathi Highlands,80.80,39.91,20,0
.goto Arathi Highlands,82.25,38.94,20,0
.goto Arathi Highlands,82.39,36.78,20,0
.goto Arathi Highlands,83.56,35.02,20,0
.goto Arathi Highlands,84.87,31.67,20,0
.goto Arathi Highlands,87.10,31.31,20,0
.goto Arathi Highlands,84.73,28.99,20,0
.goto Arathi Highlands,84.32,30.93,20,0
>>Kill |cRXP_ENEMY_Drywhisker Kobolds|r, |cRXP_ENEMY_Diggers|r and |cRXP_ENEMY_Surveyors|r. Loot them for their |cRXP_LOOT_Motes of Myzrael|r
.complete 642,1 
.mob Drywhisker Kobold
.mob Drywhisker Digger
.mob Drywhisker Surveyor
step
.goto Arathi Highlands,84.30,30.95
>>Click the |cRXP_PICK_Iridescent Shards|r towards the back of the cave
.turnin 642 >> Turn in The Princess Trapped
.accept 651 >> Accept Stones of Binding
step
.goto Arathi Highlands,66.70,29.80
>>Loot the |cRXP_PICK_Stone of East Binding|r for the |cRXP_LOOT_Cresting Key|r
>>|cRXP_ENEMY_Cresting Exiles|r |cRXP_WARN_have Frost Armor and Frost Nova|r
.complete 651,2 
.mob Cresting Exile
step
.goto Arathi Highlands,52.00,50.80
>>Loot the |cRXP_PICK_Stone of Outer Binding|r for the |cRXP_LOOT_Thundering Key|r
>>|cRXP_ENEMY_Thundering Exiles|r |cRXP_WARN_have powerful burst damage|r
.complete 651,3 
.mob Thundering Exile
step
.goto Arathi Highlands,25.50,30.10
>>Loot the |cRXP_PICK_Stone of West Binding|r for the |cRXP_LOOT_Burning Key|r
>>|cRXP_WARN_If you find yourself in danger, use a|r |T133438:0|t[Cresting Charm] |cRXP_WARN_on|r |cRXP_ENEMY_Burning Exiles|r
.complete 651,1 
.mob Burning Exile
.itemcount 4481,1
step
#optional
.goto Arathi Highlands,25.50,30.10
>>Loot the |cRXP_PICK_Stone of West Binding|r for the |cRXP_LOOT_Burning Key|r
.complete 651,1 
.mob Burning Exile
.itemcount 4481,<1
step
#completewith SigilofStrom
.subzone 324 >>Travel to Stromgarde Keep
step
#completewith next
>>Kill |cRXP_ENEMY_Syndicate|r. Loot them for the |cRXP_LOOT_Sigil of Strom|r
>>|cRXP_WARN_It has a very low drop rate. Be careful of respawns. Be careful of|r |cRXP_ENEMY_Syndicate Prowlers|r|cRXP_WARN_, who can net and disarm|r
.complete 639,1 
.mob Syndicate Prowler
.mob Syndicate Conjuror
.mob Syndicate Magus
.mob Syndicate Thief
step
.goto Arathi Highlands,29.45,64.39,30,0
.goto Arathi Highlands,29.63,62.95
>>Kill |cRXP_ENEMY_Marez Cowl|r. Loot her for her |cRXP_LOOT_Orb|r
>>|cRXP_WARN_She has two spawn locations in the eastern side of the keep|r
.complete 673,1 
.unitscan Marez Cowl
step
#label SigilofStrom
#loop
.goto Arathi Highlands,25.73,62.60,0
.goto Arathi Highlands,25.73,62.60,40,0
.goto Arathi Highlands,27.79,65.64,40,0
.goto Arathi Highlands,26.86,60.37,40,0
.goto Arathi Highlands,29.53,61.66,40,0
>>Kill |cRXP_ENEMY_Syndicate|r. Loot them for the |cRXP_LOOT_Sigil of Strom|r
>>|cRXP_WARN_It has a very low drop rate. Be careful of respawns. Be careful of|r |cRXP_ENEMY_Syndicate Prowlers|r|cRXP_WARN_, who can net and disarm|r
.complete 639,1 
.mob Syndicate Prowler
.mob Syndicate Conjuror
.mob Syndicate Magus
.mob Syndicate Thief
step
.goto Arathi Highlands,36.20,57.30
>>Click the |cRXP_PICK_Stone of Inner Binding|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Rumbling Exiles|r|cRXP_WARN_. Their stun has no diminishing return|r
.turnin 651 >> Turn in Stones of Binding
.accept 652 >> Accept Breaking the Keystone
step
#loop
.goto Arathi Highlands,67.3,31.1,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,21.1,36.5,50,0
.goto Arathi Highlands,26.4,30.3,50,0
.goto Arathi Highlands,26.0,45.4,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,67.3,31.1,50,0
>>Find and kill |cRXP_ENEMY_Fozruk|r. Loot him for his |cRXP_LOOT_Rod of Order|r
>>|cRXP_WARN_Don't go out of your way to finish this step, he patrols the whole zone|r
>>|cRXP_ENEMY_Fozruk|r |cRXP_WARN_is a level 42 non-elite. Kill the |cRXP_ENEMY_Kobolts|r first and then reset to make the fight easier|r
>>|cRXP_WARN_Scout for him with|r |T132172:0|t[Eagle Eye] << Hunter
>>|cRXP_WARN_Scout for him with|r |T136034:0|t[Far Sight] << Shaman
.complete 652,1 
.unitscan Fozruk
.train 6196,3 << Shaman
.train 6197,3 << Hunter
step << Shaman/Hunter
#optional
#loop
.goto Arathi Highlands,67.3,31.1,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,21.1,36.5,50,0
.goto Arathi Highlands,26.4,30.3,50,0
.goto Arathi Highlands,26.0,45.4,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,67.3,31.1,50,0
>>Find and kill |cRXP_ENEMY_Fozruk|r. Loot him for his |cRXP_LOOT_Rod of Order|r
>>|cRXP_WARN_Don't go out of your way to finish this step, he patrols the whole zone|r
>>|cRXP_ENEMY_Fozruk|r |cRXP_WARN_is a level 42 non-elite. Kill the |cRXP_ENEMY_Kobolts|r first and then reset to make the fight easier|r
.complete 652,1 
.unitscan Fozruk
.train 6196,1 << Shaman
.train 6197,1 << Hunter
step
.goto Arathi Highlands,36.07,58.09
>>Click the |cRXP_PICK_Keystone|r
.turnin 652 >> Turn in Breaking the Keystone
.accept 688 >> Accept Myzrael's Allies
.isQuestComplete 652
step
#optional
.goto Arathi Highlands,36.07,58.09
>>Click the |cRXP_PICK_Keystone|r
.accept 688 >> Accept Myzrael's Allies
.isQuestTurnedIn 652
step
#completewith next
>>Kill |cRXP_ENEMY_Highland Fleshstalkers|r. Loot them for their |cRXP_LOOT_Hearts|r
.complete 701,1 
.mob Highland Fleshstalker
step
#loop
.goto Arathi Highlands,53.68,79.95,0
.goto Arathi Highlands,52.06,74.38,50,0
.goto Arathi Highlands,53.81,74.59,50,0
.goto Arathi Highlands,53.58,76.20,50,0
.goto Arathi Highlands,54.52,78.00,15,0
.goto Arathi Highlands,53.68,79.95,20,0
>>Kill |cRXP_ENEMY_Boulderfist Brutes|r and |cRXP_ENEMY_Boulderfist Magi|r
>>|cRXP_WARN_Be careful of the Magi's Frost Armor and Frost Nova|r
>>|cFFEB144CBe **EXTREMELY CAUTIOUS** of the rare spawn "Molok the Crusher" which is a non-elite that hits for 250-450|r
.complete 678,1 
.mob +Boulderfist Brute
.complete 678,2 
.mob +Boulderfist Magus
.unitscan Molok the Crusher
step
#loop
.goto Arathi Highlands,49.71,68.69,0
.goto Arathi Highlands,52.77,63.56,70,0
.goto Arathi Highlands,50.22,65.00,70,0
.goto Arathi Highlands,49.71,68.69,70,0
.goto Arathi Highlands,48.07,74.25,70,0
.goto Arathi Highlands,46.21,76.74,70,0
.goto Arathi Highlands,46.04,79.55,70,0
.goto Arathi Highlands,48.59,80.56,70,0
>>Kill |cRXP_ENEMY_Highland Fleshstalkers|r. Loot them for their |cRXP_LOOT_Hearts|r
.complete 701,1 
.mob Highland Fleshstalker
step
#label HammerFallArrive
#completewith HammerFallVisit1
.subzone 321 >>Travel to Hammerfall
step
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 673 >> Turn in Foul Magics
.turnin 701 >> Turn in Guile of the Raptor
.accept 702 >> Accept Guile of the Raptor
.target Tor'gan
step
.goto Arathi Highlands,74.40,35.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaruk|r
.turnin 688 >> Turn in Myzrael's Allies
.accept 687 >> Accept Theldurin the Lost
.target Zaruk
.isQuestTurnedIn 652
step
.goto Arathi Highlands,72.64,33.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gor'mul|r
.turnin 702 >> Turn in Guile of the Raptor
.timer 13,Guile of the Raptor RP
.accept 847 >> Accept Guile of the Raptor
.target Gor'mul
step
.goto Arathi Highlands,73.80,33.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zengu|r
.turnin 639 >> Turn in Sigil of Strom
.accept 640 >> Accept The Broken Sigil
.target Zengu
step
.goto Arathi Highlands,74.30,33.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drum Fel|r
.turnin 678 >> Turn in Call to Arms
.accept 679 >> Accept Call to Arms
.target Drum Fel
step
.goto Arathi Highlands,74.00,33.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korin Fel|r
.accept 680 >> Accept The Real Threat
.target Korin Fel
step
.goto Arathi Highlands,73.84,32.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Adegwa|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Adegwa
.subzoneskip 321,1
.isQuestAvailable 665
step
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 847 >> Turn in Guile of the Raptor
.target Tor'gan
step
.goto Arathi Highlands,73.41,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doctor Gregory Victor|r
.accept 6622 >> Accept Triage
.target Doctor Gregory Victor
.skill firstaid,<225,1
step
.goto Arathi Highlands,73.03,36.84
.use 16991 >> |cRXP_WARN_Channel the|r |T133682:0|t[Triage Bandage] |cRXP_WARN_on the |cRXP_FRIENDLY_Horde Soldiers|r. Prioritize |cRXP_FRIENDLY_Critically Injured Soldiers|r first|r
.complete 6622,1 
.target Critically Injured Horde Soldier
.target Badly Injured Horde Soldier
.target Injured Horde Soldier
.isOnQuest 6622
step
.goto Arathi Highlands,73.41,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doctor Gregory Victor|r
.turnin 6622 >> turnin Triage
.target Doctor Gregory Victor
.isQuestComplete 6622
step
.destroy 16991 >> |cRXP_WARN_Delete the|r |T133682:0|t[Triage Bandage]|cRXP_WARN_. You no longer need it|r
.isQuestTurnedIn 6622
step
#optional
#label HammerFallVisit1
step
#optional
#completewith SigilFragments
.abandon 652
step
#completewith SigilFragments
.subzone 324 >>Travel to Stromgarde Keep
step
#completewith next
>>Kill |cRXP_ENEMY_Boulderfist Shamans|r and |cRXP_ENEMY_Boulderfist Lords|r
.complete 679,1 
.mob +Boulderfist Shaman
.complete 679,2 
.mob +Boulderfist Lord
step
.goto Arathi Highlands,18.74,66.30,30,0
.goto Arathi Highlands,19.6,66.9
>>Kill |cRXP_ENEMY_Or'Kalar|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_ENEMY_Or'Kalar|r |cRXP_WARN_can spawn in two areas around the Tower of Arathor's base|r
.complete 680,1 
.unitscan Or'Kalar
step
#loop
.goto Arathi Highlands,18.91,65.80,0
.goto Arathi Highlands,18.91,65.80,50,0
.goto Arathi Highlands,20.05,65.43,50,0
.goto Arathi Highlands,20.50,66.72,50,0
.goto Arathi Highlands,21.49,67.03,50,0
.goto Arathi Highlands,21.84,65.41,50,0
.goto Arathi Highlands,23.64,65.69,50,0
.goto Arathi Highlands,22.25,67.74,50,0
.goto Arathi Highlands,20.89,69.19,50,0
.goto Arathi Highlands,19.51,69.14,50,0
.goto Arathi Highlands,18.26,67.42,50,0
>>Kill |cRXP_ENEMY_Boulderfist Shamans|r and |cRXP_ENEMY_Boulderfist Lords|r
.complete 679,1 
.mob +Boulderfist Shaman
.complete 679,2 
.mob +Boulderfist Lord
step
#label SigilFragments
#loop
.goto Arathi Highlands,23.73,60.75,0
.goto Arathi Highlands,23.73,60.75,50,0
.goto Arathi Highlands,23.25,63.09,50,0
.goto Arathi Highlands,22.03,63.07,50,0
.goto Arathi Highlands,21.21,63.22,50,0
.goto Arathi Highlands,21.19,60.65,50,0
.goto Arathi Highlands,22.49,59.37,50,0
.goto Arathi Highlands,22.83,58.02,50,0
.goto Arathi Highlands,23.82,57.13,50,0
.goto Arathi Highlands,24.92,57.18,50,0
.goto Arathi Highlands,27.50,57.62,50,0
.goto Arathi Highlands,27.37,58.92,50,0
.goto Arathi Highlands,24.36,58.87,50,0
.goto Arathi Highlands,23.49,59.57,50,0
>>Kill |cRXP_ENEMY_Stromgarde Soldiers|r. Loot them for their |cRXP_LOOT_Sigil Fragments|r
>>|cRXP_ENEMY_Stromgarde Defenders|r |cRXP_WARN_have Shield Bash|r
.complete 640,1 
.mob Stromgarde Troll Hunter
.mob Stromgarde Defender
.mob Stromgarde Vindicator
step
#completewith next
.goto Arathi Highlands,24.48,65.09,10 >> Jump onto the metal wall alongside the castle wall
step
#completewith next
.goto Arathi Highlands,24.42,66.57,10,0
.goto Arathi Highlands,21.04,69.69,20 >> Run along the metal wall until you reach the hole in the castle wall
step
#completewith next
.goto Arathi Highlands,21.58,75.61,30,0
.goto Arathi Highlands,22.08,79.85,40 >> Run through the cave to Faldir's Cove
step
.goto Arathi Highlands,31.83,82.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lolo|r
.accept 663 >> Accept Land Ho!
.target Lolo the Lookout
step
.goto Arathi Highlands,32.28,81.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shakes O'Breen|r
.turnin 663 >> Turn in Land Ho!
.target Shakes O'Breen
step
.goto Arathi Highlands,32.78,81.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nilzlix|r
.accept 662 >> Accept Deep Sea Salvage
.target First Mate Nilzlix
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelgut|r and |cRXP_FRIENDLY_Phizzlethorpe|r
.accept 664 >> Accept Drowned Sorrows
.target +Captain Steelgut
.goto Arathi Highlands,34.00,80.79
.accept 665 >> Accept Sunken Treasure
.target +Professor Phizzlethorpe
.goto Arathi Highlands,33.87,80.55
step
.goto Arathi Highlands,35.7,79.7
>>Wait for |cRXP_FRIENDLY_Phizzlethorpe's|r roleplay, then kill the two |cRXP_ENEMY_Vengeful Surges|r that spawn.
>>|cRXP_WARN_These mobs are level 40. Get them off of| |cRXP_FRIENDLY_Phizzlethorpe|r |cRXP_WARN_as soon as you can|r
.complete 665,1 
.unitscan Vengeful Surge
step
.goto Arathi Highlands,33.8,80.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doctor Draxlegauge|r
.turnin 665 >> Turn in Sunken Treasure
.accept 666 >> Accept Sunken Treasure
.target Doctor Draxlegauge
step << !Druid !Warlock !Shaman
#ah
#completewith SLog
.aura 7178 >>|cRXP_WARN_Drink an|r |T134797:0|t[Elixir of Water Breathing]
.use 5996
.itemcount 5996,1
step
#sticky
#completewith Daggerspines
+|cRXP_ENEMY_Daggerspine Raiders|r |cRXP_WARN_have a Net ability, so be very careful of your breath if you haven't used an|r |T134797:0|t[Elixir of Water Breathing] << !Druid !Warlock !Shaman
+|cRXP_ENEMY_Daggerspine Raiders|r |cRXP_WARN_have a Net ability, so be sure to keep Water Breathing applied|r << Warlock/Shaman
+|cRXP_WARN_Use Aquatic Form when your breath gets low|r << Druid
step
#completewith ElvenGems
>>Kill |cRXP_ENEMY_Daggerspine Raiders|r and |cRXP_ENEMY_Sorceresses|r
.complete 664,1 
.mob +Daggerspine Raider
.complete 664,2 
.mob +Daggerspine Sorceress
step
#completewith SLog
>>Find |cRXP_PICK_Calcified Elven Gems|r. Loot them for |cRXP_LOOT_Elven Gems|r
.use 4491 >>|cRXP_WARN_Equip your|r |T133149:0|t[Goggles of Gem Hunting] |cRXP_WARN_to see them on your minimap|r
.complete 666,1 
step
.goto Arathi Highlands,23.40,85.09
>>Loot the |cRXP_PICK_Book|r for |cRXP_LOOT_Maiden's Folly Log|r
>>|cRXP_WARN_The log is on the ship's mid-level, towards its front|r
.complete 662,2 
step
.goto Arathi Highlands,23.04,84.51
>>Loot the |cRXP_PICK_Unfurled Parchment|r for |cRXP_LOOT_Maiden's Folly Charts|r
>>|cRXP_WARN_The charts are on the ship's mid-level, towards its center|r
.complete 662,1 
step
.goto Arathi Highlands,20.46,85.61
>>Loot the |cRXP_PICK_Unfurled Parchment|r for |cRXP_LOOT_Spirit of Silverpine Charts|r
>>|cRXP_WARN_The charts are on the ship's mid-level, towards its front, on a crate next to a cannon|r
.complete 662,3 
step
#label SLog
.goto Arathi Highlands,20.65,85.10
>>Loot the |cRXP_PICK_Book|r for |cRXP_LOOT_Spirit of Silverpine Log|r
>>|cRXP_WARN_The log is on the ship's lowest-level, towards its front, laying in dirt|r
.complete 662,4 
step
#label ElvenGems
#loop
.goto Arathi Highlands,19.30,84.10,0
.goto Arathi Highlands,19.30,84.10,50,0
.goto Arathi Highlands,17.70,89.50,50,0
.goto Arathi Highlands,25.50,90.80,50,0
.goto Arathi Highlands,24.10,85.70,50,0
.goto Arathi Highlands,23.20,89.70,50,0
>>Find |cRXP_PICK_Calcified Elven Gems|r. Loot them for |cRXP_LOOT_Elven Gems|r
.use 4491 >>|cRXP_WARN_Equip your|r |T133149:0|t[Goggles of Gem Hunting] |cRXP_WARN_to see them on your minimap|r
.complete 666,1 
step
#label Daggerspines
#loop
.goto Arathi Highlands,21.05,84.62,0
.goto Arathi Highlands,21.05,84.62,60,0
.goto Arathi Highlands,23.44,84.76,60,0
.goto Arathi Highlands,25.38,86.03,60,0
.goto Arathi Highlands,23.14,89.88,60,0
.goto Arathi Highlands,21.55,86.67,60,0
.goto Arathi Highlands,18.75,85.31,60,0
.goto Arathi Highlands,19.76,84.00,60,0
>>Finish killing |cRXP_ENEMY_Daggerspine Raiders|r and |cRXP_ENEMY_Sorceresses|r
.complete 664,1 
.mob +Daggerspine Raider
.complete 664,2 
.mob +Daggerspine Sorceress
step
#completewith next
+|cRXP_WARN_Re-equip your usual helm|r
step
.goto Arathi Highlands,32.77,81.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nilzlix|r
.turnin 662 >> Turn in Deep Sea Salvage
.target First Mate Nilzlix
step
.goto Arathi Highlands,33.86,80.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draxlegauge|r
.turnin 666 >> Turn in Sunken Treasure
.accept 668 >> Accept Sunken Treasure
.target Doctor Draxlegauge
step
.goto Arathi Highlands,34.00,80.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelgut|r
.turnin 664 >> Turn in Drowned Sorrows
.target Captain Steelgut
step
#label PiratesComplete
.goto Arathi Highlands,32.28,81.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shakes O'Breen|r
.turnin 668 >> Turn in Sunken Treasure
.accept 669 >> Accept Sunken Treasure
.target Shakes O'Breen
]])

RXPGuides.RegisterGuide([[#version 10
#wotlk
#tbc
#group RestedXP TBC Guide (H)
#subgroup RestedXP Horde 30-45
<< Horde
#name 40-41 Badlands
#next 41-43 Dustwallow Marsh part 2
step
#completewith next
.zone Wetlands >> Swim to Wetlands
step
.goto Wetlands,53.87,70.32,0
.goto Wetlands,53.87,70.32,15,0
.goto Wetlands,49.37,70.56,15,0
.goto Wetlands,48.27,67.52,25,0
.goto Wetlands,50.14,71.57,15,0
.goto Wetlands,50.18,78.30,15,0
.goto Wetlands,50.63,82.57,15,0
.goto Wetlands,55.13,83.53,15,0
.goto Loch Modan,25.27,0.04,15,0
.goto Loch Modan,25.56,10.12,15,0
.zone Loch Modan >>Travel through Dun Algaz into Loch Modan
.zoneskip Badlands
step
#completewith next
.goto Loch Modan,25.34,67.27,0
.goto Loch Modan,24.76,70.59,30,0
.goto Loch Modan,25.10,72.98,30,0
.goto Loch Modan,26.11,75.42,30,0
.goto Loch Modan,23.27,81.30,30,0
.goto Loch Modan,22.82,84.81,30,0
.goto Loch Modan,19.59,87.23,30,0
.goto Loch Modan,20.37,91.08,30,0
.goto Loch Modan,22.33,91.55,30,0
.goto Loch Modan,22.87,94.92,30,0
.goto Badlands,5.73,29.78,0
>>Use the shortcut to get to Badlands faster
.zone Badlands >> Run to the Badlands
.link https://www.youtube.com/watch?v=oNFXup-DCM0 >> CLICK HERE for a video tutorial
step
.goto Badlands,3.99,44.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fp Kargath >> Get the Kargath Flight Path
.target Gorrik
.isQuestAvailable 1419
step
.goto Badlands,2.90,47.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sranda|r
.vendor >>|cRXP_BUY_Sell your junk and repair, if necessary|r
.target Sranda
step
#optional
.goto Badlands,2.91,45.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorn|r
.accept 782 >> Accept Broken Alliances
.target Gorn
.xp <40,1
step
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal|r
.accept 2258 >> Accept Badlands Reagent Run
.target Jarkal Mossmeld
step
.goto Badlands,6.0,48.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Advisor Sarophas|r
.accept 9439 >> Accept Unclaimed Baggage
.target Advisor Sarophas
step
.goto Badlands,6.4,47.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neeka|r
.accept 1419 >> Accept Coyote Thieves
.target Neeka Bloodscar
step
#ah
.goto Badlands,25.95,44.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.accept 713 >> Accept Coolant Heads Prevail
.turnin 713 >> Turn in Coolant Heads Prevail
.target Lotwil Veriatus
.itemcount 3829,1 
step
#ah
.goto Badlands,25.95,44.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.accept 714 >> Accept Gyro... What?
.turnin 714 >> Turn in Gyro... What?
.target Lotwil Veriatus
.itemcount 4389,1 
.isQuestTurnedIn 713
step
.goto Badlands,25.95,44.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.accept 710 >> Accept Study of the Elements: Rock
.target Lotwil Veriatus
step
#ah
.goto Badlands,25.82,44.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucien|r
.accept 715 >> Accept Liquid Stone
.turnin 715 >> Turn in Liquid Stone
.target Lucien Tosselwrench
.itemcount 929,1 
.itemcount 3823,1 
.isQuestTurnedIn 714
step
#completewith AngorFortress
>>While questing, kill any |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r you encounter. Loot them for their |cRXP_LOOT_Wings|r, |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.collect 3404,4,703,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#loop
.goto Badlands,23.41,45.26,0
.goto Badlands,23.41,45.26,50,0
.goto Badlands,21.90,43.22,50,0
.goto Badlands,19.99,43.10,50,0
.goto Badlands,17.76,41.06,50,0
.goto Badlands,16.62,38.29,50,0
.goto Badlands,14.78,37.34,50,0
.goto Badlands,13.48,37.80,50,0
.goto Badlands,13.01,40.09,50,0
.goto Badlands,15.11,41.89,50,0
.goto Badlands,16.94,42.80,50,0
.goto Badlands,19.17,45.74,50,0
.goto Badlands,20.47,48.40,50,0
.goto Badlands,23.12,48.20,50,0
>>Kill |cRXP_ENEMY_Earth Elementals|r. Loot them for their |cRXP_LOOT_Stone Shards|r and |cRXP_LOOT_Elemental Shards|r
.complete 710,1 
.complete 2258,3 
.mob Lesser Rock Elemental
step
.goto Badlands,25.95,44.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil Veriatus|r
.turnin 710 >> Turn in Study of the Elements: Rock
.accept 711 >> Accept Study of the Elements: Rock
.target Lotwil Veriatus
step
#label AngorFortress
#completewith next
.goto Badlands,42.9,29.9,30 >> Enter Angor Fortress
step
>>Loot the |cRXP_PICK_Weapon Rack|r for the |cRXP_LOOT_Advisor's Rapier|r
>>Loot the |cRXP_PICK_Empty Barrel|r for the |cRXP_LOOT_Advisor's Pack|r
.complete 9439,2 
.goto Badlands,41.67,26.93
.complete 9439,1 
.goto Badlands,41.07,29.25
step
#completewith BrokenAlliance
#label signofearthBL
>>Find & kill |cRXP_ENEMY_Boss Tho'grun|r. Loot him for the |cRXP_LOOT_Sign of Earth|r
>>|cRXP_ENEMY_Boss Tho'grun|r |cRXP_WARN_patrols the zone, accompanied by five guards|r
.complete 782,1 
.unitscan Boss Tho'grun
.isOnQuest 782
step
#optional
#completewith InduriumFlakes
>>While questing, kill any |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r you encounter. Loot them for their |cRXP_LOOT_Wings|r, |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.collect 3404,4,703,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#completewith BarbWings
.goto Badlands,42.47,52.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jazzrik|r
.vendor >>|cRXP_BUY_Sell your junk and repair, if necessary|r
.target Jazzrik
step
#ah
.goto Badlands,42.39,52.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r
.accept 705 >> Accept Pearl Diving
.turnin 705 >> Turn in Pearl Diving
.target Rigglefuzz
.itemcount 4611,9 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r and |cRXP_FRIENDLY_Martek|r
.accept 703 >> Accept Barbecued Buzzard Wings
.target +Rigglefuzz
.goto Badlands,42.39,52.92
.turnin 1106 >> Turn in Martek the Exiled
.accept 1108 >> Accept Indurium
.target +Martek the Exiled
.goto Badlands,42.21,52.70
.isOnQuest 1106
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r and |cRXP_FRIENDLY_Martek|r
.accept 703 >> Accept Barbecued Buzzard Wings
.target +Rigglefuzz
.goto Badlands,42.39,52.92
.accept 1108 >> Accept Indurium
.target +Martek the Exiled
.goto Badlands,42.21,52.70
.isQuestTurnedIn 1106
step
#label BarbWings
.goto Badlands,42.39,52.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r
.turnin 703 >> Turn in Barbecued Buzzard Wing
.target Rigglefuzz
.isQuestComplete 703
step
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin|r
.turnin 687 >> Turn in Theldurin the Lost
.accept 709 >> Accept Solution to Doom
.target Theldurin the Lost
.isQuestTurnedIn 652
step
#optional
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin|r
.accept 709 >> Accept Solution to Doom
.target Theldurin the Lost
step
#label InduriumFlakes
#loop
.goto Badlands,47.16,69.82,0
.goto Badlands,47.16,69.82,50,0
.goto Badlands,48.38,72.06,50,0
.goto Badlands,49.86,72.12,50,0
.goto Badlands,51.20,71.93,50,0
.goto Badlands,52.41,69.96,50,0
.goto Badlands,52.55,67.79,50,0
.goto Badlands,52.46,65.90,50,0
.goto Badlands,51.00,63.86,50,0
.goto Badlands,49.66,63.97,50,0
.goto Badlands,49.69,66.39,50,0
.goto Badlands,49.78,68.28,50,0
.goto Badlands,48.14,68.30,50,0
>>Kill |cRXP_ENEMY_Stonevault Troggs|r. Loot them for their |cRXP_LOOT_Indurium Flakes|r
.complete 1108,1 
.mob Stonevault Bonesnapper
.mob Stonevault Shaman
step
#loop
.goto Badlands,36.20,75.10,0
.goto Badlands,36.20,75.10,50,0
.goto Badlands,46.00,78.40,50,0
.goto Badlands,42.80,87.20,50,0
>>Kill |cRXP_ENEMY_Rock Elementals|r. Loot them for their |cRXP_LOOT_Stone Slabs|r
>>|cRXP_ENEMY_Rock Elementals|r |cRXP_WARN_are abundant in this southern location, but the northern location from the prior elemental quest has a few as well|r
.complete 711,1 
.mob Rock Elemental
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Coyotes|r. Loot them for their |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#loop
.goto Badlands,17.24,58.53,0
.goto Badlands,17.24,58.53,50,0
.goto Badlands,15.35,58.51,50,0
.goto Badlands,14.85,60.16,50,0
.goto Badlands,15.00,61.98,50,0
.goto Badlands,16.15,61.84,50,0
.goto Badlands,17.01,61.24,50,0
>>Kill |cRXP_ENEMY_Buzzards|r. Loot them for their |cRXP_LOOT_Wings|r and |cRXP_LOOT_Gizzards|r
.collect 3404,4,703,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 2258,1 
.disablecheckbox
step
#optional
#completewith EnterUldaCave
>>Kill |cRXP_ENEMY_Coyotes|r and |cRXP_ENEMY_Buzzards|r. Loot them for their |cRXP_LOOT_Jawbones|r, |cRXP_LOOT_Fangs|r and |cRXP_LOOT_Gizzards|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r and |cRXP_FRIENDLY_Martek|r
.turnin 703 >> Turn in Barbecued Buzzard Wing
.target +Rigglefuzz
.goto Badlands,42.39,52.92
.turnin 1108 >> Turn in Indurium
.target +Martek the Exiled
.goto Badlands,42.21,52.70
step
#label EnterUldaCave
#completewith GFamilyChest
.goto Eastern Kingdoms,52.40,63.61,30 >>Travel to Uldaman and enter the cave
.subzoneskip 1337
step
#requires EnterUldaCave
#completewith Tablet
>>Kill |cRXP_ENEMY_Shadowforge Dwarves|r and |cRXP_ENEMY_Stonevault Troggs|r for a chance of getting a |T133289:0|t[|cRXP_LOOT_Shattered Necklace|r]
.collect 7666,1,2283,1 
step
#requires EnterUldaCave
#label Tablet
.goto Eastern Kingdoms,52.06,63.81,20,0
.goto Eastern Kingdoms,52.11,64.01
>>Loot the |cRXP_PICK_Ancient Chest|r in the middle of the room for the |cRXP_LOOT_Tablet of Ryun'eh|r
.complete 709,1 
step
#requires EnterUldaCave
#label GFamilyChest
.goto Eastern Kingdoms,51.78,63.77,15,0
.goto Eastern Kingdoms,51.72,63.73,15,0
.goto Eastern Kingdoms,51.68,63.81,15,0
.goto Eastern Kingdoms,51.80,64.00
>>Loot the |cRXP_PICK_Garret Family Chest|r in the southern corner of the South Common Hall for the |cRXP_LOOT_Garrett Family Treasure|r
>>|cRXP_WARN_The South Common Hall is southwest of the Uldaman instance portal|r
.complete 2342,1 
.isOnQuest 2342
step
#label ExitCave
#completewith DoomSolved
.goto Eastern Kingdoms,52.40,63.61,30 >>Exit the cave
step
#requires ExitCave
#optional
#completewith ElementRock2TI
>>Finish killing |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r. Loot them for their |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#requires ExitCave
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin the Lost|r
.turnin 709 >> Turn in Solution to Doom
.target Theldurin the Lost
.isQuestComplete 709
step << skip
#optional
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin the Lost|r
.accept 728 >> Accept To the Undercity for Yagyin's Digest
.target Theldurin the Lost
.isQuestTurnedIn 709
step
#optional
#label DoomSolved
step
#label ElementRock2TI
.goto Badlands,25.95,44.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.turnin 711 >> Turn in Study of the Elements: Rock
.target Lotwil Veriatus
step
#loop
.goto Badlands,30.28,62.70,0
.goto Badlands,44.11,71.87,90,0
.goto Badlands,37.09,69.28,90,0
.goto Badlands,30.28,62.70,90,0
.goto Badlands,25.09,55.10,90,0
.goto Badlands,44.11,71.87,90,0
.goto Badlands,37.09,69.28,90,0
.goto Badlands,30.28,62.70,90,0
>>Finish killing |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r. Loot them for their |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#sticky
#completewith EnterUldaman
.subzone 1337,2 >> Now you should be looking for a group to Uldaman
.dungeon ULDA
step
#label KargathVisit2
#completewith KargathTurnins
.subzone 340 >>Travel to Kargath
step
.goto Badlands,6.0,48.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Advisor Sarophas|r
.turnin 9439 >> Turn in Unclaimed Baggage
.target Advisor Sarophas
step
.goto Badlands,6.49,47.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neeka|r
.turnin 1419 >> Turn in Coyote Thieves
.target Neeka Bloodscar
step
#label BrokenAlliance
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal|r
.turnin 2258 >> Turn in Badlands Reagent Run
.target Jarkal Mossmeld
step
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal Mossmeld|r
.accept 2202 >> Accept Uldaman Reagent Run
.target Jarkal Mossmeld
.isQuestTurnedIn 2258
.dungeon ULDA
step
>>Find & kill |cRXP_ENEMY_Boss Tho'grun|r. Loot him for the |cRXP_LOOT_Sign of Earth|r
>>|cRXP_ENEMY_Boss Tho'grun|r |cRXP_WARN_patrols the zone, accompanied by five guards|r
>>|cRXP_WARN_Skip this step if you cannot find him|r
.complete 782,1 
.unitscan Boss Tho'grun
.isOnQuest 782
step
#label KargathTurnins
.goto Badlands,2.91,45.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorn|r
.turnin 782 >> Turn in Broken Alliances
.target Gorn
.isQuestComplete 782
step
.goto Eastern Kingdoms,54.49,57.77
.zone 1415 >> Travel to Uldaman
.dungeon ULDA
step
#completewith EnterUldaman
>>Loot the |cRXP_LOOT_Magenta Fungus Caps|r on the ground
>>|cRXP_WARN_This can be completed INSIDE and OUTSIDE of Uldaman.|r
>>|cRXP_WARN_It is recommended that maximum 3 players attempt to complete this quest if you're doing only 1 run. There aren't enough|r |cRXP_LOOT_Magenta Fungus Caps|rr |cRXP_WARN_for everybody|r
.complete 2202,1 
.isOnQuest 2202
.dungeon ULDA
step
#label EnterUldaman
.goto Eastern Kingdoms,53.85,57.68
.subzone 1337,2 >> Zone into Uldaman
.dungeon ULDA
step
>>Kill |cRXP_ENEMY_Archaedas|r
>>Click |cRXP_PICK_The Discs of Norgannon|r
.accept 2278 >> Accept The Platinum Discs
.mob Archaedas
.dungeon ULDA
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lore Keeper of Norgannon|r
.complete 2278,1 
.skipgossip
.target Lore Keeper of Norgannon
.dungeon ULDA
step
>>Click |cRXP_PICK_The Discs of Norgannon|r
.turnin 2278 >> Turn in The Platinum Discs
.accept 2280 >> Accept The Platinum Discs
.dungeon ULDA
step
#completewith next
.zone Badlands >>Leave Uldaman
.dungeon ULDA
step
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal Mossmeld|r
.turnin 2202 >> Turn in Uldaman Reagent Run
.target Jarkal Mossmeld
.dungeon ULDA
.isQuestComplete 2202
step
#optional
#completewith HammerFallFinalTurnIns
.abandon 782 >>Abandon Broken Alliances
step
#completewith HammerFallFinalTurnIns
.goto Badlands,3.99,44.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fly Hammerfall >> Fly to Hammerfall
.target Gorrik
.zoneskip Arathi Highlands
step
.goto Arathi Highlands,74.25,33.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drum Fel|r
.turnin 679 >> Turn in Call to Arms
.target Drum Fel
step
.goto Arathi Highlands,74.00,33.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korin Fel|r
.turnin 680 >> Turn in The Real Threat
.target Korin Fel
step
#label HammerFallFinalTurnIns
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 640 >> Turn in The Broken Sigil
.target Tor'gan
step << Druid
#completewith DruidTraining4
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9634 >> Train your class spells
.target Loganaar
.xp <40,1
.xp >42,1
step << Druid
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9750 >> Train your class spells
.target Loganaar
.xp <40,1
.xp >42,1
step << Druid
#label DruidTraining4
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 22812 >> Train your class spells
.target Loganaar
.xp <44,1
step << Mage
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
.train 3567,3
step
#optional << Mage
#completewith next << !Mage
.hs >> Hearth to Orgrimmar
.use 6948
.bindlocation 1637,1
.zoneskip Orgrimmar
.train 3567,1 << Mage
step << !Mage
.goto Orgrimmar,54.65,67.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barkeep Morag|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Barkeep Morag
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8423 >> Train your class spells
.target Pephredo
.xp <40,1
.xp >42,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10159 >> Train your class spells
.target Pephredo
.xp <42,1
.xp >44,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10185 >> Train your class spells
.target Pephredo
.xp <44,1
step << Mage
.goto Orgrimmar,38.70,85.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r at the top of the hut
.train 11417 >> Train |T135744:0|t[Portal: Orgrimmar]
.target Thuul
.xp <40,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 8134 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
.xp >42,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 11314 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
.xp >42,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10392 >> Train your class spells
.target Kardris Dreamseeker
.xp <44,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <40,1
.xp >42,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <42,1
.xp >44,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11341 >> Train |T11341:0|t[Instant Poison IV]
.target Ormok
.xp <44,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11665 >> Train your class spells
.target Mirket
.xp <40,1
.xp >42,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 6789 >> Train your class spells
.target Mirket
.xp <42,1
.xp >44,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11671 >> Train your class spells
.target Mirket
.xp <44,1
step << Warlock
.goto Orgrimmar,47.52,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurgul|r
.vendor >>Buy any pet upgrades you can afford
.target Kurgul
.zoneskip Orgrimmar,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14324 >> Train your class spells
.target Ormak Grimshot
.xp <40,1
.xp >42,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14289 >> Train your class spells
.target Ormak Grimshot
.xp <42,1
.xp >44,1
step << Hunter
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 13542 >> Train your class spells
.target Ormak Grimshot
.xp <44,1
step << Hunter
#optional
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 14925 >> Train your pet spells
.target Xao'tsu
.xp <40,1
.xp >42,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24561 >> Train your pet spells
.target Xao'tsu
.xp <42,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 8106 >> Train your class spells
.target Ur'kyo
.xp <40,1
.xp >42,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 8106 >> Train your class spells
.target Ur'kyo
.xp <42,1
.xp >44,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10927 >> Train your class spells
.target Ur'kyo
.xp <44,1
step
.goto Orgrimmar,59.4,36.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dran|r
.accept 2283 >> Accept Necklace Recovery
.turnin 2283 >> Turn in Necklace Recovery
.target Dran Droffers
.itemcount 7666,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11608 >> Train your class spells
.target Grezz Ragefist
.xp <40,1
.xp >42,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11550 >> Train your class spells
.target Grezz Ragefist
.xp <42,1
.xp >44,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11584 >> Train your class spells
.target Grezz Ragefist
.xp <44,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20922 >> Train your class spells
.target Master Pyreanor
.xp <40,1
.xp >42,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20307 >> Train your class spells
.target Master Pyreanor
.xp <42,1
.xp >44,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 24275 >> Train your class spells
.target Master Pyreanor
.xp <44,1
step << Hunter
.goto Orgrimmar,78.08,38.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Jin'sora|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from him if it's available|r
.target Jin'sora
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
.itemcount 11307,<1
step << Orc !Warlock
#optional
.goto Orgrimmar,69.40,13.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kildar|r and |cRXP_FRIENDLY_Ogunaro|r
.train 825 >>Train |T136103:0|t[Wolf Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132224:0|t[|cFF0070FFWolf|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Kildar
.target Ogunaro Wolfrunner
step << Troll
#optional
#completewith next
.subzone 367 >> Travel to Sen'Jin Village
.xp <30,1
.money <38
.skill riding,75,1
step << Troll
#optional
.goto Durotar,55.28,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xar'Ti|r and |cRXP_FRIENDLY_Zjolnir|r
.train 10861 >>Train |T136103:0|t[Raptor Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132253:0|t[|cFF0070FFRaptor|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Xar'Ti
.target Zjolnir
step
#completewith ThunderBluffVisit3
.goto Orgrimmar,45.13,63.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.zoneskip Thunder Bluff
.target Doras
step << Hunter
.goto Thunder Bluff,46.98,45.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuna Thunderhorn|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from her if it's available|r
.target Kuna Thunderhorn
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
.itemcount 11307,<1
step << Shaman
#ah
.goto Thunder Bluff,53.00,56.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Kard|r|cRXP_BUY_. Buy a|r |T135341:0|t[Rondel] |cRXP_BUY_from him for your off-hand|r
>>|cRXP_WARN_Alternatively, buy a better one handed weapon from the AH|r
.collect 2534,1,11201,1 
.money <4.0888
.target Kard Ragetotem
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
step << Shaman
#ssf
.goto Thunder Bluff,53.00,56.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Kard|r|cRXP_BUY_. Buy a|r |T135341:0|t[Rondel] |cRXP_BUY_from him for your off-hand|r
.collect 2534,1,11201,1 
.money <4.0888
.target Kard Ragetotem
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
step << Shaman
#ah
.goto Thunder Bluff,54.06,57.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Delgo|r|cRXP_BUY_. Buy a|r |T132392:0|t[Francisca] |cRXP_BUY_from him|r
>>|cRXP_WARN_Alternatively, buy a better one handed weapon from the AH|r
.money <4.1776
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.8
.target Delgo Ragetotem
step << Shaman
#ssf
.goto Thunder Bluff,54.06,57.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Delgo|r|cRXP_BUY_. Buy a|r |T132392:0|t[Francisca] |cRXP_BUY_from him|r
.money <4.1776
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.8
.target Delgo Ragetotem
step
.goto Thunder Bluff,61.40,80.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melor|r
.turnin 1136 >> Turn in Frostmaw
.accept 1205 >> Accept Deadmire
.target Melor Stonehoof
.isQuestComplete 1136
step
#optional
#completewith ThunderBluffVisit3
.destroy 5838 >>|cRXP_WARN_Destroy the|r |T134252:0|t[Kodo Skin Scroll] |cRXP_WARN_as you no longer need it|r
step
#optional
.goto Thunder Bluff,61.40,80.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melor|r
.accept 1205 >> Accept Deadmire
.target Melor Stonehoof
step
#label ThunderBluffVisit3
.goto Thunder Bluff,54.00,80.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mosarn|r
.turnin 1276 >> Turn in The Black Shield
.accept 11204 >> Accept Return to Krog
.target Mosarn
step << !Undead 
.goto Thunder Bluff,34.42,46.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage|r
.turnin 1049 >>Turn in Compendium of the Fallen
.target Sage
.dungeon SM
.isQuestComplete 1049
step << Mage
.goto Thunder Bluff,22.48,16.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Birgitte|r
.train 3566 >> Train |T135765:0|t[Teleport: Thunder Bluff]
.target Birgitte Cranston
step << !Undead
#optional
.abandon 1049 >> Compendium of the Fallen
.isOnQuest 1049
.dungeon SM
step << Tauren
#optional
#completewith next
.subzone 222 >> Travel to Bloodhoof Village
.xp <30,1
.money <38
.skill riding,75,1
step << Tauren
#optional
#label KodoRiding
.goto Mulgore,47.64,58.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xar'Ti|r and |cRXP_FRIENDLY_Zjolnir|r
.train 132245 >>Train |T136103:0|t[Kodo Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132253:0|t[|cFF0070FFKodo|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Kar Stormsinger
.target Harb Clawhoof
step << Tauren
#optional
.subzone 378 >>Travel to Camp Taurajo
.skill riding,<75,1
.zoneskip Thunder Bluff
.dungeon !RFD
]])

RXPGuides.RegisterGuide([[#version 10
#wotlk
#tbc
#group RestedXP TBC Guide (H)
#subgroup RestedXP Horde 30-45
<< Horde
#name 41-43 Dustwallow Marsh part 2
#next 43-45 Lower Stranglethorn Vale
step << Tauren
#label FlyDWM1
#completewith DWM2Start
.goto The Barrens,44.45,59.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Omusa|r
.fly Brackenwall Village >>Fly to Brackenwall Village
.target Omusa Thunderhorn
.zoneskip Thunder Bluff
step
#label FlyDWM2
#completewith DWM2Start
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Brackenwall Village >>Fly to Brackenwall Village
.target Tal
.zoneskip Thunder Bluff,1 << Tauren
step
.goto Dustwallow Marsh,36.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overlord Mok'Morokk|r
.accept 1166 >> Accept Overlord Mok'Morokk's Concern
.target Overlord Mok'Morokk
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 11204 >> Turn in Return to Krog
.accept 11200 >> Accept More than Coincidence
.accept 11201 >> Accept The Grimtotem Plot
.target Krog
step
.goto Dustwallow Marsh,36.89,32.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Little" Logok|r
.home >> Set your Hearthstone to Brackenwall Village
.target "Little" Logok
.bindlocation 496
.isQuestAvailable 11162
step
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.accept 1169 >> Accept Identifying the Brood
.target Draz'Zilb
step
.goto Dustwallow Marsh,37.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharg|r
.accept 1168 >> Accept Army of the Black Dragon
.target Tharg
step
#label DWM2Start
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.accept 11213 >> Accept Check Up on Tabetha
.accept 11215 >> Accept Help Mudsprocket
.target Nazeer Bloodpike
step
#completewith next
>>Loot |cRXP_LOOT_Blackhoof Armaments|r on the ground
.complete 11200,1 
step
#label GrimtotemNotes
#loop
.goto Dustwallow Marsh,40.82,12.17,0
.goto Dustwallow Marsh,43.03,14.79,40,0
.goto Dustwallow Marsh,42.19,13.71,40,0
.goto Dustwallow Marsh,40.82,12.17,40,0
.goto Dustwallow Marsh,41.02,10.56,40,0
.goto Dustwallow Marsh,42.37,11.55,40,0
>>Kill |cRXP_ENEMY_Grimtotem Elders|r. Loot them for their |T134328:0|t[|cRXP_LOOT_Grimtotem Notes|r]
.collect 33050,4,11201,1 
.mob Grimtotem Elder
step
#requires GrimtotemNotes
.use 33050 >>|cRXP_WARN_Use the|r |T134328:0|t[|cRXP_LOOT_Grimtotem Notes|r] |cRXP_WARN_to create the|r |T134331:0|t[|cRXP_LOOT_Grimtotem Battle Plan|r]
.complete 11201,1 
step
#loop
.goto Dustwallow Marsh,42.88,15.50,0
.goto Dustwallow Marsh,41.66,12.92,30,0
.goto Dustwallow Marsh,41.43,10.79,30,0
.goto Dustwallow Marsh,42.32,11.22,30,0
.goto Dustwallow Marsh,42.88,15.50,30,0
.goto Dustwallow Marsh,44.81,17.71,30,0
>>Loot |cRXP_LOOT_Blackhoof Armaments|r on the ground
.complete 11200,1 
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 11200 >> Turn in More than Coincidence
.turnin 11201 >> Turn in The Grimtotem Plot
.accept 11203 >> Accept Seek Out Tabetha
.target Krog
step
.goto Dustwallow Marsh,35.20,38.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mudcrush|r
.turnin 1177 >> Turn in Hungry!
.target Mudcrush Durtfeet
step
#completewith next
.subzone 4049 >>Travel to Tabetha's Farm
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r and |cRXP_FRIENDLY_Apprentice Garion|r
.turnin 11203 >> Turn in Seek Out Tabetha
.turnin 11213 >> Turn in Check Up on Tabetha
.accept 11205 >> Accept Raze Direhorn Post!
.target +Tabetha
.goto Dustwallow Marsh,46.02,57.10
.accept 11169 >> Accept The Grimtotem Weapon
.accept 11173 >> Accept The Reagent Thief
.target +Apprentice Garion
.goto Dustwallow Marsh,46.05,57.25
step
.goto Dustwallow Marsh,46.10,57.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Morlann|r outside
.accept 11156 >> Accept Direhorn Raiders
.accept 11172 >> Accept The Zeppelin Crash
.target Apprentice Morlann
step
.goto Dustwallow Marsh,53.57,56.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moxie Steelgrille|r
.turnin 11172 >> Turn in The Zeppelin Crash
.accept 11174 >> Accept Corrosion Prevention
.accept 11207 >> Accept Secure the Cargo!
.target Moxie Steelgrille
step
#completewith SeafBooster
.use 33108 >>|cRXP_WARN_Use the|r |T133000:0|t[Ooze Buster] |cRXP_WARN_on|r |cRXP_ENEMY_Swamp Oozes|r
>>|cRXP_WARN_This can only be used when you are|r |T136048:0|t[Energized!] |cRXP_WARN_. Stand near a |cRXP_PICK_Power Core Fragment|r to obtain the buff|r
.complete 11174,1 
.mob Acidic Swamp Ooze
.mob Bubbling Swamp Ooze
step
#completewith ElectricOozes
>>Loot |cRXP_LOOT_Zeppelin Cargo|r on the ground
.complete 11207,1 
step
#label SeafBooster
.goto Dustwallow Marsh,54.10,56.50
>>Loot the |cRXP_PICK_Crate|r on the ground near the crashed Zeppelin for the |cRXP_LOOT_Seaforium Booster|r
.complete 1187,1 
step
#label ElectricOozes
#loop
.goto Dustwallow Marsh,53.73,55.87,0
.goto Dustwallow Marsh,52.94,51.98,0
.goto Dustwallow Marsh,51.98,55.52,0
.goto Dustwallow Marsh,51.61,58.59,0
.goto Dustwallow Marsh,53.73,55.87,50,0
.goto Dustwallow Marsh,52.94,51.98,50,0
.goto Dustwallow Marsh,51.98,55.52,50,0
.goto Dustwallow Marsh,51.61,58.59,50,0
.use 33108 >>|cRXP_WARN_Use the|r |T133000:0|t[Ooze Buster] |cRXP_WARN_on|r |cRXP_ENEMY_Swamp Oozes|r
>>|cRXP_WARN_This can only be used when you are|r |T136048:0|t[Energized!] |cRXP_WARN_. Stand near a |cRXP_PICK_Power Core Fragment|r to obtain the buff|r
.complete 11174,1 
.mob Acidic Swamp Ooze
.mob Bubbling Swamp Ooze
step
#loop
.goto Dustwallow Marsh,52.71,52.58,0
.goto Dustwallow Marsh,52.71,52.58,50,0
.goto Dustwallow Marsh,51.73,51.54,50,0
.goto Dustwallow Marsh,51.37,52.65,50,0
.goto Dustwallow Marsh,50.86,55.91,50,0
.goto Dustwallow Marsh,51.07,59.02,50,0
.goto Dustwallow Marsh,49.75,60.45,50,0
.goto Dustwallow Marsh,51.39,60.93,50,0
.goto Dustwallow Marsh,52.76,59.12,50,0
.goto Dustwallow Marsh,54.53,56.71,50,0
.goto Dustwallow Marsh,54.59,54.62,50,0
>>Loot |cRXP_LOOT_Zeppelin Cargo|r on the ground
.complete 11207,1 
step
.goto Dustwallow Marsh,53.57,56.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moxie Steelgrille|r
.turnin 11174 >> Turn in Corrosion Prevention
.turnin 11207 >> Turn in Secure the Cargo!
.accept 11208 >> Accept Delivery for Drazzit
.target Moxie Steelgrille
step
#loop
.goto Dustwallow Marsh,56.51,61.15,0
.goto Dustwallow Marsh,56.51,61.15,50,0
.goto Dustwallow Marsh,55.46,61.60,50,0
.goto Dustwallow Marsh,54.80,62.41,50,0
.goto Dustwallow Marsh,54.31,63.24,50,0
.goto Dustwallow Marsh,54.68,64.41,50,0
.goto Dustwallow Marsh,56.10,65.14,50,0
.goto Dustwallow Marsh,56.52,63.62,50,0
.goto Dustwallow Marsh,56.81,62.56,50,0
.goto Dustwallow Marsh,57.30,60.20,50,0
>>Kill |cRXP_ENEMY_Muckshell Makruras|r on the beach. Loot them for a |cRXP_LOOT_Jeweled Pendant|r
.complete 1261,1 
.isOnQuest 1261
.mob Muckshell Razorclaw
.mob Muckshell Clacker
.mob Muckshell Scrabbler
.mob Muckshell Pincer
.mob Muckshell Snapclaw
.unitscan Lord Angler
step
#completewith DireGrims
.subzone 4046 >> Travel to Direhorn Post
step
#completewith DireGrims
.use 33115 >>Kill |cRXP_ENEMY_Apothecary Cylla|r. Loot her for the |T133472:0|t[|cRXP_LOOT_Sealed Letter|r]. Use it to accept the quest
.collect 33115,1,11186 
.accept 11186 >> Accept Signs of Treachery?
.unitscan Apothecary Cylla
step
#completewith next
>>Kill |cRXP_ENEMY_Grimtotem Earthbinders|r and |cRXP_ENEMY_Grimtotem Destroyers|r
.complete 11156,1 
.mob Grimtotem Earthbinder
.mob Grimtotem Destroyer
step
.use 33072 >>|cRXP_WARN_Use|r |T135432:0|t[Tabetha's Torch] |cRXP_WARN_in the |cRXP_ENEMY_Grimtotem|r tents|r
.complete 11205,1 
.goto Dustwallow Marsh,46.62,46.04
.complete 11205,2 
.goto Dustwallow Marsh,47.23,46.59
.complete 11205,3 
.goto Dustwallow Marsh,47.41,47.54
step
#label DireGrims
#loop
.goto Dustwallow Marsh,46.64,49.08,0
.goto Dustwallow Marsh,46.64,49.08,40,0
.goto Dustwallow Marsh,46.07,47.06,40,0
.goto Dustwallow Marsh,47.09,45.39,40,0
.goto Dustwallow Marsh,47.26,47.90,40,0
>>Kill |cRXP_ENEMY_Grimtotem Earthbinders|r and |cRXP_ENEMY_Grimtotem Destroyers|r
.complete 11156,1 
.mob Grimtotem Earthbinder
.mob Grimtotem Destroyer
step
.goto Dustwallow Marsh,47.22,46.59
.use 33115 >>Kill |cRXP_ENEMY_Apothecary Cylla|r. Loot her for the |T133472:0|t[|cRXP_LOOT_Sealed Letter|r]. Use it to accept the quest
.collect 33115,1,11186 
.accept 11186 >> Accept Signs of Treachery?
.unitscan Apothecary Cylla
step
#completewith MudsprocketVisit1
.use 33101 >>|cRXP_WARN_Use the|r |T136008:0|t[Captured Totem] |cRXP_WARN_within The Quagmire|r
>>Kill |cRXP_ENEMY_Mottled Drywallow Crocolisks|r and |cRXP_ENEMY_Drywall Snapper|r near the totem
.complete 11169,1 
.mob Mottled Drywallow Crocolisk
.mob Drywall Snapper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r
.turnin 11205 >> Turn in Raze Direhorn Post!
.accept 11206 >> Accept Justice Dispensed
.target Tabetha
.goto Dustwallow Marsh,46.02,57.09
step
.goto Dustwallow Marsh,46.021,57.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r
.accept 2846 >> Accept Tiara of the Deep
.target Tabetha
.dungeon ZF
step
.goto Dustwallow Marsh,46.10,57.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Morlann|r outside
.turnin 11156 >>Turn in Direhorn Raiders
.target Apprentice Morlann
step
#label MudsprocketVisit1
#completewith next
.subzone 4010 >>Travel to Mudsprocket
step
#completewith Mudsprocket1
.goto Dustwallow Marsh,42.82,72.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dyslix Silvergrub|r
.fp >> Get the Mudsprocket flight path
.target Dyslix Silvergrub
step
.goto Dustwallow Marsh,42.33,72.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazzit Dripvalve|r
.turnin 11215 >> Turn in Help Mudsprocket
.turnin 11208 >> Turn in Delivery for Drazzit
.target Drazzit Dripvalve
step
.goto Dustwallow Marsh,41.75,73.11
>>Click |cRXP_PICK_the Wanted Poster|r
.accept 11184 >> Accept WANTED: Goreclaw the Ravenous
step
.goto Dustwallow Marsh,41.55,73.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gizzix Grimegurgle|r
.accept 11217 >>Accept Catch a Dragon by the Tail
.target Gizzix Grimegurgle
step
#label Mudsprocket1
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.accept 11158 >>Accept Bloodfen Feathers
.target Brogg
step
#completewith next
>>Kill |cRXP_ENEMY_Bloodfen Raptors|r. Loot them for their |cRXP_LOOT_Feathers|r
.complete 11158,1 
.mob Bloodfen Razormaw
.mob Bloodfen Lashtail
step
.goto Dustwallow Marsh,32.07,65.55
>>Kill |cRXP_ENEMY_Goreclaw the Ravenous|r
.complete 11184,1 
.mob Goreclaw the Ravenous
step
#loop
.goto Dustwallow Marsh,32.96,64.37,0
.goto Dustwallow Marsh,32.96,64.37,50,0
.goto Dustwallow Marsh,34.51,65.20,50,0
.goto Dustwallow Marsh,34.86,66.62,50,0
.goto Dustwallow Marsh,36.84,66.08,50,0
.goto Dustwallow Marsh,37.73,70.28,50,0
>>Kill |cRXP_ENEMY_Bloodfen Raptors|r. Loot them for their |cRXP_LOOT_Feathers|r
.complete 11158,1 
.mob Bloodfen Razormaw
.mob Bloodfen Lashtail
step
#completewith MudTurnins1
.subzone 4010 >>Return to Mudsprocket
step
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11158 >> Turn in Bloodfen Feathers
.accept 11160 >> Accept Banner of the Stonemaul
.accept 11161 >> Accept The Essence of Enmity
.target Brogg
step
#label MudTurnins1
.goto Dustwallow Marsh,42.33,72.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazzit Dripvalve|r
.turnin 11184 >> Turn in WANTED: Goreclaw the Ravenous
.target Drazzit Dripvalve
step
#completewith ScalebaneCave
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#completewith Dragondeez
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
>>|cRXP_WARN_Use|r |T136021:0|t[Brogg's Totem] |cRXP_WARN_on their corpses|r |cRXP_WARN_to collect|r |cRXP_LOOT_Black Dragonkin Essence|r
.complete 1168,1 
.mob +Firemane Scout
.complete 1168,2 
.mob +Firemane Ash Tail
.complete 11161,1 
.mob +Firemane Scout
.mob +Firemane Ash Tail
step
.goto Dustwallow Marsh,38.70,65.60
>>Loot the |cRXP_PICK_Vase|r on the ground for |cRXP_LOOT_Mok'Morokk's Grog|r
.complete 1166,2 
step
#label ScalebaneCave
#completewith Dragondeez
.goto Dustwallow Marsh,38.31,66.23,12 >>Enter the cave
step
#completewith next
>>Kill |cRXP_ENEMY_Firemane Scalebanes|r
>>|cRXP_WARN_They can only be found inside the cave|r
.complete 1168,3 
.mob Firemane Scalebane
step
.goto Dustwallow Marsh,36.60,69.50
>>Loot the |cRXP_PICK_Chest|r in the back of the cave for |cRXP_LOOT_Mok'Morokk's Strongbox|r
.complete 1166,3 
step
#label StonemaulBanner
.goto Dustwallow Marsh,38.12,69.45
>>Loot the |cRXP_ENEMY_Stonemaul Clan Banner|r in the back of the cave
.complete 11160,1 
step
#label Dragondeez
#loop
.goto Dustwallow Marsh,37.44,68.47,0
.goto Dustwallow Marsh,37.44,68.47,15,0
.goto Dustwallow Marsh,38.59,68.10,15,0
.goto Dustwallow Marsh,38.31,66.98,15,0
.goto Dustwallow Marsh,37.27,67.39,15,0
>>Kill |cRXP_ENEMY_Firemane Scalebanes|r
>>|cRXP_WARN_They can only be found inside the cave|r
.complete 1168,3 
.mob Firemane Scalebane
step
#completewith next
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#loop
.goto Dustwallow Marsh,39.46,64.42,0
.goto Dustwallow Marsh,43.34,65.78,0
.goto Dustwallow Marsh,38.62,68.06,15,0
.goto Dustwallow Marsh,38.65,65.81,15,0
.goto Dustwallow Marsh,39.46,64.42,40,0
.goto Dustwallow Marsh,39.51,66.65,40,0
.goto Dustwallow Marsh,43.34,65.78,50,0
.goto Dustwallow Marsh,45.86,66.06,50,0
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
>>|cRXP_WARN_Use|r |T136021:0|t[Brogg's Totem] |cRXP_WARN_on their corpses|r |cRXP_WARN_to collect|r |cRXP_LOOT_Black Dragonkin Essence|r
.complete 1168,1 
.disablecheckbox
.complete 1168,2 
.disablecheckbox
.complete 11161,1 
.mob Firemane Scout
.mob Firemane Ash Tail
step
#completewith MudTurnins2
.subzone 4010 >>Return to Mudsprocket
step
#label MudTurnins2
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11160 >> Turn in Banner of the Stonemaul
.turnin 11161 >> Turn in The Essence of Enmity
.accept 11159 >> Accept Spirits of Stonemaul Hold
.target Brogg
step
#completewith Firemanemobs
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#completewith MokSnuff
.use 33091 >>|cRXP_WARN_Use the|r |T136021:0|t[Energized Totem] |cRXP_WARN_on |cRXP_PICK_Ogre Remains|r on the ground|r
>>Kill the |cRXP_ENEMY_Stonemaul Spirits|r that appear
.complete 11159,1 
.mob Stonemaul Spirit
step
#completewith StonemaulSpirits
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
.complete 1168,1 
.mob +Firemane Scout
.complete 1168,2 
.mob +Firemane Ash Tail
step
#label MokSnuff
.goto Dustwallow Marsh,44.50,66.00
>>Loot the |cRXP_PICK_Barrel|r on the ground for |cRXP_LOOT_Mok'Morokk's Snuff|r
.complete 1166,1 
step
#label StonemaulSpirits
#loop
.goto Dustwallow Marsh,43.98,67.76,0
.goto Dustwallow Marsh,43.98,67.76,40,0
.goto Dustwallow Marsh,42.78,66.81,40,0
.goto Dustwallow Marsh,42.29,65.67,40,0
.goto Dustwallow Marsh,43.63,64.62,40,0
.goto Dustwallow Marsh,44.11,63.63,40,0
.goto Dustwallow Marsh,45.34,63.76,40,0
.goto Dustwallow Marsh,46.61,66.21,40,0
.goto Dustwallow Marsh,45.66,68.51,40,0
.use 33091 >>|cRXP_WARN_Use the|r |T136021:0|t[Energized Totem] |cRXP_WARN_on |cRXP_PICK_Ogre Remains|r on the ground|r
>>Kill the |cRXP_ENEMY_Stonemaul Spirits|r that appear
.complete 11159,1 
.mob Stonemaul Spirit
step
#label Firemanemobs
#loop
.goto Dustwallow Marsh,39.08,65.92,0
.goto Dustwallow Marsh,39.08,65.92,80,0
.goto Dustwallow Marsh,42.81,66.35,80,0
.goto Dustwallow Marsh,44.63,66.16,80,0
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
.complete 1168,1 
.mob +Firemane Scout
.complete 1168,2 
.mob +Firemane Ash Tail
step
#completewith next
.subzone 4010 >>Return to Mudsprocket
step
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11159 >> Turn in Spirits of Stonemaul Hold
.accept 11162 >> Accept Challenge to the Black Flight
.target Brogg
step
#completewith next
>>Loot |cRXP_LOOT_Wyrmtail|r on the ground
.complete 11217,1 
step
#loop
.goto Dustwallow Marsh,45.60,82.28,0
.goto Dustwallow Marsh,48.10,80.85,60,0
.goto Dustwallow Marsh,47.09,82.39,60,0
.goto Dustwallow Marsh,45.60,82.28,60,0
.goto Dustwallow Marsh,43.99,81.35,60,0
.goto Dustwallow Marsh,42.31,80.73,60,0
.goto Dustwallow Marsh,42.08,78.40,60,0
.goto Dustwallow Marsh,42.45,75.89,60,0
.goto Dustwallow Marsh,45.60,82.28,60,0
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#loop
.goto Dustwallow Marsh,49.09,70.09,0
.goto Dustwallow Marsh,50.75,73.87,50,0
.goto Dustwallow Marsh,49.09,70.09,50,0
.goto Dustwallow Marsh,45.87,73.72,50,0
.goto Dustwallow Marsh,46.80,77.23,50,0
.goto Dustwallow Marsh,48.92,78.78,50,0
.goto Dustwallow Marsh,48.63,81.98,50,0
.goto Dustwallow Marsh,50.52,80.73,50,0
.goto Dustwallow Marsh,51.23,78.14,50,0
>>Loot |cRXP_LOOT_Wyrmtail|r on the ground
.complete 11217,1 
step
#completewith next
.goto Dustwallow Marsh,52.08,75.82
.cast 42425 >>|cRXP_WARN_Use the|r |T132484:0|t[Stonemaul Banner] |cRXP_WARN_at the entrance of Onyxia's Lair|r
.timer 22,Challenge to the Black Flight RP
step
.goto Dustwallow Marsh,52.08,75.82
>>Kill |cRXP_ENEMY_Smolderwing|r as he appears
.complete 11162,1 
.mob Smolderwing
.use 33095
step
#completewith BrackenWallTurnins2
.hs >> Hearth to Brackenwall Village
.bindlocation 496,1
.subzoneskip 496
step
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.turnin 11186 >> Turn in Signs of Treachery?
.turnin 1261 >> Turn in Marg Speaks
.accept 1262 >> Accept Report to Zor
.isQuestComplete 1261
.target Nazeer Bloodpike
step
#optional
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.turnin 11186 >> Turn in Signs of Treachery?
.target Nazeer Bloodpike
step
#optional
.goto Dustwallow Marsh,35.30,30.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.accept 1262 >> Accept Report to Zor
.target Nazeer Bloodpike
.isQuestTurnedIn 1261
step
.goto Dustwallow Marsh,36.30,31.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overlord Mok'Morokk|r
.turnin 1166 >> Turn in Overlord Mok'Morokk's Concern
.target Overlord Mok'Morokk
step
.goto Dustwallow Marsh,37.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharg|r
.turnin 1168 >> Turn in Army of the Black Dragon
.target Tharg
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 11206 >> Turn in Justice Dispensed
.target Krog
step
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1169 >> Turn in Identifying the Brood
.timer 11,Identifying the Brood RP
.accept 1170 >> Accept The Brood of Onyxia
.target Draz'Zilb
step
.goto Dustwallow Marsh,36.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mok'Morokk|r
.turnin 1170 >>Turn in The Brood of Onyxia
.accept 1171 >>Accept The Brood of Onyxia
.target Overlord Mok'Morokk
step
#label BrackenWallTurnins2
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1171 >>Turn in The Brood of Onyxia
.accept 1172 >>Accept The Brood of Onyxia
.target Draz'Zilb
step
#completewith next
.goto Dustwallow Marsh,35.57,31.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shardi|r
.fly Mudsprocket >> Fly to Mudsprocket
.target Shardi
.subzoneskip 4010
step
.goto Dustwallow Marsh,41.54,72.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gizzix Grimegurgle|r
.turnin 11217 >>Turn in Catch a Dragon by the Tail
.target Gizzix Grimegurgle
step
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11162 >>Turn in Challenge to the Black Flight
.target Brogg
step
#completewith DeadMireKill
.use 33101 >>|cRXP_WARN_Use the|r |T136008:0|t[Captured Totem] |cRXP_WARN_within The Quagmire|r
>>Kill |cRXP_ENEMY_Mottled Drywallow Crocolisks|r and |cRXP_ENEMY_Drywall Snapper|r near the totem
.complete 11169,1 
.mob Mottled Drywallow Crocolisk
.mob Drywall Snapper
step
#completewith TotemTests
>>Kill |cRXP_ENEMY_Noxious Shredders|r and |cRXP_ENEMY_Darkfang Creepers|r. Loot them for their |cRXP_LOOT_Marsh Venom|r
.complete 11173,1 
.mob Noxious Shredders
.mob Darkfang Creeper
step
#label DeadMireKill
#loop
.line Dustwallow Marsh,50.57,52.82,50.51,55.20,49.15,57.14,48.01,55.61,47.24,57.70,45.94,61.21,44.69,62.28,45.94,61.21,47.24,57.70,48.01,55.61,47.24,54.53,46.08,54.38,45.72,53.06,46.08,54.38,47.24,54.53,47.15,51.45
.goto Dustwallow Marsh,50.57,52.82,50,0
.goto Dustwallow Marsh,50.51,55.20,50,0
.goto Dustwallow Marsh,49.15,57.14,50,0
.goto Dustwallow Marsh,48.01,55.61,50,0
.goto Dustwallow Marsh,47.24,57.70,50,0
.goto Dustwallow Marsh,45.94,61.21,50,0
.goto Dustwallow Marsh,44.69,62.28,50,0
.goto Dustwallow Marsh,45.94,61.21,50,0
.goto Dustwallow Marsh,47.24,57.70,50,0
.goto Dustwallow Marsh,47.24,54.53,50,0
.goto Dustwallow Marsh,46.08,54.38,50,0
.goto Dustwallow Marsh,45.72,53.06,50,0
.goto Dustwallow Marsh,46.08,54.38,50,0
.goto Dustwallow Marsh,47.73,53.18,50,0
.goto Dustwallow Marsh,47.15,51.45,50,0
.goto Dustwallow Marsh,50.57,52.82,0
>>Find & kill |cRXP_ENEMY_Deadmire|r. Loot him for his |cRXP_LOOT_Tooth|r
>>|cRXP_WARN_He's a White Crocolisk who patrols in the water mires in the area|r
.complete 1205,1 
.unitscan Deadmire
step
#label TotemTests
#loop
.goto Dustwallow Marsh,41.64,56.36,0
.goto Dustwallow Marsh,39.11,53.51,0
.goto Dustwallow Marsh,44.93,47.36,0
.goto Dustwallow Marsh,41.64,56.36,60,0
.goto Dustwallow Marsh,38.64,59.30,60,0
.goto Dustwallow Marsh,39.11,53.51,60,0
.goto Dustwallow Marsh,40.24,48.76,60,0
.goto Dustwallow Marsh,42.04,45.45,60,0
.goto Dustwallow Marsh,44.93,47.36,60,0
.use 33101 >>|cRXP_WARN_Use the|r |T136008:0|t[Captured Totem] |cRXP_WARN_within The Quagmire|r
>>Kill |cRXP_ENEMY_Mottled Drywallow Crocolisks|r and |cRXP_ENEMY_Drywall Snapper|r near the totem
.complete 11169,1 
.mob Mottled Drywallow Crocolisk
.mob Drywall Snapper
step
#loop
.goto Dustwallow Marsh,43.50,48.32,0
.goto Dustwallow Marsh,38.56,52.05,0
.goto Dustwallow Marsh,43.46,53.64,0
.goto Dustwallow Marsh,43.50,48.32,70,0
.goto Dustwallow Marsh,39.02,46.56,70,0
.goto Dustwallow Marsh,38.56,52.05,70,0
.goto Dustwallow Marsh,40.43,56.51,70,0
.goto Dustwallow Marsh,43.46,53.64,70,0
>>Kill |cRXP_ENEMY_Noxious Shredders|r and |cRXP_ENEMY_Darkfang Creepers|r. Loot them for their |cRXP_LOOT_Marsh Venom|r
.complete 11173,1 
.mob Noxious Shredders
.mob Darkfang Creeper
step
.goto Dustwallow Marsh,46.06,57.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Garion|r
.turnin 11169 >> Turn in The Grimtotem Weapon
.turnin 11173 >> Turn in The Reagent Thief
.target Apprentice Garion
step
#loop
.goto Dustwallow Marsh,48.5,73.6,0
.goto Dustwallow Marsh,48.5,73.6,15,0
.goto Dustwallow Marsh,48.4,76.0,15,0
.goto Dustwallow Marsh,52.3,83.9,15,0
.goto Dustwallow Marsh,56.0,81.9,15,0
.goto Dustwallow Marsh,56.7,75.5,15,0
.goto Dustwallow Marsh,53.6,72.5,15,0
>>Click |cRXP_PICK_Eggs of Onyxia|r to destroy them
.complete 1172,1 
step
#completewith DWM2End
.goto Dustwallow Marsh,42.82,72.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dyslix Silvergrub|r
.fly Brackenwall >> Fly to Brackenwall Village
.target Dyslix Silvergrub
.subzoneskip 496
step
.goto Dustwallow Marsh,37.15,33.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1172 >>Turn in The Brood of Onyxia
.target Draz'Zilb
step
#softcore
.goto Dustwallow Marsh,36.30,31.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mok'Morokk|r
>>|cRXP_WARN_Accepting this quest turns|r |cRXP_ENEMY_Overlord Mok'Morokk|r |cRXP_WARN_hostile. He hits extremely hard and should be kited. Be prepared|r
.accept 1173,1 >>Accept Challenge Overlord Mok'Morokk
.unitscan Overlord Mok'Morokk
step
#softcore
.goto Dustwallow Marsh,36.30,31.50
>>Defeat |cRXP_ENEMY_Overlord Mok'Morokk|r by reducing his health to about 30%
>>|cRXP_WARN_He hits extremely hard and should be kited. Group up if needed, or skip this quest|r
>>|cRXP_WARN_He can be feared|r << Warlock/Priest/Warrior
.complete 1173,1 
.unitscan Overlord Mok'Morokk
.isOnQuest 1173
step
#softcore
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1173 >>Turn in Challenge Overlord Mok'Morokk
.target Draz'Zilb
.isQuestComplete 1173
step
#hardcore
.goto Dustwallow Marsh,36.30,31.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mok'Morokk|r
>>|cRXP_WARN_Accepting this quest turns|r |cRXP_ENEMY_Overlord Mok'Morokk|r |cRXP_WARN_hostile. He hits extremely hard and should be kited. Be prepared|r
.accept 1173,1 >>Accept Challenge Overlord Mok'Morokk
.unitscan Overlord Mok'Morokk
.group 3
step
#hardcore
.goto Dustwallow Marsh,36.30,31.50
>>Defeat |cRXP_ENEMY_Overlord Mok'Morokk|r by reducing his health to about 30%
>>|cRXP_WARN_He hits extremely hard and should be kited|r
>>|cRXP_WARN_He can be feared|r << Warlock/Priest
.complete 1173,1 
.unitscan Overlord Mok'Morokk
.group 3
step
#hardcore
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1173 >>Turn in Challenge Overlord Mok'Morokk
.target Draz'Zilb
.isQuestComplete 1173
.group
step
#label DWM2End
#optional
.abandon 1173 >>Abandon Challenge Overlord Mok'Morokk if you are unable to complete it
]])

RXPGuides.RegisterGuide([[#version 10
#wotlk
#tbc
#group RestedXP TBC Guide (H)
#subgroup RestedXP Horde 30-45
<< Horde
#name 43-45 Lower Stranglethorn Vale
#next 45-46 Tanaris Part 1
step
#completewith Boat2STV
.goto Dustwallow Marsh,35.57,31.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shardi|r
.fly Ratchet >> Fly to Ratchet
.target Shardi
step
.goto The Barrens,62.40,37.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mebok|r
.turnin 1270 >> Turn in Stinky's Escape
.target Mebok Mizzyrix
.isQuestComplete 1270
step
#label Boat2STV
#completewith next
.goto The Barrens,63.74,38.66
.zone Stranglethorn Vale >> Take the boat to Stranglethorn Vale
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Hecklebury Smotts|r
.accept 8551 >> Accept The Captain's Chest
.target Captain Hecklebury Smotts
step
.goto Stranglethorn Vale,28.10,76.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Mate Crazz|r
.accept 595 >> Accept The Bloodsail Buccaneers
.target First Mate Crazz
step
.goto Stranglethorn Vale,27.70,76.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fin|r
.accept 348 >> Accept Stranglethorn Fever
.target Fin Fizracket
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.accept 606 >> Accept Scaring Shaky
.accept 2872 >> Accept Stoley's Debt
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,26.70,76.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Privateer Bloads|r
.accept 617 >> Accept Akiris by the Bundle
.target Privateer Bloads
step
.goto Stranglethorn Vale,27.12,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank Fizzlebub|r on the inn's lowest level
.accept 600 >> Accept Venture Company Mining
.accept 621 >> Accept Zanzil's Secret
.target Crank Fizzlebub
step
.goto Stranglethorn Vale,27.039,77.310
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Skindle|r
.home >> Set your Hearthstone to Booty Bay
.target Innkeeper Skindle
.bindlocation 35
step
.goto Stranglethorn Vale,26.95,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kebok|r on the inn's top floor
.accept 209 >> Accept Skullsplitter Tusks
.target Kebok
step
.goto Stranglethorn Vale,27.17,77.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleet Master Seahorn|r
.turnin 669 >> Turn in Sunken Treasure
.target Fleet Master Seahorn
.isOnQuest 669
step
#completewith GG1
.goto Stranglethorn Vale,26.87,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Grom'gol >> Fly to Grom'gol Base Camp
.target Gringer
.subzoneskip 117
step
.goto Stranglethorn Vale,32.12,29.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.accept 572 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
#label GG1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r and |cRXP_FRIENDLY_Nimboya|r
.accept 598 >> Accept Split Bone Necklace
.target +Kin'weelay
.goto Stranglethorn Vale,32.28,27.70
.accept 584 >> Accept Bloodscalp Clan Heads
.target +Nimboya
.goto Stranglethorn Vale,32.10,27.80
step << Hunter
.goto Stranglethorn Vale,31.55,27.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uthok|r
>>|cRXP_BUY_Buy|r |T132382:0|t[Razor Arrows] |cRXP_BUY_from him|r
.collect 3030,2600,584,1 
.target Uthok
step
#completewith next
.goto Stranglethorn Vale,23.82,10.78,200 >> Travel to the Ruins of Zul'Kunda
step
.goto Stranglethorn Vale,23.52,9.53
>>Kill |cRXP_ENEMY_Nezzliok the Dire|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Be careful. |cRXP_WARN_Nezzliok|r casts|r |T136115:0|t[Shock]|cRXP_WARN_. An instant 280 damage spell|r
.complete 584,2 
.unitscan Nezzliok the Dire
step
.goto Stranglethorn Vale,23.44,8.14
>>Kill |cRXP_ENEMY_Gan'zulah|r. Loot him for his |cRXP_LOOT_Head|r
.complete 584,1 
.unitscan Gan'zulah
step
#completewith next
.subzone 117 >> Return to Grom'gol Base Camp
step
.goto Stranglethorn Vale,32.22,27.60
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.turnin 584 >> Turn in Bloodscalp Clan Heads
.accept 585 >> Accept Speaking with Nezzliok
.accept 586 >> Accept Speaking with Gan'zulah
step
#loop
.goto Stranglethorn Vale,32.99,38.06,0
.goto Stranglethorn Vale,31.00,42.50,60,0
.goto Stranglethorn Vale,32.99,38.06,50,0
.goto Stranglethorn Vale,31.42,40.17,50,0
.goto Stranglethorn Vale,30.14,43.06,50,0
.goto Stranglethorn Vale,28.36,43.47,50,0
.goto Stranglethorn Vale,28.53,45.96,50,0
.goto Stranglethorn Vale,30.61,44.54,50,0
.goto Stranglethorn Vale,31.80,43.08,50,0
.goto Stranglethorn Vale,33.24,40.38,50,0
.goto Stranglethorn Vale,33.85,38.45,50,0
.goto Stranglethorn Vale,32.99,38.06,50,0
>>Kill |cRXP_ENEMY_Jungle Stalkers|r. Loot them for their |cRXP_LOOT_Feathers|r
.complete 196,1 
.complete 572,1 
.mob Jungle Stalker
step
#loop
.goto Stranglethorn Vale,40.36,41.93,0
.goto Stranglethorn Vale,40.36,41.93,50,0
.goto Stranglethorn Vale,43.73,41.47,50,0
.goto Stranglethorn Vale,44.73,42.05,50,0
.goto Stranglethorn Vale,43.26,42.29,50,0
.goto Stranglethorn Vale,42.55,41.55,50,0
.goto Stranglethorn Vale,41.48,41.18,50,0
.goto Stranglethorn Vale,41.43,40.36,50,0
>>Kill |cRXP_ENEMY_Venture Co. Goblins|r. Loot them for their |cRXP_LOOT_Crystals|r
.complete 600,1 
.mob Venture Co. Surveyor
.mob Venture Co. Foreman
.mob Venture Co. Strip Miner
.mob Venture Co. Tinkerer
.mob Foreman Cozzle
step
#completewith SkullP
>>Kill |cRXP_ENEMY_Skullsplitter Trolls|r. Loot them for their |cRXP_LOOT_Tusks|r and |cRXP_LOOT_Necklaces|r
.complete 209,1 
.complete 598,1 
.mob Skullsplitter Mystic
.mob Skullsplitter Warrior
.mob Skullsplitter Axe Thrower
step
.goto Stranglethorn Vale,42.20,36.10
>>Loot the |cRXP_PICK_Ziata'jai Trophy Skulls|r for its |cRXP_LOOT_Trophy|r
.complete 585,2 
step
.goto Stranglethorn Vale,46.10,32.30
>>Loot the |cRXP_PICK_Balia'mah Trophy Skulls|r for its |cRXP_LOOT_Trophy|r
.complete 585,1 
step
#label SkullP
.goto Stranglethorn Vale,47.60,39.60
>>Loot the |cRXP_PICK_Zul'Mamwe Trophy Skulls|r for its |cRXP_LOOT_Trophy|r
.complete 585,3 
step
#completewith Anathek
>>Kill |cRXP_ENEMY_Skullsplitter Hunters|r, |cRXP_ENEMY_Berserkers|r and |cRXP_ENEMY_Headhunters|r. Loot them for their |cRXP_LOOT_Tusks|r and |cRXP_LOOT_Necklaces|r
.complete 586,1 
.mob +Skullsplitter Hunter
.complete 586,3 
.mob +Skullsplitter Berserker
.complete 586,2 
.mob +Skullsplitter Headhunter
.complete 209,1 
.mob +Skullsplitter Hunter
.mob +Skullsplitter Berserker
.mob +Skullsplitter Headhunter
.complete 598,1 
.mob +Skullsplitter Hunter
.mob +Skullsplitter Berserker
.mob +Skullsplitter Headhunter
step
#label Anathek
#loop
.goto Stranglethorn Vale,47.10,40.70,0
.goto Stranglethorn Vale,47.10,40.70,40,0
.goto Stranglethorn Vale,44.30,44.90,40,0
.goto Stranglethorn Vale,45.80,41.20,40,0
>>Kill |cRXP_ENEMY_Ana'thek the Cruel|r. Loot him for his |cRXP_LOOT_Armor|r
*|cRXP_WARN_Be careful of Ana'thek's adds and his|r |cFFEB144Cexecute ability.|r
.complete 586,4 
.unitscan Ana'thek the Cruel
step
#loop
.goto Stranglethorn Vale,47.90,42.90,0
.goto Stranglethorn Vale,47.60,44.10,50,0
.goto Stranglethorn Vale,46.00,42.80,50,0
.goto Stranglethorn Vale,44.40,41.90,50,0
.goto Stranglethorn Vale,47.40,39.80,50,0
.goto Stranglethorn Vale,47.90,42.90,50,0
>>Kill |cRXP_ENEMY_Skullsplitter Hunters|r, |cRXP_ENEMY_Berserkers|r and |cRXP_ENEMY_Headhunters|r. Loot them for their |cRXP_LOOT_Tusks|r and |cRXP_LOOT_Necklaces|r
.complete 586,1 
.mob +Skullsplitter Hunter
.complete 586,3 
.mob +Skullsplitter Berserker
.complete 586,2 
.mob +Skullsplitter Headhunter
.complete 209,1 
.disablecheckbox
.complete 598,1 
.disablecheckbox
step
#label SkullNecks
#loop
.goto Stranglethorn Vale,42.13,36.29,0
.goto Stranglethorn Vale,42.13,36.29,50,0
.goto Stranglethorn Vale,41.89,35.93,50,0
.goto Stranglethorn Vale,42.45,35.03,50,0
.goto Stranglethorn Vale,42.47,33.35,50,0
.goto Stranglethorn Vale,43.47,33.25,50,0
.goto Stranglethorn Vale,45.06,32.39,50,0
.goto Stranglethorn Vale,45.51,31.66,50,0
.goto Stranglethorn Vale,46.42,31.98,50,0
.goto Stranglethorn Vale,47.19,30.85,50,0
.goto Stranglethorn Vale,47.11,32.54,50,0
.goto Stranglethorn Vale,47.13,34.31,50,0
.goto Stranglethorn Vale,45.23,34.47,50,0
.goto Stranglethorn Vale,44.00,35.53,50,0
.goto Stranglethorn Vale,43.44,37.92,50,0
>>Finish killing |cRXP_ENEMY_Skullsplitter Trolls|r. Loot them for their |cRXP_LOOT_Tusks|r and |cRXP_LOOT_Necklaces|r
.complete 209,1 
.complete 598,1 
.mob Skullsplitter Mystic
.mob Skullsplitter Warrior
.mob Skullsplitter Axe Thrower
step
#loop
.goto Stranglethorn Vale,47.26,28.58,0
.goto Stranglethorn Vale,48.95,19.87,0
.goto Stranglethorn Vale,47.26,28.58,50,0
.goto Stranglethorn Vale,49.61,23.98,50,0
.goto Stranglethorn Vale,48.95,19.87,50,0
.goto Stranglethorn Vale,47.26,23.98,50,0
.goto Stranglethorn Vale,48.95,19.87,50,0
>>Kill |cRXP_ENEMY_Bhag'thera|r. Loot him for his |cRXP_LOOT_Fang|r
>>|cRXP_WARN_Before engaging|r |cRXP_ENEMY_Bhag'thera|r|cRXP_WARN_, clear the area of|r |cRXP_ENEMY_Shadowmaw Panthers|r |cRXP_WARN_to avoid adds|r
.complete 193,1 
.unitscan Bhag'thera
step
#completewith next
.subzone 100 >>Travel to Nesingwary's Expedition
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet|r and |cRXP_FRIENDLY_S. J. Erlgadin|r
.turnin 196 >> Turn in Raptor Mastery
.accept 197 >> Accept Raptor Mastery
.target +Hemet Nesingwary Jr.
.goto Stranglethorn Vale,35.66,10.81
.turnin 193 >> Turn in Panther Mastery
.goto Stranglethorn Vale,35.55,10.55
.target +Sir S. J. Erlgadin
step
#completewith next
.subzone 117 >>Travel to Grom'gol Base Camp
step
.goto Stranglethorn Vale,32.20,27.70
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.turnin 586 >> Turn in Speaking with Gan'zulah
.turnin 585 >> Turn in Speaking with Nezzliok
.accept 588 >> Accept The Fate of Yenniku
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.turnin 598 >> Turn in Split Bone Necklace
.turnin 588 >> Turn in The Fate of Yenniku
.accept 589 >> Accept The Singing Crystals
.target Kin'weelay
step
.goto Stranglethorn Vale,32.10,29.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.turnin 572 >> Turn in Mok'thardin's Enchantment
.accept 571 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
#completewith BloodSailPart1
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fly Booty Bay >> Fly to Booty Bay
.target Thysta
.subzoneskip 35
step
.goto Stranglethorn Vale,26.95,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kebok|r on the inn's top floor
.turnin 209 >> Turn in Skullsplitter Tusks
.target Kebok
step
.goto Stranglethorn Vale,27.10,77.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank|r on the inn's ground floor
.turnin 600 >> Turn in Venture Company Mining
.target Crank Fizzlebub
step
#completewith next
.goto Stranglethorn Vale,28.00,73.52,20,0
.goto Stranglethorn Vale,28.84,73.16,15,0
.goto Stranglethorn Vale,29.62,72.33,30 >>Exit Booty Bay
step
#label BloodSailPart1
.goto Stranglethorn Vale,27.27,69.51
>>Click on the |cRXP_PICK_Bloodsail Correspondence|r on top of a barrel in the center of the camp
.turnin 595 >> Turn in The Bloodsail Buccaneers
.accept 597 >> Accept The Bloodsail Buccaneers
step
#completewith SavageMokk
.goto Stranglethorn Vale,31.19,68.29,60,0
.goto Stranglethorn Vale,32.92,65.99,60,0
.goto Stranglethorn Vale,33.74,63.40,60,0
.goto Stranglethorn Vale,32.73,61.44,60,0
>>Kill |cRXP_ENEMY_Elder Mistvale Gorillas|r. Loot them for their |cRXP_LOOT_Giblets|r, a |T134298:0|t[|cRXP_LOOT_Gorilla Fang|r] and an |cRXP_LOOT_Aged Gorilla Sinew|r
.complete 606,1 
.complete 571,1 
.collect 2799,1 
.mob Elder Mistvale Gorilla
.addquestitem 2799,348
step
.goto Stranglethorn Vale,35.27,60.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Unbagwa|r
>>|cRXP_WARN_This will start an event where 3|r |cRXP_ENEMY_Gorillas|r |cRXP_WARN_come into the cave one after another. Kill them|r
.turnin 349 >> Turn in Stranglethorn Fever
.target Witch Doctor Unbagwa
.isOnQuest 348
.unitscan Mokk the Savage
step
#label SavageMokk
.goto Stranglethorn Vale,35.27,60.40
>>Face the |cRXP_ENEMY_Gorillas|r until |cRXP_ENEMY_Mokk the Savage|r appears. Kill him and loot him for his |cRXP_LOOT_Heart|r
.complete 348,1 
.unitscan Mokk the Savage
.isOnQuest 348
step
#loop
.goto Stranglethorn Vale,32.73,61.44,0
.goto Stranglethorn Vale,31.19,68.29,60,0
.goto Stranglethorn Vale,32.92,65.99,60,0
.goto Stranglethorn Vale,33.74,63.40,60,0
.goto Stranglethorn Vale,32.73,61.44,60,0
.goto Stranglethorn Vale,31.12,59.80,60,0
.goto Stranglethorn Vale,31.27,65.53,60,0
.goto Stranglethorn Vale,32.92,65.99,60,0
.goto Stranglethorn Vale,33.74,63.40,60,0
.goto Stranglethorn Vale,32.73,61.44,60,0
>>Kill |cRXP_ENEMY_Elder Mistvale Gorillas|r. Loot them for their |cRXP_LOOT_Giblets|r and an |cRXP_LOOT_Aged Gorilla Sinew|r
.complete 606,1 
.complete 571,1 
.mob Elder Mistvale Gorilla
step
#completewith next
.goto Stranglethorn Vale,37.50,49.54,50,0
.goto Stranglethorn Vale,38.91,50.56,50,0
.goto Stranglethorn Vale,41.78,50.14,25 >>Enter the Crystalvein Mine
step
#loop
.goto Stranglethorn Vale,43.84,47.77,0
.goto Stranglethorn Vale,42.69,49.05,20,0
.goto Stranglethorn Vale,43.84,47.77,20,0
>>Kill |cRXP_ENEMY_Ironjaw Basilisks|r. Loot them for their |cRXP_LOOT_Shards|r
.complete 589,1 
.mob Ironjaw Basilisk
step
.goto Stranglethorn Vale,28.80,44.80
>>Kill |cRXP_ENEMY_Tethis|r. Loot him for his |cRXP_LOOT_Talon|r
>>|cRXP_WARN_He patrols all around the raptor area|r
.complete 197,1 
.unitscan Tethis
step
#completewith next
.subzone 117 >>Travel to Grom'gol Base Camp
step
.goto Stranglethorn Vale,32.10,29.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.turnin 571 >> Turn in Mok'thardin's Enchantment
.accept 573 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.turnin 589 >> Turn in The Singing Crystals
.target Kin'weelay
step
#completewith next
.subzone 100 >>Travel to Nesingwary's Expedition
step
.goto Stranglethorn Vale,35.66,10.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet|r
.turnin 197 >> Turn in Raptor Mastery
.accept 208 >> Accept Big Game Hunter
.target Sir S. J. Erlgadin
.target Hemet Nesingwary Jr.
step
#completewith BootyBayTurnins2
.hs >>Hearth to Booty Bay
.use 6948
.bindlocation 35,1
.subzoneskip 33
.subzoneskip 35
.cooldown item,6948,>0
step
#completewith next
.subzone 117 >>Travel to Grom'gol Base Camp
.cooldown item,6948,<0,1
step
#completewith BootyBayTurnins2
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fly Booty Bay >> Fly to Booty Bay
.target Thysta
.subzoneskip 35
.cooldown item,6948,<0,1
step
.goto Stranglethorn Vale,27.60,76.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fin Fizracket|r
.turnin 348 >> Turn in Stranglethorn Fever
.target Fin Fizracket
step
.goto Stranglethorn Vale,28.09,76.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Mate Crazz|r
.turnin 597 >> Turn in The Bloodsail Buccaneers
.accept 599 >> Accept The Bloodsail Buccaneers
.target First Mate Crazz
step
.goto Stranglethorn Vale,26.90,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Shaky" Phillipe|r
.turnin 606 >> Turn in Scaring Shaky
.accept 607 >> Accept Return to MacKinley
.target "Shaky" Phillipe
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.turnin 607 >> Turn in Return to MacKinley
.accept 609 >> Accept Voodoo Dues
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,26.92,77.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deeg|r upstairs
.accept 587 >> Accept Up to Snuff
.target Deeg
step
.goto Stranglethorn Vale,27.17,77.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleet Master Seahorn|r
.turnin 599 >> Turn in The Bloodsail Buccaneers
.accept 604 >> Accept The Bloodsail Buccaneers
.target Fleet Master Seahorn
step
.goto Stranglethorn Vale,26.55,76.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Viznik Goldgrubber|r
.bankdeposit 2725,2728,2735,2730,2742,2732,2748,2751,2734,2740,2749,2745,2738,2744,2750,10699,5862,9628,8564 >>Deposit all your |T134332:0|t[Green Hills of Stranglethorn Pages] on the bank
.target Viznik Goldgrubber
.isQuestAvailable 587,576,604,621,573,617,609
step
#label BootyBayTurnins2
.goto Stranglethorn Vale,28.59,75.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dizzy One-Eye|r
.accept 576 >> Accept Keep An Eye Out
.target Dizzy One-Eye
step
#completewith Swashbucklers
>>Loot the |cRXP_PICK_Half-Burried Bottles|r along the southeastern coast for a |T133469:0|t[|cRXP_LOOT_Carefully Folded Note|r]. Use it to accept the quest
.collect 4098,1,594 
.accept 594 >> Accept Message in a Bottle
step
#completewith next
>>Kill |cRXP_ENEMY_Bloodsail Pirates|r. Loot them for their |cRXP_LOOT_Snuff|r and |cRXP_LOOT_Dizzy's Eye|r
.complete 604,1 
.complete 587,1 
.complete 576,1 
.mob Bloodsail Swashbuckler
step
#loop
.goto Stranglethorn Vale,26.94,82.49,0
.goto Stranglethorn Vale,29.61,80.89,20,0
.goto Stranglethorn Vale,27.75,83.13,20,0
.goto Stranglethorn Vale,27.18,82.66,20,0
.goto Stranglethorn Vale,26.94,82.49,20,0
>>Loot the |cRXP_LOOT_Bloodsail Orders|r and |cRXP_LOOT_Bloodsail Charts|r
>>|cRXP_WARN_They're typically in the large camp on the peninsula, or in the boat near that camp|r
.complete 604,2 
.complete 604,3 
step
#label Swashbucklers
.goto Stranglethorn Vale,32.02,79.47,0
.goto Stranglethorn Vale,32.96,88.25,0
.goto Stranglethorn Vale,32.02,79.47,60,0
.goto Stranglethorn Vale,29.83,81.11,60,0
.goto Stranglethorn Vale,27.18,82.79,60,0
.goto Stranglethorn Vale,32.02,79.47,60,0
.goto Stranglethorn Vale,29.83,81.11,60,0
.goto Stranglethorn Vale,27.18,82.79,60,0
>>Kill |cRXP_ENEMY_Bloodsail Pirates|r. Loot them for their |cRXP_LOOT_Snuff|r and |cRXP_LOOT_Dizzy's Eye|r
>>|cRXP_WARN_If you get unlucky with getting |cRXP_LOOT_Dizzy's Eye|r, go onto the most eastern ship to kill|r |cRXP_ENEMY_Brutus|r|cRXP_WARN_. He has a 100% drop chance|r
.complete 604,1 
.complete 587,1 
.complete 576,1 
.mob Bloodsail Swashbuckler
step
#loop
.goto Stranglethorn Vale,34.22,73.25,0
.goto Stranglethorn Vale,34.01,77.21,0
.goto Stranglethorn Vale,32.34,79.44,0
.goto Stranglethorn Vale,32.38,82.23,0
.goto Stranglethorn Vale,34.22,73.25,60,0
.goto Stranglethorn Vale,34.01,77.21,60,0
.goto Stranglethorn Vale,32.34,79.44,60,0
.goto Stranglethorn Vale,32.38,82.23,60,0
>>Loot the |cRXP_PICK_Half-Burried Bottles|r along the southeastern coast for a |T133469:0|t[|cRXP_LOOT_Carefully Folded Note|r]. Use it to accept the quest
.collect 4098,1,594 
.accept 594 >> Accept Message in a Bottle
step
#completewith next
.subzone 297 >>Swim to Jaguero Isle
step
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Poobah|r
.turnin 594 >>Turn in Message in a Bottle
.accept 630 >>Accept Message in a Bottle
.target Princess Poobah
step
.goto Stranglethorn Vale,40.94,83.89
>>Kill |cRXP_ENEMY_King Mukla|r. Loot him for his |cRXP_LOOT_Key|r
>>|cRXP_WARN_Clear a bit of space around|r |cRXP_ENEMY_King Mukla|r|cRXP_WARN_, as he has a fear|r
.complete 630,1 
.unitscan King Mukla
step
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Poobah|r
.turnin 630 >>Turn in Message in a Bottle
.target Princess Poobah
step
.goto Stranglethorn Vale,36.86,69.51
>>Kill |cRXP_ENEMY_Gorlash|r. Loot him for his |cRXP_LOOT_Chest|r
>>|cRXP_WARN_You can kite him back to the Booty Bay guards, and get credit as long as you did the majority damage|r
>>|cRXP_WARN_This quest is HARD depending on how well you can kite and do damage on the move. You can skip this quest if needed|r
.link https://youtu.be/lNy2ohTWeLw?t=1037 >> CLICK HERE for a reference
.complete 8551,1 
.isOnQuest 8551
.unitscan Gorlash
step
#completewith next
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
>>|cRXP_WARN_Do NOT pull or attack|r |cRXP_ENEMY_Zanzil the Outcast|r
.complete 621,1 
step
.goto Stranglethorn Vale,40.00,58.24
>>Kill |cRXP_ENEMY_Chucky|r. Loot him for his |cRXP_LOOT_Ring|r
.complete 609,3 
.unitscan Chucky "Ten Thumbs"
step
#optional
#loop
.goto Stranglethorn Vale,39.49,58.77,0
.goto Stranglethorn Vale,39.49,58.77,40,0
.goto Stranglethorn Vale,40.89,59.35,40,0
.goto Stranglethorn Vale,41.28,56.94,40,0
.goto Stranglethorn Vale,39.57,57.68,40,0
.goto Stranglethorn Vale,38.80,59.32,40,0
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
|cRXP_WARN_Try to get at least 8 |cRXP_LOOT_Mixtures|r as there are limited |cRXP_ENEMY_Zanzil|r mobs in the next camp|r
>>|cRXP_WARN_Do NOT pull or attack|r |cRXP_ENEMY_Zanzil the Outcast|r
.complete 621,1,8 
step
#optional
#completewith Maury
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
.complete 621,1 
step
.goto Stranglethorn Vale,34.92,51.84
>>Kill |cRXP_ENEMY_Jon-Jon|r. Loot him for his |cRXP_LOOT_Spyglass|r
.complete 609,2 
.unitscan Jon-Jon the Crow
step
#label Maury
.goto Stranglethorn Vale,35.25,51.25
>>Kill |cRXP_ENEMY_Maury|r. Loot her for her |cRXP_LOOT_Clubbed Foot|r
.complete 609,1 
.unitscan Maury "Club Foot" Wilkins
step
#loop
.goto Stranglethorn Vale,34.66,51.96,0
.goto Stranglethorn Vale,34.66,51.96,30,0
.goto Stranglethorn Vale,35.12,50.82,30,0
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
>>|cRXP_WARN_Return to the previous camp to find more |cRXP_ENEMY_Zanzil Undeads|r if needed|r
.complete 621,1 
.mob Zanzil Zombie
.mob Zanzil Hunter
.mob Zanzil Witch Doctor
.mob Zanzil Naga
step
#completewith HolyWater
.goto Stranglethorn Vale,27.07,59.30,40,0
.goto Stranglethorn Vale,27.37,62.97,30 >>Travel to the Nek'Mani Wellspring
step
#completewith next
>>Kill |cRXP_ENEMY_Naga Explorers|r. Loot them for their |cRXP_LOOT_Akiris Reed|r
.complete 573,1 
.complete 617,1 
.mob Naga Explorer
step
#label HolyWater
.goto Stranglethorn Vale,28.96,61.94
>>Click |cRXP_PICK_The Holy Spring|r to loot the |cRXP_LOOT_Holy Spring Water|r
.complete 573,2 
step
#loop
.goto Stranglethorn Vale,28.00,63.12,0
.goto Stranglethorn Vale,28.00,63.12,50,0
.goto Stranglethorn Vale,28.15,64.42,50,0
.goto Stranglethorn Vale,25.55,63.11,50,0
.goto Stranglethorn Vale,25.07,63.73,50,0
.goto Stranglethorn Vale,24.61,64.59,50,0
.goto Stranglethorn Vale,24.02,63.74,50,0
.goto Stranglethorn Vale,24.15,62.14,50,0
.goto Stranglethorn Vale,24.49,61.33,50,0
.goto Stranglethorn Vale,24.73,59.87,50,0
.goto Stranglethorn Vale,25.21,59.03,50,0
.goto Stranglethorn Vale,25.92,59.52,50,0
.goto Stranglethorn Vale,26.95,59.14,50,0
.goto Stranglethorn Vale,27.00,61.39,50,0
>>Finish killing |cRXP_ENEMY_Naga Explorers|r. Loot them for their |cRXP_LOOT_Akiris Reed|r
.complete 573,1 
.complete 617,1 
.mob Naga Explorer
step
#optional
.hs >>Hearth to Booty Bay
.use 6948
.bindlocation 35,1
.subzoneskip 35
.subzoneskip 33
.cooldown item,6948,>0
.isQuestComplete 617
step
.goto Stranglethorn Vale,26.70,73.60,150 >> Travel to Booty Bay
.cooldown item,6948,<0,1
.subzoneskip 35
.isQuestComplete 617
step
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Hecklebury Smotts|r
.turnin 8551 >> Turn in The Captain's Chest
.target Captain Hecklebury Smotts
.isQuestComplete 8551
step
.goto Stranglethorn Vale,28.60,75.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dizzy One-Eye|r
.turnin 576 >> Turn in Keep An Eye Out
.target Dizzy One-Eye
.isQuestComplete 576
step
.goto Stranglethorn Vale,27.80,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.turnin 609 >> Turn in Voodoo Dues
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,26.70,76.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Privateer Bloads|r
.turnin 617 >> Turn in Akiris by the Bundle
.target Privateer Bloads
step
.goto Stranglethorn Vale,26.55,76.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Viznik Goldgrubber|r
.bankwithdraw 2725,2728,2735,2730,2742,2732,2748,2751,2734,2740,2749,2745,2738,2744,2750,10699,5862,9628,8564 >>Withdraw all your |T134332:0|t[Green Hills of Stranglethorn Pages] from the bank
.target Viznik Goldgrubber
.isQuestAvailable 208
step
.goto Stranglethorn Vale,27.11,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank|r
.turnin 621 >> Turn in Zanzil's Secret
.target Crank Fizzlebub
step
.goto Stranglethorn Vale,27.13,77.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Whiskey Slim|r
.accept 580 >> Accept Whiskey Slim's Lost Grog
.target Whiskey Slim
step
.goto Stranglethorn Vale,27.00,77.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deeg|r upstairs
.turnin 587 >> Turn in Up to Snuff
.target Deeg
step
.goto Stranglethorn Vale,26.99,77.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Krazek|r
.accept 2864 >> Accept Tran'rek
.target Krazek
step
.goto Stranglethorn Vale,27.17,77.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleet Master Seahorn|r
.turnin 604 >> Turn in The Bloodsail Buccaneers
.target Fleet Master Seahorn
step
#completewith BigGameTurnin
.goto Stranglethorn Vale,26.87,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Grom'gol >> Fly to Grom'gol Base Camp
.target Gringer
.subzoneskip 117
step
.goto Stranglethorn Vale,32.10,29.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.turnin 573 >> Turn in Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
.goto Stranglethorn Vale,38.18,35.60
>>Kill |cRXP_ENEMY_King Bangalash|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_This quest is HARD. He comes with 2 mobs when he spawns, and spawns 2 more at about 50% health|r
.complete 208,1 
.unitscan King Bangalash
step
#completewith BigGameTurnin
.subzone 100 >>Travel to Nesingwary's Expedition
step
#completewith next
.goto Stranglethorn Vale,35.70,10.80,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barnil|r
+Turn in all the |T134332:0|t[Green Hills of Stranglethorn - Pages] that you have
.target Barnil Stonepot
step
#label BigGameTurnin
.goto Stranglethorn Vale,35.70,10.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet|r
.turnin 208 >> Turn in Big Game Hunter
.target Hemet Nesingwary Jr.
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 21. Hellfire Ramparts
step
#completewith next
.zone Hellfire Peninsula >> Travel to Hellfire Peninsula in Outland
step
.goto Hellfire Peninsula,56.37,65.99,20,0
.goto Hellfire Peninsula,56.61,66.77,14,0
.goto Hellfire Peninsula,56.64,66.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r upstairs in the Keep
.accept 10141 >> Accept The Legion Reborn
.target Force Commander Danath Trollbane
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Altumus|r
.goto Hellfire Peninsula,61.74,60.67,15,0
.goto Hellfire Peninsula,61.69,60.90
.turnin 10141 >> Turn in The Legion Reborn
.accept 10142 >> Accept The Path of Anguish
.target Sergeant Altumus
step
#loop
.line Hellfire Peninsula,65.83,59.06,67.03,58.91,69.16,59.36,69.64,57.71,68.15,56.25,67.55,54.60,66.82,56.63,65.55,55.62,65.83,59.06
.goto Hellfire Peninsula,65.83,59.06,50,0
.goto Hellfire Peninsula,67.03,58.91,50,0
.goto Hellfire Peninsula,69.16,59.36,50,0
.goto Hellfire Peninsula,69.64,57.71,50,0
.goto Hellfire Peninsula,68.15,56.25,50,0
.goto Hellfire Peninsula,67.55,54.60,50,0
.goto Hellfire Peninsula,66.82,56.63,50,0
.goto Hellfire Peninsula,65.55,55.62,50,0
>>Kill a |cRXP_ENEMY_Dreadcaller|r, |cRXP_ENEMY_Flamewaker Imps|r and |cRXP_ENEMY_Infernal Warbringers|r
.complete 10142,1 
.mob +Dreadcaller
.complete 10142,2 
.mob +Flamewaker Imp
.complete 10142,3 
.mob +Infernal Warbringer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Altumus|r
.goto Hellfire Peninsula,61.74,60.67,15,0
.goto Hellfire Peninsula,61.69,60.90
.turnin 10142 >> Turn in The Path of Anguish
.accept 10143 >> Accept Expedition Point
.target Sergeant Altumus
step
#label ExpeditionPoint
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Kingston|r
.turnin 10143 >> Turn in Expedition Point
.goto Hellfire Peninsula,71.34,62.76
.target Forward Commander Kingston
step
.goto Hellfire Peninsula,56.724,66.337
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Chadwick|r
.accept 9575 >> Accept Weaken the Ramparts
.target Lieutenant Chadwick
step
.isQuestAvailable 9575,9587
.goto Hellfire Peninsula,53.38,83.80,-1
.goto Hellfire Peninsula,47.543,53.609,-1
.subzone 3562 >> |cRXP_WARN_You will now run Hellfire Ramparts. Grind on nearby |cRXP_ENEMY_Unyielding Footmen|r, |cRXP_ENEMY_Unyielding Sorcerers|r and |cRXP_ENEMY_Unyielding Knights|r until you've found a group. Zone in once you have a group|r
.mob Unyielding Footman
.mob Unyielding Sorcerer
.mob Unyielding Knight
step
.isOnQuest 9575
#completewith next
>>Kill |cRXP_ENEMY_Watchkeeper Gargolmar|r. Loot him for |cRXP_LOOT_Gargolmar's Hand|r
>>Kill |cRXP_ENEMY_Omor the Unscarred|r. Loot him for |cRXP_LOOT_Omor's Hoof|r
>>Kill |cRXP_ENEMY_Nazan|r. Loot it for |cRXP_LOOT_Nazan's Head|r
.complete 9575,1 
.complete 9575,2 
.complete 9575,3 
step
>>Kill |cRXP_ENEMY_Vazruden|r. Loot him for the |T134940:0|t[|cRXP_LOOT_Ominous Letter|r]
.use 23890 >>|cRXP_WARN_Use the|r |T134940:0|t[|cRXP_LOOT_Ominous Letter|r] |cRXP_WARN_to start the quest|r
.collect 23890,1,9587,1 
.accept 9587 >> Accept Dark Tidings
step
.isOnQuest 9575
>>Kill |cRXP_ENEMY_Watchkeeper Gargolmar|r. Loot him for |cRXP_LOOT_Gargolmar's Hand|r
>>Kill |cRXP_ENEMY_Omor the Unscarred|r. Loot him for |cRXP_LOOT_Omor's Hoof|r
>>Kill |cRXP_ENEMY_Nazan|r. Loot it for |cRXP_LOOT_Nazan's Head|r
.complete 9575,1 
.complete 9575,2 
.complete 9575,3 
step
#optional
.zone Hellfire Peninsula >> Exit Hellfire Ramparts
>>|cRXP_WARN_You will run Blood Furnace after turning in the quests for Hellfire Ramparts. Consider asking your group to run Blood Furnace now if you wish to also run that|r
.subzoneskip 3562,1
step
.zone Hellfire Peninsula >> Exit Hellfire Ramparts
.subzoneskip 3562,1
step
#completewith WeakenRamparts
.subzone 3538 >> Return to Honor Hold
step
.isOnQuest 9587
.goto Hellfire Peninsula,56.64,66.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r upstairs in the Keep
.turnin 9587 >> Turn in Dark Tidings
.target Force Commander Danath Trollbane
step
#label WeakenRamparts
.isQuestComplete 9575
.goto Hellfire Peninsula,56.400,66.656
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gunny|r upstairs in the Keep
.turnin 9575 >> Turn in Weaken the Ramparts
.target Gunny
step
+|cRXP_WARN_You have completed the Hellfire Ramparts quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 22. The Blood Furnace
step
#completewith next
.zone Hellfire Peninsula >> Travel to Hellfire Peninsula in Outland
step
.isQuestTurnedIn 9587
.isQuestTurnedIn 9575
.goto Hellfire Peninsula,56.400,66.656
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gunny|r upstairs in the Keep
.accept 9589 >> Accept The Blood is Life
.accept 9607 >> Accept Heart of Rage
.target Gunny
step
.isQuestTurnedIn 9587
.goto Hellfire Peninsula,56.400,66.656
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gunny|r upstairs in the Keep
.accept 9589 >> Accept The Blood is Life
.target Gunny
step
.isQuestTurnedIn 9575
.goto Hellfire Peninsula,56.400,66.656
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gunny|r upstairs in the Keep
.accept 9607 >> Accept Heart of Rage
.target Gunny
step
.isQuestAvailable 9589,9607
.goto Hellfire Peninsula,53.38,83.80,-1
.goto Hellfire Peninsula,45.821,52.007,-1
.subzone 3713 >> |cRXP_WARN_You will now run Blood Furnace. Grind on |cRXP_ENEMY_Unyielding Footmen|r, |cRXP_ENEMY_Unyielding Sorcerers|r and |cRXP_ENEMY_Unyielding Knights|r until you've found a group. Zone in once you have a group|r
.mob Unyielding Footman
.mob Unyielding Sorcerer
.mob Unyielding Knight
step
.isOnQuest 9589
#completewith next
>>Kill |cRXP_ENEMY_Orcs|r. Loot them for their |cRXP_LOOT_Fel Orc Blood Vials|r
.complete 9589,1 
step
.isOnQuest 9607
>>Explore the final room of the Blood Furnace
.complete 9607,1 
step
.isOnQuest 9589
>>Kill |cRXP_ENEMY_Orcs|r. Loot them for their |cRXP_LOOT_Fel Orc Blood Vials|r
.complete 9589,1 
step
.zone Hellfire Peninsula >> Exit the Blood Furnace
.subzoneskip 3713,1
step
#completewith HeartofRage
.subzone 3538 >> Return to Honor Hold
step
.isQuestComplete 9589
.goto Hellfire Peninsula,56.400,66.656
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gunny|r upstairs in the Keep
.turnin 9589 >> Turn in The Blood is Life
.target Gunny
step
#label HeartofRage
.isQuestComplete 9607
.goto Hellfire Peninsula,56.64,66.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r upstairs in the Keep
.turnin 9607 >> Turn in Heart of Rage
.target Force Commander Danath Trollbane
step
+|cRXP_WARN_You have completed the Blood Furnace quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 23. The Underbog
step
#completewith EnterUB
.zone Zangarmarsh >> Travel to Zangarmarsh
step
.goto Zangarmarsh,19.368,49.785
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_T'shu|r
.accept 9717 >> Accept Oh, It's On!
.target T'shu
.reputation 970,friendly,<0,1 
.xp <63,1
step
.goto Zangarmarsh,19.650,49.701
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khn'nix|r
.accept 9719 >> Accept Stalk the Stalker
.target Khn'nix
.reputation 970,neutral,<0,1 
.xp <63,1
step
#completewith next
.isQuestAvailable 9717,9719,9738
.goto Zangarmarsh,24.93,41.85,-1 
.goto Zangarmarsh,50.379,40.900,-1 
.subzone 3905 >> |cRXP_WARN_You will now run Underbog. Grind on nearby |cRXP_ENEMY_Bloodscale Slavedrivers|r and |cRXP_ENEMY_Bloodscale Enchantresses|r until you've found a group. Zone in once you have a group|r
>>|cRXP_WARN_Once you're in a group, swim down into the Coilfang Reservoir|r
.mob Bloodscale Slavedriver
.mob Bloodscale Enchantress
.subzoneskip 3716 
step
.goto Zangarmarsh,52.291,35.959
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Jhang|r
.accept 9738 >> Accept Lost in Action
.target Watcher Jhang
step
#label EnterUB
.isQuestAvailable 9717,9719,9738
.goto Zangarmarsh,54.297,34.449
.subzone 3716 >> Zone into the Underbog
step
#sticky
>>Loot the mobs inside Underbog for |cRXP_LOOT_Sanguine Hibiscus|r
>>|cRXP_LOOT_Sanguine Hibiscus|r plants can also be looted on the ground
.collect 24246,5,9715,1 
.reputation 970,friendly,<0,1 
.subzoneskip 3716,1
step
.isOnQuest 9717
>>Loot the |cRXP_LOOT_Underspore Frond|r on the ground after defeating |cRXP_ENEMY_Hungarfen|r
.complete 9717,1 
step
.isOnQuest 9738
>>Talk to |cRXP_FRIENDLY_Earthbinder Rayge|r and |cRXP_FRIENDLY_Windcaller Claw|r inside Underbog
.complete 9738,1 
.target +Earthbinder Rayge
.complete 9738,4 
.target +Windcaller Claw
step
.isOnQuest 9719
>>Kill |cRXP_ENEMY_The Black Stalker|r. Loot it for the |cRXP_LOOT_Brain of the Black Stalker|r
.complete 9719,1 
.mob The Black Stalker
step
+|cRXP_WARN_Exit the Underbog. Consider asking your group to run the Slave Pens now if you wish to also complete that|r
.subzoneskip 3716,1
step
#optional
.isQuestComplete 9738
.goto Zangarmarsh,52.291,35.959
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Jhang|r
.turnin 9738 >> Turn in Lost in Action
.target Watcher Jhang
step
#optional
.isQuestComplete 9717
.goto Zangarmarsh,19.368,49.785
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_T'shu|r
.turnin 9717 >> Turn in Oh, It's On!
.target T'shu
step
#optional
.isQuestComplete 9719
.goto Zangarmarsh,19.650,49.701
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khn'nix|r
.turnin 9719 >> Turn in Stalk the Stalker
.target Khn'nix
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gzhun'tt|r
.accept 9715 >> Accept Bring Me A Shrubbery!
.turnin 9715 >> Turn in Bring Me A Shrubbery!
.goto Zangarmarsh,19.54,50.04
.target Gzhun'tt
.itemcount 24246,5 
.reputation 970,friendly,<0,1 
.xp <63,1
step
+|cRXP_WARN_You have completed the Underbog quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 24. The Slave Pens
step
#completewith EnterSP
.zone Zangarmarsh >> Travel to Zangarmarsh
step
.goto Zangarmarsh,52.291,35.959
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Jhang|r
.accept 9738 >> Accept Lost in Action
.target Watcher Jhang
step
#label EnterSP
.goto Zangarmarsh,49.018,35.631
.subzone 3717 >> Zone into the Slave Pens
step
.isOnQuest 9738
>>Talk to |cRXP_FRIENDLY_Naturalist Bite|r and |cRXP_FRIENDLY_Weeder Greenthumb|r inside the Slave Pens
.complete 9738,2 
.target +Naturalist Bite
.complete 9738,3 
.target +Weeder Greenthumb
step
+|cRXP_WARN_Exit the Slave Pens|r
.subzoneskip 3717,1
step
#optional
.isQuestComplete 9738
.goto Zangarmarsh,52.291,35.959
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Jhang|r
.turnin 9738 >> Turn in Lost in Action
.target Watcher Jhang
step
+|cRXP_WARN_You have completed the Slave Pens quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 25. Mana-Tombs
step
#completewith MTQuests
.zone Terokkar Forest >> Travel to Terokkar Forest
step
.isQuestAvailable 10216,10165,10218
#completewith MT1
.subzone 3792 >> |cRXP_WARN_You will shortly run Mana-Tombs. Start looking for a group to run it|r
step
#completewith next
.isQuestAvailable 10216,10165,10218
.goto Terokkar Forest,39.58,59.52,0
.subzone 3792 >> |cRXP_WARN_You will now run Mana-Tombs. Grind on nearby |cRXP_ENEMY_Cabals|r until you've found a group. Once you have found a group, head to Mana-Tombs and accept the quests outside of the dungeon|r
>>|cRXP_WARN_NOTE: You must be level 64 to accept the quests for Mana-Tombs!|r
.subzoneskip 3893 
.mob Cabal Initiate
.mob Cabal Spell-weaver
.mob Cabal Skirmisher
step
#label MTQuests
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Artificer Morphalius|r and |cRXP_FRIENDLY_Nexus-Prince Haramad|r
>>|cRXP_WARN_NOTE: These quests require level 64 to accept!|r
.accept 10216 >> Accept Safety Is Job One
.target +Artificer Morphalius
.goto Terokkar Forest,39.422,58.514
.accept 10165 >> Accept Undercutting the Competition
.target +Nexus-Prince Haramad
.goto Terokkar Forest,39.371,58.475
step
>>Kill |cRXP_ENEMY_Ethereal Crypt Raiders|r, |cRXP_ENEMY_Nexus Stalkers|r, |cRXP_ENEMY_Ethereal Sorcerers|r and |cRXP_ENEMY_Ethereal Spellbinders|r
.complete 10216,1 
.mob +Ethereal Crypt Raider
.complete 10216,2 
.mob +Nexus Stalker
.complete 10216,3 
.mob +Ethereal Sorcerer
.complete 10216,4 
.mob +Ethereal Spellbinder
step
.isQuestComplete 10216
>>Click the |cRXP_PICK_Ethereal Transporter Control Panel|r inside the dungeon
>>|cRXP_WARN_It is recommended not to accept the follow up escort quest until you have cleared the dungeon|r
.turnin 10216 >> Turn in Safety Is Job One
step
>>Kill |cRXP_ENEMY_Nexus-Prince Shaffar|r. Loot him for |cRXP_LOOT_Shaffar's Wrappings|r
.complete 10165,1 
step
.isQuestTurnedIn 10216
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cryo-Engineer Sha'heen|r
.accept 10218 >> Accept Someone Else's Hard Work Pays Off
.target Cryo-Engineer Sha'heen
step
>>Escort |cRXP_FRIENDLY_Cryo-Engineer Sha'heen|r out of the Mana-Tombs
.complete 10218,1 
.target Cryo-Engineer Sha'heen
step
#completewith MTTurnins
.zone Terokkar Forest >> |cRXP_WARN_Exit the Mana-Tombs|r
.subzoneskip 3792,1
step
.isQuestComplete 10165
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nexus-Prince Haramad|r
.turnin 10165 >> Turn in Undercutting the Competition
.target Nexus-Prince Haramad
.goto Terokkar Forest,39.371,58.475
step
#label MTTurnins
.isQuestComplete 10218
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nexus-Prince Haramad|r
.turnin 10218 >> Turn in Someone Else's Hard Work Pays Off
.target Nexus-Prince Haramad
.goto Terokkar Forest,39.371,58.475
step
+|cRXP_WARN_You have completed the Mana-Tombs quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 26. Auchenai Crypts
step
#completewith CryptsQ
.zone Terokkar Forest >> Travel to Terokkar Forest
step
#sticky
+|cRXP_WARN_There is only 1 quest for Auchenai Crypts and it is chain requiring to go to multiple zones. Simply find a group and run Auchenai Crypts if you wish to skip it, however below is the full quest chain if you wish to complete it all|r
step
.goto Terokkar Forest,35.091,65.085
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ha'lei|r
>>|cRXP_FRIENDLY_Ha'lei|r |cRXP_WARN_is located outside the Auchenai Crypts instance portal|r
.accept 10227 >> Accept I See Dead Draenei
.target Ha'lei
step
.goto Terokkar Forest,35.158,66.308
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ramdor the Mad|r
.turnin 10227 >> Turn in I See Dead Draenei
.accept 10228 >> Accept Ezekiel
.target Ramdor the Mad
step
#completewith WhatBook
.zone Shattrath City >> Travel to Shattrath
step
.goto Shattrath City,53.0,57.8,70,0
.goto Shattrath City,45.4,48.2,70,0
.goto Shattrath City,52.0,33.2,70,0
.goto Shattrath City,60.6,37.2,70,0
.goto Shattrath City,61.6,51.0,70,0
.goto Shattrath City,54.6,57.8,70,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ezekiel|r
>>|cRXP_FRIENDLY_Ezekiel|r |cRXP_WARN_patrols the inner ring of Shattrath|r
.turnin 10228 >> Turn in Ezekiel
.accept 10231 >> Accept What Book? I Don't See Any Book.
.target Ezekiel
step
#label WhatBook
.goto Shattrath City,43.632,29.761
>>Talk to then attack |cRXP_ENEMY_"Dirty" Larry|r until he turns friendly
>>|cRXP_WARN_This quest is difficult. Find a group for it if needed|r
.complete 10231,1 
.turnin 10231 >> Turn in What Book? I Don't See Any Book.
.accept 10251 >> Accept The Master's Grand Design?
.target "Dirty" Larry
step
#completewith VotD
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,51.389,57.172,20,0
.goto Nagrand,51.820,56.845
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nitrin the Learned|r inside the building
.turnin 10251 >> Turn in The Master's Grand Design?
.accept 10252 >> Accept Vision of the Dead
.target Nitrin the Learned
step
>>Kill |cRXP_ENEMY_Mountain Gronns|r. Loot it for its |cRXP_LOOT_Eyeball|r
>>Kill |cRXP_ENEMY_Greater Windrocs|r. Loot them for their |cRXP_LOOT_Flawless Greater Windroc Beak|r
>>Kill |cRXP_ENEMY_Aged Clefthoofs|r. Loot them for their |cRXP_LOOT_Aged Clefthoof Blubber|r
.complete 10252,1 
.goto Nagrand,24.37,41.81
.mob +Mountain Gronn
.complete 10252,2 
.goto Nagrand,35.97,29.37,55,0
.goto Nagrand,35.71,18.67,55,0
.goto Nagrand,32.69,22.30,55,0
.goto Nagrand,33.39,26.11,55,0
.goto Nagrand,30.88,32.97
.mob +Greater Windroc
.complete 10252,3 
.goto Nagrand,30.88,63.61,75,0
.goto Nagrand,32.53,61.08,75,0
.goto Nagrand,33.99,60.44,75,0
.goto Nagrand,36.31,58.76,75,0
.goto Nagrand,37.39,58.63,75,0
.goto Nagrand,38.67,59.52,75,0
.goto Nagrand,40.46,60.74,75,0
.goto Nagrand,44.52,61.64,75,0
.goto Nagrand,46.20,63.09,75,0
.goto Nagrand,46.71,66.40,75,0
.goto Nagrand,46.31,67.69,75,0
.goto Nagrand,45.46,68.24,75,0
.goto Nagrand,43.63,68.35,75,0
.goto Nagrand,43.05,67.77,75,0
.goto Nagrand,42.75,66.72,75,0
.goto Nagrand,42.56,64.36,75,0
.goto Nagrand,41.98,62.64,75,0
.goto Nagrand,40.82,61.30,75,0
.goto Nagrand,38.67,59.52
.mob +Aged Clefthoof
step
#label VotD
.goto Nagrand,51.389,57.172,20,0
.goto Nagrand,51.820,56.845
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nitrin the Learned|r inside the building
.turnin 10252 >> Turn in Vision of the Dead
.accept 10253 >> Accept Levixus the Soul Caller
.target Nitrin the Learned
step
#completewith next
.zone Terokkar Forest >> Travel to Terokkar Forest
step
.goto Terokkar Forest,39.64,71.28
>>Kill |cRXP_ENEMY_Levixus|r. Loot him for him for his |cRXP_LOOT_Book of the Dead|r
>>|cRXP_WARN_Be careful, |cRXP_ENEMY_Levixus|r is a strong elite. He can cast|r |T136206:0|t[Mind Control]|cRXP_WARN_,|r |T136135:0|t[Cripple] |cRXP_WARN_and he can summon an|r |T136219:0|t[Inferno]
>>|cRXP_WARN_It is recommended to do this with at least 3 players|r
.complete 10253,1 
.mob Levixus
step
.goto Terokkar Forest,35.14,66.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ramdor the Mad|r
.turnin 10253 >>Turn in Levixus the Soul Caller
.target Ramdor the Mad
step
.goto Terokkar Forest,35.03,65.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Greatfather Aldrimus|r
.accept 10164 >>Accept Everything Will Be Alright
.target Greatfather Aldrimus
.isQuestTurnedIn 10253
step
#label CryptsQ
.goto Terokkar Forest,34.40,65.59
.subzone 3790 >>Find a group and complete Auchenai Crypts
step
>>Kill |cRXP_ENEMY_Exarch Maladaar|r
.complete 10164,1 
.mob Exarch Maladaar
.isOnQuest 10164
step
.goto Terokkar Forest,35.03,65.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Greatfather Aldrimus|r
.turnin 10164 >>Turn in Everything Will Be Alright
.target Greatfather Aldrimus
.isQuestComplete 10164
step
+|cRXP_WARN_You have completed the Auchenai Crypts quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 27. Sethekk Halls
step
#optional
.goto Shattrath City,57.989,15.161
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oloraak|r
.accept 10180 >> Accept Can't Stay Away
.target Oloraak
.zoneskip Shattrath City,1
step
#completewith next
.goto Terokkar Forest,43.1,65.6,20 >>Travel to Sethekk Halls in Auchindoun
step
.goto Terokkar Forest,44.070,64.963
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Isfar|r
.turnin -10180 >>Turn In Can't Stay Away
.accept 10097 >>Accept Brother Against Brother
.accept 10098 >>Accept Terokk's Legacy
.target Isfar
step
.goto Terokkar Forest,44.90,65.61,10 >>Enter Sethekk Halls
step
>>Kill |cRXP_ENEMY_Darkweaver Syth|r. Loot him for |cRXP_LOOT_Terokk's Mask|r
>>Click on |cRXP_FRIENDLY_Lakka's|r cage
.complete 10097,1 
.complete 10098,2 
.complete 10097,2 
step
>>Loot |cRXP_PICK_The Saga of Terokk|r on the ground
>>|cRXP_WARN_This is in the centre of the room before the final boss|r
.complete 10098,1 
step
>>Kill |cRXP_ENEMY_Talon King Ikiss|r. Loot him for |cRXP_LOOT_Terokk's Quill|r
.complete 10098,3 
step
>>Open |cRXP_PICK_The Talon King's Coffer|r. Loot it for the |cRXP_LOOT_Shadow Labyrinth Key|r
.collect 27991,1 
step
.goto Terokkar Forest,44.070,64.963
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Isfar|r
.turnin 10097 >>Turn In Brother Against Brother
.turnin 10098 >>Turn In Terokk's Legacy
.target Isfar
step
+|cRXP_WARN_You have completed the Sethekk Halls quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 28. Old Hillsbrad (Escape from Durnholde)
step
#completewith CoTUnlock
.zone Tanaris >> Travel to Tanaris
step
#completewith CoTUnlock
.goto 1446/1,-4774.400,-8161.200,20 >> Travel to the Caverns of Time
step
.goto 1446/1,-4774.700,-8161.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Steward of Time|r
.target Steward of Time
.accept 10279 >>Accept To The Master's Lair
step
.goto 1446/1,-4250.100,-8372.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andormu|r
.target Andormu
.turnin 10279 >>Turn in To The Master's Lair
.accept 10277 >>Accept The Caverns of Time
step
>>|cRXP_WARN_You may either follow your |cRXP_FRIENDLY_Custodian of Time|r around the Caverns, or simply wait beside|r |cRXP_FRIENDLY_Andormu|r << tbc
>>|cRXP_WARN_Follow your |cRXP_FRIENDLY_Custodian of Time|r around the Caverns|r << wotlk
>>|cRXP_WARN_This RP takes approximately 10 minutes|r
.complete 10277,1 
.target Custodian of Time
step
#label CoTUnlock
.goto 1446/1,-4250.100,-8372.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andormu|r
.target Andormu
.turnin 10277 >>Turn in The Caverns of Time
.accept 10282 >>Accept Old Hillsbrad
step
#completewith next
.goto 1446/1,-4059.400,-8344.700,30 >> Enter Old Hillsbrad (Escape from Durnholde)
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andormu|r
.turnin 10282 >>Turn in Old Hillsbrad
.accept 10283 >>Accept Taretha's Diversion
.target Erozion
step
>>Click the five |cRXP_PICK_Barrels|r inside the Lodges
.complete 10283,1 
step
#completewith next
+|cRXP_WARN_Ensure quest auto accept has been turned OFF from other addons like Questie etc for this upcoming step!|r
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r
>>|cRXP_WARN_Only accept this quest once all of your party has turned in Taretha's Diversion. Rested XP has auto accept turned OFF for this step|r
.turnin 10283 >> Turn in Taretha's Diversion
.accept 10284,1 >>Accept Escape from Durnholde
.target Thrall
step
>>Complete Old Hillsbrad. Ensure you keep |cRXP_FRIENDLY_Thrall|r alive
.complete 10284,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Erozion|r
.turnin 10284 >> Turn in Escape from Durnholde
.accept 10285 >> Accept Return to Andormu
.target Erozion
step
#completewith next
+Talk to |cRXP_FRIENDLY_Erozion|r to teleport back to the Caverns of Time
.skipgossip
.target Erozion
step
.goto 1446/1,-4250.200,-8371.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andormu|r
.target Andormu
.turnin 10285 >>Turn in Return to Andormu
step
+|cRXP_WARN_You have completed the Old Hillsbrad (Escape from Durnholde) quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 29. Black Morass (Opening the Dark Portal)
step
#optional
.isQuestAvailable 10285
+You must first complete Old Hillsbrad (Escape from Durnholde) in order to enter Black Morass (Opening the Dark Portal)
step
.zone Tanaris >> Travel to Tanaris
.subzoneskip 1941
step
.goto 1446/1,-4774.400,-8161.200,20 >> Travel to the Caverns of Time
.subzoneskip 1941
step
.goto 1446/1,-4250.200,-8371.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andormu|r
.target Andormu
.accept 10296 >>Accept The Black Morass
step
#completewith next
.goto 1446/1,-4177.100,-8763.400,30 >> Enter the Black Morass (Opening the Dark Portal)
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sa'at|r
.target Sa'at
.turnin 10296 >>Turn in The Black Morass
.accept 10297 >>Accept The Opening of the Dark Portal
step
>>Complete the Black Morass
.complete 10297,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sa'at|r
.target Sa'at
.turnin 10297 >>Turn in The Opening of the Dark Portal
.accept 10298 >>Accept Hero of the Brood
step
#completewith next
.goto 1446/1,-4250.200,-8371.900,30 >> Return to |cRXP_FRIENDLY_Andormu|r in the Caverns of Time
step
.goto 1446/1,-4250.200,-8371.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andormu|r
.target Andormu
.turnin 10298 >>Turn in Hero of the Brood
step
+|cRXP_WARN_You have completed the Black Morass (Opening the Dark Portal) quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 30. Shadow Labyrinth
step
#completewith EnterSL
.goto 1952/530,4921.000,-3597.600,15 >> Travel to the Shadow Labyrinth in Auchindoun
step
.goto 1952/530,4921.000,-3597.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Commander Mahfuun|r
.target Field Commander Mahfuun
.accept 10094 >>Accept The Codex of Blood
step
.goto 1952/530,4926.700,-3602.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spy Grik'tha|r
.target Spy Grik'tha
.accept 10178 >>Accept Find Spy To'gun
step
#label EnterSL
.goto 1952/530,4943.000,-3647.300,10 >> Enter the Shadow Labyrinth
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Commander Mahfuun|r
>>|cRXP_FRIENDLY_Spy To'gun|r |cRXP_WARN_is located down the hallway behind|r |cRXP_ENEMY_Ambassador Hellmaw|r
.turnin 10178 >>Turn in Find Spy To'gun
.accept 10091 >>Accept The Soul Devices
.target Spy To'gun
step
#completewith KillMurmur
>>Loot the |cRXP_PICK_Soul Devices|r on the ground
.complete 10091,1 
step
>>Click the |cRXP_PICK_The Codex of Blood|r
>>|cRXP_WARN_This is located beneath|r |cRXP_ENEMY_Grandmaster Vorpil|r
.turnin 10094 >>Turn in The Codex of Blood
.accept 10095 >>Accept Into the Heart of the Labyrinth
step
#label KillMurmur
>>Kill |cRXP_ENEMY_Murmur|r
.complete 10095,1 
step
>>Loot the |cRXP_PICK_Soul Devices|r on the ground
.complete 10091,1 
step
#completewith next
.zone Shattrath City >> Travel to Shattrath City
step
.goto Shattrath City,50.246,45.356
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymistress Mehlisah Highcrown|r
.target Spymistress Mehlisah Highcrown
.turnin 10091 >>Turn in The Soul Devices
.turnin 10095 >>Turn in Into the Heart of the Labyrinth
step
+|cRXP_WARN_You have completed the Shadow Labyrinth quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 60-70
<< Alliance !classic
#name 31. The Steamvault
step
#optional
#completewith next
.zone Shattrath City >>Travel to Shattrath City
step
#optional
.goto Shattrath City,54.73,44.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
.accept 9832 >>Accept The Second and Third Fragments
.target Khadgar
.isQuestTurnedIn 9831
step
#completewith EnterSV
.goto Zangarmarsh,50.37,40.84,25,0
.goto Zangarmarsh,51.91,35.99,70 >>Swim through the underwater tunnel into Coilfang Reservoir
step
.goto Zangarmarsh,52.291,35.959
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Jhang|r
.accept 9763 >>Accept The Warlord's Hideout
.target Watcher Jhang
step
#label EnterSV
.goto Zangarmarsh,50.38,33.36
.subzone 3715 >>Enter The Steamvault
step
#sticky
>>Loot the |T134332:0|t[|cRXP_LOOT_Orders from Lady Vashj|r]
>>|cRXP_WARN_This can drop from any of the |cRXP_ENEMY_Coilfang Naga|r in The Steamvault|r
>>|cRXP_WARN_You may have to more than one run to get the drop|r
.collect 24367,1,9764 
.accept 9764 >>Accept Orders from Lady Vashj
step
#optional
>>Open the |cRXP_PICK_Arcane Container|r to spawn the |cRXP_ENEMY_Fragment Guardian|r
>>Kill the |cRXP_ENEMY_Fragment Guardian|r. Loot them for the |cRXP_LOOT_Second Key Fragment|r
.complete 9832,1 
.mob Second Fragment Guardian
.isOnQuest 9832
step
>>Kill |cRXP_ENEMY_Warlord Kalithresh|r
.complete 9763,1 
.mob Warlord Kalithresh
step
#completewith SVTurnins
.zone Zangarmarsh >>Exit The Steamvault
.subzoneskip 3715,1
step
.goto Zangarmarsh,52.291,35.959
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Jhang|r
.turnin 9763 >>Turn in The Warlord's Hideout
.target Watcher Jhang
.isQuestComplete 9763
step
#label SVTurnins
.goto Zangarmarsh,78.40,62.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysiel|r
.turnin 9764 >>Turn in Orders from Lady Vashj
.target Ysiel Windsinger
.isOnQuest 9764
step
+|cRXP_WARN_You have completed the Steamvault quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#group RXP TBC Reputation Guide
#subgroup The Scryers
#name 1. Shattrath City (Scryers)
#next 2. Netherstorm (Scryers)
step
#completewith CityofLight
.zone Shattrath City >> Travel to Shattrath City
step
.goto Shattrath City,59.657,41.428
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haggard War Veteran|r
.target Haggard War Veteran
.accept 10210 >>Accept A'dal
step
.goto Shattrath City,53.991,44.743
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A'dal|r
.target A'dal
.turnin 10210 >>Turn in A'dal
step
#label CityofLight
.goto Shattrath City,54.751,44.322
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
.target Khadgar
.accept 10211 >>Accept City of Light
.timer 530,City of Light RP
step << tbc
.goto Shattrath City,50.36,42.87
>>|cRXP_WARN_Head up to the second floor next to |cRXP_FRIENDLY_G'eras|r and wait out the RP|r
>>|cRXP_WARN_If someone else's |cRXP_FRIENDLY_Khadgar's Servant|r arrives in the meantime, you can target it and it will complete the quest for you. If the quest fails, abandon City of Light, accept the quest from |cRXP_FRIENDLY_Khadgar|r again, then follow |cRXP_FRIENDLY_Khadgar's Servant|r through Shattrath|r
.complete 10211,1 
.target Khadgar's Servant
step << wotlk
.goto Shattrath City,50.36,42.87
>>|cRXP_WARN_Follow |cRXP_FRIENDLY_Khadgar's Servant|r through Shattrath City|r
.complete 10211,1 
.target Khadgar's Servant
step
.goto Shattrath City,54.751,44.322
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
>>|cFFFF0000Ensure to turn off |cRXP_WARN_Questie|r or any other addon that has an automatic turn in option!|r
.target Khadgar
.turnin 10211 >> Turn in City of Light
step
.goto Shattrath City,54.751,44.322
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
.accept 10552 >> Accept Allegiance to the Scryers
.turnin 10552 >> Turn in Allegiance to the Scryers
>>|cFFFF0000Ensure to turn off |cRXP_WARN_Questie|r or any other addon that has an automatic turn in option!|r
.target Khadgar
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
.goto Shattrath City,54.751,44.322
.accept 10553 >>Accept Voren'thal the Seer
.target Khadgar
step
#scryer
.skill riding,225,1
#completewith VorenthaltheSeer
.goto Shattrath City,49.82,63.49,20 >> Take the elevator up to the Scryer's Tier
step
#scryer
#label VorenthaltheSeer
.goto Shattrath City,42.782,91.723
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Voren'thal the Seer|r
.turnin 10553 >>Turn in Voren'thal the Seer
.target Voren'thal the Seer
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#group RXP TBC Reputation Guide
#subgroup The Aldor
#name 1. Terokkar Forest (Aldor)
#next 2. Netherstorm (Aldor)
step
#completewith CityofLight
.zone Shattrath City >> Travel to Shattrath City
step
.goto Shattrath City,59.657,41.428
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haggard War Veteran|r
.target Haggard War Veteran
.accept 10210 >>Accept A'dal
step
.goto Shattrath City,53.991,44.743
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A'dal|r
.target A'dal
.turnin 10210 >>Turn in A'dal
step
#label CityofLight
.goto Shattrath City,54.751,44.322
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
.target Khadgar
.accept 10211 >>Accept City of Light
.timer 530,City of Light RP
step << tbc
.goto Shattrath City,50.36,42.87
>>|cRXP_WARN_Head up to the second floor next to |cRXP_FRIENDLY_G'eras|r and wait out the RP|r
>>|cRXP_WARN_If someone else's |cRXP_FRIENDLY_Khadgar's Servant|r arrives in the meantime, you can target it and it will complete the quest for you. If the quest fails, abandon City of Light, accept the quest from |cRXP_FRIENDLY_Khadgar|r again, then follow |cRXP_FRIENDLY_Khadgar's Servant|r through Shattrath|r
.complete 10211,1 
.target Khadgar's Servant
step << wotlk
.goto Shattrath City,50.36,42.87
>>|cRXP_WARN_Follow |cRXP_FRIENDLY_Khadgar's Servant|r through Shattrath City|r
.complete 10211,1 
.target Khadgar's Servant
step
.goto Shattrath City,54.751,44.322
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
>>|cFFFF0000Ensure to turn off |cRXP_WARN_Questie|r or any other addon that has an automatic turn in option!|r
.target Khadgar
.turnin 10211 >> Turn in City of Light
step
.goto Shattrath City,54.751,44.322
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
.accept 10551 >> Accept Allegiance to the Aldor
.turnin 10551 >> Turn in Allegiance to the Aldor
>>|cFFFF0000Ensure to turn off |cRXP_WARN_Questie|r or any other addon that has an automatic turn in option!|r
.target Khadgar
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar|r
.goto Shattrath City,54.751,44.322
.accept 10554 >> Accept Ishanah
.target Khadgar
step
#aldor
.skill riding,225,1
#completewith next
.goto Shattrath City,41.73,38.60,30 >> Take the elevator up to the Aldor Rise
step
#aldor
.goto 1955/530,5822.300,-1732.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishanah|r
.target Ishanah
.turnin 10554 >>Turn in Ishanah
.accept 10021 >>Accept Restoring the Light
step
#aldor
.goto Shattrath City,64.486,15.112
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sha'nir|r
.target Sha'nir
.accept 10020 >>Accept A Cure for Zahlia
step
#aldor
.goto Terokkar Forest,48.10,14.51
>>Click the |cRXP_PICK_Western Altar|r
.complete 10021,3 
step
#aldor
.goto Terokkar Forest,50.67,16.54
>>Click the |cRXP_PICK_Northern Altar|r
.complete 10021,1 
step
#aldor
.goto Terokkar Forest,49.25,20.32
>>Click the |cRXP_PICK_Eastern Altar|r
.complete 10021,2 
step
#aldor
#loop
.goto Terokkar Forest,60.77,23.14,50,0
.goto Terokkar Forest,60.97,24.34,50,0
.goto Terokkar Forest,61.46,25.43,50,0
.goto Terokkar Forest,62.10,27.12,50,0
.goto Terokkar Forest,62.77,27.68,50,0
.goto Terokkar Forest,63.32,28.38,50,0
.goto Terokkar Forest,63.72,29.37,50,0
.goto Terokkar Forest,64.54,30.01,50,0
.goto Terokkar Forest,66.31,30.54,50,0
.goto Terokkar Forest,67.93,30.85,50,0
.goto Terokkar Forest,68.35,31.31,50,0
.goto Terokkar Forest,69.16,31.22,50,0
.goto Terokkar Forest,69.63,30.88,50,0
.goto Terokkar Forest,70.35,29.82,50,0
.goto Terokkar Forest,71.26,28.70,50,0
.line Terokkar Forest,71.26,28.70,70.35,29.82,69.63,30.88,69.16,31.22,68.35,31.31,67.93,30.85,66.31,30.54,64.54,30.01,63.72,29.37,63.32,28.38,62.77,27.68,62.10,27.12,61.46,25.43,60.97,24.34,60.77,23.14
>>Kill |cRXP_ENEMY_Stonegazer|r. Loot him for his |cRXP_LOOT_Blood|r
>>|cRXP_ENEMY_Stonegazer|r |cRXP_WARN_patrols a large area|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc
.complete 10020,1 
.unitscan Stonegazer
step
#aldor
.isQuestComplete 10020
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sha'nir|r
.turnin 10020 >> Turn in A Cure for Zahlia
.goto Shattrath City,64.486,15.112
.target Sha'nir
step
#aldor
.skill riding,225,1
#completewith next
.goto Shattrath City,41.73,38.60,30 >> Take the elevator up to the Aldor Rise
step
#aldor
.goto 1955/530,5822.300,-1732.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishanah|r
.turnin 10021 >> Turn in Restoring the Light
.target Ishanah
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#group RXP TBC Reputation Guide
#subgroup The Aldor
#name 2. Netherstorm (Aldor)
#next 3. Shadowmoon Valley (Aldor)
step
#completewith next
.zone Netherstorm >> Travel to Netherstorm
step
#aldor
.goto Netherstorm,32.07,64.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Orelis|r
.accept 10241 >> Accept Distraction at Manaforge B'naar
.target Exarch Orelis
step
#aldor
>>Kill |cRXP_ENEMY_Sunfury Magisters|r and |cRXP_ENEMY_Sunfury Bloodwarders|r
.complete 10241,1 
.mob +Sunfury Magister
.goto Netherstorm,25.64,68.35,50,0
.goto Netherstorm,26.58,68.65,50,0
.goto Netherstorm,25.18,68.81
.complete 10241,2 
.mob +Sunfury Bloodwarder
.goto Netherstorm,28.09,64.84,50,0
.goto Netherstorm,27.43,65.29,50,0
.goto Netherstorm,25.91,66.72,50,0
.goto Netherstorm,25.16,67.41
step
#aldor
.goto Netherstorm,32.07,64.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Orelis|r
.turnin 10241 >> Turn in Distraction at Manaforge B'naar
.accept 10313 >> Accept Measuring Warp Energies
.target Exarch Orelis
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Karja|r
.goto Netherstorm,32.04,64.18
.accept 10243 >> Accept Naaru Technology
.target Anchorite Karja
step
#aldor
.goto Netherstorm,25.79,60.21
.use 29324 >>|cRXP_WARN_Use the|r |T134125:0|t[Warp-Attuned Orb] |cRXP_WARN_next to the|r |cRXP_PICK_Northern Pipeline|r
.complete 10313,1 
step
#aldor
.goto Netherstorm,20.88,67.20
.use 29324 >>|cRXP_WARN_Use the|r |T134125:0|t[Warp-Attuned Orb] |cRXP_WARN_next to the|r |cRXP_PICK_Western Pipeline|r
.complete 10313,4 
step
#aldor
.goto Netherstorm,20.50,70.95
.use 29324 >>|cRXP_WARN_Use the|r |T134125:0|t[Warp-Attuned Orb] |cRXP_WARN_next to the|r |cRXP_PICK_Southern Pipeline|r
.complete 10313,3 
step
#aldor
.goto Netherstorm,23.217,68.284
>>|cRXP_WARN_Go inside Manaforge B'naar|r
>>Click to the |cRXP_PICK_B'naar Control Console|r
.turnin 10243 >> Turn in Naaru Technology
.accept 10245 >> Accept B'naar Console Transcription
step
#aldor
.goto Netherstorm,28.91,72.29
.use 29324 >>|cRXP_WARN_Use the|r |T134125:0|t[Warp-Attuned Orb] |cRXP_WARN_next to the|r |cRXP_PICK_Eastern Pipeline|r
.complete 10313,2 
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Karja|r and |cRXP_FRIENDLY_Exarch Orelis|r
.turnin 10245 >> Turn in B'naar Console Transcription
.accept 10299 >> Accept Shutting Down Manaforge B'naar
.target +Anchorite Karja
.goto Netherstorm,32.04,64.18,-1
.turnin 10313 >> Turn in Measuring Warp Energies
.target +Exarch Orelis
.goto Netherstorm,32.07,64.18,-1
step
#aldor
.goto Netherstorm,24.20,68.10,40,0
.goto Netherstorm,23.68,70.02,40,0
.goto Netherstorm,23.85,70.77
>>Kill |cRXP_ENEMY_Overseer Theredis|r inside Manaforge B'naar. Loot him for the |cRXP_LOOT_B'naar Access Crystal|r
.complete 10299,2 
.mob Overseer Theredis
step
#aldor
.goto Netherstorm,23.217,68.284
>>Click to the |cRXP_PICK_B'naar Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Sunfury|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10299,1 
.skipgossip
.mob Sunfury Warp-Engineer
.mob Sunfury Warp-Master
.mob Sunfury Technician
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Karja|r and |cRXP_FRIENDLY_Exarch Orelis|r
.turnin 10299 >> Turn in Shutting Down Manaforge B'naar
.accept 10321 >> Accept Shutting Down Manaforge Coruu
.target +Anchorite Karja
.goto Netherstorm,32.04,64.18
.accept 10246 >> Accept Attack on Manaforge Coruu
.target +Exarch Orelis
.goto Netherstorm,32.07,64.18
step
#aldor
#completewith Coruu
>>Kill |cRXP_ENEMY_Sunfury Researchers|r and |cRXP_ENEMY_Sunfury Arcanists|r
.complete 10246,1 
.mob +Sunfury Researcher
.complete 10246,2 
.mob +Sunfury Arcanist
step
#aldor
.goto Netherstorm,49.02,81.52
>>Kill |cRXP_ENEMY_Overseer Seylanna|r inside Manaforge Coruu. Loot her for the |cRXP_LOOT_Coruu Access Crystal|r
.complete 10321,2 
.mob Overseer Seylanna
step
#aldor
#label Coruu
.goto Netherstorm,48.926,81.613
>>Click to the |cRXP_PICK_Coruu Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Sunfury|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10321,1 
.skipgossip
.mob Sunfury Technician
step
#aldor
>>Kill |cRXP_ENEMY_Sunfury Researchers|r and |cRXP_ENEMY_Sunfury Arcanists|r
.complete 10246,1 
.mob +Sunfury Researcher
.goto Netherstorm,49.46,82.42,40,0
.goto Netherstorm,49.08,83.00,40,0
.goto Netherstorm,48.16,82.40,40,0
.goto Netherstorm,48.14,81.55,40,0
.goto Netherstorm,48.55,81.01,40,0
.goto Netherstorm,49.14,80.95,40,0
.goto Netherstorm,49.45,81.61
.complete 10246,2 
.mob +Sunfury Arcanists
.goto Netherstorm,52.33,82.48,50,0
.goto Netherstorm,52.34,82.72,50,0
.goto Netherstorm,51.91,82.68,50,0
.goto Netherstorm,51.65,82.12,50,0
.goto Netherstorm,51.38,82.12,50,0
.goto Netherstorm,51.32,81.99,50,0
.goto Netherstorm,51.13,82.47,50,0
.goto Netherstorm,50.68,82.30,50,0
.goto Netherstorm,50.91,81.69,50,0
.goto Netherstorm,51.13,81.29,50,0
.goto Netherstorm,51.29,81.20,50,0
.goto Netherstorm,51.75,81.23
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Karja|r and |cRXP_FRIENDLY_Exarch Orelis|r
.turnin 10321 >> Turn in Shutting Down Manaforge Coruu
.accept 10322 >> Accept Shutting Down Manaforge Duro
.target +Anchorite Karja
.goto Netherstorm,32.04,64.18
.turnin 10246 >> Turn in Attack on Manaforge Coruu
.accept 10328 >> Accept Sunfury Briefings
.target +Exarch Orelis
.goto Netherstorm,32.07,64.18
step
#aldor
#completewith DuroShutDown
>>Kill |cRXP_ENEMY_Sunfury Bowmen|r and |cRXP_ENEMY_Sunfury Centurions|r. Loot them for the |cRXP_LOOT_Military Briefing|r
>>Kill |cRXP_ENEMY_Sunfury Conjurers|r. Loot them for the |cRXP_LOOT_Arcane Briefing|r
.complete 10328,1 
.mob +Sunfury Bowman
.mob +Sunfury Centurion
.complete 10328,2 
.mob +Sunfury Conjurer
step
#aldor
.goto Netherstorm,59.99,68.52
>>Kill |cRXP_ENEMY_Overseer Athanel|r inside Manaforge Duro. Loot him for the |cRXP_LOOT_Duro Access Crystal|r
.complete 10322,2 
.mob Overseer Athanel
step
#aldor
#label DuroShutDown
.goto Netherstorm,59.19,66.72
>>Click to the |cRXP_PICK_Duro Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Sunfury|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10322,1 
.skipgossip
step
#aldor
#loop
.line Netherstorm,58.84,62.54,58.31,62.97,58.10,62.71,57.76,63.29,57.21,63.42,56.82,63.89,57.34,64.44,57.39,65.29,57.22,65.92,56.95,66.52,57.34,67.19,57.38,66.58,57.22,65.92,57.39,65.29,57.34,64.44,57.91,64.06,57.76,63.29,58.10,62.71,58.31,62.97,58.84,62.54,59.10,63.14,59.45,63.04,59.20,62.36,58.84,62.54
.goto Netherstorm,58.84,62.54,50,0
.goto Netherstorm,58.31,62.97,50,0
.goto Netherstorm,58.10,62.71,50,0
.goto Netherstorm,57.76,63.29,50,0
.goto Netherstorm,57.21,63.42,50,0
.goto Netherstorm,56.82,63.89,50,0
.goto Netherstorm,57.34,64.44,50,0
.goto Netherstorm,57.39,65.29,50,0
.goto Netherstorm,57.22,65.92,50,0
.goto Netherstorm,56.95,66.52,50,0
.goto Netherstorm,57.34,67.19,50,0
.goto Netherstorm,57.38,66.58,50,0
.goto Netherstorm,57.22,65.92,50,0
.goto Netherstorm,57.39,65.29,50,0
.goto Netherstorm,57.34,64.44,50,0
.goto Netherstorm,57.91,64.06,50,0
.goto Netherstorm,57.76,63.29,50,0
.goto Netherstorm,58.10,62.71,50,0
.goto Netherstorm,58.31,62.97,50,0
.goto Netherstorm,58.84,62.54,50,0
.goto Netherstorm,59.10,63.14,50,0
.goto Netherstorm,59.45,63.04,50,0
.goto Netherstorm,59.20,62.36,50,0
>>Kill |cRXP_ENEMY_Bowmen|r and |cRXP_ENEMY_Centurions|r. Loot them for the |cRXP_LOOT_Military Briefing|r
>>Kill |cRXP_ENEMY_Sunfury Conjurers|r. Loot them for the |cRXP_LOOT_Arcane Briefing|r
.complete 10328,1 
.mob +Sunfury Bowman
.mob +Sunfury Centurion
.complete 10328,2 
.mob +Sunfury Conjurer
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Karja|r and |cRXP_FRIENDLY_Exarch Orelis|r
.turnin 10322 >> Turn in Shutting Down Manaforge Duro
.accept 10323 >> Accept Shutting Down Manaforge Ara
.target +Anchorite Karja
.goto Netherstorm,32.04,64.18
.turnin 10328 >> Turn in Sunfury Briefings
.accept 10431 >> Accept Outside Assistance
.target +Exarch Orelis
.goto Netherstorm,32.07,64.18
step
#completewith next
.subzone 3852 >> Travel to Tuluman's Landing
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaylaan|r
.turnin 10431 >> Turn in Outside Assistance
.accept 10380 >> Accept A Dark Pact
.target +Kaylaan
.goto Netherstorm,34.80,38.30
step
#completewith next
.goto Netherstorm,26.37,43.87
.subzone 3881 >> Enter the Trelleum Mine
step
#aldor
.goto Netherstorm,26.95,38.34,30,0
.goto Netherstorm,25.59,41.65,30,0
.goto Netherstorm,26.43,42.61,30,0
.goto Netherstorm,26.95,38.34,30,0
.goto Netherstorm,25.59,41.65,30,0
.goto Netherstorm,26.43,42.61
>>Kill |cRXP_ENEMY_Gan'arg Warp-Tinkers|r and |cRXP_ENEMY_Mo'arg Warp-Master|r inside the mine
.complete 10380,1 
.mob +Gan'arg Warp-Tinker
.complete 10380,3 
.mob +Mo'arg Warp-Master
step
#aldor
#loop
.line Netherstorm,28.43,41.71,28.33,40.23,28.57,37.74,30.85,39.73,29.61,44.04,28.43,41.71
.goto Netherstorm,28.43,41.71,45,0
.goto Netherstorm,28.33,40.23,45,0
.goto Netherstorm,28.57,37.74,45,0
.goto Netherstorm,30.85,39.73,45,0
.goto Netherstorm,29.61,44.04,45,0
>>Kill |cRXP_ENEMY_Daughters of Destiny|r
.complete 10380,2 
.mob +Daughter of Destiny
.skill riding,<225,1
step
#aldor
#loop
.line Netherstorm,28.43,41.71,28.33,40.23,30.85,39.73,29.61,44.04,28.43,41.71
.goto Netherstorm,28.43,41.71,45,0
.goto Netherstorm,28.33,40.23,45,0
.goto Netherstorm,30.85,39.73,45,0
.goto Netherstorm,29.61,44.04,45,0
.goto Netherstorm,28.43,41.71,45,0
>>Kill |cRXP_ENEMY_Daughters of Destiny|r
.complete 10380,2 
.mob +Daughter of Destiny
.skill riding,225,1
step
#aldor
.goto Netherstorm,26.0,38.7
>>Kill |cRXP_ENEMY_Overseer Azarad|r inside Manaforge Ara. Loot the |cRXP_LOOT_Ara Access Crystal|r
>>|cRXP_WARN_Look for a group of at least 3 people for completing this quest|r
.complete 10323,2 
.mob Overseer Azarad
step
#aldor
.goto 1953/530,4037.400,4017.100
>>Click to the |cRXP_PICK_Ara Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Demons|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10323,1 
.skipgossip
step
#completewith next
.subzone 3852 >> Return to Tuluman's Landing
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaylaan|r
.turnin 10380 >> Turn in A Dark Pact
.accept 10381 >> Accept Aldor No More
.goto Netherstorm,34.80,38.30
.target Kaylaan
step
.skill riding,225,1
#completewith next
.goto Netherstorm,45.31,34.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grennik|r
.fly Area 52>> Fly to Area 52
.target Grennik
.subzoneskip 3712
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Karja|r and |cRXP_FRIENDLY_Exarch Orelis|r
.turnin 10381 >> Turn in Aldor No More
.target +Exarch Orelis
.goto Netherstorm,32.07,64.18
.turnin 10323 >> Turn in Shutting Down Manaforge Ara
.accept 10407 >> Accept Socrethar's Shadow
.target +Anchorite Karja
.goto Netherstorm,32.04,64.18
step
.skill riding,225,1
#completewith next
.goto Netherstorm,33.74,63.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krexcil|r
.fly The Stormspire>> Fly to The Stormspire
.target Krexcil
.subzoneskip 3712,1
step
#aldor
.goto Netherstorm,36.85,27.82
>>Kill |cRXP_ENEMY_Morug|r. Loot him for the |cRXP_LOOT_First Half of Socrethar's Stone|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed|r
.complete 10407,1 
.mob Forgemaster Morug
step
#aldor
.goto Netherstorm,40.87,19.54
>>Kill |cRXP_ENEMY_Silroth|r. Loot him for the |cRXP_LOOT_Second Half of Socrethar's Stone|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed|r
.complete 10407,2 
.mob Silroth
step
.skill riding,225,1
#completewith next
.goto Netherstorm,45.31,34.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grennik|r
.fly Area 52>> Fly to Area 52
.target Grennik
.subzoneskip 3712
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Orelis|r
.turnin 10407 >> Turn in Socrethar's Shadow
.accept 10410 >> Accept Ishanah's Help
.target Anchorite Karja
.goto Netherstorm,32.04,64.18
step << !Mage
.skill riding,225,1
#completewith next
.goto Netherstorm,45.31,34.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grennik|r
.fly Shattrath City >> Fly to Shattrath
.target Grennik
.subzoneskip 3712
step << Mage
.cast 33690 >> |cRXP_WARN_Cast|r |T135760:0|t[Teleport: Shattrath]
.usespell 33690
.zoneskip Shattrath City
step
#completewith next
.zone Shattrath City >> Travel to Shattrath City
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishanah|r
.turnin 10410 >> Turn in Ishanah's Help
.accept 10409 >> Accept Deathblow to the Legion
.target Ishanah
.goto 1955/530,5822.300,-1732.900
step
.skill riding,225,1
#completewith next
.goto Shattrath City,64.061,41.112
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r
.fly The Stormspire>> Fly to The Stormspire
.target Nutral
step
.isOnQuest 10409
#optional
.goto 1953/530,3451.700,4774.700
.xp >70,1
.cast 35745 >> |cRXP_WARN_Use|r |T134465:0|t[Socrethar's Teleportation Stone] |cRXP_WARN_at the teleporter to create a portal to Socrethar's Seat|r
>>|cRXP_WARN_You will need a 5 man group for this quest. It is recommended to have a dedicated Tank and Healer|r
.use 29796
step
.isOnQuest 10409
#optional
.goto 1953/530,3451.700,4774.700
.xp >70,1
.subzone 3742 >> Go through the teleporter to Socrethar's Seat
step
#optional
#completewith next
.subzone 3742 >> Fly on your mount to Socrethar's Seat
step
.goto 1953/530,3774.200,4806.200,10,0 
.goto 1953/530,3848.500,4946.900
>>Talk to |cRXP_FRIENDLY_Adyen the Lightwarden|r to begin the RP once your group is ready
>>Kill |cRXP_ENEMY_Socrethar|r
>>|cRXP_WARN_You will need a 5 man group for this quest. It is recommended to have a dedicated Tank and Healer|r
.complete 10409,1
.mob Socrethar
.target Adyen the Lightwarden
step
#completewith next
.zone Shattrath City >> Return to Shattrath City
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishanah|r
.turnin 10409 >> Turn in Deathblow to the Legion
.target Ishanah
.goto 1955/530,5822.300,-1732.900
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#group RXP TBC Reputation Guide
#subgroup The Scryers
#name 2. Netherstorm (Scryers)
#next 3. Shadowmoon Valley (Scryers)
step
#completewith next
.zone Netherstorm >> Travel to Netherstorm
step
#scryer
.goto Netherstorm,32.00,64.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r
.accept 10189 >> Accept Manaforge B'naar
.target Spymaster Thalodien
step
#scryer
.goto Netherstorm,27.58,65.19,30,0
.goto Netherstorm,27.00,65.67
>>Kill |cRXP_ENEMY_Captain Arathyn|r. Loot him for the |cRXP_LOOT_B'naar Personnel Roster|r
.complete 10189,1 
.mob Captain Arathyn
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r and |cRXP_FRIENDLY_Magistrix Larynna|r
.goto Netherstorm,31.36,66.15,-1
.turnin 10189 >> Turn in Manaforge B'naar
.accept 10193 >> Accept High Value Targets
.target +Spymaster Thalodien
.goto Netherstorm,32.00,64.08,-1
.accept 10204 >> Accept Bloodgem Crystals
.target +Magistrix Larynna
.goto Netherstorm,32.05,63.99,-1
step
#scryer
#completewith Geologists
>>Kill |cRXP_ENEMY_Sunfury Magisters|r. Loot them for a |T132787:0|t[|cRXP_LOOT_Bloodgem Shard|r]
.collect 28452,1,10204 
.mob Sunfury Magister
step
#scryer
#completewith Geologists
.use 28452 >>|cRXP_WARN_Channel the|r |T132787:0|t[|cRXP_LOOT_Bloodgem Shard|r] |cRXP_WARN_on one of the floating Bloodgem Crystals|r
.complete 10204,1 
step
#scryer
#label Geologists
#loop
.goto Netherstorm,22.6,73.4,0
.goto Netherstorm,28.8,72.8,0
.goto Netherstorm,25.4,67.4,0
.goto Netherstorm,22.6,73.4,60,0
.goto Netherstorm,28.8,72.8,60,0
.goto Netherstorm,25.4,67.4,60,0
>>Kill |cRXP_ENEMY_Sunfury Geologists|r
.complete 10193,3 
.mob Sunfury Geologist
step
#scryer
#loop
.line Netherstorm,26.44,68.93,25.64,68.86,25.59,68.10,24.90,66.46,24.93,65.53,25.47,65.14,26.44,68.93
.goto Netherstorm,26.44,68.93,45,0
.goto Netherstorm,25.64,68.86,45,0
.goto Netherstorm,25.59,68.10,45,0
.goto Netherstorm,24.90,66.46,45,0
.goto Netherstorm,24.93,65.53,45,0
.goto Netherstorm,25.47,65.14,45,0
.goto Netherstorm,26.44,68.93,45,0
>>Kill |cRXP_ENEMY_Sunfury Magisters|r. Loot them for a |T132787:0|t[|cRXP_LOOT_Bloodgem Shard|r]
.collect 28452,1,10204 
.isOnQuest 10204
.mob Sunfury Magister
step
#scryer
.goto Netherstorm,26.07,68.37,-1
.goto Netherstorm,26.18,68.89,-1
.goto Netherstorm,26.43,68.38,-1
.goto Netherstorm,26.25,68.54,-1
.goto Netherstorm,25.16,66.11,-1
.goto Netherstorm,25.30,65.52,-1
.goto Netherstorm,25.51,65.90,-1
.goto Netherstorm,25.30,65.85,-1
.use 28452 >>|cRXP_WARN_Use the|r |T132787:0|t[|cRXP_LOOT_Bloodgem Shard|r] |cRXP_WARN_on one of the floating Bloodgem Crystals|r
.complete 10204,1 
.isOnQuest 10204
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r and |cRXP_FRIENDLY_Magistrix Larynna|r
.turnin 10193 >> Turn in High Value Targets
.accept 10329 >> Accept Shutting Down Manaforge B'naar
.target +Spymaster Thalodien
.goto Netherstorm,32.00,64.08,-1
.turnin 10204 >> Turn in Bloodgem Crystals
.target +Magistrix Larynna
.goto Netherstorm,32.05,63.99,-1
step
#scryer
.goto Netherstorm,24.20,68.10,40,0
.goto Netherstorm,23.68,70.02,40,0
.goto Netherstorm,23.85,70.77
>>Kill |cRXP_ENEMY_Overseer Theredis|r inside Manaforge B'naar. Loot him for the |cRXP_LOOT_B'naar Access Crystal|r
.complete 10329,2 
.mob Overseer Theredis
step
#scryer
.goto Netherstorm,23.217,68.284
>>Click to the |cRXP_PICK_B'naar Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Sunfury|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10329,1 
.skipgossip
.mob Sunfury Warp-Engineer
.mob Sunfury Warp-Master
.mob Sunfury Technician
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r
.turnin 10329 >> Turn in Shutting Down Manaforge B'naar
.accept 10194 >> Accept Stealth Flight
.target Spymaster Thalodien
step
#scryer
.goto Netherstorm,33.81,64.23
.fly >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veronia|r to fly to Manaforge Coruu
.turnin 10194 >> Turn in Stealth Flight
.accept 10652 >> Accept Behind Enemy Lines
.skipgossip
.timer 42,Behind Enemy Lines flight
.target Veronia
step
#scryer
.goto Netherstorm,48.24,86.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caledis Brightdawn|r once you land
.turnin 10652 >> Turn in Behind Enemy Lines
.accept 10197 >> Accept A Convincing Disguise
.target Caledis Brightdawn
step
.skill riding,225,1
#aldor
#completewith next
.goto Netherstorm,44.07,76.56,40,0
.goto Netherstorm,45.55,78.99,40 >> Cross the bridge toward Manaforge Coruu
.zoneskip Netherstorm,1
step
#scryer
#loop
.line Netherstorm,51.82,81.16,52.34,82.73,51.04,82.80,50.19,84.42,50.67,82.16,51.53,81.80,51.36,81.00,51.82,81.16
.goto Netherstorm,51.82,81.16,55,0
.goto Netherstorm,52.34,82.73,55,0
.goto Netherstorm,51.04,82.80,55,0
.goto Netherstorm,50.19,84.42,55,0
.goto Netherstorm,50.67,82.16,55,0
.goto Netherstorm,51.53,81.80,55,0
.goto Netherstorm,51.36,81.00,55,0
>>Kill |cRXP_ENEMY_Sunfury Researchers|r. Loot them for their |cRXP_LOOT_Sunfury Researcher Gloves|r
>>Kill |cRXP_ENEMY_Sunfury Guardsmen|r. Loot them for their |cRXP_LOOT_Medallion|r
>>Kill |cRXP_ENEMY_Sunfury Arcanists|r. Loot them for their |cRXP_LOOT_Robes|r
.complete 10197,1 
.mob +Sunfury Researcher
.complete 10197,2 
.mob +Sunfury Guardsman
.complete 10197,3 
.mob +Sunfury Arcanist
step
#scryer
.goto Netherstorm,48.24,86.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caledis Brightdawn|r
.turnin 10197 >> Turn in A Convincing Disguise
.accept 10198 >> Accept Information Gathering
.target Caledis Brightdawn
step
#scryer
#completewith next
.cast 34603 >> |cRXP_WARN_Use the |r|T134473:0|t[Sunfury Disguise] |cRXP_WARN_before you enter Manaforge Coruu|r
.use 28607
step
#scryer
.goto Netherstorm,48.25,83.86,20,0
.timer 121,Information Gathering RP
.goto Netherstorm,48.15,84.18
.use 28607 >>|cRXP_WARN_While disguised, enter Manaforge Coruu|r
>>|cRXP_WARN_Go into the southern room. Wait out the RP between |cRXP_ENEMY_Commander Dawnforge|r, |cRXP_ENEMY_Arcanist Ardonis|r and|r |cRXP_ENEMY_Pathaleon the Calculator's Image|r
.complete 10198,1 
.mob Commander Dawnforge
.mob Arcanist Ardonis
.mob Pathaleon the Calculator's Image
step
#scryer
.goto Netherstorm,48.24,86.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caledis Brightdawn|r
.turnin 10198 >> Turn in Information Gathering
.accept 10330 >> Accept Shutting Down Manaforge Coruu
.target Caledis Brightdawn
step
#scryer
.goto Netherstorm,49.02,81.52
>>Kill |cRXP_ENEMY_Overseer Seylanna|r inside Manaforge Coruu. Loot her for the |cRXP_LOOT_Coruu Access Crystal|r
.complete 10330,2 
.mob Overseer Seylanna
step
#scryer
#label Coruu
.goto Netherstorm,48.926,81.613
>>Click to the |cRXP_PICK_Coruu Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Sunfury|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10330,1 
.skipgossip
step
#scryer
.goto Netherstorm,48.24,86.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caledis Brightdawn|r
.turnin 10330 >> Turn in Shutting Down Manaforge Coruu
.accept 10200 >> Accept Return to Thalodien
.target Caledis Brightdawn
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r and |cRXP_FRIENDLY_Magistrix Larynna|r
.turnin 10200 >> Turn in Return to Thalodien
.accept 10338 >> Accept Shutting Down Manaforge Duro
.target +Spymaster Thalodien
.goto Netherstorm,32.00,64.08
.accept 10341 >> Accept Kick Them While They're Down
.target +Magistrix Larynna
.goto Netherstorm,32.05,63.99
step
#scryer
.goto Netherstorm,59.99,68.52
>>Kill |cRXP_ENEMY_Overseer Athanel|r inside Manaforge Duro. Loot him for the |cRXP_LOOT_Duro Access Crystal|r
.complete 10338,2 
.mob Overseer Athanel
step
#scryer
.goto Netherstorm,59.19,66.72
>>Click to the |cRXP_PICK_Duro Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Sunfury|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10338,1 
.skipgossip
step
#scryer
#loop
.line Netherstorm,58.84,62.54,58.31,62.97,58.10,62.71,57.76,63.29,57.21,63.42,56.82,63.89,57.34,64.44,57.39,65.29,57.22,65.92,56.95,66.52,57.34,67.19,57.38,66.58,57.22,65.92,57.39,65.29,57.34,64.44,57.91,64.06,57.76,63.29,58.10,62.71,58.31,62.97,58.84,62.54,59.10,63.14,59.45,63.04,59.20,62.36,58.84,62.54
.goto Netherstorm,58.84,62.54,50,0
.goto Netherstorm,58.31,62.97,50,0
.goto Netherstorm,58.10,62.71,50,0
.goto Netherstorm,57.76,63.29,50,0
.goto Netherstorm,57.21,63.42,50,0
.goto Netherstorm,56.82,63.89,50,0
.goto Netherstorm,57.34,64.44,50,0
.goto Netherstorm,57.39,65.29,50,0
.goto Netherstorm,57.22,65.92,50,0
.goto Netherstorm,56.95,66.52,50,0
.goto Netherstorm,57.34,67.19,50,0
.goto Netherstorm,57.38,66.58,50,0
.goto Netherstorm,57.22,65.92,50,0
.goto Netherstorm,57.39,65.29,50,0
.goto Netherstorm,57.34,64.44,50,0
.goto Netherstorm,57.91,64.06,50,0
.goto Netherstorm,57.76,63.29,50,0
.goto Netherstorm,58.10,62.71,50,0
.goto Netherstorm,58.31,62.97,50,0
.goto Netherstorm,58.84,62.54,50,0
.goto Netherstorm,59.10,63.14,50,0
.goto Netherstorm,59.45,63.04,50,0
.goto Netherstorm,59.20,62.36,50,0
>>Kill |cRXP_ENEMY_Sunfury Conjurers|r, |cRXP_ENEMY_Bowmen|r and |cRXP_ENEMY_Centurions|r. Loot them for their |cRXP_LOOT_Signets|r and a |cRXP_LOOT_Tome|r
.complete 10341,1 
.mob +Sunfury Conjurer
.complete 10341,2 
.mob +Sunfury Bowman
.complete 10341,3 
.mob +Sunfury Centurion
.mob +Sunfury Conjurer
.mob +Sunfury Bowman
.mob +Sunfury Centurion
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r and |cRXP_FRIENDLY_Magistrix Larynna|r
.turnin 10338 >> Turn in Shutting Down Manaforge Duro
.accept 10365 >> Accept Shutting Down Manaforge Ara
.target +Spymaster Thalodien
.goto Netherstorm,32.00,64.08
.turnin 10341 >> Turn in Kick Them While They're Down
.accept 10202 >> Accept A Defector
.target +Magistrix Larynna
.goto Netherstorm,32.05,63.99
step
.skill riding,225,1
#completewith next
.goto Netherstorm,33.59,37.77,50,0
.goto Netherstorm,31.51,41.63,50 >> Cross the bridge to Manaforge Ara
step
#scryer
.skill riding,225,1
#completewith next
.goto Netherstorm,29.56,41.80,50,0
.goto Netherstorm,29.42,39.76,50 >> Travel up the hill to Manaforge Ara
step
#scryer
.goto Netherstorm,26.19,41.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Theledorn|r
.turnin 10202 >> Turn in A Defector
.accept 10432 >> Accept Damning Evidence
.target Magister Theledorn
step
#scryer
#loop
.line Netherstorm,28.43,41.71,28.33,40.23,28.57,37.74,30.85,39.73,29.61,44.04,28.43,41.71
.goto Netherstorm,28.43,41.71,45,0
.goto Netherstorm,28.33,40.23,45,0
.goto Netherstorm,28.57,37.74,45,0
.goto Netherstorm,30.85,39.73,45,0
.goto Netherstorm,29.61,44.04,45,0
>>Kill |cRXP_ENEMY_Demons|r at Manaforge Ara. Loot the Demons for their |cRXP_LOOT_Orders|r
.complete 10432,1 
.mob +Daughter of Destiny
.mob +Gan'arg Warp-Tinker
.mob +Mo'arg Warp-Master
.skill riding,<225,1
step
#scryer
#loop
.line Netherstorm,28.43,41.71,28.33,40.23,30.85,39.73,29.61,44.04,28.43,41.71
.goto Netherstorm,28.43,41.71,45,0
.goto Netherstorm,28.33,40.23,45,0
.goto Netherstorm,30.85,39.73,45,0
.goto Netherstorm,29.61,44.04,45,0
>>Kill |cRXP_ENEMY_Demons|r at Manaforge Ara. Loot the Demons for their |cRXP_LOOT_Orders|r
.complete 10432,1 
.mob +Daughter of Destiny
.mob +Gan'arg Warp-Tinker
.mob +Mo'arg Warp-Master
.skill riding,225,1
step
#scryer
.goto Netherstorm,26.0,38.7
>>Kill |cRXP_ENEMY_Overseer Azarad|r inside Manaforge Ara. Loot the |cRXP_LOOT_Ara Access Crystal|r
>>|cRXP_WARN_Look for a group of at least 3 people for completing this quest|r
.complete 10365,2 
.mob Overseer Azarad
step
#scryer
.goto 1953/530,4037.400,4017.100
>>Click to the |cRXP_PICK_Ara Control Console|r to start the event
>>Kill the |cRXP_ENEMY_Demons|r that try to stop the shutdown. The shutdown will complete after 2 minutes
.complete 10365,1 
.skipgossip
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r
.turnin 10365 >> Turn in Shutting Down Manaforge Ara
.turnin 10432 >> Turn in Damning Evidence
.accept 10508 >> Accept A Gift for Voren'thal
.target Spymaster Thalodien
.goto Netherstorm,32.00,64.08
step
.skill riding,225,1
#completewith next
.goto Netherstorm,33.74,63.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krexcil|r
.fly The Stormspire>> Fly to The Stormspire
.target Krexcil
.subzoneskip 3712,1
step
#scryer
.goto Netherstorm,36.85,27.82
>>Kill |cRXP_ENEMY_Morug|r. Loot him for the |cRXP_LOOT_First Half of Socrethar's Stone|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed|r
.complete 10508,1 
.mob Forgemaster Morug
step
#scryer
.goto Netherstorm,40.87,19.54
>>Kill |cRXP_ENEMY_Silroth|r. Loot him for the |cRXP_LOOT_Second Half of Socrethar's Stone|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed|r
.complete 10508,2 
.mob Silroth
step
.skill riding,225,1
#completewith next
.goto Netherstorm,45.31,34.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grennik|r
.fly Area 52>> Fly to Area 52
.target Grennik
.subzoneskip 3712
step
#scryer
.goto Netherstorm,32.00,64.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spymaster Thalodien|r
.turnin 10508 >> Turn in A Gift for Voren'thal
.accept 10509 >> Accept Bound for Glory
.target Spymaster Thalodien
step << !Mage
.skill riding,225,1
#completewith next
.goto Netherstorm,45.31,34.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grennik|r
.fly Shattrath City >> Fly to Shattrath
.target Grennik
.subzoneskip 3712
step << Mage
.cast 33690 >> |cRXP_WARN_Cast|r |T135760:0|t[Teleport: Shattrath]
.usespell 33690
.zoneskip Shattrath City
step
#completewith next
.zone Shattrath City >> Travel to Shattrath City
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Voren'thal the Seer|r
.turnin 10509 >> Turn in Bound for Glory
.accept 10507 >> Accept Turning Point
.target Voren'thal the Seer
.goto Shattrath City,42.782,91.723
step
.skill riding,225,1
#completewith next
.goto Shattrath City,64.061,41.112
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r
.fly The Stormspire>> Fly to The Stormspire
.target Nutral
step
#optional
.goto 1953/530,3451.700,4774.700
.xp >70,1
.cast 35745 >> |cRXP_WARN_Use|r |T134465:0|t[Socrethar's Teleportation Stone] |cRXP_WARN_at the teleporter to create a portal to Socrethar's Seat|r
>>|cRXP_WARN_You will need a 5 man group for this quest. It is recommended to have a dedicated Tank and Healer|r
.use 29796
step
#optional
.goto 1953/530,3451.700,4774.700
.xp >70,1
.subzone 3742 >> Go through the teleporter to Socrethar's Seat
step
#optional
#completewith next
.subzone 3742 >> Fly on your mount to Socrethar's Seat
step
.goto 1953/530,3774.200,4806.200,10,0 
.goto 1953/530,3848.500,4946.900
>>Kill |cRXP_ENEMY_Socrethar|r
.use 30259 >>|cRXP_WARN_Use|r |T134335:0|t[Voren'thal's Presence] |cRXP_WARN_on |cRXP_ENEMY_Socrethar|r to weaken him|r
>>|cRXP_WARN_You will need a 5 man group for this quest. It is recommended to have a dedicated Tank and Healer|r
.complete 10507,1
.mob Socrethar
step
#completewith next
.zone Shattrath City >> Return to Shattrath City
step
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Voren'thal the Seer|r
.turnin 10507 >> Turn in Turning Point
.target Voren'thal the Seer
.goto Shattrath City,42.782,91.723
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#group RXP TBC Reputation Guide
#subgroup The Aldor
#name 3. Shadowmoon Valley (Aldor)
step
#completewith next
.zone Shadowmoon Valley >> Travel to Shadowmoon Valley
step
#completewith next
.subzone 3754 >> Travel to the Altar of Sha'tar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Onaala|r and |cRXP_FRIENDLY_Vindicator Aluumen|r
.accept 10619 >> Accept The Ashtongue Tribe
.target +Vindicator Aluumen
.goto Shadowmoon Valley,61.172,29.147,-1
.accept 10587 >> Accept Karabor Training Grounds
.goto Shadowmoon Valley,61.198,29.232,-1
.target +Exarch Onaala
step
.goto Shadowmoon Valley,62.648,28.445
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ceyla|r
.accept 10568 >> Accept Tablets of Baa'ri
.target Anchorite Ceyla
step
.skill riding,225,1
#completewith TabletFragments
.goto 1948/530,1207.700,-3170.700,40 >> Travel to the Ruins of Baa'ri
step
#completewith next
>>Kill |cRXP_ENEMY_Ashtongue Handlers|r, |cRXP_ENEMY_Ashtongue Warriors|r and |cRXP_ENEMY_Ashtongue Shamans|r
.complete 10619,1 
.mob +Ashtongue Handler
.complete 10619,2 
.mob +Ashtongue Warrior
.complete 10619,3 
.mob +Ashtongue Shaman
step
#label TabletFragments
#loop
.goto Shadowmoon Valley,56.0,37.1,0
.goto Shadowmoon Valley,59.0,34.9,70,0
.goto Shadowmoon Valley,56.0,37.1,70,0
.goto Shadowmoon Valley,59.1,39.3,70,0
>>Loot the |cRXP_PICK_Baa'ri Tablet Fragments|r on the ground
.complete 10568,1 
step
#loop
.goto Shadowmoon Valley,56.0,37.1,0
.goto Shadowmoon Valley,59.0,34.9,70,0
.goto Shadowmoon Valley,56.0,37.1,70,0
.goto Shadowmoon Valley,59.1,39.3,70,0
>>Kill |cRXP_ENEMY_Ashtongue Handlers|r, |cRXP_ENEMY_Ashtongue Warriors|r and |cRXP_ENEMY_Ashtongue Shamans|r
.complete 10619,1 
.mob +Ashtongue Handler
.complete 10619,2 
.mob +Ashtongue Warrior
.complete 10619,3 
.mob +Ashtongue Shaman
step
.goto Shadowmoon Valley,61.172,29.147
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Aluumen|r
.turnin 10619 >> Turn in The Ashtongue Tribe
.accept 10816 >> Accept Reclaiming Holy Grounds
.target Vindicator Aluumen
step
.goto Shadowmoon Valley,62.648,28.445
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ceyla|r
.turnin 10568 >> Turn in Tablets of Baa'ri
.accept 10571 >> Accept Oronu the Elder
.target Anchorite Ceyla
step
.skill riding,225,1
#completewith next
.goto 1948/530,1207.700,-3170.700,40,0
.goto 1948/530,1137.300,-3233.100,60 >> Return to the Ruins of Baa'ri
step
.goto Shadowmoon Valley,57.191,32.877
>>Kill |cRXP_ENEMY_Oronu|r on the balcony
.complete 10571,1 
.mob Oronu the Elder
step
#label gizzard
.goto Shadowmoon Valley,62.648,28.445
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ceyla|r
.turnin 10571 >> Turn in Oronu the Elder
.accept 10574 >> Accept The Ashtongue Corruptors
.target Anchorite Ceyla
step
.goto Shadowmoon Valley,49.887,23.012
>>Destroy the totems protecting |cRXP_ENEMY_Lakaan|r. Kill and loot him for his |cRXP_LOOT_Medallion Fragment|r
.complete 10574,3 
.mob Lakaan
step
.goto Shadowmoon Valley,48.289,39.564
>>Destroy the totems protecting |cRXP_ENEMY_Uylaru|r. Kill and loot him for his |cRXP_LOOT_Medallion Fragment|r
.complete 10574,4 
.mob Uylaru
step
.goto Shadowmoon Valley,51.164,52.840
>>Destroy the totems protecting |cRXP_ENEMY_Eykenen|r. Kill and loot him for his |cRXP_LOOT_Medallion Fragment|r
.complete 10574,1 
.mob Eykenen
step
.goto Shadowmoon Valley,57.083,73.687
>>Destroy the totems protecting |cRXP_ENEMY_Haalum|r. Kill and loot him for |cRXP_LOOT_Haalum's Medallion Fragment|r
.complete 10574,2 
.mob Haalum
step
.goto Shadowmoon Valley,62.648,28.445
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ceyla|r
.turnin 10574 >> Turn in The Ashtongue Corruptors
.accept 10575 >> Accept The Warden's Cage
.target Anchorite Ceyla
step
#completewith next
+|cRXP_WARN_Go down the small opening to talk to |cRXP_FRIENDLY_Sanoru|r underground|r
step
.goto Shadowmoon Valley,57.328,49.577
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanoru|r
.turnin 10575 >> Turn in The Warden's Cage
.target Sanoru
step
#loop
.goto Shadowmoon Valley,71.6,35.2,0
.goto Shadowmoon Valley,68.2,40.0,60,0
.goto Shadowmoon Valley,71.4,40.0,60,0
.goto Shadowmoon Valley,71.6,35.2,60,0
.goto Shadowmoon Valley,69.0,34.2,60,0
>>Kill |cRXP_ENEMY_Shadowmoon Slayers|r, |cRXP_ENEMY_Shadowmoon Chosens|r and |cRXP_ENEMY_Shadowmoon Darkweavers|r
.complete 10816,1 
.mob +Shadowmoon Slayer
.complete 10816,2 
.mob +Shadowmoon Chosen
.complete 10816,3 
.mob +Shadowmoon Darkweaver
step
.goto Shadowmoon Valley,68.8,49.2
>>Kill |cRXP_ENEMY_Demon Hunter Initiates|r and |cRXP_ENEMY_Demon Hunter Supplicants|r. Loot them for their |cRXP_LOOT_Sunfury Glaives|r
.complete 10587,1 
.mob Demon Hunter Supplicant
.mob Demon Hunter Initiate
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Onaala|r and |cRXP_FRIENDLY_Vindicator Aluumen|r
.turnin 10587 >> Turn in Karabor Training Grounds
.accept 10637 >> Accept A Necessary Distraction
.target +Exarch Onaala
.goto Shadowmoon Valley,61.198,29.232,-1
.turnin 10816 >> Turn in Reclaiming Holy Grounds
.target +Vindicator Aluumen
.goto Shadowmoon Valley,61.172,29.147,-1
step
#completewith next
.goto Shadowmoon Valley,69.8,51.0,0
.goto Shadowmoon Valley,72.2,49.2,0
.goto Shadowmoon Valley,71.4,52.6,0
.goto Shadowmoon Valley,69.8,51.0,50,0
.goto Shadowmoon Valley,72.2,49.2,50,0
.goto Shadowmoon Valley,71.4,52.6,50,0
>>Kill |cRXP_ENEMY_Sunfury Warlocks|r. Loot them for a |T134937:0|t[Scroll of Demonic Unbanishing]
.collect 30811,1,10637,1 
.mob Sunfury Warlock
step
.goto Shadowmoon Valley,69.841,51.410
.use 30811 >> |cRXP_WARN_Use the|r |T134937:0|t[Scroll of Demonic Unbanishing] |cRXP_WARN_on|r |cRXP_ENEMY_Azaloth|r
.complete 10637,1 
.mob Azaloth
step
.goto Shadowmoon Valley,61.198,29.232
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Onaala|r
.turnin 10637 >> Turn in A Necessary Distraction
.accept 10640 >> Accept Altruis
.target Exarch Onaala
step
#completewith next
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10640 >> Turn in Altruis
.accept 10641 >> Accept Against the Legion
.accept 10668 >> Accept Against the Illidari
.accept 10669 >> Accept Against All Odds
.target Altruis the Sufferer
step
#completewith Xelethslain
.zone Zangarmarsh >> Travel to Zangarmarsh
step
#completewith next
.goto Zangarmarsh,16.234,40.689
.cast 37904 >>|cRXP_WARN_Use the|r |T135127:0|t[Imbued Silver Spear] |cRXP_WARN_at the portal to summon|r |cRXP_ENEMY_Xeleth|r
.use 30853
step
#label Xelethslain
.goto Zangarmarsh,16.234,40.689
>>Kill |cRXP_ENEMY_Xeleth|r
.complete 10669,1 
.mob Xeleth
step
#completewith next
.zone Netherstorm >> Travel to Netherstorm
step
.goto Netherstorm,41.2,21.6
>>Kill a |cRXP_ENEMY_Wrath Priestess|r. Loot them for their |T136124:0|t[|cRXP_LOOT_Freshly Drawn Blood|r]. Note this only lasts for 1 minute
.use 30850 >> |cRXP_WARN_Use the|r |T136124:0|t[|cRXP_LOOT_Freshly Drawn Blood|r] |cRXP_WARN_to summon the|r |cRXP_ENEMY_Avatar of Sathal|r
>>Kill the |cRXP_ENEMY_Avatar of Sathal|r
.collect 30850,1,10641,1
.mob +Wrath Priestess
.complete 10641,1 
.mob +Avatar of Sathal
step
#completewith next
.zone Shadowmoon Valley >> Travel to Shadowmoon Valley
step
.goto Shadowmoon Valley,28.6,50.6
>>Kill |cRXP_ENEMY_Lothros|r
>>|cRXP_WARN_He patrols slightly in Illidari Point|r
.complete 10668,1 
.mob Lothros
step
#completewith next
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10641 >> Turn in Against the Legion
.turnin 10668 >> Turn in Against the Illidari
.turnin 10669 >> Turn in Against All Odds
.accept 10646 >> Accept Illidan's Pupil
.target Altruis the Sufferer
step
.goto Nagrand,27.33,43.09
>>Talk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.complete 10646,1 
.skipgossip
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10646 >> Turn in Illidan's Pupil
.accept 10649 >> Accept The Book of Fel Names
.target Altruis the Sufferer
step
>>You must now find a group and kill |cRXP_ENEMY_Blackheart the Inciter|r in the Shadow Labyrinth. Loot him for the |cRXP_LOOT_Book of Fel Names|r
.complete 10649,1 
step
#completewith next
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10649 >> Turn in The Book of Fel Names
.accept 10650 >> Accept Return to the Aldor
.target Altruis the Sufferer
step
#completewith next
.zone Shadowmoon Valley >> Travel to Shadowmoon Valley
step
.goto Shadowmoon Valley,61.198,29.232
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Onaala|r
.turnin 10650 >> Turn in Return to the Aldor
.accept 10651 >> Accept Varedis Must Be Stopped
.target Exarch Onaala
step
>>Kill |cRXP_ENEMY_Varedis|r, |cRXP_ENEMY_Netharel|r, |cRXP_ENEMY_Theras|r and |cRXP_ENEMY_Alandien|r
>>|cRXP_WARN_It is recommended to complete this with a full group consisting of also a Tank and Healer|r
.use 30854 >> |cRXP_WARN_Use the|r |T133738:0|t[Book of Fel Names] |cRXP_WARN_on |cRXP_ENEMY_Varedis|r once he uses Metamorphosis. Note this has a 10 second cast time|r
.complete 10651,2 
.goto Shadowmoon Valley,68.73,52.73
.mob +Netharel
.complete 10651,3 
.goto Shadowmoon Valley,72.38,48.40
.mob +Theras
.complete 10651,4 
.goto Shadowmoon Valley,69.56,54.12
.mob +Alandien
.complete 10651,1 
.goto Shadowmoon Valley,72.18,53.68
.mob +Varedis
step
.goto Shadowmoon Valley,61.198,29.232
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Exarch Onaala|r
.turnin 10651 >> Turn in Varedis Must Be Stopped
.target Exarch Onaala
step
.goto 1948/530,2893.300,-3211.200
+|cRXP_WARN_Congratulations! You have reached the end of The Aldor reputation guide|r
>>Killing the |cRXP_ENEMY_Demons|r at Legion Hold for |T133832:0|t[|cRXP_FRIENDLY_Fel Armament|r] and |T136149:0|t[Mark of Sargeras] will increase your Aldor reputation when turned in. You may also buy these from the Auction House.
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#group RXP TBC Reputation Guide
#subgroup The Scryers
#name 3. Shadowmoon Valley (Scryers)
step
#completewith next
.subzone 3938 >> Travel to the Sanctum of the Stars in Shadowmoon Valley
step
.goto Shadowmoon Valley,54.730,58.199
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varen the Reclaimer|r
.accept 10807 >> Accept The Ashtongue Broken
.target Varen the Reclaimer
step
.goto Shadowmoon Valley,55.732,58.168
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larissa Sunstrike|r
.accept 10687 >> Accept Karabor Training Grounds
.target Larissa Sunstrike
step
.goto Shadowmoon Valley,56.258,59.586
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Thelis|r
.accept 10683 >> Accept Tablets of Baa'ri
.target Arcanist Thelis
step
#completewith BaariFragments
.subzone 3753 >> Travel to the Ruins of Baa'ri
step
#completewith BaariFragments
>>Kill |cRXP_ENEMY_Ashtongue Handlers|r, |cRXP_ENEMY_Ashtongue Warriors|r and |cRXP_ENEMY_Ashtongue Shamans|r
.complete 10807,1 
.mob +Ashtongue Handler
.complete 10807,2 
.mob +Ashtongue Warrior
.complete 10807,3 
.mob +Ashtongue Shaman
step
#label BaariFragments
#loop
.goto Shadowmoon Valley,57.6,39.2,0
.goto Shadowmoon Valley,57.6,39.2,70,0
.goto Shadowmoon Valley,60.8,34.6,70,0
.goto Shadowmoon Valley,55.8,39.4,70,0
.goto Shadowmoon Valley,60.6,38.2,70,0
>>Loot the |cRXP_PICK_Baa'ri Tablet Fragments|r on the ground
.complete 10683,1 
step
#loop
.goto Shadowmoon Valley,57.6,39.2,0
.goto Shadowmoon Valley,57.6,39.2,70,0
.goto Shadowmoon Valley,60.8,34.6,70,0
.goto Shadowmoon Valley,55.8,39.4,70,0
.goto Shadowmoon Valley,60.6,38.2,70,0
>>Kill |cRXP_ENEMY_Ashtongue Handlers|r, |cRXP_ENEMY_Ashtongue Warriors|r and |cRXP_ENEMY_Ashtongue Shamans|r
.complete 10807,1 
.mob +Ashtongue Handler
.complete 10807,2 
.mob +Ashtongue Warrior
.complete 10807,3 
.mob +Ashtongue Shaman
step
.goto Shadowmoon Valley,54.730,58.199
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varen the Reclaimer|r
.turnin 10807 >> Turn in The Ashtongue Broken
.accept 10817 >> Accept The Great Retribution
.target Varen the Reclaimer
step
.goto Shadowmoon Valley,56.258,59.586
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Thelis|r
.turnin 10683 >> Turn in Tablets of Baa'ri
.accept 10684 >> Accept Oronu the Elder
.target Arcanist Thelis
step
#completewith next
.subzone 3753 >> Travel to the Ruins of Baa'ri again
step
.goto Shadowmoon Valley,57.191,32.877
>>Kill |cRXP_ENEMY_Oronu|r on the balcony
.complete 10684,1 
.mob Oronu the Elder
step
.goto Shadowmoon Valley,56.258,59.586
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Thelis|r
.turnin 10684 >> Turn in Oronu the Elder
.accept 10685 >> Accept The Ashtongue Corruptors
.target Arcanist Thelis
step
.goto Shadowmoon Valley,57.083,73.687
>>Destroy the totems protecting |cRXP_ENEMY_Haalum|r. Kill and loot him for |cRXP_LOOT_Haalum's Medallion Fragment|r
.complete 10685,2 
.mob Haalum
step
.goto Shadowmoon Valley,51.164,52.840
>>Destroy the totems protecting |cRXP_ENEMY_Eykenen|r. Kill and loot him for his |cRXP_LOOT_Medallion Fragment|r
.complete 10685,1 
.mob Eykenen
step
.goto Shadowmoon Valley,48.289,39.564
>>Destroy the totems protecting |cRXP_ENEMY_Uylaru|r. Kill and loot him for his |cRXP_LOOT_Medallion Fragment|r
.complete 10685,4 
.mob Uylaru
step
.goto Shadowmoon Valley,49.887,23.012
>>Destroy the totems protecting |cRXP_ENEMY_Lakaan|r. Kill and loot him for his |cRXP_LOOT_Medallion Fragment|r
.complete 10685,3 
.mob Lakaan
step
.goto Shadowmoon Valley,56.258,59.586
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arcanist Thelis|r
.turnin 10685 >> Turn in The Ashtongue Corruptors
.accept 10686 >> Accept The Warden's Cage
.target Arcanist Thelis
step
#completewith next
+|cRXP_WARN_Go down the small opening to talk to |cRXP_FRIENDLY_Sanoru|r underground|r
step
.goto Shadowmoon Valley,57.328,49.577
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanoru|r
.turnin 10686 >> Turn in The Warden's Cage
.target Sanoru
step
.goto Shadowmoon Valley,68.8,49.2
>>Kill |cRXP_ENEMY_Demon Hunter Initiates|r and |cRXP_ENEMY_Demon Hunter Supplicants|r. Loot them for their |cRXP_LOOT_Sunfury Glaives|r
.complete 10687,1 
.mob Demon Hunter Supplicant
.mob Demon Hunter Initiate
step
#loop
.goto Shadowmoon Valley,71.6,35.2,0
.goto Shadowmoon Valley,68.2,40.0,60,0
.goto Shadowmoon Valley,71.4,40.0,60,0
.goto Shadowmoon Valley,71.6,35.2,60,0
.goto Shadowmoon Valley,69.0,34.2,60,0
>>Kill |cRXP_ENEMY_Shadowmoon Slayers|r, |cRXP_ENEMY_Shadowmoon Chosens|r and |cRXP_ENEMY_Shadowmoon Darkweavers|r
.complete 10817,1 
.mob +Shadowmoon Slayer
.complete 10817,2 
.mob +Shadowmoon Chosen
.complete 10817,3 
.mob +Shadowmoon Darkweaver
step
#completewith next
.subzone 3938 >> Return to the Sanctum of the Stars
step
.isQuestComplete 10817
.goto Shadowmoon Valley,54.730,58.199
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varen the Reclaimer|r
.turnin 10817 >> Turn in The Great Retribution
.target Varen the Reclaimer
step
.goto Shadowmoon Valley,55.732,58.168
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larissa Sunstrike|r
.turnin 10687 >> Turn in Karabor Training Grounds
.accept 10688 >> Accept A Necessary Distraction
.target Larissa Sunstrike
step
#completewith next
.goto Shadowmoon Valley,69.8,51.0,0
.goto Shadowmoon Valley,72.2,49.2,0
.goto Shadowmoon Valley,71.4,52.6,0
.goto Shadowmoon Valley,69.8,51.0,50,0
.goto Shadowmoon Valley,72.2,49.2,50,0
.goto Shadowmoon Valley,71.4,52.6,50,0
>>Kill |cRXP_ENEMY_Sunfury Warlocks|r. Loot them for a |T134937:0|t[Scroll of Demonic Unbanishing]
.collect 30811,1,10637,1 
.mob Sunfury Warlock
step
.goto Shadowmoon Valley,69.841,51.410
.use 30811 >> |cRXP_WARN_Use the|r |T134937:0|t[Scroll of Demonic Unbanishing] |cRXP_WARN_on|r |cRXP_ENEMY_Azaloth|r
.complete 10688,1 
.mob Azaloth
step
#optional
#completewith next
.subzone 3938 >> Return to the Sanctum of the Stars
step
.goto Shadowmoon Valley,55.732,58.168
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larissa Sunstrike|r
.turnin 10688 >> Turn in A Necessary Distraction
.accept 10689 >> Accept Altruis
.target Larissa Sunstrike
step
#completewith next
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10640 >> Turn in Altruis
.accept 10641 >> Accept Against the Legion
.accept 10668 >> Accept Against the Illidari
.accept 10669 >> Accept Against All Odds
.target Altruis the Sufferer
step
#completewith Xelethslain
.zone Zangarmarsh >> Travel to Zangarmarsh
step
#completewith next
.goto Zangarmarsh,16.234,40.689
.cast 37904 >>|cRXP_WARN_Use the|r |T135127:0|t[Imbued Silver Spear] |cRXP_WARN_at the portal to summon|r |cRXP_ENEMY_Xeleth|r
.use 30853
step
#label Xelethslain
.goto Zangarmarsh,16.234,40.689
>>Kill |cRXP_ENEMY_Xeleth|r
.complete 10669,1 
.mob Xeleth
step
#completewith next
.zone Netherstorm >> Travel to Netherstorm
step
.goto Netherstorm,41.2,21.6
>>Kill a |cRXP_ENEMY_Wrath Priestess|r. Loot them for their |T136124:0|t[|cRXP_LOOT_Freshly Drawn Blood|r]. Note this only lasts for 1 minute
.use 30850 >> |cRXP_WARN_Use the|r |T136124:0|t[|cRXP_LOOT_Freshly Drawn Blood|r] |cRXP_WARN_to summon the|r |cRXP_ENEMY_Avatar of Sathal|r
>>Kill the |cRXP_ENEMY_Avatar of Sathal|r
.collect 30850,1,10641,1
.mob +Wrath Priestess
.complete 10641,1 
.mob +Avatar of Sathal
step
#completewith next
.zone Shadowmoon Valley >> Travel to Shadowmoon Valley
step
.goto Shadowmoon Valley,28.6,50.6
>>Kill |cRXP_ENEMY_Lothros|r
>>|cRXP_WARN_He patrols slightly in Illidari Point|r
.complete 10668,1 
.mob Lothros
step
#completewith next
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10641 >> Turn in Against the Legion
.turnin 10668 >> Turn in Against the Illidari
.turnin 10669 >> Turn in Against All Odds
.accept 10646 >> Accept Illidan's Pupil
.target Altruis the Sufferer
step
.goto Nagrand,27.33,43.09
>>Talk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.complete 10646,1 
.skipgossip
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10646 >> Turn in Illidan's Pupil
.accept 10649 >> Accept The Book of Fel Names
.target Altruis the Sufferer
step
>>You must now find a group and kill |cRXP_ENEMY_Blackheart the Inciter|r in the Shadow Labyrinth. Loot him for the |cRXP_LOOT_Book of Fel Names|r
.complete 10649,1 
step
#completewith next
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.turnin 10649 >> Turn in The Book of Fel Names
.accept 10691 >> Accept Return to the Scryers
.target Altruis the Sufferer
step
#completewith next
.zone Shadowmoon Valley >> Travel to Shadowmoon Valley
step
.goto Shadowmoon Valley,55.732,58.168
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larissa Sunstrike|r
.turnin 10691 >> Turn in Return to the Scryers
.accept 10692 >> Accept Varedis Must Be Stopped
.target Larissa Sunstrike
step
>>Kill |cRXP_ENEMY_Varedis|r, |cRXP_ENEMY_Netharel|r, |cRXP_ENEMY_Theras|r and |cRXP_ENEMY_Alandien|r
>>|cRXP_WARN_It is recommended to complete this with a full group consisting of also a Tank and Healer|r
.use 30854 >> |cRXP_WARN_Use the|r |T133738:0|t[Book of Fel Names] |cRXP_WARN_on |cRXP_ENEMY_Varedis|r once he uses Metamorphosis. Note this has a 10 second cast time|r
.complete 10692,2 
.goto Shadowmoon Valley,68.73,52.73
.mob +Netharel
.complete 10692,3 
.goto Shadowmoon Valley,72.38,48.40
.mob +Theras
.complete 10692,4 
.goto Shadowmoon Valley,69.56,54.12
.mob +Alandien
.complete 10692,1 
.goto Shadowmoon Valley,72.18,53.68
.mob +Varedis
step
.goto Shadowmoon Valley,55.732,58.168
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larissa Sunstrike|r
.turnin 10692 >> Turn in Varedis Must Be Stopped
.target Larissa Sunstrike
step
.goto 1953/530,2904.300,2431.600,0
.goto 1953/530,2251.500,3108.300,0
+|cRXP_WARN_Congratulations! You have reached the end of The Scryers reputation guide|r
>>Killing the |cRXP_ENEMY_Sunfury|r in Netherstorm for |T133739:0|t[|cRXP_FRIENDLY_Arcane Tome|r] and |T133378:0|t[Sunfury Signet] will increase your Scryers reputation when turned in. You may also buy these from the Auction House.
]])

RXPGuides.RegisterGuide([[#tbc
#wotlk
#group RXP TBC Reputation Guide
#name The Consortium
step
#tip
#completewith NeutralGrind
>>From Neutral to Friendly you have 2 options to gain reputation with The Consortium:
>>|cRXP_WARN_Option 1:|r Turn-ins of |T134096:0|t[Oshu'gun Crystal Fragment] OR |T133721:0|t[Pair of Ivory Tusks]. Acquire these in Nagrand or purchase them from the Auction House. Each turn in gives 250 rep. Each turn in is 10 x |T134096:0|t[Oshu'gun Crystal Fragment] OR 3 x |T133721:0|t[Pair of Ivory Tusks]
>>|cRXP_WARN_Option 2:|r Run Mana-Tombs until Friendly
step
#label NeutralGrind
.goto Nagrand,30.6,75.6,0
.goto Nagrand,34.6,64.2,0
.goto Nagrand,41.8,70.6,0
.goto Nagrand,34.8,75.8,0
.goto Nagrand,31.365,57.793,-1
.goto Nagrand,31.770,56.788,-1
.reputation 933,friendly
>>Travel to Nagrand and kill |cRXP_ENEMY_Wild Elekks|r (found all over Nagrand) for |T133721:0|t[Pair of Ivory Tusks] or kill |cRXP_ENEMY_Vir'aani Raiders|r for |T134096:0|t[Oshu'gun Crystal Fragment]. They can also be looted from the ground around Oshu'gun. You will not be able to turn either of these in after reaching Friendly
>>|cRXP_WARN_NOTE:|r It is important not to complete any other quests for The Consortium as these quests will be an easy way to gain reputation later
.accept 9914 >>Accept A Head Full of Ivory
.turnin 9914 >>Turn in A Head Full of Ivory
.accept 9882 >>Accept Stealing from Thieves
.turnin 9882 >>Turn in Stealing from Thieves
.dailyturnin 9915
.disablecheckbox
.dailyturnin 9883
.disablecheckbox
.mob Wild Elekk
.mob Vir'aani Raider
.target Gezhe
.target Shadrek
.reputation 933,friendly,>0,1
step
.goto Terokkar Forest,39.58,59.52,0
.reputation 933,honored >> Run Mana-Tombs until Honored with The Consortium
>>You can also complete the 2 quests outside of the dungeon, however you should not turn them in until you have reached Honored as Mana-Tombs stops giving rep once Honored
.accept 10216 >> Accept Safety Is Job One
.target +Artificer Morphalius
.goto Terokkar Forest,39.422,58.514
.accept 10165 >> Accept Undercutting the Competition
.target +Nexus-Prince Haramad
.goto Terokkar Forest,39.371,58.475
step
#tip
#completewith ReveredGrind
.reputation 933,revered >> Try to run Heroic Mana Tombs every day, as it is the most efficient way to gain reputation with The Consortium.
step
#completewith MTTurnins
+|cRXP_WARN_Run Mana-Tombs and complete the quests|r
step
.goto Terokkar Forest,39.58,59.52,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Artificer Morphalius|r and |cRXP_FRIENDLY_Nexus-Prince Haramad|r
.accept 10216 >> Accept Safety Is Job One
.target +Artificer Morphalius
.goto Terokkar Forest,39.422,58.514
.accept 10165 >> Accept Undercutting the Competition
.target +Nexus-Prince Haramad
.goto Terokkar Forest,39.371,58.475
step
>>Kill |cRXP_ENEMY_Ethereal Crypt Raiders|r, |cRXP_ENEMY_Nexus Stalkers|r, |cRXP_ENEMY_Ethereal Sorcerers|r and |cRXP_ENEMY_Ethereal Spellbinders|r
.complete 10216,1 
.mob +Ethereal Crypt Raider
.complete 10216,2 
.mob +Nexus Stalker
.complete 10216,3 
.mob +Ethereal Sorcerer
.complete 10216,4 
.mob +Ethereal Spellbinder
step
.isQuestComplete 10216
>>Click the |cRXP_PICK_Ethereal Transporter Control Panel|r inside the dungeon
>>|cRXP_WARN_It is recommended not to accept the follow up escort quest until you have cleared the dungeon|r
.turnin 10216 >> Turn in Safety Is Job One
step
>>Kill |cRXP_ENEMY_Nexus-Prince Shaffar|r. Loot him for |cRXP_LOOT_Shaffar's Wrappings|r
.complete 10165,1 
step
.isQuestTurnedIn 10216
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cryo-Engineer Sha'heen|r
.accept 10218 >> Accept Someone Else's Hard Work Pays Off
.target Cryo-Engineer Sha'heen
step
.isOnQuest 10218
>>Escort |cRXP_FRIENDLY_Cryo-Engineer Sha'heen|r out of the Mana-Tombs
.complete 10218,1 
.target Cryo-Engineer Sha'heen
step
#completewith MTTurnins
.zone Terokkar Forest >> |cRXP_WARN_Exit the Mana-Tombs|r
.subzoneskip 3792,1
step
.isQuestComplete 10165
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nexus-Prince Haramad|r
.turnin 10165 >> Turn in Undercutting the Competition
.target Nexus-Prince Haramad
.goto Terokkar Forest,39.371,58.475
step
#label MTTurnins
.isQuestComplete 10218
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nexus-Prince Haramad|r
.turnin 10218 >> Turn in Someone Else's Hard Work Pays Off
.target Nexus-Prince Haramad
.goto Terokkar Forest,39.371,58.475
step
#completewith NagrandQuests
.zone Nagrand >> Travel to Nagrand
step
.goto Nagrand,31.365,57.793
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gezhe|r
.target Gezhe
.accept 9893 >>Accept Obsidian Warbeads
step
#optional
.goto Nagrand,31.365,57.793
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gezhe|r
.target Gezhe
.turnin 9893 >>Turn in Obsidian Warbeads
.itemcount 25433,10
step
.goto Nagrand,30.783,58.133
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zerid|r
.target Zerid
.accept 9900 >>Accept Gava'xi
.accept 9925 >>Accept Matters of Security
step
#completewith next
>>Kill |cRXP_ENEMY_Voidspawns|r
.complete 9925,1 
.mob Voidspawn
step
#label Gava
.goto Nagrand,42.39,73.49,50,0
.goto Nagrand,43.65,74.59,50,0
.goto Nagrand,43.47,72.86,50,0
.goto Nagrand,42.45,72.32,50,0
.goto Nagrand,41.53,71.33
>>Kill |cRXP_ENEMY_Gava'xi|r
>>|cRXP_ENEMY_Gava'xi|r |cRXP_WARN_patrols slightly|r
.complete 9900,1 
.unitscan Gava'xi
step
#loop
.line Nagrand,30.51,66.79,32.23,69.85,31.75,74.99,36.51,77.38,38.03,79.58,40.19,77.22,37.87,76.04,39.87,72.76,39.35,67.61,41.46,62.82,37.64,66.21,34.90,65.37,32.91,67.36,30.51,66.79
.goto Nagrand,30.51,66.79,60,0
.goto Nagrand,32.23,69.85,60,0
.goto Nagrand,31.75,74.99,60,0
.goto Nagrand,36.51,77.38,60,0
.goto Nagrand,38.03,79.58,60,0
.goto Nagrand,40.19,77.22,60,0
.goto Nagrand,37.87,76.04,60,0
.goto Nagrand,39.87,72.76,60,0
.goto Nagrand,39.35,67.61,60,0
.goto Nagrand,41.46,62.82,60,0
.goto Nagrand,37.64,66.21,60,0
.goto Nagrand,34.90,65.37,60,0
.goto Nagrand,32.91,67.36,60,0
>>Kill |cRXP_ENEMY_Voidspawns|r
.complete 9925,1 
.mob Voidspawn
step
#loop
.goto Nagrand,50.6,56.6,0
.goto Nagrand,40.6,31.0,0
.goto Nagrand,50.6,56.6,50,0
.goto Nagrand,40.6,31.0,50,0
>>Kill |cRXP_ENEMY_Ogres|r in Nagrand. Loot them for their |cRXP_LOOT_Obsidian Warbeads|r
.complete 9893,1 
.mob Boulderfist Warrior
.mob Boulderfist Mage
step
.goto Nagrand,30.783,58.133
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zerid|r
.target Zerid
.turnin 9900 >>Turn in Gava'xi
.turnin 9925 >>Turn in Matters of Security
step
#label NagrandQuests
.goto Nagrand,31.365,57.793
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gezhe|r
.target Gezhe
.turnin 9893 >>Turn in Obsidian Warbeads
step
#completewith NetherstormQuests
.zone Netherstorm >> Travel to Area 52 in Netherstorm
step
.goto Netherstorm,32.442,64.206
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Khay'ji|r
.accept 10265 >> Accept Consortium Crystal Collection
.target Nether-Stalker Khay'ji
step
.goto Netherstorm,42.46,72.76
>>Kill |cRXP_ENEMY_Pentatharon|r. Loot him for his |cRXP_LOOT_Arklon Crystal Artifact|r
.complete 10265,1 
.mob Pentatharon
step
.goto Netherstorm,32.442,64.206
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Khay'ji|r
.turnin 10265 >> Turn in Consortium Crystal Collection
.accept 10262 >> Accept A Heap of Ethereals
.target Nether-Stalker Khay'ji
step
#loop
.line Netherstorm,28.16,76.82,28.59,77.91,28.17,79.67,29.23,80.03,29.26,78.72,30.50,79.13,30.62,75.59,31.47,76.40,31.81,75.01,30.92,73.97,30.03,74.68,29.19,75.33,28.16,76.82
.goto Netherstorm,28.16,76.82,55,0
.goto Netherstorm,28.59,77.91,55,0
.goto Netherstorm,28.17,79.67,55,0
.goto Netherstorm,29.23,80.03,55,0
.goto Netherstorm,29.26,78.72,55,0
.goto Netherstorm,30.50,79.13,55,0
.goto Netherstorm,30.62,75.59,55,0
.goto Netherstorm,31.47,76.40,55,0
.goto Netherstorm,31.81,75.01,55,0
.goto Netherstorm,30.92,73.97,55,0
.goto Netherstorm,30.03,74.68,55,0
.goto Netherstorm,29.19,75.33,55,0
>>Kill |cRXP_ENEMY_Zaxxis Raiders|r and |cRXP_ENEMY_Zaxxis Stalkers|r. Loot them for their |cRXP_LOOT_Insignias|r
.complete 10262,1 
.mob Zaxxis Raider
.mob Zaxxis Stalker
step
.goto Netherstorm,32.442,64.206
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Khay'ji|r
.turnin 10262 >> Turn in A Heap of Ethereals
.accept 10205 >> Accept Warp-Raider Nesaad
.target Nether-Stalker Khay'ji
step
.goto Netherstorm,28.27,79.61
>>Kill |cRXP_ENEMY_Warp-Raider Nesaad|r
.complete 10205,1 
.mob Warp-Raider Nesaad
step
.goto Netherstorm,32.442,64.206
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Khay'ji|r
.turnin 10205 >> Turn in Warp-Raider Nesaad
.accept 10266 >> Accept Request for Assistance
.target Nether-Stalker Khay'ji
step
#completewith next
.subzone 3851 >> Travel to Midrealm Post
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gahruj|r and |cRXP_FRIENDLY_Mehrdad|r
.turnin 10266 >> Turn in Request for Assistance
.accept 10267 >> Accept Rightful Repossession
.accept 10311 >> Accept Drijya Needs Your Help
.target +Gahruj
.goto Netherstorm,46.66,56.94
.accept 10348 >> Accept New Opportunities
.accept 10417 >> Accept Run a Diagnostic!
.target +Mehrdad
.goto Netherstorm,46.45,56.41
step
.goto Netherstorm,48.23,55.00
>>Loot the |cRXP_PICK_Diagnostic Equipment|r on the ground
.complete 10417,1 
step
.goto Netherstorm,46.45,56.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mehrdad|r
.turnin 10417 >> Turn in Run a Diagnostic!
.accept 10418 >> Accept Deal With the Saboteurs
.target Mehrdad
step
#completewith next
>>Loot the |cRXP_PICK_Ivory Bells|r on the ground
.complete 10348,1 
step
#loop
.line Netherstorm,46.94,54.53,47.57,53.95,47.62,52.83,47.02,52.66,46.75,51.68,46.05,50.41,45.29,51.93,45.91,53.50,46.94,54.53
.goto Netherstorm,46.94,54.53,50,0
.goto Netherstorm,47.57,53.95,50,0
.goto Netherstorm,47.62,52.83,50,0
.goto Netherstorm,47.02,52.66,50,0
.goto Netherstorm,46.75,51.68,50,0
.goto Netherstorm,46.05,50.41,50,0
.goto Netherstorm,45.29,51.93,50,0
.goto Netherstorm,45.91,53.50,50,0
>>Kill |cRXP_ENEMY_Barbscale Crocolisks|r
.complete 10418,1 
.mob Barbscale Crocolisk
step
#loop
.line Netherstorm,46.50,49.46,45.71,48.52,44.49,48.48,44.44,49.73,42.99,50.75,42.60,53.37,43.30,54.76,43.19,55.94,44.24,57.16,44.67,54.74,45.91,57.22,46.50,49.46
.goto Netherstorm,46.50,49.46,50,0
.goto Netherstorm,45.71,48.52,50,0
.goto Netherstorm,44.49,48.48,50,0
.goto Netherstorm,44.44,49.73,50,0
.goto Netherstorm,42.99,50.75,50,0
.goto Netherstorm,42.60,53.37,50,0
.goto Netherstorm,43.30,54.76,50,0
.goto Netherstorm,43.19,55.94,50,0
.goto Netherstorm,44.24,57.16,50,0
.goto Netherstorm,44.67,54.74,50,0
.goto Netherstorm,45.91,57.22,50,0
>>Loot the |cRXP_PICK_Ivory Bells|r on the ground
.complete 10348,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mehrdad|r
.goto Netherstorm,46.48,56.04
.turnin 10348 >> Turn in New Opportunities
.turnin 10418 >> Turn in Deal With the Saboteurs
.accept 10423 >> Accept To the Stormspire
.goto Netherstorm,46.45,56.41
.target Mehrdad
step
#completewith next
+|cRXP_WARN_Find another 1-2 party members for the upcoming escort quest|r
step
.goto Netherstorm,48.11,63.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drijya|r
>>|cRXP_WARN_You may need to wait for |cRXP_FRIENDLY_Drijya|r to return if he is not there|r
.turnin 10311 >> Turn in Drijya Needs Your Help
.accept 10310,1 >> Accept Sabotage the Warp-Gate!
.target Drijya
step
.goto Netherstorm,49.47,65.72
>>Kill the attacking |cRXP_ENEMY_Demons|r while |cRXP_FRIENDLY_Drijya|r sabotages the warp-gate
.complete 10310,1 
.target Drijya
.mob Warp-Gate Engineer
.mob Legion Destroyer
step
#loop
.line Netherstorm,58.84,62.54,58.31,62.97,58.10,62.71,57.76,63.29,57.21,63.42,56.82,63.89,57.34,64.44,57.39,65.29,57.22,65.92,56.95,66.52,57.34,67.19,57.38,66.58,57.22,65.92,57.39,65.29,57.34,64.44,57.91,64.06,57.76,63.29,58.10,62.71,58.31,62.97,58.84,62.54,59.10,63.14,59.45,63.04,59.20,62.36,58.84,62.54
.goto Netherstorm,58.84,62.54,50,0
.goto Netherstorm,58.31,62.97,50,0
.goto Netherstorm,58.10,62.71,50,0
.goto Netherstorm,57.76,63.29,50,0
.goto Netherstorm,57.21,63.42,50,0
.goto Netherstorm,56.82,63.89,50,0
.goto Netherstorm,57.34,64.44,50,0
.goto Netherstorm,57.39,65.29,50,0
.goto Netherstorm,57.22,65.92,50,0
.goto Netherstorm,56.95,66.52,50,0
.goto Netherstorm,57.34,67.19,50,0
.goto Netherstorm,57.38,66.58,50,0
.goto Netherstorm,57.22,65.92,50,0
.goto Netherstorm,57.39,65.29,50,0
.goto Netherstorm,57.34,64.44,50,0
.goto Netherstorm,57.91,64.06,50,0
.goto Netherstorm,57.76,63.29,50,0
.goto Netherstorm,58.10,62.71,50,0
.goto Netherstorm,58.31,62.97,50,0
.goto Netherstorm,58.84,62.54,50,0
.goto Netherstorm,59.10,63.14,50,0
.goto Netherstorm,59.45,63.04,50,0
.goto Netherstorm,59.20,62.36,50,0
>>Loot the |cRXP_PICK_Surveying Equipment|r boxes on the ground
.complete 10267,1 
step
.goto Netherstorm,46.66,56.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gahruj|r
.turnin 10310 >> Turn in Sabotage the Warp-Gate!
.turnin 10267 >> Turn in Rightful Repossession
.accept 10268 >> Accept An Audience with the Prince
.target Gahruj
step
#completewith next
.subzone 3738 >> Travel to the Stormspire
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghabar|r
.turnin 10423 >> Turn in To the Stormspire
.accept 10424 >> Accept Diagnosis: Critical
.goto Netherstorm,43.54,35.15
.target Ghabar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zuben Elgenubi|r
.accept 10290 >> Accept In Search of Farahlite
.goto Netherstorm,44.08,36.05
.target Zuben Elgenubi
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Nauthis|r and |cRXP_FRIENDLY_Zephyrion|r
.accept 10336 >> Accept The Minions of Culuthas
.accept 10855 >> Accept Fel Reavers, No Thanks!
.target +Nether-Stalker Nauthis
.goto Netherstorm,44.71,34.94,-1
.accept 10335 >> Accept Surveying the Ruins
.target +Zephyrion
.goto Netherstorm,44.73,34.87,-1
step
.goto Netherstorm,45.87,35.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Nexus-Prince Haramad|r
.turnin 10268 >> Turn in An Audience with the Prince
.accept 10269 >> Accept Triangulation Point One
.target Image of Nexus-Prince Haramad
step
.goto Netherstorm,47.64,26.77
.use 29803 >>|cRXP_WARN_Use the|r |T133859:0|t[Diagnostic Device] |cRXP_WARN_at the|r |cRXP_PICK_Eco-Dome Sutheron Generator|r
.complete 10424,1 
step
#loop
.line Netherstorm,39.11,28.77,38.01,30.41,36.22,30.11,35.54,28.97,35.83,28.22,37.14,27.86,36.23,26.00,36.73,24.74,38.68,25.07,38.12,27.81,39.57,27.48,39.11,28.77
.goto Netherstorm,39.11,28.77,50,0
.goto Netherstorm,38.01,30.41,50,0
.goto Netherstorm,36.22,30.11,50,0
.goto Netherstorm,35.54,28.97,50,0
.goto Netherstorm,35.83,28.22,50,0
.goto Netherstorm,37.14,27.86,50,0
.goto Netherstorm,36.23,26.00,50,0
.goto Netherstorm,36.73,24.74,50,0
.goto Netherstorm,38.68,25.07,50,0
.goto Netherstorm,38.12,27.81,50,0
.goto Netherstorm,39.57,27.48,50,0
>>Kill |cRXP_ENEMY_Gan'arg Mekgineers|r. Loot them for their |cRXP_LOOT_Condensed Nether Gas|r
.collect 31653,5,10855,1 
.mob Gan'arg Mekgineer
step
.goto Netherstorm,35.86,28.84,-1
.goto Netherstorm,36.73,25.15,-1
.goto Netherstorm,37.95,25.69,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to an |cRXP_FRIENDLY_Inactive Fel Reaver|r
.turnin 10850 >> Turn in Nether Gas In a Fel Fire Engine
.isOnQuest 10855
.target Inactive Fel Reaver
.itemcount 31653,5
step
#loop
.line Netherstorm,47.57,20.27,44.88,18.75,45.10,16.70,50.08,17.24,47.57,20.27
.goto Netherstorm,47.57,20.27,50,0
.goto Netherstorm,44.88,18.75,50,0
.goto Netherstorm,45.10,16.70,50,0
.goto Netherstorm,50.08,17.24,50,0
>>Kill |cRXP_ENEMY_Farahlon Breakers|r. Loot them for their |cRXP_LOOT_Raw Farahlite|r
>>|cRXP_WARN_This quest is difficult. Find a group for them if needed|r
.complete 10290,1 
.mob Farahlon Breaker
step
#completewith next
.subzone 3738 >> Return to the Stormspire
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Nauthis|r and |cRXP_FRIENDLY_Ghabar|r
.turnin 10855 >> Turn in Fel Reavers, No Thanks!
.accept 10856 >> Accept The Best Defense
.target +Nether-Stalker Nauthis
.goto Netherstorm,44.71,34.94
.turnin 10424 >> Turn in Diagnosis: Critical
.accept 10430 >> Accept Testing the Prototype
.goto Netherstorm,43.54,35.15
.target +Ghabar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zuben Elgenubi|r
.turnin 10290 >> Turn in In Search of Farahlite
.accept 10293 >> Accept Hitting the Motherlode
.target +Zuben Elgenubi
.goto Netherstorm,44.08,36.05
step
#loop
.line Netherstorm,39.72,25.01,38.33,20.39,37.91,18.04,39.17,18.25,39.86,17.13,41.32,17.73,42.35,18.87,40.86,21.45,42.71,20.12,43.35,21.69,42.30,23.87,40.86,23.90,39.72,25.01
.goto Netherstorm,39.72,25.01,70,0
.goto Netherstorm,38.33,20.39,70,0
.goto Netherstorm,37.91,18.04,70,0
.goto Netherstorm,39.17,18.25,70,0
.goto Netherstorm,39.86,17.13,70,0
.goto Netherstorm,41.32,17.73,70,0
.goto Netherstorm,42.35,18.87,70,0
.goto Netherstorm,40.86,21.45,70,0
.goto Netherstorm,42.71,20.12,70,0
.goto Netherstorm,43.35,21.69,70,0
.goto Netherstorm,42.30,23.87,70,0
.goto Netherstorm,40.86,23.90,70,0
>>Kill |cRXP_ENEMY_Wrathbringers|r
.complete 10856,1 
.mob Wrathbringer
step
#completewith next
.subzone 3874 >>Travel to Eco-Dome Farfield
step
.goto Netherstorm,44.69,14.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tashar|r
.turnin 10430 >> Turn in Testing the Prototype
.accept 10436 >> Accept All Clear!
.target Tashar
step
#loop
.line Netherstorm,43.16,13.33,43.68,11.53,44.90,10.74,45.01,8.01,46.51,7.78,47.05,10.12,46.35,12.99,45.28,12.71
.goto Netherstorm,43.16,13.33,65,0
.goto Netherstorm,43.68,11.53,65,0
.goto Netherstorm,44.90,10.74,65,0
.goto Netherstorm,45.01,8.01,65,0
.goto Netherstorm,46.51,7.78,65,0
.goto Netherstorm,47.05,10.12,65,0
.goto Netherstorm,46.35,12.99,65,0
.goto Netherstorm,45.28,12.71,65,0
>>Kill |cRXP_ENEMY_Scythetooth Raptors|r
.complete 10436,1 
.mob Scythetooth Raptor
step
.goto Netherstorm,44.69,14.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tashar|r. Wait for his RP
.turnin 10436 >> Turn in All Clear!
.accept 10440 >> Accept Success!
.target Tashar
step
.goto Netherstorm,47.54,21.09,60,0
.goto Netherstorm,47.59,20.49,60,0
.goto Netherstorm,47.82,19.69,60,0
.goto Netherstorm,48.66,19.33,60,0
.goto Netherstorm,48.98,18.74,60,0
.goto Netherstorm,49.46,18.15,60,0
.goto Netherstorm,49.82,17.23
.line Netherstorm,47.54,21.09,47.59,20.49,47.82,19.69,48.66,19.33,48.98,18.74,49.46,18.15,49.82,17.23
>>Kill |cRXP_ENEMY_Cragskaar|r. Loot him for his |cRXP_LOOT_Core|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed|r
.complete 10293,1 
.isOnQuest 10293
.mob Cragskaar
step
.goto Netherstorm,66.73,33.89
.use 28962 >> |cRXP_WARN_Use the|r |T135164:0|t[Triangulation Device]
>>|cRXP_WARN_Walk 10 yards away then walk into the red arrow|r
.complete 10269,1 
step
.goto Netherstorm,58.35,31.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dealer Hazzin|r
.turnin 10269 >> Turn in Triangulation Point One
.accept 10275 >> Accept Triangulation Point Two
.target Dealer Hazzin
step
#completewith next
.subzone 3738 >> Return to the Stormspire
tep
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zuben Elgenubi|r
.turnin 10293 >> Turn in Hitting the Motherlode
.goto Netherstorm,44.08,36.05
.isQuestComplete 10293
.target Zuben Elgenubi
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghabar|r and |cRXP_FRIENDLY_Nether-Stalker Nauthis|r
.turnin 10440 >> Turn in Success!
.target +Ghabar
.goto Netherstorm,43.54,35.15
.turnin 10856 >> Turn in The Best Defense
.accept 10857 >> Accept Teleport This!
.target +Nether-Stalker Nauthis
.goto Netherstorm,44.71,34.94
step
#completewith next
.subzone 3852 >> Travel to Tuluman's Landing
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wind Trader Tuluman|r and |cRXP_FRIENDLY_Nether-Stalker Oazul|r
.accept 10317 >> Accept Dealing with the Foreman
.target +Wind Trader Tuluman
.goto Netherstorm,34.62,37.95
.accept 10315 >> Accept Neutralizing the Nethermancers
.goto Netherstorm,34.50,37.80
.target +Nether-Stalker Oazul
step
#completewith next
.goto Netherstorm,26.37,43.87
.subzone 3881 >> Enter the Trelleum Mine
step
.goto Netherstorm,26.37,42.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Sundown|r inside the mine
.turnin 10317 >> Turn in Dealing with the Foreman
.accept 10318 >> Accept Dealing with the Overmaster
.target Foreman Sundown
step
#completewith Point2
>>Kill |cRXP_ENEMY_Sunfury Nethermancers|r
.complete 10315,1 
.mob Sunfury Nethermancer
step
.goto Netherstorm,26.82,35.84
>>Kill |cRXP_ENEMY_Overmaster Grindgarr|r at the end of the mine
.complete 10318,1 
.mob Overmaster Grindgarr
step
#completewith next
.skill riding,225,1
.goto Netherstorm,29.56,41.80,50,0
.goto Netherstorm,29.42,39.76,50 >> Travel up the mountain to Manaforge Ara
step
#label Point2
.goto Netherstorm,28.74,41.29
.use 29018 >> |cRXP_WARN_Use the|r |T135164:0|t[Triangulation Device]
>>|cRXP_WARN_Walk 10 yards away then walk into the red arrow|r
.complete 10275,1 
step
#loop
.line Netherstorm,28.43,41.71,28.33,40.23,28.57,37.74,30.85,39.73,29.61,44.04,28.43,41.71
.goto Netherstorm,28.43,41.71,45,0
.goto Netherstorm,28.33,40.23,45,0
.goto Netherstorm,28.57,37.74,45,0
.goto Netherstorm,30.85,39.73,45,0
.goto Netherstorm,29.61,44.04,45,0
>>Kill |cRXP_ENEMY_Sunfury Nethermancers|r
.complete 10315,1 
.mob Sunfury Nethermancer
step
#completewith TulumansLanding2
.subzone 3852 >> Return to Tuluman's Landing
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Oazul|r and |cRXP_FRIENDLY_Wind Trader Tuluman|r
.turnin 10315 >> Turn in Neutralizing the Nethermancers
.target +Nether-Stalker Oazul
.goto Netherstorm,34.50,37.80
.turnin 10275 >> Turn in Triangulation Point Two
.accept 10276 >> Accept Full Triangle
.turnin 10318 >> Turn in Dealing with the Overmaster
.target +Wind Trader Tuluman
.goto Netherstorm,34.62,37.95
step
#completewith next
.goto Netherstorm,39.36,20.83
.cast 38915 >> |cRXP_WARN_Use the|r |T135147:0|t[Mental Interference Rod] |cRXP_WARN_on a|r |cRXP_ENEMY_Cyber-Rage Forgelord|r
.use 31678
.mob Cyber-Rage Forgelord
step
.goto Netherstorm,39.19,20.43
>>|cRXP_WARN_With a|r |cRXP_ENEMY_Forgelord|r |cRXP_WARN_mind controlled, cast|r |T136193:0|t[Detonate Teleporter] (3) |cRXP_WARN_to destroy the|r |cRXP_PICK_Western Teleporter|r
.complete 10857,1 
.use 31678
.mob Cyber-Rage Forgelord
step
#completewith next
.goto Netherstorm,40.93,18.71
.cast 38915 >> |cRXP_WARN_Use the|r |T135147:0|t[Mental Interference Rod] |cRXP_WARN_on a|r |cRXP_ENEMY_Cyber-Rage Forgelord|r
.use 31678
.mob Cyber-Rage Forgelord
step
.goto Netherstorm,41.08,19.42
>>|cRXP_WARN_With a|r |cRXP_ENEMY_Forgelord|r |cRXP_WARN_mind controlled, cast|r |T136193:0|t[Detonate Teleporter] (3) |cRXP_WARN_to destroy the|r |cRXP_PICK_Central Teleporter|r
.complete 10857,2 
.mob Cyber-Rage Forgelord
step
#completewith next
.goto Netherstorm,41.82,21.10
.cast 38915 >> |cRXP_WARN_Use the|r |T135147:0|t[Mental Interference Rod] |cRXP_WARN_on a|r |cRXP_ENEMY_Cyber-Rage Forgelord|r
.use 31678
.mob Cyber-Rage Forgelord
step
.goto Netherstorm,42.28,21.07
>>|cRXP_WARN_With a|r |cRXP_ENEMY_Forgelord|r |cRXP_WARN_mind controlled, cast|r |T136193:0|t[Detonate Teleporter] (3) |cRXP_WARN_to destroy the|r |cRXP_PICK_Eastern Teleporter|r
.complete 10857,3 
.mob Cyber-Rage Forgelord
step
#completewith Surveying
.goto Netherstorm,54.5,22.0,0
>>Kill the |cRXP_ENEMY_Hounds of Culuthas|r and |cRXP_ENEMY_Eyes of Culuthas|r
.complete 10336,1 
.mob +Hound of Culuthas
.complete 10336,2 
.mob +Eye of Culuthas
step
.goto Netherstorm,51.65,20.49
.use 29445 >>|cRXP_WARN_Use the|r |T135482:0|t[Surveying Markers] |cRXP_WARN_next to the banner|r
.complete 10335,1 
step
.goto Netherstorm,53.50,21.53
>>Kill |cRXP_ENEMY_Culuthas|r. Loot him for his |cRXP_LOOT_Crystal|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed|r
.complete 10276,1 
.mob Culuthas
step
#label Surveying
.use 29445 >>|cRXP_WARN_Use the|r |T135482:0|t[Surveying Markers] |cRXP_WARN_next to the banners|r
.complete 10335,2 
.goto Netherstorm,54.54,22.82
.complete 10335,3 
.goto Netherstorm,55.82,19.92
step
#loop
.line Netherstorm,,56.15,19.69,55.29,21.86,54.32,22.98,54.95,24.74,52.68,23.78,51.27,21.26,52.13,20.00,53.54,19.55,54.18,19.34,56.15,19.69
.goto Netherstorm,56.15,19.69,50,0
.goto Netherstorm,55.29,21.86,50,0
.goto Netherstorm,54.32,22.98,50,0
.goto Netherstorm,54.95,24.74,50,0
.goto Netherstorm,52.68,23.78,50,0
.goto Netherstorm,51.27,21.26,50,0
.goto Netherstorm,52.13,20.00,50,0
.goto Netherstorm,53.54,19.55,50,0
.goto Netherstorm,54.18,19.34,50,0
>>Kill the |cRXP_ENEMY_Hounds|r and |cRXP_ENEMY_Eyes of Culuthas|r
.complete 10336,1 
.mob +Hound of Culuthas
.complete 10336,2 
.mob +Eye of Culuthas
step
#completewith next
.subzone 3738 >> Return to the Stormspire
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nether-Stalker Nauthis|r and |cRXP_FRIENDLY_Zephyrion|r
.turnin 10336 >> Turn in The Minions of Culuthas
.turnin 10857 >> Turn in Teleport This!
.target +Nether-Stalker Nauthis
.goto Netherstorm,44.71,34.94
.turnin 10335 >> Turn in Surveying the Ruins
.target +Zephyrion
.goto Netherstorm,44.73,34.87
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Nexus-Prince Haramad|r
.turnin 10276 >> Turn in Full Triangle
.accept 10280 >> Accept Special Delivery to Shattrath City
.goto Netherstorm,45.87,35.97
.target Image of Nexus-Prince Haramad
step
#completewith next
.subzone 3854 >> Travel to the Protectorate Watch Post
step
#sticky
#label CaptainTyralius
#loop
.waypoint Netherstorm,58.60,31.77,40,0
.waypoint Netherstorm,58.91,32.02,40,0
.waypoint Netherstorm,59.14,32.12,40,0
.waypoint Netherstorm,59.47,31.88,40,0
.waypoint Netherstorm,59.86,31.91,40,0
.waypoint Netherstorm,60.07,32.52,40,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flesh Handler Viridius|r
>>|cRXP_FRIENDLY_Flesh Handler Viridius|r |cRXP_WARN_patrols the Protectorate Watch Post|r
.accept 10422 >> Accept Captain Tyralius
.target Flesh Handler Viridius
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wind Trader Marid|r, |cRXP_FRIENDLY_Researcher Navuud|r and |cRXP_FRIENDLY_Professor Dabiri|r
.accept 10270 >> Accept A Not-So-Modest Proposal
.target +Researcher Navuud
.goto Netherstorm,58.32,31.66
.accept 10411 >> Accept Electro-Shock Goodness!
.target +Wind Trader Marid
.goto Netherstorm,59.25,32.58
.accept 10437 >> Accept Recipe for Destruction
.goto Netherstorm,60.11,31.72
.target +Professor Dabiri
step
.goto Netherstorm,59.5,32.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ameer|r
.accept 10339 >> Accept The Ethereum
.accept 10970 >> Accept A Mission of Mercy
>>|cRXP_WARN_This quest chain can only be done at level 70|r << !70
.target Commander Ameer
step
#requires CaptainTyralius
.isOnQuest 10411
.cast 35685 >> |cRXP_WARN_Use|r |T134716:0|t[Navuud's Concoction]
.use 29737
.aura 35685
step
#loop
.line Netherstorm,64.26,35.80,65.80,39.03,66.04,41.34,63.72,42.87,62.89,44.65,61.15,43.65,59.42,41.53,59.74,39.06,64.26,35.80
.goto Netherstorm,64.26,35.80,50,0
.goto Netherstorm,65.80,39.03,50,0
.goto Netherstorm,66.04,41.34,50,0
.goto Netherstorm,63.72,42.87,50,0
.goto Netherstorm,62.89,44.65,50,0
.goto Netherstorm,61.15,43.65,50,0
.goto Netherstorm,59.42,41.53,50,0
.goto Netherstorm,59.74,39.06,50,0
>>Kill |cRXP_ENEMY_Voidshriekers|r and |cRXP_ENEMY_Unstable Voidwraiths|r. Loot them for their |cRXP_LOOT_Fragments of Dimensius|r
>>|cRXP_WARN_Be careful as |cRXP_ENEMY_Voidshriekers|r take reduced damage from the first spell school cast on them|r << !Warrior !Rogue
.use 29737 >>Attack |cRXP_ENEMY_Seeping Sludges|r, then kill the |cRXP_ENEMY_Seeping Sludge Globules|r that spawn
.complete 10437,1 
.mob +Voidshrieker
.mob +Unstable Voidwraith
.complete 10411,1 
.mob +Seeping Sludge
.mob +Seeping Sludge Globule
step
.goto Netherstorm,59.42,45.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Agent Araxes|r
.accept 10345 >> Accept The Flesh Lies...
.target Agent Araxes
step
#completewith next
.goto Netherstorm,61.075,45.290,15 >> Enter the Access Shaft Zeon mine
>>|cRXP_WARN_Stay to the left as you enter the mine|r
step
#completewith Arconus
.use 29473 >>|cRXP_WARN_Use the|r |T135626:0|t[Protectorate Igniter] |cRXP_WARN_on |cRXP_ENEMY_Withered Corpses|r inside the mine|r
.complete 10345,1 
.mob Withered Corpse
step
.goto Netherstorm,61.02,44.52,15,0
.goto Netherstorm,60.52,43.54,15,0
.goto Netherstorm,60.02,43.35,15,0
.goto Netherstorm,59.71,42.63,15,0
>>|cRXP_WARN_Hug the left wall of the cave|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Agent Ya-six|r
.accept 10353 >> Accept Arconus the Insatiable
.goto Netherstorm,60.92,41.53
step
>>Loot the |cRXP_PICK_Teleporter Power Pack|r behind |cRXP_FRIENDLY_Agent Ya-six|r
.complete 10270,1 
.goto Netherstorm,60.98,41.52
.target Agent Ya-six
step
#label Arconus
.goto Netherstorm,59.71,42.63,15,0
.goto Netherstorm,60.11,43.50,15,0
.goto Netherstorm,60.48,42.90,15,0
.goto Netherstorm,60.74,41.36,15,0
.goto Netherstorm,60.03,40.56,15,0
.goto Netherstorm,60.20,39.91
>>|cRXP_WARN_Head back the way you came. Follow the arrow to|r |cRXP_ENEMY_Arconus the Insatiable|r
>>Kill |cRXP_ENEMY_Arconus the Insatiable|r
.complete 10353,1 
.mob Arconus the Insatiable
step
#loop
.goto Netherstorm,60.03,40.56,15,0
.goto Netherstorm,60.74,41.36,15,0
.goto Netherstorm,61.77,41.96,15,0
.goto Netherstorm,61.75,43.39,15,0
.goto Netherstorm,61.12,44.45,15,0
.goto Netherstorm,61.03,46.23,15,0
.use 29473 >>|cRXP_WARN_Use the|r |T135626:0|t[Protectorate Igniter] |cRXP_WARN_in your bags to burn |cRXP_ENEMY_Withered Corpses|r in the mine|r
.complete 10345,1 
.mob Withered Corpse
step
#completewith next
.goto Netherstorm,61.03,46.23,20 >> Exit the Access Shaft Zeon mine
step
.goto Netherstorm,59.42,45.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Agent Araxes|r
.turnin 10345 >> Turn in The Flesh Lies...
.target Agent Araxes
step
#sticky
#label SalvagedKey
.isOnQuest 10970
.goto Netherstorm,59.5,32.4,0
>>|cRXP_WARN_Keep a lookout while looting the |cRXP_ENEMY_Ethereum|r for a |T134889:0|t[|cRXP_LOOT_Salvaged Ethereum Prison Key|r]. If you loot one, turn it in at |cRXP_FRIENDLY_Commander Ameer|r at the Protectorate Watch Post immediately|r
.complete 10970,1 
.turnin 10970 >> Turn in A Mission of Mercy
.accept 10971 >> Accept Ethereum Secrets
step
#optional
#completewith next
.isOnQuest 10411
.cast 35685 >> |cRXP_WARN_Use|r |T134716:0|t[Navuud's Concoction]
.use 29737
.aura 35685
step
#completewith Tyralius
.use 29737 >>Attack |cRXP_ENEMY_Void Wastes|r, then kill the |cRXP_ENEMY_Void Waste Globules|r that spawn
.complete 10411,2 
.mob Void Waste
.mob Void Waste Globule
step
.goto Netherstorm,54.36,41.23
>>Kill |cRXP_ENEMY_Warden Icoshock|r. Loot him for |cRXP_LOOT_The Warden's Key|r
.collect 29742,1,10422,1 
.mob Warden Icoshock
step
#label Tyralius
.goto Netherstorm,53.30,41.43
>>Click |cRXP_PICK_Captain Tyralius's Prison|r
.complete 10422,1 
step
.line Netherstorm,55.61,45.18,54.87,43.96,55.24,42.73,54.70,41.97,54.91,41.19
.goto Netherstorm,55.61,45.18,50,0
.goto Netherstorm,54.87,43.96,50,0
.goto Netherstorm,55.24,42.73,50,0
.goto Netherstorm,54.70,41.97,50,0
.goto Netherstorm,54.91,41.19
.use 29737 >>Attack |cRXP_ENEMY_Void Wastes|r, then kill the |cRXP_ENEMY_Void Waste Globules|r that spawn
.complete 10411,2 
.mob Void Waste
.mob Void Waste Globule
step
#optional
.aura -35685 >> |cRXP_WARN_Click off the|r |T135990:0|t[Electro-Shock Therapy] |cRXP_WARN_buff on you|r
step
>>Kill |cRXP_ENEMY_Captain Zovax|r, |cRXP_ENEMY_Ethereum Assassins|r, |cRXP_ENEMY_Ethereum Shocktroopers|r and |cRXP_ENEMY_Ethereum Researchers|r
.complete 10339,4 
.goto Netherstorm,57.0,37.6
.mob +Captain Zovax
.complete 10339,1 
.goto Netherstorm,57.0,37.6,50,0
.goto Netherstorm,55.2,41.6,50,0
.goto Netherstorm,57.0,37.6,50,0
.goto Netherstorm,55.2,41.6
.mob +Ethereum Assassin
.complete 10339,2 
.goto Netherstorm,57.0,37.6,50,0
.goto Netherstorm,55.2,41.6,50,0
.goto Netherstorm,57.0,37.6,50,0
.goto Netherstorm,55.2,41.6
.mob +Ethereum Shocktrooper
.complete 10339,3 
.goto Netherstorm,57.0,37.6,50,0
.goto Netherstorm,55.2,41.6,50,0
.goto Netherstorm,57.0,37.6,50,0
.goto Netherstorm,55.2,41.6
.mob +Ethereum Researcher
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Image of Commander Ameer|r
.goto Netherstorm,56.810,38.700
.turnin 10339 >> Turn in The Ethereum
.accept 10384 >> Accept Ethereum Data
.target Image of Commander Ameer
step
.goto Netherstorm,55.767,39.895
>>Loot the |cRXP_PICK_Ethereum Data Cell|r
.complete 10384,1 
step
.goto Netherstorm,56.810,38.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10384 >> Turn in Ethereum Data
.accept 10385 >> Accept Potential for Brain Damage = High
.target Image of Commander Ameer
step
>>Kill the |cRXP_ENEMY_Ethereum|r. Loot them for their |T134729:0|t[|cRXP_LOOT_Ethereum Essence|r]
.use 29482 >> |cRXP_WARN_Use the|r |T134729:0|t[|cRXP_LOOT_Ethereum Essence|r] |cRXP_WARN_to be able to see and kill |cRXP_ENEMY_Ethereum Relays|r (they look like |cRXP_ENEMY_Mana Wyrms|r). Loot them for their|r |cRXP_LOOT_Ethereum Relay Data|r
>>|cRXP_WARN_NOTE: The|r |T134729:0|t[|cRXP_LOOT_Ethereum Essence|r] |cRXP_WARN_buff only lasts for only 1 minute|r
.collect 29482,1
.disablecheckbox
.complete 10385,1 
.mob Ethereum Relay
step
.goto Netherstorm,56.810,38.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10385 >> Turn in Potential for Brain Damage = High
.accept 10405 >> Accept S-A-B-O-T-A-G-E
.target Image of Commander Ameer
step
#loop
.goto Netherstorm,56.6,40.6,50,0
.goto Netherstorm,56.0,45.6,50,0
.goto Netherstorm,56.0,42.8,0
>>Kill |cRXP_ENEMY_Ethereum Archons|r and |cRXP_ENEMY_Ethereum Overlords|r. Loot them for a |cRXP_LOOT_Prepared Ethereum Wrapping|r
.complete 10405,1 
.mob Ethereum Archon
.mob Ethereum Overlord
step
.goto Netherstorm,56.810,38.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10405 >> Turn in S-A-B-O-T-A-G-E
.accept 10406 >> Accept Delivering the Message
.target Image of Commander Ameer
step
.goto Netherstorm,56.24,42.90
>>Escort the |cRXP_FRIENDLY_Protectorate Demolitionist|r through the Staging Grounds
.complete 10406,1 
.target Protectorate Demolitionist
step
.goto Netherstorm,56.810,38.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10406 >> Turn in Delivering the Message
.accept 10408 >> Accept Nexus-King Salhadaar
.target Image of Commander Ameer
step
.goto Netherstorm,53.59,42.37
.use 29618 >>Kill the |cRXP_ENEMY_Ethereum|r at the pillars around |cRXP_ENEMY_Nexus-King Salhadaar|r and use the |T133002:0|t[Protectorate Disruptor] to release him
>>Kill |cRXP_ENEMY_Nexus-King Salhadaar|r
>>|cRXP_WARN_Having a 5 man group with Tank + Healer is recommended for this step|r
.complete 10408,1 
.mob Nexus-King Salhadaar
step
.goto Netherstorm,56.810,38.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10408 >> Turn in Nexus-King Salhadaar
.target Image of Commander Ameer
step
#requries SalvagedKey
step
#sticky
#label CaptainTyraliusTurnin
#loop
.waypoint Netherstorm,58.60,31.77,40,0
.waypoint Netherstorm,58.91,32.02,40,0
.waypoint Netherstorm,59.14,32.12,40,0
.waypoint Netherstorm,59.47,31.88,40,0
.waypoint Netherstorm,59.86,31.91,40,0
.waypoint Netherstorm,60.07,32.52,40,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flesh Handler Viridius|r
>>|cRXP_FRIENDLY_Flesh Handler Viridius|r |cRXP_WARN_patrols the Protectorate Watch Post|r
.turnin 10422 >> Turn in Captain Tyralius
.target Flesh Handler Viridius
step
#label Protectorate2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Researcher Navuud|r, |cRXP_FRIENDLY_Professor Dabiri|r and |cRXP_FRIENDLY_Commander Ameer|r
.turnin 10411 >> Turn in Electro-Shock Goodness!
.target +Researcher Navuud
.goto Netherstorm,59.25,32.58,-1
.turnin 10437 >> Turn in Recipe for Destruction
.accept 10438 >> Accept On Nethery Wings
.goto Netherstorm,60.11,31.72,-1
.target +Professor Dabiri
.turnin 10353 >> Turn in Arconus the Insatiable
.goto Netherstorm,59.51,32.39,-1
.target +Commander Ameer
step
#requires CaptainTyraliusTurnin
.isOnQuest 10438
.goto Netherstorm,60.21,31.76
.gossip 20903,0 >> Talk to the |cRXP_FRIENDLY_Protectorate Nether Drake|r
.skipgossip
.target Protectorate Nether Drake
step
.goto Netherstorm,62.42,40.88
.use 29778 >>|cRXP_WARN_Once you reach the top of the Manaforge, use the|r |T133018:0|t[Phase Disruptor] |cRXP_WARN_repeatedly|r
.complete 10438,1 
step
.goto Netherstorm,60.11,31.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Dabiri|r
.turnin 10438 >> Turn in On Nethery Wings
.accept 10439 >> Accept Dimensius the All-Devouring
.target Professor Dabiri
step
.goto Netherstorm,60.63,32.08,10,0
.goto Netherstorm,62.41,40.89
>>Talk to |cRXP_FRIENDLY_Captain Saeed|r at the Protectorate Watchpost to begin the attack on |cRXP_ENEMY_Dimensius the All-Devouring|r
>>Kill |cRXP_ENEMY_Dimensius the All-Devouring|r
>>|cRXP_WARN_Having a 5 man group with Tank + Healer is recommended for this step|r
.complete 10439,1 
.complete 10439,2 
.target Captain Saeed
.mob Dimensius the All-Devouring
step
.goto Netherstorm,60.11,31.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Dabiri|r
.turnin 10439 >> Turn in Dimensius the All-Devouring
.target Professor Dabiri
step
.skill riding,225,1
#completewith next
.groundgoto Netherstorm,69.34,34.45,50,0
.groundgoto Netherstorm,70.06,37.52,50 >> Travel down the Celestial Ridge
step
#label NetherstormQuests
.goto Netherstorm,71.142,38.991
>>Click the |cRXP_PICK_Ethereal Teleport Pad|r, then talk to |cRXP_FRIENDLY_Wind Trader Marid|r
.turnin 10270 >> Turn in A Not-So-Modest Proposal
.target Wind Trader Marid
step
#label ReveredGrind
step
#tip
#completewith ReveredGrind2
>>The |cRXP_PICK_Ethereum Prisons|r can also spawn a random |cRXP_FRIENDLY_Friendly|r NPC awarding 500 rep with one of the following factions: Consortium, Cenarion Expedition, Keepers of Time, Lower City, The Sha'tar or Sporeggar. |cRXP_WARN_The reputation you gain through this method is party wide so you and 4 other friends can benefit from it|r
>>|T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r] can be bought from the Auction House
step
#label ReveredGrind2
.goto Nagrand,31.4,57.6,0
.goto Nagrand,31.365,57.793,0
.goto Nagrand,50.6,56.6,0
.goto Nagrand,40.6,31.0,0
.goto Netherstorm,30.4,76.6,0
.goto Netherstorm,32.442,64.206,0
.goto Netherstorm,59.5,32.4,0
.goto Netherstorm,54.46,40.36,0
.reputation 933,revered >>|cRXP_WARN_You now have a few choices to grind out the rep|r
>>Complete Heroic Mana-Tombs once every day (Requires Lower City Revered)
.dailyturnin 9892 >>Kill |cRXP_ENEMY_Ogres|r in Nagrand. Loot them for their |cRXP_LOOT_Obsidian Warbeads|r. Turn them in at |cRXP_FRIENDLY_Gezhe|r
.disablecheckbox
.dailyturnin 10308 >>Kill |cRXP_ENEMY_Zaxxis|r in Netherstorm. Loot them for their |cRXP_LOOT_Zaxxis Insignias|r. Turn them in at |cRXP_FRIENDLY_Nether-Stalker Khay'ji|r
.disablecheckbox
>>|cRXP_WARN_You will also be able to loot |cRXP_ENEMY_Zaxxis|r and |cRXP_ENEMY_Ethereum|r in Netherstorm and Mana-Tombs for|r |T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r]
.dailyturnin 10972 >>|cRXP_WARN_Use the keys at |cRXP_PICK_Ethereum Prisons|r at the Ethereum Staging Grounds in Netherstorm. This will spawn a |cRXP_ENEMY_Hostile|r mob which drops a |T134391:0|t[|cRXP_LOOT_Ethereum Prisoner I.D. Tag|r] that can be turned in at |cRXP_FRIENDLY_Commander Ameer|r for 250 rep|r
.disablecheckbox
step
.goto Netherstorm,59.5,32.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ameer|r
.accept 10339 >> Accept A Thousand Worlds
.target Commander Ameer
step
.goto Netherstorm,59.5,32.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ameer|r
>>|cRXP_WARN_NOTE: This quest chain requires turning in 5 x |T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r] and unlocks the ability to summon |cRXP_ENEMY_Yor|r in Heroic Mana-Tombs|r
.collect 29460,5,10339,1 
.turnin 10339 >> Turn in A Thousand Worlds
.target Commander Ameer
step
.goto Netherstorm,59.5,32.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ameer|r
.accept 10339 >> Accept A Thousand Worlds
.target Commander Ameer
step
.goto Netherstorm,59.5,32.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ameer|r
>>|cRXP_WARN_NOTE: This quest chain requires turning in 5 x |T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r] and unlocks the ability to summon |cRXP_ENEMY_Yor|r in Heroic Mana-Tombs|r
.collect 29460,5,10339,1 
.turnin 10339 >> Turn in A Thousand Worlds
.accept 10974 >> Accept Stasis Chambers of Bash'ir
.target Commander Ameer
step
.goto Blade's Edge Mountains,51.129,11.553
>>Click the |cRXP_PICK_Stasis Chamber Alpha|r to summon |cRXP_ENEMY_Thuk the Defiant|r
>>Kill |cRXP_ENEMY_Thuk the Defiant|r. Loot him for the |cRXP_LOOT_Evidence from Alpha|r
>>|cRXP_WARN_He has roughly 80,000 HP. He can be CC'd. Find 1-2 extra people to help you with it if needed|r
.complete 10974,1 
.mob Thuk the Defiant
step
.goto Blade's Edge Mountains,52.854,14.983
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10974 >> Turn in Stasis Chambers of Bash'ir
.accept 10976 >> Accept The Mark of the Nexus-King
.target Image of Commander Ameer
step
.goto Blade's Edge Mountains,52.854,14.983
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r
>>Turn in 5 |T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r] to receive a |T134891:0|t[|cRXP_LOOT_Ethereum Stasis Chamber Key|r]
.collect 29460,5,10976,1 
.collect 29750,1,10976,1 
.dailyturnin 10975 >> Turn in Purging the Chambers of Bash'ir
.disablecheckbox
.target Image of Commander Ameer
step
#loop
.goto Blade's Edge Mountains,52.70,20.25,50,0
.goto Blade's Edge Mountains,49.40,21.31,50,0
.goto Blade's Edge Mountains,49.56,15.64,50,0
>>Open the |cRXP_PICK_Ethereum Stasis Chambers|r to summon |cRXP_ENEMY_Elites|r. Kill them and loot them for a |cRXP_LOOT_Mark of the Nexus-King|r
>>|cRXP_WARN_Ensure you have a few people helping you when you summon them|r
>>|cRXP_WARN_The |cRXP_LOOT_Mark of the Nexus-King|r is not a gaurenteed drop|r
.complete 10976,1 
step
.goto Blade's Edge Mountains,52.854,14.983
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10976 >> Turn in The Mark of the Nexus-King
.accept 10977 >> Accept Stasis Chambers of the Mana-Tombs
.target Image of Commander Ameer
step
>>Find a group for Heroic: Mana-Tombs
>>Click the |cRXP_PICK_Stasis Chamber|r inside. It is in the room after |cRXP_ENEMY_Pandemonius|r
.complete 10977,1 
step
#completewith next
.zone Blade's Edge Mountains >> Return to Blade's Edge Mountains
step
.goto Blade's Edge Mountains,52.854,14.983
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10977 >> Turn in Stasis Chambers of the Mana-Tombs
.accept 10981 >> Accept Nexus-Prince Shaffar's Personal Chamber
.target Image of Commander Ameer
step
#loop
.goto Blade's Edge Mountains,52.70,20.25,50,0
.goto Blade's Edge Mountains,49.40,21.31,50,0
.goto Blade's Edge Mountains,49.56,15.64,50,0
>>Obtain another |cRXP_LOOT_Mark of the Nexus-King|r by opening the |cRXP_PICK_Ethereum Stasis Chambers|r to summon and kill the |cRXP_ENEMY_Elites|r
>>|cRXP_WARN_You must turn in 5 |T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r] to receive a |T134891:0|t[|cRXP_LOOT_Ethereum Stasis Chamber Key|r] which allows you to open|r |cRXP_PICK_Ethereum Stasis Chambers|r
.complete 10981,1 
step
.goto Blade's Edge Mountains,52.854,14.983
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r
.turnin 10981 >> Turn in Nexus-Prince Shaffar's Personal Chamber
.target Image of Commander Ameer
step
#tip
#completewith ExaltedGrind
>>The |cRXP_PICK_Ethereum Prisons|r can also spawn a random |cRXP_FRIENDLY_Friendly|r NPC awarding 500 rep with one of the following factions: Consortium, Cenarion Expedition, Keepers of Time, Lower City, The Sha'tar or Sporeggar. |cRXP_WARN_The reputation you gain through this method is party wide so you and 4 other friends can benefit from it|r
>>|T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r] can be bought from the Auction House
step
#label ExaltedGrind
.goto Nagrand,31.4,57.6,0
.goto Nagrand,31.365,57.793,0
.goto Nagrand,50.6,56.6,0
.goto Nagrand,40.6,31.0,0
.goto Netherstorm,30.4,76.6,0
.goto Netherstorm,32.442,64.206,0
.goto Netherstorm,59.5,32.4,0
.goto Netherstorm,54.46,40.36,0
.reputation 933,exalted >>|cRXP_WARN_You now have a few choices to grind out the rep|r
>>Complete Heroic Mana-Tombs once every day (Requires Lower City Revered)
.dailyturnin 9892 >>Kill |cRXP_ENEMY_Ogres|r in Nagrand. Loot them for their |cRXP_LOOT_Obsidian Warbeads|r. Turn them in at |cRXP_FRIENDLY_Gezhe|r
.disablecheckbox
.dailyturnin 10308 >>Kill |cRXP_ENEMY_Zaxxis|r in Netherstorm. Loot them for their |cRXP_LOOT_Zaxxis Insignias|r. Turn them in at |cRXP_FRIENDLY_Nether-Stalker Khay'ji|r
.disablecheckbox
>>|cRXP_WARN_You will also be able to loot |cRXP_ENEMY_Zaxxis|r and |cRXP_ENEMY_Ethereum|r in Netherstorm and Mana-Tombs for|r |T134889:0|t[|cRXP_LOOT_Ethereum Prison Key|r]
.dailyturnin 10972 >>|cRXP_WARN_Use the keys at |cRXP_PICK_Ethereum Prisons|r at the Ethereum Staging Grounds in Netherstorm. This will spawn a |cRXP_ENEMY_Hostile|r mob which drops a |T134391:0|t[|cRXP_LOOT_Ethereum Prisoner I.D. Tag|r] that can be turned in at |cRXP_FRIENDLY_Commander Ameer|r for 250 rep|r
.disablecheckbox
step
+|cRXP_WARN_Congratulations! You have reached the end of The Consortium reputation guide|r
]])

