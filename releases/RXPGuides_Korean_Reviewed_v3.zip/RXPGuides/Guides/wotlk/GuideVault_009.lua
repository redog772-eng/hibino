if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "WOTLK" then return end

RXPGuides.RegisterGuide([[#wotlk
#group +Azeroth Farming
#loop
#hidewindow
#subgroup Winterspring
#name Herbalism9
#displayname Herbalism
step
    #sticky
    .waypoint Winterspring,50,50
    .zone Winterspring >> Head to Winterspring
step
    #hidewindow
    +test
    .loop @20,Winterspring,58.3,33.3,55.9,27.3,51.5,24.6,48.6,11.3,48.8,8.6,55.5,13.7,60.5,14.3,60.3,17.4,58.8,19.7,54.1,17.5,59.5,24.7,60.5,23.4,65.8,20.2,66.4,21.7,64.6,25.9,65.7,29.1,67.4,29.8,68.4,34.9,67.2,35.9,69.0,37.9,66.8,39.6,64.6,39.2,66.8,44.7,63.2,46.6,64.5,50.8,66.9,53.8,65.0,58.2,65.7,60.4,64.9,64.3,62.5,67.2,61.6,71.7,62.8,72.9,64.4,74.0,60.7,74.5,59.2,73.4,57.7,69.7,61.6,71.7,62.5,67.2,61.0,64.6,58.7,61.4,56.5,53.4,60.5,55.4,59.8,47.6,58.1,46.3,59.3,44.5,56.4,46.7,54.0,45.4,50.5,44.1,46.2,44.4,41.9,44.2,35.2,44.6,32.0,44.3,30.6,45.5,30.9,36.6,34.0,36.6,33.5,38.8,36.4,41.5,39.0,36.2,41.3,35.6,44.1,37.2,47.6,36.5,52.6,38.2,57.1,37.2,57.0,34.8,58.3,33.3
    .openmap Winterspring
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Azeroth Farming
#loop
#hidewindow
#subgroup Winterspring
#name Mining & Herbalism9
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Winterspring,50,50
    .zone Winterspring >> Head to Winterspring
step
    #hidewindow
    +test
    .loop @20,Winterspring,58.3,33.3,55.9,27.3,51.5,24.6,48.6,11.3,48.8,8.6,55.5,13.7,60.5,14.3,60.3,17.4,58.8,19.7,60.5,23.4,65.8,20.2,66.4,21.7,64.6,25.9,65.7,29.1,67.4,29.8,68.4,34.9,67.2,35.9,69.0,37.9,66.8,39.6,64.6,39.2,66.8,44.7,66.6,54.1,65.0,58.2,65.7,60.4,62.5,66.7,61.7,70.9,62.7,74.2,59.6,75.6,60.3,78.4,62.8,78.7,64.4,79.5,64.4,79.5,62.8,78.7,60.3,78.4,61.2,82.2,62.0,83.6,59.0,83.5,59.1,87.0,57.4,88.9,55.3,84.1,53.8,84.8,53.6,86.1,53.1,86.3,52.7,88.5,51.4,89.2,53.0,84.8,55.0,79.9,56.8,79.4,58.2,72.6,57.7,68.0,61.8,70.9,62.5,66.5,62.1,63.1,58.6,61.1,60.5,56.2,61.0,51.7,63.4,50.4,62.5,47.6,57.6,47.0,57.1,43.7,53.3,44.5,48.6,43.3,45.0,44.1,45.0,37.7,48.0,37.1,51.9,38.1,53.2,38.0,58.3,33.3
    .openmap Winterspring
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Borean Tundra
#name Eternal Water (Frozen Elemental)_28a
#displayname Eternal Water (Frozen Elemental)
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,99.0,42.0,97.2,36.1,94.2,35.8,91.2,40.7,86.9,42.8,82.9,45.0,83.6,48.1,85.3,48.9,88.4,47.1,91.9,43.2,96.7,43.9,99.0,42.0
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Borean Tundra
#name Eternal Water (Steam Rager)_29a
#displayname Eternal Water (Steam Rager)
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,76.2,33.1,74.2,27.7,73.2,23.8,70.6,21.3,68.0,22.7,68.6,28.4,70.6,31.9,71.5,37.0,70.9,39.9,72.9,42.1,75.2,39.6,76.2,33.1
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Borean Tundra
#name Eternal Water (Boiling Spirit)_30a
#displayname Eternal Water (Boiling Spirit)
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,46.9,16.6,48.6,12.8,46.4,10.5,45.0,11.1,45.6,16.4,46.9,16.6
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Borean Tundra
#name Eternal Fire (Boiling Spirit)_31a
#displayname Eternal Fire (Boiling Spirit)
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,47.3,16.4,49.4,18.3,50.9,15.2,49.5,12.7,47.0,11.9,47.3,16.4
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Borean Tundra
#name Eternal Air (Enraged Tempest)_32a
#displayname Eternal Air (Enraged Tempest)
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,44.4,12.2,46.8,11.2,46.7,7.2,45.1,5.8,41.8,8.2,42.2,10.8,44.4,12.2
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Cooking & Skinning
#loop
#hidewindow
#subgroup Borean Tundra
#name Rhino Meat & Borean Leather_33a
#displayname Rhino Meat & Borean Leather
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +area1
    .loop @20,Borean Tundra,47.3,39.4,44.7,39.8,42.2,42.6,40.6,42.8,42.1,48.0,42.2,48.9,47.9,48.0,47.3,39.4
    .openmap Borean Tundra
    #hidewindow
    +area2
    .loop @20,Borean Tundra,49.7,74.3,43.4,76.4,40.1,73.8,40.6,70.3,45.8,69.7,48.7,68.9,50.7,66.7,52.1,68.7,49.7,74.3
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Cooking & Skinning
#loop
#hidewindow
#subgroup Sholazar Basin
#name Chilled Meat & Sholazar Basin_34a
#displayname Chilled Meat & Sholazar Basin
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Borean Tundra >> Head to Sholazar Basin
step
    #hidewindow
    +area1
    .loop @20,Sholazar Basin,20.6,62.6,22.1,75.6,27.8,79.8,30.2,70.5,32.8,65.7,27.2,64.5,24.9,60.8,29.6,55.9,33.4,41.7,31.5,36.4,26.2,45.0,22.7,50.5,20.6,62.6
    .openmap Sholazar Basin
    #hidewindow
    +area2
    .loop @20,Sholazar Basin,56.8,81.0,59.4,74.2,64.4,70.1,57.7,65.5,55.0,76.5,56.8,81.0
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Sholazar Basin
#name Eternal Earth (Lifeblood Elemental)_35a
#displayname Eternal Earth (Lifeblood Elemental)
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Sholazar Basin >> Head to Sholazar Basin
step
    #hidewindow
    +test
    .loop @20,Sholazar Basin,69.1,60.2,71.9,62.1,74.7,59.7,75.5,56.7,73.5,53.9,67.9,53.5,69.1,60.2
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Sholazar Basin
#name Eternal Earth (Sholazar Guardian)_36a
#displayname Eternal Earth (Sholazar Guardian)
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Sholazar Basin >> Head to Sholazar Basin
step
    #hidewindow
    +test
    .loop @20,Sholazar Basin,80.5,54.4,84.3,53.6,
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Cooking & Skinning
#loop
#hidewindow
#subgroup Sholazar Basin
#name Chunk o' Mammoth & Borean Leather_37a
#displayname Chunk o' Mammoth & Borean Leather
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Sholazar Basin >> Head to Sholazar Basin
step
    #hidewindow
    +test
    .loop @20,Sholazar Basin,58.6,38.6,56.5,30.1,51.3,28.7,39.2,26.5,36.4,27.8,36.3,32.4,46.9,44.5,54.0,44.8,55.1,38.4,58.6,38.6,
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Sholazar Basin
#name Eternal Water & Air (Storm Revenant & Aqueous Spirit)_38a
#displayname Eternal Water & Air (Storm Revenant & Aqueous Spirit)
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Sholazar Basin >> Head to Sholazar Basin
step
    #hidewindow
    +test
    .loop @20,Sholazar Basin,32.2,30.7,30.4,34.8,26.3,40.7,24.4,45.1,20.9,48.6,20.0,47.1,22.0,43.5,21.9,33.7,26.1,30.3,30.6,28.9,32.2,30.7
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Dragonblight
#name Eternal Water (Crystalline Ice Elemental)_39a
#displayname Eternal Water (Crystalline Ice Elemental)
step
    #sticky
    .waypoint Dragonblight,50,50
    .zone Dragonblight >> Head to Dragonblight
step
    #hidewindow
    +test
    .loop @20,Dragonblight,48.4,20.0,49.0,21.9,53.3,21.1,53.4,17.5,50.4,15.7,46.8,15.2,46.6,19.1,48.4,20.0
    .openmap Dragonblight
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Dragonblight
#name Eternal Shadow (Deathbringer Revenant)_40a
#displayname Eternal Shadow (Deathbringer Revenant)
step
    #sticky
    .waypoint Dragonblight,50,50
    .zone Dragonblight >> Head to Dragonblight
step
    #hidewindow
    +test
    .loop @20,Dragonblight,74.3,23.6,72.9,20.1,75.4,19.0,76.2,20.0,75.9,21.1,74.3,23.6
    .openmap Dragonblight
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Dragonblight
#name Eternal Water (Ice Revenant)_41a
#displayname Eternal Water (Ice Revenant)
step
    #sticky
    .waypoint Dragonblight,50,50
    .zone Dragonblight >> Head to Dragonblight
step
    #hidewindow
    +test
    .loop @20,Dragonblight,66.0,51.9,68.4,50.3,68.9,52.7,68.1,56.2,66.9,56.4,66.2,54.2,66.0,51.9
    .openmap Dragonblight
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Grizzly Hills
#name Eternal Earth (Runic Battle Golem)_42a
#displayname Eternal Earth (Runic Battle Golem)
step
    #sticky
    .waypoint Grizzly Hills,50,50
    .zone Grizzly Hills >> Head to Grizzly Hills
step
    #hidewindow
    +test
    .loop @20,Grizzly Hills,62.8,25.8,62.1,23.0,63.0,19.3,64.7,18.4,66.2,20.1,67.3,24.2,64.0,28.2,62.7,27.4,62.8,25.8
    .openmap Grizzly Hills
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Grizzly Hills
#name Eternal Air (Lightning Sentry)_43a
#displayname Eternal Air (Lightning Sentry)
step
    #sticky
    .waypoint Grizzly Hills,50,50
    .zone Grizzly Hills >> Head to Grizzly Hills
step
    #hidewindow
    +test
    .loop @20,Grizzly Hills,75.7,49.9,78.2,51.5,81.1,56.6,80.8,59.6,76.7,63.6,71.9,62.7,71.9,55.7,73.4,50.7,75.7,49.9
    .openmap Grizzly Hills
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Howling Fjord
#name Eternal Earth (Iron Rune Sentinel)_44a
#displayname Eternal Earth (Iron Rune Sentinel)
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,70.8,31.6,69.0,30.4,65.8,29.1,66.3,24.4,69.8,20.9,72.5,17.8,74.7,24.2,70.8,31.6
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Howling Fjord
#name Eternal Earth (Iron Rune Golem)_45a
#displayname Eternal Earth (Iron Rune Golem)
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,73.5,70.5,73.2,69.6,71.8,70.1,71.2,69.6,70.9,71.5,71.4,72.4,
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Howling Fjord
#name Eternal Water (Ice Elemental)_46a
#displayname Eternal Water (Ice Elemental)
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,60.7,20.0,62.5,20.2,64.1,22.0,64.0,24.3,63.0,26.3,60.2,24.8,58.8,22.5,59.0,19.5,60.7,20.0
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Howling Fjord
#name Eternal Water (Iceshard Elemental)_47a
#displayname Eternal Water (Iceshard Elemental)
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,57.4,9.1,59.1,9.1,60.2,11.7,58.2,15.0,53.8,12.3,51.1,5.8,50.4,1.6,56.5,1.8,56.3,8.0,57.4,9.1
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Howling Fjord
#name Eternal Life (Thornvine Creeper)_48a
#displayname Eternal Life (Thornvine Creeper)
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,55.8,17.1,55.7,19.6,52.1,20.2,51.6,16.6,52.4,14.0,55.3,15.3,55.8,17.1
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Zul'Drak
#name Eternal Water (Crazed Water Spirit)_49a
#displayname Eternal Water (Crazed Water Spirit)
step
    #sticky
    .waypoint Zul'Drak,50,50
    .zone Zul'Drak >> Head to Zul'Drak
step
    #hidewindow
    +test
    .loop @20,Zul'Drak,43.2,84.7,37.5,75.7,41.2,70.5,47.0,80.1,45.5,83.3,43.2,84.7
    .openmap Zul'Drak
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Cooking & Skinning
#loop
#hidewindow
#subgroup Zul'Drak
#name Iceweb Spider Silk & Borean Leather_50a
#displayname Iceweb Spider Silk & Borean Leather
step
    #sticky
    .waypoint Zul'Drak,50,50
    .zone Zul'Drak >> Head to Zul'Drak
step
    #hidewindow
    +test
    .loop @20,Zul'Drak,34.7,58.1,34.5,46.1,37.1,46.5,43.3,49.2,43.5,36.8,46.4,36.0,46.3,50.8,39.9,58.2,34.7,58.1
    .openmap Zul'Drak
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Zul'Drak
#name Eternal Water (Frozen Earth)_51a
#displayname Eternal Water (Frozen Earth)
step
    #sticky
    .waypoint Zul'Drak,50,50
    .zone Zul'Drak >> Head to Zul'Drak
step
    #hidewindow
    +test
    .loop @20,Zul'Drak,52.2,56.7,48.7,49.1,48.8,42.1,57.2,42.1,59.5,49.8,54.7,57.3,52.2,56.7
    .openmap Zul'Drak
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Zul'Drak
#name Eternal Earth (Guardian of Zum'Rhuk)_52a
#displayname Eternal Earth (Guardian of Zum'Rhuk)
step
    #sticky
    .waypoint Zul'Drak,50,50
    .zone Zul'Drak >> Head to Zul'Drak
step
    #hidewindow
    +test
    .loop @20,Zul'Drak,59.3,49.3,56.5,44.7,59.6,39.8,62.7,44.3,59.3,49.3
    .openmap Zul'Drak
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Cooking & Skinning
#loop
#hidewindow
#subgroup The Storm Peaks
#name Chunk o' Mammoth & Borean Leather_53a
#displayname Chunk o' Mammoth & Borean Leather
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,60.6,61.7,59.9,57.5,57.9,58.7,56.4,63.4,53.5,65.5,56.0,68.2,60.6,61.7,
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Cooking & Skinning
#loop
#hidewindow
#subgroup The Storm Peaks
#name Worm Meat & Borean Leather_54a
#displayname Worm Meat & Borean Leather
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,46.7,55.3,49.1,52.5,47.7,50.8,47.1,48.7,48.5,48.2,48.1,46.5,47.4,46.1,
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup The Storm Peaks
#name Eternal Fire (Seething Revenant)_55a
#displayname Eternal Fire (Seething Revenant)
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,68.8,62.6,68.7,57.4,70.8,55.5,71.7,56.3,72.2,58.8,72.8,61.8,77.4,61.7,77.9,62.8,76.2,64.4,67.8,63.7,68.8,62.6
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup The Storm Peaks
#name Eternal Earth (Brittle Revenant)_56a
#displayname Eternal Earth (Brittle Revenant)
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,68.8,62.6,68.7,57.4,70.8,55.5,71.5,58.4,71.5,61.1,72.7,63.4,70.5,63.1,68.8,62.6
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup The Storm Peaks
#name Eternal Fire (Wailing Winds)_57a
#displayname Eternal Fire (Wailing Winds)
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,62.5,41.5,63.2,39.6
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup The Storm Peaks
#name Eternal Air (Scion of Storm)_58a
#displayname Eternal Air (Scion of Storm)
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,66.1,39.2,69.5,39.8,70.8,42.2,68.2,46.0,66.7,45.5,65.4,42.0,66.1,39.2
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup The Storm Peaks
#name Eternal Water (Icebound Revenant)_59a
#displayname Eternal Water (Icebound Revenant)
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,42.5,61.1,41.3,60.6,40.7,62.9,41.1,64.3,43.2,66.9,44.8,64.9,42.5,61.1
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup The Storm Peaks
#name Eternal Water (Stormrider)_60a
#displayname Eternal Water (Stormrider)
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,34.1,47.3,31.6,50.3,28.8,52.3,27.7,50.4,25.7,41.6,27.4,40.3,28.4,42.4,28.9,46.8,32.3,46.9,33.5,46.4,34.1,47.3
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Icecrown
#name Frostweave Cloth (Converted Hero)_61a
#displayname Frostweave Cloth (Converted Hero)
step
    #sticky
    .waypoint Icecrown,50,50
    .zone Icecrown >> Head to Icecrown
step
    #hidewindow
    +test
    .loop @20, Icecrown,40.9,46.6,48.3,50.2,48.1,57.7,40.9,58.6,39.0,58.6,38.6,50.6,40.9,46.6
    .openmap Icecrown
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Wintergrasp
#name Eternal Shadow (Wandering Shadow)_62a
#displayname Eternal Shadow (Wandering Shadow)
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20, Wintergrasp,22.7,45.1,21.7,52.0,20.4,63.7,16.3,63.9,9.1,54.0,20.1,36.3,22.7,45.1
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Borean Tundra
#name Herbalism10
#displayname Herbalism
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,77.0,30.1,77.5,35.8,75.5,41.7,69.0,41.8,64.5,39.8,60.7,42.5,61.6,58.4,57.4,48.8,49.8,69.5,49.2,74.9,46.2,72.2,32.8,63.5,32.5,54.3,44.0,43.9,52.7,49.0,52.7,41.0,58.0,40.4,60.1,32.5,54.9,27.9,48.4,23.2,50.0,20.0,58.1,18.7,61.8,14.3,66.0,16.1,73.4,25.9,70.1,31.0,72.6,34.2,77.0,30.1
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Borean Tundra
#name Mining10
#displayname Mining
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,91.1,33.6,87.8,44.7,78.9,44.7,78.9,30.0,73.4,32.7,72.6,28.0,68.2,25.5,69.3,31.5,64.1,33.4,61.7,37.7,66.3,38.8,72.6,45.3,66.0,46.6,59.6,59.4,56.6,57.8,52.8,73.2,49.3,69.4,50.6,57.1,43.1,70.4,34.1,67.0,29.5,56.5,49.2,49.1,52.3,35.9,50.0,33.3,41.7,41.6,23.8,33.6,22.7,28.9,25.0,22.0,30.4,22.3,33.2,27.6,39.9,20.0,44.2,21.3,41.9,13.7,48.7,15.3,55.5,11.8,60.0,11.7,59.4,19.2,61.1,22.3,65.9,16.6,74.2,17.1,78.0,21.3,84.1,32.3,91.1,33.6
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Borean Tundra
#name Mining & Herbalism10
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Borean Tundra,50,50
    .zone Borean Tundra >> Head to Borean Tundra
step
    #hidewindow
    +test
    .loop @20,Borean Tundra,91.1,33.6,87.8,44.7,79.4,48.5,77.4,42.3,78.1,30.5,74.0,26.6,72.2,31.1,71.8,39.0,63.2,32.3,58.8,40.7,66.2,40.5,72.9,44.0,66.3,46.9,62.3,46.1,60.5,60.4,57.3,49.8,55.6,57.7,53.5,64.2,51.0,64.9,53.4,72.3,48.9,75.4,46.5,72.7,50.0,55.3,45.5,61.5,42.2,74.6,38.3,68.9,31.1,62.2,29.3,55.8,35.6,53.5,37.3,47.9,49.8,49.6,53.7,43.0,49.8,42.8,52.5,34.6,49.0,33.5,44.4,41.6,40.9,43.3,23.8,33.6,22.7,28.9,25.0,22.0,30.4,22.3,33.2,27.6,46.4,21.9,42.3,13.5,44.5,8.3,48.9,12.1,48.7,15.3,49.4,22.0,55.5,11.8,60.0,11.7,63.4,15.8,61.1,20.4,59.2,28.1,74.2,17.1,78.0,21.3,84.1,32.3,91.1,33.6
    .openmap Borean Tundra
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Sholazar Basin
#name Herbalism11
#displayname Herbalism
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Sholazar Basin >> Head to Sholazar Basin
step
    #hidewindow
    +test
    .loop @20,Sholazar Basin,70.1,68.4,67.1,70.9,65.7,75.3,58.3,77.7,60.9,84.4,54.4,85.7,48.6,83.5,48.1,71.7,47.8,65.8,49.6,52.4,46.4,51.7,45.1,56.3,42.1,58.0,40.9,64.3,42.2,83.2,33.5,83.1,27.2,80.1,26.6,72.8,34.2,66.3,33.8,59.8,22.2,59.2,23.1,48.1,28.6,52.7,30.1,44.5,35.4,45.0,33.4,35.1,41.4,22.8,58.3,27.8,62.1,35.0,56.1,35.7,57.3,42.3,59.2,47.0,56.7,55.9,54.2,61.5,61.7,67.2,70.1,68.4
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Sholazar Basin
#name Mining11
#displayname Mining
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Sholazar Basin >> Head to Sholazar Basin
step
    #hidewindow
    +test
    .loop @20,Sholazar Basin,77.7,56.8,76.3,65.9,64.0,81.0,60.2,80.3,59.7,87.0,54.0,88.3,59.3,66.8,53.8,64.0,47.7,60.4,45.9,63.5,50.2,78.8,48.5,87.0,40.3,87.1,37.4,83.7,40.4,76.5,36.6,69.1,32.2,75.0,31.8,80.2,32.2,83.6,22.8,82.4,20.8,70.3,23.5,52.8,25.8,47.2,31.9,59.5,36.3,57.5,39.5,51.2,31.4,37.9,35.2,32.8,37.6,37.0,40.8,38.4,43.1,35.8,49.7,43.3,53.5,38.7,51.0,31.6,43.6,22.3,58.9,25.0,59.0,29.4,62.9,31.8,67.2,42.9,61.3,50.4,64.2,53.8,67.3,50.7,67.8,55.2,74.2,55.5,77.7,56.8
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Sholazar Basin
#name Mining & Herbalism11
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Sholazar Basin,50,50
    .zone Sholazar Basin >> Head to Sholazar Basin
step
    #hidewindow
    +test
    .loop @20,Sholazar Basin,79.2,52.4,76.3,65.9,71.5,72.1,65.2,71.0,65.9,78.9,59.7,87.0,54.0,88.3,59.3,66.8,53.8,64.0,47.7,60.4,42.9,60.6,42.6,65.4,47.8,67.6,50.9,72.8,47.9,78.1,48.5,87.0,40.3,87.1,37.4,83.7,40.4,76.5,36.6,69.1,32.2,75.0,31.8,80.2,32.2,83.6,22.8,82.4,20.8,70.3,23.5,52.8,25.8,47.2,29.6,52.7,30.4,62.5,34.5,62.6,33.7,57.7,36.3,57.5,39.5,51.2,35.4,44.9,29.5,45.3,31.4,37.9,35.2,32.8,37.6,37.0,40.8,38.4,43.1,35.8,49.7,43.3,53.5,38.7,51.0,31.6,43.6,22.3,58.9,25.0,59.0,29.4,62.9,31.8,67.2,42.9,61.3,50.4,57.9,50.5,60.6,55.0,64.2,53.8,67.3,50.7,67.8,55.2,74.2,55.5,76.4,48.5,79.2,52.4
    .openmap Sholazar Basin
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Dragonblight
#name Herbalism12
#displayname Herbalism
step
    #sticky
    .waypoint Dragonblight,50,50
    .zone Dragonblight >> Head to Dragonblight
step
    #hidewindow
    +test
    .loop @20,Dragonblight,16.1,47.9,14.8,56.8,19.3,55.3,23.2,57.2,29.9,60.6,34.2,59.6,35.0,73.0,38.5,74.5,48.5,70.4,54.9,70.9,49.4,63.2,43.8,65.6,45.7,59.9,41.2,55.8,46.3,50.0,43.4,47.4,43.3,35.1,30.5,45.7,29.0,52.8,24.2,52.0,20.8,48.0,16.1,47.9
    .openmap Dragonblight
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Dragonblight
#name Mining12
#displayname Mining
step
    #sticky
    .waypoint Dragonblight,50,50
    .zone Dragonblight >> Head to Dragonblight
step
    #hidewindow
    +test
    .loop @20,Dragonblight,14.3,44.0,17.8,56.5,28.5,65.8,32.8,68.8,30.0,75.3,45.8,74.0,52.3,67.2,58.8,65.2,67.9,63.2,69.0,69.7,62.3,73.5,66.2,78.3,70.9,82.9,74.1,81.1,78.7,71.5,72.1,61.6,70.8,55.3,66.3,55.3,65.0,48.9,72.7,50.1,73.2,42.0,66.7,37.2,70.8,32.0,75.5,34.0,76.2,29.1,68.7,23.5,63.5,23.4,57.4,16.9,50.4,19.1,56.6,35.1,46.9,45.0,46.2,60.2,33.7,60.8,14.3,44.0
    .openmap Dragonblight
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Dragonblight
#name Mining & Herbalism12
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Dragonblight,50,50
    .zone Dragonblight >> Head to Dragonblight
step
    #hidewindow
    +test
    .loop @20,Dragonblight,14.3,44.0,16.6,50.7,15.0,57.7,23.4,62.7,25.5,60.3,28.4,62.3,28.9,66.3,30.5,74.2,36.2,73.3,35.0,65.5,35.5,59.8,45.5,57.9,43.5,63.6,44.0,72.7,47.9,70.6,49.9,63.7,52.7,70.7,56.4,70.6,57.0,65.8,62.2,71.6,66.2,78.5,72.1,83.2,76.6,75.7,75.3,69.2,80.0,70.6,81.5,65.6,86.1,61.5,90.5,73.5,90.8,49.1,85.9,42.9,83.4,36.8,87.8,31.4,85.4,20.3,80.1,27.9,80.0,31.5,75.6,30.2,69.0,34.3,73.6,36.4,70.6,41.8,72.7,50.5,70.6,55.4,70.4,66.3,64.6,62.7,66.5,53.5,65.0,45.1,53.7,38.2,53.1,34.4,58.9,32.7,59.8,17.5,50.8,19.3,46.6,11.6,42.9,33.5,45.6,45.7,49.6,46.0,49.3,51.7,42.7,49.7,36.9,41.3,28.3,52.9,23.0,54.6,14.3,44.0
    .openmap Dragonblight
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Howling Fjord
#name Mining & Herbalism13
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,69.8,32.3,73.3,22.7,69.1,10.4,68.2,18.9,67.7,23.3,63.0,22.5,61.8,29.7,55.7,16.7,52.1,15.9,46.7,21.5,45.9,15.4,43.4,10.7,39.3,9.6,40.8,15.5,38.0,17.1,34.3,24.0,29.3,7.7,27.3,13.8,24.0,16.8,20.2,23.3,22.9,26.3,27.1,23.3,30.8,25.5,27.7,31.1,33.7,34.2,40.1,28.4,42.3,37.4,47.0,40.1,49.9,32.4,59.8,37.8,62.6,35.2,64.3,40.3,65.9,51.6,59.8,51.2,53.9,52.4,55.4,56.9,59.9,56.1,62.6,60.7,61.4,65.8,57.3,67.3,51.8,59.4,51.2,50.6,47.8,49.1,47.7,58.6,37.3,54.5,36.2,46.6,28.1,54.6,31.2,61.6,33.4,77.7,35.5,76.7,45.8,64.8,47.8,73.1,57.9,74.7,60.4,78.9,65.8,70.6,68.7,59.0,71.7,60.8,69.5,73.2,76.7,63.2,74.7,53.9,78.0,47.1,74.5,43.6,79.8,34.1,70.6,38.9,66.8,31.9,69.8,32.3
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Howling Fjord
#name Herbalism13
#displayname Herbalism
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,27.3,10.4,30.4,23.8,38.3,21.9,42.0,25.3,42.0,29.9,47.3,26.8,45.3,23.1,50.8,16.1,57.4,23.1,56.2,35.8,53.5,49.0,53.2,58.4,59.7,56.8,61.2,48.8,60.2,35.6,68.1,19.3,71.6,26.9,67.7,34.8,78.0,46.4,70.6,49.0,72.0,57.2,76.1,63.3,75.7,65.8,70.5,64.4,68.8,74.0,66.5,69.2,61.4,79.6,55.9,74.5,48.6,70.1,50.7,60.7,41.9,55.9,34.7,49.2,37.8,44.8,47.3,42.4,40.7,38.0,32.1,34.0,24.0,26.7,25.8,18.3,27.3,10.4
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Howling Fjord
#name Mining13
#displayname Mining
step
    #sticky
    .waypoint Howling Fjord,50,50
    .zone Howling Fjord >> Head to Howling Fjord
step
    #hidewindow
    +test
    .loop @20,Howling Fjord,67.6,33.6,73.3,22.7,69.1,10.4,61.1,25.2,53.5,14.9,45.9,15.4,43.4,10.7,39.3,9.6,40.8,15.5,38.0,17.1,29.3,7.7,27.3,13.8,24.0,16.8,20.2,23.3,22.9,26.3,27.1,23.3,27.7,31.1,40.1,28.4,42.3,37.4,47.0,40.1,49.9,32.4,60.7,38.2,64.3,40.3,65.9,51.6,62.0,53.8,61.4,65.8,57.3,67.3,52.4,56.6,46.3,52.1,37.3,54.5,35.4,53.1,28.1,54.6,31.2,61.6,33.4,77.7,35.5,76.7,45.8,64.8,47.8,73.1,57.9,74.7,60.4,78.9,65.8,70.6,68.7,59.0,71.7,60.8,72.8,68.6,76.7,63.2,74.7,53.9,78.0,47.1,74.5,43.6,79.8,34.1,70.9,36.2,67.6,33.6
    .openmap Howling Fjord
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Grizzly Hills
#name Herbalism14
#displayname Herbalism
step
    #sticky
    .waypoint Grizzly Hills,50,50
    .zone Grizzly Hills >> Head to Grizzly Hills
step
    #hidewindow
    +test
    .loop @20,Grizzly Hills,18.3,74.2,27.0,70.7,31.2,44.9,36.2,41.6,38.0,36.8,44.6,30.3,58.7,30.3,55.9,38.7,53.5,50.3,61.4,51.6,67.1,55.5,69.0,45.5,80.1,52.0,77.2,42.1,72.7,35.9,69.9,33.4,70.5,28.9,75.2,24.4,70.8,21.4,66.3,22.5,65.3,32.7,62.7,32.2,62.2,26.1,43.2,28.4,38.4,31.9,33.2,35.0,29.6,40.7,16.4,39.2,9.5,36.2,10.8,44.1,14.9,46.5,23.9,47.4,25.6,55.9,14.3,59.2,11.9,68.4,18.0,66.0,18.3,74.2
    .openmap Grizzly Hills
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Grizzly Hills
#name Mining14
#displayname Mining
step
    #sticky
    .waypoint Grizzly Hills,50,50
    .zone Grizzly Hills >> Head to Grizzly Hills
step
    #hidewindow
    +test
    .loop @20,Grizzly Hills,12.2,65.3,28.8,60.1,31.1,44.7,38.2,38.7,45.8,47.6,46.7,51.5,55.3,50.7,55.2,39.4,51.4,34.9,49.2,28.1,56.8,24.4,69.7,13.0,65.3,23.2,63.2,31.0,71.5,22.8,73.4,28.8,69.7,36.2,76.8,41.4,79.2,59.5,69.2,60.8,64.8,65.9,57.9,56.2,49.5,57.5,48.6,40.1,40.6,32.0,29.4,40.1,23.1,29.9,20.7,39.7,18.6,36.0,17.0,40.3,12.6,37.0,12.2,65.3
    .openmap Grizzly Hills
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Grizzly Hills
#name Mining & Herbalism14
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Grizzly Hills,50,50
    .zone Grizzly Hills >> Head to Grizzly Hills
step
    #hidewindow
    +test
    .loop @20,Grizzly Hills,12.6,64.1,18.2,65.2,18.9,74.4,25.2,72.8,31.4,45.1,38.4,37.8,45.1,49.9,52.0,50.1,55.7,52.8,56.1,49.9,54.6,46.5,54.3,38.8,49.9,37.7,46.2,31.4,55.2,24.3,52.3,18.6,58.5,20.5,68.4,8.2,70.4,13.9,65.0,18.3,65.6,23.7,57.9,30.2,66.2,30.4,70.6,22.2,72.9,28.9,67.9,38.3,68.8,46.1,74.3,44.1,76.2,40.1,79.3,50.7,79.1,60.2,68.1,62.2,66.7,54.3,61.7,50.7,62.4,61.8,58.1,57.7,47.5,56.4,44.0,59.4,41.3,31.9,29.6,39.2,23.8,39.7,24.4,33.3,22.5,28.7,17.4,40.2,10.3,35.2,12.6,46.5,19.4,46.0,24.5,50.5,25.6,55.4,21.1,58.5,13.1,52.0,12.6,64.1
    .openmap Grizzly Hills
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Zul'Drak
#name Herbalism15
#displayname Herbalism
step
    #sticky
    .waypoint Zul'Drak,50,50
    .zone Zul'Drak >> Head to Zul'Drak
step
    #hidewindow
    +test
    .loop @20,Zul'Drak,21.6,84.2,30.1,84.0,34.0,88.4,39.0,86.5,36.2,74.7,37.2,70.5,42.0,72.2,46.0,80.5,51.8,76.3,55.5,79.7,57.2,68.8,65.4,77.2,76.2,70.1,76.5,63.9,70.3,62.8,70.7,56.6,73.7,55.1,71.3,44.1,77.8,41.7,80.0,34.2,83.3,28.8,77.0,25.3,78.2,19.9,74.9,17.5,71.6,22.2,73.9,30.0,73.0,36.3,65.9,36.2,63.3,50.4,58.3,46.1,56.2,34.7,49.9,35.4,41.3,43.9,41.3,48.1,43.7,53.6,42.9,63.2,37.1,61.1,34.0,49.7,33.4,43.6,22.4,52.1,28.2,57.1,30.6,56.3,31.4,65.1,29.5,71.5,30.7,73.8,23.1,79.6,21.6,84.2
    .openmap Zul'Drak
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Zul'Drak
#name Mining15
#displayname Mining
step
    #sticky
    .waypoint Zul'Drak,50,50
    .zone Zul'Drak >> Head to Zul'Drak
step
    #hidewindow
    +test
    .loop @20,Zul'Drak,60.6,33.9,60.1,37.9,50.6,38.5,43.4,44.3,37.5,44.3,33.9,45.8,31.3,42.3,22.4,50.1,23.2,53.7,21.3,56.9,15.5,59.3,11.9,72.9,21.3,74.0,23.9,70.8,23.1,64.2,27.7,68.2,30.8,60.7,31.5,54.0,36.3,52.9,36.5,61.8,37.2,70.9,31.2,78.8,31.8,83.8,38.4,83.3,40.8,81.6,44.3,82.6,46.5,78.7,44.7,75.9,49.7,71.8,52.5,67.2,53.8,72.8,60.1,81.9,61.8,79.5,60.2,72.4,61.5,61.5,56.0,49.8,53.0,49.2,56.6,43.9,70.9,49.8,74.7,47.8,73.4,36.0,69.9,27.1,60.6,33.9
    .openmap Zul'Drak
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Zul'Drak
#name Mining & Herbalism15
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Zul'Drak,50,50
    .zone Zul'Drak >> Head to Zul'Drak
step
    #hidewindow
    +test
    .loop @20,Zul'Drak,61.4,35.1,55.2,38.8,53.3,34.0,52.0,39.8,57.4,49.6,54.0,53.8,53.7,49.2,47.6,40.8,45.2,36.6,42.8,43.3,38.8,43.0,42.4,49.2,34.1,46.8,33.2,41.6,30.6,43.9,30.0,55.7,25.0,48.0,22.4,49.5,22.6,55.1,15.1,59.1,13.2,70.0,11.6,73.4,11.0,80.7,16.4,77.9,20.0,77.5,22.8,69.2,23.5,64.4,28.5,65.3,29.9,70.8,31.6,61.3,36.2,55.7,39.2,60.0,36.3,63.4,36.1,71.5,40.3,71.3,37.3,75.4,32.8,70.8,30.7,75.4,26.2,77.2,20.5,85.7,31.3,83.5,32.0,87.5,39.6,85.7,37.2,81.9,39.8,79.6,43.4,83.8,46.3,81.3,45.1,76.2,49.8,78.1,51.6,74.3,48.5,72.4,53.1,67.6,56.3,78.2,53.5,82.4,61.1,81.4,59.2,76.8,61.9,73.3,57.0,65.0,60.9,58.4,59.1,55.0,71.5,49.5,74.6,48.8,72.5,35.7,83.4,29.4,79.2,26.7,76.4,18.0,69.3,25.4,70.7,31.9,61.4,35.1
    .openmap Zul'Drak
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup The Storm Peaks
#name Herbalism16
#displayname Herbalism
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to The Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,56.1,65.5,59.2,59.3,63.5,62.6,72.5,63.3,71.1,55.4,71.9,48.3,67.0,45.9,65.4,41.6,61.1,44.2,58.8,48.7,55.7,50.2,50.5,53.3,49.8,59.8,46.9,62.5,38.0,62.9,38.0,53.9,44.0,52.8,43.1,43.6,37.6,44.5,34.9,40.1,32.3,49.3,28.4,50.3,26.7,56.7,22.6,57.0,25.0,63.1,27.8,61.8,26.7,72.5,31.5,65.8,36.9,66.3,37.4,77.0,30.6,83.4,32.7,89.9,39.0,88.5,39.6,80.7,50.0,74.3,56.1,65.5
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup The Storm Peaks
#name Mining16
#displayname Mining
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to The Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,48.6,68.3,53.7,65.8,56.0,67.5,55.9,64.1,58.6,58.6,63.4,59.4,63.9,63.1,68.8,62.8,76.3,64.7,77.0,62.7,72.3,59.7,71.9,47.7,70.1,50.6,67.5,47.7,63.9,49.4,62.3,45.9,63.7,43.6,67.0,45.0,68.2,43.1,68.1,39.9,62.2,41.7,58.3,39.7,57.6,42.0,58.7,46.1,55.1,49.5,46.8,55.2,47.3,62.9,41.5,61.5,37.7,62.1,38.3,53.7,47.2,36.8,38.5,44.1,35.3,40.9,34.3,50.0,30.3,45.1,30.7,42.1,29.5,38.5,26.0,43.2,27.3,57.7,22.3,56.8,23.2,62.2,28.1,63.3,26.9,67.0,30.0,65.9,35.9,66.4,36.9,80.8,32.0,83.1,31.9,86.7,35.7,88.2,42.9,86.1,46.6,79.6,39.6,78.2,41.7,69.6,48.6,68.3
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup The Storm Peaks
#name Mining & Herbalism16
#displayname Mining & Herbalism
step
    #sticky
    .waypoint The Storm Peaks,50,50
    .zone The Storm Peaks >> Head to The Storm Peaks
step
    #hidewindow
    +test
    .loop @20,The Storm Peaks,48.6,68.3,53.7,65.8,56.0,67.5,55.9,64.1,58.6,58.6,63.4,59.4,63.9,63.1,68.8,62.8,76.3,64.7,77.0,62.7,72.3,59.7,71.9,47.7,70.1,50.6,67.5,47.7,63.9,49.4,62.3,45.9,63.7,43.6,67.0,45.0,68.2,43.1,68.1,39.9,62.2,41.7,58.3,39.7,57.6,42.0,58.7,46.1,55.1,49.5,51.6,49.3,46.8,55.2,48.8,61.8,,47.3,62.9,41.5,61.5,37.7,62.1,38.3,53.7,47.2,36.8,38.5,44.1,35.3,40.9,34.3,50.0,30.3,45.1,30.7,42.1,29.5,38.5,26.0,43.2,27.3,57.7,22.3,56.8,23.2,62.2,28.1,63.3,26.9,67.0,25.6,71.3,26.7,73.0,30.0,70.3,30.0,65.9,35.9,66.4,36.9,80.8,32.0,83.1,31.9,86.7,35.7,88.2,42.9,86.1,46.6,79.6,39.6,78.2,41.7,69.6,48.6,68.3
    .openmap The Storm Peaks
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Wintergrasp
#name Mining17
#displayname Mining
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,17.6,39.4,34.3,14.7,39.1,11.7,40.4,16.9,40.0,24.2,45.1,31.7,47.7,31.6,47.6,41.1,50.2,47.9,50.8,38.7,55.2,31.6,58.1,23.2,61.9,18.4,70.9,22.5,73.9,28.8,74.2,43.0,83.1,44.0,81.2,51.6,73.0,48.9,65.0,53.3,78.4,59.0,78.7,65.8,85.6,69.4,76.7,86.6,76.5,72.8,65.0,69.8,57.7,83.4,52.9,81.6,60.3,53.9,39.9,58.6,41.1,51.1,37.3,46.6,30.3,39.4,32.4,54.7,26.7,61.5,21.6,57.3,20.7,69.2,11.6,65.1,7.5,65.5,9.5,49.3,22.7,47.6,15.7,43.7,17.6,39.4
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Wintergrasp
#name Herbalism17
#displayname Herbalism
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,14.0,57.9,9.4,54.4,15.8,53.0,19.0,49.2,20.1,44.1,29.2,41.8,24.3,33.4,27.1,26.6,32.1,28.7,34.3,18.2,38.7,28.0,47.3,36.0,40.3,42.9,40.8,51.3,44.7,49.9,48.4,43.4,53.5,48.8,55.2,40.3,55.4,31.7,61.8,33.5,59.0,47.8,64.3,49.3,67.2,47.4,66.7,37.0,62.6,20.0,69.4,28.4,75.1,38.0,74.1,42.7,79.2,42.0,79.9,47.4,72.5,50.5,73.7,68.6,59.6,79.0,60.0,69.3,60.8,61.6,55.8,56.8,51.9,75.5,46.9,76.3,39.1,58.3,35.8,58.2,37.6,73.4,25.8,70.4,20.3,58.8,14.0,57.9
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Wintergrasp
#name Mining & Herbalism17
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,7.0,66.8,9.4,51.4,14.4,58.2,14.4,45.6,18.0,39.6,21.2,43.2,19.0,49.0,21.3,53.8,24.4,45.6,31.6,46.2,29.9,38.2,23.1,32.9,26.7,23.9,32.6,27.8,30.6,19.2,40.2,19.1,38.8,22.3,42.0,29.8,47.3,34.8,40.0,39.4,41.9,51.8,45.3,48.6,44.9,43.7,52.3,48.1,55.4,43.5,51.0,40.9,55.2,33.5,59.8,27.1,62.4,18.8,70.8,22.4,62.3,37.6,59.4,48.2,66.9,45.6,70.5,32.5,74.0,37.9,75.1,44.0,82.7,43.2,80.8,49.8,75.0,48.8,64.8,53.1,77.5,58.8,80.6,67.6,86.0,69.8,76.3,86.7,77.5,72.5,74.4,65.3,66.6,64.5,61.4,79.2,57.2,79.8,60.1,67.8,61.2,56.3,56.1,55.5,53.8,73.2,46.3,74.3,46.6,64.9,49.2,57.6,35.4,56.8,37.1,72.3,26.1,68.6,32.7,63.6,30.7,56.8,24.9,61.1,20.7,60.6,17.2,66.8,7.0,66.8
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Wintergrasp
#name Eternal Life_63a
#displayname Eternal Life
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,5.8,66.3,4.5,58.6,8.2,56.3,13.8,60.3,15.2,63.7,13.7,66.7,5.8,66.3
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Wintergrasp
#name Eternal Fire_64a
#displayname Eternal Fire
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,80.7,74.6,84.8,76.5,88.4,71.1,87.5,63.7,83.1,63.3,80.1,69.0,80.7,74.6
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Wintergrasp
#name Eternal Earth_65a
#displayname Eternal Earth
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,62.8,57.0,63.0,69.8,59.7,71.2,54.1,56.3,58.3,53.7,62.0,54.6,62.8,57.0
    .loop @20,Wintergrasp,62.6,46.8,63.0,51.0,58.6,50.4,54.4,43.3,58.1,29.3,65.1,30.2,65.5,33.2,60.5,34.9,60.8,43.5,62.6,46.8
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Wintergrasp
#name Eternal Air_66a
#displayname Eternal Air
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,77.4,86.0,77.3,75.8,70.3,72.5,62.8,80.7,64.7,89.3,62.8,80.7,57.2,79.3,54.3,82.0,49.3,83.0,42.4,82.4,34.8,72.2,30.1,71.7,26.9,72.3
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Northrend Farming
#loop
#hidewindow
#subgroup Wintergrasp
#name Eternal Water_67a
#displayname Eternal Water
step
    #sticky
    .waypoint Wintergrasp,50,50
    .zone Wintergrasp >> Head to Wintergrasp
step
    #hidewindow
    +test
    .loop @20,Wintergrasp,33.3,20.9,33.8,25.6,35.9,27.9,31.1,28.5,29.2,23.5,25.8,27.2,28.2,35.3,22.8,38.8,27.2,45.3,27.2,49.2,37.7,53.6,46.2,57.9,52.1,54.1,57.1,51.3,62.4,52.8,64.5,56.0,70.9,47.8,70.1,37.7,75.8,40.6,78.5,46.1
    .openmap Wintergrasp
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Icecrown
#name Mining18
#displayname Mining
step
    #sticky
    .waypoint Icecrown,50,50
    .zone Icecrown >> Head to Icecrown
step
    #hidewindow
    +test
    .loop @20, Icecrown,65.6,35.1,59.3,29.4,54.9,38.6,47.8,35.1,42.8,37.8,39.3,33.4,37.9,36.2,37.2,41.7,41.6,41.1,38.0,50.8,37.9,57.1,40.2,59.8,31.5,58.1,30.8,64.5,36.2,68.9,39.9,65.6,49.6,61.4,48.5,51.2,56.5,44.7,65.6,59.8,67.1,72.2,72.0,63.8,74.2,65.0,77.8,64.3,79.3,57.0,75.8,46.4,67.6,46.5,67.3,42.9,74.1,40.1,74.7,35.3,65.6,35.1
    .openmap Icecrown
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Icecrown
#name Herbalism18
#displayname Herbalism
step
    #sticky
    .waypoint Icecrown,50,50
    .zone Icecrown >> Head to Icecrown
step
    #hidewindow
    +test
    .loop @20, Icecrown,64.6,56.4,62.0,46.7,57.0,44.7,53.8,41.1,49.1,47.6,47.8,56.4,53.0,72.7,49.1,74.8,44.7,60.9,41.1,59.7,39.3,53.0,42.8,50.3,42.6,40.3,35.5,44.1,28.1,45.5,28.4,40.3,29.6,31.9,31.2,27.0,35.6,29.1,45.3,35.1,47.5,38.1,58.6,36.7,65.3,40.7,70.5,40.6,73.8,30.1,76.1,35.1,74.7,46.4,67.9,52.2,71.0,62.3,70.6,67.7,67.4,68.7,67.6,59.7,64.6,56.4
    .openmap Icecrown
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Icecrown
#name Mining & Herbalism18
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Icecrown,50,50
    .zone Icecrown >> Head to Icecrown
step
    #hidewindow
    +test
    .loop @20, Icecrown,65.5,39.2,73.9,23.8,76.6,38.6,68.8,42.8,71.2,47.7,74.6,47.9,69.6,55.9,70.9,62.3,77.0,58.5,79.9,63.6,71.6,67.3,67.8,69.2,66.5,57.8,60.1,46.4,56.1,42.7,47.1,51.8,48.1,65.3,52.2,74.7,49.1,74.8,45.4,65.8,44.2,59.8,38.5,59.0,36.2,70.2,31.2,62.7,32.7,55.4,37.8,55.1,41.3,46.0,42.3,39.3,40.4,32.9,38.2,36.6,38.8,41.3,35.0,45.7,28.6,45.7,28.6,37.9,31.0,27.6,33.9,26.5,45.4,34.7,49.0,38.1,56.4,37.2,59.5,30.0,63.7,33.3,63.6,38.4,65.5,39.2
    .openmap Icecrown
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Profession Leveling
<< Horde
#name 1-450 Herbalism (H)
#displayname 1-450 Herbalism

step << Mage
    #completewith next
    .zone Undercity >> Teleport to Undercity
    .skill herbalism,70,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Dalaran
    .zoneskip Undercity
    .skill herbalism,70,1
step << !Mage
    #completewith next
    .goto Dalaran,55.9,24.1
    .zone Undercity >> In Dalaran, take the portal to Undercity
    .skill herbalism,70,1
step
    .goto Undercity,54.0,49.5
    .train 2366 >> Train Apprentice Herbalism (1-75) from Martha in Undercity
    .skill herbalism,70,1
step
    #completewith next
    .goto Undercity,53.8,54.5,-1
    .goto Undercity,67.8,14.4,-1
    .goto Undercity,67.8,14.4,70 >>Jump onto the light near the stairs and then log out, and back in. This will save you a LOT of time
    .link https://www.youtube.com/watch?v=ES8vZZ0XH2k >> CLICK HERE for a guide
    >>If you can't do this, just run out of Undercity normally
    .skill herbalism,70,1
    .zoneskip Tirisfal Glades
step
    .goto Tirisfal Glades,61.9,64.9
    .zone Tirisfal Glades >> Exit Undercity into Tirisfal Glades
    .skill herbalism,70,1
step
    .openmap Tirisfal Glades
    .skill herbalism,70 >> Level your Herbalism from 1-70 in Tirisfal Glades. Press "M" to open your map to see the route.
    .loop 60,Tirisfal Glades,53.7,59.8,51.5,62.2,49.1,66.4,43.4,67.3,42.5,64.3,42.1,60.1,41.3,53.8,39.4,50.5,30.6,49.7,30.5,46.6,37.4,45.9,39.1,39.1,44.7,40.5,43.7,31.9,48.7,29.8,52.2,28.6,47.8,43.1,45.7,46.1,46.8,52.0,50.1,55.2,52.8,48.5,56.0,48.5,58.5,47.6,60.2,44.8,57.4,39.0,57.0,33.1,58.3,30.6,61.6,32.7,63.7,35.4,66.6,35.6,63.5,44.0,63.7,48.5,65.5,51.4,58.5,58.2,56.8,59.6,53.7,59.8
step << Mage
    #completewith next
    .zone Undercity >> Teleport to Undercity
    .skill herbalism,115,1
step << !Mage
    .goto Undercity,66.2,1.5,20,0
    .goto Undercity,65.9,44.1,50,0
    .goto Undercity,54.0,49.5,50 >> Ride back to Martha in Undercity
    .skill herbalism,115,1
    .cooldown item,6948,<0,1
step << !Mage
    .hs >> Hearth to Dalaran
    .zoneskip Undercity
    .skill herbalism,115,1
step << !Mage
    #completewith next
    .goto Dalaran,55.9,24.1
    .zone Undercity >> In Dalaran, take the portal to Undercity
    .skill herbalism,115,1
step
    .goto Undercity,54.0,49.5
    .train 2368 >> Train Journeyman Herbalism (75-150) from Martha in Undercity
    .skill herbalism,115,1
step
    #completewith next
    .goto Undercity,65.9,44.1,50,0
    .goto Undercity,63.3,48.6
    .fly Sepulcher >> Fly to The Sepulcher
    .skill herbalism,115,1
    .zoneskip Silverpine Forest
step
    .skill herbalism,115 >> Level your Herbalism from 70-115 in Silverpine Forest
    .loop 60,Silverpine Forest,51.9,42.9,48.9,33.3,45.1,30.3,47.6,24.9,52.0,20.9,55.1,15.7,58.4,12.1,64.3,9.1,65.3,11.3,60.5,14.1,56.2,18.7,55.8,22.5,56.2,29.3,55.4,31.9,52.5,31.2,54.6,35.9,54.4,43.1,52.2,49.8,54.7,58.5,55.8,64.5,61.5,64.3,64.2,76.9,60.1,78.3,55.1,76.3,51.7,77.6,49.5,80.1,46.1,80.8,50.1,74.3,51.4,68.1,51.7,56.4,48.0,52.6,45.5,53.6,44.1,50.4,45.1,47.5,49.0,46.8,51.9,42.9
step
    #completewith next
    .goto Silverpine Forest,45.6,42.6,-1
    .goto Hillsbrad Foothills,21.0,46.2,-1
    >>Travel to Hillsbrad Foothills. If you're close to the border, then ride there - otherwise ride back to The Sepulcher and fly to Tarren Mill
    .fly Tarren Mill >> Fly to Tarren Mill
    .zoneskip Hillsbrad Foothills
    .skill herbalism,150,1
step
    .skill herbalism,150 >> Level your Herbalism from 115-150 in Hillsbrad Foothills
    .loop 60,Hillsbrad Foothills,56.2,28.0,55.7,17.7,58.6,15.0,63.6,13.0,66.8,8.2,70.4,15.9,71.8,23.2,75.9,30.5,84.4,33.4,87.3,37.3,86.3,39.8,76.7,32.9,70.7,38.6,64.9,45.7,64.3,52.4,70.2,53.2,75.4,55.4,70.6,63.1,67.1,69.0,68.9,83.8,64.6,73.0,60.9,67.0,56.2,52.8,51.5,46.2,46.3,47.6,45.6,51.5,43.3,61.3,40.1,64.3,35.6,63.5,37.4,56.0,33.2,55.4,25.4,53.2,21.7,54.1,16.9,54.1,14.7,51.6,18.1,44.2,22.4,42.4,25.7,42.7,26.2,33.9,31.6,29.8,38.7,32.7,42.0,38.2,47.5,35.1,48.2,31.2,53.1,31.6,56.2,28.0
step
    .goto Hillsbrad Foothills,60.1,18.6
    .train 3570 >> Train Expert Herbalism (150-225) from Aranae in Tarren Mill
    .skill herbalism,225,1
step << Mage
    #completewith next
    .zone Swamp of Sorrows >> Teleport to Stonard
    .skill herbalism,225,1
step << !Mage
    #completewith next
    .goto Hillsbrad Foothills,60.1,18.6
    .fly Stonard >> Fly to Stonard
    .skill herbalism,225,1
step
    >>Focus on Liferoot and Kingsblood to start with, and Fadeleaf when you reach 160 skill
    .skill herbalism,170 >> Level your Herbalism from 150-170 in Swamp of Sorrows
    .loop 60,Swamp of Sorrows,37.2,46.5,30.0,51.3,26.8,58.7,23.4,58.8,19.4,55.1,17.0,59.8,13.2,62.7,13.6,52.7,18.3,45.4,12.2,32.9,21.9,44.7,28.7,38.8,34.0,35.0,45.2,34.0,61.3,33.1,74.1,24.2,76.7,15.2,82.4,25.6,78.3,36.0,87.5,43.8,83.4,47.6,86.9,58.8,81.6,62.5,78.4,67.0,83.3,71.7,76.0,77.5,68.9,69.8,58.9,59.0,56.8,49.0,46.8,39.5,37.2,46.5
step
    >>Now focus on Goldthorn and when you get to 185 skill, Khadgar's Whisker
    .skill herbalism,225 >> Level your Herbalism from 170-225 in Swamp of Sorrows
    .loop 60,Swamp of Sorrows,54.5,42.1,44.8,41.9,30.8,51.2,26.7,61.6,23.2,59.5,20.9,53.4,17.1,55.1,15.1,64.0,11.8,63.7,14.8,46.3,18.0,46.1,17.0,42.3,10.9,37.1,10.7,32.1,14.9,33.2,19.4,43.7,21.6,40.7,26.3,44.3,30.2,34.8,34.1,40.7,38.3,38.5,37.4,32.4,45.7,31.3,52.8,30.6,63.4,20.9,70.3,13.1,81.2,22.0,86.4,42.3,86.2,62.1,82.8,72.2,75.4,86.1,69.1,77.5,64.5,68.6,73.3,72.4,81.3,59.1,79.3,43.9,70.1,35.0,61.2,41.1,56.1,59.1,54.5,42.1
step << Mage
    #completewith next
    .zone Orgrimmar >> Teleport to Orgrimmar
    .skill herbalism,300,1
step << !Mage
    .goto Blasted Lands,52.0,7.7,60,0
    .goto Blasted Lands,58.8,60.2,50,0
    .goto Hellfire Peninsula,88.9,50.2
    .zone Hellfire Peninsula >>Go into Blasted Lands. Go through the Dark Portal
    .skill herbalism,300,1
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Hellfire Peninsula
    .skill herbalism,300,1
step << !Mage
    #completewith next
    .goto Dalaran,55.5,25.5
    .zone Orgrimmar >> In Dalaran, take the portal to Orgrimmar
    .skill herbalism,300,1
step
    #completewith next
    .goto Orgrimmar,43.1,41.4,70,0
    .goto Orgrimmar,45.9,43.6,40,0
    .goto Orgrimmar,49.4,39.6,40,0
    .goto Orgrimmar,54.5,41.0,40 >> Go in the back entrance of the upper part of The Drag
    .skill herbalism,300,1
step
    .goto Orgrimmar,55.6,39.5
    .train 11993 >> Train Artisan Herbalism (225-300) from Jandi in the building in Orgrimmar
    .skill herbalism,300,1
step << Mage
    #completewith next
    .zone Swamp of Sorrows >> Teleport to Stonard
    .skill herbalism,300,1
step << !Mage
    .goto Durotar,45.5,12.2
    .zone Durotar >> Exit Orgrimmar into Durotar. Alternatively, pay a mage for a portal to Stonard
    .skill herbalism,300,1
    .zoneskip Swamp of Sorrows
step << !Mage
    .goto Durotar,50.7,13.3,20,0
    .goto Durotar,50.6,12.6
    .zone Stranglethorn Vale >> Climb the Zeppelin Tower. Take the Zeppelin to Stranglethorn Vale (Grom'Gol)
    .skill herbalism,300,1
    .zoneskip Swamp of Sorrows
step << !Mage
    #completewith next
    .goto Stranglethorn Vale,32.5,29.4
    .fly Stonard >> Fly to Stonard
    .skill herbalism,300,1
    .zoneskip Swamp of Sorrows
step
    .skill herbalism,300 >> Level your Herbalism from 225-300 in Swamp of Sorrows
    .loop 60,Swamp of Sorrows,54.5,42.1,44.8,41.9,30.8,51.2,26.7,61.6,23.2,59.5,20.9,53.4,17.1,55.1,15.1,64.0,11.8,63.7,14.8,46.3,18.0,46.1,17.0,42.3,10.9,37.1,10.7,32.1,14.9,33.2,19.4,43.7,21.6,40.7,26.3,44.3,30.2,34.8,34.1,40.7,38.3,38.5,37.4,32.4,45.7,31.3,52.8,30.6,60.0,33.2,63.4,20.9,70.3,13.1,81.2,22.0,79.1,31.5,,84.2,35.4,,86.4,42.3,86.2,62.1,82.8,72.2,78.5,77.4,71.1,68.9,76.9,67.2,81.3,59.1,79.3,43.9,70.1,35.0,61.2,41.1,56.1,59.1,54.5,42.1
step << !Mage
    .goto Blasted Lands,52.0,7.7,60,0
    .goto Blasted Lands,58.8,60.2,50,0
    .goto Hellfire Peninsula,88.9,50.2
    .zone Hellfire Peninsula >> Go into Blasted Lands. Go through the Dark Portal
    .skill herbalism,325,1
    .cooldown item,6948,<0,1
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill herbalism,325,1
    .zoneskip Hellfire Peninsula
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Shattrath City
    .skill herbalism,325,1
step << !Mage
    #completewith next
    .goto Dalaran,56.4,22.8
    .zone Shattrath City >> In Dalaran, take the portal to Shattrath
    .skill herbalism,325,1
step
    #completewith Ruak
    .goto Shattrath City,64.1,41.1
    .fly Thrallmar >> Fly to Thrallmar
    .skill herbalism,325,1
    .skill riding,300,1
    .zoneskip Hellfire Peninsula
step
    #completewith next
    .goto Hellfire Peninsula,52.2,36.2
    .zone Hellfire Peninsula >> Fly to Thrallmar in Hellfire Peninsula on your flying mount
    .skill herbalism,325,1
    .skill riding,<300,1
step
    #label Ruak
    .goto Hellfire Peninsula,52.7,36.6,15,0
    .goto Hellfire Peninsula,52.2,36.2
    .train 28695 >> Learn Master Herbalism (300-375) from Ruak Stronghorn in the building in Thrallmar
    .skill herbalism,325,1
step
    .skill herbalism,325 >> Level your Herbalism from 300-325 in Hellfire Peninsula
    .loop 60,Hellfire Peninsula,27.9,80.6,31.1,61.8,43.5,63.9,43.0,72.9,38.1,87.2,45.7,85.5,49.8,69.2,62.0,68.9,67.4,77.9,65.4,58.4,72.3,62.3,80.3,79.6,73.8,59.2,66.8,55.5,67.1,52.2,71.9,51.9,73.9,40.2,66.8,43.7,65.7,28.1,59.0,35.9,55.6,28.9,51.0,23.9,49.2,36.5,45.1,41.9,49.0,47.1,59.8,47.1,61.0,53.7,52.5,54.6,48.6,58.9,42.9,56.0,37.7,42.6,41.0,30.8,35.5,29.3,27.5,36.8,31.4,48.6,24.1,44.4,20.5,40.1,18.2,46.1,14.6,36.8,12.1,55.2,13.8,61.8,17.2,53.6,22.7,54.9,22.9,65.9,27.9,80.6
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill herbalism,350,1
    .zoneskip Terokkar Forest
step << !Mage
    .goto Terokkar Forest,60.5,24.2
    .zone Terokkar Forest >> Fly to Terokkar Forest
    .skill herbalism,350,1
    .zoneskip Terokkar Forest
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Shattrath City
    .skill herbalism,350,1
step << !Mage
    #completewith next
    .goto Dalaran,56.4,22.8
    .zone Shattrath City >> In Dalaran, take the portal to Shattrath
    .skill herbalism,350,1
step
    #completewith next
    .goto Terokkar Forest,39.6,24.8
    .zone Terokkar Forest >> Fly to Terokkar Forest
    .skill herbalism,350,1
step
    #label Terokkar
    .skill herbalism,350 >> Level your Herbalism from 325-350 in Terokkar Forest
    .loop 60,Terokkar Forest,20.8,16.4,22.8,7.8,25.5,10.2,35.8,8.6,44.0,18.1,44.9,13.9,50.8,17.5,50.1,25.7,37.8,35.7,40.6,40.5,45.6,33.4,50.5,35.6,55.3,27.7,61.2,24.4,54.9,38.2,60.2,42.9,65.2,30.5,72.9,30.6,67.1,43.7,60.9,45.2,69.0,50.4,64.9,56.0,60.2,49.7,54.9,58.6,56.5,65.5,65.6,69.5,73.5,82.7,73.4,87.4,68.7,86.6,60.5,70.9,56.0,71.6,49.6,82.2,30.8,79.3,29.4,66.2,24.7,65.1,25.6,77.3,18.3,78.0,17.9,66.0,27.5,50.2,32.3,36.4,20.8,16.4
step << !Mage
    #completewith next
    .goto Shattrath City,52.3,52.5,40,0
    .zone Orgrimmar >> Take portal to Orgrimmar
    .skill herbalism,375,1
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .goto Orgrimmar,52.6,85.4,40,0
    .goto Durotar,41.4,18.0,40,0
    .skill herbalism,375,1
    .cooldown item,6948,<0,1
    .zone Borean Tundra >> Climb the Zeppelin Tower. Take the Zeppelin to Borean Tundra
step << Mage
    #completewith next
    .zone Dalaran >> Teleport to Dalaran
    .skill herbalism,375,1
    .zoneskip Borean Tundra
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Shattrath City
    .skill herbalism,375,1
step << !Mage
    #completewith next
    .goto Borean Tundra,42.6,53.2
    .zone Borean Tundra >> Fly to Borean Tundra on your flying mount
    .skill herbalism,375,1
    .skill riding,<300,1
step << !mage
    #completewith next
    .goto Dalaran,71.8,45.6
    .fly Warsong Hold >> Fly to Borean Tundra (Warsong Hold)
    .skill herbalism,375,1
    .skill riding,300,1
    .zoneskip Borean Tundra
step
    #label Tansy
    .goto Borean Tundra,42.0,53.6
    .train 50300 >> Learn Grand Master Herbalism (350-450) from Tansy Wildmane in Warsong Hold
    .skill herbalism,375,1
step
    #label BoreanTundra
    .skill herbalism,375 >> Level your Herbalism from 350-400 in Borean Tundra
    .loop 20,Borean Tundra,77.0,30.1,77.5,35.8,75.5,41.7,69.0,41.8,64.5,39.8,60.7,42.5,61.6,58.4,57.4,48.8,49.8,69.5,49.2,74.9,46.2,72.2,32.8,63.5,32.5,54.3,44.0,43.9,52.7,49.0,52.7,41.0,58.0,40.4,60.1,32.5,54.9,27.9,48.4,23.2,50.0,20.0,58.1,18.7,61.8,14.3,66.0,16.1,73.4,25.9,70.1,31.0,72.6,34.2,77.0,30.1
step
    #completewith next
    .goto Sholazar Basin,50,50
    .zone Sholazar Basin >> Fly to Sholazar Basin
    .skill herbalism,425,1
step
    .skill herbalism,425 >> Level your Herbalism from 375-425 in Sholazar Basin
    .loop 20,Sholazar Basin,70.1,68.4,67.1,70.9,65.7,75.3,58.3,77.7,60.9,84.4,54.4,85.7,48.6,83.5,48.1,71.7,47.8,65.8,49.6,52.4,46.4,51.7,45.1,56.3,42.1,58.0,40.9,64.3,42.2,83.2,33.5,83.1,27.2,80.1,26.6,72.8,34.2,66.3,33.8,59.8,22.2,59.2,23.1,48.1,28.6,52.7,30.1,44.5,35.4,45.0,33.4,35.1,41.4,22.8,58.3,27.8,62.1,35.0,56.1,35.7,57.3,42.3,59.2,47.0,56.7,55.9,54.2,61.5,61.7,67.2,70.1,68.4
step
    #completewith next
    .goto The Storm Peaks,50.0,50.0
    .zone The Storm Peaks >> Fly to The Storm Peaks on your flying mount
    .skill herbalism,450,1
    .skill riding,<300,1
step << Mage
    #completewith next
    .zone Dalaran >> Teleport to Dalaran
    .skill herbalism,450,1
    .skill riding,300.1
    .zoneskip Dalaran
    .zoneskip The Storm Peaks
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill riding,300,1
    .skill herbalism 450,1
    .zoneskip The Storm Peaks
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .goto Sholazar Basin,50.2,61.5
    .fly K3 >> Fly to Storm Peaks (K3)
    .skill riding,300,1
    .skill herbalism 450,1
    .zoneskip The Storm Peaks
step
    #label TheStormPeaks
    .skill herbalism,450 >> Level your Herbalism from 425-450 in The Storm Peaks
    .loop 20,The Storm Peaks,56.1,65.5,59.2,59.3,63.5,62.6,72.5,63.3,71.1,55.4,71.9,48.3,67.0,45.9,65.4,41.6,61.1,44.2,58.8,48.7,55.7,50.2,50.5,53.3,49.8,59.8,46.9,62.5,38.0,62.9,38.0,53.9,44.0,52.8,43.1,43.6,37.6,44.5,34.9,40.1,32.3,49.3,28.4,50.3,26.7,56.7,22.6,57.0,25.0,63.1,27.8,61.8,26.7,72.5,31.5,65.8,36.9,66.3,37.4,77.0,30.6,83.4,32.7,89.9,39.0,88.5,39.6,80.7,50.0,74.3,56.1,65.5
step
    +Congratulations on reaching skill level 450 in Herbalism!
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Profession Leveling
<< Alliance
#name 1-450 Herbalism (A)
#displayname 1-450 Herbalism


step << Mage
    #completewith next
    .zone Stormwind City >> Teleport to Stormwind
    .skill herbalism,70,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Dalaran
    .skill herbalism,70,1
step << !Mage
    #completewith next
    .goto Dalaran,39.8,62.5
    .zone Stormwind City >> In Dalaran, take the portal to Stormwind City
    .skill herbalism,70,1
step
    .goto Stormwind City,54.3,84.1
    .train 2366 >> Train Apprentice Herbalism (1-75) from Tannysa in Stormwind
    .skill herbalism,70,1
step
    #completewith next
    .goto Elwynn Forest,32.3,49.9
    .zone Elwynn Forest >> Exit Stormwind into Elwynn Forest
    .skill herbalism,70,1
step
    .openmap Elwynn Forest
    .skill herbalism,70 >> Level your Herbalism from 1-70 in Elwynn Forest. Press "M" to open your map to see the route.
    .loop 60,Elwynn Forest,32.4,56.2,36.5,58.7,40.5,54.7,47.7,59.3,60.9,59.2,65.8,64.8,68.9,62.3,68.9,52.0,65.8,45.5,72.2,40.0,79.6,39.4,81.6,49.7,80.7,56.4,86.9,61.5,85.9,73.2,87.3,79.2,85.2,82.6,79.9,80.9,76.0,82.8,62.7,77.7,57.4,78.2,49.4,84.3,42.2,89.1,40.4,87.5,42.0,80.8,39.3,74.8,36.0,81.9,34.8,85.6,26.4,90.9,26.5,81.2,23.0,75.9,26.0,74.7,29.4,68.2,29.1,62.0,30.5,58.5,32.4,56.2
step << Mage
    #completewith next
    .zone Stormwind City >> Teleport to Stormwind
    .skill herbalism,150,1
step << !Mage
    .goto Stormwind City,73.0,89.9
    .zone Stormwind City >> Ride back to Stormwind City
    .skill herbalism,150,1
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Stormwind City
    .skill herbalism,150,1
step << !Mage
    #completewith next
    .goto Dalaran,39.8,62.5
    .zone Stormwind City >> In Dalaran, take the portal to Stormwind City
    .skill herbalism,150,1
step
    .goto Stormwind City,54.3,84.1
    .train 2368 >> Train Journeyman Herbalism (75-150) from Tannysa in Stormwind
    .skill herbalism,151,1
step
    #completewith next
    .goto Stormwind City,68.2,72.9,20,0
    .goto Stormwind City,71.0,72.5
    .fly Lakeshire >> Fly to Lakeshire
    .zoneskip Redridge Mountains
    .skill herbalism,150,1
step
    .skill herbalism,150 >> Level your Herbalism from 70-150 in Redridge Mountains
    .loop 60,Redridge Mountains,24.8,72.7,30.8,80.7,36.2,73.4,40.0,76.0,55.8,75.4,60.4,72.4,64.7,78.2,69.1,77.6,73.9,82.4,77.1,73.4,77.1,66.7,81.4,69.8,82.8,66.0,87.0,62.0,80.4,39.9,76.6,39.3,76.8,50.5,71.2,50.2,64.2,44.8,54.8,44.1,49.5,41.1,43.2,34.2,30.5,22.5,24.8,24.1,23.8,29.1,20.7,40.7,15.4,52.2,22.3,60.8,11.8,76.0,24.8,72.7
step
    .goto Redridge Mountains,21.7,45.8
    .train 3570 >> Train Expert Herbalism (150-225) from Alma in Lakeshire
    .skill herbalism,226,1
step
    #completewith next
    .goto Redridge Mountains,30.6,59.4
    .fly Nethergarde >> Fly to Nethergarde Keep
    .skill herbalism,225,1
    .zoneskip Swamp of Sorrows
step
    #completewith next
    .goto Blasted Lands,52.1,8.5,40,0
    .goto Swamp of Sorrows,33.9,65.9
    .zone Swamp of Sorrows >> Ride to Swamp of Sorrows
    .skill herbalism,225,1
step
    >>Focus on Liferoot and Kingsblood to start with, and Fadeleaf when you reach 160 skill
    .skill herbalism,170 >> Level your Herbalism from 150-170 in Swamp of Sorrows
    .loop 60,Swamp of Sorrows,37.2,46.5,30.0,51.3,26.8,58.7,23.4,58.8,19.4,55.1,17.0,59.8,13.2,62.7,13.6,52.7,18.3,45.4,12.2,32.9,21.9,44.7,28.7,38.8,34.0,35.0,45.2,34.0,61.3,33.1,74.1,24.2,76.7,15.2,82.4,25.6,78.3,36.0,87.5,43.8,83.4,47.6,86.9,58.8,81.6,62.5,78.4,67.0,83.3,71.7,76.0,77.5,68.9,69.8,58.9,59.0,56.8,49.0,46.8,39.5,37.2,46.5
step
    >>Now focus on Goldthorn and when you get to 185 skill, Khadgar's Whisker
    .skill herbalism,225 >> Level your Herbalism from 170-225 in Swamp of Sorrows
    .loop 60,Swamp of Sorrows,54.5,42.1,44.8,41.9,30.8,51.2,26.7,61.6,23.2,59.5,20.9,53.4,17.1,55.1,15.1,64.0,11.8,63.7,14.8,46.3,18.0,46.1,17.0,42.3,10.9,37.1,10.7,32.1,14.9,33.2,19.4,43.7,21.6,40.7,26.3,44.3,30.2,34.8,34.1,40.7,38.3,38.5,37.4,32.4,45.7,31.3,52.8,30.6,63.4,20.9,70.3,13.1,81.2,22.0,86.4,42.3,86.2,62.1,82.8,72.2,75.4,86.1,69.1,77.5,64.5,68.6,73.3,72.4,81.3,59.1,79.3,43.9,70.1,35.0,61.2,41.1,56.1,59.1,54.5,42.1
step
    #completewith next
    .goto Blasted Lands,52.1,8.5,-1
    .goto Deadwind Pass,56.8,42.0,-1
    .zone Redridge Mountains >> Travel to either Deadwind or Blasted Lands, whichever is closer
    .zoneskip Deadwind Pass
    .zoneskip Blasted Lands
    .skill herbalism,300,1
step
    #completewith next
    .goto Blasted Lands,65.5,24.3,-1
    .goto Duskwood,77.5,44.3,-1
    .fly Lakeshire >> Fly to Lakeshire
    .skill herbalism,300,1
step
    .goto Redridge Mountains,21.7,45.8
    .train 11993 >> Train Artisan Herbalism (225-300) from Alma in Lakeshire
    .skill herbalism,300,1
step
    #completewith next
    .goto Redridge Mountains,30.6,59.4
    .fly Nethergarde >> Fly to Nethergarde Keep
    .skill herbalism,300,1
    .zoneskip Swamp of Sorrows
step
    #completewith next
    .goto Blasted Lands,52.1,8.5,40,0
    .goto Swamp of Sorrows,33.9,65.9
    .zone Swamp of Sorrows >> Ride to Swamp of Sorrows
    .skill herbalism,300,1
step
    .skill herbalism,300 >> Level your Herbalism from 225-300 in Swamp of Sorrows
    .loop 60,Swamp of Sorrows,54.5,42.1,44.8,41.9,30.8,51.2,26.7,61.6,23.2,59.5,20.9,53.4,17.1,55.1,15.1,64.0,11.8,63.7,14.8,46.3,18.0,46.1,17.0,42.3,10.9,37.1,10.7,32.1,14.9,33.2,19.4,43.7,21.6,40.7,26.3,44.3,30.2,34.8,34.1,40.7,38.3,38.5,37.4,32.4,45.7,31.3,52.8,30.6,60.0,33.2,63.4,20.9,70.3,13.1,81.2,22.0,79.1,31.5,,84.2,35.4,,86.4,42.3,86.2,62.1,82.8,72.2,78.5,77.4,71.1,68.9,76.9,67.2,81.3,59.1,79.3,43.9,70.1,35.0,61.2,41.1,56.1,59.1,54.5,42.1
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill herbalism,325,1
    .zoneskip Hellfire Peninsula
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill herbalism,325,1
    .zoneskip Hellfire Peninsula
step << !Mage
    #completewith next
    .goto Dalaran,37.2,66.2
    .zone Shattrath City >> Take the portal to Shattrath
    .skill herbalism,325,1
    .zoneskip Hellfire Peninsula
step
    #completewith Rorelien
    .goto Shattrath City,64.1,41.1
    .fly Honor Hold >> Fly to Honor Hold
    .skill herbalism,325,1
    .skill riding,300,1
    .zoneskip Hellfire Peninsula
step
    #completewith next
    .goto Hellfire Peninsula,53.6,65.8
    .zone Hellfire Peninsula >> Fly to Honor Hold in Hellfire Peninsula on your flying mount
    .skill herbalism,325,1
    .skill riding,<300,1
step
    #label Rorelien
    .goto Hellfire Peninsula,54.2,65.4,15,0
    .goto Hellfire Peninsula,53.6,65.8
    .train 28695 >> Train Master Herbalism (300-375) from Rorelien in the building in Honor Hold
    .skill herbalism,325,1
step
    .skill herbalism,325 >> Level your Herbalism from 300-325 in Hellfire Peninsula
    .loop 45,Hellfire Peninsula,27.9,80.6,31.1,61.8,43.5,63.9,43.0,72.9,38.1,87.2,45.7,85.5,49.8,69.2,62.0,68.9,67.4,77.9,65.4,58.4,72.3,62.3,80.3,79.6,73.8,59.2,66.8,55.5,67.1,52.2,71.9,51.9,73.9,40.2,66.8,43.7,65.7,28.1,59.0,35.9,55.6,28.9,51.0,23.9,49.2,36.5,45.1,41.9,49.0,47.1,59.8,47.1,61.0,53.7,52.5,54.6,48.6,58.9,42.9,56.0,37.7,42.6,41.0,30.8,35.5,29.3,27.5,36.8,31.4,48.6,24.1,44.4,20.5,40.1,18.2,46.1,14.6,36.8,12.1,55.2,13.8,61.8,17.2,53.6,22.7,54.9,22.9,65.9,27.9,80.6
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill herbalism,350,1
    .zoneskip Terokkar Forest
step
    #completewith next
    .goto Terokkar Forest,39.6,24.8
    .zone Terokkar Forest >> Fly to Terokkar Forest
    .skill herbalism,350,1
step
    .skill herbalism,350 >> Level your Herbalism from 325-350 in Terokkar Forest
    .loop 60,Terokkar Forest,20.8,16.4,22.8,7.8,25.5,10.2,35.8,8.6,44.0,18.1,44.9,13.9,50.8,17.5,50.1,25.7,37.8,35.7,40.6,40.5,45.6,33.4,50.5,35.6,55.3,27.7,61.2,24.4,54.9,38.2,60.2,42.9,65.2,30.5,72.9,30.6,67.1,43.7,60.9,45.2,69.0,50.4,64.9,56.0,60.2,49.7,54.9,58.6,56.5,65.5,65.6,69.5,73.5,82.7,73.4,87.4,68.7,86.6,60.5,70.9,56.0,71.6,49.6,82.2,30.8,79.3,29.4,66.2,24.7,65.1,25.6,77.3,18.3,78.0,17.9,66.0,27.5,50.2,32.3,36.4,20.8,16.4
step << Mage
    #completewith next
    .zoneskip Borean Tundra
    .zone Dalaran >> Teleport to Dalaran
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Borean Tundra
    .skill herbalism,400,1
step
    #completewith next
    .zone Borean Tundra >> Fly to Borean Tundra on your flying mount
    .skill herbalism,400,1
    .skill riding,300,1
step
    #completewith next
    .goto Dalaran, 72.2,45.8
    .fly Valiance Keep >> Fly to Borean Tundra (Valiance Keep)
    .skill herbalism,400,1
    .skill riding,<300,1
step
    #label Kirea
    .goto Borean Tundra,57.8,71.8
    .train 50300 >> Learn Grand Master Herbalism (350-450) from Kirea Moondancer in Valiance Keep
    .skill herbalism,400,1
step
    #label BoreanTundra
    .skill herbalism,400 >> Level your Herbalism from 350-400 in Borean Tundra
    .loop 20,Borean Tundra,77.0,30.1,77.5,35.8,75.5,41.7,69.0,41.8,64.5,39.8,60.7,42.5,61.6,58.4,57.4,48.8,49.8,69.5,49.2,74.9,46.2,72.2,32.8,63.5,32.5,54.3,44.0,43.9,52.7,49.0,52.7,41.0,58.0,40.4,60.1,32.5,54.9,27.9,48.4,23.2,50.0,20.0,58.1,18.7,61.8,14.3,66.0,16.1,73.4,25.9,70.1,31.0,72.6,34.2,77.0,30.1
step
    #completewith next
    .goto Sholazar Basin,50,50
    .zone Sholazar Basin >> Fly to Sholazar Basin
    .skill herbalism,425,1
step
    .skill herbalism,425 >> Level your Herbalism from 375-425 in Sholazar Basin
    .loop 20,Sholazar Basin,70.1,68.4,67.1,70.9,65.7,75.3,58.3,77.7,60.9,84.4,54.4,85.7,48.6,83.5,48.1,71.7,47.8,65.8,49.6,52.4,46.4,51.7,45.1,56.3,42.1,58.0,40.9,64.3,42.2,83.2,33.5,83.1,27.2,80.1,26.6,72.8,34.2,66.3,33.8,59.8,22.2,59.2,23.1,48.1,28.6,52.7,30.1,44.5,35.4,45.0,33.4,35.1,41.4,22.8,58.3,27.8,62.1,35.0,56.1,35.7,57.3,42.3,59.2,47.0,56.7,55.9,54.2,61.5,61.7,67.2,70.1,68.4
step
    #completewith next
    .goto The Storm Peaks,50.0,50.0
    .zone The Storm Peaks >> Fly to The Storm Peaks on your flying mount
    .skill herbalism,450,1
    .skill riding,<300,1
step << Mage
    #completewith next
    .zone Dalaran >> Teleport to Dalaran
    .skill herbalism,450,1
    .skill riding,300.1
    .zoneskip Dalaran
    .zoneskip The Storm Peaks
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill riding,300,1
    .skill herbalism 450,1
    .zoneskip The Storm Peaks
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .goto Sholazar Basin,50.2,61.5
    .fly K3 >> Fly to Storm Peaks (K3)
    .skill riding,300,1
    .skill herbalism 450,1
    .zoneskip The Storm Peaks
step
    #label TheStormPeaks
    .skill herbalism,450 >> Level your Herbalism from 425-450 in The Storm Peaks
    .loop 20,The Storm Peaks,56.1,65.5,59.2,59.3,63.5,62.6,72.5,63.3,71.1,55.4,71.9,48.3,67.0,45.9,65.4,41.6,61.1,44.2,58.8,48.7,55.7,50.2,50.5,53.3,49.8,59.8,46.9,62.5,38.0,62.9,38.0,53.9,44.0,52.8,43.1,43.6,37.6,44.5,34.9,40.1,32.3,49.3,28.4,50.3,26.7,56.7,22.6,57.0,25.0,63.1,27.8,61.8,26.7,72.5,31.5,65.8,36.9,66.3,37.4,77.0,30.6,83.4,32.7,89.9,39.0,88.5,39.6,80.7,50.0,74.3,56.1,65.5
step
    +Congratulations on reaching skill level 450 in Herbalism!
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Profession Leveling
<< Horde
#name 1-450 Mining (H)
#displayname 1-450 Mining

step << Mage
    #completewith Makaru
    .zone Orgrimmar >> Teleport to Orgrimmar
    .skill mining,65,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Orgrimmar
    .skill mining,65,1
step << !Mage
    .goto Dalaran,55.5,25.5
    .zone Orgrimmar >> In Dalaran, take the portal to Orgrimmar
    .skill mining,65,1
step
    #sticky
    #label Pick
    .goto Orgrimmar,73.3,26.6,0,0
    >>Buy a Mining Pick from Gorina next to Makaru
    .collect 2901,1 --Mining Pick (1)
    .skill mining,65,1
step
    #label Makaru
    .goto Orgrimmar,73.1,26.1
    .train 2575 >> Train Apprentice Mining (1-75) from Makaru in the building in Orgrimmar
    .skill mining,65,1
step
    #requires Pick
    #completewith next
    .goto Durotar,45.5,12.2
    .zone Durotar >> Exit Orgrimmar into Durotar
    .skill mining,65,1
step
    #requires Pick
    .openmap Durotar
    .skill mining,65 >> Level your Mining from 1-65 in Durotar. Press "M" to open your map to see the route.
    .loop 60,Durotar,43.6,21.5,40.9,18.8,39.6,16.2,38.7,21.6,36.8,27.5,39.5,27.0,39.4,28.3,39.2,32.8,41.1,33.7,44.1,33.8,45.7,31.2,47.4,30.9,48.6,34.0,46.9,34.8,48.2,36.7,46.2,38.9,43.6,40.2,41.0,37.3,36.8,35.4,36.8,43.4,37.8,50.3,38.6,52.8,41.6,51.3,43.1,43.5,44.5,49.2,48.0,49.2,48.6,49.3,50.0,50.0,50.7,53.7,51.6,59.5,51.5,61.7,54.7,60.6,56.7,58.9,60.5,59.9,60.2,55.3,57.7,48.2,55.6,40.3,55.5,37.7,53.8,36.2,53.0,29.5,53.6,24.8,53.9,27.8,51.7,27.4,48.2,21.4,43.6,21.5
step << Mage
    #completewith next
    .zone Orgrimmar >> Teleport to Orgrimmar
    .skill mining,125,1
step << !Mage
    .goto Orgrimmar,48.8,91.0
    .zone Orgrimmar >> Ride back to Orgrimmar
    .skill mining,125,1
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Orgrimmar
    .skill mining,125,1
step << !Mage
    #completewith next
    .goto Dalaran,55.5,25.5
    .zone Orgrimmar >> In Dalaran, take the portal to Orgrimmar
    .skill mining,125,1
step
    .goto Orgrimmar,73.1,26.1
    .train 2576 >> Train Journeyman Mining (75-150) from Makaru in the building in Orgrimmar
    .skill mining,125,1
step
    #completewith next
    .goto Orgrimmar,45.1,63.9
    .fly Crossroads >> Fly to The Crossroads
    .zoneskip The Barrens
step
    .skill mining,125 >> Level your Mining from 65-125 in The Barrens [Route 1]
    .loop 60,The Barrens,52.7,30.9,54.4,27.4,55.6,26.4,56.2,24.5,58.0,25.0,58.5,26.1,58.9,24.8,57.2,18.8,57.6,16.9,54.4,16.9,53.5,18.6,50.7,12.5,49.0,14.6,47.8,15.8,47.0,15.3,46.9,12.8,44.1,13.0,43.0,14.2,39.6,14.4,38.9,11.7,37.5,16.0,41.0,18.6,40.7,21.7,40.1,24.3,41.9,28.9,43.5,27.0,44.9,25.3,45.4,23.1,49.0,28.5,52.7,30.9
    +65-125 [Route 2]
    .loop 60,The Barrens,46.6,36.9,46.8,38.9,50.3,41.5,51.1,42.8,55.1,42.8,56.5,43.6,51.7,47.4,49.0,48.8,51.2,51.6,52.1,53.4,52.9,52.6,53.2,54.5,51.7,55.4,51.0,57.8,47.7,66.3,47.3,69.4,48.7,69.5,47.7,72.7,48.5,80.4,48.4,84.0,48.8,87.2,47.0,84.8,44.0,84.4,41.0,80.5,41.1,79.3,44.0,78.2,43.7,74.2,45.7,69.1,43.6,54.8,44.6,54.3,43.8,52.6,44.0,51.4,41.4,45.4,43.5,44.4,43.3,40.2,45.7,37.0,46.6,36.9
step << Mage
    #completewith next
    .zone Orgrimmar >> Teleport to Orgrimmar
    .skill mining,175,1
step << !Mage
    .goto The Barrens,51.5,30.3,-1
    .goto The Barrens,44.4,59.2,-1
    .fly Orgrimmar
    .zone Orgrimmar >> Fly to Orgrimmar from either Crossroads or Camp Taurajo, whichever is closer (preferably Crossroads)
    .skill mining,175,1
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,175,1
    .zoneskip Orgrimmar
step << !Mage
    #completewith next
    .goto Dalaran,55.5,25.5
    .zone Orgrimmar >> In Dalaran, take the portal to Orgrimmar
    .skill mining,175,1
step
    .goto Orgrimmar,73.1,26.1
    .train 3564 >> Train Expert Mining (150-225) from Makaru in the building in Orgrimmar
    .skill mining,175,1
step << Mage
    #completewith next
    .zone Undercity >> Teleport to Undercity
    .skill mining,175,1
step << !Mage
    #completewith next
    .goto Durotar,45.5,12.2
    .zone Durotar >> Exit Orgrimmar into Durotar. Alternatively, pay a mage for a portal to Undercity
    .skill mining,175,1
    .zoneskip Undercity
step << !Mage
    .goto Durotar,50.7,13.3,20,0
    .goto Durotar,50.8,13.9
    .zone Stranglethorn Vale >> Climb the Zeppelin Tower. Take the Zeppelin to Tirisfal Glades
    .skill mining,175,1
    .zoneskip Undercity
step << !Mage
    .goto Undercity,66.3,4.4
    .zone Undercity >> Run into Undercity, then take the elevators down
    .skill mining,175,1
    .zoneskip Arathi Highlands
step
    #completewith next
    .goto Undercity,65.9,44.1,50,0
    .goto Undercity,63.3,48.6
    .fly Hammerfall >> Fly to Hammerfall
    .skill mining,175,1
    .zoneskip Arathi Highlands
step
    .skill mining,175 >> Level your Mining from 125-175 in Arathi Highlands
    .loop 60,Arathi Highlands,71.9,31.0,66.4,27.7,63.4,32.6,59.9,36.2,60.9,41.7,53.9,47.8,49.0,51.3,52.0,45.5,52.6,35.4,48.2,38.5,42.4,42.8,40.4,46.6,35.5,44.3,39.1,35.6,42.8,31.6,34.6,22.8,28.8,18.7,29.6,32.0,24.7,30.7,23.9,35.5,21.0,34.1,22.9,42.7,27.5,49.7,30.1,51.4,32.8,62.1,34.3,65.4,39.8,70.7,44.2,75.7,45.6,75.5,52.5,77.3,54.6,74.9,55.1,71.7,59.5,70.6,63.2,72.8,66.1,73.1,68.2,74.4,71.1,68.2,72.0,59.9,69.8,56.7,73.7,45.9,79.2,40.3,81.7,35.8,82.6,39.0,76.6,33.2,75.2,28.8,71.9,31.0
step
    #completewith next
    .goto Arathi Highlands,73.1,32.7
    .fly Revantusk Village >> Fly to Revantusk Village
    .skill mining,225,1
step
    .skill mining,225 >> Level your Mining from 175-225 in The Hinterlands
    .loop 60,The Hinterlands,70.9,63.3,73.9,58.0,72.9,53.0,76.5,52.4,77.6,48.8,72.9,48.5,64.6,43.0,60.6,38.5,61.7,34.3,67.5,36.2,69.3,27.4,66.1,21.8,67.2,16.5,68.7,14.2,64.2,16.1,58.6,20.7,59.0,28.3,57.3,35.2,57.6,38.3,51.8,47.3,47.6,38.5,46.7,35.7,45.0,41.1,40.7,45.6,38.9,47.4,34.2,42.2,32.2,43.3,32.1,48.8,28.9,53.5,24.9,59.5,26.6,68.0,30.9,62.4,35.8,64.0,34.2,68.5,31.4,70.4,31.5,72.6,34.2,74.0,36.1,68.7,39.7,65.9,45.7,70.0,49.0,65.4,50.7,67.3,52.7,58.3,58.0,51.6,65.7,54.8,66.0,60.7,70.9,63.3
step << Mage
    #completewith next
    .zone Orgrimmar >> Teleport to Orgrimmar
    .skill mining,245,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,245,1
    .zoneskip Orgrimmar
step << !Mage
    #completewith next
    .goto Dalaran,55.5,25.5
    .zone Orgrimmar >> In Dalaran, take the portal to Orgrimmar
    .skill mining,245,1
step
    .goto Orgrimmar,73.1,26.1
    .train 10248 >> Train Artisan Mining (225-300) from Makaru in the building in Orgrimmar
    .skill mining,245,1
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath
    .skill mining,245,1
    .zoneskip Tanaris
    .reputation 989,revered,<0,1
step << Mage
    #completewith next
    .zone Tanaris >> Talk to Zephyr in the World's End Tavern to teleport to the Caverns of Time. Do NOT talk to the Steward of Time when you arrive
    .skill mining,245,1
    .skipgossip
    .reputation 989,revered,<0,1
step
    #completewith next
    .goto Orgrimmar,45.1,63.9
    .fly Gadgetzan >> Fly to Gadgetzan
    .skill mining,245,1
    .zoneskip Tanaris
step
    >>Enter the Silithid Hives for veins of ore if there are any inside
    .skill mining,245 >> Level your Mining from 225-245 in Tanaris
    .loop 60,Tanaris,55.9,24.3,54.1,24.6,47.1,23.9,46.7,29.8,43.9,26.0,34.3,26.1,34.3,31.7,36.7,33.4,33.4,37.7,32.8,42.1,29.9,46.4,27.8,56.7,28.2,61.0,30.4,62.8,30.9,67.3,28.2,74.0,30.8,77.2,34.7,80.3,41.7,76.7,44.3,76.1,51.3,79.0,57.8,69.3,58.8,63.2,61.8,53.9,65.3,56.7,69.1,54.6,73.3,53.9,72.3,49.1,71.0,43.6,69.0,41.7,67.0,41.5,55.9,24.3
step
    #completewith next
    .goto Tanaris,51.6,25.4,-1
    .goto Un'Goro Crater,70.7,90.7,-1
    .fly Marshal's Refuge >> Fly to Marshal's Refuge from Gadgetzan, or ride into Un'Goro if it is closer
    .skill mining,275,1
    .zoneskip Un'Goro Crater
step
    .skill mining,275 >> Level your Mining from 245-275 in Un'Goro Crater
    .loop 60,Un'Goro Crater,48.4,13.8,53.1,30.7,56.1,33.3,62.2,32.3,58.6,23.4,57.7,14.1,63.0,16.8,64.5,20.9,69.5,20.3,71.6,28.1,74.5,34.5,75.6,38.7,78.9,41.8,76.5,43.8,76.2,51.1,76.0,61.2,79.6,59.9,76.0,61.2,74.1,68.0,69.8,68.4,60.8,65.7,61.6,70.1,63.8,79.0,60.4,83.4,56.1,89.5,54.4,86.3,51.0,86.5,44.8,82.6,48.8,80.7,50.7,72.5,54.3,64.9,46.9,65.4,39.0,64.8,37.1,55.5,35.8,53.7,35.7,48.2,33.4,47.7,38.3,37.0,44.5,35.1,44.1,28.8,35.8,22.1,39.6,17.4,44.2,14.5,48.4,13.8
step
    .skill mining,300 >> Level your Mining from 275-300 in Un'Goro Crater
    .loop 60,Un'Goro Crater,48.4,13.8,53.1,30.7,56.1,33.3,62.2,32.3,58.6,23.4,57.7,14.1,63.0,16.8,64.5,20.9,69.5,20.3,71.6,28.1,74.5,34.5,75.6,38.7,78.9,41.8,76.5,43.8,76.2,51.1,76.0,61.2,79.6,59.9,76.0,61.2,74.1,68.0,69.8,68.4,60.8,65.7,61.6,70.1,63.8,79.0,60.4,83.4,56.1,89.5,54.4,86.3,51.0,86.5,44.8,82.6,48.8,80.7,50.7,72.5,54.3,64.9,50.8,53.4,50.8,53.4,53.1,51.3,52.5,47.6,51.7,45.7,47.7,46.8,46.9,51.8,47.9,64.6,39.0,64.8,37.9,78.6,31.8,78.9,32.1,73.6,32.7,70.8,28.9,68.2,25.3,61.4,22.9,58.2,24.2,55.0,24.3,43.1,22.2,41.2,28.1,40.4,32.8,47.7,38.3,37.0,44.5,35.1,44.1,28.8,35.8,22.1,39.6,17.4,44.2,14.5,48.4,13.8
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill mining,325,1
    .zoneskip Hellfire Peninsula
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,325,1
    .zoneskip Hellfire Peninsula
step
    #completewith next
    .goto Dalaran,55.5,25.5
    .zone Shattrath City >> In Dalaran, Teleport to Shattrath
step
    #completewith Krugosh
    .goto Shattrath City,64.1,41.1
    .fly Thrallmar >> Fly to Thrallmar
    .skill mining,325,1
    .skill riding,300,1
    .zoneskip Hellfire Peninsula
step
    #completewith next
    .goto Hellfire Peninsula,55.4,37.6
    .zone Hellfire Peninsula >> Fly to Thrallmar in Hellfire Peninsula on your flying mount
    .skill herbalism,325,1
    .skill riding,<300,1
step
    #label Krugosh
    .goto Hellfire Peninsula,55.4,37.6
    .train 29354 >> Train Master Mining (300-375) from Krugosh in Thrallmar
    .skill mining,325
step
    .skill mining,325 >> Level your Mining from 300-325 in Hellfire Peninsula
    .loop 60,Hellfire Peninsula,48.0,58.4,51.5,54.4,53.3,56.4,57.1,52.7,60.4,51.7,59.9,47.9,49.8,48.1,46.6,43.9,48.5,35.8,54.5,30.0,51.8,23.7,49.1,28.3,44.0,29.5,42.1,33.0,40.7,30.0,37.3,30.6,34.6,30.5,33.3,33.9,37.0,39.4,40.0,43.0,41.4,47.8,43.1,55.3,38.8,52.9,37.4,50.0,31.6,48.0,31.1,43.1,28.8,40.8,25.4,46.0,16.6,45.1,16.8,38.9,13.2,37.2,11.2,48.2,7.6,49.9,14.8,60.2,20.6,54.7,23.9,56.5,22.0,63.0,26.2,78.2,28.7,78.7,30.3,71.5,27.4,66.2,30.2,64.3,30.9,60.9,35.5,59.6,35.5,64.2,36.4,69.5,41.5,64.4,43.9,66.9,47.1,65.7,47.2,61.2,48.0,58.4
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill mining,350,1
    .zoneskip Terokkar Forest
step << !Mage
    .goto Terokkar Forest,60.5,24.2
    .zone Terokkar Forest >> Fly to Terokkar Forest
    .skill mining,350,1
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Shattrath City
    .skill mining,350,1
    .zoneskip Terokkar Forest
step
    #completewith next
    .goto Terokkar Forest,39.6,24.8
    .zone Terokkar Forest >> Fly to Terokkar Forest
    .skill mining,350,1
step
    .skill mining,350 >> Level your Mining from 325-350 in Terokkar Forest
    .loop 60,Terokkar Forest,30.6,37.2,29.7,48.0,25.3,55.4,19.5,56.1,16.7,70.0,18.3,78.3,26.1,75.9,25.8,65.8,28.8,65.1,30.8,68.9,29.7,76.3,32.5,77.9,41.0,79.8,48.6,80.6,52.5,76.8,55.2,72.8,61.4,72.1,61.4,83.5,69.1,86.7,75.4,87.4,74.4,82.3,70.3,76.6,72.6,73.2,66.3,71.0,63.9,65.1,56.6,65.8,56.8,61.4,51.2,56.4,42.7,48.4,37.8,39.1,45.1,35.1,49.1,36.0,53.1,32.9,56.7,34.5,55.9,39.3,58.2,47.0,64.8,55.1,66.3,53.6,68.6,52.7,71.1,45.0,69.4,38.2,73.0,36.8,71.6,30.8,65.4,31.5,59.9,23.0,54.6,25.2,53.2,27.8,49.1,20.1,50.9,16.6,43.9,10.0,42.2,22.2,39.4,19.2,35.8,7.9,27.8,10.8,23.7,9.5,21.9,11.4,21.3,14.5,30.6,37.2
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill mining,375,1
    .zoneskip Nagrand
step
    #completewith next
    .goto Nagrand,77.4,54.6
    .zone Nagrand >> Fly to Nagrand on your flying mount
    .skill mining,375,1
step
    #label Nagrand
    .skill mining,375 >> Level your Mining from 350-375 in Nagrand
    .loop 60,Nagrand,70.8,76.0,77.7,59.9,71.6,60.3,70.6,52.1,72.2,43.4,66.1,34.7,68.0,50.3,61.2,55.5,56.9,53.2,56.4,57.9,48.4,50.9,51.5,39.8,50.3,24.7,46.1,20.7,38.9,22.4,45.3,45.8,42.7,49.2,39.5,44.8,37.8,29.6,31.7,28.3,25.6,15.0,27.1,23.6,23.2,29.1,8.0,40.4,9.9,43.7,23.4,48.1,21.0,53.5,28.0,65.1,29.9,71.0,25.4,71.8,28.9,80.8,40.4,83.0,43.1,76.3,43.7,64.1,48.6,79.4,50.7,67.2,57.2,63.3,69.0,81.5,70.8,76.0
step << Mage
    #completewith next
    .zone Dalaran >> Teleport to Dalaran
    .zoneskip Borean Tundra
    .skill mining 400,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Borean Tundra
    .skill mining 400,1
step
    #completewith next
    .zone Borean Tundra >> Fly to Borean Tundra on your flying mount
    .skill mining,400,1
    .skill riding,300,1
step
    #completewith next
    .goto Dalaran, 72.2,45.8
    .fly Warsong Hold >> Fly to Borean Tundra (Warsong Hold)
    .skill mining,400,1
    .skill riding,<300,1
step
    #label Brunna
    .goto Borean Tundra,42.6,53.2
    .train 50310 >> Learn Grand Master Mining (350-450) from Brunna Ironaxe in Warsong Hold
    .skill mining,400,1
step
    #label Borean Tundra
    .skill mining,400 >> Train your mining from 375-400 in Borean Tundra
    .loop 20,Borean Tundra,91.1,33.6,87.8,44.7,78.9,44.7,78.9,30.0,73.4,32.7,72.6,28.0,68.2,25.5,69.3,31.5,64.1,33.4,61.7,37.7,66.3,38.8,72.6,45.3,66.0,46.6,59.6,59.4,56.6,57.8,52.8,73.2,49.3,69.4,50.6,57.1,43.1,70.4,34.1,67.0,29.5,56.5,49.2,49.1,52.3,35.9,50.0,33.3,41.7,41.6,23.8,33.6,22.7,28.9,25.0,22.0,30.4,22.3,33.2,27.6,39.9,20.0,44.2,21.3,41.9,13.7,48.7,15.3,55.5,11.8,60.0,11.7,59.4,19.2,61.1,22.3,65.9,16.6,74.2,17.1,78.0,21.3,84.1,32.3,91.1,33.6
step
    #completewith next
    .goto Sholazar Basin,50,50
    .zone Sholazar Basin >> Fly to Sholazar Basin
    .skill mining,425,1
step
    .skill mining,425 >> Level your Mining from 400-425 in Sholazar Basin
    .loop 20,Sholazar Basin,77.7,56.8,76.3,65.9,64.0,81.0,60.2,80.3,59.7,87.0,54.0,88.3,59.3,66.8,53.8,64.0,47.7,60.4,45.9,63.5,50.2,78.8,48.5,87.0,40.3,87.1,37.4,83.7,40.4,76.5,36.6,69.1,32.2,75.0,31.8,80.2,32.2,83.6,22.8,82.4,20.8,70.3,23.5,52.8,25.8,47.2,31.9,59.5,36.3,57.5,39.5,51.2,31.4,37.9,35.2,32.8,37.6,37.0,40.8,38.4,43.1,35.8,49.7,43.3,53.5,38.7,51.0,31.6,43.6,22.3,58.9,25.0,59.0,29.4,62.9,31.8,67.2,42.9,61.3,50.4,64.2,53.8,67.3,50.7,67.8,55.2,74.2,55.5,77.7,56.8
step
    #completewith next
    .goto Icecrown,50,50
    .zone Icecrown >> Fly to Icecrown
    .skill mining,450,1
step
    .skill nining,450 >> Level your Mining from 425-450 in Icecrown
    .loop 20, Icecrown,65.6,35.1,59.3,29.4,54.9,38.6,47.8,35.1,42.8,37.8,39.3,33.4,37.9,36.2,37.2,41.7,41.6,41.1,38.0,50.8,37.9,57.1,40.2,59.8,31.5,58.1,30.8,64.5,36.2,68.9,39.9,65.6,49.6,61.4,48.5,51.2,56.5,44.7,65.6,59.8,67.1,72.2,72.0,63.8,74.2,65.0,77.8,64.3,79.3,57.0,75.8,46.4,67.6,46.5,67.3,42.9,74.1,40.1,74.7,35.3,65.6,35.1
step
    +Congratulations on reaching skill level 450 in Mining!
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Profession Leveling
<< Alliance
#name 1-450 Mining (A)
#displayname 1-450 Mining

step << Mage
    #completewith Gelman
    .zone Stormwind City >> Teleport to Stormwind
    .skill mining,65,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,65,1
    .zoneskip Stormwind City
step << !Mage
    .goto Dalaran,39.8,62.5
    .zone Stormwind City >> In Dalaran, take the portal to Stormwind City
    .skill mining,65,1
step
    #sticky
    #label Pick
    .goto Stormwind City,60.2,37.0,20,0
    .goto Stormwind City,59.1,37.5,0,0
     >> Buy a Mining Pick from Brooke downstairs in the house in Stormwind
    .collect 2901,1 --Mining Pick (1)
    .skill mining,65,1
step
    #label Gelman
    .goto Stormwind City,59.3,37.9
    .train 2575 >> Train Apprentice Mining (1-75) from Gelman upstairs in the house in Stormwind
    .skill mining,65,1
step
    #requires Pick
    #completewith next
    .goto Elwynn Forest,32.3,49.9
    .zone Elwynn Forest >> Exit Stormwind into Elwynn Forest
    .skill mining,65,1
step
    #requires Pick
    .openmap Elwynn Forest
    .skill mining,65 >> Level your Mining from 1-65 in Elwynn Forest. Press "M" to open your map to see the route.
    .loop 60,Elwynn Forest,37.9,52.6,41.0,52.9,43.8,50.4,50.8,58.8,51.4,65.6,54.7,62.1,60.6,63.4,58.6,57.7,61.8,54.2,65.5,58.6,69.0,68.6,65.8,72.8,58.5,77.5,51.2,85.3,51.0,75.7,46.7,72.6,43.5,76.0,39.1,82.6,38.2,84.6,36.7,81.6,40.5,73.7,37.2,72.2,34.1,71.9,26.7,69.9,27.0,67.4,29.4,63.6,29.3,60.1,31.2,54.9,37.9,52.6
step << Mage
    #completewith next
    .zone Stormwind City >> Teleport to Stormwind
    .skill mining,125,1
step << !Mage
    .goto Stormwind City,73.0,89.9
    .zone Stormwind City >> Ride back to Stormwind City
    .skill mining,125,1
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,125,1
    .zoneskip Stormwind City
step << !Mage
    .goto Dalaran,39.8,62.5
    .zone Stormwind City >> In Dalaran, take the portal to Stormwind City
    .skill mining,125,1
step
    .goto Stormwind City,60.2,37.0,20,0
    .goto Stormwind City,59.3,37.9
    .train 2576 >> Train Journeyman Mining (75-150) from Gelman upstairs in the house in Stormwind
    .skill mining,125,1
step
    #completewith next
    .goto Stormwind City,68.2,72.9,20,0
    .goto Stormwind City,71.0,72.5
    .fly Lakeshire >> Fly to Lakeshire
    .skill mining,125,1
    .zoneskip Redridge Mountains
step
    .skill mining,125 >> Level your Mining from 65-125 in Redridge Mountains
    .loop 60,Redridge Mountains,39.8,39.6,47.5,38.8,54.9,44.7,60.7,44.8,71.5,50.0,67.6,52.2,65.7,60.9,61.2,65.1,53.1,76.1,65.0,75.9,70.2,74.4,74.4,83.6,77.4,67.6,81.6,69.5,86.9,61.4,84.2,50.1,80.3,42.7,76.5,36.9,66.6,42.8,60.5,39.7,51.6,40.4,46.1,23.0,41.5,14.4,37.4,13.2,33.6,7.8,37.4,13.2,41.5,14.4,46.1,23.0,45.0,31.5,40.3,32.1,29.5,22.0,24.4,25.5,23.5,32.1,19.8,34.1,20.7,28.2,20.7,37.7,29.1,36.8,39.8,39.6
step << Mage
    #completewith next
    .zone Stormwind City >> Teleport to Stormwind
    .skill mining,175,1
step << !Mage
    .goto Redridge Mountains,30.6,59.4
    .fly Stormwind
    .zone Stormwind City >> Travel to Stormwind City
    .skill mining,175,1
    .zoneskip Stormwind City
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,175,1
    .zoneskip Stormwind City
step << !Mage
    #completewith next
    .goto Dalaran,39.8,62.5
    .zone Stormwind City >> In Dalaran, take the portal to Stormwind City
    .skill mining,175,1
step
    .goto Stormwind City,60.2,37.0,20,0
    .goto Stormwind City,59.3,37.9
    .train 3564 >> Train Expert Mining (150-225) from Gelman upstairs in the house in Stormwind
    .skill mining,175,1
step
    #completewith next
    .goto Stormwind City,68.2,72.9,20,0
    .goto Stormwind City,71.0,72.5
    .fly Refuge Pointe >> Fly to Refuge Pointe
    .skill mining,175,1
    .zoneskip Arathi Highlands
step
    .skill mining,175 >> Level your Mining from 125-175 in Arathi Highlands
    .loop 60,Arathi Highlands,71.9,31.0,66.4,27.7,63.4,32.6,59.9,36.2,60.9,41.7,53.9,47.8,49.0,51.3,52.0,45.5,52.6,35.4,48.2,38.5,42.4,42.8,40.4,46.6,35.5,44.3,39.1,35.6,42.8,31.6,34.6,22.8,28.8,18.7,29.6,32.0,24.7,30.7,23.9,35.5,21.0,34.1,22.9,42.7,27.5,49.7,30.1,51.4,32.8,62.1,34.3,65.4,39.8,70.7,44.2,75.7,45.6,75.5,52.5,77.3,54.6,74.9,55.1,71.7,59.5,70.6,63.2,72.8,66.1,73.1,68.2,74.4,71.1,68.2,72.0,59.9,69.8,56.7,73.7,45.9,79.2,40.3,81.7,35.8,82.6,39.0,76.6,33.2,75.2,28.8,71.9,31.0
step
    #completewith next
    .goto Arathi Highlands,45.8,46.1
    .fly Aerie Peak >> Fly to Aerie Peak
    .skill mining,225,1
    .zoneskip The Hinterlands
step
    .skill mining,225 >> Level your Mining from 175-225 in The Hinterlands
    .loop 60,The Hinterlands,70.9,63.3,73.9,58.0,72.9,53.0,76.5,52.4,77.6,48.8,72.9,48.5,64.6,43.0,60.6,38.5,61.7,34.3,67.5,36.2,69.3,27.4,66.1,21.8,67.2,16.5,68.7,14.2,64.2,16.1,58.6,20.7,59.0,28.3,57.3,35.2,57.6,38.3,51.8,47.3,47.6,38.5,46.7,35.7,45.0,41.1,40.7,45.6,38.9,47.4,34.2,42.2,32.2,43.3,32.1,48.8,28.9,53.5,24.9,59.5,26.6,68.0,30.9,62.4,35.8,64.0,34.2,68.5,31.4,70.4,31.5,72.6,34.2,74.0,36.1,68.7,39.7,65.9,45.7,70.0,49.0,65.4,50.7,67.3,52.7,58.3,58.0,51.6,65.7,54.8,66.0,60.7,70.9,63.3
step << Mage
    #completewith next
    .zone Ironforge >> Teleport to Ironforge
    .skill mining,245,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,245,1
    .zoneskip Stormwind City
step << !Mage
    #completewith next
    .goto Dalaran,39.2,63.7
    .zone Stormwind City >> In Dalaran, take the portal to Ironforge
    .skill mining,245,1
step
    .goto Ironforge,51.8,29.5,15,0
    .goto Ironforge,49.6,28.2,12,0
    .goto Ironforge,49.9,26.3
    .train 3564 >> Train Artisan Mining (225-300) from Geofram downstairs in the house in Ironforge
    .skill mining,245,1
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath
    .skill mining,245,1
    .zoneskip Tanaris
    .reputation 989,revered,<0,1
step << Mage
    .zone Tanaris >> Talk to Zephyr in the World's End Tavern to teleport to the Caverns of Time. Do NOT talk to the Steward of Time when you arrive
    .skill mining,245,1
    .skipgossip
    .reputation 989,revered,<0,1
step << Mage
    #completewith next
    .zone Dustwallow Marsh >> Teleport to Theramore
    .skill mining,245,1
    .zoneskip Tanaris
step << !Mage
    #completewith next
    .goto Ironforge,55.5,47.7
    .fly Wetlands >> Fly to Menethil Harbor
    .skill mining,245,1
    .zoneskip Tanaris
step << !Mage
    .goto Wetlands,5.0,63.5
    .zone Dustwallow Marsh >> Take the Boat to Dustwallow Marsh (Theramore)
    .skill mining,245,1
    .zoneskip Tanaris
step
    #completewith next
    .goto Dustwallow Marsh,67.5,51.3
    .fly Gadgetzan >> Fly to Gadgetzan
    .skill mining,245,1
    .zoneskip Tanaris
step
    >>Enter the Silithid Hives for veins of ore if there are any inside
    .skill mining,245 >> Level your Mining from 225-245 in Tanaris
    .loop 60,Tanaris,55.9,24.3,54.1,24.6,47.1,23.9,46.7,29.8,43.9,26.0,34.3,26.1,34.3,31.7,36.7,33.4,33.4,37.7,32.8,42.1,29.9,46.4,27.8,56.7,28.2,61.0,30.4,62.8,30.9,67.3,28.2,74.0,30.8,77.2,34.7,80.3,41.7,76.7,44.3,76.1,51.3,79.0,57.8,69.3,58.8,63.2,61.8,53.9,65.3,56.7,69.1,54.6,73.3,53.9,72.3,49.1,71.0,43.6,69.0,41.7,67.0,41.5,55.9,24.3
step
    #completewith next
    .goto Tanaris,51.0,29.4,-1
    .goto Un'Goro Crater,70.7,90.7,-1
    .fly Marshal's Refuge >> Fly to Marshal's Refuge from Gadgetzan, or ride into Un'Goro if it is closer
    .skill mining,275,1
    .zoneskip Un'Goro Crater
step
    .skill mining,275 >> Level your Mining from 245-275 in Un'Goro Crater
    .loop 60,Un'Goro Crater,48.4,13.8,53.1,30.7,56.1,33.3,62.2,32.3,58.6,23.4,57.7,14.1,63.0,16.8,64.5,20.9,69.5,20.3,71.6,28.1,74.5,34.5,75.6,38.7,78.9,41.8,76.5,43.8,76.2,51.1,76.0,61.2,79.6,59.9,76.0,61.2,74.1,68.0,69.8,68.4,60.8,65.7,61.6,70.1,63.8,79.0,60.4,83.4,56.1,89.5,54.4,86.3,51.0,86.5,44.8,82.6,48.8,80.7,50.7,72.5,54.3,64.9,46.9,65.4,39.0,64.8,37.1,55.5,35.8,53.7,35.7,48.2,33.4,47.7,38.3,37.0,44.5,35.1,44.1,28.8,35.8,22.1,39.6,17.4,44.2,14.5,48.4,13.8
step
    .skill mining,300 >> Level your Mining from 275-300 in Un'Goro Crater
    .loop 60,Un'Goro Crater,48.4,13.8,53.1,30.7,56.1,33.3,62.2,32.3,58.6,23.4,57.7,14.1,63.0,16.8,64.5,20.9,69.5,20.3,71.6,28.1,74.5,34.5,75.6,38.7,78.9,41.8,76.5,43.8,76.2,51.1,76.0,61.2,79.6,59.9,76.0,61.2,74.1,68.0,69.8,68.4,60.8,65.7,61.6,70.1,63.8,79.0,60.4,83.4,56.1,89.5,54.4,86.3,51.0,86.5,44.8,82.6,48.8,80.7,50.7,72.5,54.3,64.9,50.8,53.4,50.8,53.4,53.1,51.3,52.5,47.6,51.7,45.7,47.7,46.8,46.9,51.8,47.9,64.6,39.0,64.8,37.9,78.6,31.8,78.9,32.1,73.6,32.7,70.8,28.9,68.2,25.3,61.4,22.9,58.2,24.2,55.0,24.3,43.1,22.2,41.2,28.1,40.4,32.8,47.7,38.3,37.0,44.5,35.1,44.1,28.8,35.8,22.1,39.6,17.4,44.2,14.5,48.4,13.8
step << Mage
    #completewith next
    .zone Dalaran >> Teleport to Dalaran
    .skill mining,325,1
    .zoneskip Hellfire Peninsula
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .skill mining,325,1
    .zoneskip Hellfire Peninsula
step
    #completewith next
    .goto Dalaran,37.3,66.2
    .zone Shattrath City >> In Dalaran, take the portal to Shattrath
    .skill mining,325,1
    .zoneskip Hellfire Peninsula
step
    #completewith Hurnak
    .goto Shattrath City,64.1,41.1
    .fly Honor Hold >> Fly to Honor Hold
    .skill mining,325,1
    .skill riding,300,1
    .zoneskip Hellfire Peninsula
step
    #completewith next
    .goto Hellfire Peninsula,56.7,63.8
    .zone Hellfire Peninsula >> Fly to Honor Hold in Hellfire Peninsula on your flying mount
    .skill herbalism,325,1
    .skill riding,<300,1
step
    #label Hurnak
    .goto Hellfire Peninsula,56.7,63.8
    .train 29354 >> Train Master Mining (300-375) from Hurnak inside the blacksmith at Honor Hold
    .skill mining,325
step
    .skill mining,325 >> Level your Mining from 300-325 in Hellfire Peninsula
    .loop 60,Hellfire Peninsula,48.0,58.4,51.5,54.4,53.3,56.4,57.1,52.7,60.4,51.7,59.9,47.9,49.8,48.1,46.6,43.9,48.5,35.8,54.5,30.0,51.8,23.7,49.1,28.3,44.0,29.5,42.1,33.0,40.7,30.0,37.3,30.6,34.6,30.5,33.3,33.9,37.0,39.4,40.0,43.0,41.4,47.8,43.1,55.3,38.8,52.9,37.4,50.0,31.6,48.0,31.1,43.1,28.8,40.8,25.4,46.0,16.6,45.1,16.8,38.9,13.2,37.2,11.2,48.2,7.6,49.9,14.8,60.2,20.6,54.7,23.9,56.5,22.0,63.0,26.2,78.2,28.7,78.7,30.3,71.5,27.4,66.2,30.2,64.3,30.9,60.9,35.5,59.6,35.5,64.2,36.4,69.5,41.5,64.4,43.9,66.9,47.1,65.7,47.2,61.2,48.0,58.4
step << Mage
    #completewith next
    .zone Shattrath City >> Teleport to Shattrath City
    .skill mining,350,1
    .zoneskip Terokkar Forest
step << !Mage
    .goto Terokkar Forest,60.5,24.2
    .zone Terokkar Forest >> Fly to Terokkar Forest
    .skill mining,350,1
    .zoneskip Terokkar Forest
    .cooldown item,6948,<0,1
step << !Mage
    #completewith next
    .hs >> Hearth to Shattrath City
    .skill mining,350,1
    .zoneskip Terokkar Forest
step
    #completewith next
    .goto Terokkar Forest,39.6,24.8
    .zone Terokkar Forest >> Fly to Terokkar Forest
    .skill mining,350,1
step
    .skill mining,350 >> Level your Mining from 325-350 in Terokkar Forest
    .loop 60,Terokkar Forest,30.6,37.2,29.7,48.0,25.3,55.4,19.5,56.1,16.7,70.0,18.3,78.3,26.1,75.9,25.8,65.8,28.8,65.1,30.8,68.9,29.7,76.3,32.5,77.9,41.0,79.8,48.6,80.6,52.5,76.8,55.2,72.8,61.4,72.1,61.4,83.5,69.1,86.7,75.4,87.4,74.4,82.3,70.3,76.6,72.6,73.2,66.3,71.0,63.9,65.1,56.6,65.8,56.8,61.4,51.2,56.4,42.7,48.4,37.8,39.1,45.1,35.1,49.1,36.0,53.1,32.9,56.7,34.5,55.9,39.3,58.2,47.0,64.8,55.1,66.3,53.6,68.6,52.7,71.1,45.0,69.4,38.2,73.0,36.8,71.6,30.8,65.4,31.5,59.9,23.0,54.6,25.2,53.2,27.8,49.1,20.1,50.9,16.6,43.9,10.0,42.2,22.2,39.4,19.2,35.8,7.9,27.8,10.8,23.7,9.5,21.9,11.4,21.3,14.5,30.6,37.2
step
    #completewith next
    .goto Nagrand,77.4,54.6
    .zone Nagrand >> Fly to Nagrand on your flying mount
    .skill mining,375,1
step
    .skill mining,375 >> Level your Mining from 350-375 in Nagrand
    .loop 60,Nagrand,70.8,76.0,77.7,59.9,71.6,60.3,70.6,52.1,72.2,43.4,66.1,34.7,68.0,50.3,61.2,55.5,56.9,53.2,56.4,57.9,48.4,50.9,51.5,39.8,50.3,24.7,46.1,20.7,38.9,22.4,45.3,45.8,42.7,49.2,39.5,44.8,37.8,29.6,31.7,28.3,25.6,15.0,27.1,23.6,23.2,29.1,8.0,40.4,9.9,43.7,23.4,48.1,21.0,53.5,28.0,65.1,29.9,71.0,25.4,71.8,28.9,80.8,40.4,83.0,43.1,76.3,43.7,64.1,48.6,79.4,50.7,67.2,57.2,63.3,69.0,81.5,70.8,76.0
step << Mage
    #completewith next
    .zone Dalaran >> Teleport to Dalaran
    .zoneskip Borean Tundra
    .skill mining 400,1
step << !Mage
    #completewith next
    .hs >> Hearth to Dalaran
    .zoneskip Borean Tundra
    .skill mining 400,1
step
    #completewith next
    .zone Borean Tundra >> Fly to Borean Tundra on your flying mount
    .skill mining,400,1
    .skill riding,300,1
step
    #completewith next
    .goto Dalaran, 72.2,45.8
    .fly Valiance Keep >> Fly to Borean Tundra (Valiance Keep)
    .skill mining,400,1
    .skill riding,<300,1
step
    #label Fendrig
    .goto Borean Tundra,57.4,66.2
    .train 50310 >> Learn Grand Master Mining (350-450) from Fendrig Redbeard in Valiance Keep
    .skill mining,400,1
step
    #label Borean Tundra
    .skill mining,400 >> Train your mining from 375-400 in Borean Tundra
    .loop 20,Borean Tundra,91.1,33.6,87.8,44.7,78.9,44.7,78.9,30.0,73.4,32.7,72.6,28.0,68.2,25.5,69.3,31.5,64.1,33.4,61.7,37.7,66.3,38.8,72.6,45.3,66.0,46.6,59.6,59.4,56.6,57.8,52.8,73.2,49.3,69.4,50.6,57.1,43.1,70.4,34.1,67.0,29.5,56.5,49.2,49.1,52.3,35.9,50.0,33.3,41.7,41.6,23.8,33.6,22.7,28.9,25.0,22.0,30.4,22.3,33.2,27.6,39.9,20.0,44.2,21.3,41.9,13.7,48.7,15.3,55.5,11.8,60.0,11.7,59.4,19.2,61.1,22.3,65.9,16.6,74.2,17.1,78.0,21.3,84.1,32.3,91.1,33.6
step
    #completewith next
    .goto Sholazar Basin,50,50
    .zone Sholazar Basin >> Fly to Sholazar Basin
    .skill mining,425,1
step
    .skill mining,425 >> Level your Mining from 400-425 in Sholazar Basin
    .loop 20,Sholazar Basin,77.7,56.8,76.3,65.9,64.0,81.0,60.2,80.3,59.7,87.0,54.0,88.3,59.3,66.8,53.8,64.0,47.7,60.4,45.9,63.5,50.2,78.8,48.5,87.0,40.3,87.1,37.4,83.7,40.4,76.5,36.6,69.1,32.2,75.0,31.8,80.2,32.2,83.6,22.8,82.4,20.8,70.3,23.5,52.8,25.8,47.2,31.9,59.5,36.3,57.5,39.5,51.2,31.4,37.9,35.2,32.8,37.6,37.0,40.8,38.4,43.1,35.8,49.7,43.3,53.5,38.7,51.0,31.6,43.6,22.3,58.9,25.0,59.0,29.4,62.9,31.8,67.2,42.9,61.3,50.4,64.2,53.8,67.3,50.7,67.8,55.2,74.2,55.5,77.7,56.8
step
    #completewith next
    .goto Icecrown,50,50
    .zone Icecrown >> Fly to Icecrown
    .skill mining,450,1
step
    .skill nining,450 >> Level your Mining from 425-450 in Icecrown
    .loop 20, Icecrown,65.6,35.1,59.3,29.4,54.9,38.6,47.8,35.1,42.8,37.8,39.3,33.4,37.9,36.2,37.2,41.7,41.6,41.1,38.0,50.8,37.9,57.1,40.2,59.8,31.5,58.1,30.8,64.5,36.2,68.9,39.9,65.6,49.6,61.4,48.5,51.2,56.5,44.7,65.6,59.8,67.1,72.2,72.0,63.8,74.2,65.0,77.8,64.3,79.3,57.0,75.8,46.4,67.6,46.5,67.3,42.9,74.1,40.1,74.7,35.3,65.6,35.1
step
    +Congratulations on reaching skill level 450 in Mining!
]])

RXPGuides.RegisterGuide([[#version 9
#cata
#mop
#wotlk
#group RXP MoP 60-80 (A)
<< Alliance
#name 59-61 Hellfire Peninsula
#displayname 58-61 Hellfire Peninsula << !tbc !wotlk
#version 9
#next 61-63 Zangarmarsh
step << tbc
#xprate <1.5
#completewith honorhold
+As you quest through Outland, try to do as many group quests as you can, if you skip elite quests or dungeon quests you might have to grind about 1/3 of a level later after finishing Blade's Edge at level 66
step << tbc
#completwith next
.goto Stormwind City,66.28,62.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Nethergarde Keep >> Fly to Nethergarde Keep
.zoneskip Blasted Lands
.target Dungar Longdrink
step << !TBC
#completewith next
.goto Stormwind City,48.99,87.36
.zone Blasted Lands >> Take the portal from Stormwind to Blasted Lands
step << tbc/wotlk
.goto Blasted Lands,66.57,18.95,20,0
.goto Blasted Lands,67.57,19.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Ardalan|r up inside the tower
.accept 2783 >> Accept Petty Squabbles
.zoneskip Hellfire Peninsula
.target Ambassador Ardalan
step
.goto Blasted Lands,59.401,14.877
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bernie Heisten|r on the bottom floor
>>|cRXP_BUY_Buy a|r |T132791:0|t[|cRXP_LOOT_Nethergarde Bitter|r]
.collect 23848,1,9563,1 
.target Bernie Heisten
step << tbc/wotlk
.goto Swamp of Sorrows,34.28,66.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r on the border of Swamp of Sorrows
.turnin 2783 >> Turn in Petty Squabbles
.accept 2801 >> Accept A Tale of Sorrow
.complete 2801,1 
.skipgossip 7572,1
.zoneskip Hellfire Peninsula
.target Fallen Hero of the Horde
step << tbc/wotlk
.goto Swamp of Sorrows,34.28,66.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r on the border of Swamp of Sorrows
.turnin 2801 >> Turn in A Tale of Sorrow
.zoneskip Hellfire Peninsula
.target Fallen Hero of the Horde
step
#optional
.goto Blasted Lands,58.33,55.90 << tbc/wotlk
.goto 1419/0,-3196.90015,-11815.10059 << !tbc !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watch Commander Relthorn Netherwane|r outside the Dark Portal
.turnin -64038 >>Turn in The Dark Portal
.accept 10119 >> Accept Through the Dark Portal
.isOnQuest 64038
.target Watch Commander Relthorn Netherwane
step
.goto Blasted Lands,58.33,55.90 << tbc/wotlk
.goto 1419/0,-3196.90015,-11815.10059 << !tbc !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watch Commander Relthorn Netherwane|r outside the Dark Portal
.accept 10119 >> Accept Through the Dark Portal
.target Watch Commander Relthorn Netherwane
step
#completewith next
.goto Blasted Lands,55.024,54.221
.zone Hellfire Peninsula >> Go through the Dark Portal
step
.goto Hellfire Peninsula,87.32,50.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Duron|r
.turnin 10119 >> Turn in Through the Dark Portal
.accept 10288 >> Accept Arrival in Outland
.target Commander Duron
step
.goto Hellfire Peninsula,87.36,52.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amish Wildhammer|r
.turnin 10288 >> Turn in Arrival in Outland
.accept 10140 >> Accept Journey to Honor Hold
.target Amish Wildhammer
step
#completewith next
.goto Hellfire Peninsula,87.36,52.42
.gossip 18931,0 >>Talk to |cRXP_FRIENDLY_Amish Wildhammer|r to fly to Honor Hold
.skipgossip 18931,1
.target Amish Wildhammer
step
.goto Hellfire Peninsula,54.47,62.80,20,0
.goto Hellfire Peninsula,54.84,62.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Isildor|r
.turnin 10140 >> Turn in Journey to Honor Hold
.accept 10254 >> Accept Force Commander Danath
.target Marshal Isildor
step
#completewith next
.goto Hellfire Peninsula,54.81,63.61,15,0
.goto Hellfire Peninsula,54.67,63.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Isildor|r
.vendor >>|cRXP_BUY_Buy some gems from |cRXP_FRIENDLY_Markus Scylan|r for later quest gear rewards if you wish|r
.target Markus Scylan
step
#completewith HonorHS
.goto Hellfire Peninsula,54.22,63.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sid Limbardi|r
.home >> Set your Hearthstone to Honor Hold
>>Buy some of the new food/water if needed << !Warrior !Rogue !DK
>>Buy some of the new food if needed << Warrior/Rogue/DK
.target Sid Limbardi
step
.goto Hellfire Peninsula,56.37,65.99,20,0
.goto Hellfire Peninsula,56.61,66.77,14,0
.goto Hellfire Peninsula,56.64,66.70
>>Go inside the Keep to the top floor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r
.turnin 10254 >> Turn in Force Commander Danath
.accept 10160 >> Accept Know your Enemy
.accept 10141 >> Accept The Legion Reborn
.target Force Commander Danath Trollbane
step
>>Travel to the tower
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumphry|r and |cRXP_FRIENDLY_Amadi|r
.accept 10055 >> Accept Waste Not, Want Not
.goto Hellfire Peninsula,51.30,60.35,20,0
.goto Hellfire Peninsula,51.19,59.99,20,0
.goto Hellfire Peninsula,50.99,60.51
.target +Dumphry
.turnin 10160 >> Turn in Know your Enemy
.accept 10482 >> Accept Fel Orc Scavengers
.goto Hellfire Peninsula,50.91,60.19
.target +Lieutenant Amadi
step
#loop
.goto Hellfire Peninsula,54.53,54.12,50,0
.goto Hellfire Peninsula,54.23,52.51,50,0
.goto Hellfire Peninsula,55.53,53.32,50,0
.goto Hellfire Peninsula,57.07,53.05,50,0
.goto Hellfire Peninsula,57.62,51.67,50,0
.goto Hellfire Peninsula,58.55,52.43,50,0
.goto Hellfire Peninsula,59.54,51.80,50,0
.goto Hellfire Peninsula,62.09,50.91,50,0
.goto Hellfire Peninsula,54.53,54.12,50,0
.goto Hellfire Peninsula,54.53,54.12,0
>>Kill |cRXP_ENEMY_Bonechewers|r
>>Loot the |cRXP_PICK_Metal|r and |cRXP_PICK_Wood|r on the ground
>>|cRXP_WARN_Avoid|r |cRXP_ENEMY_Tagar Spinebreaker|r |cRXP_WARN_who is a level 61 elite that patrols the area|r
.complete 10482,1 
.mob +Bonechewer Mutant
.mob +Bonechewer Raider
.mob +Bonechewer Peon
.mob +Bonechewer Scavenger
.mob +Bonechewer Evoker
.mob +Bonechewer Orc
.complete 10055,1 
.complete 10055,2 
.unitscan Tagar Spinebreaker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumphry|r and |cRXP_FRIENDLY_Amadi|r
.turnin 10055 >> Turn in Waste Not, Want Not
.accept 10078 >> Accept Laying Waste to the Unwanted
.goto Hellfire Peninsula,51.30,60.35,20,0
.goto Hellfire Peninsula,51.19,59.99,20,0
.goto Hellfire Peninsula,50.99,60.51
.target +Dumphry
.turnin 10482 >> Turn in Fel Orc Scavengers
.accept 10483 >> Accept Ill Omens
.goto Hellfire Peninsula,50.91,60.19
.target +Lieutenant Amadi
step
>>Travel to the East Supply Caravan
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Altumus|r
.goto Hellfire Peninsula,61.74,60.67,15,0
.goto Hellfire Peninsula,61.69,60.90
.turnin 10141 >> Turn in The Legion Reborn
.accept 10142 >> Accept The Path of Anguish
.target Sergeant Altumus
step
#loop
.line Hellfire Peninsula,65.83,59.06,67.03,58.91,69.16,59.36,69.64,57.71,68.15,56.25,67.55,54.60,66.82,56.63,65.55,55.62,65.83,59.06
.goto Hellfire Peninsula,65.83,59.06,50,0
.goto Hellfire Peninsula,67.03,58.91,50,0
.goto Hellfire Peninsula,69.16,59.36,50,0
.goto Hellfire Peninsula,69.64,57.71,50,0
.goto Hellfire Peninsula,68.15,56.25,50,0
.goto Hellfire Peninsula,67.55,54.60,50,0
.goto Hellfire Peninsula,66.82,56.63,50,0
.goto Hellfire Peninsula,65.55,55.62,50,0
.goto Hellfire Peninsula,65.83,59.06,50,0
>>Kill a |cRXP_ENEMY_Dreadcaller|r, |cRXP_ENEMY_Flamewaker Imps|r and |cRXP_ENEMY_Infernal Warbringers|r
.complete 10142,1 
.mob +Dreadcaller
.complete 10142,2 
.mob +Flamewaker Imp
.complete 10142,3 
.mob +Infernal Warbringer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Altumus|r
.goto Hellfire Peninsula,61.74,60.67,15,0
.goto Hellfire Peninsula,61.69,60.90
.turnin 10142 >> Turn in The Path of Anguish
.accept 10143 >> Accept Expedition Point
.target Sergeant Altumus
step
.goto Hellfire Peninsula,67.88,66.92,50,0
.goto Hellfire Peninsula,70.53,68.13,50,0
.goto Hellfire Peninsula,70.79,71.38
>>Kill |cRXP_ENEMY_Bleeding Hollow Orcs|r. Loot them for a |cRXP_LOOT_Talisman|r
.complete 10483,1 
.mob Bleeding Hollow Dark Shaman
.mob Bleeding Hollow Grunt
.mob Bleeding Hollow Necrolyte
.mob Bleeding Hollow Tormentor
.mob Bleeding Hollow Peon
step
.goto 1944/530,1875.7,-702.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Corporal Ironridge|r
.target Corporal Ironridge
.turnin 10483 >>Turn in Ill Omens
.accept 10484 >>Accept Cursed Talismans
step
#label HonorHS
>>Travel to Expedition Point
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Kingston|r and |cRXP_FRIENDLY_Wing Commander Dabir'ee|r
.turnin 10143 >> Turn in Expedition Point
.accept 10144 >> Accept Disrupt Their Reinforcements
.goto Hellfire Peninsula,71.34,62.76
.target +Forward Commander Kingston
.accept 10895 >> Accept Zeth'Gor Must Burn!
.goto Hellfire Peninsula,71.41,62.48
.target +Wing Commander Dabir'ee
step
.goto Hellfire Peninsula,71.57,59.63,50,0
.goto Hellfire Peninsula,73.12,59.90,50,0
.goto Hellfire Peninsula,73.23,58.36
>>Kill |cRXP_ENEMY_Demons|r. Loot them for their |cRXP_LOOT_Rune Stones|r
.collect 28513,4,10144,1 
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
.goto Hellfire Peninsula,72.73,58.94
>>Click |cRXP_PICK_Portal Kaalez|r to disrupt it
.complete 10144,2 
step << skip
.goto Hellfire Peninsula,71.80,52.87,50,0
.goto Hellfire Peninsula,70.83,55.36,50,0
.goto Hellfire Peninsula,72.05,55.28,50,0
.goto Hellfire Peninsula,71.57,59.63,50,0
.goto Hellfire Peninsula,73.12,59.90,50,0
.goto Hellfire Peninsula,73.23,58.36
>>Kill |cRXP_ENEMY_Demons|r. Loot them for their |cRXP_LOOT_Rune Stones|r
.collect 28513,4 
.isOnQuest 10144
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
.goto Hellfire Peninsula,71.49,55.17
>>Kill |cRXP_ENEMY_Demons|r. Loot them for |cRXP_LOOT_Rune Stones|r. Then click |cRXP_PICK_Portal Grimh|r to disrupt it
.collect 28513,4,10144,1,-1 
.complete 10144,1 
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
#label Disrupt
.goto Hellfire Peninsula,71.34,62.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Kingston|r
.turnin 10144 >> Turn in Disrupt Their Reinforcements
.accept 10146 >> Accept Mission: The Murketh and Shaadraz Gateways
.target Forward Commander Kingston
step
#completewith next
.goto Hellfire Peninsula,71.41,62.48
.fly >> |Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Dabir'ee|r to start the bombing run
.skipgossip 19409,1
.timer 102,Mission: Gateways Flight
.target Wing Commander Dabir'ee
step
.use 28038 >>|cRXP_WARN_Use the|r |T133712:0|t[Seaforium PU-36 Explosive Nether Modulator] |cRXP_WARN_on |cRXP_PICK_Gateway Shaadraz|r and |cRXP_PICK_Gateway Murketh|r during the flight|r
.complete 10146,2 
.goto Hellfire Peninsula,77.73,51.80,-1
.complete 10146,1 
.goto Hellfire Peninsula,78.00,47.24,-1
step
.goto Hellfire Peninsula,71.34,62.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Kingston|r
.turnin 10146 >> Turn in Mission: The Murketh and Shaadraz Gateways
.accept 10340 >> Accept Shatter Point
.target Forward Commander Kingston
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Bleeding Hollow Orcs|r. Loot them for their |cRXP_LOOT_Talismans|r
.complete 10484,1 
.mob Bleeding Hollow Dark Shaman
.mob Bleeding Hollow Grunt
.mob Bleeding Hollow Necrolyte
.mob Bleeding Hollow Tormentor
.mob Bleeding Hollow Peon
.mob Worg Master Kruush
step
.use 31739 >>|cRXP_WARN_Use the|r |T132622:0|t[Smoke Beacon] |cRXP_WARN_on the four Towers|r
.complete 10895,3 
.goto Hellfire Peninsula,70.05,69.11
.complete 10895,4 
.goto Hellfire Peninsula,70.86,71.35
.complete 10895,2 
.goto Hellfire Peninsula,66.45,76.47
.complete 10895,1 
.goto Hellfire Peninsula,67.95,66.87
step
#loop
.line Hellfire Peninsula,68.13,69.69,69.16,69.29,70.05,69.12,70.85,71.32,68.88,72.50,69.44,75.37,69.10,76.55,68.58,75.71,66.44,76.44,68.13,69.69
.goto Hellfire Peninsula,68.13,69.69,50,0
.goto Hellfire Peninsula,69.16,69.29,50,0
.goto Hellfire Peninsula,70.05,69.12,50,0
.goto Hellfire Peninsula,70.85,71.32,50,0
.goto Hellfire Peninsula,68.88,72.50,50,0
.goto Hellfire Peninsula,69.44,75.37,50,0
.goto Hellfire Peninsula,69.10,76.55,50,0
.goto Hellfire Peninsula,68.58,75.71,50,0
.goto Hellfire Peninsula,66.44,76.44,50,0
.goto Hellfire Peninsula,68.13,69.69,50,0
>>Kill |cRXP_ENEMY_Bleeding Hollow Orcs|r. Loot them for their |cRXP_LOOT_Talismans|r
.complete 10484,1 
.mob Bleeding Hollow Dark Shaman
.mob Bleeding Hollow Grunt
.mob Bleeding Hollow Necrolyte
.mob Bleeding Hollow Tormentor
.mob Bleeding Hollow Peon
.mob Worg Master Kruush
step
.goto Hellfire Peninsula,70.97,63.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Corporal Ironridge|r
.turnin 10484 >> Turn in Cursed Talismans
.accept 10485 >> Accept Warlord of the Bleeding Hollow
.target Corporal Ironridge
step
.goto Hellfire Peninsula,71.41,62.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Dabir'ee|r
.turnin 10895 >> Turn in Zeth'Gor Must Burn!
.target Wing Commander Dabir'ee
step
.goto Hellfire Peninsula,69.65,76.48,15,0
.goto Hellfire Peninsula,70.47,76.15,15,0
.goto Hellfire Peninsula,70.08,77.08
>>Enter the Stronghold
>>Kill |cRXP_ENEMY_Warlord Morkh|r. Loot him for his |cRXP_LOOT_Armor|r
.complete 10485,1 
.mob Warlord Morkh
step
.goto Hellfire Peninsula,70.97,63.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Corporal Ironridge|r
.turnin 10485 >> Turn in Warlord of the Bleeding Hollow
.accept 10903 >> Accept Return to Honor Hold
.target Corporal Ironridge
step
#completewith next
.goto Hellfire Peninsula,71.41,62.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Dabir'ee|r
.gossip 19409,0 >> Fly to Shatter Point
.skipgossip 19409,1
.timer 56,Shatter Point Flight
.target Wing Commander Dabir'ee
step
.goto Hellfire Peninsula,78.42,34.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Runetog Wildhammer|r
.target Runetog Wildhammer
.turnin 10340 >>Turn in Shatter Point
.accept 10344 >>Accept Wing Commander Gryphongar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Gryphongar|r
.goto Hellfire Peninsula,79.34,33.86
.turnin 10344 >> Turn in Wing Commander Gryphongar
.accept 10163 >> Accept Mission: The Abyssal Shelf
.target Wing Commander Gryphongar
step
#completewith next
.goto Hellfire Peninsula,78.25,34.45
.gossip 20235,0 >>Talk to |cRXP_FRIENDLY_Gryphoneer Windbellow|r to fly to the Abyssal Shelf. If you don't kill everything after the first flight, talk to her again
.timer 154,Mission: The Abyssal Shelf Flight
.skipgossip 20235,1
.target Gryphoneer Windbellow
step
.goto Hellfire Peninsula,72.21,23.78,-1
.goto Hellfire Peninsula,72.60,19.99,-1
.goto Hellfire Peninsula,73.04,15.18,-1
.goto Hellfire Peninsula,72.69,11.19,-1
.use 28132 >>|cRXP_WARN_Use the|r |T133709:0|t[Area 52 Special] |cRXP_WARN_on the |cRXP_ENEMY_Gan'arg Peons|r, |cRXP_ENEMY_Mo'arg Overseers|r and |cRXP_ENEMY_Fel Cannons|r during the flight|r
.complete 10163,1 
.mob +Gan'arg Peon
.complete 10163,2 
.mob +Mo'arg Overseer
.complete 10163,3 
.mob +Fel Cannon
step
.goto Hellfire Peninsula,79.34,33.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Gryphongar|r
.turnin 10163 >> Turn in Mission: The Abyssal Shelf
.accept 10382 >> Accept Go to the Front
.target Wing Commander Gryphongar
step
#completewith next
.goto Hellfire Peninsula,78.25,34.45
.gossip 20235,0 >>Talk to |cRXP_FRIENDLY_Gryphoneer Windbellow|r to fly to Honor Point
.skipgossip 20235,1
.timer 40,Honor Point Flight
.target Gryphoneer Windbellow
step
.goto Hellfire Peninsula,68.29,28.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Marshal Brock|r
.turnin 10382 >> Turn in Go to the Front
.accept 10394 >> Accept Disruption - Forge Camp: Mageddon
.target Field Marshal Brock
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Gan'arg Servants|r
.complete 10394,1 
.mob Gan'arg Servant
step
#loop
.goto Hellfire Peninsula,65.55,32.56,40,0
.goto Hellfire Peninsula,65.06,31.45,40,0
.goto Hellfire Peninsula,64.53,32.48,40,0
.goto Hellfire Peninsula,64.14,31.94,40,0
.goto Hellfire Peninsula,64.16,30.67,40,0
.goto Hellfire Peninsula,65.42,29.81,40,0
.goto Hellfire Peninsula,66.06,31.33,40,0
.goto Hellfire Peninsula,65.55,32.56,40,0
.line Hellfire Peninsula,65.55,32.56,65.06,31.45,64.53,32.48,64.14,31.94,64.16,30.67,65.42,29.81,66.06,31.33,65.55,32.56
>>Kill |cRXP_ENEMY_Razorsaw|r
>>|cRXP_ENEMY_Razorsaw|r |cRXP_WARN_patrols counter-clockwise around the camp|r
.complete 10394,2 
.unitscan Razorsaw
step
#loop
.goto Hellfire Peninsula,63.50,31.00,50,0
.goto Hellfire Peninsula,64.32,33.31,50,0
.goto Hellfire Peninsula,65.88,32.45,50,0
.goto Hellfire Peninsula,66.09,30.07,50,0
.goto Hellfire Peninsula,59.62,32.39,50,0
.goto Hellfire Peninsula,58.07,32.87,50,0
.goto Hellfire Peninsula,58.07,32.87,0
>>Kill |cRXP_ENEMY_Gan'arg Servants|r
.complete 10394,1 
.mob Gan'arg Servant
step
.goto Hellfire Peninsula,68.29,28.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Marshal Brock|r
.turnin 10394 >> Turn in Disruption - Forge Camp: Mageddon
.accept 10396 >> Accept Enemy of my Enemy...
.target Field Marshal Brock
step
#loop
.goto Hellfire Peninsula,66.57,32.01,50,0
.goto Hellfire Peninsula,65.48,33.49,50,0
.goto Hellfire Peninsula,64.53,33.17,50,0
.goto Hellfire Peninsula,64.10,33.47,50,0
.goto Hellfire Peninsula,63.40,32.49,50,0
.goto Hellfire Peninsula,63.51,31.06,50,0
.goto Hellfire Peninsula,63.51,31.06,0
>>Kill |cRXP_ENEMY_Fel Cannon MKIs|r
.complete 10396,1 
.mob Fel Cannon MKI
step
.goto Hellfire Peninsula,68.29,28.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Marshal Brock|r
.turnin 10396 >> Turn in Enemy of my Enemy...
.accept 10397 >> Accept Invasion Point: Annihilator
.target Field Marshal Brock
step
.goto Hellfire Peninsula,53.09,26.46
>>Kill |cRXP_ENEMY_Arix'Amal|r. Loot him for the |cRXP_LOOT_Burning Legion Gate Key|r and the |T133473:0|t[|cRXP_LOOT_Burning Legion Missive|r]
.use 29588 >>|cRXP_WARN_Use the|r |T133473:0|t[|cRXP_LOOT_Burning Legion Missive|r] |cRXP_WARN_to start the quest|r
.complete 10397,1 
.complete 10397,3 
.collect 29588,1,10395 
.accept 10395 >> Accept The Dark Missive
.unitscan Warbringer Arix'Amal
step
.goto Hellfire Peninsula,53.04,27.71
>>Click the |cRXP_PICK_Rune of Spite|r inside the Gate
.complete 10397,2 
step
.goto Hellfire Peninsula,68.29,28.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Marshal Brock|r
.turnin 10397 >> Turn in Invasion Point: Annihilator
.target Field Marshal Brock
step
#completewith next
.goto Hellfire Peninsula,68.65,28.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphoneer Leafbeard|r
.fly Shatter >> Fly to Shatter Point
.cooldown item,6948,<0
.skipgossip
.timer 31,Shatter Point Flight
.target Gryphoneer Leafbeard
step
.goto Hellfire Peninsula,78.19,34.34,5 >> Return to Shatter Point
.isOnQuest 10395
.cooldown item,6948,<0
step
#completewith next
.goto Hellfire Peninsula,78.42,34.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Runetog Wildhammer|r
.fly Honor Hold >> Fly to Honor Hold
.cooldown item,6948,<0
.target Runetog Wildhammer
step
#completewith next
.hs >> Hearth to Honor Hold
.cooldown item,6948,>2
step
.goto 1944/530,2736.60010,-708.29999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Father Malgor Devidicus|r
.target Father Malgor Devidicus
.accept 10058 >>Accept An Old Gift
step
.goto Hellfire Peninsula,54.27,63.17,8,0
.goto Hellfire Peninsula,54.32,63.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Assistant Klatu|r upstairs
.turnin 10903 >> Turn in Return to Honor Hold
.accept 10909 >> Accept Fel Spirits
.accept 10916 >> Accept Digging for Prayer Beads
.target Assistant Klatu
step
.goto Hellfire Peninsula,54.63,63.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hama|r on the second floor of the Inn
>>|cRXP_BUY_Buy a|r |T132906:0|t[Silken Thread]|cRXP_BUY_. You may need this to progress a quest later|r
.collect 4291,1,10916,1 
.isOnQuest 10916
.target Hama
step
.goto Hellfire Peninsula,56.37,65.99,20,0
.goto Hellfire Peninsula,56.61,66.77,14,0
.goto Hellfire Peninsula,56.70,66.52
>>Go inside the Keep to the top floor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warp-Scryer Kryv|r
.target Warp-Scryer Kryv
.turnin 10395 >>Turn in The Dark Missive
.accept 10399 >>Accept The Heart of Darkness
.accept 10047 >>Accept The Path of Glory
step
.goto Hellfire Peninsula,56.64,66.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r
.target Force Commander Danath Trollbane
.accept 10400 >>Accept Overlord
step
#completewith treat
#label Beads1
.goto Hellfire Peninsula,54.16,63.32,3,0
.goto Hellfire Peninsula,54.16,63.32,0
>>Loot the |cRXP_PICK_Dirt Mound|r outside the Inn for the |cRXP_LOOT_Prayer Beads|r
>>|cRXP_WARN_The |cRXP_PICK_Dirt Mound|r will despawn on server restart, if you're unlucky, you'll have to give |cRXP_FRIENDLY_Fei Fei|r a treat|r
.complete 10916,1 
step
#completewith Beads1
#label DTreat
>>|cRXP_WARN_If the |cRXP_PICK_Dirt Mound|r is not there:|r
>>|cRXP_BUY_Buy a|r |T132165:0|t[Fei Fei Doggy Treat] |cRXP_BUY_from|r |cRXP_FRIENDLY_Warrant Officer Tracy Proudwell|r
.goto Hellfire Peninsula,56.33,62.84
.collect 31799,1,10916,1 
.isOnQuest 10916
.target Warrant Officer Tracy Proudwell
step
#completewith next
#label treat
#requires DTreat
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fei Fei|r
.goto Hellfire Peninsula,56.39,62.90
.turnin 10919 >> Turn in Fei Fei's Treat
.timer 120,Fei Fei RP
.isOnQuest 10916
.target Fei Fei
step << skip
#completewith next
.goto Hellfire Peninsula,50.87,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honor Guard Wesilow|r. You can do this while waiting for |cRXP_FRIENDLY_Fei Fei|r
.accept 10050 >> Accept Unyielding Souls
.target Honor Guard Wesilow
step
#completewith next
#requires DTreat
.goto Hellfire Peninsula,54.16,63.32,0
>>|cRXP_FRIENDLY_Fei Fei|r will dig up the |cRXP_PICK_Dirt Mound|r containing the |cRXP_LOOT_Prayer Beads|r after a couple minutes.
>>|cRXP_WARN_You don't need to wait for the full RP, you will come back for this quest later|r
.complete 10916,1 
.isOnQuest 10916
.target Fei Fei
step
.goto Hellfire Peninsula,50.87,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honor Guard Wesilow|r
.accept 10050 >> Accept Unyielding Souls
.target Honor Guard Wesilow
step
.goto Hellfire Peninsula,52.02,62.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Biggums|r
.accept 9355 >> Accept A Job for an Intelligent Man
.accept 10079 >> Accept When This Mine's a-Rockin'
.target Foreman Biggums
step
.goto Hellfire Peninsula,52.38,62.35,20,0
.goto Hellfire Peninsula,54.17,64.51,15,0
.goto Hellfire Peninsula,56.17,62.31
>>Kill |cRXP_ENEMY_Gan'arg Sappers|r inside the Mine
.complete 10079,1 
.mob Gan'arg Sapper
step
.goto Hellfire Peninsula,52.02,62.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Biggums|r
.turnin 10079 >> Turn in When This Mine's a-Rockin'
.accept 10099 >> Accept The Mastermind
.target Foreman Biggums
step
.goto Hellfire Peninsula,52.38,62.35,20,0
.goto Hellfire Peninsula,54.17,64.51,15,0
.goto Hellfire Peninsula,56.28,61.30
>>Kill |cRXP_ENEMY_Z'kral|r at the end of the Mine
.complete 10099,1 
.mob Z'kral
step
.goto Hellfire Peninsula,52.02,62.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Biggums|r
.turnin 10099 >> Turn in The Mastermind
.target Foreman Biggums
step
#loop
.line Hellfire Peninsula,51.42,63.90,48.95,64.85,47.09,63.73,45.95,65.21,47.26,65.97,48.19,66.40,48.28,68.19,49.73,67.25,51.42,63.90
.goto Hellfire Peninsula,51.42,63.90,55,0
.goto Hellfire Peninsula,48.95,64.85,55,0
.goto Hellfire Peninsula,47.09,63.73,55,0
.goto Hellfire Peninsula,45.95,65.21,55,0
.goto Hellfire Peninsula,47.26,65.97,55,0
.goto Hellfire Peninsula,48.19,66.40,55,0
.goto Hellfire Peninsula,48.28,68.19,55,0
.goto Hellfire Peninsula,49.73,67.25,55,0
.goto Hellfire Peninsula,51.42,63.90,55,0
.use 23338 >>Kill |cRXP_ENEMY_Marauding Crust Bursters|r by running over the moving rocks. Loot them for an |T133651:0|t[|cRXP_LOOT_Eroded Leather Case|r]
>>|cRXP_WARN_Use the|r |T133651:0|t[|cRXP_LOOT_Eroded Leather Case|r] |cRXP_WARN_to start the quest|r
.complete 9355,1 
.collect 23338,1,9373,1 
.accept 9373 >> Accept Missing Missive
.mob Marauding Crust Burster
step
#questguide << !tbc
#xprate <1.5 << tbc
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Legassi|r and |cRXP_FRIENDLY_"Screaming" Screed Luckheed|r
.accept 9349 >> Accept Ravager Egg Roundup
.target +Legassi
.goto Hellfire Peninsula,49.24,74.83
.accept 10161 >> Accept In Case of Emergency...
.target +"Screaming" Screed Luckheed
.goto Hellfire Peninsula,49.15,74.87
step
#xprate >1.499 << TBC
.goto Hellfire Peninsula,49.24,74.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Legassi|r
.accept 9349 >> Accept Ravager Egg Roundup
.target Legassi
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Unyielding Footmen|r, |cRXP_ENEMY_Unyielding Sorcerers|r and |cRXP_ENEMY_Unyielding Knights|r
.complete 10050,1 
.mob +Unyielding Footman
.complete 10050,2 
.mob +Unyielding Sorcerer
.complete 10050,3 
.mob +Unyielding Knight
step
.goto Hellfire Peninsula,54.96,86.82
>>Loot the |cRXP_PICK_Mysteries of the Light|r book on the ground
.complete 10058,1 
step
>>Kill |cRXP_ENEMY_Unyielding Footmen|r, |cRXP_ENEMY_Unyielding Sorcerers|r and |cRXP_ENEMY_Unyielding Knights|r
.complete 10050,1 
.goto Hellfire Peninsula,58.50,79.42,50,0
.goto Hellfire Peninsula,58.54,77.36,50,0
.goto Hellfire Peninsula,57.70,75.28,50,0
.goto Hellfire Peninsula,56.70,74.36,50,0
.goto Hellfire Peninsula,55.59,79.20
.mob +Unyielding Footman
.complete 10050,2 
.goto Hellfire Peninsula,55.89,79.86,50,0
.goto Hellfire Peninsula,55.47,81.52,50,0
.goto Hellfire Peninsula,54.45,81.43,50,0
.goto Hellfire Peninsula,54.21,79.08,50,0
.goto Hellfire Peninsula,55.11,79.59
.mob +Unyielding Sorcerer
.complete 10050,3 
.goto Hellfire Peninsula,56.44,77.81,50,0
.goto Hellfire Peninsula,54.57,78.22,50,0
.goto Hellfire Peninsula,53.58,85.16,50,0
.goto Hellfire Peninsula,55.25,85.59
.mob +Unyielding Knight
step
.goto Hellfire Peninsula,41.83,85.16,50,0
.goto Hellfire Peninsula,40.37,87.33,50,0
.goto Hellfire Peninsula,38.42,88.82,50,0
.goto Hellfire Peninsula,36.72,88.50,50,0
.goto Hellfire Peninsula,36.88,91.36,50,0
.goto Hellfire Peninsula,32.54,93.32
>>Kill |cRXP_ENEMY_Razorfang Ravagers|r. Loot them for their |cRXP_LOOT_Ravager Eggs|r
>>You can also find |cRXP_LOOT_Ravager Eggs|r on the ground
.complete 9349,1 
.mob Razorfang Ravager
step << tbc/wotlk
#completewith next
.goto Shattrath City,64.05,41.12
>>Travel to Shattrath City
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r
.fp Shattrath >> Get the Shattrath flight path
.target Nutral
step << Mage (tbc/wotlk)
#completewith next
.zone Stormwind City >> Teleport to Stormwind
step << (Warlock/Shaman/Paladin) (tbc/wotlk)
.goto Shattrath City,55.7,36.9
.zone Stormwind City >> Take the portal to Stormwind
step << (Warlock/Shaman/Paladin/Mage) (tbc/wotlk)
.goto StormwindClassic,25.3,78.7 << Warlock
.goto StormwindClassic,38.6,32.8 << Paladin
.goto StormwindClassic,61.9,84.0 << Shaman
.goto StormwindClassic,39.6,79.6 << Mage
.trainer >> Train your class spells << cata
.target Ursula Deline << Warlock
.target Demisette Cloyce << Warlock
.target Sandahl << Warlock
.target Arthur the Faithful << Paladin
.target Katherine the Pure << Paladin
.target Lord Grayson Shadowbreaker << Paladin
.target Farseer Umbrua << Shaman
.target Elsharin << Mage
.target Jennea Cannon << Mage
step << Mage (tbc/wotlk)
#completewith next
.zone Darnassus >> Teleport to Darnassus
.isOnQuest 4986
step << (Warrior/Hunter/Rogue/Priest/Druid) (tbc/wotlk)
#completewith next
.goto Shattrath City,55.2,36.5
.zone Darnassus >> Take the portal to Darnassus
step << (Warrior/Hunter/Rogue/Priest) (tbc/wotlk)
.goto Darnassus,39.0,83.2 << Priest
.goto Darnassus,40.6,9.2 << Hunter
.goto Darnassus,31.5,17.4 << Rogue
.goto Darnassus,58.75,35.16 << Warrior
.trainer >> Train your class spells << cata
.target Jandria << Priest
.target Jocaste << Hunter
.target Anishar << Rogue
.target Erion Shadewhisper << Rogue
.target Syurna << Rogue
.target Arias'ta Bladesinger << Warrior
step << (Warrior/Hunter/Rogue/Priest/Druid/Mage) (tbc/wotlk)
.turnin 4986 >> Turn in Glyphed Oaken Branch
.goto Darnassus,35.2,8.1
.isOnQuest 4986
.target Mathrengyl Bearwalker
step << (NightElf/Draenei) (tbc/wotlk)
#optional
#completewith next
.goto Darnassus,29.10,41.22,15,0
.goto Teldrassil,55.93,89.74,30 >> Go through the purple portal to Teldrassil
step << (NightElf/Draenei) (tbc/wotlk)
.goto Teldrassil,55.50,92.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Erelas Ambersky|r
.turnin 978 >> Turn in Moontouched Wildkin
.isOnQuest 978
.target Erelas Ambersky
step << Druid
>>Teleport to Moonglade
.goto Moonglade,52.4,40.6
.trainer 12042 >> Train your class spells << cata
.target Loganaar << Druid
step
#completewith next
.hs >> Hearth back to Honor Hold
.cooldown item,6948,>2
step
.goto Hellfire Peninsula,54.29,63.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Father Malgor Devidicus|r
.turnin 10058 >> Turn in An Old Gift
.target Father Malgor Devidicus
step
.goto 1944/530,2910.0,-595.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honor Guard Wesilow|r
.target Honor Guard Wesilow
.turnin 10050 >>Turn in Unyielding Souls
.accept 10057 >>Accept Looking to the Leadership
step
.goto 1944/530,2854.7,-669.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Biggums|r
.target Foreman Biggums
.turnin 9355 >>Turn in A Job for an Intelligent Man
step
.goto Hellfire Peninsula,44.82,75.34
.use 31772 >>|cRXP_WARN_Use the|r |T134423:0|t[Anchorite Relic]
>>Kill the |cRXP_ENEMY_Shattered Hand Berserkers|r targeted by the |T134423:0|t[Anchorite Relic]
>>Kill the |cRXP_ENEMY_Fel Spirits|r that spawn afterwards
.complete 10909,1 
.mob Shattered Hand Berserker
.mob Fel Spirit
step
.goto Hellfire Peninsula,49.24,74.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Legassi|r
.turnin 9349 >> Turn in Ravager Egg Roundup
.accept 9361 >> Accept Helboar, the Other White Meat
.target Legassi
step
#optional
#questguide << !tbc
#xprate <1.5 << tbc
#completewith BuzWing
>>Loot the |cRXP_PICK_Zeppelin Debris|r on the ground
.complete 10161,1 
step
#loop
.line Hellfire Peninsula,46.10,71.85,45.11,71.84,45.39,70.17,46.89,68.32,50.01,64.14,52.83,70.37,46.10,71.85
.goto Hellfire Peninsula,46.10,71.85,55,0
.goto Hellfire Peninsula,45.11,71.84,55,0
.goto Hellfire Peninsula,45.39,70.17,55,0
.goto Hellfire Peninsula,46.89,68.32,55,0
.goto Hellfire Peninsula,50.01,64.14,55,0
.goto Hellfire Peninsula,52.83,70.37,55,0
.goto Hellfire Peninsula,46.10,71.85,55,0
>>Kill |cRXP_ENEMY_Deranged Helboars|r. Loot them for their |cRXP_LOOT_Tainted Meat|r
.use 23268 >>|cRXP_WARN_Use the|r |T134720:0|t[Purification Mixture] |cRXP_WARN_to convert the |cRXP_LOOT_Tainted Meat|r into|r |cRXP_LOOT_Purified Helboar Meat|r
.collect 23270,8,9361,1,-1
.complete 9361,1 
.mob Deranged Helboar
step
.goto Hellfire Peninsula,49.24,74.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Legassi|r
.turnin 9361 >> Turn in Helboar, the Other White Meat
.accept 9356 >> Accept Smooth as Butter
.target Legassi
step
>>Kill |cRXP_ENEMY_Arch Mage Xintor|r and |cRXP_ENEMY_Commander Thalvos|r
.complete 10057,1 
.mob +Arch Mage Xintor
.goto Hellfire Peninsula,53.67,81.10
.complete 10057,2 
.mob +Lieutenant Commander Thalvos
.goto Hellfire Peninsula,54.75,83.71
step
#label BuzWing
#loop
.line Hellfire Peninsula,57.50,72.75,58.66,69.95,62.44,69.12,64.18,66.08,65.00,64.65,65.95,62.08,62.47,65.22,61.12,66.85,57.71,69.65,57.50,72.75
.goto Hellfire Peninsula,57.50,72.75,55,0
.goto Hellfire Peninsula,58.66,69.95,55,0
.goto Hellfire Peninsula,62.44,69.12,55,0
.goto Hellfire Peninsula,64.18,66.08,55,0
.goto Hellfire Peninsula,65.00,64.65,55,0
.goto Hellfire Peninsula,65.95,62.08,55,0
.goto Hellfire Peninsula,62.47,65.22,55,0
.goto Hellfire Peninsula,61.12,66.85,55,0
.goto Hellfire Peninsula,57.71,69.65,55,0
.goto Hellfire Peninsula,57.50,72.75,55,0
>>Kill |cRXP_ENEMY_Bonestripper Buzzards|r. Loot them for their |cRXP_LOOT_Wings|r
.complete 9356,1 
.mob Bonestripper Buzzard
step
#questguide << !tbc
#xprate <1.5 << tbc
#loop
.line Hellfire Peninsula,57.50,72.75,58.66,69.95,62.44,69.12,64.18,66.08,65.00,64.65,65.95,62.08,62.47,65.22,61.12,66.85,57.71,69.65,57.50,72.75
.goto Hellfire Peninsula,57.50,72.75,55,0
.goto Hellfire Peninsula,58.66,69.95,55,0
.goto Hellfire Peninsula,62.44,69.12,55,0
.goto Hellfire Peninsula,64.18,66.08,55,0
.goto Hellfire Peninsula,65.00,64.65,55,0
.goto Hellfire Peninsula,65.95,62.08,55,0
.goto Hellfire Peninsula,62.47,65.22,55,0
.goto Hellfire Peninsula,61.12,66.85,55,0
.goto Hellfire Peninsula,57.71,69.65,55,0
.goto Hellfire Peninsula,57.50,72.75,55,0
>>Loot the |cRXP_LOOT_Zeppelin Debris|r on the ground
.complete 10161,1 
step << Shaman
#completewith prayerbeads1
.hs >> Hearth to Honor Hold
step
.goto Hellfire Peninsula,54.16,63.32
>>Loot the |cRXP_PICK_Dirt Mound|r outside the Inn for the |cRXP_LOOT_Prayer Beads|r
>>|cRXP_WARN_The |cRXP_PICK_Dirt Mound|r will despawn on server restart, if you got unlucky, you'll have to give |cRXP_FRIENDLY_Fei Fei|r a treat|r
.complete 10916,1 
step
#label prayerbeads1
.goto Hellfire Peninsula,54.27,63.17,8,0
.goto Hellfire Peninsula,54.32,63.65
>>Return to Honor Hold. Go to the second floor of the Inn
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Assistant Klatu|r
.turnin 10909 >> Turn in Fel Spirits
.turnin 10916 >> Turn in Digging for Prayer Beads
.accept 10935 >> Accept The Exorcism of Colonel Jules
.target Assistant Klatu
step
#completewith next
.goto 1944/530,2754.11,-707.211
.gossip 22431,0 >> Talk to |cRXP_FRIENDLY_Anchorite Barada|r in the bedroom to start the exorcism
.skipgossip 22431,1
.target Anchorite Barada
.timer 215,Colonel Jules RP
step
.goto 1944/530,2754.36,-710.211
.use 31828 >>|cRXP_WARN_Use the|r |T133290:0|t[Ritual Prayer Beads] |cRXP_WARN_to instantly kill the spirits that spawn|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Colonel Jules|r once the RP finishes
.complete 10935,1 
.skipgossip 22431,1
.skipgossip 22432,1
.target Colonel Jules
step
.goto Hellfire Peninsula,54.32,63.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Assistant Klatu|r
.turnin 10935 >> Turn in The Exorcism of Colonel Jules
.accept 10936 >> Accept Trollbane is Looking for You
.target Assistant Klatu
step
.goto 1944/530,2736.10010,-707.29999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sid Limbardi|r
.target Sid Limbardi
.accept 9558 >>Accept The Longbeards
step
.goto Hellfire Peninsula,56.37,65.99,20,0
.goto Hellfire Peninsula,56.61,66.77,14,0
>>Go inside the Keep to the top floor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r
.turnin 10936 >> Turn in Trollbane is Looking for You
.accept 10937 >> Accept Drill the Drillmaster
.goto Hellfire Peninsula,56.64,66.70
.target Force Commander Danath Trollbane
step
.goto Hellfire Peninsula,50.87,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honor Guard Wesilow|r
.turnin 10057 >> Turn in Looking to the Leadership
.target Honor Guard Wesilow
step
.goto Hellfire Peninsula,48.07,56.17
>>Kill |cRXP_ENEMY_Drillmaster Zurok|r
>>|cRXP_WARN_Use your pet to pull him from down out of the pit, then kite him back to Honor Hold and have the guards help you|r << (tbc/wotlk) (Hunter/Warlock/DK)
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc
.complete 10937,1 
.isOnQuest 10937
.mob Drillmaster Zurok
step
.goto Hellfire Peninsula,49.63,52.08,50,0
.goto Hellfire Peninsula,52.70,50.73,50,0
.goto Hellfire Peninsula,63.42,49.34,50,0
.goto Hellfire Peninsula,52.70,50.73
>>Click the |cRXP_PICK_Trampled Skeleton|r corpses along the path
.complete 10047,1 
step
.use 26002 >>|cRXP_WARN_Use the|r |T135432:0|t[Flaming Torch] |cRXP_WARN_on the Catapults|r
.complete 10078,1 
.goto Hellfire Peninsula,58.50,47.64,-1
.complete 10078,2 
.goto Hellfire Peninsula,55.70,47.48,-1
.complete 10078,3 
.goto Hellfire Peninsula,53.55,48.24,-1
.complete 10078,4 
.goto Hellfire Peninsula,52.64,48.01,-1
step
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r outside Thrallmar Mine
.accept 10236 >> Accept Outland Sucks!
.target Foreman Razelcraz
step
.goto Hellfire Peninsula,49.02,37.63,50,0
.goto Hellfire Peninsula,47.98,37.39,50,0
.goto Hellfire Peninsula,48.41,40.86,50,0
.goto Hellfire Peninsula,47.28,42.34,50,0
.goto Hellfire Peninsula,47.17,43.74,50,0
.goto Hellfire Peninsula,48.85,35.37,50,0
.goto Hellfire Peninsula,47.28,42.34
>>Loot the |cRXP_PICK_Shredder Parts|r boxes on the ground
.complete 10236,1 
step
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10236 >> Turn in Outland Sucks!
.accept 10238 >> Accept How to Serve Goblins
.target Foreman Razelcraz
step
>>Free |cRXP_FRIENDLY_Manni|r, |cRXP_FRIENDLY_Moh|r and |cRXP_FRIENDLY_Jakk|r from the cages
.complete 10238,1 
.target +Manni
.goto Hellfire Peninsula,45.12,41.11
.complete 10238,2 
.target +Moh
.goto Hellfire Peninsula,46.42,45.18
.complete 10238,3 
.target +Jakk
.goto Hellfire Peninsula,47.50,46.63
step
#questguide << !tbc
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10238 >> Turn in How to Serve Goblins
.accept 10629 >> Accept Shizz Work
.target Foreman Razelcraz
step
#questguide << !tbc
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10238 >> Turn in How to Serve Goblins
.accept 10629 >> Accept Shizz Work
.target Foreman Razelcraz
step
#questguide << !tbc
.goto Hellfire Peninsula,51.37,30.52
#completewith next
.cast 37690 >> |cRXP_WARN_Use the|r |T133942:0|t[Felhound Whistle] |cRXP_WARN_whilst beside |cRXP_FRIENDLY_Foreman Razelcraz|r to summon a|r |cRXP_FRIENDLY_Felhound|r
.use 30803
step
#questguide << !tbc
.goto Hellfire Peninsula,50.7,28.9
>>Kill |cRXP_ENEMY_Deranged Helboars|r. Loot the |cRXP_LOOT_Droppings|r after the |cRXP_FRIENDLY_Felhound's RP|r for the |cRXP_PICK_Shredder Keys|r
.complete 10629,1 
.use 30803
.mob Deranged Helboar
step
#questguide << !tbc
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10629 >> Turn in Shizz Work
.accept 10630 >> Accept Beneath Thrallmar
.target Foreman Razelcraz
step
#questguide << !tbc
.goto Hellfire Peninsula,51.72,31.68,20,0
.goto Hellfire Peninsula,52.57,30.59,20,0
.goto Hellfire Peninsula,54.39,31.57
>>Kill |cRXP_ENEMY_Urga'zz|r in the back of Thrallmar Mine
.complete 10630,1 
.mob Urga'zz
step
#questguide << !tbc
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10630 >> Turn in Beneath Thrallmar
.target Foreman Razelcraz
step
#completewith next
.goto Hellfire Peninsula,51.37,30.52,80 >> Follow the path to the Temple of Telhamat
.skill riding,225,1
step
#sticky
#label dpredators
.goto 1944/530,4335.4,70.7,0
#loop
.waypoint Hellfire Peninsula,23.36,41.29,50,0
.waypoint Hellfire Peninsula,23.32,39.88,50,0
.waypoint Hellfire Peninsula,23.36,38.59,50,0
.waypoint Hellfire Peninsula,23.36,37.45,50,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Vanura|r, she patrols up and down the central ramp
.target Scout Vanura
.accept 9398 >>Accept Deadly Predators
step
.goto 1944/530,4350.0,90.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Obadei|r
.target Anchorite Obadei
.accept 9390 >>Accept In Search of Sedai
step
.goto 1944/530,4347.2,92.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikan|r
.target Ikan
.accept 9399 >>Accept Cruel Taskmasters
.accept 9490 >>Accept The Rock Flayer Matriarch
step
#requires dpredators
#completewith Telhamat
.goto Hellfire Peninsula,23.35,36.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caregiver Ophera Windfury|r
.home >> Set your Hearthstone to Temple of Telhamat
.target Caregiver Ophera Windfury
step
#requires dpredators
#optional
.xp <61,1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elsaana|r and |cRXP_FRIENDLY_Amaan the Wise|r
.accept 9383 >> Accept An Ambitious Plan
.goto Hellfire Peninsula,23.21,36.66
.target +Elsaana
.accept 10443 >> Accept Helping the Cenarion Post
.goto Hellfire Peninsula,23.42,36.55
.accept 9426 >> Accept The Pools of Aggonar
.goto Hellfire Peninsula,23.42,36.55
.target Amaan the Wise
step
.goto Hellfire Peninsula,23.42,36.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaan the Wise|r
.target Amaan the Wise
.accept 9426 >>Accept The Pools of Aggonar
step
#completewith next
.goto Hellfire Peninsula,25.19,37.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuma|r
.fp Temple of Telhamat >> Get the Temple of Telhamat flight path
.target Kuma
step << Mage/DK wotlk
.goto Hellfire Peninsula,24.40,38.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vodesiin|r
>>Buy 20 |T134419:0|tRunes of Teleportation from him << Mage
.collect 17031,20 << Mage 
>>Buy 60 |T133849:0|tCorpse Dust from him << DK
.collect 37201,60 << DK 
.target Vodesiin
step
.goto Hellfire Peninsula,26.89,37.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sedai's Corpse|r
.turnin 9390 >> Turn in In Search of Sedai
.accept 9423 >> Accept Return to Obadei
.target Sedai's Corpse
step
#label Telhamat
>>Return to the Temple of Telhamat
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Obadei|r and |cRXP_FRIENDLY_Makuru|r
.turnin 9423 >> Turn in Return to Obadei
.target +Anchorite Obadei
.goto Hellfire Peninsula,23.00,40.37
.accept 9424 >> Accept Makuru's Vengeance
.target +Makuru
.goto Hellfire Peninsula,23.14,40.16
step
#completewith next
.goto Hellfire Peninsula,31.99,33.13,50 >>Run up the mountain path leading toward the Mag'har Grounds
.skill riding,225,1
step
#loop
.line Hellfire Peninsula,34.10,32.54,33.30,29.46,36.22,27.59,36.22,30.25,36.54,33.98,36.14,35.53,34.10,32.54
.goto Hellfire Peninsula,34.10,32.54,45,0
.goto Hellfire Peninsula,33.30,29.46,45,0
.goto Hellfire Peninsula,36.22,27.59,45,0
.goto Hellfire Peninsula,36.22,30.25,45,0
.goto Hellfire Peninsula,36.54,33.98,45,0
.goto Hellfire Peninsula,36.14,35.53,45,0
.goto Hellfire Peninsula,34.10,32.54,45,0
>>Kill |cRXP_ENEMY_Debilitated Mag'har Grunts|r and |cRXP_ENEMY_Mag'har Grunts|r. Loot them for their |cRXP_LOOT_Beads|r
.complete 9424,1 
.mob Debilitated Mag'har Grunt
.mob Mag'har Grunt
step
.goto Hellfire Peninsula,43.81,31.56
>>Kill |cRXP_ENEMY_Arazzius the Cruel|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc/wotlk
>>|cRXP_WARN_This quest is highly recommended as it rewards a trinket that'll last you a long time|r << tbc/wotlk
.complete 10400,1 
.isOnQuest 10400
.mob Arazzius the Cruel
step
#loop
.line Hellfire Peninsula,44.25,29.53,42.30,30.09,39.77,27.81,38.94,29.46,38.92,31.26,39.79,34.29,38.87,35.98,39.31,38.57,38.39,41.37,39.87,41.62,40.48,37.90,41.20,32.65,44.25,29.53
.goto Hellfire Peninsula,44.25,29.53,45,0
.goto Hellfire Peninsula,42.30,30.09,45,0
.goto Hellfire Peninsula,39.77,27.81,45,0
.goto Hellfire Peninsula,38.94,29.46,45,0
.goto Hellfire Peninsula,38.92,31.26,45,0
.goto Hellfire Peninsula,39.79,34.29,45,0
.goto Hellfire Peninsula,38.87,35.98,45,0
.goto Hellfire Peninsula,39.31,38.57,45,0
.goto Hellfire Peninsula,38.39,41.37,45,0
.goto Hellfire Peninsula,39.87,41.62,45,0
.goto Hellfire Peninsula,40.48,37.90,45,0
.goto Hellfire Peninsula,41.20,32.65,45,0
.goto Hellfire Peninsula,44.25,29.53,45,0
>>Kill |cRXP_ENEMY_Terrorfiends|r and |cRXP_ENEMY_Blistering Rots|r
.complete 9426,2 
.mob +Blistering Rot
.complete 10399,1 
.mob +Terrorfiend
step << !tbc
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10238 >> Turn in How to Serve Goblins
.target Foreman Razelcraz
step
#completewith next
.hs >> Hearth to the Temple of Telhamat
.cooldown item,6948,>2
step
.goto 1944/530,4341.30029,97.1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Makuru|r
.target Makuru
.turnin 9424 >>Turn in Makuru's Vengeance
.timer 22,Makuru's Vengeance RP
step
.goto 1944/530,4349.9,92.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Obadei|r, you have to wait for the RP sequence to end
.target Anchorite Obadei
.accept 9543 >>Accept Atonement
step
.goto 1944/530,4330.0,220.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaan the Wise|r
.target Amaan the Wise
.turnin 9543 >>Turn in Atonement
.accept 9430 >>Accept Sha'naar Relics
.turnin 9426 >>Turn in The Pools of Aggonar
.accept 9427 >>Accept Cleansing the Waters
step
#completewith next
.goto Hellfire Peninsula,40.14,30.78
.cast 29297 >>|cRXP_WARN_Use the|r |T134861:0|t[Cleansing Vial] |cRXP_WARN_to summon|r |cRXP_ENEMY_Aggonis|r
step
.goto Hellfire Peninsula,40.14,30.78
>>Kill |cRXP_ENEMY_Aggonis|r
.use 23361
.complete 9427,1 
.mob Aggonis
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Stonescythe Alphas|r and |cRXP_ENEMY_Stonescythe Whelps|r
.complete 9398,1 
.mob +Stonescythe Alpha
.complete 9398,2 
.mob +Stonescythe Whelp
step
.goto Hellfire Peninsula,33.94,63.93,30,0
.goto Hellfire Peninsula,33.34,65.16
>>Kill |cRXP_ENEMY_Blacktalon the Savage|r. Loot him for his |cRXP_LOOT_Claws|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc
.complete 9490,1 
.isOnQuest 9490
.mob Blacktalon the Savage
step
.goto Hellfire Peninsula,34.74,60.88,50,0
.goto Hellfire Peninsula,32.20,58.92,50,0
.goto Hellfire Peninsula,28.31,66.50
>>Kill |cRXP_ENEMY_Stonescythe Alphas|r and |cRXP_ENEMY_Stonescythe Whelps|r
.complete 9398,1 
.mob +Stonescythe Alpha
.complete 9398,2 
.mob +Stonescythe Whelp
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gremni Longbeard|r and |cRXP_FRIENDLY_Mirren Longbeard|r
.turnin 9558 >> Turn in The Longbeards
.accept 9417 >> Accept The Arakkoa Threat
.accept 9385 >> Accept Rampaging Ravagers
.target +Gremni Longbeard
.goto Hellfire Peninsula,23.89,72.17
.accept 9563 >> Accept Gaining Mirren's Trust
.turnin 9563 >> Turn in Gaining Mirren's Trust
.target +Mirren Longbeard
.goto Hellfire Peninsula,23.97,72.35
.itemcount 23848,1
step
.goto Hellfire Peninsula,23.97,72.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirren Longbeard|r
.accept 9420 >> Accept The Finest Down
.isQuestTurnedIn 9563
.target Mirren Longbeard
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gremni Longbeard|r
.turnin 9558 >> Turn in The Longbeards
.accept 9417 >> Accept The Arakkoa Threat
.accept 9385 >> Accept Rampaging Ravagers
.goto Hellfire Peninsula,23.89,72.17
.target Gremni Longbeard
step
#loop
.line Hellfire Peninsula,21.71,70.55,22.68,67.28,24.03,65.47,22.24,60.51,21.57,63.11,21.45,66.57,21.71,70.55
.goto Hellfire Peninsula,21.71,70.55,50,0
.goto Hellfire Peninsula,22.68,67.28,50,0
.goto Hellfire Peninsula,24.03,65.47,50,0
.goto Hellfire Peninsula,22.24,60.51,50,0
.goto Hellfire Peninsula,21.57,63.11,50,0
.goto Hellfire Peninsula,21.45,66.57,50,0
.goto Hellfire Peninsula,21.71,70.55,50,0
>>Kill |cRXP_ENEMY_Quillfang Ravagers|r << tbc/wotlk
>>Kill |cRXP_ENEMY_Quillfang Ravagers|r and |cRXP_ENEMY_Quillfang Skitterers|r << !tbc !wotlk
.complete 9385,1 
.mob Quillfang Ravager
.mob Quillfang Skitterer << !tbc !wotlk
step
#optional
#completewith Kaliri
>>Kill |cRXP_ENEMY_Haal'eshi Windwalkers|r and |cRXP_ENEMY_Haal'eshi Talonguards|r
.complete 9417,1 
.mob +Haal'eshi Windwalker
.complete 9417,2 
.mob +Haal'eshi Talonguard
step
#optional
#completewith AvruuO
>>Kill |cRXP_ENEMY_Kaliri Matriarchs|r, |cRXP_ENEMY_Kaliri Swoopers|r, |cRXP_ENEMY_Male Kaliri Hatchlings|r and |cRXP_ENEMY_Female Kaliri Hatchlings|r. Loot them for their |cRXP_LOOT_Feathers|r
>>|cRXP_WARN_Click the nests to spawn |cRXP_ENEMY_Male Kaliri Hatchlings|r and|r |cRXP_ENEMY_Female Kaliri Hatchlings|r
.complete 9420,1 
.isOnQuest 9420
.mob Kaliri Matriarch
.mob Kaliri Swooper
.mob Male Kaliri Hatchling
.mob Female Kaliri Hatchling
step
.goto Hellfire Peninsula,25.67,75.13,30,0
.goto Hellfire Peninsula,25.72,76.44
.use 23580 >>Kill |cRXP_ENEMY_Avruu|r. Loot him for |T134124:0|t[|cRXP_LOOT_Avruu's Orb|r]
>>|cRXP_WARN_Use|r |T134124:0|t[|cRXP_LOOT_Avruu's Orb|r] |cRXP_WARN_to start the quest|r
.collect 23580,1,9418,1 
.accept 9418 >> Accept Avruu's Orb
.unitscan Avruu
step
#label AvruuO
.goto Hellfire Peninsula,28.93,81.46
>>Click the |cRXP_PICK_Haal'eshi Altar|r to summon |cRXP_FRIENDLY_Aeranas|r
>>Defeat |cRXP_ENEMY_Aeranas|r afterwards
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aeranas|r
.turnin 9418 >> Turn in Avruu's Orb
.mob Aeranas
.skipgossip
step
#label Kaliri
.goto Hellfire Peninsula,27.55,77.86,30,0
.goto Hellfire Peninsula,25.79,76.61,30,0
.goto Hellfire Peninsula,25.79,74.95,30,0
.goto Hellfire Peninsula,26.38,74.25,30,0
.goto Hellfire Peninsula,25.11,76.08,30,0
.goto Hellfire Peninsula,24.69,76.47
>>Kill |cRXP_ENEMY_Kaliri Matriarchs|r, |cRXP_ENEMY_Kaliri Swoopers|r, |cRXP_ENEMY_Male Kaliri Hatchlings|r and |cRXP_ENEMY_Female Kaliri Hatchlings|r. Loot them for their |cRXP_LOOT_Feathers|r
>>|cRXP_WARN_Click the nests to spawn |cRXP_ENEMY_Male Kaliri Hatchlings|r and|r |cRXP_ENEMY_Female Kaliri Hatchlings|r
.complete 9420,1 
.isOnQuest 9420
.mob Kaliri Matriarch
.mob Kaliri Swooper
.mob Male Kaliri Hatchling
.mob Female Kaliri Hatchling
step
.goto Hellfire Peninsula,25.97,78.32,50,0
.goto Hellfire Peninsula,26.14,72.23
>>Kill |cRXP_ENEMY_Haal'eshi Windwalkers|r and |cRXP_ENEMY_Haal'eshi Talonguards|r
.complete 9417,1 
.mob +Haal'eshi Windwalker
.complete 9417,2 
.mob +Haal'eshi Talonguard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gremni Longbeard|r and |cRXP_FRIENDLY_Mirren Longbeard|r
.turnin 9420 >> Turn in The Finest Down
.target +Mirren Longbeard
.goto Hellfire Peninsula,23.97,72.35
.turnin 9417 >> Turn in The Arakkoa Threat
.turnin 9385 >> Turn in Rampaging Ravagers
.goto Hellfire Peninsula,23.89,72.17
.isQuestComplete 9420
.target Gremni Longbeard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gremni Longbeard|r
.turnin 9417 >> Turn in The Arakkoa Threat
.turnin 9385 >> Turn in Rampaging Ravagers
.goto Hellfire Peninsula,23.89,72.17
.target Gremni Longbeard
step
#optional
#completewith Arzeth
>>Kill |cRXP_ENEMY_Illidari Taskmasters|r
>>Loot the |cRXP_PICK_Relics|r on the ground
.complete 9399,1 
.complete 9430,1 
.mob Illidari Taskmaster
step
.goto Hellfire Peninsula,15.59,58.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Akoru the Firecaller|r
.accept 10403 >> Accept Naladu
.target Akoru the Firecaller
step
.goto Hellfire Peninsula,16.27,65.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naladu|r
.turnin 10403 >> Turn in Naladu
.accept 10367 >> Accept A Traitor Among Us
.target Naladu
step
.goto Hellfire Peninsula,14.34,63.50
>>Open the |cRXP_PICK_Metal Coffer|r. Loot it for the |cRXP_LOOT_Sha'naar Key|r
.complete 10367,1 
step
.goto Hellfire Peninsula,16.27,65.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naladu|r
.turnin 10367 >> Turn in A Traitor Among Us
.accept 10368 >> Accept The Dreghood Elders
.target Naladu
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the captured |cRXP_FRIENDLY_Broken|r in the Ruins
.complete 10368,1 
.target +Morod the Windstirrer
.goto Hellfire Peninsula,13.13,61.04
.complete 10368,3 
.target +Aylaan the Waterwaker
.goto Hellfire Peninsula,13.01,58.42
.complete 10368,2 
.goto Hellfire Peninsula,15.59,58.74
.target +Akoru the Firecaller
.skipgossip
step
.goto Hellfire Peninsula,16.27,65.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naladu|r
.turnin 10368 >> Turn in The Dreghood Elders
.accept 10369 >> Accept Arzeth's Demise
.target Naladu
step
.goto Hellfire Peninsula,14.29,62.38,50,0
.goto Hellfire Peninsula,14.35,56.99
>>|cRXP_WARN_Use the|r |T135225:0|t[Staff of the Dreghood Elders] |cRXP_WARN_to weaken|r |cRXP_ENEMY_Arzeth the Merciless|r
.use 29513 >>Kill |cRXP_ENEMY_Arzeth|r, he patrol around the central path
.complete 10369,1 
.mob Arzeth the Merciless
.mob Arzeth the Powerless
step
#label Arzeth
.goto Hellfire Peninsula,16.27,65.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Naladu|r
.turnin 10369 >> Turn in Arzeth's Demise
.target Naladu
step
#loop
.line Hellfire Peninsula,14.90,64.00,14.60,63.10,13.33,62.20,13.06,61.70,13.66,60.65,12.16,57.78,13.30,58.39,13.67,57.49,15.69,57.72,14.54,59.47,14.90,64.00
.goto Hellfire Peninsula,14.90,64.00,50,0
.goto Hellfire Peninsula,14.60,63.10,50,0
.goto Hellfire Peninsula,13.33,62.20,50,0
.goto Hellfire Peninsula,13.06,61.70,50,0
.goto Hellfire Peninsula,13.66,60.65,50,0
.goto Hellfire Peninsula,12.16,57.78,50,0
.goto Hellfire Peninsula,13.30,58.39,50,0
.goto Hellfire Peninsula,13.67,57.49,50,0
.goto Hellfire Peninsula,15.69,57.72,50,0
.goto Hellfire Peninsula,14.54,59.47,50,0
.goto Hellfire Peninsula,14.90,64.00,50,0
>>Kill |cRXP_ENEMY_Illidari Taskmasters|r
>>Loot the |cRXP_PICK_Relics|r on the ground
.complete 9399,1 
.mob +Illidari Taskmaster
.complete 9430,1 
step
>>Travel to the Cenarion Post
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amythiel Mistwalker|r, |cRXP_FRIENDLY_Mahuram Stouthoof|r, |cRXP_FRIENDLY_Thiah Redmane|r and |cRXP_FRIENDLY_Tola'thion|r
.accept 9912 >> Accept The Cenarion Expedition
.target +Amythiel Mistwalker
.goto Hellfire Peninsula,16.04,52.15
.accept 10159 >> Accept Keep Thornfang Hill Clear!
.target +Mahuram Stouthoof
.goto Hellfire Peninsula,15.65,52.15
.turnin -10443 >> Turn in Helping the Cenarion Post
.turnin -9373 >> Turn in Missing Missive
.accept 9372 >> Accept Demonic Contamination
.target +Thiah Redmane
.goto Hellfire Peninsula,15.70,52.08
.accept 10132 >>Accept Colossal Menace
.target +Tola'thion
.goto Hellfire Peninsula,15.62,52.04
step
#optional
#completewith next
.goto Hellfire Peninsula,15.0,45.7,0
.use 29476 >>Kill a |cRXP_ENEMY_Raging Colossus|r. Loot it for a |T134081:0|t[|cRXP_LOOT_Crimson Crystal Shard|r]
>>|cRXP_WARN_Use the|r |T134081:0|t[|cRXP_LOOT_Crimson Crystal Shard|r] |cRXP_WARN_to start the quest|r
>>|cRXP_WARN_Find a group for them if needed. Skip this step if you're unable to find a group or solo them without all cooldowns|r << tbc/wotlk
.collect 29476,1,10134,1 
.accept 10134 >>Accept Crimson Crystal Clue
.mob Raging Colossus
step
.goto Hellfire Peninsula,14.38,44.64,50,0
.goto Hellfire Peninsula,17.96,40.76
>>Kill |cRXP_ENEMY_Raging Colossuses|r
>>|cRXP_WARN_Find a group for them if needed. Skip this step if you're unable to find a group or solo them without all cooldowns|r << tbc/wotlk
.complete 10132,1 
.mob Raging Colossus
step
.goto Hellfire Peninsula,14.38,44.64,50,0
.goto Hellfire Peninsula,17.96,40.76
.use 29476 >>Kill a |cRXP_ENEMY_Raging Colossus|r. Loot it for a |T134081:0|t[|cRXP_LOOT_Crimson Crystal Shard|r]
>>|cRXP_WARN_Use the|r |T134081:0|t[|cRXP_LOOT_Crimson Crystal Shard|r] |cRXP_WARN_to start the quest|r
>>|cRXP_WARN_Find a group for them if needed. Skip this step if you're unable to find a group or solo them without all cooldowns|r << tbc/wotlk
.collect 29476,1,10134,1 
.accept 10134 >>Accept Crimson Crystal Clue
.mob Raging Colossus
step << Shaman
#completewith next
.hs >> Hearth to the Temple of Telhamat
.cooldown item,6948,>2
step << Shaman
.goto 1944/530,4331.10010,220.70000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaan the Wise|r
.target Amaan the Wise
.turnin 9427 >>Turn in Cleansing the Waters
.turnin 9430 >>Turn in Sha'naar Relics
.accept 9545 >>Accept The Seer's Relic
step << Shaman
.goto 1944/530,4341.30029,217.60001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elsaana|r
.target Elsaana
.accept 9383 >>Accept An Ambitious Plan
step
#label dpred2
#sticky
.goto 1944/530,4333.4,179.6,0
#loop
.waypoint Hellfire Peninsula,23.36,41.29,50,0
.waypoint Hellfire Peninsula,23.32,39.88,50,0
.waypoint Hellfire Peninsula,23.36,38.59,50,0
.waypoint Hellfire Peninsula,23.36,37.45,50,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Vanura|r, she patrols up and down the central ramp
.target Scout Vanura
.turnin 9398 >>Turn in Deadly Predators
step
.goto 1944/530,4346.8,94.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikan|r
.target Ikan
.turnin 9399 >>Turn in Cruel Taskmasters
.turnin 9490 >>Turn in The Rock Flayer Matriarch
.isQuestComplete 9490
step
#optional
.goto 1944/530,4346.8,94.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikan|r
.target Ikan
.turnin 9399 >>Turn in Cruel Taskmasters
step << !Shaman
.goto 1944/530,4331.10010,220.70000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaan the Wise|r
.target Amaan the Wise
.turnin 9427 >>Turn in Cleansing the Waters
.turnin 9430 >>Turn in Sha'naar Relics
.accept 9545 >>Accept The Seer's Relic
step << !Shaman
.goto 1944/530,4341.30029,217.60001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elsaana|r
.target Elsaana
.accept 9383 >>Accept An Ambitious Plan
step
#requires dpred2
#completewith next
.goto Hellfire Peninsula,25.19,37.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuma|r
.fly Honor Hold >> Fly to Honor Hold
.target Kuma
step
#requires dpred2
>>Return to Honor Hold. Go inside the Keep to the top floor
.goto Hellfire Peninsula,56.37,65.99,20,0
.goto Hellfire Peninsula,56.61,66.77,14,0
.goto 1944/530,2615.0,-810.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warp-Scryer Kryv|r
.target Warp-Scryer Kryv
.turnin 10047 >>Turn in The Path of Glory
.accept 10093 >>Accept The Temple of Telhamat
.turnin 10399 >>Turn in The Heart of Darkness
step
#sticky
#label overlord
.goto 1944/530,2615.30005,-812.70001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r
.target Force Commander Danath Trollbane
.turnin 10400 >>Turn in Overlord
.isQuestComplete 10400
step
.goto 1944/530,2615.30005,-812.70001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r
.target Force Commander Danath Trollbane
.isQuestComplete 10937
.turnin 10937 >>Turn in Drill the Drillmaster
step
#requires overlord
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumphry|r
.goto Hellfire Peninsula,51.30,60.35,20,0
.goto Hellfire Peninsula,51.19,59.99,20,0
.goto Hellfire Peninsula,50.99,60.51
.turnin 10078 >> Turn in Laying Waste to the Unwanted
.target Dumphry
step
#questguide << !tbc
#xprate <1.5 << TBC
>>Return to the Zeppelin Crash
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Legassi|r and |cRXP_FRIENDLY_"Screaming" Screed Luckheed|r
.turnin 9356 >> Turn in Smooth as Butter
.target +Legassi
.goto Hellfire Peninsula,49.24,74.83
.turnin 10161 >> Turn in In Case of Emergency...
.accept 9351 >> Accept Voidwalkers Gone Wild
.goto Hellfire Peninsula,49.15,74.87
.target +"Screaming" Screed Luckheed
step
#xprate >1.499 << TBC
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Legassi|r
.turnin 9356 >> Turn in Smooth as Butter
.goto Hellfire Peninsula,49.24,74.83
.target Legassi
step
#questguide << !tbc
#xprate <1.5 << tbc
#completewith next
#optional
>>Kill |cRXP_ENEMY_Rogue Voidwalkers|r and |cRXP_ENEMY_Uncontrolled Voidwalkers|r. Loot them for their |cRXP_LOOT_Essence|r
.complete 9351,1 
.mob Uncontrolled Voidwalker
.mob Rogue Voidwalker
step
.goto Hellfire Peninsula,50.07,83.29,50,0
.goto Hellfire Peninsula,46.25,83.22
.use 23417 >>|cRXP_WARN_Damage an|r |cRXP_ENEMY_Uncontrolled Voidwalker|r |cRXP_WARN_down to 20% or less health, then use the|r |T132878:0|t[Sanctified Crystal] |cRXP_WARN_on it|r
.complete 9383,1 
.mob Uncontrolled Voidwalker
step
#questguide << !tbc
#xprate <1.5 << tbc
#loop
.line Hellfire Peninsula,46.32,81.97,45.65,84.23,47.81,84.70,50.15,83.32,51.18,82.56,50.45,81.79,48.50,81.74,46.32,81.97
.goto Hellfire Peninsula,46.32,81.97,50,0
.goto Hellfire Peninsula,45.65,84.23,50,0
.goto Hellfire Peninsula,47.81,84.70,50,0
.goto Hellfire Peninsula,50.15,83.32,50,0
.goto Hellfire Peninsula,51.18,82.56,50,0
.goto Hellfire Peninsula,50.45,81.79,50,0
.goto Hellfire Peninsula,48.50,81.74,50,0
.goto Hellfire Peninsula,46.32,81.97,50,0
>>Kill |cRXP_ENEMY_Rogue Voidwalkers|r and |cRXP_ENEMY_Uncontrolled Voidwalkers|r. Loot them for their |cRXP_LOOT_Essence|r
.complete 9351,1 
.mob Uncontrolled Voidwalker
.mob Rogue Voidwalker
step
#questguide << !tbc
#xprate <1.5 << tbc
.goto Hellfire Peninsula,49.15,74.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Screaming" Screed Luckheed|r
.turnin 9351 >> Turn in Voidwalkers Gone Wild
.target "Screaming" Screed Luckheed
step
#completewith Temple
.hs >> Hearth to Temple of Telhamat
.cooldown item,6948,>2
step
#completewith next
.goto Hellfire Peninsula,54.68,62.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flightmaster Krill Bitterhue|r
.fly Temple of Telhamat >> Fly to the Temple of Telhamat
.cooldown item,6948,<0
.target Flightmaster Krill Bitterhue
step
#label Temple
>>Return to the Temple of Telhamat
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaan the Wise|r and |cRXP_FRIENDLY_Elsaana|r
.turnin 10093 >> Turn in The Temple of Telhamat
.goto Hellfire Peninsula,23.42,36.55
.target +Amaan the Wise
.turnin 9383 >> Turn in An Ambitious Plan
.goto Hellfire Peninsula,23.21,36.66
.target +Elsaana
step
.goto Hellfire Peninsula,26.89,37.44
.cast 30489 >>|cRXP_WARN_Use the|r |T134907:0|t[Seer's Relic] |cRXP_WARN_on |cRXP_FRIENDLY_Sedai's Corpse|r. Do NOT wait for the RP|r
.timer 21,The Seer's Relic RP
.use 23645
.isOnQuest 9545
.target Sedai's Corpse
step
.goto Hellfire Peninsula,23.42,36.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amaan the Wise|r
.turnin 9545 >> Turn in The Seer's Relic
.target Amaan the Wise
step
.goto Hellfire Peninsula,24.99,51.58,60,0
.goto Hellfire Peninsula,23.73,57.53,60,0
.goto Hellfire Peninsula,17.33,53.85
>>Kill |cRXP_ENEMY_Hulking Helboars|r. Loot them for their |cRXP_LOOT_Blood Samples|r
.complete 9372,1 
.mob Hulking Helboar
step
#sticky
#label Thiah
>>Return to Cenarion Post
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thiah Redmane|r
.turnin 9372 >> Turn in Demonic Contamination
.accept 10255 >> Accept Testing the Antidote
.goto Hellfire Peninsula,15.70,52.08
.target Thiah Redmane
step
#optional
#completewith next
.goto Hellfire Peninsula,15.62,52.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tola'thion|r
.turnin 10132 >>Turn in Colossal Menace
.isQuestComplete 10132
.target Tola'thion
step
.goto Hellfire Peninsula,15.62,52.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tola'thion|r
.turnin 10134 >>Turn in Crimson Crystal Clue
.isOnQuest 10134
.target Tola'thion
step
.goto Hellfire Peninsula,15.62,52.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tola'thion|r
.accept 10349 >>Accept The Earthbinder
.isQuestTurnedIn 10134
.target Tola'thion
step
.goto Hellfire Peninsula,15.62,52.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tola'thion|r
.turnin 10132 >>Turn in Colossal Menace
.isQuestComplete 10132
.target Tola'thion
step
#requires Thiah
.goto Hellfire Peninsula,15.97,51.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthbinder Galandria Nightbreeze|r
.turnin 10349 >>Turn in The Earthbinder
.accept 10351 >>Accept Natural Remedies
.isQuestTurnedIn 10134
.target Earthbinder Galandria Nightbreeze
step
.goto Hellfire Peninsula,18.40,52.73,60,0
.goto Hellfire Peninsula,22.17,56.14
.use 23337 >>|cRXP_WARN_Use the|r |T134801:0|t[Cenarion Antidote] |cRXP_WARN_on a|r |cRXP_ENEMY_Hulking Helboar|r to turn them into |cRXP_ENEMY_Dreadtusk|r
>>Kill the |cRXP_ENEMY_Dreadtusk|r
.complete 10255,1 
.mob Dreadtusk
.mob Hulking Helboar
step
#completewith next
.goto Hellfire Peninsula,13.63,39.10
.cast 35413 >>|cRXP_WARN_Channel the|r |T133944:0|t[Seed of Revitalization] |cRXP_WARN_while standing on the green circle to summon|r |cRXP_ENEMY_Goliathon|r
.timer 49,Goliathon Summon RP
step
.goto Hellfire Peninsula,13.52,39.70
>>Kill |cRXP_ENEMY_Goliathon|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc/wotlk
.use 29478 >>|cRXP_WARN_Be careful as |cRXP_ENEMY_Goliathon|r has a HUGE (60 yard) knockback|r
.complete 10351,1 
.isQuestTurnedIn 10134
.mob Goliathon
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Earthbinder Galandria Nightbreeze|r and |cRXP_FRIENDLY_Thiah Redmane|r
.turnin 10351 >>Turn in Natural Remedies
.goto Hellfire Peninsula,15.97,51.57
.turnin 10255 >> Turn in Testing the Antidote
.goto Hellfire Peninsula,15.70,52.08
.isQuestComplete 10351
.target Earthbinder Galandria Nightbreeze
.target Thiah Redmane
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thiah Redmane|r
.turnin 10255 >> Turn in Testing the Antidote
.goto Hellfire Peninsula,15.70,52.08
.target Thiah Redmane
step
#optional
#sticky
>>Abandon the elite quests if you were unable to complete them
.abandon 10132 >>Abandon Colossal Menace
step
#optional
#sticky
>>Abandon the elite quests if you were unable to complete them
.abandon 10351 >> Abandon Natural Remedies
step
.goto Hellfire Peninsula,12.15,46.50,50,0
.goto Hellfire Peninsula,9.13,49.47,50,0
.goto Hellfire Peninsula,11.60,55.18,50,0
.goto Hellfire Peninsula,7.41,49.74,50,0
.goto Hellfire Peninsula,5.37,51.43,50,0
.goto Hellfire Peninsula,9.13,49.47
>>Kill |cRXP_ENEMY_Thornfang Venomspitters|r and |cRXP_ENEMY_Thornfang Ravagers|r
.complete 10159,2 
.mob +Thornfang Venomspitter
.complete 10159,1 
.mob +Thornfang Ravager
]])

RXPGuides.RegisterGuide([[#version 9
#cata
#mop
#wotlk
#group RXP MoP 60-80 (A)
<< Alliance
#name 61-63 Zangarmarsh
#displayname 61-64 Zangarmarsh << !tbc !wotlk
#version 9
#next 63-65 Terokkar Forest;65-67 Blade's Edge << tbc/wotlk
#next 64-66 Nagrand;65-67 Blade's Edge << !tbc !wotlk
step
.goto Zangarmarsh,82.81,64.85
.zone Zangarmarsh >> Travel to Zangarmarsh
step
#completewith next
>>|cRXP_WARN_Below is a list of items that drop in Zangarmarsh that are required for quests. Make a mental note of these items. Save them as they drop. You need a total of:|r
.collect 24291,6,9743,1 
.collect 24245,10,9808,1 
.collect 24401,10,9802,1 
.collect 24449,6,9806,1 
step
.goto 1946/530,5434.70020,-216.70000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikeyen|r
.target Ikeyen
.accept 9747 >>Accept The Umbrafen Tribe
step
.goto 1946/530,5440.10010,-219.50000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lauranna Thar'well|r
.target Lauranna Thar'well
.accept 9802 >>Accept Plants of Zangarmarsh
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Wanted Poster|r and |cRXP_FRIENDLY_Warden Hamoot|r upstairs
.accept 9817 >> Accept Leader of the Bloodscale
.accept 9730 >> Accept Leader of the Darkcrest
.goto Zangarmarsh,79.08,64.88
.accept 9728 >> Accept A Warm Welcome
.goto Zangarmarsh,79.09,65.27
.target Warden Hamoot
step
#label RefugeHS
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lethyn Moonfire|r and |cRXP_FRIENDLY_Ysiel Windsinger|r
.accept 9895 >> Accept The Dying Balance
.goto Zangarmarsh,78.53,63.15,-1
.target +Lethyn Moonfire
.turnin 9912 >> Turn in The Cenarion Expedition
.accept 9716 >> Accept Disturbance at Umbrafen Lake
.goto Zangarmarsh,78.40,62.02,-1
.target +Ysiel Windsinger
step
#optional << tbc
.goto Zangarmarsh,67.83,51.46
>>Travel to Telredor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Munci|r
.fp Telredor >> Get the Telredor flight path
.skill riding,<225,1
.target Munci
step
#completewith Telredor
.goto Zangarmarsh,70.24,49.27,20 >> Use the elevator to get up to Telredor
.skill riding,225,1
step
#sticky
#label deadmire1
.groundgoto 1946/530,6039.70020,258.50000,0,0
.flygoto 1946/530,6039.70020,258.50000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Idaar|r
.target Vindicator Idaar
.accept 9782 >>Accept The Dead Mire
step
.goto 1946/530,6034.80029,283.10001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Conall|r
.target Prospector Conall
.accept 9901 >>Accept Unfinished Business
step
.goto 1946/530,6044.70020,283.70001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r
.target Anchorite Ahuurn
.accept 9786 >>Accept The Boha'mu Ruins
step
.goto 1946/530,6033.30029,298.89999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ruam|r
.target Ruam
.accept 9777 >>Accept Fulgor Spores
step
#label Telredor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haalrun|r
.accept 9781 >>Accept Too Many Mouths to Feed
.goto 1946/530,6065.60010,328.70001
.target +Haalrun
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noraani|r
.accept 9791 >>Accept Menacing Marshfangs
.goto 1946/530,6074.80029,331.30002
.target +Noraani
step
#completewith Sporewing
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caregiver Abidaar|r
.goto Zangarmarsh,67.14,49.03
.home 3644>> Set your Hearthstone to Telredor
.target Caregiver Abidaar
step
#optional << !tbc
.goto Zangarmarsh,67.83,51.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Munci|r
.fp Telredor >> Get the Telredor flight path
.skill riding,225,1
.target Munci
step
#requires deadmire1
step
#optional
#completewith Rippers
>>Kill |cRXP_ENEMY_Fen Striders|r and |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Fen Strider
.mob *Marsh Walker
.mob *Sporebat
.mob *Greater Sporebat
step
#optional
#completewith Sporewing
>>Kill |cRXP_ENEMY_Marshfang Rippers|r
.complete 9791,1 
.mob Marshfang Ripper
step
#loop
.line Zangarmarsh,68.81,47.75,68.03,48.34,66.01,46.49,65.86,47.37,64.74,49.34,66.46,52.07,70.99,53.95,70.74,50.20,71.57,45.46,68.81,47.75
.goto Zangarmarsh,68.81,47.75,45,0
.goto Zangarmarsh,68.03,48.34,45,0
.goto Zangarmarsh,66.01,46.49,45,0
.goto Zangarmarsh,65.86,47.37,45,0
.goto Zangarmarsh,64.74,49.34,45,0
.goto Zangarmarsh,66.46,52.07,45,0
.goto Zangarmarsh,70.99,53.95,45,0
.goto Zangarmarsh,70.74,50.20,45,0
.goto Zangarmarsh,71.57,45.46,45,0
.goto Zangarmarsh,68.81,47.75,45,0
>>Loot the |cRXP_PICK_Fulgor Spores|r on the ground
.complete 9777,1 
step
#label Sporewing
.goto Zangarmarsh,76.80,45.97,60,0
.goto Zangarmarsh,77.29,45.84,60,0
.goto Zangarmarsh,77.76,45.39,60,0
.goto Zangarmarsh,78.64,45.49,60,0
.goto Zangarmarsh,78.83,46.82,60,0
.goto Zangarmarsh,79.79,47.25,60,0
.goto Zangarmarsh,79.79,47.25,0
.line Zangarmarsh,76.80,45.97,77.29,45.84,77.76,45.39,78.64,45.49,78.83,46.82,79.79,47.25
>>Kill |cRXP_ENEMY_Sporewing|r
>>|cRXP_ENEMY_Sporewing|r |cRXP_WARN_patrol path is marked on your map|r
.complete 9901,1 
.unitscan Sporewing
step
.goto Zangarmarsh,83.82,43.29,-1
.goto Zangarmarsh,80.67,43.45,-1
.goto Zangarmarsh,79.95,42.06,-1
>>Loot the |cRXP_PICK_Dead Mire Soil|r on the ground
.complete 9782,1 
step
#label Rippers
#loop
.line Zangarmarsh,71.61,44.61,76.33,45.27,77.92,46.48,79.79,49.98,84.36,47.15,85.19,47.91,85.42,49.75,84.98,51.50,83.16,52.43,77.63,54.34,76.78,56.41,74.54,54.83,72.82,51.77,71.61,44.61
.goto Zangarmarsh,71.61,44.61,50,0
.goto Zangarmarsh,76.33,45.27,50,0
.goto Zangarmarsh,77.92,46.48,50,0
.goto Zangarmarsh,79.79,49.98,50,0
.goto Zangarmarsh,84.36,47.15,50,0
.goto Zangarmarsh,85.19,47.91,50,0
.goto Zangarmarsh,85.42,49.75,50,0
.goto Zangarmarsh,84.98,51.50,50,0
.goto Zangarmarsh,83.16,52.43,50,0
.goto Zangarmarsh,77.63,54.34,50,0
.goto Zangarmarsh,76.78,56.41,50,0
.goto Zangarmarsh,74.54,54.83,50,0
.goto Zangarmarsh,72.82,51.77,50,0
.goto Zangarmarsh,71.61,44.61,50,0
>>Kill |cRXP_ENEMY_Marshfang Rippers|r
.complete 9791,1 
.mob Marshfang Ripper
step
#completewith next
.hs >> Hearth to Telredor
.cooldown item,6948,>2
step
.goto 1946/530,6074.10010,329.80002
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noraani|r
.target Noraani
.turnin 9791 >>Turn in Menacing Marshfangs
.accept 9780 >>Accept Umbrafen Eel Filets
step
.goto 1946/530,6027.70020,302.20001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ruam|r
.target Ruam
.turnin 9777 >>Turn in Fulgor Spores
step
.goto 1946/530,6030.89990,280.10001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Conall|r
.target Prospector Conall
.turnin 9901 >>Turn in Unfinished Business
.accept 9896 >>Accept Blacksting's Bane
step
.goto 1946/530,6038.20020,257.20001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Idaar|r
.target Vindicator Idaar
.turnin 9782 >>Turn in The Dead Mire
.accept 9783 >>Accept An Unnatural Drought
step
#optional
#completewith boglash
>>Kill |cRXP_ENEMY_Fen Striders|r and |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Fen Strider
.mob *Marsh Walker
.mob *Sporebat
.mob *Greater Sporebat
step
#optional
#label Basidium
#completewith next
>>Kill |cRXP_ENEMY_Withered Giants|r. Loot them for their |T134001:0|t[|cRXP_LOOT_Withered Basidium|r]
>>|cRXP_WARN_This is a rare drop, don't go out of your way to loot this|r << !tbc
.collect 24483,1,9827 
.mob Withered Giant
step
#label Giants
#loop
.line Zangarmarsh,82.12,44.97,79.44,42.62,77.86,35.41,80.99,31.26,84.94,36.18,85.96,42.24,82.12,44.97
.goto Zangarmarsh,82.12,44.97,60,0
.goto Zangarmarsh,79.44,42.62,60,0
.goto Zangarmarsh,77.86,35.41,60,0
.goto Zangarmarsh,80.99,31.26,60,0
.goto Zangarmarsh,84.94,36.18,60,0
.goto Zangarmarsh,85.96,42.24,60,0
.goto Zangarmarsh,82.12,44.97,60,0
>>Kill |cRXP_ENEMY_Withered Giants|r, loot the |cRXP_LOOT_Bog Lord Tendrils|r for a quest later
.collect 24291,6,9743,1,1 
.complete 9783,1 
.mob Withered Giant
step
#questguide << !tbc
#label BasidiumX
#loop
.line Zangarmarsh,82.12,44.97,79.44,42.62,77.86,35.41,80.99,31.26,84.94,36.18,85.96,42.24,82.12,44.97
.goto Zangarmarsh,82.12,44.97,60,0
.goto Zangarmarsh,79.44,42.62,60,0
.goto Zangarmarsh,77.86,35.41,60,0
.goto Zangarmarsh,80.99,31.26,60,0
.goto Zangarmarsh,84.94,36.18,60,0
.goto Zangarmarsh,85.96,42.24,60,0
.goto Zangarmarsh,82.12,44.97,60,0
.use 24483 >>Kill |cRXP_ENEMY_Withered Giants|r. Loot them for their |T134001:0|t[|cRXP_LOOT_Withered Basidium|r]
.collect 24291,6,9743,1,1 
.collect 24483,1,9827 
.mob Withered Giant
step
#sticky
#optional
.use 24483>>|cRXP_WARN_Use the|r |T134001:0|t[|cRXP_LOOT_Withered Basidium|r] |cRXP_WARN_to start the quest|r
.itemcount 24483,1
.accept 9827 >> Accept Withered Basidium
step << !Warlock
#completewith eels
#optional
.cast 22807 >> |cRXP_WARN_Use the|r |T134716:0|t[Potion of Water Breathing]
.use 25539
.itemcount 25539,1
step
#label Scales
#completewith lakeEnd
>>Kill |cRXP_ENEMY_Mire Hydras|r
.complete 9781,1 
.mob Mire Hydra
step
#label eels
#loop
.line Zangarmarsh,73.89,61.37,75.28,63.48,76.32,66.48,76.78,71.37,76.74,75.66,76.76,79.11,74.88,81.27,73.91,79.38,71.94,81.30,73.44,76.43,73.94,72.76,72.92,69.75,73.98,67.64,72.26,66.54,71.63,62.34,73.89,61.37
.goto Zangarmarsh,73.89,61.37,50,0
.goto Zangarmarsh,75.28,63.48,50,0
.goto Zangarmarsh,76.32,66.48,50,0
.goto Zangarmarsh,76.78,71.37,50,0
.goto Zangarmarsh,76.74,75.66,50,0
.goto Zangarmarsh,76.76,79.11,50,0
.goto Zangarmarsh,74.88,81.27,50,0
.goto Zangarmarsh,73.91,79.38,50,0
.goto Zangarmarsh,71.94,81.30,50,0
.goto Zangarmarsh,73.44,76.43,50,0
.goto Zangarmarsh,73.94,72.76,50,0
.goto Zangarmarsh,72.92,69.75,50,0
.goto Zangarmarsh,73.98,67.64,50,0
.goto Zangarmarsh,72.26,66.54,50,0
.goto Zangarmarsh,71.63,62.34,50,0
.goto Zangarmarsh,73.89,61.37,50,0
.use 25539 >>Kill |cRXP_ENEMY_Umbrafen Eels|r. Loot them for their |cRXP_LOOT_Filets|r
.complete 9780,1 
.mob Umbrafen Eel
step
.goto Zangarmarsh,70.57,80.28
>>Travel near to the Water Pump
.complete 9716,1 
step
#label lakeEnd
.goto Zangarmarsh,85.29,90.93,160 >> Head to Umbrafen Village
.isOnQuest 9747
.subzoneskip 3641
step
#completewith Kataru2
>>Kill |cRXP_ENEMY_Umbrafen Oracles|r, |cRXP_ENEMY_Umbrafen Seers|r and |cRXP_ENEMY_Umbrafen Witchdoctors|r
.complete 9747,2 
.mob +Umbrafen Oracle
.complete 9747,3 
.mob +Umbrafen Seer
.complete 9747,4 
.mob +Umbrafen Witchdoctor
step
#label Kataru2
.groundgoto Zangarmarsh,84.99,90.27,20,0
.goto Zangarmarsh,85.29,90.93
>>Kill |cRXP_ENEMY_Kataru|r atop the tower
.complete 9747,1 
.unitscan Kataru
step
#loop
.line Zangarmarsh,83.52,89.16,83.76,88.09,85.50,88.89,84.45,86.16,85.14,82.69,85.71,81.14,85.10,81.08,83.64,81.11,83.60,79.54,83.07,81.06,83.72,82.93,83.38,84.68,82.37,84.73,83.52,89.16
.goto Zangarmarsh,83.52,89.16,50,0
.goto Zangarmarsh,83.76,88.09,50,0
.goto Zangarmarsh,85.50,88.89,50,0
.goto Zangarmarsh,84.45,86.16,50,0
.goto Zangarmarsh,85.14,82.69,50,0
.goto Zangarmarsh,85.71,81.14,50,0
.goto Zangarmarsh,85.10,81.08,50,0
.goto Zangarmarsh,83.64,81.11,50,0
.goto Zangarmarsh,83.60,79.54,50,0
.goto Zangarmarsh,83.07,81.06,50,0
.goto Zangarmarsh,83.72,82.93,50,0
.goto Zangarmarsh,83.38,84.68,50,0
.goto Zangarmarsh,82.37,84.73,50,0
.goto Zangarmarsh,83.52,89.16,50,0
>>Kill |cRXP_ENEMY_Umbrafen Oracles|r, |cRXP_ENEMY_Umbrafen Seers|r and |cRXP_ENEMY_Umbrafen Witchdoctors|r
.complete 9747,2 
.mob +Umbrafen Oracle
.complete 9747,3 
.mob +Umbrafen Seer
.complete 9747,4 
.mob +Umbrafen Witchdoctor
step
.goto Zangarmarsh,83.38,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kayra Longmane|r
*|cRXP_WARN_You may need to wait for |cRXP_FRIENDLY_Kayra Longmane|r to respawn|r
.accept 9752 >> Accept Escape from Umbrafen
.target Kayra Longmane
step
#optional
#completewith next
.goto Zangarmarsh,83.89,78.58,100,0
.goto Zangarmarsh,82.63,77.98,80,0
.goto Zangarmarsh,81.72,75.58,60,0
.goto Zangarmarsh,82.11,73.88,60,0
.goto Zangarmarsh,81.73,72.94,60,0
.goto Zangarmarsh,81.75,72.20
.line Zangarmarsh,83.89,78.58,82.63,77.98,81.72,75.58,82.11,73.88,81.73,72.94,81.75,72.20
>>Kill |cRXP_ENEMY_Boglash|r using |cRXP_FRIENDLY_Kayra Longmane|r to assist you
>>|cRXP_WARN_Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc
.complete 9895,1 
.unitscan Boglash
.target Kayra Longmane
step
.goto Zangarmarsh,79.83,71.17
>>Escort |cRXP_FRIENDLY_Kayra Longmane|r. She can heal and assist you in combat
.complete 9752,1 
.target Kayra Longmane
step
.goto Zangarmarsh,83.89,78.58,60,0
.goto Zangarmarsh,82.63,77.98,60,0
.goto Zangarmarsh,81.72,75.58,60,0
.goto Zangarmarsh,82.11,73.88,60,0
.goto Zangarmarsh,81.73,72.94,60,0
.goto Zangarmarsh,81.75,72.20
.line Zangarmarsh,83.89,78.58,82.63,77.98,81.72,75.58,82.11,73.88,81.73,72.94,81.75,72.20
>>Kill |cRXP_ENEMY_Boglash|r
>>|cRXP_WARN_Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc
.complete 9895,1 
.unitscan Boglash
step
#label boglash
>>Kill any mob in Zangarmarsh
.collect 24401,10,9802,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikeyen|r
.target Ikeyen
.goto Zangarmarsh,80.39,64.15
.turnin 9747 >>Turn in The Umbrafen Tribe
.accept 9788 >>Accept A Damp, Dark Place
step
.goto Zangarmarsh,80.32,64.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lauranna Thar'well|r
.target Lauranna Thar'well
.turnin 9802 >>Turn in Plants of Zangarmarsh
.accept 10096 >>Accept Saving the Sporeloks
step
#sticky
#label blessing1a
.goto 1946/530,5434.60010,-233.50000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windcaller Blackhoof|r
.target Windcaller Blackhoof
.accept 9785 >>Accept Blessings of the Ancients
.reputation 942,friendly,<0,1
step
.goto 1946/530,5434.60010,-233.50000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windcaller Blackhoof|r
.target Windcaller Blackhoof
.accept 9894 >>Accept Safeguarding the Watchers
step
#requires blessing1a
.goto 1946/530,5525.50000,-182.30000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lethyn Moonfire|r
.target Lethyn Moonfire
.turnin 9895 >>Turn in The Dying Balance
step
.goto 1946/530,5533.39990,-145.20000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysiel Windsinger|r
.target Ysiel Windsinger
.turnin 9752 >> Turn in Escape from Umbrafen
.isQuestComplete 9752
step
#label CenarionPost2
.goto 1946/530,5533.39990,-145.20000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysiel Windsinger|r
.target Ysiel Windsinger
.turnin 9716 >>Turn in Disturbance at Umbrafen Lake
.accept 9718 >>Accept As the Crow Flies
step
.goto Zangarmarsh,78.40,62.02
>>|cRXP_WARN_Use the|r |T134911:0|t[Stormcrow Amulet]
.complete 9718,1 
.cast 31606
.timer 155,As the Crow Flies RP
.use 25465
step
.goto Zangarmarsh,78.40,62.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysiel Windsinger|r
.turnin 9718 >> Turn in As the Crow Flies
.accept 9720 >> Accept Balance Must Be Preserved
.target Ysiel Windsinger
step
#optional
#completewith Klaq
>>Kill |cRXP_ENEMY_Fen Striders|r and |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Fen Strider
.mob *Marsh Walker
.mob *Sporebat
.mob *Greater Sporebat
.subzoneskip 3652
step
#sticky
#label q10096
#loop
.goto Zangarmarsh,74.44,92.06,0
.goto Zangarmarsh,72.39,93.82,0
.waypoint Zangarmarsh,74.44,92.06,50,0
.waypoint Zangarmarsh,72.39,93.82,50,0
>>Kill |cRXP_ENEMY_Marsh Dredgers|r and |cRXP_ENEMY_Marsh Lurkers|r inside the Cavern. Loot them for their |cRXP_LOOT_Plant Parts|r
.complete 10096,1 
.mob +Marsh Dredger
.complete 10096,2 
.mob +Marsh Lurker
step
#label Klaq
.goto Zangarmarsh,74.44,92.06,60,0
.goto Zangarmarsh,72.39,93.82
>>Enter the Funggor Cavern. Drop down into the middle of the Cavern
>>Kill |cRXP_ENEMY_Lord Klaq|r
.complete 9894,1 
.unitscan Lord Klaq
step
#label Ikeyen
.goto Zangarmarsh,72.94,96.60,20,0
.goto Zangarmarsh,70.53,97.91
>>Loot |cRXP_PICK_Ikeyen's Belongings|r in the back of the Cavern
.complete 9788,1 
step
#requires q10096
step
#optional
#completewith Blacksting
>>Kill |cRXP_ENEMY_Fen Striders|r and |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Fen Strider
.mob *Marsh Walker
.mob *Sporebat
.mob *Greater Sporebat
step
#completewith hydra1end
>>Kill |cRXP_ENEMY_Darkcrest Nagas|r. Loot them for their |cRXP_LOOT_Claws|r
.complete 9728,1 
.mob *Darkcrest Siren
.mob *Darkcrest Slaver
.mob *Darkcrest Sorceress
.mob *Darkcrest Taskmaster
.subzoneskip 3642
step
#completewith Lagoon
.use 24330 >>Kill |cRXP_ENEMY_Steam Pump Overseers|r that spawn after using the |T136074:0|t[Ironvine Seeds] on the Lake Controls. Loot them for their |T134944:0|t[|cRXP_LOOT_Drain Schematics|r]
.collect 24330,1,9731 
.mob Steam Pump Overseer
step
.goto Zangarmarsh,70.60,80.29
.use 24355 >>|cRXP_WARN_Use the|r |T136074:0|t[Ironvine Seeds] |cRXP_WARN_Lake Controls|r
.complete 9720,1 
step
#label Rajah
.goto Zangarmarsh,65.10,68.67
>>Kill |cRXP_ENEMY_Rajah Haghazed|r
>>|cRXP_WARN_Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << tbc/wotlk
.complete 9730,1 
.unitscan Rajah Haghazed
step
#label Lagoon
.goto Zangarmarsh,63.11,64.09
>>|cRXP_WARN_Use the|r |T136074:0|t[Ironvine Seeds] |cRXP_WARN_Lake Controls|r
.complete 9720,4 
.use 24355
step
.goto Zangarmarsh,63.11,64.09
.use 24355 >>|cRXP_WARN_Keep using the|r |T136074:0|t[Ironvine Seeds] |cRXP_WARN_on the Lake Controls to spawn and kill|r |cRXP_ENEMY_Steam Pump Overseers|r. Loot them for their |T134944:0|t[|cRXP_LOOT_Drain Schematics|r]
>>Farm |cRXP_LOOT_Naga Claws|r while you wait for the Seeds to come off cooldown
.collect 24330,1,9731 
step
#sticky
.use 24330 >>|cRXP_WARN_Click the|r |T134944:0|t[|cRXP_LOOT_Drain Schematics|r] |cRXP_WARN_to start the quest|r
.accept 9731 >> Accept Drain Schematics
.mob Steam Pump Overseer
.itemcount 24330,1
step
#label hydra1end
.goto Zangarmarsh,53.79,66.14
>>Kill |cRXP_ENEMY_Mire Hydras|r
.complete 9781,1 
.mob Mire Hydra
step
#label Blacksting
.goto Zangarmarsh,49.80,59.44
>>Kill |cRXP_ENEMY_Blacksting|r. Loot him for his |cRXP_LOOT_Stinger|r
.complete 9896,1 
.mob Blacksting
step
.goto Zangarmarsh,44.13,68.91
>>Enter the Boha'mu Ruins
>>|cRXP_WARN_You don't need to pull the elite!|r
.complete 9786,1 
step
.goto Zangarmarsh,50.39,40.92
>>Head to the middle of the lake, then dive underwater toward the drain
.complete 9731,1 
step
#optional
#completewith next
>>Loot the |cRXP_PICK_Orange Mushrooms|r on the ground throughout Zangarmarsh
.collect 24245,10,9808,1 
step
#completewith next
.goto Zangarmarsh,41.28,29.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halu|r
.fp Orebor Harborage >> Get the Orebor Harborage flight path
.target Halu
step << !Shaman
#completewith next
.goto Zangarmarsh,41.28,29.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halu|r
.fly Telredor >> Fly to Telredor
.target Halu
step << Shaman
#completewith next
.hs >>Hearth to Telredor
step << !Shaman
.goto 1946/530,6040.00000,257.10001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Idaar|r
.target Vindicator Idaar
.turnin 9783 >>Turn in An Unnatural Drought
.accept 9793 >>Accept The Fate of Tuurem << tbc/wotlk
step << !Shaman
.goto 1946/530,6044.89990,278.89999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r
.target Anchorite Ahuurn
.turnin 9786 >>Turn in The Boha'mu Ruins
.accept 9787 >>Accept Idols of the Feralfen
.accept 9776 >>Accept The Orebor Harborage
step << !Shaman
.goto 1946/530,6030.89990,283.60001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Conall|r
.target Prospector Conall
.turnin 9896 >>Turn in Blacksting's Bane
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noraani|r
.turnin 9780 >>Turn in Umbrafen Eel Filets
.target +Noraani
.goto 1946/530,6075.50000,329.39999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haalrun|r
.turnin 9781 >>Turn in Too Many Mouths to Feed
.accept 9790 >>Accept Diaphanous Wings
.goto 1946/530,6065.70020,327.50000
.target +Haalrun
step
.goto Zangarmarsh,68.62,48.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ruam|r
.target Ruam
.turnin 9827 >> Turn in Withered Basidium
.isOnQuest 9827
step << Shaman
.goto 1946/530,6030.89990,283.60001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Conall|r
.target Prospector Conall
.turnin 9896 >>Turn in Blacksting's Bane
step << Shaman
.goto 1946/530,6044.89990,278.89999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r
.target Anchorite Ahuurn
.turnin 9786 >>Turn in The Boha'mu Ruins
.accept 9787 >>Accept Idols of the Feralfen
.accept 9776 >>Accept The Orebor Harborage
step << Shaman
.goto 1946/530,6040.00000,257.10001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Idaar|r
.target Vindicator Idaar
.turnin 9783 >>Turn in An Unnatural Drought
.accept 9793 >>Accept The Fate of Tuurem << tbc/wotlk
step << !tbc
.goto 1946/530,5534.89990,-142.30000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysiel Windsinger|r
.target Ysiel Windsinger
.turnin 9731 >>Turn in Drain Schematics
.accept 9724 >>Accept Warning the Cenarion Circle
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lauranna Thar'well|r
.turnin 9802 >>Turn in Plants of Zangarmarsh
.turnin 10096 >>Turn in Saving the Sporeloks
.goto 1946/530,5438.20020,-215.70000
.target +Lauranna Thar'well
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikeyen|r
.turnin 9788 >>Turn in A Damp, Dark Place
.goto 1946/530,5434.70020,-215.40001
.target +Ikeyen
step
.goto 1946/530,5438.20020,-215.70000
.dailyturnin 9784>>Talk to |cRXP_FRIENDLY_Lauranna Thar'well|r
.disablecheckbox
+Turn in all your |T133940:0|t[Unidentified Plant Parts]
.itemcount 24401,10
.reputation 942,honored,0,1
.target Lauranna Thar'well
step
.goto 1946/530,5434.10010,-234.00000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windcaller Blackhoof|r
.target Windcaller Blackhoof
.turnin 9894 >>Turn in Safeguarding the Watchers
.accept 9785 >> Accept Blessings of the Ancients
step
#sticky
#label ashyen
.goto Zangarmarsh,81.11,63.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ashyen|r
.complete 9785,1 
.skipgossip
.target Ashyen
step
#loop
.goto Zangarmarsh,81.11,64.37,40,0
.goto Zangarmarsh,79.57,64.48,40,0
.goto Zangarmarsh,78.25,63.88,40,0
.goto Zangarmarsh,78.24,65.82,40,0
.goto Zangarmarsh,78.71,66.49,40,0
.goto Zangarmarsh,78.96,67.44,40,0
.line Zangarmarsh,78.96,67.44,78.71,66.49,78.24,65.82,78.25,63.88,79.57,64.48,81.11,64.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keleth|r
>>|cRXP_FRIENDLY_Keleth|r |cRXP_WARN_patrols slighty|r
.complete 9785,2 
.skipgossip
.unitscan Keleth
step
#requires ashyen
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windcaller Blackhoof|r
.turnin 9785 >> Turn in Blessings of the Ancients
.goto Zangarmarsh,80.37,64.73
.target Windcaller Blackhoof
step
#sticky
#label hamoot1a
.goto Zangarmarsh,79.09,65.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Hamoot|r in the Tower
.turnin 9728 >> Turn in A Warm Welcome
.isQuestComplete 9728
.target Warden Hamoot
step
#sticky
#label hamoot2a
.goto Zangarmarsh,79.09,65.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Hamoot|r in the Tower
.turnin 9817 >> Turn in Leader of the Bloodscale
.isQuestComplete 9817
.target Warden Hamoot
step
.goto Zangarmarsh,79.09,65.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Hamoot|r in the Tower
.turnin 9730 >> Turn in Leader of the Darkcrest
.isQuestComplete 9730
.target Warden Hamoot
step
#requires hamoot1a
step
#requires hamoot2a
.goto Zangarmarsh,78.53,63.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lethyn Moonfire|r
.accept 9697 >> Accept Watcher Leesa'oh
.accept 9957 >> Accept What's Wrong at Cenarion Thicket? << tbc/wotlk
.target Lethyn Moonfire
step << tbc
.goto 1946/530,5534.89990,-142.30000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysiel Windsinger|r
.target Ysiel Windsinger
.turnin 9731 >>Turn in Drain Schematics
.accept 9724 >>Accept Warning the Cenarion Circle
step
>>Travel to Cenarion Post
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mahuram Stouthoof|r and |cRXP_FRIENDLY_Amythiel Mistwalker|r
.turnin -10159 >> Turn in Keep Thornfang Hill Clear!
.goto Hellfire Peninsula,15.65,52.15
.turnin 9724 >> Turn in Warning the Cenarion Circle
.accept 9732 >> Accept Return to the Marsh
.goto Hellfire Peninsula,16.04,52.15
.target Mahuram Stouthoof
.target Amythiel Mistwalker
step << Shaman (tbc/wotlk)
#completewith next
.hs >> Hearth to Telredor
.skill riding,225,1
step << tbc/wotlk
#completewith Adal
.goto Hellfire Peninsula,25.19,37.23 << !Shaman
.goto Zangarmarsh,67.83,51.46 << Shaman
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuma|r << !Shaman
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Munci|r << Shaman
.fly Shattrath >> Fly to Shattrath City
.skill riding,225,1
.target Kuma << !Shaman
.target Munci << Shaman
step << tbc/wotlk
#completewith Adal
.goto Shattrath City,59.66,41.45
.zone Shattrath City >> Travel to Shattrath City
.skill riding,<225,1
step << tbc/wotlk
#label Adal
.goto 1955/530,5362.10010,-1832.90002
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haggard War Veteran|r
.target Haggard War Veteran
.accept 10210 >>Accept A'dal
step << tbc/wotlk
.goto 1955/530,5426.70020,-1862.70007
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A'dal|r
.target A'dal
.turnin 10210 >>Turn in A'dal
step << tbc/wotlk
.goto 1955/530,5421.80029,-1859.00000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.target Khadgar
.accept 10211 >>Accept City of Light
.timer 462,City of Light RP
step << tbc/wotlk
#completewith next
#xprate <1.5
>>Whilst following |cRXP_FRIENDLY_Khadgar's Servant|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seth|r
.accept 10037 >> Accept Rather Be Fishin'
.target +Seth
.goto Shattrath City,63.94,15.52
.goto Shattrath City,52.54,21.03
.target Khadgar's Servant
step << tbc/wotlk
.goto Shattrath City,50.36,42.87
>>Follow |cRXP_FRIENDLY_Khadgar's Servant|r << wotlk
>>Head up to the second floor with |cRXP_FRIENDLY_G'eras|r and wait out the RP. If someone elses |cRXP_FRIENDLY_Khadgar's Servant|r arrives in the meantime, you can target it and it will complete the quest for you. If the quest fails, abandon it, accept the quest from |cRXP_FRIENDLY_Khadgar's Servant|r again, then follow the |cRXP_FRIENDLY_Khadgar's Servant|r around << tbc
.complete 10211,1 
.target Khadgar's Servant
step << Mage (tbc/wotlk)
.goto Shattrath City,58.77,47.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iorioa|r
.train 35715 >> Train Teleport: Shattrath and Portal: Shattrath
.target Iorioa
step << tbc/wotlk
.goto Shattrath City,54.74,44.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.turnin 10211 >> Turn in City of Light
.target Khadgar
step << tbc/wotlk
.goto Shattrath City,54.74,44.32
.turninmultiple 10551,10552>>Talk to |cRXP_FRIENDLY_Khadgar's Servant|r. Pledge your Allegiance to either the Aldor or Scryers
*If you do not see Aldor or Scryer specific quest steps after this, type "/reload" into your ingame chat box
.target Khadgar
.isQuestAvailable 10551
.isQuestAvailable 10552
step << tbc/wotlk
#scryer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.goto Shattrath City,54.74,44.32
.accept 10553 >>Accept Voren'thal the Seer
.target Khadgar
step << tbc/wotlk
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.goto Shattrath City,54.74,44.32
.accept 10554 >> Accept Ishanah
.target Khadgar
step << (Warlock/Shaman/Paladin/Mage) (tbc/wotlk)
#completewith next
.goto Shattrath City,55.7,36.9 << !Mage
.zone Stormwind City >> Take the portal to Stormwind << !Mage
.zone Stormwind City >> Teleport to Stormwind << Mage
step << (Warlock/Shaman/Paladin/Mage) (tbc/wotlk)
.goto StormwindClassic,25.3,78.7 << Warlock
.goto StormwindClassic,38.6,32.8 << Paladin
.goto StormwindClassic,61.9,84.0 << Shaman
.goto StormwindClassic,39.6,79.6 << Mage
.trainer >> Train your class spells << cata
.target Ursula Deline << Warlock
.target Demisette Cloyce << Warlock
.target Sandahl << Warlock
.target Arthur the Faithful << Paladin
.target Katherine the Pure << Paladin
.target Lord Grayson Shadowbreaker << Paladin
.target Farseer Umbrua << Shaman
.target Elsharin << Mage
.target Jennea Cannon << Mage
step << (Warrior/Hunter/Rogue/Priest) (tbc/wotlk)
#completewith next
.goto Shattrath City,55.2,36.5
.zone Darnassus >> Take the portal to Darnassus
step << (Warrior/Hunter/Rogue/Priest) (tbc/wotlk)
.goto Darnassus,39.0,83.2 << Priest
.goto Darnassus,40.6,9.2 << Hunter
.goto Darnassus,31.5,17.4 << Rogue
.goto Darnassus,58.75,35.16 << Warrior
.trainer >> Train your class spells << cata
.target Jandria << Priest
.target Jocaste << Hunter
.target Anishar << Rogue
.target Erion Shadewhisper << Rogue
.target Syurna << Rogue
.target Arias'ta Bladesinger << Warrior
step << Druid (tbc/wotlk)
>>Teleport to Moonglade
.goto Moonglade,52.4,40.6
.trainer 12042 >> Train your class spells << cata
.target Loganaar << Druid
step << DK (tbc/wotlk)
#completewith next
.cast 50977 >> Cast Death Gate
.zoneskip Eastern Plaguelands
step << DK (tbc/wotlk)
.goto Eastern Plaguelands,80.3,48.0
>>Go through the Death Gate
.trainer >> Train your class spells from |cRXP_FRIENDLY_Amal'thazad|r in Acherus << cata
.target Amal'thazad
step
#completewith Vial
.hs >> Hearth to Telredor
step
#completewith next
.goto Zangarmarsh,67.83,51.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Munci|r
.fly Orebor Harborage >> Fly to Orebor Harborage
.skill riding,300,1
.target Munci
step
.goto 1946/530,7400.70020,973.50000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Timothy Daniels|r
.target Timothy Daniels
.accept 9848 >>Accept Secrets of the Daggerfen
step
.goto 1946/530,7376.20020,1019.90002
>>|TInterface/cursor/crosshair/interact.blp:20|tClick the |cRXP_FRIENDLY_Wanted Poster|r
.accept 10116 >>Accept Wanted: Chieftain Mummaki
step
.goto 1946/530,7367.70020,1022.60004
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikuti|r
.target Ikuti
.accept 9835 >>Accept Ango'rosh Encroachment
.accept 10115 >>Accept Daggerfen Deviance
.turnin 9776 >>Turn in The Orebor Harborage
step
#optional
#completewith Vial
>>Kill |cRXP_ENEMY_Greater Sporebats|r and |cRXP_ENEMY_Marsh Walkers|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Greater Sporebat
.mob *Marsh Walker
.subzoneskip 3640
step
#optional
#completewith Vial
>>Loot the |cRXP_PICK_Orange Mushrooms|r on the ground throughout Zangarmarsh
.collect 24245,10,9808,1 
step
#optional
#completewith Mummaki
>>Kill |cRXP_ENEMY_Daggerfen Assassins|r and |cRXP_ENEMY_Daggerfen Muckdwellers|r
.complete 10115,1 
.mob +Daggerfen Assassin
.complete 10115,2 
.mob +Daggerfen Muckdweller
step
#label Vial
.goto Zangarmarsh,26.40,22.85
>>Loot the small |cRXP_PICK_Daggerfen Poison Vial|r on the ground
.complete 9848,2 
step
#label Mummaki
>>Kill |cRXP_ENEMY_Chieftain Mummaki|r atop the tower. Loot him for his |cRXP_LOOT_Totem|r
>>Loot the |cRXP_PICK_Daggerfen Poison Manual|r book on the top floor near |cRXP_ENEMY_Mummaki|r
.complete 10116,1 
.goto Zangarmarsh,23.77,26.74,-1
.complete 9848,1 
.goto Zangarmarsh,24.40,27.00,-1
.unitscan Chieftain Mummaki
step
#optional
#completewith Oreboring
>>Kill |cRXP_ENEMY_Greater Sporebats|r and |cRXP_ENEMY_Marsh Walkers|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Greater Sporebat
.mob *Marsh Walker
step
#loop
.line Zangarmarsh,24.58,26.44,25.83,27.17,27.06,25.42,28.18,23.79,28.50,22.23,26.24,22.36,26.31,20.43,25.00,20.56,24.87,22.28,22.89,21.07,22.24,22.32,24.22,24.50,25.74,24.95,24.58,26.44
.goto Zangarmarsh,24.58,26.44,50,0
.goto Zangarmarsh,25.83,27.17,50,0
.goto Zangarmarsh,27.06,25.42,50,0
.goto Zangarmarsh,28.18,23.79,50,0
.goto Zangarmarsh,28.50,22.23,50,0
.goto Zangarmarsh,26.24,22.36,50,0
.goto Zangarmarsh,26.31,20.43,50,0
.goto Zangarmarsh,25.00,20.56,50,0
.goto Zangarmarsh,24.87,22.28,50,0
.goto Zangarmarsh,22.89,21.07,50,0
.goto Zangarmarsh,22.24,22.32,50,0
.goto Zangarmarsh,24.22,24.50,50,0
.goto Zangarmarsh,25.74,24.95,50,0
.goto Zangarmarsh,24.58,26.44,50,0
>>Kill |cRXP_ENEMY_Daggerfen Assassins|r and |cRXP_ENEMY_Daggerfen Muckdwellers|r
.complete 10115,1 
.mob +Daggerfen Assassin
.complete 10115,2 
.mob +Daggerfen Muckdweller
step
#optional
#completewith Oreboring
>>Loot |cRXP_PICK_Glowcaps|r on the ground throughout Zangarmarsh
.collect 24245,10,9808,1 
step
#loop
.line Zangarmarsh,28.90,27.88,29.29,26.89,30.66,26.89,32.03,27.30,33.20,28.97,35.19,26.85,37.09,26.88,38.88,28.22,37.80,28.63,36.08,29.61,36.41,32.55,36.40,33.65,35.11,34.53,34.27,33.37,34.45,31.45,33.94,30.16,32.44,32.76,31.67,30.44,29.97,30.13,28.90,27.88
.goto Zangarmarsh,28.90,27.88,50,0
.goto Zangarmarsh,29.29,26.89,50,0
.goto Zangarmarsh,30.66,26.89,50,0
.goto Zangarmarsh,32.03,27.30,50,0
.goto Zangarmarsh,33.20,28.97,50,0
.goto Zangarmarsh,35.19,26.85,50,0
.goto Zangarmarsh,37.09,26.88,50,0
.goto Zangarmarsh,38.88,28.22,50,0
.goto Zangarmarsh,37.80,28.63,50,0
.goto Zangarmarsh,36.08,29.61,50,0
.goto Zangarmarsh,36.41,32.55,50,0
.goto Zangarmarsh,36.40,33.65,50,0
.goto Zangarmarsh,35.11,34.53,50,0
.goto Zangarmarsh,34.27,33.37,50,0
.goto Zangarmarsh,34.45,31.45,50,0
.goto Zangarmarsh,33.94,30.16,50,0
.goto Zangarmarsh,32.44,32.76,50,0
.goto Zangarmarsh,31.67,30.44,50,0
.goto Zangarmarsh,29.97,30.13,50,0
.goto Zangarmarsh,28.90,27.88,50,0
>>Kill |cRXP_ENEMY_Ango'rosh Shamans|r and |cRXP_ENEMY_Ogres|r
.complete 9835,1 
.mob +Ango'rosh Shaman
.complete 9835,2 
.mob +Ango'rosh Ogre
step
#label Oreboring
.goto Zangarmarsh,41.94,27.19
>>Return to Orebor Harborage
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikuti|r
.turnin 9835 >> Turn in Ango'rosh Encroachment
.accept 9839 >> Accept Overlord Gorefist
.turnin 10115 >> Turn in Daggerfen Deviance
.turnin 10116 >> Turn in Wanted: Chieftain Mummaki
.target Ikuti
step
#completewith Sporelings
.goto Zangarmarsh,41.85,26.22
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Kerp|r
.home >> Set your Hearthstone to Orebor Harborage
.target Innkeeper Kerp
step
.goto 1946/530,7382.50000,1019.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maktu|r
.target Maktu
.accept 9834 >>Accept Natural Armor
step
.goto 1946/530,7401.50000,976.40002
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Timothy Daniels|r
.target Timothy Daniels
.turnin 9848 >>Turn in Secrets of the Daggerfen
step
.goto 1946/530,7421.0,976.29999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Puluu|r
.target Puluu
.accept 9830 >>Accept Stinger Venom
.accept 9833 >>Accept Lines of Communication
.accept 9902 >>Accept The Terror of Marshlight Lake
step
#optional
#completewith Sporelings
>>Loot |cRXP_PICK_Glowcaps|r on the ground throughout Zangarmarsh
.collect 24245,10,9808,1 
step
#optional
#completewith Sporelings
>>Kill |cRXP_ENEMY_Greater Sporebats|r and |cRXP_ENEMY_Marsh Walkers|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Greater Sporebat
.mob *Marsh Walker
step
#optional
#completewith Sporelings
>>Kill |cRXP_ENEMY_Marshfang Slicers|r
.complete 9833,1 
.mob Marshfang Slicer
step
#label Leesa1
.goto Zangarmarsh,23.32,66.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Leesa'oh|r
.turnin 9697 >> Turn in Watcher Leesa'oh
.accept 9701 >> Accept Observing the Sporelings
.target Watcher Leesa'oh
step
#label Sporelings
.goto Zangarmarsh,19.03,62.34,50,0
.goto Zangarmarsh,19.19,64.60
.line Zangarmarsh,19.03,62.34,19.19,64.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahssn|r. He patrols around slightly
.accept 9739 >> Accept The Sporelings' Plight
.accept 9743 >> Accept Natural Enemies
.target Fahssn
step
#optional
#completewith Tendrils
>>Collect |cRXP_PICK_Sacs|r (they look like balloons) on the ground
.complete 9739,1 
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Bog Lords|r. Loot them for their |cRXP_LOOT_Tendrils|r
.complete 9743,1 
.mob Starving Fungal Giant
.mob Starving Bog Lord
.mob Bog Lord
step
.goto Zangarmarsh,14.95,59.88
>>Travel near to the Spawning Glen
.complete 9701,1 
step
#label Tendrils
#loop
.line Zangarmarsh,13.76,57.97,10.51,60.28,10.53,62.68,13.24,63.84,17.35,63.48,17.46,57.13,13.76,57.97
.goto Zangarmarsh,13.76,57.97,60,0
.goto Zangarmarsh,10.51,60.28,60,0
.goto Zangarmarsh,10.53,62.68,60,0
.goto Zangarmarsh,13.24,63.84,60,0
.goto Zangarmarsh,17.35,63.48,60,0
.goto Zangarmarsh,17.46,57.13,60,0
.goto Zangarmarsh,13.76,57.97,60,0
>>Kill |cRXP_ENEMY_Bog Lords|r. Loot them for their |cRXP_LOOT_Tendrils|r
.complete 9743,1 
.mob Starving Fungal Giant
.mob Starving Bog Lord
.mob Bog Lord
step
#loop
.line Zangarmarsh,13.76,57.97,10.51,60.28,10.53,62.68,13.24,63.84,17.35,63.48,17.46,57.13,13.76,57.97
.goto Zangarmarsh,13.76,57.97,60,0
.goto Zangarmarsh,10.51,60.28,60,0
.goto Zangarmarsh,10.53,62.68,60,0
.goto Zangarmarsh,13.24,63.84,60,0
.goto Zangarmarsh,17.35,63.48,60,0
.goto Zangarmarsh,17.46,57.13,60,0
.goto Zangarmarsh,13.76,57.97,60,0
>>Collect |cRXP_PICK_Sacs|r (they look like balloons) on the ground
.complete 9739,1 
step
#optional
#completewith Idols
>>Loot |cRXP_PICK_Glowcaps|r on the ground throughout Zangarmarsh
.collect 24245,10,9808,1 
step
#optional
#completewith Ungula
>>Kill |cRXP_ENEMY_Marshfang Slicers|r
.complete 9833,1 
.mob Marshfang Slicer
step
.goto Zangarmarsh,19.03,62.34,50,0
.goto Zangarmarsh,19.19,64.60
.line Zangarmarsh,19.03,62.34,19.19,64.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahssn|r. He patrols around slightly
.turnin 9739 >> Turn in The Sporelings' Plight
.turnin 9743 >> Turn in Natural Enemies
.target Fahssn
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Greater Sporebats|r and |cRXP_ENEMY_Marsh Walkers|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Greater Sporebat
.mob *Marsh Walker
step
#label Lessa2
.goto Zangarmarsh,23.32,66.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Leesa'oh|r
.turnin 9701 >> Turn in Observing the Sporelings
.accept 9702 >> Accept A Question of Gluttony
.target Watcher Leesa'oh
step
#label Nutriment
#loop
.line Zangarmarsh,26.31,62.73,27.31,66.10,28.34,63.77,29.80,65.23,31.36,67.21,32.31,65.48,33.59,65.76,32.31,65.48,30.89,63.10,31.89,60.49,29.28,59.50,29.10,62.48,26.31,62.73
.goto Zangarmarsh,26.31,62.73,60,0
.goto Zangarmarsh,27.31,66.10,60,0
.goto Zangarmarsh,28.34,63.77,60,0
.goto Zangarmarsh,29.80,65.23,60,0
.goto Zangarmarsh,31.36,67.21,60,0
.goto Zangarmarsh,32.31,65.48,60,0
.goto Zangarmarsh,33.59,65.76,60,0
.goto Zangarmarsh,32.31,65.48,60,0
.goto Zangarmarsh,30.89,63.10,60,0
.goto Zangarmarsh,31.89,60.49,60,0
.goto Zangarmarsh,29.28,59.50,60,0
.goto Zangarmarsh,29.10,62.48,60,0
.goto Zangarmarsh,26.31,62.73,60,0
>>Loot the |cRXP_PICK_Discarded Nutriments|r (small mushrooms) on the ground
.complete 9702,1 
step << !tbc
.goto Zangarmarsh,32.86,59.52
.use 25459 >>Kill |cRXP_ENEMY_"Count" Ungula|r. Loot him for his |cRXP_LOOT_Mandible|r. Click |T135592:0|t["Count" Ungula's Mandible] in your bags
.collect 25459,1,9911 
.accept 9911 >> Accept The Count of the Marshes
.unitscan "Count" Ungula
step << tbc
#loop
.line Zangarmarsh,26.31,62.73,27.31,66.10,28.34,63.77,29.80,65.23,31.36,67.21,32.31,65.48,33.59,65.76,32.31,65.48,30.89,63.10,31.89,60.49,29.28,59.50,29.10,62.48,26.31,62.73
.goto Zangarmarsh,26.31,62.73,60,0
.goto Zangarmarsh,27.31,66.10,60,0
.goto Zangarmarsh,28.34,63.77,60,0
.goto Zangarmarsh,29.80,65.23,60,0
.goto Zangarmarsh,31.36,67.21,60,0
.goto Zangarmarsh,32.31,65.48,60,0
.goto Zangarmarsh,33.59,65.76,60,0
.goto Zangarmarsh,32.31,65.48,60,0
.goto Zangarmarsh,30.89,63.10,60,0
.goto Zangarmarsh,31.89,60.49,60,0
.goto Zangarmarsh,29.28,59.50,60,0
.goto Zangarmarsh,29.10,62.48,60,0
.goto Zangarmarsh,26.31,62.73,60,0
>>Kill |cRXP_ENEMY_Bog Lords|r. Loot them for their |cRXP_LOOT_Tendrils|r
.collect 24291,6 
.reputation 970,neutral,0,1
.mob Starving Fungal Giant
.mob Starving Bog Lord
.mob Bog Lord
step
#loop
.line Zangarmarsh,26.31,62.73,27.31,66.10,28.34,63.77,29.80,65.23,31.36,67.21,32.31,65.48,33.59,65.76,32.31,65.48,30.89,63.10,31.89,60.49,29.28,59.50,29.10,62.48,26.31,62.73
.goto Zangarmarsh,26.31,62.73,60,0
.goto Zangarmarsh,27.31,66.10,60,0
.goto Zangarmarsh,28.34,63.77,60,0
.goto Zangarmarsh,29.80,65.23,60,0
.goto Zangarmarsh,31.36,67.21,60,0
.goto Zangarmarsh,32.31,65.48,60,0
.goto Zangarmarsh,33.59,65.76,60,0
.goto Zangarmarsh,32.31,65.48,60,0
.goto Zangarmarsh,30.89,63.10,60,0
.goto Zangarmarsh,31.89,60.49,60,0
.goto Zangarmarsh,29.28,59.50,60,0
.goto Zangarmarsh,29.10,62.48,60,0
.goto Zangarmarsh,26.31,62.73,60,0
.reputation 970,neutral,0 >> Grind |cRXP_ENEMY_Bog Lords|r until you're |cRXP_WARN_Neutral|r with Sporeggar
.mob Starving Fungal Giant
.mob Starving Bog Lord
.mob Bog Lord
step << !tbc
.goto Zangarmarsh,19.03,62.34,50,0
.goto Zangarmarsh,19.19,64.60
.line Zangarmarsh,19.03,62.34,19.19,64.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahssn|r. He patrols around slightly
.accept 9919 >> Accept Sporeggar
.mob Starving Fungal Giant
.mob Starving Bog Lord
.mob Bog Lord
step
#questguide << !tbc
.goto Zangarmarsh,23.32,66.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lessa'oh|r
.turnin 9702 >> Turn in A Question of Gluttony
.accept 9708 >> Accept Familiar Fungi
.target Watcher Leesa'oh
step << tbc
#label Ungula
.goto Zangarmarsh,32.86,59.52
.use 25459 >>Kill |cRXP_ENEMY_"Count" Ungula|r. Loot him for his |cRXP_LOOT_Mandible|r. Click |T135592:0|t["Count" Ungula's Mandible] in your bags
.collect 25459,1,9911 
.accept 9911 >> Accept The Count of the Marshes
.unitscan "Count" Ungula
step << !tbc
#label Ungula
.goto Zangarmarsh,23.32,66.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lessa'oh|r
.turnin 9911 >> Turn in The Count of the Marshes
.turnin 9702 >> Turn in A Question of Gluttony
.target Watcher Leesa'oh
step
#optional
#completewith Idols
>>Kill |cRXP_ENEMY_Fen Striders|r and |cRXP_ENEMY_Greater Sporebats|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Greater Sporebat
.mob *Fen Strider
.mob *Marsh Walker
.mob *Sporebat
step
#loop
.line Zangarmarsh,32.12,59.16,32.87,60.25,34.12,62.12,35.08,63.37,37.14,62.08,39.08,63.53,38.99,59.32,36.85,56.26,34.96,59.53,33.60,57.06,32.12,59.16
.goto Zangarmarsh,32.12,59.16,50,0
.goto Zangarmarsh,32.87,60.25,50,0
.goto Zangarmarsh,34.12,62.12,50,0
.goto Zangarmarsh,35.08,63.37,50,0
.goto Zangarmarsh,37.14,62.08,50,0
.goto Zangarmarsh,39.08,63.53,50,0
.goto Zangarmarsh,38.99,59.32,50,0
.goto Zangarmarsh,36.85,56.26,50,0
.goto Zangarmarsh,34.96,59.53,50,0
.goto Zangarmarsh,33.60,57.06,50,0
.goto Zangarmarsh,32.12,59.16,50,0
>>Kill |cRXP_ENEMY_Marshfang Slicers|r
.complete 9833,1 
.mob Marshfang Slicer
step
#label Idols
.goto Zangarmarsh,46.09,57.76,20,0
.goto Zangarmarsh,46.17,59.79,20,0
.goto Zangarmarsh,45.93,60.71,20,0
.goto Zangarmarsh,46.25,60.96,20,0
.goto Zangarmarsh,47.46,61.77,20,0
.goto Zangarmarsh,49.09,61.27,20,0
.goto Zangarmarsh,49.24,60.72,20,0
.goto Zangarmarsh,49.70,61.09,20,0
.goto Zangarmarsh,48.19,63.81,20,0
.goto Zangarmarsh,47.90,64.20,20,0
.goto Zangarmarsh,48.59,64.71,20,0
.goto Zangarmarsh,43.24,62.40
>>Loot the small stone |cRXP_PICK_Idols|r on the ground
.complete 9787,1 
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Fen Striders|r and |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Greater Sporebat
.mob *Fen Strider
.mob *Marsh Walker
.mob *Sporebat
.subzoneskip 3653
step << !Warlock
#completewith next
.cast 22807 >> Use the |T134716:0|t[Potion of Water Breathing] in your bags
.use 25539
step
#loop
.line Zangarmarsh,48.35,45.31,49.52,44.88,50.82,45.18,51.57,44.16,51.35,42.51,52.25,43.34,52.99,42.77,53.30,41.79,52.45,41.36,52.67,39.01,50.99,37.35,50.26,36.26,48.89,38.04,48.07,39.03,48.73,40.09,47.66,40.78,47.74,41.81,49.00,42.23,48.35,45.31
.goto Zangarmarsh,48.35,45.31,50,0
.goto Zangarmarsh,49.52,44.88,50,0
.goto Zangarmarsh,50.82,45.18,50,0
.goto Zangarmarsh,51.57,44.16,50,0
.goto Zangarmarsh,51.35,42.51,50,0
.goto Zangarmarsh,52.25,43.34,50,0
.goto Zangarmarsh,52.99,42.77,50,0
.goto Zangarmarsh,53.30,41.79,50,0
.goto Zangarmarsh,52.45,41.36,50,0
.goto Zangarmarsh,52.67,39.01,50,0
.goto Zangarmarsh,50.99,37.35,50,0
.goto Zangarmarsh,50.26,36.26,50,0
.goto Zangarmarsh,48.89,38.04,50,0
.goto Zangarmarsh,48.07,39.03,50,0
.goto Zangarmarsh,48.73,40.09,50,0
.goto Zangarmarsh,47.66,40.78,50,0
.goto Zangarmarsh,47.74,41.81,50,0
.goto Zangarmarsh,49.00,42.23,50,0
.goto Zangarmarsh,48.35,45.31,50,0
>>Kill |cRXP_ENEMY_Fenclaw Thrashers|r underwater. Loot them for their |cRXP_LOOT_Hides|r
.complete 9834,1 
.mob Fenclaw Thrasher
step << Shaman
#completewith next
.hs >> Hearth to Orebor Harborage
step
#optional
#completewith Orebor1
>>Kill |cRXP_ENEMY_Greater Sporebats|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob *Greater Sporebat
.mob *Marsh Walker
step
#optional
#completewith FSpores
>>Loot |cRXP_PICK_Glowcaps|r on the ground throughout Zangarmarsh
.collect 24245,10,9808,1 
step
.goto 1946/530,7383.70020,1020.29999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maktu|r
.target Maktu
.turnin 9834 >>Turn in Natural Armor
.accept 9905 >>Accept Maktu's Revenge
step
.goto 1946/530,7422.10010,974.29999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Puluu|r
.target Puluu
.turnin 9833 >>Turn in Lines of Communication
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Bogflare Needlers|r. Loot them for their |cRXP_LOOT_Wings|r
.complete 9790,1 
.mob Bogflare Needler
step
.goto Zangarmarsh,42.24,41.40
>>Kill |cRXP_ENEMY_Mragesh|r
.complete 9905,1 
.unitscan Mragesh
step
#questguide << !tbc
#loop
.line Zangarmarsh,28.90,27.88,29.29,26.89,30.66,26.89,32.03,27.30,33.20,28.97,35.19,26.85,37.09,26.88,38.88,28.22,37.80,28.63,36.08,29.61,36.41,32.55,36.40,33.65,35.11,34.53,34.27,33.37,34.45,31.45,33.94,30.16,32.44,32.76,31.67,30.44,29.97,30.13,28.90,27.88
.goto Zangarmarsh,28.90,27.88,50,0
.goto Zangarmarsh,29.29,26.89,50,0
.goto Zangarmarsh,30.66,26.89,50,0
.goto Zangarmarsh,32.03,27.30,50,0
.goto Zangarmarsh,33.20,28.97,50,0
.goto Zangarmarsh,35.19,26.85,50,0
.goto Zangarmarsh,37.09,26.88,50,0
.goto Zangarmarsh,38.88,28.22,50,0
.goto Zangarmarsh,37.80,28.63,50,0
.goto Zangarmarsh,36.08,29.61,50,0
.goto Zangarmarsh,36.41,32.55,50,0
.goto Zangarmarsh,36.40,33.65,50,0
.goto Zangarmarsh,35.11,34.53,50,0
.goto Zangarmarsh,34.27,33.37,50,0
.goto Zangarmarsh,34.45,31.45,50,0
.goto Zangarmarsh,33.94,30.16,50,0
.goto Zangarmarsh,32.44,32.76,50,0
.goto Zangarmarsh,31.67,30.44,50,0
.goto Zangarmarsh,29.97,30.13,50,0
.goto Zangarmarsh,28.90,27.88,50,0
>>Kill |cRXP_ENEMY_Ango'rosh Ogres|r, |cRXP_ENEMY_Ango'rosh Sentries|r and |cRXP_ENEMY_Ango'rosh Shamans|r. Loot them for their |cRXP_LOOT_Mushrooms|r
.complete 9708,1 
.mob Ango'rosh Ogre
.mob Ango'rosh Sentry
.mob Ango'rosh Shaman
.mob Boss Grog'ak
step
#optional
#completewith MarshControls
>>Kill |cRXP_ENEMY_Marshlight Bleeders|r. Loot them for their |cRXP_LOOT_Venom|r and |cRXP_LOOT_Wings|r
.complete 9830,1 
.complete 9790,1 
.mob Marshlight Bleeder
step
#questguide << !tbc
.goto Zangarmarsh,23.32,66.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lessa'oh|r
.turnin 9708 >> Turn in Familiar Fungi
.accept 9709 >> Accept Stealing Back the Mushrooms
.turnin 9911 >> Turn in The Count of the Marshes
.target Watcher Leesa'oh
step
#label Orebor1
step << tbc
#optional
#completewith next
>>Kill |cRXP_ENEMY_Greater Sporebats|r and |cRXP_ENEMY_Marsh Walkers|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob Greater Sporebat
.mob Marsh Walker
step << tbc
#label Sporeggar
.goto Zangarmarsh,19.03,62.34,60,0
.goto Zangarmarsh,19.19,64.60
.line Zangarmarsh,19.03,62.34,19.19,64.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahssn|r. He patrols around slightly
.accept 9919 >> Accept Sporeggar
.turnin 9744 >> Turn in More Tendrils!
.target Fahssn
step
#label FSpores
#loop
.line Zangarmarsh,20.87,66.51,21.59,60.30,22.02,58.36,20.27,57.74,18.36,55.46,21.05,52.64,25.47,57.26,20.87,66.51
.goto Zangarmarsh,20.87,66.51,50,0
.goto Zangarmarsh,21.59,60.30,50,0
.goto Zangarmarsh,22.02,58.36,50,0
.goto Zangarmarsh,20.27,57.74,50,0
.goto Zangarmarsh,18.36,55.46,50,0
.goto Zangarmarsh,21.05,52.64,50,0
.goto Zangarmarsh,25.47,57.26,50,0
.goto Zangarmarsh,20.87,66.51,50,0
>>Kill |cRXP_ENEMY_Greater Sporebats|r and |cRXP_ENEMY_Marsh Walkers|r. Loot them for their |cRXP_LOOT_Fertile Spores|r
.collect 24449,6,9806,1 
.mob Greater Sporebat
.mob Marsh Walker
step
#loop
.line Zangarmarsh,19.40,64.97,22.18,63.38,32.63,54.20,27.28,52.55,27.74,47.76,21.27,54.58,19.70,51.18,19.40,64.97
.goto Zangarmarsh,19.40,64.97,50,0
.goto Zangarmarsh,22.18,63.38,50,0
.goto Zangarmarsh,32.63,54.20,50,0
.goto Zangarmarsh,27.28,52.55,50,0
.goto Zangarmarsh,27.74,47.76,50,0
.goto Zangarmarsh,21.27,54.58,50,0
.goto Zangarmarsh,19.70,51.18,50,0
.goto Zangarmarsh,19.40,64.97,50,0
>>Loot |cRXP_PICK_Glowcaps|r on the ground throughout Zangarmarsh
.collect 24245,10,9808,1 
step
.goto 1946/530,8487.50000,191.90001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Msshi'fn|r
.target Msshi'fn
.turnin 9919 >>Turn in Sporeggar
.accept 9808 >>Accept Glowcap Mushrooms
.turnin 9808 >>Turn in Glowcap Mushrooms
step
.goto 1946/530,8511.79980,278.50000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gshaff|r
.target Gshaff
.accept 9806 >>Accept Fertile Spores
.turnin 9806 >>Turn in Fertile Spores
step
#questguide << !tbc
.goto Zangarmarsh,15.58,60.02
.reputation 970,friendly >> Grind |cRXP_ENEMY_Bog Lords|r until you're at |cRXP_FRIENDLY_Friendly|r Reputation
.mob Starving Fungal Giant
.mob Starving Bog Lord
.mob Bog Lord
step
#questguide << !tbc
>>Talk to |cRXP_FRIENDLY_Gzhun'tt|r
.accept 9726 >> Accept Now That We're Friends...
.goto Zangarmarsh,19.54,50.04
.target Gzhun'tt
step
.goto Zangarmarsh,22.34,45.89
>>Kill |cRXP_ENEMY_Terroclaw|r on the island
.complete 9902,1 
.unitscan Terrorclaw
step
#optional
#completewith Bloodscale
>>Kill |cRXP_ENEMY_Bloodscale Slavedrivers|r and |cRXP_ENEMY_Bloodscale Enchantresses|r. Loot them for their |cRXP_LOOT_Claws|r
.complete 9728,1 
.mob Bloodscale Enchantress
.mob Bloodscale Slavedriver
step
#questguide << !tbc
#optional
#completewith next
>>Kill |cRXP_ENEMY_Bloodscale Slavedrivers|r and |cRXP_ENEMY_Bloodscale Enchantresses|r
.complete 9726,1 
.mob +Bloodscale Slavedriver
.complete 9726,2 
.mob +Bloodscale Enchantress
.isOnQuest 9726
step
#label MarshControls
.goto Zangarmarsh,25.41,42.86
.use 24355 >>|cRXP_WARN_Use the|r |T136074:0|t[Ironvine Seeds] |cRXP_WARN_on the Lake Controls|r
.complete 9720,2 
step
#questguide << !tbc
#loop
.line Zangarmarsh,24.93,41.85,26.13,40.93,25.79,39.22,24.82,38.46,24.94,36.37,26.38,35.80,28.29,36.89,29.06,38.57,28.49,40.87,28.02,41.90,29.07,44.08,27.72,44.48,26.80,43.70,26.68,46.24,25.85,47.27,25.18,43.82,24.93,41.85
.goto Zangarmarsh,24.93,41.85,50,0
.goto Zangarmarsh,26.13,40.93,50,0
.goto Zangarmarsh,25.79,39.22,50,0
.goto Zangarmarsh,24.82,38.46,50,0
.goto Zangarmarsh,24.94,36.37,50,0
.goto Zangarmarsh,26.38,35.80,50,0
.goto Zangarmarsh,28.29,36.89,50,0
.goto Zangarmarsh,29.06,38.57,50,0
.goto Zangarmarsh,28.49,40.87,50,0
.goto Zangarmarsh,28.02,41.90,50,0
.goto Zangarmarsh,29.07,44.08,50,0
.goto Zangarmarsh,27.72,44.48,50,0
.goto Zangarmarsh,26.80,43.70,50,0
.goto Zangarmarsh,26.68,46.24,50,0
.goto Zangarmarsh,25.85,47.27,50,0
.goto Zangarmarsh,25.18,43.82,50,0
.goto Zangarmarsh,24.93,41.85,50,0
>>Kill |cRXP_ENEMY_Bloodscale Slavedrivers|r and |cRXP_ENEMY_Bloodscale Enchantresses|r
.complete 9726,1 
.mob +Bloodscale Slavedriver
.complete 9726,2 
.mob +Bloodscale Enchantress
.isOnQuest 9726
step
#label Bloodscale
step
#optional
#completewith Gorefist
.goto Zangarmarsh,27.73,32.32,60,0
.goto Zangarmarsh,25.87,33.28,60,0
.goto Zangarmarsh,25.71,31.64,60,0
.goto Zangarmarsh,24.78,29.79,60,0
.goto Zangarmarsh,24.27,31.62,60,0
.goto Zangarmarsh,22.83,31.15,60,0
.goto Zangarmarsh,21.23,32.21,60,0
.goto Zangarmarsh,20.51,31.27,60,0
.goto Zangarmarsh,18.84,35.49,60,0
>>Kill |cRXP_ENEMY_Marshlight Bleeders|r. Loot them for their |cRXP_LOOT_Venom|r and |cRXP_LOOT_Wings|r
.complete 9830,1 
.complete 9790,1 
.mob Marshlight Bleeder
.subzoneskip 3651
step
#completewith Gorefist
.goto Zangarmarsh,17.08,13.10,40 >> Cross the Mushroom bridge
.skill riding,225,1
step
#sticky
#label Gorefist
.goto Zangarmarsh,18.40,7.79
>>Kill |cRXP_ENEMY_Gorefist|r inside the building
.complete 9839,1 
.unitscan Overlord Gorefist
step
#questguide << !tbc
#loop
.goto Zangarmarsh,16.64,7.63,50,0
.goto Zangarmarsh,17.13,4.07,50,0
.goto Zangarmarsh,19.14,4.08,50,0
.goto Zangarmarsh,21.02,4.08,50,0
.goto Zangarmarsh,20.93,8.05,50,0
.goto Zangarmarsh,17.28,9.84,50,0
.goto Zangarmarsh,19.93,6.70,50,0
.goto Zangarmarsh,19.14,4.08,50,0
.goto Zangarmarsh,16.64,7.63,50,0
.goto Zangarmarsh,17.13,4.07,50,0
.goto Zangarmarsh,19.14,4.08,50,0
.goto Zangarmarsh,21.02,4.08,50,0
.goto Zangarmarsh,20.93,8.05,50,0
.goto Zangarmarsh,17.28,9.84,50,0
.goto Zangarmarsh,19.93,6.70,50,0
.goto Zangarmarsh,19.14,4.08,0
>>Kill |cRXP_ENEMY_Ango'rosh Maulers|r. Loot them for their |cRXP_LOOT_Boxes of Mushrooms|r
>>You can also loot |cRXP_LOOT_Boxes of Mushrooms|r on the ground
.complete 9839,2 
.disablecheckbox
.complete 9709,1 
.mob Ango'rosh Mauler
step
#loop
.goto Zangarmarsh,16.64,7.63,50,0
.goto Zangarmarsh,17.13,4.07,50,0
.goto Zangarmarsh,19.14,4.08,50,0
.goto Zangarmarsh,21.02,4.08,50,0
.goto Zangarmarsh,20.93,8.05,50,0
.goto Zangarmarsh,17.28,9.84,50,0
.goto Zangarmarsh,19.93,6.70,50,0
.goto Zangarmarsh,19.14,4.08,50,0
.goto Zangarmarsh,16.64,7.63,50,0
.goto Zangarmarsh,17.13,4.07,50,0
.goto Zangarmarsh,19.14,4.08,50,0
.goto Zangarmarsh,21.02,4.08,50,0
.goto Zangarmarsh,20.93,8.05,50,0
.goto Zangarmarsh,17.28,9.84,50,0
.goto Zangarmarsh,19.93,6.70,50,0
.goto Zangarmarsh,19.14,4.08,0
>>Finish off |cRXP_ENEMY_Ango'rosh Maulers|r
.complete 9839,2 
.mob Ango'rosh Mauler
step
#requires Gorefist
.goto Zangarmarsh,27.73,32.32,60,0
.goto Zangarmarsh,25.87,33.28,60,0
.goto Zangarmarsh,25.71,31.64,60,0
.goto Zangarmarsh,24.78,29.79,60,0
.goto Zangarmarsh,24.27,31.62,60,0
.goto Zangarmarsh,22.83,31.15,60,0
.goto Zangarmarsh,21.23,32.21,60,0
.goto Zangarmarsh,20.51,31.27,60,0
.goto Zangarmarsh,18.84,35.49,60,0
.goto Zangarmarsh,16.37,37.32,60,0
.goto Zangarmarsh,15.49,40.37,60,0
.goto Zangarmarsh,15.15,45.80,60,0
.goto Zangarmarsh,16.70,45.10,60,0
.goto Zangarmarsh,19.25,46.80
>>Kill |cRXP_ENEMY_Marshlight Bleeders|r and |cRXP_ENEMY_Fenglow Stingers|r. Loot them for their |cRXP_LOOT_Venom|r and |cRXP_LOOT_Wings|r
.complete 9830,1 
.complete 9790,1 
.mob Marshlight Bleeder
.mob Fenglow Stinger
step
#questguide << !tbc
.goto Zangarmarsh,19.54,50.04
>>Return to Sporeggar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gzhun'tt|r
.turnin 9726 >> Turn in Now That We're Friends...
.target Gzhun'tt
step
#questguide << !tbc
.goto Zangarmarsh,23.32,66.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lessa'oh|r
.turnin 9709 >> Turn in Stealing Back the Mushrooms
.target Watcher Leesa'oh
step
#xprate <1.5 << !Shaman
#completewith next
.hs >> Hearth to Orebor Harborage
step
.goto 1946/530,7364.00000,1023.79999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ikuti|r
.target Ikuti
.turnin 9839 >>Turn in Overlord Gorefist
step
.goto 1946/530,7383.10010,1019.50000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maktu|r
.target Maktu
.turnin 9905 >>Turn in Maktu's Revenge
step
.goto 1946/530,7419.39990,976.70001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Puluu|r
.target Puluu
.turnin 9830 >>Turn in Stinger Venom
.turnin 9902 >>Turn in The Terror of Marshlight Lake
step
#completewith next
.goto Zangarmarsh,41.28,29.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halu|r
.fly Telredor >> Fly to Telredor
.target Halu
step
#questguide << !tbc
>>Return to Telredor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r and |cRXP_FRIENDLY_Haalrun|r
.turnin 9787 >> Turn in Idols of the Feralfen
.goto Zangarmarsh,68.20,49.37
.accept 9801 >>Accept Gathering the Reagents
.turnin 9790 >> Turn in Diaphanous Wings
.goto Zangarmarsh,68.81,48.91
.target Anchorite Ahuurn
.target Haalrun
step
#sticky
#label idols1
.goto 1946/530,6045.39990,279.89999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r
.target Anchorite Ahuurn
.turnin 9787 >>Turn in Idols of the Feralfen
step
#questguide << !tbc
.goto 1946/530,6045.39990,279.89999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r
.target Anchorite Ahuurn
.accept 9801 >>Accept Gathering the Reagents
step
#requires idols1
.goto 1946/530,6066.80029,328.60001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haalrun|r
.target Haalrun
.turnin 9790 >>Turn in Diaphanous Wings
step
#questguide << !tbc
#completewith NagaC
>>Kill |cRXP_ENEMY_Fen Striders|r. Loot them for their |cRXP_LOOT_Tentacles|r
>>Kill |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Eyes|r
.complete 9801,2 
.mob +Fen Strider
.complete 9801,1 
.mob +Young Sporebat
.mob +Greater Sporebat
.mob +Sporebat
step
#optional
#completewith Rajis
>>Kill |cRXP_ENEMY_Bloodscale Overseers|r and |cRXP_ENEMY_Bloodscale Wavecallers|r. Loot them for their |cRXP_LOOT_Claws|r
.complete 9728,1 
.mob Bloodscale Overseer
.mob Bloodscale Wavecaller
step
.goto Zangarmarsh,61.97,40.84
.use 24355 >>|cRXP_WARN_Use the|r |T136074:0|t[Ironvine Seeds] |cRXP_WARN_on the Lake Controls|r
.complete 9720,3 
step
#label Rajis
.goto Zangarmarsh,65.15,40.91
>>Kill |cRXP_ENEMY_Rajis Fyashe|r
>>|cRXP_WARN_Find a group for her if needed. Skip this step if you're unable to find a group or solo her|r << tbc/wotlk
>>|cRXP_WARN_Try to Line of Sight her spells. Run away from the|r |T135833:0|t[Freezing Circle] |cRXP_WARN_she casts|r << tbc/wotlk
.complete 9817,1 
.isOnQuest 9817
.mob Rajis Fyashe
step
#label NagaC
#loop
.line Zangarmarsh,62.09,38.27,63.29,37.85,64.54,40.10,65.71,39.87,66.39,41.25,63.82,43.15,63.34,44.22,63.15,41.53,61.93,40.26,62.09,38.27
.goto Zangarmarsh,62.09,38.27,55,0
.goto Zangarmarsh,63.29,37.85,55,0
.goto Zangarmarsh,64.54,40.10,55,0
.goto Zangarmarsh,65.71,39.87,55,0
.goto Zangarmarsh,66.39,41.25,55,0
.goto Zangarmarsh,63.82,43.15,55,0
.goto Zangarmarsh,63.34,44.22,55,0
.goto Zangarmarsh,63.15,41.53,55,0
.goto Zangarmarsh,61.93,40.26,55,0
.goto Zangarmarsh,62.09,38.27,55,0
>>Kill |cRXP_ENEMY_Bloodscale Overseers|r and |cRXP_ENEMY_Bloodscale Wavecallers|r. Loot them for their |cRXP_LOOT_Claws|r
.complete 9728,1 
.mob Bloodscale Overseer
.mob Bloodscale Wavecaller
step
#questguide << !tbc
#completewith next
.goto Zangarmarsh,68.48,43.46,60,0
.goto Zangarmarsh,72.01,43.27,60,0
.goto Zangarmarsh,74.14,40.66,60,0
.goto Zangarmarsh,74.75,41.17,60,0
.goto Zangarmarsh,74.61,46.52,60,0
.goto Zangarmarsh,75.22,48.26,60,0
.goto Zangarmarsh,73.70,48.35,60,0
.goto Zangarmarsh,73.50,50.21,60,0
.goto Zangarmarsh,76.75,55.29,60,0
.goto Zangarmarsh,73.96,56.23,60,0
.goto Zangarmarsh,71.85,55.12,60,0
.goto Zangarmarsh,68.41,57.39,60,0
.goto Zangarmarsh,69.72,59.22,60,0
>>Kill |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Eyes|r
>>Kill |cRXP_ENEMY_Fen Striders|r. Loot them for their |cRXP_LOOT_Tentacles|r
.complete 9801,1 
.mob +Young Sporebat
.mob +Greater Sporebat
.mob +Sporebat
.complete 9801,2 
.unitscan +Fen Strider
step
.goto Zangarmarsh,78.40,62.02
>>Return to the Cenarion Refuge
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ysiel Windsinger|r
.turnin 9720 >> Turn in Balance Must Be Preserved
.turnin 9732 >> Turn in Return to the Marsh
.target Ysiel Windsinger
step
.goto Zangarmarsh,79.09,65.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Hamoot|r upstairs in the tower
.turnin 9728 >> Turn in A Warm Welcome
.turnin 9817 >> Turn in Leader of the Bloodscale
.isQuestComplete 9817
.target Warden Hamoot
step
#optional
.goto Zangarmarsh,79.09,65.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Hamoot|r upstairs in the tower
.turnin 9728 >> Turn in A Warm Welcome
.target Warden Hamoot
step
#questguide << !tbc
.goto Zangarmarsh,80.66,69.19,60,0
.goto Zangarmarsh,81.79,72.99,60,0
.goto Zangarmarsh,78.58,82.28,60,0
.goto Zangarmarsh,76.14,84.24,60,0
.goto Zangarmarsh,73.71,87.66,60,0
.goto Zangarmarsh,79.51,87.69,60,0
.goto Zangarmarsh,80.66,69.19,60,0
.goto Zangarmarsh,81.79,72.99,60,0
.goto Zangarmarsh,78.58,82.28,60,0
.goto Zangarmarsh,76.14,84.24,60,0
.goto Zangarmarsh,73.71,87.66,60,0
.goto Zangarmarsh,79.51,87.69
>>Kill |cRXP_ENEMY_Sporebats|r. Loot them for their |cRXP_LOOT_Eyes|r
>>Kill |cRXP_ENEMY_Fen Striders|r. Loot them for their |cRXP_LOOT_Tentacles|r
.complete 9801,1 
.mob +Young Sporebat
.mob +Greater Sporebat
.mob +Sporebat
.complete 9801,2 
.unitscan +Fen Strider
step << !tbc !wotlk
.goto 1955/530,5362.10010,-1832.90002
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haggard War Veteran|r
.target Haggard War Veteran
.accept 10210 >>Accept A'dal
step << !tbc !wotlk
.goto 1955/530,5426.70020,-1862.70007
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A'dal|r
.target A'dal
.turnin 10210 >>Turn in A'dal
step << !tbc !wotlk
.goto 1955/530,5421.80029,-1859.00000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.target Khadgar
.accept 10211 >>Accept City of Light
.timer 462,City of Light RP
step << !tbc !wotlk
.goto Shattrath City,50.36,42.87
>>Follow |cRXP_FRIENDLY_Khadgar's Servant|r << wotlk
>>Head up to the second floor with |cRXP_FRIENDLY_G'eras|r and wait out the RP. If someone elses |cRXP_FRIENDLY_Khadgar's Servant|r arrives in the meantime, you can target it and it will complete the quest for you. If the quest fails, abandon it, accept the quest from |cRXP_FRIENDLY_Khadgar's Servant|r again, then follow the |cRXP_FRIENDLY_Khadgar's Servant|r around << tbc
.complete 10211,1 
.target Khadgar's Servant
step << Mage !tbc !wotlk
.goto Shattrath City,58.77,47.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iorioa|r
.train 35715 >> Train Teleport: Shattrath and Portal: Shattrath
.target Iorioa
step << !tbc !wotlk
.goto Shattrath City,54.74,44.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.turnin 10211 >> Turn in City of Light
.target Khadgar
step << !tbc !wotlk
.goto Shattrath City,54.74,44.32
.accept 10551 >>Allegiance to the Aldor
.turnin 10551>>Talk to |cRXP_FRIENDLY_Khadgar|r. Pledge your Allegiance to the Aldor
.target Khadgar
step << !tbc !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.goto Shattrath City,54.74,44.32
.accept 10554 >> Accept Ishanah
.target Khadgar
step << !tbc !wotlk
#xprate >1.499
.goto 1955/530,5821.60010,-1732.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishanah|r
.target Ishanah
.turnin 10554 >>Turn in Ishanah
step
#xprate >1.499
.hs >> Hearth to Orebor Harborage
.cooldown item,6948,>0
]])

RXPGuides.RegisterGuide([[#version 9
#cata
#mop
#wotlk
#group RXP MoP 60-80 (A)
<< Alliance
#name 64-66 Nagrand
#defaultfor !wotlk
#version 9
#next 65-67 Blade's Edge
#xprate <1.5 << tbc/wotlk
step << !tbc !wotlk
.goto 1955/530,5362.10010,-1832.90002
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haggard War Veteran|r
.target Haggard War Veteran
.accept 10210 >>Accept A'dal
step << !tbc !wotlk
.goto 1955/530,5426.70020,-1862.70007
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A'dal|r
.target A'dal
.turnin 10210 >>Turn in A'dal
step << !tbc !wotlk
.goto 1955/530,5421.80029,-1859.00000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.target Khadgar
.accept 10211 >>Accept City of Light
.timer 462,City of Light RP
step << !tbc !wotlk
.goto Shattrath City,50.36,42.87
>>Follow |cRXP_FRIENDLY_Khadgar's Servant|r << wotlk
>>Head up to the second floor with |cRXP_FRIENDLY_G'eras|r and wait out the RP. If someone elses |cRXP_FRIENDLY_Khadgar's Servant|r arrives in the meantime, you can target it and it will complete the quest for you. If the quest fails, abandon it, accept the quest from |cRXP_FRIENDLY_Khadgar's Servant|r again, then follow the |cRXP_FRIENDLY_Khadgar's Servant|r around << tbc
.complete 10211,1 
.target Khadgar's Servant
step << Mage !tbc !wotlk
.goto Shattrath City,58.77,47.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iorioa|r
.train 35715 >> Train Teleport: Shattrath and Portal: Shattrath
.target Iorioa
step << !tbc !wotlk
.goto Shattrath City,54.74,44.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.turnin 10211 >> Turn in City of Light
.target Khadgar
step << !tbc !wotlk
.goto Shattrath City,54.74,44.32
.accept 10551 >>Allegiance to the Aldor
.turnin 10551>>Talk to |cRXP_FRIENDLY_Khadgar|r. Pledge your Allegiance to the Aldor
.target Khadgar
step << !tbc !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khadgar's Servant|r
.goto Shattrath City,54.74,44.32
.accept 10554 >> Accept Ishanah
.target Khadgar
step << Rogue !tbc !wotlk
.goto 1955/530,5357.10010,-1880.09998
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ifram|r
.trainer >>Train your class spells << cata
.target Windstalker Ifram
step << Shaman !tbc !wotlk
.goto 1955/530,5367.80029,-1890.09998
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luknar|r
.trainer >>Train your class spells << cata
.target Luknar
step << Warlock !tbc !wotlk
.goto 1955/530,5371.10010,-1892.59998
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fel-Caller Guloto|r
.trainer >>Train your class spells << cata
.target Fel-Caller Guloto
step << Mage !tbc !wotlk
.goto 1955/530,5412.70020,-1792.70007
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raluhi|r
.trainer >>Train your class spells << cata
.target Raluhi
step << Priest !tbc !wotlk
.goto 1955/530,5409.20020,-1789.70007
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salha|r
.trainer >>Train your class spells << cata
.target Salha
step << Paladin !tbc !wotlk
.goto 1955/530,5402.50000,-1796.59998
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ordo|r
.trainer >>Train your class spells << cata
.target Ordo
step << Warrior !tbc !wotlk
.goto 1955/530,5399.89990,-1798.59998
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bratu|r
.trainer >>Train your class spells << cata
.target Bratu
step << Hunter !tbc !wotlk
.goto 1955/530,5403.10010,-1800.59998
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Irva|r
.trainer >>Train your class spells << cata
.target Irva
step << !tbc !wotlk
.goto 1955/530,5821.60010,-1732.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishanah|r
.target Ishanah
.turnin 10554 >>Turn in Ishanah
step
#aldor
.goto Shattrath City,21.62,50.35,30,0
.goto Nagrand,78.23,54.62
.zone Nagrand >> Travel to Aldor Rise. Take the backdoor to Nagrand
.skill riding,<225,1
step
#scryer
.goto Shattrath City,21.62,50.35,30,0
.goto Nagrand,78.23,54.62
.zone Nagrand >> Travel to Aldor Rise. Take the backdoor to Nagrand
>>Make sure to avoid the |cRXP_WARN_Aldor Vindicators|r that roam the area, if they engage you, you will get teleported out of the Aldor Rise, you can spot them by hovering your mouse over them
.skill riding,<225,1
.target Aldor Vindicator
step << !tbc
#completewith Wazat
.goto Nagrand,61.6,67.0
.zone Nagrand >> Travel to Nagrand
.skill riding,225,1
step
#completewith next
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.mob Wild Elekk
step
#label Wazat
.goto Nagrand,61.70,67.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wazat|r
.accept 10109 >> Accept I Must Have Them!
.target Wazat
step
#optional
.goto Nagrand,55.05,70.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Bintook|r
.accept 9917 >> Accept Do My Eyes Deceive Me
.reputation 978,neutral,0,1
.target Huntress Bintook
step
#optional
.goto Nagrand,62.89,73.28,40,0
.goto Nagrand,62.74,71.49
>>Kill |cRXP_ENEMY_Boulderfist Ogres|r. Loot them for their |cRXP_LOOT_Plans|r
.complete 9917,1 
.mob Boulderfist Hunter
.reputation 978,neutral,0,1
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Bintook|r
.goto Nagrand,55.05,70.54
.turnin 9917 >> Turn in Do My Eyes Deceive Me
.accept 9918 >> Accept Not On My Watch!
.reputation 978,neutral,0,1
.target Huntress Bintook
step
#optional
.goto Nagrand,62.74,71.48
>>Damage |cRXP_ENEMY_Lump|r to 30% or less health
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lump|r
.skipgossip
.complete 9918,1 
.target Lump
.reputation 978,neutral,0,1
step
#optional
.goto Nagrand,55.05,70.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Bintook|r
.turnin 9918 >> Turn in Not On My Watch!
.target Huntress Bintook
.isQuestComplete 9918
step
.goto 1951/530,7253.600,-2557.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Bintook|r
.target Huntress Bintook
.accept 9917 >>Accept Do My Eyes Deceive Me
step
.goto 1951/530,7259.100,-2551.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Shotgun" Jones|r
.target "Shotgun" Jones
.accept 10113 >>Accept The Nesingwary Safari
step
.goto 1951/530,7229.100,-2492.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Ioki|r
.target Elementalist Ioki
.accept 9869 >>Accept The Throne of the Elements
step
.goto 1951/530,7273.300,-2567.000
>>Click the |cRXP_FRIENDLY_Telaar Bulletin Board|r
.accept 9936 >>Accept Wanted: Giselda the Crone
.accept 9940 >>Accept Wanted: Zorbo the Advisor
step
.goto 1951/530,7286.100,-2613.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Otonbu the Sage|r
.target Otonbu the Sage
.accept 9874 >>Accept Stopping the Spread
step
.goto 1951/530,7287.600,-2623.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Poli'lukluk the Wiser|r
.target Poli'lukluk the Wiser
.accept 9878 >>Accept Solving the Problem
step
#completewith BPlans
.goto Nagrand,54.21,76.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caregiver Isel|r
.home >> Set your Hearthstone to Telaar
.target Caregiver Isel
step
.goto Nagrand,54.17,75.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Furgu|r on the balcony at the top of the building
.fp Telaar >> Get the Telaar flight path
.target Furgu
step
#optional
#completewith Staghoofs
.use 24504 >>Kill |cRXP_ENEMY_Dust Howlers|r. Loot them for their |cRXP_LOOT_Elemental Gas|r and |cRXP_LOOT_Howling Wind|r. Click the |T135988:0|t[Howling Wind] in your bags
.complete 10109,1 
.collect 24504,1,9861 
.accept 9861 >> Accept The Howling Wind
.mob Dust Howler
step
#label BPlans
.goto Nagrand,62.89,73.28,40,0
.goto Nagrand,62.74,71.49
>>Kill |cRXP_ENEMY_Boulderfist Ogres|r. Loot them for their |cRXP_LOOT_Plans|r
.complete 9917,1 
.mob Boulderfist Hunter
step
#completewith Throne1
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.mob Wild Elekk
step
#sticky
#hidewindow
#label saved1a
#completewith Safari1
.subzone 3673 >> 1
step
#requires saved1a
#completewith Safari1
>>Sometimes |cRXP_ENEMY_Gankly|r can appear at the Safari. This is a rare event
>>Kill |cRXP_ENEMY_Gankly|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kristen Dipswitch|r
.accept 9897 >> Accept I'm Saved!
.goto Nagrand,71.42,40.60,0
.unitscan Gankly Rottenfist
.target Kristen Dipswitch
step
#label Safari1
>>Travel to the Nesingwary Safari
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado 'Fitz' Farstrider|r, |cRXP_FRIENDLY_Harold Lane|r and |cRXP_FRIENDLY_Hemet Nesingwary|r
.turnin 10113 >>Turn in The Nesingwary Safari
.accept 9854 >>Accept Windroc Mastery
.goto Nagrand,71.57,40.52,-1
.target +Shado 'Fitz' Farstrider
.accept 9857 >>Accept Talbuk Mastery
.goto Nagrand,71.38,40.62,-1
.target +Harold Lane
.accept 9789 >>Accept Clefthoof Mastery
.goto Nagrand,71.52,40.82,-1
.target +Hemet Nesingwary
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Lane|r
.turnin 9897 >> Turn in I'm Saved!
.target Harold Lane
.goto Nagrand,71.38,40.62
.isOnQuest 9897
step
#completewith Throne1
.goto Nagrand,70.22,38.37,60,0
.goto Nagrand,68.58,40.18,60,0
.goto Nagrand,62.42,35.46,60,0
>>Kill |cRXP_ENEMY_Windrocs|r
.complete 9854,1 
.mob Windroc
.subzoneskip 3614
.subzoneskip 3615
step
#label Throne1
.goto 1951/530,6945.300,-793.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Untrag|r
.target Elementalist Untrag
.accept 9818 >>Accept The Underneath
step
.goto 1951/530,6936.700,-783.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Lo'ap|r
.target Elementalist Lo'ap
.accept 9800 >>Accept A Rare Bean
.accept 9815 >>Accept Muck Diving
step
.goto 1951/530,6944.600,-773.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Sharvak|r
.target Elementalist Sharvak
.turnin 9869 >>Turn in The Throne of the Elements
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Morgh|r
.turnin 9861 >> Turn in The Howling Wind
.accept 9862 >>Accept Murkblood Corrupters
.goto Nagrand,60.50,22.37
.isOnQuest 9861
.target Elementalist Morgh
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Morgh|r
.accept 9862 >>Accept Murkblood Corrupters
.goto Nagrand,60.50,22.37
.isQuestTurnedIn 9861
.target Elementalist Morgh
step
#loop
.goto Nagrand,62.19,22.60,50,0
.goto Nagrand,61.99,22.09,50,0
.goto Nagrand,61.28,22.24,50,0
.goto Nagrand,60.88,21.39,50,0
.goto Nagrand,60.38,20.88,50,0
.goto Nagrand,59.87,21.32,50,0
.goto Nagrand,59.58,22.48,50,0
.goto Nagrand,60.08,24.41,50,0
.goto Nagrand,60.57,25.04,50,0
.goto Nagrand,61.15,24.92,50,0
.goto Nagrand,61.72,24.54,50,0
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.turnin 9818 >>Turn in The Underneath
.accept 9819 >>Accept The Tortured Earth
.unitscan Gordawg
step
#optional
#completewith Throne2
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.mob Wild Elekk
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Tortured Earth Spirits|r usually near small hills or the base of the mountain
.complete 9819,1 
.mob Tortured Earth Spirit
step
#loop
.goto Nagrand,62.64,48.31,60,0
.goto Nagrand,62.42,35.46,60,0
.goto Nagrand,68.58,40.18,60,0
.goto Nagrand,70.22,38.37,60,0
.goto Nagrand,62.64,48.31,0
.goto Nagrand,62.42,35.46,0
.goto Nagrand,68.58,40.18,0
.goto Nagrand,70.22,38.37,0
>>Kill |cRXP_ENEMY_Windrocs|r
.complete 9854,1 
.mob Windroc
step
#optional
#completewith next
.goto Nagrand,62.42,35.46,60,0
.goto Nagrand,66.64,38.34,60,0
>>Kill |cRXP_ENEMY_Talbuk Stags|r and |cRXP_ENEMY_Clefthoofs|r
.complete 9857,1 
.mob +Talbuk Stag
.complete 9789,1 
.mob +Clefthoof
step
#loop
.goto Nagrand,65.00,51.32,60,0
.goto Nagrand,61.94,54.94,60,0
.goto Nagrand,65.00,51.32,0
.goto Nagrand,61.94,54.94,0
>>Kill |cRXP_ENEMY_Tortured Earth Spirits|r
.complete 9819,1 
.mob Tortured Earth Spirit
step
#label Staghoofs
#loop
.line Nagrand,57.61,60.98,59.50,58.79,61.32,62.32,70.43,56.50,65.39,63.76,71.13,62.77,70.44,72.05,66.97,75.29,66.01,67.94,57.61,60.98
.goto Nagrand,57.61,60.98,60,0
.goto Nagrand,59.50,58.79,60,0
.goto Nagrand,61.32,62.32,60,0
.goto Nagrand,70.43,56.50,60,0
.goto Nagrand,65.39,63.76,60,0
.goto Nagrand,71.13,62.77,60,0
.goto Nagrand,70.44,72.05,60,0
.goto Nagrand,66.97,75.29,60,0
.goto Nagrand,66.01,67.94,60,0
.goto Nagrand,57.61,60.98,60,0
>>Kill |cRXP_ENEMY_Talbuk Stags|r and |cRXP_ENEMY_Clefthoofs|r
.complete 9857,1 
.mob +Talbuk Stag
.complete 9789,1 
.mob +Clefthoof
step
.goto Nagrand,66.11,62.07,60,0
.goto Nagrand,68.76,63.70,60,0
.goto Nagrand,67.52,65.69,60,0
.goto Nagrand,66.10,72.83,60,0
.goto Nagrand,67.50,74.48,60,0
.goto Nagrand,60.33,63.82,60,0
.goto Nagrand,60.85,61.08,60,0
.goto Nagrand,62.41,59.43,60,0
.goto Nagrand,66.11,62.07,60,0
.goto Nagrand,68.76,63.70,60,0
.goto Nagrand,67.52,65.69,60,0
.goto Nagrand,66.10,72.83,60,0
.goto Nagrand,67.50,74.48,60,0
.goto Nagrand,60.33,63.82,60,0
.goto Nagrand,60.85,61.08,60,0
.goto Nagrand,62.41,59.43
.use 24504 >>Kill |cRXP_ENEMY_Dust Howlers|r. Loot them for their |cRXP_LOOT_Elemental Gas|r and |cRXP_LOOT_Howling Wind|r. Click the |T135988:0|t[Howling Wind] in your bags
.complete 10109,1 
.collect 24504,1,9861 
.accept 9861 >> Accept The Howling Wind
.unitscan Dust Howler
step
#sticky
#hidewindow
#label saved2a
#completewith Safari1
.subzone 3673 >> 1
step
#requires saved2a
#completewith Safari2
>>Sometimes |cRXP_ENEMY_Gankly|r can appear at the Safari. This is a rare event
>>Kill |cRXP_ENEMY_Gankly|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kristen Dipswitch|r
.accept 9897 >> Accept I'm Saved!
.goto Nagrand,71.42,40.60,0
.unitscan Gankly Rottenfist
.target Kristen Dipswitch
step
#label Safari2
>>Return to the Safari
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado 'Fitz' Farstrider|r, |cRXP_FRIENDLY_Hemet Nesingwary|r and |cRXP_FRIENDLY_Harold Lane|r
.turnin 9854 >>Turn in Windroc Mastery
.accept 9855 >>Accept Windroc Mastery
.target +Shado 'Fitz' Farstrider
.goto Nagrand,71.57,40.52
.turnin 9789 >>Turn in Clefthoof Mastery
.accept 9850 >>Accept Clefthoof Mastery
.target +Hemet Nesingwary
.goto Nagrand,71.52,40.82
.turnin 9857 >>Turn in Talbuk Mastery
.accept 9858 >>Accept Talbuk Mastery
.target +Harold Lane
.goto Nagrand,71.38,40.62
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Lane|r
.turnin 9897 >> Turn in I'm Saved!
.target Harold Lane
.goto Nagrand,71.38,40.62
.isOnQuest 9897
step
#label Throne2
.goto Nagrand,62.19,22.60,50,0
.goto Nagrand,61.99,22.09,50,0
.goto Nagrand,61.28,22.24,50,0
.goto Nagrand,60.88,21.39,50,0
.goto Nagrand,60.38,20.88,50,0
.goto Nagrand,59.87,21.32,50,0
.goto Nagrand,59.58,22.48,50,0
.goto Nagrand,60.08,24.41,50,0
.goto Nagrand,60.57,25.04,50,0
.goto Nagrand,61.15,24.92,50,0
.goto Nagrand,61.72,24.54
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.turnin 9819 >>Turn in The Tortured Earth
.accept 9821 >>Accept Eating Damnation
.unitscan Gordawg
step
#completewith Caracoli
.destroy 24475 >> You can delete |T135241:0|t[Gordawg's Imprint] from your bags. It's no longer needed
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Morgh|r
.turnin 9861 >> Turn in The Howling Wind
.accept 9862 >>Accept Murkblood Corrupters
.goto Nagrand,60.50,22.37
.isOnQuest 9861
.target Elementalist Morgh
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Morgh|r
.accept 9862 >>Accept Murkblood Corrupters
.goto Nagrand,60.50,22.37
.isQuestTurnedIn 9861
.target Elementalist Morgh
step
#optional
#completewith Gordawg3
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.mob Wild Elekk
step
#completewith Dung
#optional
>>Kill |cRXP_ENEMY_Clefthoof Bulls|r and |cRXP_ENEMY_Talbuk Thorngrazers|r
.complete 9850,1,20 
.mob +Clefthoof Bull
.complete 9858,1 
.mob +Talbuk Thorngrazer
step
#completewith eccore
>>Loot the |cRXP_PICK_Digested Caracoli|r dung on the ground
.complete 9800,1 
step
#label eccore
#loop
.goto Nagrand,56.76,18.16,60,0
.goto Nagrand,55.16,20.27,60,0
.goto Nagrand,51.36,19.50,60,0
.goto Nagrand,48.73,18.92,60,0
.goto Nagrand,56.76,18.16,60,0
.goto Nagrand,55.16,20.27,60,0
.goto Nagrand,51.36,19.50,60,0
.goto Nagrand,48.73,18.92,60,0
.goto Nagrand,56.76,18.16,0
.goto Nagrand,55.16,20.27,0
.goto Nagrand,51.36,19.50,0
.goto Nagrand,48.73,18.92,0
.goto Nagrand,56.76,18.16,0
.goto Nagrand,55.16,20.27,0
.goto Nagrand,51.36,19.50,0
.goto Nagrand,48.73,18.92,0
>>Kill |cRXP_ENEMY_Enraged Crushers|r. Loot them for their |cRXP_LOOT_Cores|r
.complete 9821,1 
.mob Enraged Crusher
step
#label Dung
#loop
.line Nagrand,53.23,28.38,53.12,25.86,54.63,23.85,57.92,23.11,57.71,20.88,55.71,20.76,52.57,22.34,50.79,19.94,51.26,24.12,51.50,26.70,50.31,27.35,48.83,27.92,46.77,28.29,47.42,33.33,53.23,28.38
.goto Nagrand,53.23,28.38,60,0
.goto Nagrand,53.12,25.86,60,0
.goto Nagrand,54.63,23.85,60,0
.goto Nagrand,57.92,23.11,60,0
.goto Nagrand,57.71,20.88,60,0
.goto Nagrand,55.71,20.76,60,0
.goto Nagrand,52.57,22.34,60,0
.goto Nagrand,50.79,19.94,60,0
.goto Nagrand,51.26,24.12,60,0
.goto Nagrand,51.50,26.70,60,0
.goto Nagrand,50.31,27.35,60,0
.goto Nagrand,48.83,27.92,60,0
.goto Nagrand,46.77,28.29,60,0
.goto Nagrand,47.42,33.33,60,0
.goto Nagrand,53.23,28.38,60,0
>>Loot the |cRXP_PICK_Digested Caracoli|r dung on the ground
.complete 9800,1 
step
.goto Nagrand,60.81,22.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Lo'ap|r
.turnin 9800 >>Turn in A Rare Bean
.accept 9804 >>Accept Agitated Spirits of Skysong
.target Elementalist Lo'ap
step
.goto Nagrand,62.19,22.60,50,0
.goto Nagrand,61.99,22.09,50,0
.goto Nagrand,61.28,22.24,50,0
.goto Nagrand,60.88,21.39,50,0
.goto Nagrand,60.38,20.88,50,0
.goto Nagrand,59.87,21.32,50,0
.goto Nagrand,59.58,22.48,50,0
.goto Nagrand,60.08,24.41,50,0
.goto Nagrand,60.57,25.04,50,0
.goto Nagrand,61.15,24.92,50,0
.goto Nagrand,61.72,24.54
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.turnin 9821 >>Turn in Eating Damnation
.unitscan Gordawg
.isQuestComplete 9821
step
#questguide << !tbc
#label Gordawg3
.goto Nagrand,62.19,22.60,50,0
.goto Nagrand,61.99,22.09,50,0
.goto Nagrand,61.28,22.24,50,0
.goto Nagrand,60.88,21.39,50,0
.goto Nagrand,60.38,20.88,50,0
.goto Nagrand,59.87,21.32,50,0
.goto Nagrand,59.58,22.48,50,0
.goto Nagrand,60.08,24.41,50,0
.goto Nagrand,60.57,25.04,50,0
.goto Nagrand,61.15,24.92,50,0
.goto Nagrand,61.72,24.54
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.accept 9849 >>Accept Shattering the Veil
.unitscan Gordawg
.isQuestTurnedIn 9821
step << !Warlock
#completewith next
.cast 31920 >> Use the |T133999:0|t[Nagrand Cherry] in your bags
.use 24421
step
.goto Nagrand,61.62,29.65,60,0
.goto Nagrand,60.41,27.38,60,0
.goto Nagrand,59.40,27.55,60,0
.goto Nagrand,54.80,25.90,60,0
.goto Nagrand,61.62,29.65,60,0
.goto Nagrand,60.41,27.38,60,0
.goto Nagrand,59.40,27.55,60,0
.goto Nagrand,54.80,25.90
.use 24421 >>Kill |cRXP_ENEMY_Lake Spirits|r
.complete 9804,1 
.mob Lake Spirit
step
.goto Nagrand,60.81,22.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Lo'ap|r
.turnin 9804 >>Turn in Agitated Spirits of Skysong
.accept 9805 >>Accept Blessing of Incineratus
.target Elementalist Lo'ap
step
#optional
#completewith Telaar2
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.mob Wild Elekk
step
#optional
#completewith ThorngrazersEnd
>>Kill |cRXP_ENEMY_Clefthoof Bulls|r
.complete 9850,1 
.mob Clefthoof Bull
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Talbuk Thorngrazers|r
.complete 9858,1 
.mob Talbuk Thorngrazer
step
.goto Nagrand,47.37,34.95,60,0
.goto Nagrand,46.08,33.41,60,0
.goto Nagrand,42.95,30.75,60,0
.goto Nagrand,41.16,26.99,60,0
.goto Nagrand,40.03,26.17,60,0
.goto Nagrand,38.03,27.55,60,0
.goto Nagrand,36.34,26.96,60,0
.goto Nagrand,35.40,25.60,60,0
.goto Nagrand,34.49,21.76,60,0
.goto Nagrand,33.78,20.12,60,0
.goto Nagrand,40.03,26.17
.line Nagrand,47.37,34.95,46.08,33.41,42.95,30.75,41.16,26.99,40.03,26.17,38.03,27.55,36.34,26.96,35.40,25.60,34.49,21.76,33.78,20.12
.use 24559 >>Kill the |cRXP_ENEMY_Murkblood Invaders|r. Loot them for their |cRXP_LOOT_Plans|r. Click the |T134269:0|t[Murkblood Invasion Plans] in your bags
.collect 24559,1,9871 
.accept 9871 >>Accept Murkblood Invaders
.unitscan Murkblood Invader
step
#label ThorngrazersEnd
#loop
.line Nagrand,53.23,28.38,53.12,25.86,54.63,23.85,57.92,23.11,57.71,20.88,55.71,20.76,52.57,22.34,50.79,19.94,51.26,24.12,51.50,26.70,50.31,27.35,48.83,27.92,46.77,28.29,47.42,33.33,53.23,28.38
.goto Nagrand,53.23,28.38,60,0
.goto Nagrand,53.12,25.86,60,0
.goto Nagrand,54.63,23.85,60,0
.goto Nagrand,57.92,23.11,60,0
.goto Nagrand,57.71,20.88,60,0
.goto Nagrand,55.71,20.76,60,0
.goto Nagrand,52.57,22.34,60,0
.goto Nagrand,50.79,19.94,60,0
.goto Nagrand,51.26,24.12,60,0
.goto Nagrand,51.50,26.70,60,0
.goto Nagrand,50.31,27.35,60,0
.goto Nagrand,48.83,27.92,60,0
.goto Nagrand,46.77,28.29,60,0
.goto Nagrand,47.42,33.33,60,0
.goto Nagrand,53.23,28.38,60,0
>>Kill |cRXP_ENEMY_Talbuk Thorngrazers|r
.complete 9858,1 
.mob Talbuk Thorngrazer
step
#loop
.line Nagrand,50.79,27.99,48.31,31.88,47.13,39.34,48.66,40.86,51.65,39.18,50.33,35.67,50.95,31.54,52.50,29.87,50.79,27.99
.goto Nagrand,50.79,27.99,60,0
.goto Nagrand,48.31,31.88,60,0
.goto Nagrand,47.13,39.34,60,0
.goto Nagrand,48.66,40.86,60,0
.goto Nagrand,51.65,39.18,60,0
.goto Nagrand,50.33,35.67,60,0
.goto Nagrand,50.95,31.54,60,0
.goto Nagrand,52.50,29.87,60,0
.goto Nagrand,50.79,27.99,60,0
>>Kill |cRXP_ENEMY_Clefthoof Bulls|r
.complete 9850,1 
.mob Clefthoof Bull
step
.goto Nagrand,41.18,44.33
>>Travel to Halaa if the Alliance is controlling it
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kartos|r
*If the Horde or nobody is controlling Halaa, skip this step
.accept 10076 >> Accept Oshu'gun Crystal Powder
.turnin 10076 >> Turn in Oshu'gun Crystal Powder
.itemcount 26043,20 
.target Chief Researcher Kartos
step
#questguide << !tbc
#optional
#completewith next
>>Kill |cRXP_ENEMY_Ravenous Windrocs|r
.complete 9855,1 
.mob Ravenous Windroc
step
#questguide << !tbc
.goto Nagrand,51.82,56.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nitrin the Learned|r on the bottom floor inside the building
.turnin 10251 >> Turn in The Master's Grand Design?
.accept 10252 >> Accept Vision of the Dead
.isQuestTurnedIn 10231
.target Nitrin the Learned
step
#loop
.line Nagrand,49.47,58.46,51.83,61.23,50.08,63.89,49.10,61.11,47.43,60.82,43.08,56.34,43.82,54.76,47.43,60.82,49.47,58.46
.goto Nagrand,49.47,58.46,60,0
.goto Nagrand,51.83,61.23,60,0
.goto Nagrand,50.08,63.89,60,0
.goto Nagrand,49.10,61.11,60,0
.goto Nagrand,47.43,60.82,60,0
.goto Nagrand,43.08,56.34,60,0
.goto Nagrand,43.82,54.76,60,0
.goto Nagrand,47.43,60.82,60,0
.goto Nagrand,49.47,58.46,60,0
>>Kill |cRXP_ENEMY_Ravenous Windrocs|r
.complete 9855,1 
.mob Ravenous Windroc
step
.goto Nagrand,29.1,56.9
.use 24559 >>Kill the |cRXP_ENEMY_Murkblood Invaders|r. Loot them for their |cRXP_LOOT_Plans|r. Click the |T134269:0|t[Murkblood Invasion Plans] in your bags
.collect 24559,1,9871 
.accept 9871 >>Accept Murkblood Invaders
.unitscan Murkblood Invader
step << !Shaman
.goto Nagrand,51.11,69.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Consortium Recruiter|r
.accept 9913 >>Accept The Consortium Needs You!
.target Consortium Recruiter
step << Shaman
#completewith next
.hs >> Hearth to Telaar
.cooldown item,6948,>2
step
#label Telaar2
.goto 1951/530,7231.500,-2489.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arechron|r
.target Arechron
.turnin 9871 >>Turn in Murkblood Invaders
.accept 9873 >>Accept Ortor My Old Friend...
step
.goto 1951/530,7255.800,-2556.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Bintook|r
.target Huntress Bintook
.turnin 9917 >>Turn in Do My Eyes Deceive Me
.accept 9918 >>Accept Not On My Watch!
step
.goto Nagrand,62.74,71.48
>>Damage |cRXP_ENEMY_Lump|r to 30% or less health
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lump|r
.skipgossip
.complete 9918,1 
.target Lump
step
.goto 1951/530,7252.400,-2556.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Bintook|r
.target Huntress Bintook
.turnin 9918 >>Turn in Not On My Watch!
.accept 9920 >>Accept Mo'mor the Breaker
step
.goto 1951/530,7278.300,-2618.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mo'mor the Breaker|r
.target Mo'mor the Breaker
.turnin 9920 >>Turn in Mo'mor the Breaker
.accept 9921 >>Accept The Ruins of Burning Blade
step
.goto Nagrand,61.68,67.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wazat|r
.turnin 10109 >> Turn in I Must Have Them!
.accept 10111 >> Accept Bring Me The Egg!
.target Wazat
step
#completewith next
.goto Nagrand,61.82,68.84,30 >>Use the Jump-A-Tron 4000 next to Wazat to get the Slowfall buff. Mount up then run up the cliff to your south and jump toward the tree with the nest of eggs
.skill riding,225,1
step
.goto Nagrand,61.33,66.98
>>Click on the egg inside the nest in the tree. A |cRXP_ENEMY_Windroc Matriach|r will spawn after you loot the egg.
.complete 10111,1 
.cast 3365
.timer 37,Bring Me The Egg! RP
step
>>Kill the |cRXP_ENEMY_Windroc Matriach|r
>>Kite it back to Telaar so that the guards help you. Remember that you need the majority damage over either of the guards to get kill credit, or you'll have to summon the |cRXP_ENEMY_Matriach|r again. Loot it for its |cRXP_LOOT_Talon|r. This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him. <<tbc/wotlk
*|cRXP_WARN_The Matriarch IS slowable|r << tbc/wotlk
.goto Nagrand,61.57,66.52,0
.goto Nagrand,57.09,70.21
.complete 10111,2 
.unitscan Windroc Matriarch
step
.goto Nagrand,61.68,67.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wazat|r
.turnin 10111 >> Turn in Bring Me The Egg!
.target Wazat
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.mob Wild Elekk
step
#completewith CorkiC
>>Kill |cRXP_ENEMY_Boulderfist Ogres|r
.complete 9921,1 
.complete 9921,2 
step
.goto Nagrand,72.53,70.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Corki|r
.accept 9923 >> Accept HELP!
.target Corki
step
#loop
.line Nagrand,72.24,70.14,73.43,71.66,74.64,71.55,73.99,70.78,72.45,67.91,72.24,70.14,72.45,67.91,75.82,68.49,75.56,64.67,76.17,62.47,78.16,58.99,76.17,62.47,73.67,62.37,74.25,64.80,75.82,68.49,72.45,67.91
.goto Nagrand,72.24,70.14,50,0
.goto Nagrand,73.43,71.66,50,0
.goto Nagrand,74.64,71.55,50,0
.goto Nagrand,73.99,70.78,50,0
.goto Nagrand,72.45,67.91,50,0
.goto Nagrand,72.24,70.14,50,0
.goto Nagrand,72.45,67.91,50,0
.goto Nagrand,75.82,68.49,50,0
.goto Nagrand,75.56,64.67,50,0
.goto Nagrand,76.17,62.47,50,0
.goto Nagrand,78.16,58.99,50,0
.goto Nagrand,76.17,62.47,50,0
.goto Nagrand,73.67,62.37,50,0
.goto Nagrand,74.25,64.80,50,0
.goto Nagrand,75.82,68.49,50,0
.goto Nagrand,72.45,67.91,50,0
>>Kill |cRXP_ENEMY_Boulderfist Ogres|r. Loot them for the |cRXP_LOOT_Boulderfist Key|r
.collect 25490,1,9923,1 
.mob Boulderfist Crusher
.mob Boulderfist Mystic
step
#label CorkiC
.goto Nagrand,72.53,70.74
>>Click on |cRXP_FRIENDLY_Corki's|r Cage
.complete 9923,1 
.target Corki
step
#loop
.line Nagrand,72.24,70.14,73.43,71.66,74.64,71.55,73.99,70.78,72.45,67.91,72.24,70.14,72.45,67.91,75.82,68.49,75.56,64.67,76.17,62.47,78.16,58.99,76.17,62.47,73.67,62.37,74.25,64.80,75.82,68.49,72.45,67.91
.goto Nagrand,72.24,70.14,50,0
.goto Nagrand,73.43,71.66,50,0
.goto Nagrand,74.64,71.55,50,0
.goto Nagrand,73.99,70.78,50,0
.goto Nagrand,72.45,67.91,50,0
.goto Nagrand,72.24,70.14,50,0
.goto Nagrand,72.45,67.91,50,0
.goto Nagrand,75.82,68.49,50,0
.goto Nagrand,75.56,64.67,50,0
.goto Nagrand,76.17,62.47,50,0
.goto Nagrand,78.16,58.99,50,0
.goto Nagrand,76.17,62.47,50,0
.goto Nagrand,73.67,62.37,50,0
.goto Nagrand,74.25,64.80,50,0
.goto Nagrand,75.82,68.49,50,0
.goto Nagrand,72.45,67.91,50,0
>>Kill |cRXP_ENEMY_Boulderfist Ogres|r
.complete 9921,1 
.mob +Boulderfist Crusher
.complete 9921,2 
.mob +Boulderfist Mystic
step
#optional
#completewith Throne3
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.mob Wild Elekk
step
.use 24467 >> Use the |T134813:0|t[Living Fire] in your bags on the Huts in Windyreed Village
.complete 9805,4 
.goto Nagrand,72.74,54.68
.complete 9805,3 
.goto Nagrand,71.22,53.24
.complete 9805,2 
.goto Nagrand,70.75,51.11
.complete 9805,1 
.goto Nagrand,72.38,50.39
step
#label Saved3
#completewith Safari3
>>Sometimes |cRXP_ENEMY_Gankly|r can appear at the Safari. This is a rare event
>>Kill |cRXP_ENEMY_Gankly|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kristen Dipswitch|r
.accept 9897 >> Accept I'm Saved!
.goto Nagrand,71.42,40.60,0
.unitscan Gankly Rottenfist
.target Kristen Dipswitch
step
#requires Saved3
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Lane|r
.turnin 9897 >> Turn in I'm Saved!
.goto Nagrand,71.38,40.62
.target Harold Lane
step
#label Safari3
>>Return to Nesingwary's Camp
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Lane|r, |cRXP_FRIENDLY_Hemet Nesingwary|r and |cRXP_FRIENDLY_Shado 'Fitz' Farstrider|r
.turnin 9858 >>Turn in Talbuk Mastery
.accept 9859 >>Accept Talbuk Mastery
.target +Harold Lane
.goto Nagrand,71.38,40.62
.turnin 9850 >>Turn in Clefthoof Mastery
.accept 9851 >>Accept Clefthoof Mastery
.target +Hemet Nesingwary
.goto Nagrand,71.52,40.82
.turnin 9855 >> Turn in Windroc Mastery
.accept 9856 >> Accept Windroc Mastery
.goto Nagrand,71.57,40.52
.target +Shado 'Fitz' Farstrider
step
#questguide << !tbc
.goto Nagrand,62.19,22.60,50,0
.goto Nagrand,61.99,22.09,50,0
.goto Nagrand,61.28,22.24,50,0
.goto Nagrand,60.88,21.39,50,0
.goto Nagrand,60.38,20.88,50,0
.goto Nagrand,59.87,21.32,50,0
.goto Nagrand,59.58,22.48,50,0
.goto Nagrand,60.08,24.41,50,0
.goto Nagrand,60.57,25.04,50,0
.goto Nagrand,61.15,24.92,50,0
.goto Nagrand,61.72,24.54
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.turnin 9821 >>Turn in Eating Damnation
.accept 9849 >>Accept Shattering the Veil
.unitscan Gordawg
step << !tbc
.goto Nagrand,62.19,22.60,50,0
.goto Nagrand,61.99,22.09,50,0
.goto Nagrand,61.28,22.24,50,0
.goto Nagrand,60.88,21.39,50,0
.goto Nagrand,60.38,20.88,50,0
.goto Nagrand,59.87,21.32,50,0
.goto Nagrand,59.58,22.48,50,0
.goto Nagrand,60.08,24.41,50,0
.goto Nagrand,60.57,25.04,50,0
.goto Nagrand,61.15,24.92,50,0
.goto Nagrand,61.72,24.54
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.turnin 9821 >>Turn in Eating Damnation
.unitscan Gordawg
step
#label Throne3
.goto Nagrand,60.81,22.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Lo'ap|r
.turnin 9805 >>Turn in Blessing of Incineratus
.accept 9810 >>Accept The Spirit Polluted
.target Elementalist Lo'ap
step
#completewith Telaar3
.hs >> Hearth to Telaar
step
#sticky
#label caravan1
.waypoint Nagrand,53.69,68.70,40,0
.waypoint Nagrand,54.01,69.11,40,0
.waypoint Nagrand,54.33,70.32,40,0
.waypoint Nagrand,54.75,70.41,40,0
.waypoint Nagrand,54.97,70.91,40,0
.waypoint Nagrand,55.30,71.42,40,0
.waypoint Nagrand,55.70,72.60,40,0
.waypoint Nagrand,55.61,73.18,40,0
.waypoint Nagrand,54.71,73.30,40,0
.waypoint Nagrand,54.53,73.66,40,0
.waypoint Nagrand,54.53,72.64,40,0
.waypoint Nagrand,54.30,72.28,40,0
.waypoint Nagrand,53.71,72.24,40,0
.waypoint Nagrand,53.52,71.94,40,0
.waypoint Nagrand,53.82,71.30,40,0
.waypoint Nagrand,53.42,70.82,40,0
.waypoint Nagrand,52.93,70.80,40,0
.waypoint Nagrand,53.16,70.24,40,0
.waypoint Nagrand,53.56,70.43,40,0
.waypoint Nagrand,54.10,69.56,40,0
.waypoint Nagrand,54.03,69.16,40,0
.waypoint Nagrand,53.69,68.70,40,0
.line Nagrand,53.69,68.70,54.03,69.16,54.10,69.56,53.56,70.43,53.16,70.24,52.93,70.80,53.42,70.82,53.82,71.30,53.52,71.94,53.71,72.24,54.30,72.28,54.53,72.64,54.53,73.66,54.71,73.30,55.61,73.18,55.70,72.60,55.30,71.42,54.97,70.91,54.75,70.41,54.33,70.32,54.01,69.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Kima|r. She patrols counter-clockwise around Telaar
.accept 9956 >> Accept The Ravaged Caravan
.accept 9982 >> Accept He Called Himself Altruis...
.unitscan Huntress Kima
.xp <66,1
step
#label kima2
#optional
#requires caravan1
#sticky
.waypoint Nagrand,53.69,68.70,40,0
.waypoint Nagrand,54.01,69.11,40,0
.waypoint Nagrand,54.33,70.32,40,0
.waypoint Nagrand,54.75,70.41,40,0
.waypoint Nagrand,54.97,70.91,40,0
.waypoint Nagrand,55.30,71.42,40,0
.waypoint Nagrand,55.70,72.60,40,0
.waypoint Nagrand,55.61,73.18,40,0
.waypoint Nagrand,54.71,73.30,40,0
.waypoint Nagrand,54.53,73.66,40,0
.waypoint Nagrand,54.53,72.64,40,0
.waypoint Nagrand,54.30,72.28,40,0
.waypoint Nagrand,53.71,72.24,40,0
.waypoint Nagrand,53.52,71.94,40,0
.waypoint Nagrand,53.82,71.30,40,0
.waypoint Nagrand,53.42,70.82,40,0
.waypoint Nagrand,52.93,70.80,40,0
.waypoint Nagrand,53.16,70.24,40,0
.waypoint Nagrand,53.56,70.43,40,0
.waypoint Nagrand,54.10,69.56,40,0
.waypoint Nagrand,54.03,69.16,40,0
.waypoint Nagrand,53.69,68.70,40,0
.line Nagrand,53.69,68.70,54.03,69.16,54.10,69.56,53.56,70.43,53.16,70.24,52.93,70.80,53.42,70.82,53.82,71.30,53.52,71.94,53.71,72.24,54.30,72.28,54.53,72.64,54.53,73.66,54.71,73.30,55.61,73.18,55.70,72.60,55.30,71.42,54.97,70.91,54.75,70.41,54.33,70.32,54.01,69.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Kima|r. She patrols counter-clockwise around Telaar
.accept 9956 >> Accept The Ravaged Caravan
.unitscan Huntress Kima
step
#label Telaar3
.goto 1951/530,7278.200,-2618.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mo'mor the Breaker|r
.target Mo'mor the Breaker
.turnin 9921 >>Turn in The Ruins of Burning Blade
.accept 9922 >>Accept The Twin Clefts of Nagrand
step
.goto 1951/530,7231.100,-2489.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arechron|r
.target Arechron
.turnin 9923 >>Turn in HELP!
.accept 9924 >>Accept Corki's Gone Missing Again!
step
#requires kima2
.goto Nagrand,51.11,69.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Consortium Recruiter|r
.accept 9913 >>Accept The Consortium Needs You!
.target Consortium Recruiter
step
#optional
#completewith Corki2
.goto Nagrand,40.0,30.0,0
.goto Nagrand,50.0,56.0,0
>>Kill |cRXP_ENEMY_Boulderfist Warriors|r and |cRXP_ENEMY_Mages|r
.complete 9922,1 
.mob +Boulderfist Warrior
.complete 9922,2 
.mob +Boulderfist Mage
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Boulderfist Warriors|r and |cRXP_ENEMY_Mages|r. Loot them for the |cRXP_LOOT_Cleft Key|r
.collect 25509,1,9924,1 
.mob Boulderfist Warrior
.mob Boulderfist Mage
step
#loop
.goto Nagrand,44.87,49.83,60,0
.goto Nagrand,40.15,46.19,60,0
.goto Nagrand,39.99,37.46,60,0
.goto Nagrand,42.11,37.80,60,0
.goto Nagrand,45.28,42.85,60,0
.goto Nagrand,45.28,42.85,0
>>Kill |cRXP_ENEMY_Muck Spawns|r. Loot them for their |cRXP_LOOT_Cores|r
.complete 9815,1 
.mob Muck Spawn
step
#loop
.goto Nagrand,41.33,32.64,50,0
.goto Nagrand,41.59,34.86,50,0
.goto Nagrand,40.49,33.98,50,0
.goto Nagrand,40.74,31.28,20,0
.goto Nagrand,39.42,30.73,20,0
.goto Nagrand,39.61,28.98,20,0
.goto Nagrand,39.36,27.61,20,0
.goto Nagrand,40.16,29.45,20,0
.goto Nagrand,41.33,32.64,50,0
.goto Nagrand,41.59,34.86,50,0
.goto Nagrand,40.49,33.98,50,0
.goto Nagrand,40.74,31.28,20,0
.goto Nagrand,39.42,30.73,20,0
.goto Nagrand,39.61,28.98,20,0
.goto Nagrand,39.36,27.61,20,0
.goto Nagrand,40.16,29.45,20,0
.goto Nagrand,40.16,29.45,0
>>Kill |cRXP_ENEMY_Boulderfist Warriors|r and |cRXP_ENEMY_Mages|r. Loot them for the |cRXP_LOOT_Cleft Key|r
.collect 25509,1,9924,1 
.mob Boulderfist Warrior
.mob Boulderfist Mage
step
#label Corki2
.goto Nagrand,39.25,27.43
>>Click on |cRXP_FRIENDLY_Corki's|r Cage inside the Cave
.complete 9924,1 
.target Corki
step
#loop
.goto Nagrand,41.33,32.64,50,0
.goto Nagrand,41.59,34.86,50,0
.goto Nagrand,40.49,33.98,50,0
.goto Nagrand,40.74,31.28,20,0
.goto Nagrand,39.42,30.73,20,0
.goto Nagrand,39.61,28.98,20,0
.goto Nagrand,39.36,27.61,20,0
.goto Nagrand,40.16,29.45,20,0
.goto Nagrand,41.33,32.64,50,0
.goto Nagrand,41.59,34.86,50,0
.goto Nagrand,40.49,33.98,50,0
.goto Nagrand,40.74,31.28,20,0
.goto Nagrand,39.42,30.73,20,0
.goto Nagrand,39.61,28.98,20,0
.goto Nagrand,39.36,27.61,20,0
.goto Nagrand,40.16,29.45,20,0
.goto Nagrand,40.16,29.45,0
>>Kill |cRXP_ENEMY_Boulderfist Warriors|r and |cRXP_ENEMY_Mages|r
.complete 9922,1 
.mob +Boulderfist Warrior
.complete 9922,2 
.mob +Boulderfist Mage
step
#questguide << !tbc
#optional
#completewith Beaks
.goto Nagrand,35.2,61.2,0
>>Kill |cRXP_ENEMY_Aged Clefthoofs|r. Loot them for their |cRXP_LOOT_Blubber|r
.complete 10252,3 
.isOnQuest 10252
.mob Aged Clefthoof
step
#questguide << !tbc
#optional
#completewith next
>>Kill |cRXP_ENEMY_Greater Windrocs|r. Loot them for their |cRXP_LOOT_Beak|r
.complete 10252,2 
.isOnQuest 10252
.mob Greater Windroc
step
#loop
.line Nagrand,32.66,24.25,33.01,20.84,34.16,20.04,35.46,19.31,36.93,20.77,35.87,23.93,33.32,27.93,31.32,30.74,32.95,28.13,32.66,26.83,32.66,24.25
.goto Nagrand,32.66,26.83,60,0
.goto Nagrand,32.95,28.13,60,0
.goto Nagrand,31.32,30.74,60,0
.goto Nagrand,33.32,27.93,60,0
.goto Nagrand,35.87,23.93,60,0
.goto Nagrand,36.93,20.77,60,0
.goto Nagrand,35.46,19.31,60,0
.goto Nagrand,34.16,20.04,60,0
.goto Nagrand,33.01,20.84,60,0
.goto Nagrand,32.66,24.25,60,0
>>Kill |cRXP_ENEMY_Gutripper|r. Loot him for his |cRXP_LOOT_Eye|r. He patrols around clockwise and may be too high to pull at times. He runs VERY fast.
>>This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.<< tbc/wotlk
.complete 9856,1 
.unitscan Gutripper
step
#questguide << !tbc
#label Beaks
#loop
.line Nagrand,35.97,29.37,35.71,18.67,32.69,22.30,33.39,26.11,30.88,32.97
.goto Nagrand,35.97,29.37,55,0
.goto Nagrand,35.71,18.67,55,0
.goto Nagrand,32.69,22.30,55,0
.goto Nagrand,33.39,26.11,55,0
.goto Nagrand,30.88,32.97,55,0
>>Kill |cRXP_ENEMY_Greater Windrocs|r. Loot them for their |cRXP_LOOT_Beak|r
.complete 10252,2 
.isOnQuest 10252
.mob Greater Windroc
step
#optional
#completewith Murkblood
.use 24560 >>Use the |T135432:0|t[Torch of Liquid Fire] in your bags on Villager Corpses
.complete 9874,1 
.target Sunspring Villager
step
#optional
#completewith StayCaptive
.goto Nagrand,33.2,46.6,0
>>Kill |cRXP_ENEMY_Murkblood Putrefiers|r, |cRXP_ENEMY_Scavengers|r and |cRXP_ENEMY_Raiders|r
.complete 9862,1 
.mob +Murkblood Putrifier
.complete 9878,1 
.mob +Murkblood Scavenger
.complete 9878,2 
.mob +Murkblood Raider
step
.goto Nagrand,30.83,42.36
>>Kill |cRXP_ENEMY_Ortor of Murkblood|r
.complete 9873,1 
.mob Ortor of Murkblood
step
.goto Nagrand,33.19,42.30
>>Clear all the mobs around the hut and make sure you're at full health/mana before talking to the |cRXP_FRIENDLY_Kurenai Captive|r inside << !Rogue !Warrior !DK
>>Clear all the mobs around the hut and make sure you're at full health before talking to the |cRXP_FRIENDLY_Kurenai Captive|r inside << Rogue/Warrior/DK
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Kurenai Captive|r
.accept 9879 >> Accept The Totem of Kar'dash
.target Kurenai Captive
step
#label StayCaptive
.goto Nagrand,32.37,40.04,50,0
.goto Nagrand,31.57,38.77
>>Escort the |cRXP_FRIENDLY_Kurenai Captive|r. Be ready with cooldowns for an ambush close to the fork in the road
.complete 9879,1 
.target Kurenai Captive
step
#label Murkblood
>>Kill |cRXP_ENEMY_Murkblood Putrefiers|r, |cRXP_ENEMY_Scavengers|r and |cRXP_ENEMY_Raiders|r
.complete 9862,1 
.mob +Murkblood Putrifier
.goto Nagrand,31.49,46.91,50,0
.goto Nagrand,32.98,46.84,50,0
.goto Nagrand,33.98,47.50,50,0
.goto Nagrand,34.28,45.97,50,0
.goto Nagrand,33.49,43.25,50,0
.goto Nagrand,32.24,43.46
.complete 9878,2 
.mob +Murkblood Raider
.goto Nagrand,31.48,42.47,50,0
.goto Nagrand,31.14,43.33,50,0
.goto Nagrand,32.10,46.26,50,0
.goto Nagrand,32.77,45.08,50,0
.goto Nagrand,33.31,42.50,50,0
.goto Nagrand,32.24,43.46
.complete 9878,1 
.mob +Murkblood Scavenger
.goto Nagrand,32.20,45.33,50,0
.goto Nagrand,33.31,44.25,50,0
.goto Nagrand,32.84,42.59,50,0
.goto Nagrand,33.23,40.93,50,0
.goto Nagrand,31.58,39.66,50,0
.goto Nagrand,30.66,41.29,50,0
.goto Nagrand,31.14,41.52,50,0
.goto Nagrand,32.24,43.46
step
#optional
#completewith Surgers
.goto Nagrand,33.17,48.36,50,0
.use 24560 >>Use the |T135432:0|t[Torch of Liquid Fire] in your bags on Villager Corpses
.complete 9874,1 
.target Sunspring Villager
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Lake Surgers|r << !Mage
>>Kill |cRXP_ENEMY_Lake Surgers|r. Be careful as they are immune to frost << Mage
.complete 9810,2 
.mob Lake Surger
step
>>Kill |cRXP_ENEMY_Watoosun's Polluted Essence|r
.complete 9810,1 
.goto Nagrand,33.03,50.86
.mob Watoosun's Polluted Essence
step
#label Surgers
.goto Nagrand,30.98,50.56,60,0
.goto Nagrand,33.23,48.87,60,0
.goto Nagrand,35.17,46.01,60,0
.goto Nagrand,36.91,46.72,60,0
.goto Nagrand,33.26,54.42,60,0
.goto Nagrand,30.98,50.56
>>Kill |cRXP_ENEMY_Lake Surgers|r << !Mage
>>Kill |cRXP_ENEMY_Lake Surgers|r. Be careful as they are immune to frost << Mage
.complete 9810,2 
.mob Lake Surger
step
.goto Nagrand,33.17,48.36,50,0
.goto Nagrand,34.52,47.21,50,0
.goto Nagrand,34.96,46.15
.use 24560 >>Use the |T135432:0|t[Torch of Liquid Fire] in your bags on Villager Corpses
.complete 9874,1 
.target Sunspring Villager
step
#optional
#completewith next
.line Nagrand,26.34,51.07,25.93,53.93,25.27,51.74,24.45,50.91,23.69,49.61,24.47,49.04,23.93,48.94,24.36,46.98,23.77,44.47,25.33,41.39,25.72,40.82,26.35,39.23,28.22,38.16,28.35,37.22,28.12,35.92,29.35,34.24,30.07,34.90,30.64,35.79,30.65,37.70,28.90,38.17,28.49,39.43,27.84,42.01,27.25,45.30,26.91,46.66,26.65,48.17,26.34,51.07
>>Kill |cRXP_ENEMY_Bach'lor|r. Loot him for his |cRXP_LOOT_Hoof|r. He patrols around counter-clockwise.
>>This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.<< tbc/wotlk
.complete 9859,1 
.unitscan Bach'lor
step
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Kima|r
.turnin 9982 >> Turn in He Called Himself Altruis...
.isOnQuest 9982
.target Altruis the Sufferer
step
#questguide << tbc/wotlk
.goto Nagrand,27.33,43.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.accept 9991 >> Accept Surveying the Land
.timer 135,Surveying the Land RP
.target Altruis the Sufferer
.xp <66,1
step
#questguide << tbc/wotlk
.goto Nagrand,27.33,43.09
>>Wait out the flight
.turnin 9991 >> Turn in Surveying the Land
.accept 9999 >> Accept Buying Time
.target Altruis the Sufferer
.xp <66,1
step
#questguide << tbc/wotlk
#loop
.goto 1951/530,8987.400,-1346.100,60,0
.goto 1951/530,8975.500,-1357.300,60,0
.goto 1951/530,8853.800,-1347.800,60,0
.goto 1951/530,8987.400,-1346.100,0
.goto 1951/530,8975.500,-1357.300,0
.goto 1951/530,8853.800,-1347.800,0
>>Kill |cRXP_ENEMY_Gan'arg Tinkerer|r, |cRXP_ENEMY_Mo'arg Engineer|r and |cRXP_ENEMY_Felguard Legionnaire|r
.complete 9999,3 
.mob +Gan'arg Tinkerer
.complete 9999,2 
.mob +Mo'arg Engineer
.complete 9999,1 
.mob +Felguard Legionnaire
.xp <66,1
step
#questguide << tbc/wotlk
.goto 1951/530,8785.601,-1543.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.target Altruis the Sufferer
.turnin 9999 >>Turn in Buying Time
.accept 10001 >>Accept The Master Planner
.xp <66,1
step
#questguide << tbc/wotlk
.goto 1951/530,8990.500,-1234.000
>>Kill |cRXP_ENEMY_The Master Planner|r and loot his |cRXP_LOOT_Blueprints|r
.complete 10001,1 
.xp <66,1
.mob Mo'arg Master Planner
step
#questguide << tbc/wotlk
.goto 1951/530,8785.500,-1545.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Altruis the Sufferer|r
.target Altruis the Sufferer
.turnin 10001 >>Turn in The Master Planner
.xp <66,1
step
#questguide << !tbc
#optional
#completewith Banthar
.goto Nagrand,35.2,61.2,0
>>Kill |cRXP_ENEMY_Aged Clefthoofs|r. Loot them for their |cRXP_LOOT_Blubber|r
.complete 10252,3 
.isOnQuest 10252
.mob Aged Clefthoof
step
#questguide << !tbc
#optional
#completewith next
.goto Nagrand,24.37,41.81,0
>>Kill a |cRXP_ENEMY_Mountain Gronn|r. Loot it for its |cRXP_LOOT_Eyeball|r
.complete 10252,1 
.isOnQuest 10252
.unitscan Mountain Gronn
step
#label Bachlor
#loop
.goto Nagrand,26.34,51.07,60,0
.goto Nagrand,25.93,53.93,60,0
.goto Nagrand,25.27,51.74,60,0
.goto Nagrand,24.45,50.91,60,0
.goto Nagrand,23.69,49.61,60,0
.goto Nagrand,24.47,49.04,60,0
.goto Nagrand,23.93,48.94,60,0
.goto Nagrand,24.36,46.98,60,0
.goto Nagrand,23.77,44.47,60,0
.goto Nagrand,25.33,41.39,60,0
.goto Nagrand,25.72,40.82,60,0
.goto Nagrand,26.35,39.23,60,0
.goto Nagrand,28.22,38.16,60,0
.goto Nagrand,28.35,37.22,60,0
.goto Nagrand,28.12,35.92,60,0
.goto Nagrand,29.35,34.24,60,0
.goto Nagrand,30.07,34.90,60,0
.goto Nagrand,30.64,35.79,60,0
.goto Nagrand,30.65,37.70,60,0
.goto Nagrand,28.90,38.17,60,0
.goto Nagrand,28.49,39.43,60,0
.goto Nagrand,27.84,42.01,60,0
.goto Nagrand,27.25,45.30,60,0
.goto Nagrand,26.91,46.66,60,0
.goto Nagrand,26.65,48.17,60,0
.line Nagrand,26.34,51.07,25.93,53.93,25.27,51.74,24.45,50.91,23.69,49.61,24.47,49.04,23.93,48.94,24.36,46.98,23.77,44.47,25.33,41.39,25.72,40.82,26.35,39.23,28.22,38.16,28.35,37.22,28.12,35.92,29.35,34.24,30.07,34.90,30.64,35.79,30.65,37.70,28.90,38.17,28.49,39.43,27.84,42.01,27.25,45.30,26.91,46.66,26.65,48.17,26.34,51.07
>>Kill |cRXP_ENEMY_Bach'lor|r. Loot him for his |cRXP_LOOT_Hoof|r. He patrols around counter-clockwise.
>>This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.<<tbc/wotlk
.complete 9859,1 
.unitscan Bach'lor
step
#questguide << !tbc
.goto Nagrand,24.37,41.81
>>Kill a |cRXP_ENEMY_Mountain Gronn|r. Loot it for its |cRXP_LOOT_Eyeball|r
.complete 10252,1 
.isOnQuest 10252
.unitscan Mountain Gronn
step
.goto 1951/530,8540.400,-2049.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shadrek|r
.target Shadrek
.accept 9914 >>Accept A Head Full of Ivory
.turnin 9914 >>Turn in A Head Full of Ivory
.itemcount 25463,3
step
.goto 1951/530,8562.300,-2085.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gezhe|r
.target Gezhe
.turnin 9913 >>Turn in The Consortium Needs You!
.accept 9882 >>Accept Stealing from Thieves
step
.goto 1951/530,8594.900,-2099.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zerid|r
.target Zerid
.accept 9900 >>Accept Gava'xi
.accept 9925 >>Accept Matters of Security
step
#optional
#completewith Voidspawns
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
.collect 25463,3,9914,1 
.unitscan Wild Elekk
step
#optional
#completewith Gava
>>Kill |cRXP_ENEMY_Raiders|r. Loot them for their |cRXP_LOOT_Crystals|r. The |cRXP_LOOT_Crystals|r can also be found on the ground
>>Kill |cRXP_ENEMY_Voidspawns|r
.complete 9882,1 
.mob +Vir'aani Raider
.complete 9925,1 
.mob +Voidspawn
step
#questguide << !tbc
.goto Nagrand,25.84,73.34,60,0
.goto Nagrand,27.73,74.09,60,0
.goto Nagrand,28.36,78.70,60,0
.goto Nagrand,32.07,81.44,60,0
.goto Nagrand,40.34,84.18
.use 24501 >>Use |T135242:0|t[Gordawg's Boulder] on |cRXP_ENEMY_Shattered Rumblers|r to spawn the |cRXP_ENEMY_Minions of Gurok|r. Kill them. You can use the |T135242:0|tBoulder while moving
.complete 9849,1 
.mob Shattered Rumbler
.mob Minion of Gurok
step
#label Gava
.goto Nagrand,42.39,73.49,50,0
.goto Nagrand,43.65,74.59,50,0
.goto Nagrand,43.47,72.86,50,0
.goto Nagrand,42.45,72.32,50,0
.goto Nagrand,41.53,71.33
>>Kill |cRXP_ENEMY_Gava'xi|r. He patrols around from the little cliff to the crystal slightly north of it
.complete 9900,1 
.unitscan Gava'xi
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Voidspawns|r
.complete 9925,1 
.mob Voidspawn
step
#loop
.goto Nagrand,41.61,70.68,50,0
.goto Nagrand,36.88,66.96,50,0
.goto Nagrand,34.53,62.93,60,0
.goto Nagrand,30.53,76.12,60,0
.goto Nagrand,41.61,70.68,0
.goto Nagrand,36.88,66.96,0
.goto Nagrand,34.53,62.93,0
.goto Nagrand,30.53,76.12,0
>>Kill |cRXP_ENEMY_Raiders|r. Loot them for their |cRXP_LOOT_Crystals|r. The |cRXP_LOOT_Crystals|r can also be found on the ground
.complete 9882,1 
.mob Vir'aani Raider
step
#label Voidspawns
#loop
.line Nagrand,30.51,66.79,32.23,69.85,31.75,74.99,36.51,77.38,38.03,79.58,40.19,77.22,37.87,76.04,39.87,72.76,39.35,67.61,41.46,62.82,37.64,66.21,34.90,65.37,32.91,67.36,30.51,66.79
.goto Nagrand,30.51,66.79,60,0
.goto Nagrand,32.23,69.85,60,0
.goto Nagrand,31.75,74.99,60,0
.goto Nagrand,36.51,77.38,60,0
.goto Nagrand,38.03,79.58,60,0
.goto Nagrand,40.19,77.22,60,0
.goto Nagrand,37.87,76.04,60,0
.goto Nagrand,39.87,72.76,60,0
.goto Nagrand,39.35,67.61,60,0
.goto Nagrand,41.46,62.82,60,0
.goto Nagrand,37.64,66.21,60,0
.goto Nagrand,34.90,65.37,60,0
.goto Nagrand,32.91,67.36,60,0
.goto Nagrand,30.51,66.79,60,0
>>Kill |cRXP_ENEMY_Voidspawns|r
.complete 9925,1 
.mob Voidspawn
step
#optional
#completewith AerisL
>>Kill |cRXP_ENEMY_Banthar|r. Loot him for his |cRXP_LOOT_Horn|r. He patrols around.
>>This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.<<tbc/wotlk
.complete 9851,1 
.unitscan Banthar
step
#loop
.line Nagrand,44.13,76.74,35.70,58.91,29.60,61.89,33.11,77.90,44.13,76.74
.goto Nagrand,44.13,76.74,60,0
.goto Nagrand,35.70,58.91,60,0
.goto Nagrand,29.60,61.89,60,0
.goto Nagrand,33.11,77.90,60,0
.goto Nagrand,44.13,76.74,60,0
>>Kill |cRXP_ENEMY_Wild Elekks|r. Loot them for their |cRXP_LOOT_Tusks|r
>>|cRXP_WARN_Bull Elekks do NOT drop them!|r
.collect 25463,3,9914,1 
.unitscan Wild Elekk
step
#label AerisL
.goto 1951/530,8595.000,-2100.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zerid|r
.target Zerid
.turnin 9900 >>Turn in Gava'xi
.turnin 9925 >>Turn in Matters of Security
step
.goto 1951/530,8563.800,-2086.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gezhe|r
.target Gezhe
.turnin 9882 >>Turn in Stealing from Thieves
step
.goto Nagrand,31.77,56.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shadrek|r
.accept 9914 >>Accept A Head Full of Ivory
.turnin 9914 >>Turn in A Head Full of Ivory
.target Shadrek
step
#loop
.line Nagrand,30.88,63.61,32.53,61.08,33.99,60.44,36.31,58.76,37.39,58.63,38.67,59.52,40.46,60.74,44.52,61.64,46.20,63.09,46.71,66.40,46.31,67.69,45.46,68.24,43.63,68.35,43.05,67.77,42.75,66.72,42.56,64.36,41.98,62.64,40.82,61.30,38.67,59.52
.goto Nagrand,30.88,63.61,50,0
.goto Nagrand,32.53,61.08,50,0
.goto Nagrand,33.99,60.44,50,0
.goto Nagrand,36.31,58.76,50,0
.goto Nagrand,37.39,58.63,50,0
.goto Nagrand,38.67,59.52,50,0
.goto Nagrand,40.46,60.74,50,0
.goto Nagrand,44.52,61.64,50,0
.goto Nagrand,46.20,63.09,50,0
.goto Nagrand,46.71,66.40,50,0
.goto Nagrand,46.31,67.69,50,0
.goto Nagrand,45.46,68.24,50,0
.goto Nagrand,43.63,68.35,50,0
.goto Nagrand,43.05,67.77,50,0
.goto Nagrand,42.75,66.72,50,0
.goto Nagrand,42.56,64.36,50,0
.goto Nagrand,41.98,62.64,50,0
.goto Nagrand,40.82,61.30,50,0
.goto Nagrand,38.67,59.52,50,0
>>Kill |cRXP_ENEMY_Banthar|r. Loot him for his |cRXP_LOOT_Horn|r. He patrols around.
>>This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.<<tbc/wotlk
.complete 9851,1 
.unitscan Banthar
step
#questguide << !tbc
#loop
.line Nagrand,30.88,63.61,32.53,61.08,33.99,60.44,36.31,58.76,37.39,58.63,38.67,59.52,40.46,60.74,44.52,61.64,46.20,63.09,46.71,66.40,46.31,67.69,45.46,68.24,43.63,68.35,43.05,67.77,42.75,66.72,42.56,64.36,41.98,62.64,40.82,61.30,38.67,59.52
.goto Nagrand,30.88,63.61,50,0
.goto Nagrand,32.53,61.08,50,0
.goto Nagrand,33.99,60.44,50,0
.goto Nagrand,36.31,58.76,50,0
.goto Nagrand,37.39,58.63,50,0
.goto Nagrand,38.67,59.52,50,0
.goto Nagrand,40.46,60.74,50,0
.goto Nagrand,44.52,61.64,50,0
.goto Nagrand,46.20,63.09,50,0
.goto Nagrand,46.71,66.40,50,0
.goto Nagrand,46.31,67.69,50,0
.goto Nagrand,45.46,68.24,50,0
.goto Nagrand,43.63,68.35,50,0
.goto Nagrand,43.05,67.77,50,0
.goto Nagrand,42.75,66.72,50,0
.goto Nagrand,42.56,64.36,50,0
.goto Nagrand,41.98,62.64,50,0
.goto Nagrand,40.82,61.30,50,0
.goto Nagrand,38.67,59.52,50,0
>>Kill |cRXP_ENEMY_Aged Clefthoofs|r. Loot them for their |cRXP_LOOT_Blubber|r
.complete 10252,3 
.isOnQuest 10252
.unitscan Aged Clefthoof
step
#questguide << !tbc
.goto Nagrand,51.82,56.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nitrin the Learned|r on the bottom floor
.turnin 10252 >> Turn in Vision of the Dead
.isQuestComplete 10252
.target Nitrin the Learned
step
#questguide << !tbc
#sticky
#optional
.abandon 10252 >> Abandon Vision of the Dead
step << Shaman
#completewith next
.hs >> Hearth to Telaar
step
#sticky
#label problem
.goto 1951/530,7286.700,-2622.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Poli'lukluk the Wiser|r
.target Poli'lukluk the Wiser
.turnin 9878 >>Turn in Solving the Problem
step
.goto 1951/530,7278.000,-2618.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to Mo'mor the Breaker
.turnin 9922 >>Turn in The Twin Clefts of Nagrand
.accept 10108 >>Accept Diplomatic Measures
.target Mo'mor the Breaker
step
.goto 1951/530,7286.000,-2612.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Otonbu the Sage|r
.target Otonbu the Sage
.turnin 9874 >>Turn in Stopping the Spread
step
#requires problem
.goto 1951/530,7270.600,-2568.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Moi'bff Jill|r
.target Warden Moi'bff Jill
.accept 10476 >>Accept Fierce Enemies
.turnin 10476 >>Turn in Fierce Enemies
.itemcount 25433,10 
step
.goto 1951/530,7231.500,-2489.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arechron|r
.target Arechron
.turnin 9873 >>Turn in Ortor My Old Friend...
.turnin 9924 >>Turn in Corki's Gone Missing Again!
.turnin 9879 >>Turn in The Totem of Kar'dash
.accept 9954 >>Accept Corki's Ransom
step
.goto Nagrand,73.81,62.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lantresor of the Blade|r
.complete 10108,1 
.skipgossip 18261,1
.target Lantresor of the Blade
step
.goto Nagrand,73.81,62.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lantresor of the Blade|r
.turnin 10108 >> Turn in Diplomatic Measures
.accept 9928 >> Accept Armaments for Deception
.accept 9927 >> Accept Ruthless Cunning
.target Lantresor of the Blade
step
#optional
#aldor
#completewith ksf1
>>Kill |cRXP_ENEMY_Kil'sorrow|r orcs. Loot them for their |cRXP_LOOT_Marks of Kil'jaeden|r, save them for a quest later
.collect 29425,10,10325,1 
step
#optional
#completewith next
.goto Nagrand,70.51,79.79,0
.use 25552 >>Kill |cRXP_ENEMY_Orcs|r. Use the |T132484:0|t[Warmaul Ogre Banner] in your bags on their corpses
>>Loot the |cRXP_PICK_Wooden Boxes|r on the ground
.complete 9936,2 
.complete 9927,1 
.complete 9928,1 
.mob Kil'sorrow Spellbinder
.mob Kil'sorrow Cultist
.mob Kil'sorrow Deathsworn
.mob Kil'sorrow Invader
.mob Kil'sorrow Ritualist
.mob Kil'sorrow Agent
step
.goto Nagrand,70.98,81.48,30,0
.goto Nagrand,71.16,82.36
>>Kill |cRXP_ENEMY_Giselda|r inside the Fortress
.complete 9936,1 
.unitscan Giselda the Crone
step
#label ksf1
#loop
.line Nagrand,71.70,80.65,72.14,82.16,71.70,79.25,70.26,79.11,69.46,79.66,68.34,82.79,69.64,81.65,70.83,80.61,71.70,80.65
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,72.14,82.16,40,0
.goto Nagrand,71.70,79.25,40,0
.goto Nagrand,70.26,79.11,40,0
.goto Nagrand,69.46,79.66,40,0
.goto Nagrand,68.34,82.79,40,0
.goto Nagrand,69.64,81.65,40,0
.goto Nagrand,70.83,80.61,40,0
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,72.14,82.16,40,0
.goto Nagrand,71.70,79.25,40,0
.goto Nagrand,70.26,79.11,40,0
.goto Nagrand,69.46,79.66,40,0
.goto Nagrand,68.34,82.79,40,0
.goto Nagrand,69.64,81.65,40,0
.goto Nagrand,70.83,80.61,40,0
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,72.14,82.16,40,0
.goto Nagrand,71.70,79.25,40,0
.goto Nagrand,70.26,79.11,40,0
.goto Nagrand,69.46,79.66,40,0
.goto Nagrand,68.34,82.79,40,0
.goto Nagrand,69.64,81.65,40,0
.goto Nagrand,70.83,80.61,40,0
.use 25552 >>Kill |cRXP_ENEMY_Orcs|r. Use the |T132484:0|t[Warmaul Ogre Banner] in your bags on their corpses
>>Loot the wooden boxes on the ground
.complete 9936,2 
.complete 9927,1 
.complete 9928,1 
.mob Kil'sorrow Spellbinder
.mob Kil'sorrow Cultist
.mob Kil'sorrow Deathsworn
.mob Kil'sorrow Invader
.mob Kil'sorrow Ritualist
.mob Kil'sorrow Agent
step
#aldor
#loop
.line Nagrand,71.70,80.65,72.14,82.16,71.70,79.25,70.26,79.11,69.46,79.66,68.34,82.79,69.64,81.65,70.83,80.61,71.70,80.65
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,72.14,82.16,40,0
.goto Nagrand,71.70,79.25,40,0
.goto Nagrand,70.26,79.11,40,0
.goto Nagrand,69.46,79.66,40,0
.goto Nagrand,68.34,82.79,40,0
.goto Nagrand,69.64,81.65,40,0
.goto Nagrand,70.83,80.61,40,0
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,72.14,82.16,40,0
.goto Nagrand,71.70,79.25,40,0
.goto Nagrand,70.26,79.11,40,0
.goto Nagrand,69.46,79.66,40,0
.goto Nagrand,68.34,82.79,40,0
.goto Nagrand,69.64,81.65,40,0
.goto Nagrand,70.83,80.61,40,0
.goto Nagrand,71.70,80.65,40,0
.goto Nagrand,72.14,82.16,40,0
.goto Nagrand,71.70,79.25,40,0
.goto Nagrand,70.26,79.11,40,0
.goto Nagrand,69.46,79.66,40,0
.goto Nagrand,68.34,82.79,40,0
.goto Nagrand,69.64,81.65,40,0
.goto Nagrand,70.83,80.61,40,0
>>Kill |cRXP_ENEMY_Kil'sorrow|r orcs. Loot them for their |cRXP_LOOT_Marks of Kil'jaeden|r, save them for a quest later
.collect 29425,10,10325,1 
.mob Kil'sorrow Spellbinder
.mob Kil'sorrow Cultist
.mob Kil'sorrow Deathsworn
.mob Kil'sorrow Invader
.mob Kil'sorrow Ritualist
.mob Kil'sorrow Agent
step
.goto Nagrand,73.81,62.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lantresor of the Blade|r
.turnin 9928 >>Turn in Armaments for Deception
.turnin 9927 >>Turn in Ruthless Cunning
.accept 9931 >>Accept Returning the Favor
.accept 9932 >>Accept Body of Evidence
.target Lantresor of the Blade
step
#sticky
#hidewindow
#label saved4a
#completewith Safari4
.subzone 3673 >> 1
step
#requires saved4a
#label Saved4
#completewith Safari4
>>Sometimes |cRXP_ENEMY_Gankly|r can appear at the Safari. This is a rare event
>>Kill |cRXP_ENEMY_Gankly|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kristen Dipswitch|r
.accept 9897 >> Accept I'm Saved!
.goto Nagrand,71.42,40.60,0
.unitscan Gankly Rottenfist
.target Kristen Dipswitch
step
#requires Saved4
#completewith Safari4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Lane|r
.turnin 9897 >> Turn in I'm Saved!
.goto Nagrand,71.38,40.62
.target Harold Lane
step
#sticky
#label talbuk3
.goto 1951/530,6350.300,-1455.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Lane|r
.target Harold Lane
.turnin 9859 >>Turn in Talbuk Mastery
.isQuestComplete 9859
step
#sticky
#label windroc3
.goto 1951/530,6342.000,-1451.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shado 'Fitz' Farstrider|r
.target Shado 'Fitz' Farstrider
.turnin 9856 >>Turn in Windroc Mastery
.isQuestComplete 9856
step
.goto 1951/530,6343.300,-1461.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r
.target Hemet Nesingwary
.turnin 9851 >>Turn in Clefthoof Mastery
.isQuestComplete 9851
step
#requires windroc3
step
#requires talbuk3
#label Safari4
.goto Nagrand,71.52,40.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r
.accept 9852 >>Accept The Ultimate Bloodsport
.isQuestTurnedIn 9856
.isQuestTurnedIn 9859
.isQuestTurnedIn 9851
.target Hemet Nesingwary
step
#optional
#questguide << !tbc
#completewith next
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.turnin 9849 >>Turn in Shattering the Veil
.isQuestComplete 9849
.unitscan Gordawg
step
.goto 1951/530,6937.200,-782.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Lo'ap|r
.target Elementalist Lo'ap
.turnin 9810 >> Turn in The Spirit Polluted
.turnin 9815 >>Turn in Muck Diving
step
.goto 1951/530,6952.800,-782.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elementalist Morgh|r
.target Elementalist Morgh
.turnin 9862 >>Turn in Murkblood Corrupters
step
#questguide << !tbc
.goto Nagrand,62.19,22.60,50,0
.goto Nagrand,61.99,22.09,50,0
.goto Nagrand,61.28,22.24,50,0
.goto Nagrand,60.88,21.39,50,0
.goto Nagrand,60.38,20.88,50,0
.goto Nagrand,59.87,21.32,50,0
.goto Nagrand,59.58,22.48,50,0
.goto Nagrand,60.08,24.41,50,0
.goto Nagrand,60.57,25.04,50,0
.goto Nagrand,61.15,24.92,50,0
.goto Nagrand,61.72,24.54
.line Nagrand,62.19,22.60,61.99,22.09,61.28,22.24,60.88,21.39,60.38,20.88,59.87,21.32,59.58,22.48,60.08,24.41,60.57,25.04,61.15,24.92,61.72,24.54,62.19,22.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gordawg|r patrolling clockwise at the Throne of the Elements
.turnin 9849 >>Turn in Shattering the Veil
.unitscan Gordawg
step
#optional
#completewith Zorbo
.use 25555 >>Kill |cRXP_ENEMY_Orcs|r. Use the |T132484:0|t[Kil'sorrow Banner] in your bags on their corpses
.complete 9940,2 
.mob +Warmaul Shaman
.complete 9940,3 
.complete 9931,1 
.mob +Warmaul Reaver
step
#completewith next
.goto Nagrand,46.57,24.40
.cast 32408 >> Use the |T133680:0|t[Damp Woolen Blanket] in your bags at the Funeral Pyre. Kill any |cRXP_ENEMY_Ogres|r the |cRXP_FRIENDLY_Saboteurs|r are attacking
.timer 62,Body of Evidence RP
.use 25658 
step
.goto Nagrand,46.57,24.40
>>Kill |cRXP_ENEMY_Ogres|r until the objective completes
.complete 9932,1 
step
#label Zorbo
.goto Nagrand,46.21,18.79,30,0
.goto Nagrand,46.49,18.18
>>Kill |cRXP_ENEMY_Zorbo|r
.complete 9940,1 
.mob Zorbo the Advisor
step
.goto Nagrand,49.22,21.66,50,0
.goto Nagrand,48.24,23.60,50,0
.goto Nagrand,46.59,24.43,50,0
.goto Nagrand,45.44,22.01,50,0
.goto Nagrand,43.65,21.51,50,0
.goto Nagrand,42.54,22.55
.use 25555 >>Kill |cRXP_ENEMY_Orcs|r. Use the |T132484:0|t[Kil'sorrow Banner] in your bags on their corpses
.complete 9940,2 
.mob +Warmaul Shaman
.complete 9940,3 
.complete 9931,1 
.mob +Warmaul Reaver
step
.goto Nagrand,42.77,20.73
>>Look for a group for The Ring of Blood questline. There are 6 elite quests that give a LOT of fast xp and a weapon that'll last you to 70. Only accept this when your party is ready and on the same quest progression as you. (Auto-accept is disabled for this questline). Skip this step if you can't find a group for it
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gurgthock|r
.accept 9962,1 >> Accept The Ring of Blood: Brokentoe
.target Gurgthock
step
.goto Nagrand,43.66,20.37
>>Kill |cRXP_ENEMY_Brokentoe|r in the Ring of Blood
.complete 9962,1 
.isOnQuest 9962
.mob Brokentoe
step
.goto Nagrand,42.77,20.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wodin the Troll-Servant|r
.turnin 9962 >> Turn in The Ring of Blood: Brokentoe
.isQuestComplete 9962
.target Wodin the Troll-Servant
step
.goto Nagrand,42.77,20.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gurgthock|r
.accept 9967,1 >> Accept The Ring of Blood: The Blue Brothers
.isQuestTurnedIn 9962
.target Gurgthock
step
.goto Nagrand,43.66,20.37
>>Kill the |cRXP_ENEMY_Blue Brothers|r in the Ring of Blood
.complete 9967,1 
.isOnQuest 9967
.mob Murkblood Twin
step
.goto Nagrand,42.77,20.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wodin the Troll-Servant|r
.turnin 9967 >> Turn in The Ring of Blood: The Blue Brothers
.isQuestComplete 9967
.target Wodin the Troll-Servant
step
.goto Nagrand,42.77,20.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gurgthock|r
.accept 9970,1 >> Accept The Ring of Blood: Rokdar the Sundered Lord
.isQuestTurnedIn 9967
.target Gurgthock
step
.goto Nagrand,43.66,20.37
>>Kill |cRXP_ENEMY_Rokdar the Sundered Lord|r in the Ring of Blood
.complete 9970,1 
.isOnQuest 9970
.mob Rokdar the Sundered Lord
step
.goto Nagrand,42.77,20.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wodin the Troll-Servant|r
.turnin 9970 >> Turn in The Ring of Blood: Rokdar the Sundered Lord
.isQuestComplete 9970
.target Wodin the Troll-Servant
step
.goto Nagrand,42.77,20.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gurgthock|r
.accept 9972,1 >> Accept The Ring of Blood: Skra'gath
.isQuestTurnedIn 9970
.target Gurgthock
step
.goto Nagrand,43.66,20.37
>>Kill |cRXP_ENEMY_Skra'gath|r in the Ring of Blood
.complete 9972,1 
.isOnQuest 9972
.mob Skra'gath
step
.goto Nagrand,42.77,20.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wodin the Troll-Servant|r
.turnin 9972 >> Turn in The Ring of Blood: Skra'gath
.isQuestComplete 9972
.target Wodin the Troll-Servant
step
.goto Nagrand,42.77,20.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gurgthock|r
.accept 9973,1 >> Accept The Ring of Blood: The Warmaul Champion
.isQuestTurnedIn 9972
.target Gurgthock
step
.goto Nagrand,43.66,20.37
>>Kill |cRXP_ENEMY_The Warmaul Champion|r in the Ring of Blood
.complete 9973,1 
.isOnQuest 9973
.mob Warmaul Champion
step
.goto Nagrand,42.77,20.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wodin the Troll-Servant|r
.turnin 9973 >> Turn in The Ring of Blood: The Warmaul Champion
.isQuestComplete 9973
.target Wodin the Troll-Servant
step
.goto Nagrand,42.77,20.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gurgthock|r
.accept 9977,1 >> Accept The Ring of Blood: The Final Challenge
.isQuestTurnedIn 9973
.target Gurgthock
step
.goto Nagrand,43.43,20.57
>>Kill |cRXP_ENEMY_Mogor|r in the Ring of Blood (twice)
.complete 9977,1 
.isOnQuest 9977
.mob Mogor
step
.goto Nagrand,42.77,20.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wodin the Troll-Servant|r
.turnin 9977 >> Turn in The Ring of Blood: The Final Challenge
.isQuestComplete 9977
.target Wodin the Troll-Servant
step
#completewith Corki4
.goto Nagrand,26.50,22.70,0
>>Loot the silver |cRXP_PICK_Supply Crates|r on the ground in the caves and outside
.complete 9956,1 
step
#completewith SupplyC
>>Kill |cRXP_ENEMY_Ogres|r. Loot them for their |cRXP_LOOT_Warbeads|r
.collect 25433,10,10476,1 
.mob Warmaul Brute
.mob Warmaul Warlock
step
#optional
#completewith next
.goto Nagrand,28.69,30.85,40,0
.goto Nagrand,25.93,28.93,40,0
.goto Nagrand,24.57,24.66,40 >> Take the path up to the top of the mountain
.skill riding,225,1
step
#label Corki4
.goto Nagrand,29.54,26.06
>>Go into the southern ogre cave atop the mountain.
>>|cRXP_FRIENDLY_Corki|r is guarded by an |cRXP_WARN_Elite Ogre|r, |cRXP_ENEMY_Bufferlo|r. You |cRXP_WARN_DO NOT|r have to kill |cRXP_ENEMY_Bufferlo|r. Just talk to |cRXP_FRIENDLY_Corki|r and run away<<tbc/wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Corki|r
.turnin 9954 >> Turn in Corki's Ransom
.target Corki
step
#questguide << tbc/wotlk
.goto Nagrand,29.54,26.06
>>Go into the southern ogre cave atop the mountain.
>>|cRXP_FRIENDLY_Corki|r is guarded by an |cRXP_WARN_Elite Ogre|r, |cRXP_ENEMY_Bufferlo|r. You |cRXP_WARN_DO NOT|r have to kill |cRXP_ENEMY_Bufferlo|r. Just talk to |cRXP_FRIENDLY_Corki|r and run away<<tbc/wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Corki|r
.accept 9955 >> Accept Cho'war the Pillager
.target Corki
step
#questguide << tbc/wotlk
#completewith next
.flygoto Nagrand,27.55,11.22,45 >> Fly up to the back entrance of the cave
step
#questguide << tbc/wotlk
.goto Nagrand,25.38,15.31,30,0
.goto Nagrand,26.23,15.61,30,0
.goto Nagrand,25.91,13.72
>>Kill |cRXP_ENEMY_Cho'war the Pillager|r. Loot him for his |cRXP_LOOT_Key|r. This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.
.collect 25648,1,9955,1 
.mob Cho'war the Pillager
step
#questguide << tbc/wotlk
#label Corki4
.goto Nagrand,29.54,26.06
>>Go into the southern ogre cave atop the mountain. Click on |cRXP_FRIENDLY_Corki's|r Cage.
>>|cRXP_FRIENDLY_Corki|r is guarded by an |cRXP_WARN_Elite Ogre|r, |cRXP_ENEMY_Bufferlo|r. You will have to kill or distract him in order to open the cage << tbc/wotlk
.complete 9955,1 
step
#label SupplyC
#loop
.groundgoto Nagrand,28.96,31.19,60,0
.groundgoto Nagrand,28.09,29.94,60,0
.goto Nagrand,24.71,30.48,50,0
.goto Nagrand,23.63,31.77,30,0
.goto Nagrand,23.14,29.32,50,0
.goto Nagrand,23.43,28.29,50,0
.goto Nagrand,24.67,27.54,50,0
.groundgoto Nagrand,26.42,29.74,40,0
.groundgoto Nagrand,24.60,24.92,40,0
.goto Nagrand,25.64,24.47,30,0
.goto Nagrand,27.24,23.87,30,0
.goto Nagrand,29.21,25.74,30,0
.goto Nagrand,25.81,20.33,50,0
.goto Nagrand,27.64,18.92,50,0
.groundgoto Nagrand,28.96,31.19,60,0
.groundgoto Nagrand,28.09,29.94,60,0
.goto Nagrand,24.71,30.48,50,0
.goto Nagrand,23.63,31.77,30,0
.goto Nagrand,23.14,29.32,50,0
.goto Nagrand,23.43,28.29,50,0
.goto Nagrand,24.67,27.54,50,0
.groundgoto Nagrand,26.42,29.74,40,0
.groundgoto Nagrand,24.60,24.92,40,0
.goto Nagrand,25.64,24.47,30,0
.goto Nagrand,27.24,23.87,30,0
.goto Nagrand,29.21,25.74,30,0
.goto Nagrand,25.81,20.33,50,0
.goto Nagrand,27.64,18.92,0
>>Loot the silver |cRXP_PICK_Supply Crates|r on the ground in the caves and outside
.complete 9956,1 
step
#loop
.groundgoto Nagrand,28.96,31.19,60,0
.groundgoto Nagrand,28.09,29.94,60,0
.goto Nagrand,24.71,30.48,50,0
.goto Nagrand,23.63,31.77,30,0
.goto Nagrand,23.14,29.32,50,0
.goto Nagrand,23.43,28.29,50,0
.goto Nagrand,24.67,27.54,50,0
.groundgoto Nagrand,26.42,29.74,40,0
.groundgoto Nagrand,24.60,24.92,40,0
.goto Nagrand,25.64,24.47,30,0
.goto Nagrand,27.24,23.87,30,0
.goto Nagrand,29.21,25.74,30,0
.goto Nagrand,25.81,20.33,50,0
.goto Nagrand,27.64,18.92,50,0
.groundgoto Nagrand,28.96,31.19,60,0
.groundgoto Nagrand,28.09,29.94,60,0
.goto Nagrand,24.71,30.48,50,0
.goto Nagrand,23.63,31.77,30,0
.goto Nagrand,23.14,29.32,50,0
.goto Nagrand,23.43,28.29,50,0
.goto Nagrand,24.67,27.54,50,0
.groundgoto Nagrand,26.42,29.74,40,0
.groundgoto Nagrand,24.60,24.92,40,0
.goto Nagrand,25.64,24.47,30,0
.goto Nagrand,27.24,23.87,30,0
.goto Nagrand,29.21,25.74,30,0
.goto Nagrand,25.81,20.33,50,0
.goto Nagrand,27.64,18.92,0
>>Kill |cRXP_ENEMY_Ogres|r. Loot them for their |cRXP_LOOT_Warbeads|r
.collect 25433,10,10476,1 
.mob Warmaul Brute
.mob Warmaul Warlock
step
#completewith next
.hs >> Hearth to Telaar
step
#sticky
#label HuntKima
.goto Nagrand,53.69,68.70,40,0
.goto Nagrand,54.01,69.11,40,0
.goto Nagrand,54.33,70.32,40,0
.goto Nagrand,54.75,70.41,40,0
.goto Nagrand,54.97,70.91,40,0
.goto Nagrand,55.30,71.42,40,0
.goto Nagrand,55.70,72.60,40,0
.goto Nagrand,55.61,73.18,40,0
.goto Nagrand,54.71,73.30,40,0
.goto Nagrand,54.53,73.66,40,0
.goto Nagrand,54.53,72.64,40,0
.goto Nagrand,54.30,72.28,40,0
.goto Nagrand,53.71,72.24,40,0
.goto Nagrand,53.52,71.94,40,0
.goto Nagrand,53.82,71.30,40,0
.goto Nagrand,53.42,70.82,40,0
.goto Nagrand,52.93,70.80,40,0
.goto Nagrand,53.16,70.24,40,0
.goto Nagrand,53.56,70.43,40,0
.goto Nagrand,54.10,69.56,40,0
.goto Nagrand,54.03,69.16,40,0
.goto Nagrand,53.69,68.70,40,0
.line Nagrand,53.69,68.70,54.03,69.16,54.10,69.56,53.56,70.43,53.16,70.24,52.93,70.80,53.42,70.82,53.82,71.30,53.52,71.94,53.71,72.24,54.30,72.28,54.53,72.64,54.53,73.66,54.71,73.30,55.61,73.18,55.70,72.60,55.30,71.42,54.97,70.91,54.75,70.41,54.33,70.32,54.01,69.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntress Kima|r. She patrols counter-clockwise around Telaar
.turnin 9956 >> Turn in The Ravaged Caravan
.unitscan Huntress Kima
step
.goto 1951/530,7270.600,-2568.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Moi'bff Jill|r
.target Warden Moi'bff Jill
.accept 10476 >>Accept Fierce Enemies
.turnin 10476 >>Turn in Fierce Enemies
.turnin 9936 >>Turn in Wanted: Giselda the Crone
.turnin 9940 >>Turn in Wanted: Zorbo the Advisor
.accept 9938 >>Accept Wanted: Durn the Hungerer << !tbc !wotlk
step
#optional << tbc/wotlk
#requires HuntKima
.goto 1951/530,7230.800,-2489.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arechron|r
.target Arechron
.turnin 9955 >>Turn in Cho'war the Pillager
.isQuestComplete 9955
step
>>Kill |cRXP_ENEMY_Tusker|r. Loot her for her |cRXP_LOOT_Heart|r
>>You can kite her back to Telaar if needed. She is NOT slowable, but moves at only about 110% movespeed. This quest is difficult. Find a group for her if needed. Skip this step if you're unable to find a group or solo her.<<tbc/wotlk
.goto Nagrand,44.50,65.24
.complete 9852,1 
.isOnQuest 9852
.mob Tusker
step << !tbc !wotlk
#loop
.goto Nagrand,46.6,61.4,60,0
.goto Nagrand,43.6,75.8,60,0
.goto Nagrand,34.4,78.0,60,0
.goto Nagrand,30.2,62.0,60,0
.goto Nagrand,40,60,90,0
.goto Nagrand,46.6,61.4,0
.goto Nagrand,43.6,75.8,0
.goto Nagrand,34.4,78.0,0
.goto Nagrand,30.2,62.0,0
.goto Nagrand,40,60,0
>>Kill |cRXP_ENEMY_Durn the Hungerer|r, he patrols around Oshu'gun
.complete 9938,1 
.mob Durn the Hungerer
step << Mage
#completewith next
.zone Shattrath City >> Teleport to Shattrath
.skill riding,<225,1
step
.goto Nagrand,73.81,62.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lantresor of the Blade|r
.turnin 9931 >> Turn in Returning the Favor
.turnin 9932 >> Turn in Body of Evidence
.accept 9933 >> Accept Message to Telaar
.target Lantresor of the Blade
step
#completewith next
.hs >> Hearth to Telaar
.cooldown item,6948,>2
step << !tbc !wotlk
.goto 1951/530,7270.600,-2569.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Moi'bff Jill|r
.target Warden Moi'bff Jill
.turnin 9938 >>Turn in Wanted: Durn the Hungerer
step
.goto Nagrand,55.48,68.70
>>Return to Telaar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arechron|r
.turnin 9933 >> Turn in Message to Telaar
.target Arechron
step
#label Saved5
#completewith Safari5
>>Sometimes |cRXP_ENEMY_Gankly|r can appear at the Safari. This is a rare event
>>Kill |cRXP_ENEMY_Gankly|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kristen Dipswitch|r
.accept 9897 >> Accept I'm Saved!
.goto Nagrand,71.42,40.60,0
.unitscan Gankly Rottenfist
.target Kristen Dipswitch
step
#requires Saved5
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harold Lane|r
.turnin 9897 >> Turn in I'm Saved!
.goto Nagrand,71.38,40.62
.target Harold Lane
step
#label Safari5
.goto Nagrand,71.52,40.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet Nesingwary|r
.turnin 9852 >>Turn in The Ultimate Bloodsport
.isQuestComplete 9852
.target Hemet Nesingwary
step
#aldor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adyen the Lightwarden|r
.goto Shattrath City,30.72,34.63
.accept 10325 >> Accept Marks of Kil'jaeden
.turnin 10325 >> Turn in Marks of Kil'jaeden
.target Adyen the Lightwarden
.itemcount 29425,10
]])

RXPGuides.RegisterGuide([[#version 9
#cata
#mop
#wotlk
#group RXP MoP 60-80 (A)
<< Alliance
#name 65-67 Blade's Edge
#version 9
#next 67-69 Netherstorm << TBC
#next 67-67 Blade's Edge Turn-ins << !TBC
step << !tbc !wotlk
#xprate >1.59
#optional
.maxlevel 67,endOfTheGuide
step
#completewith next
.goto Shattrath City,64.05,41.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r
.fly Telredor >> Fly to Telredor
.zoneskip Nagrand
.zoneskip Zangarmarsh
.skill riding,300,1
.target Nutral
step
#questguide << !tbc
.goto Zangarmarsh,68.3,49.4
>>Return to Telredor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r
.turnin 9801 >>Turn in Gathering the Reagents
.isQuestComplete 9801
.target Anchorite Ahuurn
step
#optional
#completewith Moonwhisper
.goto Shattrath City,64.05,41.12,-1
.goto Zangarmarsh,67.83,51.46,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r or |cRXP_FRIENDLY_Munci|r
>>|cRXP_WARN_The arrow will point you to the closest Flight Master|r
.fly Orebor Harborage >> Fly to Orebor Harborage
.skill riding,300,1
.target Nutral
.target Munci
step
.goto Zangarmarsh,41.21,28.68
>>Travel to Orebor Harborage
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Timothy Daniels|r
.accept 9794 >> Accept No Time for Curiosity
.maxlevel 66,bemend	<< !tbc
.target Timothy Daniels
step
#label Moonwhisper
.goto Blade's Edge Mountains,32.20,91.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sentinel Moonwhisper|r outside the tunnel entrance
.accept 10927 >> Accept Killing the Crawlers
.maxlevel 66,bemend	<< !tbc
.target Sentinel Moonwhisper
step
.goto Blade's Edge Mountains,34.61,88.05,40,0
.goto Blade's Edge Mountains,35.00,85.60,40,0
.goto Blade's Edge Mountains,36.83,83.44,40,0
.goto Blade's Edge Mountains,37.20,81.01
>>Kill |cRXP_ENEMY_Cavern Crawlers|r
>>|cRXP_WARN_You can mount up inside the cave|r
.complete 10927,1 
.isOnQuest 10927
.mob Cavern Crawler
step
>>Travel to Sylvanaar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kialon Nightblade|r, |cRXP_FRIENDLY_Rina Moonspring|r, |cRXP_FRIENDLY_The Wanted Poster|r and |cRXP_FRIENDLY_Commander Skyshadow|r
.turnin 9794 >> Turn in No Time for Curiosity
.goto Blade's Edge Mountains,35.97,67.76,30,0
.goto Blade's Edge Mountains,36.61,67.34
.target +Kialon Nightblade
.accept 10455 >> Accept The Encroaching Wilderness
.goto Blade's Edge Mountains,36.21,67.13
.target +Rina Moonspring
.accept 10690 >> Accept The Den Mother
.goto Blade's Edge Mountains,36.61,67.29
.accept 10502 >> Accept The Bloodmaul Ogres
.turnin 10927 >> Turn in Killing the Crawlers
.goto Blade's Edge Mountains,36.28,66.24
.target +Commander Skyshadow
.maxlevel 66,bemend	<< !tbc
step
#completewith Lashh
.goto Blade's Edge Mountains,35.80,63.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shaunessy|r
.home >> Set your Hearthstone to Sylvanaar
.maxlevel 66,bemend	<< !tbc
.target Innkeeper Shaunessy
step
.goto Blade's Edge Mountains,37.82,61.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amerun Leafshade|r
.fp Sylvanaar >> Get the Sylvanaar flight path
.maxlevel 66,bemend	<< !tbc
.target Amerun Leafshade
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgrim Stouthammer|r, |cRXP_FRIENDLY_Bronwyn Stouthammer|r inside and |cRXP_FRIENDLY_Daranelle|r outside
.accept 10511 >> Accept Strange Brew
.goto Blade's Edge Mountains,37.40,64.66
.target +Borgrim Stouthammer
.accept 10510 >> Accept Into the Draenethyst Mine
.goto Blade's Edge Mountains,37.41,65.05
.target +Bronwyn Stouthammer
.accept 10555 >> Accept Malaise
.goto Blade's Edge Mountains,37.07,65.62
.target +Daranelle
.maxlevel 66,bemend	<< !tbc
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Grovestalker Lynxes|r
.complete 10455,1 
.isOnQuest 10455
.mob Grovestalker Lynx
step
#label Lashh
.goto Blade's Edge Mountains,35.75,73.61,40,0
.goto Blade's Edge Mountains,34.23,75.61,40,0
.goto Blade's Edge Mountains,34.92,78.78,40,0
.goto Blade's Edge Mountains,35.72,75.07,40,0
.goto Blade's Edge Mountains,34.31,77.40
>>Kill |cRXP_ENEMY_Lashh'an|r. Loot them for their |cRXP_LOOT_Feathers|r
.complete 10555,1 
.isOnQuest 10555
.mob Lashh'an Matriarch
.mob Lashh'an Talonite
.mob Lashh'an Windwalker
.mob Lashh'an Windwalker
step
.goto Blade's Edge Mountains,34.31,77.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Tome|r atop the tree platform
.turnin 10555 >> Turn in Malaise
.accept 10556 >> Accept Scratches
.maxlevel 66,bemend	<< !tbc
step << !tbc !wotlk
#xprate >1.59
#optional
.maxlevel 67,endOfTheGuide
step
.goto Blade's Edge Mountains,35.23,77.31
.cast 36904 >> |cRXP_WARN_Use the|r |T132926:0|t[Fistful of Feathers] |cRXP_WARN_at the summoning circle|r
.use 30530
.isOnQuest 10556
step
.goto Blade's Edge Mountains,35.23,77.31,0
.goto Blade's Edge Mountains,36.94,79.00,50,0
.goto Blade's Edge Mountains,38.17,79.10,50,0
.goto Blade's Edge Mountains,37.94,73.50,50,0
.goto Blade's Edge Mountains,39.44,71.43,50,0
.goto Blade's Edge Mountains,41.51,67.91,50,0
.goto Blade's Edge Mountains,39.59,67.21,50,0
.goto Blade's Edge Mountains,37.84,71.74,50,0
.goto Blade's Edge Mountains,35.44,71.09
>>|cRXP_WARN_After using the|r |T132926:0|t[Fistful of Feathers]|cRXP_WARN_, a |cRXP_FRIENDLY_Small Bird Companion|r will follow you around|r
>>|cRXP_WARN_Be aware that the |cRXP_FRIENDLY_Bird|r can't keep up with you if you run off on your mount|r
>>Kill |cRXP_ENEMY_Grovestalker Lynxes|r
.complete 10455,1 
.isOnQuest 10455
.use 30530
.mob Grovestalker Lynx
.target Kaliri Totem
step
>>Escort the |cRXP_FRIENDLY_Bird|r back to Sylvanaar
>>|cRXP_WARN_Be aware that the |cRXP_FRIENDLY_Bird|r can't keep up with you if you run off on your mount|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daranelle|r and |cRXP_FRIENDLY_Rina Moonspring|r
.turnin 10556 >> Turn in Scratches
.goto Blade's Edge Mountains,37.07,65.62
.target +Daranelle
.turnin 10455 >> Turn in The Encroaching Wilderness
.accept 10456 >> Accept Marauding Wolves
.goto Blade's Edge Mountains,36.21,67.13
.target +Rina Moonspring
.use 30530
.target Kaliri Totem
.maxlevel 66,bemend	<< !tbc
step
#optional
#completewith next
.goto Blade's Edge Mountains,41.81,65.64,50,0
.goto Blade's Edge Mountains,48.40,65.00,50 >> Cross the bridge to the Jagged Ridge
.skill riding,225,1
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Thunderlord Dire Wolves|r. Loot them for their |cRXP_LOOT_Tails|r
.complete 10456,1 
.isOnQuest 10456
.mob Thunderlord Dire Wolf
step
.goto Blade's Edge Mountains,51.62,74.97
>>Kill |cRXP_ENEMY_Rema|r
.complete 10690,1 
.isOnQuest 10690
.mob Rema
step
#loop
.line Blade's Edge Mountains,51.93,73.59,51.99,72.57,52.51,71.54,52.53,69.57,55.12,68.14,54.67,65.56,52.94,67.62,51.69,66.58,50.94,65.14,50.61,60.12,49.31,62.79,50.28,67.75,49.33,69.22,50.32,70.41,51.93,73.59
.goto Blade's Edge Mountains,51.93,73.59,50,0
.goto Blade's Edge Mountains,51.99,72.57,50,0
.goto Blade's Edge Mountains,52.51,71.54,50,0
.goto Blade's Edge Mountains,52.53,69.57,50,0
.goto Blade's Edge Mountains,55.12,68.14,50,0
.goto Blade's Edge Mountains,54.67,65.56,50,0
.goto Blade's Edge Mountains,52.94,67.62,50,0
.goto Blade's Edge Mountains,51.69,66.58,50,0
.goto Blade's Edge Mountains,50.94,65.14,50,0
.goto Blade's Edge Mountains,50.61,60.12,50,0
.goto Blade's Edge Mountains,49.31,62.79,50,0
.goto Blade's Edge Mountains,50.28,67.75,50,0
.goto Blade's Edge Mountains,49.33,69.22,50,0
.goto Blade's Edge Mountains,50.32,70.41,50,0
.goto Blade's Edge Mountains,51.93,73.59,50,0
>>Kill |cRXP_ENEMY_Thunderlord Dire Wolves|r. Loot them for their |cRXP_LOOT_Tails|r
.complete 10456,1 
.isOnQuest 10456
.mob Thunderlord Dire Wolf
step
#optional
#completewith next
.goto Blade's Edge Mountains,56.09,72.09,50,0
.goto Blade's Edge Mountains,56.81,70.12,50,0
.goto Blade's Edge Mountains,57.72,70.31,50 >> Go up the path toward Toshley's Station
.skill riding,225,1
step
.goto Blade's Edge Mountains,61.16,70.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rip Pedalslam|r
.fp Toshley's Station >> Get the Toshley's Station flight path
.target Rip Pedalslam
step
#completewith SylHS
.hs >> Hearth to Sylvanaar
.cooldown item,6948,>2
step
#optional
#completewith next
.goto Blade's Edge Mountains,61.16,70.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rip Pedalslam|r
.fly Sylvanaar >> Fly to Sylvanaar
.cooldown item,6948,<0
.target Rip Pedalslam
step
#label SylHS
>>Return to Sylvanaar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Skyshadow|r and |cRXP_FRIENDLY_Rina Moonspring|r
.turnin 10690 >> Turn in The Den Mother
.goto Blade's Edge Mountains,36.28,66.24
.target +Commander Skyshadow
.turnin 10456 >> Turn in Marauding Wolves
.accept 10457 >> Accept Protecting Our Own
.goto Blade's Edge Mountains,36.21,67.13
.target +Rina Moonspring
.maxlevel 66,bemend	<< !tbc
step
#loop
.line Blade's Edge Mountains,36.43,69.86,36.44,71.16,35.95,71.95,37.26,72.60,37.73,73.94,38.27,72.71,38.85,73.59,39.01.71.93,40.24,70.33,39.85,69.00,38.21,69.06,36.43,69.86
.goto Blade's Edge Mountains,36.43,69.86,30,0
.goto Blade's Edge Mountains,36.44,71.16,30,0
.goto Blade's Edge Mountains,35.95,71.95,30,0
.goto Blade's Edge Mountains,37.26,72.60,30,0
.goto Blade's Edge Mountains,37.73,73.94,30,0
.goto Blade's Edge Mountains,38.27,72.71,30,0
.goto Blade's Edge Mountains,38.85,73.59,30,0
.goto Blade's Edge Mountains,70.33,40.24,30,0
.goto Blade's Edge Mountains,69.00,39.85,30,0
.goto Blade's Edge Mountains,69.06,38.21,30,0
.goto Blade's Edge Mountains,69.86,36.43,30,0
>>Click the |cRXP_PICK_Grove Seedlings|r on the ground
.complete 10457,1 
.isOnQuest 10457
step
>>Return to Sylvanaar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rina Moonspring|r
.turnin 10457 >> Turn in Protecting Our Own
.accept 10506 >> Accept A Dire Situation
.goto Blade's Edge Mountains,36.21,67.13
.maxlevel 66,bemend	<< !tbc
.target Rina Moonspring
step
#optional
#completewith MineC
>>Kill |cRXP_ENEMY_Bloodmaul Ogres|r. Loot |cRXP_ENEMY_Bloodmaul Brewmasters|r for their |cRXP_LOOT_Bloodmaul Brutebane Brew|r
>>Open the |cRXP_PICK_Bloodmaul Brew Kegs|r. Loot them for the |cRXP_LOOT_Bloodmaul Brutebane Brew|r
.use 30251 >> |cRXP_WARN_Use|r |T133852:0|t[Rina's Diminution Powder] |cRXP_WARN_on|r |cRXP_ENEMY_Bloodmaul Wolves|r
.complete 10502,1 
.complete 10511,1 
.complete 10506,1 
.mob +Bloodmaul Dire Wolf
.isOnQuest 10502
.isOnQuest 10506
.isOnQuest 10511
.mob Bloodmaul Skirmisher
.mob Bloodmaul Geomancer
.mob Bloodmaul Lookout
.mob Bloodmaul Brewmaster
.mob Bloodmaul Shaman
.mob Bloodmaul Brute
.mob Bloodmaul Drudger
step
#completewith next
.goto Blade's Edge Mountains,42.48,83.51,40 >>Enter the mine
step
#label MineC
.goto Blade's Edge Mountains,42.38,84.54,30,0
.goto Blade's Edge Mountains,41.15,85.56,30,0
.goto Blade's Edge Mountains,40.59,83.58,30,0
.goto Blade's Edge Mountains,39.73,83.35,30,0
.goto Blade's Edge Mountains,39.45,85.72,30,0
.goto Blade's Edge Mountains,40.09,85.42
>>Kill |cRXP_ENEMY_Bloodmaul Drudgers|r. Loot them for their |cRXP_LOOT_Draenethyst Crystals|r
>>|cRXP_WARN_The|r |cRXP_LOOT_Draenethyst Crystals|r |cRXP_WARN_can also be looted inside the mine|r
.complete 10510,1 
.isOnQuest 10510
.mob Bloodmaul Drudger
step
#loop
.line Blade's Edge Mountains,46.38,76.02,47.76,74.83,46.81,79.64,45.90,77.84,44.37,82.35,43.36,81.29,41.88,83.17,42.07,79.05,43.73,77.33,42.78,73.28,46.38,76.02
.goto Blade's Edge Mountains,46.38,76.02,55,0
.goto Blade's Edge Mountains,47.76,74.83,55,0
.goto Blade's Edge Mountains,46.81,79.64,55,0
.goto Blade's Edge Mountains,45.90,77.84,55,0
.goto Blade's Edge Mountains,44.37,82.35,55,0
.goto Blade's Edge Mountains,43.36,81.29,55,0
.goto Blade's Edge Mountains,41.88,83.17,55,0
.goto Blade's Edge Mountains,42.07,79.05,55,0
.goto Blade's Edge Mountains,43.73,77.33,55,0
.goto Blade's Edge Mountains,42.78,73.28,55,0
.goto Blade's Edge Mountains,46.38,76.02,55,0
>>Kill |cRXP_ENEMY_Bloodmaul Ogres|r. Loot |cRXP_ENEMY_Bloodmaul Brewmasters|r for their |cRXP_LOOT_Bloodmaul Brutebane Brew|r
>>Open the |cRXP_PICK_Bloodmaul Brew Kegs|r. Loot them for the |cRXP_LOOT_Bloodmaul Brutebane Brew|r
.use 30251 >> |cRXP_WARN_Use|r |T133852:0|t[Rina's Diminution Powder] |cRXP_WARN_on|r |cRXP_ENEMY_Bloodmaul Wolves|r
.complete 10502,1 
.complete 10511,1 
.complete 10506,1 
.mob +Bloodmaul Dire Wolf
.isOnQuest 10502
.isOnQuest 10506
.isOnQuest 10511
.mob Bloodmaul Skirmisher
.mob Bloodmaul Geomancer
.mob Bloodmaul Lookout
.mob Bloodmaul Brewmaster
.mob Bloodmaul Shaman
.mob Bloodmaul Brute
.mob Bloodmaul Drudger
step
#completewith next
.hs >> Hearth to Sylvanaar
.cooldown item,6948,>2
step
>>Return to Sylvanaar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rina Moonspring|r, |cRXP_FRIENDLY_Commander Skyshadow|r, |cRXP_FRIENDLY_Bronwyn Stouthammer|r and |cRXP_FRIENDLY_Borgrim Stouthammer|r
.turnin 10506 >> Turn in A Dire Situation
.goto Blade's Edge Mountains,36.21,67.13
.target +Rina Moonspring
.turnin 10502 >> Turn in The Bloodmaul Ogres
.accept 10504 >> Accept The Bladespire Ogres
.goto Blade's Edge Mountains,36.28,66.24
.target +Commander Skyshadow
.turnin 10510 >> Turn in Into the Draenethyst Mine
.goto Blade's Edge Mountains,37.41,65.05
.target +Bronwyn Stouthammer
.turnin 10511 >> Turn in Strange Brew
.accept 10512 >> Accept Getting the Bladespire Tanked
.goto Blade's Edge Mountains,37.40,64.66
.target +Borgrim Stouthammer
.maxlevel 66,bemend	<< !tbc
step << !tbc !wotlk
#xprate >1.59
#optional
.maxlevel 67,endOfTheGuide
step
#optional
#completewith BladeDrunk
>>Kill |cRXP_ENEMY_Bladespire Ogres|r
.complete 10504,1 
.isOnQuest 10504
.mob Bladespire Shaman
.mob Bladespire Cook
.mob Bladespire Champion
.mob Bladespire Sober Defender
.mob Bladespire Brute
step
#optional
.goto Blade's Edge Mountains,44.01,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Vuuleen|r
>>|cRXP_WARN_You can carefully jump down the northern side of Sylvanaar to get to her|r
.accept 10516 >> Accept The Trappings of a Vindicator
.skill riding,225,1
.maxlevel 66,bemend	<< !tbc
.target Vindicator Vuuleen
step
.goto Blade's Edge Mountains,44.01,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Vuuleen|r
.accept 10516 >> Accept The Trappings of a Vindicator
.skill riding,<225,1
.maxlevel 66,bemend	<< !tbc
.target Vindicator Vuuleen
step
.goto Blade's Edge Mountains,38.77,52.61
>>|cRXP_WARN_Kill the two |cRXP_ENEMY_Ogres|r nearest to the door|r
>>|cRXP_WARN_Use the|r |T132621:0|t[Brutebane Keg] |cRXP_WARN_to lure |cRXP_ENEMY_Droggam|r away from the elite guards|r
>>Kill |cRXP_ENEMY_Droggam|r. Loot him for the |cRXP_LOOT_Blade|r
.complete 10516,1 
.use 30353
.isOnQuest 10516
.mob Bladespire Shaman
.mob Bladespire Brute
.unitscan Droggam
step
.goto Blade's Edge Mountains,42.46,58.96
>>|cRXP_WARN_Kill the three |cRXP_ENEMY_Ogres|r nearest to the door|r
>>|cRXP_WARN_Use the|r |T132621:0|t[Brutebane Keg] |cRXP_WARN_to lure |cRXP_ENEMY_Mugdorg|r away from the elite guards|r
>>Kill |cRXP_ENEMY_Mugdorg|r. Loot him for the |cRXP_LOOT_Shield|r
.complete 10516,2 
.use 30353
.isOnQuest 10516
.mob Bladespire Shaman
.mob Bladespire Brute
.unitscan Mugdorg
step
.goto Blade's Edge Mountains,44.01,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Vuuleen|r
.turnin 10516 >> Turn in The Trappings of a Vindicator
.accept 10517 >> Accept Gorr'Dim, Your Time Has Come...
.maxlevel 66,bemend	<< !tbc
.target Vindicator Vuuleen
step
.goto Blade's Edge Mountains,39.38,49.06
>>|cRXP_WARN_Kill the three |cRXP_ENEMY_Ogres|r nearest to the door|r
>>|cRXP_WARN_Use the|r |T132621:0|t[Brutebane Keg] |cRXP_WARN_to lure |cRXP_ENEMY_Gorr'Dim|r away from the elite guards|r
>>Kill |cRXP_ENEMY_Gorr'Dim|r. Loot him for the |cRXP_LOOT_Shield|r
.complete 10517,1 
.use 30353
.isOnQuest 10517
.mob Bladespire Shaman
.mob Bladespire Brute
.unitscan Gorr'Dim
step
.goto Blade's Edge Mountains,44.01,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Vuuleen|r
.turnin 10517 >> Turn in Gorr'Dim, Your Time Has Come...
.accept 10518 >> Accept Planting the Banner
.maxlevel 66,bemend	<< !tbc
.target Vindicator Vuuleen
step
.goto Blade's Edge Mountains,41.29,46.72
>>Kill the |cRXP_ENEMY_Bladespire Champion|r. Loot him for his |cRXP_LOOT_Banner|r
.complete 10518,1 
.isOnQuest 10518
.mob Bladespire Champion
step
#label BladeDrunk
#loop
.line Blade's Edge Mountains,43.48,46.85,41.40,46.63,39.81,49.22,38.90,52.64,38.44,56.05,38.99,57.99,40.23,58.34,42.32,58.35,42.57,54.37,42.11,52.30,47.50,52.35,49.61,50.17,42.91,48.97,43.48,46.85
.goto Blade's Edge Mountains,43.48,46.85,60,0
.goto Blade's Edge Mountains,41.40,46.63,60,0
.goto Blade's Edge Mountains,39.81,49.22,60,0
.goto Blade's Edge Mountains,38.90,52.64,60,0
.goto Blade's Edge Mountains,38.44,56.05,60,0
.goto Blade's Edge Mountains,38.99,57.99,60,0
.goto Blade's Edge Mountains,40.23,58.34,60,0
.goto Blade's Edge Mountains,42.32,58.35,60,0
.goto Blade's Edge Mountains,42.57,54.37,60,0
.goto Blade's Edge Mountains,42.11,52.30,60,0
.goto Blade's Edge Mountains,47.50,52.35,60,0
.goto Blade's Edge Mountains,49.61,50.17,60,0
.goto Blade's Edge Mountains,42.91,48.97,60,0
.goto Blade's Edge Mountains,43.48,46.85,60,0
>>|cRXP_WARN_Use the|r |T132621:0|t[Brutebane Keg] |cRXP_WARN_near |cRXP_ENEMY_Ogres|r to get them drunk|r
.complete 10512,1 
.use 30353
.isOnQuest 10512
.mob Bladespire Shaman
.mob Bladespire Cook
.mob Bladespire Champion
.mob Bladespire Sober Defender
.mob Bladespire Brute
step
#loop
.line Blade's Edge Mountains,43.48,46.85,41.40,46.63,39.81,49.22,38.90,52.64,38.44,56.05,38.99,57.99,40.23,58.34,42.32,58.35,42.57,54.37,42.11,52.30,47.50,52.35,49.61,50.17,42.91,48.97,43.48,46.85
.goto Blade's Edge Mountains,43.48,46.85,60,0
.goto Blade's Edge Mountains,41.40,46.63,60,0
.goto Blade's Edge Mountains,39.81,49.22,60,0
.goto Blade's Edge Mountains,38.90,52.64,60,0
.goto Blade's Edge Mountains,38.44,56.05,60,0
.goto Blade's Edge Mountains,38.99,57.99,60,0
.goto Blade's Edge Mountains,40.23,58.34,60,0
.goto Blade's Edge Mountains,42.32,58.35,60,0
.goto Blade's Edge Mountains,42.57,54.37,60,0
.goto Blade's Edge Mountains,42.11,52.30,60,0
.goto Blade's Edge Mountains,47.50,52.35,60,0
.goto Blade's Edge Mountains,49.61,50.17,60,0
.goto Blade's Edge Mountains,42.91,48.97,60,0
.goto Blade's Edge Mountains,43.48,46.85,60,0
>>Kill |cRXP_ENEMY_Bladespire Ogres|r
.complete 10504,1 
.isOnQuest 10504
.mob Bladespire Shaman
.mob Bladespire Cook
.mob Bladespire Champion
.mob Bladespire Sober Defender
.mob Bladespire Brute
step
.goto Blade's Edge Mountains,46.66,74.82
>>|cRXP_WARN_Use the|r |T132484:0|t[Bladespire Banner] |cRXP_WARN_atop the tower to start the event. You will have to deal with 3 waves of 3 mobs|r
>>|cRXP_WARN_Use the|r |T132621:0|t[Brutebane Keg] |cRXP_WARN_at the end of the ramp to pick them apart and only deal with 1 or 2 |cRXP_ENEMY_Ogres|r at a time|r
>>|cRXP_WARN_Be aware that |cRXP_ENEMY_Gurn|r enrages after a few seconds, increasing attack speed by 300% for 6 seconds, but stunning him at the end for 3 seconds. You can jump off the tower and heal if you need to|r
.complete 10518,2 
.use 30416 
.use 30353
.isOnQuest 10518
.mob Gurn Grubnosh
step
#completewith next
.hs >> Hearth to Sylvanaar
.cooldown item,6948,>2
step
>>Return to Sylvanaar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Skyshadow|r and |cRXP_FRIENDLY_Borgrim Stouthammer|r
.turnin 10504 >> Turn in The Bladespire Ogres
.turnin 10518 >> Turn in Planting the Banner
.accept 10580 >> Accept Where Did Those Darn Gnomes Go?
.goto Blade's Edge Mountains,36.28,66.24
.target +Commander Skyshadow
.turnin 10512 >> Turn in Getting the Bladespire Tanked
.goto Blade's Edge Mountains,37.40,64.66
.target +Borgrim Stouthammer
.maxlevel 66,bemend	<< !tbc
step << !tbc !wotlk
#xprate >1.59
#optional
.maxlevel 67,endOfTheGuide
step
#completewith Tally
.goto Blade's Edge Mountains,37.82,61.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amerun Leafshade|r
.fly Toshley's Station >> Fly to Toshley's Station
.skill riding,300,1
.target Amerun Leafshade
step
#completewith TestTally
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.accept 10632 >> Accept Cutting Your Teeth
.maxlevel 66,bemend << !tbc
.target Razak Ironsides
step
#label Tally
>>Travel to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nickwinkle the Metro-Gnome|r and |cRXP_FRIENDLY_Tally Zapnabber|r
.accept 10608 >> Accept Crystal Clear
.goto Blade's Edge Mountains,60.22,68.94
.target +Nickwinkle the Metro-Gnome
.accept 10557 >> Accept Test Flight: The Zephyrium Capacitorium
.goto Blade's Edge Mountains,60.28,68.39
.target +Tally Zapnabber
.maxlevel 66,bemend << !tbc
step
.goto Blade's Edge Mountains,60.175,68.794
.gossipoption 92114 >> Talk to |cRXP_FRIENDLY_Rally Zapnabber|r
.timer 48,Test Flight RP
.skipgossip
.isOnQuest 10557
.target Rally Zapnabber
step
#label TestTally
>>Wait out the RP
.complete 10557,1 
.isOnQuest 10557
step
.goto Blade's Edge Mountains,55.11,72.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_R-3D0|r
.turnin 10580 >> Turn in Where Did Those Darn Gnomes Go?
.accept 10581 >> Accept Follow the Breadcrumbs
.maxlevel 66,bemend << !tbc
.target R-3D0
step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.accept 10632 >> Accept Cutting Your Teeth
.maxlevel 66,bemend << !tbc
.target Razak Ironsides
step
>>Return to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toshley|r, |cRXP_FRIENDLY_Tally Zapnabber|r and |cRXP_FRIENDLY_Fizit "Doc" Clocktock|r
.turnin 10581 >> Turn in Follow the Breadcrumbs
.accept 10584 >> Accept Picking Up Some Power Converters
.goto Blade's Edge Mountains,60.53,68.97
.target +Toshley
.turnin 10557 >> Turn in Test Flight: The Zephyrium Capacitorium
.accept 10710 >> Accept Test Flight: The Singing Ridge
.goto Blade's Edge Mountains,60.28,68.39
.target +Tally Zapnabber
.accept 10609 >> Accept What Came First, the Drake or the Egg?
.goto Blade's Edge Mountains,60.98,68.11
.target +Fizit "Doc" Clocktock
.maxlevel 66,bemend << !tbc
step
#completewith ToshStation
.goto Blade's Edge Mountains,60.98,68.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizit "Doc" Clocktock|r
.home >> Set your Hearthstone to Toshley's Station
.target Fizit "Doc" Clocktock
step
.use 30540 >>|cRXP_WARN_Use|r |T134939:0|t[Tally's Waiver]
.collect 30539,1,10710,1 
.isOnQuest 10710
step
#requires ToshleyHS
#loop
.line Blade's Edge Mountains,57.94,60.39,58.24,59.08,58.54,57.48,57.74,57.20,57.51,55.84,58.14,55.17,56.95,55.01,56.45,59.74,57.94,60.39
.goto Blade's Edge Mountains,57.94,60.39,30,0
.goto Blade's Edge Mountains,58.24,59.08,30,0
.goto Blade's Edge Mountains,58.54,57.48,30,0
.goto Blade's Edge Mountains,57.74,57.20,30,0
.goto Blade's Edge Mountains,57.51,55.84,30,0
.goto Blade's Edge Mountains,58.14,55.17,30,0
.goto Blade's Edge Mountains,56.95,55.01,30,0
.goto Blade's Edge Mountains,56.45,59.74,30,0
.goto Blade's Edge Mountains,57.94,60.39,30,0
.use 30656 >>|cRXP_WARN_Click the|r |cRXP_WARN_Power Converters|r |cRXP_WARN_to spawn|r |cRXP_ENEMY_Electromentals|r
>>|cRXP_WARN_Use the|r |T132488:0|t[Protovoltaic Magneto Collector] |cRXP_WARN_on the |cRXP_ENEMY_Electromentals|r to make it an|r |cRXP_ENEMY_Encased Electromental|r
>>Kill the |cRXP_ENEMY_Encased Electromentals|r
.complete 10584,1 
.isOnQuest 10584
.mob Electromental
.mob Encased Electromental
step
#optional
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.accept 10632 >> Accept Cutting Your Teeth
.maxlevel 66,bemend << !tbc
.target Razak Ironsides
step
#label ToshStation
>>Return to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toshley|r and |cRXP_FRIENDLY_Dizzy Dina|r
.turnin 10584 >> Turn in Picking Up Some Power Converters
.goto Blade's Edge Mountains,60.53,68.97
.target +Toshley
.accept 10620 >> Accept Ridgespine Menace
.goto Blade's Edge Mountains,60.40,68.75
.target +Dizzy Dina
.maxlevel 66,bemend << !tbc
step
#loop
.goto Blade's Edge Mountains,59.99,69.32,30,0
.goto Blade's Edge Mountains,60.28,68.98,30,0
.goto Blade's Edge Mountains,60.11,68.37,30,0
.goto Blade's Edge Mountains,59.81,68.29,30,0
.goto Blade's Edge Mountains,60.03,67.79,30,0
.goto Blade's Edge Mountains,60.31,68.23,30,0
.goto Blade's Edge Mountains,60.42,67.91,30,0
.goto Blade's Edge Mountains,60.54,68.76,30,0
.goto Blade's Edge Mountains,60.44,69.37,30,0
.line Blade's Edge Mountains,59.99,69.32,60.28,68.98,60.11,68.37,59.81,68.29,60.03,67.79,60.31,68.23,60.42,67.91,60.54,68.76,60.44,69.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.accept 10632 >> Accept Cutting Your Teeth
.unitscan Razak Ironsides
.maxlevel 66,bemend << !tbc
step
#completewith next
.goto Blade's Edge Mountains,60.175,68.794
.gossip 21461,1 >> Talk to |cRXP_FRIENDLY_Rally Zapnabber|r
.timer 30,Test Flight RP
.isOnQuest 10710
step
>>Wait out the RP
.goto Blade's Edge Mountains,60.175,68.794
.complete 10710,1 
.skipgossip 21461,1
.isOnQuest 10710
.target Rally Zapnabber
step
.goto Blade's Edge Mountains,67.71,72.74,50,0
.goto Blade's Edge Mountains,68.61,70.81,50,0
.goto Blade's Edge Mountains,69.40,66.26,50,0
.goto Blade's Edge Mountains,68.47,64.72,50,0
.goto Blade's Edge Mountains,66.98,63.63,50,0
.goto Blade's Edge Mountains,67.05,58.87,50,0
.goto Blade's Edge Mountains,67.90,49.98,50,0
.goto Blade's Edge Mountains,64.44,51.45,50,0
.goto Blade's Edge Mountains,62.32,52.92,50,0
.goto Blade's Edge Mountains,65.52,55.81
>>Kill |cRXP_ENEMY_Ridgespine Stalkers|r. |cRXP_WARN_They are stealthed so listen for the stealth sound|r
>>Kill |cRXP_ENEMY_Daggermaws|r. Loot them for their |cRXP_LOOT_Teeth|r
.complete 10632,1 
.mob +Daggermaw Lashtail
.complete 10620,1 
.mob +Ridgespine Stalker
.isOnQuest 10620
.isOnQuest 10632
step
#completewith next
.hs >> Hearth to Toshley's Station
.cooldown item,6948,>2
step
#optional
#completewith next
>>Click the |cRXP_PICK_Nether Drake Eggs|r to spawn a |cRXP_ENEMY_Nether Whelp|r
>>|cRXP_WARN_Use the|r |T133869:0|t[Temporal Phase Modulator] |cRXP_WARN_on the |cRXP_ENEMY_Nether Whelps|r that spawn to convert it into a|r |cRXP_ENEMY_Nether Drake|r
>>|cRXP_WARN_You can use the|r |T133869:0|t[Temporal Phase Modulator] |cRXP_WARN_multiple times on the same |cRXP_ENEMY_Nether Drake|r to change it to a different type|r
.complete 10609,1 
.mob +Proto-Nether Drake
.complete 10609,2 
.mob +Adolescent Nether Drake
.complete 10609,3 
.mob +Mature Nether Drake
.use 30742
.isOnQuest 10609
step
#loop
.line Blade's Edge Mountains,67.28,75.42,68.41,76.83,67.75,76.85,66.11,77.96,65.14,78.62,64.55,77.86,62.33,79.30,61.64,79.15,59.69,79.16,59.65,78.19,60.16,75.98,61.24,75.24,62.18,76.39,62.56,76.54,63.56,77.26,64.49,75.34,65.35,76.09,65.54,75.34,66.42,74.79,67.28,75.42
.goto Blade's Edge Mountains,67.28,75.42,40,0
.goto Blade's Edge Mountains,68.41,76.83,40,0
.goto Blade's Edge Mountains,67.75,76.85,40,0
.goto Blade's Edge Mountains,66.11,77.96,40,0
.goto Blade's Edge Mountains,65.14,78.62,40,0
.goto Blade's Edge Mountains,64.55,77.86,40,0
.goto Blade's Edge Mountains,62.33,79.30,40,0
.goto Blade's Edge Mountains,61.64,79.15,40,0
.goto Blade's Edge Mountains,59.69,79.16,40,0
.goto Blade's Edge Mountains,59.65,78.19,40,0
.goto Blade's Edge Mountains,60.16,75.98,40,0
.goto Blade's Edge Mountains,61.24,75.24,40,0
.goto Blade's Edge Mountains,62.18,76.39,40,0
.goto Blade's Edge Mountains,62.56,76.54,40,0
.goto Blade's Edge Mountains,63.56,77.26,40,0
.goto Blade's Edge Mountains,64.49,75.34,40,0
.goto Blade's Edge Mountains,65.35,76.09,40,0
.goto Blade's Edge Mountains,65.54,75.34,40,0
.goto Blade's Edge Mountains,66.42,74.79,40,0
.goto Blade's Edge Mountains,67.28,75.42,40,0
>>Kill |cRXP_ENEMY_Crystal Flayers|r
.complete 10608,1 
.isOnQuest 10608
.mob Crystal Flayer
step
#loop
.line Blade's Edge Mountains,67.28,75.42,68.41,76.83,67.75,76.85,66.11,77.96,65.14,78.62,64.55,77.86,62.33,79.30,61.64,79.15,59.69,79.16,59.65,78.19,60.16,75.98,61.24,75.24,62.18,76.39,62.56,76.54,63.56,77.26,64.49,75.34,65.35,76.09,65.54,75.34,66.42,74.79,67.28,75.42
.goto Blade's Edge Mountains,67.28,75.42,40,0
.goto Blade's Edge Mountains,68.41,76.83,40,0
.goto Blade's Edge Mountains,67.75,76.85,40,0
.goto Blade's Edge Mountains,66.11,77.96,40,0
.goto Blade's Edge Mountains,65.14,78.62,40,0
.goto Blade's Edge Mountains,64.55,77.86,40,0
.goto Blade's Edge Mountains,62.33,79.30,40,0
.goto Blade's Edge Mountains,61.64,79.15,40,0
.goto Blade's Edge Mountains,59.69,79.16,40,0
.goto Blade's Edge Mountains,59.65,78.19,40,0
.goto Blade's Edge Mountains,60.16,75.98,40,0
.goto Blade's Edge Mountains,61.24,75.24,40,0
.goto Blade's Edge Mountains,62.18,76.39,40,0
.goto Blade's Edge Mountains,62.56,76.54,40,0
.goto Blade's Edge Mountains,63.56,77.26,40,0
.goto Blade's Edge Mountains,64.49,75.34,40,0
.goto Blade's Edge Mountains,65.35,76.09,40,0
.goto Blade's Edge Mountains,65.54,75.34,40,0
.goto Blade's Edge Mountains,66.42,74.79,40,0
.goto Blade's Edge Mountains,67.28,75.42,40,0
>>Click the |cRXP_PICK_Nether Drake Eggs|r to spawn a |cRXP_ENEMY_Nether Whelp|r
>>|cRXP_WARN_Use the|r |T133869:0|t[Temporal Phase Modulator] |cRXP_WARN_on the |cRXP_ENEMY_Nether Whelps|r that spawn to convert it into a|r |cRXP_ENEMY_Nether Drake|r
>>|cRXP_WARN_You can use the|r |T133869:0|t[Temporal Phase Modulator] |cRXP_WARN_multiple times on the same |cRXP_ENEMY_Nether Drake|r to change it to a different type|r
.use 30742
.isOnQuest 10609
.complete 10609,1 
.mob +Proto-Nether Drake
.complete 10609,2 
.mob +Adolescent Nether Drake
.complete 10609,3 
.mob +Mature Nether Drake
step
#completewith CrystalClear
.goto Blade's Edge Mountains,59.99,69.32,30,0
.goto Blade's Edge Mountains,60.28,68.98,30,0
.goto Blade's Edge Mountains,60.11,68.37,30,0
.goto Blade's Edge Mountains,59.81,68.29,30,0
.goto Blade's Edge Mountains,60.03,67.79,30,0
.goto Blade's Edge Mountains,60.31,68.23,30,0
.goto Blade's Edge Mountains,60.42,67.91,30,0
.goto Blade's Edge Mountains,60.54,68.76,30,0
.goto Blade's Edge Mountains,60.44,69.37
.line Blade's Edge Mountains,59.99,69.32,60.28,68.98,60.11,68.37,59.81,68.29,60.03,67.79,60.31,68.23,60.42,67.91,60.54,68.76,60.44,69.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.turnin 10632 >> Turn in Cutting Your Teeth
.unitscan Razak Ironsides
.maxlevel 66,bemend << !tbc
step
#questguide
>>Return to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nickwinkle the Metro-Gnome|r and |cRXP_FRIENDLY_Dizzy Dina|r
.turnin 10608 >> Turn in Crystal Clear
.accept 10594 >> Accept Gauging the Resonant Frequency
.goto Blade's Edge Mountains,60.22,68.94
.target +Nickwinkle the Metro-Gnome
.turnin 10620 >> Turn in Ridgespine Menace
.accept 10671 >> Accept More than a Pound of Flesh
.goto Blade's Edge Mountains,60.40,68.75
.target +Dizzy Dina
.maxlevel 66,bemend << !tbc
step << !tbc !wotlk
#xprate >1.59
#optional
.maxlevel 67,endOfTheGuide
step
#label CrystalClear
>>Return to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nickwinkle the Metro-Gnome|r and |cRXP_FRIENDLY_Dizzy Dina|r
.turnin 10608 >> Turn in Crystal Clear
.accept 10594 >> Accept Gauging the Resonant Frequency
.goto Blade's Edge Mountains,60.22,68.94
.target +Nickwinkle the Metro-Gnome
.turnin 10620 >> Turn in Ridgespine Menace
.goto Blade's Edge Mountains,60.40,68.75
.target +Dizzy Dina
.maxlevel 66,bemend << !tbc
step
.goto Blade's Edge Mountains,59.99,69.32,30,0
.goto Blade's Edge Mountains,60.28,68.98,30,0
.goto Blade's Edge Mountains,60.11,68.37,30,0
.goto Blade's Edge Mountains,59.81,68.29,30,0
.goto Blade's Edge Mountains,60.03,67.79,30,0
.goto Blade's Edge Mountains,60.31,68.23,30,0
.goto Blade's Edge Mountains,60.42,67.91,30,0
.goto Blade's Edge Mountains,60.54,68.76,30,0
.goto Blade's Edge Mountains,60.44,69.37
.line Blade's Edge Mountains,59.99,69.32,60.28,68.98,60.11,68.37,59.81,68.29,60.03,67.79,60.31,68.23,60.42,67.91,60.54,68.76,60.44,69.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.turnin 10632 >> Turn in Cutting Your Teeth
.unitscan Razak Ironsides
.maxlevel 66,bemend << !tbc
step
.goto Blade's Edge Mountains,60.21,74.83
>>|cRXP_WARN_Use the|r |T132995:0|t[Oscillating Frequency Scanners] |cRXP_WARN_to plant a rod in the ground. You need to position them in a pentagonal formation 40 yards from each other. After planting 5 rods, stand in the middle of it|r
.complete 10594,1 
.use 30701
.isOnQuest 10594
step
#questguide
>>Return to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r, |cRXP_FRIENDLY_Tally Zapnabber|r and |cRXP_FRIENDLY_Fizit "Doc" Clocktock|r
Talk to Nickwinkle, Tally, and Fizit
.turnin 10594 >> Turn in Gauging the Resonant Frequency
.goto Blade's Edge Mountains,60.22,68.94
.target +Nickwinkle the Metro-Gnome
.turnin 10710 >> Turn in Test Flight: The Singing Ridge
.accept 10711 >> Accept Test Flight: Razaan's Landing
.goto Blade's Edge Mountains,60.28,68.39
.target +Tally Zapnabber
.turnin 10609 >> Turn in What Came First, the Drake or the Egg?
.goto Blade's Edge Mountains,60.98,68.11
.target +Fizit "Doc" Clocktock
.maxlevel 66,bemend << !tbc
step
>>Return to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nickwinkle the Metro-Gnome|r, |cRXP_FRIENDLY_Tally Zapnabber|r and |cRXP_FRIENDLY_Fizit "Doc" Clocktock|r
.turnin 10594 >> Turn in Gauging the Resonant Frequency
.goto Blade's Edge Mountains,60.22,68.94
.target +Nickwinkle the Metro-Gnome
.turnin 10710 >> Turn in Test Flight: The Singing Ridge
.goto Blade's Edge Mountains,60.28,68.39
.target +Tally Zapnabber
.turnin 10609 >> Turn in What Came First, the Drake or the Egg?
.goto Blade's Edge Mountains,60.98,68.11
.target +Fizit "Doc" Clocktock
.maxlevel 66,bemend << !tbc
step
#questguide
.goto Blade's Edge Mountains,60.175,68.794
.gossipoption 92112 >> Talk to |cRXP_FRIENDLY_Rally Zapnabber|r
.timer 40,Test Flight RP
.skipgossip
.isOnQuest 10711
.target Rally Zapnabber
step
#questguide
.complete 10711,1 
.goto Blade's Edge Mountains,66.98,48.90,300 >> Wait out the RP
.isOnQuest 10711
step
#questguide
.goto Blade's Edge Mountains,67.2,43.6
>>Kill |cRXP_ENEMY_Fiendling Flesh Beasts|r. Loot them for their |cRXP_LOOT_Flesh|r
.complete 10671,1 
.isOnQuest 10671
.target Fiendling Flesh Beast
step
>>Travel to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Timeon|r and |cRXP_FRIENDLY_Tree Warden Chawn|r
.accept 10567 >>Accept Creating the Pendant
.goto Blade's Edge Mountains,62.16,39.11
.target +Timeon
.accept 10682 >>Accept A Time for Negotiation...
.goto Blade's Edge Mountains,61.97,39.47
.target +Tree Warden Chawn
.maxlevel 66,bemend << !tbc
step
.goto Blade's Edge Mountains,61.68,39.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fhyn Leafshadow|r
.fp Evergrove >> Get the Evergrove flight path
.target Fhyn Leafshadow
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mosswood the Ancient|r, |cRXP_FRIENDLY_Commander Haephus Stonewall|r, |cRXP_FRIENDLY_Lieutenant Fairweather|r and |cRXP_FRIENDLY_Faradrella|r
.accept 10770 >>Accept Little Embers
.accept 10771 >>Accept From the Ashes
.goto Blade's Edge Mountains,61.25,38.46
.target +Mosswood the Ancient
.accept 10795 >> Accept A Date with Dorgok
.goto Blade's Edge Mountains,61.98,37.98
.target +Commander Haephus Stonewall
.accept 10796 >> Accept Crush the Bloodmaul Camp!
.goto Blade's Edge Mountains,61.98,37.94
.target +Lieutenant Fairweather
.accept 10753 >>Accept Culling the Wild
.goto Blade's Edge Mountains,62.56,38.23
.target +Faradrella
.maxlevel 66,bemend << !tbc
step << !tbc !wotlk
#xprate >1.59
#optional
.maxlevel 67,endOfTheGuide
step
#completewith Damaged
.goto Blade's Edge Mountains,62.86,38.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Aelerya|r
.home >> Set your Hearthstone to Evergrove
.maxlevel 66,bemend << !tbc
.target Innkeeper Aelerya
step
#completewith next
.goto Blade's Edge Mountains,65.43,39.76,40,0
.goto Blade's Edge Mountains,66.89,38.38,40 >> Run up the mountain path
.skill riding,225,1
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Felsworn Scalewings|r and |cRXP_ENEMY_Daggermaws|r
.complete 10753,1 
.mob +Felsworn Scalewing
.complete 10753,2 
.mob +Felsworn Daggermaw
.isOnQuest 10753
step
#label Damaged
.goto Blade's Edge Mountains,69.23,37.45,60,0
.goto Blade's Edge Mountains,68.66,33.30,60,0
.goto Blade's Edge Mountains,71.75,32.63,60,0
.goto Blade's Edge Mountains,70.98,27.92
.use 31384 >>Kill |cRXP_ENEMY_Fel Corrupters|r. Loot them for their |T133133:0|t[|cRXP_LOOT_Damaged Mask|r]
>>|cRXP_WARN_Use the|r |T133133:0|t[|cRXP_LOOT_Damaged Mask|r] |cRXP_WARN_to start the quest|r
.complete 10753,3 
.collect 31384,1,10810,1 
.accept 10810 >>Accept Damaged Mask
.unitscan Fel Corrupter
.isOnQuest 10753
step
#loop
.line Blade's Edge Mountains,68.77,34.63,68.31,30.34,70.65,30.50,70.91,26.73,73.67,26.67,73.39,30.11,71.84,34.87,68.77,34.63
.goto Blade's Edge Mountains,68.77,34.63,60,0
.goto Blade's Edge Mountains,68.31,30.34,60,0
.goto Blade's Edge Mountains,70.65,30.50,60,0
.goto Blade's Edge Mountains,70.91,26.73,60,0
.goto Blade's Edge Mountains,73.67,26.67,60,0
.goto Blade's Edge Mountains,73.39,30.11,60,0
.goto Blade's Edge Mountains,71.84,34.87,60,0
.goto Blade's Edge Mountains,68.77,34.63,60,0
>>Kill |cRXP_ENEMY_Felsworn Scalewings|r and |cRXP_ENEMY_Daggermaws|r
.complete 10753,1 
.mob +Felsworn Scalewing
.complete 10753,2 
.mob +Felsworn Daggermaw
.isOnQuest 10753
step
#completewith next
>>Kill |cRXP_ENEMY_Scorch Imps|r
.complete 10770,1 
.isOnQuest 10770
.mob Scorch Imp
step
.use 31300 >>|cRXP_WARN_Use the|r |T134059:0|t[Ironroot Seeds] |cRXP_WARN_on the patches of|r |cRXP_PICK_Volcanic Soil|r
.complete 10771,1 
.goto Blade's Edge Mountains,71.66,22.38
.complete 10771,2 
.goto Blade's Edge Mountains,71.61,20.31
.complete 10771,3 
.goto Blade's Edge Mountains,71.59,18.50
.isOnQuest 10771
step
#loop
.line Blade's Edge Mountains,70.65,18.63,70.63,20.56,70.65,22.68,71.06,23.80,71.92,24.64,72.31,22.97,71.71,21.21,73.06,20.10,73.44,18.06,70.65,18.63
.goto Blade's Edge Mountains,70.65,18.63,50,0
.goto Blade's Edge Mountains,70.63,20.56,50,0
.goto Blade's Edge Mountains,70.65,22.68,50,0
.goto Blade's Edge Mountains,71.06,23.80,50,0
.goto Blade's Edge Mountains,71.92,24.64,50,0
.goto Blade's Edge Mountains,72.31,22.97,50,0
.goto Blade's Edge Mountains,71.71,21.21,50,0
.goto Blade's Edge Mountains,73.06,20.10,50,0
.goto Blade's Edge Mountains,73.44,18.06,50,0
.goto Blade's Edge Mountains,70.65,18.63,50,0
>>Kill |cRXP_ENEMY_Scorch Imps|r
.complete 10770,1 
.isOnQuest 10770
.mob Scorch Imp
step
#completewith next
.hs >>Hearth to Evergrove
.cooldown item,6948,>2
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faradrella|r, |cRXP_FRIENDLY_Mosswood the Ancient|r and |cRXP_FRIENDLY_O'Mally Zapnabber|r
.turnin 10753 >>Turn in Culling the Wild
.goto Blade's Edge Mountains,62.56,38.23
.target +Faradrella
.turnin 10770 >>Turn in Little Embers
.turnin 10771 >>Turn in From the Ashes
.goto Blade's Edge Mountains,61.25,38.46
.target +Mosswood the Ancient
.turnin 10810 >>Turn in Damaged Mask
.accept 10812 >> Accept Mystery Mask
.goto Blade's Edge Mountains,62.66,40.38
.target +O'Mally Zapnabber
.maxlevel 66,bemend << !tbc
step
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.turnin 10812 >>Turn in Mystery Mask
.accept 10819 >> Accept Felsworn Gas Mask
.maxlevel 66,bemend << !tbc
.target Wildlord Antelarion
step
#completewith next
.equip 1,10819 >> |cRXP_WARN_Equip the|r |T133133:0|t[Felsworn Gas Mask] |cRXP_WARN_to be able to talk to the|r |cRXP_FRIENDLY_Legion Communicator|r
.use 10819
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Legion Communicator|r with your |T133133:0|t[Felsworn Gas Mask] equipped
.goto Blade's Edge Mountains,73.27,40.03
.turnin 10819 >>Turn in Felsworn Gas Mask
.accept 10820 >>Accept Deceive thy Enemy
.use 31366
.maxlevel 66,bemend << !tbc
step
#loop
.line Blade's Edge Mountains,74.28,38.54,75.39,39.66,74.93,40.17,75.30,41.73,74.22,42.56,73.77,41.02,74.28,38.54
.goto Blade's Edge Mountains,74.28,38.54,40,0
.goto Blade's Edge Mountains,75.39,39.66,40,0
.goto Blade's Edge Mountains,74.93,40.17,40,0
.goto Blade's Edge Mountains,75.30,41.73,40,0
.goto Blade's Edge Mountains,74.22,42.56,40,0
.goto Blade's Edge Mountains,73.77,41.02,40,0
.goto Blade's Edge Mountains,74.28,38.54,40,0
>>|cRXP_WARN_Re-equip your normal helmet|r
>>Kill |cRXP_ENEMY_Doomforge Attendants|r and |cRXP_ENEMY_Engineers|r
.complete 10820,1 
.mob +Doomforge Attendant
.complete 10820,2 
.mob +Doomforge Engineer
.isOnQuest 10820
step
#completewith next
.equip 1,10819 >> |cRXP_WARN_Equip the|r |T133133:0|t[Felsworn Gas Mask] |cRXP_WARN_to be able to talk to the|r |cRXP_FRIENDLY_Legion Communicator|r
.use 10819
step
.goto Blade's Edge Mountains,73.27,40.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Legion Communicator|r with your |T133133:0|t[Felsworn Gas Mask] equipped
.turnin 10820 >>Turn in Deceive thy Enemy
.accept 10821 >> Accept You're Fired!
.maxlevel 66,bemend << !tbc
step
#loop
.line Blade's Edge Mountains,73.63,39.14,72.82,40.35,72.90,40.76,72.92,41.50,72.90,41.96,73.36,42.46,73.39,43.64,74.38,41.90,74.01,38.52,73.63,39.14
.goto Blade's Edge Mountains,73.63,39.14,40,0
.goto Blade's Edge Mountains,72.82,40.35,40,0
.goto Blade's Edge Mountains,72.90,40.76,40,0
.goto Blade's Edge Mountains,72.92,41.50,40,0
.goto Blade's Edge Mountains,72.90,41.96,40,0
.goto Blade's Edge Mountains,73.36,42.46,40,0
.goto Blade's Edge Mountains,73.39,43.64,40,0
.goto Blade's Edge Mountains,74.38,41.90,40,0
.goto Blade's Edge Mountains,74.01,38.52,40,0
.goto Blade's Edge Mountains,73.63,39.14,40,0
>>Kill |cRXP_ENEMY_Anger Guards|r. Loot them for |cRXP_LOOT_Camp Anger Keys|r
>>|cRXP_WARN_Don't click any |cRXP_WARN_Obelisks|r yet|r
.collect 31536,5,10821,1 
.isOnQuest 10821
.mob Anger Guard
step
#completewith Doomcryer
#label FirstO
.goto Blade's Edge Mountains,73.53,43.51
.cast 38746 >>Click the |cRXP_PICK_First Obelisk|r
>>|cRXP_WARN_*If you cannot click it, skip this step|r
.isOnQuest 10821
step
#completewith Doomcryer
#requires FirstO
#label SecondO
.goto Blade's Edge Mountains,73.82,41.03
.cast 38746 >>Click the |cRXP_PICK_Second Obelisk|r
>>|cRXP_WARN_*If you cannot click it, skip this step|r
.isOnQuest 10821
step
#completewith Doomcryer
#requires SecondO
#label ThirdO
.goto Blade's Edge Mountains,73.94,39.89
.cast 38746 >>Click the |cRXP_PICK_Third Obelisk|r
>>|cRXP_WARN_*If you cannot click it, skip this step|r
.isOnQuest 10821
step
#completewith Doomcryer
#requires ThirdO
#label FourthO
.goto Blade's Edge Mountains,75.45,40.52
.cast 38746 >>Click the |cRXP_PICK_Fourth Obelisk|r
>>|cRXP_WARN_*If you cannot click it, skip this step|r
.isOnQuest 10821
step
#completewith Doomcryer
#requires FourthO
.goto Blade's Edge Mountains,75.33,41.74
.cast 38746 >>Click the |cRXP_PICK_Fifth Obelisk|r
>>|cRXP_WARN_*If you cannot click it, skip this step|r
.timer 30,Doomcryer Spawn
.isOnQuest 10821
step
#label Doomcryer
.goto Blade's Edge Mountains,74.32,42.52
>>Click the |cRXP_PICK_Five Obelisks|r around the camp to summon |cRXP_ENEMY_Doomcryer|r
>>Kill |cRXP_ENEMY_Doomcryer|r
>>|cRXP_ENEMY_Doomcryer|r |cRXP_WARN_can be affected by a number of crowd-controlling abilities such as Slows and Fear|r
>>|cRXP_WARN_This quest is difficult. Find a group for her if needed. Skip this step if you're unable to find a group or solo her|r
.complete 10821,1 
.isOnQuest 10821
.mob Doomcryer
step
#completewith Nuaar
.hs >>Hearth to Evergrove
.cooldown item,6948,>2
step
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.turnin 10821 >> Turn in You're Fired!
.isQuestComplete 10821
.maxlevel 66,bemend << !tbc
.target Wildlord Antelarion
step
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.accept 10910 >> Accept Death's Door
.isQuestTurnedIn 10821
.maxlevel 66,bemend << !tbc
.target Wildlord Antelarion
step
#label Nuaar
.line Blade's Edge Mountains,62.82,25.94,63.12,27.41,63.34,27.87,63.28,28.37,62.73,28.77,62.45,29.31,62.37,29.65,62.44,31.66,62.11,33.34,61.80,34.00,61.43,34.10,60.61,33.98,60.12,34.47,60.01,34.80,60.08,35.15,59.90,35.72,59.60,36.07,59.11,36.21,58.96,36.61,58.65,36.91,58.18,36.96,57.90,37.34,57.84,37.81,59.13,39.47,59.90,40.27,60.51,40.90,61.50,42.02,61.78,42.41,62.62,43.95,62.97,45.05,63.06,46.38
63.06,46.38
.goto Blade's Edge Mountains,63.06,46.38,60,0
.goto Blade's Edge Mountains,62.97,45.05,60,0
.goto Blade's Edge Mountains,62.62,43.95,60,0
.goto Blade's Edge Mountains,61.78,42.41,60,0
.goto Blade's Edge Mountains,61.50,42.02,60,0
.goto Blade's Edge Mountains,60.51,40.90,60,0
.goto Blade's Edge Mountains,59.90,40.27,60,0
.goto Blade's Edge Mountains,59.13,39.47,60,0
.goto Blade's Edge Mountains,57.84,37.81,60,0
.goto Blade's Edge Mountains,57.90,37.34,60,0
.goto Blade's Edge Mountains,58.18,36.96,60,0
.goto Blade's Edge Mountains,58.65,36.91,60,0
.goto Blade's Edge Mountains,58.96,36.61,60,0
.goto Blade's Edge Mountains,59.11,36.21,60,0
.goto Blade's Edge Mountains,59.60,36.07,60,0
.goto Blade's Edge Mountains,59.90,35.72,60,0
.goto Blade's Edge Mountains,60.08,35.15,60,0
.goto Blade's Edge Mountains,60.01,34.80,60,0
.goto Blade's Edge Mountains,60.12,34.47,60,0
.goto Blade's Edge Mountains,60.61,33.98,60,0
.goto Blade's Edge Mountains,61.80,34.00,60,0
.goto Blade's Edge Mountains,62.11,33.34,60,0
.goto Blade's Edge Mountains,62.44,31.66,60,0
.goto Blade's Edge Mountains,62.37,29.65,60,0
.goto Blade's Edge Mountains,62.45,29.31,60,0
.goto Blade's Edge Mountains,62.73,28.77,60,0
.goto Blade's Edge Mountains,63.28,28.37,60,0
.goto Blade's Edge Mountains,63.34,27.87,60,0
.goto Blade's Edge Mountains,63.12,27.41,60,0
.goto Blade's Edge Mountains,62.82,25.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overseer Nuaar|r
>>|cRXP_FRIENDLY_Overseer Nuaar|r |cRXP_WARN_patrols the Wyrmcult camps of Ruuan Weald|r
.complete 10682,1 
.unitscan Overseer Nuaar
.skipgossip
.isOnQuest 10682
step
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tree Warden Chawn|r and |cRXP_FRIENDLY_Samia Inkling|r
.turnin 10682 >>Turn in A Time for Negotiation...
.accept 10713 >>Accept ...and a Time for Action
.goto Blade's Edge Mountains,61.97,39.47
.target +Tree Warden Chawn
.accept 10717 >>Accept Poaching from Poachers
.goto Blade's Edge Mountains,61.94,39.45
.target +Samia Inkling
.maxlevel 66,bemend << !tbc
step
#completewith next
#loop
.line Blade's Edge Mountains,63.61,34.11,65.32,34.83,65.52,31.59,65.32,29.29,63.99,31.39,63.61,34.11
.goto Blade's Edge Mountains,63.61,34.11,50,0
.goto Blade's Edge Mountains,65.32,34.83,50,0
.goto Blade's Edge Mountains,65.52,31.59,50,0
.goto Blade's Edge Mountains,65.32,29.29,50,0
.goto Blade's Edge Mountains,63.99,31.39,50,0
.goto Blade's Edge Mountains,63.61,34.11,50,0
>>Kill the |cRXP_ENEMY_Ruuan'ok|r. Loot them for their |cRXP_LOOT_Claws|r
.collect 30704,6,10567,1 
.isOnQuest 10567
.mob Ruuan'ok Cloudgazer
.mob Ruuan'ok Skyfury
.mob Ruuan'ok Ravenguard
.mob Ruuan'ok Matriarch
step
.goto Blade's Edge Mountains,64.48,33.09
.use 30704 >>|cRXP_WARN_Use the|r |T134295:0|t[Ruuan'ok Claws] |cRXP_WARN_in the green circle to summon the|r |cRXP_ENEMY_Harbinger of the Raven|r
>>Kill the |cRXP_ENEMY_Harbinger of the Raven|r. Loot him for his |cRXP_LOOT_Pendant|r
.cast 37426
.timer 8,Creating the Pendant RP
.complete 10567,1 
.isOnQuest 10567
.mob Harbinger of the Raven
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Wyrmcult Hewers|r and |cRXP_ENEMY_Wyrmcult Poachers|r. Loot them for the |T134942:0|t[|cRXP_LOOT_Meeting Note|r]
.use 31120 >>|cRXP_WARN_Use the|r |T134942:0|t[|cRXP_LOOT_Meeting Note|r] |cRXP_WARN_to start the quest|r
.collect 31120,1,10719,1 
.accept 10719 >>Accept Did You Get The Note?
.isOnQuest 10713
step
#loop
.line Blade's Edge Mountains,59.62,38.72,57.43,39.14,57.71,37.76,59.10,36.09,59.93,35.16,60.82,33.54,62.10,32.35,61.78,27.86,62.89,25.82,63.56,27.91,62.10,32.35,61.55,34.48,60.09,36.97,59.62,38.72
.goto Blade's Edge Mountains,59.62,38.72,50,0
.goto Blade's Edge Mountains,57.43,39.14,50,0
.goto Blade's Edge Mountains,57.71,37.76,50,0
.goto Blade's Edge Mountains,59.10,36.09,50,0
.goto Blade's Edge Mountains,59.93,35.16,50,0
.goto Blade's Edge Mountains,60.82,33.54,50,0
.goto Blade's Edge Mountains,62.10,32.35,50,0
.goto Blade's Edge Mountains,61.78,27.86,50,0
.goto Blade's Edge Mountains,62.89,25.82,50,0
.goto Blade's Edge Mountains,63.56,27.91,50,0
.goto Blade's Edge Mountains,62.10,32.35,50,0
.goto Blade's Edge Mountains,61.55,34.48,50,0
.goto Blade's Edge Mountains,60.09,36.97,50,0
.goto Blade's Edge Mountains,59.62,38.72,50,0
>>Kill |cRXP_ENEMY_Wyrmcult Poachers|r and |cRXP_ENEMY_Wyrmcult Hewers|r. Loot the |cRXP_ENEMY_Poachers|r for their |cRXP_LOOT_Nets|r
.complete 10717,1 
.mob +Wyrmcult Poacher
.mob +Wyrmcult Hewer
.complete 10713,1 
.mob +Wyrmcult Hewer
.isOnQuest 10713
step
#loop
.line Blade's Edge Mountains,59.62,38.72,57.43,39.14,57.71,37.76,59.10,36.09,59.93,35.16,60.82,33.54,62.10,32.35,61.78,27.86,62.89,25.82,63.56,27.91,62.10,32.35,61.55,34.48,60.09,36.97,59.62,38.72
.goto Blade's Edge Mountains,59.62,38.72,50,0
.goto Blade's Edge Mountains,57.43,39.14,50,0
.goto Blade's Edge Mountains,57.71,37.76,50,0
.goto Blade's Edge Mountains,59.10,36.09,50,0
.goto Blade's Edge Mountains,59.93,35.16,50,0
.goto Blade's Edge Mountains,60.82,33.54,50,0
.goto Blade's Edge Mountains,62.10,32.35,50,0
.goto Blade's Edge Mountains,61.78,27.86,50,0
.goto Blade's Edge Mountains,62.89,25.82,50,0
.goto Blade's Edge Mountains,63.56,27.91,50,0
.goto Blade's Edge Mountains,62.10,32.35,50,0
.goto Blade's Edge Mountains,61.55,34.48,50,0
.goto Blade's Edge Mountains,60.09,36.97,50,0
.goto Blade's Edge Mountains,59.62,38.72,50,0
>>Kill |cRXP_ENEMY_Wyrmcult Hewers|r and |cRXP_ENEMY_Wyrmcult Poachers|r. Loot them for the |T134942:0|t[|cRXP_LOOT_Meeting Note|r]
.use 31120 >>|cRXP_WARN_Use the|r |T134942:0|t[|cRXP_LOOT_Meeting Note|r] |cRXP_WARN_to start the quest|r
.collect 31120,1,10719,1 
.accept 10719 >>Accept Did You Get The Note?
.isOnQuest 10713
.mob Wyrmcult Hewer
.mob Wyrmcult Poacher
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Bloodmaul Maulers|r and |cRXP_ENEMY_Bloodmaul Warlocks|r
.complete 10796,1 
.mob +Bloodmaul Mauler
.complete 10796,2 
.mob +Bloodmaul Warlock
.isOnQuest 10796
step
.goto Blade's Edge Mountains,54.80,24.71,30,0
.goto Blade's Edge Mountains,55.15,24.05
>>|cRXP_WARN_Head upstairs|r
.use 31363 >>Kill |cRXP_ENEMY_Dorgok|r. Loot him for the |T134451:0|t[|cRXP_LOOT_Favor of the Gronn|r]
>>|cRXP_WARN_Use the|r |T134451:0|t[|cRXP_LOOT_Favor of the Gronn|r] |cRXP_WARN_to start the quest|r
.complete 10795,1 
.collect 31363,1,10797,1 
.accept 10797 >> Accept Favor of the Gronn
.isOnQuest 10796
.mob Dorgok
step
#loop
.line Blade's Edge Mountains,57.05,27.86,55.30,27.11,55.18,24.26,56.40,22.11,57.70,24.45,56.91,25.87,57.93,29.95,54.68,33.92,57.05,27.86
.goto Blade's Edge Mountains,57.05,27.86,50,0
.goto Blade's Edge Mountains,55.30,27.11,50,0
.goto Blade's Edge Mountains,55.18,24.26,50,0
.goto Blade's Edge Mountains,56.40,22.11,50,0
.goto Blade's Edge Mountains,57.70,24.45,50,0
.goto Blade's Edge Mountains,56.91,25.87,50,0
.goto Blade's Edge Mountains,57.93,29.95,50,0
.goto Blade's Edge Mountains,54.68,33.92,50,0
.goto Blade's Edge Mountains,57.05,27.86,50,0
>>Kill |cRXP_ENEMY_Bloodmaul Maulers|r and |cRXP_ENEMY_Bloodmaul Warlocks|r
.complete 10796,1 
.mob +Bloodmaul Mauler
.complete 10796,2 
.mob +Bloodmaul Warlock
.isOnQuest 10796
step
#completewith Evergrove2
.goto Blade's Edge Mountains,59.12,32.12,40,0
.goto Blade's Edge Mountains,60.38,28.77,40,0
.goto Blade's Edge Mountains,61.54,29.73,40 >> Ride up the mountain path
.cooldown item,6948,<0
.skill riding,225,1
step
#optional
#completewith next
.hs >>Hearth to Evergrove
.cooldown item,6948,>2
step
#label Evergrove2
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Fairweather|r, |cRXP_FRIENDLY_Commander Haephus Stonewall|r, |cRXP_FRIENDLY_Timeon|r, |cRXP_FRIENDLY_Tree Warden Chawn|r and |cRXP_FRIENDLY_Samia Inkling|r
.turnin 10796 >> Turn in Crush the Bloodmaul Camp!
.goto Blade's Edge Mountains,61.98,37.94
.target +Lieutenant Fairweather
.turnin 10795 >> Turn in A Date with Dorgok
.turnin 10797 >> Turn in Favor of the Gronn
.accept 10798 >> Accept Pay the Baron a Visit
.goto Blade's Edge Mountains,61.98,37.98
.target +Commander Haephus Stonewall
.turnin 10567 >>Turn in Creating the Pendant
.accept 10607 >>Accept Whispers of the Raven God
.goto Blade's Edge Mountains,62.16,39.11
.target +Timeon
.turnin 10713 >>Turn in ...and a Time for Action
.turnin 10719 >>Turn in Did You Get The Note?
.accept 10894 >>Accept Wyrmskull Watcher
.goto Blade's Edge Mountains,61.97,39.47
.target +Tree Warden Chawn
.turnin 10717 >>Turn in Poaching from Poachers
.accept 10747 >>Accept Whelps of the Wyrmcult
.goto Blade's Edge Mountains,61.94,39.45
.target +Samia Inkling
.maxlevel 66,bemend << !tbc
step
.goto Blade's Edge Mountains,53.25,41.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron Sablemane|r
.turnin 10798 >> Turn in Pay the Baron a Visit
.accept 10799 >> Accept Into the Churning Gulch
.maxlevel 66,bemend << !tbc
.target Baron Sablemane
step
#loop
.line Blade's Edge Mountains,51.18,37.94,48.99,41.05,49.28,44.96,47.16,45.03,45.19,47.89,44.82,44.78,47.03,43.18,48.99,41.05
.goto Blade's Edge Mountains,51.18,37.94,50,0
.goto Blade's Edge Mountains,48.99,41.05,50,0
.goto Blade's Edge Mountains,49.28,44.96,50,0
.goto Blade's Edge Mountains,47.16,45.03,50,0
.goto Blade's Edge Mountains,45.19,47.89,50,0
.goto Blade's Edge Mountains,44.82,44.78,50,0
.goto Blade's Edge Mountains,47.03,43.18,50,0
.goto Blade's Edge Mountains,48.99,41.05,50,0
>>Kill |cRXP_ENEMY_Young Crust Bursters|r and |cRXP_ENEMY_Greater Crust Bursters|r. Loot them for their |cRXP_LOOT_Venom Glands|r
.complete 10799,1 
.isOnQuest 10799
.mob Greater Crust Burster
.mob Young Crust Burster
step
.goto Blade's Edge Mountains,53.25,41.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron Sablemane|r
.turnin 10799 >> Turn in Into the Churning Gulch
.accept 10800 >> Accept Goodnight, Gronn
.maxlevel 66,bemend << !tbc
.target Baron Sablemane
step
#completewith next
.cast 38510 >> |cRXP_WARN_Use|r |T132858:0|t[Sablemane's Sleeping Powder] |cRXP_WARN_on|r |cRXP_ENEMY_Grulloc|r
.use 31403
.isOnQuest 10800
.target Grulloc
step
.goto Blade's Edge Mountains,60.90,47.77
>>|cRXP_WARN_If the|r |T132858:0|t[Sleeping Powder] |cRXP_WARN_resists, use it on|r |cRXP_ENEMY_Grulloc|r |cRXP_WARN_again|r. Loot the |cRXP_LOOT_Sack|r next to |cRXP_ENEMY_Grulloc|r
.complete 10800,1 
.use 31403
.isOnQuest 10800
.target Grulloc
step
.goto Blade's Edge Mountains,53.25,41.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron Sablemane|r
.turnin 10800 >> Turn in Goodnight, Gronn
.accept 10801 >> Accept It's a Trap!
.maxlevel 66,bemend << !tbc
.target Baron Sablemane
step << !Shaman
#completewith Evergrove3
.goto Blade's Edge Mountains,58.64,46.20,40,0
.goto Blade's Edge Mountains,59.95,44.60,40,0
.goto Blade's Edge Mountains,58.50,43.70,40,0
.goto Blade's Edge Mountains,59.40,42.14,40 >> Ride up the mountain path
.cooldown item,6948,<0
.skill riding,225,1
step << Shaman
#completewith next
.hs >>Hearth to Evergrove
.cooldown item,6948,>2
step
#label Evergrove3
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Haephus Stonewall|r and |cRXP_FRIENDLY_Lieutenant Fairweather|r
.turnin 10801 >> Turn in It's a Trap!
.accept 10802 >> Accept Gorgrom the Dragon-Eater
.goto Blade's Edge Mountains,61.98,37.98
.target +Commander Haephus Stonewall
.accept 10803 >> Accept Slaughter at Boulder'mok
.goto Blade's Edge Mountains,61.98,37.94
.target +Lieutenant Fairweather
.maxlevel 66,bemend << !tbc
step
#completewith Evergrove3
.goto Blade's Edge Mountains,55.90,39.76,60,0
.goto Blade's Edge Mountains,59.40,42.14,40 >> Cross the bridge
.skill riding,225,1
step
.goto Blade's Edge Mountains,50.35,36.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Moonshade|r atop the bridge
.turnin 10894 >>Turn in Wyrmskull Watcher
.accept 10893 >>Accept Longtail is the Lynchpin
.maxlevel 66,bemend << !tbc
.target Watcher Moonshade
step
>>Kill |cRXP_ENEMY_Draaca Longtail|r inside of the tunnel
.goto Blade's Edge Mountains,46.03,32.93,40,0
.goto Blade's Edge Mountains,45.81,32.90,40,0
.goto Blade's Edge Mountains,44.78,32.07
.complete 10893,1 
.unitscan Draaca Longtail
.isOnQuest 10893
step
.goto Blade's Edge Mountains,49.92,35.92,20,0
.goto Blade's Edge Mountains,50.35,36.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Moonshade|r
.turnin 10893 >>Turn in Longtail is the Lynchpin
.accept 10722 >>Accept Meeting at the Blackwing Coven
.maxlevel 66,bemend << !tbc
.target Watcher Moonshade
step
#optional
#completewith Prophecy
>>Kill |cRXP_ENEMY_Grishna|r. Loot them for the |T136210:0|t[|cRXP_LOOT_Orb of the Grishna|r]
.use 31489 >>|cRXP_WARN_Use the|r |T136210:0|t[|cRXP_LOOT_Orb of the Grishna|r] |cRXP_WARN_to start the quest|r
.collect 31489,1,10825,1 
.accept 10825 >>Accept The Truth Unorbed
.isOnQuest 10607
.mob Grishna Falconwing
.mob Grishna Harbinger
.mob Grishna Matriarch
.mob Grishna Scorncrow
step
#optional
#completewith Prophecy
+Kill |cRXP_ENEMY_Grishna|r
>>|cRXP_WARN_Stand next to them when they die for a chance to gain the|r |T132188:0|t[Understanding Ravenspeech] |cRXP_WARN_buff which is needed to receive the|r |cRXP_PICK_Prophecies|r
.aura 37642
.aura 37466
.isOnQuest 10607
.mob Grishna Falconwing
.mob Grishna Harbinger
.mob Grishna Matriarch
.mob Grishna Scorncrow
step
>>|cRXP_WARN_Go to the |cRXP_PICK_Prophecies|r in Grishnath to receive them|r
.complete 10607,4 
.goto Blade's Edge Mountains,40.18,23.02
.complete 10607,3 
.goto Blade's Edge Mountains,40.67,18.63
.isOnQuest 10607
step
#completewith next
.goto Blade's Edge Mountains,40.61,17.46,20,0
.goto Blade's Edge Mountains,39.92,16.42,20,0
.goto Blade's Edge Mountains,39.02,17.25,20 >>|cRXP_WARN_Go up the tree platform on the west side. Cross the bridge, then click the|r |cRXP_PICK_Prophecy|r
.skill riding,225,1
step
>>|cRXP_WARN_Go to the |cRXP_PICK_Prophecy|r on the tree platform|r
.complete 10607,1 
.goto Blade's Edge Mountains,39.02,17.25
.isOnQuest 10607
step
#completewith next
.goto Blade's Edge Mountains,41.08,18.18,20,0
.goto Blade's Edge Mountains,42.35,19.18,20,0
.goto Blade's Edge Mountains,42.47,21.63,20 >>|cRXP_WARN_Go up the tree platform on the east side. Cross the bridge, go down a floor, then click the|r |cRXP_PICK_Prophecy|r
.skill riding,225,1
step
#label Prophecy
>>|cRXP_WARN_Go to the |cRXP_PICK_Prophecy|r on the bottom floor of the tree platform|r
.goto Blade's Edge Mountains,42.47,21.63
.complete 10607,2 
.isOnQuest 10607
step
#loop
.line Blade's Edge Mountains,42.30,24.63,41.37,20.69,39.96,22.83,38.41,20.01,39.33,17.50,40.80,17.74,42.15,18.55,42.73,21.32,42.30,24.63
.goto Blade's Edge Mountains,42.30,24.63,60,0
.goto Blade's Edge Mountains,41.37,20.69,60,0
.goto Blade's Edge Mountains,39.96,22.83,60,0
.goto Blade's Edge Mountains,38.41,20.01,60,0
.goto Blade's Edge Mountains,39.33,17.50,60,0
.goto Blade's Edge Mountains,40.80,17.74,60,0
.goto Blade's Edge Mountains,42.15,18.55,60,0
.goto Blade's Edge Mountains,42.73,21.32,60,0
.goto Blade's Edge Mountains,42.30,24.63,60,0
>>Kill |cRXP_ENEMY_Grishna|r. Loot them for the |T136210:0|t[|cRXP_LOOT_Orb of the Grishna|r]
.use 31489 >>|cRXP_WARN_Use the|r |T136210:0|t[|cRXP_LOOT_Orb of the Grishna|r] |cRXP_WARN_to start the quest|r
.collect 31489,1,10825,1 
.accept 10825 >>Accept The Truth Unorbed
.isOnQuest 10607
.mob Grishna Falconwing
.mob Grishna Harbinger
.mob Grishna Matriarch
.mob Grishna Scorncrow
step
#optional
#completewith Plant
>>Kill |cRXP_ENEMY_Boulder'mok Brutes|r and |cRXP_ENEMY_Boulder'mok Shaman|r
.complete 10803,1 
.mob +Boulder'mok Brute
.complete 10803,2 
.mob +Boulder'mok Shaman
.isOnQuest 10803
step
#loop
.line Blade's Edge Mountains,31.88,21.40,31.59,22.91,30.89,24.19,29.49,23.96,30.41,22.68,30.38,21.06,31.19,19.79,31.88,21.40
.goto Blade's Edge Mountains,31.88,21.40,60,0
.goto Blade's Edge Mountains,31.59,22.91,60,0
.goto Blade's Edge Mountains,30.89,24.19,60,0
.goto Blade's Edge Mountains,29.49,23.96,60,0
.goto Blade's Edge Mountains,30.41,22.68,60,0
.goto Blade's Edge Mountains,30.38,21.06,60,0
.goto Blade's Edge Mountains,31.19,19.79,60,0
.goto Blade's Edge Mountains,31.88,21.40,60,0
>>Kill |cRXP_ENEMY_Boulder'mok Ogres|r. Loot them for their |cRXP_LOOT_Totems|r
.collect 31754,3,10802,1 
.isOnQuest 10802
.mob Boulder'mok Chieftain
.mob Boulder'mok Brute
.mob Boulder'mok Shaman
step
#completewith next
.goto Blade's Edge Mountains,30.58,22.18
.cast 39264 >>|cRXP_WARN_Click |cRXP_PICK_Gorgrom's Altar|r to start the RP|r
.timer 12,Gorgrom RP
.isOnQuest 10802
step
#label Plant
.goto Blade's Edge Mountains,30.64,22.13
.use 31754 >>|cRXP_WARN_Wait for the short RP|r
>>|cRXP_WARN_When |cRXP_ENEMY_Gorgrom|r dies, use|r |T132352:0|t[Grisly Totems] |cRXP_WARN_on him 3 times|r
.complete 10802,1 
.isOnQuest 10802
.mob Gorgrom the Dragon-Eater
step
#loop
.line Blade's Edge Mountains,31.88,21.40,31.59,22.91,30.89,24.19,29.49,23.96,30.41,22.68,30.38,21.06,31.19,19.79,31.88,21.40
.goto Blade's Edge Mountains,31.88,21.40,60,0
.goto Blade's Edge Mountains,31.59,22.91,60,0
.goto Blade's Edge Mountains,30.89,24.19,60,0
.goto Blade's Edge Mountains,29.49,23.96,60,0
.goto Blade's Edge Mountains,30.41,22.68,60,0
.goto Blade's Edge Mountains,30.38,21.06,60,0
.goto Blade's Edge Mountains,31.19,19.79,60,0
.goto Blade's Edge Mountains,31.88,21.40,60,0
>>Kill |cRXP_ENEMY_Boulder'mok Brutes|r and |cRXP_ENEMY_Boulder'mok Shaman|r
.complete 10803,1 
.mob +Boulder'mok Brute
.complete 10803,2 
.mob +Boulder'mok Shaman
.isOnQuest 10803
step
#loop
.line Blade's Edge Mountains,30.77,31.59,31.05,33.60,33.35,32.28,33.10,30.99,30.77,31.59
.goto Blade's Edge Mountains,30.77,31.59,50,0
.goto Blade's Edge Mountains,31.05,33.60,50,0
.goto Blade's Edge Mountains,33.35,32.28,50,0
.goto Blade's Edge Mountains,33.10,30.99,50,0
.goto Blade's Edge Mountains,30.77,31.59,50,0
>>Kill |cRXP_ENEMY_Wyrmcult|r. Loot them for their |cRXP_LOOT_Costume Scraps|r
.collect 31121,3,10747,1 
.isOnQuest 10722
.mob Wyrmcult Acolyte
.mob Wyrmcult Blessed
.mob Wyrmcult Zealot
.mob Wyrmcult Scout
step
#completewith Scraps
.goto Blade's Edge Mountains,32.04,33.87,20 >> Enter the Blackwing Coven
step
#optional
#completewith Kolphis
>>|cRXP_WARN_Use the|r |T134325:0|t[Blackwhelp Net] |cRXP_WARN_on|r |cRXP_ENEMY_Wyrmcult Blackwhelps|r
>>|cRXP_WARN_You can step on the eggs in the cave to spawn more|r |cRXP_ENEMY_Wyrmcult Blackwhelps|r
.complete 10747,1 
.use 31129
.isOnQuest 10747
.mob Wyrmcult Blackwhelp
step
#label Scraps
.goto Blade's Edge Mountains,32.25,34.77,30,0
.goto Blade's Edge Mountains,33.90,34.36,30,0
.goto Blade's Edge Mountains,31.55,36.03,40,0
.goto Blade's Edge Mountains,31.85,37.27,30,0
.goto Blade's Edge Mountains,32.25,34.77,30,0
.goto Blade's Edge Mountains,33.90,34.36,30,0
.goto Blade's Edge Mountains,31.55,36.03,40,0
.goto Blade's Edge Mountains,31.85,37.27,30,0
>>Kill |cRXP_ENEMY_Wyrmcult|r. Loot them for their |cRXP_LOOT_Costume Scraps|r
>>|cRXP_WARN_You can get more outside if needed|r
.collect 31121,5,10747,1 
.isOnQuest 10722
.mob Wyrmcult Acolyte
.mob Wyrmcult Blessed
.mob Wyrmcult Zealot
.mob Wyrmcult Scout
step
.use 31121 >> |cRXP_WARN_Use the|r |T132911:0|t[Costume Scraps] |cRXP_WARN_to make the|r |T132760:0|t[Overseer Disguise]
.collect 31122,1,10747,1 
.isOnQuest 10722
step
.cast 38157 >>|cRXP_WARN_Use the|r |T132760:0|t[Overseer Disguise]
.use 31122
.isOnQuest 10722
step
#label Kolphis
.goto Blade's Edge Mountains,32.66,37.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kolphis Darkscale|r at the end of the cave while disguised
>>|cRXP_WARN_Be careful as the disguise only lasts 3 minutes|r
.complete 10722,1 
.use 31122
.skipgossip
.isOnQuest 10722
.target Kolphis Darkscale
step
.goto Blade's Edge Mountains,33.62,37.14,30,0
.goto Blade's Edge Mountains,33.64,35.63,30,0
.goto Blade's Edge Mountains,33.92,34.33,30,0
.goto Blade's Edge Mountains,31.41,36.29,30,0
.goto Blade's Edge Mountains,33.62,37.14,30,0
.goto Blade's Edge Mountains,33.64,35.63,30,0
.goto Blade's Edge Mountains,33.92,34.33,30,0
.goto Blade's Edge Mountains,31.41,36.29
>>|cRXP_WARN_Use the|r |T134325:0|t[Blackwhelp Net] |cRXP_WARN_on|r |cRXP_ENEMY_Wyrmcult Blackwhelps|r
>>|cRXP_WARN_You can step on the eggs in the cave while undisguised to spawn more|r |cRXP_ENEMY_Blackwhelps|r
.complete 10747,1 
.use 31129
.isOnQuest 10747
.mob Wyrmcult Blackwhelp
step
#completewith next
.hs >>Hearth to Evergrove
step
#questguide
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Fairweather|r, |cRXP_FRIENDLY_Commander Haephus Stonewall|r, |cRXP_FRIENDLY_Timeon|r, |cRXP_FRIENDLY_Tree Warden Chawn|r and |cRXP_FRIENDLY_Samia Inkling|r
.turnin 10803 >> Turn in Slaughter at Boulder'mok
.goto Blade's Edge Mountains,61.98,37.94
.target +Lieutenant Fairweather
.turnin 10802 >> Turn in Gorgrom the Dragon-Eater
.accept 10818 >> Accept Baron Sablemane Has Requested Your Presence
.goto Blade's Edge Mountains,61.98,37.98
.target +Commander Haephus Stonewall
.turnin 10607 >> Turn in Whispers of the Raven God
.goto Blade's Edge Mountains,62.16,39.11
.target +Timeon
.turnin 10722 >> Turn in Meeting at the Blackwing Coven
.turnin 10825 >> Turn in The Truth Unorbed
.accept 10748 >> Maxnar Must Die!
.accept 10829 >> Treebole Must Know
.goto Blade's Edge Mountains,61.97,39.47
.target +Tree Warden Chawn
.turnin 10747 >> Turn in Whelps of the Wyrmcult
.goto Blade's Edge Mountains,61.94,39.45
.target +Samia Inkling
.maxlevel 66,bemend << !tbc
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Fairweather|r, |cRXP_FRIENDLY_Commander Haephus Stonewall|r, |cRXP_FRIENDLY_Timeon|r, |cRXP_FRIENDLY_Tree Warden Chawn|r and |cRXP_FRIENDLY_Samia Inkling|r
.turnin 10803 >> Turn in Slaughter at Boulder'mok
.goto Blade's Edge Mountains,61.98,37.94
.target +Lieutenant Fairweather
.turnin 10802 >> Turn in Gorgrom the Dragon-Eater
.goto Blade's Edge Mountains,61.98,37.98
.target +Commander Haephus Stonewall
.turnin 10607 >> Turn in Whispers of the Raven God
.goto Blade's Edge Mountains,62.16,39.11
.target +Timeon
.turnin 10722 >> Turn in Meeting at the Blackwing Coven
.turnin 10825 >> Turn in The Truth Unorbed
.goto Blade's Edge Mountains,61.97,39.47
.target +Tree Warden Chawn
.turnin 10747 >> Turn in Whelps of the Wyrmcult
.goto Blade's Edge Mountains,61.94,39.45
.target +Samia Inkling
.maxlevel 66,bemend << !tbc
step
#completewith Signal
.goto Blade's Edge Mountains,61.68,39.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fhyn Leafshadow|r
.fly Toshley >> Fly to Toshley's Station
.skill riding,300,1
.isQuestTurnedIn 10821
.target Fhyn Leafshadow
step
#questguide
>>Travel to Toshley's Station
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tally Zapnabber|r and |cRXP_FRIENDLY_Dizzy Dina|r
.turnin 10711 >> Turn in Test Flight: Razaan's Landing
.goto Blade's Edge Mountains,60.28,68.39
.turnin 10671 >> Turn in More than a Pound of Flesh
.goto Blade's Edge Mountains,60.40,68.75
.maxlevel 66,bemend << !tbc
.target Tally Zapnabber
.target Dizzy Dina
step
#optional
#completewith Signal
.goto Blade's Edge Mountains,64.31,70.67
>>|cRXP_WARN_Carefully jump down east of Toshley's Station to Death's Door|r
.cast 38782 >>|cRXP_WARN_Use the|r |T135815:0|t[Druid Signal] |cRXP_WARN_to summon an |cRXP_FRIENDLY_Evergrove Druid|r at Death's Door|r
.timer 18,Druid Signal RP
.skill riding,225,1
.isOnQuest 10910
step
#completewith next
.goto Blade's Edge Mountains,64.31,70.67
.cast 38782 >>|cRXP_WARN_Use the|r |T135815:0|t[Druid Signal] |cRXP_WARN_to summon an |cRXP_FRIENDLY_Evergrove Druid|r at Death's Door|r
.timer 18,Druid Signal RP
.skill riding,<225,1
.isOnQuest 10910
step
#label Signal
.goto Blade's Edge Mountains,64.31,70.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Evergrove Druid|r
.turnin 10910 >> Turn in Death's Door
.accept 10904 >> Accept Harvesting the Fel Ammunition
.use 31763
.isQuestTurnedIn 10821
.maxlevel 66,bemend << !tbc
.target Evergrove Druid
step
#loop
.line Blade's Edge Mountains,63.79,70.87,63.76,68.70,63.08,66.67,62.35,61.39,61.57,59.57,63.39,59.88,63.07,63.93,64.96,67.57,63.79,70.87
.goto Blade's Edge Mountains,63.79,70.87,45,0
.goto Blade's Edge Mountains,63.76,68.70,45,0
.goto Blade's Edge Mountains,63.08,66.67,45,0
.goto Blade's Edge Mountains,62.35,61.39,45,0
.goto Blade's Edge Mountains,61.57,59.57,45,0
.goto Blade's Edge Mountains,63.39,59.88,45,0
.goto Blade's Edge Mountains,63.07,63.93,45,0
.goto Blade's Edge Mountains,64.96,67.57,45,0
.goto Blade's Edge Mountains,63.79,70.87,45,0
>>Kill the |cRXP_ENEMY_Deathforge|r and |cRXP_ENEMY_Death Demons|r. Loot them for their |cRXP_LOOT_Cannonballs|r
.complete 10904,1 
.isOnQuest 10904
.mob Death's Might
.mob Death's Watch
.mob Deathforge Over-Smith
.mob Deathforge Technician
step
#completewith next
.goto Blade's Edge Mountains,64.81,68.32,-1
.goto Blade's Edge Mountains,61.96,60.29,-1
.cast 38782 >>|cRXP_WARN_Use the|r |T135815:0|t[Druid Signal] |cRXP_WARN_to summon an |cRXP_FRIENDLY_Evergrove Druid|r at Death's Door|r
.timer 18,Druid Signal RP
.isOnQuest 10904
step
.goto Blade's Edge Mountains,64.81,68.32,-1
.goto Blade's Edge Mountains,61.96,60.29,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Evergrove Druid|r
.turnin 10904 >> Turn in Harvesting the Fel Ammunition
.accept 10911 >> Accept Fire At Will!
.isQuestTurnedIn 10821
.maxlevel 66,bemend << !tbc
.target Evergrove Druid
step
>>|cRXP_WARN_Use the|r |T136030:0|t[Naturalized Ammunition] |cRXP_WARN_to take control of a|r |cRXP_ENEMY_Fel Cannon|r
>>|cRXP_WARN_Cast|r |T135803:0|t[Artillery on the Warp-Gate] (1) |cRXP_WARN_to destroy the |cRXP_ENEMY_Warp-Gates|r while defending it|r
.complete 10911,1 
.goto Blade's Edge Mountains,64.81,68.32,-1
.complete 10911,2 
.goto Blade's Edge Mountains,61.96,60.29,-1
.isOnQuest 10911
.isQuestTurnedIn 10821
.use 31807
step
#completewith next
.goto Blade's Edge Mountains,62.50,60.17
.cast 38782 >>|cRXP_WARN_Use the|r |T135815:0|t[Druid Signal] |cRXP_WARN_to summon an |cRXP_FRIENDLY_Evergrove Druid|r at Death's Door|r
.timer 18,Druid Signal RP
.isOnQuest 10911
step
.goto Blade's Edge Mountains,62.50,60.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Evergrove Druid|r
.turnin 10911 >> Turn in Fire At Will!
.accept 10912 >> Accept The Hound-Master
.isQuestTurnedIn 10821
.maxlevel 66,bemend << !tbc
.target Evergrove Druid
step
.goto Blade's Edge Mountains,63.62,59.11
.use 31809 >>|cRXP_WARN_Use the|r |T133749:0|t[Evergrove Wand] |cRXP_WARN_to summon |cRXP_FRIENDLY_Evergorve Ancients|r. They will help you fight|r |cRXP_ENEMY_Baelmon the Hound-Master|r
>>Kill |cRXP_ENEMY_Baelmon the Hound-Master|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r <<tbc/wotlk
.complete 10912,1 
.use 31809
.isQuestTurnedIn 10821
.isOnQuest 10912
.mob Baelmon the Hound-Master
step
#completewith HoundMaster
.goto Blade's Edge Mountains,61.15,70.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rip Pedalslam|r
.fly Evergrove >> Fly to Evergrove
.cooldown item,6948,<0
.skill riding,225,1
.isQuestTurnedIn 10821
.target Rip Pedalslam
step
#optional
#completewith next
.hs >>Hearth to Evergrove
.cooldown item,6948,>2
.isQuestTurnedIn 10821
step
#label HoundMaster
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.turnin 10912 >> Turn in The Hound-Master
.isQuestComplete 10912
.maxlevel 66,bemend << !tbc
.target Wildlord Antelarion
step
.abandon 10912 >> Abandon The Hound-Master
step << skip
.goto Blade's Edge Mountains,60.3,68.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tally Zapnabber|r
.accept 10712 >> Accept Test Flight: Ruuan Weald
.target Tally Zapnabber
step << skip
.goto Blade's Edge Mountains,60.2,68.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tally Zapnabber|r to launch you towards Ruaan Weald
.complete 10712,1 
>>IMPORTANT: Use the item in your bags during the flight
.complete 10712,2 
.target Tally Zapnabber
step << skip
.goto Blade's Edge Mountains,62.7,40.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_O'Mally Zapnabber|r
.turnin 10712 >> Turn in Test Flight: Ruuan Weald
.target O'Mally Zapnabber
step
#questguide
#label Treebole
.goto Blade's Edge Mountains,37.1,22.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Treebole|r
.turnin 10829 >> Turn in Treebole Must Know
.accept 10830 >> Accept Exorcising the Trees
.maxlevel 66,bemend << !tbc
.target Treebole
step
#questguide
#completewith leafbeardE
.goto Blade's Edge Mountains,34.3,19.8
.goto Blade's Edge Mountains,40.3,23.0,0
.goto Blade's Edge Mountains,40.0,22.8,0
.goto Blade's Edge Mountains,40.2,20.6,0
.goto Blade's Edge Mountains,39.3,17.4,0
.goto Blade's Edge Mountains,41.3,21.9,0
>>Kill |cRXP_ENEMY_Dire Ravens|r. Loot them for their |cRXP_LOOT_Pinfeathers|r
>>Loot the |cRXP_LOOT_Grishnath Orbs|r on the ground
.collect 31495,5 
.collect 31517,5 
.maxlevel 66,bemend << !tbc
.mob Dire Raven
step
#questguide
#label leafbeardE
.goto Blade's Edge Mountains,34.3,19.8
>>|cRXP_WARN_Use the|r |T136210:0|t[Grishnath Orb] |cRXP_WARN_and|r |T132915:0|t[Dire Pinfeather] |cRXP_WARN_to create an|r |T132920:0|t[Exorcism Feather]
>>|cRXP_WARN_Use them on the|r |cRXP_ENEMY_Raven's Wood Leafbeards|r
>>|cRXP_WARN_The |cRXP_ENEMY_Raven's Wood Leafbeards|r will become friendly after you kill the|r |cRXP_ENEMY_Koi-Koi Spirits|r
.use 31518
.use 31495
.complete 10830,1 
.maxlevel 66,bemend << !tbc
.mob Raven's Wood Leafbeard
.mob Koi-Koi Spirit
step
#questguide
.goto Blade's Edge Mountains,37.1,22.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Treebole|r
.turnin 10830 >>Turn in Exorcising the Trees
.maxlevel 66,bemend << !tbc
.target Treebole
step
#questguide
.goto Blade's Edge Mountains,33.7,35.9
>>Run to the back of the Blackwing Coven
>>Kill |cRXP_ENEMY_Maxnar the Ashmaw|r
.complete 10748,1 
.maxlevel 66,bemend << !tbc
.mob Maxnar the Ashmaw
step
#questguide
.goto Blade's Edge Mountains,62.0,39.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tree Warden Chawn|r
.turnin 10748 >>Turn in Maxnar Must Die!
.maxlevel 66,bemend << !tbc
.target Tree Warden Chawn
step
#label bemend
step << !tbc !wotlk
#xprate >1.59
#optional
#label endOfTheGuide
]])

RXPGuides.RegisterGuide([[#version 9
#cata
#mop
#wotlk
#group RXP MoP 60-80 (A)
<< Alliance
#name 67-67 Blade's Edge Turn-ins
#version 9
#next 67-68 Netherstorm;71-73 Borean Tundra
#defaultfor !tbc
step
+As you're now Level 67 (or higher) and have completed all of your current Blade's Edge objectives, the guide will now turn in all remaining quests before sending you off to Netherstorm.
*Click the box here to begin this process
.isQuestAvailable 10912
.xp 67,1
step
#optional
#completewith HoundMaster
.goto Shattrath City,64.05,41.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r
.fly Telredor >> Fly to Telredor
.zoneskip Nagrand
.zoneskip Zangarmarsh
.skill riding,300,1
.target Nutral
step
#questguide << !tbc
.goto Zangarmarsh,68.3, 49.4
>>Return to Telredor
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Ahuurn|r
.turnin 9801 >>Turn in Gathering the Reagents
.isQuestComplete 9801
.target Anchorite Ahuurn
step
#optional
#completewith HoundMaster
.goto Shattrath City,64.05,41.12,-1
.goto Zangarmarsh,67.83,51.46,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r or |cRXP_FRIENDLY_Munci|r
>>|cRXP_WARN_The arrow will point you to the closest Flight Master|r
.fly Orebor Harborage >> Fly to Orebor Harborage
.skill riding,300,1
.target Nutral
.target Munci
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kialon Nightblade|r
.turnin 9794 >> Turn in No Time for Curiosity
.goto Blade's Edge Mountains,35.97,67.76,30,0
.goto Blade's Edge Mountains,36.61,67.34
.isQuestComplete 9794
.target Kialon Nightblade
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Skyshadow|r
.turnin 10927 >> Turn in Killing the Crawlers
.goto Blade's Edge Mountains,36.28,66.24
.isQuestComplete 10927
.target Commander Skyshadow
step
.goto Blade's Edge Mountains,34.31,77.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Tome|r atop the tree platform
.turnin 10555 >> Turn in Malaise
.isQuestComplete 10555
step
#completewith next
.goto Blade's Edge Mountains,35.23,77.31
.cast 36904 >> Use the |T132926:0|t[Fistful of Feathers] in your bags at the summoning circle
.use 30530
.isOnQuest 10556
step
.goto Blade's Edge Mountains,37.07,65.62
>>After using the |T132926:0|tFeathers, a |cRXP_FRIENDLY_Small Bird Companion|r will follow you around
>>|cRXP_WARN_Be aware|r that the |cRXP_FRIENDLY_Bird|r can't keep up with you if you run off on your mount
>>Escort the |cRXP_FRIENDLY_Bird|r back to |cRXP_FRIENDLY_Daranelle|r
.complete 10556,1 
.isOnQuest 10556
.target Daranelle
step
#label Scratches
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daranelle|r
.turnin 10556 >> Turn in Scratches
.goto Blade's Edge Mountains,37.07,65.62
.isQuestComplete 10556
.target Daranelle
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rina Moonspring|r
.turnin 10455 >> Turn in The Encroaching Wilderness
.goto Blade's Edge Mountains,36.21,67.13
.isQuestComplete 10455
.target Rina Moonspring
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Skyshadow|r
.turnin 10690 >> Turn in The Den Mother
.goto Blade's Edge Mountains,36.28,66.24
.isQuestComplete 10690
.target Commander Skyshadow
step
#label SylHS
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rina Moonspring|r
.turnin 10456 >> Turn in Marauding Wolves
.goto Blade's Edge Mountains,36.21,67.13
.isQuestComplete 10456
.target Rina Moonspring
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rina Moonspring|r
.turnin 10457 >> Turn in Protecting Our Own
.isQuestComplete 10457
.target Rina Moonspring
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rina Moonspring|r
.turnin 10506 >> Turn in A Dire Situation
.goto Blade's Edge Mountains,36.21,67.13
.isQuestComplete 10506
.target Rina Moonspring
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Skyshadow|r
.turnin 10502 >> Turn in The Bloodmaul Ogres
.goto Blade's Edge Mountains,36.28,66.24
.isQuestComplete 10502
.target Commander Skyshadow
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bronwyn Stouthammer|r
.turnin 10510 >> Turn in Into the Draenethyst Mine
.goto Blade's Edge Mountains,37.41,65.05
.isQuestComplete 10510
.target Bronwyn Stouthammer
step
#label Borgrim2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgrim Stouthammer|r
.turnin 10511 >> Turn in Strange Brew
.goto Blade's Edge Mountains,37.40,64.66
.isQuestComplete 10511
.target Borgrim Stouthammer
step
.goto Blade's Edge Mountains,44.01,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Vuuleen|r
.turnin 10516 >> Turn in The Trappings of a Vindicator
.accept 10517 >> Accept Gorr'Dim, Your Time Has Come...
.isQuestComplete 10516
.target Vindicator Vuuleen
step
.goto Blade's Edge Mountains,44.01,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Vuuleen|r
.accept 10517 >> Accept Gorr'Dim, Your Time Has Come...
.isQuestTurnedIn 10516
.target Vindicator Vuuleen
step
.goto Blade's Edge Mountains,39.38,49.06
>>Kill the two |cRXP_ENEMY_Ogres|r nearest to the door, then use the |T132621:0|t[Brutebane Keg] in your bags to lure |cRXP_ENEMY_Gorr'Dim|r away from the elite guards. Kill him
.complete 10517,1 
.isOnQuest 10517
.mob Bladespire Shaman
.mob Bladespire Brute
.mob Gorr'Dim
step
.goto Blade's Edge Mountains,44.01,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vindicator Vuuleen|r
.turnin 10517 >> Turn in Gorr'Dim, Your Time Has Come...
.isQuestComplete 10517
.target Vindicator Vuuleen
step
#completewith BorgrimT
.hs >> Hearth to Sylvanaar
.cooldown item,6948,>2
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Skyshadow|r
.turnin 10504 >> Turn in The Bladespire Ogres
.goto Blade's Edge Mountains,36.28,66.24
.isQuestComplete 10504
.target Commander Skyshadow
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Skyshadow|r
.turnin 10518 >> Turn in Planting the Banner
.goto Blade's Edge Mountains,36.28,66.24
.isQuestComplete 10518
.target Commander Skyshadow
step
#label BorgrimT
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgrim Stouthammer|r
.turnin 10512 >> Turn in Getting the Bladespire Tanked
.goto Blade's Edge Mountains,37.40,64.66
.isQuestComplete 10512
.target Borgrim Stouthammer
step
.goto Blade's Edge Mountains,55.11,72.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_R-3D0|r
.turnin 10580 >> Turn in Where Did Those Darn Gnomes Go?
.accept 10581 >> Accept Follow the Breadcrumbs
.isQuestComplete 10580
.target R-3D0
step
.goto Blade's Edge Mountains,55.11,72.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_R-3D0|r
.accept 10581 >> Accept Follow the Breadcrumbs
.isQuestTurnedIn 10580
.target R-3D0
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toshley|r
.turnin 10581 >> Turn in Follow the Breadcrumbs
.goto Blade's Edge Mountains,60.53,68.97
.isQuestComplete 10581
.target Toshley
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tally Zapnabber|r
.turnin 10557 >> Turn in Test Flight: The Zephyrium Capacitorium
.goto Blade's Edge Mountains,60.28,68.39
.isQuestComplete 10557
.target Tally Zapnabber
step
#label ToshStation
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toshley|r
.turnin 10584 >> Turn in Picking Up Some Power Converters
.goto Blade's Edge Mountains,60.53,68.97
.isQuestComplete 10584
.target Toshley
step
#completewith CrystalClear
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.turnin 10632 >> Turn in Cutting Your Teeth
.isQuestComplete 10632
.target Razak Ironsides
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nickwinkle the Metro-Gnome|r
.turnin 10608 >> Turn in Crystal Clear
.goto Blade's Edge Mountains,60.22,68.94
.isQuestComplete 10608
.target Nickwinkle the Metro-Gnome
step
#label CrystalClear
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dizzy Dina|r
.turnin 10620 >> Turn in Ridgespine Menace
.goto Blade's Edge Mountains,60.40,68.75
.isQuestComplete 10620
.target Dizzy Dina
step
.goto Blade's Edge Mountains,59.99,69.32,30,0
.goto Blade's Edge Mountains,60.28,68.98,30,0
.goto Blade's Edge Mountains,60.11,68.37,30,0
.goto Blade's Edge Mountains,59.81,68.29,30,0
.goto Blade's Edge Mountains,60.03,67.79,30,0
.goto Blade's Edge Mountains,60.31,68.23,30,0
.goto Blade's Edge Mountains,60.42,67.91,30,0
.goto Blade's Edge Mountains,60.54,68.76,30,0
.goto Blade's Edge Mountains,60.44,69.37
.line Blade's Edge Mountains,59.99,69.32,60.28,68.98,60.11,68.37,59.81,68.29,60.03,67.79,60.31,68.23,60.42,67.91,60.54,68.76,60.44,69.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razak Ironsides|r patrolling the Station
.turnin 10632 >> Turn in Cutting Your Teeth
.isQuestComplete 10632
.target Razak Ironsides
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nickwinkle the Metro-Gnome|r
.turnin 10594 >> Turn in Gauging the Resonant Frequency
.goto Blade's Edge Mountains,60.22,68.94
.isQuestComplete 10594
.target Nickwinkle the Metro-Gnome
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tally Zapnabber|r
.turnin 10710 >> Turn in Test Flight: The Singing Ridge
.goto Blade's Edge Mountains,60.28,68.39
.isQuestComplete 10710
.target Tally Zapnabber
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizit "Doc" Clocktock|r
.turnin 10609 >> Turn in What Came First, the Drake or the Egg?
.goto Blade's Edge Mountains,60.98,68.11
.isQuestComplete 10609
.target Fizit "Doc" Clocktock
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faradrella|r
.turnin 10753 >>Turn in Culling the Wild
.goto Blade's Edge Mountains,62.56,38.23
.isQuestComplete 10753
.target Faradrella
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mosswood the Ancient|r
.turnin 10770 >>Turn in Little Embers
.goto Blade's Edge Mountains,61.25,38.46
.isQuestComplete 10770
.target Mosswood the Ancient
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mosswood the Ancient|r
.turnin 10771 >>Turn in From the Ashes
.goto Blade's Edge Mountains,61.25,38.46
.isQuestComplete 10771
.target Mosswood the Ancient
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_O'Mally Zapnabber|r
.turnin 10810 >>Turn in Damaged Mask
.accept 10812 >>Accept Mystery Mask
.goto Blade's Edge Mountains,62.66,40.38
.isQuestComplete 10810
.target O'Mally Zapnabber
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_O'Mally Zapnabber|r
.accept 10812 >>Accept Mystery Mask
.goto Blade's Edge Mountains,62.66,40.38
.isQuestTurnedIn 10810
.target O'Mally Zapnabber
step
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.turnin 10812 >>Turn in Mystery Mask
.isQuestComplete 10812
.target Wildlord Antelarion
step
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.accept 10819 >>Accept Felsworn Gas Mask
.isQuestTurnedIn 10812
.target Wildlord Antelarion
step
#completewith next
.cast 38448 >> Equip the |T133133:0|t[Felsworn Gas Mask] in your bags to be able to talk to the |cRXP_FRIENDLY_Legion Communicator|r
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Legion Communicator|r with your |T133133:0|t[Felsworn Gas Mask] equipped
.goto Blade's Edge Mountains,73.27,40.03
.turnin 10819 >>Turn in Felsworn Gas Mask
.isQuestComplete 10819
step
#completewith next
.cast 38448 >> Equip the |T133133:0|t[Felsworn Gas Mask] in your bags to be able to talk to the |cRXP_FRIENDLY_Legion Communicator|r
step
.goto Blade's Edge Mountains,73.27,40.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Legion Communicator|r with your |T133133:0|t[Felsworn Gas Mask] equipped
.turnin 10820 >>Turn in Deceive thy Enemy
.isQuestComplete 10820
step
#completewith Nuaar
.hs >>Hearth to Evergrove
.cooldown item,6948,>2
step
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.turnin 10821 >> Turn in You're Fired!
.isQuestComplete 10821
.target Wildlord Antelarion
step
#label Nuaar
.line Blade's Edge Mountains,62.82,25.94,63.12,27.41,63.34,27.87,63.28,28.37,62.73,28.77,62.45,29.31,62.37,29.65,62.44,31.66,62.11,33.34,61.80,34.00,61.43,34.10,60.61,33.98,60.12,34.47,60.01,34.80,60.08,35.15,59.90,35.72,59.60,36.07,59.11,36.21,58.96,36.61,58.65,36.91,58.18,36.96,57.90,37.34,57.84,37.81,59.13,39.47,59.90,40.27,60.51,40.90,61.50,42.02,61.78,42.41,62.62,43.95,62.97,45.05,63.06,46.38
63.06,46.38
.goto Blade's Edge Mountains,63.06,46.38,60,0
.goto Blade's Edge Mountains,62.97,45.05,60,0
.goto Blade's Edge Mountains,62.62,43.95,60,0
.goto Blade's Edge Mountains,61.78,42.41,60,0
.goto Blade's Edge Mountains,61.50,42.02,60,0
.goto Blade's Edge Mountains,60.51,40.90,60,0
.goto Blade's Edge Mountains,59.90,40.27,60,0
.goto Blade's Edge Mountains,59.13,39.47,60,0
.goto Blade's Edge Mountains,57.84,37.81,60,0
.goto Blade's Edge Mountains,57.90,37.34,60,0
.goto Blade's Edge Mountains,58.18,36.96,60,0
.goto Blade's Edge Mountains,58.65,36.91,60,0
.goto Blade's Edge Mountains,58.96,36.61,60,0
.goto Blade's Edge Mountains,59.11,36.21,60,0
.goto Blade's Edge Mountains,59.60,36.07,60,0
.goto Blade's Edge Mountains,59.90,35.72,60,0
.goto Blade's Edge Mountains,60.08,35.15,60,0
.goto Blade's Edge Mountains,60.01,34.80,60,0
.goto Blade's Edge Mountains,60.12,34.47,60,0
.goto Blade's Edge Mountains,60.61,33.98,60,0
.goto Blade's Edge Mountains,61.80,34.00,60,0
.goto Blade's Edge Mountains,62.11,33.34,60,0
.goto Blade's Edge Mountains,62.44,31.66,60,0
.goto Blade's Edge Mountains,62.37,29.65,60,0
.goto Blade's Edge Mountains,62.45,29.31,60,0
.goto Blade's Edge Mountains,62.73,28.77,60,0
.goto Blade's Edge Mountains,63.28,28.37,60,0
.goto Blade's Edge Mountains,63.34,27.87,60,0
.goto Blade's Edge Mountains,63.12,27.41,60,0
.goto Blade's Edge Mountains,62.82,25.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overseer Nuaar|r
>>He patrols the Wyrmcult camps of Ruuan Weald
.complete 10682,1 
.unitscan Overseer Nuaar
.skipgossip
.isOnQuest 10682
step
>>Return to Evergrove. Talk to Chawn
.turnin 10682 >>Turn in A Time for Negotiation...
.goto Blade's Edge Mountains,61.97,39.47
.isQuestComplete 10682
.target Tree Warden Chawn
step
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Haephus Stonewall|r
.turnin 10795 >> Turn in A Date with Dorgok
.goto Blade's Edge Mountains,61.98,37.98
.isQuestComplete 10795
.target Commander Haephus Stonewall
step
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Haephus Stonewall|r
.turnin 10797 >> Turn in Favor of the Gronn
.goto Blade's Edge Mountains,61.98,37.98
.isQuestComplete 10797
.target Commander Haephus Stonewall
step
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Fairweather|r
.turnin 10796 >> Turn in Crush the Bloodmaul Camp!
.goto Blade's Edge Mountains,61.98,37.94
.isQuestComplete 10796
.target Lieutenant Fairweather
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Timeon|r
.turnin 10567 >>Turn in Creating the Pendant
.goto Blade's Edge Mountains,62.16,39.11
.isQuestComplete 10567
.target Timeon
step
.goto Blade's Edge Mountains,61.97,39.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tree Warden Chawn|r and |cRXP_FRIENDLY_Samia Inkling|r
.turnin 10713 >>Turn in ...and a Time for Action
.isQuestComplete 10713
.target Tree Warden Chawn
step
.goto Blade's Edge Mountains,61.97,39.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tree Warden Chawn|r
.turnin 10719 >>Turn in Did You Get The Note?
.target Tree Warden Chawn
.isQuestComplete 10719
step
.goto Blade's Edge Mountains,61.94,39.45
.turnin 10717 >>Turn in Poaching from Poachers
.isQuestComplete 10717
.target Samia Inkling
step
.goto Blade's Edge Mountains,53.25,41.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron Sablemane|r
.turnin 10798 >> Turn in Pay the Baron a Visit
.isQuestComplete 10798
.target Baron Sablemane
step
.goto Blade's Edge Mountains,53.25,41.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron Sablemane|r
.turnin 10799 >> Turn in Into the Churning Gulch
.isQuestComplete 10799
.target Baron Sablemane
step
.goto Blade's Edge Mountains,53.25,41.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron Sablemane|r
.turnin 10800 >> Turn in Goodnight, Gronn
.isQuestComplete 10800
.target Baron Sablemane
step
#label Evergrove3
>>Return to Evergrove
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Haephus Stonewall|r
.turnin 10801 >> Turn in It's a Trap!
.goto Blade's Edge Mountains,61.98,37.98
.isQuestComplete 10801
.target Commander Haephus Stonewall
step
.goto Blade's Edge Mountains,50.35,36.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Moonshade|r atop the bridge
.turnin 10894 >>Turn in Wyrmskull Watcher
.isQuestComplete 10894
.target Watcher Moonshade
step
.goto Blade's Edge Mountains,50.35,36.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Moonshade|r atop the bridge
.accept 10893 >>Accept Longtail is the Lynchpin
.isQuestTurnedIn 10894
.target Watcher Moonshade
step
>>Kill |cRXP_ENEMY_Draaca|r inside of the tunnel
.goto Blade's Edge Mountains,46.03,32.93,40,0
.goto Blade's Edge Mountains,45.81,32.90,40,0
.goto Blade's Edge Mountains,44.78,32.07
.complete 10893,1 
.unitscan Draaca Longtail
.isOnQuest 10893
step
.goto Blade's Edge Mountains,49.92,35.92,20,0
.goto Blade's Edge Mountains,50.35,36.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watcher Moonshade|r
.turnin 10893 >>Turn in Longtail is the Lynchpin
.isQuestComplete 10893
.target Watcher Moonshade
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lieutenant Fairweather|r
.turnin 10803 >> Turn in Slaughter at Boulder'mok
.goto Blade's Edge Mountains,61.98,37.94
.isQuestComplete 10803
.target Lieutenant Fairweather
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Haephus Stonewall|r
.turnin 10802 >> Turn in Gorgrom the Dragon-Eater
.goto Blade's Edge Mountains,61.98,37.98
.isQuestComplete 10802
.target Commander Haephus Stonewall
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Timeon|r
.turnin 10607 >> Turn in Whispers of the Raven God
.goto Blade's Edge Mountains,62.16,39.11
.isQuestComplete 10607
.target Timeon
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tree Warden Chawn|r
.turnin 10722 >> Turn in Meeting at the Blackwing Coven
.goto Blade's Edge Mountains,61.97,39.47
.isQuestComplete 10722
.target Tree Warden Chawn
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tree Warden Chawn|r
.turnin 10825 >> Turn in The Truth Unorbed
.goto Blade's Edge Mountains,61.97,39.47
.isQuestComplete 10825
.target Tree Warden Chawn
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Samia Inkling|r
.turnin 10747 >> Turn in Whelps of the Wyrmcult
.goto Blade's Edge Mountains,61.94,39.45
.isQuestComplete 10747
.target Samia Inkling
step
#completewith next
.goto Blade's Edge Mountains,64.81,68.32,-1
.goto Blade's Edge Mountains,61.96,60.29,-1
.cast 38782 >>Use the |T135815:0|t[Druid Signal] in your bags to summon an |cRXP_FRIENDLY_Evergrove Druid|r
.timer 18,Druid Signal RP
.isQuestComplete 10904
step
.goto Blade's Edge Mountains,64.81,68.32,-1
.goto Blade's Edge Mountains,61.96,60.29,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Evergrove Druid|r
.turnin 10904 >> Turn in Harvesting the Fel Ammunition
.isQuestComplete 10904
.target Evergrove Druid
step
#completewith next
.goto Blade's Edge Mountains,62.50,60.17
.cast 38782 >>Use the |T135815:0|t[Druid Signal] in your bags to summon an |cRXP_FRIENDLY_Evergrove Druid|r
.timer 18,Druid Signal RP
.isOnQuest 10911
step
.goto Blade's Edge Mountains,62.50,60.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Evergrove Druid|r
.turnin 10911 >> Turn in Fire At Will!
.accept 10912 >> Accept The Hound-Master
.isQuestTurnedIn 10821
.target Evergrove Druid
step
#completewith next
.goto Blade's Edge Mountains,63.62,59.11
.use 31809 >>Use the |T133749:0|t[Evergrove Wand] in your bags to summon |cRXP_FRIENDLY_Evergorve Ancients|r. They will help you fight |cRXP_ENEMY_Baelmon|r
>>Kill |cRXP_ENEMY_Baelmon|r
.isOnQuest 10912
.mob Baelmon the Hound-Master
step
.goto Blade's Edge Mountains,63.62,59.11
>>Kill |cRXP_ENEMY_Baelmon the Hound-Master|r. This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him.
.complete 10912,1 
.use 31809
.isQuestTurnedIn 10821
.isOnQuest 10912
.target Baelmon the Hound-Master
step
#label HoundMaster
.goto Blade's Edge Mountains,62.53,39.91,40,0
.goto Blade's Edge Mountains,62.00,40.21,40,0
.goto Blade's Edge Mountains,61.45,39.73,40,0
.goto Blade's Edge Mountains,61.28,38.77,40,0
.goto Blade's Edge Mountains,62.20,38.15,40,0
.goto Blade's Edge Mountains,62.69,39.13
.line Blade's Edge Mountains,62.53,39.91,62.00,40.21,61.45,39.73,61.28,38.77,62.20,38.15,62.69,39.13,62.53,39.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wildlord Antelarion|r, he patrols counter-clockwise around the town
.turnin 10912 >> Turn in The Hound-Master
.isQuestComplete 10912
.target Wildlord Antelarion
step
.abandon 10912 >> Abandon The Hound-Master
step << !tbc !wotlk !Mage
#xprate >1.59
#completewith next
.zone Shattrath City >> Travel to Shattrath City
step << !tbc !wotlk
#xprate >1.59
.goto Shattrath City,57.217,48.257
.zone 84 >> Take the portal to Stormwind City << !Mage
.zone 84 >> Teleport to Stormwind City << Mage
]])

RXPGuides.RegisterGuide([[#version 9
#cata
#mop
#wotlk
#group RXP MoP 60-80 (A)
<< Alliance
#name 67-68 Netherstorm
#version 9
#displayname 67-69 Netherstorm << !tbc !wotlk
#next 69-70 Shadowmoon Valley (Aldor) << TBC
#next RXP MoP 60-80 (A)\68-71 Howling Fjord;RXP MoP 60-80 (A)\71-73 Borean Tundra << !TBC
#xprate <1.6 << !tbc !wotlk
step
#include RXPGuides\67-68 Netherstorm
]])

RXPGuides.RegisterGuide([[#version 9
#cata
#mop
#wotlk
#group RXP MoP 60-80 (A)
<< Alliance
#name 71-73 Borean Tundra
#version 9
#displayname 69-73 Borean Tundra << !wotlk
#next 72-74 Dragonblight; 73-75 Grizzly Hills << wotlk
#next 73-74 Dragonblight; 77-78 Sholazar Basin << !wotlk
step
.goto 1453/0,1407.6,-8291.2 << !wotlk
.goto StormwindNew,43.5,52.7,70,0 << wotlk
.goto StormwindNew,18.47,26.49 << wotlk
>>Travel to the Stormwind Harbor
.zone BoreanTundra >> Take the boat to Borean Tundra << !wotlk
.zone BoreanTundra >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leesha|r. Ask her for a teleport to Valiance Keep << wotlk
.skipgossip << wotlk
.target Leesha Tannerby << wotlk
step
#completewith enlist
.goto BoreanTundra,58.97,68.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tomas|r
.fp Valiance Keep >> Get the Valiance Keep flight path
.target Tomas Riverwell
step
#completewith Hawthorn5
.groundgoto BoreanTundra,58.5,68.3,15,0
.goto BoreanTundra,58.29,68.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_James|r inside the Inn
.home >> Set your Hearthstone to Valiance Keep
>>|cRXP_BUY_Buy new food/water if needed|r
.target James Deacon
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruitment Officer Blythe|r and |cRXP_FRIENDLY_Rollick|r
.accept 11672 >>Accept Enlistment Day
.goto BoreanTundra,57.85,67.60
.accept 13088 >> Accept Northern Cooking
.goto BoreanTundra,57.93,71.54
.skill cooking,<350,1
.target Recruitment Officer Blythe
.target Rollick MacKreel
step
#label enlist
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Recruitment Officer Blythe|r
.accept 11672 >>Accept Enlistment Day
.goto BoreanTundra,57.85,67.60
.target Recruitment Officer Blythe
step
#optional
#completewith next
.goto BoreanTundra,57.1,71.8,15,0
.goto BoreanTundra,57.2,72.3,15,0
.goto BoreanTundra,56.67,72.64,10 >> Travel into the Keep
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arlos|r
.turnin 11672 >>Turn in Enlistment Day
.accept 11727 >>Accept A Time for Heroes
.goto BoreanTundra,56.67,72.64
.target General Arlos
step
#completewith next
.goto BoreanTundra,56.87,71.29,20 >> Exit the Keep
step
.goto 114/571,5321.100,2223.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Hammerhill|r
.target Sergeant Hammerhill
.turnin 11727 >>Turn in A Time for Heroes
.accept 11797 >>Accept The Siege
step
.goto 114/571,5400.100,2248.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Medic Hawthorn|r
.target Medic Hawthorn
.accept 11789 >>Accept A Soldier in Need
step
.goto BoreanTundra,53.5,69.1,70,0
.goto BoreanTundra,53.1,72.8,60,0
.goto BoreanTundra,52.29,70.53,60,0
.goto BoreanTundra,53.90,67.07,60,0
.goto BoreanTundra,54.85,65.09
>>Kill |cRXP_ENEMY_Crypt Crawlers|r
.complete 11797,1 
.mob Crypt Crawler
step
.goto BoreanTundra,56.36,69.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hammerhill|r
.turnin 11797 >>Turn in The Siege
.accept 11889 >>Accept Death From Above
.target Sergeant Hammerhill
step
.goto BoreanTundra,54.8,70.2,40,0
.goto BoreanTundra,54.83,71.43,40,0
.goto BoreanTundra,54.8,70.2
.use 35278 >>|cRXP_WARN_Use the|r |T134325:0|t[Reinforced Net] |cRXP_WARN_to bring down the flying|r |cRXP_ENEMY_Scourged Flamespitters|r
>>Kill |cRXP_ENEMY_Scourged Flamespitters|r
.complete 11889,1 
.mob Scourged Flamespitter
step
.goto BoreanTundra,56.36,69.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hammerhill|r
.turnin 11889 >>Turn in Death From Above
.accept 11897 >>Accept Plug the Sinkholes
.target Sergeant Hammerhill
step
#completewith next
.goto BoreanTundra,56.96,68.75,10 >> Travel onto The Stormbreaker. Head to the lower level
step
>>Open the |cRXP_PICK_First Aid Supplies|r. Loot it for |cRXP_LOOT_Hawthorn's Anti-Venom|r
>>Click on the |cRXP_PICK_Cultist Shrine|r
.complete 11789,1 
.goto BoreanTundra,57.50,69.27
.accept 11920 >>Accept Cultists Among Us
.goto BoreanTundra,57.56,69.13
step
#completewith next
.goto BoreanTundra,56.96,68.75,10 >> Travel toward |cRXP_FRIENDLY_Captain "Lefty"|r and |cRXP_FRIENDLY_Admiral Cantlebree|r
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain "Lefty"|r and |cRXP_FRIENDLY_Admiral Cantlebree|r
.turnin 11920 >>Turn in Cultists Among Us
.goto BoreanTundra,57.83,69.20
.target +Captain "Lefty" Lugsail
.accept 11791 >>Accept Notify Arlos
.target +Admiral Cantlebree
.goto BoreanTundra,57.79,69.19
step
#completewith next
.goto BoreanTundra,57.1,71.8,15,0
.goto BoreanTundra,57.2,72.3,15,0
.goto BoreanTundra,56.67,72.64,10 >> Travel into the Keep
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arlos|r, |cRXP_FRIENDLY_Talbot|r, and |cRXP_FRIENDLY_Vurenn|r
.turnin 11791 >>Turn in Notify Arlos
.goto BoreanTundra,56.67,72.64
.target +General Arlos
.accept 12141 >>Accept A Diplomatic Mission
.goto BoreanTundra,56.72,72.62
.target +Counselor Talbot
.accept 11792 >>Accept Enemies of the Light
.target +Harbinger Vurenn
.goto BoreanTundra,56.60,72.46
step
#completewith next
.goto BoreanTundra,56.87,71.29,20 >> Exit the Keep
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hawthorn|r
.turnin 11789 >>Turn in A Soldier in Need
.goto BoreanTundra,55.00,68.91
.target Medic Hawthorn
step
.goto BoreanTundra,54.08,63.73,-1
.goto BoreanTundra,54.77,63.08,-1
.use 35704 >> |cRXP_WARN_Use the|r |T133713:0|t[Incendiary Explosives] |cRXP_WARN_at the|r |cRXP_PICK_Northern Sinkhole|r
.complete 11897,2 
step
#loop
.line BoreanTundra,54.04,62.42,53.84,60.33,55.25,63.43,54.04,62.42
.goto BoreanTundra,54.04,62.42,40,0
.goto BoreanTundra,53.84,60.33,40,0
.goto BoreanTundra,55.25,63.43,40,0
.goto BoreanTundra,54.04,62.42,40,0
>>Kill |cRXP_ENEMY_Cultist Necrolytes|r. Loot them for their |cRXP_LOOT_Communique|r
.complete 11792,1 
.mob Cultist Necrolyte
step
.goto BoreanTundra,50.46,71.38,-1
.goto BoreanTundra,50.88,72.29,-1
.use 35704 >> |cRXP_WARN_Use the|r |T133713:0|t[Incendiary Explosives] |cRXP_WARN_at the|r |cRXP_PICK_Southern Sinkhole|r
.complete 11897,1 
step
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 12141 >>Turn in A Diplomatic Mission
.accept 11613 >>Accept Karuk's Oath
.target Karuk
step
#completewith Karuk2
#label CTPrisoner2
.goto BoreanTundra,44.10,77.90,50,0
>>Kill |cRXP_ENEMY_Skadir Longboatsmen|r and the |cRXP_ENEMY_Riplash Myrmidon|r surrounding the |cRXP_FRIENDLY_Captured Tuskarr Prisoner|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Prisoner|r
>>|cRXP_WARN_Ignore this if the |cRXP_FRIENDLY_Prisoner|r isn't there|r
.accept 12471 >>Accept Cruelty of the Kvaldir
.unitscan Captured Tuskarr Prisoner
step
#loop
.goto BoreanTundra,44.08,78.16,50,0
.goto BoreanTundra,46.02,79.49,50,0
.goto BoreanTundra,46.80,80.74,50,0
.goto BoreanTundra,48.40,79.83,50,0
.goto BoreanTundra,50.33,78.08,50,0
.goto BoreanTundra,48.22,76.00,50,0
.goto BoreanTundra,47.69,77.59,50,0
.goto BoreanTundra,44.08,78.16,50,0
.goto BoreanTundra,46.02,79.49,50,0
.goto BoreanTundra,46.80,80.74,50,0
.goto BoreanTundra,48.40,79.83,50,0
.goto BoreanTundra,50.33,78.08,50,0
.goto BoreanTundra,48.22,76.00,50,0
.goto BoreanTundra,47.69,77.59,0
>>Kill |cRXP_ENEMY_Skadir Longboatsmen|r and |cRXP_ENEMY_Skadir Raiders|r
.complete 11613,2 
.mob +Skadir Longboatsman
.complete 11613,1 
.mob +Skadir Raider
step
#optional
#completewith end
#requires CTPrisoner2
#label Cruelty2
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 12471 >>Turn in Cruelty of the Kvaldir
.isOnQuest 12471
.target Karuk
step
#label Karuk2
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 11613 >>Turn in Karuk's Oath
.accept 11619 >>Accept Gamel the Cruel
.target Karuk
step
#optional
#requires Cruelty2
#completewith next
.groundgoto BoreanTundra,46.3,78.8,20,0
.goto BoreanTundra,46.42,78.23,15 >> Travel into the Cave
step
.goto BoreanTundra,46.42,78.23
>>Kill |cRXP_ENEMY_Gamel the Cruel|r inside the cave
.complete 11619,1 
.mob Gamel the Cruel
step
#optional
#completewith Karuk3
#label CTPrisoner3
.goto BoreanTundra,44.10,77.90,50,0
>>Kill |cRXP_ENEMY_Skadir Longboatsmen|r and the |cRXP_ENEMY_Riplash Myrmidon|r surrounding the |cRXP_FRIENDLY_Captured Tuskarr Prisoner|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Prisoner|r
>>|cRXP_WARN_Ignore this if the |cRXP_FRIENDLY_Prisoner|r isn't there|r
.accept 12471 >>Accept Cruelty of the Kvaldir
.unitscan Captured Tuskarr Prisoner
step
#optional
#completewith end
#requires CTPrisoner3
#label Cruelty3
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 12471 >>Turn in Cruelty of the Kvaldir
.isOnQuest 12471
.target Karuk
step
#label Karuk3
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 11619 >>Turn in Gamel the Cruel
.accept 11620 >>Accept A Father's Words
.target Karuk
step
#optional
#completewith Veehja
#label CTPrisoner4
.goto BoreanTundra,44.10,77.90,50,0
>>Kill |cRXP_ENEMY_Skadir Longboatsmen|r and the |cRXP_ENEMY_Riplash Myrmidon|r surrounding the |cRXP_FRIENDLY_Captured Tuskarr Prisoner|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Prisoner|r
>>|cRXP_WARN_Ignore this if the |cRXP_FRIENDLY_Prisoner|r isn't there|r
.accept 12471 >>Accept Cruelty of the Kvaldir
.unitscan Captured Tuskarr Prisoner
step
#optional
#completewith end
#requires CTPrisoner4
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 12471 >>Turn in Cruelty of the Kvaldir
.isOnQuest 12471
.target Karuk
step << wotlk
.goto BoreanTundra,43.60,80.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veehja|r << DK
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veehja|r. Only accept this quest if you have enough [|cRXP_WARN_Fish Oil|r] << Shaman
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veehja|r. Only accept this quest if you have multiple |T134794:0|t[|cRXP_WARN_Elixir of Water Walking|r] or are partied with a |T135771:0|t|cFFC41E3ADeath Knight|r << !Shaman !DK
.turnin 11620 >>Turn in A Father's Words
.accept 11625 >>Accept The Trident of Naz'jan
.itemcount 17058,5 << Shaman
.itemcount 8827,5 << !Shaman !DK
.skill coldweatherflying,1,1
.target Veehja
step
#label Veehja2
.goto BoreanTundra,43.60,80.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veehja|r
.turnin 11620 >>Turn in A Father's Words
.accept 11625 >>Accept The Trident of Naz'jan
.skill coldweatherflying,<1,1
.target Veehja
step
#label Veehja
.goto BoreanTundra,43.60,80.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veehja|r
.turnin 11620 >>Turn in A Father's Words
.target Veehja
step
#requires Veehja2
#completewith next
.groundgoto BoreanTundra,53.7,91.1,40,0
.goto BoreanTundra,54.85,88.78,100 >> Travel to the Riplash Ruins
.isOnQuest 11625
step
.goto BoreanTundra,55.03,88.51
>>Kill |cRXP_ENEMY_Ragnar Drakkarlund|r. Loot him for his |cRXP_LOOT_Trident|r
.complete 11625,1 
.isOnQuest 11625
.mob Ragnar Drakkarlund
step
.goto BoreanTundra,43.63,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veehja|r
.turnin 11625 >>Turn in The Trident of Naz'jan
.isQuestComplete 11625
.target Veehja
step
.goto BoreanTundra,43.63,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Veehja|r
.accept 11626 >>Accept The Emissary
.isQuestTurnedIn 11625
.target Veehja
step
.goto BoreanTundra,51.90,88.46
.use 35850 >> |cRXP_WARN_Use the|r |T135127:0|t[Trident of Naz'jan] |cRXP_WARN_to deal significant damage to |cRXP_ENEMY_Leviroth|r underwater|r
>>Kill |cRXP_ENEMY_Leviroth|r
.complete 11626,1 
.isQuestTurnedIn 11625
.mob Leviroth
step
#completewith Karuk5
#label CTPrisoner5
.goto BoreanTundra,44.10,77.90,50,0
>>Kill |cRXP_ENEMY_Skadir Longboatsmen|r and the |cRXP_ENEMY_Riplash Myrmidon|r surrounding the |cRXP_FRIENDLY_Captured Tuskarr Prisoner|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Prisoner|r
>>|cRXP_WARN_Ignore this if the |cRXP_FRIENDLY_Prisoner|r isn't there|r
.accept 12471 >>Accept Cruelty of the Kvaldir
.unitscan Captured Tuskarr Prisoner
.mob Skadir Longboatsman
.isQuestTurnedIn 11625
step
#completewith end
#requires CTPrisoner5
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 12471 >>Turn in Cruelty of the Kvaldir
.isOnQuest 12471
.target Karuk
step
#label Karuk5
.goto BoreanTundra,47.13,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karuk|r
.turnin 11626 >>Turn in The Emissary
.isQuestTurnedIn 11625
.target Karuk
step
#completewith Oculus
.hs >> Hearth to Valiance Keep
step
#completewith Oculus
.goto BoreanTundra,57.1,71.8,15,0
.goto BoreanTundra,57.2,72.3,15,0
.goto BoreanTundra,56.67,72.64,10 >> Travel into the Keep
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vurenn|r, |cRXP_FRIENDLY_Rollick|r, |cRXP_FRIENDLY_Hammerhill|r, |cRXP_FRIENDLY_Mark|r, and |cRXP_FRIENDLY_Skyhopper|r outside
.turnin 11792 >>Turn in Enemies of the Light
.accept 11793 >>Accept Further Investigation
.goto BoreanTundra,56.60,72.46
.turnin 13088 >> Turn in Northern Cooking
.goto BoreanTundra,57.93,71.54
.turnin 11897 >>Turn in Plug the Sinkholes
.accept 11928 >>Accept Farshire
.goto BoreanTundra,56.36,69.58
.accept 11927 >>Accept Word on the Street
.goto BoreanTundra,56.77,69.51
.accept 11707 >>Accept Distress Call
.goto BoreanTundra,58.84,68.72
.isQuestComplete 13088
.skill cooking,<350,1
.target Sergeant Hammerhill
.target Harbinger Vurenn
.target Rollick MacKreel
.target Mark Hanes
.target Airman Skyhopper
step
.goto 114/571,5305.900,2112.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harbinger Vurenn|r
.target Harbinger Vurenn
.turnin 11792 >>Turn in Enemies of the Light
.accept 11793 >>Accept Further Investigation
step
.goto 114/571,5321.000,2223.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Hammerhill|r
.target Sergeant Hammerhill
.turnin 11897 >>Turn in Plug the Sinkholes
.accept 11928 >>Accept Farshire
step
.goto 114/571,5296.800,2225.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mark Hanes|r
.target Mark Hanes
.accept 11927 >>Accept Word on the Street
step
.goto 114/571,5179.900,2255.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Airman Skyhopper|r
.target Airman Skyhopper
.accept 11707 >>Accept Distress Call
step
.goto BoreanTundra,58.5,68.3,15,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Midge|r, then |cRXP_FRIENDLY_Leryssa|r and |cRXP_FRIENDLY_Yaala|r upstairs
.accept 11575 >>Accept Nick of Time
.goto BoreanTundra,58.41,67.79
.target +Midge
.turnin 11927 >>Turn in Word on the Street
.accept 11599 >>Accept Thassarian, My Brother
.goto BoreanTundra,58.4,67.6,15,0
.goto BoreanTundra,58.75,68.36
.target +Leryssa
.turnin 11793 >>Turn in Further Investigation
.accept 11794 >>Accept The Hunt is On
.target +Vindicator Yaala
.goto BoreanTundra,58.55,67.29
step
#label Oculus
.use 35125 >> |cRXP_WARN_Use the|r |T134335:0|t[Oculus of the Exorcist] |cRXP_WARN_to buff yourself with|r |T135895:0|t[Righteous Vision]
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to then kill |cRXP_ENEMY_"Salty" John Thorpe|r in the Inn, |cRXP_ENEMY_Tom Hegger|r on the Dock, and |cRXP_ENEMY_Guard Mitchels|r in the Prison below the Keep
.complete 11794,3 
.goto BoreanTundra,58.57,67.13
.mob +"Salty" John Thorpe
.complete 11794,1 
.goto BoreanTundra,59.26,68.19
.mob +Tom Hegger
.complete 11794,2 
.goto BoreanTundra,56.9,72.2,12,0
.goto BoreanTundra,56.72,71.83
.mob +Guard Mitchells
.skipgossip 25248,2
.skipgossip 25827,1
.skipgossip 25828,1
.skipgossip
.timer 13,The Hunt is On RP
step
#completewith next
.goto BoreanTundra,58.21,62.82,70 >> Travel to Farshire
step
.goto BoreanTundra,58.21,62.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gerald|r
.turnin 11928 >>Turn in Farshire
.accept 11901 >>Accept Military? What Military?
.target Gerald Green
step
#completewith next
.goto BoreanTundra,56.7,57.2,40 >> Enter Farshire Mine
step
.goto BoreanTundra,56.81,55.56
>>Click the |cRXP_PICK_Plagued Grain|r on the ground
.turnin 11901 >>Turn in Military? What Military?
.accept 11902 >>Accept Pernicious Evidence
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gerald|r, |cRXP_FRIENDLY_Jeremiah|r, and |cRXP_FRIENDLY_Wendy|r
.turnin 11902 >>Turn in Pernicious Evidence
.accept 11903 >>Accept It's Time for Action
.goto BoreanTundra,58.21,62.82
.target +Gerald Green
.accept 11908 >>Accept Reference Material
.target +Jeremiah Hawning
.goto BoreanTundra,58.19,62.98
.accept 11913 >>Accept Take No Chances
.target +Wendy Darren
.goto BoreanTundra,58.28,62.77
step
#completewith next
.use 35491 >> |cRXP_WARN_Use|r |T135432:0|t[Wendy's Torch] |cRXP_WARN_to burn the|r |cRXP_PICK_Farshire Grains|r
>>Kill |cRXP_ENEMY_Plagued Scavengers|r
.complete 11913,1 
.complete 11903,1 
.mob +Plagued Scavenger
step
.goto BoreanTundra,55.75,58.32
>>Loot the |cRXP_LOOT_Fields, Factories and Workshops|r, it looks like a red book inside the burning house
.complete 11908,1 
step
#loop
.line BoreanTundra,56.84,61.57,55.59,62.11,54.56,60.67,55.89,60.80,55.32,59.32,55.81,57.69,56.83,58.39,56.84,61.57
.goto BoreanTundra,56.84,61.57,50,0
.goto BoreanTundra,55.59,62.11,50,0
.goto BoreanTundra,54.56,60.67,50,0
.goto BoreanTundra,55.89,60.80,50,0
.goto BoreanTundra,55.32,59.32,50,0
.goto BoreanTundra,55.81,57.69,50,0
.goto BoreanTundra,56.83,58.39,50,0
.goto BoreanTundra,56.84,61.57,50,0
.use 35491 >> |cRXP_WARN_Use|r |T135432:0|t[Wendy's Torch] |cRXP_WARN_to burn the|r |cRXP_PICK_Farshire Grains|r
>>Kill |cRXP_ENEMY_Plagued Scavengers|r
.complete 11913,1 
.complete 11903,1 
.mob +Plagued Scavenger
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wendy|r, |cRXP_FRIENDLY_Gerald|r and |cRXP_FRIENDLY_Jeremiah|r
.turnin 11913 >>Turn in Take No Chances
.target +Wendy Darren
.goto BoreanTundra,58.28,62.77,-1
.turnin 11903 >>Turn in It's Time for Action
.accept 11904 >>Accept Fruits of Our Labor
.goto BoreanTundra,58.21,62.82,-1
.target +Gerald Green
.turnin 11908 >>Turn in Reference Material
.accept 12035 >>Accept Repurposed Technology
.target +Jeremiah Hawning
.goto BoreanTundra,58.19,62.98,-1
step
.goto BoreanTundra,58.30,61.20,40,0
.goto BoreanTundra,56.52,62.19,40,0
.goto BoreanTundra,58.30,61.20
.use 35943 >> Kill |cRXP_ENEMY_Harvest Collectors|r. |cRXP_WARN_Use|r |T134520:0|t[Jeremiah's Tools] |cRXP_WARN_on their corpses|r
.complete 12035,1 
.mob Harvest Collector
step
#completewith next
.goto BoreanTundra,56.7,57.2,40 >> Enter Farshire Mine
step
.goto BoreanTundra,56.04,55.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_William's|r corpse
.turnin 11599 >>Turn in Thassarian, My Brother
.accept 11600 >>Accept The Late William Allerton
.target William Allerton
step
.goto BoreanTundra,57.99,53.54
>>Kill |cRXP_ENEMY_Captain Jacobs|r. Loot him for the |cRXP_LOOT_Cart Release Key|r
.collect 35705,1,11904,1 
.unitscan Captain Jacobs
step
.goto BoreanTundra,57.18,54.65
>>Click the |cRXP_PICK_Cart Release|r lever next to the |cRXP_FRIENDLY_Ore Cart|r
.complete 11904,1 
step
#completewith next
.goto BoreanTundra,56.7,57.2,40,0
.goto BoreanTundra,58.21,62.82,80 >> Travel toward |cRXP_FRIENDLY_Gerald|r and |cRXP_FRIENDLY_Jeremiah|r
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gerald|r and |cRXP_FRIENDLY_Jeremiah|r
.turnin 11904 >>Turn in Fruits of Our Labor
.accept 11962 >>Accept One Last Delivery
.target +Gerald Green
.goto BoreanTundra,58.21,62.82
.turnin 12035 >>Turn in Repurposed Technology
.goto BoreanTundra,58.19,62.98
.target +Jeremiah Hawning
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda|r
.turnin 11962 >>Turn in One Last Delivery
.accept 11963 >>Accept Weapons for Farshire
.goto BoreanTundra,57.32,66.64
.target Hilda Stoneforge
step
.goto BoreanTundra,58.75,68.42
>>|cRXP_WARN_Jump up on the cart then onto the bottom ledge of the window|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leryssa|r
.turnin 11600 >>Turn in The Late William Allerton
.accept 11601 >>Accept Lost and Found
.target Leryssa
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_James|r and then |cRXP_FRIENDLY_Yaala|r upstairs
.turnin 11601 >>Turn in Lost and Found
.accept 11603 >>Accept In Wine, Truth
.target +James Deacon
.goto BoreanTundra,58.29,68.05
.turnin 11794 >>Turn in The Hunt is On
.target +Vindicator Yaala
.goto BoreanTundra,58.55,67.29
step
.goto BoreanTundra,58.21,62.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gerald|r
.turnin 11963 >>Turn in Weapons for Farshire
.accept 11965 >>Accept Call to Arms!
.target Gerald Green
step
#completewith next
.goto BoreanTundra,57.32,59.39,30 >> Enter the Farshire Bell Tower
step
.goto BoreanTundra,57.32,59.39
>>|cRXP_WARN_Run up the stairs slightly|r
>>Click the |cRXP_PICK_Bell Rope|r hanging from the ceiling
.complete 11965,1 
step
.goto BoreanTundra,58.21,62.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gerald|r
.turnin 11965 >>Turn in Call to Arms!
.target Gerald Green
step << !wotlk
#completewith next
.goto BoreanTundra,50.07,30.72,80 >> Travel to Coldrock Quarry
step << !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Etaruk|r and |cRXP_FRIENDLY_Atkanok|r (|cRXP_WARN_the stone|r)
.accept 11612 >>Accept Reclaiming the Quarry
.goto BoreanTundra,54.29,36.09
.accept 11605 >>Accept The Honored Ancestors
.goto BoreanTundra,54.63,35.88
.target Etaruk
step << !wotlk
#completewith next
.goto BoreanTundra,54.1,34.5,0,0
.goto BoreanTundra,52.0,30.6,0
.goto BoreanTundra,50.9,33.4,0
>>Kill |cRXP_ENEMY_Beryl Treasure Hunters|r
.complete 11612,1 
.mob Beryl Treasure Hunter
step << !wotlk
>>Click the markers for |cRXP_PICK_"Elder Kesuk"|r, |cRXP_PICK_"Elder Takret"|r and |cRXP_PICK_"Elder Sagani"|r on the ground
.complete 11605,1 
.goto BoreanTundra,50.86,32.43
.complete 11605,3 
.goto BoreanTundra,52.31,31.13
.complete 11605,2 
.goto BoreanTundra,52.81,34.02
step << !wotlk
.goto BoreanTundra,54.1,34.5,70,0
.goto BoreanTundra,52.0,30.6,70,0
.goto BoreanTundra,50.9,33.4,70,0
.goto BoreanTundra,54.1,34.5
>>Kill |cRXP_ENEMY_Beryl Treasure Hunters|r
.complete 11612,1 
.mob Beryl Treasure Hunter
step << !wotlk
.goto BoreanTundra,54.63,35.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r
.turnin 11605 >>Turn in The Honored Ancestors
.accept 11607 >>Accept The Lost Spirits
step << !wotlk
.goto BoreanTundra,54.29,36.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Etaruk|r
.turnin 11612 >>Turn in Reclaiming the Quarry
.accept 11617 >>Accept Hampering Their Escape
.target Etaruk
step << !wotlk
#label cores
#completewith coresEnd
.waypoint BoreanTundra,51.7,31.6,15,0
.waypoint BoreanTundra,52.3,31.0,40,0
.waypoint BoreanTundra,51.0,32.3,40,0
.goto BoreanTundra,51.7,31.6,0,0
>>Kill |cRXP_ENEMY_Beryl Hounds|r. Loot them for their |T134337:0|t[|cRXP_LOOT_Cores of Malice|r]
.use 34711 >>|cRXP_WARN_Use the|r |T134337:0|t[|cRXP_LOOT_Cores of Malice|r] |cRXP_WARN_on |cRXP_FRIENDLY_Kaskala Craftsmen|r and|r |cRXP_FRIENDLY_Kaskala Shaman|r
.collect 34711,6,11607,0x3,-1 
.complete 11607,1 
.complete 11607,2 
.mob Beryl Hound
step << !wotlk
.goto BoreanTundra,52.6,35.5
>>Kill |cRXP_ENEMY_Beryl Reclaimers|r. Loot them for their |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r]
>>|cRXP_WARN_Stand at the edge of the cliff|r
.use 34772 >> |cRXP_WARN_Use the|r |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r] |cRXP_WARN_to destroy the|r |cRXP_PICK_East Platform|r
.collect 34772,3,11617,0x7,-1 
.complete 11617,1 
.mob Beryl Reclaimer
step << !wotlk
.goto BoreanTundra,50.3,34.1
>>Kill |cRXP_ENEMY_Beryl Reclaimers|r. Loot them for their |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r]
>>|cRXP_WARN_Stand at the edge of the cliff|r
.use 34772 >> |cRXP_WARN_Use the|r |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r] |cRXP_WARN_to destroy the|r |cRXP_PICK_West Platform|r
.collect 34772,3,11617,0x7,-1 
.complete 11617,3 
.mob Beryl Reclaimer
step << !wotlk
#label North
.goto BoreanTundra,52.6,32.4
>>Kill |cRXP_ENEMY_Beryl Reclaimers|r. Loot them for their |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r]
>>|cRXP_WARN_Stand directly below the|r |cRXP_PICK_North Platform|r
.use 34772 >> |cRXP_WARN_Use the|r |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r] |cRXP_WARN_to destroy the|r |cRXP_PICK_North Platform|r
.collect 34772,3,11617,0x7,-1 
.complete 11617,2 
.mob Beryl Reclaimer
step << !wotlk
#requires cores
#label coresEnd
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r and |cRXP_FRIENDLY_Etaruk|r
.turnin 11607 >>Turn in The Lost Spirits
.accept 11609 >>Accept Picking Up the Pieces
.goto BoreanTundra,54.63,35.88
.turnin 11617 >>Turn in Hampering Their Escape
.accept 11623 >>Accept A Visit to the Curator
.goto BoreanTundra,54.29,36.09
.target Etaruk
step << !wotlk
#completewith next
.goto BoreanTundra,51.2,36.5,50,0
.goto BoreanTundra,52.9,32.6,0
>>Loot the |cRXP_LOOT_Tuskarr Ritual Objects|r on the ground
>>|cRXP_WARN_They look like White and Blue Incense Holders or Anvils|r
.complete 11609,1 
step << !wotlk
.goto BoreanTundra,50.1,32.6
>>Kill |cRXP_ENEMY_Curator Insivius|r
.complete 11623,1 
.mob Curator Insivius
step << !wotlk
.goto BoreanTundra,52.9,32.6,70,0
.goto BoreanTundra,53.9,35.0,70,0
.goto BoreanTundra,50.9,33.2
>>Loot the |cRXP_LOOT_Tuskarr Ritual Objects|r on the ground
>>|cRXP_WARN_They look like White and Blue Incense Holders or Anvils|r
.complete 11609,1 
step << !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r and |cRXP_FRIENDLY_Etaruk|r
.turnin 11609 >>Turn in Picking Up the Pieces
.accept 11610 >>Accept Leading the Ancestors Home
.goto BoreanTundra,54.63,35.88
.turnin 11623 >>Turn in A Visit to the Curator
.goto BoreanTundra,54.29,36.09
.target Etaruk
step << !wotlk
.use 34715 >>|cRXP_WARN_Use the|r |T134378:0|t[Tuskarr Ritual Object] |cRXP_WARN_next to the markers for |cRXP_PICK_"Elder Sagani"|r, |cRXP_PICK_"Elder Takret"|r and|r |cRXP_PICK_"Elder Kesuk"|r
>>|cRXP_WARN_Do NOT wait for the RP|r
.complete 11610,2 
.goto BoreanTundra,52.81,34.04
.complete 11610,3 
.goto BoreanTundra,52.32,31.15
.complete 11610,1 
.goto BoreanTundra,50.85,32.40
step << !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r
.turnin 11610 >>Turn in Leading the Ancestors Home
.goto BoreanTundra,54.63,35.88
step
#completewith next
.goto BoreanTundra,57.05,44.32,120 >> Travel to the D.E.H.T.A. Encampment
step
.goto BoreanTundra,57.05,44.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Lathorius|r
.accept 11864 >>Accept A Mission Statement
.turnin 11864 >>Turn in A Mission Statement
.accept 11866 >>Accept Ears of Our Enemies
.accept 11876 >>Accept Help Those That Cannot Help Themselves
.target Arch Druid Lathorius
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Killinger|r patrolling around the statue, |cRXP_FRIENDLY_Zaza|r, and |cRXP_FRIENDLY_Cenius|r
.accept 11865 >>Accept Unfit for Death
.goto BoreanTundra,56.79,44.04
.target +Zaza
.accept 11869 >>Accept Happy as a Clam
.goto BoreanTundra,57.33,44.08
.target +Hierophant Cenius
.accept 11884 >>Accept Ned, Lord of Rhinos...
.goto BoreanTundra,57.17,43.59,7,0
.goto BoreanTundra,57.33,44.08,7,0
.goto BoreanTundra,57.05,44.32,7,0
.goto BoreanTundra,56.79,44.04
.target +Killinger the Den Watcher
step
#completewith LastTrap
.goto BoreanTundra,55.9,47.4,0
>>Kill |cRXP_ENEMY_Loot Crazed Poachers|r. Loot them for their |cRXP_LOOT_Ears|r
.complete 11866,1 
.mob Loot Crazed Poacher
.mob Loot Crazed Diver
step
#label LastTrap
#loop
.goto BoreanTundra,56.2,46.1,60,0
.goto BoreanTundra,57.7,46.4,60,0
.goto BoreanTundra,57.9,48.7,60,0
.goto BoreanTundra,56.5,50.2,60,0
.goto BoreanTundra,57.6,52.1,60,0
.goto BoreanTundra,57.6,52.1,0
>>|cRXP_WARN_Use the|r |T134263:0|t[Pile of Fake Furs] |cRXP_WARN_on the |cRXP_PICK_Caribou Traps|r on the ground|r
.use 35127 >> |cRXP_WARN_Do NOT wait for the RP|r
.complete 11865,1
.isOnQuest 11865
step
#loop
.goto BoreanTundra,51.7,47.0,70,0
.goto BoreanTundra,52.3,44.8,70,0
.goto BoreanTundra,52.9,43.0,70,0
.goto BoreanTundra,50.0,44.1,70,0
.goto BoreanTundra,50.0,44.1,0
>>Kill |cRXP_ENEMY_Loot Crazed Divers|r. Loot them for their |cRXP_LOOT_Ears|r
>>|cRXP_WARN_Do not go out of your way to collect all |cRXP_LOOT_Ears|r now. You will collect more later|r
.complete 11869,1 
.collect 35188,15,11866,1,1 
.mob Loot Crazed Diver
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Wooly Rhino Matriarchs|r, |cRXP_ENEMY_Wooly Rhino Bulls|r and |cRXP_ENEMY_Wooly Rhino Calves|r. Loot them for their |cRXP_LOOT_Chilled Meat|r
.complete 13088,1 
.isOnQuest 13088
.mob Wooly Rhino Matriarch
.mob Wooly Rhino Calf
.mob Wooly Rhino Bull
step
#loop
.goto BoreanTundra,48.6,40.0,50,0
.goto BoreanTundra,44.9,45.7,50,0
.goto BoreanTundra,46.7,45.6,50,0
.goto BoreanTundra,48.6,40.0,50,0
.goto BoreanTundra,44.9,45.7,0
.goto BoreanTundra,48.6,40.0,0
>>Kill |cRXP_ENEMY_Nedar, Lord of Rhinos|r and |cRXP_ENEMY_"Lunchbox"|r. Kill |cRXP_ENEMY_"Lunchbox"|r first
.complete 11884,2 
.complete 11884,1 
.unitscan Nedar, Lord of Rhinos
.mob "Lunchbox"
step
.goto BoreanTundra,48.6,40.0,50,0
.goto BoreanTundra,44.9,45.7,50,0
.goto BoreanTundra,46.7,45.6,50,0
.goto BoreanTundra,44.9,45.7,0
.goto BoreanTundra,48.6,40.0
>>Kill |cRXP_ENEMY_Wooly Rhino Matriarchs|r, |cRXP_ENEMY_Wooly Rhino Bulls|r and |cRXP_ENEMY_Wooly Rhino Calves|r. Loot them for their |cRXP_LOOT_Chilled Meat|r
.complete 13088,1 
.isOnQuest 13088
.mob Wooly Rhino Matriarch
.mob Wooly Rhino Calf
.mob Wooly Rhino Bull
step
#completewith next
.goto BoreanTundra,45.33,34.62,100 >> Travel to Amber Ledge
step
#sticky
#label ALFP
.goto BoreanTundra,45.33,34.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Surristrasz|r
.fp Amber Ledge >> Get the Amber Ledge flight path
.target Surristrasz
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donathan|r and |cRXP_FRIENDLY_Garren|r
.turnin 11575 >>Turn in Nick of Time
.accept 11587 >>Accept Prison Break
.goto BoreanTundra,45.26,33.35
.target +Librarian Donathan
.accept 11576 >>Accept Monitoring the Rift: Cleftcliff Anomaly
.goto BoreanTundra,44.98,33.38
.target +Librarian Garren
step
#requires ALFP
#completewith next
.goto BoreanTundra,54.29,36.09,100 >> Travel to Coldrock Quarry
step << wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Etaruk|r and |cRXP_FRIENDLY_Atkanok|r (|cRXP_WARN_the stone|r)
.accept 11612 >>Accept Reclaiming the Quarry
.goto BoreanTundra,54.29,36.09
.accept 11605 >>Accept The Honored Ancestors
.goto BoreanTundra,54.63,35.88
.target Etaruk
step
.goto BoreanTundra,55.5,41.1,60,0
.goto BoreanTundra,55.3,38.4,60,0
.goto BoreanTundra,57.6,38.4,60,0
.goto BoreanTundra,59.5,31.3,60,0
.goto BoreanTundra,55.4,27.7,60,0
.goto BoreanTundra,53.3,28.0,60,0
.goto BoreanTundra,56.8,37.7
.use 35228 >> |cRXP_WARN_Use the|r |T133539:0|t[D.E.H.T.A. Trap Smasher] |cRXP_WARN_to free|r |cRXP_FRIENDLY_Trapped Mammoth Calves|r
>>|cRXP_WARN_Do NOT wait for the RP|r
.complete 11876,1,7 
.target Trapped Mammoth Calf
step
.goto BoreanTundra,55.5,41.1,60,0
.goto BoreanTundra,55.3,38.4,60,0
.goto BoreanTundra,57.6,38.4,60,0
.goto BoreanTundra,59.5,31.3,60,0
.goto BoreanTundra,55.4,27.7,60,0
.goto BoreanTundra,53.3,28.0,60,0
.goto BoreanTundra,56.8,37.7
.cast 46201 >> |cRXP_WARN_Use the|r |T133539:0|t[D.E.H.T.A. Trap Smasher] |cRXP_WARN_to free|r |cRXP_FRIENDLY_Trapped Mammoth Calves|r
>>|cRXP_WARN_Do NOT wait for the RP|r
.use 35228
.isOnQuest 11876
.target Trapped Mammoth Calf
step
>>|cRXP_WARN_If you have the |T132311:0|t[Animal Blood] debuff, jump in some water to remove it or wait for it to expire before going into the camp, other wise the guards will attack you|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Killinger|r, |cRXP_FRIENDLY_Cenius|r, |cRXP_FRIENDLY_Lathorius|r, and |cRXP_FRIENDLY_Zaza|r
.turnin 11869 >>Turn in Happy as a Clam
.accept 11870 >>Accept The Abandoned Reach
.goto BoreanTundra,57.33,44.08
.turnin 11876 >>Turn in Help Those That Cannot Help Themselves
.goto BoreanTundra,57.05,44.32
.turnin 11865 >>Turn in Unfit for Death
.accept 11868 >>Accept The Culler Cometh
.goto BoreanTundra,56.79,44.04
.target +Zaza
.turnin 11884 >>Turn in Ned, Lord of Rhinos...
.goto BoreanTundra,57.17,43.59,20,0
.goto BoreanTundra,57.33,44.08,15,0
.goto BoreanTundra,57.05,44.32,15,0
.goto BoreanTundra,56.79,44.04
.target +Killinger the Den Watcher
.target Hierophant Cenius
.target Arch Druid Lathorius
step
.goto BoreanTundra,57.2,56.5
>>Kill |cRXP_ENEMY_Karen "I Don't Caribou" the Culler|r
.complete 11868,1 
.mob Karen "I Don't Caribou" the Culler
step
.goto BoreanTundra,57.80,55.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liandra|r
.turnin 11870 >>Turn in The Abandoned Reach
.accept 11871 >>Accept Not On Our Watch
.target Hierophant Liandra
step
#completewith Liandra
.goto BoreanTundra,60.8,63.1,0
>>Kill |cRXP_ENEMY_Northsea Thugs|r and |cRXP_ENEMY_Northsea Mercenaries|r. Loot them for their |cRXP_LOOT_Ears|r
.complete 11866,1 
.mob Northsea Mercenary
.mob Northsea Thug
step
.goto BoreanTundra,59.2,55.6,50,0
.goto BoreanTundra,58.6,58.3,50,0
.goto BoreanTundra,60.3,58.0,50,0
.goto BoreanTundra,59.7,60.5,50,0
.goto BoreanTundra,60.0,64.1,50,0
.goto BoreanTundra,61.8,63.5
>>Loot the |cRXP_LOOT_Shipments of Animal Parts|r on the ground
.complete 11871,1 
step
#label Liandra
.goto BoreanTundra,57.80,55.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liandra|r
.turnin 11871 >>Turn in Not On Our Watch
.accept 11872 >>Accept The Nefarious Clam Master...
.target Hierophant Liandra
step
.goto BoreanTundra,59.2,55.6,50,0
.goto BoreanTundra,58.6,58.3,50,0
.goto BoreanTundra,60.3,58.0,50,0
.goto BoreanTundra,59.7,60.5,50,0
.goto BoreanTundra,60.0,64.1,50,0
.goto BoreanTundra,61.8,63.5
>>Kill |cRXP_ENEMY_Northsea Thugs|r and |cRXP_ENEMY_Northsea Mercenaries|r. Loot them for their |cRXP_LOOT_Ears|r
.complete 11866,1 
.mob Northsea Mercenary
.mob Northsea Thug
step
#sticky
#label wine
.goto BoreanTundra,61.90,65.67
>>Open the |cRXP_PICK_Wine Crate|r underwater. Loot it for the |cRXP_LOOT_Kul Tiras Wine|r
.complete 11603,1 
step
.goto BoreanTundra,61.0,66.5,30,0
.goto BoreanTundra,62.5,66.2
>>Kill |cRXP_ENEMY_Clam Master K|r underwater
.complete 11872,1 
.unitscan Clam Master K
step
#requires wine
#completewith next
.goto BoreanTundra,58.5,68.2,100 >> Travel to Valiance Keep
step
.goto BoreanTundra,58.53,68.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Colburn|r
.turnin 11603 >>Turn in In Wine, Truth
.accept 11604 >>Accept A Deserter
.target Old Man Colburn
step
.goto BoreanTundra,57.93,71.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rollick|r
.turnin 13088 >> Turn in Northern Cooking
.isQuestComplete 13088
.skill cooking,<350,1
.target Rollick MacKreel
step
#completewith next
.goto BoreanTundra,56.9,72.2,10 >> Travel to Valiance Keep Prison
step
.goto BoreanTundra,56.68,71.44
>>Run down stairs to the Prison
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brau|r
.turnin 11604 >>Turn in A Deserter
.accept 11932 >>Accept Cowards and Fools
.target Private Brau
step
#completewith next
.goto BoreanTundra,56.9,72.2,10,0
.goto BoreanTundra,58.97,68.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tomas|r
.fly Amber Ledge >> Fly to Amber Ledge
.target Tomas Riverwell
step
>>Kill |cRXP_ENEMY_Beryl Mage Hunters|r. Loot them for a |T134242:0|t[|cRXP_LOOT_Beryl Prison Key|r]
>>|cRXP_WARN_Use the|r |T134242:0|t[|cRXP_LOOT_Beryl Prison Key|r] |cRXP_WARN_on a|r |cRXP_PICK_Arcane Prison|r
>>|cRXP_WARN_Continue opening |cRXP_PICK_Arcane Prisons|r until you are successful in saving an|r |cRXP_FRIENDLY_Arcane Prisoner|r
.collect 34688,1,11587,0x1,-1 
#loop
.line BoreanTundra,42.60,36.75,40.43,39.16,41.78,42.53,42.60,36.75
.goto BoreanTundra,42.60,36.75,20,0
.goto BoreanTundra,40.43,39.16,20,0
.goto BoreanTundra,41.78,42.53,20,0
.goto BoreanTundra,42.60,36.75,20,0
.complete 11587,1 
.goto BoreanTundra,42.60,36.75,40,0
.goto BoreanTundra,40.43,39.16,40,0
.goto BoreanTundra,41.78,42.53
.mob Beryl Mage Hunter
step
#completewith next
.groundgoto BoreanTundra,45.03,37.97,60,0
.goto BoreanTundra,45.26,33.35,50 >> Travel toward |cRXP_FRIENDLY_Donathan|r
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donathan|r
.turnin 11587 >>Turn in Prison Break
.accept 11590 >>Accept Abduction
.goto BoreanTundra,45.26,33.35
.target Librarian Donathan
step
.goto BoreanTundra,43.2,36.6,60,0
.goto BoreanTundra,41.6,37.4
.use 34691 >>|cRXP_WARN_Damage a |cRXP_ENEMY_Beryl Sorcerer|r to 50% or less health. Do NOT kill the|r |cRXP_ENEMY_Beryl Sorcerer|r
>>|cRXP_WARN_Channel the|r |T133273:0|t[Arcane Binder] |cRXP_WARN_to capture the |cRXP_ENEMY_Beryl Sorcerer|r once it's weakened|r
.complete 11590,1 
.mob Beryl Sorcerer
step
#completewith next
.groundgoto BoreanTundra,45.03,37.97,60,0
.goto BoreanTundra,45.26,33.35,50 >> Travel toward |cRXP_FRIENDLY_Donathan|r
>>|cRXP_WARN_You can ignore the |cRXP_ENEMY_Beryl Sorcerer|r. It will continue to follow you|r
step
.goto BoreanTundra,45.26,33.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donathan|r
.turnin 11590 >>Turn in Abduction
.accept 11646 >>Accept The Borean Inquisition
.target Librarian Donathan
step
#completewith next
.goto BoreanTundra,46.60,32.94,40 >> Enter the Mage Tower. Run up to the first floor
step
.goto BoreanTundra,46.32,32.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Normantis|r
.turnin 11646 >>Turn in The Borean Inquisition
.accept 11648 >>Accept The Art of Persuasion
.target Librarian Normantis
step
.goto BoreanTundra,46.33,32.92
.use 34811 >> |cRXP_WARN_Use the|r |T135470:0|t[Neural Needler] |cRXP_WARN_on the |cRXP_ENEMY_Imprisoned Beryl Sorcerer|r next to |cRXP_FRIENDLY_Normantis|r until the objective completes|r
.complete 11648,1 
.mob Imprisoned Beryl Sorcerer
step
.goto BoreanTundra,46.32,32.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Normantis|r
.turnin 11648 >>Turn in The Art of Persuasion
.accept 11663 >>Accept Sharing Intelligence
.target Librarian Normantis
step
.goto BoreanTundra,45.26,33.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donathan|r outside
.turnin 11663 >>Turn in Sharing Intelligence
.accept 11671 >>Accept A Race Against Time
.target Librarian Donathan
step
#completewith next
.goto BoreanTundra,41.30,41.79,70,0
.goto BoreanTundra,39.85,42.18,50,0 << !Shaman !DK
.goto BoreanTundra,38.46,43.37,50,0 << !Shaman !DK
.goto BoreanTundra,35.15,43.52,50,0 << !Shaman !DK
.goto BoreanTundra,34.44,42.35,50 >> Travel to The Westrift
>>|cRXP_WARN_Cast |T135863:0|t[Water Walking] to cross the water|r << Shaman
>>|cRXP_WARN_Cast |T237528:0|t[Path of Frost] to cross the water|r << DK
.skill coldweatherflying,1,1
step
.goto BoreanTundra,34.44,42.35
.use 34669 >> |cRXP_WARN_Use the|r |T133015:0|t[Arcanometer] |cRXP_WARN_at the |cRXP_PICK_Cleftcliff Anomaly|r on the ground|r
.complete 11576,1 
.skill coldweatherflying,1,1
step
#completewith next
.goto BoreanTundra,34.44,42.35,100 >> Travel to The Westrift
.skill coldweatherflying,<1,1
step
.goto BoreanTundra,34.44,42.35
.use 34669 >> |cRXP_WARN_Use the|r |T133015:0|t[Arcanometer] |cRXP_WARN_at the |cRXP_PICK_Cleftcliff Anomaly|r on the ground|r
.complete 11576,1 
.skill coldweatherflying,<1,1
step
#completewith next
.goto BoreanTundra,35.15,43.52,40,0 << !Shaman !DK
.goto BoreanTundra,38.46,43.37,50,0 << !Shaman !DK
.goto BoreanTundra,39.85,42.18,50,0 << !Shaman !DK
.goto BoreanTundra,41.30,41.79,70,0
.goto BoreanTundra,41.80,39.16,100 >> Travel back to Beryl Point
>>|cRXP_WARN_Cast |T135863:0|t[Water Walking] to cross the water|r << Shaman
>>|cRXP_WARN_Cast |T237528:0|t[Path of Frost] to cross the water|r << DK
.skill coldweatherflying,1,1
step
#completewith next
.cast 45780 >> |cRXP_WARN_Use the|r |T133709:0|t[Beryl Shield Detonator] |cRXP_WARN_to disable |cRXP_ENEMY_Inquisitor Salrand's|r shield|r
.use 34897
.skill coldweatherflying,1,1
step
.goto BoreanTundra,41.80,39.16
.use 34897 >> Kill |cRXP_ENEMY_Inquisitor Salrand|r. Loot |cRXP_PICK_Salrand's Lockbox|r that she drops on the ground for |cRXP_LOOT_Salrand's Broken Key|r
.complete 11671,1 
.mob Inquisitor Salrand
.skill coldweatherflying,1,1
step
#completewith next
.goto BoreanTundra,41.80,39.16,100 >> Travel to Beryl Point
.skill coldweatherflying,<1,1
step
#completewith next
.cast 45780 >> |cRXP_WARN_Use the|r |T133709:0|t[Beryl Shield Detonator] |cRXP_WARN_to disable |cRXP_ENEMY_Inquisitor Salrand's|r shield|r
.use 34897
.skill coldweatherflying,<1,1
step
.goto BoreanTundra,41.80,39.16
.use 34897 >> Kill |cRXP_ENEMY_Inquisitor Salrand|r. Loot |cRXP_PICK_Salrand's Lockbox|r that she drops on the ground for |cRXP_LOOT_Salrand's Broken Key|r
.complete 11671,1 
.mob Inquisitor Salrand
.skill coldweatherflying,<1,1
step
#completewith next
.groundgoto BoreanTundra,45.03,37.97,60,0
.goto BoreanTundra,45.26,33.35,60 >> Travel to Amber Ledge
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garren|r, |cRXP_FRIENDLY_Donathan|r and |cRXP_FRIENDLY_Surristrasz|r
.turnin 11576 >>Turn in Monitoring the Rift: Cleftcliff Anomaly
.accept 11582 >>Accept Monitoring the Rift: Sundered Chasm
.goto BoreanTundra,44.98,33.38
.turnin 11671 >>Turn in A Race Against Time
.accept 11679 >>Accept Reforging the Key
.goto BoreanTundra,45.26,33.35
.turnin 11679 >>Turn in Reforging the Key
.accept 11680 >>Accept Taking Wing
.goto BoreanTundra,45.33,34.62
.target Librarian Donathan
.target Librarian Garren
.target Surristrasz
step
.goto BoreanTundra,46.38,37.31
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anzim|r
.turnin 11680 >>Turn in Taking Wing
.accept 11681 >>Accept Rescuing Evanor
.timer 53,Rescuing Evanor RP
.target Warmage Anzim
step
.goto BoreanTundra,43.01,43.86,-1
.goto BoreanTundra,46.37,32.39,-1
>>|cRXP_WARN_Wait for the flight and RP to finish. You will get teleported to the quest turn in once all RP completes|r
>>|cRXP_WARN_If the event didn't start, abandon Rescuing Evanor and Accept it again|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Evanor|r
.turnin 11681 >>Turn in Rescuing Evanor
.accept 11682 >>Accept Dragonspeak
.target Archmage Evanor
step
.goto BoreanTundra,43.83,29.41
>>|cRXP_WARN_Carefully descend the mountain or jump into the water below|r
.use 34669 >> |cRXP_WARN_Use the|r |T133015:0|t[Arcanometer] |cRXP_WARN_at the |cRXP_PICK_Sundered Chasm|r on the sea floor|r
.complete 11582,1 
.skill coldweatherflying,1,1
step
.goto BoreanTundra,43.83,29.41
>>|cRXP_WARN_Fly into the water below|r
.use 34669 >> |cRXP_WARN_Use the|r |T133015:0|t[Arcanometer] |cRXP_WARN_at the |cRXP_PICK_Sundered Chasm|r on the sea floor|r
.complete 11582,1 
.skill coldweatherflying,<1,1
step << wotlk
#completewith next
.groundgoto BoreanTundra,45.5,31.2,20,0
.groundgoto BoreanTundra,47.12,29.16,20,0
.goto BoreanTundra,50.07,30.72,80 >> Travel to Coldrock Quarry
step << wotlk
#completewith next
.goto BoreanTundra,54.1,34.5,0,0
.goto BoreanTundra,52.0,30.6,0
.goto BoreanTundra,50.9,33.4,0
>>Kill |cRXP_ENEMY_Beryl Treasure Hunters|r
.complete 11612,1 
.mob Beryl Treasure Hunter
step << wotlk
>>Click the markers for |cRXP_PICK_"Elder Kesuk"|r, |cRXP_PICK_"Elder Takret"|r and |cRXP_PICK_"Elder Sagani"|r on the ground
.complete 11605,1 
.goto BoreanTundra,50.86,32.43
.complete 11605,3 
.goto BoreanTundra,52.31,31.13
.complete 11605,2 
.goto BoreanTundra,52.81,34.02
step << wotlk
.goto BoreanTundra,54.1,34.5,70,0
.goto BoreanTundra,52.0,30.6,70,0
.goto BoreanTundra,50.9,33.4,70,0
.goto BoreanTundra,54.1,34.5
>>Kill |cRXP_ENEMY_Beryl Treasure Hunters|r
.complete 11612,1 
.mob Beryl Treasure Hunter
step << wotlk
.goto BoreanTundra,54.63,35.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r
.turnin 11605 >>Turn in The Honored Ancestors
.accept 11607 >>Accept The Lost Spirits
step << wotlk
.goto BoreanTundra,54.29,36.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Etaruk|r
.turnin 11612 >>Turn in Reclaiming the Quarry
.accept 11617 >>Accept Hampering Their Escape
.target Etaruk
step << wotlk
#label cores
#completewith coresEnd
.waypoint BoreanTundra,51.7,31.6,15,0
.waypoint BoreanTundra,52.3,31.0,40,0
.waypoint BoreanTundra,51.0,32.3,40,0
.goto BoreanTundra,51.7,31.6,0,0
>>Kill |cRXP_ENEMY_Beryl Hounds|r. Loot them for their |T134337:0|t[|cRXP_LOOT_Cores of Malice|r]
.use 34711 >>|cRXP_WARN_Use the|r |T134337:0|t[|cRXP_LOOT_Cores of Malice|r] |cRXP_WARN_on |cRXP_FRIENDLY_Kaskala Craftsmen|r and|r |cRXP_FRIENDLY_Kaskala Shaman|r
.collect 34711,6,11607,0x3,-1 
.complete 11607,1 
.complete 11607,2 
.mob Beryl Hound
step << wotlk
.goto BoreanTundra,52.6,35.5
>>Kill |cRXP_ENEMY_Beryl Reclaimers|r. Loot them for their |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r]
>>|cRXP_WARN_Stand at the edge of the cliff|r
.use 34772 >> |cRXP_WARN_Use the|r |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r] |cRXP_WARN_to destroy the|r |cRXP_PICK_East Platform|r
.collect 34772,3,11617,0x7,-1 
.complete 11617,1 
.mob Beryl Reclaimer
step << wotlk
.goto BoreanTundra,50.3,34.1
>>Kill |cRXP_ENEMY_Beryl Reclaimers|r. Loot them for their |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r]
>>|cRXP_WARN_Stand at the edge of the cliff|r
.use 34772 >> |cRXP_WARN_Use the|r |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r] |cRXP_WARN_to destroy the|r |cRXP_PICK_West Platform|r
.collect 34772,3,11617,0x7,-1 
.complete 11617,3 
.mob Beryl Reclaimer
step << wotlk
#label North
.goto BoreanTundra,52.6,32.4
>>Kill |cRXP_ENEMY_Beryl Reclaimers|r. Loot them for their |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r]
>>|cRXP_WARN_Stand directly below the|r |cRXP_PICK_North Platform|r
.use 34772 >> |cRXP_WARN_Use the|r |T133717:0|t[|cRXP_LOOT_Gnomish Grenades|r] |cRXP_WARN_to destroy the|r |cRXP_PICK_North Platform|r
.collect 34772,3,11617,0x7,-1 
.complete 11617,2 
.mob Beryl Reclaimer
step << wotlk
#requires cores
#label coresEnd
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r and |cRXP_FRIENDLY_Etaruk|r
.turnin 11607 >>Turn in The Lost Spirits
.accept 11609 >>Accept Picking Up the Pieces
.goto BoreanTundra,54.63,35.88
.turnin 11617 >>Turn in Hampering Their Escape
.accept 11623 >>Accept A Visit to the Curator
.goto BoreanTundra,54.29,36.09
.target Etaruk
step << wotlk
#completewith next
.goto BoreanTundra,51.2,36.5,50,0
.goto BoreanTundra,52.9,32.6,0
>>Loot the |cRXP_LOOT_Tuskarr Ritual Objects|r on the ground
>>|cRXP_WARN_They look like White and Blue Incense Holders or Anvils|r
.complete 11609,1 
step << wotlk
.goto BoreanTundra,50.1,32.6
>>Kill |cRXP_ENEMY_Curator Insivius|r
.complete 11623,1 
.mob Curator Insivius
step << wotlk
.goto BoreanTundra,52.9,32.6,70,0
.goto BoreanTundra,53.9,35.0,70,0
.goto BoreanTundra,50.9,33.2
>>Loot the |cRXP_LOOT_Tuskarr Ritual Objects|r on the ground
>>|cRXP_WARN_They look like White and Blue Incense Holders or Anvils|r
.complete 11609,1 
step << wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r and |cRXP_FRIENDLY_Etaruk|r
.turnin 11609 >>Turn in Picking Up the Pieces
.accept 11610 >>Accept Leading the Ancestors Home
.goto BoreanTundra,54.63,35.88
.turnin 11623 >>Turn in A Visit to the Curator
.goto BoreanTundra,54.29,36.09
.target Etaruk
step << wotlk
.use 34715 >>|cRXP_WARN_Use the|r |T134378:0|t[Tuskarr Ritual Object] |cRXP_WARN_next to the markers for |cRXP_PICK_"Elder Sagani"|r, |cRXP_PICK_"Elder Takret"|r and|r |cRXP_PICK_"Elder Kesuk"|r
>>|cRXP_WARN_Do NOT wait for the RP|r
.complete 11610,2 
.goto BoreanTundra,52.81,34.04
.complete 11610,3 
.goto BoreanTundra,52.32,31.15
.complete 11610,1 
.goto BoreanTundra,50.85,32.40
step << wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atkanok|r
.turnin 11610 >>Turn in Leading the Ancestors Home
.goto BoreanTundra,54.63,35.88
step
#completewith next
.goto BoreanTundra,57.05,44.32,120 >> Travel to the D.E.H.T.A. Encampment
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaza|r, |cRXP_FRIENDLY_Lathorius|r and |cRXP_FRIENDLY_Cenius|r
.turnin 11868 >>Turn in The Culler Cometh
.goto BoreanTundra,56.80,44.04
.turnin 11866 >>Turn in Ears of Our Enemies
.accept 11878 >>Accept Khu'Nok Will Know
.goto BoreanTundra,57.05,44.32
.turnin 11872 >>Turn in The Nefarious Clam Master...
.goto BoreanTundra,57.33,44.08
.target Hierophant Cenius
.target Zaza
.target Arch Druid Lathorius
step << skip
.goto BoreanTundra,57.0,44.3,0
.goto BoreanTundra,59.25,30.83
>>Escort the |cRXP_FRIENDLY_Mammoth Calf|r north to |cRXP_FRIENDLY_Khu'Nok|r. |cRXP_WARN_Don't travel out of render range (100 yards) as this will despawn the Calf|r.
>>|cRXP_WARN_If the Calf despawns, abandon and retake the quest from|r |cRXP_FRIENDLY_Lathorius|r
.complete 11878,1 
.target Khu'nok the Behemoth
.target Arch Druid Lathorius
step
#completewith next
.goto BoreanTundra,59.43,30.38,80 >> Travel toward |cRXP_FRIENDLY_Khu'nok|r
step
.goto BoreanTundra,59.43,30.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khu'nok|r
.turnin 11878 >>Turn in Khu'nok Will Know
.accept 11879 >>Accept Kaw the Mammoth Destroyer
.target Khu'nok the Behemoth
step
#completewith next
.goto BoreanTundra,53.7,24.4
.vehicle >>Click on a |cRXP_FRIENDLY_Wooly Mammoth Bull|r to Mount it
.unitscan Wooly Mammoth Bull
step
.goto BoreanTundra,53.84,24.08
>>Engage |cRXP_ENEMY_Kaw the Mammoth Destroyer|r by running near him
>>|cRXP_WARN_Cast|r |T132337:0|t[Mammoth Charge] (2) |cRXP_WARN_to deal damage and stun for 3 seconds|r
>>|cRXP_WARN_Cast|r |T132255:0|t[Mammoth Trample] (1) |cRXP_WARN_to deal significant damage when in melee range|r
>>|cRXP_WARN_Alternatively, if your damage is high, you can kill |cRXP_ENEMY_Kaw the Mammoth Destroyer|r faster whilst dismounted|r
>>Kill |cRXP_ENEMY_Kaw the Mammoth Destroyer|r. Dismount the |cRXP_FRIENDLY_Wooly Mammoth Bull|r. Loot |cRXP_LOOT_Kaw's War Halberd|r on the ground
.complete 11879,1 
.mob Kaw the Mammoth Destroyer
step
#completewith next
.goto BoreanTundra,56.56,20.07,100 >> Travel to Fizzcrank Airstrip
step
.goto BoreanTundra,56.56,20.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kara|r
.fp Fizzcrank >> Get the Fizzcrank Airstrip Flight Path
.target Kara Thricestar
step
#completewith next
.goto BoreanTundra,57.05,44.32,120 >> Travel to the D.E.H.T.A. Encampment
step
.goto BoreanTundra,57.05,44.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lathorious|r
.turnin 11879 >>Turn in Kaw the Mammoth Destroyer
.accept 11892 >>Accept The Assassination of Harold Lane
.target Arch Druid Lathorius
step
.goto BoreanTundra,49.90,41.50
.use 35293 >>Kill |cRXP_ENEMY_Harold Lane|r
>>|cRXP_WARN_Use the|r |T134229:0|t[Cenarion Horn] |cRXP_WARN_to summon |cRXP_FRIENDLY_Stampeding Mammoths|r which will deal significant damage to |cRXP_ENEMY_Harold Lane|r. Move away from any traps he places
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << wotlk
.complete 11892,1 
.unitscan Harold Lane
.isOnQuest 11892
step
.goto BoreanTundra,57.05,44.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lathorious|r
.turnin 11892 >>Turn in The Assassination of Harold Lane
.isQuestComplete 11892
.target Arch Druid Lathorius
step
#sticky
#label AbandonAss
.goto BoreanTundra,63.8,46.1
.abandon 11892 >> Abandon The Assassination of Harold Lane
step
#completewith next
.goto BoreanTundra,63.80,46.12,80 >> Travel to Kaskala
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ataika|r and |cRXP_FRIENDLY_Utaik|r
.turnin 11932 >>Turn in Cowards and Fools
.accept 12086 >>Accept The Son of Karkut
.accept 11949 >>Accept Not Without a Fight!
.goto BoreanTundra,63.80,46.12
.daily 11945 >>Accept Preparing for the Worst
.goto BoreanTundra,63.95,45.72
.target Ataika
.target Utaik
step
#requires AbandonAss
#completewith Raiders
.goto BoreanTundra,66.2,45.9,0
.goto BoreanTundra,63.7,52.2,0
>>Loot the |cRXP_LOOT_Kaskala Supplies|r on the ground
.complete 11945,1 
.isOnQuest 11945
step << !DK
#requires AbandonAss
.goto BoreanTundra,67.3,47.7,60,0
.goto BoreanTundra,63.61,53.93
>>Kill |cRXP_ENEMY_Kvaldir Raiders|r
.complete 11949,1 
.skill coldweatherflying,1,1
.mob Kvaldir Raider
step
#requires AbandonAss
#label Raiders
.goto BoreanTundra,67.3,47.7,60,0
.goto BoreanTundra,63.61,53.93,60,0
.goto BoreanTundra,66.38,55.90,60,0
.goto BoreanTundra,67.96,56.69
>>Kill |cRXP_ENEMY_Kvaldir Raiders|r
.complete 11949,1 
.skill coldweatherflying,<1,1 << !DK
.mob Kvaldir Raider
step
.goto BoreanTundra,67.3,47.7,60,0
.goto BoreanTundra,63.61,53.93,60,0
.goto BoreanTundra,66.38,55.90,60,0
.goto BoreanTundra,67.96,56.69
>>Loot the |cRXP_LOOT_Kaskala Supplies|r on the ground
.complete 11945,1 
.isOnQuest 11945
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ataika|r and |cRXP_FRIENDLY_Utaik|r
.turnin 11949 >>Turn in Not Without a Fight!
.accept 11950 >>Accept Muahit's Wisdom
.goto BoreanTundra,63.80,46.12
.turnin 11945 >>Turn in Preparing for the Worst
.goto BoreanTundra,63.95,45.72
.isOnQuest 11945
.target Ataika
.target Utaik
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ataika|r
.turnin 11949 >>Turn in Not Without a Fight!
.accept 11950 >>Accept Muahit's Wisdom
.goto BoreanTundra,63.80,46.12
.target Ataika
step
#completewith next
.goto BoreanTundra,67.21,54.86,100 >> Travel toward |cRXP_FRIENDLY_Muahit|r
step
.goto BoreanTundra,67.21,54.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muahit|r
.turnin 11950 >>Turn in Muahit's Wisdom
.accept 11961 >>Accept Spirits Watch Over Us
.target Elder Muahit
step
.goto BoreanTundra,67.65,50.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iruk's|r corpse underwater
.complete 11961,1 
.skipgossip
.target Iruk
step
.goto BoreanTundra,67.21,54.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muahit|r
.turnin 11961 >>Turn in Spirits Watch Over Us
.accept 11968 >>Accept The Tides Turn
.target Elder Muahit
step
.goto BoreanTundra,67.41,56.87
>>Kill |cRXP_ENEMY_Heigarr the Horrible|r
>>|cRXP_WARN_You may not get credit the first time if his health is below 50%|r
.complete 11968,1 
.unitscan Heigarr the Horrible
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muahit|r and |cRXP_FRIENDLY_Hotawa|r
.turnin 11968 >>Turn in The Tides Turn
.goto BoreanTundra,67.21,54.86
.accept 12117 >>Accept Travel to Moa'ki Harbor
.goto BoreanTundra,67.27,54.86
.target Elder Muahit
.target Hotawa
step << skip
.goto BoreanTundra,78.5,51.5
>>Travel to Unu'pe
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilko|r
.fp Unu'pe >> Get the Unu'pe flight path
.target Bilko Driftspark
step
#completewith next
.goto BoreanTundra,82.01,46.42,100 >> Travel to Death's Stand
step
.goto BoreanTundra,82.01,46.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Venn|r
.turnin 12086 >>Turn in The Son of Karkut
.accept 11944 >>Accept Surrounded!
.target Corporal Venn
step
#level 71
.goto BoreanTundra,82.17,46.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Casey|r
.accept 12157 >>Accept The Lost Courier
.target Private Casey
step
.goto BoreanTundra,81.46,43.80,50,0
.goto BoreanTundra,82.78,43.69,50,0
.goto BoreanTundra,83.24,40.40,50,0
.goto BoreanTundra,81.46,43.80
>>Kill |cRXP_ENEMY_Ziggurat Defenders|r
.complete 11944,1 
.mob Ziggurat Defender
step
.goto BoreanTundra,82.01,46.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Venn|r
.turnin 11944 >>Turn in Surrounded!
.accept 12088 >>Accept Thassarian, the Death Knight
.target Corporal Venn
step
#completewith next
.goto BoreanTundra,84.7,41.0,30 >> Travel toward |cRXP_FRIENDLY_Thassarian|r inside the Ziggurat
step
.goto BoreanTundra,84.80,41.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thassarian|r
.turnin 12088 >>Turn in Thassarian, the Death Knight
.accept 11956 >>Accept Finding the Phylactery
.target Thassarian
step
.goto BoreanTundra,85.40,33.34
>>Click the |cRXP_PICK_Frozen Phylactery|r underwater to summon the |cRXP_ENEMY_Phylactery Guardian|r
>>Kill the |cRXP_ENEMY_Phylactery Guardian|r. Loot it for |cRXP_LOOT_Tanathal's Phylactery|r
.complete 11956,1 
.mob Phylactery Guardian
step
.goto BoreanTundra,84.80,41.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thassarian|r
.turnin 11956 >>Turn in Finding the Phylactery
.accept 11938 >>Accept Buying Some Time
.target Thassarian
step
.goto BoreanTundra,84.42,32.06,60,0
.goto BoreanTundra,83.35,30.70,60,0
.goto BoreanTundra,85.28,28.18,60,0
.goto BoreanTundra,86.85,28.94,60,0
.goto BoreanTundra,88.14,27.45,60,0
.goto BoreanTundra,84.49,24.31,60,0
.goto BoreanTundra,85.7,27.3
.use 35944 >>Kill the |cRXP_ENEMY_En'kilah|r
>>|cRXP_WARN_Use|r |T133730:0|t[Lurid's Bones] |cRXP_WARN_to summon |cRXP_FRIENDLY_Lurid|r to help you kill the|r |cRXP_ENEMY_En'kilah|r
.complete 11938,1 
.mob En'kilah Necromancer
.mob En'kilah Abomination
.mob En'kilah Crypt Fiend
.mob En'kilah Gargoyle
.mob En'kilah Ghoul
.mob En'kilah Necrolord
step
.goto BoreanTundra,84.80,41.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thassarian|r
.turnin 11938 >>Turn in Buying Some Time
.accept 11942 >>Accept Words of Power
.target Thassarian
step
#completewith next
.groundgoto BoreanTundra,85.0,28.9,70,0
.goto BoreanTundra,88.59,28.30,40 >> Travel to the Spire of Pain in En'kilah
step
.goto BoreanTundra,89.38,28.86
>>Kill the |cRXP_ENEMY_Mystical Webbings|r to free |cRXP_ENEMY_High Priest Talet-Kha|r
>>Kill |cRXP_ENEMY_High Priest Talet-Kha|r. Loot him for his |cRXP_LOOT_Scroll|r
.complete 11942,3 
.mob High Priest Talet-Kha
.mob Mystical Webbing
step
#completewith next
.groundgoto BoreanTundra,87.7,22.0,40,0
.goto BoreanTundra,88.68,21.72,25 >> Travel to the Spire of Blood in En'kilah. Enter through the side entrance
step
.goto BoreanTundra,88.05,20.94
>>Kill |cRXP_ENEMY_High Priest Andorath|r. Loot him for his |cRXP_LOOT_Scroll|r
.complete 11942,1 
.mob High Priest Andorath
step
#completewith next
.goto BoreanTundra,84.2,21.8,40 >> Travel to the Spire of Decay
step
.goto BoreanTundra,83.9,20.5
>>Kill the |cRXP_ENEMY_En'kilah Necromancers|r to free |cRXP_ENEMY_High Priest Naferset|r
>>Kill |cRXP_ENEMY_High Priest Naferset|r. Loot him for his |cRXP_LOOT_Scroll|r
.complete 11942,2 
.mob High Priest Naferset
.mob En'kilah Necromancer
step
.goto BoreanTundra,84.80,41.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thassarian|r
.turnin 11942 >>Turn in Words of Power
.accept 12019 >>Accept Last Rites
.target Thassarian
step
#optional << !wotlk
#completewith lastrites
.goto BoreanTundra,86.5,28.7,15 >> |cRXP_WARN_Take the teleporter up to the Ziggurat in the sky|r
.goto BoreanTundra,86.7,30.2,8 >>|cRXP_WARN_After taking the 1st teleporter, take the 2nd (blue) teleporter directly above the green circle where you first entered|r
.isOnQuest 12019
.noflyable
step
#optional << wotlk
.goto BoreanTundra,86.64,31.38
.subzone 4128>>Fly up to the roof of the ziggurat floating in the sky
.flyable << wotlk
step
#completewith next
#label lastrites
.goto BoreanTundra,86.64,31.38
.gossipoption 93099 >> Talk to |cRXP_FRIENDLY_Thassarian|r to start the RP
.timer 142,Last Rites RP
.skipgossip
.target Thassarian
.isOnQuest 12019
step
>>Kill |cRXP_ENEMY_Prince Valanar|r
>>|cRXP_WARN_Let |cRXP_FRIENDLY_Thassarian|r tank |cRXP_ENEMY_Prince Valanar|r for a few seconds before you start doing damage|r
>>|cRXP_WARN_BEWARE OF|r |T136157:0|t[Soul Deflection]
>>|cRXP_WARN_THIS DEBUFF |cRXP_ENEMY_Prince Valanar|r APPLIES TO YOU REFLECTS 100% OF THE DAMAGE YOU DEAL FOR 6 SECONDS. STOP ATTACKING DURING THIS. IF YOU HAVE DoT's ON |cRXP_ENEMY_Prince Valanar|r THEY WILL ALSO BE REFLECTED|r
>>|cRXP_WARN_This quest is difficult. Find a group for him if needed. Skip this step if you're unable to find a group or solo him|r << wotlk
.complete 12019,1 
.goto BoreanTundra,86.7,30.2
.mob Prince Valanar
step << wotlk
.goto BoreanTundra,86.80,30.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thassarian|r atop the Ziggurat
.turnin 12019 >>Turn in Last Rites
.target Thassarian
step << !wotlk
.goto 114/571,3683.900,3297.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thassarian|r
.target Thassarian
.turnin 12019 >>Turn in Last Rites
step
#completewith next
.goto BoreanTundra,86.96,28.93,12,0
.goto BoreanTundra,86.96,28.93,10 >>|cRXP_WARN_Take the teleporters down to the ground|r
.noflyable
step
#completewith next
.groundgoto BoreanTundra,85.15,28.46,50,0
.goto Dragonblight,29.15,55.32,150 >> Travel to Stars' Rest in Dragonblight
.noflyable
step
.goto Dragonblight,29.15,55.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Palena|r
.fp Stars' Rest >> Get the Stars' Rest Flight Path
.target Palena Silvercloud
step
.goto Dragonblight,28.83,56.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanson|r
>>|cRXP_WARN_Don't accept the next quest|r
.turnin 12157 >>Turn in The Lost Courier
.isOnQuest 12157
.target Courier Lanson
step
#completewith GarrenM
.hs >> Hearth to Valiance Keep
step
#completewith GarrenM
.goto BoreanTundra,44.98,33.38,100 >> Travel to Amber Ledge
.flyable
.skill riding,<300,1
step
#completewith GarrenM
.goto BoreanTundra,58.97,68.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tomas|r
.fly Amber Ledge >>Fly to Amber Ledge
.skill riding,300,1
.target Tomas Riverwell
step
#label GarrenM
.goto BoreanTundra,44.98,33.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garren|r
.turnin 11582 >>Turn in Monitoring the Rift: Sundered Chasm
.accept 12728 >>Accept Monitoring the Rift: Winterfin Cavern
.target Librarian Garren
step 
.goto BoreanTundra,45.33,34.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Surristrasz|r
>>|cRXP_WARN_This will fly you to Coldarra. This flight takes 1m 2s|r
.turnin 11682 >>Turn in Dragonspeak
.accept 11733 >>Accept Traversing the Rift
.timer 62,Coldarra flight
.target Surristrasz
step
#completewith next
.goto BoreanTundra,45.33,34.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Surristrasz|r
.fly Coldarra >> Fly to Coldarra
.target Surristrasz
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Berinand|r, |cRXP_FRIENDLY_Raelorasz|r and |cRXP_FRIENDLY_Serrah|r
.turnin 11733 >>Turn in Traversing the Rift
.accept 11900 >>Accept Reading the Meters
.accept 11910 >>Accept Secrets of the Ancients
.goto BoreanTundra,32.94,34.40
.accept 11918 >>Accept Basic Training
.goto BoreanTundra,33.32,34.54
.accept 11912 >>Accept Nuts for Berries
.goto BoreanTundra,33.49,34.38
.target Archmage Berinand
.target Raelorasz
.target Librarian Serrah
step
#sticky
#completewith Weaver1
>>Kill |cRXP_ENEMY_Coldarra Spellweavers|r
>>Open |cRXP_PICK_Frostberry Bushes|r. Loot them for |cRXP_LOOT_Frostberries|r
.complete 11918,1 
.complete 11912,1 
.mob Coldarra Spellweaver
step
.goto BoreanTundra,32.69,27.79,70,0
.goto BoreanTundra,33.45,25.68,70,0
.goto BoreanTundra,33.73,29.97,70,0
.goto BoreanTundra,31.54,28.28,70,0
.goto BoreanTundra,34.79,26.95
.use 35648 >>Kill |cRXP_ENEMY_Coldarra Spellbinders|r. Loot them for their |T134923:0|t[|cRXP_LOOT_Scintillating Fragment|r]
>>|cRXP_WARN_Use the |T134923:0|t[|cRXP_LOOT_Scintillating Fragment|r] to start the quest|r
.collect 35648,1,11941,1 
.accept 11941 >>Accept Puzzling...
.mob Coldarra Spellbinder
step
.goto BoreanTundra,33.31,34.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raelorasz|r
.turnin 11941 >>Turn in Puzzling...
.accept 11943 >>Accept The Cell
.target Raelorasz
step
#completewith splinters
>>Kill |cRXP_ENEMY_Glacial Ancients|r and |cRXP_ENEMY_Magic-bound Ancients|r. Loot them for their |cRXP_LOOT_Splinters|r
.complete 11910,1 
.complete 11910,2 
.mob Glacial Ancient
.mob Magic-bound Ancient
step
.goto BoreanTundra,28.81,34.91,-1
.goto BoreanTundra,28.25,35.04,-1
>>Click the |cRXP_PICK_Coldarra Geological Monitor|r on the ground
.complete 11900,2 
step
.goto BoreanTundra,24.14,29.60
>>Kill |cRXP_ENEMY_Warbringer Goredrak|r. Loot him for his |cRXP_LOOT_Energy Core|r
.complete 11943,1 
.mob Warbringer Goredrak
step
.goto BoreanTundra,22.36,24.21,-1
.goto BoreanTundra,22.62,23.42,-1
>>Click the |cRXP_PICK_Coldarra Geological Monitor|r on the ground
.complete 11900,4 
step
.goto BoreanTundra,27.32,20.41
>>Kill |cRXP_ENEMY_General Cerulean|r. Loot him for his |cRXP_LOOT_Prison Casing|r
.complete 11943,2 
.mob General Cerulean
step
#label Weaver1
.goto BoreanTundra,31.25,20.18,-1
.goto BoreanTundra,31.72,20.57,-1
>>Click the |cRXP_PICK_Coldarra Geological Monitor|r on the ground
.complete 11900,3 
step
#sticky
#label berries2
#loop
.goto BoreanTundra,33.7,23.1,100,0
.goto BoreanTundra,34.3,31.2,100,0
.goto BoreanTundra,24.4,35.2,100,0
.goto BoreanTundra,21.5,26.9,100,0
.goto BoreanTundra,21.5,26.9,0
.goto BoreanTundra,24.4,35.2,0
.goto BoreanTundra,34.3,31.2,0
.goto BoreanTundra,33.7,23.1,0
>>Kill |cRXP_ENEMY_Coldarra Spellweavers|r
.complete 11918,1 
.mob Coldarra Spellweaver
step
#loop
.goto BoreanTundra,33.7,23.1,100,0
.goto BoreanTundra,34.3,31.2,100,0
.goto BoreanTundra,24.4,35.2,100,0
.goto BoreanTundra,21.5,26.9,100,0
.goto BoreanTundra,21.5,26.9,0
.goto BoreanTundra,24.4,35.2,0
.goto BoreanTundra,34.3,31.2,0
.goto BoreanTundra,33.7,23.1,0
>>Open |cRXP_PICK_Frostberry Bushes|r. Loot them for |cRXP_LOOT_Frostberries|r
.complete 11912,1 
step
#completewith next
.goto BoreanTundra,33.49,34.38,100 >> Travel to Transitus
step
#requires berries2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Serrah|r and |cRXP_FRIENDLY_Raelorasz|r
.turnin 11912 >>Turn in Nuts for Berries
.accept 11914 >>Accept Keep the Secret Safe
.goto BoreanTundra,33.49,34.38
.turnin 11918 >>Turn in Basic Training
.accept 11936 >>Accept Hatching a Plan
.turnin 11943 >>Turn in The Cell
.goto BoreanTundra,33.32,34.54
.target Raelorasz
.target Librarian Serrah
step
.use 35671 >> |cRXP_WARN_Use the|r |T133836:0|t[Augmented Arcane Prison] |cRXP_WARN_to summon|r |cRXP_FRIENDLY_Keristrasza|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keristrasza|r
.accept 11946 >>Accept Keristrasza
.turnin 11946 >>Turn in Keristrasza
.accept 11951 >>Accept Bait and Switch
.target Keristrasza
step
#completewith next
#loop
.line BoreanTundra,28.69,30.93,30.12,28.57,29.84,24.39,27.68,22.32,25.25,24.59,25.39,28.67
.goto BoreanTundra,28.69,30.93,40,0
.goto BoreanTundra,30.12,28.57,40,0
.goto BoreanTundra,29.84,24.39,40,0
.goto BoreanTundra,27.68,22.32,40,0
.goto BoreanTundra,25.25,24.59,40,0
.goto BoreanTundra,25.39,28.67,40,0
>>Open the |cRXP_PICK_Crystallized Mana|r. Loot them for the |cRXP_LOOT_Crystallized Mana Shards|r
.complete 11951,1 
step
.goto BoreanTundra,29.5,30.81,90,0
.goto BoreanTundra,28.7,33.6,70,0
.goto BoreanTundra,27.5,31.3,70,0
.goto BoreanTundra,24.9,31.2,70,0
.goto BoreanTundra,25.2,24.2
>>Kill |cRXP_ENEMY_Coldarra Wyrmkins|r. Loot them for their |T132394:0|t[|cRXP_LOOT_Frozen Axes|r]
.collect 35586,5,11936,1 
.mob Coldarra Wyrmkin
step
#loop
.line BoreanTundra,28.69,30.93,30.12,28.57,29.84,24.39,27.68,22.32,25.25,24.59,25.39,28.67
.goto BoreanTundra,28.69,30.93,40,0
.goto BoreanTundra,30.12,28.57,40,0
.goto BoreanTundra,29.84,24.39,40,0
.goto BoreanTundra,27.68,22.32,40,0
.goto BoreanTundra,25.25,24.59,40,0
.goto BoreanTundra,25.39,28.67,40,0
>>Open the |cRXP_PICK_Crystallized Mana|r. Loot them for the |cRXP_LOOT_Crystallized Mana Shards|r
.complete 11951,1 
step
#sticky
#label reading
.goto BoreanTundra,28.31,28.46
>>Click the |cRXP_PICK_Coldarra Geological Monitor|r on the ground
.complete 11900,1 
step
#label splinters
.goto BoreanTundra,29.3,27.4,50,0
.goto BoreanTundra,28.2,24.4,50,0
.goto BoreanTundra,26.2,25.4,50,0
.goto BoreanTundra,26.04,27.72,50,0
.goto BoreanTundra,28.31,28.46,50,0
.goto BoreanTundra,29.3,27.4,50,0
.goto BoreanTundra,28.2,24.4,50,0
.goto BoreanTundra,26.2,25.4,50,0
.goto BoreanTundra,26.04,27.72,50,0
.goto BoreanTundra,28.31,28.46
>>Kill |cRXP_ENEMY_Arcane Serpents|r. Loot them for their |cRXP_LOOT_Essences|r
>>|cRXP_WARN_Use the|r |T132394:0|t[|cRXP_LOOT_Frozen Axes|r] |cRXP_WARN_on the|r |cRXP_PICK_Blue Dragon Eggs|r
.collect 35586,5,11936,1,-1 
.complete 11936,1 
.complete 11914,1 
.mob Arcane Serpent
step
#requires reading
.goto BoreanTundra,30.1,23.4,70,0
.goto BoreanTundra,32.6,28.2,70,0
.goto BoreanTundra,28.0,33.5,70,0
.goto BoreanTundra,25.0,30.6,70,0
.goto BoreanTundra,25.5,35.6
>>Kill |cRXP_ENEMY_Glacial Ancients|r and |cRXP_ENEMY_Magic-bound Ancients|r. Loot them for their |cRXP_LOOT_Splinters|r
.complete 11910,1 
.complete 11910,2 
.mob Glacial Ancient
.mob Magic-bound Ancient
step
.use 35671 >> |cRXP_WARN_Use the|r |T133836:0|t[Augmented Arcane Prison] |cRXP_WARN_to summon|r |cRXP_FRIENDLY_Keristrasza|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keristrasza|r
>>|cRXP_WARN_If you lost it, Talk to |cRXP_FRIENDLY_Raelorasz|r for a new one|r
.turnin 11951 >>Turn in Bait and Switch
.accept 11957 >>Accept Saragosa's End
.target Keristrasza
.target Raelorasz
step
.gossipoption 93094 >> Talk to |cRXP_FRIENDLY_Keristrasza|r to teleport to Saragosa's Landing
.skipgossip
.target Keristrasza
.use 35671
.isOnQuest 11957
step
#completewith next
.goto BoreanTundra,21.30,22.44
.cast 46793 >>|cRXP_WARN_Use the|r |T132866:0|t[Arcane Power Focus] |cRXP_WARN_to summon|r |cRXP_ENEMY_Saragosa|r
.timer 21,Saragosa's End RP
.use 35690
step
>>Kill |cRXP_ENEMY_Saragosa|r. Loot her for her |cRXP_LOOT_Corpse|r
.complete 11957,1 
.goto BoreanTundra,22.07,22.65
.use 35690
.skipgossip
.mob Saragosa
step
.use 35671 >> |cRXP_WARN_Use the|r |T133836:0|t[Augmented Arcane Prison] |cRXP_WARN_to summon|r |cRXP_FRIENDLY_Keristrasza|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keristrasza|r
.turnin 11957 >>Turn in Saragosa's End
.accept 11967 >>Accept Mustering the Reds
.goto BoreanTundra,21.57,22.55
.cooldown item,35671,>30
.target Keristrasza
step
#questguide
.goto BoreanTundra,21.6,22.5,0
>>|cRXP_WARN_DO NOT Ride back to Transitus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keristrasza|r for a teleport back to Transitus
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Serrah|r, |cRXP_FRIENDLY_Raelorasz|r and |cRXP_FRIENDLY_Berinand|r
.turnin 11914 >>Turn in Keep the Secret Safe
.goto BoreanTundra,33.49,34.38
.turnin 11967 >>Turn in Mustering the Reds
.turnin 11936 >>Turn in Hatching a Plan
.accept 11969 >>Accept Springing the Trap
.accept 11919 >>Accept Drake Hunt
.goto BoreanTundra,33.32,34.54
.turnin 11900 >>Turn in Reading the Meters
.turnin 11910 >>Turn in Secrets of the Ancients
.goto BoreanTundra,32.94,34.40
.skipgossip
.isOnQuest 11967
.target Keristrasza
.target Archmage Berinand
.target Raelorasz
.target Librarian Serrah
step
#questguide
.goto BoreanTundra,21.6,22.5,0
>>Fly back to Transitus
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Serrah|r, |cRXP_FRIENDLY_Raelorasz|r and |cRXP_FRIENDLY_Berinand|r
.turnin 11914 >>Turn in Keep the Secret Safe
.goto BoreanTundra,33.49,34.38
.turnin 11936 >>Turn in Hatching a Plan
.accept 11919 >>Accept Drake Hunt
.goto BoreanTundra,33.32,34.54
.turnin 11900 >>Turn in Reading the Meters
.turnin 11910 >>Turn in Secrets of the Ancients
.goto BoreanTundra,32.94,34.40
.skipgossip
.target Archmage Berinand
.target Raelorasz
.target Librarian Serrah
step
#optional
.goto BoreanTundra,21.6,22.5,0
>>|cRXP_WARN_DO NOT Ride back to Transitus|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keristrasza|r for a teleport back to Transitus
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Serrah|r, |cRXP_FRIENDLY_Raelorasz|r and |cRXP_FRIENDLY_Berinand|r
.turnin 11914 >>Turn in Keep the Secret Safe
.goto BoreanTundra,33.49,34.38
.turnin 11967 >>Turn in Mustering the Reds
.turnin 11936 >>Turn in Hatching a Plan
.goto BoreanTundra,33.32,34.54
.turnin 11900 >>Turn in Reading the Meters
.turnin 11910 >>Turn in Secrets of the Ancients
.goto BoreanTundra,32.94,34.40
.skipgossip
.noflyable
.target Keristrasza
.target Archmage Berinand
.target Raelorasz
.target Librarian Serrah
step
>>Go back to Transitus Shield
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Serrah|r, |cRXP_FRIENDLY_Raelorasz|r and |cRXP_FRIENDLY_Berinand|r
.turnin 11914 >>Turn in Keep the Secret Safe
.goto BoreanTundra,33.49,34.38
.turnin 11936 >>Turn in Hatching a Plan
.goto BoreanTundra,33.32,34.54
.turnin 11900 >>Turn in Reading the Meters
.turnin 11910 >>Turn in Secrets of the Ancients
.goto BoreanTundra,32.94,34.40
.target Archmage Berinand
.target Raelorasz
.target Librarian Serrah
step
.goto BoreanTundra,21.57,22.55
.use 35671 >> |cRXP_WARN_Use the|r |T133836:0|t[Augmented Arcane Prison] |cRXP_WARN_to summon|r |cRXP_FRIENDLY_Keristrasza|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keristrasza|r
.turnin 11957 >>Turn in Saragosa's End
.accept 11967 >>Accept Mustering the Reds
.target Keristrasza
step
#questguide
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raelorasz|r
.turnin 11967 >>Turn in Mustering the Reds
.accept 11969 >>Accept Springing the Trap
.goto BoreanTundra,33.32,34.54
.target Raelorasz
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raelorasz|r
.turnin 11967 >>Turn in Mustering the Reds
.goto BoreanTundra,33.32,34.54
.skill coldweatherflying,<1,1
.target Raelorasz
step
#questguide
.goto BoreanTundra,25.34,21.82
.cast 62272 >> |cRXP_WARN_Use|r |T132862:0|t[Raelorasz' Spark] |cRXP_WARN_next to the|r |cRXP_PICK_Signal Fire|r
.timer 195,Springing the Trap RP
>>|cRXP_WARN_Wait out the RP|r
.use 44950
.complete 11969,1 
.isOnQuest 11969
step
#questguide
#completewith next
+|cRXP_WARN_Dismount |cRXP_FRIENDLY_Keristrasza|r, then cast |T135992:0|t[Slow Fall]|r << Mage
+|cRXP_WARN_Dismount |cRXP_FRIENDLY_Keristrasza|r, then cast |T135928:0|t[Levitate] when you're near the ground|r << Priest
+|cRXP_WARN_Dismount |cRXP_FRIENDLY_Keristrasza|r, then cast |T135896:0|t[Divine Shield] or |T135964:0|t[Hand of Protection] when you're near the ground|r << Paladin
.itemcount 17056,1 << Mage/Priest
step
#questguide
#completewith next
.goto BoreanTundra,21.91,30.45
.use 35506 >> |cRXP_WARN_Look for a |cRXP_ENEMY_Nexus Drake Hatchling|r flying around the north-western edge of Coldarra|r
.cast 46607 >>|cRXP_WARN_Use|r |T135134:0|t[Raelorasz's Spear] |cRXP_WARN_on a |cRXP_ENEMY_Nexus Drake Hatchling|r to capture it|r
>>|cRXP_WARN_Do NOT kill the|r |cRXP_ENEMY_Nexus Drake Hatchling|r
.unitscan Nexus Drake Hatchling
.isOnQuest 11919
step
#questguide
.goto BoreanTundra,33.28,34.47
>>Take the |cRXP_FRIENDLY_Nexus Drake Hatchling|r back to |cRXP_FRIENDLY_Raelorasz|r in Transitus
>>|cRXP_WARN_The |cRXP_FRIENDLY_Nexus Drake Hatchling|r will match your movement speed|r
.complete 11919,1 
.target Raelorasz
.isOnQuest 11919
step
#questguide
.goto BoreanTundra,33.32,34.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raelorasz|r
.turnin 11919 >>Turn in Drake Hunt
.turnin 11969 >>Turn in Springing the Trap
.accept 11931 >>Accept Cracking the Code
.daily 11940 >>Accept Drake Hunt
.target Raelorasz
step
#questguide
#completewith next
.goto BoreanTundra,32.72,27.88,0
>>Kill |cRXP_ENEMY_Coldarra Spellbinders|r. Loot them for their |cRXP_LOOT_Shimmering Runes|r
.complete 11931,1 
.mob Coldarra Spellbinder
step
#questguide
.goto BoreanTundra,32.72,27.88
>>Kill |cRXP_ENEMY_Inquisitor Caleras|r. Loot him for the |cRXP_LOOT_Azure Codex|r
.complete 11931,2 
.mob Inquisitor Caleras
step
#questguide
.goto BoreanTundra,21.91,30.45
.use 35506 >> |cRXP_WARN_Look for a |cRXP_ENEMY_Nexus Drake Hatchling|r flying around the north-western edge of Coldarra|r
.cast 46607 >>|cRXP_WARN_Use|r |T135134:0|t[Raelorasz's Spear] |cRXP_WARN_on a |cRXP_ENEMY_Nexus Drake Hatchling|r to capture it|r
>>|cRXP_WARN_Do NOT kill the|r |cRXP_ENEMY_Nexus Drake Hatchling|r
.unitscan Nexus Drake Hatchling
.isOnQuest 11940
step
#questguide
.goto BoreanTundra,32.69,27.79,70,0
.goto BoreanTundra,33.45,25.68,70,0
.goto BoreanTundra,33.73,29.97,70,0
.goto BoreanTundra,31.54,28.28,70,0
.goto BoreanTundra,34.79,26.95
>>Kill |cRXP_ENEMY_Coldarra Spellbinders|r. Loot them for their |cRXP_LOOT_Shimmering Runes|r
.complete 11931,1 
.mob Coldarra Spellbinder
step
#questguide
.goto BoreanTundra,33.28,34.47
>>Take the |cRXP_FRIENDLY_Nexus Drake Hatchling|r back to |cRXP_FRIENDLY_Raelorasz|r in Transitus
>>|cRXP_WARN_The |cRXP_FRIENDLY_Nexus Drake Hatchling|r will match your movement speed|r
.complete 11940,1 
.target Raelorasz
.isOnQuest 11940
step
#questguide
.goto BoreanTundra,33.32,34.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raelorasz|r
.turnin 11931 >>Turn in Cracking the Code
.turnin -11940 >>Turn in Drake Hunt
.target Raelorasz
step
#completewith next
.goto BoreanTundra,33.13,34.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Adami|r
.fly Fizzcrank >>Fly to Fizzcrank Airstrip
.target Warmage Adami
step
#completewith ED
.goto BoreanTundra,57.12,18.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Charlie"|r
.home >>Set your Hearthstone to Fizzcrank Airstrip
.target "Charlie" Northtop
step
.goto BoreanTundra,56.98,18.71
>>|cRXP_WARN_Take the elevator up to|r |cRXP_FRIENDLY_Fizzcrank|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzcrank|r
.turnin 11707 >>Turn in Distress Call
.accept 11708 >>Accept The Mechagnomes
.target Fizzcrank Fullthrottle
step
#completewith next
.goto BoreanTundra,56.98,18.71
.gossipoption 93233 >> Talk to |cRXP_FRIENDLY_Fizzcrank|r
.skipgossip 25590,1,1,2,2,2,2,2,2,2
.isOnQuest 11708
.target Fizzcrank Fullthrottle
step
.goto BoreanTundra,56.98,18.71
>> Talk to |cRXP_FRIENDLY_Fizzcrank|r to hear his tale
.isOnQuest 11708
.complete 11708,1 
.target Fizzcrank Fullthrottle
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jinky|r, |cRXP_FRIENDLY_Mordle|r, and |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11708 >>Turn in The Mechagnomes
.accept 11712 >>Accept Re-Cursive
.goto BoreanTundra,57.44,18.73
.accept 11704 >>Accept King Mrgl-Mrgl
.accept 11710 >>Accept What's the Matter with the Transmatter?
.goto BoreanTundra,57.52,18.62
.accept 11645 >>Accept Dirty, Stinkin' Snobolds!
.goto BoreanTundra,57.51,18.72,30,0
.goto BoreanTundra,58.2,18.3
.target Jinky Twizzlefixxit
.target Mordle Cogspinner
.target Crafty Wobblesprocket
step
#questguide << !Druid !Shaman !Druid
#completewith Bonker
.goto BoreanTundra,57.3,13.1,0
.goto BoreanTundra,56.2,12.1,0
.goto BoreanTundra,55.0,13.1,0
.goto BoreanTundra,53.1,13.9,0
>>Loot |cRXP_LOOT_Crafty's Stuff|r on the ground
.complete 11645,1 
step
#questguide << !Druid !Shaman !Druid
#completewith CStuff
.goto BoreanTundra,53.8,13.8,30 >> Enter the Magmoth Cave
step
#questguide << !Druid !Shaman !Druid
.goto BoreanTundra,53.8,13.8,40,0
.goto BoreanTundra,55.57,12.58
>>Drop down to |cRXP_FRIENDLY_Bonker|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bonker|r
.accept 11673 >>Accept Get Me Outa Here!
.target Bonker Togglevolt
step
#questguide << !Druid !Shaman !Druid
.goto BoreanTundra,53.8,13.8
>>|cRXP_WARN_Escort |cRXP_FRIENDLY_Bonker|r just outside of Magmoth Cave|r
.complete 11673,1 
step
#label CStuff
.goto BoreanTundra,54.9,15.7,50,0
.goto BoreanTundra,57.3,13.1,50,0
.goto BoreanTundra,56.2,12.1,50,0
.goto BoreanTundra,55.0,13.1,50,0
.goto BoreanTundra,53.1,13.9
>>Loot |cRXP_LOOT_Crafty's Stuff|r on the ground
.complete 11645,1 
.target Bonker Togglevolt
step
.goto BoreanTundra,57.1,19.0,20,0
.goto BoreanTundra,57.0,18.7
>>|cRXP_WARN_Take the elevator up to|r |cRXP_FRIENDLY_Fizzcrank|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzcrank|r
.turnin 11673 >>Turn in Get Me Outa Here!
.isQuestComplete 11673
.target Fizzcrank Fullthrottle
step
.goto BoreanTundra,57.51,18.72,30,0
.goto BoreanTundra,58.2,18.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11645 >>Turn in Dirty, Stinkin' Snobolds!
.accept 11650 >>Accept Just a Few More Things...
.itemcount 39682,1 
.target Crafty Wobblesprocket
step
.goto BoreanTundra,57.51,18.72,30,0
.goto BoreanTundra,58.2,18.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11645 >>Turn in Dirty, Stinkin' Snobolds!
.target Crafty Wobblesprocket
step
#sticky
#label screwdriver1
.goto BoreanTundra,61.6,15.0,0
.goto BoreanTundra,59.4,17.6,0
.goto BoreanTundra,58.2,23.4,0
.goto BoreanTundra,63.5,22.4,0
.goto BoreanTundra,64.5,18.2,0
.use 34984 >> Kill |cRXP_ENEMY_Defendo-tank 66Ds|r, |cRXP_ENEMY_Scavenge-bot 004-A8s|r and |cRXP_ENEMY_Sentry-bot 57-Ks|r. Loot them for |T134429:0|t[|cRXP_LOOT_The Ultrasonic Screwdriver|r]
>>|cRXP_WARN_Use |T134429:0|t[|cRXP_LOOT_The Ultrasonic Screwdriver|r] to start the quest|r
.collect 34984,1,11729,1
.accept 11729 >> Accept The Ultrasonic Screwdriver
.mob Sentry-bot 57-K
.mob Scavenge-bot 004-A8
.mob Defendo-tank 66D
step
.goto BoreanTundra,61.7,20.9,70,0
.goto BoreanTundra,65.2,17.9,70,0
.goto BoreanTundra,64.2,23.2
.use 34973 >> Kill |cRXP_ENEMY_Fizzcrank Mechagnomes|r. |cRXP_WARN_Use the|r |T136093:0|t[Re-Cursive Transmatter Injection] |cRXP_WARN_on their corpses|r
>>Loot the |cRXP_LOOT_Fizzcrank Spare Parts|r on the ground
.complete 11712,1 
.complete 11710,1 
.mob Fizzcrank Mechagnome
step
#requires screwdriver1
#questguide
.goto BoreanTundra,61.6,15.0,70,0
.goto BoreanTundra,59.4,17.6,70,0
.goto BoreanTundra,58.2,23.4,70,0
.goto BoreanTundra,63.5,22.4,70,0
.goto BoreanTundra,64.5,18.2
.use 34984 >> Kill |cRXP_ENEMY_Defendo-tank 66Ds|r, |cRXP_ENEMY_Scavenge-bot 004-A8s|r and |cRXP_ENEMY_Sentry-bot 57-Ks|r. Loot them for |T134429:0|t[|cRXP_LOOT_The Ultrasonic Screwdriver|r]
>>|cRXP_WARN_Use |T134429:0|t[|cRXP_LOOT_The Ultrasonic Screwdriver|r] to start the quest|r
.collect 34984,1,11729,1
.accept 11729 >> Accept The Ultrasonic Screwdriver
.mob Sentry-bot 57-K
.mob Scavenge-bot 004-A8
.mob Defendo-tank 66D
step
#questguide
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r, |cRXP_FRIENDLY_Mordle|r, and |cRXP_FRIENDLY_Jinky|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11729 >> Turn in The Ultrasonic Screwdriver
.accept 11730 >> Accept Master and Servant
.goto BoreanTundra,57.51,18.72,30,0
.goto BoreanTundra,58.2,18.3
.turnin 11710 >>Turn in What's the Matter with the Transmatter?
.accept 11692 >>Accept Check in With Bixie
.goto BoreanTundra,57.52,18.62
.turnin 11712 >>Turn in Re-Cursive
.accept 11788 >>Accept Lefty Loosey, Righty Tighty
.goto BoreanTundra,57.44,18.73
.target Jinky Twizzlefixxit
.target Mordle Cogspinner
.target Crafty Wobblesprocket
step
#requires screwdriver1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r, |cRXP_FRIENDLY_Mordle|r, and |cRXP_FRIENDLY_Jinky|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11729 >> Turn in The Ultrasonic Screwdriver
.goto BoreanTundra,57.51,18.72,30,0
.goto BoreanTundra,58.2,18.3
.turnin 11710 >>Turn in What's the Matter with the Transmatter?
.accept 11692 >>Accept Check in With Bixie
.goto BoreanTundra,57.52,18.62
.turnin 11712 >>Turn in Re-Cursive
.accept 11788 >>Accept Lefty Loosey, Righty Tighty
.goto BoreanTundra,57.44,18.73
.target Jinky Twizzlefixxit
.target Mordle Cogspinner
.target Crafty Wobblesprocket
step
#questguide
#completewith ED
.use 35116 >> Kill |cRXP_ENEMY_Defendo-tank 66Ds|r, |cRXP_ENEMY_Scavenge-bot 004-A8s|r and |cRXP_ENEMY_Sentry-bot 57-Ks|r. |cRXP_WARN_Use|r |T134429:0|t[|cRXP_LOOT_The Ultrasonic Screwdriver|r] |cRXP_WARN_on their corpses|r
.complete 11730,1 
.mob Sentry-bot 57-K
.mob Scavenge-bot 004-A8
.mob Defendo-tank 66D
step
.goto BoreanTundra,60.24,20.39
>>Click the |cRXP_PICK_West Point Station Valve|r to summon |cRXP_ENEMY_Twonky|r
>>Kill |cRXP_ENEMY_Twonky|r
.complete 11788,1 
.mob Twonky
step
.goto BoreanTundra,63.68,22.50
>>Click the |cRXP_PICK_Mid Point Station Valve|r to summon |cRXP_ENEMY_Max Blasto|r
>>Kill |cRXP_ENEMY_Max Blasto|r
.complete 11788,3 
.mob Max Blasto
step
.goto BoreanTundra,64.40,23.14
>>Loot |cRXP_LOOT_Crafty's Tools|r on the ground
.complete 11650,1 
.itemcount 39682,1 
.isOnQuest 11650
step
#label ED
.goto BoreanTundra,65.41,17.51
>>Click the |cRXP_PICK_North Point Station Valve|r to summon |cRXP_ENEMY_ED-210|r
>>Kill |cRXP_ENEMY_ED-210|r
.complete 11788,2 
.mob ED-210
step
#questguide
.goto BoreanTundra,61.0,17.0,70,0
.goto BoreanTundra,58.5,20.8,70,0
.goto BoreanTundra,63.1,21.7
.use 35116 >> Kill |cRXP_ENEMY_Defendo-tank 66Ds|r, |cRXP_ENEMY_Scavenge-bot 004-A8s|r and |cRXP_ENEMY_Sentry-bot 57-Ks|r
>>|cRXP_WARN_Use|r |T134429:0|t[|cRXP_LOOT_The Ultrasonic Screwdriver|r] |cRXP_WARN_on their corpses|r
.complete 11730,1 
.mob Sentry-bot 57-K
.mob Scavenge-bot 004-A8
.mob Defendo-tank 66D
step
#completewith next
.goto BoreanTundra,73.42,18.78,100 >> Travel toward |cRXP_FRIENDLY_Bixie|r near Talramas
step
.goto BoreanTundra,73.42,18.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixie|r
.turnin 11692 >>Turn in Check in With Bixie
.accept 11693 >>Accept Oh Great... Plagued Magnataur!
.target Bixie Wrenchshanker
step
.goto BoreanTundra,82.0,29.3,70,0
.goto BoreanTundra,71.8,15.6,70,0
.goto BoreanTundra,82.0,29.3,70,0
.goto BoreanTundra,71.8,15.6
>>Kill |cRXP_ENEMY_Plagued Magnataurs|r
.complete 11693,1 
.mob Plagued Magnataur
step
.goto BoreanTundra,73.42,18.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixie|r
.turnin 11693 >>Turn in Oh Great... Plagued Magnataur!
.accept 11694 >>Accept There's Something Going On In Those Caves
.target Bixie Wrenchshanker
step
#completewith next
.goto BoreanTundra,74.77,14.10,70 >> Enter the Den of Dying
step
.goto BoreanTundra,74.77,14.10
.use 34915 >> |cRXP_WARN_Use|r |T133590:0|t[Bixie's Inhibiting Powder] |cRXP_WARN_on the|r |cRXP_PICK_Den of Dying Plague Cauldron|r
.complete 11694,1 
step
.goto BoreanTundra,73.42,18.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixie|r
.turnin 11694 >>Turn in There's Something Going On In Those Caves
.accept 11697 >>Accept Rats, Tinky Went into the Necropolis!
.accept 11698 >>Accept Might As Well Wipe Out the Scourge
.target Bixie Wrenchshanker
step
#completewith Tinky
.goto BoreanTundra,69.3,14.1,0
>>Kill the |cRXP_ENEMY_Talramas Undead|r
.complete 11698,1 
.mob Cult Plaguebringer
.mob Doctor Razorgrin
.mob Lich-Lord Chillwinter
.mob Talramas Abomination
.mob Bone Warrior
.mob Festering Ghoul
step
#completewith next
.goto BoreanTundra,68.7,15.3,60 >> Travel toward |cRXP_FRIENDLY_Tinky|r inside Talramas
step
.goto BoreanTundra,68.7,15.3,70,0
.goto BoreanTundra,69.89,14.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinky|r
.turnin 11697 >>Turn in Rats, Tinky Went into the Necropolis!
.accept 11699 >>Accept I'm Stuck in this Damned Cage... But Not For Long!
.target Tinky Wickwhistle
step
#completewith Gyroscope
.goto BoreanTundra,68.97,14.76,0
>>Kill |cRXP_ENEMY_Festering Ghouls|r. Loot them for their |cRXP_LOOT_Crystal|r
.complete 11699,1 
.mob Festering Ghoul
step
.groundgoto BoreanTundra,68.7,15.3,40,0
.groundgoto BoreanTundra,68.1,11.6,60,0
.groundgoto BoreanTundra,69.4,11.4,40,0
.groundgoto BoreanTundra,69.08,13.26,30,0
.goto BoreanTundra,69.64,13.88
>>|cRXP_WARN_Travel to the top of Talramas from the outside|r
>>Kill |cRXP_ENEMY_Lich-Lord Chillwinter|r. Loot him for the |cRXP_LOOT_Scourgestone|r
.complete 11699,3 
.mob Lich-Lord Chillwinter
step
#label Gyroscope
.goto BoreanTundra,69.88,13.33
>>|cRXP_WARN_Drop down into the center pit|r
>>Kill |cRXP_ENEMY_Doctor Razorgrin|r. Loot him for the |cRXP_LOOT_Gyroscope|r
.complete 11699,2 
.mob Doctor Razorgrin
step
.goto BoreanTundra,71.2,15.0,70,0
.goto BoreanTundra,68.2,16.9,70,0
.goto BoreanTundra,67.2,12.5,70,0
.goto BoreanTundra,69.7,13.8
>>Kill |cRXP_ENEMY_Festering Ghouls|r. Loot them for their |cRXP_LOOT_Crystal|r
.complete 11699,1 
.mob Festering Ghoul
step
#label Tinky
.goto BoreanTundra,69.89,14.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinky|r
.turnin 11699 >>Turn in I'm Stuck in this Damned Cage... But Not For Long!
.accept 11700 >>Accept Let Bixie Know
.target Tinky Wickwhistle
step
.goto BoreanTundra,71.2,15.0,70,0
.goto BoreanTundra,68.2,16.9,70,0
.goto BoreanTundra,67.2,12.5,70,0
.goto BoreanTundra,69.7,13.8
>>Kill |cRXP_ENEMY_Talramas Undead|r
.complete 11698,1 
.mob Cult Plaguebringer
.mob Doctor Razorgrin
.mob Lich-Lord Chillwinter
.mob Talramas Abomination
.mob Bone Warrior
.mob Festering Ghoul
step
.goto BoreanTundra,73.42,18.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixie|r
.turnin 11698 >>Turn in Might As Well Wipe Out the Scourge
.turnin 11700 >>Turn in Let Bixie Know
.accept 11701 >>Accept Back to the Airstrip
.target Bixie Wrenchshanker
step << Druid wotlk
#completewith DruidTrain
.cast 18960 >> Cast Teleport: Moonglade
.zoneskip Moonglade
.xp <71,1
step << Druid wotlk
.goto Moonglade,52.53,40.57
>>Go to Moonglade
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 48442 >> Train your class spells
.xp <71,1
.target Loganaar
step << Druid wotlk
#label DruidTrain
.goto Moonglade,52.53,40.57
>>Go to Moonglade
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 48464 >> Train your class spells
.xp <72,1
.target Loganaar
step << DK wotlk
#completewith next
.cast 50977 >> Cast Death Gate
.zoneskip Eastern Plaguelands
.xp <72,1
step << DK wotlk
.goto Eastern Plaguelands,80.30,48.01
>>Go through the Death Gate
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amal'thazad|r
.train 49940 >> Train your class spells
.xp <72,1
.target Amal'thazad
step << Mage wotlk
#completewith MageTrain
.zone Stormwind City >> Teleport to Stormwind
.xp <71,1
step << Mage wotlk
.goto StormwindNew,49.55,85.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jennea|r
.train 43023 >> Train your class spells
.xp <71,1
.target Elsharin
.target Jennea Cannon
step << Mage wotlk
#label MageTrain
.goto StormwindNew,49.55,85.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jennea|r
.train 42930 >> Train your class spells
.xp <72,1
.target Elsharin
.target Jennea Cannon
step
#completewith next
.hs >> Hearth to Fizzcrank Airstrip
step
.goto BoreanTundra,56.95,18.75
>>|cRXP_WARN_Take the elevator up to|r |cRXP_FRIENDLY_Fizzcrank|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzcrank|r
.turnin 11701 >>Turn in Back to the Airstrip
.accept 11725 >>Accept Finding Pilot Tailspin
.target Fizzcrank Fullthrottle
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11729 >> Turn in The Ultrasonic Screwdriver
.goto BoreanTundra,57.51,18.72,30,0
.goto BoreanTundra,58.2,18.3
.isOnQuest 11729
.target Crafty Wobblesprocket
step
#questguide
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11730 >> Turn in Master and Servant
.goto BoreanTundra,57.51,18.72,30,0
.goto BoreanTundra,58.2,18.3
.target Crafty Wobblesprocket
step
.goto BoreanTundra,65.25,28.78
>>Click the |cRXP_PICK_South Point Station Valve|r to summon |cRXP_ENEMY_The Grinder|r
>>Kill |cRXP_ENEMY_The Grinder|r
.complete 11788,4 
.mob The Grinder
step
#completewith next
.goto BoreanTundra,61.68,35.79,130 >> Travel to the Scalding Pools
step
#label Iggy
.goto BoreanTundra,61.68,35.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iggy|r
.turnin 11725 >>Turn in Finding Pilot Tailspin
.accept 11726 >>Accept A Little Bit of Spice
.target Iggy "Tailspin" Cogtoggle
step
.goto BoreanTundra,64.9,41.2,70,0
.goto BoreanTundra,67.1,40.6,70,0
.goto BoreanTundra,68.7,42.2
>>Kill the |cRXP_ENEMY_Gorloc Gibberers|r, |cRXP_ENEMY_Gorloc Steam Belchers|r and |cRXP_ENEMY_Gorloc Waddlers|r. Loot them for their |cRXP_LOOT_Pouches|r
.complete 11726,1 
.mob Gorloc Gibberer
.mob Gorloc Steam Belcher
.mob Gorloc Waddler
step
#completewith next
.goto BoreanTundra,81.5,42.5,100 >> Travel to Frozen Reach
.isOnQuest 11650
step
.goto BoreanTundra,81.5,42.5
>>Kill |cRXP_ENEMY_Rocknar|r. Loot him for his |cRXP_LOOT_Grit|r
.complete 11650,3 
.itemcount 39682,1 
.isOnQuest 11650
.mob Rocknar
step
.goto BoreanTundra,61.68,35.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iggy|r
.turnin 11726 >>Turn in A Little Bit of Spice
.accept 11728 >>Accept Lupus Pupus
.target Iggy "Tailspin" Cogtoggle
step
.goto BoreanTundra,60.95,32.94
.use 35121 >> |cRXP_WARN_Use the|r |T134045:0|t[Wolf Bait] |cRXP_WARN_on |cRXP_ENEMY_Oil-stained Wolves|r. |cRXP_WARN_Wait for their RP|r
>>Open the |cRXP_PICK_Wolf Droppings|r. Loot it for the |cRXP_LOOT_Microfilm|r
.complete 11728,1 
.mob Oil-stained Wolf
step
.goto BoreanTundra,61.68,35.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iggy|r
.turnin 11728 >>Turn in Lupus Pupus
.accept 11795 >>Accept Emergency Protocol: Section 8.2, Paragraph C
.target Iggy "Tailspin" Cogtoggle
step
.goto BoreanTundra,62.94,35.81,40,0
.goto BoreanTundra,61.53,38.76,40,0
.goto BoreanTundra,60.56,38.44,40,0
.goto BoreanTundra,60.67,35.80,40,0
.goto BoreanTundra,61.35,33.82,40,0
.goto BoreanTundra,62.79,32.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the dead |cRXP_FRIENDLY_Fizzcrank Recon Pilots|r. Loot them for their |cRXP_LOOT_Pilot's Insignias|r
.complete 11795,1 
.skipgossip
.target Fizzcrank Recon Pilot
step
.goto BoreanTundra,61.68,35.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iggy|r
.turnin 11795 >>Turn in Emergency Protocol: Section 8.2, Paragraph C
.accept 11796 >>Accept Emergency Protocol: Section 8.2, Paragraph D
.target Iggy "Tailspin" Cogtoggle
step
.use 35224 >> |cRXP_WARN_Use the|r |T135488:0|t[Emergency Torch] |cRXP_WARN_on the wreckages of the|r |cRXP_PICK_Flying Machines|r
.complete 11796,3 
.goto BoreanTundra,60.85,33.63
.complete 11796,2 
.goto BoreanTundra,61.07,40.01
.complete 11796,1 
.goto BoreanTundra,63.40,36.95
step
#label Iggy2
.goto BoreanTundra,61.68,35.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iggy|r
.turnin 11796 >>Turn in Emergency Protocol: Section 8.2, Paragraph D
.accept 11873 >>Accept Give Fizzcrank the News
.target Iggy "Tailspin" Cogtoggle
step << Shaman
#completewith next
.hs >> Hearth to Fizzcrank Airstrip
step << Shaman
.goto BoreanTundra,57.01,18.68
>>|cRXP_WARN_Take the elevator up to|r |cRXP_FRIENDLY_Fizzcrank|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzcrank|r
.turnin 11873 >>Turn in Give Fizzcrank the News
.target Fizzcrank Fullthrottle
step << !Shaman
#completewith next
.goto BoreanTundra,57.46,18.79,100 >>Travel to Fizzcrank Airstrip
step
.goto BoreanTundra,57.46,18.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jinky|r
.turnin 11788 >>Turn in Lefty Loosey, Righty Tighty
.accept 11798 >>Accept The Gearmaster
.target Jinky Wingnut
step
#completewith next
.goto BoreanTundra,57.1,19.0,20,0
.goto BoreanTundra,57.0,18.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.accept 11653 >>Accept Hah... You're Not So Big Now!
.target Crafty Wobblesprocket
step
.goto BoreanTundra,57.1,19.0,20,0
.goto BoreanTundra,57.0,18.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11650 >>Turn in Just a Few More Things...
.isQuestComplete 11650
.target Crafty Wobblesprocket
step
#completewith next
.goto BoreanTundra,54.2,13.1,60 >> Enter the Magmoth Cave
.isOnQuest 11653
step
.goto BoreanTundra,54.2,13.1,70,0
.goto BoreanTundra,55.1,12.0
.use 34812 >> |cRXP_WARN_Use|r |T133037:0|t[Crafty's Shortening Blaster] |cRXP_WARN_on |cRXP_ENEMY_Magmoth Crushers|r and|r |cRXP_ENEMY_Mates of Magmothregar|r
.complete 11653,1 
.isQuestTurnedIn 11650
.mob Magmoth Crusher
.mob Mate of Magmothregar
step
.goto BoreanTundra,57.1,19.0,20,0
.goto BoreanTundra,57.0,18.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11653 >>Turn in Hah... You're Not So Big Now!
.accept 11658 >>Accept Plan B
.isQuestTurnedIn 11650
.target Crafty Wobblesprocket
step << !Shaman
.goto BoreanTundra,57.01,18.68
>>|cRXP_WARN_Take the elevator up to|r |cRXP_FRIENDLY_Fizzcrank|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzcrank|r
.turnin 11873 >>Turn in Give Fizzcrank the News
.target Fizzcrank Fullthrottle
step
#completewith next
.goto BoreanTundra,49.3,21.4,0
.goto BoreanTundra,50.4,24.7,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_ENEMY_Dead Caravan Guards|r and |cRXP_ENEMY_Dead Caravan Workers|r. Loot them for their |cRXP_LOOT_Outfits|r
.complete 11658,1 
.skipgossip
.isQuestTurnedIn 11650
.mob Dead Caravan Guard
.mob Dead Caravan Worker
step
.goto BoreanTundra,49.59,26.68
>>Loot the |cRXP_LOOT_Warsong Banner|r on the ground
.complete 11658,2 
.isQuestTurnedIn 11650
step
.goto BoreanTundra,49.3,21.4,70,0
.goto BoreanTundra,50.4,24.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_ENEMY_Dead Caravan Guards|r and |cRXP_ENEMY_Dead Caravan Workers|r. Loot them for their |cRXP_LOOT_Outfits|r
.complete 11658,1 
.skipgossip
.isQuestTurnedIn 11650
.mob Dead Caravan Guard
.mob Dead Caravan Worker
step
#completewith next
.goto BoreanTundra,57.06,20.12,100 >> Travel to Fizzcrank Airstrip
.isQuestTurnedIn 11650
step
.goto BoreanTundra,57.06,20.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abner|r
.accept 11713 >>Accept Scouting the Sinkholes
.target Abner Fizzletorque
step
.goto BoreanTundra,57.1,19.0,20,0
.goto BoreanTundra,57.0,18.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11658 >>Turn in Plan B
.accept 11670 >>Accept It Was The Orcs, Honest!
.isQuestTurnedIn 11650
.target Crafty Wobblesprocket
step 
#completewith next
.goto BoreanTundra,54.2,13.3
.use 34871 >> |cRXP_WARN_Open|r |T133647:0|t[Crafty's Sack] |cRXP_WARN_for the|r |T132485:0|t[|cRXP_LOOT_Warsong Banner|r] |cRXP_WARN_and|r |T134475:0|t[|cRXP_LOOT_Warsong Orc Disguise|r]
.isQuestTurnedIn 11650
.collect 34869,1,11670,1 
.collect 34870,1,11670,1 
step
.goto BoreanTundra,54.2,13.3,40,0
.goto BoreanTundra,55.6,12.1
.use 34870 >> |cRXP_WARN_Use the|r |T134475:0|t[|cRXP_LOOT_Warsong Orc Disguise|r] |cRXP_WARN_in the Magmoth Cave|r
.complete 11670,2 
.isQuestTurnedIn 11650
step
.goto BoreanTundra,55.6,12.1
.use 34869 >>Kill |cRXP_ENEMY_Magmothregar|r inside Magmoth. |cRXP_WARN_Use the|r |T132485:0|t[|cRXP_LOOT_Warsong Banner|r] |cRXP_WARN_on his corpse|r
.complete 11670,1 
.isQuestTurnedIn 11650
.mob Magmothregar
step
#questguide
.goto BoreanTundra,55.6,12.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bonker|r
.accept 11673 >>Accept Get Me Outa Here!
.isQuestTurnedIn 11650
.target Bonker Togglevolt
step
#questguide
.goto BoreanTundra,53.8,13.8
>>Escort |cRXP_FRIENDLY_Bonker|r just outside of the cave
.complete 11673,1 
.isQuestTurnedIn 11650
.target Bonker Togglevolt
step
#completewith next
.goto BoreanTundra,64.43,23.40,100 >> Travel to the Fizzcrank Pumping Station
.isOnQuest 11798
step
#completewith next
.groundgoto BoreanTundra,65.62,22.95,20,0
.groundgoto BoreanTundra,64.87,24.14,15,0
.groundgoto BoreanTundra,64.71,22.93,15,0
.goto BoreanTundra,64.53,23.42
>>|cRXP_WARN_Go into the small house on the top level|r
.cast 3365 >>Click |cRXP_PICK_The Gearmaster's Manual|r on top of the table to summon |cRXP_ENEMY_Mechazod|r
.timer 51,The Gearmaster RP
.isOnQuest 11798
step
.goto BoreanTundra,64.54,23.26
|cRXP_WARN_Wait out his RP|r
>>Kill |cRXP_ENEMY_Mechazod|r. Loot him for his |cRXP_LOOT_Head|r
.complete 11798,1 
.complete 11798,2 
.mob Gearmaster Mechazod
step
#completewith next
.goto BoreanTundra,66.25,32.13,100 >> Travel to the Geyser Fields
step
#label Sinkhole
.use 34920 >> |cRXP_WARN_Use the|r |T134269:0|t[Map of the Geyser Fields] |cRXP_WARN_when standing on the edge of the|r |cRXP_PICK_Sinkholes|r
.complete 11713,3 
.goto BoreanTundra,66.25,32.13
.complete 11713,2 
.goto BoreanTundra,69.51,32.80
.complete 11713,1 
.goto BoreanTundra,70.24,36.36
step << Druid wotlk
#completewith DruidTrain2
.cast 18960 >> Cast Teleport: Moonglade
.zoneskip Moonglade
.xp <71,1
.cooldown item,6948,>2
step << Druid wotlk
.goto Moonglade,52.53,40.57
>>Go to Moonglade
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 48442 >> Train your class spells
.xp <71,1
.cooldown item,6948,>2
.target Loganaar
step << Druid wotlk
#label DruidTrain2
.goto Moonglade,52.53,40.57
>>Go to Moonglade
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 48464 >> Train your class spells
.xp <72,1
.cooldown item,6948,>2
.target Loganaar
step << DK wotlk
#completewith DKTraining3
.cast 50977 >> Cast Death Gate
.zoneskip Eastern Plaguelands
.xp <72,1
.cooldown item,6948,>2
step << DK wotlk
.goto Eastern Plaguelands,80.30,48.01
>>Go through the Death Gate
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amal'thazad|r
.train 49940 >> Train your class spells
.xp <72,1
.cooldown item,6948,>2
.target Amal'thazad
step << DK wotlk
#label DKTraining3
.goto Eastern Plaguelands,80.30,48.01
>>Go through the Death Gate
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amal'thazad|r
.train 49904 >> Train your class spells
.xp <73,1
.cooldown item,6948,>2
.target Amal'thazad
step << Mage wotlk
#completewith MageTrain2
.zone Stormwind City >> Teleport to Stormwind
.xp <71,1
.cooldown item,6948,>2
step << Mage wotlk
.goto StormwindNew,49.55,85.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jennea|r
.train 43023 >> Train your class spells
.xp <71,1
.cooldown item,6948,>2
.target Elsharin
.target Jennea Cannon
step << Mage wotlk
#label MageTrain2
.goto StormwindNew,49.55,85.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jennea|r
.train 42930 >> Train your class spells
.xp <72,1
.cooldown item,6948,>2
.target Elsharin
.target Jennea Cannon
step
#completewith GearM
.hs >> Hearth to Fizzcrank Airstrip
.cooldown item,6948,>2
step
.goto BoreanTundra,57.04,18.60
>>|cRXP_WARN_Take the elevator up to|r |cRXP_FRIENDLY_Fizzcrank|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzcrank|r
.turnin 11798 >>Turn in The Gearmaster
.isQuestTurnedIn 11673
.target Fizzcrank Fullthrottle
step
#label GearM
.goto BoreanTundra,57.04,18.60
>>|cRXP_WARN_Take the elevator up to|r |cRXP_FRIENDLY_Fizzcrank|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzcrank|r
.turnin 11798 >>Turn in The Gearmaster
.turnin 11673 >>Turn in Get Me Outa Here!
.target Fizzcrank Fullthrottle
step
#questguide << !wotlk
.goto BoreanTundra,57.08,20.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abner|r
.turnin 11713 >>Turn in Scouting the Sinkholes
.accept 11715 >>Accept Fueling the Project
.target Abner Fizzletorque
step << !wotlk
.goto BoreanTundra,57.08,20.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abner|r
.turnin 11713 >>Turn in Scouting the Sinkholes
.target Abner Fizzletorque
step
.goto BoreanTundra,57.1,19.0,20,0
.goto BoreanTundra,57.0,18.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crafty|r
>>|cRXP_FRIENDLY_Crafty|r |cRXP_WARN_patrols the outside|r
.turnin 11670 >>Turn in It Was The Orcs, Honest!
.isQuestComplete 11670
.target Crafty Wobblesprocket
step
#questguide << !wotlk
.goto BoreanTundra,56.8,26.2,70,0
.goto BoreanTundra,62.4,29.4,70,0
.goto BoreanTundra,61.8,36.0
.use 34975 >>|cRXP_WARN_Use the|r |T132997:0|t[Portable Oil Collector] |cRXP_WARN_on |cRXP_PICK_Oil Patches|r on the ground|r
.complete 11715,1 
step
#completewith next
.goto BoreanTundra,43.50,13.97,120 >>Travel to Winterfin Retreat
step
.goto BoreanTundra,43.50,13.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.accept 11571 >>Accept Learning to Communicate
.turnin 11704 >>Turn in King Mrgl-Mrgl
.target King Mrgl-Mrgl
step
.goto BoreanTundra,43.0,18.1,60,0
.goto BoreanTundra,42.5,15.4
.use 34598 >>Kill |cRXP_ENEMY_Scalder|r underwater. |cRXP_WARN_Use|r |T134431:0|t[The King's Empty Conch] |cRXP_WARN_on its corpse|r
>>|cRXP_ENEMY_Scalder|r |cRXP_WARN_patrols the seabed|r
.complete 11571,1 
.unitscan Scalder
step
.goto BoreanTundra,43.50,13.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 11571 >>Turn in Learning to Communicate
.accept 11559 >>Accept Winterfin Commerce
.target King Mrgl-Mrgl
step
.goto BoreanTundra,40.5,15.8,70,0
.goto BoreanTundra,41.6,18.9
>>Kill |cRXP_ENEMY_Winterfin Oracles|r, |cRXP_ENEMY_Winterfin Shorestrikers|r and |cRXP_ENEMY_Winterfin Warriors|r. Loot them for their |cRXP_LOOT_Winterfin Clams|r
>>|cRXP_WARN_Alternatively|r Loot the |cRXP_LOOT_Winterfin Clams|r on the ground
>>|cRXP_WARN_They are usually found next to Murloc huts but can be difficult to spot|r
.complete 11559,1 
.mob Winterfin Oracle
.mob Winterfin Shorestriker
.mob Winterfin Warrior
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ahlurglgr|r, |cRXP_FRIENDLY_King Mrgl-Mrgl|r, and |cRXP_FRIENDLY_Brglmurgl|r
.turnin 11559 >>Turn in Winterfin Commerce
.goto BoreanTundra,43.04,13.82
.accept 11560 >>Accept Oh Noes, the Tadpoles!
.goto BoreanTundra,43.50,13.97
.accept 11561 >>Accept Them!
.goto BoreanTundra,42.82,13.65
.target Brglmurgl
.target Ahlurglgr
.target King Mrgl-Mrgl
step
#completewith next
.goto BoreanTundra,41.0,15.6,0
.goto BoreanTundra,41.3,19.0,0
.goto BoreanTundra,39.2,18.3,0
.goto BoreanTundra,37.6,15.9,0
>>Kill |cRXP_ENEMY_Winterfin Oracles|r, |cRXP_ENEMY_Winterfin Shorestrikers|r and |cRXP_ENEMY_Winterfin Warriors|r
>>|cRXP_WARN_Do not prioritize this|r
.complete 11561,1 
.mob Winterfin Oracle
.mob Winterfin Shorestriker
.mob Winterfin Warrior
step
#sticky
#label tadpoles
.goto BoreanTundra,41.0,15.6,40,0
.goto BoreanTundra,41.3,19.0,40,0
.goto BoreanTundra,39.2,18.3,40,0
.goto BoreanTundra,37.6,15.9,40,0
.goto BoreanTundra,41.0,15.6,40,0
.goto BoreanTundra,41.3,19.0,40,0
.goto BoreanTundra,40.04,19.80,40,0
.goto BoreanTundra,39.2,18.3,40,0
.goto BoreanTundra,37.6,15.9
>>Click the |cRXP_PICK_Cages|r to rescure |cRXP_FRIENDLY_Winterfin Tadpoles|r
>>|cRXP_WARN_You may have to go inside the Winterfin Caverns for more|r
.complete 11560,1 
.target Winterfin Tadpole
step
.goto BoreanTundra,40.04,19.80
.use 34669 >> |cRXP_WARN_Use the|r |T133015:0|t[Arcanometer] |cRXP_WARN_at the entrance of the Winterfin Caverns|r
.complete 12728,1 
step
#completewith end
#requires tadpoles
#label Murloc2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brglmurgl|r
.turnin 11561 >>Turn in Them!
.goto BoreanTundra,42.82,13.65,0,0
.isQuestComplete 11561
.target Brglmurgl
step
#requires tadpoles
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 11560 >>Turn in Oh Noes, the Tadpoles!
.accept 11562 >>Accept I'm Being Blackmailed By My Cleaner
.goto BoreanTundra,43.50,13.97
.target King Mrgl-Mrgl
step
#requires Murloc2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mrmrglmr|r and |cRXP_FRIENDLY_Bmurglbrm|r
.turnin 11562 >>Turn in I'm Being Blackmailed By My Cleaner
.accept 11563 >>Accept Grmmurggll Mrllggrl Glrggl!!!
.goto BoreanTundra,41.98,12.77
.accept 11564 >>Accept Succulent Orca Stew
.goto BoreanTundra,42.03,13.16
.target Mrmrglmr
.target Brglmurgl
step
#completewith next
.goto BoreanTundra,38.0,9.5,0
.goto BoreanTundra,36.4,8.8,0
.goto BoreanTundra,37.4,6.3,0
.goto BoreanTundra,39.3,8.3,0
>>Kill |cRXP_ENEMY_Glimmer Bay Orcas|r. Loot them for their |cRXP_LOOT_Blubbers|r
.complete 11564,1 
.mob Glimmer Bay Orca
step
.goto BoreanTundra,38.0,9.5,70,0
.goto BoreanTundra,36.4,8.8,70,0
.goto BoreanTundra,37.4,6.3,70,0
.goto BoreanTundra,39.3,8.3
>>Kill |cRXP_ENEMY_Glrggl|r. Loot him for his |cRXP_LOOT_Head|r. |cRXP_WARN_He patrols counter-clockwise around the two northern icebergs|r
.complete 11563,1 
.unitscan Glrggl
step
.goto BoreanTundra,40.1,12.2,70,0
.goto BoreanTundra,39.3,6.7,70,0
.goto BoreanTundra,36.0,8.1
>>Kill |cRXP_ENEMY_Glimmer Bay Orcas|r. Loot them for their |cRXP_LOOT_Blubbers|r
.complete 11564,1 
.mob Glimmer Bay Orca
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mrmrglmr|r, |cRXP_FRIENDLY_Bmurglbrm|r, and |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 11563 >>Turn in Grmmurggll Mrllggrl Glrggl!!!
.accept 11565 >>Accept The Spare Suit
.goto BoreanTundra,41.98,12.77
.turnin 11564 >>Turn in Succulent Orca Stew
.goto BoreanTundra,42.03,13.16
.turnin 11565 >>Turn in The Spare Suit
.accept 11566 >>Accept Surrender... Not!
.goto BoreanTundra,43.50,13.97
.target King Mrgl-Mrgl
.target Mrmrglmr
.target Cleaver Bmurglbrm
step
#completewith next
.goto BoreanTundra,37.84,23.23,165 >> Enter Winterfin Caverns
step
#completewith Lurgglbr
.goto BoreanTundra,41.0,15.6,0
.goto BoreanTundra,41.3,19.0,0
.goto BoreanTundra,39.2,18.3,0
.goto BoreanTundra,37.6,15.9,0
>>Kill |cRXP_ENEMY_Winterfin Oracles|r, |cRXP_ENEMY_Winterfin Shorestrikers|r and |cRXP_ENEMY_Winterfin Warriors|r
>>|cRXP_WARN_Do not prioritize this|r
.complete 11561,1 
.mob Winterfin Oracle
.mob Winterfin Shorestriker
.mob Winterfin Warrior
step
.goto BoreanTundra,37.84,23.23
>>|cRXP_WARN_Stick to the left side once you enter Winterfin Caverns|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Glrglrglr|r
>>|cRXP_WARN_Do NOT Talk to |r|cRXP_FRIENDLY_Lurgglbr|r |cRXP_WARN_yet|r
.accept 11569 >>Accept Keymaster Urmgrgl
.target Glrglrglr
step
.goto BoreanTundra,38.0,22.2,12,0
.goto BoreanTundra,39.0,22.7,30,0
.goto BoreanTundra,39.8,22.5,30,0
.goto BoreanTundra,39.3,23.7
>>|cRXP_WARN_Run down the ramp below|r
>>Kill |cRXP_ENEMY_Keymaster Urmgrgl|r. Loot him for his |cRXP_LOOT_Key|r
.complete 11569,1 
.unitscan Keymaster Urmgrgl
step
#completewith next
.goto BoreanTundra,37.0,21.8,40,0
.goto BoreanTundra,36.9,24.0,40 >> Travel to the end of Winterfin Caverns
step
.goto BoreanTundra,37.55,27.53
>>Kill |cRXP_ENEMY_Claximus|r. Loot him for his |cRXP_LOOT_Claw|r
.complete 11566,1 
.mob Claximus
step
#completewith next
.goto BoreanTundra,36.80,23.22,40,0
.goto BoreanTundra,37.87,21.52,25,0
.goto BoreanTundra,37.84,23.23,30 >> Travel toward |cRXP_FRIENDLY_Glrglrglr|r near the entrance
step
.goto BoreanTundra,37.84,23.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Glrglrglr|r
.turnin 11569 >>Turn in Keymaster Urmgrgl
.target Glrglrglr
step
#questguide
.goto BoreanTundra,37.72,23.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lurgglbr|r
.accept 11570 >>Accept Escape from the Winterfin Caverns
.target Lurgglbr
step
#questguide
#label Lurgglbr
.goto BoreanTundra,39.9,19.8,40,0
.goto BoreanTundra,39.6,18.1,40,0
.goto BoreanTundra,41.36,16.32
>>Escort |cRXP_FRIENDLY_Lurgglbr|r. |cRXP_WARN_Try to kill |cRXP_ENEMY_Murlocs|r that he'd otherwise run into so that he doesn't waste time by stopping and attacking|r
.complete 11570,1 
.target Lurgglbr
step
.goto BoreanTundra,41.0,15.6,70,0
.goto BoreanTundra,41.3,19.0,70,0
.goto BoreanTundra,39.2,18.3,70,0
.goto BoreanTundra,37.6,15.9
>>Kill |cRXP_ENEMY_Winterfin Oracles|r, |cRXP_ENEMY_Winterfin Shorestrikers|r and |cRXP_ENEMY_Winterfin Warriors|r
.complete 11561,1 
.mob Winterfin Oracle
.mob Winterfin Shorestriker
.mob Winterfin Warrior
step
.goto BoreanTundra,42.82,13.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brglmurgl|r
.turnin 11561 >>Turn in Them!
.target Brglmurgl
step
#label Murliver
.goto BoreanTundra,43.04,13.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ahlurglgr|r
.vendor >>Purchase as many |T134800:0|t[Murliver Oils] as you can
.itemcount 34597,2
.isQuestTurnedIn 11559
.target Ahlurglgr
step
#questguide
.goto BoreanTundra,43.50,13.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 11566 >>Turn in Surrender... Not!
.turnin 11570 >>Turn in Escape from the Winterfin Caverns
.target King Mrgl-Mrgl
step
.goto BoreanTundra,43.50,13.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Mrgl-Mrgl|r
.turnin 11566 >>Turn in Surrender... Not!
.target King Mrgl-Mrgl
step << Druid wotlk
#requires Murliver
#completewith DruidTrain3
.cast 18960 >> Cast Teleport: Moonglade
.zoneskip Moonglade
.xp <71,1
.cooldown item,6948,>2
step << Druid wotlk
#requires Murliver
.goto Moonglade,52.53,40.57
>>Go to Moonglade
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 48442 >> Train your class spells
.xp <71,1
.cooldown item,6948,>2
.target Loganaar
step << Druid wotlk
#requires Murliver
#label DruidTrain3
.goto Moonglade,52.53,40.57
>>Go to Moonglade
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 48464 >> Train your class spells
.xp <72,1
.cooldown item,6948,>2
.target Loganaar
step << DK wotlk
#requires Murliver
#completewith next
.cast 50977 >> Cast Death Gate
.zoneskip Eastern Plaguelands
.xp <72,1
.cooldown item,6948,>2
step << DK wotlk
#requires Murliver
.goto Eastern Plaguelands,80.30,48.01
>>Go through the Death Gate
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amal'thazad|r
.train 49940 >> Train your class spells
.xp <72,1
.cooldown item,6948,>2
.target Amal'thazad
step << Mage wotlk
#requires Murliver
#completewith MageTrain3
.zone Stormwind City >> Teleport to Stormwind
.xp <71,1
.cooldown item,6948,>2
step << Mage wotlk
#requires Murliver
.goto StormwindNew,49.55,85.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jennea|r
.train 43023 >> Train your class spells
.xp <71,1
.cooldown item,6948,>2
.target Elsharin
.target Jennea Cannon
step << Mage wotlk
#requires Murliver
#label MageTrain3
.goto StormwindNew,49.55,85.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jennea|r
.train 42930 >> Train your class spells
.xp <72,1
.cooldown item,6948,>2
.target Elsharin
.target Jennea Cannon
step << (Shaman/DK/Mage/Druid) wotlk
#completewith next
.hs >> Hearth to Fizzcrank Airstrip
.cooldown item,6948,>2
step << (!Shaman !DK !Mage !Druid) wotlk
#completewith next
.goto BoreanTundra,57.02,20.12,150 >> Travel to Fizzcrank Airstrip
step
#questguide << !wotlk
.goto BoreanTundra,57.02,20.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abner|r
.turnin 11715 >>Turn in Fueling the Project
.accept 11718 >>Accept A Bot in Mammoth's Clothing
.target Abner Fizzletorque
step
#questguide << !wotlk
.goto BoreanTundra,53.55,21.34,70,0
.goto BoreanTundra,53.6,31.2,70,0
.goto BoreanTundra,52.9,40.5,70,0
.goto BoreanTundra,53.55,21.34
>>Kill |cRXP_ENEMY_Wooly Mammoths|r, |cRXP_ENEMY_Wooly Mammoth Bulls|r and |cRXP_ENEMY_Mammoth Calves|r. Loot them for their |cRXP_LOOT_Hides|r
.complete 11718,1 
.mob Mammoth Calf
.mob Wooly Mammoth
.mob Wooly Mammoth Bull
step
#completewith next
.groundgoto BoreanTundra,48.4,36.4,50,0
.goto BoreanTundra,44.98,33.38,50 >> Travel to Amber Ledge
step
.goto BoreanTundra,44.98,33.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garren|r
.turnin 12728 >>Turn in Monitoring the Rift: Winterfin Cavern
.target Librarian Garren
step
#questguide << !wotlk
#completewith next
.goto BoreanTundra,45.33,34.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Surristrasz|r
.fly Fizzcrank >> Fly to Fizzcrank Airstrip
.target Surristrasz
step
#questguide << !wotlk
.goto BoreanTundra,57.05,20.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abner|r
.turnin 11718 >>Turn in A Bot in Mammoth's Clothing
.accept 11723 >>Accept Deploy the Shake-n-Quake!
.target Abner Fizzletorque
step
#questguide << !wotlk
#completewith next
.goto BoreanTundra,70.20,36.40,120 >> Travel to the Geyser Fields
.isOnQuest 11723
step
#questguide << !wotlk
#completewith next
.goto BoreanTundra,70.20,36.40
.cast 46017 >> |cRXP_WARN_Use the|r |T133015:0|t[Shake-n-Quake 5000 Control Unit] |cRXP_WARN_next to the |cRXP_PICK_Sinkhole|r to summon|r |cRXP_ENEMY_Lord Kryxix|r
.use 34981
.timer 36,Deploy the Shake-n-Quake! RP
step
#questguide << !wotlk
.goto BoreanTundra,69.78,36.46
>>|cRXP_WARN_Wait out the RP |r
>>Kill |cRXP_ENEMY_Lord Kryxix|r
.complete 11723,1 
.complete 11723,2 
.use 34981
.mob Lord Kryxix
step
#questguide << !wotlk
#completewith next
.goto BoreanTundra,57.09,20.07,150 >> Travel to Fizzcrank Airstrip
step
#questguide << !wotlk
#label end
.goto BoreanTundra,57.09,20.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abner|r
.turnin 11723 >>Turn in Deploy the Shake-n-Quake!
.target Abner Fizzletorque
step << (Shaman/Warlock/Paladin/Hunter/Rogue/Warrior) wotlk
#completewith next
.goto BoreanTundra,56.56,20.07
.zone Stormwind City >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kara|r
.fly Valiance Keep >> Fly to Valiance Keep. Alternatively pay a |T626001:0|t|cFF3FC7EBMage|r for a portal to Stormwind
.zoneskip Elwynn Forest
.zoneskip Stormwind City
.target Kara Thricestar
step << (Shaman/Warlock/Paladin/Hunter/Rogue/Warrior) wotlk
#completewith ShamanTrain << Shaman
#completewith next << !Shaman
.goto BoreanTundra,59.70,69.26
.zone Stormwind City >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nelno|r. Ask him for a teleport to Stormwind Harbor
.zoneskip Elwynn Forest
.skipgossip
.target Nelno Copperbeam
step << Shaman wotlk
.goto StormwindNew,67.52,89.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umbrua|r
.train 58801 >> Train your class spells
.xp <71,1
.target Farseer Umbrua
step << Shaman wotlk
#label ShamanTrain
.goto StormwindNew,67.52,89.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umbrua|r
.train 49237 >> Train your class spells
.xp <73,1
.target Farseer Umbrua
step << Warlock wotlk
.goto StormwindNew,42.26,81.77,20,0
.goto StormwindNew,40.64,84.94,15,0
.goto StormwindNew,39.88,84.19
>>Go into The Slaughtered Lamb and go downstairs
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ursula|r, |cRXP_FRIENDLY_Demisette|r or |cRXP_FRIENDLY_Sandahl|r
.train 47812 >> Train your class spells
.xp <71,1
.target Ursula Deline
.target Demisette Cloyce
.target Sandahl
step << Paladin wotlk
.goto StormwindNew,52.9,50.9,20,0
.goto StormwindNew,49.8,48.5,20,0
.goto StormwindNew,49.60,49.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arthur|r or |cRXP_FRIENDLY_Katherine|r
.train 54428 >> Train your class spells
.xp <71,1
.target Arthur the Faithful
.target Katherine the Pure
step << Hunter wotlk
.goto StormwindNew,67.3,37.1,15,0
.goto StormwindNew,67.35,36.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Einris|r
.train 49051 >> Train your class spells
.xp <71,1
.target Einris Brightspear
step << Rogue wotlk
.goto StormwindNew,77.42,65.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Osborne|r
.train 48667 >> Train your class spells
.xp <73,1
.target Osborne the Night Man
step << Warrior wotlk
.goto StormwindNew,78.31,63.53,15,0
.goto StormwindNew,81.66,59.50,15,0
.goto StormwindNew,80.56,59.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wu|r or |cRXP_FRIENDLY_Ilsa|r
.train 47470 >> Train your class spells
.xp <73,1
.target Wu Shen
.target Ilsa Corbin
step << (Shaman/Warlock/Paladin/Hunter/Rogue/Warrior) wotlk
#completewith next
.hs >> Hearth to Fizzcrank Airstrip
.zoneskip BoreanTundra
step
#completewith next
.goto BoreanTundra,45.33,34.54,-1
.goto BoreanTundra,56.57,20.08,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kara Thricestar|r or |cRXP_FRIENDLY_Surristrasz|r
.fly Stars >> Fly to Stars' Rest
.target Surristrasz
.target Kara Thricestar
step
.goto Dragonblight,12.16,55.22
.zone Dragonblight >> Travel to Dragonblight
step << !wotlk
#xprate >1.59
.goto Dragonblight,29.00,55.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Modera|r
.turnin -12107 >>Turn in The End of the Line
.accept 12794 >> Accept The Magical Kingdom of Dalaran
.target Image of Archmage Modera
step << !wotlk
#xprate >1.59
.goto Dragonblight,29.00,55.45
.zone Dalaran >>Ask |cRXP_FRIENDLY_Modera|r for a teleport to Dalaran
.skipgossip
.xp <74,1
.isOnQuest 12794
.target Image of Archmage Modera
step << !wotlk
#xprate >1.59
.abandon 12794 >> Abandon The Magical Kingdom of Dalaran
step << wotlk
#xprate >1.499
.goto Dragonblight,28.84,56.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanson|r
.accept 12171 >>Accept Of Traitors and Treason
.target Courier Lanson
step << wotlk
#xprate >1.499
.goto Dragonblight,29.16,55.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Palena|r
>>|cRXP_WARN_Accepting this quest will send you flying to eastern Dragonblight|r
.turnin 12171 >>Turn in Of Traitors and Treason
.accept 12174 >>Accept High Commander Halford Wyrmbane
.timer 88,Westguard Keep Flight
.target Palena Silvercloud
step << wotlk
#xprate >1.499
.goto Dragonblight,77.08,49.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rodney|r
.fp Wintergarde Keep >>Get the Wintergarde Keep Flight Path
.target Rodney Wells
step << wotlk
#xprate >1.499
.goto Dragonblight,78.59,48.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halford Wyrmbane|r
.turnin 12174 >>Turn in High Commander Halford Wyrmbane
.target High Commander Halford Wyrmbane
step << wotlk
#xprate >1.499
.xp <73,1
#label Hills
.goto Dragonblight,77.13,50.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urik|r
>>|cRXP_WARN_Accepting this quest will send you flying to Grizzly Hills|r
.accept 12511 >>Accept The Hills Have Us
.timer 150,Fly to Amberpine Lodge
.target Gryphon Commander Urik
step << wotlk
#xprate >1.499
.zone Grizzly Hills >> Travel to Grizzly Hills
]])

