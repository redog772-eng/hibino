if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "WOTLK" then return end

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 113 Blackrock Depths
#displayname 13. Blackrock Depths
step
#completewith KargathBRDQuests
+You will now begin to collect quests for Blackrock Depths
>>Blackrock Depths is a very convoluted dungeon. In order to complete all quests in the most efficient way, it is required to leave the dungeon midrun to turn in/accept follow up quests so it may all be completed in 1 run
>>|cRXP_WARN_Try to ensure all party members have the same quests and prequests complete, along with 2-3 hours of playtime|r
step
.goto Badlands,3.77,47.47
>>Click the |cRXP_PICK_Wanted Poster|r
.accept 4081 >> Accept KILL ON SIGHT: Dark Iron Dwarves
step
.goto Badlands,3.31,48.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
>>|cRXP_FRIENDLY_Thunderheart|r|cRXP_WARN_might be patrolling around the mountain at Kargath. Find him or wait for him to return|r
.accept 3906 >> Accept Disharmony of Flame
.unitscan Thunderheart
step
.goto Badlands,2.90,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
>>|cRXP_FRIENDLY_Vivian|r|cRXP_WARN_might be patrolling around the mountain near Kargath. Find her or wait for her to return|r
.accept 7201 >> Accept The Last Element
.accept 4134 >> Accept Lost Thunderbrew Recipe
.unitscan Shadowmage Vivian Lagrave
.isQuestTurnedIn 3906 
step
#optional
.goto Badlands,2.90,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
>>|cRXP_FRIENDLY_Vivian|r|cRXP_WARN_might be patrolling around the mountain near Kargath. Find her or wait for her to return|r
.accept 4134 >> Accept Lost Thunderbrew Recipe
.unitscan Shadowmage Vivian Lagrave
step
#label KargathBRDQuests
.goto Badlands,3.03,47.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hierophant Theodora Mulvadania|r
.accept 4061 >> Accept The Rise of the Machines
.target Hierophant Theodora Mulvadania
step
#completewith next
+|cRXP_WARN_Set your hearthstone to Kargath if you have a mage in your group!|r
step
.goto Badlands,3.98,44.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fly Flame Crest >> Fly to Flame Crest
.target Gorrik
.zoneskip Burning Steppes
step
.goto Burning Steppes,65.152,23.911
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.accept 4123 >> Accept The Heart of the Mountain
.target Maxwort Uberglint
step
.goto Burning Steppes,66.058,21.951
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yuka Screwspigot|r
.accept 4136 >> Accept Ribbly Screwspigot
.target Yuka Screwspigot
step
#loop
.goto Burning Steppes,67.37,44.38,0
.goto Burning Steppes,62.74,34.92,60,0
.goto Burning Steppes,57.43,36.36,60,0
.goto Burning Steppes,53.03,39.25,60,0
.goto Burning Steppes,59.19,40.17,60,0
.goto Burning Steppes,63.33,43.19,60,0
.goto Burning Steppes,67.37,44.38,60,0
>>Kill |cRXP_ENEMY_War Reavers|r. Loot them for their |cRXP_LOOT_Shards|r
>>|cRXP_WARN_Completing this will unlock an optional BRD quest. It can be skipped|r
.complete 4061,1 
.mob War Reaver
step
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
>>Select the option: "I present you with proof of my deeds, Cyrus."
.accept 4022 >> Accept A Taste of Flame
.turnin 4022 >> Turn in A Taste of Flame
.itemcount 10575,1 
.target Cyrus Therepentous
.isQuestTurnedIn 3481
step
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
>>If you are missing the |T134430:0|t[Black Dragonflight Molt] and cannot complete the quest, talk to |cRXP_FRIENDLY_Cyrus|r and select the option: "I do not possess any proof, Cyrus."
>>This will spawn a level 54 Elite Dragon at the entrance of the small cave. Ensure you have party members with you to help kill it, then loot it for the |T134430:0|t[Black Dragonflight Molt]
>>Select the option after: "I present you with proof of my deeds, Cyrus."
.collect 10575,1,4022,1 
.accept 4022 >> Accept A Taste of Flame
.turnin 4022 >> Turn in A Taste of Flame
.target Cyrus Therepentous
.isQuestAvailable 4022
step
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
.accept 4024 >> Accept A Taste of Flame
.target Cyrus Therepentous
.isQuestTurnedIn 4022
step
#completewith CoreAttunement
.subzone 25 >> Travel to Blackrock Mountain
step
#softcoreserver
#softcore
+Die intentionally in the lava in Blackrock Mountain, ideally near the Molten Core entrance location
>>For this step you must be a |T132331:0|t[Ghost] to talk to |cRXP_FRIENDLY_Franclorn Forgewright|r inside Blackrock Mountain. Resurrect at your corpse once you have the quest
.goto 1415,48.624,64.186
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Franclorn Forgewright|r
.accept 3801 >> Accept Dark Iron Legacy
.turnin 3801 >> Turn in Dark Iron Legacy
.accept 3802 >> Accept Dark Iron Legacy
.target Franclorn Forgewright
step
#hardcoreserver
.goto 1415,48.656,64.134
.cast 417803 >>|cRXP_WARN_Click the |cRXP_PICK_Brazier of Embersight|r to gain the|r |T136215:0|t[Emberglow Vision] |cRXP_WARN_debuff|r
step
#hardcoreserver
.goto 1415,48.624,64.186
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Franclorn Forgewright|r
>>|cRXP_WARN_You must have the|r |T136215:0|t[Emberglow Vision] |cRXP_WARN_debuff to see him|r
.accept 3801 >> Accept Dark Iron Legacy
.turnin 3801 >> Turn in Dark Iron Legacy
.accept 3802 >> Accept Dark Iron Legacy
.target Franclorn Forgewright
step
#label CoreAttunement
.goto 1415,48.409,63.815
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothos Riftwaker|r
.accept 7848 >> Accept Attunement to the Core
.target Lothos Riftwaker
step
>>Kill |cRXP_ENEMY_Overmaster Pyron|r
>>|cRXP_ENEMY_Overmaster Pyron|r |cRXP_WARN_patrols outside of the BRD instance portal|r
.complete 3906,1 
.mob Overmaster Pyron
.isOnQuest 3906
step
#label EnterBRD1
.subzone 1584 >>Enter the Blackrock Depths instance
step
>>Kill |cRXP_ENEMY_Anvilrage Dwarves|r
.complete 4081,1 
.mob +Anvilrage Guardsman
.complete 4081,2 
.mob +Anvilrage Warden
.complete 4081,3 
.mob +Anvilrage Footman
.isOnQuest 4081
step
#completewith next
+Travel back to Kargath
step
.goto Badlands,3.31,48.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
>>|cRXP_FRIENDLY_Thunderheart|r|cRXP_WARN_might be patrolling around the mountain at Kargath. Find him or wait for him to return|r
.turnin 3906 >> Turn in Disharmony of Flame
.unitscan Thunderheart
.isQuestComplete 3906
step
.goto Badlands,3.31,48.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
>>|cRXP_FRIENDLY_Thunderheart|r|cRXP_WARN_might be patrolling around the mountain at Kargath. Find him or wait for him to return|r
.accept 3907 >> Accept Disharmony of Fire
.unitscan Thunderheart
.isQuestTurnedIn 3906
step
.goto Badlands,3.03,47.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hierophant Theodora Mulvadania|r
.turnin 4061 >> Turn in The Rise of the Machines
.target Hierophant Theodora Mulvadania
.isQuestComplete 4061
step
.goto Badlands,3.03,47.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hierophant Theodora Mulvadania|r
.accept 4062 >> Accept The Rise of the Machines
.target Hierophant Theodora Mulvadania
.isQuestTurnedIn 4061
step
.goto Badlands,5.81,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Goretooth|r
.turnin 4081 >> Turn in KILL ON SIGHT: Dark Iron Dwarves
.target Warlord Goretooth
.isQuestComplete 4081
step
.goto Badlands,5.96,47.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Galamav the Marksman|r on top of the tower
.accept 3981 >> Accept Commander Gor'shak
.target Galamav the Marksman
.isQuestTurnedIn 3906
step
.goto Badlands,3.97,46.77
>>Click the |cRXP_PICK_Wanted Poster|r
.accept 4082 >> Accept KILL ON SIGHT: High Ranking Dark Iron Officials
.isQuestTurnedIn 4081
step
.goto Badlands,25.95,44.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil Veriatus|r
.turnin 4062 >> Turn in The Rise of the Machines
.accept 4063 >> Accept The Rise of the Machines
.target Lotwil Veriatus
.isQuestTurnedIn 4061
step
#label EnterBRD2
.subzone 1584 >>Return to Blackrock Mountain and enter the Blackrock Depths instance
step
#completewith WhatsGoingOn
>>Kill |cRXP_ENEMY_Fire Elementals|r and |cRXP_ENEMY_Golems|r. Loot them for their |cRXP_LOOT_Essence of the Elements|r
>>|cRXP_WARN_This quest does not need to be completed now|r
.complete 7201,1 
.isOnQuest 7201
step
#completewith next
+Complete the Ring of Law boss event, then take the exit up the tunnel and immediately turn right, crossing up over the top of the Ring of Law, making your way to the Vault
step
>>Loot |cRXP_LOOT_The Heart of the Mountain|r inside of the safe wall. It takes 15 seconds for it to respawn
>>There is a trick which allows you to loot it without having to open the safe. View the link below to see how it is done
.complete 4123,1 
.link https://youtu.be/694e1n_aiKY >> Click here to see how to loot the Heart of the Mountain
.isOnQuest 4123
step
>>Kill |cRXP_ENEMY_Fineous Darkvire|r. Loot him for the |cRXP_LOOT_Ironfel|r
.complete 3802,1 
.target Fineous Darkvire
.isOnQuest 3802
step
>>Kill |cRXP_ENEMY_Lord Incendius|r
.complete 3907,1 
.target Lord Incendius
.isOnQuest 3907
step
>>Run back near the location above the Ring of Law
>>Click the |cRXP_PICK_Monument of Franclorn Forgewright|r
.turnin 3802 >> Turn in Dark Iron Legacy
.isQuestComplete 3802
step
#completewith next
>>Kill |cRXP_ENEMY_Anvilrage Dwarves|r
.complete 4082,1 
.mob +Anvilrage Medic
.complete 4082,2 
.mob +Anvilrage Soldier
.complete 4082,3 
.mob +Anvilrage Officer
.isOnQuest 4082
step
>>Head to the Shadowforge Gates at the start of the entrance
>>Kill |cRXP_ENEMY_Bael'Gar|r
.use 11231 >>|cRXP_WARN_Use the|r |T134430:0|t[Altered Black Dragonflight Molt] |cRXP_WARN_on his corpse|r
.complete 4024,1 
.mob Bael'Gar
.isOnQuest 4024
step
>>Finish killing |cRXP_ENEMY_Anvilrage Dwarves|r
.complete 4082,1 
.mob +Anvilrage Medic
.complete 4082,2 
.mob +Anvilrage Soldier
.complete 4082,3 
.mob +Anvilrage Officer
.isOnQuest 4082
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Gor'shak|r
>>If your group does not have a Rogue you may need to kill |cRXP_ENEMY_High Interrogator Gerstahn|r for the |cRXP_LOOT_Prison Cell Key|r to open the doors
>>|cRXP_WARN_ENSURE ALL PARTY MEMBERS HAVE AUTO ACCEPT OFF FOR THIS STEP! RestedXP HAS AUTO ACCEPT OFF FOR THIS STEP|r
.turnin 3981 >> Turn in Commander Gor'shak
.accept 3982,1 >> Accept What Is Going On?
.target Commander Gor'shak
step
>>Defend |cRXP_FRIENDLY_Commander Gor'shak|r from the incoming |cRXP_ENEMY_Anvilrage Dwarves|r
.complete 3982,1 
.target Commander Gor'shak
.isQuestTurnedIn 3981
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Gor'shak|r
.turnin 3982 >> Turn in What Is Going On?
.accept 4001 >> Accept What Is Going On?
.target Commander Gor'shak
.isQuestTurnedIn 3981
step
#label WhatsGoingOn
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kharan Mighthammer|r and listen to his story
>>|cRXP_WARN_He is located accross the hall from|r |cRXP_FRIENDLY_Commander Gor'shak|r
.complete 4001,1 
.target Kharan Mighthammer
.skipgossip
.isQuestTurnedIn 3981
step
#completewith RoyalResc
.zone Orgrimmar >>Travel to |cFFfa9602Orgrimmar|r
step
.goto Orgrimmar,31.74,37.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r
.turnin 4001 >> Turn in What Is Going On?
.accept 4002 >> Accept The Eastern Kingdoms
.target Thrall
.isQuestTurnedIn 3982
step
.goto Orgrimmar,31.74,37.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r again
.complete 4002,1
.target Thrall
.isQuestTurnedIn 3982
step
#label RoyalResc
.goto Orgrimmar,31.74,37.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r
.turnin 4002 >> Turn in The Eastern Kingdoms
.accept 4003 >> Accept The Royal Rescue
.target Thrall
.isQuestTurnedIn 3982
step
#completewith EnterBRD3
+Hearth to Kargath if you put your hearthstone there. If you didn't, take the zeppelin to Stranglethorn and fly there instead
step
.goto Badlands,3.31,48.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
>>|cRXP_FRIENDLY_Thunderheart|r|cRXP_WARN_might be patrolling around the mountain at Kargath. Find him or wait for him to return|r
.turnin 3907 >> Turn in Disharmony of Fire
.unitscan Thunderheart
.isQuestComplete 3907
step
.goto Badlands,2.90,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
>>|cRXP_FRIENDLY_Vivian|r|cRXP_WARN_might be patrolling around the mountain near Kargath. Find her or wait for her to return|r
.turnin 7201 >> Turn in The Last Element
.unitscan Shadowmage Vivian Lagrave
.isQuestComplete 7201
step
.goto Badlands,5.81,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Goretooth|r
.turnin 4082 >> Turn in KILL ON SIGHT: High Ranking Dark Iron Officials
.target Warlord Goretooth
.isQuestComplete 4082
step
#label EnterBRD3
.subzone 1584 >>Enter Blackrock Depths
step
#completewith PrincessSaved
>>Kill |cRXP_ENEMY_Fire Elementals|r and |cRXP_ENEMY_Golems|r. Loot them for their |cRXP_LOOT_Essence of the Elements|r
.complete 7201,1 
.isOnQuest 7201
step
>>Kill |cRXP_ENEMY_Golem Lord Argelmach|r. Loot him for his |cRXP_LOOT_Head|r
>>Kill |cRXP_ENEMY_Golems|r. Loot them for their |cRXP_LOOT_Elemental Cores|r
.complete 4063,1 
.mob +Golem Lord Argelmach
.complete 4063,2 
.mob +Wrath Hammer Construct
step
#completewith next
>>Enter the Bar and go into the small room on the left. Do NOT attack any of the neutral mobs while running through the Bar
>>Click on the 3 |cRXP_PICK_Thunderbrew Lager Kegs|r to destroy them, forcing |cRXP_ENEMY_Hurley Blackbreath|r and his 3 |cRXP_ENEMY_Blackbreath Cronies|r to engage
>>Kill |cRXP_ENEMY_Hurley Blackbreath|r. Loot him for the |cRXP_LOOT_Lost Thunderbrew Recipe|r
.complete 4134,1 
.target Hurley Blackbreath
.isOnQuest 4134
step
>>Enter the Bar and go into the small room on the left. Do NOT attack any of the neutral mobs while running through the Bar
>>Kill |cRXP_ENEMY_Ribbly Screwspigot|r. Loot him for his |cRXP_LOOT_Head|r
>>To engage |cRXP_ENEMY_Ribbly Screwspigot|r you have your tank talk to him, then bring him back along with his |cRXP_ENEMY_Cronies|r into the room with the kegs
.complete 4136,1 
.target Ribbly Screwspigot
.skipgossip
.isOnQuest 4136
step
>>Enter the Bar and go into the small room on the left. Do NOT attack any of the neutral mobs while running through the Bar
>>Click on the 3 |cRXP_PICK_Thunderbrew Lager Kegs|r to destroy them, forcing |cRXP_ENEMY_Hurley Blackbreath|r and his 3 |cRXP_ENEMY_Blackbreath Cronies|r to engage
>>Kill |cRXP_ENEMY_Hurley Blackbreath|r. Loot him for the |cRXP_LOOT_Lost Thunderbrew Recipe|r
.complete 4134,1 
.isOnQuest 4134
step
>>Loot the |cRXP_LOOT_Core Fragment|r on the ground outside of the Molten Core instance portal
.complete 7848,1 
.isOnQuest 7848
step
>>Kill |cRXP_ENEMY_Emperor Dagran Thaurissan|r
>>|cRXP_WARN_You must NOT kill |cRXP_ENEMY_Princess Moira Bronzebeard|r in order to complete and turn in this quest|r
>>|cRXP_WARN_Have a party member kite |cRXP_ENEMY_Princess Moira Bronzebeard|r while the rest of the group kills|r |cRXP_ENEMY_Emperor Dagran Thaurissan|r
.complete 4003,1 
.isOnQuest 4003
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Moira Bronzebeard|r
.turnin 4003 >> Turn in The Royal Rescue
.accept 4004 >> Accept The Princess Saved?
.target Princess Moira Bronzebeard
.isQuestComplete 4003
step
#label PrincessSaved
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Moira Bronzebeard|r
.accept 4004 >> Accept The Princess Saved?
.target Princess Moira Bronzebeard
.isQuestTurnedIn 4003
step
#completewith KargathTurnins
+|cRXP_WARN_Hearth or travel back to Kargath|r
step
.goto Badlands,2.90,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
>>|cRXP_FRIENDLY_Vivian|r|cRXP_WARN_might be patrolling around the mountain near Kargath. Find her or wait for her to return|r
.turnin 4134 >> Turn in Lost Thunderbrew Recipe
.unitscan Shadowmage Vivian Lagrave
.isQuestComplete 4134
step
.goto Badlands,2.90,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
>>|cRXP_FRIENDLY_Vivian|r|cRXP_WARN_might be patrolling around the mountain near Kargath. Find her or wait for her to return|r
.turnin 7201 >> Turn in The Last Element
.unitscan Shadowmage Vivian Lagrave
.isQuestComplete 7201
step
#label KargathTurnins
.goto Badlands,25.95,44.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil Veriatus|r
.turnin 4063 >> Turn in The Rise of the Machines
.target Lotwil Veriatus
.isQuestTurnedIn 4062
step
.goto Badlands,3.98,44.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fly Flame Crest >> Fly to Flame Crest
.target Gorrik
.zoneskip Burning Steppes
step
.goto Burning Steppes,65.152,23.911
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.turnin 4123 >> Turn in The Heart of the Mountain
.target Maxwort Uberglint
.isQuestComplete 4123
step
.goto Burning Steppes,66.058,21.951
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yuka Screwspigot|r
.turnin 4136 >> Turn in Ribbly Screwspigot
.target Yuka Screwspigot
.isQuestComplete 4136
step
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
.turnin 4024 >> Turn in A Taste of Flame
.target Cyrus Therepentous
.isQuestComplete 4024
step
.goto 1415,48.409,63.815
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothos Riftwaker|r
>>|cRXP_WARN_You can either turn this in now or the next time you are in Blackrock Mountain|r
.turnin 7848 >> Turn in Attunement to the Core
.target Lothos Riftwaker
.isQuestComplete 7848
step << !Mage
#completewith next
+|cRXP_WARN_Hearth to Everlook and fly to Orgrimmar. If you have a mage, kindly ask for a portal to Orgrimmar instead|r
step << Mage
#completewith next
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step
.goto Orgrimmar,31.74,37.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r
.turnin 4004 >> Turn in The Princess Saved?
.target Thrall
.isQuestTurnedIn 4003
step
+|cRXP_WARN_This is the end of the Blackrock Depths guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 114 Lower Blackrock Spire
#displayname 14. Lower Blackrock Spire
step
#completewith BSPickups
+|cRXP_WARN_You will now be directed to pick up all available quests for Lower Blackrock Spire|r
step
#completewith BadlandsPickups
.subzone 340 >>Travel to Kargath in |cFFfa9602Badlands|r
step
.goto Badlands,5.81,47.52
>>Talk to |cRXP_FRIENDLY_Warlord Goretooth|r to receive |T133473:0|t[|cRXP_LOOT_Warlord Goretooth's Command|r]. Use it to accept the quest
.collect 12563,1,4903 
.accept 4903 >>Accept Warlord's Command
.target Warlord Goretooth
.skipgossip 0,1,1,1,1,1
step
.goto Badlands,5.88,47.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lexlort|r on top of the tower
.accept 4981 >>Accept Operative Bijou
.target Lexlort
step
#label BadlandsPickups
.goto Badlands,5.96,47.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Galamav the Marksman|r on top of the tower
.accept 4724 >>Accept The Pack Mistress
.target Galamav the Marksman
step
#completewith BSPickups
.zone Burning Steppes >>|cRXP_WARN_Travel to|r |cFFfa9602Burning Steppes|r
step
.goto Burning Steppes,65.8,22.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kibler|r
.accept 4862 >>Accept En-Ay-Es-Tee-Why
.target Kibler
step
#label BSPickups
.goto Burning Steppes,65.8,22.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kibler|r
.accept 4729 >>Accept Kibler's Exotic Pets
.target Kibler
step
#completewith LBRS1
.subzone 254 >>Travel to |cFFfa9602Blackrock Mountain|r
step
#completewith LBRS1
.goto Eastern Kingdoms,48.95,63.89
.subzone 1583 >>Enter Blackrock Spire
step
#sticky
#label ImportantDocuments
>>Loot the |cRXP_LOOT_Important Blackrock Documents|r
>>This has 4 different possible spawn points in the dungeon:
>>|cRXP_WARN_At the feet of|r |cRXP_ENEMY_Overlord Wyrmthalak|r
>>|cRXP_WARN_In an empty corner next to|r |cRXP_ENEMY_War Master Voone|r
>>|cRXP_WARN_Near|r |cRXP_ENEMY_Highlord Omokk|r
>>|cRXP_WARN_Next to |cRXP_ENEMY_Urok Doomhowl's|r Tribute Pile|r
.complete 4903,4 
.isOnQuest 4903
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
>>|cRXP_WARN_He is located outside of the troll area, you can clear to them through the pyramid or jump onto him from the outside|r
.turnin 4981 >>Turn in Operative Bijou
.accept 4982 >>Accept Bijou's Belongings
.target Bijou
.isOnQuest 4981
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
>>|cRXP_WARN_He is located outside of the troll area, you can clear to them through the pyramid or jump onto him from the outside|r
.accept 4982 >>Accept Bijou's Belongings
.target Bijou
.isQuestTurnedIn 4981
step
>>Keep clearing through the instance until you reach the bottom floor. In the corridor filled with |cRXP_ENEMY_Orc Soldiers|r and their camps keep looking for a small brown crate, loot it for |T133652:0|t[|cRXP_PICK_Bijou's Belongings|r]
.complete 4982,1 
.isOnQuest 4982
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
>>|cRXP_WARN_He is located outside of the troll area, you can clear to them through the pyramid or jump onto him from the outside|r
.turnin 4981 >>Turn in Operative Bijou
.accept 4983 >>Accept Bijou's Reconnaissance Report
.target Bijou
.isQuestComplete 4981
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
>>|cRXP_WARN_He is located outside of the troll area, you can clear to them through the pyramid or jump onto him from the outside|r
.accept 4983 >>Accept Bijou's Reconnaissance Report
.target Bijou
.isQuestTurnedIn 4981
step
>>Loot |T132833:0|t[|cRXP_PICK_Spire Spider Eggs|r] from clusters on the ground in the spider area
>>|cRXP_WARN_Be careful as multiple|r |cRXP_ENEMY_Spire Spiderlings|r |cRXP_WARN_may spawn after looting an egg|r
.complete 4862,1
.isOnQuest 4862
step
.use 12262 >>|cRXP_WARN_Once you reach the Wolf area, target a |cRXP_ENEMY_Bloodaxe Worg Pup|r and use the|r |T132599:0|t[Empty Worg Pup Cage] |cRXP_WARN_on it|r
.complete 4729,1 
.mob Bloodaxe Worg Pup
.isOnQuest 4729
step
>>Kill the Wolf boss |cRXP_ENEMY_Halycon|r
.mob Halycon
.complete 4724,1 
.isOnQuest 4724
step
#label LBRS1
>>Kill |cRXP_ENEMY_Highlord Omokk|r, |cRXP_ENEMY_War Master Voone|r and |cRXP_ENEMY_Overlord Wyrmthalak|r
.complete 4903,2 
.mob +Highlord Omokk
.complete 4903,3 
.mob +War Master Voone
.complete 4903,1 
.mob +Overlord Wyrmthalak
.isOnQuest 4903
step
#requires ImportantDocuments
#completewith BadlandsTurnins
.subzone 340 >>Travel to Kargath in |cFFfa9602Badlands|r
step
#requires ImportantDocuments
.goto Badlands,5.81,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Goretooth|r
.turnin 4903 >>Turn in Warlord's Command
.accept 4941 >>Accept Eitrigg's Wisdom
.target Warlord Goretooth
.isQuestComplete 4903
step
#optional
#requires ImportantDocuments
.goto Badlands,5.81,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Goretooth|r
.accept 4941 >>Accept Eitrigg's Wisdom
.target Warlord Goretooth
.isQuestTurnedIn 4941
step
.goto Badlands,5.88,47.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lexlort|r on top of the tower
.turnin 4983 >>Turn in Bijou's Reconnaissance Report
.target Lexlort
.isOnQuest 4983
step
#label BadlandsTurnins
.goto Badlands,5.96,47.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Galamav the Marksman|r on top of the tower
.turnin 4724 >>Turn in The Pack Mistress
.target Galamav the Marksman
.isQuestComplete 4724
step
#completewith BSTurnins
.zone Burning Steppes >>|cRXP_WARN_Travel to|r |cFFfa9602Burning Steppes|r
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kibler|r
.turnin 4729 >> Turn in Kibler's Exotic Pets
.goto Burning Steppes,65.8,22.0
.target Kibler
.isQuestComplete 4729
step
#label BSTurnins
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kibler|r
.turnin 4862 >> Turn in En-Ay-Es-Tee-Why
.goto Burning Steppes,65.8,22.0
.target Kibler
.isQuestComplete 4862
step
+|cRXP_WARN_This is the end of the Lower Blackrock Spire guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 115 Upper Blackrock Spire
#displayname 15. Upper Blackrock Spire
step
#completewith StartDungeon
.subzone 1583,2 >>|cRXP_WARN_This is a 10-man dungeon. You or somebody in your party must have the|r |T133343:0|t[|cRXP_LOOT_Seal of Ascension|r] |cRXP_WARN_to be able to enter Upper Blackrock Spire|r
step
#completewith ForTheHorde
.zone Orgrimmar >>Travel to |cFFfa9602Orgrimmar|r
step
.goto Orgrimmar,34.27,39.35,10,0
.goto Orgrimmar,31.74,37.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eitrigg|r and go through the dialogue, then talk to |cRXP_FRIENDLY_Thrall|r
.turnin 4941 >>Turn in Eitrigg's Wisdom
.accept 4974 >>Accept For The Horde!
.target Eitrigg
.target Thrall
.skipgossip
.isOnQuest 4941
step
#label ForTheHorde
.goto Orgrimmar,34.27,39.35,10,0
.goto Orgrimmar,31.74,37.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eitrigg|r and go through the dialogue, then talk to |cRXP_FRIENDLY_Thrall|r
.accept 4974 >>Accept For The Horde!
.target Eitrigg
.target Thrall
.skipgossip
.isQuestTurnedIn 4941
step
#completewith next
.zone Azshara >>Travel to |cFFfa9602Azshara|r
step
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
>>|cRXP_WARN_These are prerequisite quests completed in Eastern Plaguelands and Silithus to unlock a quest in UBRS. Feel free to skip this|r
.accept 6804 >>Accept Poisoned Water
.accept 6805 >>Accept Stormers and Rumblers
.target Duke Hydraxis
step
#completewith next
.zone Silithus >>Travel to |cFFfa9602Silithus|r
step
>>Kill |cRXP_ENEMY_Dust Stormers|r and |cRXP_ENEMY_Desert Rumblers|r
.complete 6805,1 
.mob +Desert Rumbler
.goto Silithus,33.13,14.98,60,0
.goto Silithus,29.75,16.66,60,0
.goto Silithus,30.33,20.83,60,0
.goto Silithus,23.19,27.97,60,0
.goto Silithus,20.41,33.38,60,0
.goto Silithus,18.09,26.65,60,0
.goto Silithus,21.09,22.33,60,0
.goto Silithus,33.13,14.98,60,0
.goto Silithus,29.75,16.66,60,0
.goto Silithus,30.33,20.83,60,0
.goto Silithus,23.19,27.97,60,0
.goto Silithus,20.41,33.38,60,0
.goto Silithus,18.09,26.65,60,0
.goto Silithus,21.09,22.33
.complete 6805,2 
.mob +Dust Stormer
.goto Silithus,21.61,17.09,50,0
.goto Silithus,21.67,9.37,50,0
.goto Silithus,27.63,14.28,50,0
.goto Silithus,24.12,14.81,50,0
.goto Silithus,21.61,17.09,50,0
.goto Silithus,21.67,9.37,50,0
.goto Silithus,27.63,14.28,50,0
.goto Silithus,24.12,14.81
.isOnQuest 6805
step
#completewith next
.zone Eastern Plaguelands >>Travel to |cFFfa9602Eastern Plaguelands|r
step
#loop
.goto Eastern Plaguelands,71.34,34.07,0
.goto Eastern Plaguelands,51.36,49.77,0
.goto Eastern Plaguelands,64.58,80.71,0
.goto Eastern Plaguelands,59.71,79.12,0
.goto Eastern Plaguelands,64.58,80.71,50,0
.goto Eastern Plaguelands,59.71,79.12,50,0
>>Kill |cRXP_ENEMY_Water Elementals|r. Loot them for their |cRXP_LOOT_Discordant Bracers|r
>>|cRXP_WARN_They can be killed in three different locations in EPL. They are marked on your map|r
.complete 6804,1 
.mob Blighted Horror
.mob Plague Monstrosity
.mob Blighted Surge
.mob Plague Ravager
.isOnQuest 6804
step
#completewith EyeofEmber
.zone Azshara >>Travel to |cFFfa9602Azshara|r
step
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.turnin 6804 >>Turn in Poisoned Water
.turnin 6805 >>Turn in Stormers and Rumblers
.accept 6821 >>Accept Eye of the Emberseer
.target Duke Hydraxis
.isQuestComplete 6804
.isQuestComplete 6805
step
#label EyeofEmber
#optional
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.accept 6821 >>Accept Eye of the Emberseer
.target Duke Hydraxis
.isQuestTurnedIn 6804
.isQuestTurnedIn 6805
step
#completewith next
.subzone 340 >>Travel to Kargath in |cFFfa9602Badlands|r
step
.goto Badlands,2.90,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
>>|cRXP_FRIENDLY_Vivian|r|cRXP_WARN_might be patrolling around the mountain near Kargath. Find her or wait for her to return|r
.accept 4768 >>Accept The Darkstone Tablet
.unitscan Shadowmage Vivian Lagrave
step
#completewith EggFreezeAccept
.zone Burning Steppes >>Travel to |cFFfa9602Burning Steppes|r
step
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.accept 4734 >>Accept Egg Freezing
.target Tinkee Steamboil
step
#label EggFreezeAccept
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.accept 4735 >>Accept Egg Collection
.target Tinkee Steamboil
.isQuestTurnedIn 4734
step
#completewith StartDungeon
.subzone 254 >>Travel to |cFFfa9602Blackrock Mountain|r
step << !tbc !wotlk
#phase 3
#hardcore
.goto Eastern Kingdoms,48.94,63.92,10,0
.goto Eastern Kingdoms,49.01,64.12,10,0
.goto Eastern Kingdoms,49.12,64.09
.use 18987 >>Kill the |cRXP_ENEMY_Scarshield Quartermaster|r. Loot him for |T133473:0|t[|cRXP_LOOT_Blackhand's Command|r]. Use it to accept the quest
>>|cRXP_WARN_This is a strong level 55 elite. Do this with a group for safety|r
>>|cRXP_WARN_He is located in the hallway to the right of the Blackrock Spire instance portal|r
.collect 18987,1,7761 
.accept 7761 >>Accept Blackhand's Command
.unitscan Scarshield Quartermaster
step << !tbc !wotlk
#phase 3
#softcore
.goto Eastern Kingdoms,48.94,63.92,10,0
.goto Eastern Kingdoms,49.01,64.12,10,0
.goto Eastern Kingdoms,49.12,64.09
.use 18987 >>Kill the |cRXP_ENEMY_Scarshield Quartermaster|r. Loot him for |T133473:0|t[|cRXP_LOOT_Blackhand's Command|r]. Use it to accept the quest
>>|cRXP_WARN_He is located in the hallway to the right of the Blackrock Spire instance portal|r
.collect 18987,1,7761 
.accept 7761 >>Accept Blackhand's Command
.unitscan Scarshield Quartermaster
step << tbc/wotlk
.goto Eastern Kingdoms,48.94,63.92,10,0
.goto Eastern Kingdoms,49.01,64.12,10,0
.goto Eastern Kingdoms,49.12,64.09
.use 18987 >>Kill the |cRXP_ENEMY_Scarshield Quartermaster|r. Loot him for |T133473:0|t[|cRXP_LOOT_Blackhand's Command|r]. Use it to accept the quest
>>|cRXP_WARN_He is located in the hallway to the right of the Blackrock Spire instance portal|r
.collect 18987,1,7761 
.accept 7761 >>Accept Blackhand's Command
.unitscan Scarshield Quartermaster
step
#label StartDungeon
.subzone 1583,2 >>Enter Blackrock Spire
step
>>Kill |cRXP_ENEMY_Pyroguard Emberseer|r. Loot him for the |cRXP_LOOT_Eye of the Emberseer|r
.complete 6821,1 
.mob Pyroguard Emberseer
.isOnQuest 6821
step
#optional
#completewith next
.use 12286 >>|cRXP_WARN_Use the|r |T133003:0|t[Eggscilliscope Prototype] |cRXP_WARN_on one of the eggs in The Rookery to freeze it|r
.complete 4734,1 
.isOnQuest 4734
step
>>Loot the |cRXP_PICK_Darkstone Tablet|r laying in The Rookery
>>|cRXP_WARN_It's located to the left of the rubble ramp leading upstairs|r
.complete 4768,1 
.isOnQuest 4768
step
.use 12286 >>|cRXP_WARN_Use the|r |T133003:0|t[Eggscilliscope Prototype] |cRXP_WARN_on one of the eggs in The Rookery to freeze it|r
.complete 4734,1 
.isOnQuest 4734
step
>>Kill |cRXP_ENEMY_Rend Blackhand|r. Loot him for his |cRXP_LOOT_Head|r
.complete 4974,1 
.mob Rend Blackhand
.isOnQuest 4974
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Awbee|r and complete his dialogue
>>|cRXP_FRIENDLY_Awbee|r |cRXP_WARN_is located in the room you enter after defeating|r |cRXP_ENEMY_Rend Blackhand|r
>>|cRXP_WARN_Make sure your group knows you want to pick up this quest as the mobs guarding |cRXP_FRIENDLY_Awbee|r are usually skipped|r
.accept 5160 >>Accept The Matron Protectorate
.skipgossip
.isQuestAvailable 5160
.target Awbee
step
>>Click |cRXP_PICK_Drakkisath's Brand|r in the final room of Upper Blackrock Spire behind |cRXP_ENEMY_General Drakkisath|r
.turnin 7761 >>Turn in Blackhand's Command
.isOnQuest 7761
step
#completewith EggFreeze
+|cRXP_WARN_Stay in your raid group! The follow-up quest of "Egg Freezing" can be quickly completed inside the cleared instance|r
step
#completewith EggCollectAccept
.zone Burning Steppes >>Travel to |cFFfa9602Burning Steppes|r
step
#label EggFreeze
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.turnin 4734 >>Turn in Egg Freezing
.accept 4735 >>Accept Egg Collection
.target Tinkee Steamboil
.isQuestComplete 4734
step
#label EggCollectAccept
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.accept 4735 >>Accept Egg Collection
.target Tinkee Steamboil
.isQuestTurnedIn 4734
step
#completewith next
.subzone 254 >>Travel to |cFFfa9602Blackrock Mountain|r
step
#completewith next
.goto Eastern Kingdoms,48.95,63.89
.subzone 1583 >>Enter Blackrock Spire
step
>>Enter the rookery and use the |T133003:0|t[Eggscilliscope] on one of the eggs to freeze it. Then use the |T133014:0|t[Collectronic Module] to collect it
.complete 4735,1 
.use 12144 
.use 12287 
.isOnQuest 4735
step
#completewith next
.zone Burning Steppes >>Travel to |cFFfa9602Burning Steppes|r
step
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.turnin 4735 >>Turn in Egg Collection
.target Tinkee Steamboil
.isQuestComplete 4735
step
#completewith next
.subzone 340 >>Travel to Kargath in |cFFfa9602Badlands|r
step
.goto Badlands,2.90,47.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
>>|cRXP_FRIENDLY_Vivian|r|cRXP_WARN_might be patrolling around the mountain near Kargath. Find her or wait for her to return|r
.turnin 4768 >> Turn in The Darkstone Tablet
.unitscan Shadowmage Vivian Lagrave
.isQuestComplete 4768
step
#completewith next
.zone Orgrimmar >>Travel to |cFFfa9602Orgrimmar|r
step
.goto Orgrimmar,34.27,39.35,10,0
.goto Orgrimmar,31.74,37.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eitrigg|r and go through the dialogue, then talk to |cRXP_FRIENDLY_Thrall|r
>>|cRXP_WARN_The follow-up quest is part of the Onyxia Attunement chain. Select the Onyxia Attunement guide if you wish to complete this|r
.turnin 4974 >>Turn in For The Horde!
.target Eitrigg
.target Thrall
.skipgossip
.isQuestComplete 4974
step
#completewith next
.zone Azshara >>Travel to |cFFfa9602Azshara|r
step
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.turnin 6821 >>Turn in Eye of the Emberseer
.target Duke Hydraxis
step
+|cRXP_WARN_This is the end of the Upper Blackrock Spire guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 116 Scholomance
#displayname 16. Scholomance
step
#completewith EnterScholo
+|cRXP_WARN_You will now be directed to pick up all available quests for Scholomance|r
step
#completewith EnterScholo
+|cRXP_WARN_You or somebody in your party must have the|r |T13704:0|t[Skeleton Key] |cRXP_WARN_to enter Scholomance (a Rogue with 300 lockpicking can also open the door)|r
>>|cRXP_WARN_Select the "Scholomance Key" guide if you wish to obtain it|r
.itemcount 13704,<1
step << Shaman
>>|cRXP_WARN_Go to the Auction House in any Major city and buy an|r |T134094:0|t[Azerothian Diamond] |cRXP_WARN_and a|r |T134072:0|t[Pristine Black Diamond]
>>|cRXP_WARN_Skip this step if they are not available or if it's too expensive|r
.collect 12800,1,7667,1 
.collect 18335,1,7667,1 
.xp <58,1
step << Shaman
#completewith next
.zone Orgrimmar >>Travel to |cFFfa9602Orgrimmar|r
step << Shaman
.goto Orgrimmar,38.66,35.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sagorne Creststrider|r
.accept 7667 >>Accept Material Assistance
.turnin 7667 >>Turn in Material Assistance
.accept 8258 >>Accept The Darkreaver Menace
.target Sagorne Creststrider
.itemcount 12800,1
.itemcount 18335,1
.xp <58,1
step << Shaman
#optional
.goto Orgrimmar,38.66,35.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sagorne Creststrider|r
.accept 8258 >>Accept The Darkreaver Menace
.target Sagorne Creststrider
.isQuestTurnedIn 8258
.xp <58,1
step
#completewith next
.subzone 2268 >>Travel to |cFFfa9602Light's Hope Chapel|r in Eastern Plaguelands
step
.goto Eastern Plaguelands,81.47,59.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.accept 5529 >>Accept Plagued Hatchlings
.target Betina Bigglezink
step
.goto Eastern Plaguelands,81.627,58.077
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessica Chambers|r
.home >>Set your Hearthstone to Light's Hope Chapel
.target Jessica Chambers
.subzoneskip 2268,1
.bindlocation 2268
step
#completewith next
.zone Tirisfal Glades >>Travel to |cFFfa9602Tirisfal Glades|r
step
.goto Tirisfal Glades,83.05,71.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexi Barov|r
.accept 5341 >>Accept Barov Family Fortune
.target Alexi Barov
step
#completewith EnterScholo
.subzone 2298 >>Travel to the Scholomance entrance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
>>|cRXP_WARN_She is located right outside Scholomance|r
>>|cRXP_WARN_This quest chain will require you to run in and out of Scholomance multiple times|r
.accept 5382 >>Accept Doctor Theolen Krastinov, the Butcher
.target Eva Sarkhoff
step
#label EnterScholo
.subzone 2057 >>Enter Scholomance
step
#completewith Hatchlings
>>Loot the |cRXP_PICK_Deeds|r throughout Scholomance
>>|cRXP_PICK_The Deed to Southshore|r |cRXP_WARN_is located in the large room right after the bridge as you enter the dungeon. It's in the left corner next to a bookshelf on top of a desk|r
.complete 5341,3
>>|cRXP_PICK_The Deed to Tarren Mill|r |cRXP_WARN_is located on the desk in the right corner of the large room downstairs before the room filled with whelpes|r
.complete 5341,4
>>|cRXP_PICK_The Deed to Brill|r |cRXP_WARN_is located in |cRXP_ENEMY_Ras Frostwhisper's|r room on a table to the right side|r
.complete 5341,1
>>|cRXP_PICK_The Deed to Caer Darrow|r |cRXP_WARN_is located behind |cRXP_ENEMY_Lord Alexei Barov|r in the boss gauntlet in |cRXP_ENEMY_Grandmaster Gandling's|r room|r
.complete 5341,2
.isOnQuest 5341
step
#completewith Kirtonos
>>Kill |cRXP_ENEMY_Plagued Hatchlings|r. Loot them for a |T134319:0|t[|cRXP_LOOT_Healthy Dragon Scale|r]. Use it to accept the quest
.collect 13920,1,5582 
.accept 5582 >>Accept Healthy Dragon Scale
.complete 5529,1 
.isOnQuest 5529
step << Shaman
.use 18746 >>|cRXP_WARN_Use the|r |T133866:0|t[Divination Scryer] |cRXP_WARN_in |cRXP_ENEMY_Rattlegore's|r room|r
>>|cRXP_WARN_Many |cRXP_ENEMY_Spirits|r will spawn. Kill them until the |cRXP_ENEMY_Death Knight Darkreaver|r spawns|r
>>Kill the |cRXP_ENEMY_Death Knight Darkreaver|r. Loot him for his |cRXP_LOOT_Head|r
.complete 8258,1 
.mob Death Knight Darkreaver
.isOnQuest 8258
step
>>Kill |cRXP_ENEMY_Doctor Theolen Krastinov|r in the boss gauntlet in |cRXP_ENEMY_Grandmaster Gandling's|r room
>>Click on the |cRXP_PICK_Remains of Eva Sarkhoff|r and |cRXP_PICK_Remains of Lucien Sarkhoff|r to burn them
>>|cRXP_WARN_They look like piles of flesh and are located in |cRXP_ENEMY_Krastinov's|r room|r
.complete 5382,1 
.complete 5382,2 
.complete 5382,3 
.mob Doctor Theolen Krastinov
.isOnQuest 5382
step
#completewith next
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Eva Sarkhoff|r outside the instance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.turnin 5382 >>Turn in Doctor Theolen Krastinov, the Butcher
.accept 5515 >>Accept Krastinov's Bag of Horrors
.isQuestComplete 5382
.target Eva Sarkhoff
step
#optional
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.accept 5515 >>Accept Krastinov's Bag of Horrors
.target Eva Sarkhoff
.isQuestTurnedIn 5382
step
>>Kill |cRXP_ENEMY_Jandice Barov|r. Loot her for |T133648:0|t[|cRXP_LOOT_Krastinov's Bag of Horrors|r]
.complete 5515,1 
.isOnQuest 5515
.mob Jandice Barov
step
#completewith next
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Eva Sarkhoff|r outside the instance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.turnin 5515 >>Turn in Krastinov's Bag of Horrors
.accept 5384 >>Accept Kirtonos the Herald
.isQuestComplete 5515
.target Eva Sarkhoff
step
#optional
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.accept 5515 >>Accept Kirtonos the Herald
.isQuestTurnedIn 5384
.target Eva Sarkhoff
step
#label Kirtonos
>>|cRXP_WARN_Use the|r |T134804:0|t[Blood of Innocents] |cRXP_WARN_on the |cRXP_PICK_Brazier of the Herald|r on the balcony in the second room|r
>>Kill |cRXP_ENEMY_Kirtonos the Herald|r as he spawns
.complete 5384,1 
.mob Kirtonos the Herald
.isOnQuest 5384
step
#label Hatchlings
>>Kill |cRXP_ENEMY_Plagued Hatchlings|r. Loot them for a |T134319:0|t[|cRXP_LOOT_Healthy Dragon Scale|r]. Use it to accept the quest
.collect 13920,1,5582 
.accept 5582 >>Accept Healthy Dragon Scale
.complete 5529,1 
.isOnQuest 5529
step
>>Loot the |cRXP_PICK_Deeds|r throughout Scholomance
>>|cRXP_PICK_The Deed to Southshore|r |cRXP_WARN_is located in the large room right after the bridge as you enter the dungeon. It's in the left corner next to a bookshelf on top of a desk|r
.complete 5341,3
>>|cRXP_PICK_The Deed to Tarren Mill|r |cRXP_WARN_is located on the desk in the right corner of the large room downstairs before the room filled with whelpes|r
.complete 5341,4
>>|cRXP_PICK_The Deed to Brill|r |cRXP_WARN_is located in |cRXP_ENEMY_Ras Frostwhisper's|r room on a table to the right side|r
.complete 5341,1
>>|cRXP_PICK_The Deed to Caer Darrow|r |cRXP_WARN_is located behind |cRXP_ENEMY_Lord Alexei Barov|r in the boss gauntlet in |cRXP_ENEMY_Grandmaster Gandling's|r room|r
.complete 5341,2
.isOnQuest 5341
step
#completewith next
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Eva Sarkhoff|r outside the instance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.turnin 5384 >>Turn in Kirtonos the Herald
.isQuestComplete 5384
.target Eva Sarkhoff
step
#completewith next
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5461 >>Accept The Human, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5384
.use 13544
step
#optional
#completewith RichRas
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
#optional
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5465 >>Turn in Soulbound Keepsake
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isOnQuest 5465
.use 13544
step
#optional
#label RichRas
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5465
.use 13544
step
#optional
.use 13752>>|cRXP_WARN_Use the|r |T133736:0|t[Soulbound Keepsake] |cRXP_WARN_on|r |cRXP_ENEMY_Ras Frostwhisper|r
>>Kill |cRXP_ENEMY_Ras Frostwhisper|r inside Scholomance. Loot him for his |cRXP_LOOT_Head|r
.complete 5466,1 
.mob Ras Frostwhisper
.isOnQuest 5466
step
#optional
#completewith RichRas2
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Magistrate Marduke|r outside the instance
step
#optional
#completewith RichRas2
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
#optional
#label RichRas2
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5466 >>Turn in The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestComplete 5466
.use 13544
step
#completewith next
.zone Tirisfal Glades >>Travel to |cFFfa9602Tirisfal Glades|r
step
.goto Tirisfal Glades,83.05,71.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexi Barov|r
.turnin 5341 >>Turn in Barov Family Fortune
.target Alexi Barov
.isQuestComplete 5341
step
#completewith HatchlingsTurnin
.hs >>Hearth to Light's hope Chapel
.bindlocation 2268,1
.subzoneskip 2268
.use 6948
.cooldown item,6948,>0,1
step
#completewith HatchlingsTurnin
.subzone 2268 >>Travel to |cFFfa9602Light's Hope Chapel|r in Eastern Plaguelands
step
#label HatchlingsTurnin
.goto Eastern Plaguelands,81.47,59.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.turnin 5529 >>Turn in Plagued Hatchlings
.target Betina Bigglezink
.isQuestComplete 5529
step << Shaman
#completewith next
.zone Orgrimmar >>Travel to |cFFfa9602Orgrimmar|r
step << Shaman
.goto Orgrimmar,38.66,35.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sagorne Creststrider|r
.turnin 8258 >>Turn in The Darkreaver Menace
.target Sagorne Creststrider
.isQuestComplete 8258
step
+|cRXP_WARN_Select the "Stratholme guide" in order to continue with the quest chain of "The Human, Ras Frostwhisper"|r
.isOnQuest 5461
step
+|cRXP_WARN_This is the end of the Scholomance guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 117 Stratholme
#displayname 17. Stratholme
step
#optional
+|cRXP_WARN_It is recommended to run Scholomance first to begin the quest chain "Doctor Theolen Krastinov, the Butcher" that will send you to Stratholme afterwards|r
.isQuestAvailable 5384
step
#completewith next
.subzone 324 >>Travel to |cFFfa9602Stromgarde Keep|r in Arathi Highlands
step
#loop
.goto Arathi Highlands,28.26,62.33,0
.goto Arathi Highlands,28.26,62.33,30,0
.goto Arathi Highlands,21.40,60.08,30,0
.goto Arathi Highlands,20.86,69.04,30,0
.goto Arathi Highlands,18.21,68.45,30,0
>>Loot the |cRXP_PICK_Keepsake of Remembrance|r in Stromgarde Keep
>>|cRXP_WARN_It is a little red book which can be located in any of the fireplaces inside the keep. Also check the Ogre Tower and the intact houses|r
.complete 5461,1 
.isOnQuest 5461
step
#completewith LoveandFam
.zone Western Plaguelands >>Travel to |cFFfa9602Western Plaguelands|r
step
#completewith DyingRas
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5461 >>Turn in The Human, Ras Frostwhisper
.accept 5462 >>Accept The Dying, Ras Frostwhisper
.target Magistrate Marduke
.isQuestComplete 5461
.use 13544
step
#optional
#label DyingRas
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5462 >>Accept The Dying, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5461
.use 13544
step
.goto Western Plaguelands,65.7,75.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Artist Renfray|r
.turnin 5846 >>Turn in Of Love and Family
.accept 5848 >>Accept Of Love and Family
.target Artist Renfray
.isQuestComplete 5846
step
#label LoveandFam
#optional
.goto Western Plaguelands,65.7,75.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Artist Renfray|r
.accept 5848 >>Accept Of Love and Family
.target Artist Renfray
.isQuestTurnedIn 5846
step
#completewith LHCpickups
.zone Eastern Plaguelands >>Travel to |cFFfa9602Eastern Plaguelands|r
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
>>|cRXP_WARN_These are pre-requisite quests for a quest in Stratholme|r
.accept 6022 >>Accept To Kill With Purpose
.accept 6042 >>Accept Un-Life's Little Annoyances
.accept 6133 >>Accept The Ranger Lord's Behest
.target Nathanos Blightcaller
step
#completewith next
>>Kill |cRXP_ENEMY_Undead|r. Loot them for their |cRXP_LOOT_Living Rot|r.
>>|cRXP_WARN_Groups of elites patrol the north and east road. Invisible mobs patrol inside of Corrin's Crossing, so try to pull mobs out|r
.collect 15447,7 
.mob Hate Shrieker
.mob Scourge Warder
.mob Stitched Horror
.mob Gibbering Ghoul
.mob Unseen Servant
.mob Dark Caster
step
#loop
.goto Eastern Plaguelands,58.20,70.20,0
.goto Eastern Plaguelands,58.20,70.20,25,0
.goto Eastern Plaguelands,60.40,71.60,25,0
.goto Eastern Plaguelands,61.00,69.40,25,0
.goto Eastern Plaguelands,61.40,66.40,25,0
.goto Eastern Plaguelands,59.40,66.40,25,0
.goto Eastern Plaguelands,58.00,67.60,25,0
.use 15454 >>|cRXP_WARN_Use the|r |T133748:0|t[Mortar and Pestle] |cRXP_WARN_before the |cRXP_LOOT_Living Rot|r expires|r
.complete 6022,1 
.isOnQuest 6022
step
#loop
.goto Eastern Plaguelands,77.94,69.64,0
.goto Eastern Plaguelands,46.14,65.32,70,0
.goto Eastern Plaguelands,49.24,61.48,70,0
.goto Eastern Plaguelands,50.26,54.66,70,0
.goto Eastern Plaguelands,55.24,54.72,70,0
.goto Eastern Plaguelands,61.47,61.92,70,0
.goto Eastern Plaguelands,65.18,70.17,70,0
.goto Eastern Plaguelands,69.94,72.99,70,0
.goto Eastern Plaguelands,72.99,75.98,70,0
.goto Eastern Plaguelands,77.94,69.64,70,0
>>Kill |cRXP_ENEMY_Noxious Plaguebats|r
.complete 6042,1 
.mob Noxious Plaguebat
.isOnQuest 6042
step
#loop
.goto Eastern Plaguelands,51.18,39.91,0
.goto Eastern Plaguelands,69.73,50.55,70,0
.goto Eastern Plaguelands,70.42,43.50,70,0
.goto Eastern Plaguelands,70.34,38.47,70,0
.goto Eastern Plaguelands,67.02,34.41,70,0
.goto Eastern Plaguelands,62.69,34.72,70,0
.goto Eastern Plaguelands,50.36,28.49,70,0
.goto Eastern Plaguelands,51.18,39.91,70,0
>>Kill |cRXP_ENEMY_Monstrous Plaguebats|r
>>|cRXP_WARN_Be careful as|r |cRXP_ENEMY_Monstrous Plaguebats|r |cRXP_WARN_can silence for 10 seconds in melee range|r << !Rogue !Warrior
.complete 6042,2 
.mob +Monstrous Plaguebat
.isOnQuest 6042
step
#completewith next
.goto Eastern Plaguelands,52.14,18.30,0
>>Loot the |cRXP_LOOT_Quel'Thalas Registry|r on top of the bench
.complete 6133,4 
.isOnQuest 6133
step
#loop
.goto Eastern Plaguelands,52.88,19.18,0
.goto Eastern Plaguelands,51.75,21.66,40,0
.goto Eastern Plaguelands,50.73,18.33,40,0
.goto Eastern Plaguelands,50.89,16.50,40,0
.goto Eastern Plaguelands,52.97,17.29,40,0
.goto Eastern Plaguelands,52.88,19.18,40,0
>>Kill |cRXP_ENEMY_Pathstriders|r, |cRXP_ENEMY_Rangers|r and |cRXP_ENEMY_Woodsmen|r
>>|cRXP_WARN_These mobs hit very hard for non-elites|r << !Rogue !Druid
>>|cRXP_WARN_These mobs hit very hard for non-elites; remember Pathstrider's Faerie Fire ability, in case you need to escape|r << Rogue/Druid
.complete 6133,1 
.mob +Pathstrider
.complete 6133,2 
.mob +Ranger
.complete 6133,3 
.mob +Woodsman
.isOnQuest 6133
step
.goto Eastern Plaguelands,52.14,18.30
>>Loot the |cRXP_LOOT_Quel'Thalas Registry|r on top of the bench
.complete 6133,4 
.isOnQuest 6133
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6022 >>Turn in To Kill With Purpose
.target Nathanos Blightcaller
.isQuestComplete 6022
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6042 >>Turn in Un-Life's Little Annoyances
.target Nathanos Blightcaller
.isQuestComplete 6042
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6133 >>Turn in The Ranger Lord's Behest
.target Nathanos Blightcaller
.isQuestComplete 6133
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
>>|cRXP_WARN_These are pre-requisite quests for a quest in Stratholme|r
.accept 6135 >>Accept Duskwing, Oh How I Hate Thee...
.accept 6136 >>Accept The Corpulent One
.target Nathanos Blightcaller
.isQuestTurnedIn 6022
.isQuestTurnedIn 6042
.isQuestTurnedIn 6133
step
.goto Eastern Plaguelands,46.2,64.0,0
.goto Eastern Plaguelands,27.2,73.6,0
.goto Eastern Plaguelands,46.2,64.0,80,0
.goto Eastern Plaguelands,27.2,73.6,80,0
>>Kill |cRXP_ENEMY_Duskwing|r. Loot him for his |cRXP_LOOT_Fur|r
>>|cRXP_WARN_He patrols nearby|r
.complete 6135,1 
.unitscan Duskwing
.isOnQuest 6135
step
.goto Eastern Plaguelands,56.3,31.0
>>Kill |cRXP_ENEMY_Borelgore|r
>>|cRXP_WARN_He patrols around this area. Find him & kill him|r
.complete 6136,1 
.unitscan Borelgore
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6135 >>Turn in Duskwing, Oh How I Hate Thee...
.target Nathanos Blightcaller
.isQuestComplete 6135
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6136 >>Turn in The Corpulent One
.target Nathanos Blightcaller
.isQuestComplete 6136
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.accept 6163 >>Accept Ramstein
.target Nathanos Blightcaller
.isQuestTurnedIn 6135
.isQuestTurnedIn 6136
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.accept 6163 >>Accept Ramstein
.target Nathanos Blightcaller
.isQuestAvailable 6163
step
#completewith LHCpickups
.subzone 2268 >>Travel to |cFFfa9602Light's Hope Chapel|r
step
.goto Eastern Plaguelands,79.60,63.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alen|r
.accept 5281 >>Accept The Restless Souls
.target Caretaker Alen
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.accept 5251 >>Accept The Archivist
.target Duke Nicholas Zverenhoff
step
.goto Eastern Plaguelands,81.47,59.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.accept 5212 >>Accept The Flesh Does Not Lie
.target Betina Bigglezink
step
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.turnin 5462 >>Turn in The Dying, Ras Frostwhisper
.accept 5463 >>Accept Menethil's Gift
.target Leonid Barthalomew the Revered
.isQuestComplete 5462
step
#optional
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.accept 5463 >>Accept Menethil's Gift
.target Leonid Barthalomew the Revered
.isQuestTurnedIn 5462
step
.goto Eastern Plaguelands,80.605,57.979
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey LaRue|r
.accept 5214 >>Accept The Great Ezra Grimm
.target Smokey LaRue
step
#label LHCpickups
.goto Eastern Plaguelands,81.627,58.077
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessica Chambers|r
.home >>Set your Hearthstone to Light's Hope Chapel
.target Jessica Chambers
.subzoneskip 2268,1
.bindlocation 2268
step
#completewith RestlessSouls
.subzone 2627 >>Travel to Terrordale
step
.goto Eastern Plaguelands,14.45,33.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Egan|r
.turnin 5281 >>Turn in The Restless Souls
.accept 5282 >>Accept The Restless Souls
.target Egan
.isOnQuest 5281
step
#label RestlessSouls
#optional
.goto Eastern Plaguelands,14.45,33.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Egan|r
.accept 5282 >>Accept The Restless Souls
.target Egan
.isQuestTurnedIn 5281
step
#label EnterLiving
.goto Eastern Kingdoms,52.96,28.67
.subzone 2279,2 >>Enter Stratholme
step
#completewith RivenDare
>>Loot |T132761:0|t[|cRXP_PICK_Supply Crates|r] scattered around the instance. Loot them for |T134855:0|t[|cRXP_LOOT_Stratholme Holy Water|r]
>>Some of the crates are traps and contain poison or hostile bugs inside
>>|cRXP_WARN_If careful you can tell them apart as when you move close to a trapped crate "disarm trap" will appear on the tooltip|r
.collect 13180,5,5243,1 
step
#completewith HolyWater
.use 13289 >>|cRXP_WARN_Use|r |T135614:0|t[Egan's Blaster] |cRXP_WARN_on|r |cRXP_ENEMY_Spectral Citizens|r |cRXP_WARN_and|r |cRXP_ENEMY_Ghostly Citizen|r.
>>|cRXP_ENEMY_Restless Souls|r |cRXP_WARN_will appear. Use it on them too|r
.complete 5282,1 
.mob Spectral Citizen
.mob Ghostly Citizen
.mob Restless Soul
.isOnQuest 5282
step
>>Take a left into the alleyway coming from the entrance of the living side
>>|cRXP_WARN_Click on the|r |T132761:0|t[|cRXP_PICK_Premium Grimm Tobacco|r] |cRXP_WARN_box on the ground at the end of it|r
>>|cRXP_ENEMY_Ezra Grim|r will spawn. Kill him and loot him for |cRXP_LOOT_Grimm's Premium Tobacco|r
>>|cRXP_WARN_Be careful as he will aggro every |cRXP_ENEMY_Undead|r in an extremely large radius|r
.complete 5214,1 
.mob Ezra Grim
.isOnQuest 5214
step
>>Kill |cRXP_ENEMY_Archivist Galford|r. Click the |cRXP_PICK_Scarlet Archive|r on the table
.complete 5251,1 
.complete 5251,2 
.mob Archivist Galford
.isOnQuest 5251
step
>>Loot the |cRXP_PICK_painting|r on the wall in |cRXP_ENEMY_Archivist Galford's|r room
.complete 5848,1 
.isOnQuest 5848
step
#completewith next
+|cRXP_WARN_If possible, return to Light's hope Chapel now to turn in "The Archivist" BEFORE killing |cRXP_ENEMY_Grand Crusader Dathrohan|r |cRXP_ENEMY_(Balnazzar)|r as this will allow you to loot|r |T136183:0|t[|cRXP_LOOT_Head of Balnazzar|r]
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
>>|cRXP_WARN_Skip this step if you do not wish to do this now|r
.turnin 5251 >>Turn in The Archivist
.target Duke Nicholas Zverenhoff
step
>>Kill |cRXP_ENEMY_Grand Crusader Dathrohan|r |cRXP_ENEMY_(Balnazzar)|r. Loot him for |T136183:0|t[|cRXP_LOOT_Head of Balnazzar|r]. Use it to start the quest
.collect 13250,1,5262 
.accept 5262 >>Accept The Truth Comes Crashing Down
.mob Grand Crusader Dathrohan
.mob Balnazzar
.isQuestTurnedIn 5251
step
#completewith next
+|cRXP_WARN_If possible, return to Light's hope Chapel once more to get the follow-up quest to kill |cRXP_ENEMY_Baron Rivendare|r
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
>>|cRXP_WARN_Skip this step if you do not wish to do this now|r
.turnin 5262 >>Turn in The Truth Comes Crashing Down
.accept 5263 >>Accept in Above and Beyond
.target Duke Nicholas Zverenhoff
step
#completewith Souls2
>>Kill |cRXP_ENEMY_Undead|r. Loot them for their |T134358:0|t[|cRXP_LOOT_Plagued Flesh Samples|r]
.complete 5212,1 
.isOnQuest 5212
step
>>Kill |cRXP_ENEMY_Ramstein|r. Loot him for his |cRXP_LOOT_Head|r
.complete 6163,1 
.mob Ramstein the Gorger
.isOnQuest 6163
step
>>Kill |cRXP_ENEMY_Baron Rivendare|r. Loot him for his |cRXP_ENEMY_Head|r
.complete 5263,1 
.mob Baron Rivendare
.isOnQuest 5263
step
#label RivenDare
>>Kill |cRXP_ENEMY_Baron Rivendare|r. Afterwards, click |cRXP_FRIENDLY_Menethil's Gift|r in the orange circle on the ground
.turnin 5463 >>Turn in Menethil's Gift
.accept 5464 >>Accept Menethil's Gift
.mob Baron Rivendare
step
#label HolyWater
>>Loot |T132761:0|t[|cRXP_PICK_Supply Crates|r] scattered around the instance. Loot them for |T134855:0|t[|cRXP_LOOT_Stratholme Holy Water|r]
>>Some of the crates are traps and contain poison or hostile bugs inside
>>|cRXP_WARN_If careful you can tell them apart as when you move close to a trapped crate "disarm trap" will appear on the tooltip|r
.collect 13180,5,5243,1 
step
#label Souls2
.use 13289 >>|cRXP_WARN_Use|r |T135614:0|t[Egan's Blaster] |cRXP_WARN_on|r |cRXP_ENEMY_Spectral Citizens|r |cRXP_WARN_and|r |cRXP_ENEMY_Ghostly Citizen|r.
>>|cRXP_ENEMY_Restless Souls|r |cRXP_WARN_will appear. Use it on them too|r
.complete 5282,1 
.mob Spectral Citizen
.mob Ghostly Citizen
.mob Restless Soul
.isOnQuest 5282
step
>>Kill |cRXP_ENEMY_Undead|r. Loot them for their |T134358:0|t[|cRXP_LOOT_Plagued Flesh Samples|r]
.complete 5212,1 
.isOnQuest 5212
step
#completewith RestlessSouls
.subzone 2627 >>Travel to Terrordale
step
.goto Eastern Plaguelands,14.45,33.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Egan|r
.turnin 5282 >>Turn in The Restless Souls
.target Egan
.isQuestComplete 5282
step
#completewith LCHTurnins
.hs >>Hearth to Light's hope Chapel
.bindlocation 2268,1
.subzoneskip 2268
.use 6948
.cooldown item,6948,>0,1
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.turnin 5262 >>Turn in The Truth Comes Crashing Down
.accept 5263 >>Accept in Above and Beyond
.target Duke Nicholas Zverenhoff
.isOnQuest 5262
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.turnin 5263 >>Turn in Above and Beyond
.accept 5264 >>Accept Lord Maxwell Tyrosus
.target Duke Nicholas Zverenhoff
.isQuestComplete 5263
step
#optional
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.accept 5264 >>Accept Lord Maxwell Tyrosus
.target Duke Nicholas Zverenhoff
.isQuestTurnedIn 5263
step
.goto Eastern Plaguelands,81.74,57.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.turnin 5264 >>Turn in Lord Maxwell Tyrosus
.accept 5265 >>Accept The Argent Hold
.target Lord Maxwell Tyrosus
.isQuestComplete 5264
step
#optional
.goto Eastern Plaguelands,81.74,57.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.accept 5265 >>Accept The Argent Hold
.target Lord Maxwell Tyrosus
.isQuestTurnedIn 5264
step
.goto Eastern Plaguelands,81.81,57.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tClick on |cRXP_FRIENDLY_The Argent Hold|r a small chest next to Maxwell
.turnin 5265 >>Turn in The Argent Hold
.target The Argent Hold
.isOnQuest 5265
step
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.accept 5243 >>Accept Houses of the Holy
.turnin 5243 >>Turn in Houses of the Holy
.target Leonid Barthalomew the Revered
.itemcount 13180,5
step
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.turnin 5464 >>Turn in Menethil's Gift
.accept 5465 >>Accept Soulbound Keepsake
.target Leonid Barthalomew the Revered
.isOnQuest 5464
step
#optional
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.accept 5465 >>Accept Soulbound Keepsake
.target Leonid Barthalomew the Revered
.isQuestTurnedIn 5464
step
.goto Eastern Plaguelands,81.47,59.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.turnin 5212 >> Turn in The Flesh Does Not Lie
.target Betina Bigglezink
.isQuestComplete 5212
step
#label LCHTurnins
.goto Eastern Plaguelands,80.605,57.979
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey LaRue|r
.accept 5214 >>Accept The Great Ezra Grimm
.target Smokey LaRue
.isQuestComplete 5214
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6163 >>Turn in Ramstein
.target Nathanos Blightcaller
.isQuestComplete 6163
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.turnin 5848 >>Turn in Of Love and Family
.target Tirion Fordring
.isQuestComplete 5848
step
#completewith RichRas
.zone Western Plaguelands >>Travel to |cFFfa9602Western Plaguelands|r
step
#completewith RichRas
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5465 >>Turn in Soulbound Keepsake
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isOnQuest 5465
.use 13544
step
#optional
#label RichRas
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5465
.use 13544
step
#completewith next
+|cRXP_WARN_Find a group for Scholomance now if you wish to complete the final quest of the chain "The Lich, Ras Frostwhisper"|r
step
.use 13752>>|cRXP_WARN_Use the|r |T133736:0|t[Soulbound Keepsake] |cRXP_WARN_on|r |cRXP_ENEMY_Ras Frostwhisper|r
>>Kill |cRXP_ENEMY_Ras Frostwhisper|r inside Scholomance. Loot him for his |cRXP_LOOT_Head|r
.complete 5466,1 
.mob Ras Frostwhisper
.isOnQuest 5466
step
#optional
#completewith RichRas2
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Magistrate Marduke|r outside the instance
step
#optional
#completewith RichRas2
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
#optional
#label RichRas2
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5466 >>Turn in The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestComplete 5466
.use 13544
step
+|cRXP_WARN_This is the end of the Stratholme guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 118 Dire Maul (East)
#displayname 18. Dire Maul (East)
step << era
#optional
#phase 1
+|cRXP_WARN_Dire Maul is not until accessible until Phase 2 has released|r
step
#completewith EnterDME
.zone Feralas >> Travel to Feralas
step
.goto Feralas,76.18,43.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talo Thornhoof|r
.accept 7489 >>Accept Lethtendris's Web
.target Talo Thornhoof
step
.goto Feralas,76.910,37.353
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azj'Tordin|r
.accept 7441 >>Accept Pusillin and the Elder Azj'Tordin
.target Azj'Tordin
step << Mage era
#softcore
.xp <60,1
>>If it is possible, enter Dire Maul (North) and head into the Library to accept the quest for your level 60 Mage Water quest
>>You will need to have the |cRXP_LOOT_Crescent Key|r to open the door to the Library or consider looking for someone selling Tribute buffs that has already opened the door
>>|cRXP_WARN_If you cannot do this, skip this step|r
>>Talk to |cRXP_FRIENDLY_Lorekeeper Lydros|r in Dire Maul (North) Library
.accept 7463 >> Accept Arcane Refreshment
.target Lorekeeper Lydros
step
#label EnterDME
.goto 1414,43.83,67.40,15 >> Enter Dire Maul (East)
step
>>Talk to |cRXP_FRIENDLY_Pusillin|r and continue to chase him through Dire Maul by talking to him every time he stops
>>Kill |cRXP_ENEMY_Pusillin|r. Loot him for the |cRXP_LOOT_Crescent Key|r and |cRXP_LOOT_Book of Incantations|r
.collect 18249,1 
.complete 7441,1 
.target Pusillin
.skipgossip
.isOnQuest 7441
step
>>Kill |cRXP_ENEMY_Lethtendris|r. Loot her for |cRXP_LOOT_Lethtendris's Web|r
.complete 7489,1 
.mob Lethtendris
step << Mage era
>>Kill |cRXP_ENEMY_Hydrospawn|r. Loot it for the |cRXP_LOOT_Hydrospawn Essence|r
.complete 7463,1 
.mob Hydrospawn
step
>>Kill |cRXP_ENEMY_Alzzin the Wildshaper|r. Loot a |cRXP_PICK_Felvine Shard|r on the ground after
.collect 18501,1,5526,1 
.mob Alzzin the Wildshaper
.isOnQuest 7463
step << Mage era
#softcore
>>Talk to |cRXP_FRIENDLY_Lorekeeper Lydros|r in the Dire Maul (North) Library
>>|cRXP_WARN_Skip this if you can't access it|r
.turnin 7463 >>Turn in Arcane Refreshment
.target Lorekeeper Lydros
.xp <60,1
.isQuestComplete 7463
step
.goto Feralas,76.910,37.353
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azj'Tordin|r in Feralas
.turnin 7441 >>Turn in Pusillin and the Elder Azj'Tordin
.target Azj'Tordin
.isQuestComplete 7441
step
.goto Feralas,76.18,43.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talo Thornhoof|r
.turnin 7489 >>Turn in Lethtendris's Web
.target Talo Thornhoof
.isQuestComplete 7489
step
#completewith SotF
.zone Moonglade >> Travel to Moonglade
step
.goto Moonglade,51.685,45.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine Saturna|r
.accept 5526 >>Accept Shards of the Felvine
.target Rabine Saturna
.isQuestTurnedIn 5527
step
.use 18539 >> |cRXP_WARN_Use the|r |T132595:0|t[Reliquary of Purity]
.complete 5526,1 
.isOnQuest 5526
.isQuestTurnedIn 5527
step
#label SotF
.goto Moonglade,51.685,45.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine Saturna|r
.turnin 5526 >> Turn in Shards of the Felvine
.target Rabine Saturna
.isQuestComplete 5526
step
+|cRXP_WARN_This is the end of the Dire Maul (East) guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 119 Dire Maul (West)
#displayname 19. Dire Maul (West)
step << era
#optional
#phase 1
+Dire Maul is not until accessible until Phase 2 has released
step
#completewith EnterDM
.zone Feralas >> Travel to Feralas
step
#loop
.goto Feralas,74.15,44.79,0
.goto Feralas,74.15,44.79,30,0
.goto Feralas,74.39,44.01,30,0
.goto Feralas,75.22,43.75,30,0
.goto Feralas,76.58,43.23,30,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Korolusk|r
>>|cRXP_FRIENDLY_Sage Korolusk|r |cRXP_WARN_patrols slightly through Camp Mojache|r
.accept 7481 >>Accept Elven Legends
.target Sage Korolusk
step
#label EnterDM
.goto 1414,42.97,67.79,15 >>Enter Dire Maul (West)
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Shen'dralar Ancient|r
>>|cRXP_WARN_She is inside DM:West on the bridge in the upper section|r
.accept 7461 >>Accept The Madness Within
.target Shen'dralar Ancient
step
>>Kill |cRXP_ENEMY_Immol'thar|r and |cRXP_ENEMY_Prince Tortheldrin|r
.complete 7461,1 
.mob +Immol'thar
.complete 7461,2 
.mob +Prince Tortheldrin
.isOnQuest 7461
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Shen'dralar Ancient|r
>>|cRXP_WARN_She is inside DM:West on the bridge in the upper section|r
.turnin 7461 >>Turn in The Madness Within
.accept 7877 >>Accept The Treasure of the Shen'dralar
.target Shen'dralar Ancient
.isQuestComplete 7461
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Shen'dralar Ancient|r
>>|cRXP_WARN_She is inside DM:West on the bridge in the upper section|r
.accept 7877 >>Accept The Treasure of the Shen'dralar
.target Shen'dralar Ancient
.isQuestTurnedIn 7461
step
>>Click the |cRXP_PICK_The Treasure of the Shen'dralar|r
>>|cRXP_WARN_This is found back where you killed |cRXP_ENEMY_Prince Tortheldrin|r in the Library, under the ramp leading to him|r
.turnin 7877 >>Turn in The Treasure of the Shen'dralar
.isOnQuest 7877
step << Mage era
#optional
#softcore
>>Talk to |cRXP_FRIENDLY_Lorekeeper Lydros|r in the Dire Maul (North) Library
.turnin 7463 >> Turn in Arcane Refreshment
.target Lorekeeper Lydros
.xp <60,1
.isQuestComplete 7463
step
>>Click the |cRXP_PICK_Skeletas Remains of Kariel Winthalus|r inside the Dire Maul Library
>>|cRXP_WARN_This is located beside|r |cRXP_FRIENDLY_Lorekeeper Lydros|r
.complete 7481,1 
.isOnQuest 7481
step
#completewith next
.zone Feralas >>Travel to Feralas
step
#loop
.goto Feralas,74.15,44.79,0
.goto Feralas,74.15,44.79,30,0
.goto Feralas,74.39,44.01,30,0
.goto Feralas,75.22,43.75,30,0
.goto Feralas,76.58,43.23,30,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Korolusk|r
>>|cRXP_FRIENDLY_Sage Korolusk|r |cRXP_WARN_patrols slightly through Camp Mojache|r
.accept 7481 >>Accept Elven Legends
.target Sage Korolusk
.isQuestComplete 7481
step
+|cRXP_WARN_This is the end of the Dire Maul (West) guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RestedXP Dungeon Quest Guides (H)
#subgroup 50-60
<< Horde
#name 120 Dire Maul (North)
#displayname 20. Dire Maul (North)
step << era
#optional
#phase 1
+Dire Maul is not until accessible until Phase 2 has released
step
>>The following materials are required if you wish to complete a Tribute run
>>|cRXP_WARN_You will also need a Rogue with 300 Lockpicking skill OR a Powerful Seaforium Charge OR a Truesilver Skeleton Key|r
>>|cRXP_WARN_Skip buying the Bolt of Runecloth, Rugged Leather and Rune Thread if you decide to simply buy the Gordok Ogre Suit|r
>>|cRXP_WARN_Skip this step if you wish to complete the dungeon normally|r
.collect 18258,1 
.collect 14048,4 
.collect 8170,8 
.collect 14341,2 
.collect 15994,1 
.collect 3829,1 
step
#completewith EnterDM
.zone Feralas >>Travel to Feralas
step
#loop
.goto Feralas,74.15,44.79,0
.goto Feralas,74.15,44.79,30,0
.goto Feralas,74.39,44.01,30,0
.goto Feralas,75.22,43.75,30,0
.goto Feralas,76.58,43.23,30,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage Korolusk|r
>>|cRXP_FRIENDLY_Sage Korolusk|r |cRXP_WARN_patrols slightly through Camp Mojache|r
.accept 7481 >>Accept Elven Legends
.target Sage Korolusk
step
#label EnterDM
.goto 1414,43.45,66.52,15 >> Enter Dire Maul (North)
step
.isOnQuest 7482
>>Click the |cRXP_PICK_Skeletas Remains of Kariel Winthalus|r inside the Dire Maul Library
>>|cRXP_WARN_This is located beside|r |cRXP_FRIENDLY_Lorekeeper Lydros|r
.complete 7482,1 
step
+|cRXP_WARN_If you are doing a Tribute run:|r
>>Completely avoid |cRXP_ENEMY_Guard Mol'dar|r, |cRXP_ENEMY_Guard Fengus|r and |cRXP_ENEMY_Stomper Kreeg|r
>>Make sure someone in your party loots |cRXP_PICK_Fengus's Chest|r for the |cRXP_LOOT_Gordok Courtyard Key|r
>>Use the materials aquired earlier to trap |cRXP_ENEMY_Guard Slip'kik|r
>>Head up the ramp and loot the |cRXP_PICK_Ogre Tannin|r, then return below to |cRXP_FRIENDLY_Knot Thimblejack|r to make the |T132636:0|t[|cRXP_LOOT_Gordok Ogre Suit|r] if you didn't buy one
>>Talk to |cRXP_ENEMY_Captain Kromcrush|r while wearing the |T132636:0|t[|cRXP_LOOT_Gordok Ogre Suit|r]
>>Kill |cRXP_ENEMY_King Gordok|r. Keep |cRXP_ENEMY_Cho'Rush the Observer|r alive
>>|cRXP_WARN_Skip this step if you are doing a normal clear|r
step
+Complete Dire Maul (North)
>>|cRXP_WARN_There are no other quests to complete. Exit the instance once complete|r
.zoneskip Feralas
step
#completewith next
.zone Feralas >>Travel to Feralas
step
.goto Feralas,31.8,44.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scholar Runethorn|r
>>|cRXP_FRIENDLY_Scholar Runethorn|r |cRXP_WARN_patrols slightly through Feathermoon Stronghold|r
.turnin 7482 >> Turn in Elven Legends
.target Scholar Runethorn
step
+|cRXP_WARN_This is the end of the Dire Maul (North) guide. Please pick another guide to continue|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 15-30
<< Alliance
#name 01. The Deadmines
#displayname 1. The Deadmines
step
#completewith next
.zone Westfall >> Travel to Westfall
step
.goto Westfall,56.33,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryan Stoutmantle|r
.accept 65 >> Accept The Defias Brotherhood
.target Gryan Stoutmantle
step
#completewith next
.goto Westfall,56.55,52.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thor|r
.fly Redridge >> Fly to Redridge Mountains
.target Thor
.zoneskip Redridge Mountains
step
.goto Redridge Mountains,27.35,44.07,8,0
.goto Redridge Mountains,26.48,45.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wiley the Black|r inside upstairs
.turnin 65 >> Turn in The Defias Brotherhood
.accept 132 >> Accept The Defias Brotherhood
.target Wiley the Black
step
#completewith next
.goto Redridge Mountains,30.59,59.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ariena Stormfeather|r
.fly Westfall >> Fly to Westfall
.target Ariena Stormfeather
.zoneskip Westfall
step
.goto Westfall,56.325,47.519
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryan Stoutmantle|r
.turnin 132 >> Turn in The Defias Brotherhood
.accept 135 >> Accept The Defias Brotherhood
.target Gryan Stoutmantle
step
#completewith next
.goto Westfall,56.55,52.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thor|r
.fly Stormwind >> Fly to Stormwind
.target Thor
.zoneskip Stormwind City
step
.goto StormwindClassic,75.78,59.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Mathias Shaw|r
.turnin 135 >> Turn in The Defias Brotherhood
.accept 141 >> Accept The Defias Brotherhood
.target Master Mathias Shaw
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shoni the Shilent|r and |cRXP_FRIENDLY_Wilder Thistlenettle|r
.accept 2040 >> Accept Underground Assault
.target +Shoni the Shilent
.goto StormwindClassic,55.510,12.504
.accept 167 >> Accept Oh Brother. . .
.accept 168 >> Accept Collecting Memories
.goto StormwindClassic,65.438,21.175
.target +Wilder Thistlenettle
step
#completewith next
.goto StormwindClassic,66.277,62.137
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Westfall >> Fly to Westfall
.target Dungar Longdrink
.zoneskip Westfall
step
.goto Westfall,56.325,47.519
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryan Stoutmantle|r
.turnin 141 >> Turn in The Defias Brotherhood
.accept 142 >> Accept The Defias Brotherhood
.target Gryan Stoutmantle
step
.goto Westfall,44.50,69.62
.line Westfall,44.50,69.62,44.50,69.62,45.08,69.40,45.21,69.35,45.63,68.69,45.85,67.73,45.62,66.99,45.52,65.71,45.61,64.95,44.28,63.88,44.26,62.80,43.60,59.89,43.37,58.42,43.26,57.01,43.12,54.24,42.15,52.74,41.74,51.42,41.48,49.89,40.91,48.71,38.93,46.05,38.51,45.46,37.85,45.54,36.60,44.21,36.06,43.86,35.12,43.49,33.92,43.21,32.56,43.05,31.34,44.54,32.56,43.05,33.92,43.21,35.12,43.49,36.06,43.86,36.26,43.77,36.87,42.87,36.95,40.85,37.04,39.79,37.91,36.98,39.06,35.58,40.48,34.31,41.27,32.87,41.76,31.27,42.26,30.26,43.20,28.99,44.29,28.19,44.64,26.85,44.57,24.94,44.64,26.85,44.29,28.19,43.20,28.99,42.26,30.26,41.76,31.27,41.27,32.87,40.48,34.31,39.06,35.58,37.91,36.98,37.04,39.79,36.95,40.85,36.87,42.87,36.26,43.77,36.06,43.86,35.12,43.49,33.92,43.21,32.56,43.05,31.34,44.54,32.56,43.05,33.92,43.21,35.12,43.49,36.06,43.86,36.60,44.21,37.85,45.54,38.51,45.46,38.93,46.05,40.91,48.71,41.48,49.89,41.74,51.42,42.15,52.74,43.12,54.24,43.26,57.01,43.37,58.42,43.60,59.89,44.26,62.80,44.28,63.88,45.61,64.95,45.52,65.71,45.62,66.99,45.85,67.73,45.63,68.69,45.21,69.35,45.08,69.40,44.50,69.62
>>Kill the |cRXP_ENEMY_Defias Messenger|r. Loot him for his |cRXP_LOOT_Mysterious Message|r
>>|cRXP_WARN_The |cRXP_ENEMY_Defias Messenger|r spawns in Moonbrook. He walks along the road north of Moonbrook, to the Gold Coast Quarry and Jangolode Mine. If you don't see him along the road, wait for him to spawn in Moonbrook|r
>>|cRXP_WARN_He has a 4-5 minute respawn timer|r
.complete 142,1 
.unitscan Defias Messenger
step
.goto Westfall,56.33,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryan Stoutmantle|r
.turnin 142 >> Turn in The Defias Brotherhood
.target Gryan Stoutmantle
step
.goto Westfall,55.68,47.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_The Defias Traitor|r
>>|cRXP_WARN_You may need to wait for |cRXP_FRIENDLY_The Defias Traitor|r to spawn if he's not there|r
>>|cRXP_WARN_If you've already assembled a group, make sure your group has also turned in the previous part first before starting the escort|r
.accept 155 >> Accept The Defias Brotherhood
.target The Defias Traitor
step
.goto Westfall,42.56,71.71
>>Escort the |cRXP_FRIENDLY_The Defias Traitor|r to The Deadmines
>>|cRXP_WARN_Stay beside |cRXP_FRIENDLY_The Defias Traitor|r at all times. Be ready to fight |cRXP_ENEMY_Defias Pillagers|r and |cRXP_ENEMY_Defias Looters|r upon reaching Moonbrook|r
.complete 155,1 
.target The Defias Traitor
step
.goto Westfall,56.33,47.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryan Stoutmantle|r
.turnin 155 >> Turn in The Defias Brotherhood
.accept 166 >> Accept The Defias Brotherhood
.target Gryan Stoutmantle
step
.goto Westfall,56.67,47.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Riell|r atop the Tower
.accept 214 >> Accept Red Silk Bandanas
.target Scout Riell
step
.goto 1436,56.454,69.982,0
.goto 1436,56.434,74.339,0
.goto 1436,59.384,74.184,0
.goto 1436,60.871,74.362,0
.goto 1436,60.902,77.640,0
.goto 1436,63.442,77.339,0
.goto 1436,65.203,75.286,0
.goto 1436,63.594,72.862,0
.goto 1436,63.825,70.125,0
.goto 1436,42.649,71.376
>>|cRXP_WARN_Grind |cRXP_ENEMY_Gnolls|r south of Sentinel Hill whilst assembling a Deadmines group|r
.subzone 20 >>When your group has been assembled, travel to Moonbrook
step
.goto Westfall,42.55,71.69
.subzone 1581 >> Enter the Defias Hideout with your group
step
#completewith EnterDM
>>Kill the |cRXP_ENEMY_Defias|r. Loot them for their |cRXP_LOOT_Red Silk Bandanas|r
>>|cRXP_WARN_You can also complete this inside the Deadmines|r
.complete 214,1 
.isOnQuest 214
step
#completewith next
>>Kill |cRXP_ENEMY_Skeletal Miners|r, |cRXP_ENEMY_Undead Dynamiters|r and |cRXP_ENEMY_Undead Excavators|r. Loot them for their |cRXP_LOOT_Cards|r
>>|cRXP_WARN_This is completed OUTSIDE of the Dungeon|r
.complete 168,1 
.mob Skeletal Miner
.mob Undead Dynamiter
.mob Undead Excavator
step
.goto 1415,41.18,79.80,25,0
.goto 1415,41.03,79.96,25,0
.goto 1415,40.92,80.05,25,0
.goto 1415,41.08,80.11
>>Kill |cRXP_ENEMY_Foreman Thistlenettle|r. Loot him for his |cRXP_LOOT_Badge|r
>>|cRXP_WARN_This is completed OUTSIDE of the Dungeon|r
.complete 167,1 
.unitscan Foreman Thistlenettle
step
.goto 1415,41.18,79.80,25,0
.goto 1415,41.03,79.96,25,0
.goto 1415,40.92,80.05,25,0
.goto 1415,41.08,80.11
>>Kill |cRXP_ENEMY_Skeletal Miners|r, |cRXP_ENEMY_Undead Dynamiters|r and |cRXP_ENEMY_Undead Excavators|r. Loot them for their |cRXP_LOOT_Cards|r
>>|cRXP_WARN_This is completed OUTSIDE of the Dungeon|r
.complete 168,1 
.mob Skeletal Miner
.mob Undead Dynamiter
.mob Undead Excavator
step
#label EnterDM
.goto 1415,40.94,79.76,25,0
.goto 1415,40.86,79.62,20,0
.goto 1415,40.678,79.578
.subzone 1581,2 >> Enter The Deadmines Dungeon
step
#completewith VanCleef
>>Kill the |cRXP_ENEMY_Defias|r inside The Deadmines. Loot them for their |cRXP_LOOT_Red Silk Bandanas|r
.complete 214,1 
.isOnQuest 214
step
>>Kill |cRXP_ENEMY_Sneed|r. Loot him for the |cRXP_LOOT_Gnoam Sprecklesprocket|r
.complete 2040,1 
step
#label VanCleef
>>Kill |cRXP_ENEMY_Edwin VanCleef|r. Loot him for his |cRXP_LOOT_Head|r and |T133471:0|t[|cRXP_LOOT_An Unsent Letter|r]
>>|cRXP_WARN_Use |T133471:0|t[|cRXP_LOOT_An Unsent Letter|r] to start the quest|r
.collect 2874,1,373,1 
.complete 166,1 
.accept 373 >> Accept The Unsent Letter
.use 2874 
step
>>Kill the |cRXP_ENEMY_Defias|r. Loot them for their |cRXP_LOOT_Red Silk Bandanas|r
>>|cRXP_WARN_You can also complete this inside and outside the Deadmines|r
.complete 214,1 
.isOnQuest 214
step
#completewith next
.goto Westfall,56.33,47.52,100 >> Travel to Sentinel Hill
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryan Stoutmantle|r and |cRXP_FRIENDLY_Scout Riell|r atop the Tower
.turnin 166 >> Turn in The Defias Brotherhood
.target +Gryan Stoutmantle
.goto Westfall,56.33,47.52
.turnin -214 >> Turn in Red Silk Bandanas
.target +Scout Riell
.goto Westfall,56.67,47.35
step
#completewith next
.goto Westfall,56.55,52.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thor|r
.fly Stormwind >> Fly to Stormwind
.target Thor
.zoneskip Stormwind City
step
.goto StormwindClassic,48.079,30.913,10,0
.goto StormwindClassic,49.193,30.285
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baros Alexston|r
.turnin 373 >> Turn in The Unsent Letter
.accept 389 >> Accept Bazil Thredd
.target Baros Alexston
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wilder Thistlenettle|r and |cRXP_FRIENDLY_Shoni the Shilent|r
.turnin 167 >> Turn in Oh Brother. . .
.turnin 168 >> Turn in Collecting Memories
.target +Wilder Thistlenettle
.goto StormwindClassic,65.438,21.175
.turnin 2040 >> Turn in Underground Assault
.target +Shoni the Shilent
.goto StormwindClassic,55.510,12.504
step
.goto StormwindClassic,42.435,59.236,10,0
.goto StormwindClassic,41.102,58.091
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Thelwater|r
.turnin 389 >> Turn in Bazil Thredd
.target Warden Thelwater
step
+|cRXP_WARN_You have completed The Deadmines quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 15-30
<< Alliance
#name 02. Shadowfang Keep
#displayname 2. Shadowfang Keep
step
#completewith next
.goto Wetlands,30.8,31.0,0
.goto Wetlands,37.8,29.6,0
.goto Wetlands,43.0,33.2,0
.zone Arathi Highlands >> Grind |cRXP_ENEMY_Mosshides Gnolls|r while looking for a group for Shadowfang Keep
step
#completewith next
.goto Arathi Highlands,43.01,55.00,90,0
.goto Arathi Highlands,25.45,46.95,90,0
.goto Arathi Highlands,21.29,30.24,70,0
.goto Hillsbrad Foothills,49.338,52.272
+There are no quests for Shadowfang Keep. You will have to run from Wetlands to Silverpine Forest. Ensure you stay on the road while running through Arathi Highlands, and watchout for the |cRXP_ENEMY_Forsaken Courier|r
.unitscan Forsaken Courier
step
.goto Hillsbrad Foothills,14.77,46.72,0
.goto Silverpine Forest,44.96,67.92,0
.goto Hillsbrad Foothills,14.77,46.72,100,0
.goto Silverpine Forest,47.19,69.78,100,0
.goto Silverpine Forest,44.712,67.769
.subzone 209,2 >> Enter Shadowfang Keep
step
+There are no quests for Shadowfang Keep
>>Clear Shadowfang Keep. Leave when you are finished
.zoneskip 209,1
step
+|cRXP_WARN_You have completed the Shadowfang Keep quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 15-30
<< Alliance
#name 03. Blackfathom Deeps
#displayname 3. Blackfathom Deeps
step
#completewith next
.zone Stormwind City >> Travel to Stormwind
step
.goto StormwindClassic,21.40,55.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argos Nightwhisper|r
.accept 3765 >> Accept The Corruption Abroad
.target Argos Nightwhisper
step
#completewith next
.zone Darnassus >> Travel to Darnassus
>>|cRXP_WARN_Buy a portal from a Mage if this is an option, otherwise travel to Wetlands and get the boat to Auberdine, followed by another boat to Darnassus|r
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argent Guard Manados|r and |cRXP_FRIENDLY_Dawnwatcher Shaedlass|r upstairs
.accept 1199 >> Accept Twilight Falls
.target +Argent Guard Manados
.goto Darnassus,55.239,23.996 
.accept 1198 >> Accept In Search of Thaelrid
.goto Darnassus,55.360,25.024 
.target +Dawnwatcher Shaedlass
step
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Take the purple portal to Rut'theran Village
.zoneskip Darnassus,1
step
#completewith next
.goto Teldrassil,58.399,94.016
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
>>|cRXP_WARN_Take the boat to Darkshore if you don't have the flight path|r
.fly Auberdine >> Fly to Darkshore
.target Vesprystus
.zoneskip Darkshore
step
.goto Darkshore,38.327,43.039
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gershala Nightwhisper|r
.turnin 3765 >> Turn in The Corruption Abroad
.accept 1275 >> Accept Researching the Corruption
.target Gershala Nightwhisper
step
.goto Darkshore,36.71,44.98,5,0
.goto Darkshore,36.336,45.574
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caylais Moonfeather|r
.fly Ashenvale >> Fly to Ashenvale
.target Caylais Moonfeather
.zoneskip Ashenvale
step
.goto Ashenvale,37.6,34.0,0
+Start looking for a group for BFD
.goto Ashenvale,15.5,19.0,0
.goto Ashenvale,14.230,14.618
>>Grind |cRXP_ENEMY_Furbolgs|r north of Astranaar for |T132911:0|t[Wool Cloth] while you assemble a group
.subzoneskip 2797
step
#completewith EnterBFD
.goto Ashenvale,14.230,14.618,0
.goto 1414,43.97,35.30,50 >> Travel to Blackfathom Deeps
.subzoneskip 2797
step
#completewith next
>>Kill |cRXP_ENEMY_Fallenroot Rogues|r, |cRXP_ENEMY_Fallenroot Satyrs|r, |cRXP_ENEMY_Blackfathom Oracles|r and |cRXP_ENEMY_Blackfathom Tide Priestesses|r. Loot them for their |cRXP_LOOT_Corrupted Brain Stems|r
>>|cRXP_WARN_You may also loot |cRXP_LOOT_Corrupted Brain Stems|r once inside the Instance|r
.complete 1275,1 
.mob Blackfathom Tide Priestess
.mob Blackfathom Oracle
.mob Fallenroot Rogue
.mob Fallenroot Satyr
.isOnQuest 1275
step
#label EnterBFD
.goto 1414,43.83,35.11,25,0
.goto 1414,43.92,34.56,25,0
.goto 1414,44.02,34.57,25,0
.goto 1414,44.340,34.840
.subzone 2797,2 >> Make your way to the BFD Instance Portal. Zone in
step
#completewith Kelris
>>Kill |cRXP_ENEMY_Nagas|r and |cRXP_ENEMY_Satyrs|r. Loot them for their |cRXP_LOOT_Corrupted Brain Stems|r
.complete 1275,1 
.isOnQuest 1275
step
#label manuscript
#sticky
>>Open the |cRXP_PICK_Pitted Iron Chest|r underwater near the area with the turtles. Loot it for |cRXP_LOOT_Lorgalis' Manuscript|r
.complete 971,1 
.isOnQuest 971
step
#label Thaelrid
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argent Guard Thaelrid|r
.turnin -1198 >> Turn in Search of Thaelrid
.accept 1200 >> Accept Blackfathom Villainy
step
#requires manuscript
#completewith Kelris
>>Kill all of the |cRXP_ENEMY_Twilight's Hammer|r. Loot them for their |cRXP_LOOT_Twilight Pendants|r
.complete 1199,1 
.isOnQuest 1199
step
#requires manuscript
#label Kelris
>>Kill |cRXP_ENEMY_Twilight Lord Kelris|r. Loot him for his |cRXP_LOOT_Head|r
.complete 1200,1 
.isOnQuest 1200
step
>>Kill all of the |cRXP_ENEMY_Twilight's Hammer|r. Loot them for their |cRXP_LOOT_Twilight Pendants|r
.complete 1199,1 
.isOnQuest 1199
step
#label FinalStem
>>Kill |cRXP_ENEMY_Nagas|r and |cRXP_ENEMY_Satyrs|r. Loot them for their |cRXP_LOOT_Corrupted Brain Stems|r
>>If you haven't completed this quest yet, click on the altar at the end of the dungeon to teleport you to the entrance. The mobs outside of the instance can also drop it.
.complete 1275,1 
.isOnQuest 1275
step
#optional
+Talk to |cRXP_FRIENDLY_Morridune|r at the end of the dungeon if you are still inside BFD to be teleported to Darnassus
.target Morridune
.zoneskip Ashenvale
.zoneskip Teldrassil
.zoneskip Darnassus
step
#completewith DarnEnd
.goto Ashenvale,34.41,47.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daelyshia|r
.fly Teldrassil >> Fly to Teldrassil
.target Daelyshia
.zoneskip Teldrassil
.zoneskip Darnassus
step
#sticky
#label DarnBFD
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argent Guard Manados|r up stairs
.turnin 1199 >> Turn in Twilight Falls
.goto Darnassus,55.239,23.996 
.target Argent Guard Manados
.isQuestComplete 1199
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dawnwatcher Selgorm|r up stairs
.turnin 1200 >> Turn in Blackfathom Villainy
.goto Darnassus,56.167,24.395 
.target Dawnwatcher Selgorm
.isQuestComplete 1200
step
#requires DarnBFD
#label DarnEnd
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Take the purple portal back to Rut'theran
.zoneskip Darkshore
.zoneskip Ashenvale
.subzoneskip 2797
step
#completewith next
.goto Ashenvale,34.41,47.98,-1
.goto Teldrassil,58.399,94.016,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r or |cRXP_FRIENDLY_Daelyshia|r
.fly Darkshore >> Fly to Darkshore
.zoneskip Darkshore
.target Daelyshia
.target Vesprystus
step
.goto Darkshore,38.327,43.039
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gershala Nightwhisper|r
.turnin 1275 >> Turn in Researching the Corruption
.target Gershala Nightwhisper
.isQuestComplete 1275
step
#completewith KitD
.zone Ironforge >> Travel to Ironforge
step
.goto Darkshore,32.29,44.05
.zone Wetlands >> Take the boat to Menethil Harbor, then fly to Ironforge
.zoneskip Ironforge
step
#completewith next
.goto Wetlands,9.490,59.694
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shellei Brondir|r
.fly Ironforge >> Fly to Ironforge
.target Shellei Brondir
.zoneskip Ironforge
step
#label KitD
.goto Ironforge,50.826,5.613
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gerrig Bonegrip|r
.turnin 971 >> Turn in Knowledge in the Deeps
.target Gerrig Bonegrip
step
+|cRXP_WARN_You have completed the Blackfathom Deeps quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 15-30
<< Alliance
#name 04. The Stockade
#displayname 4. The Stockade
step
#completewith next
.zone Redridge Mountains >> Travel to Redridge Mountains
step
.goto Redridge Mountains,26.258,46.580
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard Berton|r
.accept 386 >> Accept What Comes Around...
.target Guard Berton
step
#completewith next
.goto Redridge Mountains,30.590,59.410
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ariena Stormfeather|r
.fly Duskwood >> Fly to Duskwood
.target Ariena Stormfeather
.zoneskip Duskwood
step
.goto Duskwood,71.938,47.778
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Councilman Millstipe|r
.accept 377 >> Accept Crime and Punishment
.target Councilman Millstipe
step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felicia Maline|r
.goto Duskwood,77.49,44.28
.fly Stormwind>> Fly to Stormwind
.target Felicia Maline
.zoneskip Stormwind City
step
.goto StormwindClassic,69.25,39.63,40,0
.goto StormwindClassic,71.28,41.37,40,0
.goto StormwindClassic,73.33,45.65,40,0
.goto StormwindClassic,72.44,47.70,40,0
.goto StormwindClassic,69.25,39.63,40,0
.goto StormwindClassic,71.28,41.37,40,0
.goto StormwindClassic,73.33,45.65,40,0
.goto StormwindClassic,72.44,47.70
.line StormwindClassic,69.25,39.63,71.28,41.37,73.33,45.65,72.44,47.70,73.33,45.65,71.28,41.37,69.25,39.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nikova Raskol|r
>>|cRXP_FRIENDLY_Nikova Raskol|r |cRXP_WARN_patrols in Old Town|r
.accept 388 >> Accept The Color of Blood
.unitscan Nikova Raskol
step
.goto StormwindClassic,42.435,59.236,10,0
.goto StormwindClassic,41.102,58.091
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Thelwater|r
.accept 391 >> Accept The Stockade Riots
.accept 387 >> Accept Quell The Uprising
.target Warden Thelwater
.isQuestTurnedIn 389
step
.goto StormwindClassic,42.435,59.236,10,0
.goto StormwindClassic,41.102,58.091
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Thelwater|r
.accept 387 >> Accept Quell The Uprising
.target Warden Thelwater
step
.goto StormwindClassic,39.834,54.360
+Find a group for The Stockades. Zone in once your group is ready
.zoneskip Stormwind City,1 
step
#label stock1
#sticky
>>Kill the |cRXP_ENEMY_Defias|r. Loot them for their |cRXP_LOOT_Bandanas|r
.complete 387,1 
.complete 387,2 
.complete 387,3 
.complete 388,1 
step
#label stock2
#sticky
>>Kill |cRXP_ENEMY_Targorr the Dread|r. Loot him for his |cRXP_LOOT_Head|r. |cRXP_ENEMY_Targorr|r has a random spawn location
>>Kill |cRXP_ENEMY_Dextren Ward|r on the west prison wing. Loot him for his |cRXP_LOOT_Hand|r
.complete -386,1 
.mob +Targorr the Dread
.complete -377,1 
.mob +Dextren Ward
step
>>Kill |cRXP_ENEMY_Bazil Thredd|r on the east prison wing. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Ensure you have 3|r |T132905:0|t[Silk Cloth] |cRXP_WARN_for the follow up of this quest chain|r
.complete 391,1 
.collect 4306,3,2746,1 
.isOnQuest 391
.mob Bazil Thredd
step
#requires stock1
step
.goto StormwindClassic,42.435,59.236,10,0
.goto StormwindClassic,41.102,58.091
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Thelwater|r
.turnin 387 >> Turn in Quell The Uprising
.turnin 391 >> Turn in The Stockade Riots
.accept 392 >> Accept The Curious Visitor
.target Warden Thelwater
.isQuestTurnedIn 389
step
.goto StormwindClassic,42.435,59.236,10,0
.goto StormwindClassic,41.102,58.091
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warden Thelwater|r
.turnin 387 >> Turn in Quell The Uprising
.target Warden Thelwater
step
.goto StormwindClassic,49.194,30.283
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baros Alexston|r
.turnin 392 >> Turn in The Curious Visitor
.accept 393 >> Accept Shadow of the Past
.target Baros Alexston
.isQuestTurnedIn 389
step
.goto StormwindClassic,69.25,39.63,40,0
.goto StormwindClassic,71.28,41.37,40,0
.goto StormwindClassic,73.33,45.65,40,0
.goto StormwindClassic,72.44,47.70,40,0
.goto StormwindClassic,69.25,39.63,40,0
.goto StormwindClassic,71.28,41.37,40,0
.goto StormwindClassic,73.33,45.65,40,0
.goto StormwindClassic,72.44,47.70
.line StormwindClassic,69.25,39.63,71.28,41.37,73.33,45.65,72.44,47.70,73.33,45.65,71.28,41.37,69.25,39.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nikova Raskol|r
>>|cRXP_FRIENDLY_Nikova Raskol|r |cRXP_WARN_patrols in Old Town|r
.turnin 388 >> Turn in The Color of Blood
.unitscan Nikova Raskol
step
#completewith next
.goto StormwindClassic,74.90,54.00,20,0
.goto StormwindClassic,78.43,60.15,20,0
.goto StormwindClassic,78.67,60.13,5 >> Enter the SI:7 Headquarters. Travel up stairs toward |cRXP_FRIENDLY_Master Mathias Shaw|r
.isQuestTurnedIn 389
step
.goto StormwindClassic,75.78,59.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Mathias Shaw|r
.turnin 393 >> Turn in Shadow of the Past
.accept 350 >> Accept Look to an Old Friend
.target Master Mathias Shaw
.isQuestTurnedIn 389
step
.goto StormwindClassic,61.166,64.051,8,0
.goto StormwindClassic,59.908,64.177
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elling Trias|r up stairs
.turnin 350 >> Turn in Look to an Old Friend
.accept 2745 >> Accept Infiltrating the Castle
.target Elling Trias
.isQuestTurnedIn 389
step
#completewith next
.goto StormwindClassic,70.347,27.208,15,0
.goto StormwindClassic,72.005,21.542,20 >> Travel to the Stormwind Keep
.isQuestTurnedIn 389
step
.goto StormwindClassic,69.205,14.404
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrion|r
.turnin 2745 >> Turn in Infiltrating the Castle
.accept 2746 >> Accept Items of Some Consequence
.target Tyrion
.isQuestTurnedIn 389
step
#completewith next
.goto Elwynn Forest,32.384,49.866,50 >> Exit Stormwind. Travel to Clara's Farm House in Elwynn Forest
.isQuestTurnedIn 389
step
#ah
>>Loot |cRXP_LOOT_Clara's Fresh Apples|r on the table
>>|cRXP_WARN_If you still need|r |T132905:0|t[Silk Cloth] |cRXP_WARN_buy some from the Auction House|r
.complete 2746,2 
.goto Elwynn Forest,33.952,57.162
.complete 2746,1 
.isQuestTurnedIn 389
step
>>Loot |cRXP_LOOT_Clara's Fresh Apples|r on the table
.complete 2746,2 
.goto Elwynn Forest,33.952,57.162
.complete 2746,1 
.isQuestTurnedIn 389
step
#completewith next
.goto StormwindClassic,70.347,27.208,15,0
.goto StormwindClassic,72.005,21.542,20 >> Travel to the Stormwind Keep
.isQuestTurnedIn 389
step
.goto StormwindClassic,69.205,14.404
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrion|r
>>|cRXP_WARN_Ensure your party has all turned in Items of Some Consequence before you accept The Attack!|r
>>|cRXP_WARN_Automatic quest accept has been turned off for this step. Note you may not be able to accept the quest if someone else is in the process of doing it|r
.turnin 2746 >> Turn in Items of Some Consequence
.accept 434,1 >> Accept The Attack!
.timer 124,The Attack! RP
.target Tyrion
.isQuestTurnedIn 389
step 
.goto StormwindClassic,68.024,14.075
>>|cRXP_WARN_Wait in the center of the courtyard for |cRXP_ENEMY_Lord Gregor Lescovar|r and |cRXP_ENEMY_Marzon the Silent Blade|r to arrive. This takes roughly 2 minutes|r
>>Kill |cRXP_ENEMY_Lord Gregor Lescovar|r and |cRXP_ENEMY_Marzon the Silent Blade|r
.complete 434,1 
.complete 434,2 
.complete 434,3 
.mob Lord Gregor Lescovar
.mob Marzon the Silent Blade
.isQuestTurnedIn 389
step
.goto StormwindClassic,61.166,64.051,8,0
.goto StormwindClassic,59.908,64.177
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elling Trias|r up stairs
.turnin 434 >> Turn in The Attack!
.accept 394 >> Accept The Head of the Beast
.target Elling Trias
.isQuestTurnedIn 389
step
#completewith next
.goto StormwindClassic,74.90,54.00,20,0
.goto StormwindClassic,78.43,60.15,20,0
.goto StormwindClassic,78.67,60.13,5 >> Enter the SI:7 Headquarters. Travel up stairs toward |cRXP_FRIENDLY_Master Mathias Shaw|r
.isQuestTurnedIn 389
step
.goto StormwindClassic,75.78,59.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Mathias Shaw|r
.turnin 394 >> Turn in The Head of the Beast
.accept 395 >> Accept Brotherhood's End
.target Master Mathias Shaw
.isQuestTurnedIn 389
step
.goto StormwindClassic,49.194,30.283
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baros Alexston|r
.turnin 395 >> Turn in Brotherhood's End
.accept 396 >> Accept An Audience with the King
.target Baros Alexston
.isQuestTurnedIn 389
step
#completewith next
.goto StormwindClassic,70.347,27.208,20 >> Travel to the Stormwind Keep
.isQuestTurnedIn 389
step
.goto StormwindClassic,78.105,17.750
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Katrana Prestor|r
.turnin 396 >> Turn in An Audience with the King
.target Lady Katrana Prestor
.isQuestTurnedIn 389
step
#completewith next
.goto StormwindClassic,66.277,62.137
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Redridge >> Fly to Redridge Mountains
.target Dungar Longdrink
.zoneskip Redridge Mountains
step
.goto Redridge Mountains,26.258,46.580
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guard Berton|r
.turnin 386 >> Turn in What Comes Around...
.target Guard Berton
step
#completewith next
.goto Redridge Mountains,30.590,59.410
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ariena Stormfeather|r
.fly Duskwood >> Fly to Duskwood
.target Ariena Stormfeather
.zoneskip Duskwood
step
.goto Duskwood,71.938,47.778
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Councilman Millstipe|r
.turnin 377 >> Turn in Crime and Punishment
.target Councilman Millstipe
step
+|cRXP_WARN_You have completed The Stockade quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 15-30 << !classic
#subgroup 30-50 << classic
<< Alliance
#name 05. Gnomeregan
#displayname 5. Gnomeregan
step
#completewith GyrodrillmaticExcavationators
.zone Stormwind City >> Travel to Stormwind
step
.goto StormwindClassic,40.551,30.959
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Sarno|r
.accept 2923 >> Accept Tinkmaster Overspark
.target Brother Sarno
step
#label GyrodrillmaticExcavationators
.goto StormwindClassic,55.511,12.502
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shoni the Shilent|r
.accept 2928 >> Accept Gyrodrillmatic Excavationators
.target Shoni the Shilent
step
#completewith StartGnomer
.goto Dun Morogh,24.2,39.1,0
+Start Looking for a Gnomeregan group
.subzoneskip 133
.subzoneskip 721,2
step
#completewith next
.zone Ironforge >> Travel to Ironforge
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gnoarn|r, |cRXP_FRIENDLY_Tinkmaster Overspark|r, |cRXP_FRIENDLY_High Tinker Mekkatorque|r, |cRXP_FRIENDLY_Master Mechanic Castpipe|r and |cRXP_FRIENDLY_Klockmort Spannerspan|r
.accept 2927 >> Accept The Day After
.target +Gnoarn
.goto Ironforge,69.182,50.556
.turnin -2923 >> Turn in Tinkmaster Overspark
.accept 2922 >> Accept Save Techbot's Brain!
.target +Tinkmaster Overspark
.goto Ironforge,69.540,50.325
.accept 2929 >> Accept The Grand Betrayal
.target +High Tinker Mekkatorque
.goto Ironforge,68.743,48.969
.accept 2930 >> Accept Data Rescue
.target +Master Mechanic Castpipe
.goto Ironforge,69.823,48.101
.accept 2924 >> Accept Essential Artificials
.target +Klockmort Spannerspan
.goto Ironforge,67.925,46.101
step
#completewith next
.goto Dun Morogh,53.5,34.9
.zone Dun Morogh>>Exit Ironforge
step
.goto Dun Morogh,46.005,48.637,10,0
.goto Dun Morogh,45.887,49.377
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ozzie Togglevolt|r
.turnin 2927 >> Turn in The Day After
.accept 2926 >> Accept Gnogaine
.target Ozzie Togglevolt
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Belm|r inside
.target Innkeeper Belm
.goto Dun Morogh,47.377,52.523
.home >> Set your Hearthstone to Kharanos
step
#label StartGnomer
#completewith next
.goto Dun Morogh,24.35,39.78,0
.goto Dun Morogh,24.35,39.78,30,0
.goto 1415,43.42,53.81,45 >> Travel to Gnomeregan
step
.goto 1415,43.40,53.41,50,0
.goto 1415,43.13,53.36,50,0
.goto 1415,43.38,52.94,50,0
.goto 1415,43.40,53.41
.use 9283 >>|cRXP_WARN_Use the|r |T132788:0|t[Empty Leaden Collection Phial] |cRXP_WARN_on a |cRXP_ENEMY_Irradiated Invader|r or|r |cRXP_ENEMY_Irradiated Pillager|r
>>|cRXP_WARN_The |cRXP_ENEMY_Irradiated Invader|r or |cRXP_ENEMY_Irradiated Pillager|r must be ALIVE when you use it|r
>>|cRXP_WARN_This quest is completed while OUTSIDE of the dungeon|r
.complete 2926,1 
.mob Irradiated Invader
.mob Irradiated Pillager
.isOnQuest 2926
step
#completewith next
.goto Dun Morogh,46.005,48.637,40 >> Travel to |cRXP_FRIENDLY_Ozzie Togglevolt|r in Kharanos
>>|cRXP_WARN_You will get a follow up for when you go inside the dungeon|r
.isOnQuest 2926
step
.goto Dun Morogh,46.005,48.637,10,0
.goto Dun Morogh,45.887,49.377
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ozzie Togglevolt|r
.turnin 2926 >> Turn in Gnogaine
.target Ozzie Togglevolt
.isQuestComplete 2926
step
.goto Dun Morogh,45.887,49.377
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ozzie Togglevolt|r
.accept 2962 >> Accept The Only Cure is More Green Glow
.target Ozzie Togglevolt
.isQuestTurnedIn 2926
step
#completewith next
.goto Dun Morogh,24.35,39.78,0
.goto Dun Morogh,24.35,39.78,30,0
.goto 1415,43.42,53.81,45 >> Travel to Gnomeregan
.isOnQuest 2962
step
.goto 1415,43.37,53.11,70,0
.goto 1415,43.10,52.81
>>Kill |cRXP_ENEMY_Troggs|r and |cRXP_ENEMY_Gnomes|r. Loot them for a |T133215:0|t[|cRXP_LOOT_White Punch Card|r]
.collect 9279,1,2930,1,1 
>>Kill |cRXP_ENEMY_Techbot|r. Loot him for his |cRXP_LOOT_Memory Core|r
>>|cRXP_WARN_This quest is completed while OUTSIDE of the dungeon|r
.complete 2922,1 
.mob Techbot
.isOnQuest 2922
step
.goto 1415,43.40,53.41,50,0
.goto 1415,43.13,53.36,50,0
.goto 1415,43.38,52.94,50,0
.goto 1415,43.40,53.41
>>Kill |cRXP_ENEMY_Troggs|r and |cRXP_ENEMY_Gnomes|r. Loot them for a |T133215:0|t[|cRXP_LOOT_White Punch Card|r]
.collect 9279,1 
>>|cRXP_WARN_This quest is completed while OUTSIDE of the dungeon|r
.isOnQuest 2930
step
.goto 1415,43.364,52.892,-1
.goto 1415,43.411,52.898,-1
.goto 1415,43.402,52.672,-1
.goto 1415,43.430,52.675,-1
>>|cRXP_WARN_Use the|r |T133215:0|t[|cRXP_LOOT_White Punch Card|r] |cRXP_WARN_at the|r |cRXP_PICK_Matrix Punchograph 3005-A|r
>>|cRXP_WARN_This quest is completed while OUTSIDE of the dungeon|r
.collect 9280,1,2930,1 
.itemcount 9279,1 
.skipgossip
.isOnQuest 2930
step
.goto 1415,43.17,53.36,40,0
.goto 1415,42.78,53.81
.subzone 721,2 >> Enter the Gnomeregan instance portal
step
#completewith Thermaplugg
>>Kill all |cRXP_ENEMY_Gnomeregan Mobs|r. Loot them for their |cRXP_LOOT_Robo-mechanical Guts|r
.complete 2928,1 
.isOnQuest 2928
step
>>|cRXP_WARN_Use the|r |T133215:0|t[|cRXP_LOOT_Yellow Punch Card|r] |cRXP_WARN_at the|r |cRXP_PICK_Matrix Punchograph 3005-B|r
>>The console looking machine is located at the gnomish safe zone at the bottom floor, next to the big circular room where the slimes are located
.collect 9282,1,2930,1 
.itemcount 9280,1 
.skipgossip
.isOnQuest 2930
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernobee|r
>>|cRXP_WARN_This will start an escort quest. |cRXP_FRIENDLY_Kernobee|r spawns randomly in The Dormitory, right outside of the gnomish safe zone|r
.accept 2904 >> Accept A Fine Mess
.unitscan Kernobee
step
>>Escort |cRXP_FRIENDLY_Kernobee|r back to the start of the dungeon
.complete 2904,1 
.isOnQuest 2904
step
.use 9364 >>|cRXP_WARN_Use the|r |T132788:0|t[Heavy Leaden Collection Phial] |cRXP_WARN_on a |cRXP_ENEMY_Irradiated Slime|r or|r |cRXP_ENEMY_Irradiated Horror|r
>>|cRXP_WARN_The |cRXP_ENEMY_Irradiated Slime|r or |cRXP_ENEMY_Irradiated Horror|r must be ALIVE when you use it|r
>>|cRXP_WARN_Note: You must turn this quest in within 2 hours of acquiring the|r |T136006:0|t[High Potency Radioactive Fallout]
.complete 2962,1 
.mob Irradiated Slime
.mob Irradiated Horror
.isOnQuest 2962
step
#completewith Thermaplugg
>>Open the |cRXP_PICK_Artificial Extrapolators|r. Loot them for |cRXP_LOOT_Essential Artificials|r
.complete 2924,1 
.isOnQuest 2924
step
>>|cRXP_WARN_Use the|r |T133215:0|t[|cRXP_LOOT_Blue Punch Card|r] |cRXP_WARN_at the|r |cRXP_PICK_Matrix Punchograph 3005-C|r
>>The Punchograph is located on the suspended platform right next to the |cRXP_ENEMY_Electrocutioner 6000|r
.collect 9281,1,2930,1 
.itemcount 9282,1 
.skipgossip
.isOnQuest 2930
.unitscan Electrocutioner 6000
step
>>|cRXP_WARN_Use the|r |T133215:0|t[|cRXP_LOOT_Red Punch Card|r] |cRXP_WARN_at the|r |cRXP_PICK_Matrix Punchograph 3005-D|r
.complete 2930,1 
.itemcount 9281,1 
.skipgossip
.isOnQuest 2930
step
#label Thermaplugg
>>Kill |cRXP_ENEMY_Mekgineer Thermaplugg|r
.complete 2929,1 
.isOnQuest 2929
step
#completewith Finished
>>Open the |cRXP_PICK_Artificial Extrapolators|r. Loot them for |cRXP_LOOT_Essential Artificials|r
>>If you still haven't finished this quest, go back to places where you looted them before, since they respawn after a few minutes
.complete 2924,1 
.isOnQuest 2924
step
#completewith Finished
>>Kill all |cRXP_ENEMY_Gnomeregan Mobs|r. Loot them for their |cRXP_LOOT_Robo-mechanical Guts|r
.complete 2928,1 
.isOnQuest 2928
step
>>|cRXP_WARN_Use the|r |T135230:0|t[|cRXP_LOOT_Grime-Encrusted Ring|r] |cRXP_WARN_to start the quest|r
.accept 2945 >> Accept Grime-Encrusted Ring
.collect 9326,1,2945 
.itemcount 9326,1
.use 9326
step
>>|cRXP_WARN_Take the|r |T135230:0|t[|cRXP_LOOT_Grime-Encrusted Ring|r] |cRXP_WARN_to |cRXP_PICK_The Sparklematic 5200|r in The Clean Zone|r
*You will have to back track to The Clean Zone near the instance entrance, make sure your teamates are there to help you on your trip back
.turnin 2945 >> Turn in Grime-Encrusted Ring
.itemcount 9326,1 
step
>>Click the |cRXP_PICK_The Sparklematic 5200|r one more time
.accept 2947 >> Accept Return of the Ring
.isQuestTurnedIn 2945
step
#completewith next
.hs >> Hearth to Kharanos
.zoneskip Dun Morogh
.zoneskip Ironforge
step
.goto Dun Morogh,46.005,48.637,10,0
.goto Dun Morogh,45.887,49.377
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ozzie Togglevolt|r
.turnin 2962 >> Turn in The Only Cure is More Green Glow
.target Ozzie Togglevolt
.isQuestComplete 2962
step
#completewith next
.goto Dun Morogh,47.58,41.58,40,0
.goto Dun Morogh,50.19,40.79,20,0
.goto Ironforge,14.90,87.10,40,0
.zone Ironforge >> Travel to Ironforge
step
.goto Ironforge,36.0,4.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talvash del Kissel|r
.turnin 2947 >> Turn in Return of the Ring
.accept 2948 >> Accept Gnome Improvement
.target Talvash del Kissel
.isOnQuest 2947
step
.goto Ironforge,36.0,4.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talvash del Kissel|r
>>|cRXP_WARN_If you are able to obtain a|r |T133215:0|t[Silver Bar] |cRXP_WARN_and a|r |T134105:0|t[Moss Agate] |cRXP_WARN_finish this quest. If not, abandon it|r
.collect 2842,1,2948,1 
.collect 1206,1 
.turnin 2948,2948,1 >> Turn in Gnome Improvement
.target Talvash del Kissel
.isOnQuest 2948
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkmaster Overspark|r, |cRXP_FRIENDLY_High Tinker Mekkatorque|r, |cRXP_FRIENDLY_Master Mechanic Castpipe|r and |cRXP_FRIENDLY_Klockmort Spannerspan|r
.turnin -2922,1 >> Turn in Save Techbot's Brain!
.target +Tinkmaster Overspark
.goto Ironforge,69.540,50.325
.turnin -2929,1 >> Turn in The Grand Betrayal
.target +High Tinker Mekkatorque
.goto Ironforge,68.743,48.969
.turnin -2930,1 >> Turn in Data Rescue
.target +Master Mechanic Castpipe
.goto Ironforge,69.823,48.101
.turnin -2924,1 >> Turn in Essential Artificials
.target +Klockmort Spannerspan
.goto Ironforge,67.925,46.101
step
#completewith next
.goto Ironforge,76.61,51.28,10,0
.zone Stormwind City >> Take the tram to Stormwind
step
.goto StormwindClassic,55.511,12.502
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shoni the Shilent|r
.turnin 2928 >> Turn in Gyrodrillmatic Excavationators
.target Shoni the Shilent
step
#completewith next
.goto StormwindClassic,66.277,62.137
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Booty Bay>> Fly to Booty Bay
.target Dungar Longdrink
step
.goto Stranglethorn Vale,27.600,77.481
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scooty|r
.turnin 2904 >> Turn in A Fine Mess
.isOnQuest 2904
.target Scooty
step
+|cRXP_WARN_You have completed the Gnomeregan quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 15-30 << !classic
#subgroup 30-50 << classic
<< Alliance
#name 06a. Razorfen Kraul
#displayname 6. Razorfen Kraul
step
#completewith next
.subzone 392 >> Travel to Ratchet in The Barrens
step
.goto The Barrens,62.370,37.615
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mebok Mizzyrix|r
.accept 1221 >> Accept Blueleaf Tubers
.target Mebok Mizzyrix
step
>>Loot the |cRXP_LOOT_Snufflenose Command Stick|r, |cRXP_LOOT_Snufflenose Owner's Manual|r and |cRXP_LOOT_Crate With Holes|r next to |cRXP_FRIENDLY_Mebok|r
.collect 6684,1,1221,1 
.goto The Barrens,62.340,37.607
.collect 5897,1,1221,1 
.goto The Barrens,62.332,37.623
.collect 5880,1,1221,1 
.goto The Barrens,62.323,37.620
step
#completewith CroneKraul
.zone Thousand Needles >> Travel to Thousand Needles
step
.goto Thousand Needles,30.725,24.346
>>Loot |T133741:0|t[|cRXP_LOOT_Henrig Lonebrow's Journal|r] on the ground
.use 5791 >>|cRXP_WARN_Use |T133741:0|t[|cRXP_LOOT_Henrig Lonebrow's Journal|r] to start the quest|r
.accept 1100 >> Accept Lonebrow's Journal
step
#label CroneKraul
.goto Feralas,89.634,46.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Falfindel Waywarder|r
.turnin -1100 >> Turn in Lonebrow's Journal
.accept 1101 >> Accept The Crone of the Kraul
.target Falfindel Waywarder
step
#completewith next
.goto Thousand Needles,10.88,33.24,0
.goto Thousand Needles,11.01,38.31,0
.goto Thousand Needles,13.27,38.47,0
.goto Thousand Needles,17.46,41.62,0
.zone The Barrens >> Grind |cRXP_ENEMY_Highperch Wyverns|r, |cRXP_ENEMY_Highperch Consorts|r and |cRXP_ENEMY_Highperch Patriarchs|r while looking for a group for Razorfen Kraul
.mob Highperch Patriarch
.mob Highperch Wyvern
.mob Highperch Consort
step
.goto The Barrens,43.46,90.18,0
.goto The Barrens,43.46,90.18,40,0
.goto 1414,50.877,70.339
.subzone 491,2 >> Enter Razorfen Kraul
step
>>Kill |cRXP_ENEMY_Charlga Razorflank|r. Loot her for |cRXP_LOOT_Razorflank's Heart|r
.complete 1101,1 
.isOnQuest 1101
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Heralath Fallowbrook|r and |cRXP_FRIENDLY_Willix the Importer|r
.accept 1142 >> Accept Mortality Wanes
.target +Heralath Fallowbrook
.accept 1144 >> Accept Willix the Importer
.target +Willix the Importer
step
#completewith next
>>Kill all |cRXP_ENEMY_Monsters|r inside of RFK. Loot them for |cRXP_LOOT_Treshala's Pendant|r
.complete 1142,1 
.isOnQuest 1142
step
>>Escort |cRXP_FRIENDLY_Willix the Importer|r through Razorfen Krual
>>|cRXP_WARN_Ensure you stay close to |cRXP_FRIENDLY_Willix|r otherwise the quest may not complete!|r
.complete 1144,1 
.isOnQuest 1144
step
#completewith next
>>Kill all |cRXP_ENEMY_Monsters|r inside of RFK. Loot them for |cRXP_LOOT_Treshala's Pendant|r
.complete 1142,1 
.isOnQuest 1142
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Willix the Importer|r
.turnin 1144 >> Turn in Willix the Importer
.target Willix the Importer
.isQuestComplete 1144
step
>>Kill all |cRXP_ENEMY_Monsters|r inside of RFK. Loot them for |cRXP_LOOT_Treshala's Pendant|r
.complete 1142,1 
.isOnQuest 1142
step
#completewity next
.zone Feralas >> Travel to Feralas
step
.goto Feralas,89.634,46.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Falfindel Waywarder|r
.turnin 1101 >> Turn in The Crone of the Kraul
.target Falfindel Waywarder
.isQuestComplete 1101
step
.goto The Barrens,62.370,37.615
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mebok Mizzyrix|r
.turnin 1221 >> Turn in Blueleaf Tubers
.target Mebok Mizzyrix
.isQuestComplete 1221
step
#completewith next
.zone Darnassus >> Travel to Darnassus
>>|cRXP_WARN_Buy a portal from a Mage if possible|r << !Mage
step
.goto Darnassus,62.21,57.23,10,0
.goto Darnassus,66.02,59.39,10,0
.goto Darnassus,69.529,67.759
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Treshala Fallowbrook|r up stairs
.turnin 1142 >> Turn in Mortality Wanes
.target Treshala Fallowbrook
.isQuestComplete 1142
step
+|cRXP_WARN_You have completed the Razorfen Kraul quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 30-50
<< Alliance
#name 07. Scarlet Monastery
#displayname 7. Scarlet Monastery
step
#completewith next
.zone Desolace >> Travel to Desolace
step
.goto Desolace,66.519,7.907
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Anton|r
.accept 261 >> Accept Down the Scarlet Path
.target Brother Anton
step
.goto Desolace,64.30,81.96,70,0
.goto Desolace,64.00,91.70,70,0
.goto Desolace,59.91,89.42,70,0
.goto Desolace,64.00,91.70
>>Kill |cRXP_ENEMY_Undead Ravagers|r
.complete 261,1 
.mob Undead Ravager
.isOnQuest 261
step
.goto Desolace,66.519,7.907
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Anton|r
.turnin 261 >> Turn in Down the Scarlet Path
.accept 1052 >> Accept Down the Scarlet Path
.target Brother Anton
step
#completewith next
.zone Ironforge >> Travel to Ironforge
step
.goto Ironforge,74.980,12.486
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Librarian Mae Paledust|r
.accept 1050 >> Accept Mythology of the Titans
.target Librarian Mae Paledust
step
#completewith next
.zone Hillsbrad Foothills >> Travel to Southshore
step
.goto Hillsbrad Foothills,51.468,58.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raleigh the Devout|r up stairs
.turnin 1052 >> Turn in Down the Scarlet Path
.accept 1053 >> Accept In the Name of the Light
.target Raleigh the Devout
step
#completewith next
.goto Alterac Mountains,58.31,67.92,0
.goto Alterac Mountains,48.0,82.0,0
.zone Silverpine Forest >> Grind the |cRXP_ENEMY_Syndicate|r in Alterac Mountains while looking for a group for Scarlet Monastery
.zoneskip Tirisfal Glades
.mob Syndicate Footpad
.mob Syndicate Thief
step
.goto Silverpine Forest,69.95,7.05,150,0
.goto Tirisfal Glades,56.15,64.62,100,0
.goto 1415,47.500,19.652,25,0
.goto 1415,47.792,19.611
.subzone 796,2 >> Enter Scarlet Monastery. Start with Library so you can loot the [|cRXP_FRIENDLY_The Scarlet Key|r] at the end
step
#completewith Bosses
>>Loot the |cRXP_LOOT_Mythology of the Titans|r
>>|cRXP_WARN_This can spawn randomly on the ground or in bookshelves throughout the Library wing|r
.complete 1050,1 
.isOnQuest 1050
step
#completewith Mythology
>>Open |cRXP_PICK_Doan's Strongbox|r. Loot it for [|cRXP_FRIENDLY_The Scarlet Key|r]
.collect 7146,1 
step
#label Bosses
>>Kill |cRXP_ENEMY_Houndmaster Loksey|r, |cRXP_ENEMY_Herod|r, |cRXP_ENEMY_High Inquisitor Whitemane|r and |cRXP_ENEMY_Scarlet Commander Mograine|r
>>|cRXP_ENEMY_Houndmaster Loksey|r |cRXP_WARN_is located in the Library|r
>>|cRXP_ENEMY_Herod|r |cRXP_WARN_is located in the Armory|r
>>|cRXP_ENEMY_High Inquisitor Whitemane|r |cRXP_WARN_and |cRXP_ENEMY_Scarlet Commander Mograine|r are located in the Cathedral|r
.complete 1053,4 
.complete 1053,3 
.complete 1053,1 
.complete 1053,2 
.isOnQuest 1053
step
#label Mythology
>>Loot the |cRXP_LOOT_Mythology of the Titans|r
>>|cRXP_WARN_This can spawn randomly on the ground or in bookshelves throughout the Library wing|r
.complete 1050,1 
.isOnQuest 1050
step
#completewith next
.hs >> Hearth to Southshore
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
step
.goto Hillsbrad Foothills,51.468,58.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raleigh the Devout|r up stairs
.turnin 1053 >> Turn in In the Name of the Light
.target Raleigh the Devout
.isQuestComplete 1053
step
#completewith next
.goto Hillsbrad Foothills,49.338,52.272
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darla Harris|r
.fly Ironforge>> Fly to Ironforge
.target Darla Harris
.zoneskip Ironforge
step
.goto Ironforge,74.980,12.486
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Librarian Mae Paledust|r
.turnin 1050 >> Turn in Mythology of the Titans
.target Librarian Mae Paledust
.isQuestComplete 1050
step
+|cRXP_WARN_You have completed the Scarlet Monastery quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 30-50
<< Alliance
#name 08. Razorfen Downs
#displayname 8. Razorfen Downs
step
#completewith HostEvil
.subzone 722 >> You will now run Razorfen Downs. Start looking for a group for it while you travel to the dungeon
step
#completewith next
.zone Stormwind City >> Travel to Stormwind City
step
.goto StormwindClassic,39.592,27.199
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archbishop Benedictus|r
.accept 3636 >> Accept Bring the Light
.target Archbishop Benedictus
step
#completewith next
.zone The Barrens >> Travel to The Barrens
step
#label HostEvil
.goto The Barrens,49.012,94.938
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Myriam Moonsinger|r
.accept 6626 >> Accept A Host of Evil
.target Myriam Moonsinger
step
>>Kill |cRXP_ENEMY_Razorfen Battleguards|r, |cRXP_ENEMY_Razorfen Thornweavers|r and |cRXP_ENEMY_Death's Head Cultists|r
>>|cRXP_WARN_This quest is completed outside of the Instance|r
.goto The Barrens,48.23,92.31,70,0
.goto The Barrens,48.15,90.57,70,0
.goto The Barrens,47.86,88.75,70,0
.goto The Barrens,46.46,90.19,70,0
.goto The Barrens,46.94,92.19,70,0
.goto The Barrens,48.23,92.31,70,0
.goto The Barrens,48.15,90.57,70,0
.goto The Barrens,47.86,88.75,70,0
.goto The Barrens,46.46,90.19,70,0
.goto The Barrens,46.94,92.19,70,0
.goto The Barrens,48.23,92.31
.complete 6626,1 
.mob +Razorfen Battleguard
.complete 6626,2 
.mob +Razorfen Thornweaver
.complete 6626,3 
.mob +Death's Head Cultist
.isOnQuest 6626
step
.goto The Barrens,49.012,94.938
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Myriam Moonsinger|r
.turnin 6626 >> Turn in A Host of Evil
.target Myriam Moonsinger
.isQuestComplete 6626
step
.goto The Barrens,49.255,93.077,0
.goto The Barrens,49.255,93.077,30,0
.goto 1414,53.26,71.18
.subzone 722,2 >> Enter Razorfen Downs
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belnistrasz|r
>>|cRXP_WARN_Take the left path and stick left the entire way until you reach The Murder Pens to get to|r |cRXP_FRIENDLY_Belnistrasz|r
>>|cRXP_WARN_Do not accept Extinguishing the Idol until the rest of your party is ready as this begins the escort. Auto accept has been turned off for this step|r
.accept 3523 >> Accept Scourge of the Downs
.turnin 3523 >> Turn in Scourge of the Downs
.accept 3525,1 >> Accept Extinguishing the Idol
.target Belnistrasz
step
>>Follow and protect |cRXP_FRIENDLY_Belnistrasz|r during his ritual
.complete 3525,1 
.target Belnistrasz
.isOnQuest 3525
step
>>Click |cRXP_PICK_Belnistrasz's Brazier|r
.turnin 3525 >> Turn in Extinguishing the Idol
.isQuestComplete 3525
step
>>Kill |cRXP_ENEMY_Amnennar the Coldbringer|r
.complete 3636,1 
.isOnQuest 3636
step
#completewith next
.zone Stormwind City >> Travel to Stormwind City
step
.goto StormwindClassic,39.592,27.199
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archbishop Benedictus|r
.turnin 3636 >> Turn in Bring the Light
.target Archbishop Benedictus
.isQuestComplete 3636
step
+|cRXP_WARN_You have completed the Razorfen Downs quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 30-50
<< Alliance
#name 09. Uldaman
#displayname 9. Uldaman
step
#completewith IFQuests
.zone Ironforge >> Travel to Ironforge
step
.goto Ironforge,74.179,9.371
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krom Stoutarm|r
.accept 1360 >> Accept Reclaimed Treasures
.target Krom Stoutarm
step
#label IFQuests
.goto Ironforge,74.645,11.742
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Stormpike|r
.accept 2398 >> Accept The Lost Dwarves
.accept 707 >> Accept Ironband Wants You!
.target Prospector Stormpike
step
#completewith LochQuests
.goto Ironforge,55.501,47.742
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
.fly Loch Modan>> Fly to Loch Modan
.target Gryth Thurden
.zoneskip Loch Modan
.zoneskip Badlands
step
.goto Loch Modan,36.50,48.35,15,0
.goto Loch Modan,37.067,49.379
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghak Healtouch|r
.accept 17 >> Accept Uldaman Reagent Run
.target Ghak Healtouch
.isQuestTurnedIn 2500
step
#optional
.goto Loch Modan,36.50,48.35,15,0
.goto Loch Modan,37.067,49.379
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghak Healtouch|r
>>|cRXP_WARN_This quest is a prerequisite that requires killing mobs in Badlands for a follow up quest in Uldaman. If you wish to not complete it, skip this step|r
.accept 2500 >> Accept Badlands Reagent Run
.target Ghak Healtouch
step
#completewith next
.goto Loch Modan,65.93,65.62,80 >> Travel to Ironband's Excavation Site
step
.goto Loch Modan,65.934,65.622
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ironband|r
.turnin 707 >> Turn in Ironband Wants You!
.target Prospector Ironband
.accept 738 >> Accept Find Agmond
step
#completewith EnterBandlands
.goto Loch Modan,47.04,79.27,0
.goto Loch Modan,46.71,76.90,65,0
.goto Badlands,49.23,7.80
.zone Badlands >> Travel to Badlands
step
.goto Badlands,53.027,33.944
>>Click the |cRXP_PICK_Crumpled Map|r on the ground
.accept 720 >> Accept A Sign of Hope
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ryedol|r
.turnin 720 >> Turn in A Sign of Hope
.accept 721 >> Accept A Sign of Hope
.goto Badlands,53.421,43.393
.target Prospector Ryedol
step
#label Agmond
.goto Badlands,50.892,62.402
>>Click the |cRXP_PICK_Battered Dwarven Skeleton|r
.turnin 738 >> Turn in Find Agmond
.accept 739 >> Accept Murdaloc
step
>>Kill |cRXP_ENEMY_Stonevault Bonesnappers|r and |cRXP_ENEMY_Murdaloc|r
.complete 739,2 
.mob +Stonevault Bonesnapper
.goto Badlands,53.0,72.2,40,0
.goto Badlands,47.2,70.6,40,0
.goto Badlands,52.4,66.2,40,0
.goto Badlands,50.36,69.12
.complete 739,1 
.mob +Murdaloc
.goto Badlands,49.58,66.66
step
.goto Badlands,51.386,76.874
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin the Lost|r
.accept 709 >> Accept Solution to Doom
.target Theldurin the Lost
step
.goto Badlands,42.388,52.927
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r
>>|cRXP_WARN_Skip this quest if you are level 44 or above. It has a very low drop rate and diminished XP|r
.accept 2418 >> Accept Power Stones
.target Rigglefuzz
step
#optional
.isOnQuest 2500
>>Kill |cRXP_ENEMY_Buzzards|r. Loot them for their |cRXP_LOOT_Gizzards|r
>>Kill |cRXP_ENEMY_Coyotes|r. Loot them for their |cRXP_LOOT_Fangs|r
>>Kill |cRXP_ENEMY_Lesser Rock Elementals|r. Loot them for their |cRXP_LOOT_Rock Elemental Shards|r
>>|cRXP_WARN_This quest is a prerequisite for a follow up quest in Uldaman. If you wish to not complete it, skip this step|r
.complete 2500,1 
.mob +Starving Buzzard
.mob +Buzzard
.mob +Giant Buzzard
.goto Badlands,49.8,53.0,80,0
.goto Badlands,56.2,67.2,80,0
.goto Badlands,50.6,74.8,80,0
.goto Badlands,60.0,70.6,80,0
.goto Badlands,60.8,53.4,80,0
.goto Badlands,55.8,60.2
.complete 2500,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.goto Badlands,49.0,32.4,80,0
.goto Badlands,49.2,48.8,80,0
.goto Badlands,57.8,47.7,80,0
.goto Badlands,56.6,73.8,80,0
.goto Badlands,58.8,54.0
.complete 2500,3 
.goto Badlands,21.2,45.8,60,0
.goto Badlands,18.0,42.8,60,0
.goto Badlands,13.8,38.6,60,0
.goto Badlands,21.2,45.8,60,0
.goto Badlands,18.0,42.8
.mob +Lesser Rock Elemental
step
#optional
#completewith Murdaloc
.zone Loch Modan >> Return to Loch Modan
step
#optional
.isQuestComplete 2500
.goto Loch Modan,36.50,48.35,15,0
.goto Loch Modan,37.067,49.379
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghak Healtouch|r
.turnin 2500 >> Turn in Badlands Reagent Run
.accept 17 >> Accept Uldaman Reagent Run
.target Ghak Healtouch
.isQuestComplete 2500
step
#optional
.goto Loch Modan,36.50,48.35,15,0
.goto Loch Modan,37.067,49.379
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghak Healtouch|r
.accept 17 >> Accept Uldaman Reagent Run
.target Ghak Healtouch
.isQuestTurnedIn 2500
step
#label Murdaloc
.goto Loch Modan,65.934,65.622
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ironband|r
.turnin 739 >> Turn in Murdaloc
.accept 704 >> Accept Agmond's Fate
.target Prospector Ironband
step
.goto Badlands,4.0,80.6
.goto Badlands,15.4,88.6
.goto Badlands,11.0,88.0
.goto Badlands,44.70,12.09
.zone 1415 >> Grind |cRXP_ENEMY_Ogres|r and |cRXP_ENEMY_Greater Rock Elementals|r while looking for a group for Uldaman
>>|cRXP_WARN_Once you have found a group, skip this step|r
step
#completewith HammertoeGrez
.goto 1415,54.46,57.78
.zone 1415 >> Travel to Uldaman
step
#completewith HammertoeGrez
>>Loot the |cRXP_LOOT_Carved Stone Urns|r on the ground
>>|cRXP_WARN_This can be only be completed OUTSIDE of Uldaman|r
.complete 704,1 
.isOnQuest 704
step
#completewith HammertoeGrez
>>Loot the |cRXP_LOOT_Magenta Fungus Caps|r on the ground
>>|cRXP_WARN_This can be completed INSIDE and OUTSIDE of Uldaman|r
.complete 17,1 
.isOnQuest 17
step
#completewith UldaEnd
.isOnQuest 2418
>>Kill |cRXP_ENEMY_Dwarves|r. Loot them for their |cRXP_LOOT_Power Stones|r
>>|cRXP_WARN_This can be completed INSIDE and OUTSIDE of Uldaman|r
.complete 2418,1 
.complete 2418,2 
step
.goto 1415,54.040,57.665
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hammertoe Grez|r
.turnin 721 >> Turn in A Sign of Hope
.accept 722 >> Accept Amulet of Secrets
.target Hammertoe Grez
step
.goto 1415,54.12,58.05,30,0
.goto 1415,54.09,58.21
>>Kill |cRXP_ENEMY_Magregan Deepshadow|r. Loot him for |cRXP_LOOT_Hammertoe's Amulet|r
>>|cRXP_WARN_This is completed OUTSIDE of Uldaman|r
.complete 722,1 
.mob Magregan Deepshadow
.isOnQuest 722
step
.goto 1415,54.140,58.246
>>Open the |cRXP_PICK_Ancient Chest|r. Loot it for the |cRXP_LOOT_Tablet of Ryun'eh|r
>>|cRXP_WARN_This is completed OUTSIDE of Uldaman|r
.complete 709,1 
.isOnQuest 709
step
.goto 1415,53.874,58.577
>>Loot |cRXP_LOOT_Krom Stoutarm's Treasure|r on the ground
>>|cRXP_WARN_This is completed OUTSIDE of Uldaman|r
.complete 1360,1 
.isOnQuest 1360
step
#label HammertoeGrez
.goto 1415,54.040,57.665
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hammertoe Grez|r
.turnin 722 >> Turn in Amulet of Secrets
.accept 723 >> Accept Prospect of Faith
.target Hammertoe Grez
.isQuestTurnedIn 721
step
.goto 1415,53.85,57.81,55,0
.goto 1415,53.63,58.01,55,0
.goto 1415,54.09,58.03,55,0
.goto 1415,53.85,57.81
>>Loot the |cRXP_LOOT_Carved Stone Urns|r and |cRXP_LOOT_Magenta Fungus Caps|r on the ground
>>|cRXP_WARN_Prioritize the |cRXP_LOOT_Carved Stone Urns|r. This can only be completed OUTSIDE of Uldaman. You can finish the |cRXP_LOOT_Magenta Fungus Caps|r once inside|r
.complete 704,1 
.complete 17,1 
.disablecheckbox
.isOnQuest 704
.isOnQuest 17
step
.goto 1415,53.85,57.81,55,0
.goto 1415,53.63,58.01,55,0
.goto 1415,54.09,58.03,55,0
.goto 1415,53.85,57.81
>>Loot the |cRXP_LOOT_Carved Stone Urns|r on the ground
>>|cRXP_WARN_This can be only be completed OUTSIDE of Uldaman|r
.complete 704,1 
.isOnQuest 704
step
.goto 1415,53.850,57.641
.subzone 1337,2 >> Zone into Uldaman
step
#completewith HiddenChamber
>>Loot the |cRXP_LOOT_Magenta Fungus Caps|r on the ground
.complete 17,1 
.isOnQuest 17
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelog|r
.turnin 2398 >> Turn in The Lost Dwarves
.accept 2240 >> Accept The Hidden Chamber
.target Baelog
.isOnQuest 2398
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baelog|r
.accept 2240 >> Accept The Hidden Chamber
.target Baelog
step
#completewith next
>>Open |cRXP_PICK_Baelog's Chest|r. Loot it for the |T133276:0|t[|cRXP_LOOT_Gni'kiv Medallion|r]
>>Kill |cRXP_ENEMY_Revelosh|r. Loot him for |T135225:0|t[|cRXP_LOOT_The Shaft of Tsol|r]
>>|cRXP_WARN_Note other party members can loot these items, and then combine them to create the|r |T135138:0|t[Staff of Prehistoria]|cRXP_WARN_. Only one person in the group needs to do this|r
.collect 7740,1,2240,1 
.collect 7741,1,2240,1 
.use 7740 
.use 7741 
.mob Revelosh
.isOnQuest 2240
step
#label HiddenChamber
>>|cRXP_WARN_Use the|r |T133276:0|t[|cRXP_LOOT_Gni'kiv Medallion|r] |cRXP_WARN_and|r |T135225:0|t[|cRXP_LOOT_The Shaft of Tsol|r] |cRXP_WARN_to combine them into the|r |T135138:0|t[Staff of Prehistoria]
>>|cRXP_WARN_Use the|r |T135138:0|t[Staff of Prehistoria] |cRXP_WARN_on the |cRXP_PICK_Keystone|r to summon|r |cRXP_ENEMY_Ironaya|r
>>Kill |cRXP_ENEMY_Ironaya|r. |cRXP_WARN_Run into the Hidden Chamber she came from after|r
.use 7740 
.use 7741 
.use 7733 
.complete 2240,1 
.isOnQuest 2240
step
>>Loot the |cRXP_LOOT_Magenta Fungus Caps|r on the ground
.complete 17,1 
.isOnQuest 17
step
>>Kill |cRXP_ENEMY_Archaedas|r
>>Click |cRXP_PICK_The Discs of Norgannon|r
.accept 2278 >> Accept The Platinum Discs
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lore Keeper of Norgannon|r
.complete 2278,1 
.skipgossip
.target Lore Keeper of Norgannon
step
#label UldaEnd
>>Click |cRXP_PICK_The Discs of Norgannon|r
.turnin 2278 >> Turn in The Platinum Discs
.accept 2279 >> Accept The Platinum Discs
step
+Zone out of Uldaman together as a group to turn in quests in Badlands. The closest exit is the Uldaman backdoor
.zoneskip Badlands
step
.goto Badlands,51.386,76.874
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin the Lost|r
.turnin 709 >> Turn in Solution to Doom
.target Theldurin the Lost
.isQuestComplete 709
step
.isQuestComplete 2418
.goto Badlands,42.388,52.927
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r
>>|cRXP_WARN_Skip this quest if you are level 44 or above. It has a very low drop rate and diminished XP|r
.turnin 2418 >> Turn in Power Stones
.target Rigglefuzz
step
#optional
.abandon 2418 >> Abandon Power Stones if you did not complete it or if you don't plan on running Uldaman again
step
#label HammertoeGrez
.goto Badlands,53.421,43.393
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ryedol|r
.turnin 723 >> Turn in Prospect of Faith
.accept 724 >> Accept Prospect of Faith
.target Prospector Ryedol
.isQuestTurnedIn 721
step
#completewith UldaLoch
.goto Badlands,49.52,9.83,0
.goto Loch Modan,46.78,78.09
.zone Loch Modan >> Travel to Loch Modan
step
.goto Loch Modan,65.93,65.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ironband|r
.turnin 704 >> Turn in Agmond's Fate
.target Prospector Ironband
.isQuestComplete 704
step
.goto Loch Modan,36.50,48.35,15,0
.goto Loch Modan,37.067,49.379
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghak Healtouch|r
.turnin 17 >> Turn in Uldaman Reagent Run
.target Ghak Healtouch
.isQuestComplete 17
step
#label UldaLoch
.goto Loch Modan,33.938,50.954
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thorgrum Borrelson|r
.fly Ironforge >> Fly to Ironforge
.target Thorgrum Borrelson
step
.goto Ironforge,69.930,18.548
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Explorer Magellas|r
.turnin 2279 >> Turn in The Platinum Discs
.accept 2439 >> Accept The Platinum Discs
.target High Explorer Magellas
.isQuestTurnedIn 2278
step
.goto Ironforge,74.645,11.742
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Stormpike|r
.turnin 2240 >> Turn in The Hidden Chamber
.target Prospector Stormpike
.isQuestComplete 2240
step
.goto Ironforge,74.179,9.371
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krom Stoutarm|r
.turnin 1360 >> Turn in Reclaimed Treasures
.target Krom Stoutarm
.isQuestComplete 1360
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Historian Karnik|r and |cRXP_FRIENDLY_Advisor Belgrum|r
.turnin 724 >> Turn in Prospect of Faith
.accept 725 >> Accept Passing Word of a Threat
.target +Historian Karnik
.goto Ironforge,77.539,11.834
.turnin 725 >> Turn in Passing Word of a Threat
.accept 726 >> Accept Passing Word of a Threat
.target +Advisor Belgrum
.goto Ironforge,77.343,9.714
.turnin 726 >> Turn in Passing Word of a Threat
.target +Historian Karnik
.goto Ironforge,77.539,11.834
.isQuestTurnedIn 721
step
.goto Ironforge,33.874,59.136
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dinita Stonemantle|r
.turnin 2439 >> Turn in The Platinum Discs
.target Dinita Stonemantle
.isQuestTurnedIn 2278
step
>>|cRXP_WARN_Use the |T133289:0|t[|cRXP_LOOT_Shattered Necklace|r] to start the quest|r
.accept 2198 >> Accept The Shattered Necklace
.use 7666 
.itemcount 7666,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talvash del Kissel|r
.goto Ironforge,36.377,3.614
.turnin 2198 >> Turn in The Shattered Necklace
.target Talvash del Kissel
.isOnQuest 2198
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talvash del Kissel|r
.goto Ironforge,36.377,3.614
.accept 2199 >> Accept Lore for a Price
.target Talvash del Kissel
.isQuestTurnedIn 2198
step
.goto Ironforge,36.377,3.614
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talvash del Kissel|r
>>Bring 5 |T133215:0|t[Silver Bars] to |cRXP_FRIENDLY_Talvash del Kissel|r
>>|cRXP_WARN_If you are unable to acquire them, abandon this quest|r
.complete 2199,1 
.turnin 2199 >> Turn in Lore for a Price
.target Talvash del Kissel
.isOnQuest 2199
step
+|cRXP_WARN_You have completed the Uldaman quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 30-50
<< Alliance
#name 10. Zul'Farrak
step
#completewith next
.zone The Hinterlands >> Travel to The Hinterlands
step
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.accept 2988 >> Accept Witherbark Cages
.target Gryphon Master Talonaxe
step
.goto The Hinterlands,31.98,57.31
>>Click the |cRXP_PICK_Third Witherbark Cage|r
.complete 2988,3 
step
#label FinalCages
>>Click the |cRXP_PICK_First Witherbark Cage|r and |cRXP_PICK_Second Witherbark Cage|r
.complete 2988,1 
.goto The Hinterlands,23.28,58.81
.complete 2988,2 
.goto The Hinterlands,23.12,58.82
step
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.turnin 2988 >> Turn in Witherbark Cages
.accept 2989 >> Accept The Altar of Zul
.target Gryphon Master Talonaxe
step
.goto The Hinterlands,48.64,68.24
>>Kill |cRXP_ENEMY_Qiaga the Keeper|r. Loot her for the |T133056:0|t[|cRXP_LOOT_Sacred Mallet|r]
>>|cRXP_ENEMY_Qiaga the Keeper|r |cRXP_WARN_is a level 50 elite. Make sure you bring a group|r << !tbc !wotlk
>>|cRXP_WARN_Skip this step if you do not wish to do it or if somebody else in your group already has the|r |T133056:0|t[|cRXP_FRIENDLY_Mallet of Zul'Farrak|r]
.collect 9241,1 
.itemcount 9240,<1
step
#completewith next
.subzone 354 >>Travel to |cFFfa9602Jintha'Alor|r
step
.goto The Hinterlands,59.70,77.81
.use 9241 >>Use the |T133056:0|t[|cRXP_LOOT_Sacred Mallet|r] at the altar in front of the cave to create the |T133056:0|t[|cRXP_FRIENDLY_Mallet of Zul'Farrak|r]
>>|cRXP_WARN_You will need to bypass a lot of level 46-50 elites. Make sure you bring a group|r << !tbc !wotlk
.collect 9240,1 
.itemcount 9241,1
step
.goto The Hinterlands,48.814,68.387
>>|cRXP_WARN_Clear your way to the top of The Altar of Zul. Ensure you are on full HP before you reach the top!|r
>>|cRXP_WARN_Run to the exploration location, then jump off to the side to evade the Elites at the top. Wait on the ledge until you have dropped Combat. Watch the video below for an example|r
.complete 2989,1 
.link https://youtu.be/Z4gDpWTXaFY >> |cRXP_WARN_Click here for video reference|r
step
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.turnin 2989 >> Turn in The Altar of Zul
.accept 2990 >> Accept Thadius Grimshade
.target Gryphon Master Talonaxe
step
#completewith next
.zone Blasted Lands >> Travel to Blasted Lands
step
.isQuestTurnedIn 2990
.goto Blasted Lands,66.898,19.469
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thadius Grimshade|r atop the Tower
.turnin 2990 >> Turn in Thadius Grimshade
.accept 2991 >> Accept Nekrum's Medallion
.target Thadius Grimshade
step
#completewith next
.subzone 977 >>Travel to |cFFfa9602Steamwheedle Port|r in Tanaris
step
.goto Tanaris,67.00,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
>>|cRXP_WARN_This is a prerequisite quest for Zul'Farrak|r
.accept 3520 >> Accept Screecher Spirits
.target Yeh'kinya
step
#completewith next
.zone Feralas >>Travel to |cFFfa9602Feralas|r
step
#loop
.goto Feralas,58.39,51.88,0
.goto Feralas,57.54,48.70,0
.goto Feralas,55.74,46.71,0
.goto Feralas,58.45,55.83,0
.goto Feralas,58.39,51.88,80,0
.goto Feralas,57.54,48.70,80,0
.goto Feralas,55.74,46.71,80,0
.goto Feralas,58.45,55.83,80,0
.goto Feralas,56.70,56.13,80,0
.use 10699 >>Kill |cRXP_ENEMY_Vale Screechers|r
>>|cRXP_WARN_Use|r |T135474:0|t[Yeh'kinya's Bramble] |cRXP_WARN_on their corpses. Talk to the|r |cRXP_FRIENDLY_Screecher Spirit|r |cRXP_WARN_that appears|r
.complete 3520,1 
.unitscan Rogue Vale Screecher
.unitscan Vale Screecher
.target Screecher Spirit
.isOnQuest 3520
step
#completewith next
.zone Dustwallow Marsh >>Travel to |cFFfa9602Dustwallow Marsh|r
step
.goto Dustwallow Marsh,46.021,57.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r
.accept 2846 >> Accept Tiara of the Deep
.target Tabetha
step
#completewith Prophecyt
.subzone 977 >>Travel to |cFFfa9602Steamwheedle Port|r in Tanaris
step
.goto Tanaris,67.00,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3520 >>Turn in Screecher Spirits
.target Yeh'kinya
.isQuestComplete 3520
step
#label Prophecy
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r again
.accept 3527 >> Accept The Prophecy of Mosh'aru
.target Yeh'kinya
.isQuestTurnedIn 3520
step
.goto Tanaris,51.413,28.752
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trenton Lighthammer|r
.accept 3042 >> Accept Troll Temper
.target Trenton Lighthammer
step
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.accept 2768 >> Accept Divino-matic Rod
.target Chief Engineer Bilgewhizzle
step
.goto Tanaris,51.566,26.759
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.accept 2865 >> Accept Scarab Shells
.target Tran'rek
step
#completewith next
.goto Thousand Needles,70.58,62.69,200 >>Travel to the |cFFfa9602Shimmering Flats|r
step
#label ZFPickups
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.accept 2770 >> Accept Gahz'rilla
.target Wizzle Brassbolts
step
.goto Tanaris,73.37,47.14
.goto Tanaris,38.731,19.839
.subzone 978 >> You will now run Zul'Farrak. Grind on |cRXP_ENEMY_Pirates|r while looking for a ZF group
>>Skip this step once you have found a group
step
.goto Tanaris,38.91,20.78,40,0
.goto Tanaris,38.731,19.839
.subzone 978,2 >> Enter Zul'Farrak
step
#completewith Gahzrilla
>>Kill |cRXP_ENEMY_Trolls|r. Loot them for their |cRXP_LOOT_Troll Temper|r
.complete 3042,1 
.isOnQuest 3042
step
#completewith next
>>Kill |cRXP_ENEMY_Scarabs|r. Loot them for their |cRXP_LOOT_Uncracked Scarab Shell|r
.complete 2865,1 
.isOnQuest 2865
step
#optional
>>Kill |cRXP_ENEMY_Theka the Martyr|r. Loot him for the |cRXP_LOOT_First Mosh'aru Tablet|r
.complete 3527,1 
.mob Theka the Martyr
.isOnQuest 3527
step
>>Kill |cRXP_ENEMY_Scarabs|r. Loot them for their |cRXP_LOOT_Uncracked Scarab Shell|r
.complete 2865,1 
.isOnQuest 2865
step
#completewith NekrumMedallion
+Ascend the Pyramid
>>Kill the |cRXP_ENEMY_Sandfury Executioner|r. Loot him for the |cRXP_LOOT_Executioner's Key|r
>>|cRXP_WARN_Anyone in the party may loot the|r |cRXP_LOOT_Key|r
>>|cRXP_WARN_Use the|r |cRXP_LOOT_Executioner's Key|r |cRXP_WARN_on one of the |cRXP_PICK_Troll Cages|r to free |cRXP_FRIENDLY_Sergeant Bly|r and his band|r
.collect 8444,1 
.disablecheckbox
.isOnQuest 2991,2768
.mob Sandfury Executioner
step
>>Defend |cRXP_FRIENDLY_Sergeant Bly|r and his band, then move down with them after a short period of time
>>Kill |cRXP_ENEMY_Nekrum Gutchewer|r. Loot him for |cRXP_LOOT_Nekrum's Medallion|r
>>After you kill |cRXP_ENEMY_Nekrum Gutchewer|r, eat and drink then talk to |cRXP_FRIENDLY_Sergeant Bly|r to fight him
>>Kill |cRXP_ENEMY_Sergeant Bly|r. Loot him for the |cRXP_LOOT_Divino-matic Rod|r
.complete 2991,1 
.complete 2768,1 
.isOnQuest 2991
.isOnQuest 2768
.skipgossip
step
>>Defend |cRXP_FRIENDLY_Sergeant Bly|r and his band, then move down with them after a short period of time
>>Kill |cRXP_ENEMY_Nekrum Gutchewer|r. Loot him for |cRXP_LOOT_Nekrum's Medallion|r
.complete 2991,1 
.isOnQuest 2991
.skipgossip
step
#label NekrumMedallion
>>Defend |cRXP_FRIENDLY_Sergeant Bly|r and his band, then move down with them after a short period of time
>>Kill |cRXP_ENEMY_Nekrum Gutchewer|r. Eat and drink then talk to |cRXP_FRIENDLY_Sergeant Bly|r to fight him
>>Kill |cRXP_ENEMY_Sergeant Bly|r. Loot him for the |cRXP_LOOT_Divino-matic Rod|r
.complete 2768,1 
.isOnQuest 2768
.skipgossip
step
#optional
>>Kill |cRXP_ENEMY_Hydromancer Velratha|r. Loot her for the |cRXP_LOOT_Tiara of the Deep|r and the |cRXP_LOOT_Second Mosh'aru Tablet|r
.complete 2846,1 
.complete 3527,2 
.mob Hydromancer Velratha
.isOnQuest 2846
.isOnQuest 3527
step
#optional
>>Kill |cRXP_ENEMY_Hydromancer Velratha|r. Loot her for the |cRXP_LOOT_Tiara of the Deep|r
.complete 2846,1 
.mob Hydromancer Velratha
.isOnQuest 2846
step
#optional
>>Kill |cRXP_ENEMY_Hydromancer Velratha|r. Loot her for the |cRXP_LOOT_Second Mosh'aru Tablet|r
.complete 3527,2 
.mob Hydromancer Velratha
.isOnQuest 3527
step
#label Gahzrilla
>>|cRXP_WARN_Use the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_on the |cRXP_PICK_Gong of Zul'Farrak|r to summon|r |cRXP_ENEMY_Gahz'rilla|r
>>Kill |cRXP_ENEMY_Gahz'rilla|r. Loot him for |cRXP_LOOT_Gahz'rilla's Electrified Scale|r
>>|cRXP_WARN_If no one in your party has the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_you will not be able to summon|r |cRXP_ENEMY_Gahz'rilla|r
.complete 2770,1 
.mob Gahz'rilla
.isOnQuest 2770
step
>>Kill |cRXP_ENEMY_Trolls|r. Loot them for their |cRXP_LOOT_Troll Temper|r
.complete 3042,1 
.isOnQuest 3042
step
#completewith TanarisTurnins
.zone Tanaris >>Leave Zul'Farrak
step
.goto Tanaris,51.413,28.752
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trenton Lighthammer|r
.turnin 3042 >> Turn in Troll Temper
.target Trenton Lighthammer
.isQuestComplete 3042
step
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.turnin 2768 >> Turn in Divino-matic Rod
.target Chief Engineer Bilgewhizzle
.isQuestComplete 2768
step
.goto Tanaris,51.566,26.759
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.turnin 2865 >> Turn in Scarab Shells
.target Tran'rek
.isQuestComplete 2865
step
#completewith next
.goto Tanaris,66.989,22.354,100 >> Travel to |cFFfa9602Steamwheedle Port|r
step
#label TanarisTurnins
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3527 >> Turn in The Prophecy of Mosh'aru
.target Yeh'kinya
.isQuestComplete 3527
step
#completewith next
.goto Thousand Needles,70.58,62.69,200 >>Travel to the |cFFfa9602Shimmering Flats|r
step
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.turnin 2770 >> Turn in Gahz'rilla
.target Wizzle Brassbolts
.isQuestComplete 2770
step
#completewith next
.zone Dustwallow Marsh >>Travel to |cFFfa9602Dustwallow Marsh|r
step
.goto Dustwallow Marsh,46.021,57.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r
.turnin 2846 >> Turn in Tiara of the Deep
.target Tabetha
.isQuestComplete 2846
step
#completewith next
.zone Blasted Lands >> Travel to Blasted Lands
step
.isQuestTurnedIn 2990
.goto Blasted Lands,66.898,19.469
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thadius Grimshade|r atop the Tower
.turnin 2991 >> Turn in Nekrum's Medallion
.accept 2992 >> Accept The Divination
.turnin 2992 >> Turn in The Divination
.accept 2993 >> Accept Return to the Hinterlands
.target Thadius Grimshade
step
+|cRXP_WARN_You have completed the Zul'Farrak quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 30-50
<< Alliance
#name 11. Maraudon
step
#completewith StartMara
+Start looking for a group for Maraudon while you accept the quests
step
#completewith next
.subzone 513 >> Travel to Theramore Isle in Dustwallow Marsh
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Tervosh|r atop Theramore tower
.goto Dustwallow Marsh,66.423,49.260
.accept 7070 >> Accept Shadowshard Fragments
.target Archmage Tervosh
step
#completewith VyletongueCorruption
.subzone 608 >> Travel to Nijel's Point in Desolace
step
.goto Desolace,64.64,9.25,15,0
.goto Desolace,63.827,10.669
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Marandis|r
.accept 7065 >> Accept Corruption of Earth and Seed
.target Keeper Marandis
step
#label VyletongueCorruption
.goto Desolace,68.501,8.880
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talendria|r
.accept 7041 >> Accept Vyletongue Corruption
.target Keeper Marandis
step
.goto Desolace,66.275,6.554
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Lyshaerya|r
>>|cRXP_WARN_This is so you can Hearth after completing the dungeon|r
.home >> Set your Hearthstone to Desolace
.target Innkeeper Lyshaerya
step
#completewith PariahInstructions
.zone Desolace >> Travel to Desolace
step
.goto Desolace,62.194,39.624
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Willow|r
.accept 7028 >> Accept Twisted Evils
.target Willow
step
#label PariahInstructions
.line Desolace,50.48,86.66,50.39,86.61,50.18,87.01,49.89,87.11,48.95,87.04,48.73,87.11,48.25,87.14,47.82,87.34,47.01,86.96,45.68,86.22,45.16,86.32,44.74,86.12,44.40,85.69,44.11,85.25,43.77,84.93,43.59,84.93
.goto Desolace,43.59,84.93,50,0
.goto Desolace,47.01,86.96,70,0
.goto Desolace,50.48,86.66,50,0
.goto Desolace,47.01,86.96,70,0
.goto Desolace,43.59,84.93,50,0
.goto Desolace,50.48,86.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Centaur Pariah|r
>>|cRXP_WARN_The |cRXP_FRIENDLY_Centaur Pariah|r patrols slightly around southern Desolace|r
.accept 7067 >> Accept The Pariah's Instructions
.target Centaur Pariah
step
#label StartMara
.goto Desolace,29.89,62.44,0
.goto 1414,38.43,57.97
.zone 1414 >> Travel to Maraudon
step
#completewith EnterMaraudon
>>Kill all |cRXP_ENEMY_Monsters|r in Maraudon. Loot them for their |cRXP_LOOT_Theradric Crystal Carvings|r
>>|cRXP_WARN_This can be completed OUTSIDE and INSIDE of the Instance. Don't attempt to complete this now|r
.complete 7028,1 
.isOnQuest 7028
step
>>Kill |cRXP_ENEMY_The Nameless Prophet|r. Loot it for the |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance. |cRXP_ENEMY_The Nameless Prophets|r may be patrolling|r
.collect 17757,1,7067,1 
.mob The Nameless Prophet
.isOnQuest 7067
step
#completewith next
>>Kill |cRXP_ENEMY_Shadowshard Smashers|r and |cRXP_ENEMY_Shadowshard Rumblers|r. Loot them for their |cRXP_LOOT_Shadowshard Fragments|r
>>|cRXP_WARN_These are only found in the Purple section outside of the Instance|r
.complete 7070,1 
.mob Shadowshard Smasher
.mob Shadowshard Rumbler
.isOnQuest 7070
step
.goto 1414,38.469,57.287,20,0
.goto 1414,38.380,57.376,30,0
.goto 1414,38.469,57.287
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Gelk|r
>>Kill |cRXP_ENEMY_Gelk|r. Loot him for the |T134104:0|t[|cRXP_LOOT_Gem of the Second Khan|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance|r
.collect 17762,1,7067,1 
.use 17757 
.mob Spirit of Gelk
.mob Gelk
.isOnQuest 7067
step
.goto 1414,38.13,56.90,60,0
.goto 1414,28.76,56.96,60,0
.goto 1414,38.13,56.90
>>Kill |cRXP_ENEMY_Shadowshard Smashers|r and |cRXP_ENEMY_Shadowshard Rumblers|r. Loot them for their |cRXP_LOOT_Shadowshard Fragments|r
>>|cRXP_WARN_These are only found in the Purple section outside of the Instance|r
.complete 7070,1 
.mob Shadowshard Smasher
.mob Shadowshard Rumbler
.isOnQuest 7070
step
.goto 1414,38.497,57.721
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Kolk|r
>>Kill |cRXP_ENEMY_Kolk|r. Loot him for the |T134129:0|t[|cRXP_LOOT_Gem of the First Khan|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance|r
.collect 17761,1,7067,1 
.use 17757 
.mob Spirit of Kolk
.mob Kolk
.isOnQuest 7067
step
.goto 1414,38.77,58.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cavindra|r
.accept 7044 >> Accept Legends of Maraudon
.target Cavindra
step
.goto 1414,38.928,58.354
>>|cRXP_WARN_Use the|r |T134865:0|t[Coated Cerulean Vial] |cRXP_WARN_in the Orange pool|r
.complete 7041,2 
.use 17693 
.isOnQuest 7041
step
.goto 1414,39.00,58.32,70,0
.goto 1414,39.13,57.68,60,0
.goto 1414,39.25,57.71,20,0
.goto 1414,39.13,57.68
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Magra|r
>>Kill |cRXP_ENEMY_Magra|r. Loot him for the |T134135:0|t[|cRXP_LOOT_Gem of the Third Khan|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance|r
.collect 17763,1,7067,1 
.use 17757 
.mob Spirit of Magra
.mob Magra
.isOnQuest 7067
step
#label EnterMaraudon
.goto 1414,39.266,58.205
.subzone 2100,2 >> Enter the Maraudon Instance through the Orange side
step
#completewith CrystalCarving
>>Kill any |cRXP_ENEMY_Monster|r in Maraudon. Loot them for their |cRXP_LOOT_Theradric Crystal Carvings|r
.complete 7028,1 
.isOnQuest 7028
step
#completewith next
>>|cRXP_WARN_Use the|r |T134804:0|t[Filled Cerulean Vial] |cRXP_WARN_on small flowers/plants inside Orange|r
>>Kill the |cRXP_ENEMY_Noxxious Scions|r that are summoned
.complete 7041,1 
.use 17696 
.isOnQuest 7041
step
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Veng|r
>>Kill |cRXP_ENEMY_Veng|r. Loot him for the |T134116:0|t[|cRXP_LOOT_Gem of the Fifth Khan|r]
>>|cRXP_ENEMY_Veng|r |cRXP_WARN_patrols around INSIDE the Maraudon Orange Instance|r
.collect 17765,1,7067,1 
.use 17757 
.mob Spirit of Veng
.mob Veng
.isOnQuest 7067
step
>>|cRXP_WARN_Use the|r |T134804:0|t[Filled Cerulean Vial] |cRXP_WARN_on small flowers/plants inside Orange|r
>>Kill the |cRXP_ENEMY_Noxxious Scions|r that are summoned
.complete 7041,1 
.use 17696 
.isOnQuest 7041
step
>>Kill |cRXP_ENEMY_Noxxion|r. Loot him for the |cRXP_LOOT_Celebrian Rod|r
>>Kill |cRXP_ENEMY_Lord Vyletongue|r. Loot him for the |cRXP_LOOT_Celebrian Diamond|r
>>|cRXP_ENEMY_Noxxion|r |cRXP_WARN_is in the Orange section and |cRXP_ENEMY_Lord Vyletongue|r in the Purple|r
.complete 7044,2 
.complete 7044,1 
.isOnQuest 7044
step
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Maraudos|r
>>Kill |cRXP_ENEMY_Maraudos|r. Loot him for the |T134132:0|t[|cRXP_LOOT_Gem of the Fourth Khan|r]
>>|cRXP_ENEMY_Maraudos|r |cRXP_WARN_patrols around INSIDE the Maraudon Purple Instance|r
.collect 17764,1,7067,1 
.use 17757 
.mob Spirit of Maraudos
.mob Maraudos
.isOnQuest 7067
step
>>|cRXP_WARN_Channel any of the|r |T134129:0|t|T134104:0|t|T134135:0|t|T134132:0|t|T134116:0|t[|cRXP_LOOT_Gems of the Khans|r] |cRXP_WARN_to create the|r |T133277:0|t[|cRXP_LOOT_Amulet of Union|r]
.complete 7067,1 
.use 17761,1
.use 17762,1
.use 17763,1
.use 17764,1
.use 17765,1
.itemcount 17761,1
.itemcount 17762,1
.itemcount 17763,1
.itemcount 17764,1
.itemcount 17765,1
.isOnQuest 7067
step
>>Kill |cRXP_ENEMY_Celebras the Cursed|r then talk to |cRXP_FRIENDLY_Celebras the Redeemed|r
.turnin 7044 >> Turn in Legends of Maraudon
.isQuestComplete 7044
.mob Celebras the Cursed
.target Celebras the Redeemed
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celebras the Redeemed|r
.accept 7046 >> Accept The Scepter of Celebras
.timer 14,Incantation of Celebras Spawning RP
.isQuestTurnedIn 7044
.target Celebras the Redeemed
step
.cast 6477 >> Click the |cRXP_PICK_Incantation of Celebras|r on the ground
.timer 34,The Scepter of Celebras RP
.isQuestTurnedIn 7044
step
>>|cRXP_WARN_Wait out the RP|r
.complete 7046,1 
.isQuestTurnedIn 7044
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celebras the Redeemed|r
.turnin 7046 >> Turn in The Scepter of Celebras
.isQuestTurnedIn 7044
.target Celebras the Redeemed
step
>>Kill |cRXP_ENEMY_Princess Theradras|r
.complete 7065,1 
.mob Princess Theradras
.isOnQuest 7065
step
#label CrystalCarving
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaetar's Spirit|r
.accept 7066 >> Accept Seed of Life
.target Zaetar's Spirit
step
>>Kill any |cRXP_ENEMY_Monster|r in Maraudon. Loot them for their |cRXP_LOOT_Theradric Crystal Carvings|r
>>|cRXP_WARN_This can be completed OUTSIDE and INSIDE of the Instance|r
.complete 7028,1 
.isOnQuest 7028
step
.hs >> Hearth to Nijel's Point
step
.goto Desolace,64.64,9.15,0
.goto Desolace,63.827,10.669
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Marandis|r
.turnin 7065 >> Turn in Corruption of Earth and Seed
.target Keeper Marandis
.isQuestComplete 7065
step
.goto Desolace,68.501,8.880
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talendria|r
.turnin 7041 >> Turn in Vyletongue Corruption
.target Talendria
.isQuestComplete 7041
step
.goto Desolace,62.194,39.624
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Willow|r
.turnin 7028 >> Turn in Twisted Evils
.target Willow
.isQuestComplete 7028
step
.line Desolace,50.48,86.66,50.39,86.61,50.18,87.01,49.89,87.11,48.95,87.04,48.73,87.11,48.25,87.14,47.82,87.34,47.01,86.96,45.68,86.22,45.16,86.32,44.74,86.12,44.40,85.69,44.11,85.25,43.77,84.93,43.59,84.93
.goto Desolace,43.59,84.93,50,0
.goto Desolace,47.01,86.96,70,0
.goto Desolace,50.48,86.66,50,0
.goto Desolace,47.01,86.96,70,0
.goto Desolace,43.59,84.93,50,0
.goto Desolace,50.48,86.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Centaur Pariah|r
>>|cRXP_WARN_The |cRXP_FRIENDLY_Centaur Pariah|r patrols slightly around southern Desolace|r
.turnin 7067 >> Turn in The Pariah's Instructions
.target Centaur Pariah
.isQuestComplete 7067
step
#completewith next
.goto Desolace,64.66,10.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baritanas Skyriver|r
.fly Theramore >> Fly to Theramore
.target Baritanas Skyriver
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Tervosh|r atop Theramore tower
.goto Dustwallow Marsh,66.423,49.260
.turnin 7070 >> Turn in Shadowshard Fragments
.target Archmage Tervosh
.isQuestComplete 7070
step
#completewith next
.zone Moonglade >> Travel to Moonglade
step << Druid
#completewith next
.cast 18960 >> Cast Teleport: Moonglade
.zoneskip Moonglade
step
.isOnQuest 7066
.goto Moonglade,36.178,41.798
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 7066 >> Turn in Seed of Life
.target Keeper Remulos
step
+|cRXP_WARN_You have completed the Maraudon quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 30-50
<< Alliance
#name 12. Sunken Temple
step << Paladin
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Western Plaguelands >> Travel to Western Plaguelands
step << Paladin
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.accept 8414 >> Accept Dispelling Evil
.target Commander Ashlam Valorfist
step << Paladin
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Western Plaguelands,48.91,80.84,70,0
.goto Western Plaguelands,50.01,76.90
>>Kill |cRXP_ENEMY_Skeletal Flayers|r and |cRXP_ENEMY_Slavering Ghouls|r. Loot them for their |cRXP_LOOT_Minion's Scourgestones|r
.complete 8414,1 
.mob +Slavering Ghoul
.mob +Skeletal Flayer
step << Paladin
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Western Plaguelands,51.99,82.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priest Thel'danis|r
.turnin 8414 >> Turn in Dispelling Evil
.accept 8416 >> Accept Inert Scourgestones
.target High Priest Thel'danis
step << Paladin
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 8416 >> Turn in Inert Scourgestones
.accept 8418 >> Accept Forging the Mightstone
.target Commander Ashlam Valorfist
step << Priest
.xp <50,1
#phase 4-6 << !tbc !wotlk
#ah
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to an |cRXP_FRIENDLY_Auctioneer|r in a major city
>>|cRXP_BUY_Buy a|r |T134797:0|t[Ichor of Undeath] |cRXP_BUY_from the Auction House. You will need this later for your Sunken Temple class quest|r
>>|cRXP_WARN_Skip this step if you can't acquire one|r
.collect 7972,1,8256,1 
step << Hunter/Priest
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Azshara >> Travel to Azshara
step << Hunter/Priest
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,42.400,42.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogtinc|r
.accept 8153 >> Accept Courser Antlers << Hunter
.accept 8255 >> Accept Of Coursers We Know << Priest
.target Ogtinc
step << Hunter/Priest
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,51.0,30.8,80,0
.goto Azshara,47.0,19.0,80,0
.goto Azshara,57.2,21.2,80,0
.goto Azshara,71.0,29.6,80,0
.goto Azshara,75.8,21.8,80,0
.goto Azshara,57.2,21.2
>>Kill |cRXP_ENEMY_Mosshoof Coursers|r. Loot them for their |cRXP_LOOT_Perfect Courser Antlers|r << Hunter
>>Kill |cRXP_ENEMY_Mosshoof Coursers|r. Loot them for their |cRXP_LOOT_Healthy Courser Glands|r << Priest
.complete 8153,1 << Hunter 
.complete 8255,1 << Priest 
.mob Mosshoof Courser
step << Hunter/Priest
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,42.400,42.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogtinc|r
.turnin 8153 >> Turn in Courser Antlers << Hunter
.accept 8231 >> Accept Wavethrashing << Hunter
.turnin 8255 >> Turn in Of Coursers We Know << Priest
.accept 8256 >> Accept The Ichor of Undeath << Priest
.target Ogtinc
step << Hunter
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,88.69,25.88,70,0
.goto Azshara,87.0,9.0
.goto Azshara,54.2,42.2,0
.goto Azshara,59.2,35.6,0
.goto Azshara,71.6,36.8,0
.goto Azshara,90.4,33.6,0
.goto Azshara,88.69,25.88,0
>>Kill |cRXP_ENEMY_Wavethrashers|r. Loot them for their |cRXP_LOOT_Wavethrasher Scales|r
>>|cRXP_WARN_These can be hard to find. Ensure to use|r |T132328:0|t[Track Beasts] |cRXP_WARN_and cast|r |T132172:0|t[Eagle Eye] |cRXP_WARN_around the coast to find them faster|r
.complete 8231,1 
.mob Wavethrasher
.mob Young Wavethrasher
.mob Great Wavethrasher
step << Priest
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,17.12,69.00,60,0
.goto Azshara,14.22,72.74,60,0
.goto Azshara,17.12,69.00
>>Kill |cRXP_ENEMY_Highborne Apparitions|r and |cRXP_ENEMY_Highborne Lichlings|r. Loot them for an |cRXP_LOOT_Ichor of Undeath|r
.complete 8256,1 
.mob Highborne Apparition
.mob Highborne Lichling
step << Hunter/Priest
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,42.400,42.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogtinc|r
.turnin 8231 >> Turn in Wavethrashing << Hunter
.accept 8232 >> Accept The Green Drake << Hunter
.turnin 8256 >> Turn in The Ichor of Undeath
.accept 8257 >> Accept Blood of Morphaz << Priest
.target Ogtinc
step << Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Hillsbrad Foothills,75.575,22.076,20,0
.goto Alterac Mountains,86.026,78.879
.subzone 3486 >> Travel to Hillsbrad Foothills (Southshore). From there travel to Ravenholdt Manor
step << Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Alterac Mountains,86.026,78.879
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Jorach Ravenholdt|r upstairs
.accept 8234 >> Accept Sealed Azure Bag
.target Lord Jorach Ravenholdt
step << Mage/Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Azshara >> Travel to Azshara
step << Mage
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.goto Azshara,28.113,50.088
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanath Lim-yo|r
>>|cRXP_WARN_This will teleport you to the top of the mountain|r
.turnin 3503 >> Turn in Meeting with the Master
.target Sanath Lim-yo
step << Mage
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,29.248,40.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Xylem|r atop the Tower
.accept 8251 >> Accept Magic Dust
.target Archmage Xylem
step << Mage
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.goto Azshara,26.466,46.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyrill|r
>>|cRXP_WARN_This will teleport you back down|r
.turnin 3421 >> Turn in Return Trip
.timer 8,Return Trip RP
.target Nyrill
step << Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,48.42,30.29,70,0
.goto Azshara,44.34,26.09,70,0
.goto Azshara,45.26,21.60
>>|T133644:0|t[Pick Pocket] |cRXP_ENEMY_Timbermaw Shamans|r. Loot them for the |cRXP_LOOT_Sealed Azure Bag|r
>>|cRXP_WARN_You may have to tick the [At War] checkbox for [Timbermaw Hold] in your Reputation pane to make them hostile towards you|r
.complete 8234,1 
.mob Timbermaw Shaman
step << Mage
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,55.97,29.98,30,0
.goto Azshara,56.55,28.36,30,0
.goto Azshara,57.71,31.13,50,0
.goto Azshara,59.17,31.93,40,0
.goto Azshara,58.96,28.23,30,0
.goto Azshara,56.55,28.36
>>Kill |cRXP_ENEMY_Blood Elf Reclaimers|r and |cRXP_ENEMY_Blood Elf Surveyors|r. Loot them for their |cRXP_LOOT_Glittering Dust|r
.complete 8251,1 
.mob Blood Elf Reclaimer
.mob Blood Elf Surveyor
step << Mage/Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.goto Azshara,28.113,50.088
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanath Lim-yo|r
>>|cRXP_WARN_This will teleport you to the top of the mountain|r
.turnin 3503 >> Turn in Meeting with the Master
.target Sanath Lim-yo
step << Mage/Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,29.248,40.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Xylem|r atop the Tower
.turnin 8251 >> Turn in Magic Dust << Mage
.accept 8252 >> Accept The Siren's Coral << Mage
.turnin 8234 >> Turn in Sealed Azure Bag << Rogue
.accept 8235 >> Accept Encoded Fragments << Rogue
.target Archmage Xylem
step << Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.isQuestTurnedIn 8234
#completewith next
+|cRXP_WARN_Ensure you have to unticked the [At War] checkbox for [Timbermaw Hold] in your Reputation pane to make them non-hostile towards you again|r
step << Mage/Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.goto Azshara,26.466,46.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyrill|r
>>|cRXP_WARN_This will teleport you back down|r
.turnin 3421 >> Turn in Return Trip
.timer 8,Return Trip RP
.target Nyrill
step << Mage
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,43.0,45.6,70,0
.goto Azshara,47.0,41.6,70,0
.goto Azshara,47.4,65.0,70,0
.goto Azshara,46.0,52.8
>>Kill |cRXP_ENEMY_Spitelash Sirens|r. Loot them for their |cRXP_LOOT_Enchanted Corals|r
.complete 8252,1 
.mob Spitelash Siren
step << Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,66.6,25.6,70,0
.goto Azshara,68.8,29.4,70,0
.goto Azshara,74.2,29.6,70,0
.goto Azshara,76.6,25.0,70,0
.goto Azshara,80.8,24.6,70,0
.goto Azshara,86.6,19.6,70,0
.goto Azshara,74.6,12.6,70,0
.goto Azshara,69.0,27.6
>>Kill |cRXP_ENEMY_Forest Oozes|r. Loot them for their |cRXP_LOOT_Encoded Fragments|r
>>|cRXP_WARN_Cast|r |T133644:0|t[Pick Pocket] |cRXP_WARN_on them before you kill them|r
.complete 8235,1 
.mob Forest Ooze
step << Mage/Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.goto Azshara,28.113,50.088
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanath Lim-yo|r
>>|cRXP_WARN_This will teleport you to the top of the mountain|r
.turnin 3503 >> Turn in Meeting with the Master
.target Sanath Lim-yo
step << Mage/Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Azshara,29.248,40.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Xylem|r atop the Tower
.turnin 8252 >> Turn in The Siren's Coral << Mage
.turnin 8235 >> Turn in Encoded Fragments << Rogue
.accept 8253 >> Accept Destroy Morphaz << Mage
.accept 8236 >> Accept The Azure Key << Rogue
.target Archmage Xylem
step << Mage/Rogue
.xp <50,1
#phase 4-6 << !tbc !wotlk
.isOnQuest 8253,8236
.goto Azshara,26.466,46.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyrill|r
>>|cRXP_WARN_This will teleport you back down|r
.turnin 3421 >> Turn in Return Trip
.timer 8,Return Trip RP
.target Nyrill
.zoneskip Azshara,1
step << Druid
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Un'Goro Crater >> Travel to Un'Goro Crater
step << Druid
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.accept 9052 >> Accept Bloodpetal Poison
.target Torwa Pathfinder
step << Druid
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Un'Goro Crater,44.8,75.6,70,0
.goto Un'Goro Crater,45.0,83.6,70,0
.goto Un'Goro Crater,55.0,83.6,70,0
.goto Un'Goro Crater,54.4,76.4,70,0
.goto Un'Goro Crater,48.8,85.3
>>Kill |cRXP_ENEMY_Gorishi Stingers|r and |cRXP_ENEMY_Gorishi Wasps|r. Loot them for their |cRXP_LOOT_Gorishi Stings|r
.complete 9052,1 
.mob Gorishi Wasp
.mob Gorishi Stinger
step << Druid
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Un'Goro Crater,62.5,64.1,90,0
.goto Un'Goro Crater,38.3,53.6,90,0
.goto Un'Goro Crater,45.5,24.5
>>Open the |cRXP_PICK_Bloodpetal Sprouts|r on the ground. Loot them for |cRXP_LOOT_Bloodcaps|r
.complete 9052,2 
step << Druid
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 9052 >> Turn in Bloodpetal Poison
.accept 9051 >> Accept Toxic Test
.target Torwa Pathfinder
step << Druid
.xp <50,1
#phase 4-6 << !tbc !wotlk
>>Look for a |cRXP_ENEMY_Devilsaur|r or |cRXP_ENEMY_Ironhide Devilsaur|r. Avoid |cRXP_ENEMY_Tyrant Devilsaurs|r
>>|cRXP_WARN_You should be able to see their patrols on your map|r
>>|cRXP_WARN_The way you do this is spamming|r |T136090:0|t[Hibernate]|cRXP_WARN_. You should only spam|r |T136090:0|t[Hibernate] |cRXP_WARN_and nothing else. If it breaks early start spamming|r |T136090:0|t[Hibernate] |cRXP_WARN_again, they run with 170% movement speed so you can't outrun a|r |cRXP_ENEMY_Devilsaur|r
>>|cRXP_WARN_Use the|r |T135125:0|t[Devilsaur Barb] |cRXP_WARN_on it once it has been|r |T136090:0|t[Hibernated]
>>|cRXP_WARN_Shift into|r |T132144:0|t[Travel Form] |cRXP_WARN_and run away to reset it after|r
.complete 9051,1 
.use 22432 
.mob Devilsaur
.mob Ironhide Devilsaur
step << Druid
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 9051 >> Turn in Toxic Test
.accept 9053 >> Accept A Better Ingredient
.target Torwa Pathfinder
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
.isQuestAvailable 8419
.isQuestAvailable 8420
#ah
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to an |cRXP_FRIENDLY_Auctioneer|r
>>Buy the following items from the Auction House for an instant turn in at Felwood shortly. Skip this step if you wish to not buy any
>>|T132888:0|t[Felcloth]
.collect 14256,1,8419,1 
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Felwood >> Travel to Felwood
step << Warlock
.xp <50,1
#optional
#phase 4-6 << !tbc !wotlk
.isOnQuest 8419
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.turnin 8419 >> Turn in An Imp's Request
.target Impsy
.itemcount 14256,1
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
.isQuestAvailable 8419
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.accept 8420 >> Accept Hot and Itchy
.turnin 8420 >> Turn in Hot and Itchy
.target Impsy
.itemcount 14256,1
step << Warlock
.xp <50,1
.isQuestAvailable 8419
.isQuestAvailable 8420
#phase 4-6 << !tbc !wotlk
.goto Felwood,43.27,84.98,45,0
.goto Felwood,43.41,88.13,70,0
.goto Felwood,39.45,84.55
>>Kill |cRXP_ENEMY_Jadefire Satyrs|r and |cRXP_ENEMY_Jadefire Felsworns|r. Loot them for a |cRXP_LOOT_Felcloth|r
.collect 14256,1
.mob Jadefire Satyr
.mob Jadefire Felsworn
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
.isQuestAvailable 8419
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.accept 8420 >> Accept Hot and Itchy
.turnin 8420 >> Turn in Hot and Itchy
.target Impsy
.itemcount 14256,1
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
.isQuestAvailable 8419
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.accept 8421 >> Accept The Wrong Stuff
.target Impsy
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Felwood,40.48,59.07,70,0
.goto Felwood,39.98,54.76,0
>>Kill |cRXP_ENEMY_Tainted Oozes|r. Loot them for their |cRXP_LOOT_Bloodvenom Essences|r
.complete 8421,2 
.mob Tainted Ooze
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
.isOnQuest 8421
.goto Felwood,49.0,29.6,70,0
.goto Felwood,53.0,22.8,70,0
.goto Felwood,49.4,18.0,70,0
.goto Felwood,46.4,24.6,70,0
.goto Felwood,49.0,29.6,70,0
.goto Felwood,53.0,22.8,70,0
.goto Felwood,49.4,18.0,70,0
.goto Felwood,46.4,24.6
>>Kill |cRXP_ENEMY_Irontree Stompers|r, |cRXP_ENEMY_Irontree Wanderers|r and |cRXP_ENEMY_Withered Protectors|r. Loot them for their |cRXP_LOOT_Rotting Wood|r
.complete 8421,1 
.mob Irontree Stomper
.mob Irontree Wanderer
.mob Withered Protector
step << Warlock
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.turnin 8421 >> Turn in The Wrong Stuff
.accept 8422 >> Accept Trolls of a Feather
.target Impsy
step << Warrior
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Blasted Lands >> Travel to Blasted Lands
step << Warrior
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.accept 8423 >> Accept Warrior Kinship
.target Fallen Hero of the Horde
step << Warrior
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Blasted Lands,44.2,34.8,70,0
.goto Blasted Lands,47.7,38.6,70,0
.goto Blasted Lands,52.2,37.4,70,0
.goto Blasted Lands,54.8,44.8,70,0
.goto Blasted Lands,51.2,55.6,70,0
.goto Blasted Lands,45.8,48.2,70,0
.goto Blasted Lands,49.0,36.6
>>Kill |cRXP_ENEMY_Helboars|r
.complete 8423,1 
.mob Helboar
step << Warrior
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 8423 >> Turn in Warrior Kinship
.accept 8424 >> Accept War on the Shadowsworn
.target Fallen Hero of the Horde
step << Warrior
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Blasted Lands,63.8,30.1,60,0
.goto Blasted Lands,63.1,45.8,60,0
.goto Blasted Lands,65.9,33.3,60,0
.goto Blasted Lands,63.6,39.2
>>Kill |cRXP_ENEMY_Shadowsworn Adepts|r, |cRXP_ENEMY_Shadowsworn Cultists|r and |cRXP_ENEMY_Shadowsworn Thugs|r
.complete 8424,1 
.complete 8424,2 
.complete 8424,3 
.mob Shadowsworn Adept
.mob Shadowsworn Cultist
.mob Shadowsworn Thug
step << Warrior
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 8424 >> Turn in War on the Shadowsworn
.accept 8425 >> Accept Voodoo Feathers
.target Fallen Hero of the Horde
step << Shaman
.xp <50,1
#completewith next
.zone Ironforge >> Travel to Ironforge
step << Shaman
.xp <50,1
.goto Ironforge,55.436,28.942
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Javad|r
.accept 8410 >> Accept Elemental Mastery
.target Farseer Javad
step << Shaman
.xp <50,1
#ah
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to an |cRXP_FRIENDLY_Auctioneer|r in a major city
>>|cRXP_BUY_Buy a the following from the Auction House. You will need this later for your Sunken Temple class quest|r
>>|cRXP_WARN_Skip this step if you can't acquire them|r
.collect 7070,1,8410,1 
.collect 7069,1,8410,1 
.collect 7068,1,8410,1 
.collect 7067,1,8410,1 
step << Shaman
.xp <50,1
#completewith next
.goto Ironforge,55.501,47.742
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
.fly Arathi >> Fly to Arathi Highlands
.target Gryth Thurden
.zoneskip Arathi Highlands
.zoneskip Alterac Mountains
.zoneskip Hillsbrad Foothills
step << Shaman
.xp <50,1
>>Kill |cRXP_ENEMY_Cresting Exiles|r, |cRXP_ENEMY_Thundering Exiles|r, |cRXP_ENEMY_Rumbling Exiles|r and |cRXP_ENEMY_Burning Exiles|r. Loot them for their |cRXP_LOOT_Elemental Water|r, |cRXP_LOOT_Elemental Air|r, |cRXP_LOOT_Elemental Earth|r and |cRXP_LOOT_Elemental Fire|r
.collect 7070,1,8410,1 
.mob +Cresting Exile
.goto Arathi Highlands,66.8,31.0
.collect 7069,1,8410,1 
.mob +Thundering Exile
.goto Arathi Highlands,52.0,50.6
.collect 7067,1,8410,1 
.mob +Rumbling Exile
.goto Arathi Highlands,36.4,57.6
.collect 7068,1,8410,1 
.mob +Burning Exile
.goto Arathi Highlands,25.4,30.6
step << Shaman
.xp <50,1
#completewith next
.zone Alterac Mountains >> Travel to Alterac Mountains
step << Shaman
.xp <50,1
.goto Alterac Mountains,80.497,66.919
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
.turnin 8410 >> Turn in Elemental Mastery
.accept 8412 >> Accept Spirit Totem
.target Bath'rah the Windwatcher
step << Shaman
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Western Plaguelands >>Travel to Western Plaguelands
step << Shaman
.xp <50,1
#phase 4-6 << !tbc !wotlk
#loop
.goto Western Plaguelands,34.60,65.80,0
.goto Western Plaguelands,34.60,65.80,60,0
.goto Western Plaguelands,33.60,63.20,60,0
.goto Western Plaguelands,31.80,63.60,60,0
.goto Western Plaguelands,32.00,59.60,60,0
.goto Western Plaguelands,30.80,50.20,60,0
.goto Western Plaguelands,32.80,56.00,60,0
.goto Western Plaguelands,36.00,58.40,60,0
.goto Western Plaguelands,34.00,61.80,60,0
>>Kill |cRXP_ENEMY_Venom Mist Lurkers|r, |cRXP_ENEMY_Carrion Vultures|r and |cRXP_ENEMY_Diseased Black Bears|r. Loot them for their |cRXP_LOOT_Eyes|r and |cRXP_LOOT_Claws|r
.complete 8412,1 
.mob +Carrion Vulture
.mob +Venom Mist Lurker
.complete 8412,2 
.mob +Diseased Black Bear
.mob +Carrion Vulture
step << Shaman
.xp <50,1
#phase 4-6 << !tbc !wotlk
#completewith next
.zone Alterac Mountains >>Travel to Alterac Mountains
step << Shaman
.xp <50,1
#phase 4-6 << !tbc !wotlk
.goto Alterac Mountains,80.50,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah|r
.turnin 8412 >>Turn in Spirit Totem
.accept 8413 >>Accept Da Voodoo
.target Bath'rah the Windwatcher
step
#completewith next
.zone The Hinterlands >> Travel to The Hinterlands
step
.goto The Hinterlands,33.751,75.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Atal'ai Exile|r
.accept 1446 >> Accept Jammal'an the Prophet
.target Atal'ai Exile
step
#completewith next
.zone Feralas >> Travel to Feralas
step
.goto Feralas,31.828,45.611
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angelas Moonbreeze|r
.accept 3445 >> Accept The Sunken Temple
.target Angelas Moonbreeze
step
#completewith next
.zone Tanaris >> Travel to Tanaris
step
.goto Tanaris,52.707,45.923
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon Rivetseeker|r
.turnin 3445 >> Turn in The Sunken Temple
.accept 3444 >> Accept The Stone Circle
.target Marvon Rivetseeker
step
#completewith next
.zone The Barrens >> Travel to Ratchet in The Barrens
step
.goto The Barrens,62.500,38.546
>>Open |cRXP_PICK_Marvon's Chest|r. Loot it for the |cRXP_LOOT_Stone Circle|r
.complete 3444,1 
step
#completewith next
.zone Tanaris >> Travel to Tanaris
step
.goto Tanaris,52.707,45.923
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon Rivetseeker|r
.turnin 3444 >> Turn in The Stone Circle
.accept 3446 >> Accept Into the Depths
.accept 3447 >> Accept Secret of the Circle
.target Marvon Rivetseeker
step
#optional
.isQuestTurnedIn 4787 
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.accept 3528 >> Accept The God Hakkar
.target Yeh'kinya
step
#completewith next
.zone Stormwind City >> Travel to Stormwind
step
.isQuestTurnedIn 1469
.goto StormwindClassic,64.328,20.627
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brohann Caskbelly|r
.accept 1475 >> Accept Into The Temple of Atal'Hakkar
.target Brohann Caskbelly
step
#completewith STEntry
.zone Blasted Lands >> You will now run Sunken Temple. Start looking for a group. You may fly to Blasted Lands and grind mobs there while you form a group
.zoneskip Swamp of Sorrows
.zoneskip 1415
step
#label STEntry
.goto 1415,56.33,76.28
.subzone 1477 >> Travel to Sunken Temple once your group is ready
step
.isOnQuest 1475
#completewith next
>>Loot the |cRXP_LOOT_Atal'ai Tablets|r on the ground
>>|cRXP_WARN_These can be looted en-route to the instance portal, as well as inside Sunken Temple|r
.complete 1475,1 
step
.goto 1415,56.33,76.28,40,0
.goto 1415,56.46,75.54,20,0
.goto 1415,56.83,75.86,20,0
.goto 1415,56.94,76.03,15,0
.goto 1415,57.06,75.58,20,0
.goto 1415,56.76,75.35,15,0
.goto 1415,56.809,75.151
.subzone 1477,2 >> Zone into Sunken Temple
step
.isOnQuest 1475
#sticky
>>Loot the |cRXP_LOOT_Atal'ai Tablets|r on the ground
.complete 1475,1 
step << Druid
.isOnQuest 9053
#completewith Altar
>>Kill |cRXP_ENEMY_Atal'alarion|r. Loot him for the |cRXP_LOOT_Putrid Vine|r
>>|cRXP_ENEMY_Atal'alarion|r |cRXP_WARN_is on the lower level of Sunken Temple and is summoned by clicking all |cRXP_PICK_Atal'ai Statues|r on the platforms|r
.complete 9053,1 
step 
.isOnQuest 3446
#completewith next
>>Click on the |cRXP_PICK_Altar of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Altar of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3446 >> Turn in Into the Depths
step 
.isOnQuest 3447
>>Click on the |cRXP_PICK_Idol of Hakkar|r
>>|cRXP_WARN_Clicking all of the |cRXP_PICK_Atal'ai Statues|r on the platforms will activate the|r |cRXP_PICK_Idol of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Idol of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3447 >> Turn in Secret of the Circle
step 
.isOnQuest 3446
#label Altar
>>Click on the |cRXP_PICK_Altar of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Altar of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3446 >> Turn in Into the Depths
step << Druid
.isOnQuest 9053
>>Kill |cRXP_ENEMY_Atal'alarion|r. Loot him for the |cRXP_LOOT_Putrid Vine|r
>>|cRXP_ENEMY_Atal'alarion|r |cRXP_WARN_is on the lower level of Sunken Temple and is summoned by clicking all |cRXP_PICK_Atal'ai Statues|r on the platforms|r
.complete 9053,1 
step << Paladin/Warrior/Warlock/Shaman
.isOnQuest 8418,8425,8422
>>Kill |cRXP_ENEMY_Gasher|r and |cRXP_ENEMY_Zul'Lor|r. Loot them for their |cRXP_LOOT_Amber Voodoo Feathers|r
>>Kill |cRXP_ENEMY_Mijan|r and |cRXP_ENEMY_Hukku|r. Loot them for their |cRXP_LOOT_Blue Voodoo Feathers|r
>>Kill |cRXP_ENEMY_Zolo|r and |cRXP_ENEMY_Loro|r. Loot them for their |cRXP_LOOT_Green Voodoo Feathers|r
>>|cRXP_WARN_This quest is completed on the upper level of Sunken Temple|r
.complete 8418,1 << Paladin 
.complete 8418,2 << Paladin 
.complete 8418,3 << Paladin 
.complete 8425,1 << Warrior 
.complete 8425,2 << Warrior 
.complete 8425,3 << Warrior 
.complete 8422,1 << Warlock 
.complete 8422,2 << Warlock 
.complete 8422,3 << Warlock 
.complete 8413,1 << Shaman 
.complete 8413,2 << Shaman 
.complete 8413,3 << Shaman 
step
.isOnQuest 3528
>>|cRXP_WARN_Use the|r |T132834:0|t[Egg of Hakkar] |cRXP_WARN_while next to the Dragonflayer Skeleton, then complete the event|r
>>Kill the minions of |cRXP_ENEMY_Hakkar|r until the |cRXP_ENEMY_Avatar of Hakkar|r joins
>>Kill the |cRXP_ENEMY_Avatar of Hakkar|r. Loot it for the |T136148:0|t[|cRXP_LOOT_Essence of Hakkar|r]
>>|cRXP_WARN_Use the|r |T136148:0|t[|cRXP_LOOT_Essence of Hakkar|r] |cRXP_WARN_to fill the|r |T132834:0|t[Egg of Hakkar]
.collect 10663,1,3528,1 
.disablecheckbox
.complete 3528,1 
.use 10465 
.use 10663 
step
.isOnQuest 1446
>>Kill |cRXP_ENEMY_Jammal'an the Prophet|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_You must kill the 6 |cRXP_ENEMY_Trolls|r on the upper platforms to gain access to|r |cRXP_ENEMY_Jammal'an the Prophet|r
.complete 1446,1 
step << Hunter/Mage/Priest/Rogue
.isOnQuest 8232,8253,8257,8236
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Tooth of Morphaz|r << Hunter
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Arcane Shard|r << Mage
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Blood of Morphaz|r << Priest
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Azure Key|r << Rogue
.complete 8232,1 << Hunter 
.complete 8253,1 << Mage 
.complete 8257,1 << Priest 
.complete 8236,1 << Rogue 
step
>>Kill the |cRXP_ENEMY_Shade of Eranikus|r. Loot him for the |T135229:0|t[|cRXP_LOOT_Essence of Eranikus|r]
>>|cRXP_WARN_Use the |T135229:0|t[|cRXP_LOOT_Essence of Eranikus|r] to start the quest|r
>>|cRXP_WARN_Ensure you have killed all |cRXP_ENEMY_Dragonkin|r mobs on the upper level before engaging the |cRXP_ENEMY_Shade of Eranikus|r otherwise they will all aggro onto you|r
.collect 10454,1,3373,1 
.accept 3373 >> Accept The Essence of Eranikus
step
.isOnQuest 3373
>>Click the |cRXP_PICK_Essence Font|r
.turnin 3373 >> Turn in The Essence of Eranikus
step << Warrior
.isQuestComplete 8425
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
>>|cRXP_WARN_It is strongly advised you choose the|r |T132788:0|t[|cFF0070FFDiamond Flask|r] |cRXP_WARN_as your reward. Although the other rewards are also very good, you will not ever replace the|r |T132788:0|t[|cFF0070FFDiamond Flask|r]
.turnin 8425 >> Turn in Voodoo Feathers
.target Fallen Hero of the Horde
step
#completewith TempleTurnIn
.zone Stormwind City >> Travel to Stormwind
step
.goto Blasted Lands,65.535,24.337
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexandra Constantine|r
.fly Stormwind >> Fly to Stormwind
.target Alexandra Constantine
.zoneskip Stormwind City
step
#label TempleTurnIn
.isQuestComplete 1475
.goto StormwindClassic,64.328,20.627
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brohann Caskbelly|r
.turnin 1475 >> Turn in Into The Temple of Atal'Hakkar
.target Brohann Caskbelly
step << Paladin
#completewith next
.zone Western Plaguelands >> Travel to Western Plaguelands
step << Paladin
.isQuestComplete 8418
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 8418 >> Turn in Forging the Mightstone
.target Commander Ashlam Valorfist
step << Mage/Rogue/Hunter/Priest
#completewith next
.zone Azshara >> Travel to Azshara
step << Mage/Rogue
.isQuestComplete 8253 << Mage
.isQuestComplete 8236 << Rogue
#completewith next
.goto Azshara,28.113,50.088
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanath Lim-yo|r
>>|cRXP_WARN_This will teleport you to the top of the mountain|r
.turnin 3503 >> Turn in Meeting with the Master
.target Sanath Lim-yo
step << Mage/Rogue
.isQuestComplete 8253 << Mage
.isQuestComplete 8236 << Rogue
.goto Azshara,29.248,40.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archamge Xylem|r atop the Tower
.turnin 8253 >> Turn in Destroy Morphaz << Mage
.turnin 8236 >> Turn in The Azure Key << Rogue
.target Archamge Xylem
step << Mage/Rogue
.isQuestTurnedIn 8253 << Mage
.isQuestTurnedIn 8236 << Rogue
#completewith ArcaneRunes
.goto Azshara,26.466,46.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyrill|r
>>|cRXP_WARN_This will teleport you back down|r
.turnin 3421 >> Turn in Return Trip
.timer 8,Return Trip RP
.target Nyrill
step << Hunter/Priest
.isQuestComplete 8232 << Hunter
.isQuestComplete 8257 << Priest
.goto Azshara,42.400,42.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogtinc|r
.turnin 8232 >> Turn in The Green Drake << Hunter
.turnin 8257 >> Turn in Blood of Morphaz << Priest
.target Ogtinc
step << Druid
#completewith next
.zone Un'Goro Crater >> Travel to Un'Goro Crater
step << Druid
.isQuestComplete 9053
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 9053 >> Turn in A Better Ingredient
.target Torwa Pathfinder
step << Druid
#completewith next
.zone Tanaris >> Travel to Tanaris
step << Druid
.isQuestComplete 3528
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3528 >> Turn in The God Hakkar
.target Yeh'kinya
step << Warlock
#completewith next
.zone Felwood >> Travel to Felwood
step << Warlock
.isQuestComplete 8422
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.turnin 8422 >> Turn in Trolls of a Feather
.target Impsy
step
#completewith next
.zone The Hinterlands >> Travel to The Hinterlands
step
.isQuestComplete 1446
.goto The Hinterlands,33.751,75.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Atal'ai Exile|r
.turnin 1446 >> Turn in Jammal'an the Prophet
.target Atal'ai Exile
step << Shaman
#completewith next
.zone Alterac Mountains >> Travel to Alterac Mountains
step << Shaman
.isQuestComplete 8413
.goto Alterac Mountains,80.50,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah|r
.turnin 8413 >>Turn in Da Voodoo
.target Bath'rah the Windwatcher
step << !Druid
#completewith next
.zone Tanaris >> Travel to Tanaris
step << !Druid
.isQuestComplete 3528
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3528 >> Turn in The God Hakkar
.target Yeh'kinya
step
+|cRXP_WARN_You have completed the Sunken Temple quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 13. Blackrock Depths
step
#completewith AcceptBRDQuests
+You will now fly around to accept quests for Blackrock Depths.
>>Blackrock Depths is a very convoluted dungeon. In order to complete all quests in the most efficient way, it is required to leave the dungeon midrun to turn in/accept follow up quests so it may all be completed in 1 run.
>>Try to ensure all party members have the same quests and prequests complete, along with 2-3 hours of playtime.
step
.isQuestTurnedIn 3481
>>Remember to take out |T134430:0|t[Black Dragonflight Molt] from your bank if you completed the quest in Searing Gorge for it earlier. You will need it shortly
.collect 10575,1,4022,1 
step
#completewith HurleyBlackbreath
.zone Ironforge >> Travel to Ironforge
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Firebrew|r
>>|cRXP_WARN_If you have a Mage in your group you will set your Hearth to Lakeshire instead|r
.goto Ironforge,18.10,51.60
.home >> Set your Hearthstone to Ironforge
.target Innkeeper Firebrew
step 
.isQuestTurnedIn 3701
.goto Ironforge,39.09,56.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Magni Bronzebeard|r
.accept 4341 >> Accept Kharan Mighthammer
.target King Magni Bronzebeard
step
.isQuestComplete 4513
.goto Ironforge,75.768,23.389
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Laris Geardawdle|r
.turnin 4513 >> Turn in A Little Slime Goes a Long Way
.target Laris Geardawdle
step
#completewith next
.subzone 131 >> Travel to Kharanos
step
#label HurleyBlackbreath
.goto Dun Morogh,46.825,52.361
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ragnar Thunderbrew|r
.accept 4126 >> Accept Hurley Blackbreath
.target Ragnar Thunderbrew
step
>>|cRXP_WARN_Fly to Lakeshire. Set your Hearthstone to Lakeshire ONLY if you have a Mage in your group for BRD, if not skip this step and leave your Hearth in Ironforge|r
.home >> Set your Hearthstone to Lakeshire
step
#completewith BSQuests
.fly Burning Steppes >> Fly to Burning Steppes from your nearest Flight Master
step
.goto Burning Steppes,84.555,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.accept 4286 >> Accept The Good Stuff
.target Oralius
step
.goto Burning Steppes,84.744,69.015
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Maxwell|r
>>|cRXP_WARN_If you cannot accept this quest complete the Dragonkin Menace quest chain|r
.accept 4241 >> Accept Marshal Windsor
.target Marshal Maxwell
step
.goto Burning Steppes,85.415,70.064
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.accept 4262 >> Accept Overmaster Pyron
.target Jalinda Sprig
step
.isQuestTurnedIn 3481
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
>>Select the option: "I present you with proof of my deeds, Cyrus."
.accept 4022 >> Accept A Taste of Flame
.turnin 4022 >> Turn in A Taste of Flame
.itemcount 10575,1 
.target Cyrus Therepentous
step
.isQuestAvailable 4022
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
>>If you are missing the |T134430:0|t[Black Dragonflight Molt] and cannot complete the quest, talk to |cRXP_FRIENDLY_Cyrus|r and select the option: "I do not possess any proof, Cyrus."
>>This will spawn a level 54 Elite Dragon at the entrance of the small cave. Ensure you have party members with you to help kill it, then loot it for the |T134430:0|t[Black Dragonflight Molt]
>>Select the option after: "I present you with proof of my deeds, Cyrus."
.collect 10575,1,4022,1 
.accept 4022 >> Accept A Taste of Flame
.turnin 4022 >> Turn in A Taste of Flame
.target Cyrus Therepentous
step
.isQuestTurnedIn 4022
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
.accept 4024 >> Accept A Taste of Flame
.target Cyrus Therepentous
step
.goto Burning Steppes,65.152,23.911
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.accept 4123 >> Accept The Heart of the Mountain
.target Maxwort Uberglint
step
#label BSQuests
.goto Burning Steppes,66.058,21.951
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yuka Screwspigot|r
.accept 4136 >> Accept Ribbly Screwspigot
.target Yuka Screwspigot
step
#softcoreserver
#softcore
+Die intentionally in the lava in Blackrock Mountain, ideally near the Molten Core entrance location
>>For this step you must be a |T132331:0|t[Ghost] to talk to |cRXP_FRIENDLY_Franclorn Forgewright|r inside Blackrock Mountain. Resurrect at your corpse once you have the quest
.goto 1415,48.624,64.186
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Franclorn Forgewright|r
.accept 3801 >> Accept Dark Iron Legacy
.turnin 3801 >> Turn in Dark Iron Legacy
.accept 3802 >> Accept Dark Iron Legacy
.target Franclorn Forgewright
step
#hardcoreserver
.goto 1415,48.656,64.134
.cast 417803 >>Click the |cRXP_PICK_Brazier of Embersight|r to gain the |T136215:0|t[Emberglow Vision] debuff
step
#hardcoreserver
.goto 1415,48.624,64.186
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Franclorn Forgewright|r
>>You must have the |T136215:0|t[Emberglow Vision] debuff to see him
.accept 3801 >> Accept Dark Iron Legacy
.turnin 3801 >> Turn in Dark Iron Legacy
.accept 3802 >> Accept Dark Iron Legacy
.target Franclorn Forgewright
step
#label AcceptBRDQuests
.goto 1415,48.409,63.815
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothos Riftwaker|r
.accept 7848 >> Accept Attunement to the Core
.target Lothos Riftwaker
step
.isOnQuest 4262
>>Kill |cRXP_ENEMY_Overmaster Pyron|r
>>|cRXP_ENEMY_Overmaster Pyron|r |cRXP_WARN_patrols outside of the BRD instance portal|r
.complete 4262,1 
.mob Overmaster Pyron
step
.subzone 1584,2 >>Enter Blackrock Depths
step
#completewith FannyPack
.isOnQuest 4286
>>Kill |cRXP_ENEMY_Dwarves|r inside of BRD. Loot them for their |cRXP_LOOT_Dark Iron Fanny Packs|r
.complete 4286,1 
step
.isOnQuest 4341
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kharan Mighthammer|r
>>If your group does not have a Rogue you may need to kill |cRXP_ENEMY_High Interrogator Gerstahn|r for the |cRXP_LOOT_Prison Cell Key|r to open the doors
.turnin 4341 >> Turn in Kharan Mighthammer
.accept 4342 >> Accept Kharan's Tale
step
.isQuestTurnedIn 4341
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kharan Mighthammer|r
.accept 4342 >> Accept Kharan's Tale
step
.isQuestTurnedIn 4341
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kharan Mighthammer|r
.complete 4342,1 
.skipgossip
step
.isQuestTurnedIn 4341
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kharan Mighthammer|r
.turnin 4342 >> Turn in Kharan's Tale
.accept 4361 >> Accept The Bearer of Bad News
step
.isOnQuest 4241
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Windsor|r
>>If your group does not have a Rogue you may need to kill |cRXP_ENEMY_High Interrogator Gerstahn|r for the |cRXP_LOOT_Prison Cell Key|r to open the doors
.turnin 4241 >> Turn in Marshal Windsor
.accept 4242 >> Accept Abandoned Hope
step
.isQuestTurnedIn 4241
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Windsor|r
.accept 4242 >> Accept Abandoned Hope
step
#completewith next
+Hearth to Ironforge if your Hearth was set there. If you have a Mage in group, kindly ask them for a portal to Ironforge
step
.isQuestTurnedIn 4341
.goto Ironforge,39.09,56.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Magni Bronzebeard|r
.turnin 4361 >> Turn in The Bearer of Bad News
.accept 4362 >> Accept The Fate of the Kingdom
.target King Magni Bronzebeard
step
#completewith PyronIncendius
>>Hearth to Lakeshire if your Hearth is set there. Otherwise fly to Burning Steppes manually
.fly Burning Steppes >> Fly to Burning Steppes
step
.isQuestComplete 4286
.goto Burning Steppes,84.555,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.turnin 4286 >> Turn in The Good Stuff
.target Oralius
step
.isOnQuest 4242
.goto Burning Steppes,84.744,69.015
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Maxwell|r
>>|cRXP_WARN_The quest chain will stop here until you find|r |T134331:0|t[A Crumpled Up Note] |cRXP_WARN_at BRD|r
.turnin 4242 >> Turn in Abandoned Hope
.target Marshal Maxwell
step
.isQuestComplete 4262
.goto Burning Steppes,85.415,70.064
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.turnin 4262 >> Turn in Overmaster Pyron
.accept 4263 >> Accept Incendius!
.target Jalinda Sprig
step
#label PyronIncendius
.isQuestTurnedIn 4262
.goto Burning Steppes,85.415,70.064
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.accept 4263 >> Accept Incendius!
.target Jalinda Sprig
step
.subzone 1584,2 >>Enter Blackrock Depths
step
#completewith next
+Complete the Ring of Law boss event, then take the exit up the tunnel and immediately turn right, crossing up over the top of the Ring of Law, making your way to the Vault
step
.isOnQuest 4123
>>Loot |cRXP_LOOT_The Heart of the Mountain|r inside of the safe wall. It takes 15 seconds for it to respawn
>>There is a trick which allows you to loot it without having to open the safe. View the link below to see how it is done
.complete 4123,1 
.link https://youtu.be/rg_UPmatbSw >> Click here to see how to loot the Heart of the Mountain
step
.isOnQuest 3802
>>Kill |cRXP_ENEMY_Fineous Darkvire|r. Loot him for the |cRXP_LOOT_Ironfel|r
.complete 3802,1 
step
.isOnQuest 4263
>>Kill |cRXP_ENEMY_Lord Incendius|r
.complete 4263,1 
step
.isQuestComplete 3802
>>Run back near the location above the Ring of Law
>>Click the |cRXP_PICK_Monument of Franclorn Forgewright|r
.turnin 3802 >> Turn in Dark Iron Legacy
step
.isOnQuest 4024
>>Head to the Shadowforge Gates at the start of the entrance
>>Kill |cRXP_ENEMY_Bael'Gar|r
.use 11231 >>|cRXP_WARN_Use the|r |T134430:0|t[Altered Black Dragonflight Molt] |cRXP_WARN_on his corpse|r
.complete 4024,1 
step
.isQuestTurnedIn 4242
>>Kill |cRXP_ENEMY_Dwarves|r at BRD. Loot them for |T134331:0|t[A Crumpled Up Note]
.use 11446 >> |cRXP_WARN_Use|r |T134331:0|t[A Crumpled Up Note] |cRXP_WARN_to start the quest|r
>>|cRXP_WARN_It is important you do this before killing bosses |cRXP_ENEMY_General Angerforge|r and|r |cRXP_ENEMY_Golem Lord Argelmach|r
>>|cRXP_WARN_If you still have not found this by now clear around the Detention Block until it drops|r
.collect 11446,1,4264,1 
.accept 4264 >> Accept A Crumpled Up Note
step
.isOnQuest 4264
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Windsor|r
.turnin 4264 >> Turn in A Crumpled Up Note
.accept 4282 >> Accept A Shred of Hope
step
.isQuestTurnedIn 4264
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Windsor|r
.accept 4282 >> Accept A Shred of Hope
step
.isOnQuest 4282
>>Kill |cRXP_ENEMY_General Angerforge|r and |cRXP_ENEMY_Golem Lord Argelmach|r. Loot them both for |cRXP_LOOT_Marshal Windsor's Lost Information|r
.complete 4282,1 
.complete 4282,2 
step
.isQuestTurnedIn 4264
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Windsor|r
>>|cRXP_WARN_ENSURE ALL PARTY MEMBERS HAVE AUTO ACCEPT OFF FOR THIS STEP! RestedXP HAS AUTO ACCEPT OFF FOR THIS STEP|r
>>|cRXP_WARN_Accepting this quest will begin the Jail Break escort. Ensure you have cleared all of the Detention Block area for an easier time escorting|r |cRXP_FRIENDLY_Marshal Windsor|r
.turnin 4282 >> Turn in A Shred of Hope
.accept 4322,1 >> Accept Jail Break!
step
.isOnQuest 4322
>>Escort |cRXP_FRIENDLY_Marshal Windsor|r through BRD
.complete 4322,1 
step
#completewith next
.isOnQuest 4126
>>Enter the Bar and go into the small room on the left. Do NOT attack any of the neutral mobs while running through the Bar
>>Click on the 3 |cRXP_PICK_Thunderbrew Lager Kegs|r to destroy them, forcing |cRXP_ENEMY_Hurley Blackbreath|r and his 3 |cRXP_ENEMY_Blackbreath Cronies|r to engage
>>Kill |cRXP_ENEMY_Hurley Blackbreath|r. Loot him for the |cRXP_LOOT_Lost Thunderbrew Recipe|r
.complete 4126,1 
step
.isOnQuest 4136
>>Enter the Bar and go into the small room on the left. Do NOT attack any of the neutral mobs while running through the Bar
>>Kill |cRXP_ENEMY_Ribbly Screwspigot|r. Loot him for his |cRXP_LOOT_Head|r
>>To engage |cRXP_ENEMY_Ribbly Screwspigot|r have your tank talk to him, then bring him back along with his |cRXP_ENEMY_Cronies|r into the room with the kegs
.complete 4136,1 
.skipgossip
step
.isOnQuest 4126
>>Enter the Bar and go into the small room on the left. Do NOT attack any of the neutral mobs while running through the Bar
>>Click on the 3 |cRXP_PICK_Thunderbrew Lager Kegs|r to destroy them, forcing |cRXP_ENEMY_Hurley Blackbreath|r and his 3 |cRXP_ENEMY_Blackbreath Cronies|r to engage
>>Kill |cRXP_ENEMY_Hurley Blackbreath|r. Loot him for the |cRXP_LOOT_Lost Thunderbrew Recipe|r
.complete 4126,1 
step
.isOnQuest 7848
>>Loot the |cRXP_LOOT_Core Fragment|r on the ground outside of the Molten Core instance portal
.complete 7848,1 
step
.isOnQuest 4362
>>Kill |cRXP_ENEMY_Emperor Dagran Thaurissan|r
>>|cRXP_WARN_You must NOT kill |cRXP_ENEMY_Princess Moira Bronzebeard|r in order to complete and turn in this quest|r
>>|cRXP_WARN_Have a party member kite |cRXP_ENEMY_Princess Moira Bronzebeard|r while the rest of the group kills|r |cRXP_ENEMY_Emperor Dagran Thaurissan|r
.complete 4362,1 
step
.isQuestComplete 4362
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Moira Bronzebeard|r
.turnin 4362 >> Turn in The Fate of the Kingdom
.accept 4363 >> Accept The Princess's Surprise
.target Princess Moira Bronzebeard
step
.isQuestTurnedIn 4362
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Moira Bronzebeard|r
.accept 4363 >> Accept The Princess's Surprise
.target Princess Moira Bronzebeard
step
#completewith HurleyTurnin
#label FannyPack
+Hearth to Ironforge if your Hearth was set there. If you have a Mage in group, kindly ask them for a portal to Ironforge
step
.isOnQuest 4363
.goto Ironforge,39.09,56.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Magni Bronzebeard|r
.turnin 4363 >> Turn in The Princess's Surprise
.target King Magni Bronzebeard
step
#completewith next
+Travel to Kharanos
step
#label HurleyTurnin
.isQuestComplete 4126
.goto Dun Morogh,46.825,52.361
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ragnar Thunderbrew|r
.turnin 4126 >> Turn in Hurley Blackbreath
.target Ragnar Thunderbrew
step
#completewith BSTurnins
>>Hearth to Lakeshire if your Hearth is set there. Otherwise fly to Burning Steppes manually
.fly Burning Steppes >> Fly to Burning Steppes
step
.isQuestComplete 4286
.goto Burning Steppes,84.555,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.turnin 4286 >> Turn in The Good Stuff
.target Oralius
step
.isQuestComplete 4322
.goto Burning Steppes,84.744,69.015
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Maxwell|r
.turnin 4322 >> Turn in Jail Break!
.accept 6402 >> Accept Stormwind Rendezvous
.target Marshal Maxwell
step
.isQuestTurnedIn 4322
.goto Burning Steppes,84.744,69.015
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Maxwell|r
.accept 6402 >> Accept Stormwind Rendezvous
.target Marshal Maxwell
step
.isQuestComplete 4263
.goto Burning Steppes,85.415,70.064
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.turnin 4263 >> Turn in Incendius!
.target Jalinda Sprig
step
.isQuestComplete 4024
.goto Burning Steppes,95.061,31.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus Therepentous|r
.turnin 4024 >> Turn in A Taste of Flame
.target Cyrus Therepentous
step
.isQuestComplete 4123
.goto Burning Steppes,65.152,23.911
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.turnin 4123 >> Turn in The Heart of the Mountain
.target Maxwort Uberglint
step
#label BSTurnins
.isQuestComplete 4136
.goto Burning Steppes,66.058,21.951
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yuka Screwspigot|r
.turnin 4136 >> Turn in Ribbly Screwspigot
.target Yuka Screwspigot
step
.isQuestTurnedIn 4322
.goto Burning Steppes,84.334,68.326
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgun Stoutarm|r
>>Have a Mage port you if you have one in your group
.fly Stormwind >> Fly to Stormwind
.target Borgun Stoutarm
.zoneskip Stormwind City
step
.isQuestTurnedIn 4322
#completewith next
.goto StormwindClassic,70.424,85.171,5,0
.goto StormwindClassic,69.709,86.083
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Squire Rowe|r and |cRXP_FRIENDLY_Reginald Windsor|r
>>|cRXP_FRIENDLY_Squire Rowe|r will call for |cRXP_FRIENDLY_Reginald Windsor's|r arrival after you talk to him at the Gates of Stormwind
>>|cRXP_WARN_IF YOU ARE IN A PARTY ENSURE NO ONE AUTO ACCEPTS The Great Masquerade. AUTO ACCEPT HAS BEEN TURNED OFF FOR THIS STEP|r
.turnin 6402 >> Turn in Stormwind Rendezvous
.accept 6403,1 >> Accept The Great Masquerade
.skipgossip
.target Squire Rowe
.target Reginald Windsor
step
.isQuestTurnedIn 4322
.goto StormwindClassic,75.955,19.114,-1
.goto StormwindClassic,76.865,20.830,-1
>>Escort |cRXP_FRIENDLY_Reginald Windsor|r into Stormwind Keep
>>Do not assist |cRXP_FRIENDLY_Reginald Windsor|r in combat while inside the Keep. If you do so there is a high chance you may die. Stay back at the arrow location and let the event finish on its own. It will take a few minutes
.complete 6403,1 
.target Reginald Windsor
step
.isQuestComplete 6403
.goto StormwindClassic,77.569,18.864
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Highlord Bolvar Fordragon|r
.turnin 6403 >> Turn in The Great Masquerade
.accept 6501 >> Accept The Dragon's Eye
.target Highlord Bolvar Fordragon
step
.isQuestComplete 7848
.goto 1415,48.409,63.815
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lothos Riftwaker|r
>>|cRXP_WARN_You can either turn this in now or the next time you are in Blackrock Mountain|r
.turnin 7848 >> Turn in Attunement to the Core
.target Lothos Riftwaker
step
+|cRXP_WARN_You have completed the Blackrock Depths quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 14. Lower Blackrock Spire
step
#completewith BurningAccept
+Start looking for a group for LBRS as you acquire all of the quests
step
#optional
#completewith next
.zone Tanaris >> Travel to Tanaris
step
#optional
.isQuestTurnedIn 5065
.goto Tanaris,66.88,24.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ironboot|r
.accept 4788 >> Accept The Final Tablets
.target Prospector Ironboot
step
#completewith next
.zone Burning Steppes >> Travel to Burning Steppes
step
.goto Burning Steppes,85.820,68.948
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Helendis Riverhorn|r
.accept 4701 >> Accept Put Her Down
.target Helendis Riverhorn
step
.goto Burning Steppes,65.8,22.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kibler|r
.accept 4862 >> Accept En-Ay-Es-Tee-Why
.accept 4729 >> Accept Kibler's Exotic Pets
.target Kibler
step
#completewith Bijou
.subzone 254 >>Travel to Blackrock Mountain
step
.goto Eastern Kingdoms,48.95,63.89
.subzone 1583 >>Enter Blackrock Spire
step
#completewith Bijou
+Talk to |cRXP_FRIENDLY_Warosh|r and |cRXP_FRIENDLY_Bijou|r inside Lower Blackrock Spire
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
.accept 4867 >>Accept Urok Doomhowl
.target Warosh
step
#label Bijou
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
.accept 5001 >>Accept Bijou's Belongings
.target Bijou
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
.accept 4867 >>Accept Urok Doomhowl
.target Warosh
step
#optional
#sticky
.isOnQuest 4788
>>Loot the |cRXP_PICK_Fifth Mosh'aru Tablet|r behind |cRXP_ENEMY_Shadow Hunter Vosh'gajin|r
>>Loot the |cRXP_PICK_Sixth Mosh'aru Tablet|r behind |cRXP_ENEMY_War Master Voone|r
.complete 4788,1 
.complete 4788,2 
step
#sticky
>>Loot |cRXP_PICK_Bijou's Belongings|r on the ground
>>|cRXP_WARN_This is a box found in a random location in LBRS. It is generally found amongst the |cRXP_ENEMY_Trolls|r or |cRXP_ENEMY_Orcs|r on the way to |cRXP_ENEMY_Mother Smolderweb|r|r
.complete 5001,1 
step
>>Loot a |T135124:0|t[|cRXP_PICK_Roughshod Pike|r] on the left hand side after crossing 2 bridges. This is used for summoning and killing |cRXP_ENEMY_Urok Doomhowl|r later
.collect 12533,1,4867,1 
step
.use 12533 >>|cRXP_WARN_Use the|r |T135124:0|t[|cRXP_PICK_Roughshod Pike|r] |cRXP_WARN_at the |cRXP_PICK_Challege to Urok|r (Skull pile) to begin the encounter|r
>>Kill the |cRXP_ENEMY_Ogre|r waves, then finally |cRXP_ENEMY_Urok Doomhowl|r. Loot him for |cRXP_LOOT_Warosh's Mojo|r
.complete 4867,1 
step
>>Kill |cRXP_ENEMY_Halycon|r
.complete 4701,1 
step
>>Kill |cRXP_ENEMY_Mother Smolderweb|r then loot the |cRXP_PICK_Spire Spider Eggs|r in the area
>>|cRXP_WARN_Note these can spawn small|r |cRXP_ENEMY_Spiderlings|r
.complete 4862,1 
step
.use 12262 >> |cRXP_WARN_Use the|r |T132599:0|t[Empty Worg Pup Cage] on the pups around |cRXP_ENEMY_Halcyon|r. Ensure to do this before you're group kills them all
.complete 4729,1 
step
>>Kill |cRXP_ENEMY_Overlord Wyrmthalak|r. Loot him for |T133473:0|t[|cRXP_LOOT_General Drakkisath's Command|r]
.use 12780 >> |cRXP_WARN_Use|r |T133473:0|t[|cRXP_LOOT_General Drakkisath's Command|r] |cRXP_WARN_to start the quest|r
.collect 12780,1,5089,1 
.accept 5089 >> Accept General Drakkisath's Command
step
.isQuestComplete 5001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
.turnin 5001 >>Turn in Bijou's Belongings
.accept 5002 >>Accept Message to Maxwell
.target Bijou
step
.isQuestTurnedIn 5001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
.accept 5002 >>Accept Message to Maxwell
.target Bijou
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bijou|r
.turnin 4867 >>Turn in Urok Doomhowl
.target Warosh
step
#completewith BSTurnins
.zone Burning Steppes >> Travel to Burning Steppes
step
.goto Burning Steppes,85.820,68.948
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Helendis Riverhorn|r
.turnin 4701 >> Turn in Put Her Down
.target Helendis Riverhorn
step
.goto Burning Steppes,65.8,22.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kibler|r
.turnin 4862 >> Turn in En-Ay-Es-Tee-Why
.turnin 4729 >> Turn in Kibler's Exotic Pets
.target Kibler
step
#label BSTurnins
.goto Burning Steppes,84.744,69.015
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Maxwell|r
.turnin 6402 >> Turn in Message to Maxwell
.turnin 5089 >> Turn in General Drakkisath's Command
.target Marshal Maxwell
step
#optional
#completewith next
.zone Tanaris >> Travel to Tanaris
step
#optional
.isQuestComplete 4788
.goto Tanaris,66.88,24.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ironboot|r
.turnin 4788 >> Turn in The Final Tablets
.accept 8181 >> Accept Confront Yeh'kinya
.target Prospector Ironboot
step
#optional
.isQuestTurnedIn 4788
.goto Tanaris,66.88,24.03
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prospector Ironboot|r
.accept 8181 >> Accept Confront Yeh'kinya
.target Prospector Ironboot
step
#optional
.isOnQuest 8181
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 8181 >> Turn in Confront Yeh'kinya
.target Yeh'kinya
step
+|cRXP_WARN_You have completed the Lower Blackrock Spire quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 15. Upper Blackrock Spire
step
#completewith StartDungeon
.subzone 1583,2 >>|cRXP_WARN_This is a 10-man dungeon. You or somebody in your party must have the|r |T133343:0|t[|cRXP_LOOT_Seal of Ascension|r] |cRXP_WARN_to be able to enter Upper Blackrock Spire|r
step
#completewith next
.zone Azshara >>Travel to Azshara
step
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
>>|cRXP_WARN_These are prerequisite quests completed in Eastern Plaguelands and Silithus to unlock a quest in UBRS. Feel free to skip this|r
.accept 6804 >>Accept Poisoned Water
.accept 6805 >>Accept Stormers and Rumblers
.target Duke Hydraxis
step
#completewith next
.zone Silithus >>Travel to Silithus
step
>>Kill |cRXP_ENEMY_Dust Stormers|r and |cRXP_ENEMY_Desert Rumblers|r
.complete 6805,1 
.mob +Desert Rumbler
.goto Silithus,33.13,14.98,60,0
.goto Silithus,29.75,16.66,60,0
.goto Silithus,30.33,20.83,60,0
.goto Silithus,23.19,27.97,60,0
.goto Silithus,20.41,33.38,60,0
.goto Silithus,18.09,26.65,60,0
.goto Silithus,21.09,22.33,60,0
.goto Silithus,33.13,14.98,60,0
.goto Silithus,29.75,16.66,60,0
.goto Silithus,30.33,20.83,60,0
.goto Silithus,23.19,27.97,60,0
.goto Silithus,20.41,33.38,60,0
.goto Silithus,18.09,26.65,60,0
.goto Silithus,21.09,22.33
.complete 6805,2 
.mob +Dust Stormer
.goto Silithus,21.61,17.09,50,0
.goto Silithus,21.67,9.37,50,0
.goto Silithus,27.63,14.28,50,0
.goto Silithus,24.12,14.81,50,0
.goto Silithus,21.61,17.09,50,0
.goto Silithus,21.67,9.37,50,0
.goto Silithus,27.63,14.28,50,0
.goto Silithus,24.12,14.81
.isOnQuest 6805
step
#completewith next
.zone Eastern Plaguelands >>Travel to Eastern Plaguelands
step
#loop
.goto Eastern Plaguelands,71.34,34.07,0
.goto Eastern Plaguelands,51.36,49.77,0
.goto Eastern Plaguelands,64.58,80.71,0
.goto Eastern Plaguelands,59.71,79.12,0
.goto Eastern Plaguelands,64.58,80.71,50,0
.goto Eastern Plaguelands,59.71,79.12,50,0
>>Kill |cRXP_ENEMY_Water Elementals|r. Loot them for their |cRXP_LOOT_Discordant Bracers|r
>>|cRXP_WARN_They can be killed in three different locations in EPL. They are marked on your map|r
.complete 6804,1 
.mob Blighted Horror
.mob Plague Monstrosity
.mob Blighted Surge
.mob Plague Ravager
.isOnQuest 6804
step
#completewith EyeofEmber
.zone Azshara >>Travel to Azshara
step
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.turnin 6804 >>Turn in Poisoned Water
.turnin 6805 >>Turn in Stormers and Rumblers
.accept 6821 >>Accept Eye of the Emberseer
.target Duke Hydraxis
.isQuestComplete 6804
.isQuestComplete 6805
step
#optional
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.turnin 6805 >>Turn in Stormers and Rumblers
.target Duke Hydraxis
.isQuestComplete 6805
step
#optional
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.turnin 6804 >>Turn in Poisoned Water
.target Duke Hydraxis
.isQuestComplete 6804
step
#label EyeofEmber
#optional
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.accept 6821 >>Accept Eye of the Emberseer
.target Duke Hydraxis
.isQuestTurnedIn 6804
.isQuestTurnedIn 6805
step
#completewith EggFreezeAccept
.zone Burning Steppes >> Travel to Burning Steppes
step
.goto Burning Steppes,84.8,69.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayara Brightwing|r
.accept 4764 >> Accept Doomrigger's Clasp
.target Mayara Brightwing
step
.isQuestTurnedIn 5089
.goto Burning Steppes,84.744,69.015
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Maxwell|r
.accept 5102 >> Accept General Drakkisath's Demise
.target Marshal Maxwell
step
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.accept 4734 >>Accept Egg Freezing
.target Tinkee Steamboil
step
#label EggFreezeAccept
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.accept 4735 >>Accept Egg Collection
.target Tinkee Steamboil
.isQuestTurnedIn 4734
step
#completewith StartDungeon
.subzone 254 >>Travel to Blackrock Mountain
step << !tbc !wotlk
#hardcore
.goto Eastern Kingdoms,48.94,63.92,10,0
.goto Eastern Kingdoms,49.01,64.12,10,0
.goto Eastern Kingdoms,49.12,64.09
.use 18987 >>Kill the |cRXP_ENEMY_Scarshield Quartermaster|r. Loot him for |T133473:0|t[|cRXP_LOOT_Blackhand's Command|r]. Use it to accept the quest
>>|cRXP_WARN_This is a strong level 55 elite. Do this with a group for safety|r
>>|cRXP_WARN_He is located in the hallway to the right of the Blackrock Spire instance portal|r
.collect 18987,1,7761 
.accept 7761 >>Accept Blackhand's Command
.unitscan Scarshield Quartermaster
step << !tbc !wotlk
#softcore
.goto Eastern Kingdoms,48.94,63.92,10,0
.goto Eastern Kingdoms,49.01,64.12,10,0
.goto Eastern Kingdoms,49.12,64.09
.use 18987 >>Kill the |cRXP_ENEMY_Scarshield Quartermaster|r. Loot him for |T133473:0|t[|cRXP_LOOT_Blackhand's Command|r]. Use it to accept the quest
>>|cRXP_WARN_He is located in the hallway to the right of the Blackrock Spire instance portal|r
.collect 18987,1,7761 
.accept 7761 >>Accept Blackhand's Command
.unitscan Scarshield Quartermaster
step << tbc/wotlk
.goto Eastern Kingdoms,48.94,63.92,10,0
.goto Eastern Kingdoms,49.01,64.12,10,0
.goto Eastern Kingdoms,49.12,64.09
.use 18987 >>Kill the |cRXP_ENEMY_Scarshield Quartermaster|r. Loot him for |T133473:0|t[|cRXP_LOOT_Blackhand's Command|r]. Use it to accept the quest
>>|cRXP_WARN_He is located in the hallway to the right of the Blackrock Spire instance portal|r
.collect 18987,1,7761 
.accept 7761 >>Accept Blackhand's Command
.unitscan Scarshield Quartermaster
step
#label StartDungeon
.subzone 1583,2 >>Enter Blackrock Spire
step
>>Kill |cRXP_ENEMY_Pyroguard Emberseer|r. Loot him for the |cRXP_LOOT_Eye of the Emberseer|r
.complete 6821,1 
.mob Pyroguard Emberseer
.isOnQuest 6821
step
.use 12286 >>|cRXP_WARN_Use the|r |T133003:0|t[Eggscilliscope Prototype] |cRXP_WARN_on one of the eggs in The Rookery to freeze it|r
.complete 4734,1 
.isOnQuest 4734
step
>>Click |cRXP_PICK_Drakkisath's Brand|r in the final room of Upper Blackrock Spire behind |cRXP_ENEMY_General Drakkisath|r
.turnin 7761 >>Turn in Blackhand's Command
.isOnQuest 7761
step
#completewith EggFreeze
+|cRXP_WARN_Stay in your raid group! The follow-up quest of Egg Freezing can be quickly completed inside the cleared instance|r
step
#completewith EggCollectAccept
.zone Burning Steppes >>Travel to Burning Steppes
step
#label EggFreeze
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.turnin 4734 >>Turn in Egg Freezing
.accept 4735 >>Accept Egg Collection
.target Tinkee Steamboil
.isQuestComplete 4734
step
#label EggCollectAccept
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.accept 4735 >>Accept Egg Collection
.target Tinkee Steamboil
.isQuestTurnedIn 4734
step
#completewith next
.subzone 254 >>Travel to Blackrock Mountain
step
#completewith next
.goto Eastern Kingdoms,48.95,63.89
.subzone 1583 >>Enter Blackrock Spire
step
>>Enter the rookery and use the |T133003:0|t[Eggscilliscope] on one of the eggs to freeze it. Then use the |T133014:0|t[Collectronic Module] to collect it
.complete 4735,1 
.use 12144 
.use 12287 
.isOnQuest 4735
step
#completewith next
.zone Burning Steppes >>Travel to Burning Steppes
step
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r
.turnin 4735 >>Turn in Egg Collection
.target Tinkee Steamboil
.isQuestComplete 4735
step
.goto Burning Steppes,84.8,69.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mayara Brightwing|r
.turnin 4764 >> Turn in Doomrigger's Clasp
.accept 4765 >> Accept Delivery to Ridgewell
.target Mayara Brightwing
step
.isQuestComplete 5102
.goto Burning Steppes,84.744,69.015
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Maxwell|r
.turnin 5102 >> Turn in General Drakkisath's Demise
.target Marshal Maxwell
step
#completewith next
.zone Stormwind City >> Travel to Stormwind
step
.isOnQuest 4765
.goto StormwindClassic,74.010,30.231
.target Count Remington Ridgewell
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Count Remington Ridgewell|r
.turnin 4765 >> Turn in Delivery to Ridgewell
step
#completewith next
.zone Azshara >>Travel to Azshara
step
.goto Azshara,79.28,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Hydraxis|r
.turnin 6821 >>Turn in Eye of the Emberseer
.target Duke Hydraxis
step
+|cRXP_WARN_You have completed the Upper Blackrock Spire quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 16. Scholomance
step
#completewith EnterScholo
+|cRXP_WARN_You will now be directed to pick up all available quests for Scholomance|r
step
#completewith EnterScholo
+|cRXP_WARN_You or somebody in your party must have the|r |T13704:0|t[Skeleton Key] |cRXP_WARN_to enter Scholomance (a Rogue with 300 lockpicking can also open the door)|r
>>|cRXP_WARN_Select the "Scholomance Key" guide if you wish to obtain it|r
.itemcount 13704,<1
step
#completewith next
.subzone 2268 >>Travel to Light's Hope Chapel in Eastern Plaguelands
step
.goto Eastern Plaguelands,81.47,59.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.accept 5529 >>Accept Plagued Hatchlings
.target Betina Bigglezink
step
.goto Eastern Plaguelands,81.627,58.077
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessica Chambers|r
.home >>Set your Hearthstone to Light's Hope Chapel
.target Jessica Chambers
.subzoneskip 2268,1
.bindlocation 2268
step
#completewith next
.zone Western Plaguelands >>Travel to Western Plaguelands
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Weldon Barov|r
.accept 5343 >> Accept Barov Family Fortune
.goto Western Plaguelands,43.4,83.6
.target Weldon Barov
step
#completewith EnterScholo
.subzone 2298 >>Travel to the Scholomance entrance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
>>|cRXP_WARN_She is located right outside Scholomance|r
>>|cRXP_WARN_This quest chain will require you to run in and out of Scholomance multiple times|r
.accept 5382 >>Accept Doctor Theolen Krastinov, the Butcher
.target Eva Sarkhoff
.skipgossip
step
#label EnterScholo
.subzone 2057 >>Enter Scholomance
step
#completewith Hatchlings
>>Loot the |cRXP_PICK_Deeds|r throughout Scholomance
>>|cRXP_PICK_The Deed to Southshore|r |cRXP_WARN_is located in the large room right after the bridge as you enter the dungeon. It's in the left corner next to a bookshelf on top of a desk|r
.complete 5341,3
>>|cRXP_PICK_The Deed to Tarren Mill|r |cRXP_WARN_is located on the desk in the right corner of the large room downstairs before the room filled with whelpes|r
.complete 5341,4
>>|cRXP_PICK_The Deed to Brill|r |cRXP_WARN_is located in |cRXP_ENEMY_Ras Frostwhisper's|r room on a table to the right side|r
.complete 5341,1
>>|cRXP_PICK_The Deed to Caer Darrow|r |cRXP_WARN_is located behind |cRXP_ENEMY_Lord Alexei Barov|r in the boss gauntlet in |cRXP_ENEMY_Grandmaster Gandling's|r room|r
.complete 5341,2
.isOnQuest 5341
step
#completewith Kirtonos
>>Kill |cRXP_ENEMY_Plagued Hatchlings|r. Loot them for a |T134319:0|t[|cRXP_LOOT_Healthy Dragon Scale|r]. Use it to accept the quest
.collect 13920,1,5582 
.accept 5582 >>Accept Healthy Dragon Scale
.complete 5529,1 
.isOnQuest 5529
step
>>Kill |cRXP_ENEMY_Doctor Theolen Krastinov|r in the boss gauntlet in |cRXP_ENEMY_Grandmaster Gandling's|r room
>>Click on the |cRXP_PICK_Remains of Eva Sarkhoff|r and |cRXP_PICK_Remains of Lucien Sarkhoff|r to burn them
>>|cRXP_WARN_They look like piles of flesh and are located in |cRXP_ENEMY_Krastinov's|r room|r
.complete 5382,1 
.complete 5382,2 
.complete 5382,3 
.mob Doctor Theolen Krastinov
.isOnQuest 5382
step
#completewith next
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Eva Sarkhoff|r outside the instance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.turnin 5382 >>Turn in Doctor Theolen Krastinov, the Butcher
.accept 5515 >>Accept Krastinov's Bag of Horrors
.isQuestComplete 5382
.target Eva Sarkhoff
step
#optional
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.accept 5515 >>Accept Krastinov's Bag of Horrors
.target Eva Sarkhoff
.isQuestTurnedIn 5382
step
>>Kill |cRXP_ENEMY_Jandice Barov|r. Loot her for |T133648:0|t[|cRXP_LOOT_Krastinov's Bag of Horrors|r]
.complete 5515,1 
.isOnQuest 5515
.mob Jandice Barov
step
#completewith next
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Eva Sarkhoff|r outside the instance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.turnin 5515 >>Turn in Krastinov's Bag of Horrors
.accept 5384 >>Accept Kirtonos the Herald
.isQuestComplete 5515
.target Eva Sarkhoff
step
#optional
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.accept 5515 >>Accept Kirtonos the Herald
.isQuestTurnedIn 5384
.target Eva Sarkhoff
step
#label Kirtonos
>>|cRXP_WARN_Use the|r |T134804:0|t[Blood of Innocents] |cRXP_WARN_on the |cRXP_PICK_Brazier of the Herald|r on the balcony in the second room|r
>>Kill |cRXP_ENEMY_Kirtonos the Herald|r as he spawns
.complete 5384,1 
.mob Kirtonos the Herald
.isOnQuest 5384
step
#label Hatchlings
>>Kill |cRXP_ENEMY_Plagued Hatchlings|r. Loot them for a |T134319:0|t[|cRXP_LOOT_Healthy Dragon Scale|r]. Use it to accept the quest
.collect 13920,1,5582 
.accept 5582 >>Accept Healthy Dragon Scale
.complete 5529,1 
.isOnQuest 5529
step
>>Loot the |cRXP_PICK_Deeds|r throughout Scholomance
>>|cRXP_PICK_The Deed to Southshore|r |cRXP_WARN_is located in the large room right after the bridge as you enter the dungeon. It's in the left corner next to a bookshelf on top of a desk|r
.complete 5341,3
>>|cRXP_PICK_The Deed to Tarren Mill|r |cRXP_WARN_is located on the desk in the right corner of the large room downstairs before the room filled with whelpes|r
.complete 5341,4
>>|cRXP_PICK_The Deed to Brill|r |cRXP_WARN_is located in |cRXP_ENEMY_Ras Frostwhisper's|r room on a table to the right side|r
.complete 5341,1
>>|cRXP_PICK_The Deed to Caer Darrow|r |cRXP_WARN_is located behind |cRXP_ENEMY_Lord Alexei Barov|r in the boss gauntlet in |cRXP_ENEMY_Grandmaster Gandling's|r room|r
.complete 5341,2
.isOnQuest 5341
step
#completewith next
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Eva Sarkhoff|r outside the instance
step
.goto Western Plaguelands,70.22,73.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eva Sarkhoff|r
.turnin 5384 >>Turn in Kirtonos the Herald
.isQuestComplete 5384
.target Eva Sarkhoff
step
#completewith next
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5461 >>Accept The Human, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5384
.use 13544
step
#optional
#completewith RichRas
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
#optional
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5465 >>Turn in Soulbound Keepsake
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isOnQuest 5465
.use 13544
step
#optional
#label RichRas
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5465
.use 13544
step
#optional
.use 13752>>|cRXP_WARN_Use the|r |T133736:0|t[Soulbound Keepsake] |cRXP_WARN_on|r |cRXP_ENEMY_Ras Frostwhisper|r
>>Kill |cRXP_ENEMY_Ras Frostwhisper|r inside Scholomance. Loot him for his |cRXP_LOOT_Head|r
.complete 5466,1 
.mob Ras Frostwhisper
.isOnQuest 5466
step
#optional
#completewith RichRas2
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Magistrate Marduke|r outside the instance
step
#optional
#completewith RichRas2
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
#optional
#label RichRas2
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5466 >>Turn in The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestComplete 5466
.use 13544
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Weldon Barov|r
.accept 5343 >> Accept Barov Family Fortune
.goto Western Plaguelands,43.4,83.6
.target Weldon Barov
step
#completewith HatchlingsTurnin
.hs >>Hearth to Light's Hope Chapel
.bindlocation 2268,1
.subzoneskip 2268
.use 6948
.cooldown item,6948,>0,1
step
#completewith HatchlingsTurnin
.subzone 2268 >>Travel to Light's Hope Chapel in Eastern Plaguelands
step
#label HatchlingsTurnin
.goto Eastern Plaguelands,81.47,59.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.turnin 5529 >>Turn in Plagued Hatchlings
.target Betina Bigglezink
.isQuestComplete 5529
step
+|cRXP_WARN_Select the "Stratholme guide" in order to continue with the quest chain of "The Human, Ras Frostwhisper"|r
.isOnQuest 5461
step
+|cRXP_WARN_You have completed the Scholomance quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 17. Stratholme
step
#optional
+|cRXP_WARN_It is recommended to run Scholomance first to begin the quest chain "Doctor Theolen Krastinov, the Butcher" that will send you to Stratholme afterwards|r
.isQuestAvailable 5384
step
#completewith next
.subzone 324 >>Travel to Stromgarde Keep in Arathi Highlands
step
#loop
.goto Arathi Highlands,28.26,62.33,0
.goto Arathi Highlands,28.26,62.33,30,0
.goto Arathi Highlands,21.40,60.08,30,0
.goto Arathi Highlands,20.86,69.04,30,0
.goto Arathi Highlands,18.21,68.45,30,0
>>Loot the |cRXP_PICK_Keepsake of Remembrance|r in Stromgarde Keep
>>|cRXP_WARN_It is a little red book which can be located in any of the fireplaces inside the keep. Also check the Ogre Tower and the intact houses|r
.complete 5461,1 
.isOnQuest 5461
step
#completewith LoveandFam
.zone Western Plaguelands >>Travel to Western Plaguelands
step
#completewith DyingRas
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5461 >>Turn in The Human, Ras Frostwhisper
.accept 5462 >>Accept The Dying, Ras Frostwhisper
.target Magistrate Marduke
.isQuestComplete 5461
.use 13544
step
#optional
#label DyingRas
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5462 >>Accept The Dying, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5461
.use 13544
step
.goto Western Plaguelands,65.7,75.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Artist Renfray|r
.turnin 5846 >>Turn in Of Love and Family
.accept 5848 >>Accept Of Love and Family
.target Artist Renfray
.isQuestComplete 5846
step
#label LoveandFam
#optional
.goto Western Plaguelands,65.7,75.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Artist Renfray|r
.accept 5848 >>Accept Of Love and Family
.target Artist Renfray
.isQuestTurnedIn 5846
step
#completewith LHCpickups
.subzone 2268 >>Travel to Light's Hope Chapel
step
.goto Eastern Plaguelands,79.60,63.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alen|r
.accept 5281 >>Accept The Restless Souls
.target Caretaker Alen
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.accept 5251 >>Accept The Archivist
.target Duke Nicholas Zverenhoff
step
.goto Eastern Plaguelands,81.47,59.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.accept 5212 >>Accept The Flesh Does Not Lie
.target Betina Bigglezink
step
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.turnin 5462 >>Turn in The Dying, Ras Frostwhisper
.accept 5463 >>Accept Menethil's Gift
.target Leonid Barthalomew the Revered
.isQuestComplete 5462
step
#optional
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.accept 5463 >>Accept Menethil's Gift
.target Leonid Barthalomew the Revered
.isQuestTurnedIn 5462
step
.goto Eastern Plaguelands,80.605,57.979
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey LaRue|r
.accept 5214 >>Accept The Great Ezra Grimm
.target Smokey LaRue
step
#label LHCpickups
.goto Eastern Plaguelands,81.627,58.077
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessica Chambers|r
.home >>Set your Hearthstone to Light's Hope Chapel
.target Jessica Chambers
.subzoneskip 2268,1
.bindlocation 2268
step
#completewith RestlessSouls
.subzone 2627 >>Travel to Terrordale
step
.goto Eastern Plaguelands,14.45,33.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Egan|r
.turnin 5281 >>Turn in The Restless Souls
.accept 5282 >>Accept The Restless Souls
.target Egan
.isOnQuest 5281
step
#label RestlessSouls
#optional
.goto Eastern Plaguelands,14.45,33.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Egan|r
.accept 5282 >>Accept The Restless Souls
.target Egan
.isQuestTurnedIn 5281
step
#label EnterLiving
.goto Eastern Kingdoms,52.96,28.67
.subzone 2279,2 >>Enter Stratholme
step
#completewith RivenDare
>>Loot |T132761:0|t[|cRXP_PICK_Supply Crates|r] scattered around the instance. Loot them for |T134855:0|t[|cRXP_LOOT_Stratholme Holy Water|r]
>>Some of the crates are traps and contain poison or hostile bugs inside
>>|cRXP_WARN_If careful you can tell them apart as when you move close to a trapped crate "disarm trap" will appear on the tooltip|r
.collect 13180,5,5243,1 
step
#completewith HolyWater
.use 13289 >>|cRXP_WARN_Use|r |T135614:0|t[Egan's Blaster] |cRXP_WARN_on|r |cRXP_ENEMY_Spectral Citizens|r |cRXP_WARN_and|r |cRXP_ENEMY_Ghostly Citizen|r.
>>|cRXP_ENEMY_Restless Souls|r |cRXP_WARN_will appear. Use it on them too|r
.complete 5282,1 
.mob Spectral Citizen
.mob Ghostly Citizen
.mob Restless Soul
.isOnQuest 5282
step
>>Take a left into the alleyway coming from the entrance of the living side
>>|cRXP_WARN_Click on the|r |T132761:0|t[|cRXP_PICK_Premium Grimm Tobacco|r] |cRXP_WARN_box on the ground at the end of it|r
>>|cRXP_ENEMY_Ezra Grim|r will spawn. Kill him and loot him for |cRXP_LOOT_Grimm's Premium Tobacco|r
>>|cRXP_WARN_Be careful as he will aggro every |cRXP_ENEMY_Undead|r in an extremely large radius|r
.complete 5214,1 
.mob Ezra Grim
.isOnQuest 5214
step
>>Kill |cRXP_ENEMY_Archivist Galford|r. Click the |cRXP_PICK_Scarlet Archive|r on the table
.complete 5251,1 
.complete 5251,2 
.mob Archivist Galford
.isOnQuest 5251
step
>>Loot the |cRXP_PICK_painting|r on the wall in |cRXP_ENEMY_Archivist Galford's|r room
.complete 5848,1 
.isOnQuest 5848
step
#completewith next
+|cRXP_WARN_If possible, return to Light's Hope Chapel now to turn in "The Archivist" BEFORE killing |cRXP_ENEMY_Grand Crusader Dathrohan|r |cRXP_ENEMY_(Balnazzar)|r as this will allow you to loot|r |T136183:0|t[|cRXP_LOOT_Head of Balnazzar|r]
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
>>|cRXP_WARN_Skip this step if you do not wish to do this now|r
.turnin 5251 >>Turn in The Archivist
.target Duke Nicholas Zverenhoff
step
>>Kill |cRXP_ENEMY_Grand Crusader Dathrohan|r |cRXP_ENEMY_(Balnazzar)|r. Loot him for |T136183:0|t[|cRXP_LOOT_Head of Balnazzar|r]. Use it to start the quest
.collect 13250,1,5262 
.accept 5262 >>Accept The Truth Comes Crashing Down
.mob Grand Crusader Dathrohan
.mob Balnazzar
.isQuestTurnedIn 5251
step
#completewith next
+|cRXP_WARN_If possible, return to Light's Hope Chapel once more to get the follow-up quest to kill |cRXP_ENEMY_Baron Rivendare|r
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
>>|cRXP_WARN_Skip this step if you do not wish to do this now|r
.turnin 5262 >>Turn in The Truth Comes Crashing Down
.accept 5263 >>Accept in Above and Beyond
.target Duke Nicholas Zverenhoff
step
#completewith Souls2
>>Kill |cRXP_ENEMY_Undead|r. Loot them for their |T134358:0|t[|cRXP_LOOT_Plagued Flesh Samples|r]
.complete 5212,1 
.isOnQuest 5212
step
>>Kill |cRXP_ENEMY_Baron Rivendare|r. Loot him for his |cRXP_ENEMY_Head|r
.complete 5263,1 
.mob Baron Rivendare
.isOnQuest 5263
step
#label RivenDare
>>Kill |cRXP_ENEMY_Baron Rivendare|r. Afterwards, click |cRXP_FRIENDLY_Menethil's Gift|r in the orange circle on the ground
.turnin 5463 >>Turn in Menethil's Gift
.accept 5464 >>Accept Menethil's Gift
.mob Baron Rivendare
step
#label HolyWater
>>Loot |T132761:0|t[|cRXP_PICK_Supply Crates|r] scattered around the instance. Loot them for |T134855:0|t[|cRXP_LOOT_Stratholme Holy Water|r]
>>Some of the crates are traps and contain poison or hostile bugs inside
>>|cRXP_WARN_If careful you can tell them apart as when you move close to a trapped crate "disarm trap" will appear on the tooltip|r
.collect 13180,5,5243,1 
step
#label Souls2
.use 13289 >>|cRXP_WARN_Use|r |T135614:0|t[Egan's Blaster] |cRXP_WARN_on|r |cRXP_ENEMY_Spectral Citizens|r |cRXP_WARN_and|r |cRXP_ENEMY_Ghostly Citizen|r.
>>|cRXP_ENEMY_Restless Souls|r |cRXP_WARN_will appear. Use it on them too|r
.complete 5282,1 
.mob Spectral Citizen
.mob Ghostly Citizen
.mob Restless Soul
.isOnQuest 5282
step
>>Kill |cRXP_ENEMY_Undead|r. Loot them for their |T134358:0|t[|cRXP_LOOT_Plagued Flesh Samples|r]
.complete 5212,1 
.isOnQuest 5212
step
#completewith RestlessSouls
.subzone 2627 >>Travel to Terrordale
step
.goto Eastern Plaguelands,14.45,33.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Egan|r
.turnin 5282 >>Turn in The Restless Souls
.target Egan
.isQuestComplete 5282
step
#completewith LCHTurnins
.hs >>Hearth to Light's Hope Chapel
.bindlocation 2268,1
.subzoneskip 2268
.use 6948
.cooldown item,6948,>0,1
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.turnin 5262 >>Turn in The Truth Comes Crashing Down
.accept 5263 >>Accept in Above and Beyond
.target Duke Nicholas Zverenhoff
.isOnQuest 5262
step
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.turnin 5263 >>Turn in Above and Beyond
.accept 5264 >>Accept Lord Maxwell Tyrosus
.target Duke Nicholas Zverenhoff
.isQuestComplete 5263
step
#optional
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.accept 5264 >>Accept Lord Maxwell Tyrosus
.target Duke Nicholas Zverenhoff
.isQuestTurnedIn 5263
step
.goto Eastern Plaguelands,81.74,57.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.turnin 5264 >>Turn in Lord Maxwell Tyrosus
.accept 5265 >>Accept The Argent Hold
.target Lord Maxwell Tyrosus
.isQuestComplete 5264
step
#optional
.goto Eastern Plaguelands,81.74,57.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Maxwell Tyrosus|r
.accept 5265 >>Accept The Argent Hold
.target Lord Maxwell Tyrosus
.isQuestTurnedIn 5264
step
.goto Eastern Plaguelands,81.81,57.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tClick on |cRXP_FRIENDLY_The Argent Hold|r a small chest next to Maxwell
.turnin 5265 >>Turn in The Argent Hold
.target The Argent Hold
.isOnQuest 5265
step
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.accept 5243 >>Accept Houses of the Holy
.turnin 5243 >>Turn in Houses of the Holy
.target Leonid Barthalomew the Revered
.itemcount 13180,5
step
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.turnin 5464 >>Turn in Menethil's Gift
.accept 5465 >>Accept Soulbound Keepsake
.target Leonid Barthalomew the Revered
.isOnQuest 5464
step
#optional
.goto Eastern Plaguelands,81.73,57.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Leonid|r
.accept 5465 >>Accept Soulbound Keepsake
.target Leonid Barthalomew the Revered
.isQuestTurnedIn 5464
step
.goto Eastern Plaguelands,81.47,59.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Betina Bigglezink|r
.turnin 5212 >> Turn in The Flesh Does Not Lie
.target Betina Bigglezink
.isQuestComplete 5212
step
#label LCHTurnins
.goto Eastern Plaguelands,80.605,57.979
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey LaRue|r
.accept 5214 >>Accept The Great Ezra Grimm
.target Smokey LaRue
.isQuestComplete 5214
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.turnin 5848 >>Turn in Of Love and Family
.target Tirion Fordring
.isQuestComplete 5848
step
#completewith RichRas
.zone Western Plaguelands >>Travel to Western Plaguelands
step
#completewith RichRas
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received from the previous quest to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5465 >>Turn in Soulbound Keepsake
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isOnQuest 5465
.use 13544
step
#optional
#label RichRas
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.accept 5466 >>Accept The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestTurnedIn 5465
.use 13544
step
#completewith next
+|cRXP_WARN_Find a group for Scholomance now if you wish to complete the final quest of the chain "The Lich, Ras Frostwhisper"|r
step
.use 13752>>|cRXP_WARN_Use the|r |T133736:0|t[Soulbound Keepsake] |cRXP_WARN_on|r |cRXP_ENEMY_Ras Frostwhisper|r
>>Kill |cRXP_ENEMY_Ras Frostwhisper|r inside Scholomance. Loot him for his |cRXP_LOOT_Head|r
.complete 5466,1 
.mob Ras Frostwhisper
.isOnQuest 5466
step
#optional
#completewith RichRas2
.goto Western Plaguelands,70.22,73.71,50 >>Return to |cRXP_FRIENDLY_Magistrate Marduke|r outside the instance
step
#optional
#completewith RichRas2
.use 13544 >>|cRXP_WARN_Equip the|r |T134337:0|t[|cRXP_FRIENDLY_Spectral Essence|r] |cRXP_WARN_you received to be able to see|r |cRXP_FRIENDLY_Magistrate Marduke|r
>>|cRXP_WARN_If you lost it you can ask|r |cRXP_FRIENDLY_Eva Sarkhoff|r |cRXP_WARN_for another|r
step
#optional
#label RichRas2
.goto Western Plaguelands,70.54,73.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Marduke|r
.turnin 5466 >>Turn in The Lich, Ras Frostwhisper
.target Magistrate Marduke
.isQuestComplete 5466
.use 13544
step
+|cRXP_WARN_You have completed the Stratholme quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 18. Dire Maul (East)
step << era
#optional
#phase 1
+Dire Maul is not until accessible until Phase 2 has released
step
#completewith EnterDME
+Start looking for a group for Dire Maul (East) while you accept the quests for the dungeon
step
#completewith EnterDME
.zone Feralas >> Travel to Feralas
step
.goto Feralas,31.8,44.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scholar Runethorn|r
>>|cRXP_FRIENDLY_Scholar Runethorn|r |cRXP_WARN_patrols slightly through Feathermoon Stronghold|r
.accept 7482 >> Accept Elven Legends
.target Scholar Runethorn
step
.goto Feralas,30.379,46.170
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Latronicus Moonspear|r
.accept 7488 >> Accept Lethtendris's Web
.target Latronicus Moonspear
step
.goto Feralas,76.910,37.353
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azj'Tordin|r
.accept 7441 >> Accept Pusillin and the Elder Azj'Tordin
.target Azj'Tordin
step << Mage era
#softcore
.xp <60,1
>>If it is possible, enter Dire Maul (North) and head into the Library to accept the quest for your level 60 Mage Water quest
>>You will need to have the |cRXP_LOOT_Crescent Key|r to open the door to the Library or consider looking for someone selling Tribute buffs that has already opened the door
>>|cRXP_WARN_If you cannot do this, skip this step|r
>>Talk to |cRXP_FRIENDLY_Lorekeeper Lydros|r in Dire Maul (North) Library
.accept 7463 >> Accept Arcane Refreshment
.target Lorekeeper Lydros
step
#label EnterDME
.goto 1414,43.83,67.40,15 >> Enter Dire Maul (East)
step
>>Talk to |cRXP_FRIENDLY_Pusillin|r and continue to chase him through Dire Maul by talking to him every time he stops
>>Kill |cRXP_ENEMY_Pusillin|r. Loot him for the |cRXP_LOOT_Crescent Key|r and |cRXP_LOOT_Book of Incantations|r
.collect 18249,1 
.complete 7441,1 
.target Pusillin
.skipgossip
step
>>Kill |cRXP_ENEMY_Lethtendris|r. Loot her for |cRXP_LOOT_Lethtendris's Web|r
.complete 7488,1 
.mob Lethtendris
step << Mage era
.isOnQuest 7463
>>Kill |cRXP_ENEMY_Hydrospawn|r. Loot it for the |cRXP_LOOT_Hydrospawn Essence|r
.complete 7463,1 
.mob Hydrospawn
step
>>Kill |cRXP_ENEMY_Alzzin the Wildshaper|r. Loot a |cRXP_PICK_Felvine Shard|r on the ground after
.collect 18501,1,5526,1 
step << Mage era
#softcore
.xp <60,1
.isQuestComplete 7463
>>Talk to |cRXP_FRIENDLY_Lorekeeper Lydros|r in the Dire Maul (North) Library
>>|cRXP_WARN_Skip this if you can't access it|r
.turnin 7463 >> Turn in Arcane Refreshment
.target Lorekeeper Lydros
step
.isQuestComplete 7441
.goto Feralas,76.910,37.353
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azj'Tordin|r in Feralas
.turnin 7441 >> Turn in Pusillin and the Elder Azj'Tordin
.target Azj'Tordin
step
.goto Feralas,30.379,46.170
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Latronicus Moonspear|r
.turnin 7488 >> Turn in Lethtendris's Web
.target Latronicus Moonspear
step
#completewith SotF
.zone Moonglade >> Travel to Moonglade
step
.isQuestTurnedIn 5527
.goto Moonglade,51.685,45.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine Saturna|r
.accept 5526 >> Accept Shards of the Felvine
.target Rabine Saturna
step
.isOnQuest 5526
.isQuestTurnedIn 5527
.use 18539 >> |cRXP_WARN_Use the|r |T132595:0|t[Reliquary of Purity]
.complete 5526,1 
step
#label SotF
.isQuestComplete 5526
.goto Moonglade,51.685,45.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine Saturna|r
.turnin 5526 >> Turn in Shards of the Felvine
.target Rabine Saturna
step
+|cRXP_WARN_You have completed the Dire Maul (East) quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 19. Dire Maul (West)
step << era
#optional
#phase 1
+Dire Maul is not until accessible until Phase 2 has released
step
#completewith EnterDM
.zone Feralas >> Travel to Feralas
step
.goto Feralas,31.8,44.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scholar Runethorn|r
>>|cRXP_FRIENDLY_Scholar Runethorn|r |cRXP_WARN_patrols slightly through Feathermoon Stronghold|r
.accept 7482 >> Accept Elven Legends
.target Scholar Runethorn
step
#label EnterDM
.goto 1414,42.97,67.79,15 >> Enter Dire Maul (West)
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Shen'dralar Ancient|r
>>|cRXP_WARN_She is inside DM:West on the bridge in the upper section|r
.accept 7461 >> Accept The Madness Within
.target Shen'dralar Ancient
step
>>Kill |cRXP_ENEMY_Immol'thar|r and |cRXP_ENEMY_Prince Tortheldrin|r
.complete 7461,1 
.mob +Immol'thar
.complete 7461,2 
.mob +Prince Tortheldrin
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Shen'dralar Ancient|r
>>|cRXP_WARN_She is inside DM:West on the bridge in the upper section|r
.turnin 7461 >> Turn in The Madness Within
.accept 7877 >> Accept The Treasure of the Shen'dralar
.target Shen'dralar Ancient
step
>>Click the |cRXP_PICK_The Treasure of the Shen'dralar|r
>>|cRXP_WARN_This is found back where you killed |cRXP_ENEMY_Prince Tortheldrin|r in the Library, under the ramp leading to him|r
.turnin 7877 >> Turn in The Treasure of the Shen'dralar
step << Mage era
#optional
#softcore
.xp <60,1
.isQuestComplete 7463
>>Talk to |cRXP_FRIENDLY_Lorekeeper Lydros|r in the Dire Maul (North) Library
.turnin 7463 >> Turn in Arcane Refreshment
.target Lorekeeper Lydros
step
.isOnQuest 7482
>>Click the |cRXP_PICK_Skeletas Remains of Kariel Winthalus|r inside the Dire Maul Library
>>|cRXP_WARN_This is located beside|r |cRXP_FRIENDLY_Lorekeeper Lydros|r
.complete 7482,1 
step
#completewith next
.zone Feralas >> Travel to Feralas
step
.goto Feralas,31.8,44.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scholar Runethorn|r
>>|cRXP_FRIENDLY_Scholar Runethorn|r |cRXP_WARN_patrols slightly through Feathermoon Stronghold|r
.turnin 7482 >> Turn in Elven Legends
.target Scholar Runethorn
step
+|cRXP_WARN_You have completed the Dire Maul (West) quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#classic
#tbc
#wotlk
#version 1
#group RXP Dungeon Quest Guides (A)
#subgroup 50-60
<< Alliance
#name 20. Dire Maul (North)
step << era
#optional
#phase 1
+Dire Maul is not until accessible until Phase 2 has released
step
>>The following materials are required if you wish to complete a Tribute run
>>|cRXP_WARN_You will also need a Rogue with 300 Lockpicking skill OR a Powerful Seaforium Charge OR a Truesilver Skeleton Key|r
>>|cRXP_WARN_Skip buying the Bolt of Runecloth, Rugged Leather and Rune Thread if you decide to simply buy the Gordok Ogre Suit|r
>>|cRXP_WARN_Skip this step if you wish to complete the dungeon normally|r
.collect 18258,1 
.collect 14048,4 
.collect 8170,8 
.collect 14341,2 
.collect 15994,1 
.collect 3829,1 
step
#completewith EnterDM
.zone Feralas >> Travel to Feralas
step
.goto Feralas,31.8,44.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scholar Runethorn|r
>>|cRXP_FRIENDLY_Scholar Runethorn|r |cRXP_WARN_patrols slightly through Feathermoon Stronghold|r
.accept 7482 >> Accept Elven Legends
.target Scholar Runethorn
step
#label EnterDM
.goto 1414,43.45,66.52,15 >> Enter Dire Maul (North)
step
.isOnQuest 7482
>>Click the |cRXP_PICK_Skeletas Remains of Kariel Winthalus|r inside the Dire Maul Library
>>|cRXP_WARN_This is located beside|r |cRXP_FRIENDLY_Lorekeeper Lydros|r
.complete 7482,1 
step
+|cRXP_WARN_If you are doing a Tribute run:|r
>>Completely avoid |cRXP_ENEMY_Guard Mol'dar|r, |cRXP_ENEMY_Guard Fengus|r and |cRXP_ENEMY_Stomper Kreeg|r
>>Make sure someone in your party loots |cRXP_PICK_Fengus's Chest|r for the |cRXP_LOOT_Gordok Courtyard Key|r
>>Use the materials aquired earlier to trap |cRXP_ENEMY_Guard Slip'kik|r
>>Head up the ramp and loot the |cRXP_PICK_Ogre Tannin|r, then return below to |cRXP_FRIENDLY_Knot Thimblejack|r to make the |T132636:0|t[|cRXP_LOOT_Gordok Ogre Suit|r] if you didn't buy one
>>Talk to |cRXP_ENEMY_Captain Kromcrush|r while wearing the |T132636:0|t[|cRXP_LOOT_Gordok Ogre Suit|r]
>>Kill |cRXP_ENEMY_King Gordok|r. Keep |cRXP_ENEMY_Cho'Rush the Observer|r alive
>>|cRXP_WARN_Skip this step if you are doing a normal clear|r
step
+Complete Dire Maul (North)
>>There are no other quests to complete. Exit the instance once complete
step
#completewith next
.zone Feralas >> Travel to Feralas
step
.goto Feralas,31.8,44.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scholar Runethorn|r
>>|cRXP_FRIENDLY_Scholar Runethorn|r |cRXP_WARN_patrols slightly through Feathermoon Stronghold|r
.turnin 7482 >> Turn in Elven Legends
.target Scholar Runethorn
step
+|cRXP_WARN_You have completed the Dire Maul (North) quest guide. Please select a new guide|r
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Nagrand
#name Mining & Herbalism1
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Nagrand,50,50
    .zone Nagrand >> Head to Nagrand
step
    #hidewindow
    +test
    .loop @20,Nagrand,72.3,79.8,64.5,69.6,61.4,75.3,56.3,65.8,58.2,78.9,52.5,80.2,47.9,78.2,50.3,60.7,49.3,51.5,42.8,51.3,36.1,58.9,44.3,65.6,40.4,82.6,33.6,81.0,29.6,79.2,27.4,73.4,28.7,62.8,24.9,52.8,19.0,50.5,21.6,45.2,25.5,43.8,22.5,39.8,18.7,38.7,8.4,45.4,7.1,40.3,10.5,37.2,14.1,38.2,13.1,35.8,27.8,30.1,24.0,26.9,27.2,19.4,32.9,26.4,36.4,18.1,41.2,22.6,36.3,31.7,39.5,34.4,48.9,19.6,54.7,23.3,47.6,43.0,54.3,48.0,59.9,46.2,66.4,35.3,71.4,44.5,70.3,55.9,75.0,63.0,72.3,79.8
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Nagrand

#name Mining1
#displayname Mining
step
    #sticky
    .waypoint Nagrand,50,50
    .zone Nagrand >> Head to Nagrand
step
    #hidewindow
    +test
    .loop @20,Nagrand,70.8,76.0,77.7,59.9,71.6,60.3,70.6,52.1,72.2,43.4,66.1,34.7,68.0,50.3,61.2,55.5,56.9,53.2,56.4,57.9,48.4,50.9,51.5,39.8,50.3,24.7,46.1,20.7,38.9,22.4,45.3,45.8,42.7,49.2,39.5,44.8,37.8,29.6,31.7,28.3,25.6,15.0,27.1,23.6,23.2,29.1,8.0,40.4,9.9,43.7,23.4,48.1,21.0,53.5,28.0,65.1,29.9,71.0,25.4,71.8,28.9,80.8,40.4,83.0,43.1,76.3,43.7,64.1,48.6,79.4,50.7,67.2,57.2,63.3,69.0,81.5,70.8,76.0
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Nagrand

#name Herbalism1
#displayname Herbalism
step
    #sticky
    .waypoint Nagrand,50,50
    .zone Nagrand >> Head to Nagrand
step
    #hidewindow
    +test
    .loop @20,Nagrand,72.3,79.8,64.5,69.6,61.9,73.5,56.6,66.3,59.4,81.5,52.5,80.2,48.4,73.3,50.3,60.7,49.3,51.5,42.8,51.3,36.3,59.2,44.3,65.6,40.5,81.7,33.6,81.0,29.6,79.2,27.4,73.4,28.7,62.8,24.9,52.8,19.0,50.5,21.6,45.2,25.5,43.8,22.5,39.8,18.7,38.7,9.0,44.5,7.1,40.3,10.5,37.2,14.1,38.2,12.1,34.5,27.8,30.1,25.2,27.1,27.2,19.4,32.9,26.4,36.0,19.9,41.2,22.6,36.3,31.7,39.5,34.4,49.3,21.0,54.7,23.3,47.6,43.0,54.3,48.0,59.9,46.2,66.4,39.4,71.7,42.9,70.4,58.6,75.0,63.0,72.3,79.8
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Netherstorm
#name Mining & Herbalism2
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Netherstorm,50,50
    .zone Netherstorm >> Head to Netherstorm
step
    #hidewindow
    +test
    .loop @20,Netherstorm,22.0,76.6,20.8,67.2,26.9,62.7,26.9,53.2,34.5,51.6,30.6,43.1,23.4,42.1,24.3,35.4,29.6,36.4,36.9,39.7,40.1,36.0,42.6,38.9,46.4,38.9,47.7,34.5,44.6,27.4,39.1,25.6,36.6,28.0,35.4,22.9,29.4,17.7,29.3,14.2,30.8,13.6,38.2,19.7,43.2,19.7,41.2,15.4,45.1,15.7,46.5,9.6,48.6,17.6,49.5,23.8,53.0,25.2,52.9,21.0,55.6,19.7,61.7,32.0,65.5,32.3,64.2,37.0,65.9,39.3,69.3,36.0,72.9,36.9,73.0,43.6,69.1,46.6,68.0,42.2,63.9,43.0,62.1,49.8,55.9,38.8,54.3,42.9,57.1,47.6,50.7,54.6,48.0,47.6,42.3,51.4,40.6,54.4,44.5,56.6,47.3,60.7,48.1,64.4,49.9,60.3,53.2,61.1,56.9,59.0,66.4,60.2,63.3,63.7,58.8,62.8,51.1,69.8,53.0,77.2,61.1,79.5,59.0,82.5,59.8,87.1,57.5,88.7,53.3,82.9,48.2,85.0,44.6,72.7,34.5,56.4,34.8,62.7,33.9,73.5,30.3,78.6,29.9,71.,27.8,70.7,22.0,76.6
    .openmap Netherstorm
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Netherstorm
#name Mining2
#displayname Mining
step
    #sticky
    .waypoint Netherstorm,50,50
    .zone Netherstorm >> Head to Netherstorm
step
    #hidewindow
    +test
    .loop @20,Netherstorm,57.6,88.2,61.1,80.1,55.5,68.0,61.7,70.4,66.3,60.6,62.0,59.3,60.6,60.3,54.8,58.7,48.8,63.4,42.4,54.5,48.2,47.0,49.7,57.4,51.7,53.0,55.1,44.6,54.6,41.7,57.3,37.7,59.3,38.2,60.5,42.5,59.2,48.9,63.4,46.1,66.3,47.9,69.5,44.2,72.8,41.7,71.9,36.7,65.3,39.1,64.3,37.1,64.7,31.5,54.2,26.4,56.0,20.4,52.4,21.4,49.1,17.7,47.3,13.4,44.7,12.5,42.8,19.8,40.3,16.7,39.2,19.8,37.1,20.1,31.6,14.3,28.9,15.4,30.8,19.4,38.5,26.6,37.6,29.5,47.2,36.6,46.5,39.0,39.4,37.5,36.5,39.8,24.5,35.1,24.4,41.4,29.4,42.8,35.0,51.2,38.7,66.7,27.9,53.1,26.8,62.6,20.5,67.4,20.6,73.1,27.0,78.7,29.3,78.1,29.9,72.4,33.2,74.6,35.5,74.9,37.9,78.0,41.6,74.3,48.5,78.7,48.8,87.1,52.7,81.5,57.6,88.2
    .openmap Netherstorm
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Netherstorm
#name Herbalism2
#displayname Herbalism
step
    #sticky
    .waypoint Netherstorm,50,50
    .zone Netherstorm >> Head to Netherstorm
step
    #hidewindow
    +test
    .loop @20,Netherstorm,21.8,76.1,20.6,67.5,26.8,62.6,27.1,53.5,34.0,53.6,30.6,43.1,23.8,42.3,24.7,34.9,36.8,39.0,38.5,40.6,40.0,35.9,42.9,38.8,46.4,38.9,48.4,36.1,44.6,27.4,35.6,25.3,29.2,17.4,29.2,14.6,31.1,13.5,36.4,18.2,39.1,17.8,41.3,21.2,42.8,18.1,45.4,18.3,46.4,9.8,48.1,14.1,49.8,24.3,55.1,19.2,61.5,32.0,65.1,33.6,68.9,35.7,73.0,37.0,70.9,42.8,69.0,45.3,67.5,42.0,65.4,41.0,64.2,44.8,61.9,48.8,61.3,44.6,59.9,38.7,58.1,36.4,54.3,43.0,57.2,47.9,48.5,47.7,43.9,50.8,41.5,51.7,40.6,54.6,45.1,56.6,47.3,60.8,47.3,63.3,51.6,56.3,56.6,58.8,65.9,61.1,66.8,63.2,58.5,63.4,51.7,69.4,53.0,77.2,60.0,80.2,58.9,83.5,59.7,86.4,57.8,88.6,53.3,82.9,48.5,85.2,47.4,82.3,47.6,80.1,44.8,73.4,38.3,62.2,37.0,58.8,34.0,75.2,29.5,70.4,26.9,71.1,24.3,75.1,21.8,76.1
    .openmap Netherstorm
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Terokkar Forest
#name Mining & Herbalism3
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Terokkar Forest,50,50
    .zone Terokkar Forest >> Head to Terokkar Forest
step
    #hidewindow
    +test
    .loop @20,Terokkar Forest,20.8,16.4,22.8,7.8,26.6,11.1,35.1,7.8,44.4,17.8,44.1,10.9,50.8,17.1,49.4,26.3,38.0,36.8,40.0,41.6,44.9,33.8,49.9,35.4,54.7,27.1,61.3,22.8,54.9,38.2,60.2,42.9,65.3,31.0,72.1,31.2,68.3,37.9,67.1,43.7,60.9,45.2,69.0,50.4,65.2,55.4,59.9,47.1,54.9,58.6,56.5,65.5,65.6,69.2,72.3,73.1,73.5,82.7,74.3,88.3,68.7,86.6,60.5,70.9,56.0,71.6,49.6,82.2,30.8,79.3,29.3,64.4,24.7,65.1,25.6,77.2,18.2,78.9,17.6,65.6,28.2,52.2,32.3,36.4,20.8,16.4
    .openmap Terokkar Forest
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Terokkar Forest
#name Mining3
#displayname Mining
step
    #sticky
    .waypoint Terokkar Forest,50,50
    .zone Terokkar Forest >> Head to Terokkar Forest
step
    #hidewindow
    +test
    .loop @20,Terokkar Forest,22.1,15.3,21.8,10.9,24.1,9.4,36.9,6.1,42.2,21.7,44.4,10.8,51.1,16.8,48.9,19.9,52.7,27.5,60.0,22.7,67.1,31.2,72.4,31.2,73.2,37.2,67.1,54.8,62.5,52.1,54.7,37.9,54.5,31.0,49.4,34.4,37.6,37.6,41.6,46.3,47.3,49.2,57.3,62.7,72.4,73.0,67.1,78.8,73.8,82.0,74.0,88.8,61.6,83.2,61.2,72.7,54.9,69.0,48.9,80.0,31.4,79.0,27.3,64.8,25.1,77.1,18.4,77.7,18.0,65.6,29.8,46.6,29.3,35.7,22.1,15.3
    .openmap Terokkar Forest
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Terokkar Forest
#name Herbalism3
#displayname Herbalism
step
    #sticky
    .waypoint Terokkar Forest,50,50
    .zone Terokkar Forest >> Head to Terokkar Forest
step
    #hidewindow
    +test
    .loop @20,Terokkar Forest,20.8,16.4,22.8,7.8,25.5,10.2,35.8,8.6,44.0,18.1,44.9,13.9,50.8,17.5,50.1,25.7,37.8,35.7,40.6,40.5,45.6,33.4,50.5,35.6,55.3,27.7,61.2,24.4,54.9,38.2,60.2,42.9,65.2,30.5,72.9,30.6,67.1,43.7,60.9,45.2,69.0,50.4,64.9,56.0,60.2,49.7,54.9,58.6,56.5,65.5,65.6,69.5,73.5,82.7,73.4,87.4,68.7,86.6,60.5,70.9,56.0,71.6,49.6,82.2,30.8,79.3,29.4,66.2,24.7,65.1,25.6,77.3,18.3,78.0,17.9,66.0,27.5,50.2,32.3,36.4,20.8,16.4
    .openmap Terokkar Forest
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Mining & Herbalism4
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Shadowmoon Valley,50,50
    .zone Shadowmoon Valley >> Head to Shadowmoon Valley
step
    #hidewindow
    +test
    .loop @20,Shadowmoon Valley,17.8,29.1,24.9,36.0,21.7,38.9,25.7,40.2,30.1,35.9,30.7,41.1,37.5,31.1,31.1,47.9,28.8,46.7,27.9,52.5,30.6,57.5,38.2,46.2,37.8,36.7,42.1,32.7,43.1,49.7,47.5,52.0,44.9,57.2,43.2,55.9,42.7,58.8,45.5,62.9,44.5,65.8,40.6,68.5,36.5,69.1,46.3,71.1,51.1,58.2,52.8,60.1,52.7,70.1,56.7,72.0,59.0,67.8,61.3,67.9,63.9,80.5,63.5,84.9,66.0,88.8,71.8,90.3,77.4,86.9,76.4,82.4,70.6,82.3,68.1,83.0,70.8,63.8,67.0,59.5,62.2,59.2,53.8,53.0,54.1,49.5,59.7,44.7,66.4,51.3,68.6,45.1,73.0,47.4,72.2,40.4,66.2,40.0,66.4,36.5,59.9,34.8,57.3,39.5,53.8,36.6,48.6,32.5,55.5,29.5,72.8,28.9,66.7,22.6,59.0,22.1,56.0,25.0,56.4,17.0,53.4,16.0,50.7,20.0,52.3,26.2,48.3,26.4,45.7,13.1,43.5,26.8,35.5,29.1,29.0,31.5,22.3,26.6,20.6,24.2,17.8,29.1
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Mining4
#displayname Mining
step
    #sticky
    .waypoint Shadowmoon Valley,50,50
    .zone Shadowmoon Valley >> Head to Shadowmoon Valley
step
    #hidewindow
    +test
    .loop @20,Shadowmoon Valley,20.9,31.7,24.2,35.1,21.5,39.0,25.6,38.7,28.7,44.3,29.3,52.7,31.9,51.3,32.9,41.4,32.1,39.1,33.4,36.1,42.1,35.9,44.7,40.0,42.7,42.2,37.9,40.9,37.8,44.1,43.,49.9,44.3,57.9,42.1,67.4,41.0,68.6,46.2,71.0,48.4,62.8,49.4,54.7,54.6,53.3,52.9,59.6,53.7,71.0,56.5,73.6,58.8,67.7,67.8,80.4,63.6,84.8,67.0,86.6,75.2,89.0,77.5,85.7,75.9,82.5,74.0,82.5,71.1,64.0,64.5,54.0,61.2,54.1,57.3,48.2,66.1,46.9,67.5,35.0,72.7,29.6,66.8,23.0,63.1,24.3,63.1,35.8,60.9,36.4,60.7,40.1,55.7,39.5,53.5,35.6,50.4,34.1,55.0,29.3,57.0,22.0,56.3,16.6,53.4,15.7,51.3,24.6,46.9,29.4,45.4,24.4,45.9,12.9,42.4,27.7,34.1,31.7,24.1,28.2,21.7,24.0,20.9,31.7
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Herbalism4
#displayname Herbalism
step
    #sticky
    .waypoint Shadowmoon Valley,50,50
    .zone Shadowmoon Valley >> Head to Shadowmoon Valley
step
    #hidewindow
    +test
    .loop @20,Shadowmoon Valley,17.8,29.1,23.0,37.0,23.0,39.7,29.9,35.3,30.4,42.1,37.5,31.1,31.7,46.3,29.3,46.0,27.9,52.5,29.7,57.3,37.2,47.2,37.7,34.4,42.5,32.1,42.8,41.1,42.3,48.0,46.2,52.6,44.9,57.3,43.6,55.6,42.7,58.9,44.2,67.4,36.9,69.1,45.2,73.4,48.0,69.8,51.1,58.2,52.7,70.1,56.7,72.0,59.9,68.7,63.9,80.5,64.1,86.3,68.2,89.7,71.8,90.3,77.6,86.7,75.6,81.7,70.6,82.3,68.1,83.0,67.7,59.8,59.1,56.5,54.8,50.4,56.6,46.7,59.7,44.7,66.8,51.7,68.1,47.4,73.0,47.4,72.2,40.4,66.2,40.0,64.9,36.1,55.1,37.6,50.7,33.0,55.5,29.5,71.5,28.0,66.6,23.4,60.3,21.0,57.7,21.7,54.0,15.6,50.7,20.0,52.3,26.2,48.3,26.4,45.7,13.4,44.6,21.4,42.7,27.4,35.5,29.1,25.1,28.2,22.3,26.6,20.6,24.6,17.8,29.1
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Zangarmarsh
#name Mining & Herbalism5
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Zangarmarsh,50,50
    .zone Zangarmarsh >> Head to Zangarmarsh
step
    +Required objective, do not remove this line
    .loop @20,Zangarmarsh,77.9,91.1,86.4,86.5,82.6,82.2,84.5,79.6,82.0,69.6,81.8,59.0,89.2,38.0,85.5,26.7,84.4,42.4,81.8,44.2,78.2,39.7,81.7,34.5,79.9,28.0,70.9,33.6,69.9,43.6,60.9,32.6,49.1,29.0,40.0,31.9,34.6,16.3,31.0,21.7,19.9,15.4,19.6,4.8,15.9,14.3,14.7,29.5,11.5,38.8,8.1,51.5,11.1,65.9,16.6,57.9,18.4,70.5,25.4,54.9,31.3,66.6,27.5,38.8,36.9,34.1,37.0,62.9,57.1,69.9,70.1,69.5,67.1,78.6,76.1,90.3,77.9,91.1
    .openmap Zangarmarsh
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Zangarmarsh
#name Mining5
#displayname Mining
step
    #sticky
    .waypoint Zangarmarsh,50,50
    .zone Zangarmarsh >> Head to Zangarmarsh
step
    +Required objective, do not remove this line
    .loop @20,Zangarmarsh,84.6,88.7,85.5,79.1,83.1,70.5,87.4,46.9,80.3,36.4,87.1,35.2,84.2,28.7,75.5,29.3,71.5,34.5,56.2,33.5,56.0,43.7,46.3,37.9,34.5,16.5,33.2,21.6,18.8,14.7,19.0,2.7,14.2,20.7,14.3,31.9,7.6,51.9,11.2,62.0,17.3,68.3,27.5,66.2,30.7,59.7,40.4,66.9,48.9,66.8,67.1,76.4,68.9,86.7,76.8,91.8,84.6,88.7
    .openmap Zangarmarsh
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Zangarmarsh
#name Herbalism5
#displayname Herbalism
step
    #sticky
    .waypoint Zangarmarsh,50,50
    .zone Zangarmarsh >> Head to Zangarmarsh
step
    +Required objective, do not remove this line
    .loop @20,Zangarmarsh,77.9,91.1,85.0,85.2,82.6,82.2,84.5,79.6,82.0,69.6,81.8,59.0,89.4,37.6,85.7,28.8,84.4,42.4,81.8,44.2,78.2,39.7,81.7,34.5,80.3,29.8,71.6,35.6,69.9,43.6,61.0,33.9,49.0,30.6,40.0,31.9,34.8,17.7,31.0,21.7,19.9,15.4,19.6,2.4,15.9,14.3,14.7,29.5,11.5,38.8,9.1,51.7,11.1,65.9,16.6,57.9,18.4,70.5,25.4,54.9,31.3,66.6,27.5,36.6,36.9,34.1,37.5,62.3,57.1,69.9,70.1,69.5,67.1,78.6,76.1,90.3,77.9,91.1
    .openmap Zangarmarsh
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Hellfire Peninsula
#name Mining & Herbalism6
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Hellfire Peninsula,50,50
    .zone Hellfire Peninsula >> Head to Hellfire Peninsula
step
    #hidewindow
    +test
    .loop @20,Hellfire Peninsula,26.5,78.2,30.8,61.6,35.5,60.8,46.2,65.8,42.4,77.7,35.8,89.8,54.4,81.7,68.1,75.9,69.9,70.4,64.3,64.2,68.5,63.7,66.4,57.9,66.9,52.4,74.9,51.6,73.7,38.4,68.0,45.1,66.9,32.3,65.6,19.5,57.5,20.4,50.6,27.6,27.2,34.0,32.9,43.4,22.1,44.6,14.6,36.8,10.9,44.8,11.5,56.9,15.0,62.3,22.4,53.4,22.8,71.1,26.5,70.8,26.5,78.2
    .openmap Hellfire Peninsula
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Hellfire Peninsula
#name Herbalism6
#displayname Herbalism
step
    #sticky
    .waypoint Hellfire Peninsula,50,50
    .zone Hellfire Peninsula >> Head to Hellfire Peninsula
step
    #hidewindow
    +test
    .loop @20,Hellfire Peninsula,27.9,80.6,31.1,61.8,43.5,63.9,43.0,72.9,38.1,87.2,45.7,85.5,49.8,69.2,62.0,68.9,67.4,77.9,65.4,58.4,72.3,62.3,80.3,79.6,73.8,59.2,66.8,55.5,67.1,52.2,71.9,51.9,73.9,40.2,66.8,43.7,66.2,21.1,63.2,19.0,51.0,23.9,49.2,36.5,45.1,41.9,49.0,47.1,59.8,47.1,61.0,53.7,52.5,54.6,48.6,58.9,42.9,56.0,37.7,42.6,41.0,30.8,35.5,29.3,27.5,36.8,31.4,48.6,24.1,44.4,20.5,40.1,18.2,46.1,14.6,36.8,12.1,55.2,13.8,61.8,17.2,53.6,22.7,54.9,22.9,65.9,27.9,80.6
    .openmap Hellfire Peninsula
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Hellfire Peninsula
#name Mining6
#displayname Mining
step
    #sticky
    .waypoint Hellfire Peninsula,50,50
    .zone Hellfire Peninsula >> Head to Hellfire Peninsula
step
    #hidewindow
    +test
    .loop @20,Hellfire Peninsula,25.7,78.9,22.5,67.6,21.6,54.2,18.3,54.2,14.7,61.2,8.1,50.1,11.8,44.1,13.0,36.9,16.5,37.2,17.6,45.8,26.5,45.6,33.6,30.7,33.2,43.3,37.0,40.6,39.0,29.2,46.6,28.8,52.2,23.8,54.4,29.5,48.0,35.7,47.4,45.1,50.8,48.4,61.2,47.1,61.5,52.3,55.1,52.0,52.2,56.2,48.5,56.5,46.0,65.4,43.6,68.3,38.0,70.1,35.2,58.4,31.3,61.2,31.0,70.8,28.4,71.7,25.7,78.9
    .openmap Hellfire Peninsula
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Blades Edge Mountains
#name Mining & Herbalism7
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Blade's Edge Mountains,50,50
    .zone Blade's Edge Mountains >> Head to Blade's Edge Mountains
step
    #hidewindow
    +test
    .loop @20,Blade's Edge Mountains,29.2,84.0,27.6,81.7,29.1,77.7,27.9,74.0,30.4,69.2,29.0,61.5,31.3,60.0,32.0,50.0,29.5,47.5,32.8,42.9,37.4,40.0,34.7,31.1,36.8,27.6,49.9,20.2,51.8,16.2,55.2,16.1,53.8,12.6,59.6,9.0,60.1,13.0,62.8,13.3,63.8,10.0,68.1,10.8,73.0,10.0,72.4,22.9,73.4,27.0,70.5,30.8,71.0,36.4,63.0,28.1,57.9,40.0,63.1,45.1,67.3,42.0,74.1,40.0,73.2,42.6,66.1,48.3,63.0,51.6,66.3,55.4,68.7,67.1,71.7,65.6,75.6,66.6,75.4,69.7,77.7,74.5,74.4,75.5,69.2,72.7,66.1,76.5,60.0,78.0,64.1,70.8,62.9,60.6,52.3,73.5,50.4,69.6,42.2,63.5,39.2,71.8,38.2,77.2,36.0,75.6,29.2,84.0
    .openmap Blade's Edge Mountains
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Blades Edge Mountains
#name Mining7
#displayname Mining
step
    #sticky
    .waypoint Blade's Edge Mountains,50,50
    .zone Blade's Edge Mountains >> Head to Blade's Edge Mountains
step
    #hidewindow
    +test
    .loop @20,Blade's Edge Mountains,42.5,83.2,46.2,77.6,44.2,75.0,44.9,72.0,45.0,62.8,48.8,62.1,50.5,69.4,53.8,72.7,53.9,64.3,57.7,57.3,60.8,78.4,68.7,75.5,68.3,64.9,73.2,73.8,77.8,76.5,76.5,68.9,75.1,68.6,75.3,64.4,67.9,59.2,64.3,52.8,67.3,49.2,66.7,47.7,67.5,42.9,70.9,42.9,74.3,40.8,69.7,34.2,70.2,30.3,78.2,28.7,78.9,25.9,75.6,23.1,72.3,22.2,73.3,10.7,71.0,11.1,59.0,8.8,49.7,18.3,63.2,15.3,64.8,26.5,62.3,26.5,60.7,21.2,56.0,26.7,55.6,36.2,59.8,34.2,58.2,40.9,61.7,45.2,58.8,48.7,55.4,47.6,51.8,40.1,49.2,47.5,47.3,48.8,46.1,53.3,40.7,56.1,41.1,68.1,36.0,75.1,35.8,78.3,42.5,83.2
    .openmap Blade's Edge Mountains
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Mining & Herbalism
#loop
#hidewindow
#subgroup Blades Edge Mountains
#name Herbalism7
#displayname Herbalism
step
    #sticky
    .waypoint Blade's Edge Mountains,50,50
    .zone Blade's Edge Mountains >> Head to Blade's Edge Mountains
step
    #hidewindow
    +test
    .loop @20,Blade's Edge Mountains,29.5,83.7,29.5,69.6,30.1,62.9,31.3,53.3,31.1,49.1,33.1,42.3,36.2,39.5,34.7,31.1,37.8,26.5,41.6,25.6,49.9,20.2,54.5,11,62.0,11.4,64.8,10.3,72.6,12.7,72.7,26.5,71.0,36.4,63.2,28.7,58.9,40.3,63.1,45.1,69.2,41.6,66.6,48.7,64.5,51.8,65.8,56.1,69.2,68.0,73.6,66.8,75.4,68.4,76.6,76.3,68.8,74.6,61.4,77.8,60.3,73.4,63.8,71.7,63.8,66.2,62.9,60.6,57.9,60.1,52.3,73.5,41.6,63.1,38.4,72.9,37.5,73.5,37.4,76.7,29.5,83.7
    .openmap Blade's Edge Mountains
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Netherstorm
#name Fel Hide_1a
#displayname Fel Hide
step
    #hidewindow
    +test
    .waypoint Netherstorm,61.7,59.3,-500
    .line Netherstorm,53.2,56.9,61.2,57.7,66.2,57.2,68.8,60.9,67.6,69.0,64.9,68.8,63.0,65.5,63.1,60.9,57.8,60.4,54.6,61.5,53.0,59.1,53.2,56.9
    .openmap Netherstorm
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Netherstorm
#name Nether Dragonscale_2a
#displayname Nether Dragonscale
step
    #hidewindow
    +test
    .waypoint Netherstorm,71.9,38.4,-240
    .line Netherstorm,71.9,45.2,73.4,44.4,75.2,37.6,74.6,34.4,68.9,33.9,69.8,37.4,70.1,41.7,71.9,45.2
    .openmap Netherstorm
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Netherstorm
#name Fel Armament_3a
#displayname Fel Armament
step
    #hidewindow
    +test
    .waypoint Netherstorm,39.2,24.2,-350
    .line Netherstorm,43.7,21.7,39.6,29.1,37.3,31.5,35.1,29.0,37.3,21.3,36.0,18.1,39.8,16.9,42.1,18.3,43.7,21.7
    .openmap Netherstorm
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Blades Edge Mountains
#name Wind Scale_4a
#displayname Wind Scale
step
    #hidewindow
    +test
    .waypoint Blade's Edge Mountains,67.3,61.4,-500
    .line Blade's Edge Mountains,64.9,49.8,67.8,52.6,68.0,57.6,69.2,66.4,69.1,74.9,67.1,73.3,67.2,66.1,65.6,57.0,63.4,52.1,64.9,49.8
    .openmap Blade's Edge Mountains
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Blades Edge Mountains
#name Nether Dragonscale_5a
#displayname Nether Dragonscale
step
    #hidewindow
    +test
    .waypoint Blade's Edge Mountains,62.9,77.2,-300
    .line Blade's Edge Mountains,67.9,77.4,67.0,74.9,61.6,75.4,59.8,72.5,58.2,74.2,60.1,79.7,67.9,77.4
    .openmap Blade's Edge Mountains
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Blades Edge Mountains
#name Crystal Infused Leather_6a
#displayname Crystal Infused Leather
step
    #hidewindow
    +test
    .waypoint Blade's Edge Mountains,29.8,59.5,-550
    .line Blade's Edge Mountains,31.2,73.2,32.2,70.4,30.8,65.0,33.0,59.3,32.7,53.4,32.1,49.2,28.1,47.9,27.9,59.0,27.1,72.9,31.2,73.2
    .openmap Blade's Edge Mountains
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Nagrand
#name Combined Primals_7a
#displayname Combined Primals
step
    #hidewindow
    +test
    .waypoint Nagrand,67.9,22.2,-275
    .line Nagrand,64.0,24.3,63.8,26.8,65.5,28.6,69.8,25.0,71.4,27.1,71.8,25.8,71.6,19.7,67.2,16.6,66.0,20.8,64.0,24.3
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Nagrand
#name Primal Water_8a
#displayname Primal Water
step
#hidewindow
    +loop1
    .waypoint Nagrand,37.6,46.8,-500
    .line Nagrand,43.6,48.2,40.7,47.6,39.7,44.4,41.3,40.2,39.9,37.9,41.2,36.6,44.8,41.6,45.4,43.7,44.7,47.4,43.6,48.2
    .openmap Nagrand

    .line Nagrand,37.1,44.5,37.2,47.1,36.3,49.5,35.3,53.1,32.4,55.0,30.4,54.2,31.0,47.7,34.0,46.7,35.2,44.0,37.1,44.5
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Nagrand
#name Thick Clefthoof Leather_9a
#displayname Thick Clefthoof Leather
step
    #sticky
    .waypoint Nagrand,50,50
    .zone Nagrand >> Head to Nagrand
step
    #hidewindow
    +area1
    .line Nagrand,43.8,24.0,41.7,27.5,45.0,32.1,48.8,34.0,48.5,39.0,50.8,37.6,53.9,32.0,53.8,28.9,51.6,29.1,50.7,26.4,48.9,25.0,46.2,27.1,44.9,24.3,43.8,24.0
    .openmap Nagrand
    .line Nagrand,52.8,50.9,55.0,52.8,56.2,50.0,60.7,48.1,63.7,43.3,60.4,38.2,57.0,42.8,55.3,43.6,53.8,46.2,52.8,50.9
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Nagrand
#name Talbuk Venison_10a
#displayname Talbuk Venison
step
    #hidewindow
    +test
    .waypoint Nagrand,51.7,25.9,-450
    .line Nagrand,54.4,31.9,54.4,29.2,53.3,25.7,55.3,24.2,57.9,23.4,58.0,20.5,55.2,20.2,52.7,21.6,50.8,19.5,50.8,24.6,48.4,27.3,46.6,27.8,46.5,32.6,54.4,31.9
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Nagrand
#name Cobra Scales_11a
#displayname Cobra Scales
step
    #hidewindow
    +test
    .waypoint Nagrand,13.2,37.1,-430
    .line Nagrand,20.4,36.9,19.8,33.4,17.6,31.6,12.1,34.8,7.2,40.2,7.5,44.5,9.9,45.6,13.6,39.4,17.5,38.9,19.6,38.3,20.4,36.9
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Nagrand
#name Primal Shadow_12a
#displayname Primal Shadow
step
    #hidewindow
    +test
    .waypoint Nagrand,36.7,70.8,-400
    .line Nagrand,34.4,62.0,40.4,62.4,42.7,66.7,43.6,72.3,40.1,78.3,36.7,79.9,31.2,75.3,30.7,66.5,34.4,62.0
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Nagrand
#name Primal Earth_13a
#displayname Primal Earth

step
    #hidewindow
    +area1
    .waypoint Nagrand,33.1,81.0,-625
    .line Nagrand,41.4,85.7,39.8,86.4,36.1,83.6,30.0,81.9,27.9,81.3,,27.0,76.9,26.3,74.2,23.6,71.9,24.6,71.1,27.0,70.9,28.4,70.3,29.1,74.4,32.8,79.3,41.0,81.4,41.9,80.5,41.4,85.7
    .openmap Nagrand
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Terokkar Forest
#name Mark of Kiljaeden_14a
#displayname Mark of Kiljaeden
step
    #hidewindow
    +test
    .waypoint Terokkar Forest,35.7,56.2,-350
    .line Terokkar Forest,29.8,54.9,31.1,56.3,32.7,55.0,33.1,52.5,31.6,51.4,30.0,52.8,29.8,54.9
    .openmap Terokkar Forest
    .line Terokkar Forest,37.3,57.8,37.9,60.4,41.0,60.3,42.4,57.6,41.4,55.7,40.0,55.5,38.0,55.2,37.2,56.8,37.3,57.8
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Terokkar Forest
#name Firewing Signet_15a
#displayname Firewing Signet
step
    #hidewindow
    +test
    .waypoint Terokkar Forest,71.2,37.3,-200
    .line Terokkar Forest,67.9,36.1,70.3,35.3,72.2,34.4,74.3,34.9,72.7,40.0,71.5,40.9,69.5,38.5,68.0,37.2,67.9,36.1
    .openmap Terokkar Forest
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Terokkar Forest
#name Warped Flesh_16a
#displayname Warped Flesh
step
    #hidewindow
    +test
    .waypoint Terokkar Forest,70.0,85.5,-425
    .line Terokkar Forest,64.0,82.2,62.4,83.2,62.1,85.4,64.4,86.2,65.3,87.8,68.3,87.9,69.6,90.8,75.9,90.8,77.3,79.2,75.7,79.1,74.6,87.5,70.9,88.4,70.4,85.9,66.4,84.2,64.0,82.2
    .openmap Terokkar Forest
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Terokkar Forest
#name Primal Water_17a
#displayname Primal Water
step
    #hidewindow
    +test
    .waypoint Terokkar Forest,65.3,75.3,-435
    .line Terokkar Forest,67.7,84.3,69.1,82.4,68.7,75.6,65.8,72.1,66.1,64.5,64.5,63.8,64.3,65.4,65.0,66.5,64.4,72.3,63.1,73.7,63.2,77.9,64.0,80.9,64.2,82.9,65.6,84.5,67.7,84.3
    .openmap Terokkar Forest
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Terokkar Forest
#name Netherweb Spider Silk_18a
#displayname Netherweb Spider Silk
step
#hidewindow
    .waypoint Terokkar Forest,17.3,80,-1520
    +test
    .line Terokkar Forest,46.3,48.8,48.9,48.9,51.4,52.8,53.4,55.2,54.9,54.1,57.2,58.1,57.5,62.6,55.4,64.8,54.4,70.0,53.6,76.2,53.6,81.3,49.3,84.7,48.9,78.9,51.4,74.3,52.9,64.5,51.3,59.2,48.4,52.2,46.2,50.7,46.3,48.8

    .line Terokkar Forest,25.6,54.6,23.4,54.9,22.1,56.5,18.9,62.3,15.8,65.6,15.4,70.0,16.3,73.7,17.0,77.2,17.3,80.6,19.2,81.3,23.4,77.8,26.1,76.2,29.3,74.8,29.0,71.1,26.9,71.2,25.5,69.3,26.9,65.0,24.9,61.1,25.3,56.7,25.6,54.6

    .line Terokkar Forest,51.1,36.3,44.0,35.1,42.6,36.3,37.0,33.1,37.9,28.7,43.6,16.7,43.6,12.3,45.2,11.3,47.2,12.5,49.9,20.6,55.2,25.5,58.1,30.2,57.3,36.5,54.0,36.2,51.1,36.3

    .openmap Terokkar Forest
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Fel Armament_19a
#displayname Fel Armament
step
    #hidewindow
    +test
    .waypoint Shadowmoon Valley,23.1,35.6,-225
    .line Shadowmoon Valley,20.4,34.0,22.3,29.8,23.8,30.6,26.7,33.5,26.8,36.8,25.2,40.2,24.0,42.3,21.5,41.3,20.0,38.1,20.2,35.9,20.4,34.0
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Primal Fire_20a
#displayname Primal Fire
step
    #hidewindow
    +test
    .waypoint Shadowmoon Valley,47.2,45.4,-475
    .line Shadowmoon Valley,43.8,43.5,45.7,43.0,47.1,39.8,47.6,37.1,47.9,35.0,49.3,34.1,52.6,35.6,49.9,38.3,48.5,43.3,49.8,47.9,51.7,51.1,53.4,50.9,53.7,55.0,51.7,55.6,49.0,55.1,47.6,50.1,46.2,50.0,43.6,45.8,43.8,43.5
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Primal Water_21a
#displayname Primal Water
step
    #hidewindow
    +test
    .waypoint Shadowmoon Valley,47.6,25.5,-375
    .line Shadowmoon Valley,44.4,28.9,44.8,26.5,46.3,22.2,50.1,21.4,51.5,25.4,50.5,26.4,48.0,29.2,46.0,29.8,44.4,28.9
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Primal Air_22a
#displayname Primal Air
step
    #hidewindow
    +test
    .waypoint Shadowmoon Valley,63.7,44.2,-1175
    .line Shadowmoon Valley,58.0,59.8,61.1,59.8,61.9,61.8,63.9,61.3,65.1,61.8,66.5,57.9,64.6,56.2,64.4,53.8,62.2,64.9,59.3,65.9,61.1,68.1,59.6,71.0,57.1,73.7,54.2,67.1,53.6,63.3,55.3,60.0,58.0,59.8
    .openmap Shadowmoon Valley
    .line Shadowmoon Valley,74.5,29.5,70.9,28.8,69.3,30.1,67.6,28.8,66.8,26.8,67.8,21.9,65.4,22.5,61.0,21.5,59.7,22.3
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Arcane Tome_23a
#displayname Arcane Tome
step
    #hidewindow
    +test
    .waypoint Shadowmoon Valley,69.1,50.2,-225
    .line Shadowmoon Valley,66.1,46.1,66.1,52.9,68.5,54.5,71.6,53.9,72.4,52.9,72.5,47.1,71.1,46.6,67.1,47.0,67.0,46.1,66.1,46.1
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Shadowmoon Valley
#name Wind Scale_24a
#displayname Wind Scale
step
    #hidewindow
    +test
    .waypoint Shadowmoon Valley,47.1,65.7,-350
    .line Shadowmoon Valley,50.3,59.3,51.8,60.0,51.6,61.9,49.4,64.1,48.5,66.6,48.9,71.3,46.7,73.5,44.3,73.1,43.6,70.2,43.2,67.0,44.5,63.8,46.5,63.4,48.4,59.3,50.3,59.3
    .openmap Shadowmoon Valley
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Hellfire Peninsula
#name Primal Shadow_25a
#displayname Primal Shadow
step
    #hidewindow
    +test
    .waypoint Hellfire Peninsula,78.3,70.3,-375
    .line Hellfire Peninsula,78.2,80.8,80.9,80.7,81.5,77.2,79.7,72.1,80.0,67.3,78.5,62.2,76.0,61.7,74.9,66.9,77.0,71.2,78.2,80.8
    .openmap Hellfire Peninsula
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Hellfire Peninsula
#name Primal Fire_26a
#displayname Primal Fire
step
    #hidewindow
    +test
    .waypoint Hellfire Peninsula,68.3,19.3,-350
    .line Hellfire Peninsula,63.6,20.9,65.8,21.2,68.2,20.5,67.4,16.9,64.4,15.5,61.1,16.2,57.4,17.2,56.9,23.4,61.2,24.5,63.0,22.7,63.6,20.9
    .openmap Hellfire Peninsula
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Outland Farming
#loop
#hidewindow
#subgroup Netherstorm
#name Primal Mana_27a
#displayname Primal Mana
step
    #hidewindow
    +test
    .waypoint Netherstorm,58.0,87.4,-200
    .line Netherstorm,53.8,89.9,54.9,91.4,58.5,90.9,60.4,89.7,61.9,85.1,61.6,83.5,60.5,82.7,58.1,83.9,55.2,85.8,54.2,87.8,53.8,89.9
    .openmap Netherstorm
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Azeroth Farming
#loop
#hidewindow
#subgroup Un'Goro Crater
#name Herbalism8
#displayname Herbalism
step
    #sticky
    .waypoint Un'Goro Crater,50,50
    .zone Un'Goro Crater >> Head to Un'Goro Crater
step
    #hidewindow
    +test
    .loop @20,Un'Goro Crater,48.1,15.4,50.5,20.0,53.9,21.6,61.7,22.3,59.9,26.9,56.8,31.8,58.7,35.8,69.5,30.5,73.7,33.6,75.4,38.8,78.8,41.4,76.2,44.2,76.3,57.4,74.3,67.9,68.4,76.5,64.2,78.0,60.9,81.8,58.0,84.7,55.7,88.4,53.9,84.9,46.7,86.5,41.6,82.3,44.4,73.8,48.7,64.6,52.0,56.9,50.7,53.4,50.8,51.9,53.6,49.9,52.5,47.9,51.9,45.4,47.5,46.9,46.5,52.8,40.2,54.9,39.5,62.2,36.1,75.3,30.8,78.5,27.6,67.4,25.5,61.6,22.2,59.5,24.3,55.7,24.2,51.1,22.2,49.7,24.5,46.4,22.0,40.7,26.1,37.8,27.1,32.4,33.9,34.3,37.1,33.8,33.7,26.4,30.5,20.7,38.0,21.1,46.6,33.4,49.8,30.1,44.6,18.9,48.1,15.4
    .openmap Un'Goro Crater
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Azeroth Farming
#loop
#hidewindow
#subgroup Un'Goro Crater
#name Mining8
#displayname Mining
step
    #sticky
    .waypoint Un'Goro Crater,50,50
    .zone Un'Goro Crater >> Head to Un'Goro Crater
step
    #hidewindow
    +test
    .loop @20,Un'Goro Crater,44.0,18.4,48.9,15.7,52.8,29.6,55.7,32.7,61.7,33.6,58.7,23.9,57.5,15.0,60.2,16.8,63.7,16.9,65.2,21.4,69.1,20.7,70.8,25.5,75.4,38.4,79.0,41.1,76.4,44.1,76.4,56.6,79.4,60.3,74.9,61.9,73.9,68.5,69.6,68.3,60.6,66.0,61.9,74.9,63.3,78.6,61.1,81.7,57.9,85.3,56.2,89.9,54.7,86.5,50.9,86.5,45.0,82.9,48.9,80.4,51.6,70.9,53.7,65.3,47.6,63.5,49.6,53.8,53.5,49.9,52.1,45.4,50.3,47.6,47.7,47.2,46.1,52.6,39.7,61.1,38.0,77.9,31.9,78.5,32.5,71.9,29.1,68.3,25.3,61.2,23.0,58.2,24.3,56.1,24.4,43.1,22.6,41.5,35.6,35.6,44.3,34.8,44.1,29.2,35.6,22.4,38.9,18.7,44.0,18.4
    .openmap Un'Goro Crater
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Azeroth Farming
#loop
#hidewindow
#subgroup Un'Goro Crater
#name Mining & Herbalism8
#displayname Mining & Herbalism
step
    #sticky
    .waypoint Un'Goro Crater,50,50
    .zone Un'Goro Crater >> Head to Un'Goro Crater
step
    #hidewindow
    +test
    .loop @20,Un'Goro Crater,44.0,18.4,48.9,15.7,50.7,19.1,52.9,31.4,58.9,35.8,62.6,32.7,58.7,23.9,54.8,13.6,56.4,10.7,60.0,18.0,63.7,16.9,65.2,21.4,69.1,20.7,70.9,28.0,69.5,30.5,73.2,32.4,75.4,38.4,79.0,41.1,76.4,44.1,76.4,56.6,79.4,60.3,74.9,61.9,73.9,68.5,69.6,68.3,60.6,66.0,60.4,72.6,63.3,78.6,61.1,81.7,57.9,85.3,56.2,89.9,54.1,85.1,50.9,86.5,45.0,82.9,48.9,80.4,51.6,70.9,53.7,65.3,47.6,63.5,49.6,53.8,53.5,49.9,52.1,45.4,50.3,47.6,47.7,47.2,46.1,52.6,39.7,61.1,38.0,77.9,31.9,78.5,32.5,71.9,29.1,68.3,25.3,61.2,23.0,58.2,24.3,56.1,24.4,43.1,22.6,41.5,35.6,35.6,44.3,34.8,44.1,29.2,35.6,22.4,38.9,18.7,44.0,18.4
    .openmap Un'Goro Crater
]])

RXPGuides.RegisterGuide([[#wotlk
#group +Azeroth Farming
#loop
#hidewindow
#subgroup Winterspring
#name Mining9
#displayname Mining
step
    #sticky
    .waypoint Winterspring,50,50
    .zone Winterspring >> Head to Winterspring
step
    #hidewindow
    +test
    .loop @20,Winterspring,58.3,33.3,55.9,27.3,51.5,24.6,48.6,11.3,48.8,8.6,55.5,13.7,60.3,17.4,62.1,21.8,65.7,19.9,64.7,25.9,65.8,29.0,65.1,33.3,67.2,35.6,68.8,38.1,66.8,39.5,66.3,54.4,65.0,58.1,65.7,60.4,62.5,66.7,61.7,70.9,62.7,74.2,59.6,75.6,60.3,78.4,62.8,78.7,64.4,79.5,64.4,79.5,62.8,78.7,60.3,78.4,61.2,82.2,62.0,83.6,59.0,83.5,59.1,87.0,57.4,88.9,55.3,84.1,53.8,84.8,53.6,86.1,53.1,86.3,52.7,88.5,51.4,89.2,53.0,84.8,55.0,79.9,56.8,79.4,58.2,72.6,57.7,68.0,61.8,70.9,62.5,66.5,62.1,63.1,58.6,61.1,56.5,53.2,55.8,49.8,57.6,47.0,57.1,43.7,53.3,44.5,48.6,43.3,45.0,44.1,45.0,37.7,48.0,37.1,51.9,38.1,53.2,38.0,58.3,33.3
    .openmap Winterspring
]])

