if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "CLASSIC" then return end

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Slaughter from the Shadows - 1 (Dun Morogh)
#title Slaughter from the Shadows

step << Rogue
    #season 2
    .goto Dun Morogh,47.658,51.706,5,0
    .goto Dun Morogh,47.160,52.335,5,0
    .goto Dun Morogh,46.917,51.995
    >>|cRXP_WARN_Get onto the roof of the Kharanos Inn, then jump on top of the massive keg. Follow the arrow|r
    >>Open the |cRXP_PICK_Rusty Lockbox|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Slaughter|r]
    .collect 203993,1 -- Rune of Slaughter (1)
    .train 424992,1
step << Rogue
    #season 2
    .train 424992 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Slaughter|r] |cRXP_WARN_to train|r |T236280:0|t[Slaughter from the Shadows]
    .use 203993
    .itemcount 203993,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Between the Eyes - 8 (Stormwind)
#title Between the Eyes

step << Rogue
    #season 2
    #completewith next
    .goto Stormwind City,56.93,29.54,8,0
    .goto Stormwind City,58.65,27.56,10 >> Enter the Cut-Throat Alley in Stormwind City at the Dwarven District
    .train 400081,1
step << Rogue
    #season 2
    .goto Stormwind City,63.201,29.491,5,0
    .goto Stormwind City,61.728,29.190
    >>|cRXP_WARN_Head upstairs into the house|r
    >>Open the |cRXP_PICK_Dusty Chest|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r]
    >>|cRXP_WARN_Doing this will spawn two level 10 |cRXP_ENEMY_Cut-throat Muggers|r which will attack you|r
    .collect 204174,1 -- Rune of Precision (1)
    .mob Cut-throat Mugger
    .train 400081,1
step << Rogue
    #season 2
    .train 400081 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r] |cRXP_WARN_to train|r |T135610:0|t[Between the Eyes]
    .use 204174
    .itemcount 204174,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Between the Eyes - 8 (Ironforge)
#title Between the Eyes

step << Rogue
    #season 2
    .goto Ironforge,51.913,13.383
    >>Open the |cRXP_PICK_Dusty Chest|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r]
    >>|cRXP_WARN_Doing this will spawn two level 10 |cRXP_ENEMY_Cut-throat Muggers|r which will attack you|r
    .collect 204174,1 -- Rune of Precision (1)
    .mob Cut-throat Mugger
    .train 400081,1
step << Rogue
    #season 2
    .train 400081 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r] |cRXP_WARN_to train|r |T135610:0|t[Between the Eyes]
    .use 204174
    .itemcount 204174,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Between the Eyes - 8 (Teldrassil)
#title Between the Eyes

step << Rogue
    #season 2
    .goto Teldrassil,38.92,79.93
    >>Kill or |T133644:0|t[Pick Pocket] |cRXP_ENEMY_Gnarlpine Pathfinders|r and |cRXP_ENEMY_Gnarlpine Avengers|r. Loot them for a |T134241:0|t[|cRXP_LOOT_Gnarlpine Stash Key]|r
    .collect 208749,1 -- Gnarlpine Stash Key (1)
    .mob Gnarlpine Pathfinder
    .mob Gnarlpine Avenger
    .train 400081,1
step << Rogue
    #season 2
    .goto Teldrassil,37.836,82.588
    >>Open the |cRXP_PICK_Gnarlpine Stash|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r]
    .collect 204174 -- Rune of Precision (1)
    .itemcount 208749,1
    .train 400081,1
step << Rogue
    #season 2
    .train 400081 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r] |cRXP_WARN_to train|r |T135610:0|t[Between the Eyes]
    .use 204174
    .itemcount 204174,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Blade Dance - 10 (Westfall)
#title Blade Dance

step << Rogue
    #season 2
    .goto Westfall,48.27,46.91,60,0
    .goto Westfall,46.39,37.38,60,0
    .goto Westfall,48.27,46.91
    >>|T133644:0|t[Pick Pocket] the |cRXP_ENEMY_Defias|r throughout Westfall. Loot them for a |T133463:0|t[|cRXP_LOOT_Discreet Envelope]|r
    >>|cRXP_WARN_You must be in|r |T132320:0|t[Stealth] |cRXP_WARN_to use|r |T133644:0|t[Pick Pocket]
    .collect 209031,1 -- Discreet Envelope (1)
    .mob Defias Trapper
    .mob Defias Smuggler
    .mob Defias Looter
    .train 400099,1
step << Rogue
    #season 2
    >>Open the |cRXP_PICK_Discreet Envelope|r. Loot it for the |T134237:0|t[|cRXP_LOOT_Equipment Stash Key]|r
    .collect 209030,1 -- Equipment Stash Key (1)
    .use 209031
    .itemcount 209031,1
    .train 400099,1
step << Rogue
    #season 2
    #map Westfall
    .goto 1415,40.805,80.235
    >>Head to the back enterance of the Deadmines
    >>Open the |cRXP_PICK_Equipment Stash|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r]
    .collect 208771,1 -- Rune of Blade Dance (1)
    .train 400099,1
step << Rogue
    #season 2
    .train 400099 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r] |cRXP_WARN_to train|r |T132350:0|t[Blade Dance]
    .use 208771
    .itemcount 208771,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Blade Dance - 16 (Dun Morogh)
#title Blade Dance

step << Rogue
    #season 2
    .goto Dun Morogh,77.86,61.66
    >>|T133644:0|t[Pick Pocket] |cRXP_ENEMY_Dark Iron Spies|r. Loot them for a |T133875:0|t[|cRXP_LOOT_Dark Iron Lockbox]|r
    >>|cRXP_WARN_You must be in|r |T132320:0|t[Stealth] |cRXP_WARN_to use|r |T133644:0|t[Pick Pocket]
    .collect 208838,1 -- Dark Iron Lockbox (1)
    .mob Dark Iron Spy
    .train 400099,1
step << Rogue
    #season 2
    >>Open the |T133875:0|t[|cRXP_LOOT_Dark Iron Lockbox]|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r]
    >>|cRXP_WARN_Note: You must have|r |T136058:0|t[Lockpicking] |cRXP_WARN_from your trainer to open it|r
    .collect 208771,1 -- Rune of Blade Dance (1)
    .itemcount 208838,1
    .train 400099,1
step << Rogue
    #season 2
    .train 400099 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r] |cRXP_WARN_to train|r |T132350:0|t[Blade Dance]
    .use 208771
    .itemcount 208771,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Blade Dance - 16 (Darkshore)
#title Blade Dance

step << Rogue
    #season 2
    #completewith learnBD
    .goto Darkshore,55.106,33.621,30 >> Enter the Cliffspring Naga cave
    .train 400099,1
step << Rogue
    #season 2
    .goto Darkshore,56.253,34.877
    >>Kill |cRXP_ENEMY_Stormscale Sirens|r and |cRXP_ENEMY_Stormscale Wave Rider|r. Loot them for a |T134242:0|t[|cRXP_LOOT_Cliffspring Key]|r
    .collect 211471,1 -- Cliffspring Key (1)
    .mob Stormscale Wave Rider
    .mob Stormscale Siren
    .train 400099,1
step << Rogue
    .goto Darkshore,56.253,34.877
    >>Open the |cRXP_PICK_Clliffspring Chest|r inside of the cave. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r]
    .collect 208771,1 -- Rune of Blade Dance (1)
    .itemcount 211471,1
    .train 400099,1
step << Rogue
    #season 2
    .train 400099 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r] |cRXP_WARN_to train|r |T132350:0|t[Blade Dance]
    .use 208771
    .itemcount 208771,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Mutilate - 5 (Elwynn Forest)
#title Mutilate

step << Rogue
    #season 2
    .goto Elwynn Forest,57.5,48.2
    >>|T133644:0|t[Pick Pocket] |cRXP_ENEMY_Garrick Padfoot|r for |T134331:0|t[Cutty's Note]
    >>|cRXP_WARN_You must be in|r |T132320:0|t[Stealth] |cRXP_WARN_to use|r |T133644:0|t[Pick Pocket]
    .collect 203723,1 -- Cutty's Note (1)
    .mob Garrick Padfoot
    .train 400094,1
step << Rogue
    #season 2
    .goto Elwynn Forest,49.983,52.012
    >>Talk to |cRXP_FRIENDLY_Cutty|r just south of the Northshire Valley wall
    >>He will give you the |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r]
    .collect 203990,1 -- Rune of Mutilation (1)
    .skipgossip
    .target Cutty
    .train 400094,1
step << Rogue
    #season 2
    .cast 402265 >> |cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r]
    .use 203990 -- Rune of Mutilation (1)
    .target Cutty
    .train 400094,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Mutilate - 8 (Dun Morogh)
#title Mutilate

step << Rogue
    #season 2
    .goto Dun Morogh,77.86,61.66
    >>|T133644:0|t[Pick Pocket] |cRXP_ENEMY_Dark Iron Spies|r. Loot them for |T134331:0|t[Blackrat's Note]
    >>|cRXP_WARN_You must be in|r |T132320:0|t[Stealth] |cRXP_WARN_to use|r |T133644:0|t[Pick Pocket]
    .collect 208205,1 --Blackrat's Note (1)
    .mob Dark Iron Spy
    .train 400094,1
step << Rogue
    #season 2
    .goto Dun Morogh,57.256,45.227
    >>Talk to |cRXP_FRIENDLY_Blackrat|r to receive the |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r]
    .collect 203990,1
    .skipgossip
    .train 400094,1
step << Rogue
    #season 2
    .cast 402265 >> |cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r]
    .use 203990 -- Rune of Mutilation (1)
    .train 400094,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Saber Slash - 12 (Westfall)
#title Saber Slash

step << Rogue
    #season 2
    .goto Westfall,51.540,55.361,30,0
    .goto Westfall,51.093,54.642,30,0
    .goto Westfall,50.81,47.15,50,0
    .goto Westfall,51.093,54.642
    >>|T133644:0|t[Pick Pocket] the |cRXP_ENEMY_Defias Scout|r for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    >>|cRXP_WARN_You must be in|r |T132320:0|t[Stealth] |cRXP_WARN_to use|r |T133644:0|t[Pick Pocket]
    .collect 208772,1 -- Rune of Saber Slash (1)
    .mob Defias Scout
    .train 424785,1
step << Rogue
    #season 2
    .cast 402265 >> |cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    .use 208772 -- Rune of Saber Slash (1)
    .train 424785,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Saber Slash - 12 (Loch Modan)
#title Saber Slash

step << Rogue
    #season 2
    #completewith next
    .goto Loch Modan,41.01,12.60,50,0
    .goto Loch Modan,42.86,10.36,60,0
    .goto Loch Modan,46.20,13.15,10 >> |cRXP_WARN_Make your way onto the Loch Modan dam wall and carefully drop down onto the ledge in the center of the dam. Follow the arrow|r
    .train 424785,1
step << Rogue
    #season 2
    .goto Loch Modan,46.373,12.666
    >>Open the |cRXP_PICK_Stonemason's Toolbox|r on the ledge. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    .collect 208772,1 -- Rune of Saber Slash (1)
    .train 424785,1
step << Rogue
    #season 2
    .cast 402265 >> |cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    .use 208772 -- Rune of Saber Slash (1)
    .train 424785,1
step << Rogue
    #season 2
    .goto Loch Modan,45.823,12.652
    .cast 6477 >> Click the |cRXP_PICK_Escape Rope|r to return to the top
    .subzoneskip 146,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Saber Slash - 1 (Darkshore)
#title Saber Slash

step << Rogue
    #season 2
    #completewith next
    .goto Darkshore,32.80,37.72,20 >> Swim to the small island with the Lighthouse on it
    .train 424785,1
step << Rogue
    #season 2
    .goto Darkshore,32.729,37.093
    >>Open the |cRXP_PICK_Lighthouse Stash|r inside the tree trunk. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    .collect 208772,1 -- Rune of Saber Slash (1)
    .train 424785,1
step << Rogue
    #season 2
    .cast 402265 >> |cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    .use 208772 -- Rune of Saber Slash (1)
    .train 424785,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Shadowstrike - 2 (Durotar)
#title Shadowstrike


    --Rune of Shadowstrike

step << Troll/Orc
    #season 2
    .goto Durotar,41.27,68.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rwag|r
    .accept 77592 >>Accept Atop the Cliffs << Troll
    .accept 77583 >>Accept Atop the Cliffs << Orc
    .target Rwag
step
    #season 2
    .goto Durotar,43.27,69.51
    >>Open the |cRXP_PICK_Hidden Cache|r. Loot it for the |T134419:0|t|cRXP_LOOT_[Rune of Shadowstrike]|r
    >>|cRXP_WARN_Walk around past|r |cRXP_ENEMY_Sarkoth|r |cRXP_WARN_and jump down to reach the chest|r
    .collect 204795,1 --Rune of Shadowstrike (1)
    .train 400105,1
step
    #season 2
    .train 400105 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Rune of Shadowstrike]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Shadowstrike]
    .use 204795
    .itemcount 204795,1 --Rune of Shadowstrike (1)
step << Troll/Orc
    #season 2
    .goto Durotar,41.27,68.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rwag|r
    .turnin 77592 >>Turn in Atop the Cliffs << Troll
    .turnin 77583 >>Turn in Atop the Cliffs << Orc
    .target Rwag
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Shadowstrike - 2 (Tirisfal)
#title Shadowstrike


    --Rune of Shadowstrike

step << Undead
    #season 2
    .goto Tirisfal Glades,32.53,65.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_David|r
    .accept 77669 >>Accept The Scarlet Rune
    .target David Trias
step
    #season 2
#loop
	.line Tirisfal Glades,36.13,68.74,36.46,69.49,36.85,70.02,37.42,69.58,38.05,69.79,37.91,69.22,38.03,68.77,38.49,68.28,38.72,67.07,38.59,66.25,38.65,65.07,37.62,65.36,36.93,65.38,36.51,65.42,36.85,66.59,37.45,67.95,36.93,68.16,36.13,68.74
	.goto Tirisfal Glades,36.13,68.74,25,0
	.goto Tirisfal Glades,36.46,69.49,25,0
	.goto Tirisfal Glades,36.85,70.02,25,0
	.goto Tirisfal Glades,37.42,69.58,25,0
	.goto Tirisfal Glades,38.05,69.79,25,0
	.goto Tirisfal Glades,37.91,69.22,25,0
	.goto Tirisfal Glades,38.03,68.77,25,0
	.goto Tirisfal Glades,38.49,68.28,25,0
	.goto Tirisfal Glades,38.72,67.07,25,0
	.goto Tirisfal Glades,38.59,66.25,25,0
	.goto Tirisfal Glades,38.65,65.07,25,0
	.goto Tirisfal Glades,37.62,65.36,25,0
	.goto Tirisfal Glades,36.93,65.38,25,0
	.goto Tirisfal Glades,36.51,65.42,25,0
	.goto Tirisfal Glades,36.85,66.59,25,0
	.goto Tirisfal Glades,37.45,67.95,25,0
	.goto Tirisfal Glades,36.93,68.16,25,0
	.goto Tirisfal Glades,36.13,68.74,25,0
    >>Kill or pickpocket |cRXP_ENEMY_Scarlet Converts|r. Loot them for the |T134419:0|t|cRXP_LOOT_[Rune of Shadowstrike]|r
    .collect 204795,1 --Rune of Shadowstrike (1)
    .mob Scarlet Convert
    .train 400105,1
step
    #season 2
    .train 400105 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Rune of Shadowstrike]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Shadowstrike]
    .use 204795
    .itemcount 204795,1 --Rune of Shadowstrike (1)
step << Undead
    #season 2
    .goto Tirisfal Glades,32.53,65.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_David|r
    .turnin 77669 >>Turn in The Scarlet Rune
    .target David Trias
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Deadly Brew - 25 (Silverpine Forest)
#title Deadly Brew


    --Rune of Deadly Brew

step
    #season 2
    .goto Silverpine Forest,47.12,71.01
    >>Click the |cRXP_PICK_Dead Drop|r in Silverpine Forest
    .accept 78261 >> Accept The Horn of Xelthos
step
    #season 2
    #completewith next
    .zone 209 >> Enter Shadowfang Keep
    >>|cRXP_WARN_You have to do the next part solo! Grouping up will prevent you from obtaining the keys you need|r
step << Horde
    #season 2
    .gossipoption 96495,1 >>Stealth past |cRXP_ENEMY_Rethilgore|r, talk to |cRXP_FRIENDLY_Deathstalker Adamant|r and |T132331:0|t[Vanish] aftwards. He will open the door for you
    .target Deathstalker Adamant
    .train 400080,1
step << Alliance
    #season 2
    .gossipoption 96494 >>Stealth past |cRXP_ENEMY_Rethilgore|r, talk to |cRXP_FRIENDLY_Sorcerer Ashcrombe|r and |T132331:0|t[Vanish] aftwards. He will open the door for you
    .target Sorcerer Ashcrombe
    .train 400080,1
step
    #season 2
    #completewith next
    >>Use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Gemela|r for |T134243:0|t[|cRXP_LOOT_Sister's Half-Key|r]
    >>|cRXP_WARN_She is located in the dining hall on the bottom floor|r
    .collect 210213,1 --Sister's Half-Key (1)
    .mob Gemela
step
    #season 2
    >>Use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Gefell|r for |T134244:0|t[|cRXP_LOOT_Brother's Half-Key|r]
    >>|cRXP_WARN_He is located above the dining hall on the second floor|r
    .collect 210212,1 --Brother's Half-Key (1)
    .mob Gefell
    .train 400080,1
step
    #season 2
    >>Use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Gemela|r for |T134243:0|t[|cRXP_LOOT_Sister's Half-Key|r]
    >>|cRXP_WARN_She is located in the dining hall on the bottom floor|r
    .collect 210213,1 --Sister's Half-Key (1)
    .mob Gemela
    .train 400080,1
step
    #season 2
    .use 210212 >>Return to the courtyard outside and enter the Stables. Combine the two keys for the |T237379:0|t[|cRXP_LOOT_Twin Key|r]
    .collect 210209,1 --Twin Key (1)
    .train 400080,1
step
    #season 2
    >>Open the |cRXP_PICK_Ornamented Chest|r in the stables for the |cRXP_LOOT_Horn of Xelthos|r
    .complete 78261,1 --Horn of Xelthos (1)
step
    #season 2
    .goto Silverpine Forest,47.114,70.974
    >>Click the |cRXP_PICK_Dead Drop|r in Silverpine Forest
    .turnin 78261 >> Turn in The Horn of Xelthos
step
    #season 2
    #completewith next
    +|cRXP_WARN_You now need to enter a capital city to receive mail from *C*|r
    .train 400080,1
step << Horde
    #season 2
    .goto Silverpine Forest,45.62,42.58
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karos|r
    .fly Undercity >> Fly to the Undercity
    .target Karos Razok
    .zoneskip Undercity
    .train 400080,1
step << Alliance
    >>Run to Southshore
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darla Harris|r
    .goto Hillsbrad Foothills,49.338,52.272
    .fly Ironforge >> Fly to Ironforge
    .target Darla Harris
    .train 400080,1
step
    .goto Undercity,68.290,38.043,5 >> |cRXP_WARN_Enter Undercity. Check your mailbox for the letter from *C*|r << Horde
    .goto Ironforge,71.485,72.280,5 >> |cRXP_WARN_Enter Ironforge. Check your mailbox for the letter from *C*. Skip this step if you're doing it in another major city|r << Alliance
    .train 400080,1
step
    #season 2
    #completewith next
    +|cRXP_WARN_Open your mailbox to read the mail from *C* once it has arrived. Fly back to Silverpine when you're ready|r << Horde
    +|cRXP_WARN_Open your mailbox to read the mail from *C* once it has arrived. Fly back to Southshore then make your way to Silverpine when you're ready|r << Alliance
step << Horde
    #season 2
    .goto Undercity,63.27,48.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
    .fly The Sepulcher>> Fly to The Sepulcher
    .target Michael Garrett
    .zoneskip Silverpine Forest
    .train 400080,1
step << Alliance
    .goto Ironforge,55.501,47.742
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
    .fly Southshore >> Fly to Southshore
    .target Gryth Thurden
    .zoneskip Silverpine Forest
    .train 400080,1
step << Alliance
    #completewith next
    .zone Silverpine Forest >> Travel to Silverpine Forest
    .train 400080,1
step
    #season 2
    .goto Silverpine Forest,47.114,70.974
    >>Click the |cRXP_PICK_Dead Drop|r in Silverpine Forest for |T134419:0|t[|cRXP_FRIENDLY_Rune of Deadly Brew|r]
    .collect 203994,1 --Rune of Deadly Brew (1)
    .train 400080,1
step
    #season 2
    .train 400080 >>Use the |T134419:0|t[|cRXP_FRIENDLY_Rune of Deadly Brew|r]
    .use 204795
    .itemcount 204795,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Quick Draw - 10 (Durotar)
#title Quick Draw


    --Rune of Quick Draw

step
    #season 2
    .goto Durotar,57.65,58.52,30,0
    .goto Durotar,57.36,56.59,30,0
    .goto Durotar,58.10,55.52,30,0
    .goto Durotar,58.54,53.68,30,0
    .goto Durotar,56.54,54.52,30,0
    .goto Durotar,56.37,58.35,30,0
    .goto Durotar,58.99,58.30
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Kul Tiras Sailors|r and |cRXP_ENEMY_Kul Tiras Marines|r. Loot them for |T134327:0|t[|cRXP_LOOT_Top-Right Map Piece|r]
    .collect 207109,1 --Top-Right Map Piece (1)
    .mob Kul Tiras Sailor
    .mob Kul Tiras Marine
    .train 400095,1
step
    #season 2
    .goto Durotar,50.21,50.78,30,0
    .goto Durotar,50.18,49.23,30,0
    .goto Durotar,49.48,49.14,30,0
    .goto Durotar,49.32,48.18,30,0
    .goto Durotar,48.81,49.00,30,0
    .goto Durotar,48.49,49.29,30,0
    .goto Durotar,47.58,49.62,30,0
    .goto Durotar,47.06,49.53,30,0
    .goto Durotar,46.90,48.11,30,0
    .goto Durotar,49.22,48.96
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Razormane Quilboars|r and |cRXP_ENEMY_Razormane Scouts|r.  Loot them for |T134327:0|t[|cRXP_LOOT_Bottom-Right Map Piece|r]
    .collect 207107,1 --Bottom-Right Map Piece (1)
    .mob Razormane Quilboar
    .mob Razormane Scout
    .train 400095,1
step
    #season 2
#loop
	.line Durotar,67.23,88.76,66.52,87.74,65.94,86.72,65.90,84.04,65.88,82.85,67.38,82.61,68.42,82.43,68.50,84.32,68.47,86.77,67.23,88
	.goto Durotar,67.23,88.76,25,0
	.goto Durotar,66.52,87.74,25,0
	.goto Durotar,65.94,86.72,25,0
	.goto Durotar,65.90,84.04,25,0
	.goto Durotar,65.88,82.85,25,0
	.goto Durotar,67.38,82.61,25,0
	.goto Durotar,68.42,82.43,25,0
	.goto Durotar,68.50,84.32,25,0
	.goto Durotar,68.47,86.77,25,0
	.goto Durotar,67.23,88.00,25,0
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Hexed Trolls|r and |cRXP_ENEMY_Voodoo Trolls|r. Loot them for |T134327:0|t[|cRXP_LOOT_Bottom-Left Map Piece|r]
    .collect 207106,1 --Bottom-Left Map Piece (1)
    .mob Hexed Troll
    .mob Voodoo Troll
    .train 400095,1
step
    #completewith next
    .goto Durotar,55.12,10.10,60 >> Travel toward Skull Rock
step
    #season 2
    .goto Durotar,54.72,8.78,15,0
    .goto Durotar,54.29,8.89,15,0
    .goto Durotar,53.77,8.87,15,0
    .goto Durotar,53.37,7.73,15,0
    .goto Durotar,52.73,7.85,15,0
    .goto Durotar,52.42,8.59,15,0
    .goto Durotar,51.65,8.19,15,0
    .goto Durotar,51.39,8.71,15,0
    .goto Durotar,51.48,9.71,15,0
    .goto Durotar,53.77,8.87
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Burning Blade Orcs|r. Loot them for |T134327:0|t[|cRXP_LOOT_Top-Left Map Piece|r]
    .collect 207108,1 --Top-Left Map Piece (1)
    .mob Burning Blade Thug
    .mob Burning Blade Fanatic
    .mob Burning Blade Apprentice
    .train 400095,1
step
    #season 2
    .use 207108 >>Use the |T134327:0|t[|cRXP_LOOT_Map Pieces|r] to create |T134269:0|t[|cRXP_LOOT_Durotar Treasure Map|r]
    .collect 207110,1 --Durotar Treasure Map (1)
    .train 400095,1
step
    #season 2
    .goto Durotar,62.14,94.66
    .use 207110 >>Use the |T134269:0|t[|cRXP_LOOT_Durotar Treasure Map|r] on the southernmost Echo Island
    >>Loot the |cRXP_PICK_Buried Treasure|r chest that spawns for |T134419:0|t[|cRXP_FRIENDLY_Rune of Quick Draw|r]
    .collect 203991,1 --Rune of Quick Draw (1s)
    .train 400095,1
step
    #season 2
    .train 400095 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Quick Draw|r] |cRXP_WARN_to train|r |T134536:0|t[Quick Draw]
    .use 203991
    .itemcount 203991,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Quick Draw - 10 (Tirisfal)
#title Quick Draw


    --Rune of Quick Draw

step
    #season 2
    .goto Tirisfal Glades,37.20,52.17,50,0
    .goto Tirisfal Glades,36.64,50.09,50,0
    .goto Tirisfal Glades,36.10,49.07,50,0
    .goto Tirisfal Glades,35.08,49.82,50,0
    .goto Tirisfal Glades,35.30,50.91,50,0
    .goto Tirisfal Glades,34.57,51.58,50,0
    .goto Tirisfal Glades,36.63,50.09
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Tirisfal Farmers|r and |cRXP_ENEMY_Tirisfal Farmhands|r. Loot them for |T134327:0|t[|cRXP_LOOT_Top-Left Map Piece|r]
    .collect 208036,1 --Top-Left Map Piece (1)
    .mob Tirisfal Farmer
    .mob Tirisfal Farmhand
    .train 400095,1
step
    #season 2
    #loop
    .goto Tirisfal Glades,31.78,51.36,0
    .goto Tirisfal Glades,33.73,49.34,50,0
    .goto Tirisfal Glades,33.65,51.07,50,0
    .goto Tirisfal Glades,31.78,51.36,50,0
    .goto Tirisfal Glades,30.02,50.48,50,0
    .goto Tirisfal Glades,29.91,49.24,50,0
    .goto Tirisfal Glades,30.62,47.53,50,0
    .goto Tirisfal Glades,31.01,46.50,50,0
    .goto Tirisfal Glades,32.15,44.83,50,0
    .goto Tirisfal Glades,33.73,45.29,50,0
    .goto Tirisfal Glades,34.10,47.88,50,0
    .goto Tirisfal Glades,33.73,49.34,50,0
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Scarlet Warriors|r. Loot them for |T134327:0|t[|cRXP_LOOT_Top-Right Map Piece|r]
    >>|cRXP_WARN_Any of the Scarlet Humanoids in Tirisfal can drop the Map Piece|r
    .collect 208035,1 --Top-Right Map Piece (1)
    .mob Scarlet Warrior
    .train 400095,1
step
    #season 2
    .goto Tirisfal Glades,56.31,39.67,40,0
    .goto Tirisfal Glades,54.71,41.19,40,0
    .goto Tirisfal Glades,53.90,43.93,40,0
    .goto Tirisfal Glades,55.24,42.54,40,0
    .goto Tirisfal Glades,56.43,43.92,40,0
    .goto Tirisfal Glades,55.24,42.54
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Rot Hide Gnolls|r. Loot them for |T134327:0|t[|cRXP_LOOT_Bottom-Left Map Piece|r]
    .collect 208038,1 --Bottom-Left Map Piece (1)
    .mob Rot Hide Mongrel
    .mob Rot Hide Graverobber
    .mob Rot Hide Gnoll
    .train 400095,1
step
    #season 2
    .goto Tirisfal Glades,59.38,29.05,50,0
    .goto Tirisfal Glades,59.54,27.86,50,0
    .goto Tirisfal Glades,60.64,28.66,50,0
    .goto Tirisfal Glades,61.49,29.40,50,0
    .goto Tirisfal Glades,62.96,29.46,50,0
    .goto Tirisfal Glades,65.68,30.22,50,0
    .goto Tirisfal Glades,67.48,28.97,50,0
    .goto Tirisfal Glades,68.22,26.46,50,0
    .goto Tirisfal Glades,59.54,27.86
    >>Kill or use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Murlocs|r. Loot them for |T134327:0|t[|cRXP_LOOT_Bottom-Right Map Piece|r]
    .collect 208037,1 --Bottom-Right Map Piece (1)
    .mob Vile Fin Puddlejumper
    .mob Vile Fin Minor Oracle
    .mob Vile Fin Muckdweller
    .train 400095,1
step
    #season 2
    .use 208036 >>Use the |T134327:0|t[|cRXP_LOOT_Map Pieces|r] to create |T134269:0|t[|cRXP_LOOT_Tirisfal Treasure Map|r]
    .collect 208034,1 --Tirisfal Treasure Map (1)
    .train 400095,1
step
    #season 2
    .goto Tirisfal Glades,52.89,54.03
    .use 208034 >>Use the |T134269:0|t[|cRXP_LOOT_Tirisfal Treasure Map|r] below the bridge
    >>Loot the |cRXP_PICK_Buried Treasure|r chest that spawns for |T134419:0|t[|cRXP_FRIENDLY_Rune of Quick Draw|r]
    .collect 203991,1 --Rune of Quick Draw (1s)
    .train 400095,1
step
    #season 2
    .train 400095 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Quick Draw|r] |cRXP_WARN_to train|r |T134536:0|t[Quick Draw]
    .use 203991
    .itemcount 203991,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Slaughter from the Shadows - 10 (Durotar)
#title Slaughter from the Shadows


    --Rune of Slaughter from the Shadows

step
    #completewith next
    .goto Durotar,54.25,27.64,40 >>Travel to the jump spot just east of Dustwind Cave
step
    #season 2
    .goto Durotar,54.25,27.64,40,0
    .goto Durotar,53.74,27.14
    >>Loot the |cRXP_PICK_Rusty Lockbox|r for |T134419:0|t[|cRXP_FRIENDLY_Rune of Slaughter|r]
    >>|cRXP_WARN_You'll have to make a small jump to be able to reach the chest|r
    .collect 203993,1 --Rune of Slaughter (1)
    .train 42992,1
step
    #season 2
    .train 42992 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Slaughter|r] |cRXP_WARN_to train|r |T236280:0|t[Slaughter from the Shadows]
    .use 203993
    .itemcount 203993,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Slaughter from the Shadows - 10 (Tirisfal)
#title Slaughter from the Shadows


    --Rune of Slaughter from the Shadows


step
    #season 2
    .goto Tirisfal Glades,47.39,43.64,150,0
    .goto Tirisfal Glades,52.23,26.91,20,0
    .goto Tirisfal Glades,52.29,26.40,8 >> Travel to the crypt in Agamand Mills
step
    #season 2
#loop
	.line Tirisfal Glades,51.88,25.86,52.61,25.85,52.60,26.88,51.90,26.87
	.goto Tirisfal Glades,51.88,25.86,15,0
	.goto Tirisfal Glades,52.61,25.85,15,0
	.goto Tirisfal Glades,52.60,26.88,15,0
	.goto Tirisfal Glades,51.90,26.87,15,0
    >>Kill |cRXP_ENEMY_Wailing Ancestors|r and |cRXP_ENEMY_Rotting Ancestors|r. Loot them for an |T134245:0|t[|cRXP_LOOT_Agamand Relic Coffer Key|r]
    >>|cRXP_WARN_Be careful! The mobs in this crypt respawn dynamically!|r
    .collect 208005,1 --Agamand Relic Coffer Key (1)
    .mob Wailing Ancestor
    .mob Rotting Ancestor
    .train 42992,1
step
    #season 2
    .goto Tirisfal Glades,52.53,26.91
    >>Open the |cRXP_PICK_Relic Coffer|r for |T134419:0|t[|cRXP_FRIENDLY_Rune of Slaughter|r]
    .collect 203993,1 --Rune of Slaughter (1)
    .train 42992,1
step
    #season 2
    .train 42992 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Slaughter|r] |cRXP_WARN_to train|r |T236280:0|t[Slaughter from the Shadows]
    .use 203993
    .itemcount 203993,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Mutilate - 8 (Tirisfal)
#title Mutilate


    --Rune of Mutilate

step
    #season 2
    .goto Tirisfal Glades,51.17,67.81
    >>Use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Captain Perrine|r for a |T133385:0|t[|cRXP_LOOT_Scarlet Lieutenant Signet Ring|r]
    .collect 208085,1 --Scarlet Lieutenant Signet Ring (1)
    .mob Captain Perrine
    .train 400094,1
step
    #season 2
    #completewith next
    .goto Tirisfal Glades,60.90,51.49,10 >>Travel to the Brill Town Hall
step
    #season 2
    .goto Tirisfal Glades,60.73,50.60
    .use 208085 >>Use the |T133385:0|t[|cRXP_LOOT_Scarlet Lieutenant Signet Ring|r] to create |T134328:0|t[|cRXP_LOOT_Forged Scarlet Memorandum|r]
    .collect 208086,1 --Forged Scarlet Memorandum (1)
    .train 400094,1
step
    #season 2
    .goto Tirisfal Glades,60.73,50.60
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jamie Nore|r to receive |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r] from her
    .collect 203990,1 --Rune of Mutilation (1)
    .target Jamie Nore
    .skipgossip
    .train 400094,1
step
    #season 2
    .train 400094 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r] |cRXP_WARN_to train|r |T132304:0|t[Mutilate]
    .use 203990
    .itemcount 203990,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Mutilate - 10 (Durotar)
#title Mutilate


    --Rune of Mutilate

step
    #season 2
    #completewith next
    .goto Durotar,53.18,29.15,50 >> Travel toward Dustwind Cave
step
    #season 2
    .goto Durotar,53.18,29.15,20,0
    .goto Durotar,52.70,27.97,12,0
    .goto Durotar,53.05,27.87,12,0
    .goto Durotar,53.14,27.24,12,0
    .goto Durotar,52.84,26.80,12,0
    .goto Durotar,52.07,26.85,12,0
    .goto Durotar,52.70,27.97
    >>Use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Burning Blade Thugs|r for |T134331:0|t[|cRXP_LOOT_Note from Ba'so|r]
    .collect 207098,1 --Note from Ba'so (1)
    .mob Burning Blade Thug
    .train 400094,1
step
    .goto Durotar,51.82,58.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ba'so|r to receive |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r]
    >>|cRXP_WARN_He is stealthed!|r
    .collect 203990,1 --Rune of Mutilation (1)
    .target Ba'so
    .skipgossip
    .train 400094,1
step
    #season 2
    .train 400094 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Mutilation|r] |cRXP_WARN_to train|r |T132304:0|t[Mutilate]
    .use 203990
    .itemcount 203990,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Between the Eyes - 8 (Tirisfal)
#title Between the Eyes


    --Rune of Between the Eyes

step
    #season 2
    .goto Tirisfal Glades,59.38,29.05,50,0
    .goto Tirisfal Glades,59.54,27.86,50,0
    .goto Tirisfal Glades,60.64,28.66,50,0
    .goto Tirisfal Glades,61.49,29.40,50,0
    .goto Tirisfal Glades,62.96,29.46,50,0
    .goto Tirisfal Glades,65.68,30.22,50,0
    .goto Tirisfal Glades,67.48,28.97,50,0
    .goto Tirisfal Glades,68.22,26.46,50,0
    .goto Tirisfal Glades,59.54,27.86
    >>Use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Vile Fin Murlocs|r for |T134241:0|t[|cRXP_LOOT_Shipwreck Cache Key|r]
    .collect 208007,1 --Shipwreck Cache Key (1)
    .mob Vile Fin Puddlejumper
    .mob Vile Fin Minor Oracle
    .mob Vile Fin Muckdweller
    .train 400081,1
step
    #season 2
    .goto Tirisfal Glades,66.66,24.41
    >>Loot the |cRXP_PICK_Shipwreck Cache|r for |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r]
    .collect 204174,1 --Rune of Precision (1)
    .train 400081,1
step
    #season 2
    .train 400081 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r] |cRXP_WARN_to train|r |T135610:0|t[Between the Eyes]
    .use 204174
    .itemcount 204174,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Between the Eyes - 8 (Orgrimmar)
#title Between the Eyes


    --Rune of Between the Eyes

step
    #season 2
    .goto Orgrimmar,55.87,44.89
    >>Loot the |cRXP_PICK_Dusty Chest|r for |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r]
    >>|cRXP_WARN_It's located in The Drag on the upper floor|r
    .collect 204174,1 --Rune of Precision (1)
    .train 400081,1
step
    #season 2
    .train 400081 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Precision|r] |cRXP_WARN_to train|r |T135610:0|t[Between the Eyes]
    .use 204174
    .itemcount 204174,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Blade Dance - 15 (The Barrens)
#title Blade Dance


    --Rune of Blade Dance

step
    #season 2
    .goto The Barrens,64.40,44.09,50,0
    .goto The Barrens,63.62,46.26,50,0
    .goto The Barrens,64.23,47.10
    >>Use |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Southsea Brigands|r for |T132761:0|t[|cRXP_LOOT_Buccaneer's Matchbox|r]
    .collect 208768,1 --Buccaneer's Matchbox (1)
    .mob Southsea Brigand
    .train 400099,1
step
    #season 2
    .goto The Barrens,61.82,45.80
    >>Click the Powder Keg. Loot the |cRXP_PICK_Southsea Loot Stash|r that spawns for |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r]
    .collect 208771,1 --Rune of Blade Dance (1)
    .train 400099,1
step
    #season 2
    .train 400099 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Blade Dance|r] |cRXP_WARN_to train|r |T132350:0|t[Blade Dance]
    .use 208771
    .itemcount 208771,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Saber Slash - 15 (The Barrens)
#title Saber Slash


    --Rune of Saber Slash

step
    #season 2
    #completewith next
    +|cRXP_WARN_Your lockpicking skill must be at least 80 to obtain this rune!|r
    .skill pick lock,>80,1
step
    #season 2
    .goto The Barrens,62.31,54.22
    >>Loot the |cRXP_PICK_Stable Hand's Trunk|r on top of the stable for |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    >>|cRXP_WARN_Run upward the hill and jump on top of the castle wall. From there you can jump on top of the stable|r
    .collect 208772,1 --Rune of Saber Slash (1)
    .train 424984,1
step
    #season 2
    .train 424984 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r] |cRXP_WARN_to train|r |T132375:0|t[Saber Slash]
    .use 208772
    .itemcount 208772,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Saber Slash - 15 (Silverpine)
#title Saber Slash

    --Rune of Saber Slash

step
    #season 2
    .goto Silverpine Forest,45.25,68.06,20,0
    .goto Silverpine Forest,45.26,67.21
    >>Loot the |cRXP_PICK_Rusty Chest|r next to the Shadowfang Keep entrance for |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r]
    >>|cRXP_WARN_Use|r |T132307:0|t[Sprint] |cRXP_WARN_and then jump from the bridge toward the chest|r
    .collect 208772,1 --Rune of Saber Slash (1)
    .train 424984,1
step
    #season 2
    .train 424984 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Saber Slash|r] |cRXP_WARN_to train|r |T132375:0|t[Saber Slash]
    .use 208772
    .itemcount 208772,1
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Belt
#title Shadowstep
#name Shadowstep - 30 (Silverpine Forest)

step
    #completewith next
    .zone Silverpine Forest >>Travel to Silverpine Forest
step
    .train 400101,1
    >>Click the |cRXP_PICK_Dead Drop|r chest on the ground
    .goto Silverpine Forest,47.114,70.974
    .accept 78676 >>Accept The Eye of Bhossca
step
    #completewith next
    .zone Tirisfal Glades >>Travel to Tirisfal Glades to the Scarlet Monastery
step
    >>|cRXP_WARN_Open the|r |cRXP_PICK_Supply Locker|r |cRXP_WARN_inside the stable to get the|r |T132665:0|t[Scarlet Initiate's Uniform]
    .goto Tirisfal Glades,81.2,32.12
    .collect 210955,1
    .train 400101,1
step
    #completewith next
    .goto Eastern Kingdoms,47.44,19.69,10,0
    .goto Eastern Kingdoms,47.73,19.39,5 >> Enter the Scarlet Monastery: |cRXP_WARN_Graveyard|r dungeon |cRXP_WARN_ALONE|r
step
    >>Use |T133644:0|t[Pick Pocket] on a |cRXP_ENEMY_Scarlet Scryer|r to get |T134241:0|t[Scryer's Key]
    >>|cRXP_WARN_Make use of|r |T132289:0|t[Distract] |cRXP_WARN_to avoid being detected|r
    .goto Eastern Kingdoms,47.73,19.39
    .collect 210963,1
    .mob Scarlet Scryer
    .train 400101,1
step
    #completewith next
    .goto Eastern Kingdoms,47.79,19.59,5 >> Enter the Scarlet Monastery: |cRXP_WARN_Library|r dungeon |cRXP_WARN_ALONE|r
step
    #completewith next
    +|cRXP_WARN_Run to the hallway before the last boss|r
step
    >>Loot the |cRXP_PICK_Personal Letterbox|r on the left for the |T134331:0|t[|cRXP_LOOT_Confidential Message|r]
    .use 210955 >>|cRXP_WARN_Use the|r |T132665:0|t[Scarlet Initiate's Uniform] |cRXP_WARN_to make the NPCs neutral|r
    .goto Eastern Kingdoms,47.79,19.59
    .collect 210967,1
    .train 400101,1
step
    #completewith next
    .goto Eastern Kingdoms,47.73,19.39,5 >> Enter the Scarlet Monastery: |cRXP_WARN_Graveyard|r dungeon |cRXP_WARN_ALONE|r
step
    >>|cRXP_WARN_Go to the outside area inside the dungeon and look for a bench between two statues on the right and left walls|r
    *|cRXP_WARN_On both sides|r use /sit (doable while in stealth) on the benches until the emote |cRXP_WARN_"You hear the sound of stone moving"|r appears in chat.
    *Afterwards go to the Tomb next to |cRXP_WARN_the right wall|r and open the |cRXP_PICK_Stone Coffer|r for the |T134242:0|t[Reliquary Key]
    .goto Eastern Kingdoms,47.79,19.59
    .collect 210968,1
    .train 400101,1
step
    #completewith next
    .goto Eastern Kingdoms,47.79,19.59,5 >> Enter the Scarlet Monastery: |cRXP_WARN_Library|r dungeon |cRXP_WARN_ALONE|r
step
    #completewith next
    +|cRXP_WARN_Run to the "Gallery of Treasures"|r
step
    >>Loot the |cRXP_PICK_Padlocked Reliquary|r in the first room on the left for the |T134331:0|t[|cRXP_LOOT_Eye of Bhossca|r]
    .use 210955 >>|cRXP_WARN_Use the|r |T132665:0|t[Scarlet Initiate's Uniform] |cRXP_WARN_to make the NPCs neutral|r
    .goto Eastern Kingdoms,47.79,19.59
    .complete 78676,1 --1/1 Eye of Bhossca
    .train 400101,1
step
    #completewith next
    .zone Silverpine Forest >>Travel to Silverpine Forest
step
    .train 400101,1
    >>Click the |cRXP_PICK_Dead Drop|r chest on the ground
    .goto Silverpine Forest,47.1,71.1
    .turnin 78676 >>Turn in The Eye of Bhossca
step
    #completewith next
    +|cRXP_WARN_You now need to enter a capital city to receive mail from *C*|r
    .train 400101,1
step << Horde
    .goto Silverpine Forest,45.62,42.58
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karos|r
    .fly Undercity >> Fly to the Undercity
    .target Karos Razok
    .zoneskip Undercity
    .train 400101,1
step << Alliance
    >>Run to Southshore
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darla Harris|r
    .goto Hillsbrad Foothills,49.338,52.272
    .fly Ironforge >> Fly to Ironforge
    .target Darla Harris
    .train 400101,1
step
    .goto Undercity,68.290,38.043,5 >> |cRXP_WARN_Enter Undercity. Check your mailbox for the letter from *C*|r << Horde
    .goto Ironforge,71.485,72.280,5 >> |cRXP_WARN_Enter Ironforge. Check your mailbox for the letter from *C*. Skip this step if you're doing it in another major city|r << Alliance
    .train 400101,1
step
    #completewith next
    +|cRXP_WARN_Open your mailbox to read the mail from *C* once it has arrived. Fly back to Silverpine when you're ready|r << Horde
    +|cRXP_WARN_Open your mailbox to read the mail from *C* once it has arrived. Fly back to Southshore then make your way to Silverpine when you're ready|r << Alliance
step << Horde
    .goto Undercity,63.27,48.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
    .fly The Sepulcher>> Fly to The Sepulcher
    .target Michael Garrett
    .zoneskip Silverpine Forest
    .train 400101,1
step << Alliance
    .goto Ironforge,55.501,47.742
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
    .fly Southshore >> Fly to Southshore
    .target Gryth Thurden
    .zoneskip Silverpine Forest
    .train 400101,1
step << Alliance
    #completewith next
    .zone Silverpine Forest >> Travel to Silverpine Forest
    .train 400101,1
step
    .goto Silverpine Forest,47.114,70.974
    >>Click the |cRXP_PICK_Dead Drop|r chest for |T134419:0|t[|cRXP_FRIENDLY_Rune of Shadowstep|r]
    .collect 210979,1 --Rune of Shadowstep (1)
    .train 400101,1
step
    .train 400101 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Shadowstep|r] |cRXP_WARN_to learn|r |T132303:0|t[Shadowstep]
    .use 210979
    .itemcount 210979,1
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Belt
#name Shuriken Toss - 30 (Swamp of Sorrows)
#title Shuriken Toss

step
    .train 400096,1
    .train 1842 >>|cRXP_WARN_You have to learn|r |T136162:0|t[Disarm Trap] |cRXP_WARN_before you can obtain|r |T134419:0|t[|cRXP_FRIENDLY_Rune of the Assassin|r]
    .collect 5060,1 >>|cRXP_WARN_You also need|r |T134065:0|t[Thieves' Tools]
step
    #completewith next
    .zone Swamp of Sorrows >>Travel to Swamp of Sorrows
step
    .goto Swamp of Sorrows,41.48,29.97
    .train 400096,1
    .cast 1842 >>|cRXP_WARN_Cast|r |T136162:0|t[Disarm Trap] |cRXP_WARN_on the|r |cRXP_PICK_Dart Trap|r |cRXP_WARN_on the tree|r
step
    .goto Swamp of Sorrows,42.76,30.77
    >>Loot the |cRXP_PICK_Conspicuous Cache|r that spawned for |T134419:0|t[|cRXP_FRIENDLY_Rune of the Assassin|r]|r
    .collect 213139,1
step
    .itemcount 213139,1
    .use 213139
    .train 400096 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of the Assassin|r] |cRXP_WARN_to learn|r |T132330:0|t[Shuriken Toss]
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Boots
#name Master of Subtlety - 34 (Stranglethorn Vale)
#title Master of Subtlety

step
    .train 425103,1
    .skill lockpicking,125 >>|cRXP_WARN_You must level your|r |T136058:0|t[Lockpicking] |cRXP_WARN_to at least 125 to obtain the|r |T132299:0|t[Master of Subtlety] |cRXP_WARN_rune|r
step
    .train 425103,1
    #completewith next
    .zone Stranglethorn Vale >>Travel to Stranglethorn Vale
step
    .train 425103,1
    #completewith Uniform
    .goto Stranglethorn Vale,46.30,7.61,30 >> Enter The Stockpile (Kurzen's Cave)
step
    .train 425103,1
    #completewith next
    >>Cast |T133644:0|t[Pick Pocket] on |cRXP_ENEMY_Kurzen Elites|r and |cRXP_ENEMY_Kurzen Subchiefs|r for the |cRXP_LOOT_Compound Cage Key|r
    .collect 216616,1
    .mob Kurzen Elite
    .mob Kurzen Subchief
step
    #label Uniform
    .train 425103,1
    .goto Stranglethorn Vale,49.616,7.743
    >>Open the |cRXP_PICK_Kurzen Supply Crate|r. Loot it for the |cRXP_LOOT_Kurzen Fighter's Uniform|r
    .collect 216617,1
step
    .train 425103,1
    .goto Stranglethorn Vale,49.943,3.953,40,0
    .goto Stranglethorn Vale,49.617,7.562,40,0
    .goto Stranglethorn Vale,49.25,6.18
    >>|T133644:0|t[Pick Pocket] |cRXP_ENEMY_Kurzen Elites|r and |cRXP_ENEMY_Kurzen Subchiefs|r for the |cRXP_LOOT_Compound Cage Key|r
    .collect 216616,1
    .mob Kurzen Elite
    .mob Kurzen Subchief
step
    .train 425103,1
    #completewith next
    .goto Stranglethorn Vale,44.261,7.908,60 >> Exit the cave. Travel toward |cRXP_FRIENDLY_Wendel Mathers|r in the tower outside
step
    .train 425103,1
    .goto Stranglethorn Vale,44.261,7.908
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wendel Mathers|r in the tower
    >>|cRXP_WARN_He has a respawn timer of around 3 minutes|r
    .destroy 216616 >> Hand the |cRXP_LOOT_Compound Cage Key|r to him
    .destroy 216617 >> Hand the |cRXP_LOOT_Kurzen Fighter's Uniform|r to him
    .skipgossip 218230,1
    .target Wendel Mathers
step
    .train 425103,1
    #completewith next
    .subzone 35 >>Travel to Booty Bay
step
    .train 425103,1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Aransas|r
    >>She will give you |T133640:0|t[|cRXP_LOOT_Captain Aransas' Reward|r]
    .goto Stranglethorn Vale,27.681,76.648
    .skipgossip
    .collect 216618,1
    .target Captain Aransas
step
    .train 425103,1
    .use 216618 >>Open |T133640:0|t[|cRXP_LOOT_Captain Aransas' Reward|r] to receive the |T134419:0|t[|cRXP_FRIENDLY_Rune of Sublety|r] and |T338666:0|t[|cRXP_FRIENDLY_Jani's Charm|r]
    >>|cRXP_WARN_Do NOT destroy|r |T338666:0|t[|cRXP_FRIENDLY_Jani's Charm|r] |cRXP_WARN_as it is used for gather future runes|r
    .collect 213136,1
step
    .itemcount 213136,1
    .use 213136
    .train 425103 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Sublety|r] |cRXP_WARN_to train|r |T132299:0|t[Master of Subtlety]
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Boots
#title Rolling with the Punches
#name Rolling with the Punches - 27 (Thousand Needles)


step
    #optional
    .train 400093,1
    .skill lockpicking,45 >>|cRXP_WARN_You must level your|r |T136058:0|t[Lockpicking] |cRXP_WARN_to at least 45 to obtain the|r |T134919:0|t[Rolling with the Punches] |cRXP_WARN_rune|r
step
    .train 400093,1
    #completewith next
    .zone Thousand Needles >>Travel to |cFFfa9602Thousand Needles|r
step
    .train 400093,1
    #completewith next
    .goto Thousand Needles,18.44,21.58,10 >> Enter the large tent at Camp E'thok
step
    .train 400093,1
    .goto Thousand Needles,18.686,21.126
    >>Open the |cRXP_PICK_Sizable Stolen Strongbox|r. Loot it for the |T132597:0|t[|cRXP_LOOT_Large Strongbox|r]
    .collect 215451,1
step
    .train 400093,1
    .cast 1804 >>|cRXP_WARN_Cast|r |T136058:0|t[Pick Lock] |cRXP_WARN_on the|r |T132597:0|t[|cRXP_LOOT_Large Strongbox|r] |cRXP_WARN_to unlock it|r
    .usespell 1804
    .use 215451
step
    .train 400093,1
    .use 215451 >> Open the |T132597:0|t[|cRXP_LOOT_Large Strongbox|r]. Loot it for the |T132597:0|t[|cRXP_LOOT_Medium Strongbox|r]
    .collect 215452,1
step
    .train 400093,1
    .cast 1804 >>|cRXP_WARN_Cast|r |T136058:0|t[Pick Lock] |cRXP_WARN_on the|r |T132597:0|t[|cRXP_LOOT_Medium Strongbox|r] |cRXP_WARN_to unlock it|r
    .usespell 1804
    .use 215452
step
    .train 400093,1
    .use 215452 >> Open the |T132597:0|t[|cRXP_LOOT_Medium Strongbox|r]. Loot it for the |T132597:0|t[|cRXP_LOOT_Small Strongbox|r]
    .collect 215453,1
step
    .train 400093,1
    .cast 1804 >>|cRXP_WARN_Cast|r |T136058:0|t[Pick Lock] |cRXP_WARN_on the|r |T132597:0|t[|cRXP_LOOT_Small Strongbox|r] |cRXP_WARN_to unlock it|r
    .usespell 1804
    .use 215453
step
    .train 400093,1
    .use 215453 >> Open the |T132597:0|t[|cRXP_LOOT_Small Strongbox|r]. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of the Southpaw|r]
    .collect 213138,1
step
    .itemcount 213138,1
    .use 213138
    .train 400093 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of the Southpaw|r] |cRXP_WARN_to train|r |T134919:0|t[Rolling with the Punches]
]])

RXPGuides.RegisterGuide([[#classic
 << Rogue SoD
 #group RestedXP Rune & Books Guide
 #subgroup Helmet
 #title Focused Attacks
 #name Focused Attacks - 34 (Hinterlands)

 step
    >>|cRXP_WARN_You will need|r |T136175:0|t[Blind] |cRXP_WARN_and|r |T133587:0|t[Blinding Powder] |cRXP_WARN_to obtain the|r |T236274:0|t[Focused Attacks] |cRXP_WARN_rune|r
    .train 2094 >>Train |T136175:0|t[Blind]
    .collect 5530,1 -- Blinding Powder 1/1
    .train 432291,1
step
    #completewith next
    .zone The Hinterlands >>Travel to |cFFfa9602The Hinterlands|r
step
    .goto The Hinterlands,72.76,52.91
    >>Cast |T136175:0|t[Blind] on the |cRXP_ENEMY_Vilebranch Mask|r, then loot the |cRXP_PICK_Treasure of the Bat|r chest for |T134419:0|t[|cRXP_FRIENDLY_Rune of Focus|r]
    .collect 221433,1 -- rune of focus
    .mob Vilebranch Mask
    .train 432291,1
step
    .itemcount 221433,1
    .use 221433
    .train 432291 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Focus|r] |cRXP_WARN_to train|r |T236274:0|t[Focused Attacks]
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Bracers
#title Unfair Advantage
#name Unfair Advantage - 40 (Tanaris)

step
    .train 921 >>|cRXP_WARN_You need to train|r |T133644:0|t[Pick Pocket] |cRXP_WARN_to obtain the|r |T236285:0|t[Unfair Advantage] |cRXP_WARN_rune|r
    .train 432301,1
step
    #completewith CoinPurse
    .zone Tanaris >>|cRXP_WARN_Travel to|r |cFFfa9602Tanaris|r
step
    #completewith next
    .subzone 1336 >>Travel to Lost Rigger Cove
step
    #label CoinPurse
	.line Tanaris,70.94,42.85,72.22,44.35,72.58,45.30,71.07,46.03,71.25,47.98,72.39,48.23,72.59,47.10,73.27,47.99,74.25,47.27,73.68,45.89,72.58,45.30,72.22,44.35,70.94,42.85
	.goto Tanaris,70.94,42.85,50,0
	.goto Tanaris,72.22,44.35,50,0
	.goto Tanaris,72.58,45.30,50,0
	.goto Tanaris,71.07,46.03,50,0
	.goto Tanaris,71.25,47.98,50,0
	.goto Tanaris,72.39,48.23,50,0
	.goto Tanaris,72.59,47.10,50,0
	.goto Tanaris,73.27,47.99,50,0
	.goto Tanaris,74.25,47.27,50,0
	.goto Tanaris,73.68,45.89,50,0
	.goto Tanaris,72.58,45.30,50,0
	.goto Tanaris,72.22,44.35,50,0
	.goto Tanaris,70.94,42.85,50,0
    >>|cRXP_WARN_Cast|r |T133644:0|t[Pick Pocket] |cRXP_WARN_on|r |cRXP_ENEMY_Southsea Pirates|r |cRXP_WARN_and|r |cRXP_ENEMY_Southsea Freebooters|r |cRXP_WARN_until you receive a|r |T133639:0|t|cRXP_LOOT_Kidnapper's Coin Purse|r
    .collect 221371,1 - Kidnapper's Coin Purse 1/1
    .mob Southsea Pirate
    .mob Southsea Freebooter
    .train 432301,1
step
    >>Open the |T133639:0|t|cRXP_LOOT_Kidnapper's Coin Purse|r and loot it for a |T133302:0|t|cRXP_LOOT_Precious Medalion|r
    .collect 221370,1 -- Precious Medalion 1/1
    .use 221371
    .train 432301,1
step << Rogue
    .goto Tanaris,67,22
    .gossipoption 122303 >>Talk to |cRXP_FRIENDLY_Jabbey|r to receive the |T134419:0|t[|cRXP_FRIENDLY_Rune of Foul Play|r]
    .collect 221428,1 -- Rune of Foul Play
    .target Jabbey
    .train 432301,1
    .itemcount 221370,1
step << Rogue
    .itemcount 221428,1
    .use 221428
    .train 432301 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Foul Play|r] |cRXP_WARN_to train|r |T236285:0|t[Unfair Advantage]
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Bracers
#title Carnage
#name Carnage - 45 (Blasted Lands)

step
    #optional
    .skill lockpicking,225 >>|cRXP_WARN_You must level your|r |T136058:0|t[Lockpicking] |cRXP_WARN_to at least 225 to obtain the|r |T236268:0|t[Carnage] |cRXP_WARN_rune|r
step
    #completewith next
    .zone Blasted Lands >>Travel to |cFFfa9602Blasted Lands|r
step
    #completewith next
    .goto Blasted Lands,45.27,16.52,10 >>Travel to the top of the tower in front of Dreadmaul Hold
step
    .goto Blasted Lands,45.27,16.52
    >>Open the |cRXP_PICK_Abandoned Cache|r. Kill the |cRXP_ENEMY_Murderous Lost One|r (level 46) that spawns
    >>Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Carnage|r]
    .collect 221461,1 -- Rune of Carnage 1/1
    .unitscan Murderous Lost One
    .train 432299,1
step
    .use 221461
    .itemcount 221461,1
    .train 432299 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Carnage|r] |cRXP_WARN_to train|r |T236268:0|t[Carnage]
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Helmet
#title Honor Among Thieves
#name Honor Among Thieves - 45 (Azeroth)

step
    #optional
    .xp 45 >>|cRXP_WARN_You need to reach level 45 in order to obtain this rune|r
step
    #optional
    .train 400101 >>|cRXP_WARN_You must have trained|r |T132303:0|t[Shadowstep] |cRXP_WARN_in order to obtain this rune|r
step
    #optional
    .train 400080,1 >>|cRXP_WARN_You must have trained|r |T236270:0|t[Deadly Brew] |cRXP_WARN_in order to obtain this rune|r
step
    #optional
    #completewith letterC
    >>|cRXP_WARN_In order to start the quest for this rune you need to have completed "The Manor, Ravenholdt" quest introducing you to the Ravenholdt rogue faction. In order to receive it talk to|r |cRXP_FRIENDLY_Osborne the Night Man|r |cRXP_WARN_in Stormwind|r << Alliance
    +|cRXP_WARN_In order to start the quest for this rune you need to have completed "The Manor, Ravenholdt" quest introducing you to the Ravenholdt rogue faction. In order to receive it talk to|r |cRXP_FRIENDLY_Ormok|r |cRXP_WARN_in Orgrimmar|r << Horde
    .accept 6681 >>Accept The Manor, Ravenholdt << Alliance
    .isQuestAvailable 6681
step << Horde
    .goto Orgrimmar,43.91,54.69
    .gossipoption 96925 >>Talk to |cRXP_FRIENDLY_Ormok|r to receive an |T133460:0|t[|cRXP_LOOT_Elegant Letter|r]. Use it to accept the quest
    .disablecheckbox
    .collect 17126,1,6681
    .accept 6681 >>Accept The Manor, Ravenholdt
    .target Ormok
    .isQuestAvailable 6681
step
    #completewith next
    .zone Hillsbrad Foothills >>Travel to |cFFfa9602Hillsbrad Foothills|r
    .isOnQuest 6681
step
    #completewith next
    .goto Hillsbrad Foothills,75.27,23.66,15,0
    .goto Hillsbrad Foothills,75.66,20.30,15,0
    .goto Hillsbrad Foothills,77.24,21.98,15,0
    .goto Hillsbrad Foothills,78.62,17.96,20 >>Enter Ravenholdt Manor
    .isOnQuest 6681
step
    .goto Hillsbrad Foothills,78.62,17.96
    >>Move toward the |cRXP_PICK_Chest|r
    .complete 6681,1 --Rite of Cunning: 1/1
    .isOnQuest 6681
step
    .goto Alterac Mountains,85.51,79.41,10,0
    .goto Alterac Mountains,86.11,80.22,10,0
    .goto Alterac Mountains,84.45,80.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahrad|r upstairs
    .turnin 6681 >> Turn in The Manor, Ravenholdt
    .target Fahrad
    .isOnQuest 6681
step << Alliance
    +|cRXP_WARN_Travel to any Major City|r
    >>Darnassus
    >>Ironforge
    >>Stormwind City
    .zoneskip Darnassus
    .zoneskip Ironforge
    .zoneskip Stormwind City
    .train 432295,1
step << Horde
    +|cRXP_WARN_Travel to any Major City|r
    >>Undercity
    >>Thunder Bluff
    >>Orgrimmar
    .zoneskip Undercity
    .zoneskip Thunder Bluff
    .zoneskip Orgrimmar
    .train 432295,1
step
    #label letterC
    +|cRXP_WARN_Check your mailbox for the letter from *Fahrad*|r
    >>|cRXP_WARN_Skip this step when ready|r
    .train 432295,1
step
    #completewith next
    .zone Hillsbrad Foothills >>Travel to |cFFfa9602Hillsbrad Foothills|r
step
    #completewith next
    .goto Hillsbrad Foothills,75.27,23.66,15,0
    .goto Hillsbrad Foothills,75.66,20.30,15,0
    .goto Hillsbrad Foothills,77.24,21.98,15,0
    .goto Hillsbrad Foothills,78.62,17.96,20 >>Enter Ravenholdt Manor
step
    .goto Alterac Mountains,85.51,79.41,10,0
    .goto Alterac Mountains,86.11,80.22,10,0
    .goto Alterac Mountains,84.45,80.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahrad|r upstairs
    .accept 80526 >>Accept Fool Me Twice
    .turnin 80526 >>Turn in Fool Me Twice
    .accept 80411 >>Accept The Talisman of Kazdor
    .target Fahrad
step
    #optional
    #completewith next
    .zone Tanaris >>Travel to Tanaris
step
    #completewith next
    .goto Tanaris,38.69,20.20
    .subzone 1176 >>Enter Zul'Farrak
    >>|cRXP_WARN_You can't be in a group to be able to complete the quest for this rune|r
step
    .goto Tanaris,38.69,20.20
    >>Open |cRXP_PICK_Clay Vessels|r for |T134799:0|t[|cRXP_LOOT_Vile Concoctions|r]
    >>|cRXP_WARN_They are located in troll tents throughout Zul'Farrak|r
    .collect 217716,2
    .train 432295,1
step
    #completewith next
    +|cRXP_WARN_Move toward|r |cRXP_ENEMY_Antu'sul's|r |cRXP_WARN_cave|r
step
    >>Use a |T134799:0|t[|cRXP_LOOT_Vile Concoction|r] on the cauldron. |cRXP_WARN_It will not break your stealth|r
    >>While the boss is distracted loot |cRXP_PICK_Antu'Sul's Satchel|r for an |T133724:0|t[|cRXP_LOOT_Offering of Bone|r]
    .collect 217721,1 --Offering of Bone
    .use 217716
    .train 432295,1
step
    #completewith next
    +|cRXP_WARN_Move toward |cRXP_ENEMY_Witch Doctor Zum'rah|r in the graveyard area|r
step
    >>Use your second |T134799:0|t[|cRXP_LOOT_Vile Concoction|r] on the cauldron next to |cRXP_ENEMY_Witch Doctor Zum'rah|r. |cRXP_WARN_It will not break your stealth|r
    >>While he's distracted loot |cRXP_PICK_Zum'rahs Satchel|r for |T136232:0|t|cRXP_LOOT_Ward of the Dead|r
    .collect 217727,1 --ward of the dead
    .use 217716
    .train 432295,1
step
    #completewith next
    .equip 13,217727 >>Equip the |T136232:0|t|cRXP_LOOT_Ward of the Dead|r trinket you just looted
    >>|cRXP_WARN_This will reveal which|r |cRXP_PICK_Shallow Grave|r |cRXP_WARN_needs to be looted|r
step
    >>Loot the |cRXP_PICK_Shallow Grave|r that is revealed with a blue aura for the |T236304:0|t|cRXP_LOOT_Offering of Flesh|r
    .collect 217720,1 --offering of flesh
    .use 217727
    .train 432295,1
step
    >>Use the |T236304:0|t[|cRXP_LOOT_Offering of Flesh|r] you just collected to combine it with the |T133724:0|t[|cRXP_LOOT_Offering of Bone|r] into a |T236305:0|t[|cRXP_LOOT_Blood Magic Essence|r]
    .collect 217719,1 --Blood Magic Essence
    .use 217720
    .train 432295,1
step
    >>Go to the foot of the pyramid staircase and look to your right. On the side of the wall you will see a small stone block. Jump onto it and then walk onto the edge
    >>On the second wood balcony to the right you will find a |cRXP_PICK_Sandfury Cache|r. Loot it for the |T237274:0|t[|cRXP_LOOT_Hollow Emblem|r]
    .collect 217717,1 --Hollow Emblem
    .train 432295,1
step
    >>Use the |T237274:0|t|cRXP_LOOT_Hollow Emblem|r you just looted to combine it with the |T236305:0|t[|cRXP_LOOT_Blood Magic Essence|r] into an |T133572:0|t[|cRXP_LOOT_Emblem of Blood Magic|r]
    .collect 217718,1 --Emblem of Blood Magic
    .use 217717
    .train 432295,1
step
    >>Climb the stairs to the top of the pyramid and loot the |cRXP_PICK_Spellbound War Chest|r for |T133313:0|t[|cRXP_LOOT_Talisman of Kazdor|r]
    .collect 217609,1 --Talisman of Kazdor
    .train 432295,1
step
    #completewith next
    .zone Hillsbrad Foothills >>Travel to |cFFfa9602Hillsbrad Foothills|r
step
    #completewith next
    .goto Hillsbrad Foothills,75.27,23.66,15,0
    .goto Hillsbrad Foothills,75.66,20.30,15,0
    .goto Hillsbrad Foothills,77.24,21.98,15,0
    .goto Hillsbrad Foothills,78.62,17.96,20 >>Enter Ravenholdt Manor
step
    .goto Alterac Mountains,85.51,79.41,10,0
    .goto Alterac Mountains,86.11,80.22,10,0
    .goto Alterac Mountains,84.45,80.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahrad|r upstairs
    .turnin 80411 >>Turn in The Talisman of Kazdor
    .accept 80453 >>Accept Best Laid Plans
    .target Fahrad
step
    .goto Alterac Mountains,86.0,80.0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zan Shivsproket|r downstairs in the basement
    .turnin 80453 >>Turn in Best Laid Plans
    .accept 80454 >>Accept One Last Drop
    .target Zan Shivsproket
step
    #completewith next
    .zone Silverpine Forest >>Travel to Silverpine Forest
step
    .goto Silverpine Forest,47.114,70.974
    >>Click the |cRXP_PICK_Dead Drop|r chest
    .turnin 80454 >>Turn in One Last Drop
    .accept 80455 >>Accept Biding Our Time
    .train 432295,1
step
    #completewith next
    .zone Hillsbrad Foothills >>Travel to |cFFfa9602Hillsbrad Foothills|r
step
    #completewith next
    .goto Hillsbrad Foothills,75.27,23.66,15,0
    .goto Hillsbrad Foothills,75.66,20.30,15,0
    .goto Hillsbrad Foothills,77.24,21.98,15,0
    .goto Hillsbrad Foothills,78.62,17.96,20 >>Enter Ravenholdt Manor
step
    .goto Alterac Mountains,85.51,79.41,10,0
    .goto Alterac Mountains,86.11,80.22,10,0
    .goto Alterac Mountains,84.45,80.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fahrad|r upstairs
    .turnin 80455 >>Turn in Biding Our Time
    .target Fahrad
step
    .train 432295 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of the Coterie|r] |cRXP_WARN_to train|r |T236275:0|t[Honor Among Thieves]
    .use 217736
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Cloak
#title Crimson Tempest
#name Crimson Tempest - 60 (Western Plaguelands)

step
    .train 415918,1
    .zone Western Plaguelands >>Travel to Western Plaguelands
step
    .train 415918,1
    #completewith next
    .subzone 190 >> Travel to Hearthglen
step
    #label ToolboxKey
    .train 415918,1
    .goto Western Plaguelands,45.0,13.6
    >>Kill or |T133644:0|t[Pick Pocket] |cRXP_ENEMY_Scarlet Workers|r. Loot them for the |cRXP_LOOT_Toolbox Key|r
    .collect 227928,1 -- Toolbox Key 1/1
    .mob Scarlet Worker
step
    .train 415918,1
    .goto Western Plaguelands,45.0,14.2
    >>Open the |cRXP_PICK_Scarlet Toolbox|r. Loot it for the |cRXP_LOOT_Rusty Crowbar|r
    .collect 227932,1 -- Rusty Crowbar 1/1
step
    .goto Western Plaguelands,49.5,18.5
    >>Head to the top of the tower in the middle of Hearthglen. Open the |cRXP_PICK_Marked Crate|r there. Loot it for the |T133640:0|t[|cRXP_LOOT_Hidden Bundle|r] and open it to loot a |T134237:0|t[|cRXP_LOOT_Safe Box Key|r]
    .collect 227930,1
step
    .goto Western Plaguelands,46.3,14.6
    >>Head to the middle floor of the second tower in Hearthglen located on the northern side of the city. Use the |T134237:0|t[|cRXP_LOOT_Safe Box Key|r] to open [|cRXP_PICK_Belavus' Safe Box|r] and loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of the Crimson Tempest|r]
    .collect 227456,1 --Rune of the crimson tempest
step
    .use 227456
    .itemcount 227456,1
    .train 415918 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of the Crimson Tempest|r] |cRXP_WARN_to train|r |T135315:0|t[Crimson Tempest]
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Cloak
#title Fan of Knives
#name Fan of Knives - 55 (Winterspring)

step
    .train 436609,1
    .zone Winterspring >>Travel to Winterspring
step
    .train 436609,1
    .goto Winterspring,67.7,35.4
    >>Open the |cRXP_PICK_Wooden Chest|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Knives|r]
    >>|cRXP_WARN_While opening the |cRXP_PICK_Wooden Chest|r, choose the following options in this order:|r
    >>|cRXP_WARN_Frostsaber|r
    >>|cRXP_WARN_Owl|r
    >>|cRXP_WARN_Bear|r
    >>|cRXP_WARN_Owl|r
    .collect 227921,1
step
    .use 227921
    .itemcount 227921,1
    .train 436609 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Knives|r] |cRXP_WARN_to train|r |T236273:0|t[Fan of Knives]
]])

RXPGuides.RegisterGuide([[#classic
<< Rogue SoD
#group RestedXP Rune & Books Guide
#subgroup Cloak
#title Blunderbuss
#name Blunderbuss - 60 (Eastern Plaguelands)

step
    .train 415922,1
    .zone Eastern Plaguelands >>Travel to Eastern Plaguelands
step
    .train 415922,1
    .goto Eastern Plaguelands,83,85
    >>Open |cRXP_LOOT_Scarlet Footlockers|r throughout Tyr's Hand until you loot a |cRXP_LOOT_Sending Sigil|r
    .collect 227451,1
step
    .train 415922,1
    #completewith FinalPillar
    >>|cRXP_WARN_For the following steps you must click FOUR |cRXP_PICK_Sending Pillars|r in the correct order. After clicking one you will be RANDOMLY teleported to a different one. Ensure you are at the correct location before you click another one!|r
step
    .train 415922,1
    .goto Eastern Plaguelands,82,57
    .cast 6477,6478 >>Click the first |cRXP_PICK_Sending Pillar|r |cRXP_WARN_behind Light's Hope Chapel|r
step
    .train 415922,1
    .goto Eastern Plaguelands,40,92
    .cast 6477,6478 >>Click the second |cRXP_PICK_Sending Pillar|r |cRXP_WARN_in Darrowshire|r
step
    .train 415922,1
    .goto Eastern Plaguelands,70,34
    .cast 6477,6478 >>Click the third |cRXP_PICK_Sending Pillar|r |cRXP_WARN_in Northdale|r
step
    .train 415922,1
    #label FinalPillar
    .goto Eastern Plaguelands,14,30
    .cast 6477,6478 >>Click the fourth |cRXP_PICK_Sending Pillar|r |cRXP_WARN_in Terrordale|r
step
    .train 415922,1
    >>|cRXP_WARN_Enter the House|r
    >>Open |cRXP_PICK_Adon's Trunk|r on the ground. Loot it for the |T134419:0|t[|cRXP_LOOT_Rune of the Swashbuckler|r]
    .collect 227922,1
step
    .use 227922
    .itemcount 227922,1
    .train 415922 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of the Swashbuckler|r] |cRXP_WARN_to train|r |T134538:0|t[Blunderbuss]
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Molten Blast - 8 (Mulgore)
#title Molten Blast
#next Lava Lash - 10 (Mulgore)


step
    +|cRXP_WARN_You should be at least level 8 in order to acquire|r |T133816:0|t[Engrave Gloves - Molten Blast] |cRXP_WARN_in Mulgore alone|r
    >>|cRXP_WARN_You MUST be at least level 3 to equip the|r |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133816:0|t[Engrave Gloves - Molten Blast]
    .train 425344,1
    .xp >3,1
step
    +|cRXP_WARN_You should be at least level 8 in order to acquire|r |T133816:0|t[Engrave Gloves - Molten Blast] |cRXP_WARN_in Mulgore alone|r
    .train 425344,1
    .xp <3,1
    .xp >8,1
step
    #loop
    .goto Mulgore,34.33,47.54,40,0
    .goto Mulgore,33.62,49.61,40,0
    .goto Mulgore,32.58,48.96,40,0
    .goto Mulgore,31.88,50.17,40,0
    .goto Mulgore,31.14,50.08,40,0
    .goto Mulgore,30.98,48.24,40,0
    .goto Mulgore,31.59,48.19,40,0
    .goto Mulgore,33.10,47.69,40,0
    >>Kill |cRXP_ENEMY_Bael'dun Diggers|r and |cRXP_ENEMY_Bael'dun Appraisers|r. Loot them for the |cRXP_LOOT_Artifact Storage Key|r
    >>|cRXP_WARN_Be careful as |cRXP_ENEMY_Bael'dun Appraisers|r cast|r |T135929:0|t[Lesser Heal] |cRXP_WARN_(Ranged Cast: Heals themselves or a nearby mob below 50% health for about 75 health)|r
    .collect 206975,1 --Artifact Storage Key (1)
    .mob Bael'dun Digger
    .mob Bael'dun Appraiser
    .train 425344,1
    .xp <3,1
--XX WIP to here
step
    .goto Mulgore,31.56,49.54
    >>Open the |cRXP_PICK_Artifact Storage|r chest. Loot it for the |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r
    .collect 206388,1 --Sulfurous Icon (1)
    .train 425344,1
    .xp <3,1
step
    .equip 18,206388 >> |cRXP_WARN_Equip the|r |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r
    .use 206388
    .itemcount 206388,1 --Sulfurous Icon (1)
    .train 425344,1
    .xp <3,1
step
    #loop
    .goto Mulgore,34.33,47.54,40,0
    .goto Mulgore,33.62,49.61,40,0
    .goto Mulgore,32.58,48.96,40,0
    .goto Mulgore,31.88,50.17,40,0
    .goto Mulgore,31.14,50.08,40,0
    .goto Mulgore,30.98,48.24,40,0
    .goto Mulgore,31.59,48.19,40,0
    .goto Mulgore,33.10,47.69,40,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .collect 206975,1 --Artifact Storage Key (1)
    .mob Bael'dun Digger
    .mob Bael'dun Appraiser
    .train 425344,1
    .xp <3,1
    .xp >13,1
step
    #completewith Barrens
    .zone The Barrens >> Travel to The Barrens
    .train 425344,1
    .xp <13,1
step
    #loop
    .goto The Barrens,53.94,25.86,50,0
    .goto The Barrens,54.17,25.06,50,0
    .goto The Barrens,54.86,25.43,50,0
    .goto The Barrens,55.62,25.71,50,0
    .goto The Barrens,55.98,26.36,50,0
    .goto The Barrens,55.71,27.21,50,0
    .goto The Barrens,55.44,27.35,50,0
    .goto The Barrens,54.99,26.79,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Razormane Thornweaver
    .mob Razormane Water Seeker
    .mob Razormane Hunter
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <13,1
    .xp >16,1
step
    #loop
    .goto The Barrens,55.97,16.17,50,0
    .goto The Barrens,55.43,16.15,50,0
    .goto The Barrens,54.10,15.51,50,0
    .goto The Barrens,53.10,15.25,50,0
    .goto The Barrens,53.73,13.77,50,0
    .goto The Barrens,55.09,15.00,50,0
    .goto The Barrens,55.62,14.86,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Hecklefang Hyena
    .mob Savannah Prowler
    .mob Savannah Huntress
    .mob Sunscale Screecher
    .mob Barrens Giraffe
    .mob Fleeting Plainstrider
    .mob Zhevra Runner
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <16,1
    .xp >20,1
step
    #label Barrens
    #loop
    .goto The Barrens,40.03,15.36,50,0
    .goto The Barrens,39.39,14.65,50,0
    .goto The Barrens,39.62,11.77,50,0
    .goto The Barrens,38.84,11.93,50,0
    .goto The Barrens,38.44,13.21,50,0
    .goto The Barrens,38.48,14.85,50,0
    .goto The Barrens,37.33,16.23,50,0
    .goto The Barrens,38.64,17.49,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Witchwing Slayer
    .mob Witchwing Windcaller
    .mob Witchwing Ambusher
    .mob Witchwing Roguefeather
    .mob Serena Bloodfeather
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <20,1
    .xp >22,1
step
    #completewith next
    .zone Stonetalon Mountains >> Travel to Stonetalon Mountains
    .train 425344,1
    .xp <3,1
step
    #loop
    .goto Stonetalon Mountains,64.17,57.16,50,0
    .goto Stonetalon Mountains,60.55,54.86,50,0
    .goto Stonetalon Mountains,60.95,51.21,50,0
    .goto Stonetalon Mountains,64.40,48.64,50,0
    .goto Stonetalon Mountains,66.18,52.01,50,0
    .goto Stonetalon Mountains,67.20,51.49,50,0
    .goto Stonetalon Mountains,66.83,45.34,50,0
    .goto Stonetalon Mountains,69.89,53.54,50,0
    .goto Stonetalon Mountains,70.84,56.97,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Venture Co. Logger
    .mob Venture Co. Deforester
    .mob Venture Co. Operator
    .mob Venture Co. Light Shredder
    .mob XT:9
    .mob XT:4
    .mob Deepmoss Webspinner
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <22,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Molten Blast]
    .use 206388
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <3,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Molten Blast - 10 (Durotar)
#title Molten Blast
#next Way of Earth - 12 (The Barrens)


    --Rune of Molten Blast
step
    +|cRXP_WARN_You MUST be at least level 10 in order to acquire|r |T133816:0|t[Engrave Gloves - Molten Blast] |cRXP_WARN_as it is the level requirement of training|r |T135813:0|t[Flame Shock]
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133816:0|t[Engrave Gloves - Molten Blast]
    >>|cRXP_WARN_Alternatively, you can get|r |T133816:0|t[Engrave Gloves - Molten Blast] |cRXP_WARN_in Mulgore at level 3+|r
    .train 425344,1
    .xp >10,1
step
    #completewith IconS
    #label Durotar1
    .zone Durotar >> Travel to Durotar
    .train 425344,1
    .xp <10,1
step
    #completewith next
    #requires Durotar1
    #label Durotar2
    .goto Durotar,53.28,42.57,20,0
    .goto Durotar,54.42,42.59,15 >>Travel toward |cRXP_FRIENDLY_Swart|r inside
    .train 425344,1
    .xp <10,1
step
    .goto Durotar,54.42,42.59
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Swart|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .target Swart
    .train 425344,1
    .xp <10,1
step
    #completewith next
    #requires Durotar2
    .goto Durotar,58.69,45.53,40 >>Travel toward the |cRXP_ENEMY_Frozen Makrura|r
    .train 425344,1
    .xp <10,1
step
    #label IconS
    .goto Durotar,58.69,45.53
    >>|cRXP_WARN_Look for other Shamans, Warlocks, or Mages near the |cRXP_ENEMY_Frozen Makrura|r or in General Chat (Type /1 into chat)|r
    >>|cRXP_WARN_Cast|r |T135813:0|t[Flame Shock] |cRXP_WARN_on the |cRXP_ENEMY_Frozen Makrura|r to apply a stack of|r |T135805:0|t[Applying Heat]|cRXP_WARN_. Apply 5 stacks at once together to kill the |cRXP_ENEMY_Frozen Makrura|r. Loot it for the|r |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r
    >>|cRXP_WARN_Alternatively, you can get|r |T133816:0|t[Engrave Gloves - Molten Blast] |cRXP_WARN_in Mulgore solo|r
    >>|cRXP_WARN_NOTE:|r |T135813:0|t[Flametongue Weapon] |cRXP_WARN_does NOT apply any|r |T135805:0|t[Applying Heat] stacks|r
    .collect 206388,1 --Sulfurous Icon (1)
    .mob Frozen Makrura
    .train 425344,1
    .xp <10,1
    .xp >12,1
step
    .goto Durotar,58.69,45.53
    >>|cRXP_WARN_Look for other Shamans, Warlocks, or Mages near the |cRXP_ENEMY_Frozen Makrura|r or in General Chat (Type /1 into chat)|r
    >>|cRXP_WARN_Cast|r |T135813:0|t[Flame Shock] |cRXP_WARN_on the |cRXP_ENEMY_Frozen Makrura|r to apply a stack of|r |T135805:0|t[Applying Heat]|cRXP_WARN_. Apply 5 stacks at once together to kill the |cRXP_ENEMY_Frozen Makrura|r. Loot it for the|r |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r
    >>|cRXP_WARN_Alternatively, you can get|r |T133816:0|t[Engrave Gloves - Molten Blast] |cRXP_WARN_in Mulgore solo|r
    >>|cRXP_WARN_NOTE:|r |T135813:0|t[Flametongue Weapon] |cRXP_WARN_and|r |T135824:0|t[Fire Nova Totem] |cRXP_WARN_do NOT apply any|r |T135805:0|t[Applying Heat] stacks|r
    .collect 206388,1 --Sulfurous Icon (1)
    .mob Frozen Makrura
    .train 425344,1
    .xp <12,1
--XX Flametongue and Fire Nova doesn't seem to work
step
    .equip 18,206388 >> |cRXP_WARN_Equip the|r |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r
    .use 206388
    .itemcount 206388,1 --Sulfurous Icon (1)
    .train 425344,1
    .xp <10,1
step
    #loop
    .goto Durotar,56.87,53.05,50,0
    .goto Durotar,56.82,54.69,50,0
    .goto Durotar,58.64,53.86,50,0
    .goto Durotar,59.40,56.58,50,0
    .goto Durotar,58.41,58.17,50,0
    .goto Durotar,56.21,58.51,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Kul Tiras Sailor
    .mob Kul Tiras Marine
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <10,1
    .xp >11,1
step
    #completewith Barrens
    .zone The Barrens >> Travel to The Barrens
    .train 425344,1
    .xp <10,1
step
    #loop
    .goto The Barrens,53.94,25.86,50,0
    .goto The Barrens,54.17,25.06,50,0
    .goto The Barrens,54.86,25.43,50,0
    .goto The Barrens,55.62,25.71,50,0
    .goto The Barrens,55.98,26.36,50,0
    .goto The Barrens,55.71,27.21,50,0
    .goto The Barrens,55.44,27.35,50,0
    .goto The Barrens,54.99,26.79,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Razormane Thornweaver
    .mob Razormane Water Seeker
    .mob Razormane Hunter
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <11,1
    .xp >16,1
step
    #loop
    .goto The Barrens,55.97,16.17,50,0
    .goto The Barrens,55.43,16.15,50,0
    .goto The Barrens,54.10,15.51,50,0
    .goto The Barrens,53.10,15.25,50,0
    .goto The Barrens,53.73,13.77,50,0
    .goto The Barrens,55.09,15.00,50,0
    .goto The Barrens,55.62,14.86,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Hecklefang Hyena
    .mob Savannah Prowler
    .mob Savannah Huntress
    .mob Sunscale Screecher
    .mob Barrens Giraffe
    .mob Fleeting Plainstrider
    .mob Zhevra Runner
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <16,1
    .xp >20,1
step
    #label Barrens
    #loop
    .goto The Barrens,40.03,15.36,50,0
    .goto The Barrens,39.39,14.65,50,0
    .goto The Barrens,39.62,11.77,50,0
    .goto The Barrens,38.84,11.93,50,0
    .goto The Barrens,38.44,13.21,50,0
    .goto The Barrens,38.48,14.85,50,0
    .goto The Barrens,37.33,16.23,50,0
    .goto The Barrens,38.64,17.49,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Witchwing Slayer
    .mob Witchwing Windcaller
    .mob Witchwing Ambusher
    .mob Witchwing Roguefeather
    .mob Serena Bloodfeather
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <20,1
    .xp >22,1
step
    #completewith next
    .zone Stonetalon Mountains >> Travel to Stonetalon Mountains
    .train 425344,1
    .xp <10,1
step
    #loop
    .goto Stonetalon Mountains,64.17,57.16,50,0
    .goto Stonetalon Mountains,60.55,54.86,50,0
    .goto Stonetalon Mountains,60.95,51.21,50,0
    .goto Stonetalon Mountains,64.40,48.64,50,0
    .goto Stonetalon Mountains,66.18,52.01,50,0
    .goto Stonetalon Mountains,67.20,51.49,50,0
    .goto Stonetalon Mountains,66.83,45.34,50,0
    .goto Stonetalon Mountains,69.89,53.54,50,0
    .goto Stonetalon Mountains,70.84,56.97,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using|r |T136026:0|t[Earth Shock] |cRXP_WARN_on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Venture Co. Logger
    .mob Venture Co. Deforester
    .mob Venture Co. Operator
    .mob Venture Co. Light Shredder
    .mob XT:9
    .mob XT:4
    .mob Deepmoss Webspinner
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <22,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134918:0|t|cRXP_LOOT_[Sulfurous Icon]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Molten Blast]
    .use 206388
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 425344,1
    .xp <10,1
--XX Cast ID may be wrong, may need to be checked
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Lava Lash - 10 (Mulgore)
#title Lava Lash
#next Ancestral Guidance - 10 (Mulgore)


    --Rune of Lava Lash
--XX Worth mentioning "Dual Wield Skill" in the name? Cuts off ingame due to it being 3 lines though
step
    +|cRXP_WARN_You should be at least level 10 in order to acquire|r |T133816:0|t[Engrave Gloves - Lava Lash] |cRXP_WARN_and|r |T132147:0|t[Dual Wield] |cRXP_WARN_in Mulgore alone|r
    >>|cRXP_WARN_You MUST be at least level 4 as it is the level requirement of starting the questline|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133816:0|t[Engrave Gloves - Lava Lash] |cRXP_WARN_and|r |T132147:0|t[Dual Wield]
    .train 410104,1
    .xp >4,1
step
    +|cRXP_WARN_You should be at least level 10 in order to acquire|r |T133816:0|t[Engrave Gloves - Lava Lash] |cRXP_WARN_and|r |T132147:0|t[Dual Wield] |cRXP_WARN_in Mulgore alone|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133816:0|t[Engrave Gloves - Lava Lash] |cRXP_WARN_and|r |T132147:0|t[Dual Wield]
    .train 410104,1
    .xp <4,1
    .xp >10,1
--XX WIP to here
step
    #completewith next
    .zone Thunder Bluff >> Travel to Thunder Bluff
    .train 410104,1
    .xp <4,1
step
    .goto Thunder Bluff,39.45,65.86
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boarton Shadetotem|r
    >>|cRXP_WARN_He is|r |T132320:0|t[Stealthed]
    .accept 76156 >>Accept Stalk With The Earthmother
    .target Boarton Shadetotem
    .train 410104,1
    .xp <4,1
step
    #completewith next
    .goto Mulgore,61.46,47.21,20 >>Enter The Venture Co. Mine
    >>|cRXP_WARN_NOTE: the|r |T132288:0|t[Venture Co Disguise] |cRXP_WARN_does NOT work|r
    .train 410104,1
    .xp <4,1
step
    #loop
    .goto Mulgore,63.77,43.97,15,0
    .goto Mulgore,62.81,42.81,15,0
    .goto Mulgore,60.38,42.78,15,0
    .goto Mulgore,61.64,41.33,15,0
    .goto Mulgore,63.51,39.29,15,0
    .goto Mulgore,63.39,40.80,15,0
--  .goto Mulgore,66.53,39.47,15,0 --Very deep inside the top of the mine, skipping
    .goto Mulgore,60.99,37.00,15,0
    .goto Mulgore,59.64,36.05,15,0 --Outside
    .goto Mulgore,61.72,35.15,15,0 --Outside
    >>Open the |cRXP_PICK_Blasting Supplies|r inside the mine and outside on the other side. Loot them for the |cRXP_LOOT_Seaforium Mining Charges|r
    >>|cRXP_WARN_Stay on the upper levels of the cave if possible|r
    .complete 76156,1 --Seaforium Mining Charge (5)
    .train 410104,1
    .xp <4,1
--XX Didn't add the bottom of the mine ones
step
    #completewith next
    .goto Mulgore,59.99,35.82
    .subzone 215 >>Exit the Venture Co. Mine on the other side
    .train 410099,1
    .xp <4,1
step
    #completewith next
    .goto Mulgore,60.39,33.54,40 >>Travel toward the |cRXP_FRIENDLY_Adventurer's Remains|r
    .train 410099,1
    .xp <4,1
step
    #label IconS
    .goto Mulgore,60.39,33.54
    >>|cRXP_WARN_If you don't have|r |T134596:0|t[Engrave Pants - Ancestral Guidance]|cRXP_WARN_, now is a good time to do it|r
    >>|cRXP_WARN_If you don't want to get this Rune, skip this step|r
    >>|cRXP_WARN_Join a group with another Shaman, Priest, or Druid standing over the |cRXP_FRIENDLY_Adventurer's Remains|r, or look for help from a Shaman, Priest, or Druid in General Chat (Type /1 into chat)|r
    >>|cRXP_WARN_Talk to the |cRXP_FRIENDLY_Adventurer's Remains|r on the ground to begin the ritual, OR click the other player's|r |T136223:0|t[Spirit Ritual] |cRXP_WARN_(whilst in their group)|r
    >>|cRXP_WARN_A |cRXP_FRIENDLY_Adventurer's Spirit|r will spawn and die after completing the ritual. Loot it for the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r
    .collect 210589,1 --Echo of the Ancestors (1)
    .target Adventurer's Remains
    .target Adventurer's Spirit
    .skipgossip
    .train 410099,1
    .xp <4,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r |cRXP_WARN_to learn|r |T134596:0|t[Engrave Pants - Ancestral Guidance]
    .use 210589
    .itemcount 210589,1 --Echo of the Ancestors (1)
    .train 410099,1
    .xp <4,1
step
    #completewith next
    .zone Thunder Bluff >> Travel to Thunder Bluff
    .train 410104,1
    .xp <4,1
--XX Logout skips take you to Bloodhoof, not worth doing
step
    .goto Thunder Bluff,39.45,65.86
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boarton Shadetotem|r
    >>|cRXP_WARN_He is|r |T132320:0|t[Stealthed]
    .turnin 76156 >>Turn in Stalk With The Earthmother
    .accept 76160 >>Accept Stalk With The Earthmother
    .target Boarton Shadetotem
    .train 410104,1
    .xp <4,1
step
    #completewith next
    .goto Mulgore,53.91,23.45
    .zone Mulgore >>Take the northern elevator down to Mulgore
    .train 410104,1
    .xp <4,1
step
    #loop
    .goto Mulgore,38.80,16.03,10,0
    .goto Mulgore,37.79,10.86,10,0
    .goto Mulgore,38.01,10.21,10,0
    .goto Mulgore,38.55,8.10,10,0
    .goto Mulgore,38.06,7.47,10,0
    .goto Mulgore,37.36,9.99,10,0
    .goto Mulgore,37.31,10.41,10,0
    .goto Mulgore,35.80,11.21,10,0
    .goto Mulgore,36.20,11.41,10,0
    .goto Mulgore,36.21,12.60,10,0
    .goto Mulgore,36.55,12.84,10,0
    .goto Mulgore,36.65,13.26,10,0
    .goto Mulgore,37.18,12.36,10,0
    >>Loot |cRXP_LOOT_Windfury Cones|r on the ground
    .collect 206170,8,76160,1 --Windfury Cone (8)
    .train 410104,1
    .xp <4,1
step
    >>Use the |T133748:0|t[Mortar and Pestle] to create |T133213:0|t[Pine Salve]
    .complete 76160,1 --Pine Salve (1)
    .use 206176
    .train 410104,1
    .xp <4,1
step
    .goto Thunder Bluff,39.45,65.86
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boarton Shadetotem|r
    >>|cRXP_WARN_He is|r |T132320:0|t[Stealthed]
    .turnin 76160 >>Turn in Stalk With The Earthmother
    .accept 76240 >>Accept Stalk With The Earthmother
    .target Boarton Shadetotem
    .train 410104,1
    .xp <4,1
step
    #ah
    .goto Thunder Bluff,45.23,59.40,0
    .goto Thunder Bluff,40.41,51.78
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stampi|r
    >>|cRXP_BUY_Buy a|r |T133894:0|t[Raw Brilliant Smallfish] |cRXP_BUY_from the Auction House|r
    .collect 6291,1,76240,1 --Raw Brilliant Smallfish (1)
    .target Auctioneer Stampi
    .train 410104,1
    .xp <4,1
step
    #ssf
    #completewith Sewa
    .goto Thunder Bluff,46.13,51.59,12,0
    .goto Thunder Bluff,47.09,50.07,4,0
    .goto Thunder Bluff,46.49,49.16,4,0
    .goto Thunder Bluff,46.05,49.74,4,0
    .goto Thunder Bluff,46.34,50.50,4,0
    .goto Thunder Bluff,55.78,47.02,15 >>Travel toward |cRXP_FRIENDLY_Sewa Mistrunner|r
    .train 410104,1
    .xp <4,1
step
    #ssf
    #sticky
    #label Kah
    .goto Thunder Bluff,56.13,46.39,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kah Mistrunner|r
    .train 7734 >>Train |T136245:0|t[Fishing]
    .target Kah Mistrunner
    .train 410104,1
    .xp <4,1
step
    #ssf
    #label Sewa
    .goto Thunder Bluff,55.78,47.02,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sewa Mistrunner|r
    >>|cRXP_BUY_Buy a|r |T132932:0|t[Fishing Pole] |cRXP_BUY_and|r |T134335:0|t[Shiny Bauble] |cRXP_BUY_from her|r
    .collect 6256,1 --Fishing Pole (1)
    .collect 6529,1 --Shiny Bauble (1)
    .target Sewa Mistrunner
    .train 410104,1
    .xp <4,1
step
    #ssf
    #completewith Fish
    #requires Kah
    #label Pole
    .equip 16,6256 >> |cRXP_WARN_Equip the|r |T132932:0|t[Fishing Pole]
    .use 6256
    .train 410104,1
    .xp <4,1
step
    #ssf
    #completewith Fish
    #requires Pole
    .aura 8087 >> |cRXP_WARN_Attach the|r |T134335:0|t[Shiny Bauble] |cRXP_WARN_to your|r |T132932:0|t[Fishing Pole]
    .use 6529
    .train 410104,1
    .xp <4,1
step
    #ssf
    #label Fish
    #requires Kah
    .goto Thunder Bluff,40.42,58.55
    >>Fish in the pond until you get a |T133894:0|t[|cRXP_LOOT_Raw Brilliant Smallfish|r]
    .collect 6291,1,76240,1 --Raw Brilliant Smallfish (1)
    .train 410104,1
    .xp <4,1
step
    >>Use the |T132147:0|t[Knife Set] to create |T134007:0|t[Fish Chunks]
    .complete 76240,1 --Fish Chunks (1)
    .use 206344
    .train 410104,1
    .xp <4,1
step
    .goto Thunder Bluff,39.45,65.86
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boarton Shadetotem|r
    >>|cRXP_WARN_He is|r |T132320:0|t[Stealthed]
    .turnin 76240 >>Turn in Stalk With The Earthmother
-- .train 410104 >>|cRXP_WARN_You will train|r |T236289:0|t[Lava Lash] |cRXP_WARN_and|r |T132147:0|t[Dual Wield] |cRXP_WARN_upon turnin|r
    .target Boarton Shadetotem
    .train 410104,1
    .xp <4,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Water Shield - 20 (The Barrens)
#title Water Shield
#next Greater Ghost Wolf - 25 (Stonetalon Mountains)


step
    +|cRXP_WARN_You MUST be at least level 20 in order to acquire|r |T133816:0|t[Engrave Gloves - Water Shield] |cRXP_WARN_as it is the level requirement of training|r |T135849:0|t[Frost Shock]
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133816:0|t[Engrave Gloves - Water Shield]
    .train 410097,1
    .xp >20,1
step
    .zone Orgrimmar >>Travel to Orgrimmar or Thunder Bluff
    .zoneskip Thunder Bluff
    .train 8050,1
    .xp <20,1
step
    .zone Orgrimmar >>Travel to Orgrimmar or Thunder Bluff
    .zoneskip Thunder Bluff
    .train 8056,1
    .xp <20,1
step
    #completewith OrgTrain
    .goto Orgrimmar,40.31,37.01,15,0
    .goto Orgrimmar,38.81,36.37,15 >>Travel toward |cRXP_FRIENDLY_Kardris|r
    .zoneskip Thunder Bluff
    .train 410097,1
    .xp <20,1
step
    .goto Orgrimmar,38.81,36.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Kardris Dreamseeker
    .zoneskip Thunder Bluff
    .train 8050,1
    .train 8056,1
    .xp <20,1
step
    .goto Orgrimmar,38.81,36.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .target Kardris Dreamseeker
    .zoneskip Thunder Bluff
    .train 410097,1
    .xp <20,1
step
    #label OrgTrain
    .goto Orgrimmar,38.81,36.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Kardris Dreamseeker
    .zoneskip Thunder Bluff
    .train 410097,1
    .xp <20,1
step
    #ah
    .goto Orgrimmar,50.67,70.39,0
    .goto Orgrimmar,53.74,64.60,15,0
    .goto Orgrimmar,55.54,64.81
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Wabang|r
    >>|cRXP_BUY_Buy a|r |T134237:0|t[Kolkar Booty Key] |cRXP_BUY_from the Auction House|r
    >>|cRXP_WARN_This will save you a few minutes later|r
    .collect 5020,1 --Kolkar Booty Key (1)
    .target Auctioneer Wabang
    .zoneskip Orgrimmar,1
    .train 410097,1
    .xp <20,1
step
    #completewith TBTrain
    .goto Thunder Bluff,22.82,21.11,15 >>Travel toward |cRXP_FRIENDLY_Siln|r
    .zoneskip Orgrimmar
    .train 410097,1
    .xp <20,1
step
    .goto Thunder Bluff,22.82,21.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siln|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Siln Skychaser
    .zoneskip Orgrimmar
    .train 8050,1
    .train 8056,1
    .xp <20,1
step
    .goto Thunder Bluff,22.82,21.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siln|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .target Siln Skychaser
    .zoneskip Orgrimmar
    .train 410097,1
    .xp <20,1
step
    #label TBTrain
    .goto Thunder Bluff,22.82,21.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siln|r
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Siln Skychaser
    .zoneskip Orgrimmar
    .train 410097,1
    .xp <20,1
step
    #ah
    .goto Thunder Bluff,45.23,59.40,0
    .goto Thunder Bluff,40.41,51.78
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stampi|r
    >>|cRXP_BUY_Buy a|r |T134237:0|t[Kolkar Booty Key] |cRXP_BUY_from the Auction House|r
    >>|cRXP_WARN_This will save you a few minutes later|r
    .collect 5020,1 --Kolkar Booty Key (1)
    .target Auctioneer Stampi
    .zoneskip Thunder Bluff,1
    .train 410097,1
    .xp <20,1
--XX easier to farm it IF the user is not already there to train
step
    #completewith next
    .zone The Barrens >>Travel to The Barrens
    .train 410097,1
    .xp <20,1
step
    #loop
    .goto The Barrens,45.78,25.52,0
    .goto The Barrens,43.86,21.38,0
    .goto The Barrens,43.56,26.30,0
    .goto The Barrens,45.78,25.52,50,0
    .goto The Barrens,46.54,22.99,50,0
    .goto The Barrens,45.03,20.09,50,0
    .goto The Barrens,43.86,21.38,50,0
    .goto The Barrens,43.49,23.57,50,0
    .goto The Barrens,43.56,26.30,50,0
    >>Kill |cRXP_ENEMY_Kolkar Wranglers|r and |cRXP_ENEMY_Kolkar Stormers|r. Loot them for a |T134237:0|t[Kolkar Booty Key]
    .collect 5020,1 --Kolkar Booty Key (1)
    .mob Kolkar Wrangler
    .mob Kolkar Stormer
    .train 410097,1
    .xp <20,1
step
    .goto The Barrens,43.02,23.52,-1
--  .goto The Barrens,52.73,41.84,-1
--  .goto The Barrens,44.33,37.66,-1
    >>Open the |cRXP_PICK_Kolkars' Booty|r on the ground. Loot it for the |T135832:0|t|cRXP_LOOT_[Tempest Icon]|r
    .collect 206382,1 --Tempest Icon (1)
    .itemcount 5020,1 --Kolkar Booty Key (1)
    .train 410097,1
    .xp <20,1
step
    .equip 18,206382 >> |cRXP_WARN_Equip the|r |T135832:0|t|cRXP_LOOT_[Tempest Icon]|r
    .use 206382
    .itemcount 206382,1 --Tempest Icon (1)
    .train 410097,1
    .xp <20,1
step
    #loop
    .goto The Barrens,40.03,15.36,50,0
    .goto The Barrens,39.39,14.65,50,0
    .goto The Barrens,39.62,11.77,50,0
    .goto The Barrens,38.84,11.93,50,0
    .goto The Barrens,38.44,13.21,50,0
    .goto The Barrens,38.48,14.85,50,0
    .goto The Barrens,37.33,16.23,50,0
    .goto The Barrens,38.64,17.49,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using a Nature spell (|r|T136026:0|t[Earth Shock]|cRXP_WARN_), a Frost spell (|r|T135849:0|t[Frost Shock]|cRXP_WARN_), and a Fire spell (|r|T135813:0|t[Flame Shock]|cRXP_WARN_) on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Witchwing Slayer
    .mob Witchwing Windcaller
    .mob Witchwing Ambusher
    .mob Witchwing Roguefeather
    .mob Serena Bloodfeather
    .itemStat 18,QUALITY,2
    .train 410097,1
    .xp <20,1
    .xp >22,1
step
    #completewith next
    .zone Stonetalon Mountains >> Travel to Stonetalon Mountains
    .train 410097,1
    .xp <22,1
step
    #loop
    .goto Stonetalon Mountains,64.17,57.16,50,0
    .goto Stonetalon Mountains,60.55,54.86,50,0
    .goto Stonetalon Mountains,60.95,51.21,50,0
    .goto Stonetalon Mountains,64.40,48.64,50,0
    .goto Stonetalon Mountains,66.18,52.01,50,0
    .goto Stonetalon Mountains,67.20,51.49,50,0
    .goto Stonetalon Mountains,66.83,45.34,50,0
    .goto Stonetalon Mountains,69.89,53.54,50,0
    .goto Stonetalon Mountains,70.84,56.97,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using a Nature spell (|r|T136026:0|t[Earth Shock]|cRXP_WARN_), a Frost spell (|r|T135849:0|t[Frost Shock]|cRXP_WARN_), and a Fire spell (|r|T135813:0|t[Flame Shock]|cRXP_WARN_) on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Venture Co. Logger
    .mob Venture Co. Deforester
    .mob Venture Co. Operator
    .mob Venture Co. Light Shredder
    .mob XT:9
    .mob XT:4
    .mob Deepmoss Webspinner
    .itemStat 18,QUALITY,2
    .train 410097,1
    .xp <22,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T135832:0|t|cRXP_LOOT_[Tempest Icon]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Water Shield]
    .use 206382
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410097,1
    .xp <20,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Water Shield - 20 (Silverpine Forest)
#title Water Shield
#next Greater Ghost Wolf - 25 (Stonetalon Mountains)

step
    +|cRXP_WARN_You MUST be at least level 20 in order to acquire|r |T133816:0|t[Engrave Gloves - Water Shield] |cRXP_WARN_as it is the level requirement of training|r |T135849:0|t[Frost Shock]
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133816:0|t[Engrave Gloves - Water Shield]
    .train 410097,1
    .xp >20,1
step
    .zone Orgrimmar >>Travel to Orgrimmar or Thunder Bluff
    .zoneskip Thunder Bluff
    .train 8050,1
    .xp <20,1
step
    .zone Orgrimmar >>Travel to Orgrimmar or Thunder Bluff
    .zoneskip Thunder Bluff
    .train 8056,1
    .xp <20,1
step
    #completewith OrgTrain
    .goto Orgrimmar,40.31,37.01,15,0
    .goto Orgrimmar,38.81,36.37,15 >>Travel toward |cRXP_FRIENDLY_Kardris|r
    .zoneskip Thunder Bluff
    .train 410097,1
    .xp <20,1
step
    .goto Orgrimmar,38.81,36.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Kardris Dreamseeker
    .zoneskip Thunder Bluff
    .train 8050,1
    .train 8056,1
    .xp <20,1
step
    .goto Orgrimmar,38.81,36.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .target Kardris Dreamseeker
    .zoneskip Thunder Bluff
    .train 410097,1
    .xp <20,1
step
    #label OrgTrain
    .goto Orgrimmar,38.81,36.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Kardris Dreamseeker
    .zoneskip Thunder Bluff
    .train 410097,1
    .xp <20,1
step
    #completewith TBTrain
    .goto Thunder Bluff,22.82,21.11,15 >>Travel toward |cRXP_FRIENDLY_Siln|r
    .zoneskip Orgrimmar
    .train 410097,1
    .xp <20,1
step
    .goto Thunder Bluff,22.82,21.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siln|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Siln Skychaser
    .zoneskip Orgrimmar
    .train 8050,1
    .train 8056,1
    .xp <20,1
step
    .goto Thunder Bluff,22.82,21.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siln|r
    .train 8050 >> Train |T135813:0|t[Flame Shock]
    .target Siln Skychaser
    .zoneskip Orgrimmar
    .train 410097,1
    .xp <20,1
step
    #label TBTrain
    .goto Thunder Bluff,22.82,21.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siln|r
    .train 8056 >> Train |T135849:0|t[Frost Shock]
    .target Siln Skychaser
    .zoneskip Orgrimmar
    .train 410097,1
    .xp <20,1
step
    #completewith Grimson
    #label Grimson1
    .zone Silverpine Forest >>Travel to Silverpine Forest
    .train 410097,1
    .xp <20,1
step
    #completewith Grimson
    #requires Grimson1
    #label Grimson2
    .goto Silverpine Forest,56.65,45.97,15 >>Enter the Deep Elem Mine
    .train 410097,1
    .xp <20,1
step
    #completewith Grimson
    #requires Grimson2
    .goto Silverpine Forest,57.28,45.42,10,0
    .goto Silverpine Forest,57.66,44.82,10,0
    .goto Silverpine Forest,58.59,44.85,30 >>Travel Toward |cRXP_ENEMY_Grimson the Pale|r
    .train 410097,1
    .xp <20,1
step
    #label Grimson
    .goto Silverpine Forest,58.59,44.85
    >>Kill |cRXP_ENEMY_Grimson the Pale|r inside. Loot him for the |T135832:0|t|cRXP_LOOT_[Tempest Icon]|r
    .collect 206382,1 --Tempest Icon (1)
    .mob Grimson the Pale
    .train 410097,1
    .xp <20,1
step
    .equip 18,206382 >> |cRXP_WARN_Equip the|r |T135832:0|t|cRXP_LOOT_[Tempest Icon]|r
    .use 206382
    .itemcount 206382,1 --Tempest Icon (1)
    .train 410097,1
    .xp <20,1
step
    #loop
    .goto Silverpine Forest,47.68,86.24,50,0
    .goto Silverpine Forest,45.81,86.37,50,0
    .goto Silverpine Forest,44.26,84.37,50,0
    .aura 408828 >>|cRXP_WARN_Kill enemies having dealt damage using a Nature spell (|r|T136026:0|t[Earth Shock]|cRXP_WARN_), a Frost spell (|r|T135849:0|t[Frost Shock]|cRXP_WARN_), and a Fire spell (|r|T135813:0|t[Flame Shock]|cRXP_WARN_) on them at least once. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Valdred Moray
    .mob Dalin Forgewright
    .mob Haggard Refugee
    .mob Sickly Refugee
    .itemStat 18,QUALITY,2
    .train 410097,1
    .xp <20,1
    .xp >22,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T135832:0|t|cRXP_LOOT_[Tempest Icon]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Water Shield]
    .use 206382
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410097,1
    .xp <20,1
step
    #completewith next
    >>|cRXP_WARN_If you don't have|r |T133816:0|t[Engrave Gloves - Lava Burst] |cRXP_WARN_already, it's worth doing now. If you don't want to, skip this step|r
    .train 410095,1
    .xp <25,1
step
    #completewith next
    .zone Hillsbrad Foothills >>Travel to Hillsbrad Foothills
    .train 410095,1
    .xp <25,1
step
    #loop
    .goto Hillsbrad Foothills,63.73,59.26,40,0
    .goto Hillsbrad Foothills,65.49,60.30,40,0
    .goto Hillsbrad Foothills,66.30,61.11,40,0
    .goto Hillsbrad Foothills,63.61,62.04,40,0
    .goto Hillsbrad Foothills,63.21,61.04,40,0
    .goto Hillsbrad Foothills,62.56,63.55,40,0
    .goto Hillsbrad Foothills,62.98,63.70,40,0
    >>Kill |cRXP_ENEMY_Mudsnout Shamans|r. Loot them for the |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r
    .collect 206387,1 --Kajaric Icon (1)
    .mob Mudsnout Shaman
    .train 410095,1
    .xp <25,1
step
    .equip 18,206387 >> |cRXP_WARN_Equip the|r |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r
    .use 206387
    .itemcount 206387,1 --Kajaric Icon (1)
    .train 410095,1
    .xp <25,1
step
    #completewith next
    .zone Orgrimmar >> Travel to Orgrimmar
    .train 410095,1
    .xp <25,1
step
    .goto Orgrimmar,52.77,48.97
    .subzone 2437 >> Enter Ragefire Chasm inside the Cleft of Shadow
    .itemStat 18,QUALITY,2
    .train 410095,1
    .xp <25,1
step
    >>|cRXP_WARN_Hug the right side of the wall. After going down the ramp (just after the 5th mob), walk into the shallow lava pool on your right|r
    >>|cRXP_WARN_Damage taken from|r |T135805:0|t[Lava] |cRXP_WARN_is reduced to 91 whilst the|r |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r |cRXP_WARN_is equipped|r
    .aura 408828 >>|cRXP_WARN_Take damage from the |T135805:0|t[Lava] |cRXP_WARN_source 5 times|r
    .itemStat 18,QUALITY,2
    .train 410095,1
    .xp <25,1
step
    >>|cRXP_WARN_Move out of the|r |T135805:0|t[Lava]
    .cast 402265 >>|cRXP_WARN_Use the|r |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Lava Burst]
    .use 206387
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410095,1
    .xp <25,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Lava Burst - 25 (Hillsbrad Foothills)
#title Lava Burst
#next Earth Shield - 25 (Azeroth)


step
    +|cRXP_WARN_You should be at least level 25 in order to acquire|r |T133816:0|t[Engrave Gloves - Lava Burst] |cRXP_WARN_in Hillsbrad alone|r
    .train 410095,1
    .xp >25,1
step
    #completewith next
    .zone Hillsbrad Foothills >>Travel to Hillsbrad Foothills
    .train 410095,1
step
    #loop
    .goto Hillsbrad Foothills,63.73,59.26,40,0
    .goto Hillsbrad Foothills,65.49,60.30,40,0
    .goto Hillsbrad Foothills,66.30,61.11,40,0
    .goto Hillsbrad Foothills,63.61,62.04,40,0
    .goto Hillsbrad Foothills,63.21,61.04,40,0
    .goto Hillsbrad Foothills,62.56,63.55,40,0
    .goto Hillsbrad Foothills,62.98,63.70,40,0
    >>Kill |cRXP_ENEMY_Mudsnout Shamans|r. Loot them for the |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r
    .collect 206387,1 --Kajaric Icon (1)
    .mob Mudsnout Shaman
    .train 410095,1
step
    .equip 18,206387 >> |cRXP_WARN_Equip the|r |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r
    .use 206387
    .itemcount 206387,1 --Kajaric Icon (1)
    .train 410095,1
step
    #completewith next
    .zone Orgrimmar >> Travel to Orgrimmar
    .train 410095,1
step
    .goto Orgrimmar,52.77,48.97
    .subzone 2437 >> Enter Ragefire Chasm inside the Cleft of Shadow
    .itemStat 18,QUALITY,2
    .train 410095,1
step
    >>|cRXP_WARN_Hug the right side of the wall. After going down the ramp (just after the 5th mob), walk into the shallow lava pool on your right|r
    >>|cRXP_WARN_Damage taken from|r |T135805:0|t[Lava] |cRXP_WARN_is reduced to 91 whilst the|r |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r |cRXP_WARN_is equipped|r
    .aura 408828 >>|cRXP_WARN_Take damage from the |T135805:0|t[Lava] |cRXP_WARN_source 5 times|r
    .itemStat 18,QUALITY,2
    .train 410095,1
step
    >>|cRXP_WARN_Move out of the|r |T135805:0|t[Lava]
    .cast 402265 >>|cRXP_WARN_Use the|r |T134920:0|t|cRXP_LOOT_[Kajaric Icon]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Lava Burst]
    .use 206387
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410095,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Overload - 3 (Durotar)
#title Overload
#next Shield Mastery - 6 (Durotar)

    --Rune of Overload
step
    +|cRXP_WARN_You MUST be at least level 3 in order to acquire|r |T133815:0|t[Engrave Chest - Overload] |cRXP_WARN_as it is the level requirement of equipping the|r |T134918:0|t|cRXP_LOOT_[Dyadic Icon]|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133815:0|t[Engrave Chest - Overload]
    .train 410094,1
    .xp >3,1
step
    #completewith IconS
    .zone Durotar >> Travel to Durotar
    .train 410094,1
    .xp <3,1
step << !Tauren skip
    .goto Durotar,42.39,69.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shikrik|r
    .accept 77587 >>Accept Icons of Power << Troll Shaman
    .accept 77585 >>Accept Icons of Power << Orc Shaman
    .target Shikrik
    .train 410094,1
    .xp <3,1
step
    #label IconS
#loop
	.line Durotar,43.26,58.28,42.81,58.41,41.90,58.35,41.97,59.20,41.36,60.35,40.66,61.27,40.07,61.35,39.42,61.29,39.46,62.17,39.55,63.10,40.13,64.04,40.84,64.06,40.74,65.86,39.93,66.03,40.04,66.99,40.09,67.66,40.13,68.50,40.72,68.55,41.30,67.84,41.37,66.72,41.89,66.05,41.27,65.71,41.36,64.07,41.33,63.12,41.35,61.98,41.49,61.25,41.90,60.24,42.51,59.34,43.08,59.62,43.91,59.33,45.15,59.46,45.81,59.30,45.85,60.34,46.46,61.11,47.09,62.24,47.08,63.15,47.14,64.08,47.58,64.04,47.08,63.15,47.09,62.24,46.90,61.15,46.98,60.18,47.07,59.34,46.47,58.28,45.81,59.30,45.15,59.46,43.91,59.33,43.26,58.28
	.goto Durotar,43.26,58.28,25,0
	.goto Durotar,42.81,58.41,25,0
	.goto Durotar,41.90,58.35,25,0
	.goto Durotar,41.97,59.20,25,0
	.goto Durotar,41.36,60.35,25,0
	.goto Durotar,40.66,61.27,25,0
	.goto Durotar,40.07,61.35,25,0
	.goto Durotar,39.42,61.29,25,0
	.goto Durotar,39.46,62.17,25,0
	.goto Durotar,39.55,63.10,25,0
	.goto Durotar,40.13,64.04,25,0
	.goto Durotar,40.84,64.06,25,0
	.goto Durotar,40.74,65.86,25,0
	.goto Durotar,39.93,66.03,25,0
	.goto Durotar,40.04,66.99,25,0
	.goto Durotar,40.09,67.66,25,0
	.goto Durotar,40.13,68.50,25,0
	.goto Durotar,40.72,68.55,25,0
	.goto Durotar,41.30,67.84,25,0
	.goto Durotar,41.37,66.72,25,0
	.goto Durotar,41.89,66.05,25,0
	.goto Durotar,41.27,65.71,25,0
	.goto Durotar,41.36,64.07,25,0
	.goto Durotar,41.33,63.12,25,0
	.goto Durotar,41.35,61.98,25,0
	.goto Durotar,41.49,61.25,25,0
	.goto Durotar,41.90,60.24,25,0
	.goto Durotar,42.51,59.34,25,0
	.goto Durotar,43.08,59.62,25,0
	.goto Durotar,43.91,59.33,25,0
	.goto Durotar,45.15,59.46,25,0
	.goto Durotar,45.81,59.30,25,0
	.goto Durotar,45.85,60.34,25,0
	.goto Durotar,46.46,61.11,25,0
	.goto Durotar,47.09,62.24,25,0
	.goto Durotar,47.08,63.15,25,0
	.goto Durotar,47.14,64.08,25,0
	.goto Durotar,47.58,64.04,25,0
	.goto Durotar,47.08,63.15,25,0
	.goto Durotar,47.09,62.24,25,0
	.goto Durotar,46.90,61.15,25,0
	.goto Durotar,46.98,60.18,25,0
	.goto Durotar,47.07,59.34,25,0
	.goto Durotar,46.47,58.28,25,0
	.goto Durotar,45.81,59.30,25,0
	.goto Durotar,45.15,59.46,25,0
	.goto Durotar,43.91,59.33,25,0
	.goto Durotar,43.26,58.28,25,0
    >>Kill |cRXP_ENEMY_Scorpid Workers|r. Loot them for the |T134918:0|t|cRXP_LOOT_[Dyadic Icon]|r
    .collect 206381,1 --Dyadic Icon (1)
    .mob Scorpid Worker
    .train 410094,1
    .xp <3,1
step
    .equip 18,206381 >> |cRXP_WARN_Equip the|r |T134918:0|t|cRXP_LOOT_[Dyadic Icon]|r
    .use 206381
    .itemcount 206381,1 --Dyadic Icon (1)
    .train 410094,1
    .xp <3,1
step
#loop
	.line Durotar,43.26,58.28,42.81,58.41,41.90,58.35,41.97,59.20,41.36,60.35,40.66,61.27,40.07,61.35,39.42,61.29,39.46,62.17,39.55,63.10,40.13,64.04,40.84,64.06,40.74,65.86,39.93,66.03,40.04,66.99,40.09,67.66,40.13,68.50,40.72,68.55,41.30,67.84,41.37,66.72,41.89,66.05,41.27,65.71,41.36,64.07,41.33,63.12,41.35,61.98,41.49,61.25,41.90,60.24,42.51,59.34,43.08,59.62,43.91,59.33,45.15,59.46,45.81,59.30,45.85,60.34,46.46,61.11,47.09,62.24,47.08,63.15,47.14,64.08,47.58,64.04,47.08,63.15,47.09,62.24,46.90,61.15,46.98,60.18,47.07,59.34,46.47,58.28,45.81,59.30,45.15,59.46,43.91,59.33,43.26,58.28
	.goto Durotar,43.26,58.28,25,0
	.goto Durotar,42.81,58.41,25,0
	.goto Durotar,41.90,58.35,25,0
	.goto Durotar,41.97,59.20,25,0
	.goto Durotar,41.36,60.35,25,0
	.goto Durotar,40.66,61.27,25,0
	.goto Durotar,40.07,61.35,25,0
	.goto Durotar,39.42,61.29,25,0
	.goto Durotar,39.46,62.17,25,0
	.goto Durotar,39.55,63.10,25,0
	.goto Durotar,40.13,64.04,25,0
	.goto Durotar,40.84,64.06,25,0
	.goto Durotar,40.74,65.86,25,0
	.goto Durotar,39.93,66.03,25,0
	.goto Durotar,40.04,66.99,25,0
	.goto Durotar,40.09,67.66,25,0
	.goto Durotar,40.13,68.50,25,0
	.goto Durotar,40.72,68.55,25,0
	.goto Durotar,41.30,67.84,25,0
	.goto Durotar,41.37,66.72,25,0
	.goto Durotar,41.89,66.05,25,0
	.goto Durotar,41.27,65.71,25,0
	.goto Durotar,41.36,64.07,25,0
	.goto Durotar,41.33,63.12,25,0
	.goto Durotar,41.35,61.98,25,0
	.goto Durotar,41.49,61.25,25,0
	.goto Durotar,41.90,60.24,25,0
	.goto Durotar,42.51,59.34,25,0
	.goto Durotar,43.08,59.62,25,0
	.goto Durotar,43.91,59.33,25,0
	.goto Durotar,45.15,59.46,25,0
	.goto Durotar,45.81,59.30,25,0
	.goto Durotar,45.85,60.34,25,0
	.goto Durotar,46.46,61.11,25,0
	.goto Durotar,47.09,62.24,25,0
	.goto Durotar,47.08,63.15,25,0
	.goto Durotar,47.14,64.08,25,0
	.goto Durotar,47.58,64.04,25,0
	.goto Durotar,47.08,63.15,25,0
	.goto Durotar,47.09,62.24,25,0
	.goto Durotar,46.90,61.15,25,0
	.goto Durotar,46.98,60.18,25,0
	.goto Durotar,47.07,59.34,25,0
	.goto Durotar,46.47,58.28,25,0
	.goto Durotar,45.81,59.30,25,0
	.goto Durotar,45.15,59.46,25,0
	.goto Durotar,43.91,59.33,25,0
	.goto Durotar,43.26,58.28,25,0
    .aura 408828 >>|cRXP_WARN_Let |cRXP_ENEMY_Scorpid Workers|r cast|r |T136016:0|t[Weak Poison] |cRXP_WARN_on you, then take damage from it 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    .mob Scorpid Worker
    .itemStat 18,QUALITY,2
    .train 410094,1
    .xp <3,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134918:0|t|cRXP_LOOT_[Dyadic Icon]|r |cRXP_WARN_to learn|r |T133815:0|t[Engrave Chest - Overload]
    .use 206381
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410094,1
    .xp <3,1
step << !Tauren skip
    .goto Durotar,42.39,69.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shikrik|r
    .turnin 77587 >>Turn in Icons of Power << Troll Shaman
    .turnin 77585 >>Turn in Icons of Power << Orc Shaman
    .target Shikrik
    .xp <3,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Overload - 3 (Mulgore)
#title Overload
#next Shield Mastery - 6 (Mulgore)


    --Rune of Overload
step
    +|cRXP_WARN_You MUST be at least level 3 in order to acquire|r |T133815:0|t[Engrave Chest - Overload] |cRXP_WARN_as it is the level requirement of equipping the|r |T134918:0|t|cRXP_LOOT_[Dyadic Icon]|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133815:0|t[Engrave Chest - Overload]
    .train 410094,1
    .xp >3,1
step
    #completewith IconS
    .zone Mulgore >> Travel to Mulgore
    .train 410094,1
    .xp <3,1
step << Tauren skip
    .goto Mulgore,45.01,75.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meela|r
    .accept 77652 >>Accept Icons of Power
    .target Meela Dawnstrider
    .xp <3,1
step
    #label IconS
    .goto Mulgore,63.74,81.18,50,0
    .goto Mulgore,63.86,79.97,50,0
    .goto Mulgore,65.00,78.60,50,0
    .goto Mulgore,66.05,77.83,50,0
    .goto Mulgore,65.93,77.10,50,0
    .goto Mulgore,63.57,76.25,50,0
    .goto Mulgore,63.86,80.14
    >>Kill |cRXP_ENEMY_Bristleback Shamans|r. Loot them for the |T134918:0|t[|cRXP_FRIENDLY_Dyadic Icon|r]
    .collect 206381,1 --Dyadic Icon (1)
    .mob Bristleback Shaman
    .train 410094,1
    .xp <3,1
step
    .equip 18,206381 >> |cRXP_WARN_Equip the|r |T134918:0|t|cRXP_LOOT_[Dyadic Icon]|r
    .use 206381
    .itemcount 206381,1 --Dyadic Icon (1)
    .train 410094,1
    .xp <3,1
step
    .goto Mulgore,63.74,81.18,50,0
    .goto Mulgore,63.86,79.97,50,0
    .goto Mulgore,65.00,78.60,50,0
    .goto Mulgore,66.05,77.83,50,0
    .goto Mulgore,65.93,77.10,50,0
    .goto Mulgore,63.57,76.25,50,0
    .goto Mulgore,63.86,80.14
    .aura 408828 >>|cRXP_WARN_Let |cRXP_ENEMY_Bristleback Shamans|r cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on you and take damage from it 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    .mob Bristleback Shaman
    .itemStat 18,QUALITY,2
    .train 410094,1
    .xp <3,1
--XX Loop needs to be added
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134918:0|t|cRXP_LOOT_[Dyadic Icon]|r |cRXP_WARN_to learn|r |T133815:0|t[Engrave Chest - Overload]
    .use 206381
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410094,1
    .xp <3,1
step << Tauren skip
    .goto Mulgore,45.01,75.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meela|r
    .turnin 77652 >>Turn in Icons of Power
    .target Meela Dawnstrider
    .xp <3,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Shield Mastery - 6 (Durotar)
#title Shield Mastery
#next Molten Blast - 10 (Durotar)

step
    +|cRXP_WARN_You should be at least level 6 in order to acquire|r |T133815:0|t[Engrave Chest - Shield Mastery] |cRXP_WARN_in Durotar alone|r
    >>|cRXP_WARN_You MUST be at least level 3 as it is the level requirement of equipping the|r |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133815:0|t[Engrave Chest - Shield Mastery]
    .train 410098,1
    .xp >3,1
step
    +|cRXP_WARN_You should be at least level 6 in order to acquire|r |T133815:0|t[Engrave Chest - Shield Mastery] |cRXP_WARN_in Durotar alone|r
    .train 410098,1
    .xp <3,1
    .xp >6,1
step
    #completewith IconS
    .zone Durotar >> Travel to Durotar
    .train 410098,1
    .xp <3,1
step
    #label IconS
    .goto Durotar,52.06,62.49,0
    .goto Durotar,39.43,50.07,0
    .goto Durotar,50.91,51.61,0
    .goto Durotar,56.50,46.68,0
    .goto Durotar,57.03,46.66,0
    .goto Durotar,52.06,62.49,50,0
    .goto Durotar,39.43,50.07,50,0
    .goto Durotar,50.91,51.61,50,0
    .goto Durotar,56.50,46.68,50,0
    .goto Durotar,57.03,46.66,50,0
    .goto Durotar,59.00,58.00
    >>Click the |cRXP_PICK_Galvanic Icon|r Totem. Loot it for the |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r
    >>|cRXP_WARN_The |cRXP_PICK_Galvanic Icon|r has at least 15 spawnpoints, with at least 2 up at a time. It despawns <2 minutes after being looted|r
    >>|cRXP_WARN_It makes a|r |T136051:0|t[Lightning Shield] |cRXP_WARN_sound every 5 minutes if you're within 1000 yards, and shows a Lightning Strike on its location if you're within 300 yards and facing it|r
    .collect 206386,1 --Galvanic Icon (1)
    .train 410098,1
    .xp <3,1
--XX Need to check for more locations
step
    .equip 18,206386 >> |cRXP_WARN_Equip the|r |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r
    .use 206386
    .itemcount 206386,1 --Galvanic Icon (1)
    .train 410098,1
    .xp <3,1
step
    #loop
    .goto Durotar,56.87,53.05,50,0
    .goto Durotar,56.82,54.69,50,0
    .goto Durotar,58.64,53.86,50,0
    .goto Durotar,59.40,56.58,50,0
    .goto Durotar,58.41,58.17,50,0
    .goto Durotar,56.21,58.51,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Kul Tiras Sailor
    .mob Kul Tiras Marine
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <3,1
    .xp >11,1
step
    #completewith Barrens
    .zone The Barrens >> Travel to The Barrens
    .train 410098,1
    .xp <3,1
step
    #loop
    .goto The Barrens,53.94,25.86,50,0
    .goto The Barrens,54.17,25.06,50,0
    .goto The Barrens,54.86,25.43,50,0
    .goto The Barrens,55.62,25.71,50,0
    .goto The Barrens,55.98,26.36,50,0
    .goto The Barrens,55.71,27.21,50,0
    .goto The Barrens,55.44,27.35,50,0
    .goto The Barrens,54.99,26.79,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Razormane Thornweaver
    .mob Razormane Water Seeker
    .mob Razormane Hunter
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <11,1
    .xp >16,1
step
    #loop
    .goto The Barrens,55.97,16.17,50,0
    .goto The Barrens,55.43,16.15,50,0
    .goto The Barrens,54.10,15.51,50,0
    .goto The Barrens,53.10,15.25,50,0
    .goto The Barrens,53.73,13.77,50,0
    .goto The Barrens,55.09,15.00,50,0
    .goto The Barrens,55.62,14.86,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Hecklefang Hyena
    .mob Savannah Prowler
    .mob Savannah Huntress
    .mob Sunscale Screecher
    .mob Barrens Giraffe
    .mob Fleeting Plainstrider
    .mob Zhevra Runner
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <16,1
    .xp >20,1
step
    #label Barrens
    #loop
    .goto The Barrens,40.03,15.36,50,0
    .goto The Barrens,39.39,14.65,50,0
    .goto The Barrens,39.62,11.77,50,0
    .goto The Barrens,38.84,11.93,50,0
    .goto The Barrens,38.44,13.21,50,0
    .goto The Barrens,38.48,14.85,50,0
    .goto The Barrens,37.33,16.23,50,0
    .goto The Barrens,38.64,17.49,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Witchwing Slayer
    .mob Witchwing Windcaller
    .mob Witchwing Ambusher
    .mob Witchwing Roguefeather
    .mob Serena Bloodfeather
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <20,1
    .xp >22,1
step
    #completewith next
    .zone Stonetalon Mountains >> Travel to Stonetalon Mountains
    .train 410098,1
    .xp <3,1
step
    #loop
    .goto Stonetalon Mountains,64.17,57.16,50,0
    .goto Stonetalon Mountains,60.55,54.86,50,0
    .goto Stonetalon Mountains,60.95,51.21,50,0
    .goto Stonetalon Mountains,64.40,48.64,50,0
    .goto Stonetalon Mountains,66.18,52.01,50,0
    .goto Stonetalon Mountains,67.20,51.49,50,0
    .goto Stonetalon Mountains,66.83,45.34,50,0
    .goto Stonetalon Mountains,69.89,53.54,50,0
    .goto Stonetalon Mountains,70.84,56.97,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Venture Co. Logger
    .mob Venture Co. Deforester
    .mob Venture Co. Operator
    .mob Venture Co. Light Shredder
    .mob XT:9
    .mob XT:4
    .mob Deepmoss Webspinner
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <22,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r |cRXP_WARN_to learn|r |T133815:0|t[Engrave Chest - Shield Mastery]
    .use 206386
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <3,1
--XX Cast ID may be wrong, may need to be checked
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Chest
#name Shield Mastery - 6 (Mulgore)
#title Shield Mastery
#next Molten Blast - 8 (Mulgore)


    --Rune of Shield Mastery
 step
    +|cRXP_WARN_You should be at least level 6 in order to acquire|r |T133815:0|t[Engrave Chest - Shield Mastery] |cRXP_WARN_in Mulgore alone|r
    >>|cRXP_WARN_You MUST be at least level 3 as it is the level requirement of equipping the|r |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T133815:0|t[Engrave Chest - Shield Mastery]
    .train 410098,1
    .xp >3,1
step
    +|cRXP_WARN_You should be at least level 6 in order to acquire|r |T133815:0|t[Engrave Chest - Shield Mastery] |cRXP_WARN_in Mulgore alone|r
    .train 410098,1
    .xp <3,1
    .xp >6,1
step
    #completewith IconS
    .zone Mulgore >> Travel to Mulgore
    .train 410098,1
    .xp <3,1
step
    #loop
    .goto Mulgore,41.99,43.49,0
    .goto Mulgore,43.87,48.32,0
    .goto Mulgore,37.45,52.55,0
    .goto Mulgore,41.65,55.98,0
    .goto Mulgore,38.43,72.00,0
    .goto Mulgore,36.72,68.09,0
    .goto Mulgore,53.81,58.41,0
    .goto Mulgore,64.06,55.75,0
    .goto Mulgore,56.23,64.28,0
    .goto Mulgore,56.60,70.13,0
    .goto Mulgore,67.23,66.17,0
    .goto Mulgore,62.30,22.94,0
    .goto Mulgore,56.24,22.06,0
    .goto Mulgore,44.94,11.30,0
    .goto Mulgore,36.33,9.79,0
    .goto Mulgore,30.50,25.98,0
    .goto Mulgore,41.99,43.49,20,0
    .goto Mulgore,43.87,48.32,20,0
    .goto Mulgore,37.45,52.55,20,0
    .goto Mulgore,41.65,55.98,20,0
    .goto Mulgore,38.43,72.00,20,0
    .goto Mulgore,36.72,68.09,20,0
    .goto Mulgore,53.81,58.41,20,0
    .goto Mulgore,64.06,55.75,20,0
    .goto Mulgore,56.23,64.28,20,0
    .goto Mulgore,56.60,70.13,20,0
    .goto Mulgore,67.23,66.17,20,0
    .goto Mulgore,62.30,22.94,20,0
    .goto Mulgore,56.24,22.06,20,0
    .goto Mulgore,44.94,11.30,20,0
    .goto Mulgore,36.33,9.79,20,0
    .goto Mulgore,30.50,25.98,20,0
    >>Click the |cRXP_PICK_Galvanic Icon|r Totem. Loot it for the |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r
    >>|cRXP_WARN_The |cRXP_PICK_Galvanic Icon|r has at least 15 spawnpoints, with at least 2 up at a time. It despawns <2 minutes after being looted|r
    >>|cRXP_WARN_It makes a|r |T136051:0|t[Lightning Shield] |cRXP_WARN_sound every 5 minutes if you're within 1000 yards, and shows a Lightning Strike on its location if you're within 300 yards and facing it|r
    .collect 206386,1 --Galvanic Icon (1)
    .train 410098,1
    .xp <3,1
step
    .equip 18,206386 >> |cRXP_WARN_Equip the|r |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r
    .use 206386
    .itemcount 206386,1 --Galvanic Icon (1)
    .train 410098,1
    .xp <3,1
step
    #loop
    .goto Mulgore,54.24,66.98,30,0
    .goto Mulgore,54.12,65.67,30,0
    .goto Mulgore,53.40,65.49,30,0
    .goto Mulgore,53.19,66.51,30,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Venture Co. Hireling
    .mob Venture Co. Laborer
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <3,1
    .xp >11,1
step
    #loop
    .goto Mulgore,59.86,48.74,30,0
    .goto Mulgore,60.85,49.04,30,0
    .goto Mulgore,61.83,48.28,30,0
    .goto Mulgore,61.40,47.23,30,0
    .goto Mulgore,62.02,45.84,30,0
    .goto Mulgore,62.85,45.30,30,0
    .goto Mulgore,64.87,43.32,30,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Venture Co. Worker
    .mob Venture Co. Supervisor
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <11,1
    .xp >14,1
step
    #completewith Barrens
    .zone The Barrens >> Travel to The Barrens
    .train 410098,1
    .xp <3,1
step
    #loop
    .goto The Barrens,53.94,25.86,50,0
    .goto The Barrens,54.17,25.06,50,0
    .goto The Barrens,54.86,25.43,50,0
    .goto The Barrens,55.62,25.71,50,0
    .goto The Barrens,55.98,26.36,50,0
    .goto The Barrens,55.71,27.21,50,0
    .goto The Barrens,55.44,27.35,50,0
    .goto The Barrens,54.99,26.79,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Razormane Thornweaver
    .mob Razormane Water Seeker
    .mob Razormane Hunter
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <14,1
    .xp >16,1
step
    #loop
    .goto The Barrens,55.97,16.17,50,0
    .goto The Barrens,55.43,16.15,50,0
    .goto The Barrens,54.10,15.51,50,0
    .goto The Barrens,53.10,15.25,50,0
    .goto The Barrens,53.73,13.77,50,0
    .goto The Barrens,55.09,15.00,50,0
    .goto The Barrens,55.62,14.86,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Hecklefang Hyena
    .mob Savannah Prowler
    .mob Savannah Huntress
    .mob Sunscale Screecher
    .mob Barrens Giraffe
    .mob Fleeting Plainstrider
    .mob Zhevra Runner
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <16,1
    .xp >20,1
step
    #label Barrens
    #loop
    .goto The Barrens,40.03,15.36,50,0
    .goto The Barrens,39.39,14.65,50,0
    .goto The Barrens,39.62,11.77,50,0
    .goto The Barrens,38.84,11.93,50,0
    .goto The Barrens,38.44,13.21,50,0
    .goto The Barrens,38.48,14.85,50,0
    .goto The Barrens,37.33,16.23,50,0
    .goto The Barrens,38.64,17.49,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Witchwing Slayer
    .mob Witchwing Windcaller
    .mob Witchwing Ambusher
    .mob Witchwing Roguefeather
    .mob Serena Bloodfeather
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <20,1
    .xp >22,1
step
    #completewith next
    .zone Stonetalon Mountains >> Travel to Stonetalon Mountains
    .train 410098,1
    .xp <3,1
step
    #loop
    .goto Stonetalon Mountains,64.17,57.16,50,0
    .goto Stonetalon Mountains,60.55,54.86,50,0
    .goto Stonetalon Mountains,60.95,51.21,50,0
    .goto Stonetalon Mountains,64.40,48.64,50,0
    .goto Stonetalon Mountains,66.18,52.01,50,0
    .goto Stonetalon Mountains,67.20,51.49,50,0
    .goto Stonetalon Mountains,66.83,45.34,50,0
    .goto Stonetalon Mountains,69.89,53.54,50,0
    .goto Stonetalon Mountains,70.84,56.97,50,0
    .aura 408828 >>|cRXP_WARN_Attack enemies down to low health, then cast|r |T136048:0|t[Lightning Bolt] |cRXP_WARN_on them to kill them. Do this 10 times to gain the|r |T136116:0|t[Inspired] |cRXP_WARN_buff|r
    >>|cRXP_WARN_NOTE: You must do this on enemies that can provide experience to gain stacks|r
    .mob Venture Co. Logger
    .mob Venture Co. Deforester
    .mob Venture Co. Operator
    .mob Venture Co. Light Shredder
    .mob XT:9
    .mob XT:4
    .mob Deepmoss Webspinner
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <22,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134918:0|t|cRXP_LOOT_[Galvanic Icon]|r |cRXP_WARN_to learn|r |T133815:0|t[Engrave Chest - Shield Mastery]
    .use 206386
    .aura -408828
    .itemStat 18,QUALITY,2
    .train 410098,1
    .xp <3,1
--XX Cast ID may be wrong, may need to be checked
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Ancestral Guidance - 6 (Durotar)
#title Ancestral Guidance
#next Molten Blast - 10 (Durotar)

    --Rune of Ancestral Guidance
step
    +|cRXP_WARN_You should be at least level 6 in order to acquire|r |T134596:0|t[Engrave Pants - Ancestral Guidance] |cRXP_WARN_in Durotar with another player|r
    >>|cRXP_WARN_You MUST be at least level 3 as it is the level requirement of using the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r
    .train 410099,1
    .xp <3,1
step
    +|cRXP_WARN_You should be at least level 6 in order to acquire|r |T134596:0|t[Engrave Pants - Ancestral Guidance] |cRXP_WARN_in Durotar with another player|r
    .train 410099,1
    .xp <3,1
    .xp >6,1
step
    #completewith next
    #label Durotar1
    .zone Durotar >> Travel to Durotar
    .train 410099,1
    .xp <3,1
step
    #completewith next
    #requires Durotar1
    .goto Durotar,50.84,79.14,40,0
    .goto Durotar,48.02,79.46,40 >>Travel toward the |cRXP_FRIENDLY_Adventurer's Remains|r
    .train 410099,1
    .xp <3,1
step
    #label IconS
    .goto Durotar,48.02,79.46
    >>|cRXP_WARN_Join a group with another Shaman, Priest, or Druid standing over the |cRXP_FRIENDLY_Adventurer's Remains|r, or look for help from a Shaman, Priest, or Druid in General Chat (Type /1 into chat)|r
    >>|cRXP_WARN_Talk to the |cRXP_FRIENDLY_Adventurer's Remains|r on the ground to begin the ritual, OR click the other player's|r |T136223:0|t[Spirit Ritual] |cRXP_WARN_(whilst in their group)|r
    >>|cRXP_WARN_A |cRXP_FRIENDLY_Adventurer's Spirit|r will spawn and die after completing the ritual. Loot it for the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r
    .collect 210589,1 --Echo of the Ancestors (1)
    .target Adventurer's Remains
    .target Adventurer's Spirit
    .skipgossip
    .train 410099,1
    .xp <3,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r |cRXP_WARN_to learn|r |T134596:0|t[Engrave Pants - Ancestral Guidance]
    .use 210589
    .itemcount 210589,1 --Echo of the Ancestors (1)
    .train 410099,1
    .xp <3,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Ancestral Guidance - 10 (Mulgore)
#title Ancestral Guidance
#next Way of Earth - 12 (The Barrens)


    --Rune of Ancestral Guidance

step
    +|cRXP_WARN_You should be at least level 10 in order to acquire|r |T134596:0|t[Engrave Pants - Ancestral Guidance] |cRXP_WARN_in Mulgore with another player|r
    >>|cRXP_WARN_You MUST be at least level 3 as it is the level requirement of using the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r
    .train 410099,1
    .xp <3,1
step
    +|cRXP_WARN_You should be at least level 10 in order to acquire|r |T134596:0|t[Engrave Pants - Ancestral Guidance] |cRXP_WARN_in Mulgore with another player|r
    .train 410099,1
    .xp <3,1
    .xp >10,1
step
    #completewith next
    #label Mulgore1
    .zone Mulgore >> Travel to Mulgore
    .train 410099,1
    .xp <3,1
step
    #completewith next
    #requires Mulgore1
    #label Cave1
    .goto Mulgore,61.46,47.21,20 >>Enter The Venture Co. Mine
    .train 410099,1
    .xp <3,1
step
    #completewith next
    #requires Cave1
    #label Cave2
    .goto Mulgore,62.52,45.37,25,0
    .goto Mulgore,62.56,44.48,25,0
    .goto Mulgore,61.50,42.54,25,0
    .goto Mulgore,61.66,41.45,25,0
    .goto Mulgore,63.08,39.33,25,0
    .goto Mulgore,62.69,38.01,25,0
    .goto Mulgore,60.05,35.82,20 >>Exit the Venture Co. Mine on the other side
    .train 410099,1
    .xp <3,1
step
    #completewith next
    #requires Cave2
    .goto Mulgore,60.39,33.54,40 >>Travel toward the |cRXP_FRIENDLY_Adventurer's Remains|r
    .train 410099,1
    .xp <3,1
--XX Might be a faster method via the mountains, but don't want to complicate it
step
    #label IconS
    .goto Mulgore,60.39,33.54
    >>|cRXP_WARN_Join a group with another Shaman, Priest, or Druid standing over the |cRXP_FRIENDLY_Adventurer's Remains|r, or look for help from a Shaman, Priest, or Druid in General Chat (Type /1 into chat)|r
    >>|cRXP_WARN_Talk to the |cRXP_FRIENDLY_Adventurer's Remains|r on the ground to begin the ritual, OR click the other player's|r |T136223:0|t[Spirit Ritual] |cRXP_WARN_(whilst in their group)|r
    >>|cRXP_WARN_A |cRXP_FRIENDLY_Adventurer's Spirit|r will spawn and die after completing the ritual. Loot it for the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r
    .collect 210589,1 --Echo of the Ancestors (1)
    .target Adventurer's Remains
    .target Adventurer's Spirit
    .skipgossip
    .train 410099,1
    .xp <3,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T237571:0|t|cRXP_LOOT_[Echo of the Ancestors]|r |cRXP_WARN_to learn|r |T134596:0|t[Engrave Pants - Ancestral Guidance]
    .use 210589
    .itemcount 210589,1 --Echo of the Ancestors (1)
    .train 410099,1
    .xp <3,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Way of Earth - 12 (The Barrens)
#title Way of Earth
#next Water Shield - 20 (The Barrens)



step
    +|cRXP_WARN_You MUST be at least level 12 in order to acquire|r |T134596:0|t[Engrave Pants - Way of Earth] |cRXP_WARN_as it is the level requirement of training|r |T136075:0|t[Purge]
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T134596:0|t[Engrave Pants - Way of Earth]
    >>|cRXP_WARN_Alternatively, you can get|r |T134596:0|t[Engrave Pants - Way of Earth] |cRXP_WARN_in Silverpine Forest at level 1+|r
    .train 410107,1
    .xp >12,1
step
    .zone Orgrimmar >>Travel to Orgrimmar or Thunder Bluff
    .zoneskip Thunder Bluff
    .train 370,1
    .xp <12,1
step
    #completewith next
    .goto Orgrimmar,40.31,37.01,15,0
    .goto Orgrimmar,38.81,36.37,15 >>Travel toward |cRXP_FRIENDLY_Kardris|r
    .zoneskip Thunder Bluff
    .train 410107,1
    .xp <12,1
step
    .goto Orgrimmar,38.81,36.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
    .train 370 >> Train |T136075:0|t[Purge]
    .target Kardris Dreamseeker
    .zoneskip Thunder Bluff
    .train 410107,1
    .xp <12,1
step
    #completewith next
    .goto Thunder Bluff,22.82,21.11,15 >>Travel toward |cRXP_FRIENDLY_Siln|r
    .zoneskip Orgrimmar
    .train 410107,1
    .xp <12,1
step
    .goto Thunder Bluff,22.82,21.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Siln|r
    .train 370 >> Train |T136075:0|t[Purge]
    .target Siln Skychaser
    .zoneskip Orgrimmar
    .train 410107,1
    .xp <12,1
step
    #completewith next
    .zone The Barrens >>Travel to The Barrens
    .train 410107,1
    .xp <12,1
step
    #loop
    .goto The Barrens,55.77,34.01,40,0 --Spawn 1
    .goto The Barrens,55.83,34.21,40,0
    .goto The Barrens,54.81,35.95,40,0 --Spawn 2
    .goto The Barrens,54.96,35.72,40,0
    .goto The Barrens,57.47,36.03,40,0 --Spawn 3
    .goto The Barrens,57.56,35.78,40,0
    .goto The Barrens,57.46,35.70,40,0
    .goto The Barrens,57.59,38.36,40,0 --Spawn 4
    .goto The Barrens,57.49,38.65,40,0
    .goto The Barrens,58.82,37.67,40,0 --Spawn 5
    .goto The Barrens,58.92,37.53,40,0
    .goto The Barrens,58.94,37.73,40,0
    >>Cast |T136075:0|t[Purge] on the |cRXP_ENEMY_Desert Mirage|r to kill it. Loot it for the |T134419:0|t|cRXP_LOOT_[Earthen Rune]|r
    .collect 208758,1 --Earthen Rune (1)
    .unitscan Desert Mirage
    .train 410107,1
    .xp <12,1
--XX Respawns after 85s-170s
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Earthen Rune]|r |cRXP_WARN_to learn|r |T134596:0|t[Engrave Pants - Way of Earth]
    .use 208758
    .itemcount 208758,1 --Earthen Rune (1)
    .train 410107,1
    .xp <12,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Way of Earth - 14 (Silverpine Forest)
#title Way of Earth
#next Water Shield - 20 (Silverpine Forest)

step
    +|cRXP_WARN_You should be at least level 14 in order to acquire|r |T134596:0|t[Engrave Pants - Way of Earth] |cRXP_WARN_in Silverpine Forest alone|r
    >>|cRXP_WARN_You need to level up more before even attempting to acquire|r |T134596:0|t[Engrave Pants - Way of Earth]
    .train 410107,1
    .xp >14,1
step
    #completewith next
    .zone Silverpine Forest >>Travel to the Silverpine Forest
    .train 410107,1
step
    #loop
    .goto Silverpine Forest,45.68,22.63,30,0
    .goto Silverpine Forest,45.09,23.63,30,0
    .goto Silverpine Forest,44.16,22.47,30,0
    .goto Silverpine Forest,44.05,21.66,30,0
    .goto Silverpine Forest,45.05,20.75,30,0
    .goto Silverpine Forest,45.07,19.79,30,0
    .goto Silverpine Forest,45.59,19.29,30,0
    .goto Silverpine Forest,46.18,19.74,30,0
    .goto Silverpine Forest,46.62,20.44,30,0
    .goto Silverpine Forest,46.07,21.92,30,0
    >>Kill |cRXP_ENEMY_Rot Hide Mystics|r. Loot them for the |T136008:0|t|cRXP_LOOT_[Rot Totem]|r
    .collect 210253,1 --Rot Hide Totem (1)
    .mob Rot Hide Mystic
    .itemcount 208758,<1 --Earthen Rune (1)
    .train 410107,1
step
    #completewith Rune
    .cast 425285 >> |cRXP_WARN_Use the|r |T136008:0|t|cRXP_LOOT_[Rot Totem]|r |cRXP_WARN_to summon the |cRXP_ENEMY_Decayed Elemental|r
    .use 210253 --Rot Hide Totem (1)
    .itemcount 210253,1 --Rot Hide Totem (1)
    .train 410107,1
    .xp <14,1
step
    #completewith next
    .cast 425285 >> |cRXP_WARN_Use the|r |T136008:0|t|cRXP_LOOT_[Rot Totem]|r |cRXP_WARN_to summon the |cRXP_ENEMY_Decayed Elemental|r
    >>|cRXP_WARN_Be careful as it casts|r |T135848:0|t[Frost Nova] |cRXP_WARN_(Ranged Instant: Deals about 50 damage and roots for 8 seconds) and is level 15|r
    .use 210253 --Rot Hide Totem (1)
    .itemcount 210253,1 --Rot Hide Totem (1)
    .train 410107,1
    .xp >14,1
step
    #label Rune
    >>Kill the |cRXP_ENEMY_Decayed Elemental|r. Loot it for the |T134419:0|t|cRXP_LOOT_[Earthen Rune]|r
    .collect 208758,1 --Earthen Rune (1)
    .mob Decayed Elemental
    .train 410107,1
--XX Need to test if it can be summoned anywhere, and how much or how scary it is
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Earthen Rune]|r |cRXP_WARN_to learn|r |T134596:0|t[Engrave Pants - Way of Earth]
    .use 208758
    .itemcount 208758,1 --Earthen Rune (1)
    .train 410107,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Greater Ghost Wolf - 25 (Stonetalon Mountains)
#title Greater Ghost Wolf
#next Dual Wield Specialization - 25 (Ratchet)


step
    +|cRXP_WARN_You should be at least level 25 in order to acquire|r |T134596:0|t[Engrave Pants - Greater Ghost Wolf] |cRXP_WARN_in Stonetalon Mountains alone|r
    .train 425343,1
    .xp >25,1
step
    #completewith next
    .zone Stonetalon Mountains >>Travel to Stonetalon Mountains
    .train 425343,1
step
    #loop
    .goto Stonetalon Mountains,28.45,65.00,0
    .goto Stonetalon Mountains,28.45,65.00,50,0
    .goto Stonetalon Mountains,29.08,71.97,50,0
    .goto Stonetalon Mountains,33.43,68.97,50,0
    .goto Stonetalon Mountains,33.49,69.40,50,0
    .goto Stonetalon Mountains,36.85,72.04,50,0
    >>Kill the |cRXP_ENEMY_Primordial Anomaly|r. Loot it for the |T134419:0|t|cRXP_LOOT_[Rune of Primordial Fury]|r
    >>|cRXP_WARN_Make sure to check its form (debuffs). If it's in|r |T136074:0|t[Nature Form]|cRXP_WARN_, deal|r |T135824:0|t[Fire Damage]|cRXP_WARN_. If it's in|r |T135819:0|t[Fire Form]|cRXP_WARN_, deal|r |T135865:0|t[Frost Damage]|cRXP_WARN_. If it's in|r |T135861:0|t[Water Form]|cRXP_WARN_, deal|r |T136085:0|t[Nature Damage]
    >>|cRXP_WARN_Be careful as it casts |T132939:0|t[Knock Away] |cRXP_WARN_(Melee Instant: Knocks target up in the air and deals 80 damage)|r
    >>|cRXP_WARN_It has a 5-8 minute respawn time and drops a random BoE green each time|r
    .collect 210811,1 --Rune of Primordial Fury (1)
    .mob Primordial Anomaly
    .train 425343,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Rune of Primordial Fury]|r |cRXP_WARN_to learn|r |T134596:0|t[Engrave Pants - Greater Ghost Wolf]
    .use 210811
    .itemcount 210811,1 --Rune of Primordial Fury (1)
    .train 425343,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Legs
#name Earth Shield - 25 (Azeroth)
#title Earth Shield
#next Overload - 3 (Durotar) << Orc Shaman/Troll Shaman
#next Overload - 3 (Mulgore) << Tauren Shaman


step
    +|cRXP_WARN_You MUST be at least level 25 in order to acquire|r |T134596:0|t[Engrave Pants - Earth Shield] |cRXP_WARN_as it is the level requirement of entering Blackfathom Deeps|r
    .train 410101,1
    .xp >25,1
step
    .zone Orgrimmar >>Travel to Orgrimmar or Thunder Bluff
    .zoneskip Thunder Bluff
    .train 410101,1
    .xp <25,1
step
    .goto Orgrimmar,50.67,70.39,0
    .goto Orgrimmar,53.74,64.60,15,0
    .goto Orgrimmar,55.54,64.81
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Wabang|r
    >>|cRXP_BUY_Buy a|r |T134797:0|t[Elixir of Water Breathing] |cRXP_BUY_and|r |T134717:0|t[Elixir of Wisdom] |cRXP_BUY_from the Auction House|r
    >>|cRXP_WARN_Alternatively, buy the materials to craft them yourself: 2|r |T132799:0|t[Blackmouth Oil] |cRXP_WARN_(or 4|r |T134302:0|t[Oily Blackmouth] |cRXP_WARN_to craft the oil), 1|r |T134191:0|t[Stranglekelp]|cRXP_WARN_, 1|r |T133436:0|t[Mageroyal]|cRXP_WARN_, and 2|r |T134412:0|t[Briarthorn]
    >>|cRXP_WARN_You need this for a quest later. Do NOT use them before then|r
    .collect 5996,1 --Elixir of Water Breathing (1)
    .collect 3383,1 --Elixir of Wisdom (1)
    .target Auctioneer Wabang
	.skill alchemy,<90,1
    .zoneskip Orgrimmar,1
    .train 410101,1
    .xp <25,1
step
    .goto Orgrimmar,50.67,70.39,0
    .goto Orgrimmar,53.74,64.60,15,0
    .goto Orgrimmar,55.54,64.81
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Wabang|r
    >>|cRXP_BUY_Buy a|r |T134797:0|t[Elixir of Water Breathing] |cRXP_BUY_and|r |T134717:0|t[Elixir of Wisdom] |cRXP_BUY_from the Auction House|r
    >>|cRXP_WARN_You need this for a quest later. Do NOT use them before then|r
    .collect 5996,1 --Elixir of Water Breathing (1)
    .collect 3383,1 --Elixir of Wisdom (1)
    .target Auctioneer Wabang
    .zoneskip Orgrimmar,1
    .train 410101,1
    .xp <25,1
step
    .goto Thunder Bluff,45.23,59.40,0
    .goto Thunder Bluff,40.41,51.78
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stampi|r
    >>|cRXP_BUY_Buy a|r |T134797:0|t[Elixir of Water Breathing] |cRXP_BUY_and|r |T134717:0|t[Elixir of Wisdom] |cRXP_BUY_from the Auction House|r
    >>|cRXP_WARN_Alternatively, buy the materials to craft them yourself: 2|r |T132799:0|t[Blackmouth Oil] |cRXP_WARN_(or 4|r |T134302:0|t[Oily Blackmouth] |cRXP_WARN_to craft the oil), 1|r |T134191:0|t[Stranglekelp]|cRXP_WARN_, 1|r |T133436:0|t[Mageroyal]|cRXP_WARN_, and 2|r |T134412:0|t[Briarthorn]
    >>|cRXP_WARN_You need this for a quest later. Do NOT use them before then|r
    .collect 5996,1 --Elixir of Water Breathing (1)
    .collect 3383,1 --Elixir of Wisdom (1)
    .target Auctioneer Stampi
	.skill alchemy,<90,1
    .zoneskip Thunder Bluff,1
    .train 410101,1
    .xp <25,1
step
    .goto Thunder Bluff,45.23,59.40,0
    .goto Thunder Bluff,40.41,51.78
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stampi|r
    >>|cRXP_BUY_Buy a|r |T134797:0|t[Elixir of Water Breathing] |cRXP_BUY_and|r |T134717:0|t[Elixir of Wisdom] |cRXP_BUY_from the Auction House|r
    >>|cRXP_WARN_You need this for a quest later. Do NOT use them before then|r
    .collect 5996,1 --Elixir of Water Breathing (1)
    .collect 3383,1 --Elixir of Wisdom (1)
    .target Auctioneer Stampi
    .zoneskip Thunder Bluff,1
    .train 410101,1
    .xp <25,1
step
    #completewith next
    .zone Ashenvale >> Travel to Ashenvale
    .train 410101,1
    .xp <25,1
step
    #completewith next
    .goto Kalimdor,44.36,34.86
    >>|cRXP_WARN_Join or create a fresh (0/7) raid (10-man) group for Blackfathom Deeps|r
    .subzone 2797,2 >> Make your way to the BFD Instance Portal. Zone in
    .train 410101,1
    .xp <25,1
step
    >>Kill |cRXP_ENEMY_Baron Aquanis|r in Blackfathom Deeps. Loot him for the |T136222:0|t|cRXP_LOOT_[Strange Water Globe]|r
    .collect 211454,1 --Strange Water Globe (SoD) (1)
    .mob Baron Aquanis
    .train 410101,1
    .xp <25,1
step
    >>Use the |T136222:0|t|cRXP_LOOT_[Strange Water Globe]|r to start the quest
    .accept 78920 >>Accept Baron Aquanis
    .use 211454
    .itemcount 211454,1 --Strange Water Globe (SoD) (1)
    .train 410101,1
    .xp <25,1
step
    #completewith Baron
    >>|cRXP_WARN_Finish the raid if you want, then leave Blackfathom Deeps|r
    .zone Ashenvale >> Travel to Ashenvale
    .zoneskip 221,1
    .train 410101,1
    .xp <25,1
step
    #completewith next
    .zone Ashenvale >> Travel to Ashenvale
    .train 410101,1
    .xp <25,1
step
    #label Baron
    .goto Ashenvale,11.56,34.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Je'neu Sancrea|r
    .turnin 78920 >>Turnin Baron Aquanis
    .accept 78506 >>Accept Elemental Distress
    .target Je'neu Sancrea
    .train 410101,1
    .xp <25,1
step
#loop
	.line Ashenvale,48.36,69.74,48.43,70.14,48.93,70.82,49.49,70.76,50.21,70.36,50.47,70.43,50.54,71.08,50.74,71.31,51.42,70.86,52.13,71.14,52.18,71.60,52.08,72.10,45.84,70.67,48.36,69.74
	.goto Ashenvale,48.36,69.74,50,0
	.goto Ashenvale,48.43,70.14,50,0
	.goto Ashenvale,48.93,70.82,50,0
	.goto Ashenvale,49.49,70.76,50,0
	.goto Ashenvale,50.21,70.36,50,0
	.goto Ashenvale,50.47,70.43,50,0
	.goto Ashenvale,50.54,71.08,50,0
	.goto Ashenvale,50.74,71.31,50,0
	.goto Ashenvale,51.42,70.86,50,0
	.goto Ashenvale,52.13,71.14,50,0
	.goto Ashenvale,52.18,71.60,50,0
	.goto Ashenvale,52.08,72.10,50,0
	.goto Ashenvale,45.84,70.67,50,0
	.goto Ashenvale,48.36,69.74,50,0
    >>Kill |cRXP_ENEMY_Befouled Water Elementals|r. Loot them for the |T132844:0|t|cRXP_LOOT_[Mote of Torrential Rage]|r
    .complete 78506,3 --Mote of Torrential Rage (1)
    .mob Befouled Water Elemental
    .train 410101,1
    .xp <25,1
--XX Needs to be converted to hashtag loop
step
    #completewith next
    .zone Stonetalon Mountains >>Travel to Stonetalon Mountains
    .train 410101,1
    .xp <25,1
step
    #loop
    #completewith next
    .goto Stonetalon Mountains,45.60,44.18,50,0 --NE Rogue Flame Shared Spawn Cluster (NE Spawnpoints)
    .goto Stonetalon Mountains,44.54,43.43,50,0
    .goto Stonetalon Mountains,43.96,39.90,50,0
    .goto Stonetalon Mountains,43.62,41.14,50,0
--
    .goto Stonetalon Mountains,37.09,46.62,50,0 --Path Rogue Flame Shared Spawn Cluster (Middle Spawnpoints)
    .goto Stonetalon Mountains,35.71,47.81,50,0
    .goto Stonetalon Mountains,37.21,48.30,50,0
    .goto Stonetalon Mountains,36.50,49.86,50,0
    .goto Stonetalon Mountains,37.18,51.87,50,0
    .goto Stonetalon Mountains,35.33,53.88,50,0
    .goto Stonetalon Mountains,34.59,60.23,50,0
    .goto Stonetalon Mountains,33.38,62.23,50,0
--
    .goto Stonetalon Mountains,35.22,65.79,50,0 --Start of Burning Destroyers and Ravagers
    .goto Stonetalon Mountains,36.42,71.05,50,0
    .goto Stonetalon Mountains,35.73,73.27,50,0
    .goto Stonetalon Mountains,34.50,72.62,50,0
    .goto Stonetalon Mountains,33.64,71.17,50,0
    .goto Stonetalon Mountains,33.49,70.48,50,0
    .goto Stonetalon Mountains,31.67,71.11,50,0
    .goto Stonetalon Mountains,31.13,73.45,50,0
    .goto Stonetalon Mountains,30.13,73.32,50,0
    .goto Stonetalon Mountains,30.97,67.39,50,0
    .goto Stonetalon Mountains,28.25,65.96,50,0
    >>Kill |cRXP_ENEMY_Rogue Flame Spirits|r, |cRXP_ENEMY_Burning Destroyers|r, and |cRXP_ENEMY_Burning Ravagers|r. Loot them for the |T132839:0|t|cRXP_LOOT_[Mote of Infernal Rage]|r
    >>|cRXP_ENEMY_Rogue Flame Spirits|r |cRXP_WARN_share spawns with|r |cRXP_ENEMY_Blackened Basilisks|r
    .complete 78506,2 --Mote of Infernal Rage (1)
    .mob Rogue Flame Spirit
    .mob Burning Destroyer
    .mob Burning Ravager
    .train 410101,1
    .xp <25,1
--XX Did waypoints in WOTLK, may be slightly off but i'd put more money on it being accurate than not
step
    #loop
    .goto Stonetalon Mountains,34.07,65.61,50,0
    .goto Stonetalon Mountains,36.42,71.05,50,0
    .goto Stonetalon Mountains,35.88,72.31,50,0
    .goto Stonetalon Mountains,32.49,73.81,50,0
    .goto Stonetalon Mountains,32.64,67.42,50,0
    .goto Stonetalon Mountains,28.99,65.18,50,0
    >>Kill |cRXP_ENEMY_Enraged Stone Spirits|r and |cRXP_ENEMY_Furious Stone Spirits|r. Loot them for |T132838:0|t|cRXP_LOOT_[Mote of Seismic Rage]|r |cRXP_WARN_be careful of dangerous enemies in the area.|r
    .complete 78506,1 --Mote of Seismic Rage (1)
    .mob Enraged Stone Spirit
    .mob Furious Stone Spirit
    .train 410101,1
    .xp <25,1
--XX Not totally sure if any of the elementals in the charred vale do/don't share spawns? It's a total clown fiesta
step
    #loop
    .goto Stonetalon Mountains,45.60,44.18,50,0
    .goto Stonetalon Mountains,44.54,43.43,50,0
    .goto Stonetalon Mountains,43.96,39.90,50,0
    .goto Stonetalon Mountains,43.62,41.14,50,0
    .goto Stonetalon Mountains,37.09,46.62,50,0
    .goto Stonetalon Mountains,35.71,47.81,50,0
    .goto Stonetalon Mountains,37.21,48.30,50,0
    .goto Stonetalon Mountains,36.50,49.86,50,0
    .goto Stonetalon Mountains,37.18,51.87,50,0
    .goto Stonetalon Mountains,35.33,53.88,50,0
    .goto Stonetalon Mountains,34.59,60.23,50,0
    .goto Stonetalon Mountains,33.38,62.23,50,0
    .goto Stonetalon Mountains,35.22,65.79,50,0
    .goto Stonetalon Mountains,36.42,71.05,50,0
    .goto Stonetalon Mountains,35.73,73.27,50,0
    .goto Stonetalon Mountains,34.50,72.62,50,0
    .goto Stonetalon Mountains,33.64,71.17,50,0
    .goto Stonetalon Mountains,33.49,70.48,50,0
    .goto Stonetalon Mountains,31.67,71.11,50,0
    .goto Stonetalon Mountains,31.13,73.45,50,0
    .goto Stonetalon Mountains,30.13,73.32,50,0
    .goto Stonetalon Mountains,30.97,67.39,50,0
    .goto Stonetalon Mountains,28.25,65.96,50,0
    >>Kill |cRXP_ENEMY_Rogue Flame Spirits|r, |cRXP_ENEMY_Burning Destroyers|r, and |cRXP_ENEMY_Burning Ravagers|r. Loot them for the |T132839:0|t|cRXP_LOOT_[Mote of Infernal Rage]|r
    >>|cRXP_ENEMY_Rogue Flame Spirits|r |cRXP_WARN_share spawns with|r |cRXP_ENEMY_Blackened Basilisks|r
    .complete 78506,2 --Mote of Infernal Rage (1)
    .mob Rogue Flame Spirit
    .mob Burning Destroyer
    .mob Burning Ravager
    .train 410101,1
    .xp <25,1
step
    #completewith next
    .zone Ashenvale >>Travel to Ashenvale
    .train 410101,1
    .xp <25,1
step
    .goto Ashenvale,11.56,34.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Je'neu Sancrea|r
    .turnin 78506 >>Turnin Elemental Distress
    .accept 78537 >>Accept Elixir of Insight
    .accept 78537 >>Turnin Elixir of Insight
    .accept 78561 >>Accept Elixir of Insight
    .target Je'neu Sancrea
    .train 410101,1
    .xp <25,1
step
    .goto Ashenvale,11.38,33.08
    >>Use the |T134791:0|t[Elixir of Insight] near the Bonfire
    >>|cRXP_WARN_You do NOT need to wait out the RP|r
    .complete 78561,1 --Vision Witnessed (1)
    .use 210712
    .train 410101,1
    .xp <25,1
step
    .goto Ashenvale,11.56,34.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Je'neu Sancrea|r
    .turnin 78561 >>Turnin Elixir of Insight
    .accept 78575 >>Accept Hirzek
    .target Je'neu Sancrea
    .train 410101,1
    .xp <25,1
step
    #completewith next
    .zone The Barrens >>Travel to The Barrens
    .train 410101,1
    .xp <25,1
step
    .goto The Barrens,43.18,78.59
    >>Kill |cRXP_ENEMY_Hirzek|r. Loot him for |T135146:0|t|cRXP_LOOT_[Hirzek's Staff]|r
    >>|cRXP_WARN_Be careful as |cRXP_ENEMY_Hirzek|r casts|r |T135805:0|t[Lightning Bolt] |cRXP_WARN_(Ranged Cast: Deals about 110 Nature Damage) and is a level 25 elite. He is soloable, but you may want to find someone to assist you|r
    >>|cRXP_WARN_Be careful as the |cRXP_ENEMY_Bound Elemental|r has an infinite leash if you kill |cRXP_ENEMY_Hirzek|r and leave the |cRXP_ENEMY_Bound Elemental|r alive (it'll follow you until it de-renders or you kill it)|r
    .complete 78575,1 --Hirzek's Staff (1)
    .complete 78575,2 --Hirzek (1)
    .mob Hirzek
    .mob Bound Elemental
    .train 410101,1
    .xp <25,1
--XX Objective IDs (,1 and ,2) need testing
step
    #completewith next
    .zone Ashenvale >>Travel to Ashenvale
    .train 410101,1
    .xp <25,1
step
    .goto Ashenvale,11.56,34.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Je'neu Sancrea|r
    .turnin 78575 >>Turnin Hirzek
    .target Je'neu Sancrea
    .train 410101,1
    .xp <25,1
step
    .cast 402265 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Rune of Earth Shield]|r |cRXP_WARN_to learn|r |T134596:0|t[Engrave Pants - Earth Shield]
    .use 210746
    .itemcount 210746,1 --Rune of Earth Shield (1)
    .train 410101,1
    .xp <25,1
    --XX Rune Routing will never be good for this
step << skip
    +Congratulations! You have acquired all |T134419:0|t|cRXP_LOOT_[Runes]|r currently available.
    .train 410094,3 --Overload
    .train 410095,3 --Lava Burst
    .train 410096,3 --Dual Wield Specialization
    .train 410097,3 --Water Shield
    .train 410098,3 --Shield Mastery
    .train 410099,3 --Ancestral Guidance
    .train 410101,3 --Earth Shield
    .train 410104,3 --Lava Lash
    .train 410107,3 --Way of Earth
    .train 416057,3 --Healing Rain
    .train 425343,3 --Shamanistic Rage
    .train 425344,3 --Molten Blast
    .xp <25,1
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Belt
#name Fire Nova - 35 (Azeroth)
#title Fire Nova

-- Fire Nova

step
    #completewith next
    .zone Desolace >>Travel to |cFFfa9602Desolace|r
step
    .goto Desolace,56.6,21.8
    >>Kill |cRXP_ENEMY_Flameseer Dubelen|r. Loot him for the |T136008:0|t|cRXP_LOOT_Corrupted Fire Totem|r
    .collect 213451,1
    .mob Flameseer Dubelen
step
    .goto 1443,38.23,61,25,0
    .goto 1443,37.13,60.41,25,0
    .goto 1443,35.38,58.25,25,0
    .goto 1443,33.03,55.4,25,0
    .goto 1443,30.87,57.86,25,0
    .goto 1443,29.85,62.5,25,0
    .goto 1414,38.38,57.98,25,0
    .goto 1414,38.42,57.98,25,0
    .goto 1414,38.35,58.14,25,0
    .goto 1414,38.28,58.17,25,0
    .goto 1414,38.24,58.03,25,0
    .goto 1414,38.31,58.02,25,0
    .goto 1414,38.47,58.17,25,0
    .goto 1414,38.6,58.24,25,0
    .goto 1414,38.73,58.18,25,0
    .goto 1414,38.83,58.31,25,0
    .goto 1414,39.01,58.3,25,0
    .goto 1414,39.17,58.09,25,0
    .goto 1414,39.01,57.87,25,0
    .goto 1414,39.26,57.69
    >>Click on the |cRXP_PICK_Blue Crystal|r amongst the orange crystals to collect |T134088:0|t[Tear of Theradras]
    >>|cRXP_WARN_Be careful as enemies in this area are elite and they can stun.|r |cFFFF0000you are likely going to die multiple times|r
    .collect 213552,1
step
    .goto 1414,38.45,57.84,25,0
    .goto 1414,38.64,57.69,25,0
    .goto 1414,38.52,57.52,25,0
    .goto 1414,38.43,57.43,25,0
    .goto 1443,29.65,57.19,25,0
    .goto 1443,27.72,57.51
    >>Click on a |cRXP_PICK_Blue Crystal|r amongst the purple crystals to collect |T134088:0|t[Tear of Theradras]
    >>|cRXP_WARN_Be careful as enemies in this area are elite and they can stun.|r |cFFFF0000you are likely going to die multiple times|r
    .collect 213553,1
step
    #completewith next
    .zone Orgrimmar >>Travel to |cFFfa9602Orgrimmar|r
step
    .goto Orgrimmar,38.94,38.39
    .gossip 4047 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zor Lonetree|r and select the dialog option
    -- .gossipoption --x insert id
    .target Zor Lonetree
step
    #completewith next
    .zone Thunder Bluff >>Travel to |cFFfa9602Thunder Bluff|r
step
    .goto Thunder Bluff,78.61,28.55
    .gossip 5769 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Hamuul Runetotem|r and select the dialog option
    -- .gossipoption --x insert id
    .target Arch Druid Hamuul Runetotem
step
    -- .gossipoption --x insert id
    .goto Thunder Bluff,47.00,49.82
    .gossip 2995 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r and select the dialog option to fly to Moonglade
    .target Tal
step
    #completewith next
    .zone Moonglade >>Travel to |cFFfa9602Moonglade|r
step
    .goto Moonglade,36.178,41.798
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Remulos|r
    .collect 213558,1
    .target Keeper Remulos
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Belt
#name Maelstrom Weapon - 40 (Azeroth)
#title Maelstrom Weapon

-- Maelstrom Weapon

step
    .train 410100,1
    #completewith next
    .zone The Barrens >>Travel to |cFFfa9602The Barrens|r
step
    .train 410100,1
    .goto The Barrens,43.46,90.18,0
    .goto The Barrens,43.46,90.18,40,0
    .goto 1414,50.877,70.339
    .subzone 491,2 >> Enter Razorfen Kraul
step
    .train 410100,1
    >>Kill |cRXP_ENEMY_Charlga Razorflank|r. Loot him for the |T134944:0|t|cRXP_LOOT_Tattered Note|r. Use it to accept the quest
    >>|cRXP_WARN_It is highly recommended to form a group of 5 players for this|r
    .collect 212748,1 --Tattered Note (1x)
    .accept 79358 >>Accept Tattered Note
    .mob Charlga Razorflank
step
    .train 410100,1
    #completewith next
    .zone Thousand Needles >>Travel to |cFFfa9602Thousand Needles|r
step
    .train 410100,1
    .goto Thousand Needles,46.10,51.60
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rau Cliffrunner|r
    .turnin 79358 >>Turn in Tattered Note
    .accept 79360 >>Accept Elemental Aid
    .target Rau Cliffrunner
step
    .train 410100,1
    .goto Thousand Needles,46.21,51.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jandia|r
    >>|cRXP_BUY_Buy a|r |T132793:0|t[Crystal Vial] |cRXP_BUY_from her|r
    .collect 8925,1 --Crystal Vial (1x)
    .target Jandia
step
    .train 410100,1
    #completewith next
    .zone Hillsbrad Foothills >>Travel to |cFFfa9602Hillsbrad Foothills|r
step
    .train 410100,1
    .goto Alterac Mountains,80.499,66.923
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
    .turnin 79360 >>Turn in Elemental Aid
    .accept 79361 >>Accept Power of da Wind
    .accept 79362 >>Accept Power of da Earth
    .accept 79363 >>Accept Power of da Water
    .target Bath'rah the Windwatcher
step
    .train 410100,1
    #completewith next
    .zone Desolace >>Travel to |cFFfa9602Desolace|r
step
    .train 410100,1
    #loop
    .goto Desolace,48.0,27.2,0
    .goto Desolace,40.6,37.0,0
    .goto Desolace,50.8,42.0,0
    .goto Desolace,64.4,39.4,0
    .goto Desolace,68.4,48.4,0
    .goto Desolace,69.4,64.6,0
    .goto Desolace,58.8,65.6,0
    .waypoint Desolace,48.0,27.2,25,0
    .waypoint Desolace,40.6,37.0,25,0
    .waypoint Desolace,50.8,42.0,25,0
    .waypoint Desolace,64.4,39.4,25,0
    .waypoint Desolace,68.4,48.4,25,0
    .waypoint Desolace,69.4,64.6,25,0
    .waypoint Desolace,58.8,65.6,25,0
    >>Kill |cRXP_ENEMY_Whirlwind Elementals|r throughout Desolace. Loot them for their |T132845:0|t|cRXP_LOOT_Whirling Essence|r
    .complete 79361,1 -- Power of da Wind
    .mob Whirlwind Ripper
    .mob Whirlwind Stormwalker
    .mob Whirlwind Shredder
step
    .train 410100,1
    #completewith next
    .zone Dustwallow Marsh >>Travel to |cFFfa9602Dustwallow Marsh|r
step
    .train 410100,1
    #loop
    .goto Dustwallow Marsh,42.6,30.0,0
    .goto Dustwallow Marsh,35.2,44.6,0
    .goto Dustwallow Marsh,42.6,62.0,0
    .goto Dustwallow Marsh,50.0,54.0,0
    .waypoint Dustwallow Marsh,42.6,30.0,25,0
    .waypoint Dustwallow Marsh,35.2,44.6,25,0
    .waypoint Dustwallow Marsh,42.6,62.0,25,0
    .waypoint Dustwallow Marsh,50.0,54.0,25,0
    >>Kill |cRXP_ENEMY_Withervine Elementals|r throughout Dustwallow Marsh. Loot them for their |T132846:0|t|cRXP_LOOT_Rushing Essence|r
    .complete 79363,1 -- Power of da Water
    .mob Withervine Mire Beast
    .mob Withervine Rager
    .mob Withervine Bark Ripper
    .mob Withervine Creeper
step
    .train 410100,1
    #completewith next
    .zone Badlands >>Travel to |cFFfa9602Badlands|r
step
    .train 410100,1
    #loop
    .goto Badlands,18.0,42.8,0
    .waypoint Badlands,21.2,45.8,50,0
    .waypoint Badlands,18.0,42.8,50,0
    .waypoint Badlands,13.8,38.6,50,0
    .waypoint Badlands,21.2,45.8,50,0
    .waypoint Badlands,18.0,42.8,50,0
    >>Kill |cRXP_ENEMY_Lesser Rock Elemental|r and |cRXP_ENEMY_Rock Elementals|r. Loot them for their |T132846:0|t|cRXP_LOOT_Rumbling Essences|r
    .complete 79362,1 -- Power of da Earth
    .mob Rock Elemental
    .mob Lesser Rock Elemental
step
    .train 410100,1
    #completewith next
    .zone Hillsbrad Foothills >>Travel to |cFFfa9602Hillsbrad Foothills|r
step
    .train 410100,1
    .goto Alterac Mountains,80.499,66.923
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
    .turnin 79361 >>Turn in Power of da Wind
    .turnin 79362 >>Turn in Power of da Earth
    .turnin 79363 >>Turn in Power of da Water
    .accept 79364 >>Accept A Simple Container
    .turnin 79364 >>Turn in A Simple Container
    .accept 79365 >>Accept With Wind Beneath Your Wings
    .target Bath'rah the Windwatcher
step
    .train 410100,1
    #completewith next
    .zone Thousand Needles >>Travel to |cFFfa9602Thousand Needles|r
step
    .train 410100,1
    .goto Thousand Needles,46.10,51.60
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rau Cliffrunner|r
    .turnin 79365 -- With Wind Beneath Your Wings
    .accept 79366 --Calm Before the Storm
    .target Rau Cliffrunner
step
    .train 410100,1
    .gossip 4317 >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyse|r and select the 2nd dialog option
    .target Nyse
step
    .train 410100,1
    >>Kill the |cRXP_ENEMY_Ravaging Tempest|r. Loot it for its |cRXP_LOOT_Eye of the Tempest|r
    >>|cRXP_WARN_If you die in the process talk to the|r |cRXP_FRIENDLY_Spirit Healer|r |cRXP_WARN_to teleport you to your corpse|r
    .collect 212792,1 --Eye of the Tempest (1x)
    .mob Dreath's Head Necromancer
    .mob Skeletal Servant
    .mob Ravaging Tempest
step
    .train 410100,1
    .vehicle >> Interact with the |cRXP_FRIENDLY_Freewind Post Wyvern|r
    .timer 9, Flight RP
step
    .train 410100,1
    .goto Thousand Needles,46.10,51.60
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rau Cliffrunner|r
    .turnin 79366 --Calm Before the Storm
    .accept 79442 --Catching up
    .target Rau Cliffrunner
step
    .train 410100,1
    #completewith next
    .zone Hillsbrad Foothills >>Travel to |cFFfa9602Hillsbrad Foothills|r
step
    .train 410100,1
    .goto Alterac Mountains,80.499,66.923
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
    .turnin 79442 --Catching up
    .target Bath'rah the Windwatcher
step
    .train 410100 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of the Storm|r] to learn |T136032:0|t[Maelstrom Weapon]
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Belt
#name Power Surge - 30 (Arathi Highlands)
#title Power Surge

-- Power Surge

step
    .train 416054,1
    #completewith next
    .zone Arathi Highlands >>Travel to |cFFfa9602Arathi Highlands|r |cRXP_WARN_|cRXP_WARN_It is highly recommended to form a group of atleast 3 players.|r
step
    .train 416054,1
    .goto Arathi Highlands,31.91,41.15,50,0
    .goto Arathi Highlands,35.53,40.93,50,0
    .goto Arathi Highlands,35.51,44.26,50,0
    .goto Arathi Highlands,34.40,44.25,12,0
    .goto Arathi Highlands,31.08,43.68,12,0
    .goto Arathi Highlands,34.40,44.25,12,0
    .goto Arathi Highlands,35.51,44.26
    >>Kill |cRXP_ENEMY_Boulderfist Ogres|r and |cRXP_ENEMY_Boulderfist Brutes|r. Loot them for a |T134921:0|t|cRXP_LOOT_[Ogre Lightning Rod]|r
    .collect 213426,1 --Ogre Lightning Rod (1x)
    .mob Boulderfist Ogre
    .mob Boulderfist Enforcer
step
    .train 416054,1
    .goto Arathi Highlands,33.45,44.49
    .cast 434350 >>Click the |cRXP_PICK_Soft Soil|r to insert the |T134921:0|t|cRXP_LOOT_[Lightning Rod]|r into the ground.
step
    .train 416054,1
    >>Cast |T136048:0|t[Lightning Bolt] 10 times on the |cRXP_ENEMY_Lightning Rod|r
    >>Kill |cRXP_ENEMY_Tamkar|r or kite him as he spawns. Loot him for the |T134419:0|t[Rune of Power]
    >>|cRXP_WARN_He will die automatically after 30 seconds so you can kite him instead of killing him|r
    .collect 213093,1 --Rune of Power (1x)
    .mob Lightning Rod
    .mob Tamkar
step
    .train 416054 >>|cRXP_WARN_Use the|r |T134419:0|t[Rune of Power] |cRXP_WARN_to learn|r |T134337:0|t[Power Surge]
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Boots
#title Decoy Totem
#name Decoy Totem - 27 (Thousand Needles)

-- Decoy Totem

step
    .train 425882,1
    .zone Thousand Needles >>Travel to |cFFfa9602Thousand Needles|r
step
    .train 425882,1
    .goto Thousand Needles,46.21,51.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jandia|r
    >>|cRXP_BUY_Buy a|r |T132906:0|t[Silken Thread] |cRXP_BUY_from her|r
    .collect 4291,1 --Silken Thread (1)
    .target Jandia
step
    .train 425882,1
    #loop
    .goto Thousand Needles,55.42,51.96,0
    .waypoint Thousand Needles,55.42,51.96,40,0
    .waypoint Thousand Needles,56.68,49.88,40,0
    .waypoint Thousand Needles,55.97,45.97,40,0
    .waypoint Thousand Needles,54.29,48.10,40,0
    >>Kill |cRXP_ENEMY_Cloud Serpents|r. Loot them for their |cRXP_LOOT_Cloud Serpent Fangs|r
    .collect 213709,3 --Cloud Serpent Fang (3x)
    .mob Cloud Serpent
    .mob Venomous Cloud Serpent
    .mob Elder Cloud Serpent
step
    .train 425882,1
    #loop
    .goto Thousand Needles,27.65,49.47,0
    .goto Thousand Needles,26.55,55.77,0
    .waypoint Thousand Needles,27.65,49.47,40,0
    .waypoint Thousand Needles,27.16,51.62,15,0
    .waypoint Thousand Needles,26.29,52.79,15,0
    .waypoint Thousand Needles,27.23,54.04,15,0
    .waypoint Thousand Needles,26.55,55.77,15,0
    >>Kill cRXP_ENEMY_Screeching Harpies|r. Loot them for their |cRXP_LOOT_Strong Harpy Feathers|r
    .collect 213701,10 --Strong Harpy Feather (10x)
    .mob Screeching Harpy
    .mob Screeching Roguefeather
    .mob Screeching Windcaller
step
    .train 425882,1
    .use 213709 >>|cRXP_WARN_Use your|r |T133723:0|t[Cloud Serpent Fangs] |cRXP_WARN_to create|r |T133291:0|t[Offering to the Wind Spirit]
    .collect 213737,1 --Offering to the Wind Spirit (1x)
step
    .goto Thousand Needles,31.47,36.71,30 >> Head to Darkcloud Pinnacle
step
    #completewith next
    .goto Thousand Needles,33.08,35.33,20,0
    .goto Thousand Needles,32.78,32.24,20,0
    .goto Thousand Needles,32.03,31.36,20,0
    .goto Thousand Needles,32.37,28.64,20,0
    .goto Thousand Needles,32.60,27.51,20,0
    .goto Thousand Needles,34.87,31.76,20,0
    .goto Thousand Needles,34.15,35.77,20,0
    .goto Thousand Needles,33.32,36.24,20 >> Travel up Darkcloud Pinnacle
step
    .train 425882,1
    .goto Thousand Needles,39.44,41.98
    .aura 435218 >>|cRXP_WARN_Use the|r |T133291:0|t[Offering to the Wind Spirit] |cRXP_WARN_near the|r |cRXP_PICK_Altar of the Wind Spirit|r
    >>|cRXP_WARN_The Altar is located behind the hut on the most Eastern pinnacle|r
    .use 213737
step
    .goto Thousand Needles,40.43,43.29
    >>Jump down to show your faith to the Wind Spirit to receive the |T134419:0|t|cRXP_FRIENDLY_Rune of Decoys|r
    >>|cRXP_WARN_Make sure your|r |T133291:0|t[Offering to the Wind Spirit] |cRXP_WARN_doesn't wear off. It lasts for 30 seconds|r
    .collect 213096,1 --Rune of Decoys (1x)
step
    .train 425882 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_FRIENDLY_Rune of Decoys|r |cRXP_WARN_to learn|r |T134508:0|t[Decoy Totem]
    .use 213096
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Boots
#title Spirit of the Alpha
#name Spirit of the Alpha - 27 (Thousand Needles)

-- Spirit of the Alpha

step
    .train 410103,1
    .zone Thousand Needles >>Travel to |cFFfa9602Thousand Needles|r
step
    #completewith next
    .train 410103,1
    .goto Thousand Needles,46.17,52.95,20 >>Travel to the start of the lower bridge just south of Freewind Post
step
    .train 410103,1
    .goto Thousand Needles,46.82,53.52
    >>|cRXP_WARN_Use|r |T136095:0|t[Ghost Wolf] |cRXP_WARN_to jump down carefully toward the|r |cRXP_PICK_Weathered Cache|r
    >>Click the |cRXP_PICK_Weathered Cache|r to loot |T136095:0|t|cRXP_FRIENDLY_Echo of the Alpha|r
    .collect 206985,1
step
    .train 410103 >>|cRXP_WARN_Use the|r |T136095:0|t|cRXP_FRIENDLY_Echo of the Alpha|r |cRXP_WARN_to learn|r |T408696:0|t[Spirit of the Alpha]
    .use 206985
]])

RXPGuides.RegisterGuide([[#classic
<< Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Bracers
#title Rolling Thunder
#name Rolling Thunder - 41 (Tanaris)

-- Rolling Thunder
-- PERMOK: Needs better waypoints

step
    #completewith next
    .zone Tanaris >>Travel to Tanaris
    .train 432236,1
step
    .train 432236,1
    .goto Tanaris,43.0,41.2
    .aura 446888,1 >>|cRXP_WARN_Click on the|r |cRXP_PICK_Odd Totem|r. This will transform you into a Ghost Wolf |cRXP_WARN_and increases your damage taken by 50%|r
step
    .train 432236,1
    >>|cRXP_WARN_Run towards the other totem while avoiding mobs.|r Loot the appearing chest for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Rolling Thunder|r]
    *|cRXP_WARN_You are receiving 50% additional damage. Be careful!|r. You can also pre-clear the mobs on the path to the other totem
    .goto Tanaris,45.6,37.8
    .collect 220613,1
step
    .itemcount 220613,1
    .use 220613
    .train 432236 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Rolling Thunder|r] |cRXP_WARN_to learn|r |T136111:0|t[Rolling Thunder]
]])

RXPGuides.RegisterGuide([[#classic
<< Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Bracers
#title Static Shock
#name Static Shock - 44 (Feralas)

-- PERMOK: Needs better waypoints

step
    #completewith ChargedAir
    +|cRXP_WARN_You have to be in a group with another player who can help you in order to obtain this rune|r
step
    #completewith next
    .zone Feralas >>Travel to Feralas
    .train 432238,1
step
    .train 432238,1
    .goto Feralas,60.0,66.8
    .aura 447259 >>Click on the |cRXP_PICK_Charged Totem|r to get the |T136075:0|t[Charged Air] buff
step
    #label ChargedAir
    .train 432238,1
    >>|cRXP_WARN_Stay near the totem and kill the surrounding |cRXP_ENEMY_Gordunni Ogres|r with LIGHTNING DAMAGE (e.g. Lightning Shield) until the |cRXP_ENEMY_Whirling Tempest|r spawns.
    >>Kill the |cRXP_ENEMY_Whirling Tempest|r. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Static Shock|r]
    *|cRXP_WARN_All players of the party have to stay in range of the totem|r
    .goto Feralas,60.0,66.8
    .collect 220614,1
    .mob Whirling Tempest
    .mob Gordunni Warlock
    .mob Gordunni Shaman
    .mob Gordunni Mauler
step
    .itemcount 220614,1
    .use 220614
    .train 432238 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Static Shock|r] |cRXP_WARN_to learn|r |T237587:0|t[Static Shock]
]])

RXPGuides.RegisterGuide([[#classic
<< Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Helmet
#title Tidal Waves
#name Tidal Waves - 42 (Feralas)

-- PERMOK: Needs better waypoints

step
    #completewith next
    .zone Feralas >>Travel to Feralas
    .train 432234,1
step
    .train 432234,1
    >>Click on the |cRXP_PICK_Old Crate|r behind the tent to loot the |T134239:0|t[Old Key]
    .goto Feralas,76.6,48.0
    .collect 221497,1
step
    .train 432234,1
    >>Click on the |cRXP_PICK_Old Chest|r at the seafloor to loot the |T134419:0|t[|cRXP_FRIENDLY_Rune of Tidal Waves|r]
    *|cRXP_WARN_Be careful! This will summon FOUR |cRXP_ENEMY_Simmering Elementals|r (lvl 42, Frost immune)|r
    .goto Feralas,79.2,49.4
    .collect 220612,1
    .mob Simmering Elemental
step
    .itemcount 220612,1
    .use 220612
    .train 432234 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Tidal Waves|r] |cRXP_WARN_to learn|r |T237590:0|t[Tidal Waves]
]])

RXPGuides.RegisterGuide([[#classic
<< Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Bracers
#title Tidal Waves
#name Tidal Waves - 45 (Azeroth)

--x shiek: needs better coordinates
step
    #completewith next
    .zone Tanaris >>Travel to Tanaris
    .train 432241,1
step
    #loop
    .goto Tanaris,51.6,44.2,40,0
    .goto Tanaris,51.2,52.0,40,0
    .goto Tanaris,41.0,48.6,40,0
    .goto Tanaris,41.8,44.0,40,0
    >>Kill |cRXP_ENEMY_Blisterpaw Hyena|r, |cRXP_ENEMY_Land Rager|r and |cRXP_ENEMY_Glasshide Gazer.|r Loot them for |cRXP_LOOT_|T134327:0|tSmudged Shaman's Notes|r
    .collect 221352,1 --1/1 Smudged Shaman's Notes
    .mob Blisterpaw Hyena
    .mob Land Rager
    .mob Glasshide Gazer
    .train 432241,1
step
    .goto Tanaris,62,64
    >>Click on |cRXP_PICK_|T134327:0|tSmudged Shaman's Notes|r to start the quest.
    .accept 82072,1 >>Accept Purging Earth
    .use 221352
    .train 432241,1
step
    .isOnQuest 82072
    .goto Tanaris,62,64
    .cast 446581 >>Use |T134743:0|t[Murky Earth Sapta] near the Corrupted Earth Totem.
    .use 221349
    .train 432241,1
step
    .goto Tanaris,62.0,62.6
    >>Kill |cRXP_ENEMY_Corrupt Moderate Manifestation of Earth|r then >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Earth.|r
    .turnin 82072 >>Turn in Purging Earth
    .accept 82075 >>Accept Answering Earth's Call
    .mob Corrupt Moderate Manifestation of Earth
    .target Moderate Manifestation of Earth
    .train 432241,1
step
    #completewith next
    .zone Azshara >>Travel to Azshara
    .train 432241,1
step
    #loop
    .goto Azshara,19.4,64.0,20,0
    .goto Azshara,21.2,60.8,20,0
    .goto Azshara,21.0,60.0,20,0
    >>Kill |cRXP_ENEMY_Haldarr Satyr|r, |cRXP_ENEMY_Haldarr Trickster|r and |cRXP_ENEMY_Haldarr Felsworn.|r Loot them for |cRXP_LOOT_|T134331:0|tWaterlogged Shaman's Notes|r
    .collect 221351,1 --1/1 Waterlogged Shaman's Notes
    .mob Haldarr Satyr
    .mob Haldarr Trickster
    .mob Haldarr Felsworn
    .train 432241,1
step
    .goto Azshara,14,49
    >>Click on |cRXP_PICK_|T134331:0|tWaterlogged Shaman's Notes|r to start the quest.
    .accept 82073,1 >>Accept Cleansing Water
    .use 221352
    .train 432241,1
step
    .isOnQuest 82073
    .goto Azshara,14,49
    .cast 446581 >>Use |T134743:0|t[Murky Earth Sapta] near the Corrupted Water Totem.
    .use 221348
    .train 432241,1
step
    .goto Azshara,15.0,49.8
    >>Kill |cRXP_ENEMY_Corrupt Moderate Manifestation of Water|r then >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Water.|r
    .turnin 82073 >>Turn in Cleansing Water
    .accept 82076 >>Accept Answering Water's Call
    .mob Corrupt Moderate Manifestation of Water
    .target Moderate Manifestation of Water
    .train 432241,1
step
    #completewith next
    .zone The Hinterlands >>Travel to The Hinterlands
    .train 432241,1
step
    #loop
    .goto The Hinterlands,48.8,53.0,40,0
    .goto The Hinterlands,47.6,40.8,40,0
    .goto The Hinterlands,58.2,41.8,40,0
    >>Kill |cRXP_ENEMY_Green Sludge|r and |cRXP_ENEMY_Jade Ooze.|r Loot them for |cRXP_LOOT_|T134332:0|tTorn Shaman's Notes|r
    .collect 220379,1 --1/1 Torn Shaman's Notes
    .mob Green Sludge
    .mob Jade Ooze
    .train 432241,1
step
    .goto The Hinterlands,51,46
    >>Click on |cRXP_PICK_|T134332:0|tTorn Shaman's Notes|r to start the quest.
    .accept 81960,1 >>Accept Clarifying Air
    .use 220379
    .train 432241,1
step
    .isOnQuest 82072
    .goto The Hinterlands,51,46
    .cast 446581 >>Use |T134743:0|t[Murky Earth Sapta] near the Corrupted Air Totem.
    .use 221349
    .train 432241,1
step
    .goto The Hinterlands,51.2,47.0
    >>Kill |cRXP_ENEMY_Corrupt Moderate Manifestation of Air|r then >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Earth.|r
    .turnin 81960 >>Turn in Clarifying Air
    .accept 81968 >>Accept Answering Air's Call
    .mob Corrupt Moderate Manifestation of Air
    .target Moderate Manifestation of Air
    .train 432241,1
step
    #completewith next
    .zone Searing Gorge >>Travel to Searing Gorge
    .train 432241,1
step
    #loop
    .goto Searing Gorge,52.0,35.4,40,0
    .goto Searing Gorge,42.4,38.6,40,0
    .goto Searing Gorge,32.8,43.0,40,0
    .goto Searing Gorge,28.8,44.4,40,0
    .goto Searing Gorge,30.6,64.6,40,0
    .goto Searing Gorge,31.6,73.8,40,0
    >>Kill |cRXP_ENEMY_Magma Elemental|r and |cRXP_ENEMY_Inferno Elemental.|r Loot them for |cRXP_LOOT_|T134327:0|tCharred Shaman's Notes|r
    .collect 221350,1 --1/1 Charred Shaman's Notes
    .mob Inferno Elemental
    .mob Magma Elemental
    .train 432241,1
step
    .goto Searing Gorge,24,72
    >>Click on |cRXP_PICK_|T134329:0|tCharred Shaman's Notes|r to start the quest.
    .accept 82071,1 >>Accept Purifying Fire
    .use 221352
    .train 432241,1
step
    .isOnQuest 82072
    .goto Searing Gorge,24,72
    .cast 446581 >>Use |T134743:0|t[Murky Earth Sapta] near the Corrupted Fire Totem.
    .use 221349
    .train 432241,1
step
    .goto Searing Gorge,24.0,72.4
    >>Kill |cRXP_ENEMY_Corrupt Moderate Manifestation of Fire|r then >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Fire.|r
    .turnin 82071 >>Turn in Purifying Fire
    .accept 82074 >>Accept Answering Fire's Call
    .mob Corrupt Moderate Manifestation of Fire
    .target Moderate Manifestation of Fire
    .train 432241,1
step
    #completewith next
    .zone Feralas >>Travel to Feralas
    .train 432241,1
step
    #loop
    .goto Feralas,50.2,51.4,20,0
    .goto Feralas,44.8,46.2,20,0
    .goto Feralas,41.0,37.8,20,0
    .goto Feralas,37.4,33.0,20,0
    >>Kill |cRXP_ENEMY_Sea Spray|r and |cRXP_ENEMY_Sea Elemental.|r Loot them for |cRXP_LOOT_|T132849:0|tElemental Essence|r
    .collect 220510,3
    .train 432241,1
step
    .cast 446803 >>Use |T134118:0|t[Fragment of Earth]
    .use 221355
    .train 432241,1
step
    .goto Feralas,36.0,32.6
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Earth.|r
    .turnin 82075 >> Answering Earth's Call
    .target Moderate Manifestation of Earth
    .train 432241,1
step
    #loop
    .goto Feralas,37.4,33.0,20,0
    .goto Feralas,41.0,37.8,20,0
    .goto Feralas,44.8,46.2,20,0
    .goto Feralas,50.2,51.4,20,0
    >>Kill |cRXP_ENEMY_Sea Spray|r and |cRXP_ENEMY_Sea Elemental.|r Loot them for |cRXP_LOOT_|T132849:0|tElemental Essence|r
    .collect 220510,3
    .train 432241,1
step
    .cast 446802 >>Use |T134130:0|t[Fragment of Fire]
    .use 221353
    .train 432241,1
step
    .goto Feralas,36.0,32.6
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Earth.|r
    .turnin 82075 >> Answering Earth's Call
    .target Moderate Manifestation of Earth
    .train 432241,1
step
    #loop
    .goto Feralas,50.2,51.4,20,0
    .goto Feralas,44.8,46.2,20,0
    .goto Feralas,41.0,37.8,20,0
    .goto Feralas,37.4,33.0,20,0
    >>Kill |cRXP_ENEMY_Sea Spray|r and |cRXP_ENEMY_Sea Elemental.|r Loot them for |cRXP_LOOT_|T132849:0|tElemental Essence|r
    .collect 220510,3
    .train 432241,1
step
    .cast 445748 >>Use |T134133:0|t[Fragment of Air]
    .use 220375
    .train 432241,1
step
    .goto Feralas,36.0,32.6
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Earth.|r
    .turnin 82075 >> Answering Earth's Call
    .target Moderate Manifestation of Earth
    .train 432241,1
step
    #loop
    .goto Feralas,37.4,33.0,20,0
    .goto Feralas,41.0,37.8,20,0
    .goto Feralas,44.8,46.2,20,0
    .goto Feralas,50.2,51.4,20,0
    >>Kill |cRXP_ENEMY_Sea Spray|r and |cRXP_ENEMY_Sea Elemental.|r Loot them for |cRXP_LOOT_|T132849:0|tElemental Essence|r
    .collect 220510,3
    .train 432241,1
step
    .cast 446804 >>Use |T134089:0|t[Fragment of Water]
    .use 221354
    .train 432241,1
step
    .goto Feralas,36.0,32.6
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moderate Manifestation of Earth.|r
    .turnin 82075 >> Answering Earth's Call
    .target Moderate Manifestation of Earth
    .train 432241,1
step
    >>Kill |cRXP_ENEMY_Twilight Dark Shaman.|r Loot him for |cRXP_LOOT_|cRXP_FRIENDLY_|T134419:0|tRune of Overcharged|r|r
    .collect 220616,1 --1/1 Rune of Overcharged
    .train 432241,1
step
    .train 432241 >> |cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Overcharged|r] |cRXP_WARN_to train|r |T132213:0|t[Overcharged]
]])

RXPGuides.RegisterGuide([[#classic
<< Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Cloak
#title Storm, Earth, and Fire
#name Storm, Earth, and Fire - 52 (Felwood)

step
    .train 440634,1
    #completewith next
    .zone Felwood >>Travel to Felwood
step
    .goto Felwood,62.4,9.0
    .train 440634,1
    >>Kill |cRXP_ENEMY_Deadwood Shamans|r, |cRXP_ENEMY_Deadwood Avengers|r and |cRXP_ENEMY_Deadwood Den Watchers|r. Loot them for the |T134918:0|t[|cRXP_LOOT_Voltaic Icon|r]
    .goto Feralas,76.6,48.0
    .collect 225838,1
    .mob Deadwood Shaman
    .mob Deadwood Avenger
    .mob Deadwood Den Watcher
step
    .train 440634,1
    .equip 18,225838 >> |cRXP_WARN_Equip the|r |T134918:0|t[|cRXP_LOOT_Voltaic Icon|r]
    .use 225838
step
    .train 440634,1
    .aura 408828 >>|cRXP_WARN_You must now kill 3 enemies with a single cast of|r |T136015:0|t[Chain Lightning]
    >>|cRXP_WARN_Pull 3 mobs and lower their health to roughly 5% each then cast|r |T136015:0|t[Chain Lightning]
step
    .itemcount 225838,1
    .use 225838
    .train 440634 >>|cRXP_WARN_Use the|r |T134918:0|t[|cRXP_LOOT_Voltaic Icon|r] |cRXP_WARN_to learn|r |T237588:0|t[Storm, Earth, and Fire]
]])

RXPGuides.RegisterGuide([[#classic
<< Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Cloak
#title Coherence
#name Coherence - 55 (Burning Steppes)

step
    .train 416062,1
    #completewith next
    .zone Burning Steppes >>Travel to Burning Steppes
step
    .train 416062,1
    #loop
    .goto Burning Steppes,62.4,9.0,60,0
    .goto Burning Steppes,69.4,31.8,60,0
    .goto Burning Steppes,61.4,31.8,60,0
    .goto Burning Steppes,51.2,35.6,60,0
    .goto Burning Steppes,55.6,49.2,60,0
    .goto Burning Steppes,54.8,62.2,60,0
    .goto Burning Steppes,35.6,61.6,60,0
    .goto Burning Steppes,41.6,43.6,60,0
    >>Kill |cRXP_ENEMY_Greater Obsidian Elementals|r. Loot them for the |cRXP_LOOT_Molten Obsidian Core|r
    .collect 225676,1
    .mob Greater Obsidian Elemental
step
    .train 416062,1
    .goto Redridge Mountains,44.6,50.0
    >>|cRXP_WARN_You now have 10 minutes to jump into water anywhere in the world|r
    >>|cRXP_WARN_Travel to Redridge Mountains and jump into the lake|r
    >>|cRXP_WARN_If you Hearthstone is near water you may also do that instead|r
    >>|cRXP_WARN_Jumping into water will transform the |cRXP_LOOT_Molten Obsidian Core|r into a|r |T237477:0|t[|cRXP_LOOT_Sooty Obsidian Core|r]
    .collect 225675,1
step
    .train 416062,1
    .use 225675 >> |cRXP_WARN_Open the|r |T237477:0|t[|cRXP_LOOT_Sooty Obsidian Core|r] |cRXP_WARN_to receive the|r |T134419:0|t[|cRXP_LOOT_Rune of Composure|r]
    .collect 225740,1
step
    .itemcount 225740,1
    .use 225740
    .train 416062 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_LOOT_Rune of Composure|r] |cRXP_WARN_to learn|r |T237586:0|t[Coherence]
]])

RXPGuides.RegisterGuide([[#classic
<< Shaman SoD
#group RestedXP Rune & Books Guide
#subgroup Cloak
#title Feral Spirit
#name Feral Spirit - 60 (Winterspring)

step
    .train 440630,1
    #completewith next
    .zone Winterspring >>Travel to Winterspring
    >>|cRXP_WARN_Note you must kill a level 60 elite. Consider bringing a friend|r
step
    #completewith next
    .goto Winterspring,67.93,41.44,50 >> Enter the Yeti cave
step
    .goto Winterspring,69.87,37.92
    >>|cRXP_WARN_Travel to the back of the Yeti cave and talk to the chained elemental|r |cRXP_FRIENDLY_Frijidar|r
    >>|cRXP_WARN_He will become hostile after a few seconds|r
    >>Kill |cRXP_ENEMY_Frijidar|r. Loot it for the |T134419:0|t[|cRXP_LOOT_Rune of the Bound Spirit|r]
    .collect 225914,1
    .mob Frijidar
    .skipgossip
step
    .itemcount 225914,1
    .use 225914
    .train 440630 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_LOOT_Rune of the Bound Spirit|r] |cRXP_WARN_to learn|r |T237577:0|t[Feral Spirit]
]])

RXPGuides.RegisterGuide([[#version 10
#classic
#group RestedXP SoD Preparation
#name QuestDB
#internal
step
.setquestdb {[2783]={["appliesTo"]="Alliance",["xp"]=5100,},[2784]={["appliesTo"]="Horde",["xp"]=2870,},[6610]={["itemId"]=12207,7974,8932,["itemAmount"]=12,10,20,["xp"]=3900,},[624]={["itemId"]=4056,["itemAmount"]=1,["xp"]=3600,},[4507]={["previousQuest"]=4496,["questLog"]=true,["xp"]=14140,},[4182]={["questLog"]=true,["xp"]=22470,["appliesTo"]="Alliance"},[3181]={["xp"]=19470,["appliesTo"]="Alliance"},[2937]={["previousQuest"]=2936,["questLog"]=true,["xp"]=18650,["appliesTo"]="Horde"},[211]={["previousQuest"]=5098,["questLog"]=true,["xp"]=10050,["appliesTo"]="Alliance"},[105]={["previousQuest"]=5098,["questLog"]=true,["xp"]=10050,["appliesTo"]="Horde"},[3463]={["previousQuest"]=3462,["questLog"]=true,["xp"]=9820,},[3566]={["previousQuest"]=3372,["questLog"]=true,["xp"]=9350,["appliesTo"]="Alliance"},[5242]={["previousQuest"]=5165,["questLog"]=true,["xp"]=9300,},[2994]={["previousQuest"]=2993,["questLog"]=true,["xp"]=9100,["appliesTo"]="Alliance"},[630]={["previousQuest"]=594,["questLog"]=true,["xp"]=9100,},[3907]={["previousQuest"]=3906,["questLog"]=true,["xp"]=9050,["appliesTo"]="Horde"},[2770]={["previousQuest"]=2769,["questLog"]=true,["xp"]=8850,},[8554]={["previousQuest"]=8553,["questLog"]=true,["xp"]=8850,},[5156]={["questLog"]=true,["xp"]=8550,},[2768]={["questLog"]=true,["xp"]=8050,},[7065]={["questLog"]=true,["xp"]=7850,["appliesTo"]="Alliance"},[7064]={["questLog"]=true,["xp"]=7850,["appliesTo"]="Horde"},[7861]={["questLog"]=true,["xp"]=7850,["appliesTo"]="Horde"},[7066]={["questLog"]=true,["xp"]=7850,},[7862]={["questLog"]=true,["xp"]=7850,["appliesTo"]="Horde"},[5385]={["previousQuest"]=5204,["questLog"]=true,["xp"]=7750,},[3062]={["questLog"]=true,["xp"]=7650,["appliesTo"]="Horde"},[793]={["previousQuest"]=782,["questLog"]=true,["xp"]=7650,["appliesTo"]="Horde"},[717]={["previousQuest"]=732,["questLog"]=true,["xp"]=7650,["appliesTo"]="Alliance"},[7850]={["questLog"]=true,["xp"]=7650,["appliesTo"]="Horde"},[7849]={["questLog"]=true,["xp"]=7650,["appliesTo"]="Horde"},[3461]={["previousQuest"]=3449,["questLog"]=true,["xp"]=7600,["appliesTo"]="Alliance"},[4263]={["previousQuest"]=4262,["questLog"]=true,["xp"]=7550,["appliesTo"]="Alliance"},[4286]={["questLog"]=true,["xp"]=7550,["appliesTo"]="Alliance"},[4123]={["questLog"]=true,["xp"]=7400,},[3507]={["previousQuest"]=3506,["xp"]=7300,["appliesTo"]="Horde"},[4292]={["previousQuest"]=4291,["questLog"]=true,["xp"]=7300,},[836]={["previousQuest"]=485,["questLog"]=true,["xp"]=7200,},[7201]={["questLog"]=true,["xp"]=7200,["appliesTo"]="Horde"},[4642]={["previousQuest"]=4294,["questLog"]=true,["xp"]=7050,["appliesTo"]="Horde"},[4245]={["previousQuest"]=4244,["questLog"]=true,["xp"]=6550,},[8464]={["questLog"]=true,["xp"]=6200,},[5153]={["previousQuest"]=5152,["questLog"]=true,["xp"]=6100,},[4283]={["questLog"]=true,["xp"]=5800,["appliesTo"]="Alliance"},[4101]={["questLog"]=true,["xp"]=5650,["appliesTo"]="Alliance"},[4102]={["questLog"]=true,["xp"]=5650,["appliesTo"]="Horde"},[4491]={["previousQuest"]=4492,["questLog"]=true,["xp"]=5650,},[8461]={["questLog"]=true,["xp"]=5650,},[4502]={["questLog"]=true,["xp"]=5650,},[4501]={["questLog"]=true,["xp"]=5650,},[4301]={["previousQuest"]=4289,["questLog"]=true,["xp"]=5650,},[5901]={["questLog"]=true,["xp"]=5650,["appliesTo"]="Horde"},[6389]={["questLog"]=true,["xp"]=5650,["appliesTo"]="Alliance"},[648]={["previousQuest"]=351,["questLog"]=true,["xp"]=5450,},[8114]={["repfaction"]=509,["reputation"]="friendly",["questLog"]=true,["xp"]=9950,["appliesTo"]="Alliance"},[8121]={["repfaction"]=510,["reputation"]="friendly",["questLog"]=true,["xp"]=9950,["appliesTo"]="Horde"},[7827]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Horde"},[7834]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Horde"},[7814]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Horde"},[7821]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Horde"},[7793]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Alliance"},[7803]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Alliance"},[7808]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Alliance"},[7798]={["itemId"]=4306,["itemAmount"]=60,["xp"]=660,["appliesTo"]="Alliance"},[7831]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Horde"},[7835]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Horde"},[7817]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Horde"},[7822]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Horde"},[7794]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Alliance"},[7804]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Alliance"},[7809]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Alliance"},[7799]={["itemId"]=4338,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Alliance"},[7824]={["itemId"]=14047,["itemAmount"]=60,["xp"]=6600,["appliesTo"]="Horde"},[7836]={["itemId"]=14047,["itemAmount"]=60,["xp"]=6600,["appliesTo"]="Horde"},[7818]={["itemId"]=14047,["itemAmount"]=60,["xp"]=3300,["appliesTo"]="Horde"},[7823]={["itemId"]=14047,["itemAmount"]=60,["xp"]=6600,["appliesTo"]="Horde"},[7795]={["itemId"]=14047,["itemAmount"]=60,["xp"]=6600,["appliesTo"]="Alliance"},[7805]={["itemId"]=14047,["itemAmount"]=60,["xp"]=6600,["appliesTo"]="Alliance"},[7811]={["itemId"]=14047,["itemAmount"]=60,["xp"]=6600,["appliesTo"]="Alliance"},[7800]={["itemId"]=14047,["itemAmount"]=60,["xp"]=6600,["appliesTo"]="Alliance"},[6031]={["itemId"]=14047,["itemAmount"]=30,["xp"]=5650,["factionID"]=576,["reputation"]="friendly",},[6032]={["appliesTo"]="tailoring",["itemId"]=14342,["itemAmount"]=2,["xp"]=5650,["factionID"]=576,["reputation"]="friendly",},[5237]={["previousQuest"]=5226,["xp"]=9300,["appliesTo"]="Alliance"},[5238]={["previousQuest"]=5236,["xp"]=9300,["appliesTo"]="Horde"},[8470]={["itemId"]=20741,["itemAmount"]=1,["xp"]=5650,},[3721]={["previousQuest"]=836,["xp"]=7100,},[8471]={["itemId"]=20742,["itemAmount"]=1,["xp"]=5800,},[2876]={["itemId"]=9250,["itemAmount"]=1,["xp"]=4850,},[3884]={["itemId"]=11116,["itemAmount"]=1,["xp"]=3550,},[4266]={["previousQuest"]=4265,["xp"]=6050,["appliesTo"]="Alliance"},[3842]={["previousQuest"]=3841,["itemId"]=3825,["itemAmount"]=2,["xp"]=6300,["appliesTo"]="Alliance"},[2976]={["previousQuest"]=2974,["xp"]=4850,["appliesTo"]="Horde"},[3129]={["previousQuest"]=3127,["xp"]=4700,["appliesTo"]="Horde"},[7732]={["previousQuest"]=7731,["xp"]=4400,["appliesTo"]="Horde"},[2871]={["previousQuest"]=2870,["xp"]=3900,["appliesTo"]="Alliance"},[4281]={["itemId"]=11463,["itemAmount"]=1,["xp"]=2250,["appliesTo"]="Alliance"},[4442]={["previousQuest"]=4441,["xp"]=5450,["appliesTo"]="Alliance"},[3542]={["previousQuest"]=3517,["xp"]=6650,["appliesTo"]="Horde"},[3518]={["previousQuest"]=3517,["xp"]=6650,["appliesTo"]="Horde"},[3541]={["previousQuest"]=3517,["xp"]=6650,["appliesTo"]="Horde"},[3561]={["previousQuest"]=3517,["xp"]=6650,["appliesTo"]="Horde"},[3785]={["previousQuest"]=3790,["itemId"]=11040,["itemAmount"]=10,["xp"]=5170,["appliesTo"]="Alliance"},[3782]={["previousQuest"]=3784,["itemId"]=11040,["itemAmount"]=10,["xp"]=5170,["appliesTo"]="Horde"},[3764]={["previousQuest"]=3790,["itemId"]=11018,["itemAmount"]=20,["xp"]=4700,["appliesTo"]="Alliance"},[3761]={["previousQuest"]=3784,["itemId"]=11018,["itemAmount"]=20,["xp"]=4700,["appliesTo"]="Horde"},[2874]={["previousQuest"]=2873,["xp"]=3900,},[3501]={["itemId"]=10593,["itemAmount"]=1,["xp"]=5650,},[2583]={["itemId"]=8392,8393,8394,["itemAmount"]=3,2,1,["xp"]=4700,},[2581]={["itemId"]=8391,8392,8393,["itemAmount"]=3,2,1,["xp"]=4700,},[2585]={["itemId"]=8393,8396,8392,["itemAmount"]=3,2,1,["xp"]=4700,},[2603]={["itemId"]=8396,8391,["itemAmount"]=10,3; ["xp"]=4700,},[2601]={["itemId"]=8394,8396,["itemAmount"]=10,2; ["xp"]=4700,},[5048]={["previousQuest"]=5022,["xp"]=5100,["appliesTo"]="Alliance"},[5049]={["previousQuest"]=5023,["xp"]=5100,["appliesTo"]="Horde"},[864]={["previousQuest"]=654,["xp"]=5050,["appliesTo"]="Horde"},[4022]={["previousQuest"]=3462,["xp"]=5450,},[4284]={["itemId"]=11186,11188,11185,11184,["itemAmount"]=7,7,7,7,["xp"]=5250,},}
]])

RXPGuides.RegisterGuide([[#version 1
#classic
#include QuestDB
#group RestedXP SoD Preparation
#name RestedXP Total XP prepared
#hidewindow
step
+ So far the experienced you have prepared is:
.showtotalxp
>> Out of the total possible for your character:
.showtotalxp 1
>> For questlog quests, put the items into your bag so all the quests are marked as "(Complete)".
>>-
.show25quests >> CLICK HERE to see the list of 25 best quests for your character
]])

RXPGuides.RegisterGuide([[#version 1
#classic
#group RestedXP SoD Preparation
#name !How to Use This Guide
#hidewindow
step
#sticky
+Welcome to the RXP 50-60 Prep guide for Season of Discovery!
>>We recommend that you start this guide prepared and stocked up with food and potions, as you will be delving into red level zones and killing difficult enemies.
>>If at any point you come to a stop because you cannot complete a difficult quest, we encourage you look for a group.
>>Make sure your equipment is decent and you at least have best possible runes for the content.
step << skip
+Once you finish the guide, it is highly recommended you copy your character over to the PTR and give the Turn in Guide a test whirl on the PTR so you know the route better!
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Horde
#group RestedXP SoD Preparation
#subgroup Preparation guide
#title 1 - 20 Questlog prep - Eastern Kingdoms
#name 1 - 20 Questlog prep - Eastern Kingdoms (H)
#next 2 - 20 Questlog prep - Kalimdor
step
+Welcome to the RXP preparation guide for Season of Discovery! Check this step when you are ready to start.
step << Mage
.cast 3563 >>Cast |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << !Mage
.goto Tirisfal Glades,61.80,65.06,20,0
.zone Undercity >> Make your way to Undercity
.zoneskip Undercity
step
.goto Undercity,68.2,47.6,30,0
.goto Undercity,70.8,51.6,30,0
.goto Undercity,73.8,43.4,30,0
.goto Undercity,66.0,33.6,30,0
.goto Undercity,59.0,42.6,30,0
.goto Undercity,59.0,42.6,30,0
.goto Undercity,65.8,55.0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harbinger Balthazad|r
>>|cRXP_WARN_He patrols around the bank area and closest inner cicle where auctioneers are posted|r
.accept 5094 >>Accept A Call to Arms: The Plaguelands!
.target Harbinger Balthazad
step
.requires quest,4642
.goto Undercity,47.46,73.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fuely|r
>>|cRXP_WARN_If at any point during the route you start strugling for quest log space, complete and turn in these two quests|r
.accept 4293 >>Accept A Sample of Slime...
.accept 4294 >>Accept ... and a Match of Ooze
.target Chemist Fuely
step
.goto Undercity,55.22,90.88
.goto Undercity,67.90,15.28,30 >>|cRXP_WARN_Perform a Logout Skip by positioning your character on the highest part of the lowest staircase until it looks like they're floating, then logging out and back in|r
.link https://www.youtube.com/watch?v=jj85AXyF1XE >> |cRXP_WARN_CLICK HERE for an example|r
>>|cRXP_WARN_If you can't do this, just run out of Undercity normally|r
step
#completewith next
.subzone 152 >> Travel toward the Bulwark
step
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTravel to the Bulwark, then talk to |cRXP_FRIENDLY_Derrington|r
.turnin 5094 >>Turn in A Call to Arms: The Plaguelands!
.accept 5096 >>Accept Scarlet Diversions
.target High Executor Derrington
step
.goto Western Plaguelands,26.55,56.18
>>Click the |cRXP_PICK_Box of Incendiaries|r by the fire
.collect 12814,1 
step 
.goto Western Plaguelands,40.5,51.8
.use 12807 >>Click the |cRXP_PICK_Command Tent|r, then use your |T132484:0|t[Scourge Banner]
>>|cRXP_WARN_These mobs are relatively difficult and can chain-pull each other, so be careful|r
.complete 5096,1 
step
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5096 >>Turn in Scarlet Diversions
.accept 5228 >>Accept The Scourge Cauldrons
.target High Executor Derrington
step
.requires quest,105
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5096 >>Turn in Scarlet Diversions
.accept 5098 >>Accept All Along the Watchtowers
.target High Executor Derrington
step
.requires quest,5901
.goto Tirisfal Glades,83.30,72.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mickey|r
.accept 5901 >>Accept A Plague Upon Thee
.target Mickey Levine
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5228 >>Turn in The Scourge Cauldrons
.accept 5229 >>Accept Target: Felstone Field
.target Shadow Priestess Vandis
step
.goto Western Plaguelands,37.12,57.18
>>Kill |cRXP_ENEMY_Cauldron Lord Bilemaw|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
.complete 5229,1 
.unitscan Cauldron Lord Bilemaw
step
.goto Western Plaguelands,37.2,56.8
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
.turnin 5229 >>Turn in Target: Felstone Field
.accept 5230 >>Accept Return to the Bulwark
step
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice|r on the second floor of the house
.accept 5021 >>Accept Better Late Than Never
.target Janice Felstone
step
.goto Western Plaguelands,38.8,55.3
>>Click |cRXP_PICK_Janice's Parcel|r in the barn
>>|cRXP_WARN_You can click it through the hallway wall if you want to skip the mobs inside|r
.turnin 5021 >>Turn in Better Late Than Never
.accept 5023 >>Accept Better Late Than Never
step
#completewith next
.subzone 152 >> Return to The Bulwark
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5230 >>Turn in Return to the Bulwark
.accept 5231 >>Accept Target: Dalson's Tears
.target Shadow Priestess Vandis
step
.goto Western Plaguelands,46.04,52.33
>>Kill |cRXP_ENEMY_Cauldron Lord Malvinious|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
.complete 5231,1 
.unitscan Cauldron Lord Malvinious
step
.goto Western Plaguelands,46.2,52.0
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
.turnin 5231 >>Turn in Target: Dalson's Tears
.accept 5232 >>Accept Return to the Bulwark
step
.requires quest,105
.goto Western Plaguelands,44.24,63.06
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway
>>|cRXP_WARN_Do not engage the elite inside|r
.complete 5098,3 
step
.requires quest,105
.goto Western Plaguelands,42.28,66.05
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway
>>|cRXP_WARN_Do not engage the elite inside|r
.complete 5098,2 
step
.requires quest,105
.goto Western Plaguelands,40.15,71.50
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway
>>|cRXP_WARN_Do not engage the elite inside|r
.complete 5098,1 
step
.requires quest,105
.goto Western Plaguelands,46.73,71.14
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway
>>|cRXP_WARN_Do not engage the elite inside|r
.complete 5098,4 
step
.requires quest,5153
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.accept 5142 >> Accept Little Pamela
.target Marlene Redpath
step
#completewith next
.subzone 152 >> Return to The Bulwark
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5232 >>Turn in Return to the Bulwark
.accept 5233 >>Accept Target: Writhing Haunt
.target Shadow Priestess Vandis
step
.requires quest,105
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5098 >>Turn in All Along the Watchtowers
.accept 105 >> Accept Alas, Andorhal
.target High Executor Derrington
step
.requires quest,105
.isQuestTurnedIn 5098
.destroy 12815 >> Delete the |T135432:0|t[Beacon Torch]
step
.requires quest,105
.goto Western Plaguelands,45,69
>>Kill |cRXP_ENEMY_Araj the Summoner|r. Loot his Phylactery for |cRXP_LOOT_Araj's Phylactery Shard|r
>>|cRXP_WARN_This quest is quite difficult so you should seek help if you can't solo it|r
.complete 105,1 
.mob Araj the Summoner
step
.goto Western Plaguelands,53.07,65.97
>>Kill |cRXP_ENEMY_Cauldron Lord Razarch|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_have a 5-second long, instant cast AoE stun|r
.complete 5233,1 
.unitscan Cauldron Lord Razarch
step
.goto Western Plaguelands,53.0,65.7
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_have a 5-second long, instant cast AoE stun|r
.turnin 5233 >>Turn in Target: Writhing Haunt
.accept 5234 >>Accept Return to the Bulwark
step
#completewith next
.goto Eastern Plaguelands,36.6,90.8,50 >> Travel toward |cRXP_FRIENDLY_Pamela Redpath|r in the Eastern Plaguelands
step
.requires quest,5153
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.turnin 5142 >>Turn in Little Pamela
.accept 5149 >>Accept Pamela's Doll
.target Pamela Redpath
step
.requires quest,5153
.goto Eastern Plaguelands,38.10,92.24
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12886,1,5149,1 
.unitscan Ghost of the Past
step
.requires quest,5153
.goto Eastern Plaguelands,39.64,92.51
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12887,1,5149,1 
.unitscan Ghost of the Past
step
.requires quest,5153
.goto Eastern Plaguelands,39.67,90.24
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12888,1,5149,1 
.unitscan Ghost of the Past
step
.requires quest,5153
.goto Eastern Plaguelands,36.47,90.80
.use 12886 >>Click |T134164:0|t[Pamela's Doll's Head] to combine the three pieces
.complete 5149,1 
step
.requires quest,5153
#label Pamela
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.turnin 5149 >>Turn in Pamela's Doll
.accept 5152 >>Accept Auntie Marlene
.target Pamela Redpath
step
.requires quest,5901
.goto Eastern Plaguelands,41.2,25.2,70,0
.goto Eastern Plaguelands,42.1,38.2,70,0
.goto Eastern Plaguelands,32.0,35.8,70,0
.goto Eastern Plaguelands,33.8,25.8,70,0
.goto Eastern Plaguelands,29.9,23.1,70,0
.goto Eastern Plaguelands,26.5,37.5,70,0
.goto Eastern Plaguelands,20.4,20.8,70,0
.goto Eastern Plaguelands,31.4,29.6
>>Open the |cRXP_PICK_Large Termite Mounds|r throughout Plaguewood. Loot them for the |cRXP_LOOT_Plagueland Termites|r
.complete 5901,1 
step
.requires quest,5153
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.turnin 5152 >> Turn in Auntie Marlene
.accept 5153 >> Accept A Strange Historian
.target Marlene Redpath
step
.requires quest,5153
.goto Western Plaguelands,49.696,76.754
>>Click |cRXP_PICK_Joseph Redpath's Monument|r. Loot it for |cRXP_LOOT_Joseph's Wedding Ring|r
.complete 5153,1 
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5234 >>Turn in Return to the Bulwark
.accept 5235 >>Accept Target: Gahrron's Withering
.target Shadow Priestess Vandis
step
.goto Western Plaguelands,62.80,58.76
>>Kill |cRXP_ENEMY_Cauldron Lord Soulwraith|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
>>|cRXP_WARN_This mob has a 10-second silencing disease|r << !Priest
>>|cRXP_WARN_This mob has a 10-second silencing disease; pre-cast Abolish Disease and keep it up|r << Priest
.complete 5235,1 
.unitscan Cauldron Lord Soulwraith
step
.goto Western Plaguelands,62.5,58.6
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
.turnin 5235 >>Turn in Target: Gahrron's Withering
.accept 5236 >>Accept Return to the Bulwark
step
#completewith next
.subzone 152 >> Travel back to the Bulwark
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5236 >>Turn in Return to the Bulwark
.target Shadow Priestess Vandis
step << Mage
.cast 3563 >>Cast |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step
.goto Tirisfal Glades,61.80,65.06,20,0
.zone Undercity >> Enter Undercity
.zoneskip Undercity
step
#completewith next
.goto Undercity,66.09,20.06,35,0
.goto Undercity,64.37,23.94,35,0
.goto Undercity,65.93,26.71,10,0
.goto Undercity,65.89,34.03,10,0
.goto Undercity,64.22,39.77,10,0
.goto Undercity,65.53,43.62,15 >> Take the lift down to the Undercity
step
.goto Undercity,50.15,67.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zinge|r
.accept 232 >> Accept Errand for Apothecary Zinge
.target Apothecary Zinge
step
.goto Undercity,58.61,54.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alessandro|r
.turnin 232 >> Turn in Errand for Apothecary Zinge
.accept 238 >> Accept Errand for Apothecary Zinge
.target Alessandro Luca
step
.goto Undercity,50.15,67.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zinge|r
.turnin 238 >> Turn in Errand for Apothecary Zinge
.accept 243 >> Accept Into the Field
.target Apothecary Zinge
step
.goto Undercity,69.79,43.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bauhaus|r
.turnin 5023 >>Turn in Better Late Than Never
.target Royal Overseer Bauhaus
step
.requires quest,8554
.goto Undercity,71.3,46.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r or any of the auctioneers
.collect 4457,10 
.target Auctioneer Stockton
step
.requires quest,4245
.goto Undercity,71.3,46.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r or any of the auctioneers
.collect 10561,1 
.target Auctioneer Stockton
step
.goto Undercity,63.6,48.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael Garrett|r
.fly Revantusk Village >> Fly to Revantusk Village in The Hinterlands
.target Michael Garrett
step
.requires quest,2937
#label VenomBottle
.goto The Hinterlands,23.00,57.73
>>Click one of the green |cRXP_PICK_Venom Bottles|r around the camp
.accept 2933 >> Accept Venom Bottles
step
.requires quest,2937
#completewith next
.goto Hillsbrad Foothills,62.31,20.29,125 >> Travel back to Tarren Mill
step
.requires quest,2937
.goto Hillsbrad Foothills,61.50,19.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydon|r
.turnin 2933 >> Turn in Venom Bottles
.target Apothecary Lydon
step
.requires quest,2937
.goto Hillsbrad Foothills,61.53,19.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydon|r
.accept 2934 >>Accept Undamaged Venom Sac
.target Apothecary Lydon
step
.requires quest,2937
.goto Hillsbrad Foothills,86.60,29.49,30,0
.goto The Hinterlands,9.7,55.8
.zone The Hinterlands >>Take the mountain path northeast of Durnholde Keep into The Hinterlands
step
.requires quest,2937
.goto The Hinterlands,35.9,63.9,40,0
.subzone 353 >>Travel southeast to Shadra'Alor
step
.requires quest,2937
>>Kill |cRXP_ENEMY_Witherbark Broodguards|r. Loot them for an |cRXP_LOOT_Undamaged Venom Sac|r
>>|cRXP_WARN_The|r |cRXP_LOOT_Undamaged Venom Sac|r |cRXP_WARN_has a 30 minute duration, so turn it in ASAP|r
.complete 2934,1 
.mob Witherbark Broodguard
step
.requires quest,2937
#completewith next
.goto Hillsbrad Foothills,60.8,21.2,60,0
.subzone 272 >>Travel out of the Hinterlands, back to Tarren Mill
step
.requires quest,2937
.goto Hillsbrad Foothills,61.53,19.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydon|r
>>|cRXP_WARN_The|r |cRXP_LOOT_Undamaged Venom Sac|r |cRXP_WARN_has a 30 minute duration, so turn it in ASAP|r
.turnin 2934 >>Turn in Undamaged Venom Sac
.accept 2935 >>Accept Consult Master Gadrin
.target Apothecary Lydon
step
.requires quest,2937
.goto Hillsbrad Foothills,60.2,18.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zarise|r
.fly Revantusk Village >> Fly to Revantusk Village in The Hinterlands
.target Zarise
step
.requires quest,7861
.goto The Hinterlands,79.08,78.99
>>Click the |cRXP_PICK_Call to Arms!|r wanted poster by the hut
>>|cRXP_WARN_These are 5-man group quests|r
.accept 7861 >>Accept Wanted: Vile Priestess Hexx and Her Minions
step
.requires quest,7862
.goto The Hinterlands,79.08,78.99
>>Click the |cRXP_PICK_Call to Arms!|r wanted poster by the hut
>>|cRXP_WARN_These are 5-man group quests|r
.accept 7862 >>Accept Job Opening: Guard Captain of Revantusk Village
step
.requires quest,7850
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torntusk|r
>>|cRXP_WARN_These are 5-man group quests|r
.accept 7850 >>Accept Dark Vessels
.goto The Hinterlands,78.20,81.17
.target Primal Torntusk
step
.requires quest,7849
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
>>|cRXP_WARN_These are 5-man group quests|r
.accept 7849 >>Accept Separation Anxiety
.goto The Hinterlands,79.16,79.53
.target Huntsman Markhor
step
>>Loot the |cRXP_LOOT_Vessels of Tainted Blood|r on the ground
>>|cRXP_WARN_Don't worry about focusing on this; you can finish it in later steps|r
.complete 7850,1 
.isOnQuest 7850
step
>>Kill |cRXP_ENEMY_Vilebranch Trolls|r
>>|cRXP_WARN_Don't worry about focusing on this; you can finish it in later steps|r
.complete 7862,4 
.complete 7862,1 
.complete 7862,3 
.complete 7862,2 
.mob Vilebranch Soul Eater
.mob Vilebranch Berserker
.mob Vilebranch Blood Drinker
.mob Vilebranch Shadow Hunter
.isOnQuest 7862
step
.goto The Hinterlands,62.1,75.3
>>Loot the |cRXP_PICK_Pile of Bones|r at the center of the pit for |cRXP_LOOT_Huntsman Malkhor's Bones|r
.complete 7849,2 
.isOnQuest 7849
step
.goto The Hinterlands,58.6,64.9
>>Loot the |cRXP_PICK_Pile of Skulls|r for |cRXP_LOOT_Huntsman Malkhor's Skull|r
.complete 7849,1 
.isOnQuest 7849
step
.goto The Hinterlands,59.3,78.2
>>Kill |cRXP_ENEMY_Vile Priestess Hex|r
>>|cRXP_WARN_Be extremely cautious of her Hex ability, which she can potentially spam|r
.complete 7861,1 
.unitscan Vile Priestess Hexx
.isOnQuest 7861
step
.goto The Hinterlands,59.6,77.9
>>Kill |cRXP_ENEMY_Vilebranch Aman'zasi Guards|r
.complete 7861,2 
.mob Vilebranch Aman'zasi Guard
.isOnQuest 7861
step
>>Kill enemies in The Hinterlands. Loot them for |cRXP_LOOT_OOX-09/HL Distress Beacon|r
.collect 8704,1 
step
.goto The Hinterlands,49.30,37.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r
>>|cRXP_WARN_Use |T132836:0|t[OOX-09/HL Distress Beacon]|r
.accept 485 >>Accept Find OOX-09/HL!
.turnin 485 >>Turn in Find OOX-09/HL!
.target Homing Robot OOX-09/HL
.itemcount 8704,1 
.use 8704
step
.goto The Hinterlands,49.35,37.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to start the escort
.accept 836 >>Accept Rescue OOX-09/HL!
.target Homing Robot OOX-09/HL
.isQuestTurnedIn 485
step
.goto The Hinterlands,79.47,61.21
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to the coast
>>|cRXP_WARN_This escort can be hard to solo|r
>>|cRXP_WARN_A pack of 3 level 46|r |cRXP_ENEMY_Marauding Owlbeasts|r |cRXP_WARN_will spawn south of Skulk Rock, on the road. They enrage at low HP, so try to kill one at a time|r
>>|cRXP_WARN_A pack of 3 level 47|r |cRXP_ENEMY_Vilebranch Ambushers|r |cRXP_WARN_will spawn in the woods north of Jintha'Alor. They execute when you're below 20% health. Use long CC if you can, and have the chicken tank one or two of them until it's around half HP|r
.complete 836,1 
.target Homing Robot OOX-09/HL
.mob Marauding Owlbeast
.unitscan Vilebranch Ambusher
.isQuestTurnedIn 485
step
.goto The Hinterlands,79.47,61.21
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to the coast
>>|cRXP_WARN_This escort can be fatal. Don't hesitate to abandon the attempt if it puts your run at risk|r
>>|cRXP_WARN_A pack of 3 level 46|r |cRXP_ENEMY_Marauding Owlbeasts|r |cRXP_WARN_will spawn south of Skulk Rock, on the road. They enrage at low HP, so try to kill one at a time|r
>>|cRXP_WARN_A pack of 3 level 47|r |cRXP_ENEMY_Vilebranch Ambushers|r |cRXP_WARN_will spawn in the woods north of Jintha'Alor. They execute when you're below 20% health. Use long CC if you can, and have the chicken tank one or two of them until it's around half HP|r
.complete 836,1 
.target Homing Robot OOX-09/HL
.mob Marauding Owlbeast
.unitscan Vilebranch Ambusher
.isQuestTurnedIn 485
step
.goto The Hinterlands,81.6,81.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorkas|r
.fly Hammerfall >> Fly to Hammerfall in Arathi Highlands
.target Gorkas
step
.requires quest,8121
#completewith next
>>|cRXP_WARN_To accept this quest you need friendly reputation with The Defilers, which can be gained in Arathi Basin Battleground|r
.goto Arathi Highlands,73.2,29.8
.reputation 510,friendly
step
.requires quest,8121
.goto Arathi Highlands,73.2,29.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathmaster Dwire|r
>>|cRXP_WARN_Feel free to try and complete this quest at any point when you feel like PvP-ing|r
.accept 8121 >>Accept Take Four Bases
.target Deathmaster Dwire
step
.goto Arathi Highlands,73.0,32.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urda|r
.fly Thorium Point >> Fly to Thorium Point in Searing Gorge
.target Urda
step
.goto Searing Gorge,39.10,39.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok|r, then complete his dialogue
.accept 3441 >>Accept Divine Retribution
.complete 3441,1 
.target Velarok Windblade
.skipgossip
step
.goto Searing Gorge,39.05,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok|r
.turnin 3441 >>Turn in Divine Retribution
.accept 3442 >>Accept The Flawless Flame
.target Velarok Windblade
step
#loop
.line Searing Gorge,44.0,38.2,46.6,37.8,47.0,41.4,43.6,44.6,40.6,44.8,36.8,47.6,33.2,52.2,34.0,59.6,36.6,62.8,32.6,70.6,30.6,64.6,28.4,64.0,25.6,53.6,32.4,53.6,33.8,47.4,35.6,41.2,37.6,44.6,40.6,42.8,44.0,38.2
.goto Searing Gorge,44.00,38.20,25,0
.goto Searing Gorge,46.60,37.80,25,0
.goto Searing Gorge,47.00,41.40,25,0
.goto Searing Gorge,43.60,44.60,25,0
.goto Searing Gorge,40.60,44.80,25,0
.goto Searing Gorge,36.80,47.60,25,0
.goto Searing Gorge,33.20,52.20,25,0
.goto Searing Gorge,34.00,59.60,25,0
.goto Searing Gorge,36.60,62.80,25,0
.goto Searing Gorge,32.60,70.60,25,0
.goto Searing Gorge,30.60,64.60,25,0
.goto Searing Gorge,28.40,64.00,25,0
.goto Searing Gorge,25.60,53.60,25,0
.goto Searing Gorge,32.40,53.60,25,0
.goto Searing Gorge,33.80,47.40,25,0
.goto Searing Gorge,35.60,41.20,25,0
.goto Searing Gorge,37.60,44.60,25,0
.goto Searing Gorge,40.60,42.80,25,0
.goto Searing Gorge,44.00,38.20,25,0
>>Finish killing |cRXP_ENEMY_War Golems|r and |cRXP_ENEMY_Elementals|r. Loot them for their |cRXP_LOOT_Heart of Flame|r and |cRXP_LOOT_Golem Oil|r
>>|cRXP_WARN_Kill any|r |cRXP_ENEMY_Magma Elementals|r |cRXP_WARN_that you see. They can drop both quest items|r
.complete 3442,1 
.complete 3442,2 
.mob Heavy War Golem
.mob Tempered War Golem
.mob Inferno Elemental
.mob Blazing Elemental
.unitscan Magma Elemental
step
.goto Searing Gorge,39.05,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok|r
.turnin 3442 >>Turn in The Flawless Flame
.accept 3443 >>Accept Forging the Shaft
.target Velarok Windblade
step
#loop
.line Searing Gorge,46.36,53.91,42.75,54.91,41.35,53.44,37.97,49.17,39.32,44.55,37.97,49.17,35.85,42.12,38.16,38.35,39.24,32.84,41.60,26.95,43.59,22.85,43.46,28.38,46.04,25.49,45.47,30.46,43.13,32.50,43.41,35.64,48.27,43.38,49.88,46.10,48.28,50.79,46.36,53.91
.goto Searing Gorge,46.36,53.91,25,0
.goto Searing Gorge,42.75,54.91,25,0
.goto Searing Gorge,41.35,53.44,25,0
.goto Searing Gorge,37.97,49.17,25,0
.goto Searing Gorge,39.32,44.55,25,0
.goto Searing Gorge,37.97,49.17,25,0
.goto Searing Gorge,35.85,42.12,25,0
.goto Searing Gorge,38.16,38.35,25,0
.goto Searing Gorge,39.24,32.84,25,0
.goto Searing Gorge,41.60,26.95,25,0
.goto Searing Gorge,43.59,22.85,25,0
.goto Searing Gorge,43.46,28.38,25,0
.goto Searing Gorge,46.04,25.49,25,0
.goto Searing Gorge,45.47,30.46,25,0
.goto Searing Gorge,43.13,32.50,25,0
.goto Searing Gorge,43.41,35.64,25,0
.goto Searing Gorge,48.27,43.38,25,0
.goto Searing Gorge,49.88,46.10,25,0
.goto Searing Gorge,48.28,50.79,25,0
.goto Searing Gorge,46.36,53.91,25,0
>>Kill all |cRXP_ENEMY_Dark Iron Dwarves|r and |cRXP_ENEMY_Slave Workers|r. Loot them for their |cRXP_LOOT_Daggers|r
>>|cRXP_WARN_Any Dwarves around the area should drop these daggers but if you can, avoid going down into the mines for now|r
.complete 3443,1 
.mob Dark Iron Steamsmith
.mob Dark Iron Lookout
.mob Dark Iron Slaver
.mob Dark Iron Taskmaster
.mob Dark Iron Geologist
.mob Dark Iron Watchman
.mob Dark Iron Steelshifter
.mob Dark Iron Kidnapper
step
.goto Searing Gorge,39.05,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok|r
.turnin 3443 >>Turn in Forging the Shaft
.accept 3452 >>Accept The Flame's Casing
.target Velarok Windblade
step
.goto Searing Gorge,26.56,35.03,70,0
#loop
.line Searing Gorge,24.56,39.25,22.50,39.77,22.18,36.45,24.52,34.62,25.02,31.00,25.74,29.39,22.33,26.85,25.73,25.38,27.43,24.93,25.74,29.39,25.02,31.00,24.52,34.62,24.56,39.25
.goto Searing Gorge,24.56,39.25,25,0
.goto Searing Gorge,22.50,39.77,25,0
.goto Searing Gorge,22.18,36.45,25,0
.goto Searing Gorge,24.52,34.62,25,0
.goto Searing Gorge,25.02,31.00,25,0
.goto Searing Gorge,25.74,29.39,25,0
.goto Searing Gorge,22.33,26.85,25,0
.goto Searing Gorge,25.73,25.38,25,0
.goto Searing Gorge,27.43,24.93,25,0
.goto Searing Gorge,25.74,29.39,25,0
.goto Searing Gorge,25.02,31.00,25,0
.goto Searing Gorge,24.52,34.62,25,0
.goto Searing Gorge,24.56,39.25,25,0
>>Kill |cRXP_ENEMY_Twilight mobs|r. Loot them for the |cRXP_LOOT_Symbol of Ragnaros|r
.complete 3452,1 
.mob Twilight Dark Shaman
.mob Twilight Fire Guard
.mob Twilight Geomancer
.mob Twilight Idolater
.isOnQuest 3452
step
.isQuestComplete 3452
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3452 >> Turn in The Flame's Casing
.accept 3453 >> Accept The Torch of Retribution
.timer 28,The Torch of Retribution RP
.turnin 3453 >> Turn in The Torch of Retribution
.accept 3454 >> Accept The Torch of Retribution
.target Velarok Windblade
step
.isQuestTurnedIn 3452
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.accept 3453 >> Accept The Torch of Retribution
.timer 28,The Torch of Retribution RP
.turnin 3453 >> Turn in The Torch of Retribution
.accept 3454 >> Accept The Torch of Retribution
.target Velarok Windblade
step
.isQuestTurnedIn 3452
.goto Searing Gorge,39.055,39.067
>>Click on the |cRXP_PICK_Torch of Retribution|r
.turnin 3454 >> Turn in The Torch of Retribution
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok|r and |cRXP_FRIENDLY_Maltrake|r
.accept 3462 >>Accept Squire Maltrake
.goto Searing Gorge,39.06,38.99
.turnin 3462 >>Turn in Squire Maltrake
.accept 3463 >>Accept Set Them Ablaze!
.goto Searing Gorge,39.17,39.00
.target Velarok Windblade
.target Squire Maltrake
.isQuestTurnedIn 3452
step
.goto Searing Gorge,33.30,54.47
.use 10515 >>Equip the |T135466:0|t[Torch of Retribution], then climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.complete 3463,4 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
.goto Searing Gorge,35.66,60.68
.use 10515 >>Equip the |T135466:0|t[Torch of Retribution], then climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.complete 3463,1 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
.goto Searing Gorge,44.03,60.90
.use 10515 >>Equip the |T135466:0|t[Torch of Retribution], then climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.complete 3463,2 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
.goto Searing Gorge,50.10,54.70
.use 10515 >>Equip the |T135466:0|t[Torch of Retribution], then climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.complete 3463,3 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
.goto Searing Gorge,34.8,30.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grisha|r
.fly Kargath >> Fly to Kargath in Badlands
.target Grisha
.zoneskip Badlands
step
.requires quest,3907
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
>>|cRXP_WARN_If the quest is not showing, wait for him to finish his patrol once and return to Kartgath|r
.accept 3906 >>Accept Disharmony of Flame
.goto Badlands,3.6,48.0
.target Thunderheart
step
.requires quest,793
.goto Badlands,2.80,45.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorn|r
.accept 782 >>Accept Broken Alliances
.target Gorn
step
.requires quest,793
#label signofearthBL
>>Find & kill |cRXP_ENEMY_Boss Tho'grun|r. Loot him for the |cRXP_LOOT_Sign of Earth|r
>>|cRXP_LOOT_Boss Tho'grun|r |cRXP_WARN_patrols the zone, accompanied by five guards.|r
.complete 782,1 
.unitscan Boss Tho'grun
.mob Dustbelcher Mystic
.mob Dustbelcher Wyrmhunter
.mob Dustbelcher Shaman
.mob Dustbelcher Mauler
.isOnQuest 782
step
.requires quest,793
#requires signofearthBL
.goto Badlands,2.91,45.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorn|r
.turnin 782 >> Turn in Broken Alliances
.accept 793 >> Accept Broken Alliances
.target Gorn
.isQuestComplete 782
step
.requires quest,793
#completewith next
.goto Badlands,79.97,36.57,50,0
.subzone 339 >>Travel east to the Lethlor Ravine
.isOnQuest 793
step
.requires quest,793
.goto Badlands,72.30,66.80
>>Loot the |cRXP_PICK_Pillar of Opal|r for the |cRXP_LOOT_Opal Runestone|r
.collect 4844,1 
.isOnQuest 793
step
.requires quest,793
.goto Badlands,81.30,64.20
>>Loot the |cRXP_PICK_Pillar of Amethyst|r for the |cRXP_LOOT_Amethyst Runestone|r
.collect 4843,1 
.isOnQuest 793
step
.requires quest,793
.goto Badlands,83.50,32.90
>>Loot the |cRXP_PICK_Pillar of Diamond|r for the |cRXP_LOOT_Diamond Runestone|r
.collect 4845,1 
.isOnQuest 793
step
.requires quest,793
.goto Badlands,81.70,49.90
>>After collecting the 3 runestones, click the |cRXP_PICK_Seal of the Earth|r to summon |cRXP_ENEMY_Blacklash|r and |cRXP_ENEMY_Hematus|r
>>|cRXP_WARN_This can be difficult to solo, consider getting a group if you are unable to do it by yourself|r
.accept 795 >>Accept Seal of the Earth
.turnin 795 >>Turn in Seal of the Earth
.isOnQuest 793
step
.requires quest,793
.goto Badlands,81.70,49.90
>>Kill |cRXP_ENEMY_Blacklash|r and |cRXP_ENEMY_Hematus|r. Loot them for their |cRXP_LOOT_Bindings|r and |cRXP_LOOT_Chains|r
>>|cRXP_WARN_Simplify this encounter by killing|r |cRXP_ENEMY_Hematus|r |cRXP_WARN_first, as his flame buffet intensifies|r |cRXP_ENEMY_Blacklash's|r |cRXP_WARN_fire breath|r
.complete 793,1 
.complete 793,2 
.mob Blacklash
.mob Hematus
.isOnQuest 793
step
.requires quest,3907
>>Kill |cRXP_ENEMY_Overmaster Pyron|r
>>|cRXP_WARN_He roams around near the enterance to Blackrock Depths dungeon|r
.complete 3906,1 
.unitscan Overmaster Pyron
step
.requires quest,3907
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
.turnin 3906 >>Turn in Disharmony of Flame
.goto Badlands,3.6,48.0
.target Thunderheart
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fly Booty Bay >> Fly to Booty Bay in Stranglethorn Vale
.goto Badlands,4.0,44.8
.target Gorrik
step
.requires quest,8554
.goto Stranglethorn Vale,23.60,72.00
>>Kill |cRXP_ENEMY_Mok'rash|r. Loot him for |T133694:0|t[|cRXP_LOOT_Monogrammed Sash|r]. Use it to start the quest
>>|cRXP_WARN_He has a hefty respaw timer so it might take a while to get it|r
.collect 3985,1,8552 
.accept 8552 >>Accept The Monogrammed Sash
.use 3985
step
.requires quest,8554
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smotts|r
.turnin 8552 >>Turn in The Monogrammed Sash
.target Captain Hecklebury Smotts
.isOnQuest 8552
step
.requires quest,8554
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smotts|r and |cRXP_FRIENDLY_Sprogger|r
.accept 8553 >>Accept The Captain's Cutlass
.goto Stranglethorn Vale,26.69,73.62
.turnin 8553 >>Turn in The Captain's Cutlass
.goto Stranglethorn Vale,26.66,73.64
.target Captain Hecklebury Smotts
.target Sprogger
.isQuestTurnedIn 8552
step
.requires quest,8554
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sprogger|r
.accept 8554 >>Accept Facing Negolash
.target Sprogger
step
.requires quest,8554
.goto Stranglethorn Vale,27.04,77.17,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nixxrax|r
>>|cRXP_WARN_If you didn't get|r |T133974:0|t[Barbecued Buzzard Wings] |cRXP_WARN_earlier (and none of your group members do either), then skip this step. You need 10 wings in total to summon|r |cRXP_ENEMY_Negolash|r
.vendor >>Buy |cRXP_BUY_Junglevine Wine|r from |cRXP_FRIENDLY_Nixxrax|r
.collect 4457,10 
.collect 4595,5 
.target Nixxrax Fillamug
step
.requires quest,8554
#completewith next
.goto Stranglethorn Vale,29.83,72.25,50,0
.goto Stranglethorn Vale,33.66,75.05,50,0
.subzone 43 >>Travel north out of Booty Bay, then east to the beach
step
.requires quest,8554
.goto Stranglethorn Vale,32.5,81.90
>>Click the |cRXP_PICK_Ruined Lifeboat|r
.turnin 619 >>Turn in Enticing Negolash
step
.requires quest,8554
.goto Stranglethorn Vale,32.50,81.94
>>Click the |cRXP_PICK_Ruined Lifeboat|r to summon |cRXP_ENEMY_Negolash|r. Kill him and loot him for |cRXP_LOOT_Smotts' Cutlass|r
.complete 8554,1 
.unitscan Negolash
step
.requires quest,630
#loop
.goto Stranglethorn Vale,34.22,73.25,60,0
.goto Stranglethorn Vale,34.01,77.21,60,0
.goto Stranglethorn Vale,32.34,79.44,60,0
.goto Stranglethorn Vale,32.38,82.23,60,0
>>Loot the |cRXP_PICK_Half-Burried Bottles|r along the southeastern coast
.collect 4098,1,594
.accept 594 >> Accept Message in a Bottle
step
.requires quest,630
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Poobah|r
.turnin 594 >>Turn in Message in a Bottle
.accept 630 >>Accept Message in a Bottle
.target Princess Poobah
step
.requires quest,630
.goto Stranglethorn Vale,40.94,83.89
>>Kill |cRXP_ENEMY_King Mukla|r. Loot him for his |cRXP_LOOT_Key|r
>>|cRXP_WARN_Clear a bit of space around|r |cRXP_ENEMY_King Mukla|r|cRXP_WARN_, as he has a fear|r
.complete 630,1 
.unitscan King Mukla
step
.goto Stranglethorn Vale,32.90,88.20,0
.goto Stranglethorn Vale,30.60,90.60,0
.goto Stranglethorn Vale,29.30,88.30,0
>>Search the ships' lower levels until you find a small scroll on the ground. Loot it for |T134939:0|t[|cRXP_LOOT_Cortello's Riddle|r].
.collect 4056,1,624,1 >> Cortello's Riddle (1)
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.accept 2872 >> Accept Stoley's Debt
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,25.91,72.96
.zone The Barrens >> Take a boat to Ratchet
.zoneskip The Barrens
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Horde
#group RestedXP SoD Preparation
#subgroup Preparation guide
#title 2 - 20 Questlog prep - Kalimdor
#name 2 - 20 Questlog prep - Kalimdor (H)
#next 3 - 20 Questlog prep - Dungeons and shopping
step
.requires quest,4502
.goto The Barrens,62.50,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv|r
.accept 4502 >>Accept Volcanic Activity
.target Liv Rizzlefix
step
.goto The Barrens,63.0,37.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Marshal's Refuge >> Fly to Marshal's Refuge in Un'goro Crater
.target Bragok
step
#completewith Ungoroend
>>Kill |cRXP_ENEMY_Ravasaurs|r. Loot them for |T133743:0|t[A Mangled Journal]
>>|cRXP_WARN_Any mob in Un'Goro Crater may drop it|r
>>|cRXP_WARN_Use |T133743:0|t[A Mangled Journal] to start the quest|r
.collect 11116,1,3884,1 
step
#completewith Ungoroend
>>Loot |cRXP_LOOT_Power Crystals|r on the ground as you quest through Un'Goro Crater
.collect 11186,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
.collect 11188,7,4284,1 
step
.requires quest,4292
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.accept 4290 >> Accept The Fare of Lar'korwi
.target Torwa Pathfinder
step
#completewith Ungoroend
>>Loot |cRXP_LOOT_Un'Goro Soil|r on the ground as you quest through Un'Goro Crater
.collect 11018,25 
step
.requires quest,4292
.goto Un'Goro Crater,68.73,56.70
>>Loot the |cRXP_LOOT_Piece of Threshadon Carcass|r
.complete 4290,1 
step
.requires quest,4292
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4290 >> Turn in The Fare of Lar'korwi
.accept 4291 >> Accept The Scent of Lar'korwi
.target Torwa Pathfinder
step
.requires quest,4292
.goto Un'Goro Crater,67.324,73.041,8,0
.goto Un'Goro Crater,66.601,66.727,8,0
.goto Un'Goro Crater,60.926,72.234,8,0
.goto Un'Goro Crater,62.285,65.985,8,0
.goto Un'Goro Crater,63.240,77.350,8,0
.goto Un'Goro Crater,67.324,73.041,8,0
.goto Un'Goro Crater,66.601,66.727
.goto Un'Goro Crater,67.324,73.041,0
.goto Un'Goro Crater,60.926,72.234,0
.goto Un'Goro Crater,62.285,65.985,0
.goto Un'Goro Crater,63.240,77.350,0
>>Kill |cRXP_ENEMY_Lar'korwi Mates|r. Loot them for their |cRXP_LOOT_Ravasaur Pheromone Glands|r
>>|cRXP_WARN_Walking over |cRXP_PICK_Raptor Nests|r on the ground will trigger a |cRXP_ENEMY_Lar'korwi Mate|r to spawn|r
.complete 4291,1 
.mob Lar'korwi Mate
step
.requires quest,4292
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4291 >> Turn in The Scent of Lar'korwi
.target Torwa Pathfinder
step
.requires quest,4292
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.accept 4292 >> Accept The Bait for Lar'korwi
.target Torwa Pathfinder
step
.requires quest,4301
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.accept 4289 >> Accept The Apes of Un'Goro
.target Torwa Pathfinder
step
.requires quest,4292
.goto Un'Goro Crater,79.929,49.896
>>|cRXP_WARN_Use the|r |T133970:0|t[Preserved Threshadon Meat] |cRXP_WARN_on the stone-slab, then use the|r |T134743:0|t[Preserved Pheromone Mixture] |cRXP_WARN_on it to summon|r |cRXP_ENEMY_Lar'korwi|r
>>Kill |cRXP_ENEMY_Lar'korwi|r. Loot him for his |cRXP_LOOT_Head|r
.use 11568 
.use 11569 
.use 11570 
.complete 4292,1 
.mob Lar'korwi
step
.requires quest,4301
.goto Un'Goro Crater,63.66,16.56,70,0
.goto Un'Goro Crater,65.47,16.48
>>Kill |cRXP_ENEMY_Un'Goro Gorillas|r, |cRXP_ENEMY_Un'Goro Stompers|r and |cRXP_ENEMY_Un'Goro Thunderer|r. Loot them for their |cRXP_LOOT_Pelts|r
>>|cRXP_ENEMY_Un'Goro Gorillas|r |cRXP_WARN_will call for help at low health, pay attention to your surroundings when this happens|r
>>|cRXP_ENEMY_Un'Goro Stompers|r |cRXP_WARN_will|r |T136224:0|t[Enrage] |cRXP_WARN_at low health|r
>>|cRXP_ENEMY_Un'Goro Thunderer|r |cRXP_WARN_cast a high damage|r |T136105:0|t[Thunderclap]
.complete 4289,1 
.complete 4289,2 
.complete 4289,3 
.mob Un'Goro Gorilla
.mob Un'Goro Stomper
.mob Un'Goro Thunderer
step
.requires quest,4245
.goto Un'Goro Crater,46.378,13.444
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna Remtravel|r
.accept 4243 >> Accept Chasing A-Me 01
.target Karna Remtravel
step
.requires quest,4301
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4289 >> Turn in The Apes of Un'Goro
.accept 4301 >> Accept The Mighty U'cha
.target Torwa Pathfinder
step
.requires quest,4245
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.turnin 4243 >> Turn in Chasing A-Me 01
.itemcount 10561,<1 
.target A-Me 01
step
.requires quest,4245
#label AMe
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
>>|cRXP_WARN_Don't accept the follow up yet|r
.turnin 4243 >> Turn in Chasing A-Me 01
.itemcount 10561,1 
.target A-Me 01
step
.requires quest,4301
.goto Un'Goro Crater,68.49,12.18
>>Kill |cRXP_ENEMY_U'cha|r. Loot him for his |cRXP_LOOT_Pelt|r
.complete 4301,1 
.mob U'cha
step
.requires quest,4245
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.accept 4244 >> Accept Chasing A-Me 01
.turnin 4244 >> Turn in Chasing A-Me 01
.accept 4245 >> Accept Chasing A-Me 01
.itemcount 10561,1 
.target A-Me 01
step
.requires quest,4245
.isQuestTurnedIn 4244
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.accept 4245 >> Accept Chasing A-Me 01
.target A-Me 01
step
.requires quest,4245
.isOnQuest 4245
.goto Un'Goro Crater,46.378,13.444
>>Escort |cRXP_FRIENDLY_A-Me 01|r to |cRXP_FRIENDLY_Karna Remtravel|r at Marshal's Refuge
.complete 4245,1 
.target A-Me 01
step
.goto Un'Goro Crater,45.41,12.13
>>Travel to Marshal's Refuge
>>Loot |cRXP_LOOT_Power Crystals|r on the ground en-route
.collect 11186,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
.collect 11188,7,4284,1 
step
#completewith next
.goto Un'Goro Crater,45.41,12.13
.subzone 541 >> Travel to Marshal's Refuge
step
.requires quest,4501
.goto Un'Goro Crater,43.533,8.436
>>Click the |cRXP_PICK_Wanted Poster|r
.accept 4501 >> Accept Beware of Pterrordax
step
.requires quest,4491
.goto Un'Goro Crater,43.615,8.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle Frock|r
.accept 4492 >> Accept Lost!
.target Spraggle Frock
step
.requires quest,4501
.goto Un'Goro Crater,56.3,90.6,40,0
.goto Un'Goro Crater,44.3,90.4,40,0
.goto Un'Goro Crater,56.3,90.6,40,0
.goto Un'Goro Crater,44.1,66.2,70,0
.goto Un'Goro Crater,53.5,62.9,70,0
.goto Un'Goro Crater,52.3,69.8,70,0
.goto Un'Goro Crater,44.3,90.4
>>Kill |cRXP_ENEMY_Pterrordaxes|r.
.complete 4501,1 
.disablecheckbox
.mob Pterrordax
step
.requires quest,4501
#label CompletePterro
.goto Un'Goro Crater,20.6,60,40,70,0
.goto Un'Goro Crater,22.4,50.0,70,0
.goto Un'Goro Crater,22.2,41,0,70,0
.goto Un'Goro Crater,34.8,29.4,70,0
.goto Un'Goro Crater,39.6,42.2,70,0
.goto Un'Goro Crater,36.8,76.6,70,0
.goto Un'Goro Crater,24.6,61.6
>>Kill |cRXP_ENEMY_Frenzied Pterrordaxes|r.
.complete 4501,2 
.mob Frenzied Pterrordax
step
.requires quest,4502
#loop
.line Un'Goro Crater,46.7,53.2,49.8,53.9,52.2,54.2,51.2,51.6,53.1,50.4,52.6,45.3,51.5,46.3,50.3,47.7,51.3,49.4,50.3,47.7,49.5,47.3,47.8,50.9,46.7,53.2
.goto Un'Goro Crater,46.70,53.20,25,0
.goto Un'Goro Crater,49.80,53.90,25,0
.goto Un'Goro Crater,52.20,54.20,25,0
.goto Un'Goro Crater,51.20,51.60,25,0
.goto Un'Goro Crater,53.10,50.40,25,0
.goto Un'Goro Crater,52.60,45.30,25,0
.goto Un'Goro Crater,51.50,46.30,25,0
.goto Un'Goro Crater,50.30,47.70,25,0
.goto Un'Goro Crater,51.30,49.40,25,0
.goto Un'Goro Crater,50.30,47.70,25,0
.goto Un'Goro Crater,49.50,47.30,25,0
.goto Un'Goro Crater,47.80,50.90,25,0
.goto Un'Goro Crater,46.70,53.20,25,0
>>Kill |cRXP_ENEMY_Fire Elementals|r. Loot them for their |cRXP_LOOT_Ash|r
.complete 4502,1 
.mob Scorching Elemental
.mob Living Blaze
.mob Blazing Invader
step
.requires quest,4491
#completewith next
.goto Un'Goro Crater,52.42,51.00,30 >> Enter the cave on the east side of the volcano
step
.requires quest,4491
.goto Un'Goro Crater,51.909,49.870
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ringo|r
.turnin 4492 >> Turn in Lost!
.accept 4491,1 >> Accept A Little Help From My Friends
>>|cRXP_WARN_This will start an escort quest|r
.target Ringo
step
.requires quest,4491
.goto Un'Goro Crater,43.617,8.497
>>Escort |cRXP_FRIENDLY_Ringo|r to Marshal's Refuge
.use 11804 >> |cRXP_WARN_Use|r |T132805:0|t[Spraggle's Canteen] |cRXP_WARN_on him when he faints and stops following you|r
.complete 4491,1 
.target Ringo
step
.requires quest,4642
#label Ungoroend
.goto Un'Goro Crater,46.60,62.37,70,0
.goto Un'Goro Crater,49.25,64.43,70,0
.goto Un'Goro Crater,50.93,67.97,70,0
.goto Un'Goro Crater,55.97,69.52,70,0
.goto Un'Goro Crater,57.84,63.53,70,0
.goto Un'Goro Crater,58.80,57.84,70,0
.goto Un'Goro Crater,58.43,52.67,70,0
.goto Un'Goro Crater,57.94,44.83,70,0
.goto Un'Goro Crater,50.93,67.97
>>Finish killing |cRXP_ENEMY_Oozes|r. Loot them for their |cRXP_LOOT_Slime Samples|r and |cRXP_LOOT_Un'Goro Soil|r
>>|cRXP_ENEMY_Primal Oozes|r |cRXP_WARN_to the south/west are the most abundant, but be careful of|r |cRXP_ENEMY_Devilsaur|r |cRXP_WARN_patrols through the area|r
.collect 11018,25 
.collect 12235,35 
.mob Muculent Ooze
.mob Glutinous Ooze
.mob Primal Ooze
step
>>Kill |cRXP_ENEMY_Ravasaurs|r. Loot them for |T133743:0|t[A Mangled Journal]
>>|cRXP_WARN_Any mob in Un'Goro Crater may drop it|r
>>|cRXP_WARN_Use |T133743:0|t[A Mangled Journal] to start the quest|r
.collect 11116,1,3884,1 
step
>>Loot the remaining |cRXP_LOOT_Power Crystals|r on the ground throughout Un'Goro Crater
.collect 11186,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
.collect 11188,7,4284,1 
step
.goto Un'Goro Crater,45.2,5.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryfe|r
.fly Gadgetzan >> Fly to Gadgetzan in Tanaris
.target Gryfe
.zoneskip Tanaris
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 992 >> Accept Gadgetzan Water Survey
.target Senior Surveyor Fizzledowser
step
.requires quest,4507
.goto Tanaris,39.10,29.30
.use 8584 >> the |T134867:0|t[Untapped Dowsing Widget] at the pool. Run away from the two mobs that spawn without attacking them.
.complete 992,1 
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 992 >> Turn in Gadgetzan Water Survey
.target Senior Surveyor Fizzledowser
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 82 >>Accept Noxious Lair Investigation
.target Kravel Koalbeard
step
.requires quest,4507
#completewith next
.subzone 982 >>Continue west to The Noxious Lair
step
.requires quest,4507
.goto Tanaris,35.68,39.78,70,0
.goto Tanaris,36.55,41.98,70,0
.goto Tanaris,35.59,44.08,70,0
.goto Tanaris,35.60,48.79,70,0
.goto Tanaris,31.70,49.12,70,0
.goto Tanaris,30.83,46.10,70,0
.goto Tanaris,35.68,39.78
>>Kill |cRXP_ENEMY_Centipaar Silithids|r. Loot them for their |cRXP_LOOT_Insect Parts|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Centipaar Swarmers|r|cRXP_WARN_. They can spawn many minions and social aggro from great distances|r
>>|cRXP_WARN_All|r |cRXP_ENEMY_Centipaar|r |cRXP_WARN_cast|r |T132152:0|t[Thrash] |cRXP_WARN_(Charges 2 extra attacks every 10 seconds)
.complete 82,1 
.mob Centipaar Wasp
.mob Centipaar Stinger
.mob Centipaar Swarmer
.mob Centipaar Worker
.mob Centipaar Sandreaver
.mob Centipaar Tunneler
step
.requires quest,4507
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 82 >>Turn in Noxious Lair Investigation
.target Alchemist Pestlezugg
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 10 >>Accept The Scrimshank Redemption
.target Senior Surveyor Fizzledowser
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r
.turnin 243 >> Turn in Into the Field
.accept 379 >> Accept Slake That Thirst
.goto Tanaris,52.46,28.52
.target Chief Engineer Bilgewhizzle
step
.goto Tanaris,59.36,24.75,60,0
.goto Tanaris,60.46,23.42,60,0
>>Kill |cRXP_ENEMY_Wastewander Bandits|r and |cRXP_ENEMY_Wastewander Thieves|r in the Noonshade Ruins en route to Steamwheedle Port. Loot them for their |cRXP_LOOT_Water Pouches|r
.collect 8483,5 
.mob Wastewander Bandit
.mob Wastewander Thief
step
.goto Tanaris,67.10,24.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stoley|r
.turnin 2872 >> Turn in Stoley's Debt
.accept 2873 >>Accept Stoley's Shipment
.target Stoley
step
.isQuestAvailable 2876
>>Kill |cRXP_ENEMY_Southsea Pirates|r. Loot them for their |cRXP_LOOT_Pirate's Footlockers|r. Make sure to open them and look for |cRXP_LOOT_Ship Schedule|r
.use 9276
.collect 9250,1 
.mob Southsea Pirate
.mob Southsea Freebooter
.mob Southsea Dock Worker
.mob Southsea Swashbuckler
step
>>Loot the |cRXP_PICK_Stolen Cargo|r for |cRXP_LOOT_Stoley's Shipment|r on the second floor of the western house
.goto Tanaris,72.23,46.81
.complete 2873,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stoley|r
.turnin 2873 >>Turn in Stoley's Shipment
.goto Tanaris,67.11,23.98
.target Stoley
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r and |cRXP_FRIENDLY_Luglunket|r
.turnin 379 >> Turn in Slake That Thirst
.goto Tanaris,52.46,28.52
step
.use 8524 >>Use the |T134459:0|t[|cRXP_LOOT_Model 4711-FTZ Power Source|r] to start the quest
>>|cRXP_WARN_The following quest is timed so make sure you can set aside enough time to complete it within 2 hour limit|r
.accept 654 >> Accept Tanaris Field Sampling
step
>>Kill |cRXP_ENEMY_Basilisks|r, |cRXP_ENEMY_Hyenas|r and |cRXP_ENEMY_Scorpids|r. Loot them for their their |cRXP_LOOT_Samples|r
>>Use the |cRXP_LOOT_Samples|r to test them
*|cRXP_WARN_Do not delete any untested samples|r
.complete 654,1 
.complete 654,2 
.complete 654,3 
.use 9437
.use 9439
.use 9442
.mob Glasshide Basilisk
.mob Glasshide Gazer
.mob Glasshide Petrifier
.mob Starving Blisterpaw
.mob Blisterpaw Hyena
.mob Murderous Blisterpaw
.mob Rabid Blisterpaw
.mob Scorpid Tail Lasher
.mob Scorpid Hunter
.mob Scorpid Dunestalker
.mob Scorpid Duneburrower
step
.goto Tanaris,52.40,28.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r
.turnin 654 >>Turn in Tanaris Field Sampling
.target Chief Engineer Bilgewhizzle
.isOnQuest 654
step
.isQuestAvailable 351
.use 8623 >>If you've found an |T132836:0|t[OOX-17/TN Distress Beacon], click it and accept its quest. Otherwise, kill any mobs in Tanaris for a chance to drop it
.accept 351 >>Accept Find OOX-17/TN!
.collect 8623,1
step
#completewith next
.goto Tanaris,56.19,66.62,30,0
.subzone 981 >>Travel south to The Gaping Chasm
step
.requires quest,4507
#label BugHole
.goto Tanaris,55.69,69.44,50,0
.goto Tanaris,56.36,68.44,30,0
.goto Tanaris,57.45,70.45,30,0
.goto Tanaris,55.96,71.16
>>Enter the silithid hive, then click the |cRXP_PICK_Scrimshank's Surveying Gear console|r and loot |cRXP_LOOT_Scrimshank's Surveying Gear|r
>>|cRXP_WARN_Be extremely cautious of |cRXP_ENEMY_Hazzali Swarmers|r |cRXP_WARN_as they can rapidly summon adds which deal high damage. They can also social aggro other mobs from extreme distances|r
.complete 10,1 
.unitscan Hazzali Swarmer
step
.goto Tanaris,60.20,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r
.turnin 351 >>Turn in Find OOX-17/TN!
.target Homing Robot OOX-17/TN
.isOnQuest 351
step
.goto Tanaris,60.23,64.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r again to start the escort quest
.accept 648 >>Accept Rescue OOX-17/TN!
.target Homing Robot OOX-17/TN
.isQuestTurnedIn 351
step
.goto Tanaris,67.09,23.18
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r to Steamwheedle Port
>>|cRXP_WARN_A pack of 3 level 46-47|r |cRXP_ENEMY_Scorpions|r |cRXP_WARN_will spawn at the next mountain chain|r
>>|cRXP_WARN_A pack of 3 level 43-45|r |cRXP_ENEMY_Wastewander mobs|r |cRXP_WARN_will spawn around Waterspring Field. Focus the|r |cRXP_ENEMY_Scofflaw|r|cRXP_WARN_. It EXECUTES when you're below 20% health|r
.complete 648,1 
.target Homing Robot OOX-17/TN
.unitscan Wastewander Scofflaw
.isQuestTurnedIn 351
step
#completewith next
.goto Tanaris,50.6,28.1
.subzone 976 >>Travel to Gadgetzan
step
.requires quest,4507
.goto Tanaris,50.21,27.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 10 >>Turn in The Scrimshank Redemption
.accept 110 >>Accept Insect Part Analysis
.target Senior Surveyor Fizzledowser
step
.requires quest,4507
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 110 >>Turn in Insect Part Analysis
.accept 113 >>Accept Insect Part Analysis
.target Alchemist Pestlezugg
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 113 >>Turn in Insect Part Analysis
.accept 32 >>Accept Rise of the Silithid
.target Senior Surveyor Fizzledowser
step << Mage
.requires quest,4507
.cast 3567 >>Cast |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << !Mage
.requires quest,4507
.goto Tanaris,51.6,25.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek Ragefist|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Bulkrek Ragefist
step
.requires quest,4507
.goto Orgrimmar,56.40,46.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zilzibin|r
.turnin 32 >>Turn in Rise of the Silithid
.accept 4494 >>Accept March of the Silithid
.target Zilzibin Drumlore
step
.requires quest,4507
.goto Orgrimmar,45.2,63.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Gadgetzan >> Fly to Gadgetzan in Tanaris
.target Doras
step
.requires quest,4507
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4494 >>Turn in March of the Silithid
.accept 4496 >>Accept Bungle in the Jungle
.target Alchemist Pestlezugg
step
.requires quest,4507
#completewith next
.goto Un'Goro Crater,50.59,77.06,0
>>Kill |cRXP_ENEMY_Gorishi Silithid|r. Loot them for a |cRXP_LOOT_Gorishi Scent Gland|r << !Druid
.complete 4496,1 
.mob Gorishi Worker
.mob Gorishi Wasp
.mob Gorishi Reaver
.mob Gorishi Tunneler
.mob Gorishi Stinger
.mob Gorishi Hive Guard
step
.requires quest,4507
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4496 >> Turn in Bungle in the Jungle
.accept 4507 >> Accept Pawn Captures Queen
.target Alchemist Pestlezugg
step
.requires quest,4507
.goto Un'Goro Crater,50.15,79.98,40,0
.goto Un'Goro Crater,49.74,82.52,30,0
.goto Un'Goro Crater,45.19,82.20,30,0
.goto Un'Goro Crater,43.41,80.98
>>Go deep into the silithid hive, until you reach a tall crystal in a round chamber
.use 11833 >>Use your |T134809:0|t[Gorishi Queen Lure] to summon the |cRXP_ENEMY_Gorishi Hive Queen|r. Kill her, then loot her |cRXP_LOOT_Gorishi Queen Brain|r
>>|cRXP_WARN_Stop new waves from aggroing you by dragging mobs into the hallway. Depending on your kill speed, a hallway patrol may respawn after the second wave|r
.complete 4507,1 
step
.goto Tanaris,51.6,25.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek Ragefist|r
.fly Camp Mojache >> Travel to Camp Mojache in Feralas
.target Bulkrek Ragefist
step
.goto Feralas,76.00,42.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krueg|r
.accept 2973 >> Accept A New Cloak's Sheen
.target Krueg Skullsplitter
step
.goto Feralas,74.90,42.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.accept 2862 >> Accept War on the Woodpaw
.target Hadoken Swiftstrider
step
#sticky
#completewith Feralasbot
>>Look out for the |T132836:0|t[|cRXP_FRIENDLY_Distress Beacon|r] drop as you quest throughout Feralas
.collect 8705,1,2766
.accept 2766 >> Accept Find OOX-22/FE!
step
.goto Feralas,72.79,39.32,60,0
.goto Feralas,72.11,37.21,60,0
.goto Feralas,73.18,36.29,60,0
.goto Feralas,72.79,39.32
>>Kill |cRXP_ENEMY_Woodpaw Gnolls|r northwest of Camp Mojache. Loot them for their |cRXP_LOOT_Manes|r
.complete 2862,1 
.mob Woodpaw Mongrel
.mob Woodpaw Trapper
.mob Woodpaw Brute
.mob Woodpaw Reaver
.mob Woodpaw Mystic
.mob Woodpaw Alpha
step
#completewith next
.goto Feralas,74.73,43.59,150 >> Return to Camp Mojache
step
#label WoodpawWarTurnin
.goto Feralas,74.90,42.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 2862 >> Turn in War on the Woodpaw
.accept 2863 >> Accept Alpha Strike
.target Hadoken Swiftstrider
step
.goto Feralas,68.80,48.00
>>Kill |cRXP_ENEMY_Sprite Darters|r. Loot them for their |cRXP_LOOT_Wings|r
.complete 2973,1 
.mob Sprite Darter
step
#loop
.line Feralas,67.50,55.60,69.05,55.78,68.60,54.25,71.51,55.98,72.42,56.63,73.21,56.25,72.42,56.63,71.51,55.98,68.60,54.25,69.05,55.7867.50,55.60
.goto Feralas,67.50,55.60,25,0
.goto Feralas,69.05,55.78,25,0
.goto Feralas,68.60,54.25,25,0
.goto Feralas,71.51,55.98,25,0
.goto Feralas,72.42,56.63,25,0
.goto Feralas,73.21,56.25,25,0
.goto Feralas,72.42,56.63,25,0
.goto Feralas,71.51,55.98,25,0
.goto Feralas,68.60,54.25,25,0
>>Kill |cRXP_ENEMY_Woodpaw Alphas|r within the allotted time
*|cRXP_WARN_There's usually one in each camp|r
.complete 2863,1 
.unitscan Woodpaw Alpha
step
#completewith next
.goto Feralas,74.73,43.59,150 >> Return to Camp Mojache
step
#label KruegTurnin1
.goto Feralas,76.00,42.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krueg|r
.turnin 2973 >> Turn in A New Cloak's Sheen
.accept 2974 >> Accept A Grim Discovery
.target Krueg Skullsplitter
step
.goto Feralas,74.90,42.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 2863 >> Turn in Alpha Strike
.accept 2902 >> Accept Woodpaw Investigation
.target Hadoken Swiftstrider
step
.goto Feralas,69.92,38.97,60,0
.goto Feralas,68.71,39.90,60,0
.goto Feralas,68.08,46.12,60,0
.goto Feralas,66.63,46.62,60,0
.goto Feralas,69.92,38.97,60,0
.goto Feralas,66.63,46.62
>>Kill |cRXP_ENEMY_Grimtotem Taurens|r. Loot them for their |cRXP_LOOT_Horns|r
>>|cRXP_ENEMY_Grimtotem Raiders|r |cRXP_WARN_cast|r |T132149:0|t[Net] |cRXP_WARN_which immobilizes movement for 10 seconds|r
.complete 2974,1 
.mob Grimtotem Shaman
.mob Grimtotem Raider
.mob Grimtotem Naturalist
step
.goto Feralas,71.60,55.90
>>Click on the |cRXP_PICK_Woodpaw Battle Map|r, on top of a crate
.turnin 2902 >> Turn in Woodpaw Investigation
.accept 2903 >> Accept The Battle Plans
step
.goto Feralas,76.00,42.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krueg|r
.turnin 2974 >> Turn in A Grim Discovery
.target Krueg Skullsplitter
step
.goto Feralas,74.90,42.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 2903 >> Turn in The Battle Plans
.accept 7730 >> Accept Zukk'ash Infestation
.accept 7731 >> Accept Stinglasher
.target Hadoken Swiftstrider
step
#completewith next
.goto Feralas,73.38,62.94,0
>>Kill |cRXP_ENEMY_Zukk'ash Silithid|r. Loot them for their |cRXP_LOOT_Carapace|r
.complete 7730,1 
.mob Zukk'ash Worker
.mob Zukk'ash Wasp
.mob Zukk'ash Tunneler
.mob Zukk'ash Stinger
step
.goto Feralas,73.38,63.24,-1
.goto Feralas,76.36,61.19,-1
>>Kill |cRXP_ENEMY_Stinglasher|r. Loot it for its |cRXP_LOOT_Glands|r
>>|cRXP_WARN_This mob can be quite hard make sure to have cooldowns available|r
>>It patrols all around the outside of the Silithid Hives
.complete 7731,1 
.unitscan Stinglasher
step
.goto Feralas,75.21,61.82,60,0
.goto Feralas,74.10,62.42,60,0
.goto Feralas,72.86,62.78,60,0
.goto Feralas,75.21,61.82,60,0
.goto Feralas,72.86,62.78
>>Kill |cRXP_ENEMY_Zukk'ash Silithid|r. Loot them for their |cRXP_LOOT_Carapace|r
.complete 7730,1 
.mob Zukk'ash Worker
.mob Zukk'ash Wasp
.mob Zukk'ash Tunneler
.mob Zukk'ash Stinger
step
.goto Feralas,74.90,42.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 7730 >> Turn in Zukk'ash Infestation
.turnin 7731 >> Turn in Stinglasher
.target Hadoken Swiftstrider
step
>>If you still dont have |T132836:0|t[|cRXP_FRIENDLY_Distress Beacon|r] kill enemies around feralas for it. Click on it to accept the quest.
.collect 8705,1,2766,1
.accept 2766 >> Accept Find OOX-22/FE!
.use 8705
step
.goto Feralas,53.35,55.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r
.turnin 2766 >> Turn in Find OOX-22/FE!
.target Homing Robot OOX-22/FE
.isOnQuest 2766
step
.goto Feralas,53.35,55.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r
.accept 2767 >> Accept Rescue OOX-22/FE!
.target Homing Robot OOX-22/FE
.isQuestTurnedIn 2766
step
.goto Feralas,55.47,56.37,30,0
.goto Feralas,54.38,51.32,60,0
.goto Feralas,50.31,49.91,40,0
.goto Feralas,48.38,44.83,40,0
.goto Feralas,45.04,43.27
>>|cRXP_WARN_3 Waves will spawn. Save all your very long cooldowns for the|r |cRXP_ENEMY_Gnolls|r|cRXP_WARN_, and use some on the|r |cRXP_ENEMY_Yetis|r
+3 Yetis (each level 46)
+3 Gorillas
+4 Gnolls
.complete 2767,1 
.isOnQuest 2767
.target Homing Robot OOX-22/FE
step
.goto Feralas,74.40,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.accept 3121 >> Accept A Strange Request
.target Witch Doctor Uzer'i
step << Mage
.cast 3567 >>Cast |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << !Mage
.goto Feralas,75.4,44.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Shyn
.zoneskip Orgrimmar
step
.goto Orgrimmar,49.60,50.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neeru|r
.turnin 3121 >> Turn in A Strange Request
.accept 3122 >> Accept Return to Witch Doctor Uzer'i
.target Neeru Fireblade
step
.goto Orgrimmar,75.00,34.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.accept 3504 >>Accept Betrayed
.target Belgrom Rockmaul
step
.requires quest,2937
#completewith next
.goto Durotar,56.0,74.6
.zone Durotar >> Run out into Durotar
step
.requires quest,2937
.goto Durotar,56.0,74.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Gadrin|r
.turnin 2935 >>Turn in Consult Master Gadrin
.accept 2936 >>Accept The Spider God
.target Master Gadrin
step
.requires quest,2937
#completewith next
.zone Orgrimmar >> Get back to Orgrimmar
.goto Orgrimmar,45.2,63.8
.zoneskip Orgrimmar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.goto Orgrimmar,45.2,63.8
.fly Camp Mojache >> Fly to Camp Mojache in Feralas
.target Doras
.zoneskip Feralas
step
.goto Feralas,74.50,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
>>|cRXP_WARN_Wait for him to complete his preparation|r
.turnin 3122 >>Turn in Return to Witch Doctor Uzer'i
.accept 3123 >>Accept Testing the Vessel
.target Witch Doctor Uzer'i
step
.goto Feralas,75.4,44.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Valormok >> Fly to Valormok in Azshara
.target Shyn
.zoneskip Azshara
step
.goto Azshara,22.20,51.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ag'tor|r
.turnin 3504 >>Turn in Betrayed
.target Ag'tor Bloodfist
.isOnQuest 3504
step
.goto Azshara,22.20,51.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ag'tor|r
.accept 3505 >>Accept Betrayed
.target Ag'tor Bloodfist
.isQuestTurnedIn 3504
step
.goto Azshara,22.50,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.accept 3517 >>Accept Stealing Knowledge
.target Jediga
step
#loop
.line Azshara,55.8,25.9,57.8,26.4,58.0,28.2,59.2,29.6,57.9,31.4,57.0,30.3,56.9,27.5,56.0,29.7,55.4,29.7,55.8,25.9
.goto Azshara,55.80,25.90,25,0
.goto Azshara,57.80,26.40,25,0
.goto Azshara,58.00,28.20,25,0
.goto Azshara,59.20,29.60,25,0
.goto Azshara,57.90,31.40,25,0
.goto Azshara,57.00,30.30,25,0
.goto Azshara,56.90,27.50,25,0
.goto Azshara,56.00,29.70,25,0
.goto Azshara,55.40,29.70,25,0
.goto Azshara,55.80,25.90,25,0
>>Kill |cRXP_ENEMY_Blood Elf Reclaimers|r and |cRXP_ENEMY_Blood Elf Surveyors|r
>>|cRXP_WARN_Be careful!|r |cRXP_ENEMY_Surveyors|r |cRXP_WARN_have a short cooldown Fire Nova, and|r |cRXP_ENEMY_Reclaimers|r |cRXP_WARN_have a high-damage fireball|r
.complete 3505,1 
.complete 3505,2 
.mob Blood Elf Reclaimer
.mob Blood Elf Surveyor
.isOnQuest 3505
step
.goto Azshara,59.40,31.20
>>Click the |cRXP_PICK_Kaldorei Tome of Summoning|r on the pedestal in the summoning circle
>>|cRXP_WARN_If you are not getting the credit for completion, run around the camp until it is done|r
.complete 3505,3 
.complete 3505,4 
.turnin 3505 >>Turn in Betrayed
.isOnQuest 3505
step
.goto Azshara,59.50,31.20
>>Click the |cRXP_PICK_Kaldorei Tome of Summoning|r again
.accept 3506 >>Accept Betrayed
.isQuestTurnedIn 3505
step
#label Magus
.goto Azshara,59.50,31.40
>>Destroy one of the |cRXP_PICK_Arcane Focusing Crystals|r. This will summon a |cRXP_ENEMY_Blood Elf Defender|r
>>After 13 seconds |cRXP_ENEMY_Magus Rimtori|r will spawn. Kill her and loot her for her |cRXP_LOOT_Head|r
.complete 3506,1 
.isQuestTurnedIn 3505
.mob Blood Elf Defender
.unitscan Magus Rimtori
step
#label Tablets
.goto Azshara,39.80,46.81,40,0
.goto Azshara,39.86,48.72,40,0
.goto Azshara,37.30,48.12,40,0
.goto Azshara,38.55,54.58,40,0
.goto Azshara,40.97,55.00,40,0
.goto Azshara,40.81,62.69,40,0
.goto Azshara,42.95,63.76,40,0
.goto Azshara,38.70,63.30,40,0
.goto Azshara,36.35,58.75,40,0
.goto Azshara,35.92,57.55,40,0
.goto Azshara,34.89,53.93,40,0
.goto Azshara,35.86,53.49
>>Loot the |cRXP_PICK_Glowing Tablets|r scattered around the ruins
>>|cRXP_WARN_Tablet spawn spots are random so keep your eyes peeled|r
.complete 3517,1 
.complete 3517,2 
.complete 3517,3 
.complete 3517,4 
step
.goto Azshara,22.60,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.turnin 3517 >>Turn in Stealing Knowledge
.target Jediga
step
.goto Azshara,22.26,51.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ag'tor|r
.turnin 3506 >>Turn in Betrayed
.target Ag'tor Bloodfist
.isQuestTurnedIn 3505
step
.goto Azshara,22.0,49.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kroum|r
.fly Bloodvenom Post >> Fly to Bloodvenom Post in Felwood
.target Kroum
.zoneskip Felwood
step
.requires quest,5242
.goto Felwood,51.20,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.accept 5155 >>Accept Forces of Jaedenar
.target Greta Mosshoof
step
.requires quest,4102
.goto Felwood,46.70,83.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maybess|r
.accept 4102 >>Accept Cleansing Felwood
.target Maybess Riverbreeze
step
#completewith next
.subzone 1763 >> Travel to Jaedenar
step
.requires quest,4642
#loop
.line Felwood,41.2,45.4,43.4,48.2,42.6,50.2,39.6,54.0,40.8,59.8,40.8,66.0,40.2,68.6,38.8,71.6,41.6,71.6,42.0,67.8,40.8,66.0,40.8,59.8,39.6,54.0,41.2,50.6,38.6,49.6,43.4,48.2,41.2,45.4
.goto Felwood,41.20,45.40,25,0
.goto Felwood,43.40,48.20,25,0
.goto Felwood,42.60,50.20,25,0
.goto Felwood,39.60,54.00,25,0
.goto Felwood,40.80,59.80,25,0
.goto Felwood,40.80,66.00,25,0
.goto Felwood,40.20,68.60,25,0
.goto Felwood,38.80,71.60,25,0
.goto Felwood,41.60,71.60,25,0
.goto Felwood,42.00,67.80,25,0
.goto Felwood,40.80,66.00,25,0
.goto Felwood,40.80,59.80,25,0
.goto Felwood,39.60,54.00,25,0
.goto Felwood,41.20,50.60,25,0
.goto Felwood,38.60,49.60,25,0
.goto Felwood,43.40,48.20,25,0
.goto Felwood,41.20,45.40,25,0
>>Kill |cRXP_ENEMY_Cursed Oozes|r and |cRXP_ENEMY_Tainted Oozes|r. Loot them for their |cRXP_LOOT_Slime Samples|r
.collect 12230,35 
.mob Cursed Ooze
.mob Tainted Ooze
step
.requires quest,5242
.goto Felwood,38.45,60.72
>>Kill |cRXP_ENEMY_Jaedenar Hounds|r, |cRXP_ENEMY_Guardians|r, |cRXP_ENEMY_Adepts|r and |cRXP_ENEMY_Cultists|r
>>|cRXP_WARN_Be very careful of|r |cRXP_ENEMY_Jaedenar Adepts|r|cRXP_WARN_; they have blink, as well as a strong fireball and fire blast|r
.complete 5155,1 
.complete 5155,2 
.complete 5155,3 
.complete 5155,4 
.mob Jaedenar Hound
.mob Jaedenar Guardian
.mob Jaedenar Adept
.mob Jaedenar Cultist
step
.requires quest,5242
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5155 >> Turn in Forces of Jaedenar
.accept 5157 >> Accept Collection of the Corrupt Water
.target Greta Mosshoof
step
.requires quest,5242
.goto Felwood,38.55,59.14,50,0
.goto Felwood,35.173,59.778
.use 12922 >>|cRXP_WARN_Use the|r |T132788:0|t[Empty Canteen] |cRXP_WARN_at the Moon Well in the center of Jaedenar|r
.complete 5157,1 
step
.requires quest,5242
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5157 >> Turn in Collection of the Corrupt Water
.accept 5158 >> Accept Seeking Spiritual Aid
.target Greta Mosshoof
step
.requires quest,5242
.goto Felwood,34.4,53.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakkar|r
.fly Ratchet >> Fly to Ratchet in The Barrens
.target Brakkar
step
.requires quest,5242
#label SpiritualAid
.goto The Barrens,65.827,43.776
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Islen Waterseer|r
.turnin 5158 >> Turn in Seeking Spiritual Aid
.timer 48,Seeking Spiritual Aid RP
.accept 5159 >> Accept Cleansed Water Returns to Felwood
.target Islen Waterseer
step
.requires quest,5242
.goto The Barrens,63.0,37.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Bloodvenom Post >> Fly to Bloodvenom Post in Felwood
.target Bragok
.zoneskip Felwood
step
.requires quest,4102
#completewith next
.goto Felwood,55.78,17.11
.subzone 1768 >> Travel to Irontree Cavern
step
.requires quest,4102
.goto Felwood,57.30,17.79
>>Kill |cRXP_ENEMY_Warpwood Moss Flayers|r and |cRXP_ENEMY_Warpwood Shredders|r. Loot them for their |cRXP_LOOT_Blood Ambers|r
.complete 4102,1 
.mob Warpwood Moss Flayer
.mob Warpwood Shredder
step
.requires quest,5242
#completewith next
.goto Felwood,51.21,82.10
.subzone 2479 >> Travel to the Emerald Sanctuary
step
.requires quest,5242
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5159 >> Turn in Cleansed Water Returns to Felwood
.target Greta Mosshoof
step
.requires quest,5242
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.accept 5165 >> Accept Dousing the Flames of Protection
.target Greta Mosshoof
step
.requires quest,5156
.goto Felwood,50.889,81.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn Redfeather|r
.accept 5156 >> Accept Verifying the Corruption
.target Taronn Redfeather
step
.requires quest,5242,5385
#completewith eStart
.goto Felwood,35.367,58.376
.subzone 1770 >> Travel to Shadow Hold
step
.requires quest,5242
#completewith next
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
.requires quest,5385
>>Kill |cRXP_ENEMY_Jaedenar Enforcers|r, |cRXP_ENEMY_Jaedenar Darkweavers|r, |cRXP_ENEMY_Jaedenar Warlocks|r and |cRXP_ENEMY_Jaedenar Legionnaires|r. Loot them for a |T134235:0|t[|cRXP_LOOT_Blood Red Key|r]
>>|cRXP_WARN_Use the |T134235:0|t[|cRXP_LOOT_Blood Red Key|r] to start the quest|r
>>|cRXP_WARN_This will begin an escort quest. Start this escort even if you still need to Extinguish Braziers|r
.collect 13140,1,5202,1 
.accept 5202 >> Accept A Strange Red Key
.use 13140 
.mob Jaedenar Enforcer
.mob Jaedenar Darkweaver
.mob Jaedenar Warlock
.mob Jaedenar Legionnaire
step
.requires quest,5385
#label eStart
.goto Felwood,36.207,55.465
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captured Arko'narin|r
.turnin 5202 >> Turn in A Strange Red Key
.accept 5203,1 >> Accept Rescue From Jaedenar
.target Captured Arko'narin
step
.requires quest,5242
#completewith next
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
.requires quest,5385
.goto Felwood,35.44,59.01
>>|cRXP_WARN_Escort |cRXP_FRIENDLY_Arko'narin|r through Shadow Hold. Once you approach the final |cRXP_PICK_Brazier|r, 3 |cRXP_ENEMY_Felguards|r will spawn which you will have to deal with|r
>>|cRXP_WARN_After exiting Shadow Hold, you will need to kill the |cRXP_ENEMY_Spirit of Trey Lightforge|r. Let |cRXP_FRIENDLY_Arko'narin|r tank him as much as possible|r
.complete 5203,1 
.target Arko'narin
.mob Spirit of Trey Lightforge
step
.requires quest,5242
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
.requires quest,5242
.isQuestComplete 5165
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5165 >> Turn in Dousing the Flames of Protection
.accept 5242 >> Accept A Final Blow
.target Greta Mosshoof
step
.requires quest,5385
.isQuestComplete 5203
.goto Felwood,51.346,82.013
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessir Moonbow|r
.turnin 5203 >> Turn in Rescue From Jaedenar
.accept 5204 >> Accept Retribution of the Light
.target Jessir Moonbow
step
.requires quest,5385
#completewith ShadowLord
.goto Felwood,35.367,58.376
.subzone 1770 >> Travel to Shadow Hold
step
.requires quest,5385
.isQuestTurnedIn 5203
.goto Felwood,38.499,50.414
>>Kill |cRXP_ENEMY_Rakaiah|r
.complete 5204,1 
.mob Rakaiah
step
.requires quest,5385
.isQuestTurnedIn 5203
.goto Felwood,38.499,50.414
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Remains of Trey Lightforge|r
.turnin 5204 >> Turn in Retribution of the Light
.accept 5385 >> Accept The Remains of Trey Lightforge
.target Remains of Trey Lightforge
step
.requires quest,5242
#label ShadowLord
.isQuestTurnedIn 5165
.goto Felwood,38.814,46.782
>>|cRXP_WARN_Continue further into Shadow Hold|r
>>Kill |cRXP_ENEMY_Salia|r, |cRXP_ENEMY_Moora|r and |cRXP_ENEMY_Shadow Lord Fel'dan|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Kill |cRXP_ENEMY_Salia|r first as she casts|r |T136206:0|t[Mind Control]
.complete 5242,1 
.complete 5242,2 
.complete 5242,3 
.mob Salia
.mob Moora
.mob Shadow Lord Fel'dan
step
.requires quest,5242,5385
#completewith next
.goto Felwood,38.744,47.008
+|cRXP_WARN_Perform a Logout skip on the Urn next to |cRXP_ENEMY_Shadow Lord Fel'dan|r to teleport to Irontree Woods|r
.link https://www.twitch.tv/videos/1219250841?t=02h06m57s >> |cRXP_WARN_Click here for video reference|r
.subzoneskip 1770,1
step
.requires quest,5156
>>Kill |cRXP_ENEMY_Entropic Beasts|r and |cRXP_ENEMY_Entropic Horrors|r
>>|cRXP_WARN_Be cautious of the Elite |cRXP_ENEMY_Infernals|r that patrol the Shatter Scar Vale|r
.complete 5156,1 
.goto Felwood,41.535,43.007,50,0
.goto Felwood,40.91,40.37,50,0
.goto Felwood,42.84,37.62,60,0
.goto Felwood,45.43,40.02,60,0
.goto Felwood,41.10,41.06
.complete 5156,2 
.goto Felwood,41.535,43.007,50,0
.goto Felwood,40.91,40.37,50,0
.goto Felwood,42.84,37.62,60,0
.goto Felwood,45.43,40.02,60,0
.goto Felwood,41.10,41.06
.complete 5156,3 
.goto Felwood,41.535,43.007
.mob Entropic Beast
.mob Entropic Horror
step
.requires quest,8461
.goto Felwood,64.769,8.131
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.accept 8461 >> Accept Deadwood of the North
.target Nafien
step
.requires quest,8461
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
.goto Felwood,62.61,10.12
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Den Avengers|r and |cRXP_ENEMY_Deadwood Den Shamans|r
>>|cRXP_WARN_If you find the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r], don't start the quest from this item yet|r
.complete 8461,1 
.complete 8461,2 
.complete 8461,3 
.mob Deadwood Den Watcher
.mob Deadwood Avenger
.mob Deadwood Shaman
step
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
.goto Felwood,62.61,10.12
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Den Avengers|r and |cRXP_ENEMY_Deadwood Den Shamans|r
>>|cRXP_WARN_When you find the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r], don't start the quest from this item yet|r
.collect 20741,1
.mob Deadwood Den Watcher
.mob Deadwood Avenger
.mob Deadwood Shaman
step
.reputation 576,friendly >> Keep Killing Deadwood Ursa until you reach friendly with Timbermaw Hold
step
.goto Moonglade,32.2,66.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faustron|r
.fp Moonglade >> Get the Moonglade flight path
.target Faustron
step
#completewith next
.goto Felwood,65.44,2.81,20,0
.goto Felwood,66.51,2.98,20,0
.goto Felwood,67.82,4.33,20,0
.goto Felwood,67.93,5.11,20,0
.zone Winterspring >>Travel through Timbermaw Hold to Winterspring
step
.requires quest,8464
.goto Felwood,68.30,6.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.accept 8464 >>Accept Winterfall Activity
.target Salfa
step
.requires quest,8464
#loop
.line Winterspring,67.6,34.1,66.4,34.3,65.9,35.3,66.6,36.3,67.5,35.5,68.4,35.7,68.3,37.3,67.5,37.9,66.8,37.3,65.6,37.7,66.7,39.1,68.0,39.4,68.8,37.7,68.4,35.7,67.6,34.1
.goto Winterspring,67.60,34.10,25,0
.goto Winterspring,66.40,34.30,25,0
.goto Winterspring,65.90,35.30,25,0
.goto Winterspring,66.60,36.30,25,0
.goto Winterspring,67.50,35.50,25,0
.goto Winterspring,68.40,35.70,25,0
.goto Winterspring,68.30,37.30,25,0
.goto Winterspring,67.50,37.90,25,0
.goto Winterspring,66.80,37.30,25,0
.goto Winterspring,65.60,37.70,25,0
.goto Winterspring,66.70,39.10,25,0
.goto Winterspring,68.00,39.40,25,0
.goto Winterspring,68.80,37.70,25,0
.goto Winterspring,68.40,35.70,25,0
.goto Winterspring,67.60,34.10,25,0
>>Kill |cRXP_ENEMY_Winterfall Ursa|r, |cRXP_ENEMY_Winterfall Shamans|r and |cRXP_ENEMY_Winterfall Den Watchers|r
.complete 8464,1 
.complete 8464,2 
.complete 8464,3 
.mob Winterfall Shaman
.mob Winterfall Den Watcher
.mob Winterfall Ursa
step
#loop
.line Winterspring,67.6,34.1,66.4,34.3,65.9,35.3,66.6,36.3,67.5,35.5,68.4,35.7,68.3,37.3,67.5,37.9,66.8,37.3,65.6,37.7,66.7,39.1,68.0,39.4,68.8,37.7,68.4,35.7,67.6,34.1
.goto Winterspring,67.60,34.10,25,0
.goto Winterspring,66.40,34.30,25,0
.goto Winterspring,65.90,35.30,25,0
.goto Winterspring,66.60,36.30,25,0
.goto Winterspring,67.50,35.50,25,0
.goto Winterspring,68.40,35.70,25,0
.goto Winterspring,68.30,37.30,25,0
.goto Winterspring,67.50,37.90,25,0
.goto Winterspring,66.80,37.30,25,0
.goto Winterspring,65.60,37.70,25,0
.goto Winterspring,66.70,39.10,25,0
.goto Winterspring,68.00,39.40,25,0
.goto Winterspring,68.80,37.70,25,0
.goto Winterspring,68.40,35.70,25,0
>>Kill |cRXP_ENEMY_Winterfall Ursa|r, |cRXP_ENEMY_Winterfall Shamans|r and |cRXP_ENEMY_Winterfall Den Watchers|r and loot them for |T135816:0|t[|cRXP_LOOT_Winterfall Ritual Totem|r]
.collect 20742,1,8471,1 
.mob Winterfall Shaman
.mob Winterfall Den Watcher
.mob Winterfall Ursa
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Horde
#group RestedXP SoD Preparation
#subgroup Preparation guide
#title 3 - 20 Questlog prep - Kalimdor (H)
#name 3 - 20 Questlog prep - Dungeons and shopping
step
.requires quest,2770,2768,2937
.goto Winterspring,60.4,36.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yugrek|r
.fly Gadgetzan >> Fly to Gadgetzan in Tanaris
.target Yugrek
step
.requires quest,2770
#completewith next
.goto Thousand Needles,70.58,62.69,200 >> Travel to the Shimmering Flats
step
.requires quest,2770
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.accept 2770 >> Accept Gahz'rilla
.target Wizzle Brassbolts
step
.requires quest,2768
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.accept 2768 >> Accept Divino-matic Rod
.target Chief Engineer Bilgewhizzle
step
.requires quest,2770,2768,2937
#label EnterZF
.goto Tanaris,38.91,20.78,40,0
.goto Tanaris,38.731,19.839
>>|cRXP_WARN_Make sure to bring at least one person with|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_if you need to summon Gahzrilla|r
.subzone 978 >> Find a group and enter Zul'Farrak for quests
step
.requires quest,2937
>>Read the tablet to learn a name of the spider god. It can be found in scarab area where |cRXP_ENEMY_Theka the Martyr|r patrols
.complete 2936,1 
.mob Theka the Martyr
.isOnQuest 2936
step
.requires quest,2768
#completewith next
+Ascend the Pyramid
>>Kill the |cRXP_ENEMY_Sandfury Executioner|r. Loot him for the |cRXP_LOOT_Executioner's Key|r
>>|cRXP_WARN_Anyone in the party may loot the|r |cRXP_LOOT_Key|r
>>|cRXP_WARN_Use the|r |cRXP_LOOT_Executioner's Key|r |cRXP_WARN_on one of the |cRXP_PICK_Troll Cages|r to free |cRXP_FRIENDLY_Sergeant Bly|r and his band|r
.collect 8444,1 
.disablecheckbox
.isOnQuest 2768
.mob Sandfury Executioner
step
.requires quest,2768
>>Defend |cRXP_FRIENDLY_Sergeant Bly|r and his band, then move down with them after a short period of time
>>Kill |cRXP_ENEMY_Nekrum Gutchewer|r. Eat and drink then talk to |cRXP_FRIENDLY_Sergeant Bly|r to fight him
>>Kill |cRXP_ENEMY_Sergeant Bly|r. Loot him for the |cRXP_LOOT_Divino-matic Rod|r
.complete 2768,1 
.isOnQuest 2768
.skipgossip
step
.requires quest,2770
#label Gahzrilla
>>|cRXP_WARN_Use the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_on the |cRXP_PICK_Gong of Zul'Farrak|r to summon|r |cRXP_ENEMY_Gahz'rilla|r
>>Kill |cRXP_ENEMY_Gahz'rilla|r. Loot him for |cRXP_LOOT_Gahz'rilla's Electrified Scale|r
>>|cRXP_WARN_If no one in your party has the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_you will not be able to summon|r |cRXP_ENEMY_Gahz'rilla|r
.complete 2770,1 
.mob Gahz'rilla
.isOnQuest 2770
step
.requires quest,7064,7066
.goto Tanaris,51.6,25.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek Ragefist|r
.fly Shadowprey Village >> Fly to Shadowprey Village in Desolace
.target Bulkrek Ragefist
step
.requires quest,7064,
.goto Desolace,26.87,77.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Selendra|r
.accept 7064 >> Accept Corruption of Earth and Seed
.target Selendra
step
.requires quest,7064,7066
#completewith Maraudonend
.goto Desolace,29.89,62.44,0
.goto 2100,38.43,57.97
.subzone 2100 >> Travel to Maraudon and gather a group
step
.requires quest,7064,7066
>>Kill |cRXP_ENEMY_Princess Theradras|r, last boss of the dungeon
.complete 7064,1 
.mob Princess Theradras
.isOnQuest 7064
step
.requires quest,7066
#label Maraudonend
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaetar's Spirit|r after killing |cRXP_ENEMY_Princess Theradras|r
.accept 7066 >> Accept Seed of Life
.target Zaetar's Spirit
step
.requires quest,7064,7066
#completewith next
.zone Desolace >> Exit Maraudon and head back to Shadowprey Village
step << Mage
.cast 3567 >>Cast |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << !Mage
.requires quest,7064,7066
.goto Desolace,21.6,74.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thalon|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Thalon
step << !Mage
.goto Tanaris,51.6,25.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek Ragefist|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Bulkrek Ragefist
.zoneskip Desolace
step
.requires quest,2937
#completewith next
.goto Durotar,56.0,74.6
.zone Durotar >> Run out into Durotar
step
.requires quest,2937
.goto Durotar,56.0,74.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Gadrin|r
.turnin 2936 >>Turn The Spider God
.accept 2937 >>Accept Summoning Shadra
.target Master Gadrin
step
.goto Durotar,50.8,13.6
.zone Tirisfal Glades >> Take a zeppelin to Tirisfal Glades
.zoneskip Tirisfal Glades
step
#completewith next
.goto Tirisfal Glades,61.80,65.06,20,0
.zone Undercity >> Enter Undercity
.zoneskip Undercity
step
.requires quest,4642
.goto Undercity,47.8,73.3
>>Use the |cRXP_PICK_Testing Equipment|r to test all of your samples
.use 15103 >>Open your |T134437:0|t[Corrupt Tested Samples]
.use 15102 >>Open your |T134437:0|t[Un'Goro Tested Samples]
.complete 4293,1 
.complete 4294,1 
step
.requires quest,4642
.goto Undercity,48.50,71.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cuely|r
.turnin 4293 >>Turn in A Sample of Slime...
.turnin 4294 >>Turn in ... and a Match of Ooze
.accept 4642 >>Accept Melding of Influences
.target Chemist Cuely
step
.goto Undercity,63.6,48.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael Garrett|r
.fly Revantusk Village >> Fly to Revantusk Village in The Hinterlands
.target Michael Garrett
step
#loop
.line The Hinterlands,54.0,41.2,51.4,45.6,51.6,62.6,55.0,53.0,65.6,58.6,62.6,41.0,59.0,46.4,54.0,41.2
.goto The Hinterlands,54.00,41.20,25,0
.goto The Hinterlands,51.40,45.60,25,0
.goto The Hinterlands,51.60,62.60,25,0
.goto The Hinterlands,55.00,53.00,25,0
.goto The Hinterlands,65.60,58.60,25,0
.goto The Hinterlands,62.60,41.00,25,0
.goto The Hinterlands,59.00,46.40,25,0
.use 9618 >>Kill |cRXP_ENEMY_Savage Owlbeasts|r and use the |T133841:0|t[Wildkin Muisek Vessel] near their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 3123,1 
.mob Savage Owlbeast
step
.requires quest,2937
.goto The Hinterlands,34,72
>> Go to the bottom of the altar of Shadra'Alor and use |T134937:0|t[Gadrin's Parchment], kill |cRXP_ENEMY_Shadra|r and loot her for her venom
>>|cRXP_WARN_Be very careful when attempting this, using the parchment will remove it from your inventory and you will need to go back to Durotar if you fail|r
.complete 2937,1 
.use 9323
step
.goto The Hinterlands,81.6,81.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorkas|r
.fly Undercity >> Fly back to Undercity
.target Gorkas
step
.goto Tirisfal Glades,61.06,58.86,12,0
.goto Tirisfal Glades,61.51,59.01,10,0
.goto Tirisfal Glades,61.27,59.22,8,0
.goto Tirisfal Glades,61.13,58.84,8,0
.goto Tirisfal Glades,61.38,58.71,8,0
.goto Tirisfal Glades,61.34,59.17,8,0
.goto Tirisfal Glades,60.51,58.69,-1
.goto Tirisfal Glades,60.94,46.35,-1
>>Go up the Zeppelin Tower
.zone Durotar >>Take the Zeppelin to Durotar
.zoneskip Orgrimmar
step
.goto Orgrimmar,45.2,63.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Camp Mojache >> Fly to Camp Mojache in Feralas
.target Doras
step
.goto Feralas,74.50,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.turnin 3123 >>Turn in Testing the Vessel
.accept 3124 >>Accept Hippogryph Muisek
.accept 3128 >>Accept Natural Materials
.target Witch Doctor Uzer'i
step
#completewith next
.goto Feralas,58.0,53.1,50,0
.goto Feralas,54.2,68.6,0
.subzone 1106 >>Travel southwest to the Frayfeather Highlands
step
#loop
.line Feralas,55.6,60.6,55.4,64.2,53.8,66.8,54.6,68.6,54.0,71.6,54.2,72.6,55.6,75.2,57.0,74.8,56.0,72.4,55.0,70.6,56.2,66.0,56.8,65.6,57.4,62.6,55.6,60.6
.goto Feralas,55.60,60.60,25,0
.goto Feralas,55.40,64.20,25,0
.goto Feralas,53.80,66.80,25,0
.goto Feralas,54.60,68.60,25,0
.goto Feralas,54.00,71.60,25,0
.goto Feralas,54.20,72.60,25,0
.goto Feralas,55.60,75.20,25,0
.goto Feralas,57.00,74.80,25,0
.goto Feralas,56.00,72.40,25,0
.goto Feralas,55.00,70.60,25,0
.goto Feralas,56.20,66.00,25,0
.goto Feralas,56.80,65.60,25,0
.goto Feralas,57.40,62.60,25,0
.goto Feralas,55.60,60.60,25,0
.use 9619 >>Kill |cRXP_ENEMY_Frayfeather Hippogryphs|r. Loot them for their |cRXP_LOOT_Fragments|r
>>Use the |T133841:0|t[Hippogryph Muisek Vessel] on their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 3124,1 
.complete 3128,4 
.mob Frayfeather Stagwing
.mob Frayfeather Skystormer
.mob Frayfeather Hippogryph
.mob Frayfeather Patriarch
step
#completewith next
.goto Feralas,75.9,43.7,0
.subzone 1099 >>Travel to Camp Mojache
step
.goto Feralas,74.42,43.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.turnin 3124 >>Turn in Hippogryph Muisek
.accept 3125 >>Accept Faerie Dragon Muisek
.target Witch Doctor Uzer'i
step
.goto Feralas,69.55,46.96,50,0
.goto Feralas,68.82,48.54,50,0
.goto Feralas,67.69,47.95,50,0
.goto Feralas,66.57,47.74,50,0
.goto Feralas,69.55,46.96,50,0
.goto Feralas,68.82,48.54,50,0
.goto Feralas,67.69,47.95
.use 9620 >>Kill |cRXP_ENEMY_Sprite Darters|r. Loot them for their |cRXP_LOOT_Minerals|r.
>>Use the |T133841:0|t[Faerie Dragon Muisek Vessel] on their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 3125,1 
.complete 3128,2 
.mob Sprite Darter
step
.goto Feralas,74.42,43.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.turnin 3125 >>Turn in Faerie Dragon Muisek
.accept 3126 >>Accept Treant Muisek
.target Witch Doctor Uzer'i
step
.goto Feralas,69.4,44.6,70,0
.goto Feralas,70.6,41.8,70,0
.goto Feralas,75.0,38.6,70,0
.goto Feralas,77.4,40.8,70,0
.goto Feralas,78.6,42.4,70,0
.goto Feralas,79.6,45.4,70,0
.goto Feralas,69.4,44.6
.line Feralas,55.8,60.8,55.0,65.0,55.4,66.2,54.4,69.0,55.0,71.6,58.2,74.6
.line Feralas,67.97,59.99,68.99,60.19,69.57,59.39,70.42,57.76,71.48,58.00,72.27,59.39,72.71,58.54,74.24,58.18,74.72,56.33,74.24,58.18,72.89,57.66,72.67,56.02,73.44,54.87,73.60,53.79,73.97,53.33,74.26,53.12,73.94,51.66,72.80,50.88
.line Feralas,78.4,41.8,74.6,38.4,72.4,41.2,70.6,41.8,69.4,44.6
.line Feralas,52.0,47.8,52.8,46.2,55.0,47.6,55.6,47.0
.use 9606 >>Kill |cRXP_ENEMY_Wandering Forest Walkers|r. Loot them for their |cRXP_LOOT_Splintered Logs|r
>>Use the |T133841:0|t[Treant Muisek Vessel] on their corpses
>>|cRXP_WARN_The arrow will guide you along their patrol routes, which are outlined on your world map too. The quest item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.collect 9590,1 
.collect 9593,1 
.unitscan Wandering Forest Walker
step
.goto Feralas,67.97,59.99,70,0
.goto Feralas,68.99,60.19,70,0
.goto Feralas,69.57,59.39,70,0
.goto Feralas,70.42,57.76,70,0
.goto Feralas,71.48,58.00,70,0
.goto Feralas,72.27,59.39,70,0
.goto Feralas,72.71,58.54,70,0
.goto Feralas,74.24,58.18,70,0
.goto Feralas,74.72,56.33,70,0
.goto Feralas,74.24,58.18,70,0
.goto Feralas,72.89,57.66,70,0
.goto Feralas,72.67,56.02,70,0
.goto Feralas,73.44,54.87,70,0
.goto Feralas,73.60,53.79,70,0
.goto Feralas,73.97,53.33,70,0
.goto Feralas,74.26,53.12,70,0
.goto Feralas,73.94,51.66,70,0
.goto Feralas,72.80,50.88,70,0
.line Feralas,55.8.,60.8,55.0,65.0,55.4,66.2,54.4,69.0,55.0,71.6,58.2,74.6
.line Feralas,67.97,59.99,68.99,60.19,69.57,59.39,70.42,57.76,71.48,58.00,72.27,59.39,72.71,58.54,74.24,58.18,74.72,56.33,74.24,58.18,72.89,57.66,72.67,56.02,73.44,54.87,73.60,53.79,73.97,53.33,74.26,53.12,73.94,51.66,72.80,50.88
.line Feralas,78.4,41.8,74.6,38.4,72.4,41.2,70.6,41.8,69.4,44.6
.line Feralas,52.0,47.8,52.8,46.2,55.0,47.6,55.6,47.0
.use 9606 >>Kill |cRXP_ENEMY_Wandering Forest Walkers|r. Loot them for their |cRXP_LOOT_Splintered Logs|r
>>Use the |T133841:0|t[Treant Muisek Vessel] on their corpses
>>|cRXP_WARN_The arrow will guide you along their patrol routes, which are outlined on your world map too. The quest item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.collect 9590,2 
.collect 9593,2 
.unitscan Wandering Forest Walker
step
.goto Feralas,58.6,52.0,70,0
.goto Feralas,60.0,48.8,70,0
.goto Feralas,57.8,48.0,70,0
.goto Feralas,55.6,47.0,70,0
.goto Feralas,53.2,46.6,70,0
.goto Feralas,51.6,49.0,70,0
.goto Feralas,58.6,52.0
.line Feralas,55.8.,60.8,55.0,65.0,55.4,66.2,54.4,69.0,55.0,71.6,58.2,74.6
.line Feralas,67.97,59.99,68.99,60.19,69.57,59.39,70.42,57.76,71.48,58.00,72.27,59.39,72.71,58.54,74.24,58.18,74.72,56.33,74.24,58.18,72.89,57.66,72.67,56.02,73.44,54.87,73.60,53.79,73.97,53.33,74.26,53.12,73.94,51.66,72.80,50.88
.line Feralas,78.4,41.8,74.6,38.4,72.4,41.2,70.6,41.8,69.4,44.6
.line Feralas,52.0,47.8,52.8,46.2,55.0,47.6,55.6,47.0
.use 9606 >>Kill |cRXP_ENEMY_Wandering Forest Walkers|r. Loot them for their |cRXP_LOOT_Splintered Logs|r
>>Use the |T133841:0|t[Treant Muisek Vessel] on their corpses
>>|cRXP_WARN_The arrow will guide you along their patrol routes, which are outlined on your world map too. The quest item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.collect 9593,3 
.unitscan Wandering Forest Walker
step
#completewith next
.goto Feralas,75.9,43.7,0
.subzone 1099 >>Travel to Camp Mojache
step
.goto Feralas,74.42,43.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.turnin 3126 >>Turn in Treant Muisek
.accept 3127 >>Accept Mountain Giant Muisek
.target Witch Doctor Uzer'i
step
.requires quest,3062
.goto Feralas,76.20,43.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talo|r
.accept 3062 >>Accept Dark Heart
.target Talo Thornhoof
step
#completewith next
.goto Feralas,51.89,49.82,30,0
.goto Feralas,48.82,45.15,30,0
.goto Feralas,45.67,46.94,30,0
.subzone 1108 >>Travel west to The Forgotten Coast
step
.goto Feralas,44.81,43.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zorbin|r
.accept 7003 >>Accept Zapped Giants
.target Zorbin Fandazzle
step
#loop
.line Feralas,41.08,24.52,39.36,24.29,38.38,22.21,38.52,20.83,39.47,22.04,41.08,24.52
.goto Feralas,41.08,24.52,25,0
.goto Feralas,39.36,24.29,25,0
.goto Feralas,38.38,22.21,25,0
.goto Feralas,38.52,20.83,25,0
.goto Feralas,39.47,22.04,25,0
.goto Feralas,41.08,24.52,25,0
.use 18904 >>Use |T133003:0|t[Zorbin's Ultra-Shrinker] on |cRXP_ENEMY_Land Walkers|r and |cRXP_ENEMY_Cliff Giants|r. Kill them and loot their |cRXP_LOOT_Residue|r
.use 9621 >>Use the |T133841:0|t[Mountain Giant Muisek Vessel] on their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 3127,1 
.mob Land Walker
.mob Cliff Giant
step
.isQuestComplete 3127
.abandon 7003 >> Abandon Zapped Giants
step
.requires quest,3062
.goto Feralas,40.56,8.58
.use 9530 >>Use the |T134228:0|t[Horn of Hatetalon] to summon |cRXP_ENEMY_Edana Hatetalon|r. Kill her and loot her for her |cRXP_LOOT_Heart|r
.complete 3062,1 
.unitscan Edana of Hatetalon
step
#completewith next
.goto Feralas,75.9,43.7,0
.subzone 1099 >>Travel to Camp Mojache
step
.goto Feralas,74.42,43.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.turnin 3128 >>Turn in Natural Materials
.turnin 3127 >>Turn in Mountain Giant Muisek
.target Witch Doctor Uzer'i
step
.requires quest,4642
.goto Feralas,75.4,44.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Marshal's Refuge >> Fly to Marshal's Refuge in Un'goro Crater
.target Shyn
step
.goto Feralas,75.4,44.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Ratchet >> Fly to Ratchet in The Barrens
.target Shyn
.zoneskip Feralas,1
step
.requires quest,4642
.goto Un'Goro Crater,51.6,34.8,40,0
.goto Un'Goro Crater,51.6,30.6,40,0
.goto Un'Goro Crater,47.6,26.8,40,0
.goto Un'Goro Crater,45.2,22.8,40,0
.goto Un'Goro Crater,54.0,18.6,40,0
.goto Un'Goro Crater,56.6,18.4,40,0
.use 12288 >>Let a |cRXP_ENEMY_Primal Ooze|r hit you in combat, then use the |T132622:0|t[Encased Corrupt Ooze]
>>Kill the |cRXP_ENEMY_Gargantuan Ooze|r. Loot it for its |cRXP_LOOT_Merged Ooze Sample|r
>>|cRXP_WARN_You can only use the quest item once. Let the ooze attack you before you release your own|r
.complete 4642,1 
.mob Primal Ooze
.unitscan Gargantuan Ooze
step
.requires quest,4642
.goto Un'Goro Crater,45.2,5.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryfe|r
.fly Ratchet >> Fly to Ratchet in The Barrens
.target Gryfe
step
.goto The Barrens,63.74,38.66
.zone Stranglethorn Vale >>Take the boat to Stranglethorn Vale
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 2767 >> Turn in Rescue OOX-22/FE!
.target Oglethorpe Obnoticus
step
.requires !quest,648
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 648 >> Turn in Rescue OOX-17/TN!
.target Oglethorpe Obnoticus
step
.requires !quest,836
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 836 >> Turn in Rescue OOX-09/HL!
.target Oglethorpe Obnoticus
step
.requires quest,3907,7201,4123
.goto Stranglethorn Vale,26.8,77.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Kargath >> Fly to Kargath in Badlands
.target Gringer
step
.requires quest,3907
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
.accept 3907 >>Accept Disharmony of Fire
.goto Badlands,3.6,48.0
.target Thunderheart
step
.requires quest,7201
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shadowmage Vivian Lagrave|r
.accept 7201 >>Accept The Last Element
.goto Badlands,3.0,47.6
.target Shadowmage Vivian Lagrave
step
.requires quest,4123
.goto Burning Steppes,65.6,24.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vahgruk|r
.fly Flame Crest >> Fly to Flame Crest in Burning Steppes
.target Vahgruk
step
.requires quest,4123
>>Ride through the Searing Gorge, Blackrock Mountain and into Burning Steppes in the south
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.goto Burning Steppes,65.2,23.8
.accept 4123 >>Accept The Heart of the Mountain
.target Maxwort Uberglint
step
.requires quest,3907,7201,4123
#completewith HartoftheMountain
.subzone 1584 >> Find a group for Blackrock Depths
>>|cRXP_WARN_Be aware that this is level 55 content and you need a strong group for it|r
step
#completewith lordincendius
>>Kill all Elementals, Golems and golem makers you come across and loot them for |cRXP_LOOT_Essence of the Elements|r
.collect 11129,10,7201,1 
step
.requires quest,3907
#label lordincendius
>>Make your way to the great forge and kill |cRXP_ENEMY_Lord Incendius|r
.complete 3907,1 
step
.requires quest,7201
>>Gather the remaining |cRXP_LOOT_Essence of the Elements|r from Elementals, Golems and golem makers
.collect 11129,10,7201,1 
step
.requires quest,4123
>>Make your way to the Dark Iron vault and kill |cRXP_ENEMY_Watchman Doomgrip|r, after he is dead you can loot the Heart from one of the small vaults in the back
#label HartoftheMountain
.collect 11309,1,4123,1 
.mob Watchman Doomgrip
step
.goto Searing Gorge,34.8,30.8
.zone Undercity >> Make your way to a capital of your choice. If you exit BRD on foot, closest flight path is in Thorium point.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grisha|r
.fly Undercity >> Fly to Undercity
.target Grisha
step
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.blastedLands
.target Auctioneer Rhyker
step
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 2592,60,7813,7820,7826,7833 
.target Auctioneer Rhyker
step
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 4306,60,7827,7834,7814,7827 
.target Auctioneer Rhyker
step
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 4338,60,7831,7817,7822,7835 
.target Auctioneer Rhyker
step
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 14047,60,7824,7836,7818,7823,6031 
.target Auctioneer Rhyker
step
.isQuestAvailable 6032
.skill tailoring,<280,1
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 14342,2 
.target Auctioneer Rhyker
step
.isQuestAvailable 3501
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 10593,1 
.target Auctioneer Rhyker
step
.isQuestAvailable 3761
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11018,20 
.target Auctioneer Rhyker
step
.isQuestAvailable 3761
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11040,10 
.target Auctioneer Rhyker
step
.isQuestTurnedIn 3761
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11040,10 
.target Auctioneer Rhyker
step
.isQuestAvailable 3786
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11040,10 
.target Auctioneer Rhyker
step
.isQuestAvailable 6610
.skill cooking,<225,1
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 12207,12 
.collect 7974,10 
.target Auctioneer Rhyker
step
+Congratulations on finishing the prep guide! Make sure to click through the turn in guide and check out your turn in route.
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Alliance
#group RestedXP SoD Preparation
#subgroup Preparation guide
#title 1 - 20 Questlog prep - Eastern Kingdoms
#name 1 - 20 Questlog prep - Eastern Kingdoms (A)
#next 2 - 20 Questlog prep - Kalimdor
step
+Welcome to the RXP preparation guide for Season of Discovery! Check this step when you are ready to start.
step << Mage
.cast 3562 >>Cast |T135757:0|t[Teleport: Ironforge]
.zoneskip Ironforge
step << !Mage
.goto Ironforge,30.4,67.6
>>Make your way to Ironforge
.zoneskip Ironforge
step
.goto Ironforge,31.6,65.4,30,0
.goto Ironforge,50.8,80.8,30,0
.goto Ironforge,66.6,75.0,30,0
.goto Ironforge,71.0,38.8,30,0
.goto Ironforge,58.6,13.4,30,0
.goto Ironforge,32.6,21.0,30,0
.goto Ironforge,40.0,38.8,30,0
.goto Ironforge,55.6,35.8,30,0
.goto Ironforge,55.6,52.6,30,0
.goto Ironforge,46.6,47.6,30,0
.goto Ironforge,34.8,32.2,30,0
.goto Ironforge,25.4,28.4,30,0
.goto Ironforge,23.2,62.0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Courier Hammerfall|r
>>|cRXP_WARN_He patrols around the outer circle of the city, visiting all the districts as well as around the great forge|r
.accept 5090 >>Accept A Call to Arms: The Plaguelands!
.target Courier Hammerfall
step
.goto Ironforge,55.6,48.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
.fly Chillwind Camp >> Fly to Chillwind Camp in Western Plaguelands
.target Gryth Thurden
.zoneskip Western Plaguelands
step
.requires quest,211,5901
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5090 >> Turn in A Call to Arms: The Plaguelands!
.accept 5092 >> Accept Clear the Way
.target Commander Ashlam Valorfist
step
.requires quest,211,5901
.goto Western Plaguelands,48.91,80.84,70,0
.goto Western Plaguelands,50.01,76.90
>>Kill |cRXP_ENEMY_Skeletal Flayers|r and |cRXP_ENEMY_Slavering Ghouls|r
.complete 5092,1 
.complete 5092,2 
.mob Skeletal Flayer
.mob Slavering Ghoul
step
.requires quest,5153
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.accept 5142 >> Accept Little Pamela
.target Marlene Redpath
step
.requires quest,211,5901
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5092 >> Turn in Clear the Way
.target Commander Ashlam Valorfist
step
.requires quest,211
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.accept 5097 >> Accept All Along the Watchtowers
.target Commander Ashlam Valorfist
step
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.accept 5215 >> Accept The Scourge Cauldrons
.target Commander Ashlam Valorfist
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5215 >> Turn in The Scourge Cauldrons
.accept 5216 >> Accept Target: Felstone Field
.target High Priestess MacDonnell
step
.requires quest,5901
#label TravelWPL
.goto Western Plaguelands,43.419,84.834
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathaniel Dumah|r
.accept 5903 >> Accept A Plague Upon Thee
.target Nathaniel Dumah
step
.goto Western Plaguelands,37.015,57.145
>>Kill |cRXP_ENEMY_Cauldron Lord Bilemaw|r. Loot him for the |cRXP_LOOT_Felstone Field Cauldron Key|r
>>|cRXP_ENEMY_Cauldron Lord Bilemaw|r |cRXP_WARN_may spawn as you approach the|r |cRXP_PICK_Cauldron|r
.complete 5216,1 
.unitscan Cauldron Lord Bilemaw
step
.goto Western Plaguelands,37.194,56.860
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5216 >> Turn in Target: Felstone Field
.accept 5217 >> Accept Return to Chillwind Camp
step
#completewith next
.goto Western Plaguelands,38.05,54.59,12 >>Go inside the house
step
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice Felstone|r up stairs
.accept 5021 >>Accept Better Late Than Never
.target Janice Felstone
step
#completewith next
.goto Western Plaguelands,38.05,54.56,8,0
>>Exit the house
.goto Western Plaguelands,38.58,55.33,6 >>Go inside the barn
step
.goto Western Plaguelands,38.72,55.24
>>Click |cRXP_PICK_Janice's Parcel|r on the ground
>>|cRXP_WARN_This has a 5 second cast time|r
>>|cRXP_WARN_You can do this from behind the wall to avoid aggroing anything inside|r
>>|cRXP_WARN_Avoid aggroing the |cRXP_ENEMY_Scarlets|r outside the barn. If you do, run away|r
.turnin 5021 >>Turn in Better Late Than Never
.accept 5022 >>Accept Better Late Than Never
step
#completewith next
.subzone 3197 >> Travel to Chillwind Camp
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5217 >> Turn in Return to Chillwind Camp
.accept 5219 >> Accept Target: Dalson's Tears
.target High Priestess MacDonnell
step
.requires quest,211
.goto Western Plaguelands,46.681,71.135,-1
.goto Western Plaguelands,46.558,71.156,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance. You can do this without aggroing the Elite |cRXP_ENEMY_Skeletal Warlord|r inside|r
.complete 5097,4 
step
#label DalsonCauldron
.goto Western Plaguelands,46.176,52.009
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5219 >> Turn in Target: Dalson's Tears
.accept 5220 >> Accept Return to Chillwind Camp
step
.requires quest,211
.goto Western Plaguelands,44.217,63.319,-1
.goto Western Plaguelands,44.247,63.131,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance. You can do this without aggroing the Elite |cRXP_ENEMY_Skeletal Warlord|r inside|r
.complete 5097,3 
step
.requires quest,211
.goto Western Plaguelands,42.326,66.105,-1
.goto Western Plaguelands,42.422,66.222,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance. You can do this without aggroing the Elite |cRXP_ENEMY_Skeletal Warlord|r inside|r
.complete 5097,2 
step
.requires quest,211
.goto Western Plaguelands,40.116,71.561,-1
.goto Western Plaguelands,40.038,71.713,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance. You can do this without aggroing the Elite |cRXP_ENEMY_Skeletal Warlord|r inside|r
.complete 5097,1 
step
#completewith next
.subzone 3197 >> Travel to Chillwind Camp
step
.requires quest,211
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5097 >> Turn in All Along the Watchtowers
.accept 211 >> Accept Alas, Andorhal
.target Commander Ashlam Valorfist
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.target High Priestess MacDonnell
.turnin 5220 >> Turn in Return to Chillwind Camp
.accept 5222 >> Accept Target: Writhing Haunt
step
.requires quest,211
.isQuestTurnedIn 5097
.destroy 12815 >> Delete the |T135432:0|t[Beacon Torch]
step
.requires quest,211
.goto Western Plaguelands,45,69
>>Kill |cRXP_ENEMY_Araj the Summoner|r. Loot his Phylactery for |cRXP_LOOT_Araj's Phylactery Shard|r
>>|cRXP_WARN_This quest is quite difficult so you should seek help if you can't solo it|r
.complete 211,1 
.mob Araj the Summoner
step
.goto Western Plaguelands,53.021,66.052
>>Kill |cRXP_ENEMY_Cauldron Lord Razarch|r. Loot him for the |cRXP_LOOT_Writhing Haunt Cauldron Key|r
>>|cRXP_ENEMY_Cauldron Lord Razarch|r |cRXP_WARN_may spawn as you approach the|r |cRXP_PICK_Cauldron|r
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_cast|r |T135848:0|t[Flash Freeze]|cRXP_WARN_. This ability stuns for 5 seconds. Avoid aggroing multiple at the same time at all costs|r
.complete 5222,1 
.unitscan Cauldron Lord Razarch
step
.goto Western Plaguelands,53.020,65.718
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5222 >> Turn in Target: Writhing Haunt
.accept 5223 >> Accept Return to Chillwind Camp
step
#completewith next
.goto Eastern Plaguelands,36.6,90.8,50 >> Travel toward |cRXP_FRIENDLY_Pamela Redpath|r in the Eastern Plaguelands
step
.requires quest,5153
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.turnin 5142 >>Turn in Little Pamela
.accept 5149 >>Accept Pamela's Doll
.target Pamela Redpath
step
.requires quest,5153
.goto Eastern Plaguelands,38.10,92.24
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12886,1,5149,1 
.unitscan Ghost of the Past
step
.requires quest,5153
.goto Eastern Plaguelands,39.64,92.51
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12887,1,5149,1 
.unitscan Ghost of the Past
step
.requires quest,5153
.goto Eastern Plaguelands,39.67,90.24
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12888,1,5149,1 
.unitscan Ghost of the Past
step
.requires quest,5153
.goto Eastern Plaguelands,36.47,90.80
.use 12886 >>Click |T134164:0|t[Pamela's Doll's Head] to combine the three pieces
.complete 5149,1 
step
.requires quest,5153
#label Pamela
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.turnin 5149 >>Turn in Pamela's Doll
.accept 5152 >>Accept Auntie Marlene
.target Pamela Redpath
step
.requires quest,5903
.goto Eastern Plaguelands,41.2,25.2,70,0
.goto Eastern Plaguelands,42.1,38.2,70,0
.goto Eastern Plaguelands,32.0,35.8,70,0
.goto Eastern Plaguelands,33.8,25.8,70,0
.goto Eastern Plaguelands,29.9,23.1,70,0
.goto Eastern Plaguelands,26.5,37.5,70,0
.goto Eastern Plaguelands,20.4,20.8,70,0
.goto Eastern Plaguelands,31.4,29.6
>>Open the |cRXP_PICK_Large Termite Mounds|r throughout Plaguewood. Loot them for the |cRXP_LOOT_Plagueland Termites|r
.complete 5903,1 
step
.requires quest,5153
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.turnin 5152 >> Turn in Auntie Marlene
.accept 5153 >> Accept A Strange Historian
.target Marlene Redpath
step
.requires quest,5153
.goto Western Plaguelands,49.696,76.754
>>Click |cRXP_PICK_Joseph Redpath's Monument|r. Loot it for |cRXP_LOOT_Joseph's Wedding Ring|r
.complete 5153,1 
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5223 >> Turn in Return to Chillwind Camp
.accept 5225 >> Accept Target: Gahrron's Withering
.target High Priestess MacDonnell
step
.goto Western Plaguelands,62.644,58.945
>>Kill |cRXP_ENEMY_Cauldron Lord Soulwrath|r. Loot him for the |cRXP_LOOT_Gahrron's Withering Cauldron Key|r
>>|cRXP_ENEMY_Cauldron Lord Soulwrath|r |cRXP_WARN_may spawn as you approach the|r |cRXP_PICK_Cauldron|r
.complete 5225,1 
.unitscan Cauldron Lord Soulwrath
step
.goto Western Plaguelands,62.573,58.573
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5225 >> Turn in Target: Gahrron's Withering
.accept 5226 >> Accept Return to Chillwind Camp
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5226 >> Turn in Return to Chillwind Camp
.target High Priestess MacDonnell
step
.goto Western Plaguelands,42.8,85.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bibilfaz Featherwhistle|r
.fly Aerie Peak >> Fly to Aerie Peak in The Hinterlands
.target Bibilfaz Featherwhistle
step
.requires quest,2994
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.accept 2988 >> Accept Witherbark Cages
.target Gryphon Master Talonaxe
step
.requires quest,2994
.goto The Hinterlands,31.98,57.31
>>Click the |cRXP_PICK_Third Witherbark Cage|r
.complete 2988,3 
step
.requires quest,2994
#label FinalCages
>>Click the |cRXP_PICK_First Witherbark Cage|r and |cRXP_PICK_Second Witherbark Cage|r
.complete 2988,1 
.goto The Hinterlands,23.28,58.81
.complete 2988,2 
.goto The Hinterlands,23.12,58.82
step
.requires quest,2994
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.turnin 2988 >> Turn in Witherbark Cages
.accept 2989 >> Accept The Altar of Zul
.target Gryphon Master Talonaxe
step
.requires quest,2994
.goto The Hinterlands,48.814,68.387
>>|cRXP_WARN_Clear your way to the top of The Altar of Zul. Ensure you are on full HP before you reach the top!|r
>>|cRXP_WARN_Run to the exploration location, then jump off to the side to evade the Elites at the top. Wait on the ledge until you have dropped Combat. Watch the video below for an example|r
.complete 2989,1 
.link https://www.youtube.com/watch?v=FtTS3K7T7Tw >> |cRXP_WARN_Click here for video reference|r
step
.requires quest,2994
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.turnin 2989 >> Turn in The Altar of Zul
.accept 2990 >> Accept Thadius Grimshade
.target Gryphon Master Talonaxe
step
.requires quest,8114
.goto The Hinterlands,11.071,46.153
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guthrum Thunderfist|r
.fly Refuge Point >> Fly to Refuge Point in Arathi Highlands
.target Guthrum Thunderfist
step
.requires quest,8114
#completewith next
>>|cRXP_WARN_To accept this quest you need friendly reputation with The League of Arathor, which can be gained in Arathi Basin Battleground|r
.goto Arathi Highlands,45.8,45.6
.reputation 509,friendly
step
.requires quest,8114
.goto Arathi Highlands,45.8,45.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Marshal Oslight|r
>>|cRXP_WARN_Feel free to try and complete this quest at any point when you feel like PvP-ing|r
.accept 8114 >>Accept Take Control Four Bases
.target Field Marshal Oslight
step << Mage
.cast 3562 >>Cast |T135757:0|t[Teleport: Ironforge]
.zoneskip Ironforge
step << !Mage
.goto Arathi Highlands,45.6,46.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cedrik Prose|r
.fly Ironforge >> Fly to Ironforge
.target Cedrik Prose
step
.requires quest,3461
.goto Ironforge,77.539,11.834
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Historian Karnik|r
.accept 3448 >> Accept Passing the Burden
.target Historian Karnik
step
.requires quest,3461
.goto Ironforge,30.96,4.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tymor|r
.turnin 3448 >> Turn in Passing the Burden
.accept 3449 >> Accept Arcane Runes
.accept 3450 >> Accept An Easy Pickup
.target Tymor
step
.requires quest,3461
#label CHam
.goto Ironforge,70.860,94.570
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xiggs Fuselighter|r
.turnin 3450 >> Turn in An Easy Pickup
.accept 3451 >> Accept Signal for Pickup
.turnin 3451 >> Turn in Signal for Pickup
.target Xiggs Fuselighter
step
.goto Ironforge,55.6,48.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
.fly Thorium Point >> Fly to Thorium Point in Searing Gorge
.target Gryth Thurden
step
.requires quest,3463
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.accept 3441 >> Accept Divine Retribution
.target Velarok Windblade
step
.requires quest,3463
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.skipgossip
.complete 3441,1 
.target Velarok Windblade
step
.requires quest,3463
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3441 >> Turn in Divine Retribution
.accept 3442 >> Accept The Flawless Flame
.target Velarok Windblade
step
.requires quest,3463
#label FlawlessFlame
.goto Searing Gorge,43.83,35.08,0
.goto Searing Gorge,24.18,54.52,0
.goto Searing Gorge,28.54,64.55,0
.goto Searing Gorge,43.83,35.08,70,0
.goto Searing Gorge,24.18,54.52,70,0
.goto Searing Gorge,28.54,64.55,70,0
.goto Searing Gorge,30.10,76.16,70,0
.goto Searing Gorge,28.54,64.55,70,0
.goto Searing Gorge,24.18,54.52,70,0
.goto Searing Gorge,43.83,35.08,70,0
.goto Searing Gorge,43.83,35.08,70,0
.goto Searing Gorge,24.18,54.52,70,0
.goto Searing Gorge,28.54,64.55,70,0
.goto Searing Gorge,30.10,76.16
>>Kill |cRXP_ENEMY_Inferno Elementals|r, |cRXP_ENEMY_Blazing Elementals|r and |cRXP_ENEMY_Magma Elementals|r. Loot them for their |cRXP_LOOT_Heart of Flames|r
>>Kill |cRXP_ENEMY_Heavy War Golems|r and |cRXP_ENEMY_Magma Elementals|r. Loot them for their |cRXP_LOOT_Golem Oils|r
>>|cRXP_WARN_Prioritize these two objectives|r
.complete 3442,1 
.complete 3442,2 
.mob Inferno Elemental
.mob Blazing Elemental
.mob Magma Elemental
.mob Heavy War Golem
step
.requires quest,3463
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3442 >> Turn in The Flawless Flame
.accept 3443 >> Accept Forging the Shaft
.target Velarok Windblade
step
.requires quest,3463
.goto Searing Gorge,43.18,35.09,60,0
.goto Searing Gorge,43.54,31.51,60,0
.goto Searing Gorge,45.81,25.66,60,0
.goto Searing Gorge,43.18,35.09
>>Kill |cRXP_ENEMY_Dark Iron Taskmasters|r and |cRXP_ENEMY_Dark Iron Slavers|r. Loot them for their |cRXP_LOOT_Thorium Plated Daggers|r
.complete 3443,1 
.mob Dark Iron Taskmaster
.mob Dark Iron Slaver
step
.requires quest,3463
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3443 >> Turn in Forging the Shaft
.accept 3452 >> Accept The Flame's Casing
.target Velarok Windblade
step
.requires quest,3463
.goto Searing Gorge,22.98,37.82,70,0
.goto Searing Gorge,27.10,24.40,60,0
.goto Searing Gorge,22.98,37.82
>>Kill |cRXP_ENEMY_Twilight Dark Shamans|r, |cRXP_ENEMY_Twilight Fire Guards|r, |cRXP_ENEMY_Twilight Geomancers|r and |cRXP_ENEMY_Twilight Idolaters|r. Loot them for the |cRXP_LOOT_Symbol of Ragnaros|r
.complete 3452,1 
.mob Twilight Dark Shaman
.mob Twilight Fire Guard
.mob Twilight Geomancer
.mob Twilight Idolater
step
.requires quest,3463
.isQuestComplete 3452
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3452 >> Turn in The Flame's Casing
.accept 3453 >> Accept The Torch of Retribution
.timer 28,The Torch of Retribution RP
.turnin 3453 >> Turn in The Torch of Retribution
.accept 3454 >> Accept The Torch of Retribution
.target Velarok Windblade
step
.requires quest,3463
.isQuestTurnedIn 3452
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.accept 3453 >> Accept The Torch of Retribution
.timer 28,The Torch of Retribution RP
.turnin 3453 >> Turn in The Torch of Retribution
.accept 3454 >> Accept The Torch of Retribution
.target Velarok Windblade
step
.requires quest,3463
.isQuestTurnedIn 3452
.goto Searing Gorge,39.055,39.067
>>Click on the |cRXP_PICK_Torch of Retribution|r
.turnin 3454 >> Turn in The Torch of Retribution
step
.requires quest,3463
.isQuestTurnedIn 3452
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r and |cRXP_FRIENDLY_Squire Maltrake|r
.accept 3462 >> Accept Squire Maltrake
.goto Searing Gorge,39.057,38.990
.turnin 3462 >> Turn in Squire Maltrake
.accept 3463 >> Accept Set Them Ablaze!
.goto Searing Gorge,39.165,38.997
.target Velarok Windblade
.target Squire Maltrake
step
.requires quest,3463
.isQuestTurnedIn 3452
>>Click the |cRXP_PICK_Sentry Braziers|r atop the Towers
>>|cRXP_WARN_You must have the|r |T135466:0|t[Torch of Retribution] |cRXP_WARN_equiped|r
.use 10515 
.complete 3463,4 
.goto Searing Gorge,33.303,54.477
.complete 3463,1 
.goto Searing Gorge,35.667,60.682
.complete 3463,2 
.goto Searing Gorge,44.030,60.908
.complete 3463,3 
.goto Searing Gorge,50.069,54.737
step
.goto Searing Gorge,71.92,73.79,50,0
.goto Searing Gorge,72.64,79.74
>>Kill |cRXP_ENEMY_Margol the Rager|r. Loot it for |T134229:0|t[|cRXP_LOOT_Margol's Horn|r]
.collect 10000,1,3181,1 
.mob Margol the Rager
step
.requires quest,3566
.goto Searing Gorge,63.879,60.978
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dorius Stonetender|r
>>|cRXP_WARN_This will start an escort. Clear the surrounding area of the pit before accepting this quest|r
.accept 3367 >> Accept Suntara Stones
.target Dorius Stonetender
step
.requires quest,3566
.goto Searing Gorge,74.448,19.287
>>Escort |cRXP_FRIENDLY_Dorius|r to the Loch Modan Pass Gate
.complete 3367,1 
.target Dorius Stonetender
step
.requires quest,3566
#label EscortDorius
.goto Searing Gorge,74.448,19.287
>>Click the |cRXP_PICK_Singed Letter|r on the ground
>>|cRXP_WARN_If the |cRXP_PICK_Singed Letter|r has not spawned, you will need to abandon Suntara Stones and complete the escort again. This is a bug with WoW Classic|r
.turnin 3367 >> Turn in Suntara Stones
.accept 3368 >> Accept Suntara Stones
step << !Mage
.requires quest,3566
#completewith next
.goto Searing Gorge,31.70,34.18,30,0
.goto Searing Gorge,34.31,26.41
.subzone 1446 >> Travel to Thorium Point
.zoneskip Ironforge
step << !Mage
.requires quest,3566
.goto Searing Gorge,37.934,30.861
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanie Reed|r
.fly Ironforge >> Fly to Ironforge
.target Lanie Reed
.zoneskip Ironforge
step << Mage
.requires quest,3566
.cast 3562 >>Cast |T135757:0|t[Teleport: Ironforge]
.zoneskip Ironforge
step
.requires quest,3566
.isQuestComplete 3368
.goto Ironforge,71.83,16.12,30,0
.goto Ironforge,77.02,26.38,30,0
.goto Ironforge,64.03,4.20,30,0
.goto Ironforge,71.83,16.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curator Thorius|r
>>|cRXP_FRIENDLY_Curator Thorius|r |cRXP_WARN_patrols through the Hall of Explorers|r
.turnin 3368 >> Turn in Suntara Stones
.accept 3371 >> Accept Dwarven Justice
.target Curator Thorius
step
.requires quest,3566
.goto Ironforge,55.6,48.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
.fly Thorium Point >> Fly back to Thorium Point in Searing Gorge
.target Gryth Thurden
.zoneskip Searing Gorge
step
.requires quest,3566
#completewith next
.goto Searing Gorge,49.75,45.82,35
.subzone 1443 >> Jump down to the platform below, then follow the platform to the upper entrance of the cave.
step
.requires quest,3566
.goto Searing Gorge,41.163,25.537
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Dying Archaeologist|r
.turnin 3371 >> Turn in Dwarven Justice
.accept 3372 >> Accept Release Them
.target Dying Archaeologist
step
.requires quest,3566
#completewith next
+Logout skip out of the cave. There are MANY different spots you can use
.link https://www.youtube.com/watch?v=-mcsjDkeSUw >> |cRXP_WARN_Click here for video reference|r
step
.requires quest,3566
.isOnQuest 3372
.goto Searing Gorge,24.61,30.97,25,0
.goto Searing Gorge,29.144,25.849
>>Open the |cRXP_PICK_Twilight Artifact|r. Loot it for the |cRXP_LOOT_Mysterious Artifact|r
>>|cRXP_WARN_Jump onto the |cRXP_PICK_Twilight Artifact|r to loot it|r
>>|cRXP_WARN_Skip this step if you are unable to complete it|r
.complete 3372,1 
step
.requires quest,3566
#completewith next
.isQuestComplete 3372
.goto Searing Gorge,49.56,45.38
.subzone 1443 >> Jump down into The Slag Pit. Follow the arrow
step
.requires quest,3566
.isQuestComplete 3372
.goto Searing Gorge,41.252,25.408
>>Click the |cRXP_PICK_Altar of Suntara|r
.turnin 3372 >> Turn in Release Them
step
.requires quest,3566
.isQuestTurnedIn 3372
.goto Searing Gorge,41.163,25.541
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dying Archaeologist|r
.target Dying Archaeologist
.accept 3566 >> Accept Rise, Obsidion!
step
.requires quest,3566
.isQuestTurnedIn 3372
>>Kill |cRXP_ENEMY_Lathoric the Black|r and |cRXP_ENEMY_Obsidion|r. Loot them for the |cRXP_LOOT_Head of Lathoric the Black|r and the |cRXP_LOOT_Heart of Obsidion|r
.complete 3566,1 
.complete 3566,2 
.mob Lathoric the Black
.mob Obsidion
step
.isQuestTurnedIn 3372
#completewith next
+Logout skip out of the cave. There are MANY different spots you can use
.link https://www.youtube.com/watch?v=-mcsjDkeSUw >> |cRXP_WARN_Click here for video reference|r
step
#completewith next
.goto Badlands,53.8,43.6
.zone Badlands >> Run to Badlands
step
.requires quest,717
.goto Badlands,53.8,43.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sigrun Ironhew|r
.accept 718 >>Accept Mirages
.target Sigrun Ironhew
step
.requires quest,717
.goto Badlands,66.601,21.487,10,0
.goto Badlands,66.604,22.026,10,0
.goto Badlands,66.164,21.886,10,0
.goto Badlands,66.92,23.45
>>Loot the |cRXP_PICK_Supply Crate|r on the ground
>>|cRXP_WARN_The |cRXP_PICK_Supply Crate|r can spawn in a few locations at Camp Kosh|r
.complete 718,1
step
.requires quest,717
.goto Badlands,53.8,43.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sigrun Ironhew|r
.turnin 718 >>Turn in Mirages
.target Sigrun Ironhew
step
.requires quest,717
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garek|r
.goto Badlands,61.8,54.2
.accept 732 >>Accept Tremors of the Earth
.target Garek
step
.requires quest,717
#label signofearthBL
>>Find & kill |cRXP_ENEMY_Boss Tho'grun|r. Loot him for the |cRXP_LOOT_Sign of Earth|r
>>|cRXP_LOOT_Boss Tho'grun|r |cRXP_WARN_patrols the zone, accompanied by five guards.|r
.complete 732,1 
.unitscan Boss Tho'grun
.mob Dustbelcher Mystic
.mob Dustbelcher Wyrmhunter
.mob Dustbelcher Shaman
.mob Dustbelcher Mauler
.isOnQuest 732
step
.requires quest,717
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garek|r
.goto Badlands,61.8,54.2
.turnin 732 >>Turn in Tremors of the Earth
.accept 717 >>Accept Tremors of the Earth
.isQuestComplete 732
.target Garek
step
.requires quest,717
#completewith next
.goto Badlands,79.97,36.57,50,0
.subzone 339 >>Travel east to the Lethlor Ravine
.isOnQuest 717
step
.requires quest,717
.goto Badlands,72.30,66.80
>>Loot the |cRXP_PICK_Pillar of Opal|r for the |cRXP_LOOT_Opal Runestone|r
.collect 4844,1 
.isOnQuest 717
step
.requires quest,717
.goto Badlands,81.30,64.20
>>Loot the |cRXP_PICK_Pillar of Amethyst|r for the |cRXP_LOOT_Amethyst Runestone|r
.collect 4843,1 
.isOnQuest 717
step
.requires quest,717
.goto Badlands,83.50,32.90
>>Loot the |cRXP_PICK_Pillar of Diamond|r for the |cRXP_LOOT_Diamond Runestone|r
.collect 4845,1 
.isOnQuest 717
step
.requires quest,717
.goto Badlands,81.70,49.90
>>After collecting the 3 runestones, click the |cRXP_PICK_Seal of the Earth|r to summon |cRXP_ENEMY_Blacklash|r and |cRXP_ENEMY_Hematus|r
>>|cRXP_WARN_This can be difficult to solo, consider getting a group if you are unable to do it by yourself|r
.accept 779 >>Accept Seal of the Earth
.turnin 779 >>Turn in Seal of the Earth
.isOnQuest 717
step
.requires quest,717
.goto Badlands,81.70,49.90
>>Kill |cRXP_ENEMY_Blacklash|r and |cRXP_ENEMY_Hematus|r. Loot them for their |cRXP_LOOT_Bindings|r and |cRXP_LOOT_Chains|r
>>|cRXP_WARN_Simplify this encounter by killing|r |cRXP_ENEMY_Hematus|r |cRXP_WARN_first, as his flame buffet intensifies|r |cRXP_ENEMY_Blacklash's|r |cRXP_WARN_fire breath|r
.complete 717,1 
.complete 717,2 
.mob Blacklash
.mob Hematus
.isOnQuest 717
step
.goto Loch Modan,33.8,50.8
>> Run North to Loch Modan for a flight
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garek|r
.fly Morgan's Vigil >> Fly to Morgan's Vigil in Burning Steppes
.target Thorgrum Borrelson
.zoneskip Burning Steppes
step
.requires quest,4182
.goto Burning Steppes,85.820,68.948
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Helendis Riverhorn|r
.accept 4182 >> Accept Dragonkin Menace
.target Helendis Riverhorn
step
.requires quest,4283
.goto Burning Steppes,84.554,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.accept 4283 >> Accept FIFTY! YEP!
.target Oralius
step
.requires quest,4263
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.goto Burning Steppes,85.4,70.0
.accept 4262 >>Accept Overmaster Pyron
.target Jalinda Sprig
step
.requires quest,4182
.goto Burning Steppes,81.8,27.8,0
.goto Burning Steppes,91.4,32.6,0
.goto Burning Steppes,89.8,54.6,0
.goto Burning Steppes,81.8,60.0,0
>>Kill |cRXP_ENEMY_Black Broodlings|r, |cRXP_ENEMY_Black Dragonspawns|r, |cRXP_ENEMY_Black Wyrmkins|r and a |cRXP_ENEMY_Black Drake|r
.complete 4182,1 
.complete 4182,2 
.complete 4182,4 
.complete 4182,3 
.isOnQuest 4182
.mob Black Broodling
.mob Black Dragonspawn
.mob Black Drake
.mob Black Wyrmkin
step
.requires quest,4283
.goto Burning Steppes,39.21,55.27,0
.goto Burning Steppes,41.8,35.4,0
.goto Burning Steppes,49.6,55.4,0
.goto Burning Steppes,50.6,61.8,0
.goto Burning Steppes,55.4,54.6,0
.goto Burning Steppes,39.21,55.27,60,0
.goto Burning Steppes,49.6,55.4,0,60,0
.goto Burning Steppes,50.6,61.8,0,60,0
.goto Burning Steppes,55.4,54.6,0,60,0
.goto Burning Steppes,48.8,59.6
>>Kill |cRXP_ENEMY_Blackrock Orcs|r and |cRXP_ENEMY_Worgs|r. Loot them for their |cRXP_LOOT_Blackrock Medallions|r
.complete 4283,1 
.mob Blackrock Slayer
.mob Blackrock Warlock
.mob Blackrock Sorcerer
.mob Blackrock Soldier
.mob Blackrock Worg
.mob Slavering Ember Worg
.mob Giant Ember Worg
step
.requires quest,4263
>>Kill |cRXP_ENEMY_Overmaster Pyron|r
>>|cRXP_WARN_He roams around near the enterance to Blackrock Depths dungeon|r
.complete 4262,1 
.unitscan Overmaster Pyron
step
.requires quest,4263
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.goto Burning Steppes,85.4,70.0
.turnin 4262 >>Turn in Overmaster Pyron
.target Jalinda Sprig
step << !Mage
.goto Burning Steppes,84.4,68.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgus Stoutarm|r
.fly Stormwind City >> Fly to Stormwind City
.target Borgus Stoutarm
.zoneskip Stormwind City
step << Mage
.cast 3561 >>Cast |T135763:0|t[Teleport: Stormwind]
.zoneskip Stormwind City
step
#completewith next
.goto Stormwind City,47.87,31.31,8,0
.goto Stormwind City,47.87,31.31,6 >>Travel toward |cRXP_FRIENDLY_Royal Factor Bathrilor|r upstairs
step
.goto Stormwind City,48.47,30.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Factor Bathrilor|r inside on the 2nd floor
.turnin 5022 >> Turn in Better Late Than Never
.target Royal Factor Bathrilor
step
.requires quest,8554
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgus Stoutarm|r or any of the auctioneers
.collect 4457,10 
.target Borgus Stoutarm
step
.requires quest,4245
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgus Stoutarm|r or any of the auctioneers
.collect 10561,1 
.target Borgus Stoutarm
step
.requires quest,2994
.goto Stormwind City,66.2,62.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Nethergarde Keep >> Fly to Nethergarde Keep in Blasted Lands
.target Dungar Longdrink
step
.requires quest,2994
.goto Blasted Lands,66.898,19.469
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thadius Grimshade|r atop the Tower
.turnin 2990 >> Turn in Thadius Grimshade
.target Thadius Grimshade
step
.requires quest,2994
.isQuestTurnedIn 2990
.goto Blasted Lands,66.898,19.469
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thadius Grimshade|r atop the Tower
.accept 2991 >> Accept Nekrum's Medallion
.target Thadius Grimshade
step
.goto Blasted Lands,65.6,24.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexandra Constantine|r
.fly Booty Bay >> Fly to Booty Bay in Stranglethorn Vale
.target Alexandra Constantine
step
.requires quest,8554
.goto Stranglethorn Vale,23.60,72.00
>>Kill |cRXP_ENEMY_Mok'rash|r. Loot him for |T133694:0|t[|cRXP_LOOT_Monogrammed Sash|r]. Use it to start the quest
>>|cRXP_WARN_He has a hefty respaw timer so it might take a while to get it|r
.collect 3985,1,8552 
.accept 8552 >>Accept The Monogrammed Sash
.use 3985
step
.requires quest,8554
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smotts|r
.turnin 8552 >>Turn in The Monogrammed Sash
.target Captain Hecklebury Smotts
.isOnQuest 8552
step
.requires quest,8554
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smotts|r and |cRXP_FRIENDLY_Sprogger|r
.accept 615 >>Accept The Captain's Cutlass
.goto Stranglethorn Vale,26.69,73.62
.turnin 615 >>Turn in The Captain's Cutlass
.goto Stranglethorn Vale,26.66,73.64
.target Captain Hecklebury Smotts
.target Sprogger
.isQuestTurnedIn 8552
step
.requires quest,8554
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sprogger|r
.accept 8554 >>Accept Facing Negolash
.target Sprogger
step
.requires quest,8554
.goto Stranglethorn Vale,27.04,77.17,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nixxrax|r
>>|cRXP_WARN_If you didn't get|r |T133974:0|t[Barbecued Buzzard Wings] |cRXP_WARN_earlier (and none of your group members do either), then skip this step. You need 10 wings in total to summon|r |cRXP_ENEMY_Negolash|r
.vendor >>Buy |cRXP_BUY_Junglevine Wine|r from |cRXP_FRIENDLY_Nixxrax|r
.collect 4457,10 
.collect 4595,5 
.target Nixxrax Fillamug
step
.requires quest,8554
#completewith next
.goto Stranglethorn Vale,29.83,72.25,50,0
.goto Stranglethorn Vale,33.66,75.05,50,0
.subzone 43 >>Travel north out of Booty Bay, then east to the beach
step
.requires quest,8554
.goto Stranglethorn Vale,32.5,81.90
>>Click the |cRXP_PICK_Ruined Lifeboat|r
.turnin 619 >>Turn in Enticing Negolash
step
.requires quest,8554
.goto Stranglethorn Vale,32.50,81.94
>>Click the |cRXP_PICK_Ruined Lifeboat|r to summon |cRXP_ENEMY_Negolash|r. Kill him and loot him for |cRXP_LOOT_Smotts' Cutlass|r
.complete 8554,1 
.unitscan Negolash
step
.requires quest,630
#loop
.goto Stranglethorn Vale,34.22,73.25,60,0
.goto Stranglethorn Vale,34.01,77.21,60,0
.goto Stranglethorn Vale,32.34,79.44,60,0
.goto Stranglethorn Vale,32.38,82.23,60,0
>>Loot the |cRXP_PICK_Half-Burried Bottles|r along the southeastern coast
.collect 4098,1,594
.accept 594 >> Accept Message in a Bottle
step
.requires quest,630
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Poobah|r
.turnin 594 >>Turn in Message in a Bottle
.accept 630 >>Accept Message in a Bottle
.target Princess Poobah
step
.requires quest,630
.goto Stranglethorn Vale,40.94,83.89
>>Kill |cRXP_ENEMY_King Mukla|r. Loot him for his |cRXP_LOOT_Key|r
>>|cRXP_WARN_Clear a bit of space around|r |cRXP_ENEMY_King Mukla|r|cRXP_WARN_, as he has a fear|r
.complete 630,1 
.unitscan King Mukla
step
.goto Stranglethorn Vale,32.90,88.20,0
.goto Stranglethorn Vale,30.60,90.60,0
.goto Stranglethorn Vale,29.30,88.30,0
>>Search the ships' lower levels until you find a small scroll on the ground. Loot it for |T134939:0|t[|cRXP_LOOT_Cortello's Riddle|r].
.collect 4056,1,624,1 >> Cortello's Riddle (1)
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.accept 2872 >> Accept Stoley's Debt
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,25.91,72.96
.zone The Barrens >> Take a boat to Ratchet
.zoneskip The Barrens
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Alliance
#group RestedXP SoD Preparation
#subgroup Preparation guide
#title 2 - 20 Questlog prep - Kalimdor
#name 2 - 20 Questlog prep - Kalimdor (A)
#next 3 - 20 Questlog prep - Dungeons and shopping
step
.requires quest,4502
.goto The Barrens,62.50,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv|r
.accept 4502 >>Accept Volcanic Activity
.target Liv Rizzlefix
step
.goto The Barrens,63.0,37.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Marshal's Refuge >> Fly to Marshal's Refuge in Un'goro Crater
.target Bragok
step
#completewith Ungoroend
>>Kill |cRXP_ENEMY_Ravasaurs|r. Loot them for |T133743:0|t[A Mangled Journal]
>>|cRXP_WARN_Any mob in Un'Goro Crater may drop it|r
>>|cRXP_WARN_Use |T133743:0|t[A Mangled Journal] to start the quest|r
.collect 11116,1,3884,1 
step
#completewith Ungoroend
>>Loot |cRXP_LOOT_Power Crystals|r on the ground as you quest through Un'Goro Crater
.collect 11186,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
.collect 11188,7,4284,1 
step
.requires quest,4292
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.accept 4290 >> Accept The Fare of Lar'korwi
.target Torwa Pathfinder
step
#completewith Ungoroend
>>Loot |cRXP_LOOT_Un'Goro Soil|r on the ground as you quest through Un'Goro Crater
.collect 11018,25 
step
.requires quest,4292
.goto Un'Goro Crater,68.73,56.70
>>Loot the |cRXP_LOOT_Piece of Threshadon Carcass|r
.complete 4290,1 
step
.requires quest,4292
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4290 >> Turn in The Fare of Lar'korwi
.accept 4291 >> Accept The Scent of Lar'korwi
.target Torwa Pathfinder
step
.requires quest,4292
.goto Un'Goro Crater,67.324,73.041,8,0
.goto Un'Goro Crater,66.601,66.727,8,0
.goto Un'Goro Crater,60.926,72.234,8,0
.goto Un'Goro Crater,62.285,65.985,8,0
.goto Un'Goro Crater,63.240,77.350,8,0
.goto Un'Goro Crater,67.324,73.041,8,0
.goto Un'Goro Crater,66.601,66.727
.goto Un'Goro Crater,67.324,73.041,0
.goto Un'Goro Crater,60.926,72.234,0
.goto Un'Goro Crater,62.285,65.985,0
.goto Un'Goro Crater,63.240,77.350,0
>>Kill |cRXP_ENEMY_Lar'korwi Mates|r. Loot them for their |cRXP_LOOT_Ravasaur Pheromone Glands|r
>>|cRXP_WARN_Walking over |cRXP_PICK_Raptor Nests|r on the ground will trigger a |cRXP_ENEMY_Lar'korwi Mate|r to spawn|r
.complete 4291,1 
.mob Lar'korwi Mate
step
.requires quest,4292
#label lashers
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4291 >> Turn in The Scent of Lar'korwi
.target Torwa Pathfinder
step
.requires quest,4292
#label Bait
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.accept 4292 >> Accept The Bait for Lar'korwi
.target Torwa Pathfinder
step
.requires quest,4301
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.accept 4289 >> Accept The Apes of Un'Goro
.target Torwa Pathfinder
step
.requires quest,4292
.goto Un'Goro Crater,79.929,49.896
>>|cRXP_WARN_Use the|r |T133970:0|t[Preserved Threshadon Meat] |cRXP_WARN_on the stone-slab, then use the|r |T134743:0|t[Preserved Pheromone Mixture] |cRXP_WARN_on it to summon|r |cRXP_ENEMY_Lar'korwi|r
>>Kill |cRXP_ENEMY_Lar'korwi|r. Loot him for his |cRXP_LOOT_Head|r
.use 11568 
.use 11569 
.use 11570 
.complete 4292,1 
.mob Lar'korwi
step
.requires quest,4301
.goto Un'Goro Crater,63.66,16.56,70,0
.goto Un'Goro Crater,65.47,16.48
>>Kill |cRXP_ENEMY_Un'Goro Gorillas|r, |cRXP_ENEMY_Un'Goro Stompers|r and |cRXP_ENEMY_Un'Goro Thunderer|r. Loot them for their |cRXP_LOOT_Pelts|r
>>|cRXP_ENEMY_Un'Goro Gorillas|r |cRXP_WARN_will call for help at low health, pay attention to your surroundings when this happens|r
>>|cRXP_ENEMY_Un'Goro Stompers|r |cRXP_WARN_will|r |T136224:0|t[Enrage] |cRXP_WARN_at low health|r
>>|cRXP_ENEMY_Un'Goro Thunderer|r |cRXP_WARN_cast a high damage|r |T136105:0|t[Thunderclap]
.complete 4289,1 
.complete 4289,2 
.complete 4289,3 
.mob Un'Goro Gorilla
.mob Un'Goro Stomper
.mob Un'Goro Thunderer
step
.requires quest,4245
.goto Un'Goro Crater,46.378,13.444
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna Remtravel|r
.accept 4243 >> Accept Chasing A-Me 01
.target Karna Remtravel
step
.requires quest,4301
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4289 >> Turn in The Apes of Un'Goro
.accept 4301 >> Accept The Mighty U'cha
.target Torwa Pathfinder
step
.requires quest,4245
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.turnin 4243 >> Turn in Chasing A-Me 01
.itemcount 10561,<1 
.target A-Me 01
step
.requires quest,4245
#label AMe
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
>>|cRXP_WARN_Don't accept the follow up yet|r
.turnin 4243 >> Turn in Chasing A-Me 01
.itemcount 10561,1 
.target A-Me 01
step
.requires quest,4301
.goto Un'Goro Crater,68.49,12.18
>>Kill |cRXP_ENEMY_U'cha|r. Loot him for his |cRXP_LOOT_Pelt|r
.complete 4301,1 
.mob U'cha
step
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.accept 4244 >> Accept Chasing A-Me 01
.turnin 4244 >> Turn in Chasing A-Me 01
.accept 4245 >> Accept Chasing A-Me 01
.itemcount 10561,1 
.target A-Me 01
step
.requires quest,4245
.isQuestTurnedIn 4244
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.accept 4245 >> Accept Chasing A-Me 01
.target A-Me 01
step
.requires quest,4245
.isOnQuest 4245
.goto Un'Goro Crater,46.378,13.444
>>Escort |cRXP_FRIENDLY_A-Me 01|r to |cRXP_FRIENDLY_Karna Remtravel|r at Marshal's Refuge
.complete 4245,1 
.target A-Me 01
step
.goto Un'Goro Crater,45.41,12.13
>>Travel to Marshal's Refuge
>>Loot |cRXP_LOOT_Power Crystals|r on the ground en-route
.collect 11186,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
.collect 11188,7,4284,1 
step
#completewith next
.goto Un'Goro Crater,45.41,12.13
.subzone 541 >> Travel to Marshal's Refuge
step
.requires quest,4501
.goto Un'Goro Crater,43.533,8.436
>>Click the |cRXP_PICK_Wanted Poster|r
.accept 4501 >> Accept Beware of Pterrordax
step
.requires quest,4491
.goto Un'Goro Crater,43.615,8.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle Frock|r
.accept 4492 >> Accept Lost!
.target Spraggle Frock
step
.requires quest,4501
.goto Un'Goro Crater,56.3,90.6,40,0
.goto Un'Goro Crater,44.3,90.4,40,0
.goto Un'Goro Crater,56.3,90.6,40,0
.goto Un'Goro Crater,44.1,66.2,70,0
.goto Un'Goro Crater,53.5,62.9,70,0
.goto Un'Goro Crater,52.3,69.8,70,0
.goto Un'Goro Crater,44.3,90.4
>>Kill |cRXP_ENEMY_Pterrordaxes|r.
.complete 4501,1 
.disablecheckbox
.mob Pterrordax
step
.requires quest,4501
#label CompletePterro
.goto Un'Goro Crater,20.6,60,40,70,0
.goto Un'Goro Crater,22.4,50.0,70,0
.goto Un'Goro Crater,22.2,41,0,70,0
.goto Un'Goro Crater,34.8,29.4,70,0
.goto Un'Goro Crater,39.6,42.2,70,0
.goto Un'Goro Crater,36.8,76.6,70,0
.goto Un'Goro Crater,24.6,61.6
>>Kill |cRXP_ENEMY_Frenzied Pterrordaxes|r.
.complete 4501,2 
.mob Frenzied Pterrordax
step
.requires quest,4502
#loop
.line Un'Goro Crater,46.7,53.2,49.8,53.9,52.2,54.2,51.2,51.6,53.1,50.4,52.6,45.3,51.5,46.3,50.3,47.7,51.3,49.4,50.3,47.7,49.5,47.3,47.8,50.9,46.7,53.2
.goto Un'Goro Crater,46.70,53.20,25,0
.goto Un'Goro Crater,49.80,53.90,25,0
.goto Un'Goro Crater,52.20,54.20,25,0
.goto Un'Goro Crater,51.20,51.60,25,0
.goto Un'Goro Crater,53.10,50.40,25,0
.goto Un'Goro Crater,52.60,45.30,25,0
.goto Un'Goro Crater,51.50,46.30,25,0
.goto Un'Goro Crater,50.30,47.70,25,0
.goto Un'Goro Crater,51.30,49.40,25,0
.goto Un'Goro Crater,50.30,47.70,25,0
.goto Un'Goro Crater,49.50,47.30,25,0
.goto Un'Goro Crater,47.80,50.90,25,0
.goto Un'Goro Crater,46.70,53.20,25,0
>>Kill |cRXP_ENEMY_Fire Elementals|r. Loot them for their |cRXP_LOOT_Ash|r
.complete 4502,1 
.mob Scorching Elemental
.mob Living Blaze
.mob Blazing Invader
step
.requires quest,4491
#completewith next
.goto Un'Goro Crater,52.42,51.00,30 >> Enter the cave on the east side of the volcano
step
.requires quest,4491
.goto Un'Goro Crater,51.909,49.870
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ringo|r
.turnin 4492 >> Turn in Lost!
.accept 4491,1 >> Accept A Little Help From My Friends
>>|cRXP_WARN_This will start an escort quest|r
.target Ringo
step
.requires quest,4491
#label Ungoroend
.goto Un'Goro Crater,43.617,8.497
>>Escort |cRXP_FRIENDLY_Ringo|r to Marshal's Refuge
.use 11804 >> |cRXP_WARN_Use|r |T132805:0|t[Spraggle's Canteen] |cRXP_WARN_on him when he faints and stops following you|r
.complete 4491,1 
.target Ringo
step
>>Kill |cRXP_ENEMY_Ravasaurs|r. Loot them for |T133743:0|t[A Mangled Journal]
>>|cRXP_WARN_Any mob in Un'Goro Crater may drop it|r
>>|cRXP_WARN_Use |T133743:0|t[A Mangled Journal] to start the quest|r
.collect 11116,1,3884,1 
step
>>Loot the remaining |cRXP_LOOT_Power Crystals|r on the ground throughout Un'Goro Crater
.collect 11186,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
.collect 11188,7,4284,1 
step
.goto Un'Goro Crater,45.2,5.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryfe|r
.fly Gadgetzan >> Fly to Gadgetzan in Tanaris
.target Gryfe
.zoneskip Tanaris
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 992 >> Accept Gadgetzan Water Survey
.target Senior Surveyor Fizzledowser
step
.requires quest,4507
.goto Tanaris,39.10,29.30
.use 8584 >> the |T134867:0|t[Untapped Dowsing Widget] at the pool. Run away from the two mobs that spawn without attacking them.
.complete 992,1 
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 992 >> Turn in Gadgetzan Water Survey
.target Senior Surveyor Fizzledowser
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 82 >>Accept Noxious Lair Investigation
.target Kravel Koalbeard
step
.requires quest,4507
#completewith next
.subzone 982 >>Continue west to The Noxious Lair
step
.requires quest,4507
.goto Tanaris,35.68,39.78,70,0
.goto Tanaris,36.55,41.98,70,0
.goto Tanaris,35.59,44.08,70,0
.goto Tanaris,35.60,48.79,70,0
.goto Tanaris,31.70,49.12,70,0
.goto Tanaris,30.83,46.10,70,0
.goto Tanaris,35.68,39.78
>>Kill |cRXP_ENEMY_Centipaar Silithids|r. Loot them for their |cRXP_LOOT_Insect Parts|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Centipaar Swarmers|r|cRXP_WARN_. They can spawn many minions and social aggro from great distances|r
>>|cRXP_WARN_All|r |cRXP_ENEMY_Centipaar|r |cRXP_WARN_cast|r |T132152:0|t[Thrash] |cRXP_WARN_(Charges 2 extra attacks every 10 seconds)
.complete 82,1 
.mob Centipaar Wasp
.mob Centipaar Stinger
.mob Centipaar Swarmer
.mob Centipaar Worker
.mob Centipaar Sandreaver
.mob Centipaar Tunneler
step
.requires quest,4507
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 82 >>Turn in Noxious Lair Investigation
.target Alchemist Pestlezugg
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 10 >>Accept The Scrimshank Redemption
.target Senior Surveyor Fizzledowser
step
.goto Tanaris,67.10,24.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stoley|r
.turnin 2872 >> Turn in Stoley's Debt
.accept 2873 >> Accept Stoley's Shipment
.target Stoley
step
>>Kill |cRXP_ENEMY_Southsea Pirates|r. Loot them for their |cRXP_LOOT_Pirate's Footlockers|r. Make sure to open them and look for |cRXP_LOOT_Ship Schedule|r
.use 9276
.collect 9250,1 
.mob Southsea Pirate
.mob Southsea Freebooter
.mob Southsea Dock Worker
.mob Southsea Swashbuckler
step
>>Loot the |cRXP_PICK_Stolen Cargo|r for |cRXP_LOOT_Stoley's Shipment|r on the second floor of the western house
.complete 2873,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stoley|r
.turnin 2873 >>Turn in Stoley's Shipment
.goto Tanaris,67.11,23.98
.target Stoley
step
.use 8623 >>If you've found an |T132836:0|t[OOX-17/TN Distress Beacon], click it and accept its quest. Otherwise, kill any mobs in Tanaris for a chance to drop it
.accept 351 >>Accept Find OOX-17/TN!
.collect 8623,1
step
#completewith next
.goto Tanaris,56.19,66.62,30,0
.subzone 981 >>Travel south to The Gaping Chasm
step
.requires quest,4507
#label BugHole
.goto Tanaris,55.69,69.44,50,0
.goto Tanaris,56.36,68.44,30,0
.goto Tanaris,57.45,70.45,30,0
.goto Tanaris,55.96,71.16
>>Enter the silithid hive, then click the |cRXP_PICK_Scrimshank's Surveying Gear console|r and loot |cRXP_LOOT_Scrimshank's Surveying Gear|r
>>|cRXP_WARN_Be extremely cautious of |cRXP_ENEMY_Hazzali Swarmers|r |cRXP_WARN_as they can rapidly summon adds which deal high damage. They can also social aggro other mobs from extreme distances|r
.complete 10,1 
.unitscan Hazzali Swarmer
step
.goto Tanaris,60.20,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r
.turnin 351 >>Turn in Find OOX-17/TN!
.target Homing Robot OOX-17/TN
.isOnQuest 351
step
.goto Tanaris,60.23,64.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r again to start the escort quest
>>|cRXP_WARN_This quest can be difficult. Eat/drink to full and apply any self-buffs (scrolls, food, elixirs, etc.)|r
.accept 648 >>Accept Rescue OOX-17/TN!
.target Homing Robot OOX-17/TN
.isQuestTurnedIn 351
step
.goto Tanaris,67.09,23.18
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r to Steamwheedle Port
>>|cRXP_WARN_A pack of 3 level 46-47|r |cRXP_ENEMY_Scorpions|r |cRXP_WARN_will spawn at the next mountain chain|r
>>|cRXP_WARN_A pack of 3 level 43-45|r |cRXP_ENEMY_Wastewander mobs|r |cRXP_WARN_will spawn around Waterspring Field. Focus the|r |cRXP_ENEMY_Scofflaw|r|cRXP_WARN_. It EXECUTES when you're below 20% health|r
.complete 648,1 
.target Homing Robot OOX-17/TN
.unitscan Wastewander Scofflaw
.isQuestTurnedIn 351
step
#completewith next
.goto Tanaris,50.6,28.1
.subzone 976 >>Travel to Gadgetzan
step
.requires quest,4507
.goto Tanaris,50.21,27.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 10 >>Turn in The Scrimshank Redemption
.accept 110 >>Accept Insect Part Analysis
.target Senior Surveyor Fizzledowser
step
.requires quest,4507
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 110 >>Turn in Insect Part Analysis
.accept 113 >>Accept Insect Part Analysis
.target Alchemist Pestlezugg
step
.requires quest,4507
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 113 >>Turn in Insect Part Analysis
.accept 162 >>Accept Rise of the Silithid
.target Senior Surveyor Fizzledowser
step << !Mage
.requires quest,4507
.goto Tanaris,51.0,29.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bera Stonehammer|r
.fly Rut'theran Village >> Fly to Rut'theran Village
.target Bera Stonehammer
.zoneskip Darnassus
step << !Mage
.requires quest,4507
.goto Teldrassil,55.9,89.7
.zone Darnassus >> Step through the purple portal into Darnassus
step << Mage
.requires quest,4507
.cast 3565 >>Cast |T135755:0|t[Teleport: Darnassus]
.zoneskip Darnassus
step
.requires quest,4507
.goto Darnassus,42.0,85.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gracina Spiritmight|r
.turnin 162 >>Turn in Rise of the Silithid
.accept 4493 >>Accept March of the Silithid
.target Gracina Spiritmight
step
.requires quest,4507
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Travel through the purple portal to Rut'theran Village
.zoneskip Darnassus,1
step
.requires quest,4507
.goto Teldrassil,58.4,94.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
.fly Gadgetzan >> Fly to Gadgetzan in Tanaris
.target Vesprystus
step
.requires quest,4507
.goto Tanaris,50.8,27.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alchemist Pestlezugg|r
.turnin 4493 >> Turn in March of the Silithid
.accept 4496 >> Accept Bungle in the Jungle
.target Alchemist Pestlezugg
step
.requires quest,4507
.goto Un'Goro Crater,50.59,77.06,0
>>Kill |cRXP_ENEMY_Gorishi Silithid|r. Loot them for a |cRXP_LOOT_Gorishi Scent Gland|r
.complete 4496,1 
.mob Gorishi Worker
.mob Gorishi Wasp
.mob Gorishi Reaver
.mob Gorishi Tunneler
.mob Gorishi Stinger
.mob Gorishi Hive Guard
step
.requires quest,4507
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4496 >> Turn in Bungle in the Jungle
.accept 4507 >> Accept Pawn Captures Queen
.target Alchemist Pestlezugg
step
.requires quest,4507
.goto Un'Goro Crater,50.15,79.98,40,0
.goto Un'Goro Crater,49.74,82.52,30,0
.goto Un'Goro Crater,45.19,82.20,30,0
.goto Un'Goro Crater,43.41,80.98
>>Go deep into the silithid hive, until you reach a tall crystal in a round chamber
.use 11833 >>Use your |T134809:0|t[Gorishi Queen Lure] to summon the |cRXP_ENEMY_Gorishi Hive Queen|r. Kill her, then loot her |cRXP_LOOT_Gorishi Queen Brain|r
>>|cRXP_WARN_Stop new waves from aggroing you by dragging mobs into the hallway. Depending on your kill speed, a hallway patrol may respawn after the second wave|r
.complete 4507,1 
step << skip
.goto Tanaris,50.88,26.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4507 >>Turn in Pawn Captures Queen
.accept 4509 >>Accept Calm Before the Storm
.target Alchemist Pestlezugg
.isQuestComplete 4507
step
.goto Tanaris,51.0,29.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bera Stonehammer|r
.fly Feathermoon Stronghold >> Fly to Feathermoon Stronghold in Feralas
.target Bera Stonehammer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Latronicus Moonspear|r and |cRXP_FRIENDLY_Shandris Feathermoon|r
.accept 4124 >> Accept The Missing Courier
.goto Feralas,30.379,46.170
.accept 2866 >> Accept The Ruins of Solarsal
.goto Feralas,30.276,46.168
.target Latronicus Moonspear
.target Shandris Feathermoon
step
#label start
.goto Feralas,32.14,45.46,10,0
.goto Feralas,31.860,45.130
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ginro Hearthkindle|r up stairs
.turnin 4124 >> Turn in The Missing Courier
.accept 4125 >> Accept The Missing Courier
.target Ginro Hearthkindle
step
.goto Feralas,26.316,52.343
>>Click the |cRXP_PICK_Solarsal Gazebo|r
.turnin 2866 >> Turn in The Ruins of Solarsal
.accept 2867 >> Accept Return to Feathermoon Stronghold
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shandris Feathermoon|r and |cRXP_FRIENDLY_Latronicus Moonspear|r
.turnin 2867 >> Turn in Return to Feathermoon Stronghold
.accept 3130 >> Accept Against the Hatecrest
.goto Feralas,30.276,46.168
.turnin 3130 >> Turn in Against the Hatecrest
.accept 2869 >> Accept Against the Hatecrest
.goto Feralas,30.379,46.170
.target Latronicus Moonspear
.target Shandris Feathermoon
step
.goto Feralas,26.6,52.0,70,0
.goto Feralas,26.2,55.2,70,0
.goto Feralas,29.6,53.6,70,0
.goto Feralas,29.0,50.4,70,0
.goto Feralas,26.6,53.4
>>Kill |cRXP_ENEMY_Hatecrest Screamers|r, |cRXP_ENEMY_Hatecrest Wave Riders|r, |cRXP_ENEMY_Hatecrest Warriors|r and |cRXP_ENEMY_Hatecrest Sirens|r. Loot them for their |cRXP_LOOT_Naga Scales|r
.complete 2869,1 
.mob Hatecrest Screamer
.mob Hatecrest Wave Rider
.mob Hatecrest Warrior
.mob Hatecrest Siren
step
.goto Feralas,30.379,46.170
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Latronicus Moonspear|r
.turnin 2869 >> Turn in Against the Hatecrest
.accept 2870 >> Accept Against Lord Shalzaru
.target Latronicus Moonspear
step
#completewith next
.goto Feralas,25.49,64.92,40,0
.goto Feralas,26.13,67.41,30 >> Travel to the Isle of Dread. Enter Shalzaru's Lair
step
.goto Feralas,28.51,70.59
>>Kill |cRXP_ENEMY_Lord Shalzaru|r. Loot him for the |cRXP_LOOT_Mysterious Relic|r
.complete 2870,1 
.mob Lord Shalzaru
step
#completewith next
.goto Feralas,30.276,46.168,150 >> Travel to Feathermoon Stronghold
step
.goto Feralas,30.379,46.170
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Latronicus Moonspear|r
.turnin 2870 >> Turn in Against Lord Shalzaru
.target Latronicus Moonspear
step
#completewith next
.goto Feralas,45.07,44.89,150 >> Swim to the mainland
step
.goto Feralas,45.44,64.96
>>Click on the |cRXP_PICK_Wrecked Row Boat|r in the water
.turnin 4125 >> Turn in The Missing Courier
.accept 4127 >> Accept Boat Wreckage
step
.goto Feralas,32.14,45.46,10,0
.goto Feralas,31.860,45.130
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ginro Hearthkindle|r up stairs
.turnin 4127 >> Turn in Boat Wreckage
.accept 4129 >> Accept The Knife Revealed
.target Ginro Hearthkindle
step
.goto Feralas,32.447,43.788
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quintis Jonespyre|r atop the tree house
.turnin 4129 >> Turn in The Knife Revealed
.timer 12,The Knife Revealed RP
.accept 4130 >> Accept Psychometric Reading
.target Quintis Jonespyre
step
.goto Feralas,32.14,45.46,10,0
.goto Feralas,31.860,45.130
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ginro Hearthkindle|r up stairs
.turnin 4130 >> Turn in Psychometric Reading
.accept 4131 >> Accept The Woodpaw Gnolls
.target Ginro Hearthkindle
step
#completewith spirits
.goto Feralas,47.3,44.7,65 >> Swim to the mainland
step
.goto Feralas,66.56,46.87,0
.goto Feralas,66.56,46.87,30,0
.goto Feralas,65.945,45.651
>>|cRXP_WARN_Kill some of the |cRXP_ENEMY_Grimtotem|r around the giant cage containing |cRXP_FRIENDLY_Captured Sprite Darters|r before accepting this escort quest|r
>>|cRXP_ENEMY_Grimtotem Raiders|r |cRXP_WARN_cast|r |T132149:0|t[Net] |cRXP_WARN_which immobilizes movement for 10 seconds|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kindal Moonweaver|r
.accept 2969 >> Accept Freedom for All Creatures
.target Kindal Moonweaver
.mob Grimtotem Naturalist
.mob Grimtotem Raider
.mob Grimtotem Shaman
step
.goto Feralas,66.666,46.754
>>Click the |cRXP_PICK_Cage Door|r to release the |cRXP_FRIENDLY_Captured Sprite Darters|r
>>Kill any |cRXP_ENEMY_Grimtotem|r that are attacking the |cRXP_FRIENDLY_Captured Sprite Darters|r
>>|cRXP_ENEMY_Grimtotem Raiders|r |cRXP_WARN_cast|r |T132149:0|t[Net] |cRXP_WARN_which immobilizes movement for 10 seconds|r
.complete 2969,1
.mob Grimtotem Naturalist
.mob Grimtotem Raider
.mob Grimtotem Shaman
.target Captured Sprite Darter
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kindal Moonweaver|r and |cRXP_FRIENDLY_Jer'kai Moonweaver|r
.turnin 2969 >> Turn in Freedom for All Creatures
.goto Feralas,65.945,45.651
.accept 2970 >> Accept Doling Justice
.goto Feralas,65.946,45.607
.target Kindal Moonweaver
.target Jer'kai Moonweaver
step
.goto Feralas,66.65,46.58,60,0
.goto Feralas,68.70,46.91,60,0
.goto Feralas,69.14,39.10,60,0
.goto Feralas,66.85,38.80,60,0
.goto Feralas,69.14,39.10
.goto Feralas,66.85,38.80,0
>>Kill |cRXP_ENEMY_Grimtotem Naturalists|r, |cRXP_ENEMY_Grimtotem Raiders|r and |cRXP_ENEMY_Grimtotem Shamans|r
>>|cRXP_ENEMY_Grimtotem Raiders|r |cRXP_WARN_cast|r |T132149:0|t[Net] |cRXP_WARN_which immobilizes movement for 10 seconds|r
.complete 2970,1 
.complete 2970,2 
.complete 2970,3 
.mob Grimtotem Naturalist
.mob Grimtotem Raider
.mob Grimtotem Shaman
step
.goto Feralas,65.946,45.607
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jer'kai Moonweaver|r
.turnin 2970 >> Turn in Doling Justice
.accept 2972 >> Accept Doling Justice
.target Jer'kai Moonweaver
step
.goto Feralas,73.314,56.311
>>Click the |cRXP_PICK_Large Leather Backpacks|r on the tree
.turnin 4131 >> Turn in The Woodpaw Gnolls
.accept 4135 >> Accept The Writhing Deep
step
.goto Feralas,73.31,56.30
>>|cRXP_WARN_Collect the |T133628:0|t[|cRXP_LOOT_Undelivered Parcel|r]|r
.collect 11463,1,4281,1
step
#completewith next
.goto Feralas,73.57,63.13,100,0
.goto Feralas,72.78,64.48,15 >> Enter The Writhering Deep Hive from the lower southwest entrance
step
.goto Feralas,72.080,63.713
>>Click the |cRXP_PICK_Zukk'ash Pod|r
.turnin 4135 >> Turn in The Writhing Deep
.accept 4265 >> Accept Freed from the Hive
.timer 19,Freed from the Hive RP
step
.goto Feralas,72.080,63.713
>>|cRXP_WARN_Wait out the RP|r
.complete 4265,1
step
.goto Feralas,53.6,55.4
>>Kill |cRXP_ENEMY_Feral Scar Yeti|r, |cRXP_ENEMY_Enraged Feral Scar|r and |cRXP_ENEMY_Hulking Feral Scar|r. Loot them for the |T132836:0|t[|cRXP_LOOT_OOX-22/FE Distress Beacon|r]
.use 8705 >>|cRXP_WARN_Use the |T132836:0|t[|cRXP_LOOT_OOX-22/FE Distress Beacon|r] to start the quest|r
.collect 8705,1,2766,1 
.disablecheckbox
.accept 2766 >> Accept Find OOX-22/FE!
.mob Feral Scar Yeti
.mob Enraged Feral Scar
.mob Hulking Feral Scar
step
.isOnQuest 2766
.goto Feralas,55.44,56.45,40,0
.goto Feralas,53.353,55.696
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r
>>|cRXP_WARN_Do NOT accept the follow up and attempt to do the Escort, unless you are in a group|r
.turnin 2766 >> Turn in Find OOX-22/FE!
.target Homing Robot OOX-22/FE
step
.isQuestTurnedIn 2766
.goto Feralas,53.353,55.696
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r
.accept 2767,1 >> Accept Rescue OOX-22/FE!
.target Homing Robot OOX-22/FE
step
.isOnQuest 2767
.goto Feralas,45.67,43.38
>>Escort the |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r to safety
.complete 2767,1
.target Homing Robot OOX-22/FE
step
.goto Feralas,32.14,45.46,10,0
.goto Feralas,31.860,45.130
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ginro Hearthkindle|r up stairs
.turnin 4265 >> Turn in Freed from the Hive
.target Ginro Hearthkindle
step
.goto Feralas,30.2,43.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fyldren Moonfeather|r
.fly Talrendis Point >> Fly to Talrendis Point in Azshara
.target Fyldren Moonfeather
step
.requires quest,3461
#label RuneRubbing
>>Click the |cRXP_PICK_Runes|r. Loot them for the |cRXP_LOOT_Rubbings|r
.complete 3449,2 
.goto Azshara,39.57,50.32
.complete 3449,1 
.goto Azshara,36.95,53.18
.complete 3449,3 
.goto Azshara,39.33,55.42
.complete 3449,4 
.goto Azshara,42.34,64.14
step
.requires quest,3461
#completewith ArcaneRunes
.goto Azshara,60.11,73.02,150,0
.goto Azshara,72.71,75.91,150,0
.goto Azshara,77.800,91.327,20 >> Swim around to the small island with the Landing Pad
step
.requires quest,3461
#completewith next
.cast 12283 >>|cRXP_WARN_Use the|r |T134537:0|t[Standard Issue Flare Gun] |cRXP_WARN_while on top of the Landing Pad and wait for |cRXP_FRIENDLY_Pilot Xiggs Fuselighter|r to arrive|r
.timer 40,Arcane Runes RP
.use 10444
step
.requires quest,3461
#label ArcaneRunes
.goto Azshara,77.800,91.327
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pilot Xiggs Fuselighter|r
.turnin 3449 >> Turn in Arcane Runes
.accept 3461 >> Accept Return to Tymor
.target Pilot Xiggs Fuselighter
step
#completewith next
.goto Azshara,11.8,77.6
.subzone 3137 >> Run back to Talrendis Point
step
.goto Azshara,11.8,77.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarrodenus|r
.fly Astranaar >> Fly to Astranaar in Ashenvale
.target Jarrodenus
step
#completewith next
.goto Ashenvale,59.65,62.41,30,0
.goto Ashenvale,63.92,49.95,30,0
.goto Ashenvale,55.88,32.55,30,0
.goto Felwood,54.14,86.83
>>Head towards Felwood crossing from Ashenvale
step
.requires quest,4101
.goto Felwood,54.14,86.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arathandris Silversky|r
.accept 4101 >> Accept Cleansing Felwood
.target Arathandris Silversky
step
.requires quest,5242
.goto Felwood,51.20,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.accept 5155 >>Accept Forces of Jaedenar
.target Greta Mosshoof
step
.requires quest,5156
.goto Felwood,50.889,81.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn Redfeather|r
.accept 5156 >> Accept Verifying the Corruption
.target Taronn Redfeather
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.accept 4421 >> Accept The Corruption of the Jadefire
.goto Felwood,51.350,81.511
.target Eridan Bluewind
step
>>Kill |cRXP_ENEMY_Jadefire Felsworns|r, |cRXP_ENEMY_Jadefire Shadowstalkers|r, |cRXP_ENEMY_Jadefire Rogues|r and |cRXP_ENEMY_Xavathras|r
>>|cRXP_WARN_This area can be very dangerous. Be extremely cautious|r
>>|cRXP_ENEMY_Jadefire Felsworns|r |cRXP_WARN_cast|r |T136135:0|t[Cripple] |cRXP_WARN_which slows your movement speed|r
>>|cRXP_ENEMY_Jadefire Shadowstalkers|r |cRXP_WARN_are in|r |T132320:0|t[Stealth] |cRXP_WARN_and patrol around, as well as apply a|r |T136093:0|t[Slowing Poison] |cRXP_WARN_which slows you for 25 seconds|r
.complete 4421,1 
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91,60,0
.goto Felwood,32.23,67.10,60,0
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91
.complete 4421,2 
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91,60,0
.goto Felwood,32.23,67.10,60,0
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91
.complete 4421,3 
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91,60,0
.goto Felwood,32.23,67.10,60,0
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91
.complete 4421,4 
.goto Felwood,32.23,67.10
.mob Jadefire Felsworn
.mob Jadefire Shadowstalker
.mob Jadefire Rogue
.mob Xavathras
step
.requires quest,5242
.goto Felwood,38.55,59.14,50,0
.goto Felwood,36.49,61.40,60,0
.goto Felwood,35.01,59.83,60,0
.goto Felwood,36.49,61.40,60,0
.goto Felwood,38.55,59.14,60,0
.goto Felwood,36.49,61.40
>>Kill |cRXP_ENEMY_Jaedenar Hounds|r, |cRXP_ENEMY_Jaedenar Guardians|r, |cRXP_ENEMY_Jaedenar Adepts|r and |cRXP_ENEMY_Jaedenar Cultists|r
.complete 5155,1 
.complete 5155,2 
.complete 5155,3 
.complete 5155,4 
.mob Jaedenar Hound
.mob Jaedenar Guardian
.mob Jaedenar Adept
.mob Jaedenar Cultist
step
.isQuestComplete 4421
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.turnin 4421 >> Turn in The Corruption of the Jadefire
.accept 4906 >> Accept Further Corruption
.target Eridan Bluewind
step
.requires quest,5242
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5155 >> Turn in Forces of Jaedenar
.accept 5157 >> Accept Collection of the Corrupt Water
.target Greta Mosshoof
step
.requires quest,5242
.goto Felwood,38.55,59.14,50,0
.goto Felwood,35.173,59.778
.use 12922 >>|cRXP_WARN_Use the|r |T132788:0|t[Empty Canteen] |cRXP_WARN_at the Moon Well in the center of Jaedenar|r
.complete 5157,1 
step
.requires quest,5242
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5157 >> Turn in Collection of the Corrupt Water
.accept 5158 >> Accept Seeking Spiritual Aid
.target Greta Mosshoof
step
.isQuestTurnedIn 4421
.goto Felwood,41.58,19.19,90,0
.goto Felwood,38.98,22.31
>>Kill |cRXP_ENEMY_Xavaric|r. Loot him for the |T133942:0|t[|cRXP_LOOT_Flute of Xavaric|r]
>>|cRXP_WARN_Use the |T133942:0|t[|cRXP_LOOT_Flute of Xavaric|r] to start the quest|r
.collect 11668,1,939,1 
.accept 939 >> Accept Flute of Xavaric
.use 11668 
.mob Xavaric
step
.isQuestTurnedIn 4421
.goto Felwood,38.98,22.31,70,0
.goto Felwood,43.44,14.47,70,0
.goto Felwood,38.98,22.31,70,0
.goto Felwood,38.98,22.31
>>Kill |cRXP_ENEMY_Jadefire Hellcallers|r, |cRXP_ENEMY_Jadefire Betrayers|r and |cRXP_ENEMY_Jadefire Trickster|r. Loot them for their |cRXP_LOOT_Jadefire Felbinds|r
.complete 939,1 
.mob Jadefire Hellcaller
.mob Jadefire Betrayer
.mob Jadefire Trickster
step
.isOnQuest 939
.abandon 4906 >> Abandon Further Corruption
step
.requires quest,5156
>>Kill |cRXP_ENEMY_Entropic Beasts|r and |cRXP_ENEMY_Entropic Horrors|r
>>|cRXP_WARN_Be cautious of the Elite |cRXP_ENEMY_Infernals|r that patrol the Shatter Scar Vale|r
.complete 5156,1 
.goto Felwood,41.535,43.007,50,0
.goto Felwood,40.91,40.37,50,0
.goto Felwood,42.84,37.62,60,0
.goto Felwood,45.43,40.02,60,0
.goto Felwood,41.10,41.06
.complete 5156,2 
.goto Felwood,41.535,43.007,50,0
.goto Felwood,40.91,40.37,50,0
.goto Felwood,42.84,37.62,60,0
.goto Felwood,45.43,40.02,60,0
.goto Felwood,41.10,41.06
.complete 5156,3 
.goto Felwood,41.535,43.007
.mob Entropic Beast
.mob Entropic Horror
step
#completewith next
.goto Felwood,55.78,17.11
.subzone 1768 >> Travel to Irontree Cavern
step
.requires quest,4101
.goto Felwood,57.30,17.79
>>Kill |cRXP_ENEMY_Warpwood Moss Flayers|r and |cRXP_ENEMY_Warpwood Shredders|r. Loot them for their |cRXP_LOOT_Blood Ambers|r
.complete 4101,1 
.mob Warpwood Moss Flayer
.mob Warpwood Shredder
step
.isQuestComplete 939
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.turnin 939 >> Turn in Flute of Xavaric
.accept 4441 >> Accept Felbound Ancients
.target Eridan Bluewind
step << !Mage
#completewith next
>> Go to nearest Flight Master
.goto Ashenvale,34.4,48.0,-1
.goto Felwood,62.4,24.2,-1
.zoneskip Darnassus
step << !Mage
.goto Ashenvale,34.4,48.0,-1
.goto Felwood,62.4,24.2,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flight Master|r
.fly Rut'theran Village >> Fly to Rut'theran Village
.zoneskip Darnassus
step << !Mage
.goto Teldrassil,55.9,89.7
.zone Darnassus >> Step through the purple portal into Darnassus
step << Mage
.cast 3565 >>Cast |T135755:0|t[Teleport: Darnassus]
.zoneskip Darnassus
step
#label BlessedWater
.goto Darnassus,39.31,84.67
.use 11682 >>|cRXP_WARN_Use|r |T134870:0|t[Eridan's Vial] |cRXP_WARN_at the moonwell inside the Temple of the Moon|r
.complete 4441,1 
step
.goto Darnassus,39.0,81.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tyrande Whisperwind|r on the inner balcony
.turnin 2972 >> Turn in Doling Justice
.target Tyrande Whisperwind
step
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Travel through the purple portal to Rut'theran Village
.zoneskip Darnassus,1
step
.requires quest,5242
.goto Teldrassil,58.4,94.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
.fly Ratchet >> Fly to Ratchet in The Barrens
.target Vesprystus
step
.requires quest,5242
#label SpiritualAid
.goto The Barrens,65.827,43.776
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Islen Waterseer|r
.turnin 5158 >> Turn in Seeking Spiritual Aid
.timer 48,Seeking Spiritual Aid RP
.accept 5159 >> Accept Cleansed Water Returns to Felwood
.target Islen Waterseer
step
.goto The Barrens,63.0,37.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Astranaar >> Fly to Astranaar in Ashenvale
.target Bragok
step
.requires quest,5242
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5159 >> Turn in Cleansed Water Returns to Felwood
.accept 5165 >> Accept Dousing the Flames of Protection
.target Greta Mosshoof
step
#label FelboundAncients
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.turnin 4441 >> Turn in Felbound Ancients
.target Eridan Bluewind
step
.requires quest,5242,5385
#completewith eStart
.goto Felwood,35.367,58.376
.subzone 1770 >> Travel to Shadow Hold
step
.requires quest,5242
#completewith next
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
.requires quest,5385
>>Kill |cRXP_ENEMY_Jaedenar Enforcers|r, |cRXP_ENEMY_Jaedenar Darkweavers|r, |cRXP_ENEMY_Jaedenar Warlocks|r and |cRXP_ENEMY_Jaedenar Legionnaires|r. Loot them for a |T134235:0|t[|cRXP_LOOT_Blood Red Key|r]
>>|cRXP_WARN_Use the |T134235:0|t[|cRXP_LOOT_Blood Red Key|r] to start the quest|r
>>|cRXP_WARN_This will begin an escort quest. Start this escort even if you still need to Extinguish Braziers|r
.collect 13140,1,5202,1 
.accept 5202 >> Accept A Strange Red Key
.use 13140 
.mob Jaedenar Enforcer
.mob Jaedenar Darkweaver
.mob Jaedenar Warlock
.mob Jaedenar Legionnaire
step
.requires quest,5385
#label eStart
.goto Felwood,36.207,55.465
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captured Arko'narin|r
.turnin 5202 >> Turn in A Strange Red Key
.accept 5203,1 >> Accept Rescue From Jaedenar
.target Captured Arko'narin
step
.requires quest,5242
#completewith next
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
.requires quest,5385
.goto Felwood,35.44,59.01
>>|cRXP_WARN_Escort |cRXP_FRIENDLY_Arko'narin|r through Shadow Hold. Once you approach the final |cRXP_PICK_Brazier|r, 3 |cRXP_ENEMY_Felguards|r will spawn which you will have to deal with|r
>>|cRXP_WARN_After exiting Shadow Hold, you will need to kill the |cRXP_ENEMY_Spirit of Trey Lightforge|r. Let |cRXP_FRIENDLY_Arko'narin|r tank him as much as possible|r
.complete 5203,1 
.target Arko'narin
.mob Spirit of Trey Lightforge
step
.requires quest,5242
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
.requires quest,5242
.isQuestComplete 5165
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5165 >> Turn in Dousing the Flames of Protection
.accept 5242 >> Accept A Final Blow
.target Greta Mosshoof
step
.requires quest,5242
.isQuestTurnedIn 5165
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.accept 5242 >> Accept A Final Blow
.target Greta Mosshoof
step
.requires quest,5385
.isQuestComplete 5203
.goto Felwood,51.346,82.013
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessir Moonbow|r
.turnin 5203 >> Turn in Rescue From Jaedenar
.accept 5204 >> Accept Retribution of the Light
.target Jessir Moonbow
step
.requires quest,5385
.isQuestTurnedIn 5203
.goto Felwood,51.346,82.013
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessir Moonbow|r
.accept 5204 >> Accept Retribution of the Light
.target Jessir Moonbow
step
.requires quest,5385,5242
#completewith ShadowLord
.goto Felwood,35.367,58.376
.subzone 1770 >> Travel to Shadow Hold
step
.requires quest,5385
.isQuestTurnedIn 5203
.goto Felwood,38.499,50.414
>>Kill |cRXP_ENEMY_Rakaiah|r
.complete 5204,1 
.mob Rakaiah
step
.requires quest,5385
.isQuestTurnedIn 5203
.goto Felwood,38.499,50.414
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Remains of Trey Lightforge|r
.turnin 5204 >> Turn in Retribution of the Light
.accept 5385 >> Accept The Remains of Trey Lightforge
.target Remains of Trey Lightforge
step
.requires quest,5242
#label ShadowLord
.isQuestTurnedIn 5165
.goto Felwood,38.814,46.782
>>|cRXP_WARN_Continue further into Shadow Hold|r
>>Kill |cRXP_ENEMY_Salia|r, |cRXP_ENEMY_Moora|r and |cRXP_ENEMY_Shadow Lord Fel'dan|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Kill |cRXP_ENEMY_Salia|r first as she casts|r |T136206:0|t[Mind Control]
.complete 5242,1 
.complete 5242,2 
.complete 5242,3 
.mob Salia
.mob Moora
.mob Shadow Lord Fel'dan
step
.requires quest,8461
.goto Felwood,64.769,8.131
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.accept 8461 >> Accept Deadwood of the North
.target Nafien
step
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
.goto Felwood,62.61,10.12
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Den Avengers|r and |cRXP_ENEMY_Deadwood Den Shamans|r
>>|cRXP_WARN_If you find the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r], don't start the quest from this item yet|r
.complete 8461,1 
.complete 8461,2 
.complete 8461,3 
.mob Deadwood Den Watcher
.mob Deadwood Avenger
.mob Deadwood Shaman
step
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
.goto Felwood,62.61,10.12
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Den Avengers|r and |cRXP_ENEMY_Deadwood Den Shamans|r
>>|cRXP_WARN_When you find the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r], don't start the quest from this item yet|r
.collect 20741,1
.mob Deadwood Den Watcher
.mob Deadwood Avenger
.mob Deadwood Shaman
step
.reputation 576,friendly >> Keep Killing Deadwood Ursa until you reach friendly with Timbermaw Hold
step
.goto Moonglade,48.0,67.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sindrayl|r
.fp Moonglade >> Get the Moonglade flight path
.target Sindrayl
step
#completewith next
.goto Felwood,65.44,2.81,20,0
.goto Felwood,66.51,2.98,20,0
.goto Felwood,67.82,4.33,20,0
.goto Felwood,67.93,5.11,20,0
.zone Winterspring >>Travel through Timbermaw Hold to Winterspring
step
.requires quest,8464
.goto Felwood,68.30,6.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.accept 8464 >>Accept Winterfall Activity
.target Salfa
step
.requires quest,8464
#completewith next
#loop
.line Winterspring,67.6,34.1,66.4,34.3,65.9,35.3,66.6,36.3,67.5,35.5,68.4,35.7,68.3,37.3,67.5,37.9,66.8,37.3,65.6,37.7,66.7,39.1,68.0,39.4,68.8,37.7,68.4,35.7,67.6,34.1
.goto Winterspring,67.60,34.10,25,0
.goto Winterspring,66.40,34.30,25,0
.goto Winterspring,65.90,35.30,25,0
.goto Winterspring,66.60,36.30,25,0
.goto Winterspring,67.50,35.50,25,0
.goto Winterspring,68.40,35.70,25,0
.goto Winterspring,68.30,37.30,25,0
.goto Winterspring,67.50,37.90,25,0
.goto Winterspring,66.80,37.30,25,0
.goto Winterspring,65.60,37.70,25,0
.goto Winterspring,66.70,39.10,25,0
.goto Winterspring,68.00,39.40,25,0
.goto Winterspring,68.80,37.70,25,0
.goto Winterspring,68.40,35.70,25,0
>>Kill |cRXP_ENEMY_Winterfall Ursa|r, |cRXP_ENEMY_Winterfall Shamans|r and |cRXP_ENEMY_Winterfall Den Watchers|r until you collect |T135816:0|t[|cRXP_LOOT_Winterfall Ritual Totem|r]
.complete 8464,1 
.complete 8464,2 
.complete 8464,3 
.mob Winterfall Shaman
.mob Winterfall Den Watcher
.mob Winterfall Ursa
step
#loop
.line Winterspring,67.6,34.1,66.4,34.3,65.9,35.3,66.6,36.3,67.5,35.5,68.4,35.7,68.3,37.3,67.5,37.9,66.8,37.3,65.6,37.7,66.7,39.1,68.0,39.4,68.8,37.7,68.4,35.7,67.6,34.1
.goto Winterspring,67.60,34.10,25,0
.goto Winterspring,66.40,34.30,25,0
.goto Winterspring,65.90,35.30,25,0
.goto Winterspring,66.60,36.30,25,0
.goto Winterspring,67.50,35.50,25,0
.goto Winterspring,68.40,35.70,25,0
.goto Winterspring,68.30,37.30,25,0
.goto Winterspring,67.50,37.90,25,0
.goto Winterspring,66.80,37.30,25,0
.goto Winterspring,65.60,37.70,25,0
.goto Winterspring,66.70,39.10,25,0
.goto Winterspring,68.00,39.40,25,0
.goto Winterspring,68.80,37.70,25,0
.goto Winterspring,68.40,35.70,25,0
>>Kill |cRXP_ENEMY_Winterfall Ursa|r, |cRXP_ENEMY_Winterfall Shamans|r and |cRXP_ENEMY_Winterfall Den Watchers|r until you collect |T135816:0|t[|cRXP_LOOT_Winterfall Ritual Totem|r]
.collect 20742,1,8471,1 
.mob Winterfall Shaman
.mob Winterfall Den Watcher
.mob Winterfall Ursa
step
#loop
.line Winterspring,67.6,34.1,66.4,34.3,65.9,35.3,66.6,36.3,67.5,35.5,68.4,35.7,68.3,37.3,67.5,37.9,66.8,37.3,65.6,37.7,66.7,39.1,68.0,39.4,68.8,37.7,68.4,35.7,67.6,34.1
.goto Winterspring,67.60,34.10,25,0
.goto Winterspring,66.40,34.30,25,0
.goto Winterspring,65.90,35.30,25,0
.goto Winterspring,66.60,36.30,25,0
.goto Winterspring,67.50,35.50,25,0
.goto Winterspring,68.40,35.70,25,0
.goto Winterspring,68.30,37.30,25,0
.goto Winterspring,67.50,37.90,25,0
.goto Winterspring,66.80,37.30,25,0
.goto Winterspring,65.60,37.70,25,0
.goto Winterspring,66.70,39.10,25,0
.goto Winterspring,68.00,39.40,25,0
.goto Winterspring,68.80,37.70,25,0
.goto Winterspring,68.40,35.70,25,0
.goto Winterspring,67.60,34.10,25,0
>>Kill |cRXP_ENEMY_Winterfall Ursa|r, |cRXP_ENEMY_Winterfall Shamans|r and |cRXP_ENEMY_Winterfall Den Watchers|r
.complete 8464,1 
.complete 8464,2 
.complete 8464,3 
.mob Winterfall Shaman
.mob Winterfall Den Watcher
.mob Winterfall Ursa
step
.goto Winterspring,62.2,36.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maethrya|r
.fly Thalanaar >> Fly to Thalanaar in Feralas
.target Maethrya
step
.goto Feralas,65.945,45.651
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kindal Moonweaver|r
.accept 3841 >> Accept An Orphan Looking For a Home
.target Kindal Moonweaver
step
#completewith next
.goto Thousand Needles,70.58,62.69,200 >> Travel to the Shimmering Flats
step
.goto Thousand Needles,78.347,74.725
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quentin|r
.turnin 3841 >> Turn in An Orphan Looking For a Home
.target Quentin
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Alliance
#group RestedXP SoD Preparation
#subgroup Preparation guide
#title 3 - 20 Questlog prep - Kalimdor
#name 3 - 20 Questlog prep - Dungeons and shopping (A)
step
.requires quest,2770
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.accept 2770 >> Accept Gahz'rilla
.target Wizzle Brassbolts
step
.requires quest,2768
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.accept 2768 >> Accept Divino-matic Rod
.target Chief Engineer Bilgewhizzle
step
.requires quest,2768,2770,2994
#label EnterZF
.goto Tanaris,38.91,20.78,40,0
.goto Tanaris,38.731,19.839
>>|cRXP_WARN_Make sure to bring at least one person with|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_if you need to summon Gahzrilla|r
.subzone 978 >> Find a group and enter Zul'Farrak for quests
step
.requires quest,2768,2994
#completewith next
+Ascend the Pyramid
>>Kill the |cRXP_ENEMY_Sandfury Executioner|r. Loot him for the |cRXP_LOOT_Executioner's Key|r
>>|cRXP_WARN_Anyone in the party may loot the|r |cRXP_LOOT_Key|r
>>|cRXP_WARN_Use the|r |cRXP_LOOT_Executioner's Key|r |cRXP_WARN_on one of the |cRXP_PICK_Troll Cages|r to free |cRXP_FRIENDLY_Sergeant Bly|r and his band|r
.collect 8444,1 
.disablecheckbox
.isOnQuest 2768
.mob Sandfury Executioner
step
.requires quest,2994
>>Defend |cRXP_FRIENDLY_Sergeant Bly|r and his band, then move down with them after a short period of time
>>Kill |cRXP_ENEMY_Nekrum Gutchewer|r. Loot him for |cRXP_LOOT_Nekrum's Medallion|r
>>After you kill |cRXP_ENEMY_Nekrum Gutchewer|r, eat and drink then talk to |cRXP_FRIENDLY_Sergeant Bly|r to fight him
.complete 2991,1 
.isOnQuest 2991
.skipgossip
step
.requires quest,2768
>>Defend |cRXP_FRIENDLY_Sergeant Bly|r and his band, then move down with them after a short period of time
>>After you kill |cRXP_ENEMY_Nekrum Gutchewer|r, eat and drink then talk to |cRXP_FRIENDLY_Sergeant Bly|r to fight him
>>Kill |cRXP_ENEMY_Sergeant Bly|r. Loot him for the |cRXP_LOOT_Divino-matic Rod|r
.complete 2768,1 
.isOnQuest 2768
.skipgossip
step
.requires quest,2770
#label Gahzrilla
>>|cRXP_WARN_Use the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_on the |cRXP_PICK_Gong of Zul'Farrak|r to summon|r |cRXP_ENEMY_Gahz'rilla|r
>>Kill |cRXP_ENEMY_Gahz'rilla|r. Loot him for |cRXP_LOOT_Gahz'rilla's Electrified Scale|r
>>|cRXP_WARN_If no one in your party has the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_you will not be able to summon|r |cRXP_ENEMY_Gahz'rilla|r
.complete 2770,1 
.mob Gahz'rilla
.isOnQuest 2770
step
.goto Tanaris,51.0,29.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bera Stonehammer|r
.fly Nijel's Point >> Fly to Nijel's Point in Desolace
.target Bera Stonehammer
step
.requires quest,7065
.goto Desolace,64.0,10.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Marandis|r
.accept 7065 >> Accept Corruption of Earth and Seed
.target Keeper Marandis
step
.requires quest,7065,7066
#completewith Maraudonend
.goto Desolace,29.89,62.44,0
.goto 2100,38.43,57.97
.subzone 2100 >> Travel to Maraudon and gather a group
step
.requires quest,7065
>>Kill |cRXP_ENEMY_Princess Theradras|r, last boss of the dungeon
.complete 7065,1 
.mob Princess Theradras
.isOnQuest 7065
step
.requires quest,7066
#label Maraudonend
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaetar's Spirit|r after defeating |cRXP_ENEMY_Princess Theradras|r
.accept 7066 >> Accept Seed of Life
.target Zaetar's Spirit
step
#completewith next
.zone Desolace >> Exit Maraudon and head back to Nijel's Point
step
.goto Desolace,64.6,10.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baritanas Skyriver|r
.fly Ratchet >> Fly to Ratchet in The Barrens
.target Baritanas Skyriver
step
.goto The Barrens,26,73.2
.zone Stranglethorn Vale >> Take a boat to Booty Bay
.zoneskip Blasted Lands
step
.requires quest,2994
.goto Stranglethorn Vale,27.6,77.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gyll|r
.fly Nethergarde Keep >> Fly to Nethergarde Keep in Blasted Lands
.target Gyll
step
.requires quest,2994
.isQuestComplete 2991
.goto Blasted Lands,66.898,19.469
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thadius Grimshade|r atop the Tower
.turnin 2991 >> Turn in Nekrum's Medallion
.accept 2992 >> Accept The Divination
.timer 11,The Divination RP
.turnin 2992 >> Turn in The Divination
.accept 2993 >> Accept Return to the Hinterlands
.target Thadius Grimshade
step
.requires quest,2994
.isQuestTurnedIn 2991
.goto Blasted Lands,66.898,19.469
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thadius Grimshade|r atop the Tower
.accept 2992 >> Accept The Divination
.timer 11,The Divination RP
.turnin 2992 >> Turn in The Divination
.accept 2993 >> Accept Return to the Hinterlands
.target Thadius Grimshade
step
.goto Blasted Lands,65.6,24.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alexandra Constantine|r
.fly Aerie Peak >> Fly to Aerie Peak in The Hinterlands
.target Alexandra Constantine
step
.requires quest,2994
.isOnQuest 2993
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.turnin 2993 >> Turn in Return to the Hinterlands
.accept 2994 >> Accept Saving Sharpbeak
.target Gryphon Master Talonaxe
step
.requires quest,2994
.isQuestTurnedIn 2993
.goto The Hinterlands,9.752,44.473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.accept 2994 >> Accept Saving Sharpbeak
.target Gryphon Master Talonaxe
step
.requires quest,2994
.goto The Hinterlands,59.6,77.4
>>Kill the |cRXP_ENEMY_Vile Priestess Hexx|r. Loot it for its |cRXP_LOOT_Hexx's Key|r
>>|cRXP_WARN_She can be found at the very top of Jintha'Alor|r
.collect 9472,1,2994,1 
step
.requires quest,2994
#completewith next
>> Head north to another cave passage
.goto The Hinterlands,56,68,30
.goto The Hinterlands,53.6,66.8
step
.requires quest,2994
.goto The Hinterlands,53.6,66.8
>>Open Sharpbeak's cage and release him
.complete 2994,1 
step
>>Kill enemies in The Hinterlands. Loot them for |cRXP_LOOT_OOX-09/HL Distress Beacon|r
.collect 8704,1 
step
.goto The Hinterlands,49.30,37.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r
>>|cRXP_WARN_Use |T132836:0|t[OOX-09/HL Distress Beacon]|r
.accept 485 >>Accept Find OOX-09/HL!
.turnin 485 >>Turn in Find OOX-09/HL!
.target Homing Robot OOX-09/HL
.itemcount 8704,1 
.use 8704
step
.goto The Hinterlands,49.35,37.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to start the escort
.accept 836 >>Accept Rescue OOX-09/HL!
.target Homing Robot OOX-09/HL
.isQuestTurnedIn 485
step
.goto The Hinterlands,79.47,61.21
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to the coast
>>|cRXP_WARN_This escort can be hard to solo|r
>>|cRXP_WARN_A pack of 3 level 46|r |cRXP_ENEMY_Marauding Owlbeasts|r |cRXP_WARN_will spawn south of Skulk Rock, on the road. They enrage at low HP, so try to kill one at a time|r
>>|cRXP_WARN_A pack of 3 level 47|r |cRXP_ENEMY_Vilebranch Ambushers|r |cRXP_WARN_will spawn in the woods north of Jintha'Alor. They execute when you're below 20% health. Use long CC if you can, and have the chicken tank one or two of them until it's around half HP|r
.complete 836,1 
.target Homing Robot OOX-09/HL
.mob Marauding Owlbeast
.unitscan Vilebranch Ambusher
.isQuestTurnedIn 485
step
.goto The Hinterlands,79.47,61.21
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to the coast
>>|cRXP_WARN_This escort can be fatal. Don't hesitate to abandon the attempt if it puts your run at risk|r
>>|cRXP_WARN_A pack of 3 level 46|r |cRXP_ENEMY_Marauding Owlbeasts|r |cRXP_WARN_will spawn south of Skulk Rock, on the road. They enrage at low HP, so try to kill one at a time|r
>>|cRXP_WARN_A pack of 3 level 47|r |cRXP_ENEMY_Vilebranch Ambushers|r |cRXP_WARN_will spawn in the woods north of Jintha'Alor. They execute when you're below 20% health. Use long CC if you can, and have the chicken tank one or two of them until it's around half HP|r
.complete 836,1 
.target Homing Robot OOX-09/HL
.mob Marauding Owlbeast
.unitscan Vilebranch Ambusher
.isQuestTurnedIn 485
step << !Mage
#completewith next
.goto The Hinterlands,11.0,46.0
.subzone 348 >> Head back to Aerie Peak
step << !Mage
.goto The Hinterlands,11.0,46.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guthrum Thunderfist|r
.fly Booty Bay >> Fly to Booty Bay in Stranglethorn Vale
.target Guthrum Thunderfist
.zoneskip Stranglethorn Vale
step << Mage
.cast 3561 >>Cast |T135763:0|t[Teleport: Stormwind]
.zoneskip Stormwind
step << Mage
.goto Stormwind,66.2,62.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Booty Bay >> Fly to Booty Bay in Stranglethorn Vale
.target Dungar Longdrink
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 2767 >> Turn in Rescue OOX-22/FE!
.target Oglethorpe Obnoticus
step
.requires !quest,648
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 648 >> Turn in Rescue OOX-17/TN!
.target Oglethorpe Obnoticus
step
.requires !quest,836
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 836 >> Turn in Rescue OOX-09/HL!
.target Oglethorpe Obnoticus
step
.requires quest,4263,4286,4123
.goto Stranglethorn Vale,27.6,77.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gyll|r
.fly Morgan's Vigil >> Fly to Morgan's Vigil in Burning Steppes
.target Gyll
.zoneskip Burning Steppes
step
.requires quest,4263
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.goto Burning Steppes,85.4,70.0
.accept 4263 >>Accept Incendius!
.target Jalinda Sprig
step
.requires quest,4286
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.goto Burning Steppes,84.6,68.6
.accept 4286 >>Accept The Good Stuff
.target Oralius
step
.requires quest,4123
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.goto Burning Steppes,65.2,23.8
.accept 4123 >>Accept The Heart of the Mountain
.target Maxwort Uberglint
step
.requires quest,4263,4286,4123
#completewith HartoftheMountain
.subzone 1584 >>Find a group for Blackrock Depths
>>|cRXP_WARN_Be aware that this is level 55 content and you need a strong group for it|r
step
.requires quest,4286
#completewith HartoftheMountain
>>Kill Dwarves and loot them for |cRXP_LOOT_Dark Iron Fanny Pack|r
.collect 11468,20,4286,1 
step
.requires quest,4263
>>Make your way to the great forge and kill |cRXP_ENEMY_Lord Incendius|r
.complete 4263,1 
step
.requires quest,4123
>>Make your way to the Dark Iron vault and kill |cRXP_ENEMY_Watchman Doomgrip|r, after he is dead you can loot the Heart from one of the small vaults in the back
#label HartoftheMountain
.collect 11309,1,4123,1 
.mob Watchman Doomgrip
step
.requires quest,4286
>>Complete looting enough |cRXP_LOOT_Dark Iron Fanny Pack|r
.collect 11468,20,4286,1 
step
.goto Searing Gorge,37.8,30.6
.zone Stormwind City >> Make your way to a capital of your choice. If you exit BRD on foot, closest flight path is at Thorium Point.
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lanie Reed|r
.fly Stormwind City >> Fly to Stormwind City
.target Lanie Reed
step
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitchr|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.blastedLands
.target Auctioneer Fitch
step
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 2592,60,7807,7791,7792,7802 
.target Auctioneer Fitch
step
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 4306,60,7793,7803,7808,7798 
.target Auctioneer Fitch
step
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 4338,60,7794,7804,7809,7799 
.target Auctioneer Fitch
step
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.questitemcount 14047,60,7795,7805,7811,7800,6031 
.target Auctioneer Fitch
step
.isQuestAvailable 6032
.skill tailoring,<280,1
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 14342,2 
.target Auctioneer Fitch
step
.isQuestAvailable 3501
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 10593,1 
.target Auctioneer Fitch
step
.isQuestAvailable 3764
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11018,20 
.target Auctioneer Fitch
step
.isQuestAvailable 3764
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11040,10 
.target Auctioneer Fitch
step
.isQuestTurnedIn 3764
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11040,10 
.target Auctioneer Fitch
step
.isQuestAvailable 3785
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitch|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 11040,10 
.target Auctioneer Fitch
step
.isQuestAvailable 3842
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgus Stoutarm|r or any of the auctioneers
.collect 3825,2 
.target Borgus Stoutarm
step
.isQuestAvailable 6610
.skill cooking,<225,1
.goto Stormwind City,53.6,60.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Fitchr|r
>>|cRXP_BUY_Buy the following from the Auction House|r
.collect 12207,12 
.collect 7974,10 
.target Auctioneer Fitch
step
.isQuestAvailable 6610
.skill cooking,<225,1
.goto Stormwind City,60.6,63.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elaine Trias|r
>>|cRXP_BUY_Buy Alterac Swiss from cheese vendor|r
.collect 8932,20 
.target Elaine Trias
step
+Congratulations on finishing the prep guide! Make sure to click through the turn in guide and check out your turn in route.
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Horde
#group RestedXP SoD Preparation
#title Turn in Guide
#name Turn in Guide (Horde)
step
.home 2255>>Make sure your Hearthstone is set to Everlook in Winterspring before you start the route.
>>You can leave all your cloth in the bank to save bag space.
step
.isQuestAvailable 6031
>> Keep at least 30 Runecloth for timbermaw turn in
.collect 14047,30
step
#completewith BadlandsEND
.zone Badlands >> We will be starting our route in Badlands, make your way there.
step
.goto Badlands,2.91,45.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorn|r
.turnin 793 >> Turn in Broken Alliances
.target Gorn
.isQuestComplete 782
step
.goto Badlands,3.0,47.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vivian|r
.turnin 7201 >> Turn in The Last Element
.target Shadowmage Vivian Lagrave
.isQuestComplete 7201
step
#label BadlandsEND
.goto Badlands,3.6,48.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thunderheart|r
>>|cRXP_WARN_If the quest is not showing, wait for him to finish his patrol once and return to Kartgath|r
.turnin 3907 >>Turn in Disharmony of Fire
.target Thunderheart
.isQuestComplete 3907
step
.goto Badlands,4.0,44.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fly Thorium Point >> Fly to Thorium Point in Searing Gorge
.zoneskip Searing Gorge
.target Gorrik
step
.isQuestComplete 3463
.goto Searing Gorge,39.165,38.997
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Squire Maltrake|r
.turnin 3463 >> Turn in Set Them Ablaze!
.target Squire Maltrake
step
.isQuestTurnedIn 3463
.goto Searing Gorge,38.847,38.985
>>Click the |cRXP_PICK_Hoard of the Black Dragonflight|r on the ground and then click again to turn it in
.accept 3481 >> Accept Trinkets...
.turnin 3481 >> Turn in Trinkets...
step
.isQuestTurnedIn 3481
.use 10569 >>|cRXP_WARN_Open the|r |T132595:0|t[Hoard of the Black Dragonflight]
+|cRXP_WARN_Ensure you keep the|r |T134430:0|t[Black Dragonflight Molt]|cRXP_WARN_. Do not destroy it. You will need it later|r
.collect 10575,1
step
.goto Searing Gorge,34.8,30.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grisha|r
.fly Flame Crest >> Fly to Flame Crest in Burning Steppes
.zoneskip Burning Steppes
.target Grisha
step
.isQuestComplete 4123
.goto Burning Steppes,65.2,23.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.turnin 4123 >> Turn in The Heart of the Mountain
.target Maxwort Uberglint
step
.xp <52,1
.goto Burning Steppes,95.09,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus|r
>>|cRXP_WARN_Open your|r |T132595:0|t[Hoard of the Black Dragonflight] |cRXP_WARN_if you haven't yet|r
.accept 4022 >>Accept A Taste of Flame
.turnin 4022 >>Turn in A Taste of Flame
.target Cyrus Therepentous
.isQuestTurnedIn 3481
.itemcount 10575,1
step
.goto Burning Steppes,65.6,24.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus|r
.fly Stonard >> Fly to Stonard in Swamp of Sorrows
.zoneskip Swamp of Sorrows
.target Vahgruk
step
.itemcount 4056,1
.goto Swamp of Sorrows,22.90,48.30
.use 4056 >>|cRXP_WARN_Use the |T134939:0|t[|cRXP_LOOT_Cortello's Riddle|r] to start the quest|r
.accept 624 >>Accept Cortello's Riddle
.turnin 624 >>Turn in Cortello's Riddle
step
#completewith next
.goto Blasted Lands,52.2,10.8
.zone Blasted Lands >> Travel south to Blasted Lands
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazial|r
.accept 2583 >>Accept A Boar's Vitality
.turnin 2583 >>Turn in A Boar's Vitality
.itemcount 8392,3
.itemcount 8393,2
.itemcount 8394,1
.goto Blasted Lands,50.64,14.30
.target Bloodmage Drazial
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazial|r
.accept 2585 >>Accept The Decisive Striker
.turnin 2585 >>Turn in The Decisive Striker
.itemcount 8393,3
.itemcount 8396,2
.itemcount 8392,1
.goto Blasted Lands,50.64,14.30
.target Bloodmage Drazial
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazial|r
.accept 2581 >>Accept Snickerfang Jowls
.turnin 2581 >>Turn in Snickerfang Jowls
.itemcount 8391,3
.itemcount 8392,2
.itemcount 8393,1
.goto Blasted Lands,50.64,14.30
.target Bloodmage Drazial
step
.goto Blasted Lands,50.55,14.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lynnore|r
.accept 2601 >>Accept The Basilisk's Bite
.turnin 2601 >>Turn in The Basilisk's Bite
.itemcount 8394,10
.itemcount 8396,2
.goto Blasted Lands,50.64,14.30
.target Bloodmage Lynnore
step
.goto Blasted Lands,50.55,14.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lynnore|r
.accept 2603 >>Accept Vulture's Vigor
.turnin 2603 >>Turn in Vulture's Vigor
.itemcount 8396,10
.itemcount 8391,2
.goto Blasted Lands,50.64,14.30
.target Bloodmage Lynnore
step
.goto Blasted Lands,51.8,35.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kum'isha|r
.accept 3501 >>Accept Everything Counts In Large Amounts
.turnin 3501 >>Turn in Everything Counts In Large Amounts
.target Kum'isha the Collector
.itemcount 10593,1
step
.goto Swamp of Sorrows,34.30,66.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fallen Hero of the Horde|r at the Blasted Lands border
.accept 2784 >>Accept Fall from Grace
.target Fallen Hero of the Horde
step
.goto Swamp of Sorrows,34.30,66.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fallen Hero of the Horde|r and go through the whole dialogue
.complete 2784,1 
.target Fallen Hero of the Horde
.skipgossip
step
.goto Blasted Lands,52.76,2.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 2784 >>Turn in Fall From Grace
.accept 2621 >>Accept The Disgraced One
.target Fallen Hero of the Horde
step
#completewith next
.goto Swamp of Sorrows,46.0,54.2,50,0
.subzone 75 >>Travel to Stonard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ruag|r
>>|cRXP_WARN_He is at the top of the tower|r
.turnin 2621 >>Turn in The Disgraced One
.accept 2622 >>Accept The Missing Orders
.goto Swamp of Sorrows,47.78,54.94
.target Dispatch Commander Ruags
step
.goto Swamp of Sorrows,44.96,57.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bengor|r
.turnin 2622 >>Turn in The Missing Orders
.target Bengor
step
.goto Swamp of Sorrows,46.0,54.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breyk|r
.fly Booty Bay >> Fly to Booty Bay in Stranglethorn Vale
.zoneskip Stranglethorn Vale
.target Breyk
step
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 648 >> Turn in Rescue OOX-17/TN!
.target Oglethorpe Obnoticus
.isQuestComplete 648
step
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 836 >> Turn in Rescue OOX-09/HL!
.target Oglethorpe Obnoticus
.isQuestComplete 836
step
.goto Stranglethorn Vale,28.40,76.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 3721 >>Turn in An OOX of Your Own
.target Oglethorpe Obnoticus
.isQuestTurnedIn 648
.isQuestTurnedIn 836
.isQuestTurnedIn 2767
step
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sprogger|r
.turnin 8554 >>Turn in Facing Negolas
.target Sprogger
.isQuestComplete 8554
step
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tExit Booty Bay and head towards |cRXP_FRIENDLY_Princess Poobah|r
.turnin 630 >>Turn in Message in a Bottle
.target Princess Poobah
.isQuestComplete 630
step << Druid
.cast 18960 >> Cast |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << !Druid
.hs >> Hearthstone to Everlook
.zoneskip Winterspring
.use 6948
step << !Druid
.isQuestComplete 7066
.goto Winterspring,60.4,36.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yugrek|r
.fly South of Lake >> Fly to South of Lake in Moonglade
.zoneskip Moonglade
.target Yugrek
step
.goto Moonglade,36.178,41.798
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 7066 >> Turn in Seed of Life
.target Keeper Remulos
.isQuestComplete 7066
step
#completewith TimbermawEND
.subzone 1216 >> Head South towards Timbermaw Cavern
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20741 >>|cRXP_WARN_Use the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r] to start the quest|r
.accept 8470 >> Accept Deadwood Ritual Totem
.turnin 8470 >> Turn in Deadwood Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20741,1 
.target Kernda
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20742 >>|cRXP_WARN_Use the |T135816:0|t[|cRXP_LOOT_Winterfall Ritual Totem|r] to start the quest|r
.accept 8471 >> Accept Winterfall Ritual Totem
.turnin 8471 >> Turn in Winterfall Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20742,1 
.target Kernda
step
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
.accept 6031 >> Accept Runecloth
.turnin 6031 >> Turn in Runecloth
.reputation 576,friendly,<0,1 
.itemcount 14047,30 
.target Meilosh
step
#label TimbermawEND
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
.accept 6032 >> Accept Sacred Cloth
.turnin 6032 >> Turn in Sacred Cloth
.skill tailoring,<280,1 
.reputation 576,friendly,<0,1 
.itemcount 14342,2 
.target Meilosh
step
#completewith next
.goto Winterspring,27.736,34.499
>> Run towards Winterspring exit
step
.isQuestComplete 8464
.goto Winterspring,27.736,34.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.turnin 8464 >> Turn in Winterfall Activity
.target Salfa
step
#completewith FelwoodEND
.zoneskip Felwood >> Run back through Timbermaw Hold towards Felwood
step
.isQuestComplete 8461
.goto Felwood,64.769,8.131
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.turnin 8461 >> Turn in Deadwood of the North
.target Nafien
step
.isQuestComplete 4102
.goto Felwood,46.60,83.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maybess|r
.turnin 4102 >>Turn in Cleansing Felwood
step
.isQuestComplete 5156
.goto Felwood,50.90,81.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn|r
.turnin 5156 >>Turn in Verifying the Corruption
.target Taronn Redfeather
step
.isQuestComplete 5385
.goto Felwood,51.35,82.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessir|r
.turnin 5385 >>Turn in The Remains of Trey Lightforge
.target Jessir Moonbow
step
.isQuestComplete 5242
.goto Felwood,51.23,82.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.turnin 5242 >>Turn in A Final Blow
.target Greta Mosshoof
step
.goto Felwood,34.4,53.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakkar|r
.fly Valormok >> Fly to Valormok in Azshara
.zoneskip Azshara
.target Brakkar
step
.isQuestTurnedIn 3517
.goto Azshara,22.60,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.accept 3561 >>Accept Delivery to Archmage Xylem
.accept 3518 >>Accept Delivery to Magatha
.accept 3541 >>Accept Delivery to Jes'rimon
.accept 3542 >>Accept Delivery to Andron Gant
.target Jediga
step
.goto Azshara,22.26,51.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ag'tor|r
.accept 3507 >>Accept Betrayed
.target Ag'tor Bloodfist
.isQuestTurnedIn 3506
step
.isOnQuest 3561
.goto Azshara,28.11,50.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanath|r
.turnin 3503 >>Turn in Meeting with the Master
.target Sanath Lim-yo
step
.isOnQuest 3561
.goto Azshara,29.7,40.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Xylem|r
.turnin 3561 >>Turn in Delivery to Archmage Xylem
.accept 3565 >>Accept Xylem's Payment to Jediga
.target Archmage Xylem
step
.isQuestTurnedIn 3561
.goto Azshara,29.7,40.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Xylem|r
.accept 3565 >>Accept Xylem's Payment to Jediga
.target Archmage Xylem
step
.isOnQuest 3565
.goto Azshara,26.466,46.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyrill|r
>>|cRXP_WARN_This will teleport you back down|r
.turnin 3421 >> Turn in Return Trip
.timer 8,Return Trip RP
.target Nyrill
step
.isOnQuest 3565
.goto Azshara,22.56,51.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.turnin 3565 >>Turn in Xylem's Payment to Jediga
.target Jediga
step << Mage
.cast 3567 >>Cast |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << !Mage
.goto Azshara,22.0,49.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kroum|r
.fly Orgrimmar >> Fly to Orgrimmar
.zoneskip Orgrimmar
.target Kroum
step
.goto Orgrimmar,75.20,34.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.turnin 3507 >>Turn in Betrayed
.target Belgrom Rockmaul
.isOnQuest 3507
step
.goto Orgrimmar,55.52,34.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jes'rimon|r
.turnin 3541 >>Turn in Delivery to Jes'rimon
.accept 3563 >>Accept Jes'rimon's Payment to Jediga
.target Jes'rimon
.isOnQuest 3541
step
.goto Orgrimmar,55.52,34.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jes'rimon|r
.accept 3563 >>Accept Jes'rimon's Payment to Jediga
.target Jes'rimon
.isQuestTurnedIn 3541
step
#completewith OrgCloth
.goto Orgrimmar,49.8,70.0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karus|r
+Retrieve all the cloth you need from the Bank for Orgrimmar turn-ins
.target Karus
step
.goto Orgrimmar,63.62,51.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rashona|r
.turnin 7826 >>Turn in A Donation of Wool
.target Rashona Straglash
step
.goto Orgrimmar,63.62,51.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rashona|r
.turnin 7827 >>Turn in A Donation of Silk
.target Rashona Straglash
step
.goto Orgrimmar,63.62,51.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rashona|r
.turnin 7831 >>Turn in A Donation of Mageweave
.target Rashona Straglash
step
#label OrgCloth
.isQuestTurnedIn 7826
.isQuestTurnedIn 7827
.isQuestTurnedIn 7831
.goto Orgrimmar,63.62,51.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rashona|r
.turnin 7824 >>Turn in A Donation of Runecloth
.target Rashona Straglash
step
.goto Orgrimmar,37.69,87.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vehena|r
.turnin 7833 >>Turn in A Donation of Wool
.target Vehena
step
.goto Orgrimmar,37.69,87.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vehena|r
.turnin 7834 >>Turn in A Donation of Silk
.target Vehena
step
.goto Orgrimmar,37.69,87.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vehena|r
.turnin 7835 >>Turn in A Donation of Mageweave
.target Vehena
step
.isQuestTurnedIn 7833
.isQuestTurnedIn 7834
.isQuestTurnedIn 7835
.goto Orgrimmar,37.69,87.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vehena|r
.turnin 7836 >>Turn in A Donation of Runecloth
.target Vehena
step
.goto Orgrimmar,54.10,68.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grysha|r
.home >> Set your Hearthstone to Orgrimmar
.target Innkeeper Grysha
step
.goto Durotar,50.8,13.6
.zone Tirisfal Glades >> Take a zeppelin to Tirisfal Glades
.zoneskip Tirisfal Glades
step
#completewith BulwarkEND
.subzone 152 >> Travel to the Bulwark
step
.isQuestComplete 6390
.goto Tirisfal Glades,83.30,72.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mickey|r
.turnin 6390 >>Turn in A Plague Upon Thee
.target Mickey Levine
step
.isQuestComplete 5236
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5238 >>Turn in Mission Accomplished!
.target High Executor Derrington
step
#label BulwarkEND
.isQuestComplete 105
.goto Western Plaguelands,83.0,69.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Derrington|r
.turnin 105 >> Turn in Alas, Andorhal
.target High Executor Derrington
step
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.isQuestTurnedIn 5152
.accept 5153 >> Accept A Strange Historian
.target Marlene Redpath
step
.goto Western Plaguelands,49.696,76.754
>>Click |cRXP_PICK_Joseph Redpath's Monument|r. Loot it for |cRXP_LOOT_Joseph's Wedding Ring|r
.complete 5153,1 
.isOnQuest 5153
step
.isQuestComplete 5153
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.turnin 5153 >>Turn in A Strange Historian
.target Chromie
step
.goto Alterac Mountains,80.3,38.1
.zone Western Plaguelands,1 >> Run south into Alterac Mountains
step
.isQuestComplete 2937
.goto Hillsbrad Foothills,61.4,19.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Lydon|r
.turnin 2937 >> Turn in Summoning Shadra
.accept 2938 >> Accept Venom to the Undercity
.target Apothecary Lydon
step
.isQuestTurnedIn 2937
.goto Hillsbrad Foothills,61.4,19.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apothecary Lydon|r
.accept 2938 >> Accept Venom to the Undercity
.target Apothecary Lydon
step
.goto Undercity,63.6,48.6,-1
.goto Hillsbrad Foothills,60.2,18.6,-1
.fly Revantusk Village >> Fly to Revantusk Village in The Hinterlands
.zoneskip The Hinterlands
.target Zarise
.target Michael Garrett
step
.goto The Hinterlands,78.20,81.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yayo'jin|r
.turnin 7862 >>Turn in Job Opening: Guard Captain of Revantusk Village
.target Primal Torntusk
.isQuestComplete 7862
step
.goto The Hinterlands,78.20,81.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yayo'jin|r
.turnin 7861 >>Turn in Wanted: Vile Priestess Hexx and Her Minions
.target Primal Torntusk
.isQuestComplete 7861
step
.goto The Hinterlands,78.20,81.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Primal Torntusk|r
.turnin 7850 >>Turn in Dark Vessels
.target Primal Torntusk
.isQuestComplete 7850
step
.goto The Hinterlands,79.16,79.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
.turnin 7849 >>Turn in Separation Anxiety
.target Huntsman Markhor
.isQuestComplete 7849
step
#completewith ArathiEND
.goto The Hinterlands,81.6,81.8,-1
.goto Undercity,63.6,48.6,-1
.goto Hillsbrad Foothills,60.2,18.6,-1
.fly Hammerfall >> Fly to Hammerfall in Arathi Highlands
.zoneskip Arathi Highlands
.target Gorkas
.target Michael Garrett
.target Zarise
step
#label ArathiEND
.isQuestComplete 8121
.goto Arathi Highlands,73.2,29.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deathmaster Dwire|r
.turnin 8121 >> Turn in Take Four Bases
.target Deathmaster Dwire
step << Mage
.cast 3563 >>Cast |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << !Mage
#completewith UCCloth
.goto The Hinterlands,81.6,81.8,-1
.goto Hillsbrad Foothills,60.2,18.6,-1
.goto Arathi Highlands,73.0,32.6,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urda|r
.fly Undercity >> Fly to Undercity
.zoneskip Undercity
.target Urda
.target Gorkas
.target Zarise
step
.isQuestComplete 2938
.goto Undercity,48.6,69.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faranell|r
.turnin 2938 >> Turn in Venom to the Undercity
.target Master Apothecary Faranell
step
.isQuestComplete 4642
.goto Undercity,48.50,71.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cuely|r
.turnin 4642 >>Turn in Melding of Influences
.target Chemist Cuely
step
.isQuestTurnedIn 5023
.goto Undercity,69.79,43.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bauhaus|r
.accept 5049 >>Accept The Jeremiah Blues
.target Royal Overseer Bauhaus
step
.isOnQuest 5049
.goto Undercity,67.61,44.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jeremiah|r
.turnin 5049 >>Turn in The Jeremiah Blues
.accept 5050 >>Accept Good Luck Charm
.target Jeremiah Payson
step
.goto Undercity,54.81,76.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andron|r
.turnin 3542 >>Turn in Delivery to Andron Gant
.accept 3564 >>Accept Andron's Payment to Jediga
.target Andron Gant
.isOnQuest 3542
step
#completewith UCCloth
.goto Undercity,66.0,42.8,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ophelia Montague|r
+Retrieve all the cloth you need from the Bank for Undercity turn-ins
.target Ophelia Montague
step
.goto Undercity,72.6,29.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ralston Farnsley|r
.turnin 7813 >>Turn in A Donation of Wool
.target Ralston Farnsley
step
.goto Undercity,72.6,29.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ralston Farnsley|r
.turnin 7814 >>Turn in A Donation of Silk
.target Ralston Farnsley
step
.goto Undercity,72.6,29.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ralston Farnsley|r
.turnin 7817 >>Turn in A Donation of Mageweave
.target Ralston Farnsley
step
#label UCCloth
.isQuestTurnedIn 7813
.isQuestTurnedIn 7814
.isQuestTurnedIn 7817
.goto Undercity,72.6,29.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ralston Farnsley|r
.turnin 7818 >>Turn in A Donation of Runecloth
.target Ralston Farnsley
step << Mage
.cast 3567 >>Cast |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
.isQuestComplete 4502
step << !Mage
#completewith next
.goto Tirisfal Glades,61.85,66.59,60 >>Exit Undercity
.zoneskip Tirisfal Glades
step << !Mage
.goto Tirisfal Glades,61.06,58.86,12,0
.goto Tirisfal Glades,61.51,59.01,10,0
.goto Tirisfal Glades,61.27,59.22,8,0
.goto Tirisfal Glades,61.13,58.84,8,0
.goto Tirisfal Glades,61.38,58.71,8,0
.goto Tirisfal Glades,61.34,59.17,8,0
.goto Tirisfal Glades,60.51,58.69,-1
.goto Tirisfal Glades,60.94,46.35,-1
>>Go up the Zeppelin Tower
.zone Durotar >>Take the Zeppelin to Durotar
.zoneskip Orgrimmar
step
.isQuestComplete 4502
.goto Orgrimmar,45.2,63.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Ratchet >> Fly to Ratchet in The Barrens
.zoneskip The Barrens
.target Doras
step
.isQuestComplete 4502
.goto The Barrens,62.50,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv|r
.turnin 4502 >>Turn in Volcanic Activity
.target Liv Rizzlefix
step << Mage
.cast 3566 >> Cast |T135765:0|t[Teleport: Thunder Bluff]
.zoneskip Thunder Bluff
step << !Mage
.goto The Barrens,63.0,37.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.zoneskip Thunder Bluff
.target Bragok
step
.goto Thunder Bluff,45.80,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pala|r
.accept 3762 >>Accept Assisting Arch Druid Runetotem
.target Innkeeper Pala
step
.goto Thunder Bluff,70.20,30.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magatha|r
.turnin 3518 >>Turn in Delivery to Magatha
.target Magatha Grimtotem
.isOnQuest 3518
step
.goto Thunder Bluff,70.20,30.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magatha|r
.accept 3562 >>Accept Magatha's Payment to Jediga
.target Magatha Grimtotem
.isQuestTurnedIn 3518
step
.itemcount 11018,20
isOnQuest 3762
.goto Thunder Bluff,78.50,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hamuul|r
.turnin 3762 >>Turn in Assisting Arch Druid Runetotem
.accept 3761 >>Accept Un'Goro Soil
.target Arch Druid Hamuul Runetotem
step
.itemcount 11018,20
isQuestTurnedIn 3762
.goto Thunder Bluff,78.50,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hamuul|r
.accept 3761 >>Accept Un'Goro Soil
.target Arch Druid Hamuul Runetotem
step
.itemcount 11018,20
.goto Thunder Bluff,77.30,22.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghede|r
.turnin 3761 >>Turn in Un'Goro Soil
.target Ghede
step
.isQuestTurnedIn 3761
.goto Thunder Bluff,78.40,28.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hamuul|r
.accept 3782 >>Accept Morrowgrain Research
.target Arch Druid Hamuul Runetotem
step
.isOnQuest 3782
.goto Thunder Bluff,71.00,33.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bashana|r
.turnin 3782 >>Turn in Morrowgrain Research
.target Bashana Runetotem
step
.isQuestTurnedIn 3782
.itemcount 11040,10
.goto Thunder Bluff,71.00,33.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bashana|r
.accept 3786 >>Accept Morrowgrain Research
.target Bashana Runetotem
step
.isOnQuest 3786
.itemcount 11040,10
.goto Thunder Bluff,71.00,33.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bashana|r
.turnin 3786 >> Turn in Morrowgrain Research
.target Bashana Runetotem
step
#completewith next
.isQuestAvailable 6610
.skill cooking,<225,1
.goto Thunder Bluff,45.8,64.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Pala|r
>>|cRXP_BUY_Buy Alterac Swiss from Thunder Bluff Innkeeper|r
.collect 8932,20 
.target Innkeeper Pala
step
.isQuestAvailable 6610
.skill cooking,<225,1
.goto Thunder Bluff,47.0,59.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atepa|r
>>Pick up cooking mats from the bank
.collect 12207,12 
.collect 7974,10 
.collect 8932,20 
.target Atepa
step
#completewith TBCloth
.goto Thunder Bluff,47.0,59.0,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Atepa|r
+Retrieve all the cloth you need from the Bank for Thunder bluff turn-ins
.target Atepa
step
.goto Thunder Bluff,43.8,42.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rumstag Proudstrider|r
.turnin 7820 >>Turn in A Donation of Wool
.target Rumstag Proudstrider
step
.goto Thunder Bluff,43.8,42.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rumstag Proudstrider|r
.turnin 7821 >>Turn in A Donation of Silk
.target Rumstag Proudstrider
step
.goto Thunder Bluff,43.8,42.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rumstag Proudstrider|r
.turnin 7822 >>Turn in A Donation of Mageweave
.target Rumstag Proudstrider
step
#label TBCloth
.isQuestTurnedIn 7820
.isQuestTurnedIn 7821
.isQuestTurnedIn 7822
.goto Thunder Bluff,43.8,42.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rumstag Proudstrider|r
.turnin 7823 >>Turn in A Donation of Runecloth
.target Rumstag Proudstrider
step
.isQuestComplete 7064
.goto Thunder Bluff,46.8,50.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Shadowprey Village >> Fly to Shadowprey Village in Desolace
.zoneskip Desolace
.target Tal
step
.goto Desolace,26.87,77.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Selendra|r
.turnin 7064 >> Turn in Corruption of Earth and Seed
.target Selendra
.isQuestComplete 7064
step
#completewith FeralasEnd
.goto Thunder Bluff,46.8,50.0,-1
.goto Desolace,21.6,74.0,-1
.fly Camp Mojache >> Fly to Camp Mojache in Feralas
.zoneskip Feralas
.target Thalon
.target Tal
step
.goto Feralas,76.18,43.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Talo|r
.turnin 3062 >>Turn in Dark Heart
.target Talo Thornhoof
.isQuestComplete 3062
step
.isQuestTurnedIn 2974
.goto Feralas,76.00,42.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krueg|r
.accept 2976 >> Accept A Grim Discovery
.target Krueg Skullsplitter
step
.isQuestTurnedIn 7730
.isQuestTurnedIn 7731
.goto Feralas,74.90,42.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.accept 7732 >> Accept Zukk'ash Report
.target Hadoken Swiftstrider
step
.isQuestTurnedIn 3128
.isQuestTurnedIn 3127
.goto Feralas,74.42,43.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
>>|cRXP_WARN_This quest has a bit of roleplay before you can turn it in. If you see a que forming, skip this step.|r
.accept 3129 >>Accept Weapons of Spirit
.target Witch Doctor Uzer'i
step
#label FeralasEnd
.isOnQuest 3129
.goto Feralas,74.42,43.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
>>|cRXP_WARN_Wait for him to finish making weapons|r
.turnin 3129 >>Turn in Weapons of Spirit
.target Witch Doctor Uzer'i
step
.goto Feralas,75.4,44.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Gadgetzan >> Fly to Gadgetzan in Tanaris
.zoneskip Tanaris
.target Shyn
step
.isQuestComplete 2770
#completewith next
.zone Thousand Needles >> Travel to the Shimmering Flats
step
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.turnin 2770 >> Turn in Gahz'rilla
.target Wizzle Brassbolts
.isQuestComplete 2770
step
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.turnin 2768 >> Turn in Divino-matic Rod
.target Chief Engineer Bilgewhizzle
.isQuestComplete 2768
step
.goto Tanaris,50.88,26.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4507 >>Turn in Pawn Captures Queen
.accept 4509 >>Accept Calm Before the Storm
.target Alchemist Pestlezugg
.isQuestComplete 4507
step
.goto Tanaris,50.88,26.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.accept 4509 >>Accept Calm Before the Storm
.target Alchemist Pestlezugg
.isQuestTurnedIn 4507
step
.goto Tanaris,52.40,28.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r
.accept 864 >> Accept Return to Apothecary Zinge
.target Chief Engineer Bilgewhizzle
.isQuestTurnedIn 654
step
.isQuestAvailable 6610
.skill cooking,<225,1
.itemcount 12207,12
.itemcount 7974,10
.itemcount 8932,20
.goto Tanaris,52.6,28.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dirge Quikcleave|r
.accept 6610 >> Accept Clamlette Surprise
.turnin 6610 >> Turn in Clamlette Surprise
.target Dirge Quikcleave
step
.isQuestTurnedIn 2873
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stoley|r
.accept 2874 >>Accept Deliver to MacKinley
.goto Tanaris,67.11,23.98
.target Stoley
step
.itemcount 9250,1
.goto Tanaris,67.0,23.8
.use 9250 >>|cRXP_WARN_Use the |T134939:0|t[|cRXP_LOOT_Ship Schedule|r] to start the quest|r
.accept 2876 >> Accept Ship Schedules
.turnin 2876 >> Turn in Ship Schedules
.target Security Chief Bilgewhizzle
step
#completewith ungoroEND
.goto Tanaris,51.6,25.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek Ragefist|r
.fly Marshal's Refuge >> Fly to Marshal's Refuge in Un'goro Crater
.zoneskip Un'Goro Crater
.target Bulkrek Ragefist
step
.itemcount 11116,1
.goto Un'Goro Crater,43.947,7.137
.use 11116 >>|cRXP_WARN_Use the |T133743:0|t[|cRXP_LOOT_A Mangled Journal|r] to start the quest|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Williden Marshal|r
.accept 3884 >> Accept Williden's Journal
.turnin 3884 >> Turn in Williden's Journal
.use 11116
.target Williden Marshal
step
.itemcount 11186,7
.itemcount 11188,7
.itemcount 11185,7
.itemcount 11184,7
.goto Un'Goro Crater,41.918,2.703
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.accept 4284 >> Accept Crystals of Power
.turnin 4284 >> Turn in Crystals of Power
.target J.D. Collie
step
.isQuestComplete 4501
.goto Un'Goro Crater,43.61,8.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle|r
.turnin 4501 >>Turn in Beware of Pterrordax
.target Spraggle Frock
step
.isQuestComplete 4491
.goto Un'Goro Crater,43.61,8.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle|r
.turnin 4491 >>Turn in A Little Help From My Friends
.target Spraggle Frock
step
.goto Un'Goro Crater,46.37,13.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna|r
.turnin 4245 >>Turn in Chasing A-Me 01
.target Karna Remtravel
.isQuestComplete 4245
step
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4301 >>Turn in The Mighty U'cha
.target Torwa Pathfinder
.isQuestComplete 4301
step
#label ungoroEND
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4292 >>Turn in The Bait for Lar'korwi
.target Torwa Pathfinder
.isQuestComplete 4292
step << Mage
.cast 3567 >>Cast |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << !Mage
.hs >> Hearthstone to Orgrimmar
.zoneskip Orgrimmar
.use 6948
>>|cRXP_WARN_If your HS is still on cooldown, fly to Tanaris and ghetto hearth from Zul'Farrak|r
.link /run InviteUnit("a");C_Timer.After(1,function() LeaveParty() end) >> |cRXP_WARN_Click here to Copy + Paste this macro into chat to ghetto hearth back to Orgrimmar|r
step
.isOnQuest 2976
.goto Orgrimmar,75.20,34.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.turnin 2976 >> Turn in A Grim Discovery
.target Belgrom Rockmaul
step
.isOnQuest 7732
.goto Orgrimmar,56.50,46.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zilzibin|r
.turnin 7732 >> Turn in Zukk'ash Report
.target Zilzibin Drumlore
step
.goto Orgrimmar,56.50,46.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zilzibin|r
.turnin 4509 >>Turn in Calm Before the Storm
.accept 4511 >>Accept Calm Before the Storm
.target Zilzibin Drumlore
.isQuestTurnedIn 4507
step
.goto Orgrimmar,49.70,69.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karus|r
.turnin 4511 >>Turn in Calm Before the Storm
.target Karus
.isOnQuest 4511
step
.goto Orgrimmar,45.2,63.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Valormok >> Fly to Valormok in Azshara
.zoneskip Azshara
.target Doras
step
.goto Azshara,22.50,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.turnin 3564 >>Turn in Andron's Payment to Jediga
.target Jediga
.isOnQuest 3564
step
.goto Azshara,22.50,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.turnin 3563 >>Turn in Jes'rimon's Payment to Jediga
.target Jediga
.isOnQuest 3563
step
.goto Azshara,22.50,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.turnin 3562 >>Turn in Magatha's Payment to Jediga
.target Jediga
.isOnQuest 3562
step << Mage
.isOnQuest 864
.cast 3563 >>Cast |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << Mage
.goto Undercity,50.00,68.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zinge|r
.turnin 864 >>Turn in Return to Apothecary Zinge
.target Apothecary Zinge
.isOnQuest 864
step
+Congratulations on completing the turn-in guide. If there are any Quest starting items in your inventory or Quests in your Log, it is because it was not time-efficient to go there for your character. You can turn those in whenever your journey takes you there.
]])

RXPGuides.RegisterGuide([[#version 1
#classic
<< Alliance
#group RestedXP SoD Preparation
#title Turn in Guide
#name Turn in guide (Alliance)
step
.home 2255>>Make sure your Hearthstone is set to Everlook in Winterspring before you start the route.
>>You can leave all your cloth in the bank to save bag space.
step
.isQuestAvailable 6031
>> Keep at least 30 Runecloth for timbermaw turn in
.collect 14047,30
step
.isQuestComplete 8114
#completewith next
.zone Badlands >> We will be starting our route in Arathi Highlands, make your way there.
step
.goto Arathi Highlands,45.8,45.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Marshal Oslight|r
.turnin 8114 >> Turn in Control Four Bases
.target Field Marshal Oslight
.isQuestComplete 8114
step
#completewith HinterlandsEnd
.goto Arathi Highlands,45.6,46.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cedrik Prose|r
.fly Aerie Peak >> Fly to Aerie Peak in The Hinterlands
.target Cedrik Prose
.zoneskip The Hinterlands
step
.isQuestComplete 2994
#completewith next
.zone The Hinterlands >> We will be starting our route in The Hinterlands, make your way there.
step
#label HinterlandsEnd
.goto The Hinterlands,9.8,44.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryphon Master Talonaxe|r
.turnin 2994 >> Turn in Saving Sharpbeak
.target Gryphon Master Talonaxe
.isQuestComplete 2994
step
#completewith WPLend
.goto The Hinterlands,11.0,46.0,-1
.goto Arathi Highlands,45.6,46.0,-1
.fly Chillwind Camp >> Fly to Chillwind Camp in Western Plaguelands
.target Guthrum Thunderfist
.target Cedrik Prose
.zoneskip Western Plaguelands
step
#completewith next
.zone Western Plaguelands >> We will be starting our route in Western Plaguelands, make your way there.
step
.isQuestComplete 5903
.goto Western Plaguelands,43.4,84.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathaniel Dumah|r
.turnin 5903 >>Turn in A Plague Upon Thee
.target Nathaniel Dumah
step
.isQuestTurnedIn 5226
.goto Western Plaguelands,42.8,84.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ashlam|r
.turnin 5237 >>Turn in Mission Accomplished!
.target Commander Ashlam Valorfist
step
#label BulwarkEND
.isQuestComplete 211
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ashlam|r
.turnin 211 >> Turn in Alas, Andorhal
.target Commander Ashlam Valorfist
step
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.isQuestTurnedIn 5152
.accept 5153 >> Accept A Strange Historian
.target Marlene Redpath
step
.goto Western Plaguelands,49.696,76.754
>>Click |cRXP_PICK_Joseph Redpath's Monument|r. Loot it for |cRXP_LOOT_Joseph's Wedding Ring|r
.complete 5153,1 
.isOnQuest 5153
step
#label WPLend
.isQuestComplete 5153
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.turnin 5153 >>Turn in A Strange Historian
.target Chromie
step << Druid
.cast 18960 >> Cast |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << !Druid
.hs >> Hearthstone to Everlook
.zoneskip Winterspring
.use 6948
step << !Druid
.isQuestComplete 7066
.goto Winterspring,62.2,36.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maethrya|r
.fly South of Lake >> Fly to South of Lake in Moonglade
.zoneskip Moonglade
.target Maethrya
step
.goto Moonglade,36.178,41.798
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 7066 >> Turn in Seed of Life
.target Keeper Remulos
.isQuestComplete 7066
step
#completewith TimbermawEND
.subzone 1216 >> Head South towards Timbermaw Cavern
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20741 >>|cRXP_WARN_Use the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r] to start the quest|r
.accept 8470 >> Accept Deadwood Ritual Totem
.turnin 8470 >> Turn in Deadwood Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20741,1 
.target Kernda
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20742 >>|cRXP_WARN_Use the |T135816:0|t[|cRXP_LOOT_Winterfall Ritual Totem|r] to start the quest|r
.accept 8471 >> Accept Winterfall Ritual Totem
.turnin 8471 >> Turn in Winterfall Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20742,1 
.target Kernda
step
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
.accept 6031 >> Accept Runecloth
.turnin 6031 >> Turn in Runecloth
.reputation 576,friendly,<0,1 
.itemcount 14047,30 
.target Meilosh
step
#label TimbermawEND
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
.accept 6032 >> Accept Sacred Cloth
.turnin 6032 >> Turn in Sacred Cloth
.skill tailoring,<280,1 
.reputation 576,friendly,<0,1 
.itemcount 14342,2 
.target Meilosh
step
#completewith next
.goto Winterspring,27.736,34.499
>> Run towards Winterspring exit
step
.isQuestComplete 8464
.goto Winterspring,27.736,34.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.turnin 8464 >> Turn in Winterfall Activity
.target Salfa
step
#completewith FelwoodEND
.zoneskip Felwood >> Run back through Timbermaw Hold towards Felwood
step
.isQuestComplete 8461
.goto Felwood,64.769,8.131
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.turnin 8461 >> Turn in Deadwood of the North
.target Nafien
step
.isQuestComplete 4101
.goto Felwood,54.14,86.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arathandris Silversky|r
.turnin 4101 >> Turn in Cleansing Felwood
.target Arathandris Silversky
step
.isQuestComplete 5156
.goto Felwood,50.90,81.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn|r
.turnin 5156 >>Turn in Verifying the Corruption
.target Taronn Redfeather
step
.isQuestComplete 5385
.goto Felwood,51.35,82.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessir|r
.turnin 5385 >>Turn in The Remains of Trey Lightforge
.target Jessir Moonbow
step
.isQuestComplete 5242
.goto Felwood,51.23,82.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.turnin 5242 >>Turn in A Final Blow
.target Greta Mosshoof
step
.isQuestTurnedIn 4441
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.accept 4442 >> Accept Purified!
.turnin 4442 >> Turn in Purified!
.target Eridan Bluewind
step << Mage
.requires quest,4507
.cast 3562 >>Cast |T135757:0|t[Teleport: Ironforge]
.zoneskip Ironforge
step << !Mage
.goto Ashenvale,55.9,32.9
#completewith next
.zone Ashenvale >>Run into Ashenvale and towards Astranaar
step << !Mage
.goto Ashenvale,34.4,48.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daelyshia|r
.fly Auberdine >> Fly to Auberdine in Darkshore
.target Daelyshia
.zoneskip Darkshore
step << !Mage
.goto Darkshore,37.0,44.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shaussiy|r
.home >> Set your Hearthstone to Auberdine
.target Innkeeper Shaussiy
step << !Mage
.goto Darkshore,32.7,43.7
.zone Wetlands >> Take a boat to Menathil Harbor
step
#completewith hotbend
.goto Ironforge,55.6,48.0,-1
.goto Wetlands,9.6,59.6,-1
.fly Thelsamar >> Fly to Thelsamar in Loch Modan
.zoneskip Loch Modan
.target Shellei Brondir
.target Gryth Thurden
step
.itemcount 10000,1
.goto Loch Modan,18.2,83.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mountaineer Pebblebitty|r
.use 10000 >>|cRXP_WARN_Use |T134229:0|t[|cRXP_LOOT_Margol's Horn|r] to start the quest|r
.accept 3181 >> Accept The Horn of the Beast
.target Mountaineer Pebblebitty
step
.isOnQuest 3181
.goto Loch Modan,18.2,83.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mountaineer Pebblebitty|r
.turnin 3181 >> Turn in The Horn of the Beast
.target Mountaineer Pebblebitty
step
#label hotbend
.isQuestTurnedIn 3181
.goto Loch Modan,18.2,83.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mountaineer Pebblebitty|r
.accept 3182 >> Accept Proof of Deed
.target Mountaineer Pebblebitty
step
.goto Loch Modan,33.8,50.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thorgrum Borrelson|r
.fly Ironforge >> Fly to Ironforge
.target Thorgrum Borrelson
.zoneskip Ironforge
step
.isQuestTurnedIn 3181
.goto Ironforge,71.83,16.12,30,0
.goto Ironforge,77.02,26.38,30,0
.goto Ironforge,64.03,4.20,30,0
.goto Ironforge,71.83,16.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curator Thorius|r
>>|cRXP_FRIENDLY_Curator Thorius|r |cRXP_WARN_patrols through the Hall of Explorers|r
.turnin 3182 >> Turn in Proof of Deed
.accept 3201 >> Accept At Last!
.target Curator Thorius
step
.isQuestComplete 3566
.goto Ironforge,71.83,16.12,30,0
.goto Ironforge,77.02,26.38,30,0
.goto Ironforge,64.03,4.20,30,0
.goto Ironforge,71.83,16.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curator Thorius|r
>>|cRXP_FRIENDLY_Curator Thorius|r |cRXP_WARN_patrols through the Hall of Explorers|r
.turnin 3566 >> Turn in Rise Obsidion!
.target Curator Thorius
step
.goto Ironforge,30.96,4.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tymor|r
.turnin 3461 >> Turn in Return to Tymor
.isQuestComplete 3461
.target Tymor
step
#completewith IronforgeCloth
.goto Ironforge,35.6,60.6,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bailey Stonemantle|r
+Retrieve all the cloth you need from the Bank for Ironforge turn-ins
.target Bailey Stonemantle
step
.goto Ironforge,73.8,47.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bubulo Acerbus|r
.turnin 7807 >>Turn in A Donation of Wool
.target Bubulo Acerbus
step
.goto Ironforge,73.8,47.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bubulo Acerbus|r
.turnin 7808 >>Turn in A Donation of Silk
.target Bubulo Acerbus
step
.goto Ironforge,73.8,47.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bubulo Acerbus|r
.turnin 7809 >>Turn in A Donation of Mageweave
.target Bubulo Acerbus
step
.isQuestTurnedIn 7807
.isQuestTurnedIn 7808
.isQuestTurnedIn 7809
.goto Ironforge,73.8,47.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bubulo Acerbus|r
.turnin 7811 >>Turn in A Donation of Runecloth
.target Bubulo Acerbus
step
.goto Ironforge,43.6,33.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mistina Steelshield|r
.turnin 7802 >>Turn in A Donation of Wool
.target Mistina Steelshield
step
.goto Ironforge,43.6,33.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mistina Steelshield|r
.turnin 7803 >>Turn in A Donation of Silk
.target Mistina Steelshield
step
.goto Ironforge,43.6,33.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mistina Steelshield|r
.turnin 7804 >>Turn in A Donation of Mageweave
.target Mistina Steelshield
step
#label IronforgeCloth
.isQuestTurnedIn 7802
.isQuestTurnedIn 7803
.isQuestTurnedIn 7804
.itemcount 14047,60
.goto Ironforge,43.6,33.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mistina Steelshield|r
.turnin 7805 >>Turn in A Donation of Runecloth
.target Mistina Steelshield
step
#completewith SGEnd
.goto Ironforge,55.6,48.0,-1
.goto Loch Modan,33.8,50.8,-1
.fly Thorium Point >> Fly to Thorium Point in Searing Gorge
.zoneskip Searing Gorge
.target Thorgrum Borrelson
.target Gryth Thurden
step
.isQuestComplete 3463
.goto Searing Gorge,39.165,38.997
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Squire Maltrake|r
.turnin 3463 >> Turn in Set Them Ablaze!
.target Squire Maltrake
step
.isQuestTurnedIn 3463
.goto Searing Gorge,38.847,38.985
>>Click the |cRXP_PICK_Hoard of the Black Dragonflight|r on the ground and then click again to turn it in
.accept 3481 >> Accept Trinkets...
.turnin 3481 >> Turn in Trinkets...
step
#label SGEnd
.isQuestTurnedIn 3481
.use 10569 >>|cRXP_WARN_Open the|r |T132595:0|t[Hoard of the Black Dragonflight]
+|cRXP_WARN_Ensure you keep the|r |T134430:0|t[Black Dragonflight Molt]|cRXP_WARN_. Do not destroy it. You will need it later|r
.collect 10575,1
step
#completewith next
.goto Badlands,61.8,54.2
.zone Badlands >> Head towards Badlands
step
.isQuestComplete 717
.goto Badlands,61.8,54.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garek|r
.turnin 717 >> Turn in Tremors of the Earth
.target Garek
step
.zoneskip Badlands,1
.goto Loch Modan,33.8,50.8
.zone Loch Modan >> Run north into Loch Modan
step
.isOnQuest 3201 
.zoneskip Loch Modan
.goto Ironforge,55.6,48.0,-1
.goto Wetlands,9.6,59.6,-1
.goto Searing Gorge,37.8,30.6,-1
.fly Thelsamar >> Fly to Thelsamar
.target Gryth Thurden
.target Shellei Brondir
.target Lanie Reed
step
.isOnQuest 3201
.goto Loch Modan,18.186,84.034
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mountaineer Pebblebitty|r
.turnin 3201 >> Turn in At Last!
.target Mountaineer Pebblebitty
step
#completewith BSEnd
.goto Ironforge,55.6,48.0,-1
.goto Searing Gorge,37.8,30.6,-1
.goto Loch Modan,33.8,50.8,-1
.fly Morgan's Vigil >> Fly to Morgan's Vigil in Burning Steppes
.zoneskip Burning Steppes
.target Thorgrum Borrelson
.target Lanie Reed
.target Gryth Thurden
step
.isQuestComplete 4182
.goto Burning Steppes,85.820,68.948
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Helendis Riverhorn|r
.turnin 4182 >> Turn in Dragonkin Menace
.accept 4183 >> Accept The True Masters
.target Helendis Riverhorn
step
.isQuestTurnedIn 4182
.goto Burning Steppes,85.820,68.948
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Helendis Riverhorn|r
.accept 4183 >> Accept The True Masters
.target Helendis Riverhorn
step
.isQuestComplete 4283
.goto Burning Steppes,84.554,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.turnin 4283 >> Turn in FIFTY! YEP!
.target Oralius
step
.isQuestComplete 4286
.goto Burning Steppes,84.555,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.turnin 4286 >> Turn in The Good Stuff
.target Oralius
step
.isQuestComplete 4263
.goto Burning Steppes,85.415,70.064
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jalinda Sprig|r
.turnin 4263 >> Turn in Incendius!
.target Jalinda Sprig
step
.isQuestComplete 4123
.goto Burning Steppes,65.152,23.911
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.turnin 4123 >> Turn in The Heart of the Mountain
.target Maxwort Uberglint
step
#label BSEnd
.xp <52,1
.goto Burning Steppes,95.09,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus|r
>>|cRXP_WARN_Open your|r |T132595:0|t[Hoard of the Black Dragonflight] |cRXP_WARN_if you haven't yet|r
.accept 4022 >>Accept A Taste of Flame
.turnin 4022 >>Turn in A Taste of Flame
.target Cyrus Therepentous
.isQuestTurnedIn 3481
.itemcount 10575,1
step
.isQuestTurnedIn 4182
#completewith next
.goto Burning Steppes,84.333,68.328
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgus Stoutarm|r
.fly Redridge >> Fly to Redridge Mountains
.zoneskip Redridge Mountains
.target Borgus Stoutarm
step
.isQuestTurnedIn 4182
.goto Redridge Mountains,29.98,44.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Solomon|r
.turnin 4183 >> Turn in The True Masters
.accept 4184 >> Accept The True Masters
.target Magistrate Solomon
step
#completewith StormwindCloth
.goto Burning Steppes,84.333,68.328,-1
.goto Redridge Mountains,30.590,59.410,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ariena Stormfeather|r
.fly Stormwind >> Fly to Stormwind
.zoneskip Stormwind City
.target Ariena Stormfeather
.target Borgus Stoutarm
step
.isQuestTurnedIn 5022
.goto Stormwind City,48.47,30.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Factor Bathrilor|r inside on the 2nd floor
.accept 5048 >> Accept Good Natured Emma
.target Royal Factor Bathrilor
step
.goto Stormwind City,52.37,42.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ol' Emma|r either inside her home on the 2nd floor, or patrolling the Trade District
>>Skip the follow up as you won't return to WPL before hitting 60
.turnin 5048 >> Turn in Good Natured Emma
.accept 5050 >> Accept Good Luck Charm
.unitscan Ol' Emma
step
.isQuestTurnedIn 4182
.goto Stormwind City,78.213,17.980
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Highlord Bolvar Fordragon|r
.turnin 4184 >> Turn in The True Masters
.accept 4185 >> Accept The True Masters
.target Highlord Bolvar Fordragon
.xp <56,1
step
.isQuestTurnedIn 4182
.goto Stormwind City,78.213,17.980
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Highlord Bolvar Fordragon|r
.turnin 4184 >> Turn in The True Masters
.accept 4185 >> Accept The True Masters
.target Highlord Bolvar Fordragon
step
.isQuestTurnedIn 4182
.goto Stormwind City,78.102,17.750
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Katrana Prestor|r
.complete 4185,1 
.skipgossip
.target Lady Katrana Prestor
step
.isQuestTurnedIn 4182
.goto Stormwind City,78.213,17.980
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Highlord Bolvar Fordragon|r
.turnin 4185 >> Turn in The True Masters
.accept 4186 >> Accept The True Masters
.target Highlord Bolvar Fordragon
step
.isQuestAvailable 6610
.skill cooking,<225,1
.goto Stormwind City,56.4,73.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_John Burnside|r
>>Pick up cooking mats from the bank
.collect 12207,12 
.collect 7974,10 
.collect 8932,20 
.target John Burnside
step
#completewith StormwindCloth
.goto Stormwind City,56.4,73.2,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_John Burnside|r
+Retrieve all the cloth you need from the Bank for Stormwind turn-ins
.target John Burnside
step
.goto Stormwind City,44.2,73.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Clavicus Knavingham|r
.turnin 7791 >>Turn in A Donation of Wool
.target Clavicus Knavingham
step
.goto Stormwind City,44.2,73.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Clavicus Knavingham|r
.turnin 7793 >>Turn in A Donation of Silk
.target Clavicus Knavingham
step
.goto Stormwind City,44.2,73.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Clavicus Knavingham|r
.turnin 7794 >>Turn in A Donation of Mageweave
.target Clavicus Knavingham
step
#label StormwindCloth
.isQuestTurnedIn 7791
.isQuestTurnedIn 7793
.isQuestTurnedIn 7794
.goto Stormwind City,44.2,73.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Clavicus Knavingham|r
.turnin 7795 >>Turn in A Donation of Runecloth
.target Clavicus Knavingham
step
.isQuestTurnedIn 4182
#completewith next
.goto Stormwind City,66.277,62.137
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Redridge>> Fly to Redridge Mountains
.zoneskip Stormwind City,1
.target Dungar Longdrink
step
.isQuestTurnedIn 4182
.goto Redridge Mountains,29.98,44.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrate Solomon|r
.turnin 4186 >> Turn in The True Masters
.target Magistrate Solomon
step
#completewith BLend
.goto Stormwind City,66.277,62.137,-1
.goto Redridge Mountains,30.6,59.6,-1
.fly Nethergarde Keep >> Fly to Nethergarde Keep in Blasted Lands
.zoneskip Blasted Lands
.target Ariena Stormfeather
.target Dungar Longdrink
step
.goto Blasted Lands,67.570,19.291
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Ardalan|r atop the Tower
.accept 2783 >> Accept Petty Squabbles
.target Ambassador Ardalan
step
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 2783 >> Turn in Petty Squabbles
.accept 2801 >> Accept A Tale of Sorrow
.target Fallen Hero of the Horde
step
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.complete 2801,1 
.skipgossip
.target Fallen Hero of the Horde
step
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 2801 >> Turn in A Tale of Sorrow
.target Fallen Hero of the Horde
step
.itemcount 4056,1
.goto Swamp of Sorrows,22.90,48.30
.use 4056 >>|cRXP_WARN_Use the |T134939:0|t[|cRXP_LOOT_Cortello's Riddle|r] to start the quest|r
.accept 624 >>Accept Cortello's Riddle
.turnin 624 >>Turn in Cortello's Riddle
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazial|r
.accept 2583 >>Accept A Boar's Vitality
.turnin 2583 >>Turn in A Boar's Vitality
.itemcount 8392,3
.itemcount 8393,2
.itemcount 8394,1
.goto Blasted Lands,50.64,14.30
.target Bloodmage Drazial
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazial|r
.accept 2585 >>Accept The Decisive Striker
.turnin 2585 >>Turn in The Decisive Striker
.itemcount 8393,3
.itemcount 8396,2
.itemcount 8392,1
.goto Blasted Lands,50.64,14.30
.target Bloodmage Drazial
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazial|r
.accept 2581 >>Accept Snickerfang Jowls
.turnin 2581 >>Turn in Snickerfang Jowls
.itemcount 8391,3
.itemcount 8392,2
.itemcount 8393,1
.goto Blasted Lands,50.64,14.30
.target Bloodmage Drazial
step
.goto Blasted Lands,50.55,14.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lynnore|r
.accept 2601 >>Accept The Basilisk's Bite
.turnin 2601 >>Turn in The Basilisk's Bite
.itemcount 8394,10
.itemcount 8396,2
.goto Blasted Lands,50.64,14.30
.target Bloodmage Lynnore
step
.goto Blasted Lands,50.55,14.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lynnore|r
.accept 2603 >>Accept Vulture's Vigor
.turnin 2603 >>Turn in Vulture's Vigor
.itemcount 8396,10
.itemcount 8391,2
.goto Blasted Lands,50.64,14.30
.target Bloodmage Lynnore
step
#label BLend
.goto Blasted Lands,51.8,35.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kum'isha|r
.accept 3501 >>Accept Everything Counts In Large Amounts
.turnin 3501 >>Turn in Everything Counts In Large Amounts
.target Kum'isha the Collector
.itemcount 10593,1
step
#completewith stvEnd
.goto Stormwind City,66.277,62.137,-1
.goto Redridge Mountains,30.6,59.6,-1
.goto Blasted Lands,65.6,24.4,-1
.fly Booty Bay >> Fly to Booty Bay in Stranglethorn Vale
.zoneskip Stranglethorn Vale
.target Alexandra Constantine
.target Ariena Stormfeather
.target Dungar Longdrink
step
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 648 >> Turn in Rescue OOX-17/TN!
.target Oglethorpe Obnoticus
.isQuestComplete 648
step
.goto Stranglethorn Vale,28.2,76.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 836 >> Turn in Rescue OOX-09/HL!
.target Oglethorpe Obnoticus
.isQuestComplete 836
step
.goto Stranglethorn Vale,28.40,76.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe Obnoticus|r
.turnin 3721 >>Turn in An OOX of Your Own
.target Oglethorpe Obnoticus
.isQuestTurnedIn 648
.isQuestTurnedIn 836
.isQuestTurnedIn 2767
step
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sprogger|r
.turnin 8554 >>Turn in Facing Negolas
.target Sprogger
.isQuestComplete 8554
step
#label stvEnd
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tExit Booty Bay and head towards |cRXP_FRIENDLY_Princess Poobah|r
.turnin 630 >>Turn in Message in a Bottle
.target Princess Poobah
.isQuestComplete 630
step
.goto Stranglethorn Vale,25.91,72.96
.zone The Barrens >> Take a boat to Ratchet in The Barrens
step
.isQuestComplete 4502
.goto The Barrens,62.50,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv|r
.turnin 4502 >>Turn in Volcanic Activity
.target Liv Rizzlefix
step
.isQuestComplete 7065
.goto The Barrens,63.0,37.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Nijel's Point >> Fly to Nijel's Point in Desolace
.zoneskip Desolace
.target Bragok
step
.goto Desolace,64.0,10.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keeper Marandis|r
.turnin 7065 >> Turn in Corruption of Earth and Seed
.target Keeper Marandis
.isQuestComplete 7065
step
#completewith FeralasEnd
.goto The Barrens,63.0,37.2,-1
.goto Desolace,64.6,10.6,-1
.fly Feathermoon Stronghold >> Fly to Feathermoon Stronghold in Feralas
.zoneskip Feralas
.target Baritanas Skyriver
.target Bragok
step
.isQuestTurnedIn 4265
.goto Feralas,32.14,45.46,10,0
.goto Feralas,31.860,45.130
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ginro Hearthkindle|r up stairs
.accept 4266 >> Accept A Hero's Welcome
.target Ginro Hearthkindle
step
#label FeralasEnd
.isOnQuest 4266
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shandris Feathermoon|r
.turnin 4266 >> Turn in A Hero's Welcome
.goto Feralas,30.276,46.168
.target Shandris Feathermoon
step
.isQuestTurnedIn 2870
.goto Feralas,30.379,46.170
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Latronicus Moonspear|r
.accept 2871 >> Accept Delivering the Relic
.target Latronicus Moonspear
step
.isOnQuest 2871
.goto Feralas,30.077,45.060
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vestia Moonspear|r
.turnin 2871 >> Turn in Delivering the Relic
.target Vestia Moonspear
step
.itemcount 11463,1
#completewith next
.goto Feralas,30.2,43.2
.fly Thalanaar >> Fly to Thalanaar on the border between Feralas and Thousand Needles
.target Fyldren Moonfeather
step
.itemcount 11463,1
.goto Feralas,89.634,46.563
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Falfindel Waywarder|r
.use 11463 >>|cRXP_WARN_Use the |T133628:0|t[|cRXP_LOOT_Undelivered Parcel|r] to start the quest|r
.accept 4281 >> Accept Thalanaar Delivery
.turnin 4281 >> Turn in Thalanaar Delivery
.target Falfindel Waywarder
step
#completewith tanarisEnd
.goto Feralas,89.4,45.8,-1
.goto Feralas,30.2,43.2,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thyssiana|r
.fly Gadgetzan >> Fly to Gadgetzan in Tanaris
.zoneskip Tanaris
.target Thyssiana
.target Fyldren Moonfeather
step
#completewith next
.zone Thousand Needles >> Travel to the Shimmering Flats
step
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.turnin 2770 >> Turn in Gahz'rilla
.target Wizzle Brassbolts
.isQuestComplete 2770
step
.isQuestTurnedIn 3841
.goto Thousand Needles,78.347,74.725
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Quentin|r
.accept 3842 >> Accept A Short Incubation
.turnin 3842 >> Turn in A Short Incubation
.itemcount 3825,2 
.target Quentin
step
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.turnin 2768 >> Turn in Divino-matic Rod
.target Chief Engineer Bilgewhizzle
.isQuestComplete 2768
step
.goto Tanaris,50.88,26.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4507 >>Turn in Pawn Captures Queen
.accept 4508 >>Accept Calm Before the Storm
.target Alchemist Pestlezugg
.isQuestComplete 4507
step
.goto Tanaris,50.88,26.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.accept 4508 >>Accept Calm Before the Storm
.target Alchemist Pestlezugg
.isQuestTurnedIn 4507
step
.isQuestTurnedIn 2873
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stoley|r
.accept 2874 >>Accept Deliver to MacKinley
.goto Tanaris,67.11,23.98
.target Stoley
step
.itemcount 9250,1
.goto Tanaris,67.0,23.8
.use 9250 >>|cRXP_WARN_Use the |T134939:0|t[|cRXP_LOOT_Ship Schedule|r] to start the quest|r
.accept 2876 >> Accept Ship Schedules
.turnin 2876 >> Turn in Ship Schedules
.target Security Chief Bilgewhizzle
step
#label tanarisEnd
.isQuestAvailable 6610
.skill cooking,<225,1
.itemcount 12207,12
.itemcount 7974,10
.itemcount 8932,20
.goto Tanaris,52.6,28.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dirge Quikcleave|r
.accept 6610 >> Accept Clamlette Surprise
.turnin 6610 >> Turn in Clamlette Surprise
.target Dirge Quikcleave
step
.goto Tanaris,51.0,29.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bera Stonehammer|r
.fly Marshal's Refuge >> Fly to Marshal's Refuge in Un'goro Crater
.zoneskip Un'Goro Crater
.target Bera Stonehammer
step
.itemcount 11116,1
.goto Un'Goro Crater,43.947,7.137
.use 11116 >>|cRXP_WARN_Use the |T133743:0|t[|cRXP_LOOT_A Mangled Journal|r] to start the quest|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Williden Marshal|r
.accept 3884 >> Accept Williden's Journal
.turnin 3884 >> Turn in Williden's Journal
.use 11116
.target Williden Marshal
step
.itemcount 11186,7
.itemcount 11188,7
.itemcount 11185,7
.itemcount 11184,7
.goto Un'Goro Crater,41.918,2.703
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.accept 4284 >> Accept Crystals of Power
.turnin 4284 >> Turn in Crystals of Power
.target J.D. Collie
step
.isQuestComplete 4501
.goto Un'Goro Crater,43.61,8.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle|r
.turnin 4501 >>Turn in Beware of Pterrordax
.target Spraggle Frock
step
.isQuestComplete 4491
.goto Un'Goro Crater,43.61,8.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle|r
.turnin 4491 >>Turn in A Little Help From My Friends
.target Spraggle Frock
step
.goto Un'Goro Crater,46.37,13.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna|r
.turnin 4245 >>Turn in Chasing A-Me 01
.target Karna Remtravel
.isQuestComplete 4245
step
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4301 >>Turn in The Mighty U'cha
.target Torwa Pathfinder
.isQuestComplete 4301
step
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4292 >>Turn in The Bait for Lar'korwi
.target Torwa Pathfinder
.isQuestComplete 4292
step << Mage
.requires quest,4507
.cast 3565 >>Cast |T135755:0|t[Teleport: Darnassus]
.zoneskip Darnassus
step << !Mage
.hs >> Hearthstone to Auberdine
.zoneskip Darkshore
.use 6948
>>|cRXP_WARN_If your HS is still on cooldown, fly to Tanaris and ghetto hearth from Zul'Farrak|r
.link /run InviteUnit("a");C_Timer.After(1,function() LeaveParty() end) >> |cRXP_WARN_Click here to Copy + Paste this macro into chat to ghetto hearth back to Auberdine|r
step << !Mage
.goto Ashenvale,34.4,48.0,-1
.goto Felwood,62.4,24.2,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flight Master|r
.fly Rut'theran Village >> Fly to Rut'theran Village
.zoneskip Darnassus
step << !Mage
.goto Teldrassil,55.9,89.7
.zone Darnassus >> Step through the purple portal into Darnassus
step
.goto Darnassus,67.427,15.655
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Saelienne|r
.accept 3763 >> Accept Assisting Arch Druid Staghelm
.target Innkeeper Saelienne
step
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 3763 >> Turn in Assisting Arch Druid Staghelm
.accept 3764 >> Accept Un'Goro Soil
.target Arch Druid Fandral Staghelm
step
.goto Darnassus,31.485,8.237
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jenal|r
.turnin 3764 >> Turn in Un'Goro Soil
.target Jenal
step
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.accept 3781 >> Accept Morrowgrain Research
.target Arch Druid Fandral Staghelm
step
#label Morrowgrain
.goto Darnassus,35.375,8.405
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mathrengyl Bearwalker|r on the middle floor
.turnin 3781 >> Turn in Morrowgrain Research
.accept 3785 >> Accept Morrowgrain Research
.turnin 3785 >> Turn in Morrowgrain Research
.target Mathrengyl Bearwalker
step
.isQuestTurnedIn 4507
.goto Darnassus,39.26,92.84,10,0
.goto Darnassus,41.833,85.622
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gracina Spiritmight|r upstairs
.turnin 4508 >> Turn in Calm Before the Storm
.accept 4510 >> Accept Calm Before the Storm
.target Gracina Spiritmight
step
.goto Darnassus,39.38,42.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Idriana|r
.turnin 4510 >> Turn in Calm Before the Storm
.target Idriana
step
#completewith DarbassusCloth
.goto Darnassus,39.38,42.43,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Idriana|r
+Retrieve all the cloth you need from the Bank for Darnassus turn-ins
.target Idriana
step
.goto Darnassus,63.8,22.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raedon Duskstriker|r
.turnin 7792 >>Turn in A Donation of Wool
.target Raedon Duskstriker
step
.goto Darnassus,63.8,22.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raedon Duskstriker|r
.turnin 7798 >>Turn in A Donation of Silk
.target Raedon Duskstriker
step
.goto Darnassus,63.8,22.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raedon Duskstriker|r
.turnin 7799 >>Turn in A Donation of Mageweave
.target Raedon Duskstriker
step
#label DarbassusCloth
.isQuestTurnedIn 7792
.isQuestTurnedIn 7798
.isQuestTurnedIn 7799
.goto Darnassus,63.8,22.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raedon Duskstriker|r
.turnin 7800 >>Turn in A Donation of Runecloth
.target Raedon Duskstriker
step
+Congratulations on completing the turn-in guide. If there are any Quest starting items in your inventory or Quests in your Log, it is because it was not time-efficient to go there for your character. You can turn those in whenever your journey takes you there.
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Warlock SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Haunt - 3 (Elwynn Forest)
#title Haunt

step << Warlock
    #season 2
    .goto Elwynn Forest,52.544,51.922
    >>Open the |cRXP_PICK_Defias Stashbox|r on the ground. Loot it for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Haunting|r]
    .collect 205230,1 -- Rune of Haunting (1)
    .train 403919,1
step << Warlock
    #season 2
    #label RoH
    .cast 402265 >>|cRXP_WARN_Use the|r |T134419:0|t[|cRXP_FRIENDLY_Rune of Haunting|r] |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Haunt]
    .use 205230
    .itemcount 205230,1
    .train 403919,1
]])

RXPGuides.RegisterGuide([[#classic
<< Alliance Warlock SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Haunt - 1 (Dun Morogh)
#title Haunt

step << Warlock
    #season 2
    .goto Dun Morogh,26.733,72.552
    >>Open the |cRXP_PICK_Rockjaw Footlocker|r on the ground. Loot it for the |T134419:0|t|cRXP_LOOT_[Rune of Haunting]|r
    .collect 205230,1 -- Rune of Haunting (1)
    .train 403919,1
step << Warlock
    #season 2
    .train 403919 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Rune of Haunting]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Haunt]
    .use 205230
    .itemcount 205230,1 -- Rune of Haunting (1)
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Warlock SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Haunt - 2 (Durotar)
#title Haunt


    --Rune of Haunt

step << Orc
    #season 2
    .goto Durotar,40.65,68.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nartok|r
    .accept 77586 >>Accept Stolen Power
    .target Nartok
    .train 403919,1
step
    #season 2
    .goto Durotar,42.99,54.43
    >>Loot the |cRXP_PICK_Waterlogged Stashbox|r for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Haunting|r] inside the cave
    .collect 205230,1 --Rune of Haunting (1)
    .train 403919,1
step
    #season 2
    .train 403919 >>|cRXP_WARN_Use the|r |T134419:0|t|cRXP_LOOT_[Rune of Haunting]|r |cRXP_WARN_to learn|r |T133816:0|t[Engrave Gloves - Haunt]
    .use 205230
    .itemcount 205230,1 -- Rune of Haunting (1)
step << Orc
    #season 2
    .goto Durotar,42.51,69.04
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mai'ah|r
    .turnin 77586 >>Turn in Stolen Power
    .target Nartok
    .isOnQuest 77586
]])

RXPGuides.RegisterGuide([[#classic
<< Horde Warlock SoD
#group RestedXP Rune & Books Guide
#subgroup Gloves
#name Haunt - 2 (Tirisfal Glades)
#title Haunt


    --Rune of Haunt

step << Undead
    #season 2
    .goto Tirisfal Glades,30.91,66.34
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maximillion|r
    .accept 77672 >>Accept The Lost Rune
    .target Maximillion
step
    #season 2
    .goto Tirisfal Glades,24.60,59.45
    >>Loot the |cRXP_PICK_Lost Stache|r inside the cave for the |T134419:0|t[|cRXP_FRIENDLY_Rune of Haunting|r]
    .collect 205230,1 --Rune of Haunting (1)
    .train 403919,1
step
    #season 2
    .cast 402265 >>Use the |T134939:0|t[|cRXP_FRIENDLY_Spell Notes: CALE ENCI|r]
    .use 205230
    .train 403919,1
step << Undead
    #season 2
    .goto Tirisfal Glades,30.91,66.34
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maximillion|r
    .turnin 77672 >>Turn in The Lost Rune
    .target Maximillion
]])

