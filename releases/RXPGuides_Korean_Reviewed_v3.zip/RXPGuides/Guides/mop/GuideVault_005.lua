if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "MOP" then return end

RXPGuides.RegisterGuide([[#mop
#internal
#group RXP-Pandaria
#name 89-90 Dread Wastes
step
#label pt1start
#completewith DreadStart
.subzone 6306 >> Travel to Dread Wastes
>>|cRXP_WARN_Be cautious of large packs of |cRXP_ENEMY_Mantids|r when entering on a ground mount|r
step
.noflyable
.isQuestAvailable 31001,31002
.goto 422,70.282,20.958,70,0
.goto 422,75.092,21.292
.vehicle >> |cRXP_WARN_Click the |cRXP_PICK_Shado-Pan Rope|r on the ground to ascend the wall|r
step
#label DreadStart
.goto 390,14.13,76.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bowmistress Li|r
.turnin -31390 >>Turn in The Klaxxi << Alliance
.turnin -31391 >>Turn in The Klaxxi << Horde
.turnin -31656 >>Turn in The Threat in the South
.target Bowmistress Li
.accept 31001 >>Accept Falling Down
.accept 31002 >>Accept Nope
step
.noflyable
.isOnQuest 31001,31002
.goto 390,14.202,76.719
.vehicle >> |cRXP_WARN_Click the |cRXP_PICK_Shado-Pan Rope|r behind |cRXP_FRIENDLY_Bowmistress Li|r to descend the wall you are on|r
.subzoneskip 6306
step
#completewith DreadspinnerTender
#hidewindow
#loop
.goto 422,74.173,24.745,25,0
.goto 422,72.484,22.262,25,0
.goto 422,70.920,22.080,20,0
.goto 422,71.506,28.578,25,0
.goto 422,65.619,27.905,25,0
.goto 422,67.872,31.332,30,0
.goto 422,74.173,24.745,0
.goto 422,72.484,22.262,0
.goto 422,70.920,22.080,0
.goto 422,71.506,28.578,0
.goto 422,65.619,27.905,0
.goto 422,67.872,31.332,0
.complete 31002,1 
.complete 31002,2 
step
#completewith next
>>Kill |cRXP_ENEMY_Dreadspinner Tenders|r
.complete 31002,2 
.mob Dreadspinner Tender
step
.use 82807 >>|cRXP_WARN_Use the|r |T133837:0|t[Shado-Pan Dragon Gun] |cRXP_WARN_to destroy the|r |cRXP_PICK_Dreadspinner Eggs|r
*|cRXP_WARN_The|r |T133837:0|t[Shado-Pan Dragon Gun] |cRXP_WARN_also damages the |cRXP_ENEMY_Spiders|r and you can cancel the channel by pressing ESC|r
.complete 31002,1 
step
#label DreadspinnerTender
>>Kill |cRXP_ENEMY_Dreadspinner Tenders|r
.complete 31002,2 
.mob Dreadspinner Tender
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marksman Lann|r
.goto 422,72.55,28.68
.skipgossip 62166,1
.complete 31001,1 
.target Marksman Lann
step
.goto 422,72.55,28.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marksman Lann|r
.turnin 31001 >>Turn in Falling Down
.turnin 31002 >>Turn in Nope
.accept 31003 >>Accept Psycho Mantid
.target Marksman Lann
step
#completewith next
.goto 422,73.21,27.81,10 >> Enter the Cave
step
.goto 422,73.48,27.49
>>Kill |cRXP_ENEMY_Adjunct Kree'zot|r
.complete 31003,1 
.mob Adjunct Kree'zot
step
.goto 422,73.67,27.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Klaxxi'va Tik|r
.turnin 31003 >>Turn in Psycho Mantid
.target Klaxxi'va Tik
.accept 31004 >>Accept Preserved in Amber
step
#completewith next
.goto 422,72.96,27.74,15 >> Leave the cave
step
>>Click on the |cRXP_PICK_Ancient Amber Chunk|r
.goto 422,70.210,25.661
.complete 31004,1 
step
.goto 422,70.21,25.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.turnin 31004 >>Turn in Preserved in Amber
.target Kil'ruk the Wind-Reaver
.accept 31676 >>Accept Ancient Vengeance
.accept 31005 >>Accept Wakening Sickness
step
#completewith VengefulGurthani
#hidewindow
#loop
.goto 422,71.394,30.671,45,0
.goto 422,71.329,39.100,45,0
.goto 422,71.394,30.671,45,0
.goto 422,66.021,27.701,45,0
.goto 422,71.394,30.671,0
.goto 422,66.021,27.701,0
.goto 422,71.329,39.100,0
.complete 31676,1 
.complete 31005,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Vengeful Gurthani Spirits|r
.complete 31676,1 
.mob Vengeful Gurthani Spirit
step
>>Kill |cRXP_ENEMY_Sapflies|r. Loot them for their |cRXP_LOOT_Sapfly Bits|r
.complete 31005,1 
.mob Sapfly
step
#label VengefulGurthani
>>Kill |cRXP_ENEMY_Vengeful Gurthani Spirit|r
.complete 31676,1 
.mob Vengeful Gurthani Spirit
step
.goto 422,70.19,25.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.turnin 31005 >>Turn in Wakening Sickness
.turnin 31676 >>Turn in Ancient Vengeance
.accept 31006 >>Accept The Klaxxi Council
.target Kil'ruk the Wind-Reaver
step
.maxlevel 89
#completewith DungeonReminder
+|cFFFF0000REMINDER:|r |cRXP_WARN_Queueing for dungeons using the Group Finder tool is a great way to gain efficient XP as well as acquiring gear upgrades while leveling|r
>>|cRXP_WARN_It is |cFFFF0000highly recommended|r to queue for dungeons and complete them at least once for the quests as you level so you don't fall behind in XP. You can pick up quests and turn them in once inside the dungeons|r
step
.goto 422,54.98,34.05
>>|cRXP_WARN_Travel to Klaxxi'vess|r
>>|cRXP_WARN_Don't talk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r to avoid excessive RP|r
.complete 31006,1 
step
.goto 422,54.99,34.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.turnin 31006 >>Turn in The Klaxxi Council
.target Kil'ruk the Wind-Reaver
.accept 31007 >>Accept The Dread Clutches
.accept 31660 >>Accept Not Fit to Swarm
step
.goto 422,54.77,34.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kor'ik|r
.accept 31009 >>Accept Dead Zone
.target Kor'ik
step
.goto 422,55.02,35.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambersmith Zikk|r
.accept 31008 >>Accept Amber Arms
.target Ambersmith Zikk
step
.goto 422,55.833,34.879
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kik'tik|r
.fp Klaxxi'vess >> Get the Klaxxi'vess flight path
.target Kik'tik
.subzoneskip 6315,1
step
#label DungeonReminder
.goto 422,55.92,32.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zit'tix|r
.home >>Set your Hearthstone to Klaxxi'vess
.target Zit'tix
.bindlocation 6315
step
#completewith HauntedCrystal
>>Kill |cRXP_ENEMY_Shek'zeer Bladesworns|r. Loot them for their |cRXP_LOOT_Amber Blades|r
.complete 31008,1 
.mob Shek'zeer Bladesworn
step
>>Click on the |cRXP_PICK_Inactive Sonic Relay|r
.groundgoto 422/870,3982.100,-117.000,30,0
.goto 422,40.02,39.00
.complete 31009,1 
step
>>Click on the popup under your minimap or complete the quest in your questlog
.goto 422,40.02,39.00
.turnin 31009 >>Turn in Dead Zone
.accept 31010 >>Accept In Her Clutch
step
#label HauntedCrystal
.goto 422,44.581,41.317
>>Click the |cRXP_PICK_Sha-Haunted Crystal|r on the ground
.accept 31661 >>Accept A Source of Terrifying Power
step
.isOnQuest 31010
.goto 422,44.76,41.58
.cast 122531 >>Click on the |cRXP_PICK_Ancient Amber Chunk|r
>>|cRXP_WARN_Do NOT wait out the RP after. Continue questing|r
step
#completewith next
>>Kill |cRXP_ENEMY_Shek'zeer Swarmborns|r and |cRXP_ENEMY_Shek'zeer Clutch-Keepers|r
.complete 31660,1 
.mob +Shek'zeer Swarmborn
.complete 31007,1 
.mob +Shek'zeer Clutch-Keeper
step
#loop
.goto 422,49.124,43.860,30,0
.goto 422,39.037,39.632,30,0
>>Kill |cRXP_ENEMY_Shek'zeer Bladesworns|r. Loot them for their |cRXP_LOOT_Amber Blades|r
.complete 31008,1 
.mob Shek'zeer Bladesworn
step
#loop
.goto 422,41.597,42.415,55,0
.goto 422,42.505,46.290,55,0
.goto 422,47.282,41.128,55,0
.goto 422,44.549,40.010,45,0
.goto 422,41.597,42.415,0
.goto 422,42.505,46.290,0
.goto 422,47.282,41.128,0
.goto 422,44.549,40.010,0
>>Kill |cRXP_ENEMY_Shek'zeer Swarmborns|r and |cRXP_ENEMY_Shek'zeer Clutch-Keepers|r
.complete 31660,1 
.mob +Shek'zeer Swarmborn
.complete 31007,1 
.mob +Shek'zeer Clutch-Keeper
step 
#optional
.isOnQuest 31010
.goto 422,44.76,41.58
>>Click on the |cRXP_PICK_Ancient Amber Chunk|r
.complete 31010,1 
step << Shaman
#completewith returnkv
.hs >> Hearth to Klaxxi'vess
.cooldown item,6948,>2,1
.subzoneskip 6315
.bindlocation 6315,1
step
#completewith next
.subzone 6315 >> Return to Klaxxi'vess
step
#label returnkv
.goto 422,55.02,35.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambersmith Zikk|r
.turnin 31008 >>Turn in Amber Arms
.target Ambersmith Zikk
.turnin 31661 >>Turn in A Source of Terrifying Power
.accept 31108 >>Accept Concentrated Fear
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malik the Unscathed|r and |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.turnin 31010 >>Turn in In Her Clutch
.timer 38,Malik the Unscathed RP
.goto 422,54.94,34.13
.target +Malik the Unscathed
.turnin 31007 >>Turn in The Dread Clutches
.turnin 31660 >>Turn in Not Fit to Swarm
.goto 422,54.986,34.045
.target +Kil'ruk the Wind-Reaver
step
.goto 422,54.76,34.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kor'ik|r
.accept 31066 >>Accept A Cry From Darkness
.target Kor'ik
step
.goto 422,55.07,35.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malik the Unscathed|r
.accept 31107 >>Accept Citizens of a New Empire
.target Malik the Unscathed
.accept 31689 >>Accept The Dreadsworn
step
#completewith QitartheDeathcaller
>>Kill |cRXP_ENEMY_Vor'thik Dreadsworns|r
>>Kill |cRXP_ENEMY_Vor'thik Fear-Shapers|r. Loot them for their |cRXP_LOOT_Dread Amber Focus|r
.complete 31689,1 
.mob +Vor'thik Dreadsworn
.complete 31108,1 
.mob +Vor'thik Fear-Shaper
step
#completewith QitartheDeathcaller
>>Loot the |cRXP_PICK_Vor'thik Eggs|r on the ground
.complete 31107,1 
step
#label QitartheDeathcaller
.groundgoto 422,54.74,29.79,40,0
.goto 422,59.40,18.44
>>Kill |cRXP_ENEMY_Qi'tar the Deathcaller|r
.complete 31066,1 
.mob Qi'tar the Deathcaller
step
#completewith VorthikEggs
>>Kill |cRXP_ENEMY_Vor'thik Dreadsworns|r
.complete 31689,1 
.mob Vor'thik Dreadsworn
step
#completewith VorthikEggs
>>Kill |cRXP_ENEMY_Vor'thik Fear-Shapers|r. Loot them for their |cRXP_LOOT_Dread Amber Focus|r
.complete 31108,1 
.mob Vor'thik Fear-Shaper
step
#label VorthikEggs
#loop
.goto 422,59.71,17.01,40,0
.goto 422,60.09,19.53,40,0
.goto 422,58.21,17.94,40,0
.goto 422,59.71,17.01,0
.goto 422,60.09,19.53,0
.goto 422,58.21,17.94,0
>>Loot the |cRXP_PICK_Vor'thik Eggs|r on the ground
.complete 31107,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Vor'thik Dreadsworns|r
.complete 31689,1 
.mob Vor'thik Dreadsworn
step
.goto 422,59.164,14.671,55,0
.goto 422,56.862,11.771,55,0
.goto 422,57.658,16.739,55,0
.goto 422,59.164,14.671,0
.goto 422,56.862,11.771,0
.goto 422,57.658,16.739,0
>>Kill |cRXP_ENEMY_Vor'thik Fear-Shapers|r. Loot them for their |cRXP_LOOT_Dread Amber Focus|r
.complete 31108,1 
.mob Vor'thik Fear-Shaper
step
.goto 422,59.164,14.671,55,0
.goto 422,56.862,11.771,55,0
.goto 422,57.658,16.739,55,0
.goto 422,59.164,14.671,0
.goto 422,56.862,11.771,0
.goto 422,57.658,16.739,0
>>Kill |cRXP_ENEMY_Vor'thik Dreadsworns|r
.complete 31689,1 
.mob Vor'thik Dreadsworn
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jin the Flying Keg|r
.target Jin the Flying Keg
.goto 422/870,3451.700,980.500
.fp The Sunset Brewgarden>>Get The Sunset Brewgarden Flight Path
.noflyable
step << !Shaman
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jin the Flying Keg|r
.target Jin the Flying Keg
.goto 422/870,3451.700,980.500
.fly Klaxxi'vess >>Fly to Klaxxi'vess
.subzoneskip 6334,1
.noflyable
step << Shaman
#completewith next
.hs >> Hearth to Klaxxi'vess
.cooldown item,6948,>2,1
.subzoneskip 6315
.bindlocation 6315,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malik the Unscathed|r and |cRXP_FRIENDLY_Ambersmith Zikk|r
.turnin 31107 >>Turn in Citizens of a New Empire
.turnin 31689 >>Turn in The Dreadsworn
.goto 422,55.060,35.482
.target +Malik the Unscathed
.turnin 31108 >>Turn in Concentrated Fear
.goto 422,55.016,35.555
.target +Ambersmith Zikk
step
.goto 422,54.76,34.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kor'ik|r
.turnin 31066 >>Turn in A Cry From Darkness
.accept 31087 >>Accept Extending Our Coverage
.target Kor'ik
step
.goto 422,55.06,35.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.accept 31019 >>Accept Amber Is Life
.target Kil'ruk the Wind-Reaver
step
.target Kil'ruk the Wind-Reaver
.goto 422,55.06,35.86
.isOnQuest 31087
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.aura 123075 >> Get the |cRXP_WARN_[Klaxxi Enhancement]|r from him to get the |cRXP_WARN_Angel of Death|r buff
.skipgossipid 126276
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.goto 422,55.06,35.86
.isOnQuest 31019
.accept 31267 >>Accept Mistblade Destruction
.target Kil'ruk the Wind-Reaver
.klaxxi lake
step
.goto 422,46.339,52.976,10,0
.goto 422,46.38,52.95
>>Travel to Amberglow Hollow
.complete 31087,1 
step
.goto 422,48.125,49.781
>>Kill |cRXP_ENEMY_Adjunct Zet'uk|r inside Amberglow Hollow
.complete 31087,2 
.mob Adjunct Zet'uk
step
>>Click on the |cRXP_PICK_Silent Beacon|r
.goto 422,48.12,49.75
.complete 31087,3 
step
.goto 422,48.11,49.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kor'ik|r
.turnin 31087 >>Turn in Extending Our Coverage
.accept 31088 >>Accept Crime and Punishment
.accept 31090 >>Accept Better With Age
.target Kor'ik
step
#completewith next
.goto 422,46.339,52.976,10 >>Leave Amberglow Hollow
.subzoneskip 6432,1
step
#completewith IkthikHarvester
#hidewindow
#loop
.goto 422,45.535,52.012,18,0
.goto 422,42.260,50.297,22,0
.goto 422,41.542,52.595,22,0
.goto 422,39.638,52.012,22,0
.goto 422,36.958,51.815,22,0
.goto 422,34.739,51.846,22,0
.goto 422,32.738,50.473,22,0
.goto 422,38.626,49.036,26,0
.goto 422,40.356,47.884,26,0
.goto 422,45.105,57.507,22,0
.goto 422,49.250,62.705,22,0
.goto 422,48.803,64.237,22,0
.goto 422,49.711,66.443,22,0
.goto 422,51.484,66.092,22,0
.goto 422,45.535,52.012,0
.goto 422,51.484,66.092,0
+1
step
#completewith next
>>Kill |cRXP_ENEMY_Ik'thik Harvesters|r
.complete 31088,1 
.mob Ik'thik Harvester
step
#label AmberFilledJar
>>Loot the |cRXP_PICK_Amber Collectors|r on the trees for |cRXP_LOOT_Amber-Filled Jars|r
.complete 31090,1 
step
#label IkthikHarvester
>>Kill |cRXP_ENEMY_Ik'thik Harvesters|r
.complete 31088,1 
.mob Ik'thik Harvester
step
#completewith next
.goto 422,46.339,52.976,10 >> Return to Amberglow Hollow
step
.goto 422,48.11,49.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kor'ik|r
.turnin 31088 >>Turn in Crime and Punishment
.turnin 31090 >>Turn in Better With Age
.accept 31089 >>Accept By the Sea, Nevermore
.target Kor'ik
step
>>|cRXP_WARN_Use the|r |T645165:0|t[Klaxxi Tuning Fork] |cRXP_WARN_at the large rocks|r
.goto 422,43.42,63.55
.use 84119
.complete 31089,1 
.timer 30,By the Sea Nevermore RP
step
.goto 422,43.32,63.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaz'tik the Manipulator|r
.turnin 31089 >>Turn in By the Sea, Nevermore
.target Kaz'tik the Manipulator
.accept 31091 >>Accept Reunited
step
.isOnQuest 31091
.goto 422,43.321,63.498
.gossipoption 129709 >>Talk to |cRXP_FRIENDLY_Kaz'tik the Manipulator|r to begin the escort
.skipgossip
.target Kaz'tik the Manipulator
step
>>|cRXP_WARN_Follow and defend |cRXP_FRIENDLY_Kaz'tik the Manipulator|r|r
.goto 422,43.321,63.498,0
.goto 422,41.763,72.038
.skipgossip 63876,1
.complete 31091,1 
.timer 20,Reunited RP
.target Kaz'tik the Manipulator
.mob Muckscale Ripper
.mob Muckscale Flesh-Hunter
.mob Muckscale Slayer
step
.goto 422,41.38,71.42
>>|cRXP_WARN_Wait out the RP|r
.complete 31091,2 
.target Kaz'tik the Manipulator
step
.goto 422,41.75,72.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaz'tik the Manipulator|r
.turnin 31091 >>Turn in Reunited
.target Kaz'tik the Manipulator
.accept 31092 >>Accept Feed or Be Eaten
.accept 31359 >>Accept The Kunchong Whisperer
step
#completewith OracleHissir
>>Kill |cRXP_ENEMY_Brinshell Snappers|r. Loot them for their |T237345:0|t[|cRXP_LOOT_Succulent Turtle Filet|r]
>>|cRXP_WARN_Use the|r |T237345:0|t[|cRXP_LOOT_Succulent Turtle Filet|r] |cRXP_WARN_to feed|r |cRXP_FRIENDLY_Kovok|r
.use 86489
.collect 86489,6,31092,0x1,-1
.complete 31092,1 
.mob Brineshell Snapper
step
#completewith TurtleFilets
>>Kill the |cRXP_ENEMY_Muckscales|r
.complete 31359,2 
.mob Muckscale Shaman
.mob Muckscale Slayer
.mob Muckscale Ripper
.mob Muckscale Flesh-Hunter
.mob Muckscale Serpentus
step
#label OracleHissir
.goto 422,41.935,63.781
>>Kill |cRXP_ENEMY_Oracle Hiss'ir|r
.complete 31359,1 
.mob Oracle Hiss'ir
step
.goto 422,41.87,63.70
>>Click on the |cRXP_PICK_Glowing Amber|r on the ground
.accept 31398 >>Accept Falling to Pieces
.target Glowing Amber
step
#label TurtleFilets
#loop
.goto 422,44.334,67.336,38,0
.goto 422,45.885,61.940,38,0
.goto 422,39.003,62.402,38,0
.goto 422,35.147,56.680,38,0
.goto 422,34.928,66.549,38,0
.goto 422,39.065,67.311,38,0
.goto 422,41.935,63.781,38,0
.goto 422,44.334,67.336,0
.goto 422,45.885,61.940,0
.goto 422,39.003,62.402,0
.goto 422,35.147,56.680,0
.goto 422,34.928,66.549,0
.goto 422,39.065,67.311,0
.goto 422,41.935,63.781,0
>>Kill |cRXP_ENEMY_Brinshell Snappers|r. Loot them for their |T237345:0|t[|cRXP_LOOT_Succulent Turtle Filet|r]
>>|cRXP_WARN_Use the|r |T237345:0|t[|cRXP_LOOT_Succulent Turtle Filet|r] |cRXP_WARN_to feed|r |cRXP_FRIENDLY_Kovok|r
.use 86489
.collect 86489,6,31092,0x1,-1
.complete 31092,1 
.mob Brineshell Snapper
step
#loop
.goto 422,41.935,63.781,32,0
.goto 422,37.183,57,529,32,0
.goto 422,38.893,68.359,32,0
.goto 422,41.935,63.781,0
.goto 422,37.183,57,529,0
.goto 422,38.893,68.359,0
>>Kill the |cRXP_ENEMY_Muckscales|r
.complete 31359,2 
.mob Muckscale Shaman
.mob Muckscale Slayer
.mob Muckscale Ripper
.mob Muckscale Flesh-Hunter
.mob Muckscale Serpentus
step
.goto 422,31.80,88.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rik'kal the Dissector|r
.turnin -31605 >>Turn in The Zan'thik Dig
.accept 31606 >>Accept The Dissector Wakens
.timer 47,The Dissector Wakens RP
.target Rik'kal the Dissector
step
>>Kill the attacking |cRXP_ENEMY_Mantids|r
.complete 31606,1
.mob Zan'thik Impaler
.mob Zan'thik Manipulator
step
.goto 422,31.80,88.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rik'kal the Dissector|r
.target Rik'kal the Dissector
.turnin 31606 >>Turn in The Dissector Wakens
step
#completewith next
.hs >> Hearth to Klaxxi'vess
.cooldown item,6948,>2,1
.subzoneskip 6315
.bindlocation 6315,1
step
.goto 422,54.26,35.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaz'tik the Manipulator|r
.turnin 31092 >>Turn in Feed or Be Eaten
.turnin 31359 >>Turn in The Kunchong Whisperer
.turnin 31398 >>Turn in Falling to Pieces
.target Kaz'tik the Manipulator
step
.isOnQuest 31019
.target Kaz'tik the Manipulator
.goto 422,54.364,35.932
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaz'tik the Manipulator|r
.aura 127351 >> Get the |cRXP_WARN_[Klaxxi Augmentation]|r from him to get the |cRXP_WARN_Master of Puppets|r buff
.skipgossip 63758,1
step
.isOnQuest 31019
.goto 422/870,3229.300,134.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rik'kal the Dissector|r
.target Rik'kal the Dissector
.aura 127794 >> Get the |cRXP_WARN_[Klaxxi Enhancement]|r from him to get the |cRXP_WARN_Children of the Grave|r buff
.skipgossip 63072,1
step
.isOnQuest 31019
#optional
.klaxxi lake
.goto 422/870,3233.400,133.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rik'kal the Dissector|r and |cRXP_FRIENDLY_Kaz'tik the Manipulator|r
.target Rik'kal the Dissector
.target Kaz'tik the Manipulator
.daily 31268 >>Accept A Little Brain Work
.daily 31271 >>Accept Bad Genes
.daily 31024 >>Accept Kunchong Treats
step
.isOnQuest 31019
#optional
.klaxxi lake
.goto 422/870,3195.800,137.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.target Kil'ruk the Wind-Reaver
.daily 31267 >>Accept Mistblade Destruction
step
#label RelicsoftheSwarm
#loop
.goto 422,62.6,60.66,30,0
.goto 422,64.457,64.439,28,0
.goto 422,67.859,63.296,30,0
.goto 422,67.536,57.168,30,0
>>Kill |cRXP_ENEMY_Mistblade Rippers|r. Loot them for a |T134459:0|t[|cRXP_LOOT_Strange Relic|r]
.use 82870 >>|cRXP_WARN_Use the|r |T134459:0|t[|cRXP_LOOT_Strange Relic|r] |cRXP_WARN_to start the quest|r
.collect 82870,1,31023
.accept 31023 >>Accept Relics of the Swarm
.mob Mistblade Ripper
step
#completewith LeaveCaveRelicAmber
>>Loot the |cRXP_PICK_Mantid Relics|r on the ground
.complete 31023,1 
step
#loop
.goto 422,66.982,63.182,0
.goto 422,66.982,63.182,40,0
.goto 422,67.260,61.020,40,0
.goto 422,65.806,63.709,40,0
.goto 422,64.469,64.025,40,0
>>Kill |cRXP_ENEMY_Mistblade Rippers|r
.complete 31019,1 
.mob Mistblade Ripper
step
#completewith next
.goto 422,66.77,63.94
.subzone 6543 >>Enter the Mistblade Den
step
.goto 422/870,2566.500,-861.600,10,0
.goto 422,66.43,66.11
>>Enter the small hole on the ground and kill the |cRXP_ENEMY_Mistblade Scale-Lord|r
.complete 31019,2 
.mob Mistblade Scale-Lord
step
.goto 422,66.86,65.35
>>Click the |cRXP_PICK_Ancient Amber Chunk|r
.turnin 31019 >>Turn in Amber Is Life
.timer 30,Amber Is Life RP
.target +Ancient Amber Chunk
step
.goto 422,66.86,65.35
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korven the Prime|r
.accept 31021 >>Accept Living Amber
.accept 31020 >>Accept Feeding the Beast
.target Korven the Prime
step
#label LeaveCaveRelicAmber
#completewith LivingAmber
.goto 422,66.77,63.78,10 >>Exit the Mistblade Den
.subzoneskip 6543,1
step
#requires LeaveCaveRelicAmber
#hidewindow
#completewith Mantid Relic
#loop
.goto 422,66.219,62.486,50,0
.goto 422,66.151,57.196,50,0
.goto 422,63.967,60.886,50,0
.goto 422,66.219,62.486,0
.goto 422,66.151,57.196,0
.goto 422,63.967,60.886,0
+1
step
#requires LeaveCaveRelicAmber
#completewith LivingAmber
>>Loot the |cRXP_PICK_Mantid Relics|r on the ground
.complete 31023,1 
step
#requires LeaveCaveRelicAmber
#completewith LivingAmber
>>Kill |cRXP_ENEMY_Coldbite Crocolisks|r
.complete 31020,1 
.mob Coldbite Crocolisk
step
#requires LeaveCaveRelicAmber
>>Loot the |cRXP_PICK_Amber Fragments|r underwater
>>|cRXP_WARN_Use the|r |T463485:0|t[Living Ember] |cRXP_WARN_next to |cRXP_FRIENDLY_Korven the Prime|r to feed him, while he is not eating a|r |cRXP_ENEMY_Crocolisk|r
.use 82864
.collect 82864,9,31021,0x1,-1
.complete 31021,1 
.target Korven the Prime
step
#optional
#label LivingAmber
step
#completewith next
>>Loot the |cRXP_PICK_Mantid Relics|r on the ground
.complete 31023,1 
step
#loop
.goto 422,67.291,56.815,40,0
.goto 422,65.163,54.581,40,0
.goto 422,62.413,56.369,40,0
.goto 422,64.395,61.529,40,0
.goto 422,66.929,60.934,40,0
.goto 422,65.853,58.294,40,0
.goto 422,67.291,56.815,0
.goto 422,65.163,54.581,0
.goto 422,62.413,56.369,0
.goto 422,64.395,61.529,0
.goto 422,66.929,60.934,0
.goto 422,65.853,58.294,0
>>Kill |cRXP_ENEMY_Coldbite Crocolisks|r
.complete 31020,1 
.mob Coldbite Crocolisk
step
#label Mantid Relic
>>Loot the |cRXP_PICK_Mantid Relics|r on the ground
.complete 31023,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korven the Prime|r beside you
.turnin 31020 >>Turn in Feeding the Beast
.turnin 31021 >>Turn in Living Amber
.accept 31022 >>Accept Kypari Zar
.target Korven the Prime
step
>>Click on the |cRXP_PICK_Sonar Tower|r
.goto 422,59.799,59.477
.complete 31022,1 
.timer 102,Kypari Zar RP
step
>>Kill the spawning |cRXP_ENEMY_Ik'thik Towerguards|r
.goto 422,59.799,59.477
.complete 31022,2 
.mob Ik'thik Towerguard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korven the Prime|r beside you
.turnin 31022 >>Turn in Kypari Zar
.accept 31026 >>Accept The Root of the Problem
.target Korven the Prime
step
#completewith next
.goto 422,58.537,59.416
.subzone 6544 >>Enter the Coldbite Burrow
>>|cRXP_WARN_Avoid running over the |cRXP_PICK_Eggs|r on the ground once inside|r
step
.goto 422,57.368,57.776
>>Kill the |cRXP_ENEMY_Coldbite Matriarch|r
*|cRXP_WARN_Avoid running over the |cRXP_PICK_Eggs|r on the ground as they will spawn additional Crocolisks|r
.complete 31026,1 
.mob Coldbite Matriarch
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korven the Prime|r beside you
.turnin 31026 >>Turn in The Root of the Problem
.target Korven the Prime
step
.noflyable
.isOnQuest 31023
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Min the Breeze Rider|r
.target Min the Breeze Rider
.goto 422/870,3137.300,-1088.700
.fly Klaxxi'vess >>Fly to Klaxxi'vess
step
.goto 422,55.02,35.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambersmith Zikk|r
.turnin 31023 >>Turn in Relics of the Swarm
.target Ambersmith Zikk
.accept 31727 >>Accept Gambling Problem
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.goto 422,55.06,35.86
.isQuestComplete 31267
.turnin 31267 >>Turn in Mistblade Destruction
.target Kil'ruk the Wind-Reaver
.accept 31175 >>Accept Skeer the Bloodseeker
step
.goto 422,55.06,35.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.accept 31730 >>Accept A Not So Friendly Request
.target Kil'ruk the Wind-Reaver
.isQuestAvailable 31067
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.goto 422,55.06,35.86
.target Kil'ruk the Wind-Reaver
.accept 31175 >>Accept Skeer the Bloodseeker
step
#optional
.klaxxi south
.goto 422/870,3195.800,137.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.target Kil'ruk the Wind-Reaver
.daily 31111 >>Accept Eradicating the Zan'thik
.daily 31505 >>Accept Vess-Guard Duty
step
.isOnQuest 31175
.goto 422/870,3233.000,128.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korven the Prime|r
.aura 123211 >> Get the |cRXP_WARN_[Klaxxi Augmentation]|r from him to get the |cRXP_WARN_Painkiller|r buff
.skipgossip 62180,1
.target Korven the Prime
step
#optional
.klaxxi south
.goto 422/870,3233.400,133.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rik'kal the Dissector|r, |cRXP_FRIENDLY_Kaz'tik the Manipulator|r and |cRXP_FRIENDLY_Korven the Prime|r
.target Rik'kal the Dissector
.target Kaz'tik the Manipulator
.target Korven the Prime
.daily 31509 >>Accept Fear Takes Root
.daily 31507 >>Accept Meltdown
.daily 31506 >>Accept Shackles of Manipulation
.daily 31508 >>Accept Specimen Request
step
.noflyable
#completewith HeavensHum
.subzoneskip 6334
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kik'tik|r
.target Kik'tik
.goto 422/870,3150.100,172.300
.fly The Sunset Brewgarden >>Fly to The Sunset Brewgarden
.subzoneskip 6315,1
.noflyable
step
#completewith HeavensHum
.goto 422,50.203,12.245
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jin the Flying Keg|r
.fp The Sunset Brewgarden >> Get the Sunset Brewgarden flight path
.target Jin the Flying Keg
.noflyable
step
#label HeavensHum
.goto 422,51.21,11.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sapmaster Vu|r
.turnin -31730 >>Turn in A Not So Friendly Request
.accept 31067 >>Accept The Heavens Hum With War
.target Sapmaster Vu
step
#completewith next
.goto 422,53.525,15.100,10 >>Enter The Amber Vault
step
.goto 422,53.08,12.36
>>Click on the |cRXP_PICK_Scroll of Auspice|r
.accept 31068 >>Accept Sacred Recipe
.target Scroll of Auspice
step
.goto 422,52.78,10.56
>>Kill |cRXP_ENEMY_Azzix K'tai|r
.complete 31067,1 
.mob Azzix K'tai
step
#completewith next
.goto 422,53.525,15.100,10 >>Leave The Amber Vault
step
.goto 422,50.73,11.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lya of Ten Songs|r
.turnin 31068 >>Turn in Sacred Recipe
.timer 36,Lya of Ten Songs Roleplay
.target Lya of Ten Songs
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sapmaster Vu|r, |cRXP_FRIENDLY_Olon|r, and |cRXP_FRIENDLY_Thirsty Missho|r
.turnin 31067 >>Turn in The Heavens Hum With War
.accept 31069 >>Accept Bound With Shade
.goto 422,51.21,11.39
.target +Sapmaster Vu
.accept 31070 >>Accept Daggers of the Great Ones
.goto 422,51.16,11.21
.target +Olon
.accept 31071 >>Accept I Bring Us Great Shame
.goto 422,51.133,11.109
.target +Thirsty Missho
step
.goto 422,50.44,12.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.daily 31076,31129 >>Accept Fate of the Stormstouts
.target Chen Stormstout
step
.isOnQuest 31076
.goto 422,50.91,11.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Dan Stormstout|r
.complete 31076,3 
.skipgossip 62845,1
.target Big Dan Stormstout
step
.isOnQuest 31076
.goto 422,51.21,11.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sapmaster Vu|r
.complete 31076,1 
.skipgossip 62666,1
.target Sapmaster Vu
step
.isOnQuest 31076
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lya of Ten Songs|r
.goto 422,50.73,11.70
.skipgossip 62667,1
.complete 31076,2 
.target Lya of Ten Songs
step
.isOnQuest 31129
.goto 422,50.91,11.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Big Dan Stormstout|r
.complete 31129,3 
.skipgossip 62845,1
.target Big Dan Stormstout
step
.isOnQuest 31129
.goto 422,51.21,11.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sapmaster Vu|r
.complete 31129,1 
.skipgossip 62666,1
.target Sapmaster Vu
step
.isOnQuest 31129
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lya of Ten Songs|r
>>|cRXP_WARN_You may need to wait for her RP|r
.goto 422,50.73,11.70
.skipgossip 62667,1
.complete 31129,2 
.target Lya of Ten Songs
step
.goto 422,50.73,11.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lya of Ten Songs|r
.accept 31072 >>Accept Rending Daggers
.target Lya of Ten Songs
step
.goto 422,50.45,12.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.turnin 31076 >>Turn in Fate of the Stormstouts
.target Chen Stormstout
.isQuestComplete 31076
step
.goto 422,50.45,12.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.turnin 31129 >>Turn in Fate of the Stormstouts
.target Chen Stormstout
.isQuestComplete 31129
step
#completewith ShadeHarvested
>>Kill |cRXP_ENEMY_Frightened Mushans|r. Loot them for their |cRXP_LOOT_Large Mushan Teeth|r
.complete 31070,1 
.mob Frightened Mushan
step
>>Loot the |cRXP_PICK_Lost Mugs|r on the rock
.goto 422,51.72,19.07
.complete 31071,1 
step
#label BladeofIlikkax
>>Kill |cRXP_ENEMY_Ilikkax|r. Loot him for the |cRXP_LOOT_Blade of Ilikkax|r
.goto 422,50.94,20.86
.complete 31072,2 
.mob Ilikkax
step
#loop
.goto 422,52.106,21.147,15,0
.goto 422,53.558,19.712,15,0
.goto 422,52.106,21.147,0
.goto 422,53.558,19.712,0
>>Kill |cRXP_ENEMY_Kz'Kzik|r. Loot him for the |cRXP_LOOT_Blade of Kz'Kzik|r
>>|cRXP_ENEMY_Kz'Kzik|r |cRXP_WARN_patrols slightly|r
.complete 31072,1 
.mob Kz'Kzik
step
.goto 422,54.11,20.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.accept 31077 >>Accept Evie Stormstout
.target Chen Stormstout
step
>>Loot the |cRXP_PICK_Lost Keg|r on the ground
.goto 422,54.41,20.33
.complete 31071,2 
step
#completewith LostPicnic
>>Kill |cRXP_ENEMY_Dread Lurkers|r and |cRXP_ENEMY_Nagging Dreadlings|r
.complete 31069,1 
.mob Dread Lurker
.mob Nagging Dreadling
step
#label LostPicnic
>>Loot the |cRXP_PICK_Lost Picnic Supplies|r on the ground
.goto 422,56.02,19.43
.complete 31071,3 
step
#label ShadeHarvested
#loop
.goto 422,57.958,20.062,45,0
.goto 422,56.105,16.052,45,0
.goto 422,53.995,17.333,45,0
.goto 422,55.094,19.947,45,0
.goto 422,57.958,20.062,0
.goto 422,56.105,16.052,0
.goto 422,53.995,17.333,0
.goto 422,55.094,19.947,0
>>Kill |cRXP_ENEMY_Dread Lurkers|r and |cRXP_ENEMY_Nagging Dreadlings|r
.complete 31069,1 
.mob Dread Lurker
.mob Nagging Dreadling
step
#loop
.goto 422,51.940,14.578,55,0
.goto 422,49.263,16.335,55,0
.goto 422,47.060,20.709,55,0
.goto 422,49.102,22.156,55,0
.goto 422,56.034,14.707,55,0
.goto 422,51.940,14.578,0
.goto 422,49.263,16.335,0
.goto 422,47.060,20.709,0
.goto 422,49.102,22.156,0
.goto 422,56.034,14.707,0
>>Kill |cRXP_ENEMY_Frightened Mushans|r. Loot them for their |cRXP_LOOT_Large Mushan Teeth|r
.complete 31070,1 
.mob Frightened Mushan
step
.goto 422,50.18,10.19
>>Travel to |cRXP_FRIENDLY_Chen Stormstout|r to begin the RP
.complete 31077,1 
.timer 27,Chen Stormstout RP
step
#completewith EvieTurnin
>>|cRXP_WARN_Turn in the other quests while waiting for the roleplay|r
.complete 31077,2 
step
.goto 422,50.73,11.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lya of Ten Songs|r
.turnin 31072 >>Turn in Rending Daggers
.accept 31074 >>Accept Wood and Shade
.target Lya of Ten Songs
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thirsty Missho|r, |cRXP_FRIENDLY_Olon|r, and |cRXP_FRIENDLY_Sapmaster Vu|r
.turnin 31071 >>Turn in I Bring Us Great Shame
.goto 422,51.139,11.112
.target +Thirsty Missho
.turnin 31070 >>Turn in Daggers of the Great Ones
.goto 422,51.17,11.22
.target +Olon
.turnin 31069 >>Turn in Bound With Shade
.accept 31073 >>Accept Bound With Wood
.goto 422,51.21,11.40
.target +Sapmaster Vu
step
#label EvieTurnin
.goto 422,50.18,10.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.turnin 31077 >>Turn in Evie Stormstout
.target Chen Stormstout
.accept 31078 >>Accept Han Stormstout
step
.goto 422,50.18,12.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Defender Azzo|r
.accept 31133 >>Accept Kor'thik Aggression
.target Defender Azzo
step
.goto 422,46.508,16.809
#completewith HanStormstout
.subzone 6346 >>Enter the Morrowchamber
step
#completewith HanStormstout
>>Kill |cRXP_ENEMY_Kor'thik Mantids|r
.complete 31133,1 
.mob Kor'thik Chitinel
.mob Kor'thik Battlesinger
.mob Kor'thik Havoc
step
>>|cRXP_WARN_Follow the arrow to get to |cRXP_FRIENDLY_Han Stormstout|r inside the Morrowchamber|r
>>|cRXP_WARN_Running into the |cRXP_PICK_Amber Beam|r will cause you to take damage and be knocked back|r
.goto 422,44.862,16.587,15,0
.goto 422,45.486,14.655,15,0
.goto 422,44.313,15.861,15,0
.goto 422,43.554,15.682,15,0
.goto 422,42.624,14.560,15,0
.goto 422,43.369,16.020,15,0
.goto 422,43.77,16.74
.complete 31078,1 
.target Han Stormstout
step
#label HanStormstout
.goto 422,44.41,16.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.turnin 31078 >>Turn in Han Stormstout
.target Chen Stormstout
step
>>Kill |cRXP_ENEMY_Kor'thik Mantids|r
.goto 422,44.41,16.81
.complete 31133,1 
.mob Kor'thik Chitinel
.mob Kor'thik Battlesinger
.mob Kor'thik Havoc
step
#completewith MarkoftheEmpress
#label LeaveMorrowchamber
.goto 422,47.22,16.84,10 >>Leave the Morrowchamber and head up the hill
.subzoneskip 6346,1
step
#completewith MarkoftheEmpress
#requires LeaveMorrowchamber
.goto 422,44.754,15.935,8 >>Enter the house
step
#label MarkoftheEmpress
>>|cRXP_WARN_Run down the stairs|r
.goto 422,44.754,15.935,0
.goto 422,44.515,16.778
.complete 31074,1 
step
#completewith HeartrootofKypariKor
#label LeavetheHouseA
.goto 422,44.754,15.935,8 >>Leave the house
step
#completewith HeartrootofKypariKor
#requires LeavetheHouseA
.goto 422,43.050,13.965,8 >>Enter the house
step
#label HeartrootofKypariKor
>>|cRXP_WARN_Run down the stairs|r
.goto 422,43.116,14.988
.complete 31074,2 
step
#completewith next
.goto 422,43.050,13.965,8 >>Leave the house
step
#completewith Hulking Kor'thik Fleshrender
>>Loot the |cRXP_FRIENDLY_Withered Husks|r
>>|cRXP_WARN_This is possible while mounted|r
.complete 31073,1 
.target Withered Husk
step
.isOnQuest 30975
.goto 422,44.87,9.87,5 >>Follow the Arrow
.timer 15, Time until enemy arrival
step
.isOnQuest 30975
#label Hulking Kor'thik Fleshrender
.goto 422,43.33,10.89,20,0
.goto 422,44.38,12.08,20,0
.goto 422,45.57,11.24,20,0
.goto 422,44.85,9.96
>>Kill incoming |cRXP_ENEMY_Kor'thik Bloodletters|r and |cRXP_ENEMY_Hulking Kor'thik Fleshrender|r
>>|cRXP_WARN_Pick up barrels for a damage buff|r
.complete 30975,1 
.mob +Kor'thik Bloodletter
.complete 30975,2 
.mob +Hulking Kor'thik Fleshrender
step
#completewith KorthikMantid
#hidewindow
#loop
.goto 422,42.796,7.545,35,0
.goto 422,44.556,7.456,35,0
.goto 422,48.603,11.101,35,0
.goto 422,47.245,19.051,35,0
.goto 422,45.008,18.417,37,0
.goto 422,45.957,13.026,35,0
.goto 422,43.095,12.129,35,0
.goto 422,42.796,7.545,0
.goto 422,44.556,7.456,0
.goto 422,48.603,11.101,0
.goto 422,47.245,19.051,0
.goto 422,45.008,18.417,0
.goto 422,45.957,13.026,0
.goto 422,43.095,12.129,0
+1
step
#loop
.goto 422,42.44,10.36,70,0
.goto 422,46.01,14.09,70,0
.goto 422,45.48,18.71,70,0
>>Loot the |cRXP_FRIENDLY_Withered Husks|r
>>|cRXP_WARN_This is possible while mounted|r
.complete 31073,1 
.target Withered Husk
step
#label KorthikMantid
#loop
.goto 422,42.44,10.36,70,0
.goto 422,46.01,14.09,70,0
.goto 422,45.48,18.71,70,0
>>Kill |cRXP_ENEMY_Kor'thik Mantids|r
.complete 31133,1 
.mob Kor'thik Chitinel
.mob Kor'thik Battlesinger
.mob Kor'thik Havoc
step
.goto 422,50.20,12.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Defender Azzo|r
.turnin 31133 >>Turn in Kor'thik Aggression
.target Defender Azzo
step
.goto 422,50.73,11.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lya of Ten Songs|r
.turnin 31074 >>Turn in Wood and Shade
.target Lya of Ten Songs
step
.goto 422,51.21,11.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sapmaster Vu|r
.turnin 31073 >>Turn in Bound With Wood
.accept 31075 >>Accept Sunset Kings
.target Sapmaster Vu
step
#completewith next
.noflyable
.goto 422/870,3919.400,549.000,20,0
.goto 422,38.19,17.18
.subzone 6336 >> Head to Rikkitun Village
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sapmaster Vu|r
.goto 422,38.19,17.18
.turnin 31075 >>Turn in Sunset Kings
.target Sapmaster Vu
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Olon|r, |cRXP_FRIENDLY_Boggeo|r and |cRXP_FRIENDLY_Lya of Ten Songs|r
.accept 31080 >>Accept Fiery Wings
.goto 422,38.20,17.13
.target +Olon
.accept 31079 >>Accept The Horror Comes A-Rising
.goto 422,38.159,17.339
.target +Boggeo
.accept 31081 >>Accept Incantations Fae and Primal
.goto 422,38.302,17.137
.target +Lya of Ten Songs
step
.goto 422,38.65,17.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Rikkitun|r
.accept 31082 >>Accept Great Vessel of Salvation
.target Chief Rikkitun
step
#completewith Motherseed
>>Kill |cRXP_ENEMY_Shuffling Mistlurkers|r and |cRXP_ENEMY_Kyparites|r
>>|cRXP_WARN_Step onto the clouds of dust on the ground to spawn|r |cRXP_ENEMY_Kyparites|r
.complete 31079,1 
.mob +Shuffling Mistlurker
.complete 31079,2 
.mob +Kyparite
step
.goto 422,33.07,19.13
>>Kill |cRXP_ENEMY_Mygoness|r
.complete 31081,2 
.mob Mygoness
step
.goto 422,32.10,17.35
>>Kill |cRXP_ENEMY_Ahgunoss|r
.complete 31081,1 
.mob Ahgunoss
step
#label FliterringDust
#loop
.goto 422,34.321,22.761,35,0
.goto 422,39.261,24.069,35,0
.goto 422,39.536,19.790,35,0
.goto 422,36.998,14.867,35,0
.goto 422,34.321,22.761,0
.goto 422,39.261,24.069,0
.goto 422,39.536,19.790,0
.goto 422,36.998,14.867,0
>>Click on |cRXP_FRIENDLY_Rikkilea Flitterlings|r
>>|cRXP_WARN_Follow them as they move away to catch the dust|r
.complete 31080,1 
.target Rikkilea Flitterling
step
#completewith next
#loop
.goto 422,36.998,14.867,35,0
.goto 422,35.666,18.056,35,0
.goto 422,35.956,22.458,35,0
.goto 422,34.321,19.465,35,0
.goto 422,36.998,14.867,0
.goto 422,35.666,18.056,0
.goto 422,35.956,22.458,0
.goto 422,34.321,19.465,0
.cast 122165 >>Click on a |cRXP_PICK_Motherseed|r
.use 84267 >>|cRXP_WARN_If you are unable to click it use the|r |T133706:0|t[Rikkitun Bell] |cRXP_WARN_to summon the|r |cRXP_FRIENDLY_Rikkitun Chanters|r
step
>>Bring the |cRXP_FRIENDLY_Motherseed|r back to the Motherseed Pit
.use 84267 >>|cRXP_WARN_Use the|r |T133706:0|t[Rikkitun Bell] |cRXP_WARN_if you can't click on the seeds|r
.goto 422,36.897,17.445
.use 84267
.complete 31082,1,1 
step
#completewith next
#loop
.goto 422,34.321,19.465,35,0
.goto 422,36.998,14.867,35,0
.goto 422,35.666,18.056,35,0
.goto 422,35.956,22.458,35,0
.goto 422,34.321,19.465,0
.goto 422,36.998,14.867,0
.goto 422,35.666,18.056,0
.goto 422,35.956,22.458,0
.cast 122165 >>Click on a |cRXP_PICK_Motherseed|r
.use 84267 >>|cRXP_WARN_If you are unable to click it use the|r |T133706:0|t[Rikkitun Bell] |cRXP_WARN_to summon the|r |cRXP_FRIENDLY_Rikkitun Chanters|r
step
>>Bring the |cRXP_FRIENDLY_Motherseed|r back to the Motherseed Pit
>>|cRXP_WARN_You may only take back one at a time|r
.use 84267 >>|cRXP_WARN_Use the|r |T133706:0|t[Rikkitun Bell] |cRXP_WARN_if you can't click on the seeds|r
.goto 422,36.897,17.445
.complete 31082,1,2 
step
#completewith next
#loop
.goto 422,35.956,22.458,35,0
.goto 422,34.321,19.465,35,0
.goto 422,36.998,14.867,35,0
.goto 422,35.666,18.056,35,0
.goto 422,35.956,22.458,0
.goto 422,34.321,19.465,0
.goto 422,36.998,14.867,0
.goto 422,35.666,18.056,0
.cast 122165 >>Click on a |cRXP_PICK_Motherseed|r
.use 84267 >>|cRXP_WARN_If you are unable to click it use the|r |T133706:0|t[Rikkitun Bell] |cRXP_WARN_to summon the|r |cRXP_FRIENDLY_Rikkitun Chanters|r
step
#label Motherseed
>>Bring the |cRXP_FRIENDLY_Motherseed|r back to the Motherseed Pit
>>|cRXP_WARN_You may only take back one at a time|r
.use 84267 >>|cRXP_WARN_Use the|r |T133706:0|t[Rikkitun Bell] |cRXP_WARN_if you can't click on the seeds|r
.goto 422,36.897,17.445
.complete 31082,1 
step
#loop
.goto 422,32.060,20.009,35,0
.goto 422,33.450,23.674,35,0
.goto 422,36.371,20.878,35,0
.goto 422,38.385,14.506,35,0
.goto 422,32.060,20.009,0
.goto 422,33.450,23.674,0
.goto 422,36.371,20.878,0
.goto 422,38.385,14.506,0
>>Kill |cRXP_ENEMY_Shuffling Mistlurkers|r and |cRXP_ENEMY_Kyparites|r
>>|cRXP_WARN_Step onto the clouds of dust on the ground to spawn|r |cRXP_ENEMY_Kyparites|r
.complete 31079,1 
.mob +Shuffling Mistlurker
.complete 31079,2 
.mob +Kyparite
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boggeo|r, |cRXP_FRIENDLY_Olon|r, and |cRXP_FRIENDLY_Lya of Ten Songs|r
.turnin 31079 >>Turn in The Horror Comes A-Rising
.goto 422,38.16,17.34
.target +Boggeo
.turnin 31080 >>Turn in Fiery Wings
.goto 422,38.20,17.12
.target +Olon
.turnin 31081 >>Turn in Incantations Fae and Primal
.goto 422,38.304,17.137
.target +Lya of Ten Songs
step
.goto 422,38.65,17.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Rikkitun|r
.turnin 31082 >>Turn in Great Vessel of Salvation
.target Chief Rikkitun
.accept 31084 >>Accept Bind the Glamour
step
#completewith next
.gossipoption 129468 >>Talk to |cRXP_FRIENDLY_Chief Rikkitun|r
.timer 55,Bind the Glamour RP
.goto 422,38.65,17.25
.target Chief Rikkitun
step
.goto 422,38.65,17.25,0
>>Follow |cRXP_FRIENDLY_Chief Rikkitun|r
>>|cRXP_WARN_Don't run too far away from him (at maximum 90 yards)|r
.goto 422,39.67,23.18
.complete 31084,1 
.target Chief Rikkitun
step
.goto 422,38.65,17.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Rikkitun|r
.turnin 31084 >>Turn in Bind the Glamour
.target Chief Rikkitun
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lya of Ten Songs|r and |cRXP_FRIENDLY_Sapmaster Vu|r
.accept 31085 >>Accept Fires and Fears of Old
.goto 422,38.30,17.13
.target +Lya of Ten Songs
.accept 31086 >>Accept Blood of Ancients
.goto 422,38.183,17.184
.target +Sapmaster Vu
step
>>Loot the |cRXP_PICK_Solidified Amber|r on the ground
.goto 422,30.22,30.58
.complete 31086,1 
step
#completewith next
.goto 422,30.23,31.68,10,0
.cast 123270 >>Click on the |cRXP_PICK_Enormous Landslide|r rocks
step
#completewith next
.goto 422,30.431,31.896,12 >>Enter The Amber Hibernal
step
>>|cRXP_WARN_Use the|r |T645165:0|t[Ruining Fork] |cRXP_WARN_on|r |cRXP_FRIENDLY_Iyyokuk the Lucid|r
.goto 422,32.67,33.88
.use 84771
.complete 31085,1 
.target Iyyokuk the Lucid
step
>>Kill |cRXP_ENEMY_Adjunct G'kkal|r, |cRXP_ENEMY_Adjunct Okzyk|r, and |cRXP_ENEMY_Adjunct Pivvika|r
.goto 422,33.013,34.129
.complete 31085,2 
.mob Adjunct G'kkal
.mob Adjunct Okzyk
.mob Adjunct Pivvika
step
#completewith next
.goto 422,30.431,31.896,12 >>Leave The Amber Hibernal
.subzoneskip 6338,1
step
#completewith SeekertheBloodseeker
.goto 422,25.752,53.923,12 >>Enter the underwater cave
step << skip
.isQuestAvailable 31436
.goto 422,25.967,50.238
>>Click on the |cRXP_PICK_Bloodsoaked Chitin Fragment|r
*|cRXP_WARN_Skip this step if it's not there|r
.collect 86525,1
step
#label SeekertheBloodseeker
>>Click on the |cRXP_PICK_Ancient Amber Chunk|r
.goto 422,25.709,50.342
.complete 31175,1 
.timer 30,Skeer the Bloodseeker RP
step
.goto 422,25.71,50.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Skeer the Bloodseeker|r
.turnin 31175 >>Turn in Skeer the Bloodseeker
.target Skeer the Bloodseeker
.accept 31176 >>Accept A Strange Appetite
.accept 31177 >>Accept Fine Dining
.accept 31178 >>Accept A Bloody Delight
step
#completewith next
.goto 422,25.752,53.923,12 >>Leave the cave
.subzoneskip 6403,1
step
#completewith VolatileBlood
#hidewindow
#loop
.goto 422,25.435,55.593,25,0
.goto 422,27.393,53.959,30,0
.goto 422,28.144,65.767,40,0
.goto 422,22.978,65.299,32,0
.goto 422,25.435,55.593,0
.goto 422,27.393,53.959,0
.goto 422,28.144,65.767,0
.goto 422,22.978,65.299,0
+1
step
#completewith ClackerTail
>>Loot the |cRXP_PICK_Spiny Starfish|r on the ground
.complete 31176,1 
step
#completewith StartfishMeat
>>Kill |cRXP_ENEMY_Dread Remoras|r. Loot them for their |cRXP_LOOT_Volatile Blood|r
.complete 31178,1 
.mob Dread Remora
step
#label ClackerTail
>>Kill |cRXP_ENEMY_Briny Clackers|r. Loot them for their |cRXP_LOOT_Clacker Tails|r
.complete 31177,1 
.mob Briny Clacker
step
#label StartfishMeat
>>Loot the |cRXP_PICK_Spiny Starfish|r on the ground
.complete 31176,1 
step
#label VolatileBlood
>>Kill |cRXP_ENEMY_Dread Remoras|r. Loot them for their |cRXP_LOOT_Volatile Blood|r
.complete 31178,1 
.mob Dread Remora
step
#completewith next
.goto 422,25.752,53.923,12 >>Enter the cave
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Skeer the Bloodseeker|r
.goto 422,25.71,50.61
.turnin 31176 >>Turn in A Strange Appetite
.turnin 31177 >>Turn in Fine Dining
.turnin 31178 >>Turn in A Bloody Delight
.accept 31179 >>Accept The Scent of Blood
.timer 100,The Scent of Blood RP
.target Skeer the Bloodseeker
step
>>|cRXP_WARN_Wait at the waypoint location|r
>>Kill the spawning |cRXP_ENEMY_Muckscale Flesheaters|r and the |cRXP_ENEMY_Muckscale Serpentus|r
.goto 422,25.711,52.037
.complete 31179,1 
.mob +Muckscale Flesheater
.complete 31179,2 
.mob +Muckscale Serpentus
step
#completewith next
.hs >> Hearth to Klaxxi'vess
.cooldown item,6948,>2,1
.subzoneskip 6315
.bindlocation 6315,1
step
.goto 422,55.06,35.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kil'ruk the Wind-Reaver|r
.turnin 31179 >>Turn in The Scent of Blood
.target Kil'ruk the Wind-Reaver
step
#completewith next
.subzoneskip 6334
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kik'tik|r
.target Kik'tik
.goto 422/870,3150.100,172.300
.fly The Sunset Brewgarden >>Fly to The Sunset Brewgarden
.subzoneskip 6315,1
.noflyable
step
#label BloodAncientsFiresFearsOld
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sapmaster Vu|r and |cRXP_FRIENDLY_Lya of Ten Songs|r
.turnin 31086 >>Turn in Blood of Ancients
.goto 422,50.22,12.11
.target +Sapmaster Vu
.turnin 31085 >>Turn in Fires and Fears of Old
.goto 422,50.29,12.07
.target +Lya of Ten Songs
step
.subzoneskip 6315
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jin the Flying Keg|r
.goto 422,50.203,12.245
.target Jin the Flying Keg
.fly Klaxxi'vess >>Fly to Klaxxi'vess
.noflyable
step << Shaman
#completewith next
.hs >> Hearth to Klaxxi'vess
.cooldown item,6948,>2,1
.subzoneskip 6315
.bindlocation 6315,1
step
.goto 422/870,3224.700,122.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Skeer the Bloodseeker|r
.target Skeer the Bloodseeker
.aura 123219 >> Get the |cRXP_WARN_[Klaxxi Augmentation]|r from him to get the |cRXP_WARN_Battle Hymn|r buff
.skipgossip 63071,1
.zoneskip 422,1
#label pt1end
step
#label pt2start
.noflyable
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kik'tik|r or |cRXP_FRIENDLY_Jin the Flying Keg|r
.goto 422/870,3451.300,980.200,-1
.target Jin the Flying Keg
.goto 422/870,3152.300,172.700,-1
.target Kik'tik
.fly Soggy's Gamble >>Fly to Soggy's Gamble
.noflyable
step
.goto 422,54.715,72.168
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deck Boss Arie|r
.turnin -31727 >>Turn in Gambling Problem
.accept 31265 >>Accept Mazu's Breath
.target Deck Boss Arie
step
.use 85869 >>|cRXP_WARN_Use the|r |T134851:0|t[Potion of Mazu's Breath]
.complete 31265,1 
step
.goto 422,54.722,72.153
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deck Boss Arie|r
.turnin 31265 >>Turn in Mazu's Breath
.accept 31181 >>Accept Fresh Pots
.accept 31182 >>Accept You Otter Know
.target Deck Boss Arie
step
#completewith next
.use 85231 >>|cRXP_WARN_Use the|r |T133639:0|t[Bag of Clams] |cRXP_WARN_on|r |cRXP_FRIENDLY_Coldwhisker Otters|r
.complete 31182,1 
.target Coldwhisker Otter
step
#loop
.goto 422,58.439,82.072,0
.goto 422,58.439,82.072,60,0
.goto 422,59.698,83.842,60,0
.goto 422,61.288,83.141,60,0
.goto 422,61.465,80.183,60,0
.goto 422,59.840,78.701,60,0
>>Kill |cRXP_ENEMY_Sea Monarchs|r. Loot them for their |T237338:0|t[|cRXP_LOOT_Sea Monarch Chunks|r]
>>|cRXP_WARN_Open the|r |cRXP_PICK_Empty Crab Pots|r|cRXP_WARN_. To open one you need 2|r |T237338:0|t[|cRXP_LOOT_Sea Monarch Chunks|r]
.collect 85230,20,31181,0x1,-2
.complete 31181,1 
.mob Sea Monarch
step
#loop
.goto 422,59.698,83.842,0
.goto 422,58.439,82.072,60,0
.goto 422,59.698,83.842,60,0
.goto 422,61.288,83.141,60,0
.goto 422,61.465,80.183,60,0
.goto 422,59.840,78.701,60,0
.use 85231 >>|cRXP_WARN_Use the|r |T133639:0|t[Bag of Clams] |cRXP_WARN_on|r |cRXP_FRIENDLY_Coldwhisker Otters|r
.complete 31182,1 
.target Coldwhisker Otter
step
.goto 422,54.724,72.153
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deck Boss Arie|r
.turnin 31181 >>Turn in Fresh Pots
.turnin 31182 >>Turn in You Otter Know
.accept 31183 >>Accept Meet the Cap'n
.target Deck Boss Arie
step
.goto 422,55.663,72.496
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain "Soggy" Su-Dao|r inside the hut
.turnin 31183 >>Turn in Meet the Cap'n
.accept 31185 >>Accept Walking Dog
.accept 31184 >>Accept Old Age and Treachery
.target Captain "Soggy" Su-Dao
step
.goto 422,54.721,72.172
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deck Boss Arie|r
.accept 31187 >>Accept On the Crab
.target Deck Boss Arie
step
.goto 422,53.629,76.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Angler Ju Lien|r
.accept 31188 >>Accept Shark Week
.target Master Angler Ju Lien
step
.goto 422,44.392,77.827
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dog|r
.use 85955 >>|cRXP_WARN_Use|r |T134434:0|t[Dog's Whistle] |cRXP_WARN_to summon|r |cRXP_FRIENDLY_Dog|r
.accept 31186 >>Accept Dog Food
step
#completewith WhaleCorpse
>>Kill |cRXP_ENEMY_Longfin Threshers|r. Loot them for their |T463487:0|t[|cRXP_LOOT_Thresher Jaws|r]
.use 85998 >>|cRXP_WARN_Use the|r |T463487:0|t[|cRXP_LOOT_Thresher Jaws|r] |cRXP_WARN_to loot their|r |cRXP_LOOT_Teeth|r
.complete 31188,1 
.mob Longfin Thresher
step
#completewith ThresherTeeth
>>Click the |cRXP_PICK_Full Crab Pots|r on the ocean floor
.complete 31187,1 
step
#completewith CrabPots
>>Kill |cRXP_ENEMY_Rockshell Snapclaws|r
.use 85955 >>|cRXP_WARN_Ensure |cRXP_FRIENDLY_Dog|r is beside you when you kill them|r
.complete 31186,1 
.mob Rockshell Snapclaw
step
.goto 422,44.392,77.827
>>|cRXP_WARN_Swim to the Wreck of the Mist-Hopper|r
.use 85955 >>|cRXP_WARN_Use|r |T134434:0|t[Dog's Whistle] |cRXP_WARN_to summon |cRXP_FRIENDLY_Dog|r if you lost him|r
.complete 31185,2 
step
.goto 422,44.724,78.656
>>Loot |cRXP_PICK_Soggy's Footlocker|r for the |cRXP_LOOT_Sealed Charter Tube|r
.complete 31184,1 
step
.goto 422,45.834,73.803
>>|cRXP_WARN_Swim to the Silt Vents|r
.use 85955 >>|cRXP_WARN_Use|r |T134434:0|t[Dog's Whistle] |cRXP_WARN_to summon |cRXP_FRIENDLY_Dog|r if you lost him|r
.complete 31185,1 
step
#label WhaleCorpse
.goto 422,40.387,77.943
>>|cRXP_WARN_Swim to the Whale Corpse|r
.use 85955 >>|cRXP_WARN_Use|r |T134434:0|t[Dog's Whistle] |cRXP_WARN_to summon |cRXP_FRIENDLY_Dog|r if you lost him|r
.complete 31185,3 
step
#label ThresherTeeth
#loop
.goto 422,47.489,75.500,0
.goto 422,47.489,75.500,60,0
.goto 422,47.601,70.762,60,0
.goto 422,45.033,70.058,60,0
.goto 422,43.062,72.536,60,0
.goto 422,41.706,77.748,60,0
.goto 422,39.035,78.744,60,0
.goto 422,42.991,78.453,60,0
>>Kill |cRXP_ENEMY_Longfin Threshers|r. Loot them for their |T463487:0|t[|cRXP_LOOT_Thresher Jaws|r]
.use 85998 >>|cRXP_WARN_Use the|r |T463487:0|t[|cRXP_LOOT_Thresher Jaws|r] |cRXP_WARN_to loot their|r |cRXP_LOOT_Teeth|r
.complete 31188,1 
.mob Longfin Thresher
step
#label CrabPots
#loop
.goto 422,47.601,70.762,0
.goto 422,47.489,75.500,60,0
.goto 422,47.601,70.762,60,0
.goto 422,45.033,70.058,60,0
.goto 422,43.062,72.536,60,0
.goto 422,41.706,77.748,60,0
.goto 422,39.035,78.744,60,0
.goto 422,42.991,78.453,60,0
>>Click the |cRXP_PICK_Full Crab Pots|r on the ocean floor
.complete 31187,1 
step
#loop
.goto 422,45.033,70.058,0
.goto 422,47.489,75.500,60,0
.goto 422,47.601,70.762,60,0
.goto 422,45.033,70.058,60,0
.goto 422,43.062,72.536,60,0
.goto 422,41.706,77.748,60,0
.goto 422,39.035,78.744,60,0
.goto 422,42.991,78.453,60,0
>>Kill |cRXP_ENEMY_Rockshell Snapclaws|r
.complete 31186,1 
.use 85955 >>|cRXP_WARN_Ensure |cRXP_FRIENDLY_Dog|r is beside you when you kill them|r
.mob Rockshell Snapclaw
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dog|r next to you
.use 85955 >>|cRXP_WARN_Use|r |T134434:0|t[Dog's Whistle] |cRXP_WARN_to summon |cRXP_FRIENDLY_Dog|r if you lost him|r
.turnin 31186 >>Turn in Dog Food
step
.goto 422,55.662,72.505
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain "Soggy" Su-Dao|r
.turnin 31184 >>Turn in Old Age and Treachery
.target Captain "Soggy" Su-Dao
step
.goto 422,54.719,72.167
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deck Boss Arie|r
.turnin 31188 >>Turn in Shark Week
.turnin 31187 >>Turn in On the Crab
.accept 31189 >>Accept Reeltime Strategy
.target Deck Boss Arie
step
.goto 422,53.629,76.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Angler Ju Lien|r
.complete 31189,1 
.target Master Angler Ju Lien
.skipgossip
step
.goto 422,53.629,76.031
>>Click on the |cRXP_PICK_Serpent Rod|r, |cRXP_PICK_Improvised Rod|r and |cRXP_PICK_Classic Rod|r next to |cRXP_FRIENDLY_Master Angler Ju Lien|r
>>Kill the |cRXP_ENEMY_Jiao Spawns|r that spawn
>>|cRXP_WARN_If you are unable to click the |cRXP_PICK_Rods|r, talk to him again|r
.complete 31189,2 
.mob Jiao Spawn
step
.goto 422,54.726,72.162
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deck Boss Arie|r
.turnin 31189 >>Turn in Reeltime Strategy
.target Deck Boss Arie
step
.goto 422,54.810,72.028
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain "Soggy" Su-Dao|r
.turnin 31185 >>Turn in Walking Dog
.accept 31190 >>Accept The Mariner's Revenge
.target Captain "Soggy" Su-Dao
step
.goto 422,56.172,76.357
.vehicle >>|cRXP_WARN_Enter the|r |cRXP_FRIENDLY_Mist-Hopper Jr.|r
.isOnQuest 31190
step
>>|cRXP_WARN_Cast|r |T514302:0|t[Harpoon Cannon] |cRXP_WARN_(1) at|r |cRXP_ENEMY_Jiao|r
>>|cRXP_WARN_Aim at the red circles|r
.complete 31190,4 
.complete 31190,2 
.complete 31190,1 
.complete 31190,3 
step
#completewith next
.exitvehicle >> |cRXP_WARN_Exit the|r |cRXP_FRIENDLY_Mist-Hopper Jr|r
.isOnQuest 31190
step
.goto 422,56.580,75.918
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain "Soggy" Su-Dao|r
.target Captain "Soggy" Su-Dao
.turnin 31190 >>Turn in The Mariner's Revenge
step
.goto 422,56.570,75.825
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deck Boss Arie|r
.accept 31354 >>Accept Mazu's Bounty
.target Deck Boss Arie
step
#label DreadWastesEnd
.goto 422,54.893,72.831
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Angler Ju Lien|r
.target Master Angler Ju Lien
.turnin 31354 >>Turn in Mazu's Bounty
.accept 32030 >>Accept Once in a Hundred Lifetimes
step
.isOnQuest 32030
.hs >> Hearth to Klaxxi'vess
.cooldown item,6948,>2,1
.subzoneskip 6315
.bindlocation 6315,1
step
.noflyable
#optional
.isOnQuest 32030
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Min the Breeze Rider|r
.target Min the Breeze Rider
.goto 422/870,3137.300,-1088.700
.fly Klaxxi'vess >>Fly to Klaxxi'vess
.subzoneskip 6315
step
.goto 422,54.71,34.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Klaxxi'va Ik|r
.turnin 32030 >>Turn in Once in a Hundred Lifetimes
.accept 31782 >>Accept Overthrone
.target Klaxxi'va Ik
step
>>|cRXP_WARN_You can cancel the cutscene|r
.complete 31782,1 
step
.goto 422,55.11,34.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Klaxxi'va Vor|r
.turnin 31782 >>Turn in Overthrone
.target Klaxxi'va Vor
step
.xp 90 >> Grind to 90
>>|cRXP_WARN_Queue for dungeons using the Group Finder tool and complete the quests inside|r
step
#label pt2end
+Congratulations on finishing the RestedXP 85-90 leveling guide! Thank you for using RestedXP.
.link https://support.restedxp.com/report-bug >> As this was tested on Beta, the guide may have had some bugs. If you encountered any while playing through, report them here! |cRXP_WARN_CLICK HERE|r
]])

RXPGuides.RegisterGuide([[#mop
#internal
#group RXP-Pandaria
#subgroup Isle of Thunder
#name isle of thunder campaign
#next isle of thunder daily choice
#displayname |cRXP_FRIENDLY_0|r - Isle of Thunder Campaign
step
#completewith TheStormGathers
.zone 388 >> Travel to Townlong Steppes
step << Horde
#optional
.isOnQuest 32678
.goto 388/870,4162.400,1748.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.turnin 32678 >>Turn in Thunder Calls
.accept 32680 >>Accept The Storm Gathers
step << Horde
#label TheStormGathers
.goto 388/870,4162.400,1748.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.accept 32680 >>Accept The Storm Gathers
step << Horde
.goto 388/870,4162.400,1748.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r to travel to the Isle of Thunder
.complete 32680,1 
.skipgossip
.target Scout Captain Elsia
step << Alliance
#optional
.isOnQuest 32679
.goto 388/870,4211.200,1914.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
.turnin 32679 >>Turn in Thunder Calls
.accept 32681 >>Accept The Storm Gathers
step << Alliance
#label TheStormGathers
.goto 388/870,4211.200,1914.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
.accept 32681 >>Accept The Storm Gathers
step << Alliance
.goto 388/870,4211.200,1914.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r to travel to the Isle of Thunder
.complete 32681,1 
.skipgossip
.target Vereesa Windrunner
step
>>|cRXP_WARN_Wait out the RP|r
.complete 32680,2 << Horde
.complete 32681,2 << Alliance
step << Horde
.goto 504,28.363986,52.412514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
>>|cRXP_WARN_If you cannot accept The Assault on Zeb'tula, you must wait until Stage 2 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lor'themar Theron
.turnin 32680 >>Turn in The Storm Gathers
.accept 32709 >>Accept Allies in the Shadows
.accept 32212 >>Accept The Assault on Zeb'tula
step << Horde
.goto 504,28.363986,52.412514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.complete 32212,1 
.target Lor'themar Theron
.skipgossip
step << Horde
.isOnQuest 32212
.zone 516 >> |cRXP_WARN_Accept the Assault on Zeb'tula queue in a brief moment|r
step << Horde
.isOnQuest 32212
.goto 516,28.503,52.365
.vehicle >> |cRXP_WARN_Mount the|r |cRXP_FRIENDLY_Sunreaver Bloodhawk|r
.timer 73,Flight to Diremoor
.target Sunreaver Bloodhawk
step << Horde
.isOnQuest 32212
.goto 516,42.687,50.499,5 >> |cRXP_WARN_Wait out the RP|r
step << Horde
.goto 516,41.765,49.343,25,0
.goto 516,39.85,47.93,25,0
.goto 516,38.93,43.49,25,0
.goto 516,38.726,38.509,25,0
.goto 516,35.169,38.269,25,0
.goto 516,32.718,35.270
>>|cRXP_WARN_Follow |cRXP_FRIENDLY_Scout Captain Elsia|r through the Scenario|r
>>Kill the attacking |cRXP_ENEMY_Zeb'tula|r
>>Kill the |cRXP_ENEMY_Zeb'tula Stoneshields|r and take down the |cRXP_ENEMY_Zandalari Barricade|r
>>Kill |cRXP_ENEMY_Kresh the Ripper|r
>>Kill |cRXP_ENEMY_Arcanital Tula'chek|r
.complete 32212,2 
.timer 40,The Assault on Zeb'tula RP
.target Scout Captain Elsia
.mob Arcanital Tula'chek
step << Horde
.goto 504,32.511086,35.578047
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
>>|cRXP_WARN_If you cannot accept Tear Down This Wall!, you must wait until Stage 3 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lor'themar Theron
.turnin 32212 >>Turn in The Assault on Zeb'tula
.accept 32276 >>Accept Tear Down This Wall!
step << Horde
.goto 504,32.511086,35.578047
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r to begin the mission
.complete 32276,1 
.skipgossip
.target Lor'themar Theron
step << Horde
.isOnQuest 32276
.subzone 6576 >> |cRXP_WARN_Accept the Tear Down This Wall! queue in a brief moment|r
.subzoneskip 6686
step << Horde
.isOnQuest 32276
.goto 516,48.407,50.994
.cast 3365 >> Loot the |cRXP_PICK_Heavy Explosives|r on the ground
.target Heavy Explosives
step << Horde
.isOnQuest 32276
.goto 516,55.813,57.742
.gossipoption 130692 >> Talk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
step << Horde
.isOnQuest 32276
.goto 516,56.277,56.064
.cast 137541,137490,137469,137472,137473 >> Click the |cRXP_PICK_Heavy Explosives|r
.target Heavy Explosives
step << Horde
.goto 516,56.489,54.067,25,0
.goto 516,53.76,47.63,25,0
.goto 516,54.735,45.823
>>Kill |cRXP_ENEMY_War-God Al'chukla|r
.complete 32276,2 
.mob War-God Al'chukla
step << Horde
.isOnQuest 32276
.goto 516,54.095,46.252
.zone 504 >> Go through the |cRXP_PICK_Portal to the Isle of Thunder|r
step << Horde
.goto 504,32.511086,35.581675
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
>>|cRXP_WARN_If you cannot accept To the Skies!, you must wait until Stage 4 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lor'themar Theron
.turnin 32276 >>Turn in Tear Down This Wall!
.accept 32277 >>Accept To the Skies!
step << Horde
.goto 504,32.511086,35.581675
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r to begin the mission
.complete 32277,1 
.skipgossip
.target Lor'themar Theron
step << Horde
.isOnQuest 32277
.zone 516 >> |cRXP_WARN_Accept the To the Skies! queue in a brief moment|r
step << Horde
.isOnQuest 32277
.goto 516,32.219,34.324
.vehicle >> |cRXP_WARN_Mount|r |cRXP_FRIENDLY_Thunderwing|r
.timer 50,Thunderwing flight
.target Thunderwing
step << Horde
.isOnQuest 32277
.goto 516,49.309,25.994,5 >>You will soon be intercepted by |cRXP_ENEMY_Zandalari Beastcallers|r
>>|cRXP_WARN_Cast|r |T463836:0|t[Jump!] |cRXP_WARN_to land on their|r |cRXP_ENEMY_Pterrorwings|r
>>Kill the |cRXP_ENEMY_Zandalari Beastcallers|r
.mob Zandalari Beastcaller
step << Horde
.isOnQuest 32277
.goto 516,47.972,25.586,15,0
.goto 516,49.309,25.994
.gossipoption 130699 >> Kill |cRXP_ENEMY_Beastmaster Horaki|r, then talk to |cRXP_FRIENDLY_Taoshi|r
.mob Beastmaster Horaki
.target Taoshi
step << Horde
.isOnQuest 32277
.goto 517,41.34,30.25,20,0
.goto 517,47.19,50.99,15,0
.goto 517,28.169,67.394
>>Kill |cRXP_ENEMY_Slavemaster Shiaxu|r in the Lightning Vein Mine
.complete 32277,2 
.mob Slavemaster Shiaxu
step << Horde
.isOnQuest 32277
.goto 517,31.442,77.826
.zone 504 >> Go through the |cRXP_PICK_Portal to the Isle of Thunder|r
step << Horde
.goto 504,32.511086,35.581675
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32277 >>Turn in To the Skies!
step << Horde
.goto 504,32.890733,32.671925
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r
>>|cRXP_WARN_If you cannot accept Decisive Action, you must wait until Stage 5 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Taoshi
.accept 32278 >>Accept Decisive Action
step << Horde
.isOnQuest 32278
.goto 504,32.890733,32.671925
.gossipoption 130724 >> Talk to |cRXP_FRIENDLY_Taoshi|r to begin the mission
.skipgossip
.target Taoshi
step << Horde
.isOnQuest 32278
.zone 516 >> |cRXP_WARN_Accept the Stormsea Landing queue in a brief moment|r
step << Horde
.isOnQuest 32278
.goto 516,63.293,54.364
.vehicle >> |cRXP_WARN_Mount|r |cRXP_FRIENDLY_Thunderwing|r
.timer 22,Thunderwing flight
.target Thunderwing
step << Horde
.isOnQuest 32278
.goto 516,68.993,45.000,3 >>|cRXP_WARN_Cast|r |T458733:0|t[Smoke Bomb] (1) |cRXP_WARN_on the |cRXP_ENEMY_Sentry Totems|r below|r
>>|cRXP_WARN_NOTE: Try to use them on the |cRXP_ENEMY_Sentry Totems|r on the grassy area near the broken wall to the west, as this will become helpful in a later stage|r
.mob Sentry Totem
step << Horde
.isOnQuest 32278
.goto 516,68.462,45.237,5,0
.goto 516,68.174,44.791,5,0
.goto 516,67.939,44.913,5,0
.goto 516,67.721,45.461,5,0
.goto 516,67.526,45.521,5,0
.goto 516,67.188,46.245,5,0
.goto 516,66.852,46.456,5,0
.goto 516,67.327,46.661,5,0
.goto 516,67.542,47.535,5,0
.goto 516,68.221,46.377,5,0
.goto 516,68.587,45.633,4,0
.goto 516,66.974,47.544,10,0
.goto 516,67.282,45.474,10 >>Follow |cRXP_FRIENDLY_Taoshi|r closely on the ship
>>|cRXP_WARN_Cast|r |T132310:0|t[Knock Out] |cRXP_WARN_on |cRXP_ENEMY_Veteran Wingriders|r with the|r |T132295:0|t[Mark of Tasoshi] |cRXP_WARN_debuff|r
>>Kill |cRXP_ENEMY_Captain Halu'kal|r on the lower deck
.target Taoshi
.mob Captain Halu'kal
step << Horde
.goto 516,66.653,43.721,15,0
.goto 516,59.039,43.758,35,0
.goto 516,58.372,42.778
>>|cRXP_WARN_Sneak up to |cRXP_ENEMY_Hu'seng the Gatekeeper|r while avoiding the |cRXP_ENEMY_Sentry Totems|r. You can step into the circles but only for a couple seconds as you go passed them|r
>>Kill |cRXP_ENEMY_Hu'seng the Gatekeeper|r. Loot him for the |cRXP_LOOT_Gatekeeper's Orb|r, then click the |cRXP_PICK_Deactivated Access Generator|r
.complete 32278,1 
.mob Hu'seng the Gatekeeper
step << Horde
.isOnQuest 32278
.goto 516,57.790,41.876
.zone 504 >> Go through the |cRXP_PICK_Portal to Dawnseeker Promontory|r
step << Horde
.goto 504,32.511086,35.578047
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
>>|cRXP_WARN_If you cannot accept The Fall of Shan Bu, you must wait until Stage 6 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lor'themar Theron
.turnin 32278 >>Turn in Decisive Action
.accept 32279 >>Accept The Fall of Shan Bu
step << Horde
.goto 504,32.511086,35.578047
.gossipoption 130674 >> Talk to |cRXP_FRIENDLY_Lor'themar Theron|r to begin the mission
.target Lor'themar Theron
.skipgossip
step << Horde
.isOnQuest 32279
.zone 516 >> |cRXP_WARN_Accept the The Fall of Shan Bu queue in a brief moment|r
step << Horde
.isOnQuest 32279
.goto 516,56.071,39.207
.gossipoption 130702 >> Talk to |cRXP_FRIENDLY_Scout Captain Elsia|r to begin the assault
.skipgossip
.target Scout Captain Elsia
step << Horde
.goto 516,57.19,40.60,25,0
.goto 516,58.691,39.758,20,0
.goto 516,59.931,37.899
>>Follow |cRXP_FRIENDLY_Scout Captain Elsia|r
>>Kill the |cRXP_ENEMY_Zandalari|r, |cRXP_ENEMY_Mogu|r and |cRXP_ENEMY_Shan Bu|r
.complete 32279,2 
.target Scout Captain Elsia
.mob Shan Bu
step << Horde
.isOnQuest 32279
.goto 516,56.824,40.443
.zone 504 >> Go through the |cRXP_PICK_Portal to the Isle of Thunder|r
step << Horde
.goto 504,32.511086,35.578047
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32279 >>Turn in The Fall of Shan Bu
step << Alliance
.goto 504,34.605190,89.448342
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
>>|cRXP_WARN_If you cannot accept The Assault on Shaol'mara, you must wait until Stage 2 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lady Jaina Proudmoore
.turnin 32681 >>Turn in The Storm Gathers
.accept 32706 >>Accept Allies in the Shadows
.accept 32644 >>Accept The Assault on Shaol'mara
step << Alliance
.goto 504,34.605190,89.448342
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r to begin the assault on Shaol'mara
.complete 32644,1 
.skipgossip
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32644
.zone 516 >> |cRXP_WARN_Accept the Assault on Shaol'mara queue in a brief moment|r
step << Alliance
.isOnQuest 32644
.goto 516,35.040,89.843
.vehicle >> |cRXP_WARN_Mount the|r |cRXP_FRIENDLY_Silver Covenant Hippogryph|r
.timer 70,Flight to Diremoor
.target Silver Covenant Hippogryph
step << Alliance
.isOnQuest 32644
.goto 516,52.431,59.246,5 >> |cRXP_WARN_Wait out the RP|r
step << Alliance
.goto 516,53.529,59.676,15,0
.goto 516,57.991,65.877,15,0
.goto 516,59.942,68.715,20,0
.goto 516,58.988,71.197,25,0
.goto 516,61.239,73.064,25,0
.goto 516,64.377,73.010
>>|cRXP_WARN_Follow |cRXP_FRIENDLY_Vereesa Windrunner|r through the Scenario|r
>>Kill the attacking |cRXP_ENEMY_Shaol'mara Raptors|r
>>Kill the |cRXP_ENEMY_Shaol'mara Stoneshields|r and take down the |cRXP_ENEMY_Zandalari Barricade|r
>>Kill |cRXP_ENEMY_Anki|r and |cRXP_ENEMY_Beastcaller Pakutesh|r
>>Travel up the set of two large stairs, killing the |cRXP_ENEMY_Shaol'mara|r along the way
>>Kill |cRXP_ENEMY_Arcanital Mara'kah|r
.complete 32644,2 
.timer 40,The Assault on Shaol'mara RP
.target Vereesa Windrunner
.mob Arcanital Mara'kah
step << Alliance
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
>>|cRXP_WARN_If you cannot accept Tear Down This Wall!, you must wait until Stage 3 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lady Jaina Proudmoore
.turnin 32644 >>Turn in The Assault on Shaol'mara
.accept 32654 >>Accept Tear Down This Wall!
step << Alliance
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r to begin the mission
.complete 32654,1 
.skipgossip
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32654
.subzone 6576 >> |cRXP_WARN_Accept the Tear Down This Wall! queue in a brief moment|r
.subzoneskip 6686
step << Alliance
.isOnQuest 32654
.goto 516,48.412,50.862
.cast 3365 >> Loot the |cRXP_PICK_Heavy Explosives|r on the ground
.target Heavy Explosives
step << Alliance
.isOnQuest 32654
.goto 516,55.813,57.742
.gossipoption 130691 >> Talk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
step << Alliance
.isOnQuest 32654
.goto 516,56.277,56.064
.cast 137541,137490,137469,137472,137473 >> Click the |cRXP_PICK_Heavy Explosives|r
.target Heavy Explosives
step << Alliance
.goto 516,56.489,54.067,25,0
.goto 516,53.76,47.63,25,0
.goto 516,54.735,45.823
>>Kill |cRXP_ENEMY_War-God Al'chukla|r
.complete 32654,2 
.mob War-God Al'chukla
step << Alliance
.isOnQuest 32654
.goto 516,54.095,46.252
.subzone 6583 >> Go through the |cRXP_PICK_Portal to the Isle of Thunder|r
step << Alliance
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
>>|cRXP_WARN_If you cannot accept To the Skies!, you must wait until Stage 4 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lady Jaina Proudmoore
.turnin 32654 >>Turn in Tear Down This Wall!
.accept 32652 >>Accept To the Skies!
step << Alliance
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r to begin the mission
.complete 32652,1 
.skipgossip
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32652
.zone 516 >> |cRXP_WARN_Accept the To the Skies! queue in a brief moment|r
step << Alliance
.isOnQuest 32652
.goto 516,63.321,74.259
.vehicle >> |cRXP_WARN_Mount|r |cRXP_FRIENDLY_Thunderwing|r
.timer 70,Thunderwing flight
.target Thunderwing
step << Alliance
.isOnQuest 32652
.goto 516,49.309,25.994,5 >>You will soon be intercepted by |cRXP_ENEMY_Zandalari Beastcallers|r
>>|cRXP_WARN_Cast|r |T463836:0|t[Jump!] |cRXP_WARN_to land on their|r |cRXP_ENEMY_Pterrorwings|r
>>Kill the |cRXP_ENEMY_Zandalari Beastcallers|r
.mob Zandalari Beastcaller
step << Alliance
.isOnQuest 32652
.goto 516,47.972,25.586,15,0
.goto 516,49.309,25.994
.gossipoption 130699 >> Kill |cRXP_ENEMY_Beastmaster Horaki|r, then talk to |cRXP_FRIENDLY_Taoshi|r
.mob Beastmaster Horaki
.target Taoshi
step << Alliance
.isOnQuest 32652
.goto 517,41.34,30.25,20,0
.goto 517,47.19,50.99,15,0
.goto 517,28.169,67.394
>>Kill |cRXP_ENEMY_Slavemaster Shiaxu|r in the Lightning Vein Mine
.complete 32652,2 
.mob Slavemaster Shiaxu
step << Alliance
.isOnQuest 32652
.goto 517,31.442,77.826
.subzone 6583 >> Go through the |cRXP_PICK_Portal to the Isle of Thunder|r
step << Alliance
.goto 504,63.243152,72.229294
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.turnin 32652 >>Turn in To the Skies!
step << Alliance
.goto 504,63.199626,73.905485
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r
>>|cRXP_WARN_If you cannot accept A Bold Idea, you must wait until Stage 5 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Taoshi
.accept 32655 >>Accept A Bold Idea
step << Alliance
.isOnQuest 32655
.goto 504,63.199626,73.905485
.gossipoption 130724 >> Talk to |cRXP_FRIENDLY_Taoshi|r to begin the mission
.skipgossip
.target Taoshi
step << Alliance
.isOnQuest 32655
.zone 516 >> |cRXP_WARN_Accept the Stormsea Landing queue in a brief moment|r
step << Alliance
.isOnQuest 32655
.goto 516,63.293,54.364
.vehicle >> |cRXP_WARN_Mount|r |cRXP_FRIENDLY_Thunderwing|r
.timer 22,Thunderwing flight
.target Thunderwing
step << Alliance
.isOnQuest 32655
.goto 516,68.993,45.000,3 >>|cRXP_WARN_Cast|r |T458733:0|t[Smoke Bomb] (1) |cRXP_WARN_on the |cRXP_ENEMY_Sentry Totems|r below|r
>>|cRXP_WARN_NOTE: Try to use them on the |cRXP_ENEMY_Sentry Totems|r on the grassy area near the broken wall to the west, as this will become helpful in a later stage|r
.mob Sentry Totem
step << Alliance
.isOnQuest 32655
.goto 516,68.462,45.237,5,0
.goto 516,68.174,44.791,5,0
.goto 516,67.939,44.913,5,0
.goto 516,67.721,45.461,5,0
.goto 516,67.526,45.521,5,0
.goto 516,67.188,46.245,5,0
.goto 516,66.852,46.456,5,0
.goto 516,67.327,46.661,5,0
.goto 516,67.542,47.535,5,0
.goto 516,68.221,46.377,5,0
.goto 516,68.587,45.633,4,0
.goto 516,66.974,47.544,10,0
.goto 516,67.282,45.474,10 >>Follow |cRXP_FRIENDLY_Taoshi|r closely on the ship
>>|cRXP_WARN_Cast|r |T132310:0|t[Knock Out] |cRXP_WARN_on |cRXP_ENEMY_Veteran Wingriders|r with the|r |T132295:0|t[Mark of Tasoshi] |cRXP_WARN_debuff|r
>>Kill |cRXP_ENEMY_Captain Halu'kal|r on the lower deck
.target Taoshi
.mob Captain Halu'kal
step << Alliance
.goto 516,66.653,43.721,15,0
.goto 516,59.039,43.758,35,0
.goto 516,58.372,42.778
>>|cRXP_WARN_Sneak up to |cRXP_ENEMY_Hu'seng the Gatekeeper|r while avoiding the |cRXP_ENEMY_Sentry Totems|r. You can step into the circles but only for a couple seconds as you go passed them|r
>>Kill |cRXP_ENEMY_Hu'seng the Gatekeeper|r. Loot him for the |cRXP_LOOT_Gatekeeper's Orb|r, then click the |cRXP_PICK_Deactivated Access Generator|r
.complete 32655,1 
.mob Hu'seng the Gatekeeper
step << Alliance
.isOnQuest 32655
.goto 516,57.790,41.876
.subzone 6583 >> Go through the |cRXP_PICK_Portal to Violet Rise|r
step << Alliance
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
>>|cRXP_WARN_If you cannot accept The Fall of Shan Bu, you must wait until Stage 6 begins|r
>>|cRXP_WARN_Manually select the|r "|cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection" |cRXP_WARN_guide to begin completing daily quests|r
.target Lady Jaina Proudmoore
.turnin 32655 >>Turn in A Bold Idea
.accept 32656 >>Accept The Fall of Shan Bu
step << Alliance
.goto 504,63.243152,72.225666
.gossipoption 130694 >> Talk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r to begin the mission
.target Lady Jaina Proudmoore
.skipgossip
step << Alliance
.isOnQuest 32656
.zone 516 >> |cRXP_WARN_Accept the The Fall of Shan Bu queue in a brief moment|r
step << Alliance
.isOnQuest 32656
.goto 516,58.985,43.773
.gossipoption 130721 >> Talk to |cRXP_FRIENDLY_Vereesa Windrunner|r to begin the assault
.skipgossip
.target Vereesa Windrunner
step << Alliance
.goto 516,58.319,42.709,25,0
.goto 516,58.691,39.758,20,0
.goto 516,59.931,37.899
>>Follow |cRXP_FRIENDLY_Vereesa Windrunner|r
>>Kill the |cRXP_ENEMY_Zandalari|r, |cRXP_ENEMY_Mogu|r and |cRXP_ENEMY_Shan Bu|r
.complete 32656,2 
.target Vereesa Windrunner
.mob Shan Bu
step << Alliance
.isOnQuest 32656
.goto 516,58.239,42.564
.subzone 6583 >> Go through the |cRXP_PICK_Portal to the Isle of Thunder|r
step << Alliance
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.turnin 32656 >>Turn in The Fall of Shan Bu
step
#completewith next
.goto 504,50.581802,47.739498,55 >> Travel toward |cRXP_FRIENDLY_Taran Zhu|r in the Bleak Hollow
.target Taran Zhu
.subzoneskip 6672
.subzoneskip 6586
step
.goto 504,51.420895,46.088705
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r
.target Taran Zhu
.turnin 32709 >>Turn in Allies in the Shadows << Horde
.turnin 32706 >>Turn in Allies in the Shadows << Alliance
.accept 32707 >>Accept Secrets in the Isle of Thunder
step
.cast 140295,140300 >>|cRXP_WARN_NOTE: This quest can take a VERY long time to complete (|cFFFF0000many hours/days|r). You have now completed the main storyline for the Isle of Thunder, and can continue completing all other activities on the Isle|r
>>To collect |T134891:0|t[|cFF0070FFShan'ze Ritual Stones|r], keep a lookout for |cRXP_ENEMY_Rare|r mobs on the Isle of Thunder, and |cRXP_PICK_Troves of the Thunder King|r (chests which can only be looted once per week)
>>|cRXP_WARN_If you wish to skip this step for now, use the|r |T801132:0|t[Kirin Tor Beacon] |cRXP_WARN_to teleport to the Violet Rise|r << Alliance
>>|cRXP_WARN_If you wish to skip this step for now, use the|r |T838819:0|t[Sunreaver Beacon] |cRXP_WARN_to teleport to the Dawnseeker's Promontory|r << Horde
.complete 32707,1 
.disablecheckbox
.itemcount 94221,<3 
.use 95567 << Alliance
.use 95568 << Horde
.subzoneskip 6583 
.subzoneskip 6690 
.subzoneskip 6584 
.subzoneskip 6674 
.subzoneskip 6691 
step
#completewith next
.goto 504,50.581802,47.739498,55 >> Return to |cRXP_FRIENDLY_Taran Zhu|r in the Bleak Hollow
.target Taran Zhu
.subzoneskip 6672
.subzoneskip 6586
step
.isQuestComplete 32707
.goto 504,51.420895,46.092333
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r
.target Taran Zhu
.turnin 32707 >>Turn in Secrets in the Isle of Thunder
.accept 32708 >>Accept Setting the Trap
step
.isQuestTurnedIn 32707
.goto 504,51.420895,46.092333
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r
.target Taran Zhu
.accept 32708 >>Accept Setting the Trap
step
.isOnQuest 32708
.goto 504,55.178675,87.721358
>>|cRXP_WARN_It is recommended to complete with with a Tank, Healer and three DPS. Ensure you are NOT in a raid group otherwise you will not receive credit!|r
>>Click the |cRXP_PICK_Spirit Ritual Stone|r to summon the |cRXP_ENEMY_Echo of Kros|r
>>Kill the |cRXP_ENEMY_Echo of Kros|r. Kill the |cRXP_ENEMY_Skumblade Ritualist|r that spawns quickly, otherwise he will eat it and gain HP
.complete 32708,1 
.complete 32708,2 
.mob Echo of Kros
step
#completewith next
.goto 504,50.581802,47.739498,55 >> Return to |cRXP_FRIENDLY_Taran Zhu|r in the Bleak Hollow
.target Taran Zhu
.subzoneskip 6672
.subzoneskip 6586
step
.isQuestComplete 32708
.goto 504,51.420895,46.092333
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r
.target Taran Zhu
.turnin 32708 >>Turn in Setting the Trap
.accept 32641 >>Accept Champions of the Thunder King
step
.isQuestTurnedIn 32708
.goto 504,51.420895,46.092333
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r
.target Taran Zhu
.accept 32641 >>Accept Champions of the Thunder King
step
.isOnQuest 32641
>>|cRXP_WARN_It is recommended to complete with with a Tank, Healer and three DPS. Ensure you are NOT in a raid group otherwise you will not receive credit!|r
>>|cRXP_WARN_Three|r |T134891:0|t[|cFF0070FFShan'ze Ritual Stones|r] |cRXP_WARN_are required to summon each |cRXP_ENEMY_Champion|r. Try to find other players who are also capable of summoning|r
>>Summon and kill the |cRXP_ENEMY_Champions|r at the locations marked on your map
.complete 32641,1 
.goto 504,55.178675,87.721358
.complete 32641,2 
.goto 504,53.111170,47.046528
.complete 32641,3 
.goto 504,33.185745,45.591652 << Horde
.goto 504,57.848295,79.217049 << Alliance
step
#completewith next
.goto 504,50.581802,47.739498,55 >> Return to |cRXP_FRIENDLY_Taran Zhu|r in the Bleak Hollow
.target Taran Zhu
.subzoneskip 6672
.subzoneskip 6586
step
.isQuestComplete 32641
.goto 504,51.420895,46.092333
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taran Zhu|r
.target Taran Zhu
.turnin 32641 >>Turn in Champions of the Thunder King
]])

RXPGuides.RegisterGuide([[#mop
#internal
#group RXP-Pandaria
#subgroup Isle of Thunder
#name isle of thunder daily choice
#displayname |cRXP_FRIENDLY_1.0|r - Isle of Thunder Daily Selection
step
.goto 388/870,4169.900,1747.600 << Horde
.goto 388/870,4222.000,1928.900 << Alliance
.zone 504 >> Take the teleporter from Townlong Steppes to the Isle of Thunder
step
#completewith next
.goto 504,63.245570,72.203897 << Alliance
.goto 504,32.445796,35.229748 << Horde
+Click the |cRXP_PICK_Assignment Map|r and select an option for which type of daily quests you wish to complete: PvE or PvP
>>|cRXP_WARN_Note: The PvP option will still consist of all PvE type daily quests. You can view the reward differences when making your selection|r
>>|cRXP_WARN_Once you have made your choice, click the step below to switch to that guide: PvE Daily Quests or PvP Daily Quests|r
>>|cRXP_WARN_During Stage 1 the daily quests are given from your faction's main ship off the coast of the island|r
step << Alliance
+|cRXP_WARN_Click the text below to begin the guide based on the selection you made|r
.clicknext RXP MoP Reputation Guide\isle of thunder daily pve quests-a >>PvE Daily Quests
>>|cRXP_WARN_OR|r
.clicknext RXP MoP Reputation Guide\isle of thunder daily pvp quests-a >>PvP Daily Quests
step << Horde
+|cRXP_WARN_Click the text below to begin the guide based on the selection you made|r
.clicknext RXP MoP Reputation Guide\isle of thunder daily pve quests-h >>PvE Daily Quests
>>|cRXP_WARN_OR|r
.clicknext RXP MoP Reputation Guide\isle of thunder daily pvp quests-h >>PvP Daily Quests
]])

RXPGuides.RegisterGuide([[#mop
#internal
#group RXP-Pandaria
#subgroup Isle of Thunder
#name isle of thunder daily pve quests
#displayname |cRXP_FRIENDLY_1.1|r - Isle of Thunder Daily PvE Quests
step << Alliance
#optional
.convertquest 32677,32608
.convertquest 32676,32607
step << Horde
#loop
.goto 504,32.426451,35.222491,5,0
.goto 504,32.445796,35.229748,5,0
.goto 504,32.513504,35.574419,5,0
.goto 504,33.519448,35.149929,5,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Hathorel|r, |cRXP_FRIENDLY_Girana the Blooded|r,|cRXP_FRIENDLY_Lor'themar Theron|r and |cRXP_FRIENDLY_High Arcanist Savor|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32730,32506,32728,32230,32228,32729,32287,32285 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32730,32506,32728,32230,32228,32729,32287,32285 
.target Girana the Blooded
.target Magister Hathorel
.target Lor'themar Theron
.target High Arcanist Savor
step << Alliance
#loop
.goto 504,63.255243,72.127707,5,0
.goto 504,63.243152,72.225666,5,0
.goto 504,63.475293,73.604351,5,0
.goto 504,62.701490,73.560813,5,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r, |cRXP_FRIENDLY_Lady Jaina Proudmoore|r, |cRXP_FRIENDLY_Warmage Yurias|r and |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32574,32575,32731,32733,32571,32572,32573,32732 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32574,32575,32731,32733,32571,32572,32573,32732 
.target Vereesa Windrunner
.target Lady Jaina Proudmoore
.target Warmage Yurias
.target Captain Elleane Wavecrest
step << Alliance
.goto 504,55.611521,74.536777
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Archmage Vargoth|r
.target Image of Archmage Vargoth
.accept 32549 >>Accept Skin of the Saurok
.subzoneskip 6580,1
step << Alliance
.isOnQuest 32732
.goto 504,55.737264,74.406165
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Modera|r
.target Archmage Modera
.dailyturnin 32732 >>Turn in Ihgaluk Crag
step << Alliance
#loop
.goto 504,55.737264,74.402537,3,0
.goto 504,55.892025,74.449702,3,0
.goto 504,55.546231,74.446074,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Modera|r, |cRXP_FRIENDLY_Lyalia|r and |cRXP_FRIENDLY_Sanitation Sorcerer Stephen Litmatch|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32606,32537,32536,32535,32545,32546,32547,32548 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32606,32537,32536,32535,32545,32546,32547,32548 
.target Archmage Modera
.target Lyalia
.target Sanitation Sorcerer Stephen Litmatch
.subzoneskip 6580,1
step << Alliance
.isOnQuest 32549
.goto 504,54.238021,76.920451
>>Kill a |cRXP_ENEMY_Skumblade Saurok|r
.complete 32549,1 
.mob Skumblade Fleshripper
.mob Skumblade Scavenger
.mob Skumblade Filthmonger
step << Alliance
.isOnQuest 32549
>>Click on the quest popup under your minimap to turn in the quest
.turnin 32549 >>Turn in Skin of the Saurok
step << Alliance
.isOnQuest 32254,32536
#sticky
#label Magisters
>>Talk to the |cRXP_FRIENDLY_Magisters|r
>>|cRXP_WARN_Note: They patrol around inside an invisible proximity shield. You can only see them once you approach them|r
.complete 32536,1 << Alliance 
.goto 504,44.154402,83.385757,20,0
.goto 504,45.090220,84.035190,20,0
.goto 504,44.154402,83.385757,20,0
.target +Magister Yalis
.complete 32536,2 << Alliance 
.target +Magister Lyanis
.goto 504,51.471675,85.040179
.complete 32536,3 << Alliance 
.target +Magistrix Sanal
.goto 504,50.828452,73.451970,20,0
.goto 504,51.996411,73.945394,20,0
.goto 504,50.828452,73.451970,20,0
.goto 504,51.996411,73.945394
.skipgossip
step << Alliance
.isOnQuest 32255,32537
#sticky
#label Constructs
>>Click the |cRXP_FRIENDLY_Constructs|r
.complete 32255,1 << Horde 
.complete 32537,1 << Alliance 
.goto 504,44.113293,81.793013,-1
.target +Disabled Sunreaver Construct << Horde
.target +Disabled Silver Covenant Construct << Alliance
.complete 32255,2 << Horde 
.complete 32537,2 << Alliance 
.goto 504,53.539180,91.287798,-1
.target +Buried Sunreaver Construct << Horde
.target +Buried Silver Covenant Construct << Alliance
.complete 32255,3 << Horde 
.complete 32537,3 << Alliance 
.goto 504,49.781400,84.771698
.target +Distressed Sunreaver Construct << Horde
.target +Distressed Silver Covenant Construct << Alliance
.complete 32255,4 << Horde 
.complete 32537,4 << Alliance 
.goto 504,46.589463,71.993467
.target +Malfunctioning Sunreaver Construct << Horde
.target +Malfunctioning Silver Covenant Construct << Alliance
step << Alliance
.isOnQuest 32299,32546
#sticky
#label Filthdispersed
#loop
.waypoint 504,53.522253,79.910020,50,0
.waypoint 504,49.904725,81.274192,50,0
>>Kill |cRXP_ENEMY_Quivering Filth|r
.complete 32299,1 << Horde 
.complete 32546,1 << Alliance 
.mob Quivering Filth
step << Alliance
.isOnQuest 32491,32548
#sticky
#label MeatPile
#loop
.waypoint 504,45.2,77.2,70,0
.waypoint 504,51.6,83.8,70,0
.waypoint 504,51.2,73.8,70,0
>>Kill the |cRXP_ENEMY_Fetid Meat Piles|r
.complete 32491,1 << Horde 
.complete 32548,1 << Alliance 
.mob Fetid Meat Pile
step << Alliance
.isOnQuest 32204,32535
#sticky
#label SkumbladeThreat
#loop
.waypoint 504,46.8,74.6,70,0
.waypoint 504,46.0,78.4,70,0
.waypoint 504,52.0,72.6,70,0
.waypoint 504,54.6,76.0,70,0
.waypoint 504,52.6,83.6,70,0
>>Kill the |cRXP_ENEMY_Skumblades|r
.complete 32204,1 << Horde 
.complete 32535,1 << Alliance 
step << Alliance
.isOnQuest 32605,32606
#sticky
#label SkumbladeWeapon
#loop
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
>>Kill the |cRXP_ENEMY_Skumblades|r
>>|cRXP_WARN_After you kill them, go to their corpse and use|r |T628136:0|t[Plant Mogu Weapon] |cRXP_WARN_Extra Action Button which will appear once you approach it|r
.complete 32606,1 << Alliance 
.complete 32605,1 << Horde 
.mob Skumblade Fleshripper
.mob Skumblade Scavenger
.mob Skumblade Filthmonger
step << Alliance
.isOnQuest 32274,32545
#sticky
#label SkumbladeResident
>>Kill a |cRXP_ENEMY_Skumblade Brute|r, |cRXP_ENEMY_Skumblade Saur-Priest|r and |cRXP_ENEMY_Skumblade Seadragon|r
>>|cRXP_ENEMY_Skumblade Saur-Priests|r |cRXP_WARN_can be found inside the small caves|r
.complete 32545,1 << Alliance 
.complete 32274,1 << Horde 
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
.mob +Skumblade Brute
.complete 32545,2 << Alliance 
.complete 32274,2 << Horde 
.waypoint 504,49.742710,76.931335,15,0
.waypoint 504,50.303717,74.899589,10,0
.mob +Skumblade Saur-Priest
.complete 32545,3 << Alliance 
.complete 32274,3 << Horde 
.waypoint 504,47.750167,87.982582,70,0
.waypoint 504,49.6,90.1,70,0
.waypoint 504,53.5,91.2,70,0
.waypoint 504,55.8,82.7,70,0
.waypoint 504,49.6,90.1,70,0
.waypoint 504,53.5,91.2,70,0
.waypoint 504,55.8,82.7,70,0
.mob +Skumblade Seadragon
step << Alliance
.isOnQuest 32489,32547
#sticky
#label Roachcrushed
#loop
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
>>Run over the |cRXP_ENEMY_Ihgaluk Roaches|r
.complete 32547,1 << Alliance 
.complete 32489,1 << Horde 
.mob Ihgaluk Roach
step << Alliance
#requires SkumbladeWeapon
step << Alliance
#requires SkumbladeResident
step << Alliance
#requires Roachcrushed
step << Alliance
#requires Constructs
step << Alliance
#requires Magisters
step << Alliance
#requires SkumbladeThreat
step << Alliance
#requires Filthdispersed
step << Alliance
#requires MeatPile
step << Alliance
.isOnQuest 32606
.goto 504,55.737264,74.402537
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Modera|r
.dailyturnin 32606 >>Turn in Subtle Encouragement
.target Archmage Modera
step << Alliance
.isOnQuest 32537
.goto 504,55.737264,74.402537
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Modera|r
.dailyturnin 32537 >>Turn in De-Constructed
.target Archmage Modera
step << Alliance
.isOnQuest 32536
.goto 504,55.737264,74.402537
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Modera|r
.dailyturnin 32536 >>Turn in Manipulating the Saurok
.target Archmage Modera
step << Alliance
.isOnQuest 32535
.goto 504,55.737264,74.402537
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Modera|r
.dailyturnin 32535 >>Turn in The Skumblade Threat
.target Archmage Modera
step << Alliance
.isOnQuest 32546
.goto 504,55.546231,74.446074
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanitation Sorcerer Stephen Litmatch|r
.dailyturnin 32546 >>Turn in Just Some Light Clean-Up Work
.target Sanitation Sorcerer Stephen Litmatch
step << Alliance
.isOnQuest 32547
.goto 504,55.546231,74.446074
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanitation Sorcerer Stephen Litmatch|r
.dailyturnin 32547 >>Turn in The Creeping Carpet of Ihgaluk
.target Sanitation Sorcerer Stephen Litmatch
step << Alliance
.isOnQuest 32548
.goto 504,55.546231,74.446074
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanitation Sorcerer Stephen Litmatch|r
.dailyturnin 32548 >>Turn in Left To Rot
.target Sanitation Sorcerer Stephen Litmatch
step << Alliance
.isOnQuest 32545
.goto 504,55.892025,74.449702
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyalia|r
.dailyturnin 32545 >>Turn in The Residents of Ihgaluk
.target Lyalia
step << Alliance
.goto 504,55.737264,74.402537
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Modera|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF SHE IS NOT OFFERING ANY|r
.daily 32606,32537,32536,32535,32545,32546,32547,32548 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32568,32567,32580,32584,32585,32576,32579,32578,32577,32581 
.target Archmage Modera
.isQuestTurnedIn 32732
step << Horde
.isOnQuest 32728
.goto 504,38.476623,51.327707
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.dailyturnin 32728 >>Turn in The Court of Bones
step << Horde
#loop
.goto 504,38.476623,51.327707,3,0
.goto 504,38.464532,51.168070,3,0
.goto 504,38.541912,51.120904,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r, |cRXP_FRIENDLY_Ryshelle Brightlock|r and |cRXP_FRIENDLY_Captain Aerthas Firehawk|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32201,32219,32226,32224,32218,32220,32517,32225,32495 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32201,32219,32226,32224,32218,32220,32517,32225,32495 
.target Grand Magister Rommath
.target Ryshelle Brightlock
.target Captain Aerthas Firehawk
.target Grand Magister Rommath
.isQuestTurnedIn 32728
step << Horde
#completewith next
.isOnQuest 32226,32528
.goto 504,36.331738,59.189838
.subzone 6671 >> Travel down into the Hall of the Exalted
step << Horde
.isOnQuest 32226,32528
.goto 504,36.621914,60.731789,15,0
.goto 504,37.569822,58.787117,15,0
.goto 504,36.793601,56.436097
#sticky
#label GuratheReclaimed
.use 93803 >>|cRXP_WARN_Use the|r |T531009:0|t[Incantation of Gura] |cRXP_WARN_next to the statue to summon|r |cRXP_ENEMY_Gura the Reclaimed|r
>>Kill |cRXP_ENEMY_Gura the Reclaimed|r
.complete 32226,1 << Horde
.complete 32528,1 << Alliance 
.mob Gura the Reclaimed
step << Horde
#sticky
#label GuratheReclaimed1
#requires GuratheReclaimed
.isOnQuest 32226,32528
.goto 504,37.569822,58.787117,20,0
.goto 504,36.621914,60.731789,15,0
.goto 504,36.331738,59.189838,10 >> Exit the Hall of the Exalted
.subzoneskip 6671,1
step << Horde
.isOnQuest 32526,32220
#sticky
#label ScoutsSaved
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Click the |cRXP_PICK_Tormentor's Cages|r with |cRXP_FRIENDLY_Sunreaver Scouts|r or |cRXP_FRIENDLY_Silver Covenant Scouts|r inside
.complete 32526,1 << Alliance 
.complete 32220,1 << Horde 
.target Silver Covenant Scout
.target Sunreaver Scout
step << Horde
.isOnQuest 32533,32219
#sticky
#label GraveGuardians
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Click the |cRXP_PICK_Grave Guardian|r statues. Kill them if they come to life
.complete 32533,1 << Alliance 
.complete 32219,1 << Horde 
.mob Grave Guardian
step << Horde
.isOnQuest 32527,32201
#sticky
#label ShanzeMogu
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Kill |cRXP_ENEMY_Shan'ze Gravekeepers|r, |cRXP_ENEMY_Shan'ze Soulrippers|r and |cRXP_ENEMY_Shan'ze Thundercallers|r
.complete 32527,1 << Alliance 
.complete 32201,1 << Horde 
.mob Shan'ze Gravekeeper
.mob Shan'ze Soulripper
.mob Shan'ze Thundercaller
step << Horde
.isOnQuest 32224,32532
#sticky
#label RisenAncestors
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Kill |cRXP_ENEMY_Risen Ancestors|r
.complete 32532,1 << Alliance 
.complete 32224,1 << Horde 
.mob Risen Ancestor
step << Horde
.isOnQuest 32525,32218
#sticky
#label MummifiedRemains
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
.use 93751 >> |cRXP_WARN_Use the|r |T135432:0|t[Blessed Torch] |cRXP_WARN_on|r |cRXP_PICK_Mummified Remains|r
>>|cRXP_WARN_These can be hard to spot. Make sure you are trying to continously target them|r
.complete 32525,1 << Alliance 
.complete 32218,1 << Horde 
.target Mummified Remains
step << Horde
.isOnQuest 32495,32530
.goto 504,34.987255,48.958546,20,0
.goto 504,34.987255,47.939045
>>Kill |cRXP_ENEMY_Kaida the Bloodletter|r
.complete 32495,1 << Horde 
.complete 32530,1 << Alliance 
.mob Kaida the Bloodletter
step << Horde
.isOnQuest 32517,32531
#completewith next
.goto 504,35.115416,62.429748
.subzone 6714 >> Enter the Hall of the Grand Imperion
step << Horde
.isOnQuest 32517,32531
.goto 504,35.112998,64.951290
>>Kill the |cRXP_ENEMY_Shan'ze Soulrippers|r surrounding the |cRXP_ENEMY_Ancient Stone Conqueror|r
.complete 32517,1 << Horde 
.complete 32531,1 << Alliance 
.mob Shan'ze Soulripper
step << Horde
.isOnQuest 32225,32529
#completewith next
.goto 504,34.007911,59.077367
.subzone 6594 >> Enter the Hall of the Defamed
step << Horde
.isOnQuest 32225,32529
.goto 504,33.945039,60.543126,15,0
.goto 504,32.956023,55.982582
>>Kill the four channeling |cRXP_ENEMY_Shan'ze Thundercallers|r
.complete 32225,1 << Horde 
.complete 32529,1 << Alliance 
.mob Shan'ze Thundercaller
step << Horde
#requires ShanzeMogu
step << Horde
#requires MummifiedRemains
step << Horde
#requires GraveGuardians
step << Horde
#requires ScoutsSaved
step << Horde
#requires GuratheReclaimed1
step << Horde
#requires RisenAncestors
step << Horde
.isOnQuest 32218
.goto 504,38.539494,51.110020
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Aerthas Firehawk|r
.target Captain Aerthas Firehawk
.dailyturnin 32218 >>Turn in Ashes of the Enemy
step << Horde
.isOnQuest 32201
.goto 504,38.474205,51.327707
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.dailyturnin 32201 >>Turn in Grave Circumstances
step << Horde
.isOnQuest 32220
.goto 504,38.476623,51.327707
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.dailyturnin 32220 >>Turn in Soul Surrender
step << Horde
.isOnQuest 32219
.goto 504,38.464532,51.168070
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ryshelle Brightlock|r
.target Ryshelle Brightlock
.dailyturnin 32219 >>Turn in Stone Cold
step << Horde
.isOnQuest 32226
.goto 504,38.464532,51.168070
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ryshelle Brightlock|r
.target Ryshelle Brightlock
.dailyturnin 32226 >>Turn in Into the Crypts
step << Horde
.isOnQuest 32224
.goto 504,38.464532,51.168070
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ryshelle Brightlock|r
.target Ryshelle Brightlock
.dailyturnin 32224 >>Turn in Rise No More!
step << Horde
#loop
.goto 504,38.476623,51.327707,3,0
.goto 504,38.464532,51.168070,3,0
.goto 504,38.541912,51.120904,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r and |cRXP_FRIENDLY_Ryshelle Brightlock|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF THEY ARE NOT OFFERING ANY|r
.daily 32495,32225,32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32495,32225,32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 
.target Grand Magister Rommath
.target Ryshelle Brightlock
.isQuestTurnedIn 32728
step << Horde
.isOnQuest 32495,32530
.goto 504,34.987255,48.958546,20,0
.goto 504,34.987255,47.939045
>>Kill |cRXP_ENEMY_Kaida the Bloodletter|r
.complete 32495,1 << Horde 
.complete 32530,1 << Alliance 
.mob Kaida the Bloodletter
step << Horde
.isOnQuest 32517,32531
#completewith next
.goto 504,35.115416,62.429748
.subzone 6714 >> Enter the Hall of the Grand Imperion
step << Horde
.isOnQuest 32517,32531
.goto 504,35.112998,64.951290
>>Kill the |cRXP_ENEMY_Shan'ze Soulrippers|r surrounding the |cRXP_ENEMY_Ancient Stone Conqueror|r
.complete 32517,1 << Horde 
.complete 32531,1 << Alliance 
.mob Shan'ze Soulripper
step << Horde
.isOnQuest 32225,32529
#completewith next
.goto 504,34.007911,59.077367
.subzone 6594 >> Enter the Hall of the Defamed
step << Horde
.isOnQuest 32225,32529
.goto 504,32.956023,55.982582
>>Kill the four channeling |cRXP_ENEMY_Shan'ze Thundercallers|r
.complete 32225,1 << Horde 
.complete 32529,1 << Alliance 
.mob Shan'ze Thundercaller
step << Horde
.isOnQuest 32517
.goto 504,38.466950,51.171698
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ryshelle Brightlock|r
.target Ryshelle Brightlock
.dailyturnin 32517 >>Turn in The Conquest of Stone
step << Horde
.isOnQuest 32495
.goto 504,38.476623,51.327707
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.dailyturnin 32495 >>Turn in The Bloodletter
step << Horde
.isOnQuest 32225
.goto 504,38.476623,51.327707
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.dailyturnin 32225 >>Turn in The Call of Thunder
step
.isOnQuest 32506,32571
#sticky
#label WildPtrerrorwingHatchling
#loop
.goto 504,54.7,57.4,70,0
.goto 504,45.2,48.7,70,0
.goto 504,41.2,50.1,70,0
.goto 504,53.9,65.2,70,0
.goto 504,46.0,45.0,70,0
.goto 504,49.7,46.4,70,0
.goto 504,45.9,45.0,70,0
>>Look for |cRXP_FRIENDLY_Wild Pterrorwing Hatchlings|r flying in the air. Follow it until it lands, then click on it
.complete 32506,1 << Horde 
.complete 32571,1 << Alliance 
.target Wild Pterrorwing Hatchling
step
.isOnQuest 32230,32575
#sticky
#label ZandalariColossus
#loop
.goto 504,41.608106,59.425666,60,0
.goto 504,45.849514,66.159453,60,0
>>Kill the |cRXP_ENEMY_Zandalari Colossus|r
.complete 32230,1 << Horde 
.complete 32575,1 << Alliance 
.mob Zandalari Colossus
step
.isOnQuest 32228,32574
#sticky
#label MightyDevilsaur
#loop
.goto 504,46.6,48.8,60,0
.goto 504,53.2,58.2,60,0
>>Kill the |cRXP_ENEMY_Mighty Devilsaur|r
.complete 32228,1 << Horde 
.complete 32574,1 << Alliance 
.mob Mighty Devilsaur
step
.isOnQuest 32287,32573
#sticky
#label Diremoormogu
#loop
.goto 504,43.6,54.8,70,0
.goto 504,48.6,54.8,70,0
.goto 504,49.6,62.2,70,0
.goto 504,48.2,52.8,70,0
>>Kill |cRXP_ENEMY_Shan'ze Bloodseekers|r and |cRXP_ENEMY_Shan'ze Animators|r
.complete 32287,1 << Horde 
.complete 32573,1 << Alliance 
.mob Shan'ze Bloodseeker
.mob Shan'ze Animator
step
.isOnQuest 32285,32572
#sticky
#label AnimatedWarrior
#loop
.goto 504,43.6,54.8,70,0
.goto 504,48.6,54.8,70,0
.goto 504,49.6,62.2,70,0
.goto 504,48.2,52.8,70,0
>>Kill |cRXP_ENEMY_Animated Warriors|r
.complete 32285,1 << Horde 
.complete 32572,1 << Alliance 
.mob Animated Warrior
step
#requires ZandalariColossus
step
#requires MightyDevilsaur
step
#requires WildPtrerrorwingHatchling
step
#requires Diremoormogu
step
#requires AnimatedWarrior
step << Horde
.isOnQuest 32729
.goto 504,36.721057,64.780768
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r
.target Halduron Brightwing
.dailyturnin 32729 >>Turn in Za'Tual
step << Horde
#loop
.goto 504,36.721057,64.780768,3,0
.goto 504,36.634005,64.675553,3,0
.goto 504,36.764584,64.907752,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwin|r, |cRXP_FRIENDLY_Elina Zaralae|r and |cRXP_FRIENDLY_Kethiel Sunlance|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32275,32252,32200,32215,32217,32216,32227 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32275,32252,32200,32215,32217,32216,32227 
.target Halduron Brightwing
.target Elina Zaralae
.target Kethiel Sunlance
.isQuestTurnedIn 32729
step << Alliance
.isOnQuest 32733
.goto 504,42.215058,66.333603
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r
.target Archmage Lan'dalock
.dailyturnin 32733 >>Turn in Za'Tual
step << Alliance
#loop
.goto 504,42.215058,66.333603,3,0
.goto 504,42.304529,66.308206,3,0
.goto 504,42.152187,66.442446,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r, |cRXP_FRIENDLY_Dalvin Jaacor|r and |cRXP_FRIENDLY_Ako|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32542,32543,32540,32538,32539,32541,32544 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32542,32543,32540,32538,32539,32541,32544 
.target Archmage Lan'dalock
.target Dalvin Jaacor
.target Ako
.isQuestTurnedIn 32733
step
.isOnQuest 32216,32544
#sticky
#label TormentedSkyscreamer
.goto 504,41.245386,69.889158
>>Kill the |cRXP_ENEMY_Zandalari Arcweavers|r around the |cRXP_FRIENDLY_Tormented Skyscreamer|r
.complete 32216,1 << Horde 
.complete 32544,1 << Alliance 
.mob Tormented Skyscreamer
step
.isOnQuest 32215,32538
#sticky
#label ThreeAltars
>>Click the three |cRXP_PICK_Altars|r
.complete 32215,1 << Horde
.complete 32538,1 << Alliance
.goto 504,33.838641,76.085984,-1
.complete 32215,2 << Horde
.complete 32538,2 << Alliance
.goto 504,39.734052,65.190745,-1
.complete 32215,3 << Horde
.complete 32538,3 << Alliance
.goto 504,38.636220,78.680088,-1
step
.isOnQuest 32252,32540
#sticky
#label LoaHarbingers
.goto 504,36.6,70.0,15,0
.goto 504,33.8,71.2,15,0
.goto 504,33.2,73.6,15,0
.goto 504,39.0,76.2,15,0
>>Kill |cRXP_ENEMY_Zandalari Speakers|r, |cRXP_ENEMY_Zandalari Arcanitals|r or |cRXP_ENEMY_Zandalari Spiritweavers|r
>>|cRXP_WARN_These can be primarily found in the big tents|r
.complete 32252,1 << Horde 
.complete 32540,1 << Alliance 
.mob Zandalari Speaker
.mob Zandalari Arcanital
.mob Zandalari Spiritweaver
step
.isOnQuest 32200,32543
#sticky
#label ZatualTrolls
#loop
.waypoint 504,32.7,70.9,70,0
.waypoint 504,37.5,76.8,70,0
.waypoint 504,36.9,68.1,70,0
>>Kill |cRXP_ENEMY_Trolls|r
.complete 32200,1 << Horde 
.complete 32543,1 << Alliance 
step
.isOnQuest 32217,32539
#sticky
#label ZandalariOfferings
#loop
.waypoint 504,32.7,70.9,70,0
.waypoint 504,37.5,76.8,70,0
.waypoint 504,36.9,68.1,70,0
>>Click the |cRXP_PICK_Zandalari Offerings|r on the ground
.complete 32217,1 << Horde
.complete 32539,1 << Alliance
step
.isOnQuest 32227,32541
#sticky
#label Skyscreamersfrightened
.waypoint 504,32.6,78.8,50,0
.waypoint 504,28.0,75.6,50,0
.waypoint 504,32.2,82.6,50,0
.waypoint 504,31.6,75.2,50,0
>>Run on top of |cRXP_FRIENDLY_Hatchling Skyscreamers|r
.complete 32227,1 << Horde
.complete 32541,1 << Alliance
.target Hatchling Skyscreamer
step
.isOnQuest 32275,32542
#sticky
#label ZandalariSlain
#loop
.waypoint 504,32.7,70.9,70,0
.waypoint 504,37.5,76.8,70,0
.waypoint 504,36.9,68.1,70,0
>>Kill |cRXP_ENEMY_Zandalari Beastcallers|r, |cRXP_ENEMY_Zandalari Jaguar Warriors|r and |cRXP_ENEMY_Zandalari Spiritbinders|r
.complete 32275,1 << Horde 
.complete 32542,1 << Alliance 
.mob +Zandalari Beastcaller
.complete 32275,2 << Horde 
.complete 32542,2 << Alliance 
.mob +Zandalari Jaguar Warrior
.complete 32275,3 << Horde 
.complete 32542,3 << Alliance 
.mob +Zandalari Spiritbinder
step
#requires ZandalariSlain
step
#requires TormentedSkyscreamer
step
#requires LoaHarbingers
step
#requires ZatualTrolls
step
#requires ThreeAltars
step
#requires ZandalariOfferings
step
#requires Skyscreamersfrightened
step << Horde
.isOnQuest 32216
.goto 504,36.767002,64.907752
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kethiel Sunlance|r
.target Kethiel Sunlance
.dailyturnin 32216 >>Turn in Pterrible Ptorment
step << Horde
.isOnQuest 32227
.goto 504,36.767002,64.907752
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kethiel Sunlance|r
.target Kethiel Sunlance
.dailyturnin 32227 >>Turn in Preventing a Future Threat
step << Horde
.isOnQuest 32275
.goto 504,36.721057,64.780768
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r
.target Halduron Brightwing
.dailyturnin 32275 >>Turn in Surgical Death
step << Horde
.isOnQuest 32252
.goto 504,36.721057,64.780768
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r
.target Halduron Brightwing
.dailyturnin 32252 >>Turn in Harbingers of the Loa
step << Horde
.isOnQuest 32200
.goto 504,36.721057,64.780768
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r
.target Halduron Brightwing
.dailyturnin 32200 >>Turn in Dangers of Za'Tual
step << Horde
.isOnQuest 32215
.goto 504,36.634005,64.675553
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elina Zaralae|r
.target Elina Zaralae
.dailyturnin 32215 >>Turn in Heinous Sacrifice
step << Horde
.isOnQuest 32217
.goto 504,36.634005,64.675553
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elina Zaralae|r
.target Elina Zaralae
.dailyturnin 32217 >>Turn in Dark Offerings
step << Horde
#loop
.goto 504,36.723476,64.780768
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Halduron Brightwing|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF HE IS NOT OFFERING ANY|r
.daily 32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 
.target Halduron Brightwing
.isQuestTurnedIn 32729
step << Alliance
.isOnQuest 32542
.goto 504,42.215058,66.333603
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r
.target Archmage Lan'dalock
.dailyturnin 32542 >>Turn in Surgical Strike
step << Alliance
.isOnQuest 32543
.goto 504,42.215058,66.333603
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r
.target Archmage Lan'dalock
.dailyturnin 32543 >>Turn in Dangers of Za'Tual
step << Alliance
.isOnQuest 32540
.goto 504,42.215058,66.333603
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r
.target Archmage Lan'dalock
.dailyturnin 32540 >>Turn in Harbingers of the Loa
step << Alliance
.isOnQuest 32538
.goto 504,42.304529,66.308206
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dalvin Jaacor|r
.target Dalvin Jaacor
.dailyturnin 32538 >>Turn in Heinous Sacrifice
step << Alliance
.isOnQuest 32539
.goto 504,42.304529,66.308206
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dalvin Jaacor|r
.target Dalvin Jaacor
.dailyturnin 32539 >>Turn in Dark Offerings
step << Alliance
.isOnQuest 32541
.goto 504,42.152187,66.442446
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ako|r
.target Ako
.dailyturnin 32541 >>Turn in Preventing a Future Threat
step << Alliance
.isOnQuest 32544
.goto 504,42.152187,66.442446
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ako|r
.target Ako
.dailyturnin 32544 >>Turn in Pterrible Ptorment
step << Alliance
#loop
.goto 504,42.215058,66.333603
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Lan'dalock|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF HE IS NOT OFFERING ANY|r
.daily 32568,32567,32580,32584,32585,32576,32579,32578,32577,32581 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32568,32567,32580,32584,32585,32576,32579,32578,32577,32581 
.target Archmage Lan'dalock
.isQuestTurnedIn 32733
step << Horde
.isOnQuest 32730
.goto 504,46.867548,66.910473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r
.target Archmage Aethas Sunreaver
.dailyturnin 32730 >>Turn in Ihgaluk Crag
step << Horde 
.isQuestTurnedIn 32730
.goto 504,46.920747,66.899589
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magistrix Saia|r
.target Magistrix Saia
.accept 32507 >>Accept Skin of the Saurok
step << Horde
#loop
.goto 504,46.867548,66.910473,3,0
.goto 504,46.724878,66.761721,3,0
.goto 504,47.007800,66.732696,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r, |cRXP_FRIENDLY_Sunwalker Dezco|r and |cRXP_FRIENDLY_Amalia Penshire|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32605,32255,32254,32204,32274,32489,32299,32491 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32605,32255,32254,32204,32274,32489,32299,32491 
.target Archmage Aethas Sunreaver
.target Sunwalker Dezco
.target Amalia Penshire
.isQuestTurnedIn 32730
step << Horde
.isOnQuest 32507
.goto 504,45.864022,71.786664
>>Kill a |cRXP_ENEMY_Skumblade Saurok|r
.complete 32507,1 
.mob Skumblade Fleshripper
.mob Skumblade Scavenger
.mob Skumblade Filthmonger
step << Horde
.isOnQuest 32507
>>Click on the quest popup under your minimap to turn in the quest
.turnin 32507 >>Turn in Skin of the Saurok
step << Horde
.isOnQuest 32254,32536
#sticky
#label Magisters
>>Talk to the |cRXP_FRIENDLY_Magisters|r
>>|cRXP_WARN_Note: They patrol around inside an invisible proximity shield. You can only see them once you approach them|r
.complete 32254,1 << Horde 
.target +Magister Arlan
.goto 504,44.154402,83.385757,20,0
.goto 504,45.090220,84.035190,20,0
.goto 504,44.154402,83.385757,20,0
.goto 504,45.090220,84.035190
.complete 32254,2 << Horde 
.target +Magister Sarien
.goto 504,51.471675,85.040179
.complete 32254,3 << Horde 
.target +Magistrix Vesara
.goto 504,50.828452,73.451970,20,0
.goto 504,51.996411,73.945394,20,0
.goto 504,50.828452,73.451970,20,0
.goto 504,51.996411,73.945394
.skipgossip
step << Horde
.isOnQuest 32255,32537
#sticky
#label Constructs
>>Click the |cRXP_FRIENDLY_Constructs|r
.complete 32255,1 << Horde 
.complete 32537,1 << Alliance 
.goto 504,44.113293,81.793013,-1
.target +Disabled Sunreaver Construct << Horde
.target +Disabled Silver Covenant Construct << Alliance
.complete 32255,2 << Horde 
.complete 32537,2 << Alliance 
.goto 504,53.539180,91.287798,-1
.target +Buried Sunreaver Construct << Horde
.target +Buried Silver Covenant Construct << Alliance
.complete 32255,3 << Horde 
.complete 32537,3 << Alliance 
.goto 504,49.875707,83.955371,-1
.target +Distressed Sunreaver Construct << Horde
.target +Distressed Silver Covenant Construct << Alliance
.complete 32255,4 << Horde 
.complete 32537,4 << Alliance 
.goto 504,46.483065,71.895507,-1
.target +Malfunctioning Sunreaver Construct << Horde
.target +Malfunctioning Silver Covenant Construct << Alliance
step << Horde
.isOnQuest 32299,32546
#sticky
#label Filthdispersed
#loop
.waypoint 504,53.522253,79.910020,50,0
.waypoint 504,49.904725,81.274192,50,0
>>Kill |cRXP_ENEMY_Quivering Filth|r
.complete 32299,1 << Horde 
.complete 32546,1 << Alliance 
.mob Quivering Filth
step << Horde
.isOnQuest 32491,32548
#sticky
#label MeatPile
#loop
.waypoint 504,45.2,77.2,70,0
.waypoint 504,51.6,83.8,70,0
.waypoint 504,51.2,73.8,70,0
>>Kill the |cRXP_ENEMY_Fetid Meat Piles|r
.complete 32491,1 << Horde 
.complete 32548,1 << Alliance 
.mob Fetid Meat Pile
step << Horde
.isOnQuest 32204,32535
#sticky
#label SkumbladeThreat
#loop
.waypoint 504,46.8,74.6,70,0
.waypoint 504,46.0,78.4,70,0
.waypoint 504,52.0,72.6,70,0
.waypoint 504,54.6,76.0,70,0
.waypoint 504,52.6,83.6,70,0
>>Kill the |cRXP_ENEMY_Skumblades|r
.complete 32204,1 << Horde 
.complete 32535,1 << Alliance 
step << Horde
.isOnQuest 32605,32606
#sticky
#label SkumbladeWeapon
#loop
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
>>Kill the |cRXP_ENEMY_Skumblades|r
>>|cRXP_WARN_After you kill them, go to their corpse and use|r |T628136:0|t[Plant Mogu Weapon] |cRXP_WARN_Extra Action Button which will appear once you approach it|r
.complete 32606,1 << Alliance 
.complete 32605,1 << Horde 
.mob Skumblade Fleshripper
.mob Skumblade Scavenger
.mob Skumblade Filthmonger
step << Horde
.isOnQuest 32274,32545
#sticky
#label SkumbladeResident
>>Kill a |cRXP_ENEMY_Skumblade Brute|r, |cRXP_ENEMY_Skumblade Saur-Priest|r and |cRXP_ENEMY_Skumblade Seadragon|r
>>|cRXP_ENEMY_Skumblade Saur-Priests|r |cRXP_WARN_can be found inside the small caves|r
.complete 32545,1 << Alliance 
.complete 32274,1 << Horde 
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
.mob +Skumblade Brute
.complete 32545,2 << Alliance 
.complete 32274,2 << Horde 
.waypoint 504,49.742710,76.931335,15,0
.waypoint 504,50.303717,74.899589,10,0
.mob +Skumblade Saur-Priest
.complete 32545,3 << Alliance 
.complete 32274,3 << Horde 
.waypoint 504,47.750167,87.982582,70,0
.waypoint 504,49.6,90.1,70,0
.waypoint 504,53.5,91.2,70,0
.waypoint 504,55.8,82.7,70,0
.waypoint 504,49.6,90.1,70,0
.waypoint 504,53.5,91.2,70,0
.waypoint 504,55.8,82.7,70,0
.mob +Skumblade Seadragon
step << Horde
.isOnQuest 32489,32547
#sticky
#label Roachcrushed
#loop
.waypoint 504,45.20,73.51,70,0
.waypoint 504,46.47,79.28,70,0
.waypoint 504,44.52,83.17,70,0
.waypoint 504,50.20,83.73,70,0
.waypoint 504,53.95,77.65,70,0
>>Run over the |cRXP_ENEMY_Ihgaluk Roaches|r
.complete 32547,1 << Alliance 
.complete 32489,1 << Horde 
.mob Ihgaluk Roach
step << Horde
#requires SkumbladeWeapon
step << Horde
#requires SkumbladeResident
step << Horde
#requires Roachcrushed
step << Horde
#requires Constructs
step << Horde
#requires Magisters
step << Horde
#requires SkumbladeThreat
step << Horde
#requires Filthdispersed
step << Horde
#requires MeatPile
step << Horde
.isOnQuest 32274
.goto 504,46.724878,66.758092
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sunwalker Dezco|r
.target Sunwalker Dezco
.dailyturnin 32274 >>Turn in The Residents of Ihgaluk
step << Horde
.isOnQuest 32605
.goto 504,46.867548,66.910473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r
.target Archmage Aethas Sunreaver
.dailyturnin 32605 >>Turn in Subtle Encouragement
step << Horde
.isOnQuest 32255
.goto 504,46.867548,66.910473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r
.target Archmage Aethas Sunreaver
.dailyturnin 32255 >>Turn in De-Constructed
step << Horde
.isOnQuest 32254
.goto 504,46.867548,66.910473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r
.target Archmage Aethas Sunreaver
.dailyturnin 32254 >>Turn in Manipulating the Saurok
step << Horde
.isOnQuest 32204
.goto 504,46.867548,66.910473
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r
.target Archmage Aethas Sunreaver
.dailyturnin 32204 >>Turn in The Skumblade Threat
step << Horde
.isOnQuest 32489
.goto 504,47.007800,66.736324
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amalia Penshire|r
.target Amalia Penshire
.dailyturnin 32489 >>Turn in The Creeping Carpet of Ihgaluk
step << Horde
.isOnQuest 32299
.goto 504,47.007800,66.736324
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amalia Penshire|r
.target Amalia Penshire
.dailyturnin 32299 >>Turn in Just Some Light Clean-Up Work
step << Horde
.isOnQuest 32491
.goto 504,47.007800,66.736324
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amalia Penshire|r
.target Amalia Penshire
.dailyturnin 32491 >>Turn in Left To Rot
step << Horde
.goto 504,46.867548,66.910473
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF HE IS NOT OFFERING ANY|r
.daily 32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 
.target Archmage Aethas Sunreaver
.subzoneskip 6576,1
step << Alliance
.isOnQuest 32731
.goto 504,40.186244,59.567163
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narasi Snowdawn|r
.target Narasi Snowdawn
.dailyturnin 32731 >>Turn in The Court of Bones
step << Alliance
#loop
.goto 504,40.099191,59.120904,3,0
.goto 504,40.186244,59.567163,3,0
.goto 504,40.145135,59.291426,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r, |cRXP_FRIENDLY_Narasi Snowdawn|r and |cRXP_FRIENDLY_Danara Silverglass|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32530,32531,32529,32527,32526,32525,32528,32532,32533 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32530,32531,32529,32527,32526,32525,32528,32532,32533 
.target Vylene Amaranth
.target Narasi Snowdawn
.target Danara Silverglass
.isQuestTurnedIn 32731
step << Alliance
#completewith next
.isOnQuest 32226,32528
.goto 504,36.331738,59.189838
.subzone 6671 >> Travel down into the Hall of the Exalted
step << Alliance
.isOnQuest 32226,32528
.goto 504,36.621914,60.731789,15,0
.goto 504,37.569822,58.787117,15,0
.goto 504,36.793601,56.436097
#sticky
#label GuratheReclaimed
.use 93803 >>|cRXP_WARN_Use the|r |T531009:0|t[Incantation of Gura] |cRXP_WARN_next to the statue to summon|r |cRXP_ENEMY_Gura the Reclaimed|r
>>Kill |cRXP_ENEMY_Gura the Reclaimed|r
.complete 32226,1 << Horde
.complete 32528,1 << Alliance 
.mob Gura the Reclaimed
step << Alliance
#sticky
#label GuratheReclaimed1
#requires GuratheReclaimed
.isOnQuest 32226,32528
.goto 504,37.569822,58.787117,20,0
.goto 504,36.621914,60.731789,15,0
.goto 504,36.331738,59.189838,10 >> Exit the Hall of the Exalted
.subzoneskip 6671,1
step << Alliance
.isOnQuest 32526,32220
#sticky
#label ScoutsSaved
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Click the |cRXP_PICK_Tormentor's Cages|r with |cRXP_FRIENDLY_Sunreaver Scouts|r or |cRXP_FRIENDLY_Silver Covenant Scouts|r inside
.complete 32526,1 << Alliance 
.complete 32220,1 << Horde 
.target Silver Covenant Scout
.target Sunreaver Scout
step << Alliance
.isOnQuest 32533,32219
#sticky
#label GraveGuardians
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Click the |cRXP_PICK_Grave Guardian|r statues. Kill them if they come to life
.complete 32533,1 << Alliance 
.complete 32219,1 << Horde 
.mob Grave Guardian
step << Alliance
.isOnQuest 32527,32201
#sticky
#label ShanzeMogu
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Kill |cRXP_ENEMY_Shan'ze Gravekeepers|r, |cRXP_ENEMY_Shan'ze Soulrippers|r and |cRXP_ENEMY_Shan'ze Thundercallers|r
.complete 32527,1 << Alliance 
.complete 32201,1 << Horde 
.mob Shan'ze Gravekeeper
.mob Shan'ze Soulripper
.mob Shan'ze Thundercaller
step << Alliance
.isOnQuest 32224,32532
#sticky
#label RisenAncestors
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
>>Kill |cRXP_ENEMY_Risen Ancestors|r
.complete 32532,1 << Alliance 
.complete 32224,1 << Horde 
.mob Risen Ancestor
step << Alliance
.isOnQuest 32525,32218
#sticky
#label MummifiedRemains
#loop
.waypoint 504,34.9,47.9,50,0
.waypoint 504,34.0,58.4,70,0
.waypoint 504,38.0,58.2,70,0
.waypoint 504,37.6,51.4,70,0
.use 93751 >> |cRXP_WARN_Use the|r |T135432:0|t[Blessed Torch] |cRXP_WARN_on|r |cRXP_PICK_Mummified Remains|r
>>|cRXP_WARN_These can be hard to spot. Make sure you are trying to continously target them|r
.complete 32525,1 << Alliance 
.complete 32218,1 << Horde 
.target Mummified Remains
step << Alliance
.isOnQuest 32495,32530
.goto 504,34.987255,48.958546,20,0
.goto 504,34.987255,47.939045
>>Kill |cRXP_ENEMY_Kaida the Bloodletter|r
.complete 32495,1 << Horde 
.complete 32530,1 << Alliance 
.mob Kaida the Bloodletter
step << Alliance
.isOnQuest 32517,32531
#completewith next
.goto 504,35.115416,62.429748
.subzone 6714 >> Enter the Hall of the Grand Imperion
step << Alliance
.isOnQuest 32517,32531
.goto 504,35.112998,64.951290
>>Kill the |cRXP_ENEMY_Shan'ze Soulrippers|r surrounding the |cRXP_ENEMY_Ancient Stone Conqueror|r
.complete 32517,1 << Horde 
.complete 32531,1 << Alliance 
.mob Shan'ze Soulripper
step << Alliance
.isOnQuest 32225,32529
#completewith next
.goto 504,34.007911,59.077367
.subzone 6594 >> Enter the Hall of the Defamed
step << Alliance
.isOnQuest 32225,32529
.goto 504,33.945039,60.543126,15,0
.goto 504,32.956023,55.982582
>>Kill the four channeling |cRXP_ENEMY_Shan'ze Thundercallers|r
.complete 32225,1 << Horde 
.complete 32529,1 << Alliance 
.mob Shan'ze Thundercaller
step << Alliance
#requires ShanzeMogu
step << Alliance
#requires MummifiedRemains
step << Alliance
#requires GraveGuardians
step << Alliance
#requires ScoutsSaved
step << Alliance
#requires GuratheReclaimed1
step << Alliance
#requires RisenAncestors
step << Alliance
.isOnQuest 32527
.goto 504,40.186244,59.567163
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narasi Snowdawn|r
.target Narasi Snowdawn
.dailyturnin 32527 >>Turn in Grave Circumstances
step << Alliance
.isOnQuest 32526
.goto 504,40.186244,59.567163
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narasi Snowdawn|r
.target Narasi Snowdawn
.dailyturnin 32526 >>Turn in Soul Surrender
step << Alliance
.isOnQuest 32525
.goto 504,40.145135,59.291426
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danara Silverglass|r
.target Danara Silverglass
.dailyturnin 32525 >>Turn in Ashes of the Enemy
step << Alliance
.isOnQuest 32528
.goto 504,40.145135,59.291426
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danara Silverglass|r
.target Danara Silverglass
.dailyturnin 32528 >>Turn in Into the Crypts
step << Alliance
.isOnQuest 32532
.goto 504,40.145135,59.291426
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danara Silverglass|r
.target Danara Silverglass
.dailyturnin 32532 >>Turn in Rise No More!
step << Alliance
.isOnQuest 32533
.goto 504,40.145135,59.291426
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Danara Silverglass|r
.target Danara Silverglass
.dailyturnin 32533 >>Turn in Stone Cold
step << Alliance
.isOnQuest 32531
.goto 504,40.099191,59.120904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r
.target Vylene Amaranth
.dailyturnin 32531 >>Turn in The Conquest of Stone
step << Alliance
.isOnQuest 32530
.goto 504,40.099191,59.120904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r
.target Vylene Amaranth
.dailyturnin 32530 >>Turn in The Bloodletter
step << Alliance
.isOnQuest 32529
.goto 504,40.099191,59.120904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r
.target Vylene Amaranth
.dailyturnin 32529 >>Turn in The Call of Thunder
step << Alliance
.goto 504,40.099191,59.120904
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r
>>|cRXP_WARN_SKIP THIS STEP IF SHE IS NOT OFFERING A DAILY QUEST|r
.daily 32530,32529,32531 >>Accept all available daily quests
.disablecheckbox
.questcount <1,32530,32529,32531
.target Vylene Amaranth
.isQuestTurnedIn 32731
step << Alliance
.isOnQuest 32495,32530
.goto 504,34.987255,48.958546,20,0
.goto 504,34.987255,47.939045
>>Kill |cRXP_ENEMY_Kaida the Bloodletter|r
.complete 32495,1 << Horde 
.complete 32530,1 << Alliance 
.mob Kaida the Bloodletter
step << Alliance
.isOnQuest 32517,32531
#completewith next
.goto 504,35.115416,62.429748
.subzone 6714 >> Enter the Hall of the Grand Imperion
step << Alliance
.isOnQuest 32517,32531
.goto 504,35.112998,64.951290
>>Kill the |cRXP_ENEMY_Shan'ze Soulrippers|r surrounding the |cRXP_ENEMY_Ancient Stone Conqueror|r
.complete 32517,1 << Horde 
.complete 32531,1 << Alliance 
.mob Shan'ze Soulripper
step << Alliance
.isOnQuest 32225,32529
#completewith next
.goto 504,34.007911,59.077367
.subzone 6594 >> Enter the Hall of the Defamed
step << Alliance
.isOnQuest 32225,32529
.goto 504,32.956023,55.982582
>>Kill the four channeling |cRXP_ENEMY_Shan'ze Thundercallers|r
.complete 32225,1 << Horde 
.complete 32529,1 << Alliance 
.mob Shan'ze Thundercaller
step << Alliance
.isOnQuest 32531
.goto 504,40.099191,59.120904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r
.target Vylene Amaranth
.dailyturnin 32531 >>Turn in The Conquest of Stone
step << Alliance
.isOnQuest 32530
.goto 504,40.099191,59.120904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r
.target Vylene Amaranth
.dailyturnin 32530 >>Turn in The Bloodletter
step << Alliance
.isOnQuest 32529
.goto 504,40.099191,59.120904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vylene Amaranth|r
.target Vylene Amaranth
.dailyturnin 32529 >>Turn in The Call of Thunder
step << Alliance
.goto 504,40.186244,59.567163
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Narasi Snowdawn|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF SHE IS NOT OFFERING ANY|r
.daily 32568,32567,32580,32584,32585,32576,32579,32578,32577,32581 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32568,32567,32580,32584,32585,32576,32579,32578,32577,32581
.target Narasi Snowdawn
.isQuestTurnedIn 32731
step
.isOnQuest 32520,32576
.goto 504,44.043167,68.902310
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32520,1 << Horde 
.complete 32576,1 << Alliance 
.mob Arcweaver Jor'guva
step
.isOnQuest 32561,32579
.goto 504,44.043167,68.902310
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32561,1 << Horde 
.complete 32579,1 << Alliance 
.mob Arcweaver Jor'guva
step
.isOnQuest 32564,32583
.goto 504,44.043167,68.902310
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32564,1 << Horde 
.complete 32583,1 << Alliance 
.mob Arcweaver Jor'guva
step
.isOnQuest 32293,32578
.goto 504,41.934555,79.481902
>>Kill |cRXP_ENEMY_Zur'chaka the Bonecrafter|r
.complete 32293,1 << Horde 
.complete 32578,1 << Alliance 
.mob Zur'chaka the Bonecrafter
step
.isOnQuest 32522,32577
.goto 504,45.653645,59.287798
>>Kill |cRXP_ENEMY_Horgak the Enslaver|r
.complete 32522,1 << Horde 
.complete 32577,1 << Alliance 
.mob Horgak the Enslaver
step
.isOnQuest 32562,32581
.goto 504,45.653645,59.287798
>>Kill |cRXP_ENEMY_Horgak the Enslaver|r
.complete 32562,1 << Horde 
.complete 32581,1 << Alliance 
.mob Horgak the Enslaver
step << Horde
.isOnQuest 32230,32228,32287,32285,32506
.cast 140300 >> |cRXP_WARN_Use the|r |T838819:0|t[Sunreaver Beacon] |cRXP_WARN_to teleport to the Dawnseeker's Promontory|r
.use 95568
.subzoneskip 6584
step << Alliance
.isOnQuest 32575,32574,32573,32572,32571
.cast 140295 >> |cRXP_WARN_Use the|r |T801132:0|t[Kirin Tor Beacon] |cRXP_WARN_to teleport to the Violet Rise|r
.use 95567
.subzoneskip 6583
step << Horde
.isOnQuest 32287
.goto 504,33.519448,35.149929
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Arcanist Savor|r
.target High Arcanist Savor
.dailyturnin 32287 >>Turn in Enemies Beneath the Tower
step << Horde
.isOnQuest 32285
.goto 504,33.519448,35.149929
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Arcanist Savor|r
.target High Arcanist Savor
.dailyturnin 32285 >>Turn in The Sleepless Legion
step << Horde
.isOnQuest 32506
.goto 504,32.445796,35.229748
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Hathorel|r
.target Magister Hathorel
.dailyturnin 32506 >>Turn in A Wing to Fly On
step << Horde
.isOnQuest 32230
.goto 504,32.426451,35.222491
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Girana the Blooded|r
.target Girana the Blooded
.dailyturnin 32230 >>Turn in The Zandalari Colossus
step << Horde
.isOnQuest 32228
.goto 504,32.426451,35.222491
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Girana the Blooded|r
.target Girana the Blooded
.dailyturnin 32228 >>Turn in The Shuddering Moor
step << Alliance
.isOnQuest 32571
.goto 504,63.475293,73.604351
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmage Yurias|r
.target Warmage Yurias
.dailyturnin 32571 >>Turn in A Wing to Fly On
step << Alliance
.isOnQuest 32572
.goto 504,62.701490,73.560813
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
.target Captain Elleane Wavecrest
.dailyturnin 32572 >>Turn in The Sleepless Legion
step << Alliance
.isOnQuest 32573
.goto 504,62.701490,73.560813
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
.target Captain Elleane Wavecrest
.dailyturnin 32573 >>Turn in Enemies Beneath the Tower
step << Alliance
.isOnQuest 32575
.goto 504,63.255243,72.131335
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
.dailyturnin 32575 >>Turn in The Zandalari Colossus
step << Alliance
.isOnQuest 32574
.goto 504,63.255243,72.131335
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
.dailyturnin 32574 >>Turn in The Shuddering Moor
step << Horde 
.isQuestTurnedIn 32506,32287,32285,32228,32230
.goto 504,32.511086,35.578047
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF HE IS NOT OFFERING ANY|r
.daily 32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32524,32523,32521,32563,32565,32520,32561,32293,32522,32562 
.target Lor'themar Theron
step << Alliance
.isQuestTurnedIn 32575,32574,32572,32573,32571
.goto 504,63.243152,72.225666
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE QUESTS OR IF HE IS NOT OFFERING ANY|r
.daily 32567,32568,32578,32577,32581,32580,32584,32585,32576,32579 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32567,32568,32578,32577,32581,32580,32584,32585,32576,32579 
.target Lady Jaina Proudmoore
step
.isOnQuest 32520,32576
.goto 504,44.043167,68.902310
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32520,1 << Horde 
.complete 32576,1 << Alliance 
.mob Arcweaver Jor'guva
step
.isOnQuest 32561,32579
.goto 504,44.043167,68.902310
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32561,1 << Horde 
.complete 32579,1 << Alliance 
.mob Arcweaver Jor'guva
step
.isOnQuest 32564,32583
.goto 504,44.043167,68.902310
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32564,1 << Horde 
.complete 32583,1 << Alliance 
.mob Arcweaver Jor'guva
step
.isOnQuest 32293,32578
.goto 504,41.934555,79.481902
>>Kill |cRXP_ENEMY_Zur'chaka the Bonecrafter|r
.complete 32293,1 << Horde 
.complete 32578,1 << Alliance 
.mob Zur'chaka the Bonecrafter
step
.isOnQuest 32522,32581
.goto 504,45.653645,59.287798
>>Kill |cRXP_ENEMY_Horgak the Enslaver|r
.complete 32522,1 << Horde 
.complete 32581,1 << Alliance 
.mob Horgak the Enslaver
step
.isOnQuest 32562,32577
.goto 504,45.653645,59.287798
>>Kill |cRXP_ENEMY_Horgak the Enslaver|r
.complete 32562,1 << Horde 
.complete 32577,1 << Alliance 
.mob Horgak the Enslaver
step << Horde
#optional
.skipOnQuest 32524,TheBeatingofTrollDrums
step << Horde
#optional
.skipOnQuest 32523,TheBeastPensHORDE
step << Alliance
#optional
.skipOnQuest 32568,NoTimeToRest
step << Alliance
#optional
.skipOnQuest 32567,TheBeastPensALLY
step << Horde
#label TheBeastPensHORDE
step << Horde
.isOnQuest 32523
.goto 504,47.177069,40.635643
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32523 >>Turn in The Beast Pens
step << Horde
.isQuestTurnedIn 32523
#loop
.goto 504,47.177069,40.635643,3,0
.goto 504,47.223014,40.744487,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r and |cRXP_FRIENDLY_Magister Edien Sunhollow|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32298,32282,32207,32297,32283 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32298,32282,32207,32297,32283 
.target Scout Captain Elsia
.target Magister Edien Sunhollow
step << Alliance
#label TheBeastPensALLY
step << Alliance
.isOnQuest 32567
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32567 >>Turn in The Beast Pens
step << Alliance
#loop
.goto 504,51.778779,47.144487,3,0
.goto 504,51.853741,47.166256,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r and |cRXP_FRIENDLY_Miura Brightweaver|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32554,32550,32551,32552,32553 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32554,32550,32551,32552,32553 
.target Scout Captain Daelin
.target Miura Brightweaver
.isQuestTurnedIn 32567
step
.isOnQuest 32282,32551
#sticky
#label TrainedSaurid
#loop
.waypoint 504,48.8,39.2,60,0
.waypoint 504,50.0,44.0,60,0
.waypoint 504,53.6,44.4,60,0
.waypoint 504,51.8,36.8,60,0
>>Kill |cRXP_ENEMY_Tamed Bladetalons|r, |cRXP_ENEMY_Maturing Raptors|r and |cRXP_ENEMY_Trained Compy|r
.complete 32282,1 << Horde
.complete 32551,1 << Alliance
.mob +Tamed Bladetalon
.mob +Maturing Raptor
.complete 32282,2 << Horde
.complete 32551,2 << Alliance
.mob +Trained Compy
step
.isOnQuest 32298,32554
#sticky
#label SaurFetish
#loop
.waypoint 504,48.8,39.2,60,0
.waypoint 504,50.0,44.0,60,0
.waypoint 504,53.6,44.4,60,0
.waypoint 504,51.8,36.8,60,0
.use 93668 >>Kill |cRXP_ENEMY_Trolls|r. Loot them for their |T133446:0|t[|cRXP_LOOT_Saur Fetishes|r]. You can also loot them off the ground
>>|cRXP_WARN_Use the|r |T133446:0|t[|cRXP_LOOT_Saur Fetishes|r] |cRXP_WARN_on |cRXP_ENEMY_Raptors|r, |cRXP_ENEMY_Trained Compy|r, |cRXP_ENEMY_Skyscreamers|r or|r |cRXP_ENEMY_Direhorns|r
.collect 93668,5,32298,1,-1 << Horde
.collect 93668,5,32554,1,-1 << Alliance
.complete 32298,1 << Horde 
.complete 32554,1 << Alliance 
step
.isOnQuest 32207,32550
#sticky
#label BeastPenstrolls
#loop
.waypoint 504,48.8,39.2,60,0
.waypoint 504,50.0,44.0,60,0
.waypoint 504,53.6,44.4,60,0
.waypoint 504,51.8,36.8,60,0
>>Kill |cRXP_ENEMY_Trolls|r
.complete 32207,1 << Horde 
.complete 32550,1 << Alliance 
step
.isOnQuest 32283,32552
#sticky
#label LoaSpeaker
#loop
.waypoint 504,48.8,39.2,0
.waypoint 504,50.0,44.0,0
.waypoint 504,53.6,44.4,0
.waypoint 504,51.8,36.8,0
.waypoint 504,48.8,39.2,20,0
.waypoint 504,50.0,44.0,20,0
.waypoint 504,53.6,44.4,20,0
.waypoint 504,51.8,36.8,20,0
>>Kill the |cRXP_ENEMY_Loa Speaker|r
>>|cRXP_WARN_The |cRXP_ENEMY_Loa Speaker|r can spawn in one of four different locations|r
.complete 32283,1 << Horde
.complete 32552,1 << Alliance
.mob Loa Speaker
step
.isOnQuest 32297,32553
#sticky
#label DevilDire
#loop
.goto 504,53.901900,42.808886,30,0
.goto 504,51.764270,33.176233,30,0
>>Kill the |cRXP_ENEMY_Master Callers|r around either the |cRXP_ENEMY_Devilsaur|r or |cRXP_ENEMY_Direhorn|r ritual locations
.complete 32297,1 << Horde 
.complete 32553,1 << Alliance 
.mob Master Caller
step
#requires TrainedSaurid
step
#requires LoaSpeaker
step
#requires SaurFetish
step
#requires BeastPenstrolls
step
#requires DevilDire
step << Horde
.isOnQuest 32207
.goto 504,47.225432,40.744487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r
.target Magister Edien Sunhollow
.dailyturnin 32207 >>Turn in Saur Loser
step << Horde
.isOnQuest 32283
.goto 504,47.225432,40.744487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r
.target Magister Edien Sunhollow
.dailyturnin 32283 >>Turn in Loa-saur
step << Horde
.isOnQuest 32297
.goto 504,47.225432,40.744487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r
.target Magister Edien Sunhollow
.dailyturnin 32297 >>Turn in Direhorn or Devilsaur
step << Horde
.isOnQuest 32298
.goto 504,47.179487,40.635643
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32298 >>Turn in Dino Might
step << Horde
.isOnQuest 32282
.goto 504,47.179487,40.635643
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32282 >>Turn in Compy Stomp
step << Horde
.goto 504,53.935754,49.861947
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r or |cRXP_FRIENDLY_Scout Captain Elsia|r
>>|cRXP_WARN_Skip this step they are not offering any quest|r
.target Magister Edien Sunhollow
.target Scout Captain Elsia
.daily 32208,32209,32563,32565,32564,32294 >>Accept the random daily quest
.questcount <1,32208,32209,32563,32565,32564,32294
.subzoneskip 6587,1
step << Horde
.goto 504,47.227850,40.744487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r or |cRXP_FRIENDLY_Scout Captain Elsia|r
>>|cRXP_WARN_Skip this step they are not offering any quest|r
.target Magister Edien Sunhollow
.target Scout Captain Elsia
.daily 32208,32209,32563,32565,32564,32294 >>Accept the random daily quest
.questcount <1,32208,32209,32563,32565,32564,32294
.subzoneskip 6586,1
step << Alliance
.isOnQuest 32554
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32554 >>Turn in Dino Might
step << Alliance
.isOnQuest 32550
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32550 >>Turn in Saur Loser
step << Alliance
.isOnQuest 32551
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32551 >>Turn in Compy Stomp
step << Alliance
.isOnQuest 32552
.goto 504,51.853741,47.166256
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miura Brightweaver|r
.target Miura Brightweaver
.dailyturnin 32552 >>Turn in Loa-saur
step << Alliance
.isOnQuest 32553
.goto 504,51.853741,47.166256
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miura Brightweaver|r
.target Miura Brightweaver
.dailyturnin 32553 >>Turn in Direhorn vs Devilsaur
step << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miura Brightweaver|r or |cRXP_FRIENDLY_Scout Captain Daelin|r
>>|cRXP_WARN_Skip this step if they are not offering a quest|r
.target Miura Brightweaver
.target Scout Captain Daelin
.goto 504,51.853741,47.166256
.daily 32586,32588,32582,32584,32585,32583 >>Accept the random daily quest
.questcount <1,32586,32588,32582,32584,32585,32583
.subzoneskip 6586,1
step
.isOnQuest 32563,32584
.goto 504,45.230471,35.567163
>>Kill |cRXP_ENEMY_Nurkala|r
.complete 32563,1 << Horde 
.complete 32584,1 << Alliance 
.mob Nurkala
step
.isOnQuest 32565,32585
.goto 504,45.230471,35.567163
>>Kill |cRXP_ENEMY_Nurkala|r
.complete 32565,1 << Horde 
.complete 32585,1 << Alliance 
.mob Nurkala
step
.isOnQuest 32564,32583
.goto 504,54.702303,45.733149
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32564,1 << Horde 
.complete 32583,1 << Alliance 
.mob Arcweaver Jor'guv
step
.isOnQuest 32294,32582
.goto 504,54.462907,45.199816
>>Kill |cRXP_ENEMY_Zur'chaka the Bonecrafter|r
.complete 32294,1 << Horde 
.complete 32582,1 << Alliance 
.mob Zur'chaka the Bonecrafter
step << Horde
.isOnQuest 32294
.goto 504,47.172233,40.639272
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32294 >>Turn in Raining Bones
step << Horde
.isOnQuest 32563
.goto 504,47.172233,40.639272
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32563 >>Turn in Encroaching Force
step << Horde
.isOnQuest 32565
.goto 504,47.172233,40.639272
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32565 >>Turn in Encroaching Force
step << Horde
.isOnQuest 32564
.goto 504,47.172233,40.639272
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32564 >>Turn in Zandalari on the Rise
step << Alliance
.isOnQuest 32582
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32582 >>Turn in Raining Bones
step << Alliance
.isOnQuest 32584
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32584 >>Turn in Encroaching Force
step << Alliance
.isOnQuest 32585
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32585 >>Turn in Encroaching Force
step << Alliance
.isOnQuest 32583
.goto 504,51.778779,47.144487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32583 >>Turn in Zandalari on the Rise
step << Horde
#label TheBeatingofTrollDrums
step << Horde
.isOnQuest 32524
.goto 504,53.930918,49.774872
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32524 >>Turn in The Beating of Troll Drums
step << Horde
#loop
.goto 504,53.935754,49.822038
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r and |cRXP_FRIENDLY_Magister Edien Sunhollow|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32233,32206,32232,32493,32494,32234 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32233,32206,32232,32493,32494,32234 
.target Scout Captain Elsia
.target Magister Edien Sunhollow
.subzoneskip 6587,1
step << Alliance
#label NoTimeToRest
step << Alliance
.isOnQuest 32568
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32568 >>Turn in No Time To Rest
step << Alliance
.isQuestTurnedIn 32568
#loop
.goto 504,61.886579,51.995281,3,0
.goto 504,61.896252,52.100496,3,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r and |cRXP_FRIENDLY_Miura Brightweaver|r
>>|cRXP_WARN_MANUALLY SKIP THIS STEP ONCE YOU HAVE ACCEPTED ALL AVAILABLE DAILY QUESTS|r
.daily 32559,32560,32557,32555,32558,32556 >>Accept all available daily quests
.disablecheckbox
.questcount <99,32559,32560,32557,32555,32558,32556 
.target Scout Captain Daelin
.target Miura Brightweaver
step
.isOnQuest 32494,32558
#sticky
#label Masks
>>Kill |cRXP_ENEMY_Spiritbinder Tu'chek|r and |cRXP_ENEMY_Arcanital Ra'kul|r. Loot them for their |cRXP_LOOT_Mask|r
.complete 32494,1 << Horde 
.complete 32558,1 << Alliance 
.mob +Spiritbinder Tu'chek
.goto 504,59.386228,56.679181,-1
.complete 32494,2 << Horde 
.complete 32558,2 << Alliance 
.mob +Arcanital Ra'kul
.goto 504,56.711772,46.357185,-1
step
.isOnQuest 32234,32556
#sticky
#label RitualArtifacts
#loop
.waypoint 504,57.1,46.9,70,0
.waypoint 504,55.6,54.1,70,0
.waypoint 504,61.3,51.1,70,0
>>Loot the |cRXP_PICK_Ritual Artifacts|r on the ground and on the walls
.complete 32234,1 << Horde 
.complete 32556,1 << Alliance 
step
.isOnQuest 32233,32557
#sticky
#label LoaInfusedBlades
#loop
.waypoint 504,57.1,46.9,70,0
.waypoint 504,55.6,54.1,70,0
.waypoint 504,61.3,51.1,70,0
>>Loot the |cRXP_PICK_Loa-Infused Blades|r on the ground
.complete 32233,1 << Horde 
.complete 32557,1 << Alliance 
step
.isOnQuest 32206,32560
#sticky
#label Zandalarislain
#loop
.waypoint 504,57.1,46.9,70,0
.waypoint 504,55.6,54.1,70,0
.waypoint 504,61.3,51.1,70,0
>>Kill the |cRXP_ENEMY_Zandalari|r
.complete 32206,1 << Horde 
.complete 32560,1 << Alliance 
step
.isOnQuest 32493,32555
#sticky
#label ZandalariSpirits
#loop
.waypoint 504,57.1,46.9,70,0
.waypoint 504,55.6,54.1,70,0
.waypoint 504,61.3,51.1,70,0
>>Kill |cRXP_ENEMY_Spirit-Bound Sentries|r
.use 93806 >>|cRXP_WARN_Use the|r |T133450:0|t[Resonance Siphon] |cRXP_WARN_on their corpse|r
.complete 32493,1 << Horde 
.complete 32555,1 << Alliance 
.mob Spirit-Bound Sentry
step
.isOnQuest 32232,32559
#sticky
#label GuardianTaku
.goto 504,60.239830,54.157639
>>Kill the |cRXP_ENEMY_Priests|r and |cRXP_ENEMY_Guardian Tak'u|r
.complete 32232,1 << Horde 
.complete 32559,1 << Alliance 
.mob Guardian Tak'u
step
#requires GuardianTaku
step
#requires Zandalarislain
step
#requires LoaInfusedBlades
step
#requires ZandalariSpirits
step
#requires Masks
step
#requires RitualArtifacts
step << Horde
.isOnQuest 32206
.goto 504,53.928500,49.771244
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32206 >>Turn in This Just Won't Do
step << Horde
.isOnQuest 32232
.goto 504,53.928500,49.771244
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32232 >>Turn in What's Inside Counts
step << Horde
.isOnQuest 32233
.goto 504,53.928500,49.771244
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32233 >>Turn in Very Disarming
step << Horde
.isOnQuest 32493
.goto 504,53.935754,49.861947
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r
.target Magister Edien Sunhollow
.dailyturnin 32493 >>Turn in They All Fall Down
step << Horde
.isOnQuest 32494
.goto 504,53.935754,49.861947
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r
.target Magister Edien Sunhollow
.dailyturnin 32494 >>Turn in Power Play
step << Horde
.isOnQuest 32234
.goto 504,53.935754,49.861947
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r
.target Magister Edien Sunhollow
.dailyturnin 32234 >>Turn in Knowledge Is Power
step << Horde
.goto 504,53.935754,49.861947
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r or |cRXP_FRIENDLY_Scout Captain Elsia|r
>>|cRXP_WARN_Skip this step if they are not offering a quest|r
.target Magister Edien Sunhollow
.target Scout Captain Elsia
.daily 32208,32209,32563,32565,32564,32294 >>Accept the random daily quest
.questcount <1,32208,32209,32563,32565,32564,32294
.subzoneskip 6587,1
step << Horde
.goto 504,47.227850,40.744487
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Edien Sunhollow|r or |cRXP_FRIENDLY_Scout Captain Elsia|r
>>|cRXP_WARN_Skip this step if they are not offering a quest|r
.target Magister Edien Sunhollow
.target Scout Captain Elsia
.daily 32208,32209,32563,32565,32564,32294 >>Accept the random daily quest
.questcount <1,32208,32209,32563,32565,32564,32294
.subzoneskip 6586,1
step << Alliance
.isOnQuest 32559
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32559 >>Turn in Even Giants Fall
step << Alliance
.isOnQuest 32560
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32560 >>Turn in Keep It Secret
step << Alliance
.isOnQuest 32557
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32557 >>Turn in Out of Enemy Hands
step << Alliance
.isOnQuest 32555
.goto 504,61.896252,52.100496
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miura Brightweaver|r
.target Miura Brightweaver
.dailyturnin 32555 >>Turn in Centuries in Sentries
step << Alliance
.isOnQuest 32558
.goto 504,61.896252,52.100496
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miura Brightweaver|r
.target Miura Brightweaver
.dailyturnin 32558 >>Turn in All In the Family
step << Alliance
.isOnQuest 32556
.goto 504,61.896252,52.100496
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miura Brightweaver|r
.target Miura Brightweaver
.dailyturnin 32556 >>Turn in The More You Know
step << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miura Brightweaver|r or |cRXP_FRIENDLY_Scout Captain Daelin|r
>>|cRXP_WARN_Skip this step if they are not offering a quest|r
.target Miura Brightweaver
.target Scout Captain Daelin
.goto 504,61.896252,52.100496
.daily 32586,32588,32582,32584,32585,32583 >>Accept the random daily quest
.questcount <1,32586,32588,32582,32584,32585,32583
step
.isOnQuest 32563,32584
.goto 504,45.230471,35.567163 << Horde
.goto 504,61.884161,61.529974 << Alliance
>>Kill |cRXP_ENEMY_Nurkala|r
.complete 32563,1 << Horde 
.complete 32584,1 << Alliance 
.mob Nurkala
step
.isOnQuest 32565,32585
.goto 504,45.230471,35.567163 << Horde
.goto 504,61.884161,61.529974 << Alliance
>>Kill |cRXP_ENEMY_Nurkala|r
.complete 32565,1 << Horde 
.complete 32585,1 << Alliance 
.mob Nurkala
step
.isOnQuest 32564,32583
.goto 504,54.702303,45.733149
>>Kill |cRXP_ENEMY_Arcweaver Jor'guva|r
.complete 32564,1 << Horde 
.complete 32583,1 << Alliance 
.mob Arcweaver Jor'guva
step
.isOnQuest 32294,32582
.goto 504,54.462907,45.199816
>>Kill |cRXP_ENEMY_Zur'chaka the Bonecrafter|r
.complete 32294,1 << Horde 
.complete 32582,1 << Alliance 
.mob Zur'chaka the Bonecrafter
step << Horde
.isOnQuest 32294
.goto 504,53.935754,49.774872
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32294 >>Turn in Raining Bones
step << Horde
.isOnQuest 32563
.goto 504,53.935754,49.774872
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32563 >>Turn in Encroaching Force
step << Horde
.isOnQuest 32565
.goto 504,53.935754,49.774872
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32565 >>Turn in Encroaching Force
step << Horde
.isOnQuest 32564
.goto 504,53.935754,49.774872
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32564 >>Turn in Zandalari on the Rise
step << Alliance
.isOnQuest 32582
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32582 >>Turn in Raining Bones
step << Alliance
.isOnQuest 32584
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32584 >>Turn in Encroaching Force
step << Alliance
.isOnQuest 32585
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32585 >>Turn in Encroaching Force
step << Alliance
.isOnQuest 32583
.goto 504,61.886579,51.995281
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32583 >>Turn in Zandalari on the Rise
step 
.isOnQuest 32521,32580
.goto 504,45.230471,35.567163
>>Kill |cRXP_ENEMY_Nurkala|r
.complete 32521,1 << Horde 
.complete 32580,1 << Alliance 
.mob Nurkala
step
.isOnQuest 32209,32588,32208,32586
#completewith endLVM
.goto 504,49.145430,31.525439
.subzone 6589 >> Enter the Lightning Vein Mine
step
.isOnQuest 32209,32588
.use 93761 >>|cRXP_WARN_Channel the|r |T135477:0|t[Arcane Emancipator] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Scouts|r << Horde
.use 93761 >>|cRXP_WARN_Channel the|r |T135477:0|t[Arcane Emancipator] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Agents|r << Alliance
>>|cRXP_WARN_Do not turn your character while you channel otherwise the cast will fail|r
.complete 32209,3 << Horde
.target +Scout Alaine << Horde
.goto 504,48.744020,29.678727 << Horde
.complete 32588,1 << Alliance 
.target +Agent Reginald << Alliance
.goto 504,49.515405,30.618410 << Alliance
.complete 32209,1 << Horde
.target +Scout Elearis << Horde
.goto 504,50.654346,28.840632 << Horde
.complete 32588,2 << Alliance 
.target +Agent Grisel << Alliance
.goto 504,50.236009,28.659226 << Alliance
.complete 32209,2 << Horde
.target +Scout Merior << Horde
.goto 504,51.858577,26.816142 << Horde
.complete 32588,3 << Alliance 
.target +Agent Crowley << Alliance
.goto 504,51.244371,27.512741 << Alliance
step
.isOnQuest 32209,32588
>>Kill |cRXP_ENEMY_Metal Lord Mono-Han|r
.complete 32209,4 << Horde
.complete 32588,4 << Alliance
.goto 504,55.077113,31.057412
.mob Metal Lord Mono-Han
step
.isOnQuest 32209,32588
>>Click on the quest popup under your minimap to turn in the quest
.dailyturnin 32209 >>Turn in Save Our Scouts! << Horde
.dailyturnin 32588 >>Turn in On Her Magic-ey Secret Service << Alliance
.daily 32292,32722 >>Accept Forge Ahead! << Horde
.daily 32587,32724 >>Accept Forge Ahead! << Alliance
>>|cRXP_WARN_Forge Ahead! should accept automatically. If it does not, return to either the Beast Pens or Conqueror's Terrace to accept the quest. The location is marked on your map|r
.goto 504,47.179487,40.635643,0 << Horde
.goto 504,53.930918,49.774872,0 << Horde
.goto 504,61.886579,51.995281,0 << Alliance
.goto 504,51.778779,47.144487,0 << Alliance
.target Scout Captain Elsia << Horde
.target Scout Captain Daelin << Alliance
step
.isOnQuest 32208,32586
.goto 504,47.921855,30.476913
>>Click the |cRXP_PICK_Lightning Drill|r
.complete 32208,1 << Horde
.complete 32586,1 << Alliance
step
.isOnQuest 32208,32586
.goto 504,50.448805,29.584396,20,0
.goto 504,49.210720,26.750836
>>Click the |cRXP_PICK_Lightning Drill|r on the lower level
.complete 32208,2 << Horde
.complete 32586,2 << Alliance
step
.isOnQuest 32208,32586
.goto 504,52.668652,24.087798
>>Click the |cRXP_PICK_Lightning Drill|r
.complete 32208,3 << Horde
.complete 32586,3 << Alliance 
step
.isOnQuest 32208,32586
>>Kill |cRXP_ENEMY_Metal Lord Mono-Han|r
.complete 32208,4 << Horde
.complete 32586,4 << Alliance
.goto 504,55.077113,31.057412
.mob Metal Lord Mono-Han
step
#label endLVM
.isOnQuest 32208,32586
>>Click on the quest popup under your minimap to turn in the quest
.dailyturnin 32208 >>Turn in Maximum Capacitor << Horde
.dailyturnin 32586 >>Turn in Maximum Capacitor << Alliance
.daily 32292,32722 >>Accept Forge Ahead! << Horde
.daily 32587,32724 >>Accept Forge Ahead! << Alliance
>>|cRXP_WARN_Forge Ahead! should accept automatically. If it does not, return to either the Beast Pens or Conqueror's Terrace to accept the quest. The location is marked on your map|r
.goto 504,47.179487,40.635643,0 << Horde
.goto 504,53.930918,49.774872,0 << Horde
.goto 504,61.886579,51.995281,0 << Alliance
.goto 504,51.778779,47.144487,0 << Alliance
.target Scout Captain Elsia << Horde
.target Scout Captain Daelin << Alliance
step
.isOnQuest 32292,32587
.goto 504,57.780587,34.028841
>>Kill |cRXP_ENEMY_Itoka|r
>>|cRXP_WARN_Click the |cRXP_PICK_Activated Forges|r that are channeling lightning when |cRXP_ENEMY_Itoka|r gains the|r |T610472:0|t[Thunder King's Protection] |cRXP_WARN_buff|r
.complete 32292,1 << Horde
.complete 32587,1 << Alliance
.mob Itoka
step
.isOnQuest 32292,32587
.goto 504,55.497869,38.473285
>>Kill |cRXP_ENEMY_Fleshcrafter Hoku|r. Loot him for the |cRXP_LOOT_Mogu Codex Fragment|r
.complete 32292,2 << Horde
.complete 32587,2 << Alliance 
.mob Fleshcrafter Hoku
step << Horde
.isOnQuest 32292
.goto 504,58.704315,42.689158
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32292 >>Turn in Forge Ahead!
step << Alliance
.isOnQuest 32587
.goto 504,58.701896,42.689158
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32587 >>Turn in Forge Ahead!
step
.isOnQuest 32722,32724
.goto 504,57.780587,34.028841
>>Kill |cRXP_ENEMY_Itoka|r
>>|cRXP_WARN_Click the |cRXP_PICK_Activated Forges|r that are channeling lightning when |cRXP_ENEMY_Itoka|r gains the|r |T610472:0|t[Thunder King's Protection] |cRXP_WARN_buff|r
.complete 32722,1 << Horde
.complete 32724,1 << Alliance
.mob Itoka
step
.isOnQuest 32722,32724
.goto 504,55.497869,38.473285
>>Kill |cRXP_ENEMY_Fleshcrafter Hoku|r. Loot him for the |cRXP_LOOT_Mogu Codex Fragment|r
.complete 32722,2 << Horde
.complete 32724,2 << Alliance 
.mob Fleshcrafter Hoku
step << Horde
.isOnQuest 32722
.goto 504,58.704315,42.689158
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Scout Captain Elsia
.dailyturnin 32722 >>Turn in Forge Ahead!
step << Alliance
.isOnQuest 32724
.goto 504,58.701896,42.689158
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.target Scout Captain Daelin
.dailyturnin 32724 >>Turn in Forge Ahead!
step
.isQuestTurnedIn 32292,32722,32587,32724
.goto 504,58.668043,42.758092
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taoshi|r
>>|cRXP_WARN_SKIP THIS STEP IF THE LARGE DOOR IS STILL CLOSED. IT WILL OPEN IN A LATER STAGE|r
.target Taoshi
.daily 32677,32676,32607,32608 >>Accept Raiding the Vault or Extended Shore Leave
step
.isOnQuest 32677
#completewith next
.goto 504,62.292826,40.203897
.subzone 6592 >> Go through the |cRXP_PICK_Swollen Vault|r door
step
.isOnQuest 32677
.goto 504,61.286882,38.669204
>>Kill |cRXP_ENEMY_Lu-Shero|r. Loot him for the |cRXP_LOOT_Hoard-Keeper's Key|r
.collect 95374,1 
.mob Lu-Shero
step
.isOnQuest 32677
#completewith next
.goto 504,59.042853,35.327707,15 >> Jump on the pillars to get to the other side. The lightning fields on the pillars will rotate giving safe spots
>>|cRXP_WARN_If you cannot make it, die to the traps below and run back. Resurrect on the side with the chest|r
step
.isOnQuest 32677
.goto 504,59.042853,35.327707
>>Loot the |cRXP_PICK_Stormy Chest|r for the |cRXP_LOOT_Choker of Storms|r
.complete 32677,1 
step
#completewith next
.goto 504,67.063804,45.156278,10 >> Head onto the warship
step
.isOnQuest 32676
.goto 504,68.446977,45.921811,10,0
.goto 504,67.121839,47.137231
>>Kill |cRXP_ENEMY_Beastcaller Tuk'wa|r or |cRXP_ENEMY_Arcweaver Uzan|r on the upper deck
>>Loot the |cRXP_PICK_Workshop Orders|r
.complete 32676,1 
.mob +Beastcaller Tuk'wa
.mob +Arcweaver Uzan
.complete 32676,2 
step << Horde
.isOnQuest 32677,32676,32521,32563,32565,32520,32561,32522,32562,32293
.cast 140300 >> |cRXP_WARN_Use the|r |T838819:0|t[Sunreaver Beacon] |cRXP_WARN_to teleport to the Dawnseeker's Promontory|r
.use 95568
.subzoneskip 6584
step << Alliance
.isOnQuest 32608,32607,32576,32579,32580,32584,32585,32578,32577,32581
.cast 140295 >> |cRXP_WARN_Use the|r |T801132:0|t[Kirin Tor Beacon] |cRXP_WARN_to teleport to the Violet Rise|r
.use 95567
.subzoneskip 6583
step << Horde
.isOnQuest 32677
.goto 504,32.513504,35.574419
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.dailyturnin 32677 >>Turn in Raiding the Vault
step << Horde
.isOnQuest 32676
.goto 504,32.511086,35.578047
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.dailyturnin 32676 >>Turn in Extended Shore Leave
step << Horde
.isOnQuest 32521,32563,32565
.goto 504,32.511086,35.578047
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.dailyturnin 32521,32563,32565 >>Turn in Encroaching Force
step << Horde
.isOnQuest 32520,32561
.goto 504,32.513504,35.574419
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.dailyturnin 32520,32561 >>Turn in Competing Magic
step << Horde
.isOnQuest 32293
.goto 504,32.513504,35.574419
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.dailyturnin 32293 >>Turn in Among the Bones
step << Horde
.isOnQuest 32522,32562
.goto 504,32.513504,35.574419
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.dailyturnin 32522,32562 >>Turn in Imposing Threat
step << Horde 
.isOnQuest 32564
.goto 504,32.513504,35.574419
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Elsia|r
.target Lor'themar Theron
.dailyturnin 32564 >>Turn in Zandalari on the Rise
step << Alliance
.isOnQuest 32608
.goto 504,63.240734,72.229294
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.dailyturnin 32608 >>Turn in Raiding the Vault
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32607
.goto 504,63.240734,72.229294
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.dailyturnin 32607 >>Turn in Extended Shore Leave
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32576,32579
.goto 504,63.240734,72.229294
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.dailyturnin 32576,32579 >>Turn in Competing Magic
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32580,32584,32585
.goto 504,63.240734,72.229294
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.dailyturnin 32580,32584,32585 >>Turn in Encroaching Force
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32578
.goto 504,63.240734,72.229294
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.dailyturnin 32578 >>Turn in Among the Bones
.target Lady Jaina Proudmoore
step << Alliance
.isOnQuest 32577,32581
.goto 504,63.240734,72.229294
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.dailyturnin 32577,32581 >>Turn in Imposing Threat
.target Lady Jaina Proudmoore
step << Alliance 
.isOnQuest 32579
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Captain Daelin|r
.dailyturnin 32579 >>Turn in Zandalari on the Rise
.target Scout Captain Daelin
step
+|cRXP_WARN_You have completed all available daily quests on the Isle of Thunder for today. Load the same guide again tomorrow once the daily quests have reset to complete more daily quests|r
]])

RXPGuides.RegisterGuide([[#mop
#internal
#group RXP-Pandaria
#subgroup Isle of Thunder
#name isle of thunder daily pvp quests
#displayname |cRXP_FRIENDLY_1.1|r - Isle of Thunder Daily PvP Quests
step << Horde
#loop
.goto 504,32.445796,35.229748,5,0
.goto 504,32.508668,35.588931,5,0
.goto 504,33.519448,35.157185,5,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Girana the Blooded|r, |cRXP_FRIENDLY_Magister Hathorel|r, |cRXP_FRIENDLY_Lor'themar Theron|r and |cRXP_FRIENDLY_High Arcanist Savor|r
.daily 32213,32265,32303,32264,32288,32262,32300,32305,32269,32302,32266,32268 >>Accept all of the available daily quests
.disablecheckbox
.questcount <7,32213,32265,32303,32264,32288,32262,32300,32305,32269,32302,32266,32268
.target Girana the Blooded
.target Magister Hathorel
.target Lor'themar Theron
.target High Arcanist Savor
step << Horde
.isOnQuest 32288
#completewith FinalBomb
>>Click the |cRXP_PICK_Sunreaver Perimeter Wards|r
.complete 32288,1 
.target Sunreaver Perimeter Ward
step << Horde
.isOnQuest 32300
.goto 504,36.280957,38.291879
>>Click the |cRXP_PICK_Tactical Mana Bomb|r under the bridge
.complete 32300,3 
step << Horde
.isOnQuest 32300
.goto 504,41.330021,31.445621
>>Click the |cRXP_PICK_Tactical Mana Bomb|r on the side of the ship
.complete 32300,1 
step << Horde
.isOnQuest 32300
#label FinalBomb
.goto 504,41.521054,40.882355
>>Click the |cRXP_PICK_Tactical Mana Bomb|r
.complete 32300,2 
step << Horde
.isOnQuest 32288
#loop
.goto 504,40.8,39.3,65,0
.goto 504,37.2,45.5,65,0
.goto 504,43.6,46.5,65,0
>>Click the |cRXP_PICK_Sunreaver Perimeter Wards|r
.complete 32288,1 
.target Sunreaver Perimeter Ward
step << Horde
.isOnQuest 32265
#loop
.goto 504,40.8,51.5,20,0
.goto 504,45.5,50.6,20,0
.goto 504,54.3,58.4,20,0
>>Loot a |cRXP_PICK_Charged Moganite|r on the ground
>>|cRXP_WARN_NOTE: When you are near one you will see an indicator on your minimap|r
.complete 32265,1 
.aura 137257
step << Horde
.isOnQuest 32213
#sticky
#label SilverCovenants
#loop
.waypoint 504,56.6,73.8,70,0
.waypoint 504,55.8,59.0,70,0
.waypoint 504,60.0,66.6,70,0
>>Kill |cRXP_ENEMY_Silver Covenant Spellblades|r and |cRXP_ENEMY_Silver Covenant Rangers|r
>>|cRXP_WARN_You can also kill |cRXP_ENEMY_Alliance|r players to receive credit|r
.complete 32213,1 
.mob Silver Covenant Spellblade
.mob Silver Covenant Ranger
step << Horde
.isOnQuest 32303
#sticky
#label ArcaneDestroyer
.waypoint 504,61.355,66.772
>>Kill the |cRXP_ENEMY_Arcane Destroyer|r
.complete 32303,1 
.mob Arcane Destroyer
step << Horde
.isOnQuest 32264
#sticky
#label JainaBook
.waypoint 504,60.468,67.419
>>Loot |cRXP_PICK_Jaina's Weathered Spellbook|r on the table
.complete 32264,1 
step << Horde
.isOnQuest 32262
#sticky
#label SunreaverCaptives
.waypoint 504,61.2,67.2,65,0
.waypoint 504,57.4,74.2,65,0
.waypoint 504,58.4,64.2,65,0
>>Click the |cRXP_FRIENDLY_Sunreaver Captives|r
.complete 32262,1 
.target Sunreaver Captive
step << Horde
.isOnQuest 32305
#loop
#sticky
#label ManaFoci
.waypoint 504,58.3,65.3,50,0
.waypoint 504,59.7,72.1,50,0
.waypoint 504,64.8,73.0,50,0
.use 95352 >>|cRXP_WARN_Use the|r |T512905:0|t[Sunreaver Mana Crystal] |cRXP_WARN_near|r |cRXP_PICK_Kirin Tor Mana Foci|r
>>|cRXP_WARN_These are the blue circular objects on the ground|r
.complete 32305,1 
step << Horde
.isOnQuest 32269
#sticky
#label KirinTorPerimeterWards
.waypoint 504,54.6,63.7,70,0
.waypoint 504,57.4,72.7,70,0
.waypoint 504,59.5,62.1,70,0
>>Click the |cRXP_PICK_Kirin Tor Perimeter Wards|r
.complete 32269,1 
.mob Kirin Tor Perimeter Ward
step << Horde
.isOnQuest 32302
#sticky
#label KirinTorConstruct
.waypoint 504,56.8,67.8,70,0
.waypoint 504,62.6,73.4,70,0
.waypoint 504,59.0,63.6,70,0
>>Kill |cRXP_ENEMY_Kirin Tor Constructs|r
.complete 32302,1 
.mob Kirin Tor Construct
step << Horde
.isOnQuest 32266
#sticky
#label KirinTorManafiend
.waypoint 504,57.8,67.2,65,0
.waypoint 504,57.2,73.8,65,0
.waypoint 504,59.0,63.4,65,0
>>Kill |cRXP_ENEMY_Kirin Tor Manafiends|r
.complete 32266,1 
.mob Kirin Tor Manafiend
step << Horde
.isOnQuest 32268
>>Click the |cRXP_PICK_Tactical Mana Bomb Placements|r
.complete 32268,1 
.waypoint 504,62.609601,78.821584,-1
.complete 32268,3 
.goto 504,59.071871,65.531789,-1
.complete 32268,2 
.waypoint 504,58.967891,73.829294,-1
.target Tactical Mana Bomb Placement
step << Horde
#optional
.isOnQuest 32265
#loop
.goto 504,40.8,51.5,20,0
.goto 504,45.5,50.6,20,0
.goto 504,54.3,58.4,20,0
>>Loot a |cRXP_PICK_Charged Moganite|r on the ground
>>|cRXP_WARN_NOTE: When you are near one you will see an indicator on your minimap|r
.complete 32265,1 
.aura 137257
step << Horde
#requires SilverCovenants
step << Horde
#requires ArcaneDestroyer
step << Horde
#requires JainaBook
step << Horde
#requires SunreaverCaptives
step << Horde
#requires ManaFoci
step << Horde
#requires KirinTorPerimeterWards
step << Horde
#requires KirinTorConstruct
step << Horde
#requires KirinTorManafiend
step << Horde 
.isNotOnQuest 32265
.isOnQuest 32213,32303,32264,32288,32262,32300,32305,32269,32302,32266,32268
.cast 140300 >> |cRXP_WARN_Use the|r |T838819:0|t[Sunreaver Beacon] |cRXP_WARN_to teleport to the Dawnseeker's Promontory|r
.use 95568
.subzoneskip 6584
step << Horde
.isOnQuest 32265
#completewith next
.subzone 6584 >> Return to the Dawnseeker's Promontory
step << Horde
.isOnQuest 32265
.goto 504,33.519448,35.149929
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Arcanist Savor|r
.target High Arcanist Savor
.dailyturnin 32265 >>Turn in Charged Moganite
step << Horde
.isOnQuest 32303
.goto 504,33.519448,35.149929
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Arcanist Savor|r
.target High Arcanist Savor
.dailyturnin 32303 >>Turn in Made for War
step << Horde
.isOnQuest 32264
.goto 504,33.519448,35.149929
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Arcanist Savor|r
.target High Arcanist Savor
.dailyturnin 32264 >>Turn in Spellbound
step << Horde
.isOnQuest 32213
.goto 504,32.513504,35.574419
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.dailyturnin 32213 >>Turn in Old Enemies
step << Horde
.isOnQuest 32288
.goto 504,32.445796,35.229748
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Hathorel|r
.target Magister Hathorel
.dailyturnin 32288 >>Turn in Bolstering the Defenses
step << Horde
.isOnQuest 32262
.goto 504,32.445796,35.229748
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Hathorel|r
.target Magister Hathorel
.dailyturnin 32262 >>Turn in Captive Audience
step << Horde
.isOnQuest 32300
.goto 504,32.445796,35.229748
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Hathorel|r
.target Magister Hathorel
.dailyturnin 32300 >>Turn in Disarming Irony
step << Horde
.isOnQuest 32305
.goto 504,32.445796,35.229748
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magister Hathorel|r
.target Magister Hathorel
.dailyturnin 32305 >>Turn in Overpowered
step << Horde
.isOnQuest 32269
.goto 504,32.426451,35.222491
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Girana the Blooded|r
.target Girana the Blooded
.dailyturnin 32269 >>Turn in Breaking Down the Defenses
step << Horde
.isOnQuest 32302
.goto 504,32.426451,35.222491
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Girana the Blooded|r
.target Girana the Blooded
.dailyturnin 32302 >>Turn in Desconstruction
step << Horde
.isOnQuest 32266
.goto 504,32.426451,35.222491
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Girana the Blooded|r
.target Girana the Blooded
.dailyturnin 32266 >>Turn in Mana Manifestations
step << Horde
.isOnQuest 32268
.goto 504,32.426451,35.222491
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Girana the Blooded|r
.target Girana the Blooded
.dailyturnin 32268 >>Turn in Tactical Mana Bombs
step << Horde
.isQuestTurnedIn 32213,32265,32303,32264,32288,32262,32300,32305,32269,32302,32266,32268
.goto 504,32.511086,35.578047
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.daily 32304 >>Accept High Recognition
.dailyturnin 32304 >>Turn in High Recognition
step << Alliance
#loop
.goto 504,63.247989,72.174872,5,0
.goto 504,63.475293,73.604351,5,0
.goto 504,62.703908,73.560813,5,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r, |cRXP_FRIENDLY_Lady Jaina Proudmoore|r, |cRXP_FRIENDLY_Warmage Yurias|r and |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
.daily 32301,32627,32632,32633,32485,32636,32635,32637,32634,32639,32638,32628 >>Accept all of the available daily quests
.disablecheckbox
.questcount <7,32301,32627,32632,32633,32485,32636,32635,32637,32634,32639,32638,32628
.target Vereesa Windrunner
.target Warmage Yurias
.target Lady Jaina Proudmoore
.target Captain Elleane Wavecrest
step << Alliance
.isOnQuest 32635
.goto 504,65.138970,67.556278
>>Click the |cRXP_PICK_Tactical Mana Bomb|r
.complete 32635,1 
.target Tactical Mana Bomb
step << Alliance
.isOnQuest 32485
#completewith FinalBomb
>>Click the |cRXP_PICK_Kirin Tor Perimeter Wards|r
.complete 32485,1 
.target Kirin Tor Perimeter Ward
step << Alliance
.isOnQuest 32635
.goto 504,59.260485,65.263308
.complete 32635,3 
.target Tactical Mana Bomb
step << Alliance
.isOnQuest 32635
#label FinalBomb
.goto 504,59.006581,73.814782
.complete 32635,2 
.target Tactical Mana Bomb
step << Alliance
.isOnQuest 32485
#loop
.goto 504,57.5,70.2,70,0
.goto 504,56.5,61.3,70,0
.goto 504,59.5,67.3,70,0
>>Click the |cRXP_PICK_Kirin Tor Perimeter Wards|r
.complete 32485,1 
.target Kirin Tor Perimeter Ward
step << Alliance
.isOnQuest 32627
#loop
.goto 504,52.5,57.3,20,0
.goto 504,50.1,55.5,20,0
.goto 504,45.5,50.6,20,0
.goto 504,40.8,51.5,20,0
>>Loot a |cRXP_PICK_Charged Moganite|r on the ground
>>|cRXP_WARN_NOTE: When you are near one you will see an indicator on your minimap|r
.complete 32627,1 
.aura 137257
step << Alliance
.isOnQuest 32301
#sticky
#label SunreaverAgents
#loop
.waypoint 504,39.2,43.8,70,0
.waypoint 504,35.8,38.4,70,0
.waypoint 504,41.4,39.6,70,0
>>Kill |cRXP_ENEMY_Sunreaver Magi|r and |cRXP_ENEMY_Silvermoon Spellbreakers|r
>>|cRXP_WARN_You can also kill |cRXP_ENEMY_Horde|r players to receive credit|r
.complete 32301,1 
.mob Sunreaver Magus
.mob Silvermoon Spellbreaker
step << Alliance
.isOnQuest 32632
#sticky
#label PyrestarDemolisher
.waypoint 504,34.880,38.077
>>Kill the |cRXP_ENEMY_Pyrestar Demolisher|r
.complete 32632,1 
.mob Pyrestar Demolisher
step << Alliance
.isOnQuest 32633
#sticky
#label BookofIncantations
.waypoint 504,39.253,37.366
>>Loot |cRXP_PICK_Rommath's Book of Incantations|r on the table
.complete 32633,1 
step << Alliance
.isOnQuest 32636
#sticky
#label KirinTorCaptives
#loop
.waypoint 504,38.0,43.4,60,0
.waypoint 504,38.8,37.0,60,0
.waypoint 504,41.4,39.6,60,0
.waypoint 504,35.8,42.0,60,0
>>Click the |cRXP_FRIENDLY_Kirin Tor Captives|r
.complete 32636,1 
.target Kirin Tor Captive
step << Alliance
.isOnQuest 32637
#sticky
#label ManaCollectors
#loop
.waypoint 504,39.1,43.6,50,0
.waypoint 504,37.2,38.8,50,0
.waypoint 504,40.2,38.4,50,0
.use 95360 >>|cRXP_WARN_Use the|r |T458245:0|t[Kirin Tor Mana Crystal] |cRXP_WARN_near|r |cRXP_PICK_Sunreaver Mana Collectors|r
>>|cRXP_WARN_These are the black circular objects on the ground|r
.complete 32637,1 
step << Alliance
.isOnQuest 32634
#sticky
#label SunreaverPerimeterWard
#loop
.waypoint 504,39.0,48.3,70,0
.waypoint 504,37.7,37.6,70,0
.waypoint 504,43.6,46.5,70,0
>>Click the |cRXP_PICK_Sunreaver Perimeter Wards|r
.complete 32634,1 
.mob Sunreaver Perimeter Ward
step << Alliance
.isOnQuest 32639
#sticky
#label SunreaverConstructs
#loop
.waypoint 504,37.8,41.2,70,0
.waypoint 504,35.8,42.0,70,0
.waypoint 504,43.3,40.0,70,0
>>Kill |cRXP_ENEMY_Sunreaver Constructs|r
.complete 32639,1 
.mob Sunreaver Construct
step << Alliance
.isOnQuest 32638
#sticky
#label SunreaverManaWyrms
#loop
.waypoint 504,39.2,43.6,50,0
.waypoint 504,36.8,40.6,50,0
.waypoint 504,38.8,37.0,50,0
.waypoint 504,41.6,41.2,50,0
>>Kill |cRXP_ENEMY_Sunreaver Mana Wyrms|r
.complete 32638,1 
.mob Sunreaver Mana Wyrm
step << Alliance
.isOnQuest 32628
.goto 504,41.514,40.879
>>Click the |cRXP_PICK_Tactical Mana Bomb Placements|r
.complete 32628,3 
step << Alliance
.isOnQuest 32628
.goto 504,36.280957,38.291879
>>Click the |cRXP_PICK_Tactical Mana Bomb|r under the bridge
.complete 32628,2 
step << Alliance
.isOnQuest 32628
.goto 504,35.168,28.155
>>Click the |cRXP_PICK_Tactical Mana Bomb|r beside the ship in the water
.complete 32628,1 
step << Alliance
#optional
.isOnQuest 32627
#loop
.goto 504,52.5,57.3,20,0
.goto 504,50.1,55.5,20,0
.goto 504,45.5,50.6,20,0
.goto 504,40.8,51.5,20,0
>>Loot a |cRXP_PICK_Charged Moganite|r on the ground
>>|cRXP_WARN_NOTE: When you are near one you will see an indicator on your minimap|r
.complete 32627,1 
.aura 137257
step << Alliance
#requires SunreaverAgents
step << Alliance
#requires PyrestarDemolisher
step << Alliance
#requires BookofIncantations
step << Alliance
#requires KirinTorCaptives
step << Alliance
#requires ManaCollectors
step << Alliance
#requires SunreaverPerimeterWard
step << Alliance
#requires SunreaverConstructs
step << Alliance
#requires SunreaverManaWyrms
step << Alliance 
.isNotOnQuest 32627
.isOnQuest 32301,32632,32633,32485,32636,32635,32637,32634,32639,32638,32628
.cast 140295 >> |cRXP_WARN_Use the|r |T801132:0|t[Kirin Tor Beacon] |cRXP_WARN_to teleport to the Violet Rise|r
.use 95567
.subzoneskip 6583
step << Alliance
.isOnQuest 32627
#completewith ChargedMoganite
.subzone 6583 >> Return to the Violet Rise
step << Alliance
.isOnQuest 32632
.goto 504,63.475293,73.604351
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmage Yurias|r
.target Warmage Yurias
.dailyturnin 32632 >>Turn in Made for War
step << Alliance
.isOnQuest 32633
.goto 504,63.475293,73.604351
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmage Yurias|r
.target Warmage Yurias
.dailyturnin 32633 >>Turn in Spellbound
step << Alliance
.isOnQuest 32627
#label ChargedMoganite
.goto 504,63.475293,73.604351
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warmage Yurias|r
.target Warmage Yurias
.dailyturnin 32627 >>Turn in Charged Moganite
step << Alliance
.isOnQuest 32634
.goto 504,62.701490,73.560813
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
.target Captain Elleane Wavecrest
.dailyturnin 32634 >>Turn in Breaking Down the Defenses
step << Alliance
.isOnQuest 32639
.goto 504,62.701490,73.560813
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
.target Captain Elleane Wavecrest
.dailyturnin 32639 >>Turn in Deconstruction
step << Alliance
.isOnQuest 32638
.goto 504,62.701490,73.560813
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
.target Captain Elleane Wavecrest
.dailyturnin 32638 >>Turn in Mana Scavengers
step << Alliance
.isOnQuest 32628
.goto 504,62.701490,73.560813
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Elleane Wavecrest|r
.target Captain Elleane Wavecrest
.dailyturnin 32628 >>Turn in Tactical Mana Bombs
step << Alliance
.isOnQuest 32485
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.dailyturnin 32485 >>Turn in Bolstering the Defenses
step << Alliance
.isOnQuest 32637
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.dailyturnin 32637 >>Turn in Overpowered
step << Alliance
.isOnQuest 32635
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.dailyturnin 32635 >>Turn in Enough with the Bombs!
step << Alliance
.isOnQuest 32636
.goto 504,63.243152,72.225666
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.dailyturnin 32636 >>Turn in Captive Audience
step << Alliance
.isOnQuest 32301
.goto 504,63.255243,72.131335
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
.dailyturnin 32301 >>Turn in Old Enemies
step << Alliance
.isQuestTurnedIn 32301,32627,32632,32633,32485,32636,32635,32637,32634,32639,32638,32628
.goto 504,63.242,72.226
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.daily 32631 >>Accept High Recognition
.dailyturnin 32631 >>Turn in High Recognition
step
+|cRXP_WARN_You have completed all available daily quests on the Isle of Thunder for today. Load the same guide again tomorrow once the daily quests have reset to complete more daily quests|r
]])

RXPGuides.RegisterGuide([[#mop
#name Landfall
#group RXP-Pandaria
#internal
step
#completewith next
.zone 390 >> Travel to the Shrine of Two Moons << Horde
.zone 390 >> Travel to the Shrine of Seven Stars << Alliance
step << Horde
.goto 390/870,936.100,1563.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sunwalker Dezco|r
.target Sunwalker Dezco
.accept 32249 >>Accept Meet the Scout
step << Alliance
.goto 390/870,346.600,832.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lyalia|r
.target Lyalia
.accept 32246 >>Accept Meet the Scout
step
#completewith DailyStart
.zone 418 >> Travel to Krasarang Wilds
step << Horde
.goto 418/870,2538.500,-2121.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Rokla|r
.target Scout Rokla
.turnin 32249 >>Turn in Meet the Scout
.timer 33,Garrosh Hellscream RP
step << Horde
.goto 418/870,2541.500,-2124.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garrosh Hellscream|r
.target Garrosh Hellscream
.accept 32250 >>Accept The Might of the Warchief
step << Horde
#completewith GrizzleGearslip
>>Kill |cRXP_ENEMY_Alliance Sentinels|r, |cRXP_ENEMY_Alliance Footmen|r and |cRXP_ENEMY_Alliance Priests|r
.complete 32250,1 
.mob Alliance Sentinel
.mob Alliance Footman
.mob Alliance Priest
step << Horde
.goto 418/870,2446.000,-1771.500
>>Head to |cRXP_FRIENDLY_Blood Guard Gro'tash|r and kill any |cRXP_ENEMY_Alliance|r around him
.complete 32250,2 
.target Blood Guard Gro'tash
.skipgossip
step << Horde
#label GrizzleGearslip
.goto 418/870,2210.600,-1915.300
>>Head to |cRXP_FRIENDLY_Grizzle Gearslip|r and kill any |cRXP_ENEMY_Alliance|r around him
.complete 32250,3 
.target Grizzle Gearslip
.skipgossip
step << Horde
#loop
.goto 418/870,2380.300,-1806.400,60,0
.goto 418/870,2388.500,-2158.500,60,0
.goto 418/870,2487.300,-2086.900,60,0
>>Kill |cRXP_ENEMY_Alliance Sentinels|r, |cRXP_ENEMY_Alliance Footmen|r and |cRXP_ENEMY_Alliance Priests|r
.complete 32250,1 
.mob Alliance Sentinel
.mob Alliance Footman
.mob Alliance Priest
step << Horde
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garrosh Hellscream|r beside you
.turnin 32250 >>Turn in The Might of the Warchief
.accept 32108 >>Accept Domination Point
.target Garrosh Hellscream
step << Horde
.goto 418/870,2548.100,-2106.000
>>Click the |cRXP_PICK_Signal Fire|r
.turnin 32108 >>Turn in Domination Point
step << Horde
.goto 418/870,2461.100,-1789.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
.target General Nazgrim
.accept 32251 >>Accept Dagger in the Dark
step << Horde
.isOnQuest 32251
.goto 418/870,2461.100,-1789.200
.gossipoption 130650 >>Talk to |cRXP_FRIENDLY_General Nazgrim|r
.target General Nazgrim
step << Horde
.isOnQuest 32251
.zone 488 >> |cRXP_WARN_Accept the Dagger in the Dark queue in a brief moment|r
step << Horde
.goto 488,56.080,75.201
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vol'jin|r
.target Vol'jin
.turnin 32251 >>Turn in Dagger in the Dark
step << Horde
.goto 488,56.080,75.201
.gossipoption 41344 >> Talk to |cRXP_FRIENDLY_Vol'jin|r to begin
.skipgossip
.target Vol'jin
.zoneskip 488,1
step << Horde
.goto 488,51.866,43.047
.vehicle >> Kill the |cRXP_ENEMY_Saurok|r and the |cRXP_ENEMY_Darkhatched Lizard-Lord|r
>>Click on the |cRXP_PICK_Spring Saurok-Slayer|r boat once |cRXP_FRIENDLY_Grizzle|r has made it ready
.mob Darkhatched Lizard-Lord
.zoneskip 488,1
step << Horde
.goto 489,50.341,51.149,5 >>|cRXP_WARN_Cast|r |T135265:0|t[Living Flames] (1) |cRXP_WARN_five times followed by|r |T135818:0|t[Flame Extension] (2) |cRXP_WARN_on the|r |cRXP_ENEMY_Saurok|r
>>|cRXP_WARN_Cast|r |T369278:0|t[Cluster Rocket] (3) |cRXP_WARN_and|r |T135735:0|t[Portable Wormhole] (4) |cRXP_WARN_when other spells are on cooldown|r
.zoneskip 488,1
step << Horde
.goto 489,54.762,30.543
>>Head to the Dark Rookery and kill |cRXP_ENEMY_Broodmaster Noshi|r
.mob Broodmaster Noshi
.zoneskip 488,1
step << Horde
.goto 489,51.568,34.184
.cast 133749 >> Click the first |cRXP_PICK_Broken Mogu Tablet|r
.zoneskip 489,1
step << Horde
.goto 489,54.939,16.288
.cast 133750 >> Click the second |cRXP_PICK_Broken Mogu Tablet|r
.zoneskip 489,1
step << Horde
.goto 489,54.355,29.271
.gossipoption 41764 >>Kill |cRXP_ENEMY_Rak'gor Bloodrazor|r
>>Talk to |cRXP_FRIENDLY_Vol'jin|r afterwards
.skipgossip
.mob Rak'gor Bloodrazor
.target Vol'jin
.zoneskip 489,1
step << Horde
.zone 418 >> Leave the Scenario
.zoneskip 489,1
step << Alliance
.goto 418/870,-1047.800,-1020.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Scout Lynna|r
.target Scout Lynna
.turnin 32246 >>Turn in Meet the Scout
.timer 33,King Varian Wrynn RP
step << Alliance
.goto 418/870,-1050.100,-1020.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Varian Wrynn|r
.target King Varian Wrynn
.accept 32247 >>Accept A King Among Men
step << Alliance
#completewith HildaHornswaggle
>>Kill |cRXP_ENEMY_Horde Raiders|r, |cRXP_ENEMY_Horde Priests|r and |cRXP_ENEMY_Horde Hunters|r
.complete 32247,1 
.mob Horde Raider
.mob Horde Priest
.mob Horde Hunter
step << Alliance
.goto 418/870,-784.900,-893.000
>>Head to |cRXP_FRIENDLY_Marshal Troteman|r and kill any |cRXP_ENEMY_Horde|r around him
.complete 32247,2 
.target Marshal Troteman
.skipgossip
step << Alliance
#label HildaHornswaggle
.goto 418/870,-822.200,-658.300
>>Head to |cRXP_FRIENDLY_Hilda Hornswaggle|r and kill any |cRXP_ENEMY_Horde|r around her
.complete 32247,3 
.target Hilda Hornswaggle
.skipgossip
step << Alliance
#loop
.goto 418/870,-1073.100,-848.300,60,0
.goto 418/870,-886.500,-872.100,60,0
.goto 418/870,-863.600,-725.600,60,0
>>Kill |cRXP_ENEMY_Horde Raiders|r, |cRXP_ENEMY_Horde Priests|r and |cRXP_ENEMY_Horde Hunters|r
.complete 32247,1 
.mob Horde Raider
.mob Horde Priest
.mob Horde Hunter
step << Alliance
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Varian Wrynn|r beside you
.target King Varian Wrynn
.goto 418/870,-1084.700,-850.500
.turnin 32247 >>Turn in A King Among Men
.accept 32109 >>Accept Lion's Landing
step << Alliance
.goto 418/870,-1064.500,-1020.800
>>Click the |cRXP_PICK_Flare Launcher|r on the ground
.turnin 32109 >>Turn in Lion's Landing
step << Alliance
.goto 418/870,-1250.000,-1128.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
.target Admiral Taylor
.accept 32248 >>Accept A Little Patience
step << Alliance
.isOnQuest 32248
.goto 487,41.916,15.419
>>|cRXP_WARN_Talk to |cRXP_FRIENDLY_Admiral Taylor|r or use the Group Finder tool to queue for the Specific Scenario "A Little Patience"|r
>>Once inside, talk to |cRXP_FRIENDLY_King Varian Wrynn|r
.turnin 32248 >>Turn in A Little Patience
.skipgossip
.target Admiral Taylor
.target King Varian Wrynn
step << Alliance
.goto 487,41.591,14.181
>>Loot the |cRXP_PICK_Tool Chest|r on the ground for the |T133054:0|t[|cRXP_LOOT_Laborer's Tool|r]
.collect 92061,1
.zoneskip 487,1
step << Alliance
.goto 487,37.409,16.175
.gossipoption 41932 >> Talk to |cRXP_FRIENDLY_Ferra Pearl|r
.skipgossip
.zoneskip 487,1
.target Ferra Pearl
step << Alliance
.goto 487,32.271,59.287
.achievement 7992,1 >>|cRXP_WARN_Assist the |cRXP_FRIENDLY_Night Elves|r by killing the attackers at the construction site. Use the items and click the objects on the ground to increase the construction speed|r
.mob Wakened Mogu
.mob Bogroot
.mob Krasari Stalker
.zoneskip 487,1
step << Alliance
.goto 487,22.606,32.625
.gossipoption 41492 >> Talk to |cRXP_FRIENDLY_Elder Alder|r
.skipgossip
.target Elder Alder
.zoneskip 487,1
step << Alliance
.goto 487,47.342,54.128
.achievement 7989,1 >>|cRXP_WARN_Follow the |cRXP_FRIENDLY_Jinyu|r to the construction site. Kill the attackers and click the objects on the ground again to speed up the contruction speed|r
.zoneskip 487,1
step << Alliance
.goto 487,47.496,60.591
.achievement 7988,1 >> Kill |cRXP_ENEMY_Commander Scargash|r
.mob Commander Scargash
.zoneskip 487,1
step << Alliance
.zone 418 >> Leave the Scenario
.zoneskip 487,1
step << Horde
#label DailyStart
.isQuestOffered 67880,32235,32449,32450
.goto 418/870,2475.400,-1793.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
>>|cRXP_WARN_Skip this step if he is not offering a quest|r
.target Blood Guard Gro'tash
.daily 32235,32449,32450 >>Accept the random daily quest
.landfall unknown
step << Horde
.skipOnQuest 32235,DominancePoint
step << Horde
.skipOnQuest 32449,Ogudei
step << Horde
.skipOnQuest 32450,LionsLanding
step << Horde
.goto 418/870,2351.400,-1882.100
>>Click the |cRXP_PICK_Bounty Board|r
.daily 32223,32222 >>Accept the random daily quest
.landfall unknown
step << Horde
.goto 418/870,2342.600,-1864.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r
.target Rivett Clutchpop
.daily 32221,32214 >>Accept the random daily quest
.landfall unknown
step << Horde
.goto 418/870,2302.400,-1853.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke|r
.target Duke
.daily 32199,32197 >>Accept the random daily quest
.landfall unknown
step << Horde
.goto 418/870,2301.500,-1855.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss-Lady Trixel|r
.target Boss-Lady Trixel
.daily 32138,32136,32140 >>Accept the random daily quest
.landfall unknown
step << Horde
.isOnQuest 32222
.goto 418/870,1932.000,-1709.700
>>Kill |cRXP_ENEMY_Chief Engineer Cogwrench|r
.complete 32222,1 
.mob Chief Engineer Cogwrench
step << Horde
.isOnQuest 32138
.goto 418/870,1988.000,-1924.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zino "The Shredder" Quickchop|r
.dailyturnin 32138 >>Turn in Work Order: Lumber
.daily 32139 >>Accept Stacked!
.target Zino "The Shredder" Quickchop
step << Horde
#optional
.isQuestTurnedIn 32138
.goto 418/870,1988.000,-1924.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zino "The Shredder" Quickchop|r
.daily 32139 >>Accept Stacked!
.target Zino "The Shredder" Quickchop
step << Horde
.isQuestTurnedIn 32138
.goto 418/870,1982.400,-1924.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixy Buzzsaw|r
.target Bixy Buzzsaw
.daily 32238 >>Accept Universal Remote-Explode
step << Horde
.isOnQuest 32140
.goto 418/870,1889.900,-2059.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daxil "The Gem" Oregrind|r
.dailyturnin 32140 >>Turn in Work Order: Iron
.daily 32141 >> Accept Power Metal
.target Daxil "The Gem" Oregrind
step << Horde
.isQuestTurnedIn 32140
.goto 418/870,1889.900,-2059.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Daxil "The Gem" Oregrind|r
.daily 32141 >> Accept Power Metal
.target Daxil "The Gem" Oregrind
step << Horde
.isQuestTurnedIn 32140
.goto 418/870,1898.700,-2056.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixy Buzzsaw|r
.target Bixy Buzzsaw
.daily 32236 >> Accept Bug Off!
step << Horde
.isOnQuest 32136
.goto 418/870,1750.800,-2000.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grizzle Gearslip|r
.target Grizzle Gearslip
.dailyturnin 32136 >>Turn in Work Order: Fuel
.daily 32137 >>Accept Runnin' On Empty
step << Horde
#optional
.isQuestTurnedIn 32136
.goto 418/870,1750.800,-2000.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grizzle Gearslip|r
.target Grizzle Gearslip
.daily 32137 >>Accept Runnin' On Empty
step << Horde
.isQuestTurnedIn 32136
.goto 418/870,1764.300,-1998.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixy Buzzsaw|r
.target Bixy Buzzsaw
.daily 32237 >>Accept Precious Resource
step << Horde
.isOnQuest 32141,32236
#completewith ShaleSpider
.goto 418/870,1940.000,-2031.100,10 >> Enter Daxil's Dig
step << Horde
.isOnQuest 32141
#loop
#completewith ShaleSpider
.goto 418/870,1994.800,-2062.600,25,0
.goto 418/870,2071.900,-2030.600,25,0
>>Click the |cRXP_PICK_Energized Iron|r deposits. Loot the |cRXP_LOOT_Energized Iron Ore Chunks|r on the ground
.complete 32141,1 
step << Horde
.isOnQuest 32236
#loop
#label ShaleSpider
.goto 418/870,1994.800,-2062.600,25,0
.goto 418/870,2071.900,-2030.600,25,0
.use 93026 >> |cRXP_WARN_Use the|r |T609616:0|t[Hand-Dandy Bug Off Sprayer] |cRXP_WARN_on|r |cRXP_ENEMY_Agitated Shale Spiders|r
>>Kill the |cRXP_ENEMY_Shale Shards|r that spawn from |cRXP_ENEMY_Agitated Shale Spiders|r
.complete 32236,1 
.mob +Agitated Shale Spider
.complete 32236,2 
step << Horde
.isOnQuest 32141
#loop
.goto 418/870,1994.800,-2062.600,25,0
.goto 418/870,2071.900,-2030.600,25,0
>>Click the |cRXP_PICK_Energized Iron|r deposits. Loot the |cRXP_LOOT_Energized Iron Ore Chunks|r on the ground
.complete 32141,1 
step << Horde
.isOnQuest 32236
.goto 418/870,1898.700,-2056.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixy Buzzsaw|r
.target Bixy Buzzsaw
.dailyturnin 32236 >> Turn in Bug Off!
step << Horde
.isOnQuest 32221
#sticky
#label Shieldwallforces
#loop
.waypoint 418,22.0,49.2,70,0
.waypoint 418,25.0,55.0,70,0
.waypoint 418,17.4,70.2,70,0
.waypoint 418,10.6,61.2,70,0
>>Kill the |cRXP_ENEMY_Shieldwall forces|r
.complete 32221,1 
step << Horde
.isOnQuest 32199
#sticky
#label ViseclawMeat
#loop
.waypoint 418,26.6,61.8,70,0
.waypoint 418,21.2,68.2,70,0
.waypoint 418,18.0,54.2,70,0
>>Kill |cRXP_ENEMY_Polluted Viseclaws|r. Loot them for their |cRXP_LOOT_Polluted Viseclaw Meat|r
.complete 32199,1 
.mob Polluted Viseclaw Fry
.mob Polluted Viseclaw
.mob Polluted Viseclaw Scuttler
step << Horde
.isOnQuest 32139
#sticky
#label DominationLumber
#loop
.waypoint 418,19.4,63.5,45,0
.waypoint 418,21.2,58.4,45,0
.waypoint 418,21.7,48.9,45,0
>>Click the |cRXP_PICK_Domination Point Lumber|r on the ground
.complete 32139,1 
step << Horde
.isOnQuest 32238
#sticky
#label ShieldwallPounder
#loop
.waypoint 418,20.4,63.6,60,0
.waypoint 418,19.8,58.4,60,0
.waypoint 418,21.6,51.2,60,0
.waypoint 418,25.0,54.0,60,0
>>Kill |cRXP_ENEMY_Shieldwall Mecha-Pounders|r
.use 91902 >> |cRXP_WARN_Use the|r |T133015:0|t[Universal Remote] |cRXP_WARN_to weaken them|r
.complete 32238,1 
.mob Shieldwall Mecha-Pounder
step << Horde
.isOnQuest 32214
#sticky
#label SI7
#loop
.waypoint 418,25.8,59.0,70,0
.waypoint 418,21.8,54.0,70,0
.waypoint 418,19.2,63.0,70,0
.waypoint 418,19.2,63.0,70,0
.waypoint 418,15.6,58.6,70,0
.waypoint 418,11.6,64.6,70,0
.waypoint 418,9.6,60.0,70,0
>>Kill |cRXP_ENEMY_SI:7 Saboteurs|r
.use 92475 >> |cRXP_WARN_Use the|r |T644269:0|t["New" and "Improved" Infrared Heat Focals] |cRXP_WARN_so you can see them|r
.complete 32214,1 
.mob SI:7 Saboteur
step << Horde
.isOnQuest 32197
#sticky
#label MysteryMeat
#loop
.waypoint 418,26.4,62.6,70,0
.waypoint 418,22.4,67.2,70,0
.waypoint 418,21.2,71.4,70,0
.waypoint 418,16.2,64.2,70,0
.waypoint 418,17.8,54.8,70,0
>>Kill |cRXP_ENEMY_Polluted Viseclaws|r and |cRXP_ENEMY_Terrapins|r. Loot them for their |cRXP_LOOT_Chunks of Mystery Meat|r
.complete 32197,1 
.mob Mature Terrapin
.mob Polluted Viseclaw
.mob Polluted Viseclaw Scuttler
.mob Terrapin Hatchling
step << Horde
.isOnQuest 32137
#sticky
#label FuelBarrel
#loop
.waypoint 418,26.1,67.1,50,0
.waypoint 418,27.9,60.0,50,0
.waypoint 418,25.1,62.2,50,0
>>Loot the |cRXP_PICK_"Distilled" Fuel|r barrels arond the rig
.complete 32137,1 
step << Horde
.isOnQuest 32237
#sticky
#label FaultyValve
#loop
.waypoint 418/870,1704.700,-2052.400,30,0
.waypoint 418/870,1660.200,-1944.700,30,0
.waypoint 418/870,1923.200,-1842.700,30,0
>>Click the |cRXP_PICK_Faulty Valves|r on the structures around the beach and on the rig
.complete 32237,1 
step << Horde
.isOnQuest 32223
#sticky
#label LEJ
.goto 418/870,2054.200,-2329.200
>>Kill |cRXP_ENEMY_Lieutenant Ethan Jacobson|r
.complete 32223,1 
.mob Lieutenant Ethan Jacobson
step << Horde
#requires Shieldwallforces
step << Horde
#requires ViseclawMeat
step << Horde
#requires DominationLumber
step << Horde
#requires ShieldwallPounder
step << Horde
#requires LEJ
step << Horde
#requires SI7
step << Horde
#requires MysteryMeat
step << Horde
#requires FuelBarrel
step << Horde
#requires FaultyValve
step << Horde
.isOnQuest 32197
.goto 418/870,1726.300,-1924.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sezik Steampot|r
.target Sezik Steampot
.dailyturnin 32197 >>Turn in Mystery Meatloaf
step << Horde
.isOnQuest 32199
.goto 418/870,1726.300,-1924.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sezik Steampot|r
.target Sezik Steampot
.dailyturnin 32199 >>Turn in Krasarang Steampot
step << Horde
.isOnQuest 32237
.goto 418/870,1764.200,-1998.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixy Buzzsaw|r
.target Bixy Buzzsaw
.dailyturnin 32237 >>Turn in Precious Resource
step << Horde
.isOnQuest 32238
.goto 418/870,1982.400,-1924.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bixy Buzzsaw|r
.target Bixy Buzzsaw
.dailyturnin 32238 >>Turn in Universal Remote-Explode
step << Horde
.isOnQuest 32139
.goto 418/870,1988.000,-1924.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zino "The Shredder" Quickchop|r
.dailyturnin 32139 >>Turn in Stacked!
.target Zino "The Shredder" Quickchop
step << Horde
.isOnQuest 32137
.goto 418/870,2301.400,-1855.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss-Lady Trixel|r
.target Boss-Lady Trixel
.dailyturnin 32137 >>Turn in Runnin' On Empty
step << Horde
.isOnQuest 32141
.goto 418/870,2301.400,-1855.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Boss-Lady Trixel|r
.target Boss-Lady Trixel
.dailyturnin 32141 >>Turn in Power Metal
step << Horde
.isOnQuest 32214
.goto 418/870,2342.600,-1864.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r
.target Rivett Clutchpop
.dailyturnin 32214 >>Turn in Bilgewater Infiltrators
step << Horde
.isOnQuest 32221
.goto 418/870,2342.600,-1864.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rivett Clutchpop|r
.target Rivett Clutchpop
.dailyturnin 32221 >>Turn in Bilgewater Infiltrators
step << Horde
.isOnQuest 32222
.goto 418/870,2475.400,-1793.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
.target Blood Guard Gro'tash
.turnin 32222 >>Turn in Wanted: Chief Engineer Cogwrench
step << Horde
.isOnQuest 32222
.goto 418/870,2475.400,-1793.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
.target Blood Guard Gro'tash
.turnin 32222 >>Turn in Wanted: Chief Engineer Cogwrench
step << Horde
.isOnQuest 32223
.goto 418/870,2475.400,-1793.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
.target Blood Guard Gro'tash
.turnin 32223 >>Turn in Wanted: Chief Engineer Cogwrench
step << Horde
#label DominancePoint
step << Horde
.goto 418/870,2475.400,-1793.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
.target Blood Guard Gro'tash
.daily 32235 >>Accept Flash! Aaaaaahhhh!
.landfall DominancePoint
step << Horde
#loop
.goto 418/870,2457.000,-1767.400,10,0
.goto 418/870,2458.600,-1796.800,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brolic|r
>>|cRXP_FRIENDLY_Brolic|r |cRXP_WARN_patrols the camp|r
.target Brolic
.daily 32126 >>Accept Tear It Up
.landfall DominancePoint
step << Horde
.goto 418/870,2463.900,-1850.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shokia|r
.target Shokia
.daily 32123 >>Accept Death on Two Legs
.landfall DominancePoint
step << Horde
.isOnQuest 32235
.goto 418/870,2422.600,-1940.600
.use 92019 >> |cRXP_WARN_Use the|r |T135815:0|t[The Bilgewater Molotov] |cRXP_WARN_on |cRXP_ENEMY_Skyfire Gyrocopter X2s|r in the air|r
>>|cRXP_WARN_You can complete this while on your flying mount|r
.complete 32235,1 
.mob Skyfire Gyrocopter X2
step << Horde
.isOnQuest 32123
#completewith next
>>Kill the |cRXP_ENEMY_Alliance|r on the beach and on the docks
.complete 32123,1 
step << Horde
.isOnQuest 32126
#loop
.goto 418/870,2590.100,-1989.400,60,0
.goto 418/870,2500.800,-2121.800,60,0
.goto 418/870,2575.100,-2236.500,60,0
>>Click the |cRXP_PICK_Alliance Supply Drops|r on the ground
.complete 32126,1 
step << Horde
.isOnQuest 32123
#loop
.goto 418/870,2590.100,-1989.400,60,0
.goto 418/870,2500.800,-2121.800,60,0
.goto 418/870,2575.100,-2236.500,60,0
>>Kill the |cRXP_ENEMY_Alliance|r on the beach and on the docks
.complete 32123,1 
step << Horde
.isOnQuest 32123
.goto 418/870,2463.900,-1850.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shokia|r
.target Shokia
.dailyturnin 32123 >>Turn in Death on Two Legs
step << Horde
.isOnQuest 32235
.goto 418/870,2475.500,-1793.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
.target Blood Guard Gro'tash
.dailyturnin 32235 >>Turn in Flash! Aaaaaahhhh!
step << Horde
#loop
.goto 418/870,2457.000,-1767.400,10,0
.goto 418/870,2458.600,-1796.800,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brolic|r
>>|cRXP_FRIENDLY_Brolic|r |cRXP_WARN_patrols the camp|r
.target Brolic
.dailyturnin 32126 >>Turn in Tear It Up
.daily 32127 >>Accept All Dead, All Dead
.landfall DominancePoint
step << Horde
.goto 418/870,2475.500,-1793.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
.target Blood Guard Gro'tash
.daily 32128 >>Accept Another One Bites the Dust
.landfall DominancePoint
step << Horde
.isOnQuest 32127
>>Kill |cRXP_ENEMY_Captain Brent the Black|r on the first floor
.goto 418/870,2348.200,-2479.000
.complete 32127,1 
.mob Captain Brent the Black
step << Horde
.isOnQuest 32128
.goto 418/870,2398.600,-2458.800,8,0
.goto 418/870,2370.000,-2472.200
>>Click the |cRXP_PICK_Powder Magazine|r on the lower level
.complete 32128,2 
step << Horde
.isOnQuest 32127
.goto 418/870,2231.300,-2497.000
>>Kill |cRXP_ENEMY_Captain Mulkey|r on the first floor
.complete 32127,2 
.mob Captain Mulkey
step << Horde
.isOnQuest 32128
.goto 418/870,2281.600,-2514.900,8,0
.goto 418/870,2240.700,-2504.700
>>Click the |cRXP_PICK_Powder Magazine|r on the lower level
.complete 32128,1 
step << Horde
.isOnQuest 32128
.goto 418/870,2475.300,-1793.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Blood Guard Gro'tash|r
.target Blood Guard Gro'tash
.dailyturnin 32128 >>Turn in Another One Bites the Dust
step << Horde
.isOnQuest 32127
#loop
.goto 418/870,2457.000,-1767.400,10,0
.goto 418/870,2458.600,-1796.800,10,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brolic|r
>>|cRXP_FRIENDLY_Brolic|r |cRXP_WARN_patrols the camp|r
.target Brolic
.dailyturnin 32127 >>Turn in All Dead, All Dead
step << Horde
#label LionsLanding
step << Horde
#completewith next
.subzone 6597 >> Travel to the Sparkrocket Outpost
step << Horde
.goto 418/870,-606.600,-1187.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r
.target Shademaster Kiryn
.dailyturnin 32450 >>Turn in The Time Is Now!
.daily 32135 >>Accept Hero Killer
.daily 32133 >>Accept Sentry Wards
.daily 32132 >>Accept Worker Harassment
.landfall LionsLanding
step << Horde
.goto 418/870,-608.000,-1178.100
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zazzix "Toasty" Sparkrocket|r
.target Zazzix "Toasty" Sparkrocket
.daily 32130,32134,32131 >> Accept all of the available daily quests
.disablecheckbox
.questcount <2,32130,32134,32131
.landfall LionsLanding
step << Horde
.isOnQuest 32133
#sticky
>>Click the |cRXP_PICK_Sentry Wards|r in the Town Hall, Docks and on the 2nd floor of the Barracks
.complete 32133,1 
.waypoint 418/870,-1096.400,-909.700,-1
.complete 32133,2 
.waypoint 418/870,-1087.900,-1146.000,-1
.complete 32133,3 
.waypoint 418/870,-1165.700,-1133.600,-1
step << Horde
.isOnQuest 32135
#sticky
#label AllianceHero
.waypoint 418,81.32,24.64
>>Kill |cRXP_ENEMY_Thane Stonehearth|r
.complete 32135,1 
.mob Thane Stonehearth
step << Horde
.isOnQuest 32132
#sticky
#label ShieldwallPeasants
#loop
.waypoint 418,80.8,20.4,60,0
.waypoint 418,84.6,23.6,60,0
>>Kill |cRXP_ENEMY_Shieldwall Peasants|r
.complete 32132,1 
.mob Shieldwall Peasant
step << Horde
.isOnQuest 32130
#sticky
#label WaxyEars
#loop
.waypoint 418/870,-1096.400,-909.700,60,0
.waypoint 418/870,-1165.700,-1133.600,60,0
.waypoint 418,80.8,20.4,60,0
.waypoint 418,84.6,23.6,60,0
>>Kill the |cRXP_ENEMY_Shieldwall Alliance|r. Loot them for their |cRXP_LOOT_Extra-Waxy Alliance Ears|r
.complete 32130,1 
step << Horde
.isOnQuest 32131
#sticky
#label AnimatableStone
.waypoint 418,78.50,18.58
>>Kill |cRXP_ENEMY_Shieldwall Engineers|r. Loot them for their |cRXP_LOOT_Animatable Stone|r
>>You can also loot |cRXP_PICK_Chunks of Stone|r on the ground for |cRXP_LOOT_Animatable Stone|r
.complete 32131,1 
.mob Shieldwall Engineer
step << Horde
.isOnQuest 32134
#sticky
#label DwarvenMortar
#loop
.waypoint 418,81.95,23.67,50,0
.waypoint 418,83.20,25.75,50,0
.waypoint 418,85.35,32.03,50,0
>>Kill |cRXP_ENEMY_Dwarven Mortar Team Engineers|r and |cRXP_ENEMY_Dwarven Mortar Tubes|r
.complete 32134,1 
.mob +Dwarven Mortar Team Engineer
.complete 32134,2 
.mob +Dwarven Mortar Tube
step << Horde
#requires AllianceHero
step << Horde
#requires ShieldwallPeasants
step << Horde
#requires WaxyEars
step << Horde
#requires AnimatableStone
step << Horde
#requires DwarvenMortar
step << Horde
.isOnQuest 32130
.goto 418/870,-608.100,-1178.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zazzix "Toasty" Sparkrocket|r
.target Zazzix "Toasty" Sparkrocket
.dailyturnin 32130 >>Turn in Good Luck, Have Fun
step << Horde
.isOnQuest 32134
.goto 418/870,-608.100,-1178.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zazzix "Toasty" Sparkrocket|r
.target Zazzix "Toasty" Sparkrocket
.dailyturnin 32134 >>Turn in Hard Counter
step << Horde
.isOnQuest 32131
.goto 418/870,-608.100,-1178.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zazzix "Toasty" Sparkrocket|r
.target Zazzix "Toasty" Sparkrocket
.dailyturnin 32131 >>Turn in We Require More Minerals!
step << Horde
.isOnQuest 32135
.goto 418/870,-606.500,-1187.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r
.target Shademaster Kiryn
.dailyturnin 32135 >>Turn in Hero Killer
step << Horde
.isOnQuest 32133
.goto 418/870,-606.500,-1187.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r
.target Shademaster Kiryn
.dailyturnin 32133 >>Turn in Sentry Wards
step << Horde
.isOnQuest 32132
.goto 418/870,-606.500,-1187.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shademaster Kiryn|r
.target Shademaster Kiryn
.dailyturnin 32132 >>Turn in Worker Harassment
step << Horde
#label Ogudei
step << Horde
#completewith next
.subzone 6597 >> Travel to the Sparkrocket Outpost
step << Horde
.goto 418/870,-629.500,-1175.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belloc Brightblade|r
.target Belloc Brightblade
.dailyturnin 32449 >>Turn in The Ruins of Ogudei
.daily 32118 >>Accept Taking Advantage
.landfall Ogudei
step << Horde
#completewith next
.goto 418/870,-624.100,-1172.300
.subzone 6609 >> Portal to Ruins of Ogudei
.landfall Ogudei
step << Horde
.goto 418/870,-871.900,-681.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaelis Sunsoar|r
.target Kaelis Sunsoar
.dailyturnin 32118 >>Turn in Taking Advantage
.daily 32342 >>Accept The Spirit Trap
.daily 32120 >>Accept Legacy of Ogudei
.daily 32343 >>Accept Ogudei's Lieutenants
.daily 32348 >>Accept Kick 'em While They're Down
.daily 32344,32345 >>Accept It Is A Mystery or We're Not Monsters!
.landfall Ogudei
step << Horde
#completewith next
.goto 418/870,-967.400,-674.600,10,0
.goto 418/870,-955.100,-649.600,12,0
.goto 418/870,-939.300,-689.100,8,0
.goto 418/870,-948.000,-744.000,8,0
.goto 418/870,-1004.900,-687.300,8,0
.goto 418/870,-1030.700,-723.500,10,0
.goto 418/870,-1015.200,-781.300,10 >>|cRXP_WARN_Follow the arrow closely to get to |cRXP_ENEMY_Gen-li|r and |cRXP_ENEMY_Meng-do|r!|r
step << Horde
#sticky
#label GenliMengdo
.isOnQuest 32343
.goto 418/870,-970.600,-821.100
>>Kill |cRXP_ENEMY_Gen-li, Twister of Words|r and |cRXP_ENEMY_Meng-do, Strength of Mountains|r. Loot them for their |cRXP_LOOT_Essence|r
.complete 32343,1 
.mob +Gen-li, Twister of Words
.complete 32343,2 
.mob +Meng-do, Strength of Mountains
step << Horde
.isOnQuest 32120
#sticky
#label MoguEssence
#loop
.waypoint 418/870,-931.500,-754.600,40,0
.waypoint 418/870,-884.600,-617.600,40,0
.waypoint 418/870,-1002.900,-605.600,40,0
.waypoint 418/870,-966.800,-745.100,40,0
>>Kill |cRXP_ENEMY_Spiritbound Arcanists|r and |cRXP_ENEMY_Spiritbound Brutalizers|r. Loot them for their |cRXP_LOOT_Ancient Mogu Essence|r
.complete 32120,1 
.mob Spiritbound Arcanist
.mob Spiritbound Brutalizer
step << Horde
.isOnQuest 32342
#sticky
#label SpiritTrap
#loop
.waypoint 418/870,-931.500,-754.600,40,0
.waypoint 418/870,-884.600,-617.600,40,0
.waypoint 418/870,-1002.900,-605.600,40,0
.waypoint 418/870,-966.800,-745.100,40,0
>>Kill |cRXP_ENEMY_Spirit Traps|r. Loot it once it falls to the ground
.complete 32342,1 
.mob Spirit Trap
step << Horde
.isOnQuest 32345
#sticky
#label SlaveSpirit
#loop
.waypoint 418/870,-931.500,-754.600,40,0
.waypoint 418/870,-884.600,-617.600,40,0
.waypoint 418/870,-1002.900,-605.600,40,0
.waypoint 418/870,-966.800,-745.100,40,0
>>Kill |cRXP_ENEMY_Troubled Slave Spirits|r
.complete 32345,1 
.mob Troubled Slave Spirit
step << Horde
.isOnQuest 32348
#sticky
#label LLM
.waypoint 418/870,-928.500,-658.500,10,0
.waypoint 418/870,-858.900,-603.700,20,0
.waypoint 418/870,-902.100,-690.400,20,0
.waypoint 418/870,-858.900,-603.700,20,0
.waypoint 418/870,-902.100,-690.400
>>Kill |cRXP_ENEMY_Shieldwall Riflemen|r, |cRXP_ENEMY_Shieldwall Footmen|r and |cRXP_ENEMY_Lion's Landing Guard Captains|r on the upper level
.complete 32348,1 
.mob Shieldwall Rifleman
.mob Shieldwall Footman
.mob Lion's Landing Guard Captain
step << Horde
.isOnQuest 32344
#label Anomalydispersed
.waypoint 418/870,-957.200,-639.600
>>Head to the arrow location on the upper level
.complete 32344,1 
step << Horde
#requires GenliMengdo
step << Horde
#requires MoguEssence
step << Horde
#requires SpiritTrap
step << Horde
#requires SlaveSpirit
step << Horde
#requires Anomalydispersed
step << Horde
#requires LLM
step << Horde
#completewith caveturnin
.goto 418/870,-949.500,-685.500,10 >> Return to |cRXP_FRIENDLY_Kaelis Sunsoar|r on the lower level
step << Horde
.isOnQuest 32342
.goto 418/870,-871.900,-681.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaelis Sunsoar|r
.target Kaelis Sunsoar
.dailyturnin 32342 >>Turn in The Spirit Trap
step << Horde
.isOnQuest 32120
.goto 418/870,-871.900,-681.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaelis Sunsoar|r
.target Kaelis Sunsoar
.dailyturnin 32120 >>Turn in Legacy of Ogudei
step << Horde
.isOnQuest 32343
.goto 418/870,-871.900,-681.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaelis Sunsoar|r
.target Kaelis Sunsoar
.dailyturnin 32343 >>Turn in Ogudei's Lieutenants
step << Horde
.isOnQuest 32348
.goto 418/870,-871.900,-681.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaelis Sunsoar|r
.target Kaelis Sunsoar
.dailyturnin 32348 >>Turn in Kick 'em While They're Down
step << Horde
.isOnQuest 32344
.goto 418/870,-871.900,-681.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaelis Sunsoar|r
.target Kaelis Sunsoar
.dailyturnin 32344 >>Turn in It Is A Mystery
step << Horde
#label caveturnin
.isOnQuest 32345
.goto 418/870,-871.900,-681.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kaelis Sunsoar|r
.target Kaelis Sunsoar
.dailyturnin 32345 >>Turn in We're Not Monsters!
step << Alliance
#label DailyStart
.isQuestOffered 68908,32452,32451
.goto 418/870,-1261.000,-1123.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amber Kearnen|r
>>|cRXP_WARN_Skip this step if she is not offering a quest|r
.target Amber Kearnen
.daily 32452,32451 >>Accept the random daily quest
.landfall unknown
step << Alliance
.skipOnQuest 32451,DominancePoint
step << Alliance
.skipOnQuest 32452,BilgewaterOperations
step << Alliance
.isQuestOffered 67631,32116
.goto 418/870,-1256.200,-1144.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Troteman|r
>>|cRXP_WARN_Skip this step if he is not offering a quest|r
.target Marshal Troteman
.daily 32116 >>Accept Priorities, People!
.landfall unknown
step << Alliance
.skipOnQuest 32116,RuinsofOgudei
step << Alliance
.goto 418/870,-1256.200,-1144.200
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Troteman|r
.daily 32148,32151,32153,32152 >> Accept all of the available daily quests
.disablecheckbox
.questcount <3,32148,32151,32153,32152
.target Marshal Troteman
.landfall unknown
step << Alliance
.goto 418/870,-1255.300,-1135.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r
.target Mishka
.daily 32149 >>Accept Resource Gathering
.daily 32150 >>Accept Supply Block
.landfall unknown
step << Alliance
.isOnQuest 32148
#sticky
#label DominanceShamRaid
#loop
.waypoint 418,81.0,25.6,70,0
.waypoint 418,78.8,27.4,70,0
.waypoint 418,78.0,32.8,70,0
>>Kill |cRXP_ENEMY_Dominance Shaman|r and |cRXP_ENEMY_Dominance Raiders|r
.complete 32148,1 
.mob Dominance Shaman
.mob Dominance Raider
step << Alliance
.isOnQuest 32152
#sticky
#label BlastingCap
>>Kill |cRXP_ENEMY_Bilgewater Sappers|r. Loot them for a |cRXP_LOOT_Bilgewater Blasting Cap|r
>>Click on a |cRXP_PICK_Domination Point Demolisher|r once you have a |cRXP_LOOT_Bilgewater Blasting Cap|r
.complete 32152,1 
.waypoint 418,77.0,18.8
.mob +Bilgewater Sapper
.complete 32152,2 
.waypoint 418,78.68,28.17
.mob +Domination Point Demolisher
step << Alliance
.isOnQuest 32151
#sticky
#label AnimatableStone
.waypoint 418,78.50,18.58
>>Kill |cRXP_ENEMY_Bilgewater Sappers|r. Loot them for their |cRXP_LOOT_Animatable Stone|r
>>You can also loot |cRXP_PICK_Chunks of Stone|r on the ground for |cRXP_LOOT_Animatable Stone|r
.complete 32151,1 
.mob Bilgewater Sapper
step << Alliance
.isOnQuest 32153
#sticky
#label Mazuru
.waypoint 418,79.26,27.47
>>Kill |cRXP_ENEMY_Mazuru|r
.complete 32153,1 
.mob Mazuru
step << Alliance
.isOnQuest 32153
#sticky
#label Lumber
#loop
.waypoint 418,82.2,17.9,50,0
.waypoint 418,77.5,28.0,50,0
.waypoint 418,77.5,22.0,50,0
>>Loot the |cRXP_PICK_Hastily Abandoned Lumber|r on the ground for |cRXP_LOOT_Lion's Landing Lumber|r
.complete 32149,1 
step << Alliance
.isOnQuest 32150
#sticky
#label DPSupplies
#loop
.waypoint 418,79.0,28.2,40,0
.waypoint 418,76.6,29.0,40,0
.waypoint 418,78.2,32.8,40,0
>>Destroy the |cRXP_PICK_Domination Point Supply Carts|r
.complete 32150,1 
.mob Domination Point Supply Carts
step << Alliance
#requires DominanceShamRaid
step << Alliance
#requires BlastingCap
step << Alliance
#requires AnimatableStone
step << Alliance
#requires Mazuru
step << Alliance
#requires Lumber
step << Alliance
#requires DPSupplies
step << Alliance
.isOnQuest 32149
.goto 418/870,-1255.300,-1135.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r
.target Mishka
.dailyturnin 32149 >>Turn in Resource Gathering
step << Alliance
.isOnQuest 32150
.goto 418/870,-1255.300,-1135.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r
.target Mishka
.dailyturnin 32150 >>Turn in Supply Block
step << Alliance
.isOnQuest 32148
.goto 418/870,-1256.300,-1144.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Troteman|r
.target Marshal Troteman
.dailyturnin 32148 >>Turn in Attack! Move!
step << Alliance
.isOnQuest 32151
.goto 418/870,-1256.300,-1144.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Troteman|r
.target Marshal Troteman
.dailyturnin 32151 >>Turn in Tower Defense
step << Alliance
.isOnQuest 32153
.goto 418/870,-1256.300,-1144.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Troteman|r
.target Marshal Troteman
.dailyturnin 32153 >>Turn in Hero Killer
step << Alliance
.isOnQuest 32152
.goto 418/870,-1256.300,-1144.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Troteman|r
.target Marshal Troteman
.dailyturnin 32152 >>Turn in Siege Damage
step << Alliance
#label DominancePoint
step << Alliance
#completewith DPAccept
.goto 418/870,2175.500,-2585.400,20 >> Travel to the Skyfire airship
step << Alliance
.isOnQuest 32451
.goto 418/870,2175.500,-2585.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sky Admiral Rogers|r
.target Sky Admiral Rogers
.dailyturnin 32451 >>Turn in Send a Message
step << Alliance
.goto 418/870,2175.500,-2585.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sky Admiral Rogers|r
.target Sky Admiral Rogers
.daily 32142 >>Accept We Will Rock You
.daily 32146 >>Accept Hammer to Fall
.landfall DominancePoint
step << Alliance
.goto 418/870,2166.900,-2564.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r
.target Mishka
.daily 32144 >>Accept Under Pressure
.landfall DominancePoint
step << Alliance
#label DPAccept
.goto 418/870,2163.300,-2600.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkmaster Overspark|r
.target Tinkmaster Overspark
.daily 32143 >>Accept A Kind of Magic
.landfall DominancePoint
step << Alliance
.isOnQuest 32146
#sticky
#label HeavyMook
#loop
.waypoint 418,9.4,61.6,60,0
.waypoint 418,12.0,65.4,60,0
.waypoint 418,12.6,58.8,60,0
>>Kill |cRXP_ENEMY_Heavy Mooks|r
.complete 32146,1 
.mob Heavy Mook
step << Alliance
.isOnQuest 32144
#sticky
#label HSC
#loop
.waypoint 418,12.5,55.2,60,0
.waypoint 418,10.9,58.7,60,0
.waypoint 418,12.5,64.0,60,0
.waypoint 418,8.6,66.5,60,0
>>Click the |cRXP_PICK_Horde Supply Crates|r on the ground
.complete 32144,1 
step << Alliance
.isOnQuest 32142
#sticky
#label Hordeslain
#loop
.waypoint 418,9.4,61.6,60,0
.waypoint 418,12.0,65.4,60,0
.waypoint 418,12.6,58.8,60,0
>>Kill the |cRXP_ENEMY_Horde|r
.complete 32142,1 
step << Alliance
.isOnQuest 32143
.goto 418/870,2402.100,-2234.800
>>Click the |cRXP_PICK_Scout-o-Meter Mk I|r on the ground
.complete 32143,1 
step << Alliance
.isOnQuest 32143
.goto 418/870,2441.200,-2013.500
>>Click the |cRXP_PICK_Scout-o-Meter Mk II|r on the ground
.complete 32143,2 
step << Alliance
.isOnQuest 32143
>>Click on the quest popup under your minimap to turn in the quest
.dailyturnin 32143 >>Turn in A Kind of Magic
.daily 32145 >>Accept Don't Lose Your Head
.landfall DominancePoint
step << Alliance
>>Click on the quest popup under your minimap to turn in the quest
.daily 32145 >>Accept Don't Lose Your Head
.landfall DominancePoint
step << Alliance
.isOnQuest 32145
.goto 418/870,2322.900,-1868.600
>>Kill |cRXP_ENEMY_Chief Bombgineer Snicklefritz|r
.complete 32145,3 
.mob Chief Bombgineer Snicklefritz
step << Alliance
.isOnQuest 32145
.goto 418/870,2320.100,-1919.600
>>Kill |cRXP_ENEMY_Stone Guard Ruk'Ra|r
.complete 32145,2 
.mob Stone Guard Ruk'Ra
step << Alliance
.isOnQuest 32145
.goto 418/870,2455.800,-1916.600
>>Kill |cRXP_ENEMY_Or'Dac|r
.complete 32145,1 
step << Alliance
#requires HeavyMook
step << Alliance
#requires HSC
step << Alliance
#requires Hordeslain
step << Alliance
.isOnQuest 32144
.goto 418/870,2167.000,-2564.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r
.target Mishka
.dailyturnin 32144 >>Turn in Under Pressure
step << Alliance
.isOnQuest 32142
.goto 418/870,2175.500,-2585.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sky Admiral Rogers|r
.target Sky Admiral Rogers
.dailyturnin 32142 >>Turn in We Will Rock You
step << Alliance
.isOnQuest 32146
.goto 418/870,2175.500,-2585.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sky Admiral Rogers|r
.target Sky Admiral Rogers
.dailyturnin 32146 >>Turn in Hammer to Fall
step << Alliance
.isOnQuest 32145
.goto 418/870,2163.200,-2600.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkmaster Overspark|r
.target Tinkmaster Overspark
.dailyturnin 32145 >>Turn in Don't Lose Your Head
step << Alliance
#label RuinsofOgudei
step << Alliance
#completewith next
.subzone 6609 >> Travel to the Ruins of Ogudei
step << Alliance
.goto 418/870,-810.900,-623.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.dailyturnin 32116 >>Turn in Priorities, People!
.daily 32121 >>Accept The Spirit Trap
.daily 32347 >>Accept Eviction Notice
.daily 32346 >>Accept Oi Ain't Afraid o' No Ghosts!
.daily 32122 >>Accept Ogudei's Lieutenants
.daily 32119,32115 >>Accept It Is A Mystery or Shackles of the Past
.landfall Ogudei
step << Alliance
#completewith next
.goto 418/870,-908.500,-663.700,10,0
.goto 418/870,-949.900,-744.000,10,0
.goto 418/870,-1004.200,-687.900,10,0
.goto 418/870,-1019.900,-753.900,10,0
.goto 418/870,-1008.500,-785.600,15 >>|cRXP_WARN_Follow the arrow closely to get to |cRXP_ENEMY_Gen-li|r and |cRXP_ENEMY_Meng-do|r!|r
step << Alliance
#sticky
#label GenliMengdo
.isOnQuest 32122
.goto 418/870,-970.600,-821.100
>>Kill |cRXP_ENEMY_Gen-li, Twister of Words|r and |cRXP_ENEMY_Meng-do, Strength of Mountains|r
.complete 32122,1 
.mob +Gen-li, Twister of Words
.complete 32122,2 
.mob +Meng-do, Strength of Mountains
step << Alliance
.isOnQuest 32346
#sticky
#label MoguEssence
#loop
.waypoint 418/870,-931.500,-754.600,40,0
.waypoint 418/870,-884.600,-617.600,40,0
.waypoint 418/870,-1002.900,-605.600,40,0
.waypoint 418/870,-966.800,-745.100,40,0
>>Kill |cRXP_ENEMY_Spiritbound Arcanists|r and |cRXP_ENEMY_Spiritbound Brutalizers|r
.complete 32346,1 
.mob Spiritbound Arcanist
.mob Spiritbound Brutalizer
step << Alliance
.isOnQuest 32121
#sticky
#label SpiritTrap
#loop
.waypoint 418/870,-931.500,-754.600,40,0
.waypoint 418/870,-884.600,-617.600,40,0
.waypoint 418/870,-1002.900,-605.600,40,0
.waypoint 418/870,-966.800,-745.100,40,0
>>Kill |cRXP_ENEMY_Spirit Traps|r
.complete 32121,1 
.mob Spirit Trap
step << Alliance
.isOnQuest 32115
#sticky
#label SlaveSpirit
#loop
.waypoint 418/870,-931.500,-754.600,40,0
.waypoint 418/870,-884.600,-617.600,40,0
.waypoint 418/870,-1002.900,-605.600,40,0
.waypoint 418/870,-966.800,-745.100,40,0
>>Kill |cRXP_ENEMY_Troubled Slave Spirits|r
.complete 32115,1 
.mob Troubled Slave Spirit
step << Alliance
.isOnQuest 32119
#label Anomalydispersed
.waypoint 418/870,-957.200,-639.600
>>Head to the arrow location on the upper level
.complete 32119,1 
step << Alliance
.isOnQuest 32347
#sticky
#label LLM
.waypoint 418/870,-947.200,-685.800,10,0
.goto 418/870,-967.900,-691.300,12,0
.waypoint 418/870,-911.300,-725.200,40,0
.waypoint 418/870,-899.100,-674.200,40,0
.waypoint 418/870,-911.300,-725.200,40,0
.waypoint 418/870,-899.100,-674.200
>>Kill |cRXP_ENEMY_Reliquary Scouts|r, |cRXP_ENEMY_Reliquary Mages|r, |cRXP_ENEMY_Reliquary Blood Knights|r and |cRXP_ENEMY_Reliquary Commanders|r on the lower level
.complete 32347,1 
.mob Reliquary Scout
.mob Reliquary Mage
.mob Reliquary Blood Knight
.mob Reliquary Commander
step << Alliance
#requires GenliMengdo
step << Alliance
#requires MoguEssence
step << Alliance
#requires SpiritTrap
step << Alliance
#requires SlaveSpirit
step << Alliance
#requires Anomalydispersed
step << Alliance
#requires LLM
step << Alliance
#completewith ogudeiturnins
.goto 418/870,-928.500,-658.500,10,0
.goto 418/870,-810.900,-623.100,15 >> Return to |cRXP_FRIENDLY_Hilda Hornswaggle|r on the upper level
step << Alliance
.isOnQuest 32121
.goto 418/870,-810.900,-623.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.dailyturnin 32121 >>Turn in The Spirit Trap
step << Alliance
.isOnQuest 32347
.goto 418/870,-810.900,-623.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.dailyturnin 32347 >>Turn in Eviction Notice
step << Alliance
.isOnQuest 32346
.goto 418/870,-810.900,-623.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.dailyturnin 32346 >>Turn in Oi Ain't Afraid o' No Ghosts!
step << Alliance
.isOnQuest 32122
.goto 418/870,-810.900,-623.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.dailyturnin 32122 >>Turn in Ogudei's Lieutenants
step << Alliance
.isOnQuest 32119
.goto 418/870,-810.900,-623.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.dailyturnin 32119 >>Turn in It Is A Mystery
step << Alliance
#label ogudeiturnins
.isOnQuest 32115
.goto 418/870,-810.900,-623.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.dailyturnin 32115 >>Turn in Shackles of the Past
step << Alliance
#label BilgewaterOperations
step << Alliance
#completewith BilgewaterAccept
.goto 418/870,2175.500,-2585.400,20 >> Travel to the Skyfire airship
step << Alliance
.isOnQuest 32452
.goto 418/870,2175.500,-2585.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sky Admiral Rogers|r
.target Sky Admiral Rogers
.dailyturnin 32452 >>Turn in And Then There Were Goblins
step << Alliance
#label BilgewaterAccept
#loop
.goto 418/870,2175.500,-2585.300,5,0
.goto 418/870,2167.000,-2564.400,5,0
.goto 418/870,2164.700,-2564.700,5,0
.goto 418/870,2138.500,-2568.400,5,0
+|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sky Admiral Rogers|r, |cRXP_FRIENDLY_Mishka|r, |cRXP_FRIENDLY_Seraphine of the Winter|r and |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r
.target Sky Admiral Rogers
.target Mishka
.target Seraphine of the Winter
.target Sully "The Pickle" McLeary
.daily 32157,32156,32158,32433,32154,32155,32446,32159 >> Accept all of the available daily quests
.disablecheckbox
.questcount <4,32157,32156,32158,32433,32154,32155,32446,32159
.landfall Bilgewater
step << Alliance
.isOnQuest 32157
#sticky
#label BilgewaterGoblins
#loop
.waypoint 418,19.6,63.6,60,0
.waypoint 418,20.6,59.8,60,0
.waypoint 418,22.8,51.8,60,0
.waypoint 418,25.4,53.4,60,0
>>Kill |cRXP_ENEMY_Bilgewater Goblins|r
.complete 32157,1 
.mob Bilgewater Logger
.mob Grease Worker
.mob Refining Specialist
.mob Off-Duty Logger
step << Alliance
.isOnQuest 32156
#sticky
#label DogTag
#loop
.waypoint 418,19.6,63.6,60,0
.waypoint 418,20.6,59.8,60,0
.waypoint 418,22.8,51.8,60,0
.waypoint 418,25.4,53.4,60,0
>>Loot the |cRXP_FRIENDLY_Fallen Shieldwall Soldiers|r for their |cRXP_LOOT_Shieldwall Soldier Dog Tags|r
.complete 32156,1 
.target Fallen Shieldwall Soldier
step << Alliance
.isOnQuest 32154
#sticky
#label TanksDestroyed
#loop
.use 93187 >> |cRXP_WARN_Use the|r |T133717:0|t[Unstable Explosive] |cRXP_WARN_next to the |cRXP_PICK_Goblin Explosive Crates|r at the specific locations|r
.complete 32154,1 
.waypoint 418/870,1754.500,-1968.100,-1
.complete 32154,2 
.waypoint 418/870,1826.800,-1817.300,-1
.complete 32154,3 
.waypoint 418/870,2232.300,-1953.800,-1
step << Alliance
.isOnQuest 32155
#sticky
#label RustyValve
#loop
.waypoint 418,15.1,58.2,45,0
.waypoint 418,19.5,55.2,45,0
.waypoint 418,24.0,57.6,45,0
.waypoint 418,26.7,61.3,45,0
>>Loot the |cRXP_PICK_Rusty Valves|r
.complete 32155,1 
step << Alliance
.isOnQuest 32446
#sticky
#label JungleShredder
#loop
.waypoint 418,19.6,63.6,60,0
.waypoint 418,20.6,59.8,60,0
.waypoint 418,22.8,51.8,60,0
.waypoint 418,25.4,53.4,60,0
>>Kill |cRXP_ENEMY_Jungle Shredders|r. Loot them for their |cRXP_LOOT_Scrap Metal|r
.use 93180 >> |cRXP_WARN_Use the|r |T133015:0|t[Re-Configured Remote] |cRXP_WARN_on them to weaken them|r
.complete 32446,1 
.mob Jungle Shredder
step << Alliance
.isOnQuest 32159
#sticky
#label EnergizedSeeds
#loop
.waypoint 418,19.6,63.6,60,0
.waypoint 418,20.6,59.8,60,0
.waypoint 418,22.8,51.8,60,0
.waypoint 418,25.4,53.4,60,0
>>Click the |cRXP_PICK_Undisturbed Soil|r
.complete 32159,1 
step << Alliance
.isOnQuest 32158
#sticky
#label ShredmasterPackle
.goto 418/870,2031.100,-2049.600
>>Kill |cRXP_ENEMY_Shredmaster Packle|r
.complete 32158,1 
.mob Shredmaster Packle
step << Alliance
.isOnQuest 32433
#sticky
#label GrezikOregrind
.goto 418/870,1910.700,-2026.100
>Kill |cRXP_ENEMY_Grezik Oregrind|r
.complete 32433,1 
.mob Grezik Oregrind
step
#requires BilgewaterGoblins
step
#requires DogTag
step
#requires ShredmasterPackle
step
#requires TanksDestroyed
step
#requires GrezikOregrind
step
#requires RustyValve
step
#requires JungleShredder
step
#requires EnergizedSeeds
step << Alliance
.isOnQuest 32156
.goto 418/870,2167.000,-2564.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishka|r
.target Mishka
.dailyturnin 32156 >>Turn in It's Only Right
step << Alliance
.isOnQuest 32158
.goto 418/870,2164.700,-2564.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seraphine of the Winter|r
.target Seraphine of the Winter
.dailyturnin 32158 >>Turn in Two Step Program
step << Alliance
.isOnQuest 32433
.goto 418/870,2164.700,-2564.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Seraphine of the Winter|r
.target Seraphine of the Winter
.dailyturnin 32433 >>Turn in Undermining the Under Miner
step << Alliance
.isOnQuest 32154
.goto 418/870,2138.500,-2568.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r
.target Sully "The Pickle" McLeary
.dailyturnin 32154 >>Turn in Burn Out!
step << Alliance
.isOnQuest 32446
.goto 418/870,2138.500,-2568.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r
.target Sully "The Pickle" McLeary
.dailyturnin 32446 >>Turn in Dis-Assembly Required
step << Alliance
.isOnQuest 32155
.goto 418/870,2138.500,-2568.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r
.target Sully "The Pickle" McLeary
.dailyturnin 32155 >>Turn in Necessary Breaks
step << Alliance
.isOnQuest 32159
.goto 418/870,2138.500,-2568.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sully "The Pickle" McLeary|r
.target Sully "The Pickle" McLeary
.dailyturnin 32159 >>Turn in Circle of Life
step << Alliance
.isOnQuest 32157
.goto 418/870,2175.500,-2585.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sky Admiral Rogers|r
.target Sky Admiral Rogers
.dailyturnin 32157 >>Turn in The Only Good Goblin...
step << Horde
.goto 418/870,2461.200,-1789.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 1000 into Friendly in order to accept this quest|r
.target General Nazgrim
.accept 32256 >>Accept Rise Of An Empire
step << Horde
#completewith next
.zone 390 >> Travel to Shrine of Two Moons
step << Horde
.goto 390/870,980.100,1662.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garrosh Hellscream|r
.target Garrosh Hellscream
.turnin 32256 >>Turn in Rise Of An Empire
.accept 32242 >>Accept Buried Secrets
step << Horde
#completewith next
.subzone 6149 >> Travel to the Ancestral Rise in Vale of Eternal Blossoms
step << Horde
.goto 390/870,1950.500,1685.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fanlyr Silverthorn|r
.target Fanlyr Silverthorn
.turnin 32242 >>Turn in Buried Secrets
.accept 32257 >>Accept Voice of the Gods
step << Horde
.goto 390/870,2023.300,1748.500
>>Click the |cRXP_ENEMY_Mercurial Guardian|r. Kill it once it comes to life. Loot it for the |cRXP_LOOT_Ancient Korune Tablet|r
.complete 32257,1 
.complete 32257,2 
.mob Mercurial Guardian
step << Horde
.goto 390/870,1950.400,1685.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fanlyr Silverthorn|r
.target Fanlyr Silverthorn
.turnin 32257 >>Turn in Voice of the Gods
step << Horde
.goto 418/870,2446.500,-1788.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Messenger Grummle|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 5000 into Friendly in order to accept this quest|r
.target Messenger Grummle
.accept 32284 >>Accept Someone You Should See
step << Horde
#completewith next
.zone 379 >> Travel to Kun-Lai Summit
step << Horde
.goto 379/870,355.000,1728.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.target Chen Stormstout
.turnin 32284 >>Turn in Someone You Should See
.accept 32318 >>Accept Regeneration Takes Time
step << Horde
#loop
.goto 379/870,67.700,1854.400,50,0
.goto 379/870,-2.100,1773.000,50,0
.goto 371/870,-91.300,1713.100,50,0
.goto 433/870,-181.200,1460.300,50,0
.goto 371/870,-290.700,1419.900,50,0
.goto 371/870,-307.100,1319.000,50,0
>>Kill |cRXP_ENEMY_Summit Sprites|r and |cRXP_ENEMY_Sinister Needles|r. Loot them for their |cRXP_LOOT_Sturdy Needles|r
.complete 32318,1 
.mob Summit Sprite
.mob Sinister Needle
step << Horde
.goto 379/870,355.200,1728.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chen Stormstout|r
.target Chen Stormstout
.turnin 32318 >>Turn in Regeneration Takes Time
step << Horde
.goto 379/870,356.800,1729.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vol'jin|r
.target Vol'jin
.accept 32319 >>Accept Find Thrall!
step << Horde
.use 92510 >> |cRXP_WARN_Use|r |T413582:0|t[Vol'jin's Hearthstone]
.complete 32319,1 
step << Horde
.goto 461/1,-4244.000,-600.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r
.target Thrall
.turnin 32319 >>Turn in Find Thrall!
.accept 32320 >>Accept The Horde Is Family
step << Horde
.goto 463/1,-5185.300,-1084.500
>>Escort |cRXP_FRIENDLY_Thrall|r to Echo Isles
>>Kill the |cRXP_ENEMY_Kor'kron Soulbreaker|r
.complete 32320,1 
.target Thrall
.mob Kor'kron Soulbreaker
step << Horde
.goto 463/1,-5185.300,-1084.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r
.target Thrall
.turnin 32320 >>Turn in The Horde Is Family
.accept 32372 >>Accept De-Subjugation
step << Horde
>>Kill |cRXP_ENEMY_Kor'kron Overseers|r, |cRXP_ENEMY_Kor'kron Subjugators|r and |cRXP_ENEMY_Gul'tar the Subjugator|r
.complete 32372,1 
.waypoint 463,48.6,56.8,70,0
.waypoint 463,57.0,45.6,70,0
.waypoint 463,58.8,61.4,70,0
.waypoint 463,46.6,48.0,70,0
.waypoint 463,48.6,56.8,70,0
.waypoint 463,57.0,45.6,70,0
.waypoint 463,58.8,61.4,70,0
.waypoint 463,46.6,48.0,70,0
.mob +Kor'kron Overseer
.complete 32372,2 
.waypoint 463,48.6,56.8,70,0
.waypoint 463,57.0,45.6,70,0
.waypoint 463,58.8,61.4,70,0
.waypoint 463,46.6,48.0,70,0
.waypoint 463,48.6,56.8,70,0
.waypoint 463,57.0,45.6,70,0
.waypoint 463,58.8,61.4,70,0
.waypoint 463,46.6,48.0,70,0
.mob +Kor'kron Subjugator
.complete 32372,3 
.goto 463/1,-5609.100,-1322.800
.mob +Gul'tar the Subjugator
step << Horde
.goto 463/1,-5549.900,-1271.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thrall|r
.target Thrall
.turnin 32372 >>Turn in De-Subjugation
step << Horde
.goto 463/1,-5555.000,-1261.300
.zone 418 >> Take the |cRXP_PICK_Portal to Domination Point|r
.zoneskip 463,1
step << Horde
.goto 418/870,2461.000,-1788.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 3000 into Honored in order to accept this quest|r
.target General Nazgrim
.accept 32190 >>Accept To Mogujia
step << Horde
.isOnQuest 32190
.goto 418/870,2484.000,-1747.700
.gossipoption 40753 >> Talk to |cRXP_FRIENDLY_Tak-Tak|r to fly to Mogujia
.timer 114,Flight Time
.skipgossip
.target Tak-Tak
step << Horde
>>|cRXP_WARN_Wait out the RP|r
.complete 32190,1 
step << Horde
.goto 379/870,1268.200,2321.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32190 >>Turn in To Mogujia
.accept 32192 >>Accept Bloodlines
step << Horde
.goto 379/870,1264.600,2339.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fanlyr Silverthorn|r
.target Fanlyr Silverthorn
.accept 32191 >>Accept Ancient Guardians
.accept 32244 >>Accept The Korune
step << Horde
>>Kill the |cRXP_ENEMY_Korune Spellweaver|r. Loot it for the |cRXP_LOOT_Korune Codex|r
>>Kill the |cRXP_ENEMY_Korune Wardens|r that are beside the trapped |cRXP_FRIENDLY_Blood Elves|r
>>Kill |cRXP_ENEMY_Korune Guardians|r
.complete 32244,1 
.goto 379/870,1202.600,2659.400
.complete 32192,1 
.waypoint 379/870,1243.800,2463.400,45,0
.waypoint 379/870,1121.000,2548.500,45,0
.waypoint 379/870,1243.800,2463.400,45,0
.waypoint 379/870,1121.000,2548.500,45,0
.mob +Korune Warden
.complete 32191,1 
.waypoint 379/870,1243.800,2463.400,45,0
.waypoint 379/870,1121.000,2548.500,45,0
.waypoint 379/870,1243.800,2463.400,45,0
.waypoint 379/870,1121.000,2548.500,45,0
.mob +Korune Guardian
step << Horde
.goto 379/870,1264.500,2339.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fanlyr Silverthorn|r
.target Fanlyr Silverthorn
.turnin 32244 >>Turn in The Korune
.turnin 32191 >>Turn in Ancient Guardians
step << Horde
.goto 379/870,1268.400,2321.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32192 >>Turn in Bloodlines
step << Horde
.goto 418/870,2461.100,-1788.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 6500 into Honored in order to accept this quest|r
.target General Nazgrim
.accept 32376 >>Accept To the Valley!
step << Horde
#completewith next
.zone 379 >> Travel to Kun-Lai Summit
step << Horde
.goto 379/870,1470.600,3564.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32376 >>Turn in To the Valley!
.accept 32379 >>Accept Legacy of the Korune
.accept 32378 >>Accept Clearing a Path
step << Horde
>>Kill |cRXP_ENEMY_Korune Mutilators|r. Loot them for the |cRXP_LOOT_Korune Orders|r
>>Kill |cRXP_ENEMY_Korune Sha-weavers|r. Loot them for the |cRXP_LOOT_Sealed Korune Artifact|r
>>Loot the |cRXP_PICK_Legacy of the Korune|r on the ground
.complete 32378,1 
.waypoint 379/870,1514.900,3684.800,50,0
.waypoint 379/870,1499.400,3604.500,50,0
.waypoint 379,56.93,47.75,50,0
.waypoint 379/870,1514.900,3684.800,50,0
.waypoint 379/870,1499.400,3604.500,50,0
.waypoint 379,56.93,47.75,50,0
.mob +Korune Mutilator
.mob +Korune Sha-weaver
.complete 32379,1 
.waypoint 379/870,1514.900,3684.800,50,0
.waypoint 379/870,1499.400,3604.500,50,0
.waypoint 379,56.93,47.75,50,0
.waypoint 379/870,1514.900,3684.800,50,0
.waypoint 379/870,1499.400,3604.500,50,0
.waypoint 379,56.93,47.75,50,0
.mob +Korune Mutilator
.complete 32379,3 
.mob +Korune Sha-weaver
.complete 32379,2 
.target +Legacy of the Korune
.goto 379,56.93,47.75
step << Horde
.goto 379/870,1470.600,3564.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32379 >>Turn in Legacy of the Korune
.turnin 32378 >>Turn in Clearing a Path
.accept 32384 >>Accept Trapping the Leader
step << Horde
#completewith next
.goto 379/870,1334.400,3703.900
.subzone 6199 >> Enter the Tomb of Shadows
step << Horde
.goto 379/870,1286.000,3783.000
>>Attack |cRXP_ENEMY_Shan Kien|r until he submits
.complete 32384,1 
.mob Shan Kien
step << Horde
#completewith next
.subzone 6198 >> Return to |cRXP_FRIENDLY_Lor'themar Theron|r. You don't need to wait for the RP
.subzoneskip 6199,1
step << Horde
.goto 379/870,1470.500,3564.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32384 >>Turn in Trapping the Leader
step << Horde
.goto 418/870,2461.100,-1788.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 10800 into Honored in order to accept this quest|r
.target General Nazgrim
.accept 32351 >>Accept Echoes of Thunder
step << Horde
#completewith next
.zone 390 >> Travel to Shrine of Two Moons
step << Horde
.goto 390/870,885.500,1733.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baine Bloodhoof|r
.target Baine Bloodhoof
.turnin 32351 >>Turn in Echoes of Thunder
.accept 32352 >>Accept A Gathering Storm
step << Horde
#loop
.goto 390/870,885.500,1733.200,50,0
.goto 390/870,935.600,1712.600,50,0
.goto 390/870,992.400,1709.600,50,0
>>Click on |cRXP_FRIENDLY_Sha-Touched Grunts|r. Kill them once they become hostile
.complete 32352,1 
.target Sha-Touched Grunt
step << Horde
.goto 390/870,894.100,1728.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garrosh Hellscream|r
.target Garrosh Hellscream
.turnin 32352 >>Turn in A Gathering Storm
step << Horde
.goto 418/870,2461.000,-1788.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 2700 into Revered in order to accept this quest|r
.target General Nazgrim
.accept 32329 >>Accept Get My Results!
step << Horde
.goto 418/870,2464.500,-1786.900
>>Take the |cRXP_PICK_Portal to Silvermoon City|r
.complete 32329,1 
step << Horde
.goto 110/0,-4652.500,7590.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32329 >>Turn in Get My Results!
.accept 32330 >>Accept What's in the Box?
step << Horde
.goto 110/0,-5049.700,7490.101
>>Talk to |cRXP_FRIENDLY_Arcanis Mechanica|r
.complete 32330,1 
step << Horde
>>Drop down to the lower level and talk to |cRXP_FRIENDLY_Archmage Aethas Sunreaver|r and |cRXP_FRIENDLY_Grand Magister Rommath|r
.complete 32330,2 
.goto 110/0,-5118.300,7448.601
.target +Archmage Aethas Sunreaver
.complete 32330,3 
.goto 110/0,-5119.400,7454.101
.target +Grand Magister Rommath
.skipgossip
step << Horde
.goto 110/0,-5121.100,7450.700
>>Click on the |cRXP_PICK_Intensifier Disc|r and kill the |cRXP_ENEMY_Concentrated Sha|r that spawns
.complete 32330,4 
.mob Concentrated Sha
step << Horde
.goto 110/0,-5058.400,7455.400,20,0
.goto 110/0,-5058.800,7512.400,10,0
.goto 110/0,-5090.800,7453.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r upstairs
.target Lor'themar Theron
.turnin 32330 >>Turn in What's in the Box?
step << Horde
.goto 418/870,2461.100,-1788.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 6900 into Revered in order to accept this quest|r
.target General Nazgrim
.accept 32363 >>Accept The Kun-Lai Expedition
step << Horde
.isOnQuest 32363
.goto 418/870,2484.000,-1747.700
.gossipoption 40750 >> Talk to |cRXP_FRIENDLY_Tak-Tak|r to fly to Garrosh'ar Advance
.timer 193,Flight Time
.skipgossip
.target Tak-Tak
step << Horde
>>|cRXP_WARN_Wait out the RP|r
.complete 32363,1 
step << Horde
.goto 379/870,1062.900,3318.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baine Bloodhoof|r
.target Baine Bloodhoof
.turnin 32363 >>Turn in The Kun-Lai Expedition
.accept 32448 >>Accept Ties with the Past
step << Horde
#completewith next
.goto 379/870,839.000,3557.000
.subzone 6462 >> Go down into the Path of Conquerors
step << Horde
.goto 379/870,839.300,3735.300
>>Kill |cRXP_ENEMY_Varatus the Conqueror|r. Loot her for the |cRXP_LOOT_Essence of Varatus|r
.complete 32448,1 
.mob Varatus the Conqueror
step << Horde
.goto 379/870,1062.700,3318.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baine Bloodhoof|r
.target Baine Bloodhoof
.turnin 32448 >>Turn in Ties with the Past
.accept 32368 >>Accept Memory Wine
step << Horde
.use 92756 >> |cRXP_WARN_Drink the|r |T613399:0|t[Memory Wine]
>>|cRXP_WARN_You may skip the cinematic if you wish|r
.complete 32368,1 
step << Horde
.goto 379/870,1062.700,3318.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baine Bloodhoof|r
.target Baine Bloodhoof
.turnin 32368 >>Turn in Memory Wine
step << Horde
.goto 418/870,2461.000,-1788.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 10700 into Revered in order to accept this quest|r
.target General Nazgrim
.accept 32391 >>Accept The Ruins of Korune
step << Horde
.isOnQuest 32391
.goto 418/870,2484.000,-1747.700
.gossipoption 40749 >> Talk to |cRXP_FRIENDLY_Tak-Tak|r to fly to the Ruins of Korune
.timer 167,Flight Time
.skipgossip
.target Tak-Tak
step << Horde
>>|cRXP_WARN_Wait out the RP|r
.complete 32391,1 
step << Horde
.goto 379/870,2781.600,4519.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishi|r
.target Ishi
.turnin 32391 >>Turn in The Ruins of Korune
.accept 32392 >>Accept The Divine Bell
step << Horde
.goto 379/870,2762.600,4483.700,15,0
.goto 379/870,2818.800,4314.600,20,0
.goto 379/870,2906.800,4196.900,20,0
.goto 379/870,2793.900,4347.200
>>Kill |cRXP_ENEMY_Sarannha Skyglaive|r
.complete 32392,1 
.mob Sarannha Skyglaive
step << Horde
.goto 379/870,2789.100,4342.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ishi|r
.target Ishi
.turnin 32392 >>Turn in The Divine Bell
step << Horde
.goto 418/870,2461.000,-1788.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 14700 into Revered in order to accept this quest|r
.target General Nazgrim
.accept 32326 >>Accept Insertion
step << Horde
.goto 418/870,2489.800,-1776.000
>>Go through the |cRXP_PICK_Sunreaver Portal: Darnassus|r
.complete 32326,1 
step << Horde
.goto 57/1,1881.600,9872.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fanlyr Silverthorn|r
.target Fanlyr Silverthorn
.turnin 32326 >>Turn in Insertion
.accept 32327 >>Accept The Darnassus Mission
step << Horde
.isOnQuest 32327
.goto 57/1,1881.600,9872.500
.gossipoption 40875 >> Talk to |cRXP_FRIENDLY_Fanlyr Silverthorn|r to gain the |T136047:0|t[Stealth] buff
.skipgossip
.target Fanlyr Silverthorn
step << Horde
>>|cRXP_WARN_Do NOT use any abilities or you will lose your|r |T136047:0|t[Stealth] |cRXP_WARN_buff. Teleport back to |cRXP_FRIENDLY_Fanlyr Silverthorn|r if you need the buff again|r
>>Head down into the Cenarion Enclave
>>Click the |cRXP_PICK_Divine Bell|r
.complete 32327,1 
.goto 89/1,2598.800,10122.101
.complete 32327,2 
.goto 89/1,2573.800,10056.500
step << Horde
#completewith next
.cast 134055 >> |cRXP_WARN_Use the|r |T236740:0|t[Sunreavers' Portal-Charm] |cRXP_WARN_to get back to|r |cRXP_FRIENDLY_Fanlyr Silverthorn|r
step << Horde
.goto 57/1,1881.800,9872.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fanlyr Silverthorn|r
.target Fanlyr Silverthorn
.turnin 32327 >>Turn in The Darnassus Mission
.accept 32328 >>Accept Victorious Return
step << Horde
#completewith next
.goto 57/1,1884.800,9867.800
.zone 418 >> Go through the |cRXP_PICK_Portal: Domination Point|r
.target Portal: Domination Point
step << Horde
.goto 418/870,2461.100,-1789.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
.target General Nazgrim
.turnin 32328 >>Turn in Victorious Return
step << Horde
.goto 418/870,2461.000,-1788.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: Your reputation with Dominance Offensive must be at least 18500 into Revered in order to accept this quest|r
.target General Nazgrim
.accept 32402 >>Accept The Situation In Dalaran
step << Horde
.goto 418/870,2493.800,-1751.300
>>Talk to |cRXP_FRIENDLY_Kromthar|r to teleport to Dalaran
.complete 32402,1 
.skipgossip
.target Kromthar
step << Horde
#completewith next
.goto 502,31.504,50.114,25 >> |cRXP_WARN_Stay inside the sewer. Travel towards|r |cRXP_FRIENDLY_Grand Magister Rommath|r
step << Horde
.goto 502,31.504,50.114
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.turnin 32402 >>Turn in The Situation In Dalaran
.accept 32403 >>Accept It Starts in the Sewers
step << Horde
#loop
.goto 502,43.269,64.867,35,0
.goto 502,37.005,44.339,35,0
>>Talk to the |cRXP_FRIENDLY_Sunreaver Citizens|r
.complete 32403,1 
.skipgossip
.target Sunreaver Citizen
step << Horde
.goto 502,45.613,53.604
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.turnin 32403 >>Turn in It Starts in the Sewers
.accept 32404 >>Accept Violence in the Arena
step << Horde
#loop
.goto 502,40.852,35.581,40,0
.goto 502,57.493,56.007,40,0
>>Kill |cRXP_ENEMY_Silver Covenant Enforcers|r and |cRXP_ENEMY_Silver Covenant Spellbows|r
.complete 32404,1 
.mob +Silver Covenant Enforcer
.complete 32404,2 
.mob +Silver Covenant Spellbow
step << Horde
.goto 502,54.529,27.962
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.turnin 32404 >>Turn in Violence in the Arena
.accept 32405 >>Accept Hand of the Silver Covenant
step << Horde
.goto 502,62.692,13.066
>>Kill |cRXP_ENEMY_Sorin Magehand|r
.complete 32405,1 
.mob Sorin Magehand
step << Horde
.goto 502,64.679,48.728
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.turnin 32405 >>Turn in Hand of the Silver Covenant
.accept 32406 >>Accept A Tactical Assault
step << Horde
#completewith next
.goto 501,50.572,48.107,10 >> |cRXP_WARN_Follow |cRXP_FRIENDLY_Grand Magister Rommath|r up into Dalaran|r
.target Grand Magister Rommath
step << Horde
.goto 501,50.572,48.107
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.turnin 32406 >>Turn in A Tactical Assault
.accept 32408 >>Accept The Silver Covenant's Stronghold
.accept 32409 >>Accept The Kirin Tor's True Colors
.accept 32410 >>Accept Krasus' Landing
step << Horde
.goto 501,40.123,56.478,20,0
.goto 501,36.121,64.102
>>Kill |cRXP_ENEMY_Arcanist Rathaella|r
.complete 32408,1 
.mob Arcanist Rathaella
step << Horde
>>Kill |cRXP_ENEMY_Lieutenant Corwin|r, |cRXP_ENEMY_Stormwind Footmen|r and |cRXP_ENEMY_Stormwind Clerics|r
.complete 32409,1 
.goto 501,44.047,21.345,10,0
.goto 501,46.202,16.762
.mob +Lieutenant Corwin
.complete 32409,2 
.goto 501,52.862,18.044,20,0
.goto 501,46.202,16.762,20,0
.goto 501,44.047,21.345,20,0
.mob Stormwind Footman
.mob Stormwind Clerics
step << Horde
.goto 501,68.072,42.894,20,0
.goto 501,73.926,46.745
>>Click the |cRXP_FRIENDLY_Sunreaver Dragonhawks|r
.complete 32410,1 
.target Sunreaver Dragonhawk
step << Horde
.goto 501,50.581,48.091
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.turnin 32408 >>Turn in The Silver Covenant's Stronghold
.turnin 32409 >>Turn in The Kirin Tor's True Colors
.turnin 32410 >>Turn in Krasus' Landing
.accept 32411 >>Accept The Remaining Sunreavers
step << Horde
.goto 501,69.174,33.622
.use 93124 >>|cRXP_WARN_Use the|r |T134334:0|t[Tear of the Sin'dorei] |cRXP_WARN_on|r |cRXP_FRIENDLY_Uda the Beast|r
.complete 32411,1 
.target Uda the Beast
step << Horde
.goto 501,67.228,33.799
.use 93124 >>|cRXP_WARN_Use the|r |T134334:0|t[Tear of the Sin'dorei] |cRXP_WARN_on|r |cRXP_FRIENDLY_Magister Hathorel|r up stairs
.complete 32411,3 
.target Magister Hathorel
step << Horde
.goto 501,64.668,24.602
.use 93124 >>|cRXP_WARN_Use the|r |T134334:0|t[Tear of the Sin'dorei] |cRXP_WARN_on|r |cRXP_FRIENDLY_Magistrix Vesara|r
.complete 32411,5 
.target Magistrix Vesara
step << Horde
.goto 501,59.939,15.923
.use 93124 >>|cRXP_WARN_Use the|r |T134334:0|t[Tear of the Sin'dorei] |cRXP_WARN_on|r |cRXP_FRIENDLY_High Arcanist Savor|r
.complete 32411,2 
.target High Arcanist Savor
step << Horde
.goto 501,58.625,25.889
.use 93124 >>|cRXP_WARN_Use the|r |T134334:0|t[Tear of the Sin'dorei] |cRXP_WARN_on|r |cRXP_FRIENDLY_Magister Surdiel|r
.complete 32411,4 
.target Magister Surdiel
step << Horde
.goto 501,50.575,48.124
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grand Magister Rommath|r
.target Grand Magister Rommath
.turnin 32411 >>Turn in The Remaining Sunreavers
.accept 32412 >>Accept One Last Grasp
step << Horde
.isOnQuest 32412
.goto 501,28.999,48.304
.zone 502 >>Click on |cRXP_PICK_Rommath's Portal|r
.target Rommath's Portal
step << Horde
.goto 502,27.32,58.78,20,0
.goto 502,9.74,87.94
>>Head down the sewer tunnel and jump out of it once you reach the end
.complete 32412,2 
step << Horde
.goto 110/0,-4861.300,7420.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
.target Lor'themar Theron
.turnin 32412 >>Turn in One Last Grasp
step << Horde
.goto 110/0,-4852.400,7417.300
.zone 418 >> Take the |cRXP_PICK_Portal to Domination Point|r
.zoneskip 110,1
step << Horde
.goto 418/870,2461.000,-1788.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_General Nazgrim|r
>>|cRXP_WARN_NOTE: You must be Exalted with Dominance Offensive in order to accept this quest|r
.target General Nazgrim
.accept 32398 >>Accept The Bell Speaks
step << Horde
.isOnQuest 32398
.goto 418/870,2484.000,-1747.700
.gossipoption 40748 >> Talk to |cRXP_FRIENDLY_Tak-Tak|r to fly to Emperor's Reach
.timer 170,Flight Time
.skipgossip
.target Tak-Tak
step << Horde
>>|cRXP_WARN_Wait out the RP|r
.complete 32398,1 
step << Horde
.goto 379/870,1341.900,4197.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malkorok|r
.target Malkorok
.turnin 32398 >>Turn in The Bell Speaks
.accept 32399 >>Accept Breath of Darkest Shadow
step << Horde
.goto 379/870,1338.000,4279.200
>>|cRXP_WARN_Head to the centre and wait out the RP|r
>>Kill |cRXP_ENEMY_Blademaster Ishi|r once he is attackable
.complete 32399,1 
.mob +Blademaster Ishi
.complete 32399,2 
step << Horde
.goto 379/870,1337.700,4284.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garrosh Hellscream|r
.target Garrosh Hellscream
.turnin 32399 >>Turn in Breath of Darkest Shadow
step << Horde
+Congratulations! You have completed the Landfall campaign
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 1000 into Friendly in order to accept this quest|r
.target Admiral Taylor
.accept 32380 >>Accept The Best Around
step << Alliance !Mage
.isOnQuest 32380
.goto 418/870,-1248.900,-1158.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Proveditor Grantley|r
>>|cRXP_WARN_Buy the|r |T461801:0|t[Portal Reagents: Stormwind]
.collect 92431,1 
.target Proveditor Grantley
.zoneskip 84
step << Alliance !Mage
.isOnQuest 32380
.goto 418/870,-1226.700,-1169.800
.cast 133790 >> |cRXP_WARN_Use the|r |T461801:0|t[Portal Reagents: Stormwind]
.use 92431
.zoneskip 84
step << Alliance
.isOnQuest 32380
.goto 418/870,-1226.700,-1169.800 << !Mage
.zone 84 >> Go through the portal to Stormwind City << !Mage
.zone 84 >> Teleport to Stormwind City << Mage
step << Alliance
#completewith next
.goto 84/0,559.900,-8393.601,15,0
.goto 84/0,513.600,-8356.200
.zone 499 >> Head into the Deeprun Tram
step << Alliance
.goto 499/369,2469.000,15.100,10,0
.goto 499/369,2465.100,6.200
>>|cRXP_WARN_Follow the arrow to the underground Brawlpub|r
.complete 32380,2 
step << Alliance
.isOnQuest 32380
.goto 500/369,2464.000,-107.700
.gossipoption 41352 >> Talk to |cRXP_FRIENDLY_Barkeep Townsley|r
.skipgossip
.target Barkeep Townsley
step << Alliance
.goto 500/369,2464.000,-107.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barkeep Townsley|r
.target Barkeep Townsley
.turnin 32380 >>Turn in The Best Around
.accept 32381 >>Accept To Catch A Spy
step << Alliance
.isOnQuest 32381
.goto 500/369,2464.000,-107.700
.gossipoption 41353 >>Talk to |cRXP_FRIENDLY_Barkeep Townsley|r for the first clue
.skipgossip
step << Alliance
.goto 500/369,2474.100,-77.600
>>Talk to |cRXP_FRIENDLY_Keith "The Party" Westin|r
.complete 32381,1 
.skipgossip
.target Keith "The Party" Westin
step << Alliance
.isOnQuest 32381
.goto 500/369,2464.000,-107.700
.gossipoption 41354 >>Talk to |cRXP_FRIENDLY_Barkeep Townsley|r for the second clue
.skipgossip
step << Alliance
.goto 500/369,2501.700,-92.400
>>Talk to |cRXP_FRIENDLY_Twix Gearspark|r
.complete 32381,2 
.target Twix Gearspark
.skipgossip
step << Alliance
.isOnQuest 32381
.goto 500/369,2464.000,-107.700
.gossipoption 41355 >>Talk to |cRXP_FRIENDLY_Barkeep Townsley|r for the third clue
.skipgossip
step << Alliance
.goto 500/369,2468.800,-123.300
>>Talk to |cRXP_FRIENDLY_Tasha Windpaw|r
.complete 32381,3 
.target Tasha Windpaw
step << Alliance
.goto 500/369,2464.000,-107.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barkeep Townsley|r
.target Barkeep Townsley
.turnin 32381 >>Turn in To Catch A Spy
.accept 32426 >>Accept Stirred, Not Shaken
step << Alliance
#completewith next
.goto 500/369,2542.500,-73.600,10 >> Head up the ramp toward |cRXP_FRIENDLY_Professor Kilt|r
step << Alliance
.goto 500/369,2549.500,-150.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Kilt|r
.target Professor Kilt
.turnin 32426 >>Turn in Stirred, Not Shaken
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 5000 into Friendly in order to accept this quest|r
.target Admiral Taylor
.accept 32382 >>Accept He's In Deep
step << Alliance
.isOnQuest 32382
.goto 418/870,-1192.900,-1178.800
.gossipoption 41244 >> Talk to |cRXP_FRIENDLY_Fennie Hornswaggle|r for a flight to Kun-Lai Summit
.timer 148,Kun-Lai Flight
.skipgossip
.target Fennie Hornswaggle
step << Alliance
>>|cRXP_WARN_Wait out the RP|r
.complete 32382,1 
step << Alliance
.goto 379/870,1134.700,2102.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cousin Goottooth|r
.target Cousin Goottooth
.turnin 32382 >>Turn in He's In Deep
.accept 32383 >>Accept Bugging Out
.accept 32397 >>Accept He Won't Even Miss It
step << Alliance
.isOnQuest 32383,32397
.cast 134886 >> |cRXP_WARN_Use the|r |T348523:0|t[Grummle Disguise Kit]
.use 92950
step << Alliance
.goto 379/870,1175.400,2114.700
>>Click on a |cRXP_FRIENDLY_Shaggy Longhorn|r to distract |cRXP_ENEMY_Garrosh|r
.complete 32397,1 
step << Alliance
.goto 379/870,1193.000,2105.000
>>Quickly loot the |cRXP_PICK_Weathered Journal|r on the table
.complete 32397,2 
step << Alliance
>>Click the small |cRXP_PICK_Mogu Statues|r
.complete 32383,1 
.goto 379/870,1188.000,2111.600,-1
.complete 32383,3 
.goto 379/870,1195.800,2074.900,-1
.complete 32383,2 
.goto 379/870,1204.500,2090.400,-1
step << Alliance
.goto 379/870,1134.700,2102.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cousin Goottooth|r
.target Cousin Goottooth
.turnin 32383 >>Turn in Bugging Out
.turnin 32397 >>Turn in He Won't Even Miss It
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 3000 into Honored in order to accept this quest|r
.target Admiral Taylor
.accept 32331 >>Accept The Kirin Tor
step << Alliance
.goto 418/870,-1232.900,-1159.100
>>Go through the |cRXP_PICK_Portal to The Purple Parlor|r
.complete 32331,1 
step << Alliance
.goto 501,26.780,39.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r
.target Anduin Wrynn
.turnin 32331 >>Turn in The Kirin Tor
.accept 32362 >>Accept The Fate of Dalaran
step << Alliance
.goto 501,26.779,39.257
>>Talk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.complete 32362,1 
.skipgossip 1
.target Lady Jaina Proudmoore
step << Alliance
.goto 501,26.785,39.010
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.turnin 32362 >>Turn in The Fate of Dalaran
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 6500 into Honored in order to accept this quest|r
.target Admiral Taylor
.accept 32193 >>Accept To Mogujia
step << Alliance
.isOnQuest 32193
.goto 418/870,-1192.900,-1178.800
.gossipoption 41242 >> Talk to |cRXP_FRIENDLY_Fennie Hornswaggle|r for a flight to Mogujia
.timer 157,Mogujia Flight
.skipgossip
.target Fennie Hornswaggle
step << Alliance
>>|cRXP_WARN_Wait out the RP|r
.complete 32193,1 
step << Alliance
.goto 379/870,1095.000,2449.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brann Bronzebeard|r
.target Brann Bronzebeard
.turnin 32193 >>Turn in To Mogujia
step << Alliance
.goto 379/870,1096.000,2445.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.accept 32243 >>Accept The Source of Korune Power
step << Alliance
.goto 379/870,1086.200,2475.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarannha Skyglaive|r
.target Sarannha Skyglaive
.accept 32194 >>Accept Bad Blood
step << Alliance
#completewith next
>>Kill |cRXP_ENEMY_Silvermoon Runeseekers|r, |cRXP_ENEMY_Dominance Mages|r and |cRXP_ENEMY_Dominance Knights|r. Loot them for their |cRXP_LOOT_Korune Artifacts|r
.complete 32194,1 
.mob Silvermoon Runeseeker
.mob Dominance Mage
.mob Dominance Knight
step << Alliance
.goto 379/870,1202.800,2658.100
>>Kill the |cRXP_ENEMY_Korune Spellweaver|r. Loot it for the |cRXP_LOOT_Sha-Touched Claw|r
.complete 32243,1 
.mob Korune Spellweaver
step << Alliance
#loop
.goto 379/870,1122.000,2561.600,60,0
.goto 379/870,1285.800,2351.500,60,0
>>Kill |cRXP_ENEMY_Silvermoon Runeseekers|r, |cRXP_ENEMY_Dominance Mages|r and |cRXP_ENEMY_Dominance Knights|r. Loot them for their |cRXP_LOOT_Korune Artifacts|r
.complete 32194,1 
.mob Silvermoon Runeseeker
.mob Dominance Mage
.mob Dominance Knight
step << Alliance
.goto 379/870,1086.400,2475.300
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarannha Skyglaive|r
.target Sarannha Skyglaive
.turnin 32194 >>Turn in Bad Blood
step << Alliance
.goto 379/870,1096.100,2445.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hilda Hornswaggle|r
.target Hilda Hornswaggle
.turnin 32243 >>Turn in The Source of Korune Power
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 10800 into Honored in order to accept this quest|r
.target Admiral Taylor
.accept 32315 >>Accept Anduin's Plea
step << Alliance
.isOnQuest 32315
.goto 418/870,-1192.900,-1178.800
.gossipoption 41241 >> Talk to |cRXP_FRIENDLY_Fennie Hornswaggle|r for a flight to Shrine of Seven Stars
.timer 105,Shrine of Seven Stars Flight
.skipgossip
.target Fennie Hornswaggle
step << Alliance
>>|cRXP_WARN_Wait out the RP|r
.complete 32315,1 
step << Alliance
.goto 390/870,194.100,833.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r upstairs
.target Anduin Wrynn
.turnin 32315 >>Turn in Anduin's Plea
.accept 32316 >>Accept Heart Of The Alliance
step << Alliance
#loop
.goto 390/870,300.800,787.600,45,0
.goto 390/870,194.100,833.900,45,0
>>Click on |cRXP_FRIENDLY_Sha-Touched Footmen|r. Kill them once they come to life
.complete 32316,1 
.mob Sha-Touched Footman
step << Alliance
.goto 390/870,190.100,812.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Varian Wrynn|r upstairs
.target King Varian Wrynn
.turnin 32316 >>Turn in Heart Of The Alliance
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 2700 into Revered in order to accept this quest|r
.target Admiral Taylor
.accept 32370 >>Accept The Kun-Lai Expedition
step << Alliance
.isOnQuest 32370
.goto 418/870,-1192.900,-1178.800
.gossipoption 41240 >> Talk to |cRXP_FRIENDLY_Fennie Hornswaggle|r for a flight to the Grummle Bazaar
.timer 182,Grummle Bazaar Flight
.skipgossip
.target Fennie Hornswaggle
step << Alliance
>>|cRXP_WARN_Wait out the RP|r
.complete 32370,1 
step << Alliance
.goto 379/870,764.700,3082.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Agent Connelly|r
.turnin 32370 >>Turn in The Kun-Lai Expedition
.accept 32377 >>Accept A Kor'kron In Our Midst
.target Agent Connelly
step << Alliance
.isOnQuest 32377
#loop
.goto 379,61.6,58.6,40,0
.goto 379,60.2,57.2,40,0
.goto 379,61.0,55.4,40,0
>>Kill |cRXP_ENEMY_Kor'kron Reavers|r. Loot them for their |T133076:0|t[|cRXP_LOOT_Kor'kron Helmet|r]
>>Kill |cRXP_ENEMY_Kor'kron Honor Guards|r. Loot them for their |T132628:0|t[|cRXP_LOOT_Kor'kron Armor|r]
>>Kill |cRXP_ENEMY_Kor'kron Scouts|r. Loot them for their |T132546:0|t[|cRXP_LOOT_Kor'kron Boots|r]
.collect 92763,1 
.mob +Kor'kron Reaver
.collect 92764,1 
.mob +Kor'Honor Guard
.collect 92765,1 
.mob +Kor'kron Reaver
step << Alliance
.use 92763 >> Use the |T133076:0|t[|cRXP_LOOT_Kor'kron Helmet|r] to create the |cRXP_LOOT_Kor'kron Disguise|r
.complete 32377,1 
step << Alliance
>>Click on the quest popup under your minimap to turn in the quest
.turnin 32377 >>Turn in A Kor'kron In Our Midst
.accept 32371 >>Accept Memory Wine
step << Alliance
.use 92766 >>|cRXP_WARN_Use the|r |T236452:0|t[|cRXP_LOOT_Kor'kron Disguise|r]
.complete 32371,1 
step << Alliance
>>Click the |cRXP_PICK_Memory Wine|r
>>|cRXP_WARN_You can skip the cinematic if you wish|r
.complete 32371,2 
.complete 32371,3 
step << Alliance
.goto 379/870,764.800,3082.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Agent Connelly|r
.target Agent Connelly
.turnin 32371 >>Turn in Memory Wine
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 6900 into Revered in order to accept this quest|r
.target Admiral Taylor
.accept 32393 >>Accept The Ruins of Korune
step << Alliance
.isOnQuest 32393
.goto 418/870,-1192.900,-1178.800
.gossipoption 41239 >> Talk to |cRXP_FRIENDLY_Fennie Hornswaggle|r for a flight to the Ruins of Korune
.timer 188,Ruins of Korune Flight
.skipgossip
.target Fennie Hornswaggle
step << Alliance
>>|cRXP_WARN_Wait out the RP|r
.complete 32393,1 
step << Alliance
.goto 379/870,2780.800,4522.700
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarannha Skyglaive|r
.target Sarannha Skyglaive
.turnin 32393 >>Turn in The Ruins of Korune
.accept 32394 >>Accept The Divine Bell
step << Alliance
.goto 379/870,2762.600,4483.700,15,0
.goto 379/870,2818.800,4314.600,20,0
.goto 379/870,2906.800,4196.900,20,0
.goto 379/870,2798.600,4341.800
>>Kill |cRXP_ENEMY_Dreadweaver Avartu|r
.complete 32394,1 
.mob Dreadweaver Avartu
step << Alliance
.goto 379/870,2792.400,4349.400
>>Click the |cRXP_PICK_Divine Bell|r
.complete 32394,2 
step << Alliance
.goto 379/870,2789.100,4342.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sarannha Skyglaive|r
.target Sarannha Skyglaive
.turnin 32394 >>Turn in The Divine Bell
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 8700 into Revered in order to accept this quest|r
.target Admiral Taylor
.accept 32414 >>Accept Darnassus Attacked?
step << Alliance
.goto 418/870,-1228.400,-1165.100
>>Talk to |cRXP_FRIENDLY_Seamus Goldenkicks|r to be ported to Darnassus
.complete 32414,1 
.target Seamus Goldenkicks
.skipgossip
step << Alliance
.goto 89/1,2588.500,10127.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.turnin 32414 >>Turn in Darnassus Attacked?
.accept 32460 >>Accept Tracking the Thieves
step << Alliance
.goto 57/1,1884.900,9873.101
>>Head to the arrow location outside of Darnassus
.complete 32460,1 
.target Lady Jaina Proudmoore
step << Alliance
.goto 57/1,1886.500,9870.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
.target Lady Jaina Proudmoore
.turnin 32460 >>Turn in Tracking the Thieves
.accept 32416 >>Accept Jaina's Resolution
step << Alliance
.goto 57,39.990,50.602
>>Go through the |cRXP_PICK_Portal to Dalaran|r
.complete 32416,1 
step << Alliance
.goto 501,34.276,48.691
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
.turnin 32416 >>Turn in Jaina's Resolution
.accept 32421 >>Accept Nowhere to Run
.accept 32419 >>Accept Nowhere to Hide
.accept 32417 >>Accept Sewer Cleaning
.accept 32418 >>Accept Unfair Trade
.accept 32420 >>Accept Cashing Out
step << Alliance
.goto 501,41.478,36.174
>>Kill |cRXP_ENEMY_Inkmaster Aelon|r
.complete 32418,1 
.mob Inkmaster Aelon
step << Alliance
.goto 501,35.571,33.000
>>Kill |cRXP_ENEMY_Sintharia Cinderweave|r
.complete 32418,4 
.mob Sintharia Cinderweave
step << Alliance
.goto 501,39.444,24.566
>>Kill |cRXP_ENEMY_Gearmage Astalon|r
.complete 32418,3 
.mob Gearmage Astalon
step << Alliance
.goto 501,43.364,26.087
>>Kill |cRXP_ENEMY_Tolyria|r
.complete 32418,2 
.mob Tolyria
step << Alliance
.goto 501,53.526,15.506
>>Kill |cRXP_ENEMY_Magister Brasael|r
.complete 32420,1 
.mob Magister Brasael
step << Alliance
#loop
.goto 501,68.576,31.673,40,0
.goto 501,59.242,20.865,40,0
>>Kill the |cRXP_ENEMY_Sunreavers|r
.mob Sunreaver Mage
.mob Sunreaver Summoner
.mob Sunreaver Captain
.mob Sunreaver Aegis
.mob Sunreaver Captain
step << Alliance
.goto 501,72.636,45.703
>>Kill |cRXP_ENEMY_Sunreaver Dragonhawks|r
.complete 32421,1 
.mob Sunreaver Dragonhawk
step << Alliance
#completewith next
.goto 502,65.618,47.151
.zone 502 >> Head down into the Dalaran Sewers
step << Alliance
#loop
.goto 502,41.167,35.963,40,0
.goto 502,58.313,57.281,40,0
>>Kill the |cRXP_ENEMY_Sunreavers|r in the Dalaran Sewers
.complete 32417,1 
.mob Sunreaver Duelist
.mob Sunreaver Pyromancer
.mob Sunreaver Assassin
.mob Sunreaver Assassin
.mob Sunreaver Frosthand
.mob Sunreaver Pyromancer
step << Alliance
#completewith next
.goto 501,34.276,48.691,10 >> Exit the Sewers. Return to |cRXP_FRIENDLY_Vereesa Windrunner|r in Dalaran
step << Alliance
.goto 501,34.276,48.691
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vereesa Windrunner|r
.target Vereesa Windrunner
.turnin 32421 >>Turn in Nowhere to Run
.turnin 32419 >>Turn in Nowhere to Hide
.turnin 32417 >>Turn in Sewer Cleaning
.turnin 32418 >>Turn in Unfair Trade
.turnin 32420 >>Turn in Cashing Out
.accept 32423 >>Accept What Had To Be Done
step << Alliance
.goto 501,34.276,48.691
>>Talk to |cRXP_FRIENDLY_Vereesa Windrunner|r to return to Pandaria
.complete 32423,1 
.skipgossip
step << Alliance
.goto 418/870,-1172.700,-1144.800
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Varian Wrynn|r
.target King Varian Wrynn
.turnin 32423 >>Turn in What Had To Be Done
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 14600 into Revered in order to accept this quest|r
.target Admiral Taylor
.accept 32355 >>Accept The Harmonic Mallet
step << Alliance
.isOnQuest 32355
.goto 418/870,-1192.900,-1178.800
.gossipoption 41237 >> Talk to |cRXP_FRIENDLY_Fennie Hornswaggle|r for a flight to the Tomb of Conquerors
.timer 182,Tomb of Conquerors Flight
.skipgossip
.target Fennie Hornswaggle
step << Alliance
>>|cRXP_WARN_Wait out the RP|r
.complete 32355,1 
step << Alliance
.goto 379/870,1524.900,3680.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r
.target Anduin Wrynn
.turnin 32355 >>Turn in The Harmonic Mallet
.accept 32321 >>Accept The Monkey King
step << Alliance
>>Talk to |cRXP_FRIENDLY_Anduin Wrynn|r
.complete 32321,1 
.target Anduin Wrynn
.skipgossip
step << Alliance
.goto 379/870,1572.800,3601.200,20,0
.goto 379/870,1669.400,3552.800,20,0
.goto 379/870,1697.000,3432.300,20,0
.goto 379/870,1786.000,3456.500,20,0
.goto 379/870,1781.000,3512.200
>>Escort |cRXP_FRIENDLY_Anduin Wrynn|r into through the Tomb of Conquerors
.complete 32321,2 
.target Anduin Wrynn
step << Alliance
.isOnQuest 32321
.goto 379/870,1781.000,3512.200
.subzoneskip 6201,1
.gossipoption 41925 >> Talk to |cRXP_FRIENDLY_Anduin Wrynn|r
.target Anduin Wrynn
.skipgossip
step << Alliance
>>Kill |cRXP_ENEMY_The Jade Warlord|r
.goto 379/870,1776.600,3545.000
.complete 32321,3 
.mob The Jade Warlord
step << Alliance
.goto 379/870,1785.600,3512.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_The Monkey King|r
.target The Monkey King
.turnin 32321 >>Turn in The Monkey King
.accept 32332 >>Accept The First Riddle: Mercy
.accept 32333 >>Accept The Second Riddle: Fellowship
.accept 32334 >>Accept The Third Riddle: Strength
step << Alliance
#completewith next
.goto 379/870,528.700,3720.200,10 >> Travel to the Temple of the White Tiger. Head down the ramp in the main building
step << Alliance
.goto 379/870,450.100,3706.100
>>Talk to |cRXP_FRIENDLY_The Monkey King|r, then defeat him
.complete 32334,1 
.target The Monkey King
step << Alliance
#completewith next
.zone 371 >> Travel to The Jade Forest
step << Alliance
.goto 371/870,-882.300,2059.300
>>Click the |cRXP_PICK_Hammer of Fellowship|r on the ground
.complete 32333,1 
step << Alliance
.goto 371/870,-898.200,2053.100
>>Defeat |cRXP_ENEMY_Sam the Wise|r
.complete 32333,2 
.mob Sam the Wise
step << Alliance
.goto 371/870,-903.800,2048.800
>>Loot the |cRXP_PICK_Keg of Metal Brew|r on the ground
.complete 32333,3 
step << Alliance
#completewith next
.zone 422 >> Travel to Dread Wastes
step << Alliance
.isOnQuest 32333
.goto 422/870,2624.600,-1141.000
.cast 3365 >> Click the |cRXP_PICK_Untamed Amber|r on the ground to summon |cRXP_ENEMY_Untamed Ambertail|r
step << Alliance
.goto 422/870,2610.100,-1143.400
>>Kill the |cRXP_ENEMY_Untamed Ambertail|r. Loot it for the |cRXP_LOOT_Untamed Amber|r
.complete 32332,1 
.mob Untamed Ambertail
step << Alliance
#completewith next
.subzone 6596 >> Return to Lion's Landing in Krasarang Wilds
step << Alliance
.goto 418/870,-1218.100,-1102.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_The Monkey King|r
.target The Monkey King
.turnin 32332 >>Turn in The First Riddle: Mercy
.turnin 32333 >>Turn in The Second Riddle: Fellowship
.turnin 32334 >>Turn in The Third Riddle: Strength
.accept 32335 >>Accept The Greatest Prank
step << Alliance
.goto 418/870,-1222.900,-1101.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r
.target Anduin Wrynn
.turnin 32335 >>Turn in The Greatest Prank
step << Alliance
.goto 418/870,-1218.200,-1102.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_The Monkey King|r
>>|cRXP_WARN_NOTE: Your reputation with Operation Shieldwall must be at least 18500 into Revered in order to accept these quests|r
.target The Monkey King
.accept 32336 >>Accept The Handle
.accept 32337 >>Accept The Head
.accept 32338 >>Accept The Harmonic Ointment
step << Alliance
>>Talk to |cRXP_ENEMY_Chief Ingoo Ingoo XVII|r and kill him. Loot him for the |cRXP_LOOT_Mallet Handle|r
.complete 32336,1 
.mob Chief Ingoo Ingoo XVII
.skipgossip
step << Alliance
.goto 418/870,910.900,-2814.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_The Monkey King|r
.target The Monkey King
.turnin 32336 >>Turn in The Handle
step << Alliance
#completewith next
.zone 376 >> Travel to Valley of the Four Winds
step << Alliance
.goto 376/870,1772.900,293.700
>>Talk to the |cRXP_FRIENDLY_Royal Finder|r
.complete 32337,1 
.target Royal Finder
step << Alliance
.goto 376/870,1697.800,361.800
>>Loot the |cRXP_PICK_Mallet Head|r dangling from the tree root
.complete 32337,2 
step << Alliance
#completewith next
.zone 388 >> Travel to Townlong Steppes
step << Alliance
.goto 388/870,3480.200,3252.600
>>Kill |cRXP_ENEMY_The Blade|r. Loot him for the |cRXP_LOOT_Harmonic Ointment|r
.complete 32338,1 
.mob The Blade
step << Alliance
#completewith next
.subzone 6596 >> Return to Lion's Landing in Krasarang Wilds
step << Alliance
.goto 418/870,-1218.300,-1102.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_The Monkey King|r
.target The Monkey King
.turnin 32337 >>Turn in The Head
.turnin 32338 >>Turn in The Harmonic Ointment
step << Alliance
.goto 418/870,-1250.000,-1128.600
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
>>|cRXP_WARN_NOTE: You must be Exalted with Operation Shieldwall in order to accept this quest|r
.target Admiral Taylor
.accept 32400 >>Accept The Bell Speaks
step << Alliance
.isOnQuest 32400
.goto 418/870,-1192.900,-1178.800
.gossipoption 41236 >> Talk to |cRXP_FRIENDLY_Fennie Hornswaggle|r for a flight to Emperor's Reach
.timer 167,Emperor's Reach Flight
.skipgossip
.target Fennie Hornswaggle
step << Alliance
>>|cRXP_WARN_Wait out the RP|r
.complete 32400,1 
step << Alliance
.goto 379/870,1311.400,4187.200
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r
.target Anduin Wrynn
.turnin 32400 >>Turn in The Bell Speaks
.accept 32401 >>Accept Breath of Darkest Shadow
step << Alliance
.goto 379/870,1338.000,4279.200
>>|cRXP_WARN_Head to the centre and wait out the RP|r
>>Kill the |cRXP_ENEMY_Kor'kron Reavers|r once they are attackable
>>Kill |cRXP_ENEMY_Ishi|r once he is attackable
.complete 32401,1 
.mob +Kor'kron Reaver
.mob +Ishi
.complete 32401,2 
step << Alliance
.goto 379/870,1337.600,4288.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anduin Wrynn|r
.target Anduin Wrynn
.turnin 32401 >>Turn in Breath of Darkest Shadow
.accept 32455 >>Accept The Silence
step << Alliance
.use 93362 >> |cRXP_WARN_Use the|r |T331784:0|t[Alliance Flare Gun]
.complete 32455,1 
step << Alliance
#completewith next
.subzone 6596 >> Return to Lion's Landing in Krasarang Wilds
step << Alliance
.goto 418/870,-1164.000,-1144.100
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Admiral Taylor|r
.target Admiral Taylor
.turnin 32455 >>Turn in The Silence
step << Alliance
+Congratulations! You have completed the Landfall campaign
]])

RXPGuides.RegisterGuide([[#mop
#version 1
#group RXP Starting Zone (Pandaren)
#name 1-12 The Wandering Isle
#next RXP MoP 1-80 (A)\10-20 Loch Modan;RXP MoP 1-80 (H)\10-22 Azshara;skip


<< Pandaren !DK

step
    .goto 378,56.67,18.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .accept 30034 >>Accept The Lesson of the Iron Bough << Hunter
    .accept 30027 >>Accept The Lesson of the Iron Bough << Priest/Monk
    .accept 30033 >>Accept The Lesson of the Iron Bough << Mage
    .accept 30037 >>Accept The Lesson of the Iron Bough << Shaman
    .accept 30038 >>Accept The Lesson of the Iron Bough << Warrior
    .accept 30036 >>Accept The Lesson of the Iron Bough << Rogue
	.target Master Shang Xi
step << Hunter
    .isOnQuest 30034
    .goto 378,57.22,19.22
    >>Click the |cRXP_PICK_Weapon Rack|r for the |T537025:0|t[Trainee's Crossbow]
    .collect 73211,1 --Trainee's Crossbow (1)
step << Hunter
    .goto 378,57.22,19.22
    >>Equip the |T537025:0|t[Trainee's Crossbow]
    .complete 30034,1 --1/1 Loot and Equip a Trainee's Crossbow
    .use 73211 --Trainee's Crossbow
step << Mage
    .isOnQuest 30033
    .goto 378,57.22,19.22
    >>Click the |cRXP_PICK_Weapon Rack|r for the |T537771:0|t[Trainee's Spellblade] and |T654237:0|t[Trainee's Hand Fan]
    .collect 76390,1 --Trainee's Spellblade (1)
    .collect 76392,1, --Trainee's Hand Fan (1)
step << Mage
    .goto 378,57.22,19.22
    >>Equip the |T537771:0|t[Trainee's Spellblade] and |T654237:0|t[Trainee's Hand Fan]
    .complete 30033,1 --Loot and Equip a Trainee's Spellblade (1)
    .complete 30033,2 --Loot and Equip a Trainee's Hand Fan (1)
    .use 76390 --Trainee's Spellblade
    .use 76392 --Trainee's Hand Fan
step << Monk/Priest
    .isOnQuest 30027
    .goto 378,57.22,19.22
    >>|cRXP_WARN_Click the|r |cRXP_PICK_Weapon Rack|r |cRXP_WARN_for the|r |T537770:0|t[Trainee's Staff]
    .collect 73209,1 -Trainee's Staff (1)
step << Monk/Priest
    .goto 378,56.67,18.20
    >>Equip the |T537770:0|t[Trainee's Staff]
    .complete 30027,1 --Loot and Equip a Trainee's Staff
    .use 73209
step << Shaman
    .isOnQuest 30037
    .goto 378,57.22,19.22
    >>|cRXP_WARN_Click the|r |cRXP_PICK_Weapon Rack|r |cRXP_WARN_for the|r |T537205:0|t[Trainee's Axe] |cRXP_WARN_and|r |T537769:0|t[Trainee's Shield]
    .collect 76391,1  --Trainee's Axe (1)
    .collect 73213,1 --Trainee's Shield (1)
step << Shaman
    .goto 378,57.22,19.22
    >>|cRXP_WARN_Equip the|r |T537205:0|t[Trainee's Axe] |cRXP_WARN_and|r |T537769:0|t[Trainee's Shield]
    .complete 30037,1 --Loot and Equip a Trainee's Axe
    .complete 30037,2 --Loot and Equip a Trainee's Shield
    .use 76391 --Trainee's Axe
    .use 73213 --Trainee's Shield
step << Warrior
    .isOnQuest 30038
    .goto 378,57.22,19.22
    >>|cRXP_WARN_Click the|r |cRXP_PICK_Weapon Rack|r |cRXP_WARN_for the|r |T537205:0|t[Trainee's Axe] |cRXP_WARN_and|r |T537769:0|t[Trainee's Shield]
    .collect 76391,1  --Trainee's Axe (1)
    .collect 73213,1  --Trainee's Shield (1)
step << Warrior
    .isOnQuest 30038
    .goto 378,57.22,19.22
    >>|cRXP_WARN_Equip the|r |T537205:0|t[Trainee's Axe] |cRXP_WARN_and|r |T537769:0|t[Trainee's Shield]
    .complete 30038,1 --Loot and Equip a Trainee's Axe
    .complete 30038,2 --Loot and Equip a Trainee's Shield
    .use 76391 --Trainee's Axe
    .use 73213 --Trainee's Shield
step << Rogue
    .isOnQuest 30036
    .goto 378,57.22,19.22
    >>|cRXP_WARN_Click the|r |cRXP_PICK_Weapon Rack|r |cRXP_WARN_for the|r |T537767:0|t[Trainee's Daggers]
    .collect 73208,1,30036,1,1 --Trainee's Dagger (ID 1)
    .collect 73212,1,30036,1,1 --Trainee's Dagger (ID 2)
step << Rogue
    .goto 378,57.22,19.22
    >>|cRXP_WARN_Equip the|r |T537767:0|t[Trainee's Daggers]
    .complete 30036,1 --Loot and Equip a Trainee's Dagger
    .complete 30036,2 --Loot and Equip a Second Trainee's Dagger
    .use 73208 --Trainee's Dagger (ID 1)
    .use 73212 --Trainee's Dagger (ID 2)
step
    .goto 378,56.67,18.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 30034 >>Turn in The Lesson of the Iron Bough << Hunter
    .turnin 30033 >>Turn in The Lesson of the Iron Bough << Mage
    .turnin 30027 >>Turn in The Lesson of the Iron Bough << Priest/Monk
    .turnin 30037 >>Turn in The Lesson of the Iron Bough << Shaman
    .turnin 30038 >>Turn in The Lesson of the Iron Bough << Warrior
    .turnin 30036 >>Turn in The Lesson of the Iron Bough << Rogue
    .accept 29406 >>Accept The Lesson of the Sandy Fist
	.target Master Shang Xi
step
    .goto 378,57.49,18.64,10,0
    .goto 378,57.12,19.43,10,0
    .goto 378,57.49,18.64,10,0
    .goto 378,57.12,19.43,10,0
    .goto 378,57.31,18.97
    >>Kill |cRXP_ENEMY_Training Targets|r.
    .complete 29406,1 --5/5 Training Targets destroyed
	.mob Training Target
step
    .goto 378,56.67,18.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29406 >>Turn in The Lesson of the Sandy Fist
    .accept 29524 >>Accept The Lesson of Stifled Pride
	.target Master Shang Xi
step
    #completewith next
    --#title |cFFFCDC00Enter the house|r
    .goto 378,59.57,19.05,10 >>Enter the house
step
    .goto 378,60.26,19.35
    >>Defeat |cRXP_ENEMY_Sparring Trainees|r
    *|cRXP_WARN_There are more upstairs|r
    .complete 29524,1 --6/6 Sparring Trainees defeated
	.mob Tushui Trainee
	.mob Huojin Trainee
step
    .goto 378,59.67,19.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29524 >>Turn in The Lesson of Stifled Pride
    .accept 29408 >>Accept The Lesson of the Burning Scroll
	.target Master Shang Xi
step
    .isOnQuest 29408
    .goto 378,59.97,18.58,8,0
    .goto 378,60.48,18.85,5,0
    .goto 378,60.20,18.89,5,0
    .goto 378,59.98,18.69,5,0
	.goto 378,60.46,19.60,8 >>Go upstairs
    >>|cRXP_WARN_Take the shortcut to the top floor by jumping through the gap under the second set of stairs|r
step
    .goto 378,59.95,20.39
    >>Click the |cRXP_PICK_Banner|r at the top of the building
    .complete 29408,2 --1/1 Burn the Edict of Temperance
step
	#completewith next
    --#title |cFFFCDC00Jump down|r
    .goto 378,60.19,19.35,6 >> |cRXP_WARN_Jump down|r
step
    .goto 378,59.67,19.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29408 >>Turn in The Lesson of the Burning Scroll
    .accept 29409 >>Accept The Disciple's Challenge
	.target Master Shang Xi
step
    .goto 378,67.78,22.75
    >>Defeat |cRXP_ENEMY_Jaomin Ro|r
    .complete 29409,1 --1/1 Defeat Jaomin Ro
	.mob Jaomin Ro
step << Warrior
	#completewith Lorvo
    +|cRXP_WARN_Use|r |T132337:0|t[Charge] |cRXP_WARN_on critters to move faster|r
step
    .goto 378,65.97,22.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29409 >>Turn in The Disciple's Challenge
    .accept 29410 >>Accept Aysa of the Tushui
	.target Master Shang Xi
step
    #completewith next
    .goto 378,55.09,32.83,50 >>Travel toward |cRXP_FRIENDLY_Merchant Lorvo|r
step
	#label Lorvo
    .goto 378,55.09,32.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merchant Lorvo|r
    .turnin 29410 >>Turn in Aysa of the Tushui
    .accept 29419 >>Accept The Missing Driver
    .accept 29424 >>Accept Items of Utmost Importance
	.target Merchant Lorvo
step
    #completewith next
    >>Kill |cRXP_ENEMY_Amberleaf Scamps|r. Loot them for |T132622:0|t[|cRXP_LOOT_Stolen Training Supplies|r]
    .complete 29424,1 --6/6 Stolen Training Supplies
	.mob Amberleaf Scamp
step
    .goto 378,54.11,20.90
    --#title |cFFFCDC00Follow the arrow to |cFF00FF25Min Dimwind|r|r
    >>Travel to |cRXP_FRIENDLY_Min Dimwind|r
    .complete 29419,1 --1/1 Rescue the Cart Driver
	.target Min Dimwind
step
    #loop
    .goto 378,53.08,31.58,0
    .goto 378,54.03,20.93,15,0
    .goto 378,54.02,17.44,15,0
    .goto 378,53.00,20.17,15,0
    .goto 378,52.89,24.41,20,0
    .goto 378,55.04,24.93,20,0
    .goto 378,53.08,31.58,20,0
    >>Kill |cRXP_ENEMY_Amberleaf Scamps|r and loot them for |T132622:0|t[|cRXP_LOOT_Stolen Training Supplies|r]
    .complete 29424,1 --6/6 Stolen Training Supplies
	.target Amberleaf Scamp
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Merchant Lorvo|r and |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 29419,2 >>Turn in The Missing Driver
    .turnin 29424 >>Turn in Items of Utmost Importance
	.target +Merchant Lorvo
    .goto 378,55.11,32.40
    .accept 29414 >>Accept The Way of the Tushui
    .goto 378,55.10,32.55
	.target +Aysa Cloudsinger
step
	#completewith next
    --#title |cFFFCDC00Enter the cave|r
    .goto 378,57.21,31.04,30,0
    .goto 378,57.63,35.20,10 >> Enter the cave
	.timer 87,Cave RP
step
    .goto 378,57.89,36.55
    >>Defend |cRXP_FRIENDLY_Aysa|r from the incoming |cRXP_ENEMY_Amberleaf Troublemakers|r
    .complete 29414,1 --1/1 Protect Aysa while she meditates
	.mob Amberleaf Troublemaker
--step
--    #title Advanced
--    .isOnQuest 29414
--    >>|cFFFF0000Try out find out|r.
--    .goto 378,57.52,34.59,5 >>|cRXP_WARN_Staying near the entrance is faster but more dangerous|r
step
    .goto 378,57.54,34.68
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29414 >>Turn in The Way of the Tushui
    .accept 29522 >>Accept Ji of the Huojin
	.target Master Shang Xi
step
    .goto 378,50.24,21.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 29522 >>Turn in Ji of the Huojin
    .accept 29417 >>Accept The Way of the Huojin
	.target Ji Firepaw
step
    #loop
    .goto 378,51.18,17.71,0
    .goto 378,51.18,17.71,30,0
    .goto 378,49.56,18.31,30,0
    .goto 378,49.49,20.13,30,0
    .goto 378,49.23,24.48,30,0
    .goto 378,49.90,23.37,30,0
    .goto 378,46.12,20.46,30,0
    >>Kill |cRXP_ENEMY_Fe-Feng|r
    .complete 29417,1 --8/8 Fe-Feng attackers slain
	.mob Fe-Feng Hozen
    .mob Fe-Feng Brewthief
    .mob Fe-Feng Leaper
step
    .goto 378,50.24,21.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 29417 >>Turn in The Way of the Huojin
    .accept 29418 >>Accept Kindling the Fire
    .accept 29523 >>Accept Fanning the Flames
	.target Ji Firepaw
step << skip
    .isOnQuest 29523
    #completewith Fluttering Breeze
    +|cRXP_WARN_To enable keybinding for quest items, follow these steps:|r
    *[1] Press the |cRXP_WARN_Escape key|r.
    *[2] Select |cRXP_WARN_Options|r.
    *[3] Navigate to |cRXP_WARN_Keybindings|r.
    *[4] Within |cRXP_WARN_Keybindings|r,find |cRXP_WARN_RestedXP Guides|r
    *[5] Select and bind the |cRXP_WARN_Active Buttons|r.
step
#optional
    #completewith next
	>>Pick up |cRXP_PICK_Loose Dogwood Roots|r on the ground next to the trees
    .complete 29418,1 --5/5 Dry Dogwood Root
step
    .goto 378,47.24,31.32
	>>|cRXP_WARN_Use the|r |T519378:0|t[Wind Stone] |cRXP_WARN_at the Shrine to summon a|r |cRXP_ENEMY_Living Air|r
    >>Kill it and loot it for a |T463565:0|t[|cRXP_LOOT_Fluttering Breeze|r]
    .complete 29523,1 --1/1 Fluttering Breeze
    .use 72109
	.mob Living Air
step
    #loop
    .goto 378,47.98,31.97,0
    .goto 378,47.98,31.97,10,0
    .goto 378,46.07,27.94,10,0
    .goto 378,48.99,30.16,10,0
    .goto 378,46.83,34.88,10,0
    .goto 378,46.04,33.12,10,0
    .goto 378,46.17,27.09,10,0
    .goto 378,48.31,29.58,10,0
    .goto 378,50.06,31.41,10,0
    .goto 378,48.90,33.14,10,0
    .goto 378,49.58,36.46,10,0
    .goto 378,46.86,35.05,10,0
    .goto 378,46.01,33.12,10,0
    >>Pick up |cRXP_PICK_Loose Dogwood Roots|r on the ground next to the trees
    .complete 29418,1 --5/5 Dry Dogwood Root
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r and |cRXP_FRIENDLY_Shang Xi|r
    .turnin 29418 >>Turn in Kindling the Fire
    .turnin 29523 >>Turn in Fanning the Flames
	.target +Ji Firepaw
    .goto 378,50.24,21.26
    .accept 29420 >>Accept The Spirit's Guardian
    .goto 378,50.29,21.47
	.target +Master Shang Xi
step
   --#title |cFFFCDC00Enter the cave|r
    .goto 378,41.09,24.83,10 >> Enter the cave
    .isOnQuest 29420
step
    .goto 378,40.75,23.86,10,0
    .goto 378,40.84,22.19,10,0
    .goto 378,40,22.77,10,0
    .goto 378,38.81,25.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Li Fei|r
    >>|cRXP_WARN_Dodge the fire geysers en-route|r
    .turnin 29420 >>Turn in The Spirit's Guardian
    .accept 29664 >>Accept The Challenger's Fires
	.target Master Li Fei
 step
    >>Click on the |cRXP_PICK_Braziers|r
    .complete 29664,1 --1/1 Challenger Torch lit
    .goto 378,38.71,25.39
    .complete 29664,4 --1/1 Violet Brazier lit
    .goto 378,38.25,24.87
    .complete 29664,2 --1/1 Red Brazier lit
    .goto 378,38.99,23.50
    .complete 29664,3 --1/1 Blue Brazier lit
    .goto 378,39.19,25.41
step
    .goto 378,38.81,25.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Li Fei|r
    .turnin 29664 >>Turn in The Challenger's Fires
    .accept 29421 >>Accept Only the Worthy Shall Pass
	.target Master Li Fei
step
    .goto 378,38.81,25.50
    >>|cRXP_WARN_Defeat |cRXP_ENEMY_Master Li Fei|r by reducing his health to 20%|r
    .complete 29421,1 --1/1 Defeat Master Li Fei
	.mob Master Li Fei
step
    .goto 378,38.81,25.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Li Fei|r
    .turnin 29421,2 >>Turn in Only the Worthy Shall Pass
    .accept 29422 >>Accept Huo, the Spirit of Fire
	.target Master Li Fei
step
    --#title |cFFFCDC00Run up the ramp.|r Use |T133662:0|t[Huo's Offerings]
    .goto 378,39.41,29.55
	.cast 102522 >>|cRXP_WARN_Use|r |T133662:0|t[Huo's Offerings] |cRXP_WARN_on|r |cRXP_FRIENDLY_Huo|r
	.timer 11, Huo the Spirit of Fire RP
	.use 72583
    .target Huo
    .isOnQuest 29422
step
    .goto 378,39.41,29.55
    >>|cRXP_WARN_Wait for the RP to finish|r
    .complete 29422,1 --1/1 Reignite the Spirit of Fire
    .use 72583
    .target Huo
    .isOnQuest 29422
step
    .goto 378,39.41,29.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huo|r
    .turnin 29422 >>Turn in Huo, the Spirit of Fire
    .accept 29423 >>Accept The Passion of Shen-zin Su
	.target Huo
step
    --#title |cFFFCDC00Leave the cave|r
    .goto 378,40.12,25.50,20,0
    .goto 378,41.48,25.05,20,0
    .goto 378,42.0,25.29
    .subzone 5849,1 >>Leave the cave
step
	#completewith next
    --#title |cFFFCDC00Follow the arrow|r
    .goto 378,51.04,30.62,20,0
    .goto 378,51.89,35.93,20,0
    .goto 378,50.12,38.94,15,0
    .goto 378,50.32,37.48,20,0
    .goto 378,51.58,40.46
    .subzone 5820 >> Travel to the |cRXP_WARN_Temple of Five Dawns|r
step
    .goto 378,51.41,46.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29423 >>Turn in The Passion of Shen-zin Su
    .accept 29521 >>Accept The Singing Pools
	.target Master Shang Xi
step
    .isOnQuest 29521
    .goto 378,51.83,46.08
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cheng Dawnscrive|r
    .home >>Set your hearthstone to the Temple of Five Dawns
	.target Cheng Dawnscrive
step
    #completewith SingingPools
    .subzone 5826 >>Travel to the Singing Pools
step
    .isOnQuest 29521
    .goto 378,53.22,47.45,10,0
    .goto 378,57.12,46.63,10,0
    .goto 378,63.12,41.44
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Whittler Dewei|r
    .train 2366 >> Train Herbalism
    .target Whittler Dewei
    .skipgossipid 112959
    .skipgossipid 130364
    .skipgossipid 112911
step
    .isOnQuest 29521
    .goto 378,63.12,41.44
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Whittler Dewei|r
    .train 2575 >> Train Mining
	.target Whittler Dewei
    .skipgossipid 130364
    .skipgossipid 112912
    .skipgossipid 112975
step
    .goto 378,63.50,41.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jojo Ironbrow|r
    .accept 29662 >>Accept Stronger Than Reeds
	.target Jojo Ironbrow
step
    #completewith JumpOnPole
    +|cRXP_WARN_Mining/Herbalism nodes gives 1 mob worth of xp this expansion, remember to collect nearby nodes. You can collect all types of nodes regardless of your profession skill|r
step
    #completewith next
    +|cRXP_WARN_In this area, some water turns you into an animal, boosting your movement speed|r
step
    #label SingingPools
    .goto 378,65.59,42.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 29521 >>Turn in The Singing Pools
    .accept 29661 >>Accept The Lesson of Dry Fur
    .accept 29663 >>Accept The Lesson of the Balanced Rock
	.target Aysa Cloudsinger
step
    #completewith RingTrainingBell
	>>Defeat the |cRXP_ENEMY_Tushui Monks|r on the poles
    .complete 29663,1 --6/6 Defeat Tushui Monks
	.mob Tushui Monk
step
    .isOnQuest 29663
    .isQuestNotComplete 29663
    #label JumpOnPole
    .goto 378,63.37,45.17
	.vehicle >> Click on a |cRXP_FRIENDLY_Balance Pole|r |cRXP_WARN_while you are not in the water/are a frog|r
step
    #label RingTrainingBell
    .goto 378,61.41,47.81
    >>|cRXP_WARN_Click on |cRXP_FRIENDLY_Balance Poles|r to jump toward the|r |cRXP_PICK_Training Bell|r
    >>Click on the |cRXP_PICK_Training Bell|r
    .complete 29661,1 --1/1 Ring the Training Bell
step
    #completewith next
    >>Loot the |cRXP_PICK_Hard Tearwood Reed|r on the ground
    .complete 29662,1 --8/8 Hard Tearwood Reed
step
    #loop
    .goto 378,63.22,45.17,0
    .goto 378,63.22,45.17,20,0
    .goto 378,62.25,50,15,0
    .goto 378,60.43,48.97,15,0
    .goto 378,62.22,44.33,15,0
	>>Defeat the |cRXP_ENEMY_Tushui Monks|r on the poles
    .complete 29663,1 --6/6 Defeat Tushui Monks
	.mob Tushui Monk
step
    #completewith next
    --#title |cFFFCDC00Exit the vehicle|r
    .exitvehicle >>|cRXP_WARN_Exit the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step
    #loop
    .goto 378,62.85,49.06,0
    .goto 378,62.85,49.06,20,0
    .goto 378,60.53,49.31,20,0
    .goto 378,60.82,45.70,20,0
    >>Loot the |cRXP_PICK_Hard Tearwood Reed|r on the ground
    *|cRXP_WARN_If you stay at the edge then the |cRXP_ENEMY_Whitefeather Cranes|r won't attack you|r
    .complete 29662,1 --8/8 Hard Tearwood Reed
step
    .goto 378,63.50,41.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jojo Ironbrow|r
    .turnin 29662 >>Turn in Stronger Than Reeds
	.target Jojo Ironbrow
step
    .goto 378,65.59,42.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 29661 >>Turn in The Lesson of Dry Fur
    .turnin 29663 >>Turn in The Lesson of the Balanced Rock
    .accept 29676 >>Accept Finding an Old Friend
	.target Aysa Cloudsinger
step
    #completewith next
    +|cRXP_WARN_In this area, purple water ponds turns you into an animal, boosting your movement speed|r
step
    .goto 378,72.15,37.88,13,0
    .goto 378,70.62,38.73
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Man Liang|r
    .turnin 29676 >>Turn in Finding an Old Friend
    .accept 29666 >>Accept The Sting of Learning
    .accept 29677 >>Accept The Sun Pearl
	.target Old Man Liang
step
    #loop
    .goto 378,74.94,38.46,30,0
    .goto 378,72.21,46.53,30,0
    .goto 378,71.47,52.26,30,0
    >>Kill |cRXP_ENEMY_Water Pincers|r
    .complete 29666,1 --6/6 Water Pincer slain
    .mob Water Pincer
step
    .goto 378,76.21,46.87
    >>Click the |cRXP_PICK_Ancient Clam|r underwater
    >>|cRXP_WARN_You don't need to kill|r |cRXP_ENEMY_Fang-she|r
    .complete 29677,1 --1/1 Sun Pearl
    .mob Fang-she
step
    .goto 378,78.47,42.85
    .goto 378,70.62,38.73
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Old Man Liang|r
    >>|cRXP_WARN_If for some reason you can't find the quest giver, head back to his house west|r
    .turnin 29666 >>Turn in The Sting of Learning
    .turnin 29677 >>Turn in The Sun Pearl
    .accept 29678 >>Accept Shu, the Spirit of Water
	.target Old Man Liang
step
	.isOnQuest 29678
    .goto 378,79.66,41.83,4,0
    .goto 378,79.61,38.72
    >>Walk on top of the glowing circles
    >>|cRXP_WARN_This will allow you to jump toward the pool|r
    .complete 29678,1 --1/1 Cross to the Pool of Reflection
step
    .goto 378,79.59,38.58
    >>|cRXP_WARN_Use the|r |T463854:0|t[Sun Pearl] |cRXP_WARN_on the|r |cRXP_WARN_water's surface|r
    .complete 29678,2 --1/1 Coax Shu, the Water Spirit
    .use 73791
step
    .goto 378,79.82,39.31
    >>Click the Quest Turnin Pop-Up in your Questlog.
    .turnin 29678 >>Turn in Shu, the Spirit of Water
step
    .goto 378,79.82,39.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .accept 29679 >>Accept A New Friend
	.target Aysa Cloudsinger
step
    .goto 378,79.11,37.77
    >>Follow |cRXP_FRIENDLY_Shu|r closely as he moves around
    >>|cRXP_WARN_Move on top of the spouting water next to him|r
    .complete 29679,1 --5/5 Play with the Spirit of Water
	.target Shu
step
    .goto 378,79.82,39.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 29679 >>Turn in A New Friend
    .accept 29680 >>Accept The Source of Our Livelihood
	.target Aysa Cloudsinger
step
    .goto 378,76.57,57.36,40,0
    .goto 378,68.89,64.98
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
	>>|cRXP_WARN_The |cRXP_PICK_Delivery Cart|r is slower than running manually|r
    .turnin 29680 >>Turn in The Source of Our Livelihood
    .accept 29769 >>Accept Rascals
    .target Ji Firepaw
step
    .goto 378,68.13,66.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gao Summerdraft|r
    .accept 29770 >>Accept Still Good!
	.target Gao Summerdraft
step
	#completewith Carrots
    >>Kill |cRXP_ENEMY_Plump Virmens|r
    .complete 29769,1 --10/10 Plump Virmen slain
	.mob Plump Virmen
    .mob Plump Carrotcatcher
step
	.goto 378,70.11,77.63,0
    .goto 378,70.11,77.63,15,0
    .goto 378,69.55,79.23,15,0
    .goto 378,70.84,80.41,15,0
    .goto 378,71.46,78.11,15,0
#loop
	.line 378,70.11,77.63,69.55,79.23,70.84,80.41,71.46,78.11
	.goto 378,70.11,77.63,10,0
	.goto 378,69.55,79.23,10,0
	.goto 378,70.84,80.41,10,0
	.goto 378,71.46,78.11,10,0
    >>Loot the |cRXP_PICK_Uprooted Turnips|r on the ground
    .complete 29770,1 --3/3 Uprooted Turnip
step
	.goto 378,78.60,69.75,0
    .goto 378,75.54,72.25,20,0
    .goto 378,77.79,71.81,20,0
    .goto 378,78.01,72.56,15,0
    .goto 378,78.85,70.76,20,0
    .goto 378,78.6,69.74,20,0
#loop
	.line 378,77.35,70.51,78.12,72.61,78.82,70.88,78.6,69.75
	.goto 378,77.35,70.51,10,0
	.goto 378,78.12,72.61,10,0
	.goto 378,78.82,70.88,10,0
	.goto 378,78.60,69.75,10,0
    >>Loot the |cRXP_PICK_Pilfered Pumpkins|r on the ground
    .complete 29770,3 --3/3 Pilfered Pumpkin
step
	.isOnQuest 29770
    .goto 378,77.05,71.02,10 >> Enter the cave
step
	#label Carrots
	.goto 378,74.70,74.76,0
    .goto 378,76.1,71.26,15,0
    .goto 378,75.57,72.94,15,0
    .goto 378,73.97,72.58,15,0
    .goto 378,73.94,70.86,15,0
    .goto 378,74.7,74.76,15,0
#loop
	.line 378,73.97,72.58,73.94,70.86,74.7,74.76
	.goto 378,73.97,72.58,5,0
	.goto 378,73.94,70.86,5,0
	.goto 378,74.70,74.76,5,0
    >>Kill |cRXP_ENEMY_Plump Carrotcrunchers|r. Loot them for their |cRXP_LOOT_Carrots|r
    >>|cRXP_WARN_You can also loot the|r |cRXP_PICK_Carrots|r |cRXP_WARN_on the ground|r
    .complete 29770,2 --3/3 Stolen Carrot
	.mob Plump Carrotcruncher
step
	.isOnQuest 29770
    .goto 378,74.99,69.42,10 >> Leave the cave
step
	.goto 378,77.85,71.75,0
    .goto 378,74.73,67.2,15,0
    .goto 378,72.67,69.48,15,0
    .goto 378,70.75,71.61,15,0
    .goto 378,69.4,69.74,15,0
#loop
	.line 378,77.89,70.13,77.36,70.49,77.85,71.75
	.goto 378,77.89,70.13,10,0
	.goto 378,77.36,70.49,10,0
	.goto 378,77.85,71.75,10,0
    >>Kill |cRXP_ENEMY_Plump Virmens|r
    .complete 29769,1 --10/10 Plump Virmen slain
	.mob Plump Virmen
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gao Summerdraft|r, |cRXP_FRIENDLY_Ji Firepaw|r, and |cRXP_FRIENDLY_Jojo Ironbrow|r
    .turnin 29770 >>Turn in Still Good!
	.target +Gao Summerdraft
    .goto 378,68.13,66.40
    .turnin 29769 >>Turn in Rascals
    .accept 29768 >>Accept Missing Mallet
	.target +Ji Firepaw
	.goto 378,68.89,64.98
    .accept 29771 >>Accept Stronger Than Wood
	.target +Jojo Ironbrow
    .goto 378,69.16,66.71
step
	#completewith next
	>>Loot the |cRXP_PICK_Wood Planks|r on the ground
    .complete 29771,1 --12/12 Discarded Wood Plank
step
    .goto 378,62.63,77.05
	>>Loot the |cRXP_PICK_Mallet|r on the barrel
    >>|cRXP_WARN_You don't have to kill |cRXP_ENEMY_Raggis|r if you can avoid it|r
    .complete 29768,1 --1/1 Dai-Lo Recess Mallet
step
    #loop
    .goto 378,63.77,77.19,0
    .goto 378,63.77,77.19,15,0
    .goto 378,63.27,79.16,15,0
    .goto 378,62.94,79.04,15,0
    .goto 378,62.19,81.08,15,0
	>>Loot the |cRXP_PICK_Wood Planks|r on the ground
    .complete 29771,1 --12/12 Discarded Wood Plank
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jojo Ironbrow|r and |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 29771 >>Turn in Stronger Than Wood
    .target +Jojo Ironbrow
    .goto 378,69.16,66.71
    .turnin 29768 >>Turn in Missing Mallet
    .accept 29772 >>Accept Raucous Rousing
    .target +Ji Firepaw
	.goto 378,68.89,64.98
step
    .goto 378,68.95,64.80
    >>Click on the |cRXP_PICK_Gong|r
    .complete 29772,1 --1/1 Ring the town gong
step
    .goto 378,68.89,64.98
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 29772 >>Turn in Raucous Rousing
    .accept 29774 >>Accept Not In the Face!
	.target Ji Firepaw
step
    .goto 378,68.98,62.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shu|r
    .complete 29774,1 --1/1 Ask Shu for help
	.timer 15,Roleplay
	.target Shu
    .skipgossip
step
    .goto 378,68.89,64.98
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    >>|cRXP_WARN_Wait for the RP to finish|r
    .turnin 29774 >>Turn in Not In the Face!
    .accept 29775 >>Accept The Spirit and Body of Shen-zin Su
	.target Ji Firepaw
step
	.isOnQuest 29775
    .goto 378,58.86,63.38,40,0
    .goto 378,55.23,58.57,40,0
    .goto 378,51.48,57.40,20 >>Travel to the Temple of the Five Dawns
	>>|cRXP_WARN_The |cRXP_PICK_Delivery Cart|r is slower than running manually|r
    .subzoneskip 5820--temple of five dawns
step
    .goto 378,51.59,48.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29775 >>Turn in The Spirit and Body of Shen-zin Su
    .accept 29776 >>Accept Morning Breeze Village
	.timer 20,Morning Breeze Village RP
	.target Master Shang Xi
step
    .isOnQuest 29776
    .goto 378,51.46,48.93,7 >>|cRXP_WARN_Wait for the RP to finish|r
step
    #completewith next
    .subzoneskip 5830
	.isOnQuest 29776
    .goto 378,51.01,49.05,10,0
    .goto 378,40.19,50.79,20,0
    .goto 378,34.91,50.73,15,0
    .goto 378,33.1,42.6,15,0
    .goto 378,30.42,37.50,20 >>Travel to |cRXP_WARN_Morning Breeze Village|r
step
    .goto 378,30.97,36.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 29776 >>Turn in Morning Breeze Village
    .accept 29778 >>Accept Rewritten Wisdoms
	.target Ji Firepaw
step
    .goto 378,29.90,39.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jojo Ironbrow|r
    .accept 29783 >>Accept Stronger Than Stone
	.target Jojo Ironbrow
step
    .goto 378,31.78,39.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shaopai|r
    .accept 29777 >>Accept Tools of the Enemy
	.target Elder Shaopai
step
    .isOnQuest 29777
    #completewith Defaced Scroll of Wisdom burned
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shen Stonecarver|r
    .vendor >>|cRXP_WARN_Sell and repair if you need to|r
    .target Shen Stonecarver
step
    #completewith Defaced Scroll of Wisdom burned
    >>Kill |cRXP_ENEMY_Fe-Feng Wisemans|r. Loot them for their |cRXP_LOOT_Brushes|r
    .complete 29777,1 --8/8 Paint Soaked Brush
	.mob Fe-Feng Wiseman
step
    #completewith Defaced Scroll of Wisdom burned
    >>Loot the |cRXP_PICK_Stone Blocks|r on the ground
    .complete 29783,1 --12/12 Abandoned Stone Block
step
	.goto 378,28.71,50.23,0
    .goto 378,30.3,42.95,15,0
    .goto 378,29.49,45.36,15,0
    .goto 378,29.11,47.53,15,0
    .goto 378,29.78,47.67,15,0
    .goto 378,29.21,48.57,15,0
    .goto 378,28.37,49.37,15,0
    .goto 378,27.16,49.67,15,0
    .goto 378,28.54,49.93,15,0
    .goto 378,29.12,51.09,15,0
    .goto 378,31.19,47.97,15,0
    .goto 378,32.49,46.63,15,0
    .goto 378,33.13,46.32,15,0
#loop
	.line 378,33.42,50.88,32.57,53.31,28.71,50.23
	.goto 378,33.42,50.88,15,0
	.goto 378,32.57,53.31,15,0
	.goto 378,28.71,50.23,15,0
    #label Defaced Scroll of Wisdom burned
    >>Click the |cRXP_PICK_Banners|r on the monuments
    .complete 29778,1 --5/5 Defaced Scroll of Wisdom burned
step
    #completewith next
    >>Kill |cRXP_ENEMY_Fe-Feng Wisemans|r. Loot them for their |cRXP_LOOT_Brushes|r
    .complete 29777,1 --8/8 Paint Soaked Brush
	.mob Fe-Feng Wiseman
step
	.goto 378,31.32,52.22,0
    .goto 378,31.18,47.97,15,0
    .goto 378,32.57,46.43,15,0
    .goto 378,33.66,47.21,15,0
    .goto 378,33.99,50.9,15,0
    .goto 378,33.06,52.27,15,0
    .goto 378,32.16,50.53,15,0
    .goto 378,31.32,52.22,15,0
#loop
	.line 378,31.18,47.9,32.57,46.43,33.99,50.9,32.16,50.53,31.32,52.22
	.goto 378,31.18,47.90,15,0
	.goto 378,32.57,46.43,15,0
	.goto 378,33.99,50.90,15,0
	.goto 378,32.16,50.53,15,0
	.goto 378,31.32,52.22,15,0
    >>Loot the |cRXP_PICK_Stone Blocks|r on the ground
    .complete 29783,1 --12/12 Abandoned Stone Block
step
#loop
	.line 378,31.18,47.9,32.57,46.43,33.99,50.9,32.16,50.53,31.32,52.22
	.goto 378,31.32,52.22,0
	.goto 378,31.18,47.90,15,0
	.goto 378,32.57,46.43,15,0
	.goto 378,33.99,50.90,15,0
	.goto 378,32.16,50.53,15,0
	.goto 378,31.32,52.22,15,0
    >>Kill |cRXP_ENEMY_Fe-Feng Wisemans|r. Loot them for their |cRXP_LOOT_Brushes|r
    .complete 29777,1 --8/8 Paint Soaked Brush
	.mob Fe-Feng Wiseman
step
    .goto 378,31.751,39.784
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Shaopai|r
    .target Elder Shaopai
    .turnin 29777 >>Turn in Tools of the Enemy
step
    .goto 378,29.969,39.757
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jojo Ironbrow|r
    .target Jojo Ironbrow
    .turnin 29783 >>Turn in Stronger Than Stone
step
    .goto 378,30.950,36.774
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .target Ji Firepaw
    .turnin 29778 >>Turn in Rewritten Wisdoms
    .accept 29779 >>Accept The Direct Solution
    .accept 29780 >>Accept Do No Evil
    .accept 29781 >>Accept Monkey Advisory Warning
step
	.isOnQuest 29779
    .goto 378,29.28,39.98,15,0
    .goto 378,27.42,36.25,30,0
    .goto 378,26.42,33.68,30 >> Travel to the |cRXP_WARN_Jade Pillar|r
step
	#completewith RukRuk
	>>Kill |cRXP_ENEMY_Fe-Feng Hozen|r
    .complete 29779,1 --20/20 Fe-Feng Hozen slain
	.mob Fe-Feng Firethief
	.mob Fe-Feng Ruffian
step
    .goto 378,26.42,33.68
    >>Click the |cRXP_FRIENDLY_Jade Pillar|r
    .accept 29782 >>Accept Stronger Than Bone
step
    #completewith FeFeng
	>>Loot the |cRXP_PICK_Stolen Fireworks|r on the ground
    .complete 29781,1 --8/8 Stolen Firework Bundle
step
    #label RukRuk
    .goto 378,26.08,35.17,15,0
    .goto 378,20.94,34.43
	>>Kill |cRXP_ENEMY_Ruk-Ruk|r
    .complete 29780,1 --1/1 Ruk-Ruk slain
	.mob Ruk-Ruk
step
    #label FeFeng
	.goto 378,26.75,31.86,0
    .goto 378,26.75,31.86,15,0
    .goto 378,27.49,29.61,15,0
    .goto 378,25.72,29.91,15,0
    .goto 378,24.24,30.84,15,0
    .goto 378,20.52,34.6,10,0
#loop
	.line 378,24.24,30.84,25.72,29.91,27.49,29.61,26.75,31.86
	.goto 378,24.24,30.84,10,0
	.goto 378,25.72,29.91,10,0
	.goto 378,27.49,29.61,10,0
	.goto 378,26.75,31.86,10,0
    >>Kill |cRXP_ENEMY_Fe-Feng Hozen|r
    .complete 29779,1 --20/20 Fe-Feng Hozen slain
	.mob Fe-Feng Firethief
	.mob Fe-Feng Ruffian
step
#loop
	.line 378,24.24,30.84,25.72,29.91,27.49,29.61,26.75,31.86
	.goto 378,24.24,30.84,0
	.goto 378,24.24,30.84,10,0
	.goto 378,25.72,29.91,10,0
	.goto 378,27.49,29.61,10,0
	.goto 378,26.75,31.86,10,0
	>>Loot the |cRXP_PICK_Stolen Fireworks|r on the ground
    .complete 29781,1 --8/8 Stolen Firework Bundle
step
	#completewith next
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r, who should be next to you
    >>|cRXP_WARN_If he isn't there, skip this step|r
    .turnin 29779 >>Turn in The Direct Solution
    .turnin 29780 >>Turn in Do No Evil
    .turnin 29781 >>Turn in Monkey Advisory Warning
    .accept 29784 >>Accept Balanced Perspective
	.target Ji Firepaw
step
    .goto 378,29.90,39.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jojo Ironbrow|r
    .turnin 29782 >>Turn in Stronger Than Bone
	.target Jojo Ironbrow
step
    .goto 378,30.97,36.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 29779 >>Turn in The Direct Solution
    .turnin 29780 >>Turn in Do No Evil
    .turnin 29781 >>Turn in Monkey Advisory Warning
    .accept 29784 >>Accept Balanced Perspective
	.target Ji Firepaw
step
	#completewith next
    .goto 378,31.14,36.79,5,0
    .goto 378,32.17,36.36,8,0
    .goto 378,32.88,37.16,8,0
    .goto 378,32.94,35.61,8 >>|cRXP_WARN_Carefully|r walk over the rope
step
	#label BalancedP
    .goto 378,32.94,35.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 29784 >>Turn in Balanced Perspective
    .accept 29785 >>Accept Dafeng, the Spirit of Air
	.target Aysa Cloudsinger
step
	#sticky
	#label Temple1
    .goto 378,30.21,38.57,20,0
    .goto 378,28.94,62.89,20 >>Travel to the |cRXP_WARN_Chamber of Whispers|r
	.isOnQuest 29785
step
	#sticky
	#label Temple2
	#requires Temple1
    .goto 378,26.64,66.63,10 >> Run in between the sets of stairs after the first time the winds subside
	.isOnQuest 29785
step
	#sticky
	#label Temple3
	#requires Temple2
    .goto 378,26.64,66.63,10 >> Run toward |cRXP_FRIENDLY_Dafeng|r after the winds in the next room subside
	.isOnQuest 29785
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dafeng|r and |cRXP_FRIENDLY_Aysa|r
    .turnin 29785 >>Turn in Dafeng, the Spirit of Air
	.target +Dafeng
    .goto 378,24.65,69.80
    .accept 29786 >>Accept Battle for the Skies
	.target +Aysa Cloudsinger
    .goto 378,24.78,69.78
step
    .goto 378,29.54,60.74,5,0
    .goto 378,30.18,61.88,5,0
    .goto 378,30.93,61.59,5,0
    .goto 378,31.37,60.05,5,0
    .goto 378,29.78,58.93,5,0
    .goto 378,29.54,60.74,5,0
    .goto 378,30.18,61.88,5,0
    .goto 378,30.93,61.59,5,0
    .goto 378,31.37,60.05,5,0
    .goto 378,29.78,58.93,5,0
    .goto 378,30.52,59.72
	>>Click |cRXP_PICK_Firework Launchers|r on the ground when |cRXP_ENEMY_Zhao-Ren|r flies over them to damage him
    >>He circles counter-clockwise. |cRXP_WARN_Avoid his Lightning puddles|r. Damage him when he lands. Kill him when he lands the second time
    .complete 29786,1 --1/1 Zhao-Ren slain
	.target Zhao-Ren
step
    .goto 378,29.99,60.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29786 >>Turn in Battle for the Skies
    .accept 29787 >>Accept Worthy of Passing
	.target Master Shang Xi
step
	#completewith next
    .goto 378,26.32,52.83,20,0
    .goto 378,22.70,52.80,40 >>Travel |cRXP_WARN_to The Elders' Path|r
step
    .goto 378,22.70,52.80
	>>Kill the |cRXP_ENEMY_Guardian of the Elders|r
    .complete 29787,1 --1/1 Guardian of the Elders slain
	.timer 19,Worthy of Passing RP
	.target Guardian of the Elders
step
    .goto 378,19.45,51.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
	>>|cRXP_WARN_Wait for the RP to finish|r
    .turnin 29787 >>Turn in Worthy of Passing
    .accept 29788 >>Accept Unwelcome Nature
    .accept 29789 >>Accept Small, But Significant
	.target Master Shang Xi
step
    #loop
    .goto 378,18.84,51.88,0
    .goto 378,18.84,51.88,30,0
    .goto 378,18.43,49.88,30,0
    .goto 378,18.37,48.13,30,0
    .goto 378,21.57,49.29,30,0
    .goto 378,22.50,48.95,30,0
    .goto 378,24.22,45.72,30,0
    .goto 378,18.18,44.52,30,0
    .goto 378,18.18,44.52,30,0
	>>Kill |cRXP_ENEMY_Thornbranch Scamps|r
    >>Loot the |cRXP_PICK_Charms|r hanging from the trees
    .complete 29788,1 --8/8 Thornbranch Scamp slain
	.mob +Thornbranch Scamp
    .complete 29789,1 --8/8 Kun-Pai Ritual Charm
step
    .goto 378,19.46,51.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Shang Xi|r
    .turnin 29788 >>Turn in Unwelcome Nature
    .turnin 29789 >>Turn in Small, But Significant
    .accept 29790 >>Accept Passing Wisdom
	.timer 83,Passing Wisdom RP
	.target Master Shang Xi
step
    .goto 378,17.29,50.78
    >>Wait out the RP at the arrow location
    >>|cRXP_WARN_If you go past that, |cRXP_FRIENDLY_Shang Xi|r will despawn. If that happens, abandon the quest and start the RP again|r
    .complete 29790,1 --1/1 Listen to Master Shang Xi
	.target Master Shang Xi
step
    .goto 378,15.79,49.10
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 29790 >>Turn in Passing Wisdom
    .accept 29791 >>Accept The Suffering of Shen-zin Su
	.target Aysa Cloudsinger
step
    .goto 378,15.55,48.91
    >>Click the |cRXP_PICK_Air Balloon|r to Board it
    .complete 29791,1 --1/1 Board the Hot Air Balloon
	.timer 231,The Suffering of Shen-zin Su RP
step
    .goto 378,30.8,92.9
	>>|cRXP_WARN_Wait out the RP|r
    .complete 29791,2 --1/1 Uncover the source of Shen-zin Su's pain
step
    .goto 378,51.35,57.21,20,0
    .goto 378,51.31,48.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shaopai|r
    .turnin 29791 >>Turn in The Suffering of Shen-zin Su
    .accept 29792 >>Accept Bidden to Greatness
	.target Elder Shaopai
step
    .goto 378,51.60,61.39
    --#title |cFFFCDC00Follow the arrow|r
    >>|cRXP_WARN_Follow the arrow|r
    .complete 29792,1 --1/1 Open the Mandori Village Gate
step
	#completewith next
    .goto 378,50.66,65.62,20,0
    .goto 378,52.28,68.43,30 >>Travel |cRXP_WARN_to the Pei-Wu Gate|r
	.timer 28,Pei-Wu Gate RP
step
    .goto 378,52.28,68.43
    >>|cFFFCDC00Follow the arrow|r. Wait for the RP
    .complete 29792,2 --1/1 Open the Pei-Wu Forest Gate
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wei|r and |cRXP_FRIENDLY_Korga|r
    .turnin 29792 >>Turn in Bidden to Greatness
    .accept 30591 >>Accept Preying on the Predators
	.target +Wei Palerage
    .goto 378,50.07,76.63
    .accept 29795 >>Accept Stocking Stalks
	.target +Korga Strongmane
    .goto 378,50.22,76.65
step
    #loop
	.line 378,54.51,85.54,45.05,85.81,45.89,71.57,55.62,69.49,54.51,85.54
	.goto 378,54.51,85.54,40,0
	.goto 378,45.05,85.81,40,0
	.goto 378,45.89,71.57,40,0
	.goto 378,55.62,69.49,40,0
	.goto 378,54.51,85.54,0
    >>Kill |cRXP_ENEMY_Pei-Wu Tigers|r
    >>Loot the |cRXP_PICK_Bamboo Stalks|r on the ground
    .complete 30591,1 --9/9 Pei-Wu Tiger slain
	.mob +Pei-Wu Tiger
    .complete 29795,1 --10/10 Broken Bamboo Stalk
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wei|r and |cRXP_FRIENDLY_Korga|r
    .turnin 30591 >>Turn in Preying on the Predators
	.target +Wei Palerage
    .goto 378,50.07,76.63
    .turnin 29795 >>Turn in Stocking Stalks
    .accept 30589 >>Accept Wrecking the Wreck
	.target +Korga Strongmane
    .goto 378,50.22,76.65
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Makael|r and |cRXP_FRIENDLY_Ji|r
    .turnin 30589 >>Turn in Wrecking the Wreck
    .accept 30590 >>Accept Handle With Care
	.target +Makael Bay
    .goto 378,36.32,72.36
    .accept 29793 >>Accept Evil from the Seas
	.target +Ji Firepaw
    .goto 378,36.37,72.53
step
    #loop
    .goto 378,36.06,76.73,0
    .goto 378,36.06,76.73,40,0
    .goto 378,35.41,79.00,40,0
    .goto 378,40.14,78.79,40,0
    .goto 378,38.29,74.01,40,0
    >>Kill |cRXP_ENEMY_Darkened Horrors|r and |cRXP_ENEMY_Darkened Terrors|r
	>>Loot the |cRXP_PICK_Explosion Bundles|r on the ground
    >>|cRXP_WARN_Be careful of the Horrors' Shadow Geysers|r
    .complete 29793,1 --8/8 Darkened Horrors or Darkened Terrors slain
	.mob +Darkened Horror
	.mob +Darkened Terror
    .complete 30590,1 --6/6 Packed Explosion Charge
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Makael Bay|r and |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 30590 >>Turn in Handle With Care
	.target +Makael Bay
    .goto 378,36.32,72.36
    .turnin 29793 >>Turn in Evil from the Seas
    .accept 29796 >>Accept Urgent News
	.target +Ji Firepaw
    .goto 378,36.37,72.53
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Delora Lionheart|r and |cRXP_FRIENDLY_Jojo Ironbrow|r
    .turnin 29796 >>Turn in Urgent News
    .accept 29794 >>Accept None Left Behind
    .accept 29797 >>Accept Medical Supplies
	.target +Delora Lionheart
    .goto 378,42.21,86.54
    .accept 29665 >>Accept From Bad to Worse
	.target +Jojo Ironbrow
    .goto 378,42.30,86.35
step << skip
    #optional
    #completewith next
    #label InjuredSailorA
    .goto 378,42.27,86.80,0,0
    >>Carry the |cRXP_FRIENDLY_Injured Sailor|r back to |cRXP_FRIENDLY_Delora's|r Camp.
    .complete 29794,1,1 --3/3 Injured Sailors rescued
step << skip
    #optional
	#completewith InjuredSailorA
    .goto 378,40.18,87.69
	.cast 56685 >>Pick up an |cRXP_FRIENDLY_Injured Sailor|r on the ground
	.isOnQuest 29794
	.target Injured Sailor
step << skip
    #optional
    #requires InjuredSailorA
    .goto 378,42.27,86.80
    >>Carry the |cRXP_FRIENDLY_Injured Sailor|r back to |cRXP_FRIENDLY_Delora's|r Camp.
    .complete 29794,1,1 --3/3 Injured Sailors rescued
step << skip
    #optional
    #completewith next
	#label InjuredSailorB
    .goto 378,42.27,86.80,0,0
    >>Carry the |cRXP_FRIENDLY_Injured Sailor|r back to |cRXP_FRIENDLY_Delora's|r Camp.
    .complete 29794,1,2 --3/3 Injured Sailors rescued
step << skip
    #optional
	#completewith InjuredSailorB
    .goto 378,39.41,87.98
	.cast 56685 >>Pick up the |cRXP_FRIENDLY_Injured Sailor|r.
	.isOnQuest 29794
	.target Injured Sailor
step << skip
    #optional
    #requires InjuredSailorB
    .goto 378,42.27,86.80
    >>Carry the |cRXP_FRIENDLY_Injured Sailor|r back to |cRXP_FRIENDLY_Delora's|r Camp.
    .complete 29794,1,2 --3/3 Injured Sailors rescued
step
	#completewith InjuredSailorB
    >>Kill |cRXP_ENEMY_Deepscale Tormentors|r
    >>Loot the |cRXP_PICK_Medical Crates|r on the ground
    .complete 29665,1 --8/8 Deepscale Tormentor slain
	.mob +Deepscale Tormentor
    .complete 29797,1 --8/8 Alliance Medical Supplies
step
    .waypoint 378,42.27,86.80,-129340,wpbuff,UNIT_AURA--put this WP at the top, this is where to point at once you have the buff
    .waypoint 378,42.27,86.80,-105520,wpbuff,UNIT_AURA--put this WP at the top, this is where to point at once you have the buff
    .waypoint 378,40.18,87.69,10
    .waypoint 378,40.01,84.36,10
    .waypoint 378,38.08,84.73,10
    .waypoint 378,38.41,83.09,10
    .waypoint 378,37.60,81.44,10
    .waypoint 378,35.49,83.80,10
    .waypoint 378,36.17,87.63,10
    .waypoint 378,37.66,87.22,10
    .waypoint 378,38.36,87.43,10
    .goto 378,40.18,87.69
    >>Pick up an |cRXP_FRIENDLY_Injured Sailor|r on the ground and bring him back to |cRXP_FRIENDLY_Delora Lionheart's|r camp
    >>|cRXP_WARN_Do this at least twice|r
    .complete 29794,1,2 --2/3 Injured Sailors rescued
    .target Injured Sailor
step
#optional
#label InjuredSailorB
step
    #optional
    #loop
    .goto 378,37.86,83.22,0
    .goto 378,38.36,87.60,20,0
    .goto 378,37.04,87.93,20,0
    .goto 378,35.77,86.77,20,0
    .goto 378,36.40,83.30,20,0
    .goto 378,37.92,81.39,20,0
    .goto 378,37.86,83.22,20,0
    .goto 378,36.41,85.51,10,0
    .goto 378,36.82,89.24,20,0
    .goto 378,38.36,87.60,20,0
    .goto 378,37.04,87.93,20,0
    .goto 378,35.77,86.77,20,0
    .goto 378,36.40,83.30,20,0
    .goto 378,37.92,81.39,20,0
    .goto 378,37.86,83.22,20,0
    .goto 378,36.41,85.51,15,0
    .goto 378,36.82,89.24,15,0
    >>Kill |cRXP_ENEMY_Deepscale Tormentors|r
    >>Loot the |cRXP_PICK_Medical Crates|r on the ground
	>>|cRXP_WARN_Don't pick up a new |cRXP_FRIENDLY_Injured Sailor|r yet|r
    .complete 29665,1 --8/8 Deepscale Tormentor slain
	.mob +Deepscale Tormentor
    .complete 29797,1 --8/8 Alliance Medical Supplies
step
    #label InjuredSailorC
	#completewith next
    .goto 378,38.36,87.43,10,0
    .goto 378,37.66,87.22,10,0
    .goto 378,36.17,87.63,10,0
    .goto 378,35.49,83.80,10,0
    .goto 378,37.60,81.44,10,0
    .goto 378,38.41,83.09,10,0
    .goto 378,38.08,84.73,10,0
    .goto 378,40.01,84.36,10,0
    .goto 378,40.18,87.69
	.cast 56685 >>Pick up an |cRXP_FRIENDLY_Injured Sailor|r
	.isOnQuest 29794
	.target Injured Sailor
step
    #requires InjuredSailorC
    .goto 378,42.27,86.80
    >>Carry the |cRXP_FRIENDLY_Injured Sailor|r back to |cRXP_FRIENDLY_Delora Lionheart's|r Camp
    .complete 29794,1 --3/3 Injured Sailors rescued
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Delora Lionheart|r and |cRXP_FRIENDLY_Jojo Ironbrow|r
    .turnin 29794 >>Turn in None Left Behind
    .turnin 29797 >>Turn in Medical Supplies
	.target +Delora Lionheart
    .goto 378,42.21,86.54
    .turnin 29665 >>Turn in From Bad to Worse
    .accept 29798 >>Accept An Ancient Evil
	.target +Jojo Ironbrow
    .goto 378,42.30,86.35
step
    .goto 378,36.50,84.23
    >>Kill |cRXP_ENEMY_Vordraka, The Deep Sea Nightmare|r
    *|cRXP_WARN_Dodge his Deep Sea Smash|r
    *|cRXP_WARN_Kill |cRXP_ENEMY_Deepscale Aggressors|r when they spawn|r
    .complete 29798,1 --1/1 Vordraka, the Deep Sea Nightmare slain
	.mob Vordraka, The Deep Sea Nightmare
    .mob Deepscale Aggressor
step
    .goto 378,36.50,84.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 29798 >>Turn in An Ancient Evil
    .accept 30767 >>Accept Risking It All
    .timer 77,Risking It All RP
	.target Aysa Cloudsinger
	.skipgossip
step
    .goto 378,36.35,86.08,10,0 << skip
    .goto 378,36.27,86.99,10,0 << skip
    .goto 378,36.90,85.50,5,0 << skip
    .goto 378,36.36,87.2,10,0 << skip
    .goto 378,36.38,87.12 << skip
    >>Wait out the RP
    >>|cRXP_WARN_Take a break if you wish|r
	>>|cRXP_WARN_Press "Escape" on your keyboard to skip the cinematic|r
    .complete 30767,1 --1/1 Shen-zin Su's Thorn Removed
step
    .goto 378,39.30,86.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 30767 >>Turn in Risking It All
    .accept 29799 >>Accept The Healing of Shen-zin Su
	.target Ji Firepaw
step
    .goto 378,39.08,88.32,5,0
    .goto 378,39.04,88.87,5,0
    .goto 378,39.89,88.62,5,0
    .goto 378,42.92,87.31,5,0
    .goto 378,42.85,85.16,5,0
    .goto 378,42.01,84.89,5,0
    .goto 378,42.31,83.89,5,0
    .goto 378,41.21,83.78,5,0
    .goto 378,40.55,82.45,5,0
    .goto 378,40.26,83.35,5,0
    .goto 378,40.12,84.37,5,0
    .goto 378,38.44,86.07
    >>Click on the |cRXP_PICK_Loose Wreckages|r and help |cRXP_FRIENDLY_Alliance Priests|r and |cRXP_FRIENDLY_Horde Druids|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alliance Priests|r and |cRXP_FRIENDLY_Horde Druids|r
    *|cRXP_WARN_Kill |cRXP_ENEMY_Dampscale Fleshrippers|r if they're attacking them|r
    .complete 29799,1 --1/1 Protect the healers
	.target Alliance Priest
	.target Horde Druid
	.mob Dampscale Fleshripper
step
    .goto 378,39.30,86.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
	>>|cRXP_WARN_Press "Escape" on your keyboard to skip the cinematic|r.
    .turnin 29799 >>Turn in The Healing of Shen-zin Su
	.timer 18,The Healing of Shen-zin Su RP
	.target Ji Firepaw
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    >>|cRXP_WARN_Wait out the RP|r
    .goto 378,38.77,86.32
    .accept 29800 >>Accept New Allies
	.target Ji Firepaw
step
    #completewith next
    .hs >> Hearthstone to |cRXP_WARN_the Temple of Five Dawns|r
step
    .goto 378,51.45,48.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Spirit of Shang Xi|r and select your Faction
	>>|cRXP_WARN_Press "Escape" on your keyboard to skip the cinematic|r
    .turnin 29800 >>Turn in New Allies
    .accept 31450 >>Accept A New Fate
    .complete 31450,1 --1/1 Choose your faction
    .skipgossip
	.target Spirit of Shang Xi
step
    .zoneskip 84
    .goto 1,45.58,12.61
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ji Firepaw|r
    .turnin 31450 >>Turn in A New Fate
    .accept 31012 >>Accept Joining the Horde
    .target Ji Firepaw
step
    .zoneskip 1
    .zoneskip 85
    .goto 84,74.19,91.98
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aysa Cloudsinger|r
    .turnin 31450 >>Turn in A New Fate
	.accept 30987 >>Accept Joining the Alliance
	.target Aysa Cloudsinger
step
#optional
.neutralzonefinished
step <<skip
--TODO: skip this? the whole trip to SW keep is way too long
    .zoneskip 1
    .zoneskip 85
    .goto 84,74.19,91.98
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Varian Wrynn|r
	.turnin 30987 >>Turn in Joining the Alliance
	.target King Varian Wrynn
    .neutralzonefinished
step
    .zoneskip 84
    #completewith next
    .goto 85,49.87,75.52,20 >> Enter Grommash Hold
step
    .zoneskip 84
    .goto 85,48.76,70.77
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garrosh Hellscream|r
    .turnin 31012 >> Turn in Joining the Horde
    .target Garrosh Hellscream
    .neutralzonefinished
step
.zoneskip 84
.zoneskip 1
.zoneskip 85
+Congratulations, you just finished the pandaren starting zone, please click on the cogwheel button under the RXP window and select the appropriate follow-up guide
]])

