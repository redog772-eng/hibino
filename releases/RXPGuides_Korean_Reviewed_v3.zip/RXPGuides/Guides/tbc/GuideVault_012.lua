if not RXPGuides or type(RXPGuides.RegisterGuide) ~= "function" then return end
local _, rxpGuideVaultAddon = ...
local rxpGuideVaultGame = rxpGuideVaultAddon and rxpGuideVaultAddon.game
if not rxpGuideVaultGame then
    local rxpGuideVaultVersion = select(4, GetBuildInfo())
    if rxpGuideVaultVersion > 60000 then
        rxpGuideVaultGame = "RETAIL"
    elseif rxpGuideVaultVersion > 50000 then
        rxpGuideVaultGame = "MOP"
    elseif rxpGuideVaultVersion > 40000 then
        rxpGuideVaultGame = "CATA"
    elseif rxpGuideVaultVersion > 30000 then
        rxpGuideVaultGame = "WOTLK"
    elseif rxpGuideVaultVersion > 20000 then
        rxpGuideVaultGame = "TBC"
    elseif rxpGuideVaultVersion >= 16000 and rxpGuideVaultVersion < 20000 then
        rxpGuideVaultGame = "FOREVER"
    else
        rxpGuideVaultGame = "CLASSIC"
    end
end
if rxpGuideVaultGame ~= "TBC" then return end

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (A)
#subgroup RXP Survival Guide 47-60
<< Alliance
#name 53-53 Felwood
#next 53-55 Un'Goro Crater
step
#completewith next
.goto Ashenvale,55.97,31.97,0
.goto Felwood,54.14,86.83
.zone Felwood >> Travel to Felwood
step
.goto Felwood,54.14,86.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arathandris Silversky|r
.accept 4101 >> Accept Cleansing Felwood
.target Arathandris Silversky
step
.goto Felwood,51.569,82.172
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrim|r
.fp Emerald Sanctuary >> Get the Emerald Sanctuary flight path
.target Gorrim
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.accept 5155 >> Accept Forces of Jaedenar
.goto Felwood,51.21,82.10
.target Greta Mosshoof
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.accept 4421 >> Accept The Corruption of the Jadefire
.goto Felwood,51.350,81.511
.target Eridan Bluewind
step
.goto Felwood,50.889,81.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn Redfeather|r
.accept 5156 >> Accept Verifying the Corruption
.target Taronn Redfeather
step
.goto Felwood,50.927,85.005
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grazle|r
.accept 8460 >> Accept Timbermaw Ally
.target Grazle
step
#loop
.goto Felwood,48.48,89.60,0
.goto Felwood,48.22,93.81,0
.goto Felwood,46.68,88.03,0
.goto Felwood,48.48,89.60,70,0
.goto Felwood,48.22,93.81,70,0
.goto Felwood,46.68,88.03,70,0
>>Kill |cRXP_ENEMY_Deadwood Warriors|r, |cRXP_ENEMY_Deadwood Pathfinders|r and |cRXP_ENEMY_Deadwood Gardeners|r
.complete 8460,1 
.mob +Deadwood Warrior
.complete 8460,2 
.mob +Deadwood Pathfinder
.complete 8460,3 
.mob +Deadwood Gardener
step
#completewith next
.use 11912 >> |cRXP_WARN_Open the|r |T132763:0|t[Package of Empty Ooze Containers]
.collect 11914,6 
.collect 11948,6 
step
.goto Felwood,40.77,66.86
>>Kill |cRXP_ENEMY_Cursed Oozes|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Cursed Ooze Jars] |cRXP_WARN_on their corpses|r
.complete 4512,1 
.use 11912 
.use 11914 
.mob Cursed Ooze
step
>>Kill |cRXP_ENEMY_Jadefire Felsworns|r, |cRXP_ENEMY_Jadefire Shadowstalkers|r, |cRXP_ENEMY_Jadefire Rogues|r and |cRXP_ENEMY_Xavathras|r
.complete 4421,1 
.mob +Jadefire Felsworn
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91,60,0
.goto Felwood,32.23,67.10,60,0
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91
.complete 4421,2 
.mob +Jadefire Shadowstalker
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91,60,0
.goto Felwood,32.23,67.10,60,0
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91
.complete 4421,3 
.mob +Jadefire Rogue
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91,60,0
.goto Felwood,32.23,67.10,60,0
.goto Felwood,37.19,68.93,60,0
.goto Felwood,37.34,66.91
.complete 4421,4 
.mob +Xavathras
.goto Felwood,32.23,67.10

step << Warlock
#optional
.isQuestComplete 8419
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.turnin 8419 >> Turn in An Imp's Request
.accept 8421 >> Accept The Wrong Stuff
.target Impsy
step << Warlock
#optional
.isQuestTurnedIn 8419
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.accept 8421 >> Accept The Wrong Stuff
.target Impsy
step << Warlock
#optional
.isOnQuest 8421
.goto Felwood,39.92,54.77,50,0
.goto Felwood,40.48,59.07,70,0
.goto Felwood,39.92,54.77
>>Kill |cRXP_ENEMY_Tainted Oozes|r. Loot them for their |cRXP_LOOT_Bloodvenom Essences|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Tainted Ooze Jars] |cRXP_WARN_on their corpses|r
.use 11948 
.complete 8421,2 
.complete 4512,2 
.mob Tainted Ooze
step
#completewith next
.goto Felwood,40.48,59.07,0
.goto Felwood,39.98,54.76,0
>>Kill |cRXP_ENEMY_Tainted Oozes|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Tainted Ooze Jars] |cRXP_WARN_on their corpses|r
.use 11948 
.complete 4512,2 
.mob Tainted Ooze
step
#loop
.goto Felwood,38.55,59.14,0
.goto Felwood,36.49,61.40,0
.goto Felwood,35.01,59.83,0
.goto Felwood,38.55,59.14,0
.goto Felwood,38.55,59.14,50,0
.goto Felwood,36.49,61.40,60,0
.goto Felwood,35.01,59.83,60,0
.goto Felwood,38.55,59.14,60,0
>>Kill |cRXP_ENEMY_Jaedenar Hounds|r, |cRXP_ENEMY_Jaedenar Guardians|r, |cRXP_ENEMY_Jaedenar Adepts|r and |cRXP_ENEMY_Jaedenar Cultists|r
.complete 5155,1 
.mob +Jaedenar Hound
.complete 5155,2 
.mob +Jaedenar Guardian
.complete 5155,3 
.mob +Jaedenar Adept
.complete 5155,4 
.mob +Jaedenar Cultist
step
.goto Felwood,40.48,59.07,70,0
.goto Felwood,39.92,54.77
>>Kill |cRXP_ENEMY_Tainted Oozes|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Tainted Ooze Jars] |cRXP_WARN_on their corpses|r
.use 11948 
.complete 4512,2 
.mob Tainted Ooze
step
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5155 >> Turn in Forces of Jaedenar
.accept 5157 >> Accept Collection of the Corrupt Water
.target Greta Mosshoof
step
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.turnin 4421 >> Turn in The Corruption of the Jadefire
.accept 4906 >> Accept Further Corruption
.target Eridan Bluewind
step
.goto Felwood,50.927,85.005
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grazle|r
.turnin 8460 >> Turn in Timbermaw Ally
.accept 8462 >> Accept Speak to Nafien
.target Grazle
step
.goto Felwood,38.55,59.14,50,0
.goto Felwood,35.173,59.778
.use 12922 >>|cRXP_WARN_Use the|r |T132788:0|t[Empty Canteen] |cRXP_WARN_at the Moon Well in the center of Jaedenar|r
.complete 5157,1 
step
>>Kill |cRXP_ENEMY_Entropic Beasts|r and |cRXP_ENEMY_Entropic Horrors|r
.complete 5156,1 
.mob +Entropic Beast
.goto Felwood,41.535,43.007,50,0
.goto Felwood,40.91,40.37,50,0
.goto Felwood,42.84,37.62,60,0
.goto Felwood,45.43,40.02,60,0
.goto Felwood,41.10,41.06
.complete 5156,2 
.mob +Entropic Horror
.goto Felwood,41.535,43.007,50,0
.goto Felwood,40.91,40.37,50,0
.goto Felwood,42.84,37.62,60,0
.goto Felwood,45.43,40.02,60,0
.goto Felwood,41.10,41.06
.complete 5156,3 
.goto Felwood,41.535,43.007
step
.isQuestTurnedIn 4421
.goto Felwood,41.58,19.19,90,0
.goto Felwood,38.98,22.31
>>Kill |cRXP_ENEMY_Xavaric|r. Loot him for the |T133942:0|t[|cRXP_LOOT_Flute of Xavaric|r]
>>|cRXP_WARN_Use the |T133942:0|t[|cRXP_LOOT_Flute of Xavaric|r] to start the quest|r
.complete 4906,4 
.collect 11668,1,939,1 
.accept 939 >> Accept Flute of Xavaric
.use 11668 
.mob Xavaric
step
.isQuestTurnedIn 4421
#loop
.goto Felwood,38.98,22.31,0
.goto Felwood,43.44,14.47,0
.goto Felwood,38.98,22.31,70,0
.goto Felwood,43.44,14.47,70,0
>>Kill |cRXP_ENEMY_Jadefire Hellcallers|r, |cRXP_ENEMY_Jadefire Betrayers|r and |cRXP_ENEMY_Jadefire Trickster|r. Loot them for their |cRXP_LOOT_Jadefire Felbinds|r
.complete 4906,1 
.mob +Jadefire Hellcaller
.complete 4906,2 
.mob +Jadefire Betrayer
.complete 4906,3 
.mob +Jadefire Trickster
.complete 939,1 
.mob +Jadefire Hellcaller
.mob +Jadefire Betrayer
.mob +Jadefire Trickster
step << Warlock
#optional
.isOnQuest 8421
#loop
.goto Felwood,49.0,29.6,0
.goto Felwood,53.0,22.8,0
.goto Felwood,49.4,18.0,0
.goto Felwood,46.4,24.6,0
.goto Felwood,49.0,29.6,70,0
.goto Felwood,53.0,22.8,70,0
.goto Felwood,49.4,18.0,70,0
.goto Felwood,46.4,24.6,70,0
>>Kill |cRXP_ENEMY_Irontree Stompers|r, |cRXP_ENEMY_Irontree Wanderers|r and |cRXP_ENEMY_Withered Protectors|r. Loot them for their |cRXP_LOOT_Rotting Wood|r
.complete 8421,1 
.mob Irontree Stomper
.mob Irontree Wanderer
.mob Withered Protector
step
.goto Felwood,57.30,17.79
>>Kill |cRXP_ENEMY_Warpwood Moss Flayers|r and |cRXP_ENEMY_Warpwood Shredders|r. Loot them for their |cRXP_LOOT_Blood Ambers|r
.complete 4101,1 
.mob Warpwood Moss Flayer
.mob Warpwood Shredder

step << Warlock
.dungeon ST
.isQuestComplete 8421
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.turnin 8421 >> Turn in The Wrong Stuff
.accept 8422 >> Accept Trolls of a Feather
.target Impsy
step << Warlock
.dungeon ST
.isQuestTurnedIn 8421
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.accept 8422 >> Accept Trolls of a Feather
.target Impsy
step
.isOnQuest 5157,939,4906,5156,4101
#completewith next
.subzone 1998 >> Travel to Talonbranch Glade
step
.isOnQuest 5157,939,4906,5156,4101
.goto Felwood,62.406,25.780
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mylini Frostmoon|r
.vendor >> |cRXP_WARN_Ensure to vendor your trash in Talonbranch Glade as there is no vendor to sell to at the Emerald Sanctuary|r
.target Mylini Frostmoon
step
.goto Felwood,62.488,24.242
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishellena|r
.fp Talonbranch Glade >> Get the Talonbranch Glade Flight Path
.fly Emerald Sanctuary >> Fly to Emerald Sanctuary
.target Mishellena
step
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5157 >> Turn in Collection of the Corrupt Water
.accept 5158 >> Accept Seeking Spiritual Aid
.target Greta Mosshoof
step
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.turnin 4906 >> Turn in Further Corruption
.turnin 939 >> Turn in Flute of Xavaric
.accept 4441 >> Accept Felbound Ancients
.target Eridan Bluewind
step
.goto Felwood,50.889,81.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn Redfeather|r
.turnin 5156 >> Turn in Verifying the Corruption
.target Taronn Redfeather
step
.goto Felwood,54.14,86.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arathandris Silversky|r
.turnin 4101 >> Turn in Cleansing Felwood
.target Arathandris Silversky
step
.isQuestTurnedIn 4101
.goto Felwood,54.14,86.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arathandris Silversky|r
>>|cRXP_WARN_Select the option:|r "I need a Cenarion beacon."
.collect 11511,1 
.target Arathandris Silversky
step << !Mage
#completewith SeekingSpiritualAid
.goto Felwood,51.569,82.172
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrim|r
.fly Ratchet >> Fly to Ratchet
.target Gorrim
step << Mage
#completewith SeekingSpiritualAid
.cast 49359 >> |cRXP_WARN_Cast|r |T135764:0|t[Teleport: Theramore]
.usespell 49359
.train 49359,3
.zoneskip Dustwallow Marsh
step << Mage
#completewith SeekingSpiritualAid
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baldruc|r
.goto Dustwallow Marsh,67.476,51.300
.fly Ratchet >> Fly to Ratchet
.target Baldruc
step << Warlock
.isQuestComplete 1804
.goto The Barrens,62.627,35.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Strahad Farsan|r
.turnin 1804 >> Turn in Tome of the Cabal
.target Strahad Farsan
step << Warlock
.isQuestTurnedIn 1804
.goto The Barrens,62.627,35.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Strahad Farsan|r
.accept 1795 >> Accept The Binding
.target Strahad Farsan
step << Warlock
#completewith next
.goto The Barrens,62.6,35.2
.cast 8712 >> |cRXP_WARN_Use the|r |T133740:0|t[Tome of the Cabal] |cRXP_WARN_at the summoning circle|r
.use 6999
step << Warlock
.isQuestTurnedIn 1804
.goto The Barrens,62.6,35.2
>>Kill the |cRXP_ENEMY_Summoned Felhunter|r
.use 6999
.complete 1795,1 
.mob Summoned Felhunter
step << Warlock
.isQuestTurnedIn 1804
.goto The Barrens,62.627,35.500
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Strahad Farsan|r
.turnin 1795 >> Turn in The Binding
step
.goto The Barrens,62.448,38.734
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv Rizzlefix|r
.accept 4502 >> Accept Volcanic Activity
.target Liv Rizzlefix
step
.goto The Barrens,62.500,38.546
>>Open |cRXP_PICK_Marvon's Chest|r. Loot it for the |cRXP_LOOT_Stone Circle|r
.complete 3444,1 
step
#label SeekingSpiritualAid
.goto The Barrens,65.827,43.776
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Islen Waterseer|r
.turnin 5158 >> Turn in Seeking Spiritual Aid
.timer 48,Seeking Spiritual Aid RP
.accept 5159 >> Accept Cleansed Water Returns to Felwood
.target Islen Waterseer
step
.dungeon ST
#completewith STEntry
.zone Blasted Lands >> You will shortly run Sunken Temple. You will head to Tanaris to turn in a quest and pick up 2 more for the dungeon. Begin looking for a Sunken Temple group soon << !Warrior
.zone Blasted Lands >> You will shortly run Sunken Temple. You will head to Tanaris to turn in a quest and pick up 2 more for the dungeon. You will also complete your class quest for Sunken Temple in Blasted Lands before running the dungeon << Warrior
step << !Mage
.dungeon ST
.isQuestAvailable 4243,4503,4492,4501,3882,4288,4287,4285,3883,3881
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.goto The Barrens,63.084,37.163
.fly Tanaris >> Fly to Tanaris
.target Bragok
.zoneskip Tanaris
.zoneskip Blasted Lands
.zoneskip Swamp of Sorrows
step << Mage
.dungeon ST
.isQuestAvailable 4243,4503,4492,4501,3882,4288,4287,4285,3883,3881
.cast 49359 >> |cRXP_WARN_Cast|r |T135764:0|t[Teleport: Theramore]
.usespell 49359
.zoneskip Dustwallow Marsh
.zoneskip Tanaris
.zoneskip Blasted Lands
.zoneskip Swamp of Sorrows
step << Mage
.dungeon ST
.isQuestAvailable 4243,4503,4492,4501,3882,4288,4287,4285,3883,3881
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baldruc|r
.goto Dustwallow Marsh,67.476,51.300
.fly Tanaris >> Fly to Tanaris
.target Baldruc
.zoneskip Tanaris
.zoneskip Blasted Lands
.zoneskip Swamp of Sorrows
step
.dungeon ST
.goto Tanaris,52.51,27.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Fizzgrimble|r
.home >> Set your Hearthstone to Gadgetzan
.target Innkeeper Fizzgrimble
.bindlocation 976
step
.dungeon ST
.goto Tanaris,52.707,45.923
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon Rivetseeker|r
.turnin 3444 >> Turn in The Stone Circle
.accept 3446 >> Accept Into the Depths
.accept 3447 >> Accept Secret of the Circle
.target Marvon Rivetseeker
step << !Mage
.dungeon ST
.goto Tanaris,51.006,29.345
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bera Stonehammer|r
.fly Ratchet >> Fly to Ratchet
.target Bera Stonehammer
.zoneskip The Barrens
.zoneskip Stranglethorn Vale
.zoneskip Blasted Lands
.zoneskip Swamp of Sorrows
step << !Mage
.dungeon ST
.goto The Barrens,63.677,38.618
>>|cRXP_WARN_Level your|r |T135966:0|t[First Aid] |cRXP_WARN_while waiting|r
.zone Stranglethorn Vale >> Take the boat to Booty Bay
.zoneskip Blasted Lands
.zoneskip 1415
step << !Mage
.dungeon ST
.goto Stranglethorn Vale,27.530,77.787
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gyll|r
.fly Blasted Lands>> Fly to Blasted Lands
.target Gyll
.zoneskip 1415
step << Mage
.dungeon ST
.cast 3561 >>|cRXP_WARN_Cast|r |T135763:0|t[Teleport: Stormwind]
.usespell 3561
.zoneskip 1415
step << Mage
.dungeon ST
.goto Stormwind City,66.27,62.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Blasted Lands>> Fly to Blasted Lands
.target Dungar Longdrink
.zoneskip 1415
step << Warrior
.dungeon ST
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 8417 >> Turn in A Troubled Spirit
.accept 8423 >> Accept Warrior Kinship
.target Fallen Hero of the Horde
step << Warrior
.dungeon ST
#loop
.goto Blasted Lands,44.2,34.8,0
.goto Blasted Lands,47.7,38.6,0
.goto Blasted Lands,52.2,37.4,0
.goto Blasted Lands,54.8,44.8,0
.goto Blasted Lands,51.2,55.6,0
.goto Blasted Lands,45.8,48.2,0
.goto Blasted Lands,49.0,36.6,0
.goto Blasted Lands,44.2,34.8,70,0
.goto Blasted Lands,47.7,38.6,70,0
.goto Blasted Lands,52.2,37.4,70,0
.goto Blasted Lands,54.8,44.8,70,0
.goto Blasted Lands,51.2,55.6,70,0
.goto Blasted Lands,45.8,48.2,70,0
.goto Blasted Lands,49.0,36.6,70,0
>>Kill |cRXP_ENEMY_Helboars|r
.complete 8423,1 
.mob Helboar
step << Warrior
.dungeon ST
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 8423 >> Turn in Warrior Kinship
.accept 8424 >> Accept War on the Shadowsworn
.target Fallen Hero of the Horde
step << Warrior
.dungeon ST
#loop
.goto Blasted Lands,63.8,30.1,0
.goto Blasted Lands,63.1,45.8,0
.goto Blasted Lands,65.9,33.3,0
.goto Blasted Lands,63.6,39.2,0
.goto Blasted Lands,63.8,30.1,60,0
.goto Blasted Lands,63.1,45.8,60,0
.goto Blasted Lands,65.9,33.3,60,0
.goto Blasted Lands,63.6,39.2,60,0
>>Kill |cRXP_ENEMY_Shadowsworn Adepts|r, |cRXP_ENEMY_Shadowsworn Cultists|r and |cRXP_ENEMY_Shadowsworn Thugs|r
.complete 8424,1 
.mob +Shadowsworn Adept
.complete 8424,2 
.mob +Shadowsworn Cultist
.complete 8424,3 
.mob +Shadowsworn Thug
step << Warrior
.dungeon ST
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 8424 >> Turn in War on the Shadowsworn
.accept 8425 >> Accept Voodoo Feathers
.target Fallen Hero of the Horde
step
.dungeon ST
#label STEntry
.goto 1435/0,-3038.700,-10565.300,100,0 
.goto 1415,56.33,76.28
.subzone 1477 >> Travel to Sunken Temple
step
.dungeon ST
.isOnQuest 1475
#completewith next
>>Loot the |cRXP_LOOT_Atal'ai Tablets|r on the ground
>>|cRXP_WARN_These can be looted en-route to the instance portal, as well as inside Sunken Temple|r
.complete 1475,1 
step
.dungeon ST
.goto 1415,56.33,76.28,40,0
.goto 1415,56.46,75.54,20,0
.goto 1415,56.83,75.86,20,0
.goto 1415,56.94,76.03,15,0
.goto 1415,57.06,75.58,20,0
.goto 1415,56.76,75.35,15,0
.goto 1415,56.809,75.151
.subzone 1477,2 >> Zone into Sunken Temple
step
.dungeon ST
.isOnQuest 1475
#sticky
>>Loot the |cRXP_LOOT_Atal'ai Tablets|r on the ground
.complete 1475,1 
step << Druid
.dungeon ST
.isOnQuest 9053
#completewith Altar
>>Kill |cRXP_ENEMY_Atal'alarion|r. Loot him for the |cRXP_LOOT_Putrid Vine|r
>>|cRXP_ENEMY_Atal'alarion|r |cRXP_WARN_is on the lower level of Sunken Temple and is summoned by clicking all |cRXP_PICK_Atal'ai Statues|r on the platforms|r
.complete 9053,1 
step 
.dungeon ST
.isOnQuest 3446
#completewith next
>>Click on the |cRXP_PICK_Altar of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Altar of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3446 >> Turn in Into the Depths
step 
.dungeon ST
.isOnQuest 3447
>>Click on the |cRXP_PICK_Idol of Hakkar|r
>>|cRXP_WARN_Clicking all of the |cRXP_PICK_Atal'ai Statues|r on the platforms will activate the|r |cRXP_PICK_Idol of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Idol of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3447 >> Turn in Secret of the Circle
step 
.dungeon ST
.isOnQuest 3446
#label Altar
>>Click on the |cRXP_PICK_Altar of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Altar of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3446 >> Turn in Into the Depths
step << Druid
.dungeon ST
.isOnQuest 9053
>>Kill |cRXP_ENEMY_Atal'alarion|r. Loot him for the |cRXP_LOOT_Putrid Vine|r
>>|cRXP_ENEMY_Atal'alarion|r |cRXP_WARN_is on the lower level of Sunken Temple and is summoned by clicking all |cRXP_PICK_Atal'ai Statues|r on the platforms|r
.complete 9053,1 
step << Paladin/Warrior/Warlock
.dungeon ST
.isOnQuest 8418,8425,8422
>>Kill |cRXP_ENEMY_Gasher|r and |cRXP_ENEMY_Zul'Lor|r. Loot them for their |cRXP_LOOT_Amber Voodoo Feathers|r
>>Kill |cRXP_ENEMY_Mijan|r and |cRXP_ENEMY_Hukku|r. Loot them for their |cRXP_LOOT_Blue Voodoo Feathers|r
>>Kill |cRXP_ENEMY_Zolo|r and |cRXP_ENEMY_Loro|r. Loot them for their |cRXP_LOOT_Green Voodoo Feathers|r
>>|cRXP_WARN_This quest is completed on the upper level of Sunken Temple|r
.complete 8418,1 << Paladin 
.complete 8418,2 << Paladin 
.complete 8418,3 << Paladin 
.complete 8425,1 << Warrior 
.complete 8425,2 << Warrior 
.complete 8425,3 << Warrior 
.complete 8422,1 << Warlock 
.complete 8422,2 << Warlock 
.complete 8422,3 << Warlock 
step
.dungeon ST
.isOnQuest 3528
>>|cRXP_WARN_Use the|r |T132834:0|t[Egg of Hakkar] |cRXP_WARN_while next to the Dragonflayer Skeleton, then complete the event|r
>>Kill the minions of |cRXP_ENEMY_Hakkar|r until the |cRXP_ENEMY_Avatar of Hakkar|r joins
>>Kill the |cRXP_ENEMY_Avatar of Hakkar|r. Loot it for the |T136148:0|t[|cRXP_LOOT_Essence of Hakkar|r]
>>|cRXP_WARN_Use the|r |T136148:0|t[|cRXP_LOOT_Essence of Hakkar|r] |cRXP_WARN_to fill the|r |T132834:0|t[Egg of Hakkar]
.collect 10663,1,3528,1 
.disablecheckbox
.complete 3528,1 
.use 10465 
.use 10663 
step
.dungeon ST
.isOnQuest 1446
>>Kill |cRXP_ENEMY_Jammal'an the Prophet|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_You must kill the 6 |cRXP_ENEMY_Trolls|r on the upper platforms to gain access to|r |cRXP_ENEMY_Jammal'an the Prophet|r
.complete 1446,1 
step << Hunter/Mage/Priest/Rogue
.dungeon ST
.isOnQuest 8232,8253,8257,8236
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Tooth of Morphaz|r << Hunter
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Arcane Shard|r << Mage
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Blood of Morphaz|r << Priest
>>Kill |cRXP_ENEMY_Morphaz|r. Loot it for the |cRXP_LOOT_Azure Key|r << Rogue
.complete 8232,1 << Hunter 
.complete 8253,1 << Mage 
.complete 8257,1 << Priest 
.complete 8236,1 << Rogue 
step
.dungeon ST
>>Kill the |cRXP_ENEMY_Shade of Eranikus|r. Loot him for the |T135229:0|t[|cRXP_LOOT_Essence of Eranikus|r]
>>|cRXP_WARN_Use the |T135229:0|t[|cRXP_LOOT_Essence of Eranikus|r] to start the quest|r
>>|cRXP_WARN_Ensure you have killed all |cRXP_ENEMY_Dragonkin|r mobs on the upper level before engaging the |cRXP_ENEMY_Shade of Eranikus|r otherwise they will all aggro onto you|r
.collect 10454,1,3373,1 
.accept 3373 >> Accept The Essence of Eranikus
step
.dungeon ST
.isOnQuest 3373
>>Click the |cRXP_PICK_Essence Font|r
.turnin 3373 >> Turn in The Essence of Eranikus
step
.dungeon ST
#completewith next
.goto Swamp of Sorrows,34.287,66.134,80 >> Exit Sunken Temple. Return to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r on the border of Swamp of Sorrows and Blasted Lands
step << Warrior
.dungeon ST
.isQuestComplete 8425
.goto Swamp of Sorrows,34.287,66.134
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r
.turnin 8425 >> Turn in Voodoo Feathers
.target Fallen Hero of the Horde
step << Mage
.dungeon ST
#completewith DestroyMorphaz
.cast 3565 >>|cRXP_WARN_Cast|r |T135755:0|t[Teleport: Darnassus]
.usespell 3565
.train 3565,3
.zoneskip Darnassus
.zoneskip Azshara
.zoneskip Tanaris
step << Mage
.dungeon ST
#optional
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Travel through the purple portal to Rut'theran Village
.zoneskip Darnassus,1
step
.dungeon ST
.isQuestComplete 8253
.goto Teldrassil,58.39,94.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
.fly Azshara >> Fly to Azshara
.target Vesprystus
.zoneskip Azshara
.zoneskip Felwood
.zoneskip Tanaris
.zoneskip The Barrens
step << Mage
.dungeon ST
#completewith DestroyMorphaz
.goto Azshara,28.113,50.088
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanath Lim-yo|r
>>|cRXP_WARN_This will teleport you to the top of the mountain|r
.turnin 3503 >> Turn in Meeting with the Master
.target Sanath Lim-yo
step << Mage
.dungeon ST
#label DestroyMorphaz
.isQuestComplete 8253
.goto Azshara,29.248,40.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Xylem|r atop the Tower
.turnin 8253 >> Turn in Destroy Morphaz
.target Archmage Xylem
step
.dungeon ST
.hs >> Hearth to Gadgetzan
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
.cooldown item,6948,>2,1
.bindlocation 976,1
.zoneskip Tanaris
.zoneskip Un'Goro Crater
step << !Mage
.isQuestAvailable 4243,4503,4492,4501,3882,4288,4287,4285,3883,3881
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.goto The Barrens,63.084,37.163
.fly Tanaris >> Fly to Tanaris
.target Bragok
.zoneskip Tanaris
.zoneskip Un'Goro Crater
step << Mage
.isQuestAvailable 4243,4503,4492,4501,3882,4288,4287,4285,3883,3881
.cast 49359 >> |cRXP_WARN_Cast|r |T135764:0|t[Teleport: Theramore]
.usespell 49359
.zoneskip Dustwallow Marsh
.zoneskip Tanaris
.zoneskip Un'Goro Crater
step << Mage
.isQuestAvailable 4243,4503,4492,4501,3882,4288,4287,4285,3883,3881
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baldruc|r
.goto Dustwallow Marsh,67.476,51.300
.fly Tanaris >> Fly to Tanaris
.target Baldruc
.zoneskip Tanaris
.zoneskip Un'Goro Crater
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (A)
#subgroup RXP Survival Guide 47-60
<< Alliance
#name 53-55 Un'Goro Crater
#next 55-56 Felwood/Winterspring
step
.goto Tanaris,51.059,26.873
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sprinkle|r
.turnin 2641 >> Turn in Sprinkle's Secret Ingredient
.accept 2661 >> Accept Delivery for Marin
.target Sprinkle
step
.goto Tanaris,50.887,26.963
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alchemist Pestlezugg|r
.turnin 4493 >> Turn in March of the Silithid
.accept 4496 >> Accept Bungle in the Jungle
.target Alchemist Pestlezugg
step
.goto Tanaris,51.566,26.759
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.accept 4504 >> Accept Super Sticky
.target Tran'rek
step << Mage
.isQuestAvailable 4243,4503,4492,4501,3882,4288,4287,4285,3883,3881
.goto Tanaris,52.51,27.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Fizzgrimble|r
.home >> Set your Hearthstone to Gadgetzan
.target Innkeeper Fizzgrimble
.bindlocation 976
step
.goto Tanaris,51.808,28.662
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marin Noggenfogger|r
.turnin 2661 >> Turn in Delivery for Marin
.accept 2662 >> Accept Noggenfogger Elixir
.turnin 2662 >> Turn in Noggenfogger Elixir
.target Marin Noggenfogger
step
.dungeon ST
#optional
.isQuestComplete 3528
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3528 >> Turn in The God Hakkar
.target Yeh'kinya
step
.goto Tanaris,52.707,45.923
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon Rivetseeker|r
.turnin 3444 >>Turn in The Stone Circle
.target Marvon Rivetseeker
step
#completewith Pylons
.goto Tanaris,51.006,29.345
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bera Stonehammer|r
.fly Un'Goro >> Fly to Un'Goro
.target Bera Stonehammer
.zoneskip Un'Goro Crater
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Williden Marshal|r and |cRXP_FRIENDLY_Hol'anyee Marshal|r
.accept 3881 >> Accept Expedition Salvation
.target +Williden Marshal
.goto Un'Goro Crater,43.947,7.137
.accept 3883 >> Accept Alien Ecology
.target +Hol'anyee Marshal
.goto Un'Goro Crater,43.889,7.240
step
.goto Un'Goro Crater,41.918,2.703
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.accept 4284 >> Accept Crystals of Power
.turnin 4284 >> Turn in Crystals of Power
.itemcount 11186,7 
.itemcount 11185,7 
.itemcount 11184,7 
.itemcount 11188,7 
.target J.D. Collie
step
.isQuestTurnedIn 4284
.goto Un'Goro Crater,41.918,2.703
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.accept 4285 >> Accept The Northern Pylon
.accept 4287 >> Accept The Eastern Pylon
.accept 4288 >> Accept The Western Pylon
.target J.D. Collie
step
.goto Un'Goro Crater,43.5,7.5
.target Spark Nilminer
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spark Nilminer|r
.accept 3882 >> Accept Roll the Bones
step
.goto Un'Goro Crater,43.533,8.436
>>Click the |cRXP_PICK_Wanted Poster|r
.accept 4501 >> Accept Beware of Pterrordax
step
.goto Un'Goro Crater,43.615,8.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle Frock|r
.accept 4492 >> Accept Lost!
.target Spraggle Frock
step
.goto Un'Goro Crater,42.942,9.635
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muigin|r
.accept 4141 >> Accept Muigin and Larion
.target Muigin
step
.goto Un'Goro Crater,44.232,11.583
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shizzle|r
.accept 4503 >> Accept Shizzle's Flyer
.target Shizzle
step
#loop
.goto Un'Goro Crater,62.5,64.1,0
.goto Un'Goro Crater,38.3,53.6,0
.goto Un'Goro Crater,45.5,24.5,0
.goto Un'Goro Crater,62.5,64.1,90,0
.goto Un'Goro Crater,38.3,53.6,90,0
.goto Un'Goro Crater,45.5,24.5,90,0
>>Loot |cRXP_LOOT_Power Crystals|r on the ground
>>|cRXP_WARN_Complete this now if you havn't done so already. They are scattered on the ground throughout Un'Goro|r
.collect 11186,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
.collect 11188,7,4284,1 
step
.goto Un'Goro Crater,41.918,2.703
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.accept 4284 >> Accept Crystals of Power
.turnin 4284 >> Turn in Crystals of Power
.itemcount 11186,7 
.itemcount 11185,7 
.itemcount 11184,7 
.itemcount 11188,7 
.target J.D. Collie
step
#label Pylons
.isQuestTurnedIn 4284
.goto Un'Goro Crater,41.918,2.703
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.accept 4285 >> Accept The Northern Pylon
.accept 4287 >> Accept The Eastern Pylon
.accept 4288 >> Accept The Western Pylon
.target J.D. Collie
step
.isQuestTurnedIn 3764
.isOnQuest 4496
#completewith ucha
>>Loot |cRXP_LOOT_Un'Goro Soil|r on the ground
.collect 11018,5
step
.isQuestAvailable 3764 
.isQuestAvailable 4496 
#completewith ucha
>>Loot |cRXP_LOOT_Un'Goro Soil|r on the ground
.collect 11018,25
step
#completewith NorthPylon
>>Kill |cRXP_ENEMY_Diemetradons|r and |cRXP_ENEMY_Young Diemetradons|r. Loot them for their |cRXP_LOOT_Dinosaur Bones|r and |cRXP_LOOT_Webbed Diemetradon Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Young Diemetradon
.mob Diemetradon
step
#completewith NorthPylon
>>Kill |cRXP_ENEMY_Pterrordaxes|r and |cRXP_ENEMY_Fledgling Pterrordaxes|r. Loot them for their |cRXP_LOOT_Webbed Pterrordax Scales|r
.complete 4501,1 
.complete 4503,2 
.mob Fledgling Pterrordax
.mob Pterrordax
step
#label NorthPylon
.goto Un'Goro Crater,56.503,12.492
>>Click the |cRXP_PICK_Northern Crystal Pylon|r
.complete 4285,1 
.skipgossip
step
.goto Un'Goro Crater,63.66,16.56,70,0
.goto Un'Goro Crater,65.47,16.48
>>Kill |cRXP_ENEMY_Un'Goro Gorillas|r, |cRXP_ENEMY_Un'Goro Stompers|r and |cRXP_ENEMY_Un'Goro Thunderer|r. Loot them for their |cRXP_LOOT_Pelts|r
>>|cRXP_ENEMY_Un'Goro Gorillas|r |cRXP_WARN_will call for help at low health, pay attention to your surroundings when this happens|r
>>|cRXP_ENEMY_Un'Goro Stompers|r |cRXP_WARN_will|r |T136224:0|t[Enrage] |cRXP_WARN_at low health|r
>>|cRXP_ENEMY_Un'Goro Thunderer|r |cRXP_WARN_cast a high damage|r |T136105:0|t[Thunderclap]
.complete 4289,1 
.mob +Un'Goro Gorilla
.complete 4289,2 
.mob +Un'Goro Stomper
.complete 4289,3 
.mob +Un'Goro Thunderer
step
#completewith CrateofFoodstuffs
>>Kill |cRXP_ENEMY_Bloodpetal Lashers|r, |cRXP_ENEMY_Bloodpetal Threshers|r and |cRXP_ENEMY_Bloodpetal Flayers|r. Loot them for their |cRXP_LOOT_Bloodpetals|r
.complete 4141,1 
.mob Bloodpetal Lasher
.mob Bloodpetal Thresher
.mob Bloodpetal Flayer
step
#completewith FinishBait
>>Kill |cRXP_ENEMY_Pterrordaxes|r and |cRXP_ENEMY_Fledgling Pterrordaxes|r. Loot them for their |cRXP_LOOT_Webbed Pterrordax Scales|r
.complete 4503,2 
.mob Fledgling Pterrordax
.mob Pterrordax
step
#completewith FinishBait
>>Kill |cRXP_ENEMY_Diemetradons|r and |cRXP_ENEMY_Young Diemetradons|r. Loot them for their |cRXP_LOOT_Dinosaur Bones|r and |cRXP_LOOT_Webbed Diemetradon Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Young Diemetradon
.mob Diemetradon
step
#optional
.isOnQuest 4513
#completewith FinishBait
>>Kill |cRXP_ENEMY_Muculent Oozes|r and |cRXP_ENEMY_Glutinous Oozes|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Pure Sample Jars] |cRXP_WARN_on their corpses|r
.use 11953 
.use 11955 
.complete 4513,1 
.mob Muculent Ooze
.mob Glutinous Ooze
step
#label CrateofFoodstuffs
.goto Un'Goro Crater,68.541,36.539
>>Loot the |cRXP_LOOT_Crate of Foodstuffs|r on the ground
.complete 3881,1 
step
.goto Un'Goro Crater,75.6,44.4,80,0
.goto Un'Goro Crater,69.6,22.6,80,0
.goto Un'Goro Crater,57.6,37.6,80,0
.goto Un'Goro Crater,74.6,39.8,80,0
.goto Un'Goro Crater,67.6,32.6,80,0
.goto Un'Goro Crater,75.6,44.4,80,0
.goto Un'Goro Crater,69.6,22.6,80,0
.goto Un'Goro Crater,57.6,37.6,80,0
.goto Un'Goro Crater,74.6,39.8,80,0
.goto Un'Goro Crater,67.6,32.6
>>Kill |cRXP_ENEMY_Bloodpetal Lashers|r, |cRXP_ENEMY_Bloodpetal Threshers|r and |cRXP_ENEMY_Bloodpetal Flayers|r. Loot them for their |cRXP_LOOT_Bloodpetals|r
.complete 4141,1 
.mob Bloodpetal Lasher
.mob Bloodpetal Thresher
.mob Bloodpetal Flayer
step
.goto Un'Goro Crater,77.225,49.980
>>Click the |cRXP_PICK_Eastern Crystal Pylon|r
.complete 4287,1 
.skipgossip
step
.use 11568 >> |cRXP_WARN_Open|r |T133635:0|t[Torwa's Pouch] |cRXP_WARN_for the|r |T133970:0|t[Preserved Threshadon Meat] |cRXP_WARN_and|r |T134743:0|t[Preserved Pheromone Mixture]
.collect 11569,1,4292,1 
.collect 11570,1,4292,1 
step
.goto Un'Goro Crater,79.929,49.896
>>|cRXP_WARN_Use the|r |T133970:0|t[Preserved Threshadon Meat] |cRXP_WARN_on the stone-slab, then use the|r |T134743:0|t[Preserved Pheromone Mixture] |cRXP_WARN_on it to summon|r |cRXP_ENEMY_Lar'korwi|r
>>Kill |cRXP_ENEMY_Lar'korwi|r. Loot him for his |cRXP_LOOT_Head|r
.use 11568 
.use 11569 
.use 11570 
.complete 4292,1 
.mob Lar'korwi
step
#label FinishBait
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4289 >> Turn in The Apes of Un'Goro
.accept 4301 >> Accept The Mighty U'cha
.turnin 4292 >> Turn in The Bait for Lar'korwi
.turnin 9063 >> Turn in Torwa Pathfinder << Druid
.target Torwa Pathfinder
step
#completewith GlandWallSample
>>Kill |cRXP_ENEMY_Diemetradons|r and |cRXP_ENEMY_Young Diemetradons|r. Loot them for their |cRXP_LOOT_Dinosaur Bones|r and |cRXP_LOOT_Webbed Diemetradon Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Young Diemetradon
.mob Diemetradon
step
.goto Un'Goro Crater,56.3,90.6,40,0
.goto Un'Goro Crater,44.3,90.4,40,0
.goto Un'Goro Crater,56.3,90.6,40,0
.goto Un'Goro Crater,44.1,66.2,70,0
.goto Un'Goro Crater,53.5,62.9,70,0
.goto Un'Goro Crater,52.3,69.8,70,0
.goto Un'Goro Crater,44.3,90.4
>>Kill |cRXP_ENEMY_Pterrordaxes|r. Loot them for their |cRXP_LOOT_Webbed Pterrordax Scales|r
>>|cRXP_WARN_You don't need to collect all |cRXP_LOOT_Webbed Pterrordax Scales|r right now|r
.complete 4501,1 
.complete 4503,2 
.disablecheckbox
.mob Pterrordax
step
#label GlandWallSample
.goto Un'Goro Crater,49.93,81.70,70 >> Enter The Slithering Scar Hive
.isOnQuest 4496,3883
step
#completewith next
>>Kill the |cRXP_ENEMY_Gorishi|r. Loot them for their |cRXP_LOOT_Gorishi Scent Gland|r
.complete 4496,1 
.mob Gorishi Worker
.mob Gorishi Wasp
.mob Gorishi Reaver
.mob Gorishi Tunneler
.mob Gorishi Stinger
step
.goto Un'Goro Crater,48.671,85.322
>>|cRXP_WARN_Enter The Slithering Scar Hive|r
.use 11132 >>|cRXP_WARN_Use the|r |T134864:0|t[Unused Scraping Vial] |cRXP_WARN_in the centre of the circular room|r
.complete 3883,1 
step
#loop
.goto Un'Goro Crater,44.8,75.6,0
.goto Un'Goro Crater,45.0,83.6,0
.goto Un'Goro Crater,55.0,83.6,0
.goto Un'Goro Crater,54.4,76.4,0
.goto Un'Goro Crater,48.8,85.3,0
.goto Un'Goro Crater,44.8,75.6,70,0
.goto Un'Goro Crater,45.0,83.6,70,0
.goto Un'Goro Crater,55.0,83.6,70,0
.goto Un'Goro Crater,54.4,76.4,70,0
.goto Un'Goro Crater,48.8,85.3,70,0
>>Kill the |cRXP_ENEMY_Gorishi|r. Loot them for their |cRXP_LOOT_Gorishi Scent Gland|r
.complete 4496,1 
.mob Gorishi Worker
.mob Gorishi Wasp
.mob Gorishi Reaver
.mob Gorishi Tunneler
.mob Gorishi Stinger
step
#completewith WesternPylon
>>Kill |cRXP_ENEMY_Diemetradons|r and |cRXP_ENEMY_Elder Diemetradons|r. Loot them for their |cRXP_LOOT_Dinosaur Bones|r and |cRXP_LOOT_Webbed Diemetradon Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Elder Diemetradon
.mob Diemetradon
step
#completewith WesternPylon
>>Kill |cRXP_ENEMY_Frenzied Pterrordaxes|r. Loot them for their |cRXP_LOOT_Webbed Pterrordax Scales|r
.complete 4501,2 
.complete 4503,2 
.mob Frenzied Pterrordax
step
#optional
.isOnQuest 4513
#completewith WesternPylon
>>Kill |cRXP_ENEMY_Muculent Oozes|r and |cRXP_ENEMY_Glutinous Oozes|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Pure Sample Jars] |cRXP_WARN_on their corpses|r
.use 11953 
.use 11955 
.complete 4513,1 
.mob Muculent Ooze
.mob Glutinous Ooze
step
.goto Un'Goro Crater,38.457,66.066
>>Loot the |cRXP_LOOT_Research Equipment|r on the ground
.complete 3881,2 
step
.goto Un'Goro Crater,30.928,50.438
.target Krakle
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krakle|r
.accept 974 >> Accept Finding the Source
step
#label WesternPylon
.goto Un'Goro Crater,23.827,59.201
>>Click the |cRXP_PICK_Western Crystal Pylon|r
.complete 4288,1 
.skipgossip
step
#completewith CompletePterro
>>Kill |cRXP_ENEMY_Diemetradons|r and |cRXP_ENEMY_Elder Diemetradons|r. Loot them for their |cRXP_LOOT_Dinosaur Bones|r and |cRXP_LOOT_Webbed Diemetradon Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Elder Diemetradon
.mob Diemetradon
step
#optional
.isOnQuest 4513
#completewith CompletePterro
>>Kill |cRXP_ENEMY_Muculent Oozes|r and |cRXP_ENEMY_Glutinous Oozes|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Pure Sample Jars] |cRXP_WARN_on their corpses|r
.use 11953 
.use 11955 
.complete 4513,1 
.mob Muculent Ooze
.mob Glutinous Ooze
step
#label CompletePterro
#loop
.goto Un'Goro Crater,20.6,60,4,0
.goto Un'Goro Crater,22.4,50.0,0
.goto Un'Goro Crater,22.2,41,0,0
.goto Un'Goro Crater,34.8,29.4,0
.goto Un'Goro Crater,39.6,42.2,0
.goto Un'Goro Crater,36.8,76.6,0
.goto Un'Goro Crater,24.6,61.6,0
.goto Un'Goro Crater,20.6,60,4,70,0
.goto Un'Goro Crater,22.4,50.0,70,0
.goto Un'Goro Crater,22.2,41,0,70,0
.goto Un'Goro Crater,34.8,29.4,70,0
.goto Un'Goro Crater,39.6,42.2,70,0
.goto Un'Goro Crater,36.8,76.6,70,0
.goto Un'Goro Crater,24.6,61.6,70,0
>>Kill |cRXP_ENEMY_Frenzied Pterrordaxes|r. Loot them for their |cRXP_LOOT_Webbed Pterrordax Scales|r
.complete 4501,2 
.complete 4503,2 
.mob Frenzied Pterrordax
step
#completewith next
>>Kill |cRXP_ENEMY_Diemetradons|r and |cRXP_ENEMY_Elder Diemetradons|r. Loot them for their |cRXP_LOOT_Dinosaur Bones|r and |cRXP_LOOT_Webbed Diemetradon Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Elder Diemetradon
.mob Diemetradon
step
#optional
.isOnQuest 4513
#loop
.goto Un'Goro Crater,27.0,44.8,0
.goto Un'Goro Crater,34.6,28.6,0
.goto Un'Goro Crater,42.8,54.6,0
.goto Un'Goro Crater,37.0,73.4,0
.goto Un'Goro Crater,28.4,60.8,0
.goto Un'Goro Crater,27.0,44.8,70,0
.goto Un'Goro Crater,34.6,28.6,70,0
.goto Un'Goro Crater,42.8,54.6,70,0
.goto Un'Goro Crater,37.0,73.4,70,0
.goto Un'Goro Crater,28.4,60.8,70,0
>>Kill |cRXP_ENEMY_Muculent Oozes|r and |cRXP_ENEMY_Glutinous Oozes|r
>>|cRXP_WARN_Use the|r |T134864:0|t[Empty Pure Sample Jars] |cRXP_WARN_on their corpses|r
.use 11953 
.use 11955 
.complete 4513,1 
.mob Muculent Ooze
.mob Glutinous Ooze
step
#loop
.goto Un'Goro Crater,27.0,44.8,0
.goto Un'Goro Crater,34.6,28.6,0
.goto Un'Goro Crater,42.8,54.6,0
.goto Un'Goro Crater,37.0,73.4,0
.goto Un'Goro Crater,28.4,60.8,0
.goto Un'Goro Crater,27.0,44.8,70,0
.goto Un'Goro Crater,34.6,28.6,70,0
.goto Un'Goro Crater,42.8,54.6,70,0
.goto Un'Goro Crater,37.0,73.4,70,0
.goto Un'Goro Crater,28.4,60.8,70,0
>>Kill |cRXP_ENEMY_Diemetradons|r and |cRXP_ENEMY_Elder Diemetradons|r. Loot them for their |cRXP_LOOT_Dinosaur Bones|r and |cRXP_LOOT_Webbed Diemetradon Scales|r
>>|cRXP_LOOT_Dinosaur Bones|r |cRXP_WARN_may also be looted from the ground. The location is marked on your map to the southwest|r
.complete 3882,1 
.goto Un'Goro Crater,31.04,77.70,0
.complete 4503,1 
.mob Elder Diemetradon
.mob Diemetradon
step
#completewith next
.goto Un'Goro Crater,47.1,47.1,10,0
.goto Un'Goro Crater,47.7,48.3,10,0
.goto Un'Goro Crater,48.2,50.1,10,0
.goto Un'Goro Crater,48.67,49.33,15,0
.goto Un'Goro Crater,48.02,47.05,10,0
.goto Un'Goro Crater,48.81,45.94,10 >> |cRXP_WARN_Travel up the Lava Path of Fire Plume Ridge for a shortcut to the top. Follow the Arrow precisely|r
step
.goto Un'Goro Crater,49.631,45.694
.use 12472 >>|cRXP_WARN_Use|r |T132995:0|t[Krakle's Thermometer] |cRXP_WARN_atop Fire Plume Ridge at the Hot Spot|r
.complete 974,1 
step
.goto Un'Goro Crater,30.928,50.438
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krakle|r
.turnin 974 >> Turn in Finding the Source
.accept 980 >> Accept The New Springs
.target Krakle
step
.isOnQuest 4502
#loop
.goto Un'Goro Crater,46.8,45.6,0
.goto Un'Goro Crater,53.8,54.6,0
.goto Un'Goro Crater,51.0,45.0,0
.goto Un'Goro Crater,46.8,45.6,70,0
.goto Un'Goro Crater,47.2,53.0,70,0
.goto Un'Goro Crater,53.8,54.6,70,0
.goto Un'Goro Crater,55.0,48.6,70,0
.goto Un'Goro Crater,51.0,45.0,70,0
>>Kill |cRXP_ENEMY_Scorching Elementals|r and |cRXP_ENEMY_Living Blazes|r. Loot them for their |cRXP_LOOT_Ash|r
>>|cRXP_WARN_NOTE: The elemental invasion event may be active. If you see |cRXP_ENEMY_Blazing Invaders|r or |cRXP_ENEMY_Baron Charr|r, skip this step and abandon Volcanic Activity|r
.complete 4502,1 
.mob Scorching Elemental
.mob Living Blaze
step
.isOnQuest 4492
.goto Un'Goro Crater,51.909,49.870
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ringo|r
>>|cRXP_WARN_NOTE: The elemental invasion event may be active. If you see |cRXP_ENEMY_Blazing Invaders|r or |cRXP_ENEMY_Baron Charr|r, skip this step and abandon Lost!|r
.turnin 4492 >> Turn in Lost!
.accept 4491,1 >> Accept A Little Help From My Friends
>>|cRXP_WARN_This will start an escort quest|r
.target Ringo
step
.isQuestTurnedIn 4492
.goto Un'Goro Crater,51.909,49.870
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ringo|r
>>|cRXP_WARN_NOTE: The elemental invasion event may be active. If you see |cRXP_ENEMY_Blazing Invaders|r or |cRXP_ENEMY_Baron Charr|r, skip this step|r
.accept 4491,1 >> Accept A Little Help From My Friends
>>|cRXP_WARN_This will start an escort quest|r
.target Ringo
step
.goto Un'Goro Crater,43.617,8.497
>>Escort |cRXP_FRIENDLY_Ringo|r to Marshal's Refuge
.use 11804 >> |cRXP_WARN_Use|r |T132805:0|t[Spraggle's Canteen] |cRXP_WARN_on him when he faints and stops following you|r
.complete 4491,1 
.target Ringo
step
.goto Un'Goro Crater,43.617,8.497
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle Frock|r
.turnin 4491 >> Turn in A Little Help From My Friends
.turnin 4501 >> Turn in Beware of Pterrordax
.target Spraggle Frock
step
.goto Un'Goro Crater,43.497,7.420
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spark Nilminer|r
.turnin 3882 >> Turn in Roll the Bones
.target Spark Nilminer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Williden Marshal|r and |cRXP_FRIENDLY_Hol'anyee Marshal|r
.turnin 3883 >> Turn in Alien Ecology
.target +Hol'anyee Marshal
.goto Un'Goro Crater,43.889,7.240
.turnin 3881 >> Turn in Expedition Salvation
.target +Williden Marshal
.goto Un'Goro Crater,43.947,7.137
step
#optional
.goto Un'Goro Crater,43.947,7.137
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Williden Marshal|r
>>|cRXP_WARN_Use |T133743:0|t[A Mangled Journal] to start the quest|r
.collect 11116,1,3884,1 
.accept 3884 >> Accept Williden's Journal
.turnin 3884 >> Turn in Williden's Journal
.use 11116
.itemcount 11116,1
.target Williden Marshal
step
.goto Un'Goro Crater,41.918,2.703
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.turnin 4285 >> Turn in The Northern Pylon
.turnin 4287 >> Turn in The Eastern Pylon
.turnin 4288 >> Turn in The Western Pylon
.accept 4321 >> Accept Making Sense of It
.turnin 4321 >> Turn in Making Sense of It
.target J.D. Collie
step
.isQuestTurnedIn 3845
.goto Un'Goro Crater,44.658,8.098
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Linken|r
.accept 3908 >> Accept It's a Secret to Everybody
.target Linken
step
.goto Un'Goro Crater,42.942,9.635
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muigin|r
.turnin 4141 >> Turn in Muigin and Larion
.target Muigin
step
.goto Un'Goro Crater,44.232,11.586
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shizzle|r
.turnin 4503 >> Turn in Shizzle's Flyer
.target Shizzle
step
#completewith AMe
.destroy 11482 >> Destroy the |T133740:0|t[Crystal Pylon User's Manual]
step
.goto Un'Goro Crater,46.378,13.444
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna Remtravel|r
.accept 4243 >> Accept Chasing A-Me 01
.target Karna Remtravel
step
#loop
.goto Un'Goro Crater,46.2,19.6,0
.goto Un'Goro Crater,50.6,26.6,0
.goto Un'Goro Crater,48.4,32.8,0
.goto Un'Goro Crater,59.6,32.4,0
.goto Un'Goro Crater,63.4,23.6,0
.goto Un'Goro Crater,59.4,24.6,0
.goto Un'Goro Crater,51.6,24.8,0
.goto Un'Goro Crater,46.2,19.6,70,0
.goto Un'Goro Crater,50.6,26.6,70,0
.goto Un'Goro Crater,48.4,32.8,70,0
.goto Un'Goro Crater,59.6,32.4,70,0
.goto Un'Goro Crater,63.4,23.6,70,0
.goto Un'Goro Crater,59.4,24.6,70,0
.goto Un'Goro Crater,51.6,24.8,70,0
>>Kill |cRXP_ENEMY_Tar Beasts|r, |cRXP_ENEMY_Tar Creepers|r, |cRXP_ENEMY_Tar Lurkers|r and |cRXP_ENEMY_Tar Lords|r. Loot them for their |cRXP_LOOT_Super Sticky Tar|r
.complete 4504,1 
.mob Tar Beast
.mob Tar Creeper
.mob Tar Lurker
.mob Tar Lord
step
#completewith AMe
.goto Un'Goro Crater,63.66,16.56
.subzone 542 >> Travel to Fungal Rock
step
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.turnin 4243 >> Turn in Chasing A-Me 01
.itemcount 10561,<1 
.target A-Me 01
step
#label AMe
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
>>|cRXP_WARN_Don't accept the follow up yet|r
.turnin 4243 >> Turn in Chasing A-Me 01
.itemcount 10561,1 
.target A-Me 01
step
.goto Un'Goro Crater,68.49,12.18
>>Kill |cRXP_ENEMY_U'cha|r. Loot him for his |cRXP_LOOT_Pelt|r
.complete 4301,1 
.mob U'cha
step
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.accept 4244 >> Accept Chasing A-Me 01
.turnin 4244 >> Turn in Chasing A-Me 01
.accept 4245 >> Accept Chasing A-Me 01
.itemcount 10561,1 
.target A-Me 01
step
.isQuestTurnedIn 4244
.goto Un'Goro Crater,67.657,16.758
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me 01|r
.accept 4245 >> Accept Chasing A-Me 01
.target A-Me 01
step
.isOnQuest 4245
.goto Un'Goro Crater,46.378,13.444
>>Escort |cRXP_FRIENDLY_A-Me 01|r to |cRXP_FRIENDLY_Karna Remtravel|r at Marshal's Refuge
.complete 4245,1 
.target A-Me 01
step
.isQuestComplete 4245
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna Remtravel|r
.turnin 4245 >>Turn in Chasing A-Me 01
.target Karna Remtravel
step
#completewith next
>>Loot |cRXP_LOOT_Un'Goro Soil|r on the ground
.collect 11018,20,3764,1
step
#label ucha
.goto Un'Goro Crater,71.639,75.960
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa Pathfinder|r
.turnin 4301 >> Turn in The Mighty U'cha
.target Torwa Pathfinder
step
.isQuestTurnedIn 3764
.isOnQuest 4496
#loop
.goto Un'Goro Crater,62.5,64.1,0
.goto Un'Goro Crater,38.3,53.6,0
.goto Un'Goro Crater,45.5,24.5,0
.goto Un'Goro Crater,62.5,64.1,90,0
.goto Un'Goro Crater,38.3,53.6,90,0
.goto Un'Goro Crater,45.5,24.5,90,0
>>Loot |cRXP_LOOT_Un'Goro Soil|r on the ground
.collect 11018,5
step
.isQuestAvailable 3764 
.isQuestAvailable 4496 
#loop
.goto Un'Goro Crater,62.5,64.1,0
.goto Un'Goro Crater,38.3,53.6,0
.goto Un'Goro Crater,45.5,24.5,0
.goto Un'Goro Crater,62.5,64.1,90,0
.goto Un'Goro Crater,38.3,53.6,90,0
.goto Un'Goro Crater,45.5,24.5,90,0
>>Loot |cRXP_LOOT_Un'Goro Soil|r on the ground
.collect 11018,25
step
.isQuestAvailable 8277,8280
.goto Un'Goro Crater,28.71,21.43,40,0
.goto Un'Goro Crater,29.78,10.25,40,0
.goto 1451/1,-392.300,-6283.900,40,0
.goto Un'Goro Crater,28.71,21.43,0
.zone Silithus >> Travel to Silithus
step
#completewith CH1
.subzone 3425 >> Travel to Cenarion Hold
step
.goto Silithus,51.80,38.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beetix Ficklespragg|r upstairs
.accept 8277 >> Accept Deadly Desert Venom
.target Beetix Ficklespragg
step
#label CH1
.goto Silithus,51.152,38.289
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windcaller Proudhorn|r
.accept 8280 >> Accept Securing the Supply Lines
.target Windcaller Proudhorn
step
#loop
.goto Silithus,54.6,33.6,70,0
.goto Silithus,53.4,18.6,70,0
.goto Silithus,58.6,14.8,70,0
.goto Silithus,62.4,20.0,70,0
.goto Silithus,58.6,26.6,70,0
.goto Silithus,67.0,32.2,70,0
.goto Silithus,70.0,38.8,70,0
.goto Silithus,61.0,42.8,70,0
.goto Silithus,58.2,23.8
.goto Silithus,36.8,33.0,0
>>Kill |cRXP_ENEMY_Dredge Strikers|r
>>Kill |cRXP_ENEMY_Sand Skitterers|r. Loot them for their |cRXP_LOOT_Skitterer Fangs|r
>>Kill |cRXP_ENEMY_Stonelash Scorpids|r. Loot them for their |cRXP_LOOT_Scorpid Stingers|r
.complete 8280,1 
.mob +Dredge Striker
.complete 8277,2 
.mob +Sand Skitterer
.complete 8277,1 
.mob +Stonelash Scorpid
step
.goto Silithus,51.152,38.289
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Windcaller Proudhorn|r
.turnin 8280 >> Turn in Securing the Supply Lines
.target Windcaller Proudhorn
step
.goto Silithus,51.70,38.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beetix Ficklespragg|r upstairs
.turnin 8277 >> Turn in Deadly Desert Venom
.target Beetix Ficklespragg
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cloud Skydancer|r
.target Cloud Skydancer
.goto 1451/1,775.500,-6758.500
.fp Cenarion Hold >>Get the Cenarion Hold Flight Path
.zoneskip Silithus,1
step
#optional
.isOnQuest 4496,4504
.hs >> Hearth to Gadgetzan
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
.cooldown item,6948,>2,1
.subzoneskip 976
.bindlocation 976,1
step
.isOnQuest 4496,4504
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cloud Skydancer|r
.target Cloud Skydancer
.goto 1451/1,775.500,-6758.500
.fly Tanaris >>Fly to Tanaris
.zoneskip Tanaris
step
.goto Tanaris,50.887,26.963
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alchemist Pestlezugg|r
.turnin 4496 >> Turn in Bungle in the Jungle
.target Alchemist Pestlezugg
step
.goto Tanaris,51.566,26.759
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.turnin 4504 >> Turn in Super Sticky
.target Tran'rek
step
.goto Tanaris,51.80,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marin|r
>>|cRXP_BUY_Buy 2 or more additional stacks of|r |T134863:0|t[Noggenfogger Elixir] |cRXP_BUY_from him|r
>>|T134863:0|t[Noggenfogger Elixirs] |cRXP_WARN_can be used to get the|r |T135992:0|t[Slow Fall] |cRXP_WARN_buff which will be needed later in the guide. Put the additional stacks on the bank|r
.collect 8529,40
.target Marin Noggenfogger
.isQuestTurnedIn 2662
step << Mage
.isOnQuest 3566,3182,3368
.cast 3562 >>|cRXP_WARN_Cast|r |T135763:0|t[Teleport: Ironforge]
.usespell 3562
.zoneskip Ironforge
step << Mage
.goto Ironforge,27.18,8.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dink|r
.trainer >> Train your class spells
.target Dink
step << Mage
#optional
.isQuestAvailable 4510,4441
.cast 3565 >>|cRXP_WARN_Cast|r |T135755:0|t[Teleport: Darnassus]
.usespell 3565
.train 3565,3
.zoneskip Darnassus
step << Mage
.goto Darnassus,39.31,84.67
.use 11682 >>|cRXP_WARN_Use|r |T134870:0|t[Eridan's Vial] |cRXP_WARN_at the moonwell inside the Temple of the Moon|r
.complete 4441,1 
step << !Mage
.isQuestAvailable 4510,4441
.hs >> Hearth to Darnassus
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
.cooldown item,6948,>2,1
.zoneskip Darnassus
.bindlocation 1659,1
step << !Mage
.goto Tanaris,51.006,29.345
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bera Stonehammer|r
.fly Teldrassil >> Fly to Teldrassil
.target Bera Stonehammer
.zoneskip Teldrassil
.zoneskip Darnassus
step << !Mage
.goto Teldrassil,55.889,89.456
.zone Darnassus >> Take the purple portal into Darnassus
step
#sticky
#label TNF
#loop
.line Darnassus,36.6,42.4,37.6,16.2,52.6,19.2,56.6,8.8,65.4,15.8,60.8,23.4,62.4,55.6,68.0,59.2,63.8,72.2,60.2,67.8,49.2,80.8,39.6,74.6,38.6,47.0,61.6,40.6
.waypoint Darnassus,36.6,42.4,60,0
.waypoint Darnassus,37.6,16.2,60,0
.waypoint Darnassus,52.6,19.2,60,0
.waypoint Darnassus,56.6,8.8,50,0
.waypoint Darnassus,65.4,15.8,50,0
.waypoint Darnassus,60.8,23.4,50,0
.waypoint Darnassus,62.4,55.6,50,0
.waypoint Darnassus,68.0,59.2,50,0
.waypoint Darnassus,63.8,72.2,50,0
.waypoint Darnassus,60.2,67.8,50,0
.waypoint Darnassus,49.2,80.8,50,0
.waypoint Darnassus,39.6,74.6,50,0
.waypoint Darnassus,38.6,47.0,50,0
.waypoint Darnassus,61.6,40.6,50,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Herald Moonstalker|r
>>|cRXP_FRIENDLY_Herald Moonstalker|r |cRXP_WARN_patrols throughout Darnassus|r
>>|cRXP_WARN_Cast|r |T132172:0|t[Eagle Eye] |cRXP_WARN_to try and find her faster|r << Hunter
.accept 1047 >> Accept The New Frontier
.unitscan Herald Moonstalker
step
#optional
.isNotOnQuest 3789,3790,10520
.goto Darnassus,67.427,15.655
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Saelienne|r
.accept 3763 >> Accept Assisting Arch Druid Staghelm
.itemcount 11018,20 
.target Innkeeper Saelienne
step
#optional
.isOnQuest 3763
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 3763 >> Turn In Assisting Arch Druid Staghelm
.accept 3764 >> Accept Un'Goro Soil
.itemcount 11018,20 
.target Arch Druid Fandral Staghelm
step
#optional
.isOnQuest 10520
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 10520 >> Turn In Assisting Arch Druid Staghelm
.accept 3764 >> Accept Un'Goro Soil
.itemcount 11018,20 
.target Arch Druid Fandral Staghelm
step
#optional
.isOnQuest 3790
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 3790 >> Turn In Assisting Arch Druid Staghelm
.accept 3764 >> Accept Un'Goro Soil
.itemcount 11018,20 
.target Arch Druid Fandral Staghelm
step
#optional
.isOnQuest 3789
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 3789 >> Turn In Assisting Arch Druid Staghelm
.accept 3764 >> Accept Un'Goro Soil
.itemcount 11018,20 
.target Arch Druid Fandral Staghelm
step
#optional
.isQuestTurnedIn 3789,3790,10520,3763
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.accept 3764 >> Accept Un'Goro Soil
.itemcount 11018,20 
.target Arch Druid Fandral Staghelm
step
#optional
.isOnQuest 1047
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 1047 >> Turn in The New Frontier
.accept 6761 >> Accept The New Frontier
.target Arch Druid Fandral Staghelm
step
#optional
.isQuestTurnedIn 1047
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.accept 6761 >> Accept The New Frontier
.target Arch Druid Fandral Staghelm
step
#optional
.isQuestTurnedIn 1047
.goto Darnassus,35.375,8.405
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mathrengyl Bearwalker|r on the middle floor
.turnin 6761 >> Turn in The New Frontier
.accept 6762 >> Accept Rabine Saturna
.target Mathrengyl Bearwalker
step
#optional
.goto Darnassus,31.485,8.237
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jenal|r
.turnin 3764 >> Turn in Un'Goro Soil
.itemcount 11018,20 
.target Jenal
step << Warrior
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arias'ta Bladesinger|r
.goto Darnassus,58.72,34.92
.trainer >> Train your class spells
.target Arias'ta Bladesinger
.zoneskip Darnassus,1
step << Rogue
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Syurna|r
.goto Darnassus,31.84,16.69,30,0
.goto Darnassus,37.00,21.92
.trainer >> Train your class spells
.target Syurna
.zoneskip Darnassus,1
step << Hunter
.goto Darnassus,40.377,8.545
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jocaste|r
.trainer >> Train your class spells
.target Jocaste
.zoneskip Darnassus,1
step << !Mage
.goto Darnassus,39.31,84.67
.use 11682 >>|cRXP_WARN_Use|r |T134870:0|t[Eridan's Vial] |cRXP_WARN_at the moonwell inside the Temple of the Moon|r
.complete 4441,1 
step << Priest
.goto Darnassus,37.90,82.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jandria|r
.trainer >> Train your class spells
.target Jandria
.zoneskip Darnassus,1
step
#requires TNF
.goto Darnassus,64.021,23.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raedon Duskstriker|r
>>Do the Darnassus cloth turn ins. You'll need 3 stacks of each cloth. Skip this step if you're unable to complete all of them
.turnin 7792 >> Turn in A Donation of Wool
.turnin 7798 >> Turn in A Donation of Silk
.turnin 7799 >> Turn in A Donation of Mageweave
.turnin 7800 >> Turn in A Donation of Runecloth
.target Raedon Duskstriker
.zoneskip Darnassus,1
step
.isOnQuest 1047
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 1047 >> Turn in The New Frontier
.accept 6761 >> Accept The New Frontier
.target Arch Druid Fandral Staghelm
step
.isQuestTurnedIn 1047
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.accept 6761 >> Accept The New Frontier
.target Arch Druid Fandral Staghelm
step
.isQuestTurnedIn 1047
.goto Darnassus,35.375,8.405
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mathrengyl Bearwalker|r on the middle floor
.turnin 6761 >> Turn in The New Frontier
.accept 6762 >> Accept Rabine Saturna
.target Mathrengyl Bearwalker
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (A)
#subgroup RXP Survival Guide 47-60
<< Alliance
#name 55-56 Felwood/Winterspring
#next 56-59 Plaguelands
step << Druid
#completewith next
.isQuestAvailable 4842,5121,5123,5128
.cast 18960 >> |cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.usespell 18960
.zoneskip Moonglade
.zoneskip Felwood
.zoneskip Winterspring
step << Druid
.isQuestAvailable 4842,5121,5123,5128
.goto Moonglade,52.53,40.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.trainer >> Train your class spells
.target Loganaar
.zoneskip Felwood
.zoneskip Winterspring
step << Druid
.isQuestAvailable 4842,5121,5123,5128
.goto Moonglade,48.102,67.346
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sindrayl|r
.fly Talonbranch Glade >> Fly to Talonbranch Glade
.target Sindrayl
.zoneskip Felwood
.zoneskip Winterspring
step << !Druid
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Travel through the purple portal to Rut'theran Village
.zoneskip Darnassus,1
step << Warlock/Paladin/Shaman
.goto Teldrassil,58.39,94.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
.fly Auberdine >>Fly to Auberdine
.target Vesprystus
.zoneskip Teldrassil,1
step << Warlock
.goto Darkshore,32.44,43.71
.zone Wetlands >> Take the boat to Menethil Harbor
.zoneskip Felwood
.zoneskip Ironforge
step << Warlock
.goto Wetlands,9.490,59.693
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shellei Brondir|r
.fly Ironforge>> Fly to Ironforge
.target Shellei Brondir
.zoneskip Felwood
.zoneskip Ironforge
step << Warlock
.goto Ironforge,51.1,8.7,15,0
.goto Ironforge,50.343,5.657
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Briarthorn|r
.trainer >> Train your class spells
.target Briarthorn
.zoneskip Felwood
step << Warlock
.goto Ironforge,53.2,7.8,15,0
.goto Ironforge,52.701,6.070
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jubahl Corpseseeker|r
.vendor >> |cRXP_BUY_Buy|r |T133738:0|t[Grimoires] |cRXP_BUY_for your|r |T136220:0|t[Succubus] |cRXP_BUY_or|r |T136221:0|t[Voidwalker]
.target Jubahl Corpseseeker
.zoneskip Felwood
step << Warlock
.goto Ironforge,55.501,47.742
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
.fly Wetlands >> Fly to Wetlands
.target Gryth Thurden
.zoneskip Felwood
step << Warlock
.goto Wetlands,4.560,57.160
.zone Darkshore >> Take the boat to Darkshore
.zoneskip Teldrassil
.zoneskip Darnassus
.zoneskip Felwood
step << Paladin/Shaman
.goto Darkshore,30.749,40.995
.zone Azuremyst Isle >> Take the boat to Azuremyst Isle
.zoneskip Felwood
.zoneskip The Exodar
step << Paladin/Shaman
#completewith next
.goto Azuremyst Isle,24.6,49.0,20 >>Enter The Exodar through the back ramp
.zoneskip Felwood
step << Shaman
.goto The Exodar,32.450,23.996
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sulaa|r
.trainer >> Train your class spells
.target Sulaa
.zoneskip Felwood
step << Paladin
.goto The Exodar,38.367,82.564
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Priestess Kyleen Il'dinare|r
.target Jol
.trainer >> Train your class spells
.zoneskip Felwood
step << Paladin/Shaman
#completewith next
.goto 1947/1,6179.200,6216.100,20 >> Exit The Exodar
.zoneskip The Exodar,1
step << Paladin/Shaman
.goto Azuremyst Isle,20.405,54.184
.zone Darkshore >> Take the boat to Darkshore
.zoneskip Felwood
step << Warlock/Paladin/Shaman
.goto Darkshore,36.336,45.574
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caylais Moonfeather|r
.fly Talonbranch Glade >> Fly to Talonbranch Glade
.target Caylais Moonfeather
.zoneskip Felwood
step << !Druid !Warlock !Paladin !Shaman
.isQuestAvailable 4842,5121,5123,5128
.goto Teldrassil,58.39,94.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
.fly Talonbranch Glade >> Fly to Talonbranch Glade
.target Vesprystus
.zoneskip Felwood
.zoneskip Winterspring
step
.goto Felwood,64.768,8.129
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.turnin 8462 >> Turn in Speak to Nafien
.accept 8461 >> Accept Deadwood of the North
.target Nafien
step
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
.goto Felwood,62.61,10.12
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Den Avengers|r and |cRXP_ENEMY_Deadwood Den Shamans|r
>>|cRXP_WARN_If you find the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r], don't start the quest from this item yet|r
.complete 8461,1 
.mob +Deadwood Den Watcher
.complete 8461,2 
.mob +Deadwood Avenger
.complete 8461,3 
.mob +Deadwood Shaman
.reputation 576,unfriendly,>0,1 
step
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
.goto Felwood,62.61,10.12
.xp 55 >> Grind Furbolgs to level 55
step
.isQuestComplete 8461
.goto Felwood,64.769,8.131
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.turnin 8461 >> Turn in Deadwood of the North
.accept 8465 >> Accept Speak to Salfa
.target Nafien
step
.isQuestTurnedIn 8461
.goto Felwood,64.769,8.131
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.accept 8465 >> Accept Speak to Salfa
.target Nafien
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
>>|cRXP_WARN_If you have more than 5|r |T132926:0|t[Deadwood Headdress Feathers] |cRXP_WARN_you may turn them in for reputation with Timbermaw Hold|r
.dailyturnin 8467 >> Turn in Feathers for Nafien
.itemcount 21377,>5 
.target Nafien
step
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
.goto Felwood,62.61,10.12
.reputation 576,unfriendly 

.mob Deadwood Shaman
.mob Deadwood Avenger
.mob Deadwood Den Watcher
step
#completewith next
.goto Felwood,65.48,3.47,20 >> Travel through Timbermaw Hold to |cRXP_FRIENDLY_Kernda|r
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20741 >>|cRXP_WARN_Use the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r] to start the quest|r
>>Skip this step if you aren't neutral with Timbermaw Hold
.accept 8470 >> Accept Deadwood Ritual Totem
.turnin 8470 >> Turn in Deadwood Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20741,1 
.target Kernda
step
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
>>Skip this step if you aren't friendly with Timbermaw Hold
.accept 6031 >> Accept Runecloth
.turnin 6031 >> Turn in Runecloth
.reputation 576,friendly,<0,1 
.itemcount 14047,30 
.target Meilosh
step
#completewith FallingWinterfall
.goto Winterspring,27.736,34.499,20 >> Travel through Timbermaw Hold to Winterspring
step
.isOnQuest 8465
.goto Winterspring,27.736,34.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.turnin 8465 >> Turn in Speak to Salfa
.target Salfa
step
#optional
.isOnQuest 978
#completewith FallingWinterfall
>>Loot |cRXP_LOOT_Moontouched Feathers|r on the ground
.complete 978,1 
step
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 980 >> Turn in The New Springs
.turnin 3908 >> Turn in It's a Secret to Everybody
.accept 5082 >> Accept Threat of the Winterfall
.target Donova Snowden
step
#completewith next
>>Kill |cRXP_ENEMY_Winterfall Pathfinders|r, |cRXP_ENEMY_Winterfall Den Watchers|r and |cRXP_ENEMY_Winterfall Totemics|r
>>|cRXP_WARN_Don't go out of your way to complete this now|r
.complete 5082,1 
.mob +Winterfall Pathfinder
.complete 5082,2 
.mob +Winterfall Den Watcher
.complete 5082,3 
.mob +Winterfall Totemic
step
#loop
.goto Winterspring,30.6,35.8,0
.goto Winterspring,33.6,36.8,0
.goto Winterspring,39.4,43.8,0
.goto Winterspring,41.6,42.8,0
.goto Winterspring,30.6,35.8,70,0
.goto Winterspring,33.6,36.8,70,0
.goto Winterspring,39.4,43.8,70,0
.goto Winterspring,41.6,42.8,70,0
>>Kill |cRXP_ENEMY_Winterfall Furbolgs|r. Loot them for a |T134865:0|t[|cRXP_LOOT_Empty Firewater Flask|r]
.use 12771 >>|cRXP_WARN_Use the |T134865:0|t[|cRXP_LOOT_Empty Firewater Flask|r] to start the quest|r
.collect 12771,1,5083,1 
.accept 5083 >> Accept Winterfall Firewater
.mob Winterfall Pathfinder
.mob Winterfall Den Watcher
.mob Winterfall Totemic
step
#optional
.isQuestComplete 5082
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 5082 >> Turn in Threat of the Winterfall
.turnin 5083 >> Turn in Winterfall Firewater
.accept 5084 >> Accept Falling to Corruption
.target Donova Snowden
step
#label FallingWinterfall
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 5083 >> Turn in Winterfall Firewater
.accept 5084 >> Accept Falling to Corruption
.target Donova Snowden
step
#completewith next
.goto 1448/1,-2288.100,6914.200,30,0
.zone Felwood >> Head back to Felwood through the Timbermaw Hold tunnel
step
#completewith next
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Den Avengers|r and |cRXP_ENEMY_Deadwood Den Shamans|r
>>|cRXP_WARN_If you find the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r], don't start the quest from this item yet|r
.complete 8461,1 
.mob +Deadwood Den Watcher
.complete 8461,2 
.mob +Deadwood Avenger
.complete 8461,3 
.mob +Deadwood Shaman
step
.goto Felwood,60.204,5.841
>>Click the |cRXP_PICK_Deadwood Cauldron|r in the northern |cRXP_ENEMY_Furbolg|r camp
.turnin 5084 >> Turn in Falling to Corruption
.accept 5085 >> Accept Mystery Goo
step
#loop
.goto Felwood,62.61,10.12,0
.goto Felwood,62.73,7.31,0
.goto Felwood,61.33,7.46,0
.goto Felwood,59.79,5.92,0
.goto Felwood,62.61,10.12,70,0
.goto Felwood,62.73,7.31,70,0
.goto Felwood,61.33,7.46,70,0
.goto Felwood,59.79,5.92,70,0
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Den Avengers|r and |cRXP_ENEMY_Deadwood Den Shamans|r
>>|cRXP_WARN_If you find the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r], don't start the quest from this item yet|r
.complete 8461,1 
.mob +Deadwood Den Watcher
.complete 8461,2 
.mob +Deadwood Avenger
.complete 8461,3 
.mob +Deadwood Shaman
step
.goto Felwood,64.769,8.131
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.turnin 8461 >> Turn in Deadwood of the North
.accept 8465 >> Accept Speak to Salfa
.target Nafien
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
>>|cRXP_WARN_If you have more than 5|r |T132926:0|t[Deadwood Headdress Feathers] |cRXP_WARN_you may turn them in for reputation with Timbermaw Hold|r
.dailyturnin 8467 >> Turn in Feathers for Nafien
.itemcount 21377,>5 
.target Nafien
step
#completewith next
.goto Felwood,65.48,3.47,20 >> Travel through Timbermaw Hold to |cRXP_FRIENDLY_Kernda|r
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20741 >>|cRXP_WARN_Use the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r] to start the quest|r
>>Skip this step if you aren't neutral with Timbermaw Hold
.accept 8470 >> Accept Deadwood Ritual Totem
.turnin 8470 >> Turn in Deadwood Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20741,1 
.target Kernda
step
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
>>Skip this step if you aren't friendly with Timbermaw Hold
.accept 6031 >> Accept Runecloth
.turnin 6031 >> Turn in Runecloth
.reputation 576,friendly,<0,1 
.itemcount 14047,30 
.target Meilosh
step
#completewith MysteryGoo
.goto Winterspring,27.736,34.499,20 >> Travel through Timbermaw Hold to Winterspring
step
.goto Winterspring,27.736,34.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.turnin 8465 >> Turn in Speak to Salfa
.target Salfa
step
#optional
.isOnQuest 978
#completewith next
>>Loot |cRXP_LOOT_Moontouched Feathers|r on the ground
.complete 978,1 
step
#label MysteryGoo
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 5085 >> Turn in Mystery Goo
.accept 5086 >> Accept Toxic Horrors
.target Donova Snowden
step << !Druid
#completewith FlySouthFelwood
.goto Moonglade,35.77,71.94
.zone Moonglade >> Travel to Moonglade via Timbermaw Hold
step << !Druid
.dungeon Mara
.isOnQuest 7066
.goto Moonglade,36.178,41.798
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 7066 >> Turn in Seed of Life
.target Keeper Remulos
step << Druid
#completewith FlySouthFelwood
.cast 18960 >> |cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.usespell 18960
.zoneskip Moonglade
step << Hunter
.dungeon ST
#completewith next
.goto Moonglade,48.102,67.346
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sindrayl|r
.fp Moonglade >> Get the Moonglade Flight path
.fly Azshara >> Fly to Azshara
.target Sindrayl
step << Hunter
.dungeon ST
.isQuestComplete 8232
.goto Azshara,42.400,42.619
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogtinc|r
.turnin 8232 >> Turn in The Green Drake
.target Ogtinc
step << Hunter
.dungeon ST
.goto Azshara,11.90,77.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarrodenus|r
.fly Emerald Sanctuary >> Fly to Emerald Sanctuary
.target Jarrodenus
.zoneskip Azshara,1
step
#completewith FlySouthFelwood
.goto Moonglade,48.102,67.346
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sindrayl|r
.fp Moonglade >> Get the Moonglade Flight path << !Druid
.fly Emerald Sanctuary >> Fly to Emerald Sanctuary
.target Sindrayl
.subzoneskip 2479
.zoneskip Azshara
step
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
.turnin 4441 >> Turn in Felbound Ancients
.timer 16,Felbound Ancients RP
.target Eridan Bluewind
step
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 5159 >> Turn in Cleansed Water Returns to Felwood
.target Greta Mosshoof
step << Priest
#optional
.isQuestComplete 8257
.goto Felwood,51.21,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta Mosshoof|r
.turnin 8257 >> Turn in Blood of Morphaz
.target Greta Mosshoof
step
.goto Felwood,51.350,81.511
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eridan Bluewind|r
>>|cRXP_WARN_You may need to wait for the RP|r
.accept 4442 >> Accept Purified!
.turnin 4442 >> Turn in Purified!
.target Eridan Bluewind
step
#label FlySouthFelwood
.goto Felwood,50.957,81.580
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ivy Leafrunner|r
.accept 5249 >> Accept To Winterspring!
.target Ivy Leafrunner
step
#sticky
#optional
.destroy 11445 >> Destroy the |T133942:0|t[Flute of the Ancients]
step
.goto Felwood,48.22,93.81,0
.goto Felwood,54.14,86.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arathandris Silversky|r
>>|cRXP_WARN_Turn in your 6|r |T132884:0|t[|cRXP_LOOT_Corrupted Soul Shards|r] |cRXP_WARN_you have to receive 2|r |T132804:0|t[|cRXP_LOOT_Cenarion Plant Salves|r]
>>If you don't have 6 get them from the |cRXP_ENEMY_Furbolgs|r to the west
.collect 11515,6,5882,1 
.accept 5882 >> Accept Salve via Hunting
.turnin 5882 >> Turn in Salve via Hunting
.target Arathandris Silversky
.zoneskip Felwood,1
.mob Deadwood Warrior
.mob Deadwood Pathfinder
.mob Deadwood Gardener
step
#completewith ToxicHorror
#icon |T135934:0|t
.goto Felwood,55.808,10.438,0
.goto Felwood,50.575,13.918,0
.goto Felwood,63.336,22.610,0
.goto Felwood,40.142,44.353,0
.goto Felwood,40.142,56.523,0
.goto Felwood,48.260,75.650,0
.goto Felwood,45.942,85.219,0
.goto Felwood,52.893,87.825,0
.goto Felwood,52.893,87.825,25,0
.goto Felwood,45.942,85.219,25,0
.goto Felwood,48.260,75.650,25,0
.goto Felwood,40.142,56.523,25,0
.goto Felwood,40.142,44.353,25,0
.goto Felwood,50.575,13.918,25,0
.goto Felwood,55.808,10.438,25,0
.goto Felwood,63.336,22.610,25,0
.aura 15366 >> |cRXP_WARN_Look for a |cRXP_PICK_Corrupted Songflower|r. Click it to cleanse it. Click the |cRXP_PICK_Cleansed Songflower|r to receive the hour-long|r |T135934:0|t[Songflower Serenade] |cRXP_WARN_buff|r
>>|cRXP_WARN_Their locations have been marked on your map. Skip this step if you aren't able to find one|r
.itemcount 11516,2 
step << Warlock
.isQuestComplete 8421
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.turnin 8421 >> Turn in The Wrong Stuff
.target Impsy
step << Warlock
#optional
.isQuestComplete 8422
.goto Felwood,41.52,44.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Impsy|r
.turnin 8422 >> Turn in Trolls of a Feather
.target Impsy
step
#loop
.goto Felwood,50.6,22.4,0
.goto Felwood,49.6,26.6,0
.goto Felwood,48.0,24.0,0
.goto Felwood,50.6,22.4,70,0
.goto Felwood,49.6,26.6,70,0
.goto Felwood,48.0,24.0,70,0
>>Kill |cRXP_ENEMY_Toxic Horrors|r. Loot them for their |cRXP_LOOT_Toxic Horror Droplets|r
.complete 5086,1 
.mob Toxic Horror
step
#completewith ToxicHorror
.goto Felwood,65.280,7.515,20,0
.goto Felwood,65.280,7.515,0
.goto Winterspring,27.76,34.59
.zone Winterspring >> Travel to Winterspring via Timbermaw Hold
step
#label ToxicHorror
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 5086 >> Turn in Toxic Horrors
.accept 5087 >> Accept Winterfall Runners
.accept 4842 >> Accept Strange Sources
.target Donova Snowden
step
#completewith RelicFragments
>>Kill the |cRXP_ENEMY_Winterfall Runners|r. Loot them for their |cRXP_LOOT_Winterfall Crate|r
>>|cRXP_WARN_Their spawn point is on the west side of Winterspring near the Timbermaw tunnel. Their patrol route is marked on your map|r
>>|cRXP_WARN_You may complete this later if you can't find them now|r
.complete 5087,1 
.line Winterspring,28.07,35.29,28.02,36.46,28.32,37.14,28.47,37.92,28.53,39.39,28.80,39.76,29.32,40.86,29.91,42.27,30.44,42.54,31.65,42.44,32.60,42.17,33.59,41.99,34.67,41.91,36.04,42.16,38.21,41.98,40.23,40.75,42.32,39.97,44.29,39.90,46.45,39.66,48.38,38.86,49.19,38.15,49.35,37.79,49.65,37.59,50.57,36.63,51.67,36.21,52.25,35.75,52.75,35.30,53.46,34.27,53.75,33.38,53.93,32.50,53.97,31.32,54.60,30.91,55.51,30.05,57.14,29.72,58.07,28.93,58.74,27.94,59.01,26.99,59.24,26.48,60.37,25.02,60.62,24.75,61.11,24.44,61.29,24.35,61.92,23.82,62.34,23.92,62.37,24.95,62.21,25.30,62.60,25.99,63.04,26.55,63.50,27.81,63.95,28.34,64.12,28.94,64.10,30.84,64.21,31.40,64.97,33.08,65.44,33.48,66.44,33.71,66.63,33.93,66.80,34.47,66.87,34.87,66.97,35.22,67.53,37.01,68.12,37.76,68.65,38.20,68.76,38.13,68.94,37.84,69.29,38.40,69.61,38.29
.unitscan Winterfall Runner
step
#optional
.isOnQuest 978
#completewith MoontouchedFeathers
>>Loot |cRXP_LOOT_Moontouched Feathers|r on the ground
.complete 978,1 
step
#loop
.goto Winterspring,30.6,35.8,0
.goto Winterspring,33.6,36.8,0
.goto Winterspring,39.4,43.8,0
.goto Winterspring,41.6,42.8,0
.goto Winterspring,30.6,35.8,70,0
.goto Winterspring,33.6,36.8,70,0
.goto Winterspring,39.4,43.8,70,0
.goto Winterspring,41.6,42.8,70,0
>>Kill |cRXP_ENEMY_Winterfall Pathfinders|r, |cRXP_ENEMY_Winterfall Den Watchers|r and |cRXP_ENEMY_Winterfall Totemics|r
.complete 5082,1 
.mob +Winterfall Pathfinder
.complete 5082,2 
.mob +Winterfall Den Watcher
.complete 5082,3 
.mob +Winterfall Totemic
step
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 5082 >> Turn in Threat of the Winterfall
.target Donova Snowden
step
#completewith Ursius
.subzone 2255 >> Travel to Everlook
step
.goto Winterspring,60.883,37.620
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umi Rumplesnicker|r
.accept 3783 >> Accept Are We There, Yeti?
.target Umi Rumplesnicker
step
.goto Winterspring,61.626,38.615
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felnok Steelspring|r
.turnin 4808 >> Turn in Felnok Steelspring
.target Felnok Steelspring
step
#label Ursius
.goto Winterspring,61.93,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Storm Shadowhoof|r
.accept 5054 >> Accept Ursius of the Shardtooth
.target Storm Shadowhoof
step
.goto Winterspring,62.334,36.609
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maethrya|r
.fp Winterspring >> Get the Winterspring Flight Path
.target Maethrya
step
#loop
.goto Winterspring,66.50,41.70,0
.goto Winterspring,66.50,41.70,50,0
.goto Winterspring,65.90,43.60,50,0
.goto Winterspring,66.20,45.80,50,0
.goto Winterspring,67.60,45.60,50,0
.goto Winterspring,67.60,43.80,50,0
.goto Winterspring,67.20,43.00,50,0
.goto Winterspring,67.60,41.90,50,0
.goto Winterspring,68.40,41.50,50,0
.goto Winterspring,69.00,41.30,50,0
.goto Winterspring,69.50,40.00,50,0
.goto Winterspring,69.80,41.80,50,0
.goto Winterspring,70.10,42.00,50,0
.goto Winterspring,70.30,40.80,50,0
.goto Winterspring,71.30,40.80,50,0
.goto Winterspring,71.80,39.80,50,0
.goto Winterspring,70.50,38.30,50,0
.goto Winterspring,71.80,39.80,50,0
.goto Winterspring,71.30,40.80,50,0
.goto Winterspring,70.30,40.80,50,0
.goto Winterspring,69.50,40.00,50,0
.goto Winterspring,69.00,41.30,50,0
.goto Winterspring,68.40,41.50,50,0
>>Kill all types of |cRXP_ENEMY_Ice Thistle Yetis|r. Loot them for their |cRXP_LOOT_Fur|r
.complete 3783,1 
.mob Rogue Ice Thistle
.mob Ice Thistle Yeti
.mob Ice Thistle Patriarch
step
#loop
.goto Winterspring,56.62,32.34,0
.goto Winterspring,60.50,33.02,0
.goto Winterspring,62.55,30.83,0
.goto Winterspring,62.43,28.08,0
.goto Winterspring,63.40,27.04,0
.goto Winterspring,56.62,32.34,70,0
.goto Winterspring,60.50,33.02,70,0
.goto Winterspring,62.55,30.83,70,0
.goto Winterspring,62.43,28.08,70,0
.goto Winterspring,63.40,27.04,70,0
>>Kill |cRXP_ENEMY_Ursius|r
>>|cRXP_ENEMY_Ursius|r |cRXP_WARN_patrols the mountain north of Everlook|r
.complete 5054,1 
.unitscan Ursius
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wynd Nightchaser|r and |cRXP_FRIENDLY_Jaron Stoneshaper|r
.turnin 5249 >> Turn in To Winterspring!
.accept 5244 >> Accept The Ruins of Kel'Theril
.target +Wynd Nightchaser
.goto Winterspring,51.971,30.387
.turnin 5244 >> Turn in The Ruins of Kel'Theril
.accept 5245 >> Accept Troubled Spirits of Kel'Theril
.accept 4861 >> Accept Enraged Wildkin
.target +Jaron Stoneshaper
.goto Winterspring,52.139,30.429
step
#completewith yetiturnin
.subzone 2255 >> Return to Everlook
step
.goto Winterspring,61.93,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Storm Shadowhoof|r
.turnin 5054 >> Turn in Ursius of the Shardtooth
.target Storm Shadowhoof
step
.goto Winterspring,61.348,38.973
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gregor Greystone|r
.accept 6028 >> Accept The Everlook Report
.accept 6030 >> Accept Duke Nicholas Zverenhoff
.target Gregor Greystone
step
#label yetiturnin
.goto Winterspring,60.883,37.620
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umi Rumplesnicker|r
.turnin 3783 >> Turn in Are We There, Yeti?
.target Umi Rumplesnicker
step
#label RelicFragments
.isOnQuest 5245
>>Click the |cRXP_PICK_Highborne Relic Fragments|r on the ground
>>|cRXP_WARN_NOTE: The elemental invasion event may be active. If you see |cRXP_ENEMY_Watery Invaders|r or |cRXP_ENEMY_Princess Tempestria|r, skip this step and abandon Troubled Spirits of Kel'Theril|r
.complete 5245,2
.goto Winterspring,50.88,41.71,-1
.complete 5245,4
.goto Winterspring,52.42,41.50,-1
.complete 5245,3
.goto Winterspring,53.30,43.43,-1
.complete 5245,1
.goto Winterspring,55.13,42.98,-1
step
#label MoontouchedFeathers
>>Kill the |cRXP_ENEMY_Winterfall Runners|r. Loot them for their |cRXP_LOOT_Winterfall Crate|r
>>|cRXP_WARN_Their spawn point is on the west side of Winterspring near the Timbermaw tunnel. Their patrol route is marked on your map|r
.complete 5087,1 
.line Winterspring,28.07,35.29,28.02,36.46,28.32,37.14,28.47,37.92,28.53,39.39,28.80,39.76,29.32,40.86,29.91,42.27,30.44,42.54,31.65,42.44,32.60,42.17,33.59,41.99,34.67,41.91,36.04,42.16,38.21,41.98,40.23,40.75,42.32,39.97,44.29,39.90,46.45,39.66,48.38,38.86,49.19,38.15,49.35,37.79,49.65,37.59,50.57,36.63,51.67,36.21,52.25,35.75,52.75,35.30,53.46,34.27,53.75,33.38,53.93,32.50,53.97,31.32,54.60,30.91,55.51,30.05,57.14,29.72,58.07,28.93,58.74,27.94,59.01,26.99,59.24,26.48,60.37,25.02,60.62,24.75,61.11,24.44,61.29,24.35,61.92,23.82,62.34,23.92,62.37,24.95,62.21,25.30,62.60,25.99,63.04,26.55,63.50,27.81,63.95,28.34,64.12,28.94,64.10,30.84,64.21,31.40,64.97,33.08,65.44,33.48,66.44,33.71,66.63,33.93,66.80,34.47,66.87,34.87,66.97,35.22,67.53,37.01,68.12,37.76,68.65,38.20,68.76,38.13,68.94,37.84,69.29,38.40,69.61,38.29
.unitscan Winterfall Runner
step
#optional
.isOnQuest 978
#loop
.goto Winterspring,32.8,44.3,70,0
.goto Winterspring,37.4,44.2,70,0
.goto Winterspring,40.5,37.5,70,0
.goto Winterspring,43.6,42.6,70,0
.goto Winterspring,45.9,41.6,70,0
.goto Winterspring,47.9,45.1,70,0
.goto Winterspring,50.5,38.0,70,0
.goto Winterspring,60.6,33.7,70,0
>>Loot |cRXP_LOOT_Moontouched Feathers|r on the ground
.complete 978,1
step
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 5087 >> Turn in Winterfall Runners
.accept 5121 >> Accept High Chief Winterfall
.target Donova Snowden
step
.goto 1448/1,-2279.500,6921.500,40,0
#completewith RabineWasteland << !Druid
#completewith Runeclothcheck << Druid
.zone Moonglade >> Travel to Moonglade via Timbermaw Hold << !Druid
.subzone 1216 >> Travel to Timbermaw Hold << Druid
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20741 >>|cRXP_WARN_Use the |T136232:0|t[|cRXP_LOOT_Deadwood Ritual Totem|r] to start the quest|r
.accept 8470 >> Accept Deadwood Ritual Totem
.turnin 8470 >> Turn in Deadwood Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20741,1 
.target Kernda
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20742 >>|cRXP_WARN_Use the |T135816:0|t[|cRXP_LOOT_Winterfall Ritual Totem|r] to start the quest|r
>>Skip this step if you aren't neutral with Timbermaw Hold
.accept 8471 >> Accept Winterfall Ritual Totem
.turnin 8471 >> Turn in Winterfall Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20742,1 
.target Kernda
step
#label Runeclothcheck
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
>>Skip this step if you aren't friendly with Timbermaw Hold
.accept 6031 >> Accept Runecloth
.turnin 6031 >> Turn in Runecloth
.reputation 576,friendly,<0,1 
.itemcount 14047,30 
.target Meilosh
step << Druid
#completewith RabineWasteland
.cast 18960 >> |cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.usespell 18960
.zoneskip Moonglade
step << Druid
.goto Moonglade,52.53,40.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.trainer >> Train your class spells
.target Loganaar
step
.goto Moonglade,51.685,45.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine Saturna|r
.turnin 6762 >> Turn in Rabine Saturna
.accept 1124 >> Accept Wasteland
.target Rabine Saturna
step
#label RabineWasteland
.goto Moonglade,51.685,45.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine Saturna|r
>>|cRXP_WARN_Skip this step if the Dire Maul dialogue is not available|r
.skipgossip
.accept 5527 >> Accept A Reliquary of Purity
.target Rabine Saturna
step << Mage
.cast 3565 >>|cRXP_WARN_Cast|r |T135755:0|t[Teleport: Darnassus]
.usespell 3565
.train 3565,3
.zoneskip Darnassus
step << !Mage
.hs >> Hearth to Darnassus
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
.cooldown item,6948,>2,1
.zoneskip Darnassus
.bindlocation 1659,1
step
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Travel through the purple portal to Rut'theran Village
step
#label MoontouchedWildkin
.isQuestComplete 978
.goto Teldrassil,55.497,92.045
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Erelas Ambersky|r
.turnin 978 >> Turn in Moontouched Wildkin
.accept 979 >> Accept Find Ranshalla
.target Erelas Ambersky
step << Mage
#completewith next
.cast 3562 >>|cRXP_WARN_Cast|r |T135763:0|t[Teleport: Ironforge]
.usespell 3562
.zoneskip Ironforge
step << Mage
.goto Ironforge,27.18,8.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dink|r
.trainer >> Train your class spells
.target Dink
step << !Mage
.goto Teldrassil,58.39,94.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
.fly Darkshore >> Fly to Darkshore
.target Vesprystus
.zoneskip Teldrassil,1
step << !Mage
.goto Darkshore,32.4,43.8
.zone Wetlands >> Take the boat to Wetlands
step << !Mage
.goto Wetlands,10.69,60.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Helbrek|r
.home >> Set your Hearthstone to Menethil Harbor
.target Innkeeper Helbrek
.bindlocation 2104
step << !Mage
.goto Wetlands,9.490,59.694
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shellei|r
.fly Ironforge >> Fly to Ironforge
.target Shellei Brondir
step
.goto Ironforge,38.368,55.303
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Historian Archesonus|r
.accept 3702 >> Accept The Smoldering Ruins of Thaurissan
.target Royal Historian Archesonus
step
.goto Ironforge,38.368,55.303
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Historian Archesonus|r
.skipgossip
.complete 3702,1 
.target Royal Historian Archesonus
step
.goto Ironforge,38.368,55.303
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Historian Archesonus|r
.turnin 3702 >> Turn in The Smoldering Ruins of Thaurissan
.accept 3701 >> Accept The Smoldering Ruins of Thaurissan
.target Royal Historian Archesonus
step << Shaman
.goto Ironforge,55.436,28.942
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Javad|r
.trainer >> Train your class spells
.target Farseer Javad
step << Priest/Paladin
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Toldren Deepiron|r << Priest
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brandur Ironhammer|r << Paladin
.goto Ironforge,25.207,10.756 << Priest
.goto Ironforge,23.141,6.149 << Paladin
.accept 8415 >> Accept Chillwind Camp << Paladin
.trainer >> Train your class spells
.target Toldren Deepiron << Priest
.target Brandur Ironhammer << Paladin
step
.goto Ironforge,75.768,23.389
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Laris Geardawdle|r
.turnin 4512 >> Turn in A Little Slime Goes a Long Way
.target Laris Geardawdle
step
#optional
.isQuestComplete 4513
.goto Ironforge,75.768,23.389
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Laris Geardawdle|r
.turnin 4513 >> Turn in A Little Slime Goes a Long Way
.target Laris Geardawdle
step << Warlock
.goto Ironforge,53.2,7.8,15,0
.goto Ironforge,52.701,6.070
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jubahl Corpseseeker|r
.vendor >> |cRXP_BUY_Buy|r |T133738:0|t[Grimoires] |cRXP_BUY_for your|r |T136220:0|t[Succubus] |cRXP_BUY_or|r |T136221:0|t[Voidwalker]
.target Jubahl Corpseseeker
step << Warlock
.goto Ironforge,51.1,8.7,15,0
.goto Ironforge,50.343,5.657
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Briarthorn|r
.trainer >> Train your class spells
.target Briarthorn
step << Rogue
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fenthwick|r
.goto Ironforge,51.495,15.330
.trainer >> Train your class spells
.target Fenthwick
step << Hunter/Warrior
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Regnus Thundergranite|r << Hunter
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilban Tosslespanner|r << Warrior
.goto Ironforge,69.872,82.890 << Hunter
.goto Ironforge,65.905,88.405 << Warrior
.trainer >> Train your class spells
.target Regnus Thundergranite << Hunter
.target Bilban Tosslespanner << Warrior
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bailey Stonemantle|r
.goto Ironforge,35.90,60.17
.bankwithdraw 8529 >> Withdraw the following items from your bank:
>>|T134863:0|t[Noggenfogger Elixirs] (If you have any)
.target Bailey Stonemantle
step
#ah
.goto Ironforge,25.800,75.500,-1
.goto Ironforge,24.200,74.600,-1
.goto Ironforge,23.800,71.800,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to an |cRXP_FRIENDLY_Ironforge Auctioneer|r
>>|cRXP_BUY_Buy the following items from the Auction House. You will need these later for multiple free quest turn ins in EPL|r
>>|cRXP_WARN_There are 5 different quests and each require 30. If you can't get 30 of one type then skip it|r
>>|cRXP_WARN_Don't take these out of your mailbox yet|r
.collect 22529,30,9136,1 
.collect 22526,30,9126,1 
.collect 22525,30,9124,1 
.collect 22527,30,9128,1 
.collect 22528,30,9131,1 
.collect 12359,2,6026,1 
.collect 11128,1,6026,1 
.collect 10562,8,6026,1 
.collect 10560,8,6026,1 
.target Auctioneer Lympkin
.target Auctioneer Redmuse
.target Auctioneer Buckler
step
#completewith cloth2
+|cRXP_WARN_NOTE: You should also gather extra cloth for the Stormwind turn ins as you will shortly head there|r
.zoneskip Ironforge,1
step
#sticky
#label cloth1
.goto Ironforge,74.082,48.208
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bubulo Acerbus|r
>>Do the Gnomeregan cloth turn ins. You'll need 3 stacks of each cloth. Skip this step if you're unable to complete all of them
.turnin 7807 >> Turn in A Donation of Wool
.turnin 7808 >> Turn in A Donation of Silk
.turnin 7809 >> Turn in A Donation of Mageweave
.turnin 7811 >> Turn in A Donation of Runecloth
.zoneskip Ironforge,1
.target Bubulo Acerbus
step
#label cloth2
.goto Ironforge,43.224,31.574
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mistina Steelshield|r
>>Do the Ironforge cloth turn ins. You'll need 3 stacks of each cloth. Skip this step if you're unable to complete all of them
.turnin 7802 >> Turn in A Donation of Wool
.turnin 7803 >> Turn in A Donation of Silk
.turnin 7804 >> Turn in A Donation of Mageweave
.turnin 7805 >> Turn in A Donation of Runecloth
.zoneskip Ironforge,1
.target Mistina Steelshield
step
#requires cloth1
#requires cloth2
.isNotOnQuest 5091,5066,10373
#loop
.goto Ironforge,33.4,20.0,70,0
.goto Ironforge,25.6,61.6,70,0
.goto Ironforge,64.8,77.8,70,0
.goto Ironforge,70.6,48.0,70,0
.goto Ironforge,65.0,22.6,70,0
.goto Ironforge,50.4,10.4,70,0
.goto Ironforge,32.6,21.0,70,0
.goto Ironforge,40.8,39.4,70,0
.goto Ironforge,51.2,56.6,70,0
.goto Ironforge,55.8,35.2,70,0
.goto Ironforge,33.0,22.4,70,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Courier Hammerfall|r
>>|cRXP_FRIENDLY_Courier Hammerfall|r |cRXP_WARN_patrols through all of Ironforge|r
.accept 5090 >> Accept A Call to Arms: The Plaguelands!
.unitscan Courier Hammerfall
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (A)
#subgroup RXP Survival Guide 47-60
<< Alliance
#name 56-59 Plaguelands
#next 59-60 Hellfire Peninsula (Part 1)
step << !Mage
#completewith SWCloth
.goto Ironforge,78.00,52.00,5,0
.zone Stormwind City >> Enter the Deeprun Tram. Take the tram to Stormwind
step << !Mage
.dungeon ST
#optional
.isQuestComplete 1475
.goto Stormwind City,64.328,20.627
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brohann Caskbelly|r
.turnin 1475 >> Turn in Into The Temple of Atal'Hakkar
.target Brohann Caskbelly
step << !Mage
.goto Stormwind City,78.213,17.980
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Highlord Bolvar Fordragon|r
.accept 6182 >> Accept The First and the Last
.target Highlord Bolvar Fordragon
.xp <56,1
step << !Mage
#completewith next
.goto StormwindClassic,74.90,54.00,20,0
.goto StormwindClassic,78.43,60.15,20,0
.goto StormwindClassic,78.67,60.13,5 >> Enter the SI:7 Headquarters. Travel up stairs toward |cRXP_FRIENDLY_Master Mathias Shaw|r
step << !Mage
.goto StormwindClassic,75.78,59.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Mathias Shaw|r
.turnin 6182 >> Turn in The First and the Last
.accept 6183 >> Accept Honor the Dead
.turnin 6183 >> Turn in Honor the Dead
.accept 6184 >> Accept Flint Shadowmore
.target Master Mathias Shaw
.xp <56,1
step << Mage
#completewith FnL
.cast 3561 >>|cRXP_WARN_Cast|r |T135763:0|t[Teleport: Stormwind]
.usespell 3561
.zoneskip Stormwind City
step
#label SWCloth
.goto Stormwind City,44.274,73.973
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Clavicus Knavingham|r up stairs
>>Do the Stormwind cloth turn ins. You'll need 3 stacks of each cloth. Skip this step if you're unable to complete all of them
.turnin 7791 >> Turn in A Donation of Wool
.turnin 7793 >> Turn in A Donation of Silk
.turnin 7794 >> Turn in A Donation of Mageweave
.turnin 7795 >> Turn in A Donation of Runecloth
.target Clavicus Knavingham
step << Mage
.dungeon ST
#optional
.isQuestComplete 1475
.goto Stormwind City,64.328,20.627
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brohann Caskbelly|r
.turnin 1475 >> Turn in Into The Temple of Atal'Hakkar
.target Brohann Caskbelly
step << Mage
.goto Stormwind City,78.213,17.980
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Highlord Bolvar Fordragon|r
.accept 6182 >> Accept The First and the Last
.target Highlord Bolvar Fordragon
.xp <56,1
step << Mage
#completewith next
.goto StormwindClassic,74.90,54.00,20,0
.goto StormwindClassic,78.43,60.15,20,0
.goto StormwindClassic,78.67,60.13,5 >> Enter the SI:7 Headquarters. Travel up stairs toward |cRXP_FRIENDLY_Master Mathias Shaw|r
step << Mage
#label FnL
.goto StormwindClassic,75.78,59.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Master Mathias Shaw|r
.turnin 6182 >> Turn in The First and the Last
.accept 6183 >> Accept Honor the Dead
.turnin 6183 >> Turn in Honor the Dead
.accept 6184 >> Accept Flint Shadowmore
.target Master Mathias Shaw
.xp <56,1
step
.isQuestAvailable 3823,4283,3824,4296,3701,3825
.goto Stormwind City,66.27,62.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Burning Steppes >> Fly to Burning Steppes
.target Dungar Longdrink
.zoneskip Burning Steppes
step
.goto Burning Steppes,84.555,68.677
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.accept 3823 >> Accept Extinguish the Firegut
.target Oralius
step
#loop
.goto Burning Steppes,75.34,48.62,0
.goto Burning Steppes,82.89,37.61,0
.goto Burning Steppes,80.74,44.38,0
.goto Burning Steppes,75.34,48.62,70,0
.goto Burning Steppes,82.89,37.61,70,0
.goto Burning Steppes,80.74,44.38,70,0
>>Kill |cRXP_ENEMY_Firegut Ogre Mages|r, |cRXP_ENEMY_Firegut Ogres|r and |cRXP_ENEMY_Firegut Brutes|r
.complete 3823,1 
.mob +Firegut Ogre Mage
.complete 3823,2 
.mob +Firegut Ogre
.complete 3823,3 
.mob +Firegut Brute
step
.goto Burning Steppes,84.555,68.677
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.turnin 3823 >> Turn in Extinguish the Firegut
.accept 4283 >> Accept FIFTY! YEP!
.accept 3824 >> Accept Gor'tesh the Brute Lord
.target Oralius
step
#completewith next
>>Kill |cRXP_ENEMY_Blackrock Orcs|r and |cRXP_ENEMY_Worgs|r. Loot them for their |cRXP_LOOT_Blackrock Medallions|r
.complete 4283,1 
.mob Blackrock Slayer
.mob Blackrock Warlock
.mob Blackrock Sorcerer
.mob Blackrock Soldier
.mob Blackrock Worg
.mob Slavering Ember Worg
.mob Giant Ember Worg
step
.goto Burning Steppes,39.21,55.27
>>Kill |cRXP_ENEMY_Gor'tesh|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_ENEMY_Gor'tesh|r |cRXP_WARN_hits very hard and has a thrash attack, be careful|r
.complete 3824,1 
.mob Gor'tesh
step
#loop
.goto Burning Steppes,39.21,55.27,0
.goto Burning Steppes,41.8,35.4,0
.goto Burning Steppes,49.6,55.4,0
.goto Burning Steppes,50.6,61.8,0
.goto Burning Steppes,55.4,54.6,0
.goto Burning Steppes,39.21,55.27,60,0
.goto Burning Steppes,49.6,55.4,0,60,0
.goto Burning Steppes,50.6,61.8,0,60,0
.goto Burning Steppes,55.4,54.6,0,60,0
.goto Burning Steppes,48.8,59.6,60,0
>>Kill |cRXP_ENEMY_Blackrock Orcs|r and |cRXP_ENEMY_Worgs|r. Loot them for their |cRXP_LOOT_Blackrock Medallions|r
.complete 4283,1 
.mob Blackrock Slayer
.mob Blackrock Warlock
.mob Blackrock Sorcerer
.mob Blackrock Soldier
.mob Blackrock Worg
.mob Slavering Ember Worg
.mob Giant Ember Worg
step
#completewith next
.goto Burning Steppes,65.236,24.007
.subzone 251 >> Travel to Flame Crest
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.accept 4296 >> Accept Tablet of the Seven
.goto Burning Steppes,65.152,23.911
.target Maxwort Uberglint
step
#completewith next
>>Click the |cRXP_PICK_Thaurissan Relics|r on the ground
.complete 3701,1 
step
.goto Burning Steppes,54.121,40.757
>>Click the |cRXP_PICK_Tablet of the Seven|r. Loot it for the |cRXP_LOOT_Tablet Transcript |r
.complete 4296,1 
.skipgossip
step
#loop
.goto Burning Steppes,54.2,38.3,0
.goto Burning Steppes,65.6,43.9,0
.goto Burning Steppes,63.5,33.8,0
.goto Burning Steppes,57.4,36.4,0
.goto Burning Steppes,54.2,38.3,60,0
.goto Burning Steppes,65.6,43.9,60,0
.goto Burning Steppes,63.5,33.8,60,0
.goto Burning Steppes,57.4,36.4,60,0
>>Click the |cRXP_PICK_Thaurissan Relics|r on the ground
.complete 3701,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maxwort Uberglint|r
.turnin 4296 >> Turn in Tablet of the Seven
.goto Burning Steppes,65.152,23.911
.target Maxwort Uberglint
step
.goto Burning Steppes,84.554,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.turnin 4283 >> Turn in FIFTY! YEP!
.turnin 3824 >> Turn in Gor'tesh the Brute Lord
.accept 3825 >> Accept Ogre Head On A Stick = Party
.target Oralius
step
.goto Burning Steppes,80.997,46.790
>>Click the |cRXP_PICK_Soft Dirt Mound|r atop the mountain
.complete 3825,1 
step
.goto Burning Steppes,84.554,68.679
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oralius|r
.turnin 3825 >> Turn in Ogre Head On A Stick = Party
.target Oralius
step << Mage
#completewith next
.cast 3562 >>|cRXP_WARN_Cast|r |T135763:0|t[Teleport: Ironforge]
.usespell 3562
.zoneskip Ironforge
step << Mage
.isQuestAvailable 5168,5181,5211
.goto Ironforge,55.51,47.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gryth Thurden|r
.fly Southshore >> Fly to Southshore
.target Gryth Thurden
.zoneskip Western Plaguelands
.zoneskip Eastern Plaguelands
.zoneskip Hillsbrad Foothills
.zoneskip The Hinterlands
step << !Mage
.isQuestAvailable 5168,5181,5211
.hs >> Hearth to Wetlands
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
.cooldown item,6948,>2,1
.bindlocation 2104,1
.zoneskip Western Plaguelands
.zoneskip Eastern Plaguelands
.zoneskip Hillsbrad Foothills
.zoneskip The Hinterlands
step << !Mage
.isQuestAvailable 5168,5181,5211
.goto Wetlands,9.490,59.694
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shellei Brondir|r
.fly Southshore>> Fly to Southshore
.target Shellei Brondir
.zoneskip Western Plaguelands
.zoneskip Eastern Plaguelands
.zoneskip Hillsbrad Foothills
.zoneskip The Hinterlands
step << !Mage
.goto Burning Steppes,84.333,68.328
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Borgus Stoutarm|r
.fly Southshore>> Fly to Southshore
.target Borgus Stoutarm
.zoneskip Burning Steppes,1
step
.isQuestAvailable 5168,5181,5211
.goto Hillsbrad Foothills,51.170,58.927
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Anderson|r
.home >> Set your Hearthstone to Southshore
.target Innkeeper Anderson
.bindlocation 271
step << Rogue
.dungeon ST
.isQuestComplete 8236
.goto Hillsbrad Foothills,75.575,22.076,20,0
.goto Alterac Mountains,86.026,78.879
.subzone 3486 >> Travel to Ravenholdt Manor
step << Rogue
.dungeon ST
.isQuestComplete 8236
.goto Alterac Mountains,86.026,78.879
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Jorach Ravenholdt|r upstairs
.turnin 8236 >> Turn in The Azure Key
.target Lord Jorach Ravenholdt
step
.dungeon ST
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darla Harris|r
.goto Hillsbrad Foothills,49.338,52.272
.fly The Hinterlands>> Fly to The Hinterlands
.target Darla Harris
.zoneskip The Hinterlands
step
.dungeon ST
.isQuestComplete 1446
.goto The Hinterlands,33.751,75.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Atal'ai Exile|r
.turnin 1446 >> Turn in Jammal'an the Prophet
.target Atal'ai Exile
step
.dungeon ST
#completewith FlyWPL
.goto The Hinterlands,11.071,46.153
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Guthrum Thunderfist|r
.fly Western Plaguelands>> Fly to Western Plaguelands
.target Guthrum Thunderfist
.zoneskip The Hinterlands,1
step
.dungeon !ST
#completewith FlyWPL
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darla Harris|r
.goto Hillsbrad Foothills,49.338,52.272
.fly Western Plaguelands>> Fly to Western Plaguelands
.target Darla Harris
.zoneskip Western Plaguelands
.zoneskip Eastern Plaguelands
step
.goto Western Plaguelands,42.909,84.494
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Truuen|r
>>|cRXP_WARN_Skip this step if he is not here|r
.accept 9474 >> Accept The Mark of the Lightbringer
.target Anchorite Truuen
step << Paladin
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 8415 >> Turn in Chillwind Point
.accept 8414 >> Accept Dispelling Evil
.target Commander Ashlam Valorfist
step
.isOnQuest 5090
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5090 >> Turn in A Call to Arms: The Plaguelands!
.accept 5092 >> Accept Clear the Way
.target Commander Ashlam Valorfist
step
#optional
.isOnQuest 5091
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5091 >> Turn in A Call to Arms: The Plaguelands!
.accept 5092 >> Accept Clear the Way
.target Commander Ashlam Valorfist
step
#optional
.isOnQuest 5066
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5066 >> Turn in A Call to Arms: The Plaguelands!
.accept 5092 >> Accept Clear the Way
.target Commander Ashlam Valorfist
step
#optional
.isOnQuest 10373
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 10373 >> Turn in A Call to Arms: The Plaguelands!
.accept 5092 >> Accept Clear the Way
.target Commander Ashlam Valorfist
step
.isQuestTurnedIn 5090,5091,5066,10373
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.accept 5092 >> Accept Clear the Way
.target Commander Ashlam Valorfist
step
.goto Western Plaguelands,42.967,83.546
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Argent Officer Pureheart|r
.turnin 6028 >> Turn in The Everlook Report
.accept 5401 >> Accept Argent Dawn Commission
.turnin 5401 >> Turn in Argent Dawn Commission
.target Argent Officer Pureheart
step
#completewith ADC
.cast 17670 >> |cRXP_WARN_Equip the|r |T133440:0|t[Argent Dawn Commission] |cRXP_WARN_to start collecting|r |T133447:0|t[Scourgestones]
.use 12846
step
.goto Western Plaguelands,43.419,84.834
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathaniel Dumah|r
.accept 5903 >> Accept A Plague Upon Thee
.target Nathaniel Dumah
step
.isQuestTurnedIn 6183
.goto Western Plaguelands,43.607,84.506
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flint Shadowmore|r
.turnin 6184 >> Turn in Flint Shadowmore
.accept 6185 >> Accept The Eastern Plagues
.target Flint Shadowmore
step << Paladin
#completewith BLTN
>>Kill any of the |cRXP_ENEMY_Scourge|r. Loot them for their |cRXP_LOOT_Minion's Scourgestones|r
.complete 8414,1 
step
#label FlyWPL
.goto Western Plaguelands,48.91,80.84,70,0
.goto Western Plaguelands,50.01,76.90
>>Kill |cRXP_ENEMY_Skeletal Flayers|r and |cRXP_ENEMY_Slavering Ghouls|r
.complete 5092,1 
.mob +Skeletal Flayer
.complete 5092,2 
.mob +Slavering Ghoul
step
#optional
#completewith next
.abandon 5601 >> Abandon Sister Pamela if you have it. You cannot accept Little Pamela if you have the quest Sister Pamela. Little Pamela gives more XP
step
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.accept 5142 >> Accept Little Pamela
.target Marlene Redpath
step << Paladin
#optional
.isQuestComplete 8414
.goto Western Plaguelands,51.99,82.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priest Thel'danis|r
.turnin 8414 >> Turn in Dispelling Evil
.accept 8416 >> Accept Inert Scourgestones
.target High Priest Thel'danis
step << Paladin
#optional
.isQuestTurnedIn 8414
.goto Western Plaguelands,51.99,82.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priest Thel'danis|r
.accept 8416 >> Accept Inert Scourgestones
.target High Priest Thel'danis
step
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5092 >> Turn in Clear the Way
.accept 5215 >> Accept The Scourge Cauldrons
.accept 5097 >> Accept All Along the Watchtowers
.target Commander Ashlam Valorfist
step << Paladin
#optional
.isOnQuest 8416
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 8416 >> Turn in Inert Scourgestones
.target Commander Ashlam Valorfist
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5215 >> Turn in The Scourge Cauldrons
.accept 5216 >> Accept Target: Felstone Field
.target High Priestess MacDonnell
step
.goto Western Plaguelands,40.116,71.561,-1
.goto Western Plaguelands,40.038,71.713,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance|r
.complete 5097,1 
step
.goto Western Plaguelands,37.015,57.145
>>Kill |cRXP_ENEMY_Cauldron Lord Bilemaw|r. Loot him for the |cRXP_LOOT_Felstone Field Cauldron Key|r
>>|cRXP_ENEMY_Cauldron Lord Bilemaw|r |cRXP_WARN_may spawn as you approach the|r |cRXP_PICK_Scourge Cauldron|r
.complete 5216,1 
.unitscan Cauldron Lord Bilemaw
step
.goto Western Plaguelands,37.194,56.860
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5216 >> Turn in Target: Felstone Field
.accept 5217 >> Accept Return to Chillwind Camp
step
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice Felstone|r up stairs
.accept 5021 >>Accept Better Late Than Never
.target Janice Felstone
step
#completewith next
.goto Western Plaguelands,38.05,54.56,8,0
>>Exit the house
.goto Western Plaguelands,38.58,55.33,6 >>Go inside the barn
step
#label BLTN
.goto Western Plaguelands,38.72,55.24
>>Click |cRXP_PICK_Janice's Parcel|r on the ground
>>|cRXP_WARN_This has a 5 second cast time|r
>>|cRXP_WARN_You can do this from behind the wall to avoid aggroing anything inside|r
>>|cRXP_WARN_Avoid aggroing the |cRXP_ENEMY_Scarlets|r outside the barn. If you do, run away|r
.turnin 5021 >>Turn in Better Late Than Never
.accept 5022 >>Accept Better Late Than Never
step << Paladin
.isOnQuest 8414
.goto Western Plaguelands,37.194,56.860
>>Kill any of the |cRXP_ENEMY_Scourge|r. Loot them for their |cRXP_LOOT_Minion's Scourgestones|r
.complete 8414,1 
.mob Skeletal Flayer
.mob Skeletal Sorcerer
.mob Slavering Ghoul
step
.goto Western Plaguelands,42.326,66.105,-1
.goto Western Plaguelands,42.422,66.222,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance|r
.complete 5097,2 
step
.goto Western Plaguelands,44.217,63.319,-1
.goto Western Plaguelands,44.247,63.131,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance|r
.complete 5097,3 
step
#label ADC
.goto Western Plaguelands,46.681,71.135,-1
.goto Western Plaguelands,46.558,71.156,-1
.use 12815 >> |cRXP_WARN_Use the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_next to the Tower entrance|r
.complete 5097,4 
step << Paladin
.goto Western Plaguelands,51.99,82.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priest Thel'danis|r
.turnin 8414 >> Turn in Dispelling Evil
.accept 8416 >> Accept Inert Scourgestones
.target High Priest Thel'danis
step << Paladin
.goto Western Plaguelands,51.99,82.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priest Thel'danis|r
.turnin 8414 >> Turn in Dispelling Evil
.accept 8416 >> Accept Inert Scourgestones
.target High Priest Thel'danis
step
#completewith next
.subzone 3197 >> Travel to Chillwind Camp
step
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 5097 >> Turn in All Along the Watchtowers
.accept 5533 >> Accept Scholomance

.target Commander Ashlam Valorfist
step
#sticky
#optional
.isQuestTurnedIn 5097
.destroy 12815 >> Destroy the |T135432:0|t[Beacon Torch]
step << Paladin
.goto Western Plaguelands,42.702,84.031
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.turnin 8416 >> Turn in Inert Scourgestones
.target Commander Ashlam Valorfist
step
.goto Western Plaguelands,42.665,83.774
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alchemist Arbington|r
>>|cRXP_WARN_Don't accept the follow up yet|r
.turnin 5533 >> Turn in Scholomance
.target Alchemist Arbington
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5217 >> Turn in Return to Chillwind Camp
.accept 5219 >> Accept Target: Dalson's Tears
.target High Priestess MacDonnell
step
.goto Western Plaguelands,46.156,52.427
>>Kill |cRXP_ENEMY_Cauldron Lord Malvinious|r. Loot him for the |cRXP_LOOT_Dalson's Tears Cauldron Key|r
>>|cRXP_ENEMY_Cauldron Lord Malvinious|r |cRXP_WARN_may spawn as you approach the|r |cRXP_PICK_Cauldron|r
.complete 5219,1 
.unitscan Cauldron Lord Malvinious
step
#label DalsonCauldron
.goto Western Plaguelands,46.176,52.009
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5219 >> Turn in Target: Dalson's Tears
.accept 5220 >> Accept Return to Chillwind Camp
step
#completewith next
.goto Eastern Plaguelands,9.57,66.20,30,0
.goto 1423/0,-2621.000,2105.600
.zone Eastern Plaguelands >> Travel to Eastern Plaguelands
step
#label ArriveTirion
.goto Eastern Plaguelands,7.530,43.635
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion Fordring|r
.accept 5542 >> Accept Demon Dogs
.accept 5543 >> Accept Blood Tinged Skies
.accept 5544 >> Accept Carrion Grubbage
.target Tirion Fordring
step
#completewith PamelaRedpath
>>Kill |cRXP_ENEMY_Plaguebats|r
>>Kill |cRXP_ENEMY_Plaguehound Runts|r
>>Kill |cRXP_ENEMY_Carrion Grubs|r. Loot them for their |cRXP_LOOT_Worm Meat|r
.complete 5543,1 
.mob +Plaguebat
.complete 5542,1 
.mob +Plaguehound Runt
.complete 5544,1 
.mob +Carrion Grub
step
.isQuestTurnedIn 6183
.goto Eastern Plaguelands,27.266,74.956
>>Click the |cRXP_PICK_Mangled Human Remains|r on the ground. Loot it for the |cRXP_LOOT_SI:7 Insignia (Fredo)|r
.complete 6185,2 
step
.isQuestTurnedIn 6183
.goto Eastern Plaguelands,28.805,74.880
>>Click the |cRXP_PICK_Mangled Human Remains|r on the ground. Loot it for the |cRXP_LOOT_SI:7 Insignia (Turyen)|r
.complete 6185,3 
step
.isQuestTurnedIn 6183
.goto Eastern Plaguelands,28.806,79.853
>>Click the |cRXP_PICK_Mangled Human Remains|r on the ground. Loot it for the |cRXP_LOOT_SI:7 Insignia (Rutger)|r
.complete 6185,1 
step
.isOnQuest 5601
.goto Eastern Plaguelands,36.489,90.718
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela Redpath|r
.turnin 5601 >> Turn in Sister Pamela
.accept 5149 >> Accept Pamela's Doll
.target Pamela Redpath
step
.isOnQuest 5142
.goto Eastern Plaguelands,36.489,90.718
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela Redpath|r
.turnin 5142 >> Turn in Little Pamela
.accept 5149 >> Accept Pamela's Doll
.target Pamela Redpath
step
#label PamelaRedpath
.isQuestTurnedIn 5601,5142
.goto Eastern Plaguelands,36.489,90.718
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela Redpath|r
.accept 5149 >> Accept Pamela's Doll
.target Pamela Redpath
step
.goto Eastern Plaguelands,38.038,92.549,15,0
.goto Eastern Plaguelands,39.643,92.522,15,0
.goto Eastern Plaguelands,39.622,90.079
>>Loot |T134164:0|t[|cRXP_LOOT_Pamela's Doll's Head|r], |T134230:0|t[|cRXP_LOOT_Pamela's Doll's Left Side|r] and |T134230:0|t[|cRXP_LOOT_Pamela's Doll's Right Side|r] throughout the buildings
>>|cRXP_WARN_They all spawn randomly in any of the 3 buildings in Darrowshire|r
.collect 12886,1,5149,1 
.collect 12887,1,5149,1 
.collect 12888,1,5149,1 
step
>>|cRXP_WARN_Use|r |T134164:0|t[|cRXP_LOOT_Pamela's Doll's Head|r]|cRXP_WARN_,|r |T134230:0|t[|cRXP_LOOT_Pamela's Doll's Left Side|r] |cRXP_WARN_or|r |T134230:0|t[|cRXP_LOOT_Pamela's Doll's Right Side|r] |cRXP_WARN_to combine them into|r |cRXP_LOOT_Pamela's Doll|r
.complete 5149,1 
.use 12886
.use 12887
.use 12888
step
.goto Eastern Plaguelands,36.489,90.718
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela Redpath|r
.turnin 5149 >> Turn in Pamela's Doll
.accept 5152 >> Accept Auntie Marlene
.accept 5241 >> Accept Uncle Carlin
.target Pamela Redpath
step
#sticky
#label grubs
.goto Eastern Plaguelands,19.2,35.2,0
.goto Eastern Plaguelands,32.2,39.4,0
.goto Eastern Plaguelands,50.6,41.0,0
.goto Eastern Plaguelands,49.2,27.0,0
.waypoint Eastern Plaguelands,19.2,35.2,70,0
.waypoint Eastern Plaguelands,32.2,39.4,70,0
.waypoint Eastern Plaguelands,50.6,41.0,70,0
.waypoint Eastern Plaguelands,49.2,27.0,70,0
>>Kill |cRXP_ENEMY_Carrion Grubs|r and |cRXP_ENEMY_Carrion Devourers|r. Loot them for their |cRXP_LOOT_Worm Meat|r
.complete 5544,1 
.mob Carrion Grub
.mob Carrion Devourer
step
>>Kill |cRXP_ENEMY_Plaguebats|r
>>Kill |cRXP_ENEMY_Plaguehound Runts|r and |cRXP_ENEMY_Plaguehounds|r
.complete 5543,1 
.mob +Plaguebat
.goto Eastern Plaguelands,33.8,82.2,70,0
.goto Eastern Plaguelands,17.2,78.2,70,0
.goto Eastern Plaguelands,16.6,65.8,70,0
.goto Eastern Plaguelands,40.8,71.8,70,0
.goto Eastern Plaguelands,48.8,77.6,70,0
.goto Eastern Plaguelands,32.2,83.4,70,0
.goto Eastern Plaguelands,31.6,71.6
.complete 5542,1 
.mob +Plaguehound Runt
.goto Eastern Plaguelands,33.8,82.2,70,0
.goto Eastern Plaguelands,17.2,78.2,70,0
.goto Eastern Plaguelands,16.6,65.8,70,0
.goto Eastern Plaguelands,40.8,71.8,70,0
.goto Eastern Plaguelands,48.8,77.6,70,0
.goto Eastern Plaguelands,32.2,83.4,70,0
.goto Eastern Plaguelands,31.6,71.6
.complete 5542,2 
.mob +Plaguehound
.goto Eastern Plaguelands,46.6,64.6,70,0
.goto Eastern Plaguelands,51.6,61.0,70,0
.goto Eastern Plaguelands,50.0,54.6,70,0
.goto Eastern Plaguelands,53.8,51.6,70,0
.goto Eastern Plaguelands,61.6,61.2,70,0
.goto Eastern Plaguelands,75.0,73.2,70,0
.goto Eastern Plaguelands,68.6,58.4,70,0
.goto Eastern Plaguelands,54.6,59.0
step
.isOnQuest 6030
.goto Eastern Plaguelands,81.437,59.820
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Duke Nicholas Zverenhoff|r
.turnin 6030 >> Turn in Duke Nicholas Zverenhoff
.target Duke Nicholas Zverenhoff
step
.goto Eastern Plaguelands,81.518,59.766
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin Redpath|r
.turnin 5241 >> Turn in Uncle Carlin
.accept 5211 >> Accept Defenders of Darrowshire
.target Carlin Redpath
step
#ah
.goto Eastern Plaguelands,80.937,58.515
>>Withdraw the following items from your mailbox if you bought them earlier. If you didn't buy them, skip this step
.collect 12359,2,6026,1 
.collect 11128,1,6026,1 
.collect 10562,8,6026,1 
.collect 10560,8,6026,1 
step
#optional
.goto Eastern Plaguelands,80.605,57.979
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey LaRue|r
.accept 6026 >> Accept That's Asking A Lot
.turnin 6026 >> Turn in That's Asking A Lot
.itemcount 12359,2 
.itemcount 11128,1 
.itemcount 10562,8 
.itemcount 10560,8 
.target Smokey LaRue
step
.goto Eastern Plaguelands,81.637,59.280
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khaelyn Steelwing|r
.fp Chapel >> Get the Light's Hope Chapel flight path
.target Khaelyn Steelwing
step
.goto Eastern Plaguelands,79.405,63.983
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caretaker Alen|r
.accept 5281 >> Accept The Restless Souls
.accept 6021 >> Accept Zaeldarr the Outcast
.vendor >> |cRXP_BUY_Restock on|r |T135661:0|t[Jagged Arrows] |cRXP_BUY_if needed|r << Hunter
.target Caretaker Alen
step
#completewith Egan
.goto Eastern Plaguelands,60.6,68.4,0
.goto Eastern Plaguelands,67.7,41.5,0
.goto Eastern Plaguelands,75.5,51.2,0
.goto Eastern Plaguelands,41.8,30.4,0
.goto Eastern Plaguelands,28.35,28.49,0
>>Kill |cRXP_ENEMY_Diseased Flayers|r, |cRXP_ENEMY_Gibbering Ghouls|r and |cRXP_ENEMY_Cannibal Ghouls|r. Talk to the |cRXP_FRIENDLY_Darrowshire Spirits|r that spawn from their corpses
.complete 5211,1 
.mob Diseased Flayer
.mob Gibbering Ghoul
.mob Cannibal Ghoul
.target Darrowshire Spirit
step
#completewith Egan
#loop
.goto Eastern Plaguelands,69.2,50.6,0
.goto Eastern Plaguelands,64.6,32.0,0
.goto Eastern Plaguelands,51.6,30.6,0
.goto Eastern Plaguelands,56.6,40.0,0
.goto Eastern Plaguelands,44.4,36.4,0
.goto Eastern Plaguelands,48.0,24.6,0
.goto Eastern Plaguelands,50.9,38.3,0
.goto Eastern Plaguelands,69.2,50.6,70,0
.goto Eastern Plaguelands,64.6,32.0,70,0
.goto Eastern Plaguelands,51.6,30.6,70,0
.goto Eastern Plaguelands,56.6,40.0,70,0
.goto Eastern Plaguelands,44.4,36.4,70,0
.goto Eastern Plaguelands,48.0,24.6,70,0
.goto Eastern Plaguelands,50.9,38.3,70,0
>>Kill |cRXP_ENEMY_Frenzied Plaguehounds|r
.complete 5542,3 
.mob Frenzied Plaguehound
step
.isOnQuest 5245
.goto Eastern Plaguelands,53.506,21.999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Aurora Skycaller|r
.turnin 5245 >> Turn in Troubled Spirits of Kel'Theril
.target Aurora Skycaller
step
#sticky
#optional
.destroy 12891 >> Destroy |T134708:0|t[Jaron's Pick]
step
#loop
.goto Eastern Plaguelands,41.2,25.2,0
.goto Eastern Plaguelands,42.1,38.2,0
.goto Eastern Plaguelands,32.0,35.8,0
.goto Eastern Plaguelands,33.8,25.8,0
.goto Eastern Plaguelands,29.9,23.1,0
.goto Eastern Plaguelands,26.5,37.5,0
.goto Eastern Plaguelands,20.4,20.8,0
.goto Eastern Plaguelands,31.4,29.6,0
.goto Eastern Plaguelands,41.2,25.2,70,0
.goto Eastern Plaguelands,42.1,38.2,70,0
.goto Eastern Plaguelands,32.0,35.8,70,0
.goto Eastern Plaguelands,33.8,25.8,70,0
.goto Eastern Plaguelands,29.9,23.1,70,0
.goto Eastern Plaguelands,26.5,37.5,70,0
.goto Eastern Plaguelands,20.4,20.8,70,0
.goto Eastern Plaguelands,31.4,29.6,70,0
>>Open the |cRXP_PICK_Large Termite Mounds|r throughout Plaguewood. Loot them for the |cRXP_LOOT_Plagueland Termites|r
.complete 5903,1 
step
#label Egan
.goto Eastern Plaguelands,14.448,33.740
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Egan|r
.turnin 5281 >> Turn in The Restless Souls
.target Egan
step
#completewith next
.goto Eastern Plaguelands,60.6,68.4,0
.goto Eastern Plaguelands,67.7,41.5,0
.goto Eastern Plaguelands,75.5,51.2,0
.goto Eastern Plaguelands,41.8,30.4,0
.goto Eastern Plaguelands,28.35,28.49,0
.goto Eastern Plaguelands,66.0,39.2,0
>>Kill |cRXP_ENEMY_Diseased Flayers|r, |cRXP_ENEMY_Gibbering Ghouls|r and |cRXP_ENEMY_Cannibal Ghouls|r. Talk to the |cRXP_FRIENDLY_Darrowshire Spirits|r that spawn from their corpses
.complete 5211,1 
.mob Diseased Flayer
.mob Gibbering Ghoul
.mob Cannibal Ghoul
.target Darrowshire Spirit
step
.goto Eastern Plaguelands,69.2,50.6,70,0
.goto Eastern Plaguelands,64.6,32.0,70,0
.goto Eastern Plaguelands,51.6,30.6,70,0
.goto Eastern Plaguelands,56.6,40.0,70,0
.goto Eastern Plaguelands,44.4,36.4,70,0
.goto Eastern Plaguelands,48.0,24.6,70,0
.goto Eastern Plaguelands,50.9,38.3
>>Kill |cRXP_ENEMY_Frenzied Plaguehounds|r
.complete 5542,3 
.mob Frenzied Plaguehound
step
#completewith next
#requires grubs
.goto Eastern Plaguelands,23.850,42.438,10,0
.goto Eastern Plaguelands,23.253,41.611,5 >> If you have |T134863:0|t[Noggenfogger Elixirs] you may try the mountain skip to get to |cRXP_FRIENDLY_Tirion Fordring|r faster << !Priest !Mage
.goto Eastern Plaguelands,23.253,41.611,5 >> If you have |T134863:0|t[Noggenfogger Elixirs] or |T132917:0|t[Light Feathers] you may try the mountain skip to get to |cRXP_FRIENDLY_Tirion Fordring|r faster << Priest/Mage
>>The starting location is marked on your map. If you're unable to do it, just run around normally
.link https://youtu.be/YxkJh6ocQsg >> |cRXP_WARN_Click here for video reference|r
step
#requires grubs
.goto Eastern Plaguelands,7.530,43.635
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion Fordring|r
.turnin 5542 >> Turn in Demon Dogs
.turnin 5543 >> Turn in Blood Tinged Skies
.turnin 5544 >> Turn in Carrion Grubbage
.accept 5742 >> Accept Redemption
.target Tirion Fordring
step
.goto Eastern Plaguelands,7.530,43.635
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion Fordring|r
.complete 5742,1 
.skipgossip
.target Tirion Fordring
step
.goto Eastern Plaguelands,7.530,43.635
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion Fordring|r
.turnin 5742 >> Turn in Redemption
.target Tirion Fordring
step
#completewith next
.goto Eastern Plaguelands,27.850,86.245,15 >> Enter The Undercroft crypt
step
.goto Eastern Plaguelands,27.467,84.853
>>Kill |cRXP_ENEMY_Zaeldarr the Outcast|r. Loot him for his |cRXP_LOOT_Head|r
.complete 6021,1 
.mob Zaeldarr the Outcast
step
.isOnQuest 5903,6185,5152
.hs >> Hearth to Southshore
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
.cooldown item,6948,>2,1
.zoneskip Western Plaguelands
.bindlocation 271,1
step
.isOnQuest 5903,6185,5152
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darla Harris|r
.goto Hillsbrad Foothills,49.338,52.272
.fly Western Plaguelands>> Fly to Western Plaguelands
.target Darla Harris
.zoneskip Western Plaguelands
step
#completewith next
.subzone 3197 >> Travel to Chillwind Camp
.zoneskip Hillsbrad Foothills
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.target High Priestess MacDonnell
.turnin 5220 >> Turn in Return to Chillwind Camp
.accept 5222 >> Accept Target: Writhing Haunt
step
.goto Western Plaguelands,42.665,83.774
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alchemist Arbington|r
.accept 5537 >> Accept Skeletal Fragments
.target Alchemist Arbington
step
.goto Western Plaguelands,43.418,84.834
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathaniel Dumah|r
.turnin 5903 >> Turn in A Plague Upon Thee
.accept 5904 >> Accept A Plague Upon Thee
.target Nathaniel Dumah
step
.isQuestTurnedIn 6183
.goto Western Plaguelands,43.607,84.506
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Flint Shadowmore|r
.turnin 6185 >> Turn in The Eastern Plagues
.accept 6186 >> Accept The Blightcaller Cometh
.target Flint Shadowmore
step
#sticky
#optional
.destroy 15043 >> Destroy any left over |T134321:0|t[Plagueland Termites]
step
.goto Western Plaguelands,49.2,78.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene Redpath|r
>>|cRXP_FRIENDLY_Marlene Redpath|r may also be upstairs
.turnin 5152 >> Turn in Auntie Marlene
.accept 5153 >> Accept A Strange Historian
.target Marlene Redpath
step
.goto Western Plaguelands,49.696,76.754
>>Click |cRXP_PICK_Joseph Redpath's Monument|r. Loot it for |cRXP_LOOT_Joseph's Wedding Ring|r
.complete 5153,1 
step
#completewith CountingTime
>>Kill |cRXP_ENEMY_Skeletal Executioners|r and |cRXP_ENEMY_Skeletal Acolytes|r. Loot them for their |cRXP_LOOT_Skeletal Fragments|r
.complete 5537,1 
.mob Skeletal Executioner
.mob Skeletal Acolyte
step
.goto Western Plaguelands,39.456,66.760
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r upstairs
.turnin 5153 >> Turn in A Strange Historian
.accept 5154 >> Accept The Annals of Darrowshire
.accept 4971 >> Accept A Matter of Time
.target Chromie
step
#completewith next
.goto Western Plaguelands,43.822,69.250,10,0 >> Enter the Ruins of Andorhal Town Hall
.link https://youtu.be/GUb1Ny4NwQw >> |cRXP_WARN_Click here for video reference on how to enter the Town Hall safely|r
step
.goto Western Plaguelands,43.50,69.46
>>Enter the Ruins of Andorhal Town Hall
>>Open the |cRXP_PICK_Musty Tomes|r. Loot them for the |cRXP_LOOT_Annals of Darrowshire|r
>>|cRXP_WARN_The correct |cRXP_PICK_Musty Tome|r will have its pages be a completely dark-shade, or have a brown stain. If it's only half white and half black, that is a trap|r
>>|cRXP_WARN_There can be times where all |cRXP_PICK_Musty Tomes|r are traps and you must open them to force a correct one to spawn|r
.complete 5154,1 
.link https://youtu.be/GUb1Ny4NwQw >> |cRXP_WARN_Click here for video reference on how to identify the correct|r |cRXP_PICK_Musty Tome|r
step
.goto Western Plaguelands,45.172,62.559,25,0
.goto Western Plaguelands,46.858,62.040,25,0
.goto Western Plaguelands,48.324,62.610,25,0
.goto Western Plaguelands,48.10,63.92,20,0
.goto Western Plaguelands,48.06,66.18
>>Kill |cRXP_ENEMY_Temporal Parasites|r
.use 12627 >>|cRXP_WARN_Use the|r |T134229:0|t[Temporal Displacer] |cRXP_WARN_at the silos to make them spawn. If the silo isn't pulsing blue then it cannot spawn any|r |cRXP_ENEMY_Temporal Parasites|r
>>|cRXP_WARN_Multiple |cRXP_ENEMY_Temporal Parasites|r can spawn at the same time, and once one dies, another one can instantly spawn. They will also keep casting|r |T136091:0|t[Slow] |cRXP_WARN_on you severely reducing your movement and attack speed|r
>>|cRXP_WARN_The |cRXP_ENEMY_Parasites|r cannot swim! If you get overwhelmed try to run into|r |T135861:0|t[|cRXP_LOOT_Water|r] |cRXP_WARN_to evade them|r
.complete 4971,1 
.mob Temporal Parasite
step
.isQuestComplete 4971
.goto Western Plaguelands,39.456,66.760
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r upstairs
.turnin 4971 >> Turn in A Matter of Time
.accept 4972 >> Accept Counting Out Time
.turnin 5154 >> Turn in The Annals of Darrowshire
.accept 5210 >> Accept Brother Carlin
.target Chromie
step
.isQuestTurnedIn 4971
.goto Western Plaguelands,39.456,66.760
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r upstairs
.accept 4972 >> Accept Counting Out Time
.turnin 5154 >> Turn in The Annals of Darrowshire
.accept 5210 >> Accept Brother Carlin
.target Chromie
step
.goto Western Plaguelands,39.456,66.760
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r upstairs
.turnin 5154 >> Turn in The Annals of Darrowshire
.accept 5210 >> Accept Brother Carlin
.target Chromie
step
#optional
.abandon 4971 >> Abandon A Matter of Time if it's too difficult
step
.isQuestTurnedIn 4971
#loop
.goto Western Plaguelands,38.71,68.25,0
.goto Western Plaguelands,38.51,69.74,0
.goto Western Plaguelands,40.63,68.40,0
.goto Western Plaguelands,41.08,67.45,0
.goto Western Plaguelands,40.69,66.16,0
.goto Western Plaguelands,41.46,69.85,0
.goto Western Plaguelands,42.17,68.88,0
.goto Western Plaguelands,42.67,70.31,0
.goto Western Plaguelands,38.71,68.25,20,0
.goto Western Plaguelands,38.51,69.74,20,0
.goto Western Plaguelands,40.63,68.40,20,0
.goto Western Plaguelands,41.08,67.45,20,0
.goto Western Plaguelands,40.69,66.16,20,0
.goto Western Plaguelands,41.46,69.85,15,0
.goto Western Plaguelands,42.17,68.88,20,0
.goto Western Plaguelands,42.67,70.31,20,0
>>Open the |cRXP_PICK_Small Lockboxes|r. Loot them for |cRXP_LOOT_Andorhal Watches|r
>>|cRXP_WARN_These are found inside of the burnt-down houses|r
.complete 4972,1 
step
#label CountingTime
.isQuestTurnedIn 4971
.goto Western Plaguelands,39.456,66.760
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r
.turnin 4972 >> Turn in Counting Out Time
.target Chromie
step
#loop
.goto Western Plaguelands,37.8,70.6,0
.goto Western Plaguelands,42.6,73.8,0
.goto Western Plaguelands,49.6,69.4,0
.goto Western Plaguelands,49.6,63.6,0
.goto Western Plaguelands,43.0,63.4,0
.goto Western Plaguelands,39.8,67.4,0
.goto Western Plaguelands,37.8,70.6,70,0
.goto Western Plaguelands,42.6,73.8,70,0
.goto Western Plaguelands,49.6,69.4,70,0
.goto Western Plaguelands,49.6,63.6,70,0
.goto Western Plaguelands,43.0,63.4,70,0
.goto Western Plaguelands,39.8,67.4,70,0
>>Kill |cRXP_ENEMY_Skeletal Executioners|r and |cRXP_ENEMY_Skeletal Acolytes|r. Loot them for their |cRXP_LOOT_Skeletal Fragments|r
.complete 5537,1 
.mob Skeletal Executioner
.mob Skeletal Acolyte
step
.goto Western Plaguelands,53.021,66.052
>>Kill |cRXP_ENEMY_Cauldron Lord Razarch|r. Loot him for the |cRXP_LOOT_Writhing Haunt Cauldron Key|r
>>|cRXP_ENEMY_Cauldron Lord Razarch|r |cRXP_WARN_may spawn as you approach the|r |cRXP_PICK_Cauldron|r
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_cast|r |T135848:0|t[Flash Freeze]|cRXP_WARN_. This ability stuns for 5 seconds. Avoid aggroing multiple at the same time|r
.complete 5222,1 
.unitscan Cauldron Lord Razarch
step
.goto Western Plaguelands,53.020,65.718
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5222 >> Turn in Target: Writhing Haunt
.accept 5223 >> Accept Return to Chillwind Camp
step
.goto Western Plaguelands,53.733,64.662
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mulgris Deepriver|r
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_cast|r |T135848:0|t[Flash Freeze]|cRXP_WARN_. This ability stuns for 5 seconds. Avoid aggroing multiple at the same time|r

.accept 4984 >> Accept The Wildlife Suffers Too
.target Mulgris Deepriver
step
#completewith next
.goto Western Plaguelands,49.2,58.4,0
.goto Western Plaguelands,51.6,47.6,0
.goto Western Plaguelands,43.0,48.2,0
.goto Western Plaguelands,43.4,57.8,0
.goto Western Plaguelands,46.6,40.4,0
>>Kill |cRXP_ENEMY_Diseased Wolves|r
>>|cRXP_ENEMY_Diseased Wolves|r |cRXP_WARN_share spawns with |cRXP_ENEMY_Carrion Lurkers|r. You may need to kill them to force |cRXP_ENEMY_Diseased Wolves|r to spawn|r
.complete 4984,1 
.unitscan Diseased Wolf
step
.goto Western Plaguelands,47.796,50.671
>>|cRXP_WARN_Enter the Dalson's Tears Barn|r
>>Click |cRXP_PICK_Mrs. Dalson's Diary|r on the ground
.accept 5058 >> Accept Mrs. Dalson Diary
.turnin 5058 >> Turn in Mrs. Dalson Diary
step
.goto Western Plaguelands,47.86,49.88,25,0
.goto Western Plaguelands,48.48,51.56,25,0
.goto Western Plaguelands,47.39,51.77,25,0
.goto Western Plaguelands,46.64,49.21,25,0
.goto Western Plaguelands,47.86,49.88
>>Kill the |cRXP_LOOT_Wandering Skeleton|r. Loot it for the |cRXP_LOOT_Dalson Outhouse Key|r
>>|cRXP_WARN_The |cRXP_LOOT_Wandering Skeleton|r patrols around the Dalson's Tear Barn and House|r
.collect 12738,1,5060,1 
.unitscan Wandering Skeleton
step
#completewith next
.goto Western Plaguelands,48.109,49.654
>>Click the |cRXP_PICK_Outhouse|r to summon |cRXP_ENEMY_Farmer Dalson|r
.turnin 5059 >> Turn in Locked Away
step
.goto Western Plaguelands,48.115,49.814
>>Kill |cRXP_ENEMY_Farmer Dalson|r. Loot him for the |cRXP_LOOT_Dalson Cabinet Key|r
.collect 12739,1,5060,1 
.mob Farmer Dalson
step
.goto Western Plaguelands,47.353,49.626
>>Click the |cRXP_PICK_Locked Cabinet|r up stairs in the house
.turnin 5060 >> Turn in Locked Away
step
#completewith next
.goto Western Plaguelands,38.05,54.59,12 >>Go inside the house
step
.isQuestTurnedIn 5022
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice|r through the ground from the 1st floor
.turnin 5050 >>Turn in Better Late Than Never
.accept 5051 >>Accept Two Halves Become One
.target Janice Felstone
step
.isQuestTurnedIn 5022
.goto Western Plaguelands,38.16,57.10,60,0
.goto Western Plaguelands,36.34,58.23,60,0
.goto Western Plaguelands,36.43,56.37,60,0
.goto Western Plaguelands,38.16,57.10
>>Kill the |cRXP_ENEMY_Jabbering Ghoul|r. Loot it for the |T133443:0|t[Good Luck Other-Half-Charm]
>>|cRXP_WARN_He patrols around the Field|r
.collect 12722,1,5051,1 
.unitscan Jabbering Ghoul
step
.isQuestTurnedIn 5022
#completewith 2Halves1
>>|cRXP_WARN_Use the|r |T133443:0|t[Good Luck Other-Half-Charm] |cRXP_WARN_to create the|r |cRXP_LOOT_Good Luck Charm|r
.collect 12723,1,5051,1 
.use 12722 
step
.isQuestTurnedIn 5022
#completewith next
.goto Western Plaguelands,38.05,54.59,12 >>Go inside the house
step
.isQuestTurnedIn 5022
#label 2Halves1
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice|r through the ground from the 1st floor
.turnin 5051 >>Turn in Two Halves Become One
.target Janice Felstone
step
#loop
.goto Western Plaguelands,49.2,58.4,0
.goto Western Plaguelands,51.6,47.6,0
.goto Western Plaguelands,43.0,48.2,0
.goto Western Plaguelands,43.4,57.8,0
.goto Western Plaguelands,49.2,58.4,70,0
.goto Western Plaguelands,51.6,47.6,70,0
.goto Western Plaguelands,43.0,48.2,70,0
.goto Western Plaguelands,43.4,57.8,70,0
.goto Western Plaguelands,46.6,40.4,70,0
>>Kill |cRXP_ENEMY_Diseased Wolves|r
>>|cRXP_ENEMY_Diseased Wolves|r |cRXP_WARN_share spawns with |cRXP_ENEMY_Carrion Lurkers|r. You may need to kill them to force |cRXP_ENEMY_Diseased Wolves|r to spawn|r
.complete 4984,1 
.unitscan Diseased Wolf
step
.goto Western Plaguelands,53.733,64.662
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mulgris Deepriver|r
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_cast|r |T135848:0|t[Flash Freeze]|cRXP_WARN_. This ability stuns for 5 seconds. Avoid aggroing multiple at the same time|r

.turnin 4984 >> Turn in The Wildlife Suffers Too
.accept 4985 >> Accept The Wildlife Suffers Too
.target Mulgris Deepriver
step
#completewith next
.subzone 3197 >> Travel to Chillwind Camp
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5223 >> Turn in Return to Chillwind Camp
.accept 5225 >> Accept Target: Gahrron's Withering
.target High Priestess MacDonnell
step
.goto Western Plaguelands,42.665,83.774
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alchemist Arbington|r
.turnin 5537 >> Turn in Skeletal Fragments
.target Alchemist Arbington
step
.isQuestAvailable 6604,5168,5181,5211,5226,9474,5237,6389
.goto Western Plaguelands,42.924,85.061
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bibilfaz Featherwhistle|r
.fly Eastern Plaguelands >> Fly to Eastern Plaguelands
.target Bibilfaz Featherwhistle
.zoneskip Eastern Plaguelands
step
.isQuestAvailable 6604,5168,5181,5211,5226,9474,5237,6389
.goto Eastern Plaguelands,81.627,58.077
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessica Chambers|r
.home >> Set your Hearthstone to Light's Hope Chapel
.target Jessica Chambers
.bindlocation 2268
step
#optional
.isQuestComplete 5211
.goto Eastern Plaguelands,81.518,59.766
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin Redpath|r
.turnin 5211 >> Turn in Defenders of Darrowshire
.turnin 5210 >> Turn in Brother Carlin
.accept 5181 >> Accept Villains of Darrowshire
.accept 5168 >> Accept Heroes of Darrowshire
.target Carlin Redpath
step
.goto Eastern Plaguelands,81.518,59.766
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin Redpath|r
.turnin 5210 >> Turn in Brother Carlin
.accept 5181 >> Accept Villains of Darrowshire
.accept 5168 >> Accept Heroes of Darrowshire
.target Carlin Redpath
step
.goto Eastern Plaguelands,79.405,63.983
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caretaker Alen|r
.turnin 6021 >> Turn in Zaeldarr the Outcast
.target Caretaker Alen
step
#completewith SkullofHorgus
>>Kill |cRXP_ENEMY_Diseased Flayers|r, |cRXP_ENEMY_Gibbering Ghouls|r and |cRXP_ENEMY_Cannibal Ghouls|r. Talk to the |cRXP_FRIENDLY_Darrowshire Spirits|r that spawn from their corpses
.complete 5211,1 
.mob Diseased Flayer
.mob Gibbering Ghoul
.mob Cannibal Ghoul
.target Darrowshire Spirit
step
#label SkullofHorgus
.goto Eastern Plaguelands,51.106,49.937
>>Loot the |cRXP_LOOT_Skull of Horgus|r underwater
.complete 5181,1 
step
#loop
.goto Eastern Plaguelands,60.6,68.4,0
.goto Eastern Plaguelands,67.7,41.5,0
.goto Eastern Plaguelands,75.5,51.2,0
.goto Eastern Plaguelands,41.8,30.4,0
.goto Eastern Plaguelands,28.35,28.49,0
.goto Eastern Plaguelands,59.4,69.0,100,0
.goto Eastern Plaguelands,77.4,54.0,70,0
.goto Eastern Plaguelands,80.6,43.6,80,0
.goto Eastern Plaguelands,66.0,39.2,80,0
.goto Eastern Plaguelands,37.85,31.10,70,0
.goto Eastern Plaguelands,28.35,28.49,70,0
>>Kill |cRXP_ENEMY_Diseased Flayers|r, |cRXP_ENEMY_Gibbering Ghouls|r and |cRXP_ENEMY_Cannibal Ghouls|r. Talk to the |cRXP_FRIENDLY_Darrowshire Spirits|r that spawn from their corpses
.complete 5211,1 
.mob Diseased Flayer
.mob Gibbering Ghoul
.mob Cannibal Ghoul
.target Darrowshire Spirit
step
.goto Eastern Plaguelands,53.913,65.755
>>Loot the |cRXP_LOOT_Shattered Sword of Marduk|r on the ground
.complete 5181,2 
step
#completewith CLS
.zone Western Plaguelands >> Travel to Western Plaguelands
step
#completewith CLS
>>Kill |cRXP_ENEMY_Diseased Grizzlies|r
>>|cRXP_ENEMY_Diseased Grizzlies|r |cRXP_WARN_share spawns with |cRXP_ENEMY_Plague Lurkers|r. You may need to kill them to force |cRXP_ENEMY_Diseased Grizzlies|r to spawn|r
.complete 4985,1 
.unitscan Diseased Grizzly
step
.isOnQuest 5168
.goto Western Plaguelands,63.789,57.192
>>Loot |cRXP_LOOT_Redpath's Shield|r on the ground
.complete 5168,2 
step
#label CLS
.goto Western Plaguelands,62.644,58.945
>>Kill |cRXP_ENEMY_Cauldron Lord Soulwrath|r. Loot him for the |cRXP_LOOT_Gahrron's Withering Cauldron Key|r
>>|cRXP_ENEMY_Cauldron Lord Soulwrath|r |cRXP_WARN_may spawn as you approach the|r |cRXP_PICK_Cauldron|r
.complete 5225,1 
.unitscan Cauldron Lord Soulwrath
step
.goto Western Plaguelands,62.573,58.573
>>Click on the |cRXP_PICK_Scourge Cauldron|r
.turnin 5225 >> Turn in Target: Gahrron's Withering
.accept 5226 >> Accept Return to Chillwind Camp
step
#loop
.goto Western Plaguelands,58.8,58.6,0
.goto Western Plaguelands,53.6,48.0,0
.goto Western Plaguelands,58.8,52.6,0
.goto Western Plaguelands,67.2,46.6,0
.goto Western Plaguelands,66.0,55.6,0
.goto Western Plaguelands,60.8,50.8,0
.goto Western Plaguelands,58.8,58.6,70,0
.goto Western Plaguelands,53.6,48.0,70,0
.goto Western Plaguelands,58.8,52.6,70,0
.goto Western Plaguelands,67.2,46.6,70,0
.goto Western Plaguelands,66.0,55.6,70,0
.goto Western Plaguelands,60.8,50.8,70,0
>>Kill |cRXP_ENEMY_Diseased Grizzlies|r
>>|cRXP_ENEMY_Diseased Grizzlies|r |cRXP_WARN_share spawns with |cRXP_ENEMY_Plague Lurkers|r. You may need to kill them to force |cRXP_ENEMY_Diseased Grizzlies|r to spawn|r
.complete 4985,1 
.unitscan Diseased Grizzly
step
.goto Western Plaguelands,53.733,64.662
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mulgris Deepriver|r
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_cast|r |T135848:0|t[Flash Freeze]|cRXP_WARN_. This ability stuns for 5 seconds. Avoid aggroing multiple at the same time|r

.turnin 4985 >> Turn in The Wildlife Suffers Too
.accept 4986 >> Accept Glyphed Oaken Branch
.target Mulgris Deepriver
step
.goto Western Plaguelands,48.348,31.996
>>Click on the |cRXP_PICK_Northridge Lumber Mill Crate|r to place the |cRXP_PICK_Termite Barrel|r and then click on the |cRXP_PICK_Termite Barrel|r after
.skipgossip
.turnin 5904 >> Turn in A Plague Upon Thee
.accept 6389 >> Accept A Plague Upon Thee
step
.goto Western Plaguelands,51.923,28.062
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta Deepshadow|r
.accept 6004 >> Accept Unfinished Business
.target Kirsta Deepshadow
step
.goto Western Plaguelands,50.85,40.68,60,0
.goto Western Plaguelands,51.97,44.47,60,0
.goto Western Plaguelands,41.23,51.54,60,0
.goto Western Plaguelands,50.85,40.68
>>Kill |cRXP_ENEMY_Scarlet Medics|r, |cRXP_ENEMY_Scarlet Hunters|r, |cRXP_ENEMY_Scarlet Mages|r and |cRXP_ENEMY_Scarlet Knights|r
>>|cRXP_ENEMY_Scarlet Medics|r |cRXP_WARN_and |cRXP_ENEMY_Scarlet Hunters|r share spawns|r
>>|cRXP_ENEMY_Scarlet Mages|r |cRXP_WARN_and |cRXP_ENEMY_Scarlet Knights|r share spawns|r
.complete 6004,1 
.mob +Scarlet Medic
.complete 6004,2 
.mob +Scarlet Hunter
.complete 6004,3 
.mob +Scarlet Mage
.complete 6004,4 
.mob +Scarlet Knight
step
.goto Western Plaguelands,51.923,28.062
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta Deepshadow|r
.turnin 6004 >> Turn in Unfinished Business
.accept 6023 >> Accept Unfinished Business
.target Kirsta Deepshadow
step
.goto Western Plaguelands,56.38,34.11,50,0
.goto Western Plaguelands,57.83,36.10
>>Kill |cRXP_ENEMY_Huntsman Radley|r
.complete 6023,1 
.mob Huntsman Radley
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Cavalier Durgen|r
.complete 6023,2 
>>|cRXP_WARN_There is a level 63 elite mob that can spawn at the tower, if that's the case just be patient and wait for |cRXP_ENEMY_Cavalier Durgen|r to come down|r
.mob Scarlet High Clerist
.unitscan Cavalier Durgen
step
.isOnQuest 9474
.goto Western Plaguelands,55.192,23.511
>>Open the |cRXP_PICK_Holy Coffer|r at the top of the tower. Loot it for the |cRXP_LOOT_Mark of the Lightbringer|r
>>|cRXP_WARN_Skip this step if the |cRXP_ENEMY_Scarlet High Clerist|r is parked on top of the tower, avoid him at all costs|r
.complete 9474,1 
.mob Scarlet High Clerist
step
#completewith next
.goto Western Plaguelands,54.520,23.818
>>Kill |cRXP_ENEMY_Cavalier Durgen|r
>>|cRXP_WARN_He may be patrolling up and down the tower|r
.complete 6023,2 
.mob Scarlet High Clerist
.unitscan Cavalier Durgen
step
.goto Western Plaguelands,51.923,28.062
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta Deepshadow|r
.turnin 6023 >> Turn in Unfinished Business
.accept 6025 >> Accept Unfinished Business
.target Kirsta Deepshadow
step
#completewith HearthglenFinish
.goto Western Plaguelands,45.7,18.8
.subzone 190 >> Travel to Hearthglen
step
.goto Western Plaguelands,45.7,18.8
>>Ascend the Hearthglen Tower
>>|cRXP_WARN_You may either run straight to the top and jump down or clear your way up|r
>>|cRXP_WARN_Avoid |cRXP_ENEMY_High Protector Lorik|r who is a strong Elite that roams Hearthglen|r
.complete 6025,1 
.unitscan High Protector Lorik
.unitscan Scarlet Executioner
step
#label HearthglenFinish
.isOnQuest 5168
.goto Western Plaguelands,42.519,18.990
>>Loot |cRXP_LOOT_Davil's Libram|r on the table
>>|cRXP_WARN_Avoid |cRXP_ENEMY_High Protector Lorik|r who is a strong Elite that roams Hearthglen|r
.complete 5168,1 
.unitscan High Protector Lorik
step
.goto Western Plaguelands,51.923,28.062
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta Deepshadow|r
.turnin 6025 >> Turn in Unfinished Business
.isQuestComplete 6025
.target Kirsta Deepshadow
step
.isOnQuest 5168,5181,5211
.hs >> Hearth to Light's Hope Chapel
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue
.cooldown item,6948,>2,1
.zoneskip Eastern Plaguelands
.bindlocation 2268,1
step
#completewith HVD
.subzone 2268 >> Travel to Light's Hope Chapel
step
.goto Eastern Plaguelands,80.937,58.515
+|cRXP_WARN_If you bought|r |T133614:0|t[Dark Iron Scraps] |cRXP_WARN_/|r |T134139:0|t[Core of Elements] |cRXP_WARN_/|r |T133571:0|t[Crypt Fiend Parts] |cRXP_WARN_/|r |T133724:0|t[Bone Fragments] |cRXP_WARN_/|r |T136074:0|t[Savage Fronds] |cRXP_WARN_take them out of your mail. If you did not buy any, skip this step|r
.itemcount 22529,<30 
.itemcount 22526,<30 
.itemcount 22525,<30 
.itemcount 22527,<30 
.itemcount 22528,<30 
step
#completewith 5TurnIns
.goto Western Plaguelands,50.01,76.90,0
>>|cRXP_WARN_If you do not have the Reputation required to accept these quests, grind on nearby |cRXP_ENEMY_Undead|r until you are Friendly with the Argent Dawn|r
>>|cRXP_WARN_If you still have quests to turn in at Western Plaguelands fly there and turn them in, then grind any needed reputation still at Sorrow Hill in WPL. The location is marked on your map|r
.reputation 529,friendly
step
#optional
.goto Eastern Plaguelands,81.200,59.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rayne|r
.accept 9136 >> Accept Savage Flora
.turnin 9136 >> Turn in Savage Flora
.itemcount 22529,30
.target Rayne
step
#optional
.goto Eastern Plaguelands,81.505,58.556
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntsman Leopold|r
.accept 9124 >> Accept Cryptstalker Armor Doesn't Make Itself...
.turnin 9124 >> Turn in Cryptstalker Armor Doesn't Make Itself...
.itemcount 22525,30
.target Huntsman Leopold
step
#optional
.goto Eastern Plaguelands,81.428,58.507
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rohan the Assassin|r
.accept 9126 >> Accept Bonescythe Digs
.turnin 9126 >> Turn in Bonescythe Digs
.itemcount 22526,30
.target Rohan the Assassin
step
#optional
.goto Eastern Plaguelands,81.523,58.269
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Angela Dosantos|r
.accept 9128 >> Accept The Elemental Equation
.turnin 9128 >> Turn in The Elemental Equation
.itemcount 22527,30
.target Archmage Angela Dosantos
step
#optional
#label 5TurnIns
.goto Eastern Plaguelands,81.798,58.079
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korfax|r
.accept 9131 >> Accept Binding the Dreadnaught
.turnin 9131 >> Turn in Binding the Dreadnaught
.itemcount 22528,30
.target Korfax, Champion of the Light
step
#label HVD
.goto Eastern Plaguelands,81.518,59.766
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin Redpath|r
.turnin 5168 >> Turn in Heroes of Darrowshire
.turnin 5181 >> Turn in Villains of Darrowshire
.turnin 5211 >> Turn in Defenders of Darrowshire
.target Carlin Redpath
step
#completewith LoveandFamily
.goto Eastern Plaguelands,81.637,59.280
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Khaelyn Steelwing|r
.fly Western Plaguelands>> Fly to Western Plaguelands
.target Khaelyn Steelwing
.zoneskip Western Plaguelands
step
.goto Western Plaguelands,42.972,84.501
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Priestess MacDonnell|r
.turnin 5226 >> Turn in Return to Chillwind Camp
.target High Priestess MacDonnell
step
.isQuestComplete 9474
.goto Western Plaguelands,42.909,84.494
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anchorite Truuen|r
.turnin 9474 >> Turn in The Mark of the Lightbringer
.target Anchorite Truuen
step
.goto Western Plaguelands,42.702,84.031
.target Commander Ashlam Valorfist
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ashlam Valorfist|r
.accept 5237 >> Accept Mission Accomplished!
.turnin 5237 >> Turn in Mission Accomplished!
step
#label LoveandFamily
.goto Western Plaguelands,43.418,84.834
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathaniel Dumah|r
.turnin 6389 >> Turn in A Plague Upon Thee
.target Nathaniel Dumah
step << Mage
#completewith next
.isQuestComplete 4986
.cast 3565 >>|cRXP_WARN_Cast|r |T135755:0|t[Teleport: Darnassus]
.usespell 3565
.train 3565,3
.zoneskip Darnassus
step << Mage
.isQuestComplete 4986
.goto Darnassus,35.375,8.405
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mathrengyl Bearwalker|r
.turnin 4986 >> Turn in Glyphed Oaken Branch
.target Mathrengyl Bearwalker
step << Mage
#completewith next
.cast 3562 >>|cRXP_WARN_Cast|r |T135763:0|t[Teleport: Ironforge]
.usespell 3562
.zoneskip Ironforge
step << Mage
.goto Ironforge,27.18,8.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dink|r
.trainer >> Train your class spells
.target Dink
step << !Mage
#completewith next
.goto Western Plaguelands,42.924,85.061
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bibilfaz Featherwhistle|r
.fly Ironforge >> Fly to Ironforge
.target Bibilfaz Featherwhistle
.zoneskip Ironforge
step
.goto Ironforge,38.368,55.303
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Historian Archesonus|r
.turnin 3701 >> Turn in The Smoldering Ruins of Thaurissan
.target Royal Historian Archesonus
step << !Mage
#optional
.goto Western Plaguelands,42.924,85.061
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bibilfaz Featherwhistle|r
.fly Stormwind >> Fly to Stormwind
.target Bibilfaz Featherwhistle
.zoneskip Western Plaguelands,1
step << !Mage
#completewith endsw
.goto Ironforge,78.00,52.00,5,0
.zone Stormwind City >> Enter the Deeprun Tram. Take the tram to Stormwind
.zoneskip Western Plaguelands
step << Mage
.cast 3561 >>|cRXP_WARN_Cast|r |T135763:0|t[Teleport: Stormwind]
.usespell 3561
.zoneskip Stormwind City
step << Hunter
.goto StormwindClassic,61.609,15.269
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Einris Brightspear|r
.trainer >> Train your class spells
.target Einris Brightspear
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step << Hunter
.goto StormwindClassic,61.576,15.996
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karrina Mekenda|r
.trainer >> Train your pet spells
.target Karrina Mekenda
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step
.isOnQuest 6186
.goto Stormwind City,78.213,17.980
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Highlord Bolvar Fordragon|r
.turnin 6186 >> Turn in The Blightcaller Cometh
.target Highlord Bolvar Fordragon
step
#optional
.xp <60,1
.goto 1453/0,487.200,-8406.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alicia|r
.accept 11451 >> Accept Alicia's Poem
.target Alicia
.zoneskip Stormwind City,1
step
.isOnQuest 5022
.goto Stormwind City,48.47,30.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Factor Bathrilor|r inside on the 2nd floor
.turnin 5022 >> Turn in Better Late Than Never
.accept 5048 >> Accept Good Natured Emma
.target Royal Factor Bathrilor
step
.isQuestTurnedIn 5022
.goto Stormwind City,48.47,30.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Royal Factor Bathrilor|r inside on the 2nd floor
.accept 5048 >> Accept Good Natured Emma
.target Royal Factor Bathrilor
step
.isQuestTurnedIn 5022
.goto Stormwind City,52.6,41.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ol' Emma|r
>>|cRXP_FRIENDLY_Ol' Emma|r |cRXP_WARN_can be either inside her home on the 2nd floor, or patrolling the Trade District|r
.turnin 5048 >> Turn in Good Natured Emma
.target Ol' Emma
step << Priest/Paladin
#completewith next
.goto StormwindClassic,42.51,33.51,20 >> Travel to the Stormwind Cathedral
step << Paladin
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arthur the Faithful|r
.goto StormwindClassic,38.82,31.27,10,0
.goto StormwindClassic,38.67,32.82
.trainer >> Train your class spells
.target Arthur the Faithful
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step << Priest
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brother Joshua|r
.goto StormwindClassic,38.54,26.86
.trainer >> Train your class spells
.target Brother Joshua
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step << Druid
.goto StormwindClassic,20.898,55.491
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sheldras Moontree|r
.trainer >> Train your class spells
.target Sheldras Moontree
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step << Shaman
.goto Stormwind City,61.822,83.991
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Farseer Umbrua|r
.trainer >> Train your class spells
.target Farseer Umbrua
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step << Warlock
#completewith next
.goto Stormwind City,29.2,74.0,20,0
.goto Stormwind City,27.2,78.1,15 >> Go into The Slaughtered Lamb and go downstairs
step << Warlock
.goto StormwindClassic,26.117,77.225
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ursula Deline|r
.trainer >> Train your class spells
.target Ursula Deline
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step << Warrior
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wu|r or |cRXP_FRIENDLY_Ilsa|r
.goto StormwindClassic,76.08,50.14,15,0
.goto StormwindClassic,80.22,45.37,15,0
.goto StormwindClassic,78.68,45.79
.trainer >> Train your class spells
.target Wu Shen
.target Ilsa Corbin
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step << Rogue
.goto StormwindClassic,74.65,52.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Osborne|r
.trainer >> Train your class spells
.target Osborne the Night Man
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
step
#label endsw
.goto Stormwind City,66.27,62.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dungar Longdrink|r
.fly Blasted Lands>> Fly to Blasted Lands
.target Dungar Longdrink
.zoneskip Blasted Lands
.zoneskip Hellfire Peninsula
.zoneskip Shattrath City
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (A)
#subgroup RXP Survival Guide 47-60
<< Alliance
#name 59-60 Hellfire Peninsula (Part 1)
#next 60-61 Winterspring/Silithus
step
#completewith ArriveHH
+|cRXP_WARN_You will now travel to Outland to complete a few quick and easy quests for item upgrades in Hellfire Peninsula. You will then return to Azeroth to finish quests in Winterspring and Silithus before returning to Outland again|r
step
.goto Blasted Lands,66.57,18.95,20,0
.goto Blasted Lands,67.57,19.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Ardalan|r atop the tower
.accept 2783 >> Accept Petty Squabbles
.target Ambassador Ardalan
.zoneskip Hellfire Peninsula
step
.goto 1419/0,-3369.300,-10946.601
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bernie Heisten|r on the bottom floor
>>|cRXP_BUY_Buy a|r |T132791:0|t[|cRXP_LOOT_Nethergarde Bitter|r]
.collect 23848,1,9563,1 
.target Bernie Heisten
.zoneskip Hellfire Peninsula
step
.goto Swamp of Sorrows,34.28,66.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r on the border of Swamp of Sorrows
.turnin 2783 >> Turn in Petty Squabbles
.accept 2801 >> Accept A Tale of Sorrow
.complete 2801,1 
.skipgossip 7572,1
.target Fallen Hero of the Horde
.zoneskip Hellfire Peninsula
step
.goto Swamp of Sorrows,34.28,66.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Fallen Hero of the Horde|r on the border of Swamp of Sorrows
.turnin 2801 >> Turn in A Tale of Sorrow
.accept 2681 >>Accept The Stones That Bind Us
.target Fallen Hero of the Horde
.zoneskip Hellfire Peninsula
step
#optional
.isOnQuest 64038
.goto Blasted Lands,58.33,55.90 << tbc/wotlk
.goto 1419/0,-3196.90015,-11815.10059 << !tbc !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watch Commander Relthorn Netherwane|r outside the Dark Portal
.turnin 64038 >>Turn in The Dark Portal
.accept 10119 >> Accept Through the Dark Portal
.target Watch Commander Relthorn Netherwane
.zoneskip Hellfire Peninsula
step
.goto Blasted Lands,58.33,55.90 << tbc/wotlk
.goto 1419/0,-3196.90015,-11815.10059 << !tbc !wotlk
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Watch Commander Relthorn Netherwane|r outside the Dark Portal
.accept 10119 >> Accept Through the Dark Portal
.target Watch Commander Relthorn Netherwane
.zoneskip Hellfire Peninsula
step
#completewith ArriveHH
.goto Blasted Lands,58.764,60.162
.zone Hellfire Peninsula >> Go through the Dark Portal
step
.goto Hellfire Peninsula,87.32,50.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Duron|r
.turnin 10119 >> Turn in Through the Dark Portal
.accept 10288 >> Accept Arrival in Outland
.target Commander Duron
step
.goto Hellfire Peninsula,87.36,52.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amish Wildhammer|r
.turnin 10288 >> Turn in Arrival in Outland
.accept 10140 >> Accept Journey to Honor Hold
.target Amish Wildhammer
step
#completewith ArriveHH
.goto Hellfire Peninsula,87.36,52.42
.fly Honor Hold >>Talk to |cRXP_FRIENDLY_Amish Wildhammer|r to fly to Honor Hold
.skipgossip 18931,1
.target Amish Wildhammer
.subzoneskip 3538
step
#label ArriveHH
.goto Hellfire Peninsula,54.47,62.80,20,0
.goto Hellfire Peninsula,54.84,62.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marshal Isildor|r
.turnin 10140 >> Turn in Journey to Honor Hold
.accept 10254 >> Accept Force Commander Danath
.target Marshal Isildor
step
.goto 1944/530,2736.60010,-708.29999
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Father Malgor Devidicus|r
.target Father Malgor Devidicus
.accept 10058 >>Accept An Old Gift
step
.goto Hellfire Peninsula,54.22,63.60
.isQuestAvailable 10937,10078
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sid Limbardi|r
.home >> Set your Hearthstone to Honor Hold
>>|cRXP_BUY_Buy some of the new food/water if needed|r << !Warrior !Rogue !DK
>>|cRXP_BUY_Buy some of the new food if needed|r << Warrior/Rogue/DK
.target Sid Limbardi
.bindlocation 3538
.zoneskip Hellfire Peninsula,1
step
.goto Hellfire Peninsula,56.37,65.99,20,0
.goto Hellfire Peninsula,56.61,66.77,14,0
.goto Hellfire Peninsula,56.64,66.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Force Commander Danath Trollbane|r upstairs in the Keep
.turnin 10254 >> Turn in Force Commander Danath
.accept 10160 >> Accept Know your Enemy
.accept 10141 >> Accept The Legion Reborn
.target Force Commander Danath Trollbane
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumphry|r and |cRXP_FRIENDLY_Amadi|r
>>|cRXP_FRIENDLY_Dumphry|r |cRXP_WARN_may be patrolling slightly|r
.accept 10055 >> Accept Waste Not, Want Not
.goto Hellfire Peninsula,51.30,60.35,20,0
.goto Hellfire Peninsula,51.19,59.99,20,0
.goto Hellfire Peninsula,50.99,60.51
.target +Dumphry
.turnin 10160 >> Turn in Know your Enemy
.accept 10482 >> Accept Fel Orc Scavengers
.goto Hellfire Peninsula,50.91,60.19
.target +Lieutenant Amadi
step
#loop
.goto Hellfire Peninsula,54.53,54.12,50,0
.goto Hellfire Peninsula,54.23,52.51,50,0
.goto Hellfire Peninsula,55.53,53.32,50,0
.goto Hellfire Peninsula,57.07,53.05,50,0
.goto Hellfire Peninsula,57.62,51.67,50,0
.goto Hellfire Peninsula,58.55,52.43,50,0
.goto Hellfire Peninsula,59.54,51.80,50,0
.goto Hellfire Peninsula,62.09,50.91,50,0
.goto Hellfire Peninsula,54.53,54.12,0
>>Kill |cRXP_ENEMY_Bonechewers|r
>>Loot the |cRXP_PICK_Metal|r and |cRXP_PICK_Wood|r on the ground
>>|cRXP_WARN_Avoid|r |cRXP_ENEMY_Tagar Spinebreaker|r |cRXP_WARN_who is a level 61 elite that patrols the area|r
.complete 10482,1 
.mob +Bonechewer Mutant
.mob +Bonechewer Raider
.mob +Bonechewer Peon
.mob +Bonechewer Scavenger
.mob +Bonechewer Evoker
.mob +Bonechewer Orc
.complete 10055,1 
.complete 10055,2 
.unitscan Tagar Spinebreaker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumphry|r and |cRXP_FRIENDLY_Amadi|r
>>|cRXP_FRIENDLY_Dumphry|r |cRXP_WARN_may be patrolling slightly|r
.turnin 10055 >> Turn in Waste Not, Want Not
.accept 10078 >> Accept Laying Waste to the Unwanted
.goto Hellfire Peninsula,51.30,60.35,20,0
.goto Hellfire Peninsula,51.19,59.99,20,0
.goto Hellfire Peninsula,50.99,60.51
.target +Dumphry
.turnin 10482 >> Turn in Fel Orc Scavengers
.goto Hellfire Peninsula,50.91,60.19
.target +Lieutenant Amadi
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Altumus|r
.goto Hellfire Peninsula,61.74,60.67,15,0
.goto Hellfire Peninsula,61.69,60.90
.turnin 10141 >> Turn in The Legion Reborn
.accept 10142 >> Accept The Path of Anguish
.target Sergeant Altumus
step
#loop
.line Hellfire Peninsula,65.83,59.06,67.03,58.91,69.16,59.36,69.64,57.71,68.15,56.25,67.55,54.60,66.82,56.63,65.55,55.62,65.83,59.06
.goto Hellfire Peninsula,65.83,59.06,50,0
.goto Hellfire Peninsula,67.03,58.91,50,0
.goto Hellfire Peninsula,69.16,59.36,50,0
.goto Hellfire Peninsula,69.64,57.71,50,0
.goto Hellfire Peninsula,68.15,56.25,50,0
.goto Hellfire Peninsula,67.55,54.60,50,0
.goto Hellfire Peninsula,66.82,56.63,50,0
.goto Hellfire Peninsula,65.55,55.62,50,0
>>Kill a |cRXP_ENEMY_Dreadcaller|r, |cRXP_ENEMY_Flamewaker Imps|r and |cRXP_ENEMY_Infernal Warbringers|r
.complete 10142,1 
.mob +Dreadcaller
.complete 10142,2 
.mob +Flamewaker Imp
.complete 10142,3 
.mob +Infernal Warbringer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sergeant Altumus|r
.goto Hellfire Peninsula,61.74,60.67,15,0
.goto Hellfire Peninsula,61.69,60.90
.turnin 10142 >> Turn in The Path of Anguish
.accept 10143 >> Accept Expedition Point
.target Sergeant Altumus
step
#completewith ExpeditionPoint
.subzone 3815 >> Travel to Expedition Point
step
#label ExpeditionPoint
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Kingston|r
.turnin 10143 >> Turn in Expedition Point
.accept 10144 >> Accept Disrupt Their Reinforcements
.goto Hellfire Peninsula,71.34,62.76
.target Forward Commander Kingston
step
#loop
.goto Hellfire Peninsula,72.73,58.94,0
.goto Hellfire Peninsula,71.49,55.17,0
.goto Hellfire Peninsula,72.73,58.94,60,0
.goto Hellfire Peninsula,71.49,55.17,60,0
>>Kill |cRXP_ENEMY_Demons|r. Loot them for their |cRXP_LOOT_Demonic Rune Stones|r
.collect 28513,4,10144,1 
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
.goto Hellfire Peninsula,72.73,58.94
>>Click |cRXP_PICK_Portal Kaalez|r to disrupt it
.complete 10144,2 
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
.goto Hellfire Peninsula,71.49,55.17
>>Kill |cRXP_ENEMY_Demons|r. Loot them for their |cRXP_LOOT_Demonic Rune Stones|r
.collect 28513,4,10144,1 
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
.goto Hellfire Peninsula,71.49,55.17
>>Click |cRXP_PICK_Portal Grimh|r to disrupt it
.complete 10144,1 
step
.goto Hellfire Peninsula,71.34,62.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Kingston|r
.turnin 10144 >> Turn in Disrupt Their Reinforcements
.accept 10146 >> Accept Mission: The Murketh and Shaadraz Gateways
.target Forward Commander Kingston
step
#completewith next
.goto Hellfire Peninsula,71.41,62.48
.gossipoption 118831 >> Talk to |cRXP_FRIENDLY_Wing Commander Dabir'ee|r to start the bombing run
.skipgossip
.timer 102,Mission: Gateways Flight
.target Wing Commander Dabir'ee
step
.use 28038 >>|cRXP_WARN_Use the|r |T133712:0|t[Seaforium PU-36 Explosive Nether Modulator] |cRXP_WARN_on |cRXP_PICK_Gateway Shaadraz|r and |cRXP_PICK_Gateway Murketh|r during the flight|r
.complete 10146,2 
.goto Hellfire Peninsula,77.73,51.80,-1
.complete 10146,1 
.goto Hellfire Peninsula,78.00,47.24,-1
step
.goto Hellfire Peninsula,71.34,62.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forward Commander Kingston|r
.turnin 10146 >> Turn in Mission: The Murketh and Shaadraz Gateways
.accept 10340 >> Accept Shatter Point
.target Forward Commander Kingston
step
#completewith next
.goto Hellfire Peninsula,71.41,62.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Dabir'ee|r
.gossip 19409,0 >> Fly to Shatter Point
.skipgossip 19409,1
.timer 56,Shatter Point Flight
.target Wing Commander Dabir'ee
.subzoneskip 3920
step
.goto Hellfire Peninsula,78.42,34.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Runetog Wildhammer|r
.target Runetog Wildhammer
.turnin 10340 >>Turn in Shatter Point
.accept 10344 >>Accept Wing Commander Gryphongar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Gryphongar|r
.goto Hellfire Peninsula,79.34,33.86
.turnin 10344 >> Turn in Wing Commander Gryphongar
.accept 10163 >> Accept Mission: The Abyssal Shelf
.target Wing Commander Gryphongar
step
#completewith next
.goto Hellfire Peninsula,78.25,34.45
.gossip 20235,0 >>Talk to |cRXP_FRIENDLY_Gryphoneer Windbellow|r to fly to the Abyssal Shelf. If you don't kill everything after the first flight, talk to her again
.timer 154,Mission: The Abyssal Shelf Flight
.skipgossip 20235,1
.target Gryphoneer Windbellow
step
.goto Hellfire Peninsula,72.21,23.78,-1
.goto Hellfire Peninsula,72.60,19.99,-1
.goto Hellfire Peninsula,73.04,15.18,-1
.goto Hellfire Peninsula,72.69,11.19,-1
.use 28132 >>|cRXP_WARN_Use the|r |T133709:0|t[Area 52 Special] |cRXP_WARN_on the |cRXP_ENEMY_Gan'arg Peons|r, |cRXP_ENEMY_Mo'arg Overseers|r and |cRXP_ENEMY_Fel Cannons|r during the flight|r
>>|cRXP_WARN_If you didn't kill everything on the first pass, talk to |cRXP_FRIENDLY_Gryphoneer Windbellow|r again and select the option: "Send me to the Abyssal Shelf!"|r
.complete 10163,1 
.mob +Gan'arg Peon
.complete 10163,2 
.mob +Mo'arg Overseer
.complete 10163,3 
.mob +Fel Cannon
step
.goto Hellfire Peninsula,79.34,33.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wing Commander Gryphongar|r
.turnin 10163 >> Turn in Mission: The Abyssal Shelf
.accept 10382 >> Accept Go to the Front
.target Wing Commander Gryphongar
step
#completewith next
.goto Hellfire Peninsula,78.25,34.45
.gossip 20235,0 >>Talk to |cRXP_FRIENDLY_Gryphoneer Windbellow|r to fly to Honor Point
.skipgossip 20235,1
.timer 40,Honor Point Flight
.target Gryphoneer Windbellow
step
.goto Hellfire Peninsula,68.29,28.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Field Marshal Brock|r
.turnin 10382 >> Turn in Go to the Front
.target Field Marshal Brock
step
.use 26002 >>|cRXP_WARN_Use the|r |T135432:0|t[Flaming Torch] |cRXP_WARN_on the Catapults|r
.complete 10078,1 
.goto Hellfire Peninsula,58.50,47.64,-1
.complete 10078,2 
.goto Hellfire Peninsula,55.70,47.48,-1
.complete 10078,3 
.goto Hellfire Peninsula,53.55,48.24,-1
.complete 10078,4 
.goto Hellfire Peninsula,52.64,48.01,-1
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r outside Thrallmar Mine
.accept 10236 >> Accept Outland Sucks!
.target Foreman Razelcraz
step << Shaman
#loop
.goto Hellfire Peninsula,47.98,37.39,0
.goto Hellfire Peninsula,47.28,42.34,0
.goto Hellfire Peninsula,48.85,35.37,0
.goto Hellfire Peninsula,49.02,37.63,50,0
.goto Hellfire Peninsula,47.98,37.39,50,0
.goto Hellfire Peninsula,48.41,40.86,50,0
.goto Hellfire Peninsula,47.28,42.34,50,0
.goto Hellfire Peninsula,47.17,43.74,50,0
.goto Hellfire Peninsula,48.85,35.37,50,0
>>Loot the |cRXP_PICK_Shredder Parts|r boxes on the ground
.complete 10236,1 
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10236 >> Turn in Outland Sucks!
.accept 10238 >> Accept How to Serve Goblins
.target Foreman Razelcraz
step << Shaman
>>Free |cRXP_FRIENDLY_Manni|r, |cRXP_FRIENDLY_Moh|r and |cRXP_FRIENDLY_Jakk|r from the cages
.complete 10238,1 
.target +Manni
.goto Hellfire Peninsula,45.12,41.11,-1
.complete 10238,2 
.target +Moh
.goto Hellfire Peninsula,46.42,45.18,-1
.complete 10238,3 
.target +Jakk
.goto Hellfire Peninsula,47.50,46.63,-1
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10238 >> Turn in How to Serve Goblins
.accept 10629 >> Accept Shizz Work
.target Foreman Razelcraz
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
#completewith next
.cast 37690 >> |cRXP_WARN_Use the|r |T133942:0|t[Felhound Whistle] |cRXP_WARN_whilst beside |cRXP_FRIENDLY_Foreman Razelcraz|r to summon a|r |cRXP_FRIENDLY_Felhound|r
.use 30803
step << Shaman
.goto Hellfire Peninsula,50.7,28.9
>>Kill |cRXP_ENEMY_Deranged Helboars|r. Loot the |cRXP_LOOT_Droppings|r after the |cRXP_FRIENDLY_Felhound's RP|r for the |cRXP_PICK_Shredder Keys|r
.complete 10629,1 
.use 30803
.mob Deranged Helboar
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10629 >> Turn in Shizz Work
.accept 10630 >> Accept Beneath Thrallmar
.target Foreman Razelcraz
step << Shaman
.goto Hellfire Peninsula,51.72,31.68,20,0
.goto Hellfire Peninsula,52.57,30.59,20,0
.goto Hellfire Peninsula,54.39,31.57
>>Kill |cRXP_ENEMY_Urga'zz|r in the back of Thrallmar Mine
.complete 10630,1 
.mob Urga'zz
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10630 >> Turn in Beneath Thrallmar
.target Foreman Razelcraz
step
.isOnQuest 10078
.hs >> Hearth to Honor Hold
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue !DK
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue/DK
.cooldown item,6948,>2,1
.subzoneskip 3538
.bindlocation 3538,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dumphry|r
>>|cRXP_FRIENDLY_Dumphry|r |cRXP_WARN_may be patrolling slightly|r
.goto Hellfire Peninsula,51.30,60.35,20,0
.goto Hellfire Peninsula,51.19,59.99,20,0
.goto Hellfire Peninsula,50.99,60.51
.turnin 10078 >> Turn in Laying Waste to the Unwanted
.target Dumphry
step
.goto Hellfire Peninsula,50.87,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honor Guard Wesilow|r
.accept 10050 >> Accept Unyielding Souls
.target Honor Guard Wesilow
step
.goto Hellfire Peninsula,52.02,62.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Biggums|r
.accept 10079 >> Accept When This Mine's a-Rockin'
.target Foreman Biggums
step
.goto Hellfire Peninsula,52.38,62.35,20,0
.goto Hellfire Peninsula,54.17,64.51,15,0
.goto Hellfire Peninsula,56.17,62.31
>>Kill |cRXP_ENEMY_Gan'arg Sappers|r inside the Honor Hold Mine
.complete 10079,1 
.mob Gan'arg Sapper
step
.goto Hellfire Peninsula,52.02,62.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Biggums|r
.turnin 10079 >> Turn in When This Mine's a-Rockin'
.accept 10099 >> Accept The Mastermind
.target Foreman Biggums
step
.goto Hellfire Peninsula,52.38,62.35,20,0
.goto Hellfire Peninsula,54.17,64.51,15,0
.goto Hellfire Peninsula,56.28,61.30
>>Kill |cRXP_ENEMY_Z'kral|r at the end of the Mine
.complete 10099,1 
.mob Z'kral
step
.goto Hellfire Peninsula,52.02,62.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Biggums|r
.turnin 10099 >> Turn in The Mastermind
.target Foreman Biggums
step
#completewith MotL
.subzone 3546 >> Travel to the Expedition Armory
step
#completewith next
>>Kill |cRXP_ENEMY_Unyielding Footmen|r, |cRXP_ENEMY_Unyielding Sorcerers|r and |cRXP_ENEMY_Unyielding Knights|r
.complete 10050,1 
.mob +Unyielding Footman
.complete 10050,2 
.mob +Unyielding Sorcerer
.complete 10050,3 
.mob +Unyielding Knight
step
#label MotL
.goto Hellfire Peninsula,54.96,86.82
>>Loot the |cRXP_PICK_Mysteries of the Light|r book on the ground
.complete 10058,1 
step
>>Kill |cRXP_ENEMY_Unyielding Footmen|r, |cRXP_ENEMY_Unyielding Sorcerers|r and |cRXP_ENEMY_Unyielding Knights|r
.complete 10050,1 
.mob +Unyielding Footman
.goto Hellfire Peninsula,58.50,79.42,50,0
.goto Hellfire Peninsula,58.54,77.36,50,0
.goto Hellfire Peninsula,57.70,75.28,50,0
.goto Hellfire Peninsula,56.70,74.36,50,0
.goto Hellfire Peninsula,55.59,79.20
.complete 10050,2 
.mob +Unyielding Sorcerer
.goto Hellfire Peninsula,55.89,79.86,50,0
.goto Hellfire Peninsula,55.47,81.52,50,0
.goto Hellfire Peninsula,54.45,81.43,50,0
.goto Hellfire Peninsula,54.21,79.08,50,0
.goto Hellfire Peninsula,55.11,79.59
.complete 10050,3 
.mob +Unyielding Knight
.goto Hellfire Peninsula,56.44,77.81,50,0
.goto Hellfire Peninsula,54.57,78.22,50,0
.goto Hellfire Peninsula,53.58,85.16,50,0
.goto Hellfire Peninsula,55.25,85.59
step
#optional
.isOnQuest 10050,10058
.hs >> Hearth to Honor Hold
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue !DK
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue/DK
.cooldown item,6948,>2,1
.subzoneskip 3538
.bindlocation 3538,1
step
#completewith next
.subzone 3538 >> Return to Honor Hold
step
.goto Hellfire Peninsula,54.29,63.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Father Malgor Devidicus|r
.turnin 10058 >> Turn in An Old Gift
.target Father Malgor Devidicus
step
.goto 1944/530,2910.0,-595.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honor Guard Wesilow|r
.target Honor Guard Wesilow
.turnin 10050 >>Turn in Unyielding Souls
.accept 10057 >>Accept Looking to the Leadership
step
#completewith next
.subzone 3546 >> Return to the Expedition Armory
step
>>Kill |cRXP_ENEMY_Arch Mage Xintor|r and |cRXP_ENEMY_Commander Thalvos|r
.complete 10057,1 
.mob +Arch Mage Xintor
.goto Hellfire Peninsula,53.67,81.10,-1
.complete 10057,2 
.mob +Lieutenant Commander Thalvos
.goto Hellfire Peninsula,54.75,83.71,-1
step
#optional
.isOnQuest 10057
.hs >> Hearth to Honor Hold
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue !DK
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue/DK
.cooldown item,6948,>2,1
.subzoneskip 3538
.bindlocation 3538,1
step
#completewith next
.goto Hellfire Peninsula,50.87,60.36,60 >> Return to |cRXP_FRIENDLY_Honor Guard Wesilow|r
step
.goto Hellfire Peninsula,50.87,60.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Honor Guard Wesilow|r
.turnin 10057 >> Turn in Looking to the Leadership
.target Honor Guard Wesilow
step
.goto 1944/530,3228.800,-1295.300,80,0
.goto 1944/530,3697.200,-1623.900,80,0
.goto 1952/530,4286.600,-1878.900,80,0
.goto 1955/530,5128.300,-1964.300,80 >> Travel to Shattrath City
.zoneskip Shattrath City
step
.goto Shattrath City,64.061,41.112
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r
.fp Shattrath >> Get the Shattrath City flight path
.target Nutral
step
#optional
#completewith next
.goto Shattrath City,41.73,38.60,30 >> Take the elevator up to the Aldor Rise
step
#optional
.isOnQuest 11451
.goto 1955/530,5727.800,-1715.400
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caylee Dak|r
.turnin 11451 >> Turn in Alicia's Poem
.target Caylee Dak
step << Mage
.goto Shattrath City,58.749,47.167
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iorioa|r
.train 33690 >> Train |T135760:0|t[Teleport: Shattrath]
.target Iorioa
.xp <60,1
step << Mage
#optional
.goto Shattrath City,59.533,46.653
.zone The Exodar >> Take the Shattrath portal to Exodar
.train 25304,1 
.train 25306,1 
.train 10151,1 
.train 25345,1 
.xp <60,1
step << Mage
.goto The Exodar,47.228,62.305
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Edirah|r
.trainer >> Train your class spells
.target Edirah
.train 25304,1 
.train 25306,1 
.train 10151,1 
.train 25345,1 
.xp <60,1
step << Mage
.cast 3565 >>|cRXP_WARN_Cast|r |T135755:0|t[Teleport: Darnassus]
.usespell 3565
.train 3565,3
.zoneskip Darnassus
step << Shaman
.goto 1955/530,5357.500,-1880.200
.zone The Exodar >> Take the Shattrath portal to Exodar
.zoneskip Shattrath City,1
.train 29228,1 
.xp <60,1
step << Shaman
.goto The Exodar,32.450,23.996
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sulaa|r
.trainer >> Train your class spells
.target Sulaa
.train 29228,1 
.xp <60,1
step << Shaman
#completewith next
.goto 1947/1,6179.200,6216.100,20 >> Exit The Exodar
.zoneskip The Exodar,1
step << Shaman
.goto Azuremyst Isle,20.405,54.184
.zone Darkshore >> Take the boat to Darkshore
.zoneskip Darnassus
step << Shaman
.goto Darkshore,36.336,45.574
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Caylais Moonfeather|r
.fly Rut'theran Village >> Fly to Darnassus
.target Caylais Moonfeather
.zoneskip Darnassus
.zoneskip Teldrassil
step
.goto 1955/530,5414.000,-1791.000
.zone Darnassus >> Take the Shattrath portal to Darnassus
.zoneskip Shattrath City,1
step
#optional
.goto Teldrassil,55.889,89.456
.zone Darnassus >> Take the purple portal into Darnassus
step
#loop
.line Darnassus,36.6,42.4,37.6,16.2,52.6,19.2,56.6,8.8,65.4,15.8,60.8,23.4,62.4,55.6,68.0,59.2,63.8,72.2,60.2,67.8,49.2,80.8,39.6,74.6,38.6,47.0,61.6,40.6
.goto Darnassus,36.6,42.4,60,0
.goto Darnassus,37.6,16.2,60,0
.goto Darnassus,52.6,19.2,60,0
.goto Darnassus,56.6,8.8,50,0
.goto Darnassus,65.4,15.8,50,0
.goto Darnassus,60.8,23.4,50,0
.goto Darnassus,62.4,55.6,50,0
.goto Darnassus,68.0,59.2,50,0
.goto Darnassus,63.8,72.2,50,0
.goto Darnassus,60.2,67.8,50,0
.goto Darnassus,49.2,80.8,50,0
.goto Darnassus,39.6,74.6,50,0
.goto Darnassus,38.6,47.0,50,0
.goto Darnassus,61.6,40.6,50,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Herald Moonstalker|r
>>|cRXP_FRIENDLY_Herald Moonstalker|r |cRXP_WARN_patrols throughout Darnassus|r
>>|cRXP_WARN_Cast|r |T132172:0|t[Eagle Eye] |cRXP_WARN_to try and find her faster|r << Hunter
.accept 1047 >> Accept The New Frontier
.unitscan Herald Moonstalker
step
.goto Darnassus,34.814,9.255
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arch Druid Fandral Staghelm|r
.turnin 1047 >> Turn in The New Frontier
.accept 6761 >> Accept The New Frontier
.target Arch Druid Fandral Staghelm
step
.goto Darnassus,35.375,8.405
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mathrengyl Bearwalker|r on the middle floor
.turnin 6761 >> Turn in The New Frontier
.accept 6762 >> Accept Rabine Saturna
.target Mathrengyl Bearwalker
step
.isOnQuest 4986
.goto 1457/1,2563.900,10178.900
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mathrengyl Bearwalker|r
.target Mathrengyl Bearwalker
.turnin 4986 >>Turn in Glyphed Oaken Branch
step << Druid
.goto Darnassus,34.768,7.374
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Denatharion|r
.trainer >> Train your class spells
.target Denatharion
.train 31018,1 
.train 21850,1 
.train 9885,1 
.train 25299,1 
.train 25298,1 
step << Hunter
.goto Darnassus,40.377,8.545
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jocaste|r
.trainer >> Train your class spells
.target Jocaste
.train 25295,1 << Hunter 
.train 25294,1 << Hunter 
.train 25296,1 << Hunter 
.train 14287,1 << Hunter 
step << Priest
.goto 1457,37.903,82.753
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jandria|r
.trainer >> Train your class spells
.target Jandria
.train 34916,1 << Priest 
.train 25315,1 << Priest 
.train 10901,1 << Priest 
step << Rogue
.goto Darnassus,31.21,17.72,8,0
.goto Darnassus,36.99,21.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Syurna|r
.trainer >> Train your class spells
.target Syurna
.train 31016,1 << Rogue 
.train 11343,1 << Rogue 
step << Warrior
.goto Darnassus,58.945,35.336
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darnath Bladesinger|r
.trainer >> Train your class spells
.target Darnath Bladesinger
.train 25289,1 << Warrior 
step
.goto Darnassus,29.466,41.405
.zone Teldrassil >> Travel through the purple portal to Rut'theran Village
.zoneskip Darnassus,1
step
.goto Teldrassil,58.39,94.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vesprystus|r
.fly Emerald Sanctuary >>Fly to Emerald Sanctuary
.target Vesprystus
.zoneskip Teldrassil,1
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 31-33 Hillsbrad/Arathi part 1
#next 33-34 Shimmering Flats
step
#completewith next
.zone Durotar >> Leave Orgrimmar
.zoneskip Durotar
step << skip
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Stranglethorn Vale >>Take the Zeppelin to Stranglethorn Vale
.zoneskip Stranglethorn Vale
step << skip
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fp Grom'Gol Base Camp >>Get the Grom'Gol Base Camp flight path
.target Thysta
.isQuestAvailable 532
step << !Mage
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Tirisfal Glades >>Take the Zeppelin to Tirisfal Glades
.zoneskip Tirisfal Glades
.zoneskip Undercity
.zoneskip Hillsbrad Foothills
.isQuestAvailable 532
step << Mage
#completewith StealfromThievesPickup
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
step << Mage
.goto Undercity,82.79,15.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannah Akeley|r
>>|cRXP_BUY_Buy at least two|r |T134419:0|t[Rune of Teleportation]
.collect 17031,2,547,1 
.target Hannah Akeley
.isQuestAvailable 532
step << Undead !Warlock
#optional
#completewith next
.subzone 159 >> Travel to Brill
.xp <30,1
.money <38
.skill riding,75,1
step << Undead !Warlock
#optional
.goto Tirisfal Glades,60.09,52.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velma|r and |cRXP_FRIENDLY_Zachariah|r
.train 10906 >>Train |T136103:0|t[Undead Horsemanship]
.vendor >>|cRXP_BUY_Buy a|r |T132264:0|t[|cFF0070FFSkeletal Horse|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Velma Warnam
.target Zachariah Post
step << !Mage
#completewith StealfromThievesPickup
.goto Tirisfal Glades,61.80,65.06,20,0
.zone Undercity >> Enter Undercity
.zoneskip Undercity
step << BloodElf !Warlock !Paladin
#optional
#completewith next
.goto Undercity,65.87,1.48,15,0
.goto Undercity,65.82,5.44,15,0
.goto Undercity,62.76,11.02,12,0
.goto Undercity,54.67,11.25
.zone Silvermoon City >> Take the Orb of Translocation to Silvermoon City
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
#completewith next
.goto Silvermoon City,62.89,31.20,20,0
.goto Silvermoon City,75.63,58.34,20,0
.goto Silvermoon City,73.22,59.91,20,0
.goto Eversong Woods,56.43,49.91
.zone Eversong Woods >>Exit Silvermoon
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
.goto Eversong Woods,61.08,54.15,12,0
.goto Eversong Woods,61.38,53.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perascamin|r and |cRXP_FRIENDLY_Winaestra|r
.train 33388 >> Train |T136103:0|t[Apprentice Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132228:0|t[|cFF0070FFHawkstrider|r]
.target Perascamin
.target Winaestra
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
#completewith StealfromThievesPickup
.goto Silvermoon City,51.83,17.91,30,0
.goto Silvermoon City,49.45,15.00
.zone Undercity >>Take the Orb of Translocation back to Undercity
.skill riding,<75,1
step << !Mage
#completewith StealfromThievesPickup
.goto Undercity,66.09,20.06,20,0
.goto Undercity,64.37,23.94,20,0
.goto Undercity,65.93,26.71,10,0
.goto Undercity,65.89,34.03,10,0
.goto Undercity,64.22,39.77,10,0
.goto Undercity,65.53,43.62,15 >> Take the lift down to the Undercity
step << Hunter
.goto Undercity,57.31,32.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archibald|r
.train 5011 >> Train Crossbows
.train 202 >> Train Two-Handed Swords
.target Archibald
step << Hunter
#ah
.goto Undercity,58.82,32.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Benijah|r|cRXP_BUY_. Buy a|r |T134402:0|t[Heavy Quiver] |cRXP_BUY_and a|r |T135532:0|t[Heavy Crossbow] |cRXP_BUY_from him and fill your quiver with arrows|r
>>|cRXP_WARN_Alternatively buy a better weapon from the Auction House|r
.collect 15809,1,552,1 
.collect 7371,1,552,1 
.collect 3030,2600,552,1 << Hunter 
.money <1.6691
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.0
.target Benijah Fenner
step << Hunter
#ssf
.goto Undercity,58.82,32.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Benijah|r|cRXP_BUY_. Buy a|r |T134402:0|t[Heavy Quiver] |cRXP_BUY_and a|r |T135532:0|t[Heavy Crossbow] |cRXP_BUY_from him and fill your quiver with arrows|r
.collect 15809,1,552,1 
.collect 7371,1,552,1 
.collect 3030,2600,552,1 << Hunter 
.money <1.6691
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.0
.target Benijah Fenner
step << Hunter
.goto Undercity,58.82,32.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Benijah|r|cRXP_BUY_. Buy a|r |T134402:0|t[Heavy Quiver] |cRXP_BUY_from him and fill your quiver with arrows|r
.collect 7371,1,552,1 
.target Benijah Fenner
step << Rogue
#ah
.goto Undercity,58.65,33.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135275:0|t[Broadsword] |cRXP_BUY_from him|r
>>|cRXP_WARN_Alternatively buy a better weapon from the Auction House|r
.collect 2520,1,552,1 
.money <2.2165
.target Geoffrey Hartwell
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.6
step << Rogue
#ssf
.goto Undercity,58.65,33.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135275:0|t[Broadsword] |cRXP_BUY_from him|r
.collect 2520,1,552,1 
.money <2.2165
.target Geoffrey Hartwell
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.6
step << Rogue
#optional
#completewith StealfromThievesPickup
+|cRXP_WARN_Equip the|r |T135275:0|t[Broadsword]
.use 2520
.itemcount 2520,1
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.6
step << Rogue
#ah
.goto Undercity,58.65,33.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135651:0|t[Main Gauche] |cRXP_BUY_from him for your off-hand|r
>>|cRXP_WARN_Alternatively buy a better weapon from the Auction House|r
.collect 2526,1,552,1 
.money <1.7402
.target Geoffrey Hartwell
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.5
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.5
step << Rogue
#ssf
.goto Undercity,58.65,33.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135651:0|t[Main Gauche] |cRXP_BUY_from him for your off-hand|r
.collect 2526,1,552,1 
.money <1.7402
.target Geoffrey Hartwell
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.5
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.5
step << Rogue
#optional
#completewith StealfromThievesPickup
+|cRXP_WARN_Equip the|r |T135651:0|t[Main Gauche]
.use 2526
.itemcount 2526,1
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.5
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.5
step
#completewith next
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Faranell|r
.isQuestComplete 1109
.dungeon RFK
step
.goto Undercity,48.80,69.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faranell|r
.turnin 1109 >> Turn in Going, Going, Guano!
.target Master Apothecary Faranell
.isQuestComplete 1109
.dungeon RFK
step
#completewith next
.goto Undercity,51.92,64.68,15 >>Travel toward |cRXP_FRIENDLY_Varimathras|r
.isOnQuest 6522
.dungeon RFK
step
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.turnin 6522 >>Turn in An Unholy Alliance
.target Varimathras
.isOnQuest 6522
.dungeon RFK
step << skip
.goto Undercity,65.99,44.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_William|r
.bankwithdraw 3692 >> Withdraw the |T133730:0|t[|cRXP_LOOT_Hillsbrad Human Skulls|r] from your bank if you have them

.target William Montague
step
#label StealfromThievesPickup
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Genavie |r
.accept 1164 >> Accept To Steal From Thieves
.target Genavie Callow
step
#ah
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
>>|cRXP_BUY_Buy|r |T134026:0|t[Turtle Meat] |cRXP_BUY_from the Auction House|r
.collect 3712,10,7321,1 
.target Auctioneer Rhyker
step
#ah
.goto Undercity,62.14,44.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Eunice|r
.train 2550 >> Train cooking for a quest later
.target Eunice Burch
.itemcount 3712,10 
.isQuestAvailable 7321
step << Druid
#completewith next
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
.fly The Sepulcher >> Fly to The Sepulcher
.target Michael Garrett
.zoneskip Hillsbrad Foothills
.isOnQuest 30
step << Druid
#completewith next
.goto Silverpine Forest,36.12,28.30,120 >> Travel North/East toward the Great Sea
.isOnQuest 30
step << Druid
.goto Silverpine Forest,29.58,29.30
>>Loot the |cRXP_PICK_Strange Lockbox|r in the water for the |T133442:0|t[Half Pendant of Aquatic Endurance]

.collect 15882,1,30,1 

.isOnQuest 30
step << Druid
#completewith next
.goto Silverpine Forest,45.62,42.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karos|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Karos Razok
.zoneskip Silverpine Forest,1
step << !Shaman
#completewith AgonyPickup
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Michael Garrett
.zoneskip Hillsbrad Foothills
step << Shaman
#completewith next
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
.fly The Sepulcher >> Fly to The Sepulcher
.target Michael Garrett
.zoneskip Silverpine Forest
step << Shaman
.zone Silverpine Forest >> Travel to Silverpine Forest
>>|cRXP_WARN_Follow the link below to open the website unstuck page. Select your current character on the website, but do NOT click anything else yet|r
>>|cRXP_WARN_If this fails, skip this step and run back normally|r
.link https://us.battle.net/support/en/help/product/wow/197/834/solution >> |cRXP_WARN_CLICK HERE|r
.isOnQuest 63
step << Shaman
#completewith CallofWaterSVP
#label CallofWaterSVP1
.goto Silverpine Forest,42.05,40.62,10,0
.goto Silverpine Forest,41.83,41.16,8 >> Jump up the side of the tree
.isOnQuest 63
step << Shaman
#completewith CallofWaterSVP
#label CallofWaterSVP2
#requires CallofWaterSVP1
.goto Silverpine Forest,38.09,44.40,15 >>Run down the mountain
.isOnQuest 63
step << Shaman
#completewith next
#requires CallofWaterSVP2
.goto Silverpine Forest,38.09,44.40
.aura 8899 >>|cRXP_WARN_Drink the|r |T134754:0|t[Water Sapta] |cRXP_WARN_to see the|r |cRXP_ENEMY_Corrupt Minor Manifestion of Water|r
.use 6637
.isOnQuest 63
step << Shaman
.goto Silverpine Forest,38.50,44.46
>>Kill the |cRXP_ENEMY_Corrupt Minor Manifestion of Water|r. Loot it for the |cRXP_LOOT_Corrupt Manifestation's Bracers|r
.complete 63,1 
.mob Corrupt Minor Manifestation of Water
.isOnQuest 63
step << Shaman
#label CallofWaterSVP
.goto Silverpine Forest,38.26,44.56
>>Click the |cRXP_PICK_Brazier of Everfount|r
.turnin 63 >>Turn in Call of Water
.accept 100 >>Accept Call of Water
.timer 15,Call of Water RP
step << Shaman
.goto Silverpine Forest,38.75,44.63
>>|cRXP_WARN_Wait out the RP|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Minor Manifestation of Water|r
.turnin 100 >>Turn in Call of Water
.accept 96 >>Accept Call of Water
.target Minor Manifestation of Water
step << Shaman
#completewith next
.goto Silverpine Forest,45.62,42.59,100 >> |cRXP_WARN_If you opened the website unstuck page earlier, you can now log out ingame and then click to move your character to the nearest graveyard (The Sepulcher)|r
>>|cRXP_WARN_If this fails or the page won't load, skip this step|r
.link https://us.battle.net/support/en/help/product/wow/197/834/solution >> |cRXP_WARN_CLICK HERE|r
.zoneskip Silverpine Forest,1
step << Shaman
#completewith next
.goto Silverpine Forest,45.62,42.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karos|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Karos Razok
.zoneskip Hillsbrad Foothills
step
#optional
.abandon 1144,1102,1109



.dungeon RFK
step
#label AgonyPickup
.goto Hillsbrad Foothills,61.44,19.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydon|r
.accept 509 >> Accept Elixir of Agony
.target Apothecary Lydon
step
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darthalia|r
.accept 529 >> Accept Battle of Hillsbrad
.target High Executor Darthalia
.isQuestTurnedIn 528
step
.goto Hillsbrad Foothills,62.76,20.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Humbert|r
.accept 547 >> Accept Humbert's Sword
.target Deathguard Humbert
step
.goto Hillsbrad Foothills,63.24,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.accept 533 >> Accept Infiltration
.target Krusk
.isQuestTurnedIn 498
step
.goto Hillsbrad Foothills,63.88,19.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thaivand|r
.accept 552 >> Accept Helcular's Revenge
.target Novice Thaivand
step
#ah
.goto Hillsbrad Foothills,62.3,19.1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Christoph Jeffcoat|r
>>|cRXP_BUY_Buy|r [Soothing Spices] |cRXP_BUY_from him|r
.collect 3713,1,7321,1 
.itemcount 3712,10 
.target Christoph Jeffcoat
step
#ah
.goto Hillsbrad Foothills,62.28,19.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Christoph|r inside the inn
.accept 7321 >> Accept Soothing Turtle Bisque
.turnin 7321 >> Turn in Soothing Turtle Bisque
.target Christoph Jeffcoat
.itemcount 3712,10 
step
.goto Hillsbrad Foothills,61.86,19.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tallow|r
.accept 676 >> Accept The Hammer May Fall
.target Tallow
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bel'varil|r and |cRXP_FRIENDLY_Wordeen|r
.accept 556 >> Accept Stone Tokens
.target +Keeper Bel'varil
.goto Hillsbrad Foothills,61.60,20.86
.accept 544 >> Accept Prison Break In
.target +Magus Wordeen Voidglare
.goto Hillsbrad Foothills,61.49,20.93
step
#completewith HillsbradBlacksmith
.subzone 286 >> Travel to the Hillsbrad Fields
.isQuestTurnedIn 528
step
#completewith next
>>Kill |cRXP_ENEMY_Blacksmith Verringtan|r and |cRXP_ENEMY_Hillsbrad Apprentice Blacksmiths|r
.complete 529,1 
.unitscan +Blacksmith Verringtan
.complete 529,2 
.mob +Hillsbrad Apprentice Blacksmith
.isQuestTurnedIn 528
step
.goto Hillsbrad Foothills,32.02,45.45
>>Loot the |cRXP_PICK_Shipment of Iron|r for the |T132761:0|t[|cRXP_LOOT_Shipment of Iron|r]
.complete 529,3 
.isQuestTurnedIn 528
step
#label HillsbradBlacksmith
.goto Hillsbrad Foothills,32.65,45.48,20,0
.goto Hillsbrad Foothills,31.87,46.66,20,0
.goto Hillsbrad Foothills,32.23,45.32
>>Kill |cRXP_ENEMY_Blacksmith Verringtan|r and |cRXP_ENEMY_Hillsbrad Apprentice Blacksmiths|r
.complete 529,1 
.unitscan +Blacksmith Verringtan
.complete 529,2 
.mob +Hillsbrad Apprentice Blacksmith
.isQuestTurnedIn 528
step
#completewith next
.goto Hillsbrad Foothills,62.37,20.32
.subzone 272 >> Return to Tarren Mill
step
.goto Hillsbrad Foothills,62.31,20.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darthalia|r
.turnin 529 >> Turn in Battle of Hillsbrad
.accept 532 >> Accept Battle of Hillsbrad
.target High Executor Darthalia
.isQuestTurnedIn 528
step
#loop
.goto Hillsbrad Foothills,47.90,31.50,0
.goto Hillsbrad Foothills,47.90,31.50,25,0
.goto Hillsbrad Foothills,46.10,33.20,25,0
.goto Hillsbrad Foothills,43.50,27.30,25,0
.goto Hillsbrad Foothills,43.90,30.20,25,0
.goto Hillsbrad Foothills,41.80,30.60,25,0
.goto Hillsbrad Foothills,43.60,24.90,25,0
>>Kill |cRXP_ENEMY_Yetis|r in and around the cave at Darrow Hill. Loot them for |cRXP_LOOT_Helcular's Rod|r
>>|T135471:0|t[Helcular's Rod] |cRXP_WARN_has a fairly low drop rate|r
.complete 552,1 
.mob Cave Yeti
.mob Ferocious Yeti
step
#loop
.goto Hillsbrad Foothills,47.90,31.50,0
.goto Hillsbrad Foothills,46.10,33.20,25,0
.goto Hillsbrad Foothills,43.50,27.30,25,0
.goto Hillsbrad Foothills,43.90,30.20,25,0
.goto Hillsbrad Foothills,41.80,30.60,25,0
.goto Hillsbrad Foothills,43.60,24.90,25,0
.goto Hillsbrad Foothills,47.90,31.50,25,0
>>Kill |cRXP_ENEMY_Yetis|r in and around the cave at Darrow Hill. Loot them for |cRXP_LOOT_Helcular's Rod|r
>>|T135471:0|t[Helcular's Rod] |cRXP_WARN_has a fairly low drop rate|r
.complete 552,1 
.mob Cave Yeti
.mob Ferocious Yeti
step
#completewith WhitesteedBurnside
.subzone 286 >> Travel to the Hillsbrad Fields
step
#completewith next
#label Council
.goto Hillsbrad Foothills,29.63,42.33
>>Kill |cRXP_ENEMY_Hillsbrad Councilmen|r
>>|cRXP_WARN_Be careful of their Frost Nova and Frostbolt|r
.complete 532,2 
.mob Hillsbrad Councilman
.isQuestTurnedIn 529
step
#label WhitesteedBurnside
>>Kill |cRXP_ENEMY_Magistrate Burnside|r and |cRXP_ENEMY_Clerk Horrace Whitesteed|r inside Hillsbrad Town Hall
>>Loot the |cRXP_LOOT_Hillsbrad Town Registry|r and burn the |cRXP_PICK_Hillsbrad Proclamation|r
.complete 532,1 
.mob +Magistrate Burnside
.complete 567,1 
.mob +Clerk Horrace Whitesteed
.goto Hillsbrad Foothills,29.67,41.64
.complete 532,4 
.goto Hillsbrad Foothills,29.52,41.53
.complete 532,3 
.goto Hillsbrad Foothills,29.73,41.75
.isQuestTurnedIn 529
step
.goto Hillsbrad Foothills,29.63,42.33
>>Finish killing |cRXP_ENEMY_Hillsbrad Councilmen|r
>>|cRXP_WARN_Be careful of their Frost Nova and Frostbolt|r
.complete 532,2 
.mob Hillsbrad Councilman
.isQuestTurnedIn 529
step
#completewith next
.goto Hillsbrad Foothills,62.37,20.32
.subzone 272 >> Return to Tarren Mill
step
#requires Council
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darthalia|r
.turnin 532 >> Turn in Battle of Hillsbrad
.accept 539 >> Accept Battle of Hillsbrad
.target High Executor Darthalia
.isQuestTurnedIn 529
step
.goto Hillsbrad Foothills,63.88,19.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Novice Thaivand|r
.turnin 552 >> Turn in Helcular's Revenge
.target Novice Thaivand
step << Hunter
#completewith next
.goto Hillsbrad Foothills,62.55,19.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kayren|r
.vendor >> |cRXP_BUY_Fill your quiver with arrows|r
.target Kayren Soothallow
step
.goto Hillsbrad Foothills,62.76,19.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shay|r
>>|cRXP_BUY_Buy a|r |T132795:0|t[Southshore Stout] |cRXP_BUY_from him|r
.collect 3703,1,533,1 
.target Innkeeper Shay
.isQuestTurnedIn 498
step
#completewith next
.goto Hillsbrad Foothills,50.45,49.21,0
>>|cRXP_WARN_Be careful! Do not get too close to Southshoure (south) as |cRXP_ENEMY_Soutshore Guards|r could kill you|r
>>|cRXP_ENEMY_Soutshore Guards|r |cRXP_WARN_have a huge aggro range|r
step
.goto Hillsbrad Foothills,26.95,59.55,100 >>Run to the Azurelode Mine
.subzoneskip 288
.isOnQuest 546
step
#completewith Hacket
>>Kill |cRXP_ENEMY_Hillsbrad|r mobs. Loot them for their |cRXP_LOOT_Skulls|r
.complete 546,1 
.isOnQuest 546
step
#completewith next
.goto Hillsbrad Foothills,31.8,52.5,60,0
.goto Hillsbrad Foothills,29.7,55.7,60,0
.goto Hillsbrad Foothills,31.1,58.6,60,0
>>Kill |cRXP_ENEMY_Miner Hackett|r
>>|cRXP_WARN_He has 3 different spawn locations in the mine|r
.complete 567,3 
.unitscan Miner Hackett
.isQuestTurnedIn 528
step
.goto Hillsbrad Foothills,31.21,56.01
>>Kill |cRXP_ENEMY_Foreman Bonds|r and |cRXP_ENEMY_Hillsbrad Miners|r
>>|cRXP_ENEMY_Foreman Bonds|r |cRXP_WARN_is located in the center of the mine's lowest floor|r
>>|cRXP_WARN_Be careful! At 30% health he will summon 2|r |cRXP_ENEMY_Dun Garok Soldiers|r
.complete 539,1 
.mob +Foreman Bonds
.complete 539,2 
.isQuestTurnedIn 528
step
#label Hacket
.goto Hillsbrad Foothills,31.8,52.5,0
.goto Hillsbrad Foothills,29.7,55.7,0
.goto Hillsbrad Foothills,31.1,58.6,0
.goto Hillsbrad Foothills,31.8,52.5,60,0
.goto Hillsbrad Foothills,29.7,55.7,60,0
.goto Hillsbrad Foothills,31.1,58.6,60,0
.goto Hillsbrad Foothills,31.8,52.5
>>Kill |cRXP_ENEMY_Miner Hackett|r
>>|cRXP_WARN_He has 3 different spawn locations in the mine|r
.complete 567,3 
.unitscan Miner Hackett
.isQuestTurnedIn 528
step
#loop
.goto Hillsbrad Foothills,31.15,54.73,0
.goto Hillsbrad Foothills,29.69,58.03,15,0
.goto Hillsbrad Foothills,28.17,57.27,15,0
.goto Hillsbrad Foothills,26.48,58.74,15,0
.goto Hillsbrad Foothills,27.39,59.38,15,0
.goto Hillsbrad Foothills,27.48,57.60,15,0
.goto Hillsbrad Foothills,28.06,55.12,15,0
.goto Hillsbrad Foothills,28.33,53.10,15,0
.goto Hillsbrad Foothills,31.15,54.73,15,0
>>Finish killing |cRXP_ENEMY_Hillsbrad|r mobs. Loot them for their |cRXP_LOOT_Skulls|r
.complete 546,1 
.isQuestTurnedIn 528
step
#loop
.goto Hillsbrad Foothills,31.15,54.73,0
.goto Hillsbrad Foothills,29.69,58.03,15,0
.goto Hillsbrad Foothills,28.17,57.27,15,0
.goto Hillsbrad Foothills,26.48,58.74,15,0
.goto Hillsbrad Foothills,27.39,59.38,15,0
.goto Hillsbrad Foothills,27.48,57.60,15,0
.goto Hillsbrad Foothills,28.06,55.12,15,0
.goto Hillsbrad Foothills,28.33,53.10,15,0
.goto Hillsbrad Foothills,31.15,54.73,15,0
.xp 32 >> Grind to 32 in Azurelode Mine. Return to Tarren Mill if you need to restock
step
#completewith next
.goto Alterac Mountains,57.17,69.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Henchman Valik|r
>>|cRXP_WARN_Trade the|r |T132795:0|t[Southshore Stout] |cRXP_WARN_for the|r |cRXP_LOOT_Syndicate Missive|r
>>|cRXP_WARN_He may be hostile. If so, kill him and wait for his respawn. Alternatively kill|r |cRXP_ENEMY_Syndicate|r |cRXP_WARN_to obtain the|r |cRXP_LOOT_Syndicate Missive|r
.complete 533,1 
.target Henchman Valik
.itemcount 3703,1 
.isQuestTurnedIn 498
step
#loop
.goto Alterac Mountains,48.86,82.87,0
.goto Alterac Mountains,46.51,81.74,50,0
.goto Alterac Mountains,48.86,82.87,50,0
.goto Alterac Mountains,48.78,80.96,50,0
.goto Alterac Mountains,56.38,66.23,50,0
.goto Alterac Mountains,57.85,69.74,50,0
.goto Alterac Mountains,59.14,69.36,50,0
.goto Alterac Mountains,59.53,66.50,50,0
.goto Alterac Mountains,58.30,66.67,50,0
>>Kill |cRXP_ENEMY_Syndicate Thieves|r and |cRXP_ENEMY_Syndicate Footpads|r. Loot them for a |cRXP_LOOT_Syndicate Missive|r
.complete 533,1 
.mob Syndicate Footpad
.mob Syndicate Thief
.isQuestTurnedIn 498
step
#completewith next
.subzone 272 >>Travel to Tarren Mill
step
.goto Hillsbrad Foothills,62.11,19.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Samsa|r
.turnin 546 >> Turn in Souvenirs of Death
.target Deathguard Samsa
step
.goto Hillsbrad Foothills,62.31,20.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darthalia|r
.turnin 567 >> Turn in Dangerous!
.turnin 539 >> Turn in Battle of Hillsbrad
.accept 541 >> Accept Battle of Hillsbrad
.target High Executor Darthalia
.group
step
.goto Hillsbrad Foothills,62.31,20.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darthalia|r
.turnin 567 >> Turn in Dangerous!
.turnin 539 >> Turn in Battle of Hillsbrad
.target High Executor Darthalia
step
#optional
.abandon 567 >>Abandon Dangerous!
step
.goto Hillsbrad Foothills,63.24,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.turnin 533 >> Turn in Infiltration
.target Krusk
.isQuestComplete 533
step
#completewith EnterArathi
.destroy 3703 >>|cRXP_WARN_Destroy the|r |T132795:0|t[Southshore Stout] |cRXP_WARN_as you no longer need it|r
step << Hunter
.goto Hillsbrad Foothills,62.56,19.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Kayren|r
>>|cRXP_BUY_Buy|r |T132382:0|t[Razor Arrows] |cRXP_BUY_from him|r
.collect 3030,1800,541,1 << Hunter 
.target Kayren Soothallow
.itemcount 3030,<1200
.subzoneskip 272,1
step
.goto Hillsbrad Foothills,62.79,19.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shay|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Shay
.isQuestAvailable 541
.subzoneskip 272,1
step
#loop
.goto Hillsbrad Foothills,64.68,62.01,0
.goto Hillsbrad Foothills,64.67,60.01,20,0
.goto Hillsbrad Foothills,63.02,61.19,20,0
.goto Hillsbrad Foothills,63.45,62.50,20,0
.goto Hillsbrad Foothills,64.68,62.01,20,0
>>Loot the |cRXP_PICK_White Mushrooms|r around Nethander Stead for |cRXP_LOOT_Mudsnout Blossoms|r
.complete 509,1 
step
#completewith DunGarok
.goto Hillsbrad Foothills,70.76,78.14,150 >> Travel to Dun Garok
.subzoneskip 2371
step
#loop
.goto Hillsbrad Foothills,71.60,80.0,0
.goto Hillsbrad Foothills,71.26,75.17,25,0
.goto Hillsbrad Foothills,69.11,75.18,25,0
.goto Hillsbrad Foothills,68.59,78.47,25,0
.goto Hillsbrad Foothills,69.66,78.68,25,0
.goto Hillsbrad Foothills,71.01,79.09,25,0
.goto Hillsbrad Foothills,70.57,79.70,25,0
.goto Hillsbrad Foothills,71.48,81.57,25,0
.goto Hillsbrad Foothills,71.72,80.64,25,0
.goto Hillsbrad Foothills,71.98,81.24,25,0
.goto Hillsbrad Foothills,72.57,80.52,25,0
.goto Hillsbrad Foothills,72.20,80.00,25,0
.goto Hillsbrad Foothills,72.87,79.79,25,0
.goto Hillsbrad Foothills,72.40,79.28,25,0
.goto Hillsbrad Foothills,71.84,78.26,25,0
.goto Hillsbrad Foothills,71.32,78.69,25,0
.goto Hillsbrad Foothills,71.26,75.17,25,0
>>Kill |cRXP_ENEMY_Dun Garok Soldiers|r and |cRXP_ENEMY_Captain Ironhill|r. Loot them for |cRXP_LOOT_Humbert's Sword|r
>>|cRXP_WARN_Be careful on your way in and out of Dun Garok; there are multiple patrols on the road and in the stronghold|r
.complete 541,1 
.mob +Dun Garok Mountaineer
.complete 541,2 
.mob +Dun Garok Rifleman
.complete 541,3 
.mob +Dun Garok Priest
.complete 541,4 
.unitscan +Captain Ironhill
.complete 547,1 
.mob +Dun Garok Mountaineer
.mob +Dun Garok Rifleman
.mob +Dun Garok Priest
.group 2
step
#label DunGarok
#loop
.goto Hillsbrad Foothills,71.60,80.0,0
.goto Hillsbrad Foothills,71.26,75.17,25,0
.goto Hillsbrad Foothills,69.11,75.18,25,0
.goto Hillsbrad Foothills,68.59,78.47,25,0
.goto Hillsbrad Foothills,69.66,78.68,25,0
.goto Hillsbrad Foothills,71.01,79.09,25,0
.goto Hillsbrad Foothills,70.57,79.70,25,0
.goto Hillsbrad Foothills,71.48,81.57,25,0
.goto Hillsbrad Foothills,71.72,80.64,25,0
.goto Hillsbrad Foothills,71.98,81.24,25,0
.goto Hillsbrad Foothills,72.57,80.52,25,0
.goto Hillsbrad Foothills,72.20,80.00,25,0
.goto Hillsbrad Foothills,72.87,79.79,25,0
.goto Hillsbrad Foothills,72.40,79.28,25,0
.goto Hillsbrad Foothills,71.84,78.26,25,0
.goto Hillsbrad Foothills,71.32,78.69,25,0
.goto Hillsbrad Foothills,71.26,75.17,25,0
>>Kill |cRXP_ENEMY_Dun Garok Dwarves|r. Loot them for |cRXP_LOOT_Humbert's Sword|r
>>|cRXP_WARN_Be careful on your way in and out of Dun Garok; there are multiple patrols on the road and in the stronghold|r
.complete 547,1 
.mob Dun Garok Mountaineer
.mob Dun Garok Rifleman
.mob Dun Garok Priest
step
#label EnterArathi
.goto Arathi Highlands,20.19,29.54
.zone Arathi Highlands >> Travel to Arathi Highlands
.zoneskip Arathi Highlands
step
#loop
.goto Arathi Highlands,35.51,44.26,0
.goto Arathi Highlands,31.91,41.15,50,0
.goto Arathi Highlands,35.53,40.93,50,0
.goto Arathi Highlands,35.51,44.26,50,0
.goto Arathi Highlands,34.40,44.25,12,0
.goto Arathi Highlands,31.08,43.68,12,0
.goto Arathi Highlands,34.40,44.25,12,0
.goto Arathi Highlands,35.51,44.26,50,0
>>Kill |cRXP_ENEMY_Boulderfist Ogres|r and |cRXP_ENEMY_Boulderfist Enforcers|r in and around Boulder'gor
>>|cRXP_WARN_Be careful. They can buff themselves with|r |T132154:0|t[Fist of Stone] |cRXP_WARN_(+100 damage each hit and 75% reduced movement speed)|r
.complete 676,1 
.mob +Boulderfist Ogre
.complete 676,2 
.mob +Boulderfist Enforcer
step
.goto Arathi Highlands,62.50,33.80
>>Click the |cRXP_PICK_Shards of Myzrael|r
.accept 642 >> Accept The Princess Trapped
step
#completewith next
.goto Arathi Highlands,73.52,33.20,150 >> Travel to Hammerfall
.subzoneskip 321
step
.goto Arathi Highlands,73.10,32.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urda|r
.fp Hammerfall >> Get the Hammerfall flight path
.target Urda
.isQuestAvailable 672,671
step
.goto Arathi Highlands,74.20,33.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drum Fel|r
.turnin 676 >> Turn in The Hammer May Fall
.accept 677 >> Accept Call to Arms
.target Drum Fel
step
.goto Arathi Highlands,73.84,32.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Adegwa|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Adegwa
.isQuestAvailable 672,671
step
.goto Arathi Highlands,72.64,33.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gor'mul|r
.accept 655 >> Accept Hammerfall
.target Gor'mul
step
.goto Arathi Highlands,74.60,36.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 655 >> Turn in Hammerfall
.accept 672 >> Accept Raising Spirits
.accept 671 >> Accept Foul Magics
.target Tor'gan
step << Hunter
#completewith next
.goto Arathi Highlands,73.92,33.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharlidun|r
.stable >> Stable your pet. You will tame a |cRXP_ENEMY_Plains Creeper|r shortly
.target Tharlidun
step << Hunter
#loop
.goto Arathi Highlands,69.28,37.53,0
.goto Arathi Highlands,62.09,38.95,0
.goto Arathi Highlands,68.55,51.64,0
.goto Arathi Highlands,69.28,37.53,40,0
.goto Arathi Highlands,62.09,38.95,40,0
.goto Arathi Highlands,68.55,51.64,40,0
>>|cRXP_WARN_Cast|r |T132172:0|t[Eagle Eye] |cRXP_WARN_to try and find a |cRXP_ENEMY_Plains Creeper|r. Some of their locations are marked on your map|r
>>|cRXP_WARN_Cast|r |T132164:0|t[Tame Beast] |cRXP_WARN_on a |cRXP_ENEMY_Plains Creeper|r to tame it|r 
.train 17265 >>|cRXP_WARN_Attack mobs with it to learn|r |T132278:0|t[Bite (Rank 5)]
.link https://www.wow-petopia.com/classic/training.php >> |cRXP_WARN_Click here for more info about pet training|r
.unitscan Plains Creeper
.zoneskip Arathi Highlands,1
step << Hunter
.goto Arathi Highlands,73.92,33.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharlidun|r
.stable >> Abandon the |cRXP_ENEMY_Plains Creeper|r and retrieve your regular pet
.target Tharlidun
.train 17265,3
.zoneskip Arathi Highlands,1
step
#completewith WitherbarkArrive
.goto Arathi Highlands,45.78,43.61,0
+|cRXP_WARN_Be careful of getting too close to Refuge Point (Alliance base) in the centre of the zone.|r |cRXP_ENEMY_Refuge Point Defenders|r |cRXP_WARN_can kill you|r
.unitscan Refuge Point Defender
step
#completewith xpgate
>>Kill any |cRXP_ENEMY_Highland Raptor|r that you encounter. Loot them for their |cRXP_LOOT_Eyes|r
>>|cRXP_WARN_Be careful of the|r |cRXP_ENEMY_Highland Trashers|r, |cRXP_WARN_as they actually|r |T132152:0|t[Thrash]
.complete 672,1 
.mob Highland Strider
.mob Highland Thrasher
step
#loop
.goto Arathi Highlands,34.07,28.35,0
.goto Arathi Highlands,34.07,28.35,50,0
.goto Arathi Highlands,33.36,26.41,50,0
.goto Arathi Highlands,31.79,26.47,50,0
.goto Arathi Highlands,30.83,27.49,50,0
.goto Arathi Highlands,31.01,29.58,50,0
.goto Arathi Highlands,32.32,30.87,50,0
.goto Arathi Highlands,33.36,30.72,50,0
>>Kill |cRXP_ENEMY_Syndicate members|r. Loot them for their |cRXP_LOOT_Amulets|r
>>|cRXP_WARN_Be careful of |cRXP_ENEMY_Syndicate Highwaymen|r; they stealth around the farm's perimeter, and will backstab you if you kite/run away|r
.complete 671,1 
.mob Syndicate Pathstalker
.mob Syndicate Mercenary
.mob Syndicate Highwayman
step
#label xpgate
#loop
.goto Arathi Highlands,34.07,28.35,50,0
.goto Arathi Highlands,33.36,26.41,50,0
.goto Arathi Highlands,31.79,26.47,50,0
.goto Arathi Highlands,30.83,27.49,50,0
.goto Arathi Highlands,31.01,29.58,50,0
.goto Arathi Highlands,32.32,30.87,50,0
.goto Arathi Highlands,33.36,30.72,50,0
.xp 33>> Grind to level 33
step
#completewith StealFromThieves
>>Kill |cRXP_ENEMY_Highland Raptors|r. Loot them for their |cRXP_LOOT_Eyes|r
>>|cRXP_WARN_Be careful of the|r |cRXP_ENEMY_Highland Trashers|r, |cRXP_WARN_as they actually|r |T132152:0|t[Thrash]
.complete 672,1 
.mob Highland Strider
.mob Highland Thrasher
step
.goto Arathi Highlands,54.20,38.20
>>Kill |cRXP_ENEMY_Marcel|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_He uses|r |T132362:0|t[Shield Wall] |cRXP_WARN_(-75% damage for 10s) and|r |T132357:0|t[Shield Bash] |cRXP_WARN_(interrupt)|r
.complete 1164,2 
.unitscan Marcel Dabyrie
step
.goto Arathi Highlands,56.40,36.10
>>Kill |cRXP_ENEMY_Kenata|r. Loot her for her |cRXP_LOOT_Head|r
>>|cRXP_WARN_This can be quite hard. Be very careful|r << Rogue/Warrior/Shaman
.complete 1164,1 
.unitscan Kenata Dabyrie
step
#label StealFromThieves
.goto Arathi Highlands,56.50,38.70
>>Kill |cRXP_ENEMY_Fardel|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Be careful of his high-damage poison and|r |T132152:0|t[Thrash]
.complete 1164,3 
.unitscan Fardel Dabyrie
step
.goto Arathi Highlands,59.40,42.61
>>Finish killing |cRXP_ENEMY_Highland Raptors|r. Loot them for their |cRXP_LOOT_Eyes|r
>>|cRXP_WARN_Be careful of the|r |cRXP_ENEMY_Highland Trashers|r, |cRXP_WARN_as they actually|r |T132152:0|t[Thrash]
.complete 672,1 
.mob Highland Strider
.mob Highland Thrasher
step
#label WitherbarkArrive
#completewith WitherbarkTrolls
.goto Arathi Highlands,66.68,62.96,150 >> Travel to Witherbark Village
step
#completewith WitherbarkTrolls
+|cRXP_WARN_Keep an eye out for|r |cRXP_ENEMY_Nimar the Slayer|r |cRXP_WARN_(rare). He can drop powerful BoEs|r
.unitscan Nimar the Slayer
step
#label WitherbarkTrolls
#loop
.goto Arathi Highlands,71.70,60.30,0
.goto Arathi Highlands,71.70,60.30,50,0
.goto Arathi Highlands,73.40,65.20,50,0
.goto Arathi Highlands,70.60,69.30,50,0
.goto Arathi Highlands,68.30,74.50,50,0
.goto Arathi Highlands,66.20,69.20,50,0
.goto Arathi Highlands,64.80,73.10,50,0
.goto Arathi Highlands,61.30,72.40,50,0
.goto Arathi Highlands,63.30,67.70,50,0
.goto Arathi Highlands,66.50,63.70,50,0
>>Kill |cRXP_ENEMY_Witherbark Witch Doctors|r, |cRXP_ENEMY_Headhunters|r, and |cRXP_ENEMY_Axe Throwers|r
>>|cRXP_WARN_This next quest can be quite hard, be extra careful|r
.complete 677,3 
.mob +Witherbark Witch Doctor
.complete 677,2 
.mob +Witherbark Headhunter
.complete 677,1 
.mob +Witherbark Axe Thrower
step
.goto Arathi Highlands,74.72,36.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Tor'gan|r
.turnin 671 >> Turn in Foul Magics
.turnin 672 >> Turn in Raising Spirits
.accept 674 >> Accept Raising Spirits
.target Tor'gan
step
#label RaisingSpirits
.goto Arathi Highlands,72.64,33.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Gor'mul|r
.turnin 674 >> Turn in Raising Spirits
.accept 675 >> Accept Raising Spirits
.target Gor'mul
step
.goto Arathi Highlands,74.72,36.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 675 >> Turn in Raising Spirits
.target Tor'gan
step
.goto Arathi Highlands,74.24,33.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Drum|r
.turnin 677 >> Turn in Call to Arms
.target Drum Fel
step
#label FlyTM
#completewith next
.goto Arathi Highlands,73.10,32.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urda|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Urda
.zoneskip Hillsbrad Foothills
step
.goto Hillsbrad Foothills,61.44,19.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydon|r
.turnin 509 >> Turn in Elixir of Agony
.accept 513 >> Accept Elixir of Agony
.target Apothecary Lydon
step
.goto Hillsbrad Foothills,62.76,20.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Humbert|r
.turnin 547 >> Turn in Humbert's Sword
.target Deathguard Humbert
.isQuestComplete 547
step
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darthalia|r
.turnin 541 >> Turn in Battle of Hillsbrad
.accept 550 >> Accept Battle of Hillsbrad
.target High Executor Darthalia
.isQuestComplete 541
.group
step
#optional
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Darthalia|r
.accept 550 >> Accept Battle of Hillsbrad
.target High Executor Darthalia
.isQuestTurnedIn 541
.group
step
#completewith Belamoore
.goto Alterac Mountains,39.90,80.93,0
+|cRXP_WARN_Be careful of the |cRXP_ENEMY_Alliance Guards|r at the Alterac Valley cave as you travel north! They have a large aggro pull and will kill you in 2 hits|r
>>|cRXP_WARN_Check the map to see their location|r
.unitscan Southshore Guard
step
#completewith Belamoore
+|cRXP_WARN_This next quest can be quite hard, be extra careful!|r
step
#completewith Belamoore
>>Kill all |cRXP_ENEMY_Dalaran Humanoids|r. Loot them for their |cRXP_LOOT_Worn Stone Tokens|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Dalaran Shield Guards'|r |cRXP_WARN_glowing|r |T136173:0|t[Violet Shield Effect] |cRXP_WARN_ buff. It lasts eight seconds and returns 85 damage upon being struck in melee|r << !Mage !Priest !Warlock
.complete 556,1 
step
>>Kill |cRXP_ENEMY_Ricter|r, |cRXP_ENEMY_Alina|r and |cRXP_ENEMY_Dermot|r. Loot them for their |cRXP_LOOT_Bloodstones|r
.complete 544,2 
.mob +Ricter
.goto Alterac Mountains,20.13,84.32
.complete 544,3 
.mob +Alina
.goto Alterac Mountains,20.34,86.29
.complete 544,1 
.mob +Dermot
.goto Alterac Mountains,19.89,85.95
step
#completewith next
.goto Alterac Mountains,18.70,84.38,10 >> Enter the western building
step
#label Belamoore
.goto Alterac Mountains,18.29,82.83,8,0
.goto Alterac Mountains,17.65,84.11,8,0
.goto Alterac Mountains,17.76,83.18
>>Kill |cRXP_ENEMY_Kegan Darkmar|r on the second floor of the building. Loot him for his |cRXP_LOOT_Bloodstone|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Warden Belamoore|r|cRXP_WARN_. Kill her prior to attacking|r |cRXP_ENEMY_Kegan Darkmar|r
.complete 544,4 
.mob Kegan Darkmar
.mob Warden Belamoore
step
#loop
.goto Alterac Mountains,20.10,86.20,0
.goto Alterac Mountains,20.10,86.20,50,0
.goto Alterac Mountains,17.90,83.00,50,0
.goto Alterac Mountains,10.70,76.60,50,0
.goto Alterac Mountains,19.40,75.60,50,0
>>Finish killing the |cRXP_ENEMY_Dalaran Humanoids|r. Loot them for their |cRXP_LOOT_Worn Stone Tokens|r
>>|cRXP_WARN_Be careful of |cRXP_ENEMY_Dalaran Shield Guards'|r |cRXP_WARN_glowing|r |T136173:0|t[Violet Shield Effect] |cRXP_WARN_ buff. It lasts eight seconds and returns 85 damage upon being struck in melee|r << !Mage !Priest !Warlock
.complete 556,1 
.mob Dalaran Shield Guard
.mob Dalaran Theurgist
.mob Dalaran Worker
.mob Dalaran Summoner
step
#optional
#completewith next
.destroy 3711 >>|cRXP_WARN_Destroy|r |T133736:0|t[Belamoore's Research Journal] |cRXP_WARN_as it's not needed for anything|r
step
#completewith next
.subzone 272 >> Travel back to Tarren Mill
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bel'varil|r and |cRXP_FRIENDLY_Wordeen|r
.turnin 556 >> Turn in Stone Tokens
.target +Keeper Bel'varil
.goto Hillsbrad Foothills,61.60,20.86
.turnin 544 >> Turn in Prison Break In
.target +Magus Wordeen Voidglare
.goto Hillsbrad Foothills,61.49,20.93
step << skip
#completewith Frostmaw2
#loop
.goto Alterac Mountains,30.69,82.31,0
.goto Alterac Mountains,29.12,77.98,60,0
.goto Alterac Mountains,30.69,82.31,60,0
.goto Alterac Mountains,30.48,87.06,60,0
.goto Alterac Mountains,35.35,82.68,60,0
.goto Alterac Mountains,42.83,82.98,60,0
.goto Alterac Mountains,41.83,76.57,60,0
>>Kill |cRXP_ENEMY_Mountain Lions|r. Loot them for a |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r]
>>The |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r] |cRXP_WARN_disappears after 30 minutes|r
.collect 5810,1,1136,1 
.mob Feral Mountain Lion
.mob Mountain Lion
.mob Starving Mountain Lion
.mob Hulking Mountain Lion
.isOnQuest 1136
step << skip
.goto Alterac Mountains,37.56,68.22
.use 5810 >> Use the |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r] inside Growless Cave to summon |cRXP_ENEMY_Frostmaw|r. Kill him and loot him for his |cRXP_LOOT_Mane|r
>>|cRXP_WARN_Frostmaw is level 37. Clear a kiting path outside the cave before summoning him!|r
>>|cRXP_WARN_Place a|r |T13809:0|t[Frost Trap] |cRXP_WARN_outside to kite him easily|r << Hunter
>>|cRXP_WARN_Use|r |T132298:0|t[Kidney Shot] |cRXP_WARN_and|r |T132155:0|t[Gouge] |cRXP_WARN_to run away from him to use|r |T135426:0|t[Thrown] |cRXP_WARN_and to restore energy. Save|r |T136205:0|t[Evasion] |cRXP_WARN_and|r |T132307:0|t[Sprint] |cRXP_WARN_for when he dodges both|r << Rogue
>>|cRXP_WARN_Use|r |T132336:0|t[Retaliation] |cRXP_WARN_if you have it up. Use|r |T132154:0|t[Intimidating Shout] |cRXP_WARN_to get a full bandage off, but make sure he has no |T132090:0|t[Bleeds] when you do so|r << Warrior
>>|cRXP_WARN_Kite him with rank 1|r |T135846:0|t[Frostbolts] |cRXP_WARN_if mana becomes an issue. Remember that he will resist spells at a high frequency|r << Mage
>>|cRXP_WARN_Use your mana mainly on|r |T136207:0|t[Shadow Word Pain] |cRXP_WARN_and healing as he is likely to resist a lot|r << Priest
>>|cRXP_WARN_Use|r |T136183:0|t[Fear] |cRXP_WARN_as much as possible but remember that he will resist spells at a high frequency|r << Warlock
>>|cRXP_WARN_Stay in|r |T132276:0|t[Bear Form] |cRXP_WARN_as much as possible, only come out to heal|r << Druid
>>|cRXP_WARN_Don't waste mana on Shock abilities, he will resist too much. Try to kite him with|r |T136102:0|t[Earthbind Totem] |cRXP_WARN_and save mana for healing|r << Shaman
.complete 1136,1 
.unitscan Frostmaw
.isOnQuest 1136
.xp <35,1
step << skip
.goto Alterac Mountains,37.56,68.22
.use 5810 >> |cRXP_WARN_Use the|r |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r] |cRXP_WARN_inside Growless Cave to summon|r |cRXP_ENEMY_Frostmaw|r
>>Kill him and loot him for his |cRXP_LOOT_Mane|r
.complete 1136,1 
.unitscan Frostmaw
.isOnQuest 1136
.xp >34,1
step
#optional
#label Frostmaw2
step << Warrior
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah|r
.turnin 1791 >>Turn in The Windwatcher
.accept 1712 >>Accept Cyclonian
.target Bath'rah the Windwatcher
step << Mage
#completewith Thieves
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
.itemcount 17031,1
step
#completewith next
.goto Hillsbrad Foothills,60.14,18.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zarise|r
.fly Undercity >> Fly to the Undercity
.target Zarise
.zoneskip Undercity
.itemcount 17031,<1 << Mage
step << Mage
#optional
.goto Undercity,85.15,10.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8407 >> Train your class spells
.target Anastasia Hartwell
.xp <32,1
.xp >34,1
step << Mage
#optional
.goto Undercity,85.15,10.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8492 >> Train your class spells
.target Anastasia Hartwell
.xp <34,1
.xp >36,1
step << Mage
.goto Undercity,85.15,10.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8427 >> Train your class spells
.target Anastasia Hartwell
.xp <36,1
step
#label Thieves
.goto Undercity,63.83,49.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Genavie Callow|r
.turnin 1164 >> Turn In To Steal From Thieves
.target Genavie Callow
step << !Druid !Warlock
#ah
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
.collect 5996,2 >>|cRXP_BUY_Buy two|r |T134797:0|t[Elixir of Water Breathing] << !Shaman
.collect 17057,2 >>|cRXP_BUY_Buy two|r |T134310:0|t[Shiny Fish Scales] << Shaman
.target Auctioneer Rhyker
.train 131,3 << Shaman 
step << Shaman
#optional
#ah
.goto Undercity,64.20,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Rhyker|r
.collect 5996,2 >>|cRXP_BUY_Buy two|r |T134797:0|t[Elixir of Water Breathing]
.target Auctioneer Rhyker
.train 131,1 << Shaman 
step << Warrior
#optional
.goto Undercity,48.32,15.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angela|r
.train 11564 >> Train your class spells
.target Angela Curthas
.xp <32,1
.xp >34,1
step << Warrior
#optional
.goto Undercity,48.32,15.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angela|r
.train 8380 >> Train your class spells
.target Angela Curthas
.xp <34,1
.xp >36,1
step << Warrior
.goto Undercity,48.32,15.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angela|r
.train 1680 >> Train your class spells
.target Angela Curthas
.xp <36,1
step << Rogue
#optional
.goto Undercity,83.86,72.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carolyn|r
.train 8623 >> Train your class spells
.target Carolyn Ward
.xp <32,1
.xp >34,1
step << Rogue
#optional
.goto Undercity,83.86,72.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carolyn|r
.train 8696 >> Train your class spells
.target Carolyn Ward
.xp <34,1
.xp >36,1
step << Rogue
.goto Undercity,83.86,72.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carolyn|r
>>|T132273:0|t[Instant Poison Rank 3] |cRXP_WARN_requires 160 skill in Poisons!|r
.train 8691 >> Train your class spells
.target Carolyn Ward
.xp <36,1
step << Warlock
#optional
.goto Undercity,88.93,15.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Richard|r
.train 6229 >> Train your class spells
.target Richard Kerwin
.xp <32,1
.xp >34,1
step << Warlock
#optional
.goto Undercity,88.93,15.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Richard|r
.train 7648 >> Train your class spells
.target Richard Kerwin
.xp <34,1
.xp >36,1
step << Warlock
.goto Undercity,88.93,15.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Richard|r
.train 7641 >> Train your class spells
.target Richard Kerwin
.xp <36,1
step << Priest
#optional
.goto Undercity,47.55,18.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 9473 >> Train your class spells
.target Father Lazarus
.xp <32,1
.xp >34,1
step << Priest
#optional
.goto Undercity,47.55,18.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 8105 >> Train your class spells
.target Father Lazarus
.xp <34,1
.xp >36,1
step << Priest
.goto Undercity,47.55,18.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 6066 >> Train your class spells
.target Father Lazarus
.xp <36,1
step
#completewith next
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Faranell|r
step
.goto Undercity,48.80,69.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faranell|r
.turnin 513 >> Turn in Elixir of Agony
.target Master Apothecary Faranell
step
#completewith next
.goto Undercity,51.99,64.54,10,0
.goto Undercity,46.25,73.22,10,0
.goto Undercity,45.32,78.32,10,0
.goto Undercity,46.26,83.91,10,0
.goto Undercity,49.03,87.92,10,0
.goto Undercity,52.94,89.60,10 >>Enter the Royal Quarter
step
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.turnin 550 >> Turn in Battle of Hillsbrad
.target Varimathras
.isQuestTurnedIn 541
.group
step << Paladin
#optional
.goto Undercity,58.0,90.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 19836 >> Train your class spells
.target Champion Cyssa Dawnrose
.xp <32,1
.xp >34,1
step << Paladin
#optional
.goto Undercity,58.0,90.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 642 >> Train your class spells
.target Champion Cyssa Dawnrose
.xp <34,1
.xp >36,1
step << Paladin
.goto Undercity,58.0,90.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 642 >> Train your class spells
.target Champion Cyssa Dawnrose
.xp <36,1
step << Druid
#optional
#completewith next
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,36.026,41.374
>>|cRXP_WARN_Combine the two pendants at the Shrine of Remulos for the|r |cRXP_LOOT_Pendant of the Sea Lion|r
.collect 15882,1,30,1,1
.collect 15883,1,30,1,1
.complete 30,1 
.itemcount 15882,1
step << Druid
#optional
.goto Moonglade,56.21,30.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dendrite|r
.turnin 30 >> Turn in Trial of the Sea lion
.accept 31 >> Accept Aquatic Form
.target Dendrite Starblaze
.isQuestComplete 30
step << Druid
#optional
.goto Moonglade,56.21,30.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dendrite|r
.accept 31 >> Accept Aquatic Form
.target Dendrite Starblaze
.isQuestTurnedIn 30
step << Druid
#completewith DruidTraining1
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 22568 >> Train your class spells
.target Loganaar
.xp <32,1
.xp >34,1
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 1823 >> Train your class spells
.target Loganaar
.xp <34,1
.xp >36,1
step << Druid
#label DruidTraining1
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9005 >> Train your class spells
.target Loganaar
.xp <36,1
step
#completewith next
.hs >> Hearth to Freewind Post
.use 6948
.bindlocation 484,1
.subzoneskip 484
.zoneskip Thousand Needles
step
.goto Thousand Needles,46.07,51.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Abeqwa|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Abeqwa
.isQuestAvailable 1147
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 33-34 Shimmering Flats
#next 34-36 Desolace Horde
step
.goto Thousand Needles,45.70,50.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cliffwatcher Longhorn|r
.accept 5361 >> Accept Family Tree
.target Cliffwatcher Longhorn
step
.goto Thousand Needles,46.10,51.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rau|r
.accept 1197 >> Accept The Sacred Flame
.target Rau Cliffrunner
.maxlevel 33
step << Hunter
.goto Thousand Needles,44.89,50.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Starn|r
.vendor >>|cRXP_BUY_Buy a|r |T135495:0|t[|cRXP_FRIENDLY_Dense Shortbow|r] |cRXP_BUY_from him if it's up|r
.target Starn
.money <2.7172
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<14.2
.subzoneskip 484,1
step << Hunter
.goto Thousand Needles,44.89,50.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Starn|r
>>|cRXP_BUY_Buy|r |T132382:0|t[Razor Arrows] |cRXP_BUY_from him|r
.collect 3030,2600,1146,1 
.target Starn
.subzoneskip 484,1
step
.goto Thousand Needles,45.15,50.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Montarr|r
.vendor >> |cRXP_BUY_Buy|r |T134831:0|t[Healing Potions] |cRXP_BUY_and|r |T134937:0|t[Scrolls] |cRXP_BUY_from him if they're up|r << !Warrior
.vendor >> |cRXP_BUY_Buy|r |T134831:0|t[Healing Potions]|cRXP_BUY_, |r|T134937:0|t[Scrolls] |cRXP_BUY_and|r |T134413:0|t[Liferoot] |cRXP_BUY_from him if they're up|r << Warrior
.target Montarr
.subzoneskip 484,1
step
#completewith Clovenhoof2
.goto Thousand Needles,44.12,37.22,20 >>Enter the cave
.isOnQuest 1197
step
#completewith Clovenhoof2
.goto Thousand Needles,44.44,36.32,12,0
.goto Thousand Needles,43.14,35.19,12,0
.goto Thousand Needles,42.11,34.54,12,0
.goto Thousand Needles,42.01,31.47,20 >>Travel toward the |cRXP_PICK_Ancient Brazier|r
.isOnQuest 1197
step
#label Clovenhoof2
.goto Thousand Needles,42.01,31.47
>>Open the |cRXP_PICK_Ancient Brazier|r. Loot it for the |cRXP_LOOT_Cloven Hoof|r
>>|cRXP_WARN_Be careful! The brazier is defended by two level 30|r |cRXP_ENEMY_Galak Flame Guards|r
.complete 1197,1 
.mob Galak Flame Guard
.isOnQuest 1197
step << Shaman
#completewith next
.goto Thousand Needles,54.7,44.4,30 >> Run up the ramp here
step << Shaman
.goto Thousand Needles,53.5,42.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Prate|r
>>|cRXP_WARN_This turn-in grants a 1-hour buff with +40% move speed, +30% attack speed|r
.turnin 1531 >>Turn in Call of Air
.target Prate Cloudseer
step
.goto Thousand Needles,67.58,63.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moktar|r
.turnin 1146 >> Turn in The Swarm Grows
.accept 1147 >> Accept The Swarm Grows
.target Moktar Krin
step
.goto Thousand Needles,77.79,77.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kravel|r
.turnin 1112 >> Turn in Parts for Kravel
.timer 15,Parts for Kravel RP
.accept 1114 >> Accept Delivery to the Gnomes
.accept 1110 >> Accept Rocket Car Parts
.target Kravel Koalbeard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzle|r and |cRXP_FRIENDLY_Wizzle|r
.turnin 1114 >> Turn in Delivery to the Gnomes
.accept 1104 >> Accept Salt Flat Venom
.target +Fizzle Brassbolts
.goto Thousand Needles,78.07,77.13
.accept 1105 >> Accept Hardened Shells
.target +Wizzle Brassbolts
.goto Thousand Needles,78.14,77.12
step
.goto Thousand Needles,77.79,77.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kravel|r
.accept 1115 >> Accept The Rumormonger
.target Kravel Koalbeard
step
.goto Thousand Needles,80.18,75.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pozzik|r
.accept 1176 >> Accept Load Lightening
.target Pozzik
step
.goto Thousand Needles,81.64,77.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zherin|r
.accept 1175 >> Accept A Bump in the Road
.target Trackmaster Zherin
step
.goto Thousand Needles,69.66,85.97
.subzone 479 >>Travel to The Rustmaul Dig Site
>>Loot |cRXP_PICK_Rocket Car Rubble|r and kill |cRXP_ENEMY_Scorpids|r, |cRXP_ENEMY_Vultures|r, |cRXP_ENEMY_Basilisks|r and |cRXP_ENEMY_Tortoises|r on the way
.complete 1176,1 
.disablecheckbox
.complete 1105,1 
.disablecheckbox
.complete 1104,1 
.disablecheckbox
.complete 1175,1 
.disablecheckbox
.complete 1175,2 
.disablecheckbox
.complete 1110,1 
.disablecheckbox
.mob Salt Flats Scavenger
.mob Salt Flats Vulture
.mob Sparkleshell Snapper
.mob Sparkleshell Borer
.mob Sparkleshell Tortoise
.mob Saltstone Basilisk
.mob Saltstone Crystalhide
.mob Scorpid Reaver
.mob Scorpid Terror
.isOnQuest 1147
step
#completewith next
>>Kill |cRXP_ENEMY_Silithid Invaders|r, |cRXP_ENEMY_Silithid Invaders|r and |cRXP_ENEMY_Silithid Invaders|r
>>|cRXP_WARN_Be careful! They cry for help when attacked, you could accidently aggro multiple nearby mobs|r
.complete 1147,3 
.mob +Silithid Invader
.complete 1147,1 
.mob +Silithid Searcher
.complete 1147,2 
.mob +Silithid Hive Drone
step
#loop
.goto Thousand Needles,67.27,85.30,0
.goto Thousand Needles,67.27,85.30,50,0
.goto Thousand Needles,68.14,85.96,50,0
.goto Thousand Needles,68.03,86.93,50,0
.goto Thousand Needles,68.08,88.54,50,0
.goto Thousand Needles,69.48,89.64,50,0
.goto Thousand Needles,70.31,87.64,50,0
.goto Thousand Needles,71.09,86.23,50,0
.goto Thousand Needles,71.34,84.11,50,0
.goto Thousand Needles,70.51,82.80,50,0
.goto Thousand Needles,68.52,80.87,50,0
.goto Thousand Needles,67.45,82.28,50,0
>>Loot the |cRXP_ENEMY_Silithid|r mobs for a |T135034:0|t[|cRXP_LOOT_Cracked Silithid Carapace|r]. Use it to start the quest
.collect 5877,1,1148,1 
.accept 1148 >> Accept Parts of the Swarm
.use 5877
step
#loop
.goto Thousand Needles,67.27,85.30,0
.goto Thousand Needles,67.27,85.30,50,0
.goto Thousand Needles,68.14,85.96,50,0
.goto Thousand Needles,68.03,86.93,50,0
.goto Thousand Needles,68.08,88.54,50,0
.goto Thousand Needles,69.48,89.64,50,0
.goto Thousand Needles,70.31,87.64,50,0
.goto Thousand Needles,71.09,86.23,50,0
.goto Thousand Needles,71.34,84.11,50,0
.goto Thousand Needles,70.51,82.80,50,0
.goto Thousand Needles,68.52,80.87,50,0
.goto Thousand Needles,67.45,82.28,50,0
>>Kill |cRXP_ENEMY_Silithid Invaders|r, |cRXP_ENEMY_Silithid Searchers|r and |cRXP_ENEMY_Silithid Hive Drones|r. Loot them for their |cRXP_LOOT_Hearts|r, |cRXP_LOOT_Talons|r and |cRXP_LOOT_Carapaces|r
>>|cRXP_WARN_Be careful! They cry for help when attacked, you could accidently aggro multiple nearby mobs|r
.complete 1147,3 
.mob +Silithid Invader
.complete 1147,1 
.mob +Silithid Searcher
.complete 1147,2 
.mob +Silithid Hive Drone
.complete 1148,1 
.mob +Silithid Invader
.mob +Silithid Searcher
.mob +Silithid Hive Drone
.complete 1148,2 
.mob +Silithid Invader
.mob +Silithid Searcher
.mob +Silithid Hive Drone
.complete 1148,3 
.mob +Silithid Invader
.mob +Silithid Searcher
.mob +Silithid Hive Drone
step
#completewith ShimmeringFlatsLoop
+|cRXP_WARN_Be careful!|r |cRXP_ENEMY_Salt Flats Vultures|r |cRXP_WARN_can execute. Stay above 20% health!|r
step
#completewith next
.goto Thousand Needles,67.58,63.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Moktar|r
.turnin 1147 >> Turn in The Swarm Grows
.target Moktar Krin
step
#label ShimmeringFlatsLoop
>>|cRXP_WARN_Run circles around The Shimmering Flats until all objectives are complete|r
>>Kill |cRXP_ENEMY_Salt Flats Scavengers|r and |cRXP_ENEMY_Salt Flats Vultures|r. Loot them for their |cRXP_LOOT_Bones|r
>>Kill |cRXP_ENEMY_Sparkleshell Tortoises|r, |cRXP_ENEMY_Sparkleshell Borers|r and |cRXP_ENEMY_Sparkleshell Snappers|r. Loot them for their |cRXP_LOOT_Shells|r
>>Kill |cRXP_ENEMY_Scorpid Reavers|r and |cRXP_ENEMY_Scorpid Terrors|r. Loot them for their |cRXP_LOOT_Venom|r
>>Kill |cRXP_ENEMY_Saltstone Basilisks|r, |cRXP_ENEMY_Saltstone Crystalhides|r and |cRXP_ENEMY_Saltstone Gazers|r
>>Open the |cRXP_PICK_Rocket Car Rubble|r. Loot it for the |cRXP_LOOT_Rocket Car Parts|r
.complete 1176,1 
.mob +Salt Flats Scavenger
.mob +Salt Flats Vulture
.goto Thousand Needles,87.5,65.6,0
.complete 1105,1 
.mob +Sparkleshell Snapper
.mob +Sparkleshell Borer
.mob +Sparkleshell Tortoise
.goto Thousand Needles,82.6,54.8,0
.complete 1104,1 
.mob +Scorpid Reaver
.mob +Scorpid Terror
.goto Thousand Needles,71.8,73.4,0
.complete 1175,1 
.mob +Saltstone Basilisk
.goto Thousand Needles,73.5,59.9,0
.complete 1175,2 
.mob +Saltstone Crystalhide
.goto Thousand Needles,77.65,87.34,0
.complete 1175,3 
.mob +Saltstone Gazer
.goto Thousand Needles,77.65,87.34,0
.complete 1110,1 
step
.goto Thousand Needles,67.58,63.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Moktar|r
.turnin 1147 >> Turn in The Swarm Grows
.target Moktar Krin
step
.goto Thousand Needles,77.79,77.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Kravel|r
.turnin 1110 >> Turn in Rocket Car Parts
.accept 5762 >> Accept Hemet Nesingwary
.target Kravel Koalbeard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzle|r and |cRXP_FRIENDLY_Wizzle|r
.turnin 1104 >> Turn in Salt Flat Venom
.goto Thousand Needles,78.07,77.13
.turnin 1105 >> Turn in Hardened Shells
.target +Wizzle Brassbolts
.goto Thousand Needles,78.14,77.12
.accept 1106 >> Accept Martek the Exiled
.target +Fizzle Brassbolts
.goto Thousand Needles,78.07,77.13
step
#ah << !Warlock !Druid !Shaman
.goto Thousand Needles,78.14,77.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.accept 1107 >> Accept in Encrusted Tail Fins
.target Wizzle Brassbolts
step
.goto Thousand Needles,80.18,75.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pozzik|r
.turnin 1176 >> Turn in Load Lightening
.accept 1178 >> Accept Goblin Sponsorship
.target Pozzik
step
.goto Thousand Needles,81.63,77.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zherin|r
.turnin 1175 >> Turn in A Bump in the Road
.target Trackmaster Zherin
step
.goto Thousand Needles,75.44,97.37,40,0
.goto Tanaris,51.60,25.44,100 >> Travel to Gadgetzan
.zoneskip Tanaris
step
#optional
#completewith next
.goto Tanaris,51.61,25.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Freewind Post >> Fly to Freewind Post
.target Bulkrek Ragefist
.subzoneskip 484
.isQuestComplete 1197
step
#optional
.goto Thousand Needles,46.10,51.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rau|r
.turnin 1197 >> Turn in The Sacred Flame
.target Rau Cliffrunner
.isQuestComplete 1197
step
#optional
#completewith SetHSCampT
.goto Thousand Needles,45.14,49.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyse|r
.fly Camp Taurajo >> Fly to Camp Taurajo
.target Nyse
.zoneskip Thousand Needles,1
step
#completewith next
.goto Tanaris,51.61,25.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Camp Taurajo >> Fly to Camp Taurajo
.target Bulkrek Ragefist
.zoneskip Tanaris,1
step
#label SetHSCampT
.goto The Barrens,45.60,59.0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Byula|r
.home >>Set your Hearthstone to Camp Taurajo
.target Innkeeper Byula
.bindlocation 378
step
#completewith next
.goto The Barrens,44.45,59.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Omusa|r
.fly Crossroads >> Fly to The Crossroads
.target Omusa Thunderhorn
.subzoneskip 380
step
.goto The Barrens,51.10,29.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korran|r
.turnin 1148 >> Turn in Parts of the Swarm
.accept 1184 >> Accept Parts of the Swarm
.target Korran
step
#completewith next
.goto The Barrens,51.50,30.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Devrak|r
.fly Ratchet >> Fly to Ratchet
.target Devrak
.subzoneskip 392
step
.goto The Barrens,62.68,37.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zikkel|r
.bankdeposit 4306,15 >> Deposit 15 |T132905:0|t[Silk Cloth] into your bank
.target Zikkel
.itemcount 4306,15
step
.goto The Barrens,62.68,36.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gazlowe|r
.turnin 1178 >> Turn in Goblin Sponsorship
.accept 1180 >> Accept Goblin Sponsorship
.target Gazlowe
step << Shaman
.goto The Barrens,65.83,43.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Islen|r
.turnin 96 >>Turn in Call of Water
.target Islen Waterseer
step
#completewith next
.goto The Barrens,63.74,38.66
.zone Stranglethorn Vale >> Take the boat to Stranglethorn Vale
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,26.30,73.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lozgil|r
.turnin 1180 >> Turn in Goblin Sponsorship
.accept 1181 >> Accept Goblin Sponsorship
.target Wharfmaster Lozgil
step
.goto Stranglethorn Vale,28.30,77.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drizzlik|r
.accept 575 >> Accept Supply and Demand
.target Drizzlik
step << Warrior/Shaman
.goto Stranglethorn Vale,28.34,75.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Zarena|r
.vendor >>|cRXP_BUY_Buy a|r |T135158:0|t[Big Stick] |cRXP_BUY_or a|r |T135144:0|t[Staff of Protection] |cRXP_BUY_from her if one of them is available|r


.money <5.3896
.target Zarena Cromwind
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.6
step
.goto Stranglethorn Vale,27.10,77.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank|r inside the inn
.accept 605 >> Accept Singing Blue Shards
.target Crank Fizzlebub
step << Rogue
.goto Stranglethorn Vale,26.82,77.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ian|r on the second floor of the inn
.train 8696 >> Train your class spells
.target Ian Strom
.xp <34,1
.xp >36,1
step << Rogue
#optional
.goto Stranglethorn Vale,26.82,77.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ian|r on the second floor of the inn
.train 8691 >> Train your class spells
>>|T132273:0|t[Instant Poison Rank 3] |cRXP_WARN_requires 160 skill in Poisons!|r
.target Ian Strom
.xp <36,1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krazek|r and |cRXP_FRIENDLY_Kebok|r on the third floor of the inn
.turnin 1115 >> Turn in The Rumormonger
.accept 201 >> Accept Investigate the Camp
.target +Krazek
.goto Stranglethorn Vale,26.94,77.21
.accept 189 >> Accept Bloodscalp Ears
.accept 213 >> Accept Hostile Takeover
.target +Kebok
.goto Stranglethorn Vale,27.00,77.13
step
.goto Stranglethorn Vale,27.20,76.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron|r on the third floor balcony
.turnin 1181 >> Turn in Goblin Sponsorship
.accept 1182 >> Accept Goblin Sponsorship
.target Baron Revilgaz
step
.goto Stranglethorn Vale,26.90,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r around the corner of the balcony
.fp Booty Bay >> Get the Booty Bay flight path
.target Gringer
.subzoneskip 35,1
step
.goto Stranglethorn Vale,28.14,78.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Glyx|r
.vendor >> |cRXP_BUY_Buy|r |T134832:0|t[Greater Healing Potions] |cRXP_BUY_from him if they're up|r
.target Glyx Brewright
.subzoneskip 35,1
step
.hs >> Hearth to Camp Taurajo
.bindlocation 378,1
.subzoneskip 378
.use 6948
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 34-36 Desolace Horde
#next 36-38 Stranglethorn Vale part 1
step
#optional
.maxlevel 36,DesolaceSkip
step
#completewith next
.goto The Barrens,44.45,59.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Omusa|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.target Omusa Thunderhorn
.zoneskip Thunder Bluff
step
.goto Thunder Bluff,45.81,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Pala|r
.home >>Set your Hearthstone to Thunder Bluff
.target Innkeeper Pala
.bindlocation 1638
.isQuestAvailable 1480
step << Druid
.goto Thunder Bluff,76.46,27.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turak|r
.train 1823 >>Train your class spells
.target Turak Runetotem
.xp <34,1
.xp >36,1
step << Druid
#optional
.goto Thunder Bluff,76.46,27.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turak|r
.train 1823 >>Train your class spells
.target Turak Runetotem
.xp <36,1
step << Hunter
.goto Thunder Bluff,59.11,86.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 13552 >>Train your class spells
.target Urek Thunderhorn
.xp <34,1
.xp >36,1
step << Hunter
#optional
.goto Thunder Bluff,59.11,86.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 14284 >>Train your class spells
.target Urek Thunderhorn
.xp <36,1
step << Hunter
.goto Thunder Bluff,54.08,84.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hesuwa|r
.train 24560 >>Train your pet spells
.target Hesuwa Thunderhorn
.xp <36,1
step << Warrior
.goto Thunder Bluff,57.56,85.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ker|r
.train 11554 >>Train your class spells
.target Ker Ragetotem
.xp <34,1
.xp >36,1
step << Warrior
#optional
.goto Thunder Bluff,57.56,85.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ker|r
.train 1680 >> Train your class spells
.target Ker Ragetotem
.xp <36,1
step << Shaman
.goto Thunder Bluff,22.84,21.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigor|r
.train 16314 >>Train your class spells
.target Tigor Skychaser
.xp <34,1
.xp >36,1
step << Shaman
#optional
.goto Thunder Bluff,22.84,21.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigor|r
.train 10412 >>Train your class spells
.target Tigor Skychaser
.xp <36,1
step << Priest
.goto Thunder Bluff,24.56,22.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malakai|r
.train 2767 >> Train your class spells
.target Malakai Cross
.xp <34,1
.xp >36,1
step << Priest
#optional
.goto Thunder Bluff,24.56,22.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malakai|r
.train 15264 >> Train your class spells
.target Malakai Cross
.xp <36,1
step << Mage
.goto Thunder Bluff,25.18,20.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thurston|r
.train 8492 >> Train your class spells
.target Thurston Xane
.xp <34,1
.xp >36,1
step << Mage
#optional
.goto Thunder Bluff,25.18,20.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thurston|r
.train 8495 >> Train your class spells
.target Thurston Xane
.xp <36,1
step
#ah
.goto Thunder Bluff,40.39,51.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Stampi|r
>>|cRXP_BUY_Buy|r |T133900:0|t[Shellfish] |cRXP_BUY_from the auction house if possible|r
.collect 13545,10,5386,1 
.target Auctioneer Stampi
step
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Sun Rock >> Fly to Stonetalon Mountains
.target Tal
.zoneskip Stonetalon Mountains
step
.goto Stonetalon Mountains,44.63,61.55,60,0
.goto Stonetalon Mountains,38.77,68.65,60,0
.goto Stonetalon Mountains,30.22,75.61,60,0
.goto Stonetalon Mountains,29.29,79.69
.zone Desolace >>Head southwest to the mountain path. Follow it into the Charred Vale. From there, turn south into Desolace
.zoneskip Desolace
step
#completewith next
.subzone 599 >>Travel to Thunder Axe Fortress
step
.goto Desolace,55.80,30.10
>>Kill and loot members of the |cRXP_ENEMY_Burning Blade|r until you get a |T134253:0|t[|cRXP_LOOT_Flayed Demon Skin|r]
.collect 20310,1,1480 
.accept 1480 >> Accept The Corrupter
.mob Burning Blade Augur
.mob Burning Blade Adept
.mob Burning Blade Reaver
.mob Burning Blade Felsworn
.mob Burning Blade Shadowmage
step << Warrior/Hunter/Rogue/Druid/Shaman
.goto Desolace,55.94,29.19
.xp 35+35000 >> Grind Burning Blade mobs at Thunder Axe Fortress to level 35 35000+/67100
.mob Burning Blade Felsworn
.mob Burning Blade Augur
.mob Burning Blade Reaver
.mob Burning Blade Adept
step
.goto Desolace,38.90,27.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azore|r
.accept 5741 >> Accept Sceptre of Light
.target Azore Aldamort
step
#completewith next
.goto Desolace,56.30,57.07,100 >> Travel to Ghost Walker Post
step
.goto Desolace,55.40,55.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nataka|r
.turnin 5361 >> Turn in Family Tree
.target Nataka Longhorn
step
.goto Desolace,52.60,54.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Takata|r
.turnin 1432 >> Turn in Alliance Relations
.accept 1433 >> Accept Alliance Relations
.accept 1434 >> Accept Befouled by Satyr
.target Takata Steelblade
step
.goto Desolace,52.20,53.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maurin|r
.turnin 1433 >> Turn in Alliance Relations
.accept 1435 >> Accept The Burning of Spirits
.turnin 1480 >> Turn in The Corrupter
.accept 1481 >> Accept The Corrupter
.target Maurin Bonesplitter
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felgur|r and |cRXP_FRIENDLY_Gurda|r
.accept 1365 >> Accept Khan Dez'hepah
.target +Felgur Twocuts
.goto Desolace,56.19,59.56
.accept 1368 >> Accept Gelkis Alliance
.target +Gurda Wildmane
.goto Desolace,56.29,59.67
step
#loop
.goto Desolace,73.20,41.80,0
.goto Desolace,73.00,46.80,0
.goto Desolace,74.80,48.80,0
.goto Desolace,73.20,41.80,60,0
.goto Desolace,73.00,46.80,60,0
.goto Desolace,74.80,48.80,60,0
>>Kill |cRXP_ENEMY_Khan Dez'hepah|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_He has 3 different spawn locations in the camp|r
.complete 1365,1 
.unitscan Khan Dez'hepah
step
#completewith next
>>Kill |cRXP_ENEMY_Hatefury Shadowstalkers|r. Loot them for a |cRXP_LOOT_Scalp|r
.complete 1481,1 
.mob Hatefury Shadowstalker
step
#loop
.goto Desolace,75.26,27.91,0
.goto Desolace,75.26,27.91,60,0
.goto Desolace,76.77,27.73,60,0
.goto Desolace,77.54,26.68,60,0
.goto Desolace,78.20,25.63,60,0
.goto Desolace,78.90,24.60,60,0
.goto Desolace,78.74,23.15,60,0
.goto Desolace,79.33,20.96,60,0
.goto Desolace,79.69,18.92,60,0
.goto Desolace,79.36,16.18,60,0
.goto Desolace,77.43,15.44,60,0
.goto Desolace,75.96,15.89,60,0
.goto Desolace,74.52,15.66,60,0
.goto Desolace,72.81,16.83,60,0
.goto Desolace,71.58,17.94,60,0
.goto Desolace,71.50,20.22,60,0
.goto Desolace,72.36,21.23,60,0
.goto Desolace,73.04,22.41,60,0
.goto Desolace,73.09,24.41,60,0
.goto Desolace,73.79,25.72,60,0
>>Kill |cRXP_ENEMY_Hatefury Satyrs|r. Prioritize killing the |cRXP_ENEMY_Hatefury Rogues|r
.complete 1434,1 
.mob +Hatefury Rogue
.complete 1434,2 
.mob +Hatefury Felsworn
.complete 1434,3 
.mob +Hatefury Betrayer
.complete 1434,4 
.mob +Hatefury Hellcaller
step
#loop
.goto Desolace,75.26,27.91,0
.goto Desolace,75.26,27.91,60,0
.goto Desolace,76.77,27.73,60,0
.goto Desolace,77.54,26.68,60,0
.goto Desolace,78.20,25.63,60,0
.goto Desolace,78.90,24.60,60,0
.goto Desolace,78.74,23.15,60,0
.goto Desolace,79.33,20.96,60,0
.goto Desolace,79.69,18.92,60,0
.goto Desolace,79.36,16.18,60,0
.goto Desolace,77.43,15.44,60,0
.goto Desolace,75.96,15.89,60,0
.goto Desolace,74.52,15.66,60,0
.goto Desolace,72.81,16.83,60,0
.goto Desolace,71.58,17.94,60,0
.goto Desolace,71.50,20.22,60,0
.goto Desolace,72.36,21.23,60,0
.goto Desolace,73.04,22.41,60,0
.goto Desolace,73.09,24.41,60,0
.goto Desolace,73.79,25.72,60,0
>>Kill |cRXP_ENEMY_Hatefury Shadowstalkers|r. Loot them for a |cRXP_LOOT_Scalp|r
.complete 1481,1 
.mob Hatefury Shadowstalker
step
.goto Desolace,62.30,39.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bibbly|r
.accept 5501 >> Accept Bone Collector
.target Bibbly F'utzbuckle
step
#completewith next
.goto Desolace,56.30,57.07,100 >> Travel to Ghost Walker Post
step
.goto Desolace,52.60,54.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Takata|r
.turnin 1434 >> Turn in Befouled by Satyr
.target Takata Steelblade
step
.goto Desolace,52.20,53.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maurin|r
.turnin 1481 >> Turn in The Corrupter
.accept 1482 >> Accept The Corrupter
.target Maurin Bonesplitter
step
.goto Desolace,51.20,53.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harnor|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Harnor
.isQuestAvailable 1366
.subzoneskip 597,1
step
.goto Desolace,56.20,59.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felgur|r
.turnin 1365 >> Turn in Khan Dez'hepah
.accept 1366 >> Accept Centaur Bounty
.target Felgur Twocuts
step
.goto Desolace,60.80,61.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smeed|r
.accept 5561 >> Accept Kodo Roundup
.target Smeed Scrabblescrew
step
#loop
.goto Desolace,69.60,77.85,0
.goto Desolace,67.90,73.59,60,0
.goto Desolace,67.86,75.80,60,0
.goto Desolace,66.26,75.70,60,0
.goto Desolace,65.70,78.86,60,0
.goto Desolace,66.40,80.05,60,0
.goto Desolace,68.56,81.01,60,0
.goto Desolace,72.20,78.35,60,0
.goto Desolace,70.95,75.09,60,0
.goto Desolace,73.36,73.37,60,0
.goto Desolace,69.60,77.85,60,0
>>Kill |cRXP_ENEMY_Magram Centaur|r. Loot them for their |cRXP_LOOT_Ears|r
>>|cRXP_WARN_Be careful of |cRXP_ENEMY_Magram Pack Runners|r as they have two |cRXP_ENEMY_Hyenas|r (level 37-38) with them|r
.complete 1366,1 
.mob Magram Outrunner
.mob Magram Scout
.mob Magram Stormer
.mob Magram Mauler
.mob Magram Marauder
.mob Magram Wrangler
step
#loop
.goto Desolace,69.60,77.85,0
.goto Desolace,67.90,73.59,60,0
.goto Desolace,67.86,75.80,60,0
.goto Desolace,66.26,75.70,60,0
.goto Desolace,65.70,78.86,60,0
.goto Desolace,66.40,80.05,60,0
.goto Desolace,68.56,81.01,60,0
.goto Desolace,72.20,78.35,60,0
.goto Desolace,70.95,75.09,60,0
.goto Desolace,73.36,73.37,60,0
.goto Desolace,69.60,77.85,60,0
>>Continue grinding |cRXP_ENEMY_Magram Centaur|r until your reputation with the |cRXP_FRIENDLY_Gelkis Centaur|r is Friendly
>>|cRXP_WARN_Be careful of |cRXP_ENEMY_Magram Pack Runners|r as they have two |cRXP_ENEMY_Hyenas|r (level 37-38) with them|r
.reputation 92,Friendly
.mob Magram Outrunner
.mob Magram Scout
.mob Magram Stormer
.mob Magram Mauler
.mob Magram Marauder
.mob Magram Wrangler
step
#completewith next
.goto Desolace,60.86,61.86,0
>>Use the |T132488:0|t[Kodo Kombobulator] on |cRXP_FRIENDLY_Kodos|r, then escort them to |cRXP_FRIENDLY_Smeed|r
>>Click on the |cRXP_FRIENDLY_Kodo|r after each trip to progress the quest
.complete 5561,1 
.use 13892
.target Dying Kodo
.target Aged Kodo
.target Ancient Kodo
.target Smeed Scrabblescrew
.skipgossip
step
#loop
.goto Desolace,53.31,61.24,0
.goto Desolace,54.42,63.79,30,0
.goto Desolace,54.38,62.87,30,0
.goto Desolace,53.31,61.24,30,0
.goto Desolace,54.39,60.38,30,0
.goto Desolace,53.90,58.17,30,0
.goto Desolace,52.88,57.13,30,0
.goto Desolace,52.14,58.56,30,0
.goto Desolace,51.13,59.97,30,0
.goto Desolace,50.81,58.72,30,0
.goto Desolace,49.70,57.15,30,0
.goto Desolace,48.90,58.86,30,0
.goto Desolace,48.98,60.05,30,0
>>Loot the |cRXP_LOOT_Kodo Bones|r on the ground around the Kodo Graveyard
>>|cRXP_WARN_Be careful as high level|r |cRXP_ENEMY_Kodos|r |cRXP_WARN_can spawn after looting the|r |cRXP_LOOT_Kodo Bones|r << !Rogue !Druid
>>|cRXP_WARN_Be careful as high level|r |cRXP_ENEMY_Kodos|r |cRXP_WARN_can spawn after looting the|r |cRXP_LOOT_Kodo Bones|r|cRXP_WARN_. Immediately stealthing will often prevent them from attacking you|r << Rogue/Druid
.complete 5501,1 
step
#loop
.goto Desolace,53.96,61.10,0
.goto Desolace,53.96,61.10,50,0
.goto Desolace,60.87,61.85,20,0
>>Use the |T132488:0|t[Kodo Kombobulator] on |cRXP_FRIENDLY_Kodos|r, then escort them to |cRXP_FRIENDLY_Smeed|r
>>Click on the |cRXP_FRIENDLY_Kodo|r after each trip to progress the quest
.complete 5561,1 
.use 13892
.target Dying Kodo
.target Aged Kodo
.target Ancient Kodo
.target Smeed Scrabblescrew
.skipgossip
step
.goto Desolace,60.80,61.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smeed|r
.turnin 5561 >> Turn in Kodo Roundup
.target Smeed Scrabblescrew
step
.goto Desolace,36.30,79.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uthek|r
.turnin 1368 >> Turn in Gelkis Alliance
.accept 1370 >> Accept Stealing Supplies
.target Uthek the Wise
step
#completewith ShadowPreyVisit1
.goto Desolace,27.07,75.74,100,0
.goto Desolace,26.09,74.49,60,0
.subzone 2408 >>Travel to Shadowprey Village
step
.goto Desolace,25.80,68.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taiga|r
.accept 5381 >> Accept Hand of Iruxos
.target Taiga Wisemane
step << Mage
#optional
.goto Desolace,24.09,68.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Sikewa|r
.home >> Set your Hearthstone to Shadowprey Village
.target Innkeeper Sikewa
.bindlocation 484
.isQuestAvailable 6027,5501,5741,6161,1482,6143
.train 3566,3 
.itemcount 17031,1 
step
.goto Desolace,22.70,72.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mai'Lahii|r
.accept 6142 >> Accept Clam Bait
.target Mai'Lahii
step
#label ShadowPreyVisit1
.goto Desolace,23.30,72.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drulzegar|r
.accept 6143 >> Accept Other Fish to Fry
.target Drulzegar Skraghook
step
.goto Desolace,21.60,74.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thalon|r at the end of the dock
.fp Shadowprey Village >> Get the Shadowprey Village flight path
.target Thalon
.subzoneskip 2408,1
step
#ah
.goto Desolace,22.44,73.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jinar'Zillen|r
.turnin 5421 >> Turn in Fish in a Bucket |cRXP_WARN_TWICE|r to receive 2 |T133892:0|t[|cRXP_LOOT_Bloodbelly Fish|r]
.collect 13546,2,5386,1 
.target Jinar'Zillen
.itemcount 13545,10 
step << Hunter
.goto Desolace,24.93,71.84
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tukk|r
>>|cRXP_BUY_Buy|r |T132382:0|t[Razor Arrows] |cRXP_BUY_from him|r
.collect 3030,2600,5741,1 
.target Tukk
step
#completewith next
.goto Desolace,62.30,39.00,150 >> Travel to northern Desolace
step
.goto Desolace,62.30,39.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bibbly|r
.turnin 5501 >> Turn in Bone Collector
.target Bibbly F'utzbuckle
step
#completewith DemonSpirit
.use 6436 >> Kill |cRXP_ENEMY_Burning Blade members|r
>>|cRXP_WARN_Use the|r |T134095:0|t[Burning Gem] |cRXP_WARN_to get the killing blow (100 damage per tick)|r
.complete 1435,1 
step
.goto Desolace,55.20,30.10
>>Kill the |cRXP_ENEMY_Burning Blade Seer|r at the top of the tower. Loot it for the |cRXP_LOOT_Sceptre|r
.complete 5741,1 
.mob Burning Blade Seer
step
#completewith next
.goto Desolace,55.31,27.55,12 >>Enter the large building
step
#label DemonSpirit
.goto Desolace,54.62,27.54,10,0
.goto Desolace,54.43,27.22,10,0
.goto Desolace,54.93,26.67
>>|cRXP_WARN_Use the|r |T136248:0|t[Demon Pick] |cRXP_WARN_on the|r |cRXP_PICK_Hand of Iruxos Crystal|r
>>Kill the |cRXP_ENEMY_Demon Spirit|r after it spawns. Loot it for the |cRXP_LOOT_Demon Box|r
.complete 5381,1 
.mob Demon Spirit
step
#loop
.goto Desolace,56.82,29.95,0
.goto Desolace,55.58,28.70,50,0
.goto Desolace,56.82,29.95,50,0
.goto Desolace,57.21,27.86,50,0
.goto Desolace,57.62,26.30,50,0
.goto Desolace,57.26,22.39,50,0
.goto Desolace,56.41,21.57,50,0
.use 6436 >> Kill |cRXP_ENEMY_Burning Blade members|r
>>|cRXP_WARN_Use the|r |T134095:0|t[Burning Gem] |cRXP_WARN_to get the killing blow (100 damage per tick)|r
.complete 1435,1 
.mob Burning Blade Augur
.mob Burning Blade Adept
.mob Burning Blade Reaver
.mob Burning Blade Felsworn
.mob Burning Blade Shadowmage
step
.goto Desolace,38.90,27.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Azore|r
.turnin 5741 >> Turn in Sceptre of Light
.accept 6027 >> Accept Book of the Ancients
.target Azore Aldamort
step
.goto Desolace,36.07,30.40
>>Click |cRXP_PICK_Rackmore's Log|r, resting on a barrel
.accept 6161 >> Accept Claim Rackmore's Treasure!
step << !Warlock !Druid !Shaman
#ah
#completewith next
.aura 7178 >>|cRXP_WARN_Drink an|r |T134797:0|t[Elixir of Water Breathing]
.use 5996
.itemcount 5996,1
step
#completewith Rackmore
>>Kill |cRXP_ENEMY_Slitherblade Oracles|r. Loot them for an |cRXP_LOOT_Oracle Crystal|r
>>|cRXP_ENEMY_Slitherblade Oracles|r |cRXP_WARN_share spawns with other|r |cRXP_ENEMY_Slitherblade Nagas|r|cRXP_WARN_; you may have to kill them|r
.complete 1482,1 
.mob Slitherblade Oracle
step
#completewith BookoftheAncients
>>Kill |cRXP_ENEMY_Slitherblade Nagas|r. Loot them for the |cRXP_LOOT_Golden Key|r
.complete 6161,2 
step
#completewith ClamMeat
>>Kill |cRXP_ENEMY_Drysnap Pincers|r and |cRXP_ENEMY_Crawlers|r. Loot them for the |cRXP_LOOT_Silver Key|r
.complete 6161,1 
.mob Drysnap Pincer
.mob Drysnap Crawler
step
#completewith Rackmore
>>Kill |cRXP_ENEMY_Slitherblade Naga|r, |cRXP_ENEMY_Myrmidons|r, and |cRXP_ENEMY_Sorceresses|r
.complete 6143,1 
.mob +Slitherblade Myrmidon
.complete 6143,2 
.mob +Slitherblade Naga
.complete 6143,3 
.mob +Slitherblade Sorceress
step
#label ClamMeat
#loop
.goto Desolace,32.97,28.58,0
.goto Desolace,34.12,30.74,40,0
.goto Desolace,31.96,30.60,40,0
.goto Desolace,32.98,28.57,40,0
.goto Desolace,35.36,25.03,40,0
.goto Desolace,34.34,23.11,40,0
.goto Desolace,32.97,28.58,40,0
.use 15874 >>Loot the |cRXP_PICK_Giant Softshell Clams|r on the ocean floor. Open them for their |cRXP_LOOT_Meat|r
>>|cRXP_ENEMY_Enraged Reef Crawlers|r |cRXP_WARN_can also drop the|r |cRXP_PICK_Giant Softshell Clams|r
.complete 6142,1 
.mob Enraged Reef Crawler
step
#label SilverKey
#loop
.goto Desolace,31.96,30.60,0
.goto Desolace,34.12,30.74,40,0
.goto Desolace,31.96,30.60,40,0
.goto Desolace,32.98,28.57,40,0
.goto Desolace,35.36,25.03,40,0
.goto Desolace,34.34,23.11,40,0
.goto Desolace,32.97,28.58,40,0
>>Kill |cRXP_ENEMY_Drysnap Pincers|r and |cRXP_ENEMY_Crawlers|r. Loot them for the |cRXP_LOOT_Silver Key|r
.complete 6161,1 
.mob Drysnap Pincer
.mob Drysnap Crawler
step
.goto Desolace,30.00,8.80
>>Click |cRXP_PICK_Rackmore's Chest|r
.turnin 6161 >> Turn in Claim Rackmore's Treasure!
.isQuestComplete 6161
step
#label BookoftheAncients
.goto Desolace,28.20,6.60
>>Click the |cRXP_PICK_Serpent Statue|r to summon |cRXP_ENEMY_Lord Kragaru|r. Kill him and loot him for his |cRXP_LOOT_Book|r
>>|cRXP_WARN_Kill everything around the Serpent Statue first!|r
.complete 6027,1 
.mob Lord Kragaru
step
#loop
.goto Desolace,28.48,11.14,0
.goto Desolace,28.48,11.14,50,0
.goto Desolace,27.24,10.26,50,0
.goto Desolace,27.81,7.83,50,0
.goto Desolace,27.87,5.71,50,0
.goto Desolace,28.66,6.74,50,0
.goto Desolace,30.07,6.86,50,0
.goto Desolace,30.96,7.87,50,0
.goto Desolace,30.33,8.98,50,0
.goto Desolace,29.99,11.23,50,0
>>Kill |cRXP_ENEMY_Slitherblade Nagas|r. Loot them for the |cRXP_LOOT_Golden Key|r
.complete 6161,2 
step
#label Rackmore
.goto Desolace,30.00,8.80
>>Click |cRXP_PICK_Rackmore's Chest|r
.turnin 6161 >> Turn in Claim Rackmore's Treasure!
step
#completewith next
>>Kill |cRXP_ENEMY_Slitherblade Naga|r, |cRXP_ENEMY_Myrmidons|r, and |cRXP_ENEMY_Sorceresses|r
.complete 6143,1 
.mob +Slitherblade Myrmidon
.complete 6143,2 
.mob +Slitherblade Naga
.complete 6143,3 
.mob +Slitherblade Sorceress
step
#loop
.goto Desolace,28.48,11.14,0
.goto Desolace,28.48,11.14,50,0
.goto Desolace,27.24,10.26,50,0
.goto Desolace,27.81,7.83,50,0
.goto Desolace,27.87,5.71,50,0
.goto Desolace,28.66,6.74,50,0
.goto Desolace,30.07,6.86,50,0
.goto Desolace,30.96,7.87,50,0
.goto Desolace,30.33,8.98,50,0
.goto Desolace,29.99,11.23,50,0
>>Kill |cRXP_ENEMY_Slitherblade Oracles|r. Loot them for an |cRXP_LOOT_Oracle Crystal|r
>>|cRXP_ENEMY_Slitherblade Oracles|r |cRXP_WARN_share spawns with other|r |cRXP_ENEMY_Slitherblade Nagas|r|cRXP_WARN_; you may have to kill them|r
.complete 1482,1 
.mob Slitherblade Oracle
step
#loop
.goto Desolace,32.41,23.00,0
.goto Desolace,32.41,23.00,60,0
.goto Desolace,34.99,21.73,60,0
.goto Desolace,36.86,20.16,60,0
.goto Desolace,39.13,18.74,60,0
.goto Desolace,40.44,20.40,60,0
.goto Desolace,37.70,20.85,60,0
.goto Desolace,36.64,23.40,60,0
.goto Desolace,34.67,24.12,60,0
>>Kill |cRXP_ENEMY_Slitherblade Naga|r, |cRXP_ENEMY_Myrmidons|r, and |cRXP_ENEMY_Sorceresses|r
.complete 6143,1 
.mob +Slitherblade Myrmidon
.complete 6143,2 
.mob +Slitherblade Naga
.complete 6143,3 
.mob +Slitherblade Sorceress
step
.goto Desolace,38.88,27.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Azore|r
.turnin 6027 >> Turn in Book of the Ancients
.target Azore Aldamort
step
#completewith next
.goto Desolace,56.30,57.07,100 >> Travel to Ghost Walker Post
step
.goto Desolace,52.24,53.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Maurin|r
.turnin 1435 >> Turn in The Burning of Spirits
.turnin 1482 >> Turn in The Corrupter
.timer 30,The Corrupter RP
.target Maurin Bonesplitter
step
.goto Desolace,52.24,53.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Maurin|r
>>|cRXP_WARN_Wait for the RP to finish|r
.accept 1484 >> Accept The Corrupter
.target Maurin Bonesplitter
step
#ah
.goto Desolace,55.41,55.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nataka|r
.accept 5386 >> Accept Catch of the Day
.turnin 5386 >> Turn in Catch of the Day
.target Nataka Longhorn
.itemcount 13546,2 
step
.goto Desolace,52.56,54.38
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Takata|r
.turnin 1484 >> Turn in The Corrupter

.accept 1436 >> Accept Alliance Relations
.target Takata Steelblade
step
.goto Desolace,51.20,53.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harnor|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Harnor
.isQuestAvailable 1370
.subzoneskip 597,1
step
.goto Desolace,56.20,59.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felgur|r
.turnin 1366 >> Turn in Centaur Bounty
.target Felgur Twocuts
step
#loop
.goto Desolace,73.67,72.90,0
.goto Desolace,69.22,77.24,30,0
.goto Desolace,70.01,78.60,30,0
.goto Desolace,70.92,75.43,30,0
.goto Desolace,73.18,75.11,30,0
.goto Desolace,73.57,74.21,30,0
.goto Desolace,73.67,72.90,30,0
>>Loot the |cRXP_PICK_Sacks of Meat|r around Magram Village for their |cRXP_LOOT_Meat|r
.complete 1370,1
.complete 1370,2
step
.goto Desolace,36.21,79.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uthek the Wise|r
.turnin 1370 >> Turn in Stealing Supplies

.target Uthek the Wise
step << Mage
.hs >>Hearth to Shadowprey Village
.bindlocation 2408,1
.subzoneskip 2408
.cooldown item,6948,>0,1
.itemcount 17031,1 
.isQuestComplete 5381
step
#completewith DesolaceEnd
.goto Desolace,27.07,75.74,100,0
.goto Desolace,26.09,74.49,60,0
.subzone 2408 >>Travel to Shadowprey Village
step
.goto Desolace,25.10,72.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Roon|r
.accept 5763 >> Accept Hunting in Stranglethorn
.target Roon Wildmane
step << Hunter
#completewith next
.goto Desolace,24.90,68.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Aboda|r
.stable >> Stable your pet. You will tame a |cRXP_ENEMY_Scorpashi Lasher|r shortly
.target Aboda
step << Hunter
#loop
.goto Desolace,42.45,70.19,0
.goto Desolace,38.24,74.30,50,0
.goto Desolace,42.45,70.19,50,0
.goto Desolace,43.34,60.43,50,0
.cast 1515 >>|cRXP_WARN_Cast|r |T132164:0|t[Tame Beast] |cRXP_WARN_on a |cRXP_ENEMY_Scorpashi Lasher|r to tame it|r
.train 16831 >>|cRXP_WARN_Attack mobs with it to learn|r |T132140:0|t[Claw (Rank 5)]
.link https://www.wow-petopia.com/classic/training.php >> |cRXP_WARN_Click here for more info about pet training|r
.mob Scorpashi Lasher
step << Hunter
.goto Desolace,24.90,68.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Aboda|r
.stable >> Abandon the |cRXP_ENEMY_Scorpashi Lasher|r and retrieve your regular pet
.target Aboda
step
.goto Desolace,25.80,68.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Taiga|r
.turnin 5381 >> Turn in Hand of Iruxos
.target Taiga Wisemane
step
.goto Desolace,23.40,72.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Drulzegar|r
.turnin 6143 >> Turn in Other Fish to Fry
.target Drulzegar Skraghook
step
#label DesolaceEnd
.goto Desolace,22.70,72.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Mai'Lahii|r
.turnin 6142 >> Turn in Clam Bait
.target Mai'Lahii
step << Mage
.cast 3566 >>|cRXP_WARN_Cast|r |T135765:0|t[Teleport: Thunder Bluff]
.zoneskip Thunder Bluff
.train 3566,3
.itemcount 17031,1 
step
#optional
.goto Desolace,21.60,74.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thalon|r at the end of the dock
.fly Thunder Bluff >>Fly to Thunder Bluff
.target Thalon
.zoneskip Thunder Bluff
.cooldown item,6948,<0
step
.hs >> Hearth to Thunder Bluff
.use 6948
.bindlocation 1638,1
.zoneskip Thunder Bluff
.cooldown item,6948,>0,1
step << !Undead 
.goto Thunder Bluff,34.42,46.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage|r
.accept 1049 >> Accept Compendium of the Fallen
.target Sage Truthseeker
.dungeon SM
step << Druid
.goto Thunder Bluff,76.46,27.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turak|r
.train 9493 >>Train your class spells
.target Turak Runetotem
.xp <36,1
.xp >38,1
step << Druid
#optional
.goto Thunder Bluff,76.46,27.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turak|r
.train 5201 >>Train your class spells
.target Turak Runetotem
.xp <38,1
step << Hunter
.goto Thunder Bluff,59.11,86.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 14303 >>Train your class spells
.target Urek Thunderhorn
.xp <36,1
.xp >38,1
step << Hunter
#optional
.goto Thunder Bluff,59.11,86.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 14320 >>Train your class spells
.target Urek Thunderhorn
.xp <38,1
step << Hunter
.goto Thunder Bluff,54.08,84.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hesuwa|r
.train 24560 >>Train your pet spells
.target Hesuwa Thunderhorn
.xp <36,1
step << Warrior
.goto Thunder Bluff,57.56,85.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ker|r
.train 1680 >>Train your class spells
.target Ker Ragetotem
.xp <36,1
.xp >38,1
step << Warrior
#optional
.goto Thunder Bluff,57.56,85.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ker|r
.train 8820 >> Train your class spells
.target Ker Ragetotem
.xp <38,1
step
#optional
#label DesolaceSkip
step << !Mage
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Orgrimmar >>Fly to Orgrimmar
.target Tal
.zoneskip Thunder Bluff,1
step << !Mage
#completewith next
.goto The Barrens,44.45,59.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Omusa|r
.fly Orgrimmar >>Fly to Orgrimmar
.target Omusa Thunderhorn
.zoneskip The Barrens,1
step << Mage
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8427 >> Train your class spells
.target Pephredo
.xp <36,1
.xp >38,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8413 >> Train your class spells
.target Pephredo
.xp <38,1
step << Mage
.goto Orgrimmar,45.43,56.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Horthus|r|cRXP_BUY_. Buy two or more|r |T134419:0|t[Rune of Teleportation] |cRXP_BUY_from him|r
.collect 17031,2 
.target Horthus
.zoneskip Orgrimmar,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10412 >> Train your class spells
.target Kardris Dreamseeker
.xp <36,1
.xp >38,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10391 >> Train your class spells
.target Kardris Dreamseeker
.xp <38,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
>>|T132273:0|t[Instant Poison Rank 3] |cRXP_WARN_requires 160 skill in Poisons!|r
.train 8691 >> Train your class spells
.target Ormok
.xp <36,1
.xp >38,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8621 >> Train your class spells
.target Ormok
.xp <38,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 2362 >> Train your class spells
.target Mirket
.xp <36,1
.xp >38,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11711 >> Train your class spells
.target Mirket
.xp <38,1
step << Warlock
.goto Orgrimmar,47.52,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurgul|r
.vendor >>Buy any pet upgrades you can afford
.target Kurgul
.zoneskip Orgrimmar,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 6066 >> Train your class spells
.target Ur'kyo
.xp <36,1
.xp >38,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 6078 >> Train your class spells
.target Ur'kyo
.xp <38,1
step
.goto Orgrimmar,22.40,52.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Keldran|r
.turnin 1436 >> Turn in Alliance Relations
.target Keldran
step
.goto Orgrimmar,75.20,34.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.turnin 1184 >> Turn in Parts of the Swarm
.target Belgrom Rockmaul
step
#completewith STVZepp
.destroy 5877 >>|cRXP_WARN_Destroy the|r |T135034:0|t[Cracked Silithid Carapace] |cRXP_WARN_as you no longer need it|r
step << Hunter
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14303 >>Train your class spells
.target Ormak Grimshot
.xp <36,1
.xp >38,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14320 >>Train your class spells
.target Ormak Grimshot
.xp <38,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24560 >>Train your pet spells
.target Xao'tsu
.xp <36,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 1680 >>Train your class spells
.target Grezz Ragefist
.xp <36,1
.xp >38,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 8820 >> Train your class spells
.target Grezz Ragefist
.xp <38,1
step << !Hunter
#ah
.goto Orgrimmar,55.59,62.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Thathung|r
>>|cRXP_BUY_Buy three|r |T134816:0|t[Catseye Elixir] |cRXP_BUY_from the Auction House|r
.collect 10592,3 
.target Auctioneer Thathung
.zoneskip Orgrimmar,1
step
.goto Orgrimmar,54.10,68.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Gryshka|r
.home >> Set your Hearthstone to Orgrimmar
.target Innkeeper Gryshka
.zoneskip Orgrimmar,1
.bindlocation 1637
step
#completewith next
.zone Durotar >> Leave Orgrimmar
.zoneskip Durotar
step
#label STVZepp
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Stranglethorn Vale >>Take the Zeppelin to Stranglethorn Vale
.zoneskip Stranglethorn Vale
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 36-38 Stranglethorn Vale part 1
#next 38-39 Dustwallow Marsh part 1
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Aggro'gosh|r, |cRXP_FRIENDLY_Far Seer Mok'thardin|r, |cRXP_FRIENDLY_Nemeth Hawkeye|r, |cRXP_FRIENDLY_Kin'weelay|r and |cRXP_FRIENDLY_Nimboya|r
.accept 568 >> Accept The Defense of Grom'gol
.target +Commander Aggro'gosh
.goto Stranglethorn Vale,32.20,28.90
.accept 570 >> Accept Mok'thardin's Enchantment
.target +Far Seer Mok'thardin
.goto Stranglethorn Vale,32.12,29.24
.accept 9436 >> Accept Bloodscalp Insight
.target +Nemeth Hawkeye
.goto Stranglethorn Vale,31.96,28.60
.accept 596 >> Accept Bloody Bone Necklaces
.accept 629 >> Accept The Vile Reef
.target +Kin'weelay
.goto Stranglethorn Vale,32.28,27.70
.accept 581 >> Accept Hunt for Yenniku
.accept 638 >> Accept Trollbane
.target +Nimboya
.goto Stranglethorn Vale,32.20,27.80
step << Mage
.goto Stranglethorn Vale,31.49,29.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Thulbek|r
.home >>Set your Hearthstone to Grom'Gol Base Camp
.target Innkeeper Thulbek
.bindlocation 117
.train 3567,3 
step
#completewith next
.subzone 100 >>Travel to Nesingwary's Expedition
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barnil|r, |cRXP_FRIENDLY_Hemet|r, |cRXP_FRIENDLY_Ajeck|r and |cRXP_FRIENDLY_S. J. Erlgadin|r
.accept 583 >> Accept Welcome to the Jungle
.target +Barnil Stonepot
.goto Stranglethorn Vale,35.66,10.53
.turnin 583 >> Turn in Welcome to the Jungle
.turnin 5762 >> Turn in Hemet Nesingwary
.turnin 5763 >> Turn in Hunting in Stranglethorn
.accept 194 >> Accept Raptor Mastery
.target +Hemet Nesingwary Jr.
.goto Stranglethorn Vale,35.66,10.81
.accept 185 >> Accept Tiger Mastery
.target +Ajeck Rouack
.goto Stranglethorn Vale,35.62,10.62
.accept 190 >> Accept Panther Mastery
.target +Sir S. J. Erlgadin
.goto Stranglethorn Vale,35.56,10.55
step
#completewith YoungPanthers
>>Kill |cRXP_ENEMY_River Crocolisks|r along the river. Loot them for their |cRXP_LOOT_Skin|r
.complete 575,1 
.mob River Crocolisk
step
#completewith YoungPanthers
>>Kill |cRXP_ENEMY_Young Stranglethorn Tigers|r
.complete 185,1 
.mob Young Stranglethorn Tiger
step
#label YoungPanthers
.goto Stranglethorn Vale,36.82,10.25,0
.goto Stranglethorn Vale,36.82,10.25,60,0
.goto Stranglethorn Vale,36.66,11.88,60,0
.goto Stranglethorn Vale,37.70,14.44,60,0
.goto Stranglethorn Vale,39.26,14.53,60,0
.goto Stranglethorn Vale,41.01,13.63,60,0
.goto Stranglethorn Vale,41.48,13.18,60,0
.goto Stranglethorn Vale,42.29,13.14,60,0
.goto Stranglethorn Vale,43.06,12.26,60,0
.goto Stranglethorn Vale,42.86,10.49,60,0
.goto Stranglethorn Vale,41.99,10.21,60,0
.goto Stranglethorn Vale,41.04,9.37,60,0
.goto Stranglethorn Vale,40.26,10.04,60,0
.goto Stranglethorn Vale,39.96,11.55,60,0
.goto Stranglethorn Vale,40.42,12.35,60,0
.goto Stranglethorn Vale,40.96,13.65,60,0
>>Kill |cRXP_ENEMY_Young Panthers|r
.complete 190,1 
.mob Young Panther
step << Warrior
#completewith next
.subzone 101 >>Travel to Kurzen's Compound
step << Warrior
#loop
.goto Stranglethorn Vale,43.99,11.95,0
.goto Stranglethorn Vale,44.73,11.46,50,0
.goto Stranglethorn Vale,45.21,11.05,50,0
.goto Stranglethorn Vale,45.19,9.53,50,0
.goto Stranglethorn Vale,44.83,8.60,50,0
.goto Stranglethorn Vale,43.91,8.74,50,0
.goto Stranglethorn Vale,43.50,9.72,50,0
.goto Stranglethorn Vale,43.95,10.50,50,0
.goto Stranglethorn Vale,43.99,11.95,50,0
>>Kill |cRXP_LOOT_Kurzen Medicine Men|r. Loot them for their |T134413:0|t[Liferoot]
>>|cRXP_WARN_You could also buy Liferoot from the Auction House instead|r
>>|cRXP_WARN_Jungle Fighters and Medicine Men share spawns, so you'll have to kill both|r
.collect 3357,8,1712,1 
.mob Kurzen Jungle Fighter
.mob Kurzen Medicine Man
step
#completewith next
>>Kill |cRXP_ENEMY_River Crocolisks|r along the river. Loot them for their |cRXP_LOOT_Skin|r
.complete 575,1 
.mob River Crocolisk
step
#loop
.goto Stranglethorn Vale,38.82,14.20,0
.goto Stranglethorn Vale,38.82,14.20,60,0
.goto Stranglethorn Vale,37.04,13.94,60,0
.goto Stranglethorn Vale,35.58,12.38,60,0
.goto Stranglethorn Vale,33.59,12.20,60,0
.goto Stranglethorn Vale,32.67,10.15,60,0
.goto Stranglethorn Vale,31.42,8.48,60,0
.goto Stranglethorn Vale,33.47,10.25,60,0
.goto Stranglethorn Vale,34.07,11.34,60,0
>>Kill |cRXP_ENEMY_Young Stranglethorn Tigers|r
.complete 185,1 
.mob Young Stranglethorn Tiger
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ajeck|r and |cRXP_FRIENDLY_S. J. Erlgadin|r
.turnin 185 >> Turn in Tiger Mastery
.accept 186 >> Accept Tiger Mastery
.target +Ajeck Rouack
.goto Stranglethorn Vale,35.62,10.62
.turnin 190 >> Turn in Panther Mastery
.accept 191 >> Accept Panther Mastery
.target +Sir S. J. Erlgadin
.goto Stranglethorn Vale,35.56,10.55
step
#completewith RaptorsPart1
>>Kill |cRXP_ENEMY_River Crocolisks|r along the river. Loot them for their |cRXP_LOOT_Skin|r
.complete 575,1 
.mob River Crocolisk
step
#completewith next
.goto Stranglethorn Vale,30.27,10.41,50,0
.goto Stranglethorn Vale,28.59,10.15,50,0
.goto Stranglethorn Vale,28.26,13.36,50,0
.goto Stranglethorn Vale,28.23,16.19,50,0
>>Kill |cRXP_ENEMY_Panthers|r and |cRXP_ENEMY_Stranglethorn Tigers|r
.complete 191,1 
.mob +Panther
.complete 186,1 
.mob +Stranglethorn Tiger
step
#label RaptorsPart1
#loop
.goto Stranglethorn Vale,28.08,15.41,0
.goto Stranglethorn Vale,27.82,16.35,50,0
.goto Stranglethorn Vale,27.18,16.81,50,0
.goto Stranglethorn Vale,26.28,16.70,50,0
.goto Stranglethorn Vale,25.39,16.33,50,0
.goto Stranglethorn Vale,23.71,15.44,50,0
.goto Stranglethorn Vale,25.69,15.71,50,0
.goto Stranglethorn Vale,26.61,15.85,50,0
.goto Stranglethorn Vale,27.24,15.14,50,0
.goto Stranglethorn Vale,27.80,14.33,50,0
.goto Stranglethorn Vale,28.08,15.41,50,0
>>Kill |cRXP_ENEMY_Stranglethorn Raptors|r
.complete 194,1 
.mob Stranglethorn Raptor
step
#loop
.goto Stranglethorn Vale,28.13,9.53,0
.goto Stranglethorn Vale,30.49,15.11,50,0
.goto Stranglethorn Vale,30.33,10.40,50,0
.goto Stranglethorn Vale,28.13,9.53,50,0
.goto Stranglethorn Vale,28.16,12.74,50,0
.goto Stranglethorn Vale,28.07,15.81,50,0
>>Kill |cRXP_ENEMY_Panthers|r and |cRXP_ENEMY_Stranglethorn Tigers|r
.complete 191,1 
.mob +Panther
.complete 186,1 
.mob +Stranglethorn Tiger
step
#completewith NesingwaryTurnIns
.subzone 100 >>Travel to Nesingwary's Expedition
step
#label NesingwaryTurnIns
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_S. J. Erlgadin|r, |cRXP_FRIENDLY_Ajeck|r and |cRXP_FRIENDLY_Hemet|r
.turnin 191 >> Turn in Panther Mastery
.accept 192 >> Accept Panther Mastery
.target +Sir S. J. Erlgadin
.goto Stranglethorn Vale,35.55,10.55
.turnin 186 >> Turn in Tiger Mastery
.accept 187 >> Accept Tiger Mastery
.target +Ajeck Rouack
.goto Stranglethorn Vale,35.61,10.62
.turnin 194 >> Turn in Raptor Mastery
.accept 195 >> Accept Raptor Mastery
.target +Hemet Nesingwary Jr.
.goto Stranglethorn Vale,35.66,10.81
step
#loop
.goto Stranglethorn Vale,39.8,14.4,0
.goto Stranglethorn Vale,32.4,8.8,90,0
.goto Stranglethorn Vale,34.4,8.2,90,0
.goto Stranglethorn Vale,36.8,10.4,90,0
.goto Stranglethorn Vale,39.8,11.4,90,0
.goto Stranglethorn Vale,39.8,14.4,90,0
>>Kill |cRXP_ENEMY_River Crocolisks|r along the river. Loot them for their |cRXP_LOOT_Skin|r
.complete 575,1 
.mob River Crocolisk
step
#completewith next
>>Kill |cRXP_ENEMY_Elder Stranglethorn Tigers|r
.complete 187,1 
.mob Elder Stranglethorn Tiger
step
#loop
.goto Stranglethorn Vale,33.90,15.60,0
.goto Stranglethorn Vale,33.20,13.70,50,0
.goto Stranglethorn Vale,28.80,19.60,50,0
.goto Stranglethorn Vale,29.80,19.40,50,0
.goto Stranglethorn Vale,30.60,18.90,50,0
.goto Stranglethorn Vale,33.90,15.60,50,0
>>Kill |cRXP_ENEMY_Bloodscalp Trolls|r. Loot them for their |cRXP_LOOT_Tusks|r, |cRXP_LOOT_Ears|r and |cRXP_LOOT_Necklaces|r
>>Kill |cRXP_ENEMY_Bloodscalp Shamans|r. Loot them for a |cRXP_LOOT_Bloodscalp Totem|r
.complete 581,1 
.mob +Bloodscalp Warrior
.mob +Bloodscalp Axe Thrower
.mob +Bloodscalp Shaman
.complete 189,1 
.disablecheckbox
.complete 596,1 
.disablecheckbox
.complete 9436,1 
.mob +Bloodscalp Shaman
step
#loop
.goto Stranglethorn Vale,32.10,15.80,0
.goto Stranglethorn Vale,31.40,18.40,50,0
.goto Stranglethorn Vale,31.80,20.00,50,0
.goto Stranglethorn Vale,34.20,17.60,50,0
.goto Stranglethorn Vale,32.10,15.80,50,0
>>Kill |cRXP_ENEMY_Elder Stranglethorn Tigers|r
.complete 187,1 
.mob Elder Stranglethorn Tiger
step
#loop
.goto Stranglethorn Vale,31.90,20.90,0
.goto Stranglethorn Vale,30.40,24.70,50,0
.goto Stranglethorn Vale,32.50,23.40,50,0
.goto Stranglethorn Vale,34.10,25.50,50,0
.goto Stranglethorn Vale,36.00,26.80,50,0
.goto Stranglethorn Vale,38.90,25.10,50,0
.goto Stranglethorn Vale,38.10,28.10,50,0
.goto Stranglethorn Vale,31.90,20.90,50,0
>>Kill |cRXP_ENEMY_Lashtail Raptors|r
>>|cRXP_WARN_Be careful. |cRXP_ENEMY_Lashtail Raptors|r can stun and|r |T132343:0|t[Disarm] |cRXP_WARN_you|r << Rogue/Warrior/Shaman/Pala
>>|cRXP_WARN_Be careful. |cRXP_ENEMY_Lashtail Raptors|r can stun you|r << !Rogue !Warrior !Shaman !Pala
.complete 568,1 
.complete 195,1 
.mob Lashtail Raptor
step << skip 
#optional
#completewith GGvisit2
.hs >> Hearth to Grom'gol Base Camp
.use 6948
.bindlocation 117,1
.subzoneskip 117
.cooldown item,6948,>0,1
step
#completewith GGvisit2
.subzone 117 >>Return to Grom'Gol Base Camp

step
.goto Stranglethorn Vale,32.2,27.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nimboya|r
.turnin 581 >> Turn in Hunt for Yenniku
.accept 582 >> Accept Headhunting
.target Nimboya
step
.goto Stranglethorn Vale,31.96,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nemeth Hawkeye|r
.turnin 9436 >> Turn in Bloodscalp Insight
.accept 9457 >> Accept An Unusual Patron
.target Nemeth Hawkeye
step
.goto Stranglethorn Vale,32.17,28.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Aggro'gosh|r
.turnin 568 >> Turn in The Defense of Grom'gol
.accept 569 >> Accept The Defense of Grom'gol
.target Commander Aggro'gosh
step << Hunter
.goto Stranglethorn Vale,31.55,27.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uthok|r
>>|cRXP_BUY_Buy|r |T132382:0|t[Razor Arrows] |cRXP_BUY_from him|r
.collect 3030,2600,629,1 
.target Uthok
step << Hunter
.goto Stranglethorn Vale,31.23,28.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kragg|r
.train 14303 >>Train your class spells
.target Kragg
.xp <36,1
.xp >38,1
step << Hunter
#optional
.goto Stranglethorn Vale,31.23,28.68
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kragg|r
.train 14320 >>Train your class spells
.target Kragg
.xp <38,1
step
#optional
#label GGvisit2
step
#completewith next << Warlock/Druid/Shaman
#completewith TailFins << !Warlock !Druid !Shaman
.goto Stranglethorn Vale,24.83,23.04
>>Loot the |cRXP_PICK_Gri'lek the Wanderer|r for the |cRXP_LOOT_Tablet Shard|r |cRXP_WARN_underwater|r
.complete 629,1 
step
#optional
#loop
.goto Stranglethorn Vale,24.92,23.59,0
.goto Stranglethorn Vale,24.92,23.59,50,0
.goto Stranglethorn Vale,23.40,24.49,50,0
.goto Stranglethorn Vale,23.71,25.90,50,0
.goto Stranglethorn Vale,25.46,25.61,50,0
.goto Stranglethorn Vale,25.31,24.59,50,0
.goto Stranglethorn Vale,26.80,26.00,50,0
.use 5996 >>|cRXP_WARN_Drink an|r |T134797:0|t[Elixir of Water Breathing] << !Warlock !Druid !Shaman
>>Kill |cRXP_ENEMY_Saltscale Murlocs|r. Loot them for their |cRXP_LOOT_Tail Fins|r
.complete 1107,1 
.mob Saltscale Forager
.mob Saltscale Warrior
.mob Saltscale Hunter
.mob Saltscale Oracle
.mob Saltscale Tide Lord
.itemcount 5996,1 << !Warlock !Druid !Shaman
step << !Warlock !Druid !Shaman
#label TailFins
#loop
.goto Stranglethorn Vale,24.92,23.59,0
.goto Stranglethorn Vale,24.92,23.59,50,0
.goto Stranglethorn Vale,23.40,24.49,50,0
.goto Stranglethorn Vale,23.71,25.90,50,0
.goto Stranglethorn Vale,25.46,25.61,50,0
.goto Stranglethorn Vale,25.31,24.59,50,0
.goto Stranglethorn Vale,26.80,26.00,50,0
>>Kill |cRXP_ENEMY_Saltscale Murlocs|r. Loot them for their |cRXP_LOOT_Tail Fins|r
.complete 1107,1 
.mob Saltscale Forager
.mob Saltscale Warrior
.mob Saltscale Hunter
.mob Saltscale Oracle
.mob Saltscale Tide Lord
.aura -7178
step
.goto Stranglethorn Vale,24.83,23.04
>>Loot the |cRXP_PICK_Gri'lek the Wanderer|r for the |cRXP_LOOT_Tablet Shard|r |cRXP_WARN_underwater|r
.complete 629,1 
step
.goto Stranglethorn Vale,19.8,22.6
.use 23680 >>|cRXP_WARN_Use the|r |T136232:0|t[Gift of Naias] |cRXP_WARN_at the altar to summon|r |cRXP_ENEMY_Naias|r
>>Kill and loot him for his |cRXP_LOOT_Heart|r
.complete 9457,1 
.mob Naias
.isQuestTurnedIn 568
step
#loop
.goto Stranglethorn Vale,27.37,18.62,0
.goto Stranglethorn Vale,25.94,18.20,50,0
.goto Stranglethorn Vale,24.84,17.26,50,0
.goto Stranglethorn Vale,23.22,16.89,50,0
.goto Stranglethorn Vale,23.21,18.35,50,0
.goto Stranglethorn Vale,24.80,18.98,50,0
.goto Stranglethorn Vale,26.97,19.78,50,0
.goto Stranglethorn Vale,27.37,18.62,50,0
>>Kill |cRXP_ENEMY_Crystal Spine Basilisks|r. Loot them for their |cRXP_LOOT_Crystal Shards|r
>>|cRXP_WARN_You have to go back and forth here forcing dynamic respawns|r
.complete 605,1 
.mob Crystal Spine Basilisk
step << Warrior
#loop
.goto Stranglethorn Vale,20.38,13.94,0
.goto Stranglethorn Vale,20.38,13.94,50,0
.goto Stranglethorn Vale,20.81,12.74,50,0
.goto Stranglethorn Vale,21.00,10.81,50,0
.goto Stranglethorn Vale,20.06,11.88,50,0
.goto Stranglethorn Vale,19.36,11.81,50,0
.goto Stranglethorn Vale,19.67,13.31,50,0
>>Kill |cRXP_ENEMY_Bloodscalp Trolls|r. Loot them for their |cRXP_LOOT_Ears|r, |cRXP_LOOT_Heads|r, |cRXP_LOOT_Necklaces|r and |cRXP_LOOT_Tusks|r
>>|T133730:0|t[|cRXP_LOOT_Shrunken Heads|r] |cRXP_WARN_only drop from|r |cRXP_ENEMY_Bloodscalp Headhunters|r
.complete 189,1 
.mob +Bloodscalp Witch Doctor
.mob +Bloodscalp Berserker
.mob +Bloodscalp Headhunter
.complete 582,1 
.mob +Bloodscalp Headhunter
.complete 596,1 
.mob +Bloodscalp Witch Doctor
.mob +Bloodscalp Berserker
.mob +Bloodscalp Headhunter
.complete 1712,2 
.mob +Bloodscalp Witch Doctor
.mob +Bloodscalp Berserker
.mob +Bloodscalp Headhunter
step << !Warrior
#loop
.goto Stranglethorn Vale,20.38,13.94,0
.goto Stranglethorn Vale,20.38,13.94,50,0
.goto Stranglethorn Vale,20.81,12.74,50,0
.goto Stranglethorn Vale,21.00,10.81,50,0
.goto Stranglethorn Vale,20.06,11.88,50,0
.goto Stranglethorn Vale,19.36,11.81,50,0
.goto Stranglethorn Vale,19.67,13.31,50,0
>>Kill |cRXP_ENEMY_Bloodscalp Trolls|r. Loot them for their |cRXP_LOOT_Ears|r, |cRXP_LOOT_Heads|r and |cRXP_LOOT_Necklaces|r
>>|T133730:0|t[Shrunken Head] |cRXP_WARN_only drop from|r |cRXP_ENEMY_Bloodscalp Headhunters|r
.complete 189,1 
.mob +Bloodscalp Witch Doctor
.mob +Bloodscalp Berserker
.mob +Bloodscalp Headhunter
.complete 582,1 
.mob +Bloodscalp Headhunter
.complete 596,1 
.mob +Bloodscalp Witch Doctor
.mob +Bloodscalp Berserker
.mob +Bloodscalp Headhunter
step << Mage
#optional
#completewith GGvisit3
.hs >> Hearth to Grom'gol Base Camp
.use 6948
.bindlocation 117,1
.subzoneskip 117
.cooldown item,6948,>0,1
step
#completewith GGvisit3
.subzone 117 >>Return to Grom'Gol Base Camp
.bindlocation 1637,1 << Mage
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nimboya|r and |cRXP_FRIENDLY_Kin'weelay|r
.turnin 582 >> Turn in Headhunting
.target +Nimboya
.goto Stranglethorn Vale,32.16,27.72
.turnin 596 >> Turn in Bloody Bone Necklaces
.turnin 629 >> Turn in The Vile Reef
.target +Kin'weelay
.goto Stranglethorn Vale,32.28,27.70
step
#label GGvisit3
.goto Stranglethorn Vale,31.96,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nemeth Hawkeye|r
.turnin 9457 >> Turn in An Unusual Patron
.target Nemeth Hawkeye
step
#completewith next
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fly Booty Bay >> Fly to Booty Bay
.target Thysta
.subzoneskip 35
step
.goto Stranglethorn Vale,28.29,77.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drizzlik|r
.turnin 575 >> Turn in Supply and Demand
.accept 577 >> Accept Some Assembly Required
.target Drizzlik
step
.goto Stranglethorn Vale,28.14,78.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Glyx|r
.vendor >> |cRXP_BUY_Buy|r |T134832:0|t[Greater Healing Potions] |cRXP_BUY_from him if they're up|r
.target Glyx Brewright
.subzoneskip 35,1
step
.goto Stranglethorn Vale,26.87,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Grom'gol >> Fly to Grom'gol Base Camp
.target Gringer
.subzoneskip 35,1
step
#completewith MoshOgg
.goto Stranglethorn Vale,36.87,34.92,0
>>Kill |cRXP_ENEMY_Shadowmaw Panthers|r and |cRXP_ENEMY_Stranglethorn Tigresses|r |cRXP_WARN_across the river|r
>>|cRXP_WARN_Only do this when waiting for |cRXP_ENEMY_Mosh'Ogg Ogre|r respawns|r
>>|cRXP_ENEMY_Shadowmaw Panthers|r |cRXP_WARN_are stealthed mobs. Search any vacant areas|r
.complete 570,1 
.unitscan +Shadowmaw Panther
.complete 192,1 
.unitscan +Shadowmaw Panther
.complete 570,2 
.mob +Stranglethorn Tigress
step
#label MoshOgg
#loop
.goto Stranglethorn Vale,36.49,31.61,0
.goto Stranglethorn Vale,37.28,30.96,50,0
.goto Stranglethorn Vale,38.04,29.61,50,0
.goto Stranglethorn Vale,36.88,29.69,50,0
.goto Stranglethorn Vale,35.60,30.62,50,0
.goto Stranglethorn Vale,36.49,31.61,50,0
>>Kill |cRXP_ENEMY_Mosh'Ogg Brutes|r and |cRXP_ENEMY_Mosh'Ogg Witch Doctors|r
>>|cRXP_WARN_There are not enough |cRXP_ENEMY_Mosh'Ogg Brutes|r so you will have to wait for respawns at least once|r
.complete 569,1 
.mob +Mosh'Ogg Brute
.complete 569,2 
.mob +Mosh'Ogg Witch Doctor
step
#loop
.goto Stranglethorn Vale,42.6,17.2,0
.goto Stranglethorn Vale,38.0,32.4,50,0
.goto Stranglethorn Vale,38.8,28.4,50,0
.goto Stranglethorn Vale,40.4,24.4,50,0
.goto Stranglethorn Vale,40.4,22.8,50,0
.goto Stranglethorn Vale,39.4,21.6,50,0
.goto Stranglethorn Vale,39.8,16.6,50,0
.goto Stranglethorn Vale,42.6,17.2,50,0
>>Kill |cRXP_ENEMY_Snapjaw Crocolisks|r along the river. Loot them for their |cRXP_LOOT_Skin|r
.complete 577,1 
.mob Snapjaw Crocolisk
step
#completewith CozzleBl
>>Kill |cRXP_ENEMY_Venture Co. Geologists|r. Loot them for their |cRXP_LOOT_Crystals|r
.complete 213,1 
.mob Venture Co. Geologist
step
.goto Stranglethorn Vale,42.74,18.04,40,0
.goto Stranglethorn Vale,42.10,18.33,12,0
.goto Stranglethorn Vale,42.29,18.98,12,0
.goto Stranglethorn Vale,42.51,18.82,12,0
.goto Stranglethorn Vale,42.66,18.36
>>Climb to the oil rig's top level, then kill |cRXP_ENEMY_Foreman Cozzle|r. Loot him for his |cRXP_LOOT_Key|r
.collect 5851,1 
.unitscan Foreman Cozzle
.isOnQuest 1182
step
#completewith next
.goto Stranglethorn Vale,43.47,20.33,6 >>Enter the house
step
#label CozzleBl
.goto Stranglethorn Vale,43.33,20.33
>>Loot |cRXP_PICK_Cozzle's Footlocker|r for the |cRXP_LOOT_Fuel Regulator Blueprints|r
.complete 1182,1 
step
#loop
.goto Stranglethorn Vale,36.49,31.61,0
.goto Stranglethorn Vale,37.28,30.96,50,0
.goto Stranglethorn Vale,38.04,29.61,50,0
.goto Stranglethorn Vale,36.88,29.69,50,0
.goto Stranglethorn Vale,35.60,30.62,50,0
.goto Stranglethorn Vale,36.49,31.61,50,0
>>Return to the Mizjah Ruins and finish killing |cRXP_ENEMY_Mosh'Ogg Brutes|r and |cRXP_ENEMY_Mosh'Ogg Witch Doctors|r
.complete 569,1 
.mob +Mosh'Ogg Brute
.complete 569,2 
.mob +Mosh'Ogg Witch Doctor
step
#loop
.goto Stranglethorn Vale,43.26,21.05,0
.goto Stranglethorn Vale,42.58,22.00,50,0
.goto Stranglethorn Vale,43.78,22.80,50,0
.goto Stranglethorn Vale,44.42,23.55,50,0
.goto Stranglethorn Vale,45.38,23.28,50,0
.goto Stranglethorn Vale,46.29,23.45,50,0
.goto Stranglethorn Vale,46.26,21.94,50,0
.goto Stranglethorn Vale,47.02,20.02,50,0
.goto Stranglethorn Vale,46.67,19.13,50,0
.goto Stranglethorn Vale,46.34,18.00,50,0
.goto Stranglethorn Vale,45.27,17.76,50,0
.goto Stranglethorn Vale,44.89,16.79,50,0
.goto Stranglethorn Vale,44.44,16.19,50,0
.goto Stranglethorn Vale,43.60,15.80,50,0
.goto Stranglethorn Vale,43.39,17.63,50,0
.goto Stranglethorn Vale,43.65,19.32,50,0
.goto Stranglethorn Vale,43.26,21.05,50,0
>>Finish killing |cRXP_ENEMY_Venture Co. Geologists|r. Loot them for their |cRXP_LOOT_Crystals|r
.complete 213,1 
.mob Venture Co. Geologist
step
#loop
.goto Stranglethorn Vale,43.26,21.05,0
.goto Stranglethorn Vale,42.58,22.00,50,0
.goto Stranglethorn Vale,43.78,22.80,50,0
.goto Stranglethorn Vale,44.42,23.55,50,0
.goto Stranglethorn Vale,45.38,23.28,50,0
.goto Stranglethorn Vale,46.29,23.45,50,0
.goto Stranglethorn Vale,46.26,21.94,50,0
.goto Stranglethorn Vale,47.02,20.02,50,0
.goto Stranglethorn Vale,46.67,19.13,50,0
.goto Stranglethorn Vale,46.34,18.00,50,0
.goto Stranglethorn Vale,45.27,17.76,50,0
.goto Stranglethorn Vale,44.89,16.79,50,0
.goto Stranglethorn Vale,44.44,16.19,50,0
.goto Stranglethorn Vale,43.60,15.80,50,0
.goto Stranglethorn Vale,43.39,17.63,50,0
.goto Stranglethorn Vale,43.65,19.32,50,0
.goto Stranglethorn Vale,43.26,21.05,50,0
.xp 36+17000 >> Grind to 17000+/58700 xp
.mob Venture Co. Geologist
step
#completewith ShadowPanthers
>>Kill |cRXP_ENEMY_Stranglethorn Tigresses|r. Loot them for a |cRXP_LOOT_Pristine Tigress Fang|r
.complete 570,2 
.mob Stranglethorn Tigress
step << !Hunter
#ah
#completewith next
.aura 12608 >>|cRXP_WARN_Consume your|r |T134816:0|t[Catseye Elixir] |cRXP_WARN_to find the|r |cRXP_ENEMY_Shadowmaw Panthers|r |cRXP_WARN_more easily|r
.use 10592
.itemcount 10592,1
step << Hunter
#completewith next
.cast 19885 >>|cRXP_WARN_Cast|r |T132320:0|t[Track Hidden] |cRXP_WARN_to find the|r |cRXP_ENEMY_Shadowmaw Panthers|r |cRXP_WARN_more easily|r
step
#label ShadowPanthers
#loop
.goto Stranglethorn Vale,48.82,23.91,0
.goto Stranglethorn Vale,47.64,22.47,40,0
.goto Stranglethorn Vale,48.08,23.54,40,0
.goto Stranglethorn Vale,48.82,23.91,40,0
.goto Stranglethorn Vale,49.58,25.41,40,0
.goto Stranglethorn Vale,50.29,24.76,40,0
.goto Stranglethorn Vale,50.25,23.37,40,0
.goto Stranglethorn Vale,50.26,21.44,40,0
.goto Stranglethorn Vale,49.29,19.84,40,0
.goto Stranglethorn Vale,48.33,19.99,40,0
.goto Stranglethorn Vale,47.75,21.21,40,0
.goto Stranglethorn Vale,47.64,22.47,40,0
>>Kill |cRXP_ENEMY_Shadowmaw Panthers|r. Loot them for their |cRXP_LOOT_Claws|r
>>|cRXP_WARN_These are stealthed mobs. Search any vacant areas|r
.complete 570,1 
.complete 192,1 
.unitscan Shadowmaw Panther
step
#loop
.goto Stranglethorn Vale,48.82,23.91,0
.goto Stranglethorn Vale,47.64,22.47,40,0
.goto Stranglethorn Vale,48.08,23.54,40,0
.goto Stranglethorn Vale,48.82,23.91,40,0
.goto Stranglethorn Vale,49.58,25.41,40,0
.goto Stranglethorn Vale,50.29,24.76,40,0
.goto Stranglethorn Vale,50.25,23.37,40,0
.goto Stranglethorn Vale,50.26,21.44,40,0
.goto Stranglethorn Vale,49.29,19.84,40,0
.goto Stranglethorn Vale,48.33,19.99,40,0
.goto Stranglethorn Vale,47.75,21.21,40,0
.goto Stranglethorn Vale,47.64,22.47,40,0
>>Kill |cRXP_ENEMY_Stranglethorn Tigresses|r. Loot them for a |cRXP_LOOT_Pristine Tigress Fang|r
.complete 570,2 
.mob Stranglethorn Tigress
step
#completewith NesingTurnins3
.subzone 100 >>Travel to Nesingwary's Expedition
step
#label NesingTurnins3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_S. J. Erlgadin|r, |cRXP_FRIENDLY_Ajeck|r and |cRXP_FRIENDLY_Hemet|r
.turnin 192 >> Turn in Panther Mastery
.accept 193 >> Accept Panther Mastery
.target +Sir S. J. Erlgadin
.goto Stranglethorn Vale,35.55,10.55
.turnin 187 >> Turn in Tiger Mastery
.accept 188 >> Accept Tiger Master
.target +Ajeck Rouack
.goto Stranglethorn Vale,35.61,10.62
.turnin 195 >> Turn in Raptor Mastery
.accept 196 >> Accept Raptor Mastery
.target +Hemet Nesingwary Jr.
.goto Stranglethorn Vale,35.66,10.81
step
.goto Stranglethorn Vale,32.2,17.4
>>Kill |cRXP_ENEMY_Sin'Dall|r. Loot her for her |cRXP_LOOT_Paw|r
>>|cRXP_WARN_Sin'Dall is either atop the plateau, or patrolling its base|r
.complete 188,1 
.unitscan Sin'Dall
step
.goto Stranglethorn Vale,35.61,10.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ajeck|r
.turnin 188 >> Turn in Tiger Mastery
.target Ajeck Rouack
step << Mage
#optional
#completewith GGvisit3
.hs >> Hearth to Grom'gol Base Camp
.use 6948
.bindlocation 117,1
.subzoneskip 117
.cooldown item,6948,>0,1
step
#completewith GGvisit3
.subzone 117 >>Return to Grom'Gol Base Camp
.bindlocation 1637,1 << Mage
step
.goto Stranglethorn Vale,32.17,28.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Aggro'gosh|r
.turnin 569 >> Turn in The Defense of Grom'gol
.target Commander Aggro'gosh
step
.goto Stranglethorn Vale,32.12,29.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.turnin 570 >> Turn in Mok'thardin's Enchantment
.accept 572 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
#label GGvisit3
#completewith BBHealingPots
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fly Booty Bay >> Fly to Booty Bay
.target Thysta
.subzoneskip 35
step
.goto Stranglethorn Vale,27.23,76.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Baron Revilgaz|r
.turnin 1182 >> Turn in Goblin Sponsorship
.accept 1183 >> Accept Goblin Sponsorship
.target Baron Revilgaz
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kebok|r and |cRXP_FRIENDLY_Krazek|r
.turnin 189 >> Turn in Bloodscalp Ears
.turnin 213 >> Turn in Hostile Takeover
.target +Kebok
.goto Stranglethorn Vale,27.0,77.13
.turnin 201 >> Turn in Investigate the Camp
.target +Krazek
.goto Stranglethorn Vale,26.95,77.21
step
.goto Stranglethorn Vale,27.12,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank Fizzlebub|r on the inn's lowest level
.turnin 605 >> Turn in Singing Blue Shards
.accept 600 >> Accept Venture Company Mining
.target Crank Fizzlebub
step
.goto Stranglethorn Vale,26.95,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kebok|r on the inn's top floor
.accept 209 >> Accept Skullsplitter Tusks
.target Kebok
step << Rogue
.goto Stranglethorn Vale,26.82,77.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ian|r on the second floor of the inn
.train 8691 >> Train your class spells
>>|T132273:0|t[Instant Poison Rank 3] |cRXP_WARN_requires 160 skill in Poisons!|r
.target Ian Strom
.xp <36,1
.xp >38,1
step << Rogue
#optional
.goto Stranglethorn Vale,26.82,77.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ian|r on the second floor of the inn
.train 8621 >> Train your class spells
>>|T132273:0|t[Instant Poison Rank 3] |cRXP_WARN_requires 160 skill in Poisons!|r
.target Ian Strom
.xp <38,1
step
#label BBturnins2
.goto Stranglethorn Vale,28.29,77.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drizzlik|r
.turnin 577 >> Turn in Some Assembly Required
.accept 628 >> Accept Excelsior
.target Drizzlik
step
#label BBHealingPots
.goto Stranglethorn Vale,28.14,78.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Glyx|r
.vendor >> |cRXP_BUY_Buy|r |T134832:0|t[Greater Healing Potions] |cRXP_BUY_from him if they're up|r
.target Glyx Brewright
.subzoneskip 35,1
step << Druid
#completewith DruidTraining2
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9493 >> Train your class spells
.target Loganaar
.xp <36,1
.xp >38,1
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 5201 >> Train your class spells
.target Loganaar
.xp <36,1
.xp >38,1
step << Druid
#label DruidTraining2
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9634 >> Train your class spells
.target Loganaar
.xp <40,1
step << Mage
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
.train 3567,3
step
#optional << Mage
#completewith next << !Mage
.hs >> Hearth to Orgrimmar
.use 6948
.bindlocation 1637,1
.zoneskip Orgrimmar
.train 3567,1 << Mage
step << !Mage
.goto Orgrimmar,54.65,67.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barkeep Morag|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Barkeep Morag
.isQuestAvailable 1273
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8427 >> Train your class spells
.target Pephredo
.xp <36,1
.xp >38,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8413 >> Train your class spells
.target Pephredo
.xp <38,1
.xp >40,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8423 >> Train your class spells
.target Pephredo
.xp <40,1
step << Mage
.goto Orgrimmar,38.70,85.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r at the top of the hut
.train 11417 >> Train |T135744:0|t[Portal: Orgrimmar]
.target Thuul
.xp <40,1
step << Mage
#optional
.goto Orgrimmar,45.43,56.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Horthus|r|cRXP_BUY_. Buy two or more|r |T134419:0|t[Rune of Teleportation] |cRXP_BUY_and optionally one or more|r |T134421:0|t[Rune of Portals] |cRXP_BUY_from him|r
.collect 17031,2 
.collect 17032,1 
.target Horthus
.xp <40,1
step << Mage
.goto Orgrimmar,45.43,56.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Horthus|r|cRXP_BUY_. Buy two or more|r |T134419:0|t[Rune of Teleportation] |cRXP_BUY_from him|r
.collect 17031,2 
.target Horthus
.xp >40,1
step
.goto Orgrimmar,49.57,69.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karus|r
.bankdeposit 2725,2728,2735,2730,2742,2732,2748,2751,2734,2740,2749,2745,2738,2744,2750 >>Deposit all your |T134332:0|t[Green Hills of Stranglethorn Pages] onto the bank
.target Karus
.isQuestAvailable 1273
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10412 >> Train your class spells
.target Kardris Dreamseeker
.xp <36,1
.xp >38,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10391 >> Train your class spells
.target Kardris Dreamseeker
.xp <38,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10391 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8691 >> Train your class spells
>>|T132273:0|t[Instant Poison Rank 3] |cRXP_WARN_requires 160 skill in Poisons!|r
.target Ormok
.xp <36,1
.xp >38,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8621 >> Train your class spells
.target Ormok
.xp <38,1
.xp >40,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <40,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 2362 >> Train your class spells
.target Mirket
.xp <36,1
.xp >38,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11711 >> Train your class spells
.target Mirket
.xp <38,1
.xp >40,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11665 >> Train your class spells
.target Mirket
.xp <40,1
step << Warlock
.goto Orgrimmar,47.52,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurgul|r
.vendor >>Buy any pet upgrades you can afford
.target Kurgul
.zoneskip Orgrimmar,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 1680 >>Train your class spells
.target Grezz Ragefist
.xp <36,1
.xp >38,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 8820 >> Train your class spells
.target Grezz Ragefist
.xp <38,1
.xp >40,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 20660 >> Train your class spells
.target Grezz Ragefist
.xp <40,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14303 >>Train your class spells
.target Ormak Grimshot
.xp <36,1
.xp >38,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14320 >>Train your class spells
.target Ormak Grimshot
.xp <38,1
.xp >40,1
step << Hunter
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14324 >>Train your class spells
.target Ormak Grimshot
.xp <40,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24560 >>Train your pet spells
.target Xao'tsu
.xp <36,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 6066 >> Train your class spells
.target Ur'kyo
.xp <36,1
.xp >38,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 6078 >> Train your class spells
.target Ur'kyo
.xp <38,1
.xp >40,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 1006 >> Train your class spells
.target Ur'kyo
.xp <40,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 10299 >> Train your class spells
.target Master Pyreanor
.xp <36,1
.xp >38,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 3472 >> Train your class spells
.target Master Pyreanor
.xp <38,1
.xp >40,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 5589 >> Train your class spells
.target Master Pyreanor
.xp <40,1
step << Orc !Warlock
#optional
.goto Orgrimmar,69.40,13.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kildar|r and |cRXP_FRIENDLY_Ogunaro|r
.train 825 >>Train |T136103:0|t[Wolf Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132224:0|t[|cFF0070FFWolf|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Kildar
.target Ogunaro Wolfrunner
step << Troll
#optional
#completewith next
.subzone 367 >> Travel to Sen'Jin Village
.xp <30,1
.money <38
.skill riding,75,1
step << Troll
#optional
.goto Durotar,55.28,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xar'Ti|r and |cRXP_FRIENDLY_Zjolnir|r
.train 10861 >>Train |T136103:0|t[Raptor Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132253:0|t[|cFF0070FFRaptor|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Xar'Ti
.target Zjolnir
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 38-39 Dustwallow Marsh part 1
#next 39-41 Hillsbrad/Alterac/Arathi part 2
step
#completewith BlackShield1
.goto Orgrimmar,45.120,63.889
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Doras|r
.fly Brackenwall Village >>Fly to Brackenwall Village
.target Doras
.zoneskip Dustwallow Marsh
step
#completewith BlackShield1
.subzone 403 >>Travel to the Shady Rest Inn at the Dustwallow/Barrens border
step
.goto Dustwallow Marsh,29.7,47.6
>>Click the |cRXP_PICK_Suspicious Hoofprints|r on the ground
.accept 1268 >> Accept Suspicious Hoofprints
step
.goto Dustwallow Marsh,29.83,48.24
>>Click the |cRXP_PICK_Theramore Guard Badge|r on the plank of wood on the ground
.accept 1269 >> Accept Lieutenant Paval Reethe
step
#label BlackShield1
.goto Dustwallow Marsh,29.63,48.60
>>Click the |cRXP_PICK_Black Shield|r above the fireplace
.accept 1251 >> Accept The Black Shield
step
.goto Dustwallow Marsh,35.15,38.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mudcrush|r
.accept 1177 >> Accept Hungry!
.target Mudcrush Durtfeet
step
.goto Dustwallow Marsh,35.57,31.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shardi|r
.fp Brackenwall >> Get the Brackenwall Village Flight Path
.target Shardi
.subzoneskip 496,1
step
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.accept 1201 >> Accept Theramore Spies
.target Nazeer Bloodpike
step << skip 
.goto Dustwallow Marsh,35.9,31.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Balandar Brightstar|r
.accept 9437 >> Accept Twilight of the Dawn Runner
.target Balandar Brightstar
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 1268 >> Turn in Suspicious Hoofprints
.turnin 1269 >> Turn in Lieutenant Paval Reethe
.turnin 1251 >> Turn in The Black Shield
.accept 1321 >> Accept The Black Shield
.target Krog
step
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.accept 11225 >> Accept The Hermit of Witch Hill
.target Draz'Zilb
step
.goto Dustwallow Marsh,36.50,30.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Do'gol|r
.turnin 1321 >> Turn in The Black Shield
.accept 1322 >> Accept The Black Shield
.target Do'gol
step
#completewith Infiltrator
>>Kill |cRXP_ENEMY_Darkfang Spiders|r. Loot them for their |cRXP_LOOT_Venom Sacs|r
>>|cRXP_ENEMY_Bloodfen Raptors|r |cRXP_WARN_share spawns with |cRXP_ENEMY_Darkfang spiders|r, so kill them too if needed|r
.complete 1322,1 
.mob Darkfang Lurker
.mob Darkfang Spider
.mob Darkfang Creeper
.mob Darkfang Venomspitter
step
.goto Dustwallow Marsh,40.96,36.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogron|r, then start his escort quest
>>|cRXP_WARN_Be careful, this quest is hard as you must kill four mobs simultaneously. Find a group if needed, or skip this quest|r
.accept 1273,1 >> Accept Questioning Reethe
.target Ogron
step
.goto Dustwallow Marsh,42.50,38.00
>>Four mobs will spawn when you reach the camp. They will attack after their roleplay
>>|cRXP_WARN_Let|r |cRXP_FRIENDLY_Ogron|r |cRXP_WARN_aggro one and use your cooldowns to kill the other three|r
.complete 1273,1 
.target Ogron
.isOnQuest 1273
step
#completewith next
.goto Dustwallow Marsh,42.06,26.03,0
.goto Dustwallow Marsh,39.63,23.85,0
.goto Dustwallow Marsh,38.94,22.44,0
.goto Dustwallow Marsh,38.01,25.50,0
.goto Dustwallow Marsh,37.63,27.60,0
.goto Dustwallow Marsh,38.03,33.99,0
.goto Dustwallow Marsh,38.02,37.40,0
.goto Dustwallow Marsh,40.67,35.22,0
>>Kill any |cRXP_ENEMY_Theramore Infiltrator|r you encounter
>>|cRXP_WARN_They are stealthed|r << !Hunter
>>|cRXP_WARN_They are stealthed! Cast|r |T132320:0|t[Track Hidden] |cRXP_WARN_to find them more easily|r << Hunter
.complete 1201,1 
.unitscan Theramore Infiltrator
step << skip
.goto Dustwallow Marsh,46.63,24.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ithania|r inside the tower
.complete 9437,1 
.target Ithania
.skipgossip
step << skip
.goto Dustwallow Marsh,46.6,24.3
>>Loot the |cRXP_PICK_Warped Crates|r at the top of the tower for the |cRXP_LOOT_Dawn Runner Cargo|r
.complete 9437,2 
step
.goto Dustwallow Marsh,46.90,17.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Stinky" Ignatz|r, then start his escort
.accept 1270,1 >> Accept Stinky's Escape
.target "Stinky" Ignatz
step
>>Escort |cRXP_FRIENDLY_Stinky|r
>>|cRXP_WARN_Be careful!|r |cRXP_ENEMY_Bloodfen Screechers|r |cRXP_WARN_call for help at 33% health|r
.complete 1270,1 
.target "Stinky" Ignatz
.mob Bloodfen Screecher
step
.goto Dustwallow Marsh,55.44,25.93
>>Click the |cRXP_PICK_Loose Dirt|r West of |cRXP_FRIENDLY_"Swamp Eye" Jarl's|r house
.accept 1238 >> Accept The Lost Report
step
.goto Dustwallow Marsh,55.435,26.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Swamp Eye" Jarl|r
.turnin 11225 >> Turn in The Hermit of Witch Hill
.accept 1218 >> Accept Marsh Frog Legs
.target "Swamp Eye" Jarl
step
.goto Dustwallow Marsh,55.583,26.146
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mordant Grimsby|r
.accept 11180 >> Accept What's Haunting Witch Hill?
.target Mordant Grimsby
step
#completewith next
>>Kill |cRXP_ENEMY_Giant Marsh Frogs|r. Loot them for their |cRXP_LOOT_Marsh Frog Legs|r
.complete 1218,1 
.mob Giant Marsh Frog
step
#loop
.goto 1445,56.8,29.4,0
.goto 1445,57.8,24.8,0
.goto 1445,56.2,22.8,0
.goto 1445,53.8,22.4,0
.goto 1445,52.6,29.4,0
.goto 1445,56.8,29.4,65,0
.goto 1445,57.8,24.8,65,0
.goto 1445,56.2,22.8,65,0
.goto 1445,53.8,22.4,65,0
.goto 1445,52.6,29.4,65,0
>>Kill |cRXP_ENEMY_Risen Husks|r and |cRXP_ENEMY_Risen Spirits|r
.complete 11180,1 
.mob Risen Husk
.mob Risen Spirit
step
#loop
.goto 1445,56.8,29.4,0
.goto 1445,57.8,24.8,0
.goto 1445,56.2,22.8,0
.goto 1445,53.8,22.4,0
.goto 1445,52.6,29.4,0
.goto 1445,56.8,29.4,65,0
.goto 1445,57.8,24.8,65,0
.goto 1445,56.2,22.8,65,0
.goto 1445,53.8,22.4,65,0
.goto 1445,52.6,29.4,65,0
>>Kill |cRXP_ENEMY_Giant Marsh Frogs|r. Loot them for their |cRXP_LOOT_Marsh Frog Legs|r
.complete 1218,1 
.mob Giant Marsh Frog
step
.goto Dustwallow Marsh,55.435,26.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Swamp Eye" Jarl|r
.turnin 1218 >> Turn in Marsh Frog Legs
.accept 1206 >> Accept Jarl Needs Eyes
.target "Swamp Eye" Jarl
step
.goto Dustwallow Marsh,55.583,26.146
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mordant Grimsby|r
.turnin 11180 >> Turn in What's Haunting Witch Hill?
.accept 11181 >> Accept The Witch's Bane
.target Mordant Grimsby
step
#loop
.goto 1445,55.2,27.7,0
.goto 1445,55.0,25.7,0
.goto 1445,54.3,23.5,0
.goto 1445,53.7,21.5,0
.goto 1445,50.5,22.5,0
.goto 1445,50.0,21.0,0
.goto 1445,51.7,16.5,0
.goto 1445,55.2,27.7,50,0
.goto 1445,55.0,25.7,50,0
.goto 1445,54.3,23.5,50,0
.goto 1445,53.7,21.5,50,0
.goto 1445,50.5,22.5,50,0
.goto 1445,50.0,21.0,50,0
.goto 1445,51.7,16.5,50,0
>>Loot the |cRXP_LOOT_Witchbane|r on the ground
.complete 11181,1 
step
#completewith next
>>Kill any |cRXP_ENEMY_Theramore Infiltrator|r you encounter
>>|cRXP_WARN_They are stealthed|r << !Hunter
>>|cRXP_WARN_They are stealthed! Cast|r |T132320:0|t[Track Hidden] |cRXP_WARN_to find them more easily|r << Hunter
.complete 1201,1 
.unitscan Theramore Infiltrator
step
#loop
.goto Dustwallow Marsh,35.9,20.7,90,0
.goto Dustwallow Marsh,32.8,21.4,90,0
.goto Dustwallow Marsh,34.40,25.20,50,0
.goto Dustwallow Marsh,35.90,20.70,50,0
.goto Dustwallow Marsh,32.80,21.40,50,0
.goto Dustwallow Marsh,34.40,25.20,50,0
>>Kill |cRXP_ENEMY_all Darkmist Spiders|r. Loot them for their |cRXP_LOOT_Eyes|r
.complete 1206,1 
.mob Darkmist Recluse
.mob Darkmist Spider
.mob Darkmist Spider
.mob Darkmist Lurker
.unitscan Darkmist Widow
step
#label Infiltrator
#loop
.goto Dustwallow Marsh,42.06,26.03,0
.goto Dustwallow Marsh,39.63,23.85,0
.goto Dustwallow Marsh,38.94,22.44,0
.goto Dustwallow Marsh,38.01,25.50,0
.goto Dustwallow Marsh,37.63,27.60,0
.goto Dustwallow Marsh,38.03,33.99,0
.goto Dustwallow Marsh,38.02,37.40,0
.goto Dustwallow Marsh,40.67,35.22,0
.goto Dustwallow Marsh,42.06,26.03,40,0
.goto Dustwallow Marsh,39.63,23.85,40,0
.goto Dustwallow Marsh,38.94,22.44,40,0
.goto Dustwallow Marsh,38.01,25.50,40,0
.goto Dustwallow Marsh,37.63,27.60,40,0
.goto Dustwallow Marsh,38.03,33.99,40,0
.goto Dustwallow Marsh,38.02,37.40,40,0
.goto Dustwallow Marsh,40.67,35.22,40,0
.goto Dustwallow Marsh,40.50,33.48,40,0
>>Finish killing |cRXP_ENEMY_Theramore Infiltrators|r
>>|cRXP_WARN_They are stealthed|r << !Hunter
>>|cRXP_WARN_They are stealthed! Cast|r |T132320:0|t[Track Hidden] |cRXP_WARN_to find them more easily|r << Hunter
.complete 1201,1 
.unitscan Theramore Infiltrator
step
#loop
.goto Dustwallow Marsh,37.79,27.07,0
.goto Dustwallow Marsh,40.99,25.49,0
.goto Dustwallow Marsh,35.45,40.88,0
.goto Dustwallow Marsh,40.21,47.43,0
.goto Dustwallow Marsh,38.52,51.31,0
.goto Dustwallow Marsh,37.79,27.07,50,0
.goto Dustwallow Marsh,38.75,25.98,50,0
.goto Dustwallow Marsh,40.99,25.49,50,0
.goto Dustwallow Marsh,38.26,36.91,50,0
.goto Dustwallow Marsh,35.45,40.88,50,0
.goto Dustwallow Marsh,38.11,43.09,50,0
.goto Dustwallow Marsh,40.21,47.43,50,0
.goto Dustwallow Marsh,38.52,51.31,50,0
.goto Dustwallow Marsh,36.99,52.10,50,0
>>Kill |cRXP_ENEMY_Darkfang Spiders|r. Loot them for their |cRXP_LOOT_Venom Sacs|r
>>|cRXP_ENEMY_Bloodfen Raptors|r |cRXP_WARN_share spawnss with |cRXP_ENEMY_Darkfang spiders|r, so kill them too if needed|r
.complete 1322,1 
.mob Darkfang Lurker
.mob Darkfang Spider
.mob Darkfang Creeper
.mob Darkfang Venomspitter
step
#completewith next
.subzone 496 >> Travel back to Brackenwall Village
step
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.turnin 1201 >> Turn in Theramore Spies
.turnin 1238 >> Turn in The Lost Report
.target Nazeer Bloodpike
step
.goto Dustwallow Marsh,36.50,30.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Do'gol|r
.turnin 1322 >> Turn in The Black Shield
.accept 1323 >> Accept The Black Shield
.target Do'gol
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 1323 >> Turn in The Black Shield
.turnin 1273 >> Turn in Questioning Reethe
.accept 1276 >> Accept The Black Shield
.target Krog
.isQuestComplete 1273
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 1323 >> Turn in The Black Shield
.accept 1276 >> Accept The Black Shield
.target Krog
step << skip
.goto Dustwallow Marsh,35.9,31.7
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Balandar Brightstar|r
.turnin 9437 >> Turn in Twilight of the Dawn Runner
.target Balandar Brightstar
step
.goto Dustwallow Marsh,55.44,25.93
>>Click the |cRXP_PICK_Loose Dirt|r West of |cRXP_FRIENDLY_"Swamp Eye" Jarl's|r house
.accept 1239 >> Accept The Severed Head
step
.goto Dustwallow Marsh,55.43,26.26
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Swamp Eye" Jarl|r
.turnin 1206 >> Turn in Jarl Needs Eyes
.accept 1203 >> Accept Jarl Needs a Blade
.target "Swamp Eye" Jarl
step
.goto Dustwallow Marsh,55.583,26.146
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mordant Grimsby|r
.turnin 11181 >> Turn in The Witch's Bane
.accept 11183 >> Accept Cleansing Witch Hill
.target Mordant Grimsby
step
#optional
#sticky
#completewith Razorspine
.destroy 5884 >> |cRXP_WARN_Destroy any leftover|r |T133884:0|t[Unpopped Darkmist Eyes] |cRXP_WARN_you have|r
step
.goto 1445,55.178,26.689
#completewith next
.cast 42521 >> |cRXP_WARN_Use the|r |T135432:0|t[Witchbane Torch] |cRXP_WARN_at the end of the dock to summon|r |cRXP_ENEMY_Zelfrax|r
.timer 32,Cleansing Witch Hill RP
.use 33113
step
.goto 1445,55.178,26.689
.use 33113 >>Kill |cRXP_ENEMY_Zelfrax|r as he spawns
.complete 11183,1 
.mob Zelfrax
step
.goto Dustwallow Marsh,55.583,26.146
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mordant Grimsby|r
.turnin 11183 >> Turn in Cleansing Witch Hill
.target Mordant Grimsby
step
#completewith next
>>Kill |cRXP_ENEMY_Mirefin Murlocs|r. Loot them for their |cRXP_LOOT_Heads|r
.complete 1177,1 
.mob Mirefin Puddlejumper
.mob Mirefin Murloc
.mob Mirefin Coastrunner
.mob Mirefin Muckdweller
step
#label Razorspine
.goto 1445,57.77,19.67,20,0
.goto 1445,57.90,18.36
>>Kill |cRXP_ENEMY_Razorspine|r. Loot him for his |cRXP_LOOT_Sword|r
.complete 1203,1 
.mob Razorspine
step
#loop
.goto Dustwallow Marsh,57.91,15.50,0
.goto Dustwallow Marsh,57.91,15.50,50,0
.goto Dustwallow Marsh,54.17,14.98,50,0
.goto Dustwallow Marsh,58.71,9.98,50,0
>>Kill |cRXP_ENEMY_Mirefin Murlocs|r. Loot them for their |cRXP_LOOT_Heads|r
.complete 1177,1 
.mob Mirefin Puddlejumper
.mob Mirefin Murloc
.mob Mirefin Coastrunner
.mob Mirefin Muckdweller
step
.goto Dustwallow Marsh,55.435,26.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Swamp Eye" Jarl|r
.turnin 1203 >> Turn in Jarl Needs a Blade
.target "Swamp Eye" Jarl
step
.goto Dustwallow Marsh,35.20,38.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mudcrush|r
.turnin 1177 >> Turn in Hungry!
.target Mudcrush Durtfeet
step
#completewith next
.subzone 496 >> Travel back to Brackenwall Village
step
.goto Dustwallow Marsh,35.30,30.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.turnin 1239 >> Turn in The Severed Head
.accept 1240 >> Accept The Troll Witchdoctor
.target Nazeer Bloodpike
step
#completewith ShimmFlatsVisit
.goto Dustwallow Marsh,35.57,31.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shardi|r
.fly Gadgetzan >> Fly to Gadgetzan
.target Shardi
.zoneskip Thousand Needles
step
#completewith ShimmFlatsVisit
.goto Tanaris,50.87,23.09,30,0
.goto Thousand Needles,75.49,97.58,30,0
.zone Thousand Needles >>Travel north to the Shimmering Flats
step
.goto Thousand Needles,78.14,77.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle|r
.turnin 1107 >> Turn in Encrusted Tail Fins
.target Wizzle Brassbolts
.isQuestComplete 1107
step
#optional
.abandon 1107 >> Abandon Encrusted Tail Fins
step
.goto Thousand Needles,80.18,75.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pozzik|r
.turnin 1183 >> Turn in Goblin Sponsorship
.accept 1186 >> Accept The Eighteenth Pilot
.target Pozzik
.isQuestTurnedIn 1182
step
#label ShimmFlatsVisit
.goto Thousand Needles,80.32,76.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razzeric|r
.turnin 1186 >> Turn in The Eighteenth Pilot
.accept 1187 >> Accept Razzeric's Tweaking
.target Razzeric
.isQuestTurnedIn 1183
step << Druid
#completewith DruidTraining3
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 8992 >> Train your class spells
.target Loganaar
.xp <38,1
.xp >40,1
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9634 >> Train your class spells
.target Loganaar
.xp <38,1
.xp >40,1
step << Druid
#label DruidTraining3
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9745 >> Train your class spells
.target Loganaar
.xp <42,1
step << Mage
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
.train 3567,3
step
#optional << Mage
#completewith next << !Mage
.hs >> Hearth to Orgrimmar
.use 6948
.bindlocation 1637,1
.zoneskip Orgrimmar
.train 3567,1 << Mage
step << !Mage
.goto Orgrimmar,54.65,67.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barkeep Morag|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Barkeep Morag
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8413 >> Train your class spells
.target Pephredo
.xp <38,1
.xp >40,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8423 >> Train your class spells
.target Pephredo
.xp <40,1
.xp >42,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10159 >> Train your class spells
.target Pephredo
.xp <42,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10391 >> Train your class spells
.target Kardris Dreamseeker
.xp <38,1
.xp >40,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 8134 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
.xp >42,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 11314 >> Train your class spells
.target Kardris Dreamseeker
.xp <42,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8621 >> Train your class spells
.target Ormok
.xp <38,1
.xp >40,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <40,1
.xp >42,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 6774 >> Train your class spells
.target Ormok
.xp <42,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 8820 >> Train your class spells
.target Grezz Ragefist
.xp <38,1
.xp >40,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 20660 >> Train your class spells
.target Grezz Ragefist
.xp <40,1
.xp >42,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11550 >> Train your class spells
.target Grezz Ragefist
.xp <42,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14320 >> Train your class spells
.target Ormak Grimshot
.xp <38,1
.xp >40,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14324 >> Train your class spells
.target Ormak Grimshot
.xp <40,1
.xp >42,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14289 >> Train your class spells
.target Ormak Grimshot
.xp <42,1
step << Hunter
#optional
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 14925 >> Train your pet spells
.target Xao'tsu
.xp <40,1
.xp >42,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24561 >> Train your pet spells
.target Xao'tsu
.xp <42,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 6078 >> Train your class spells
.target Ur'kyo
.xp <38,1
.xp >40,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 8106 >> Train your class spells
.target Ur'kyo
.xp <40,1
.xp >42,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10898 >> Train your class spells
.target Ur'kyo
.xp <42,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 3472 >> Train your class spells
.target Master Pyreanor
.xp <38,1
.xp >40,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 1032 >> Train your class spells
.target Master Pyreanor
.xp <40,1
.xp >42,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 19837 >> Train your class spells
.target Master Pyreanor
.xp <42,1
step << Orc !Warlock
#optional
.goto Orgrimmar,69.40,13.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kildar|r and |cRXP_FRIENDLY_Ogunaro|r
.train 825 >>Train |T136103:0|t[Wolf Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132224:0|t[|cFF0070FFWolf|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Kildar
.target Ogunaro Wolfrunner
step << Troll
#optional
#completewith next
.subzone 367 >> Travel to Sen'Jin Village
.xp <30,1
.money <38
.skill riding,75,1
step << Troll
#optional
.goto Durotar,55.28,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xar'Ti|r and |cRXP_FRIENDLY_Zjolnir|r
.train 10861 >>Train |T136103:0|t[Raptor Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132253:0|t[|cFF0070FFRaptor|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Xar'Ti
.target Zjolnir
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 39-41 Hillsbrad/Alterac/Arathi part 2
#next 41-42 Badlands
step
#sticky
#completewith EnterSM
.subzone 796,2 >> Now you should be looking for a group to Scarlet Monastery
.dungeon SM
step << !Mage
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Tirisfal Glades >>Take the Zeppelin to Undercity
.zoneskip Undercity
step << Mage
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << Mage
#optional
.goto Undercity,85.13,10.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8413 >> Train your class spells
.target Anastasia Hartwell
.xp <38,1
.xp >40,1
step << Mage
#optional
.goto Undercity,85.13,10.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8423 >> Train your class spells
.target Anastasia Hartwell
.xp <40,1
.xp >42,1
step << Mage
.goto Undercity,85.13,10.04
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 8423 >> Train your class spells
.target Anastasia Hartwell
.xp <42,1
step << Mage
.goto Undercity,84.20,15.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Lexington|r
.train 11418 >> Train |T135751:0|t[Portal: Undercity]
.target Lexington Mortaim
.xp <40,1
step << Mage
.goto Undercity,82.79,15.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Hannah|r|cRXP_BUY_. Buy two or more|r |T134419:0|t[Rune of Teleportation] |cRXP_BUY_from him|r
.collect 17031,2,503,1 
.target Hannah Akeley
step << Undead !Warlock
#optional
#completewith next
.subzone 159 >> Travel to Brill
.xp <30,1
.money <38
.skill riding,75,1
.dungeon !SM << Mage
step << Undead !Warlock
#optional
.goto Tirisfal Glades,60.09,52.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velma|r and |cRXP_FRIENDLY_Zachariah|r
.train 10906 >>Train |T136103:0|t[Undead Horsemanship]
.vendor >>|cRXP_BUY_Buy a|r |T132264:0|t[|cFF0070FFSkeletal Horse|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Velma Warnam
.target Zachariah Post
.dungeon !SM << Mage
step
#completewith UCVisit3
.goto Tirisfal Glades,61.80,65.06,20,0
.zone Undercity >> Enter Undercity
.zoneskip Undercity
.dungeon !SM << Mage
step << BloodElf !Warlock !Paladin
#optional
#completewith next
.goto Undercity,65.87,1.48,15,0
.goto Undercity,65.82,5.44,15,0
.goto Undercity,62.76,11.02,12,0
.goto Undercity,54.67,11.25
.zone Silvermoon City >> Take the Orb of Translocation to Silvermoon City
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
#completewith next
.goto Silvermoon City,62.89,31.20,20,0
.goto Silvermoon City,75.63,58.34,20,0
.goto Silvermoon City,73.22,59.91,20,0
.goto Eversong Woods,56.43,49.91
.zone Eversong Woods >>Exit Silvermoon
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
.goto Eversong Woods,61.08,54.15,12,0
.goto Eversong Woods,61.38,53.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Perascamin|r and |cRXP_FRIENDLY_Winaestra|r
.train 33388 >> Train |T136103:0|t[Apprentice Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132228:0|t[|cFF0070FFHawkstrider|r]
.target Perascamin
.target Winaestra
.xp <30,1
.money <38
.skill riding,75,1
step << BloodElf !Warlock !Paladin
#optional
#completewith UCVisit3
.goto Silvermoon City,51.83,17.91,30,0
.goto Silvermoon City,49.45,15.00
.zone Undercity >>Take the Orb of Translocation back to Undercity
.skill riding,<75,1
step
#completewith next
.goto Undercity,51.92,64.68,15 >>Travel toward |cRXP_FRIENDLY_Varimathras|r
.dungeon SM
step
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.accept 1048 >>Accept Into The Scarlet Monastery
.target Varimathras
.dungeon SM
step
#completewith next
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Zinge|r
step
.goto Undercity,50.15,67.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zinge|r
.accept 232 >> Accept Errand for Apothecary Zinge
.target Apothecary Zinge
step
.goto Undercity,48.80,69.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faranell|r
.accept 1113 >> Accept Hearts of Zeal
.target Master Apothecary Faranell
.isQuestTurnedIn 1109 
step
.goto Undercity,58.61,54.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alessandro|r
.turnin 232 >> Turn in Errand for Apothecary Zinge
.accept 238 >> Accept Errand for Apothecary Zinge
.target Alessandro Luca
step
#label IntoFieldPU
.goto Undercity,50.15,67.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zinge|r
.turnin 238 >> Turn in Errand for Apothecary Zinge
.accept 243 >> Accept Into the Field
.target Apothecary Zinge
step << Hunter
.goto Undercity,54.71,38.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Abigail|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from her if it's available|r
.target Abigail Sawyer
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
step << Hunter
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_WARN_when you are level 42|r
.use 11307
.itemcount 11307,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
step << Hunter
.goto Undercity,58.66,33.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |cRXP_BUY_Buy a|r |T135424:0|t[Great Axe] |cRXP_BUY_from him if you're melee weaving. Otherwise, skip this step|r
.collect 2531,1,503,1 
.target Geoffrey Hartwell
.money <5.0552
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<31.2
step << Hunter
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135424:0|t[Great Axe] |cRXP_WARN_when you are level 39|r
.use 2531
.itemcount 2531,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<31.2
.xp >39,1
step << Hunter
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135424:0|t[Great Axe]
.use 2531
.itemcount 2531,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<31.2
.xp <39,1
step << Rogue
.goto Undercity,58.66,33.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135344:0|t[Falchion] |cRXP_BUY_from him|r
.collect 2528,1,503,1 
.money <4.6652
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.6
.target Geoffrey Hartwell
step << Rogue
.goto Undercity,58.66,33.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Geoffrey|r|cRXP_BUY_. Buy a|r |T135341:0|t[Rondel] |cRXP_BUY_from him|r
.collect 2534,1,503,1 
.money <4.0888
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
.target Geoffrey Hartwell
step << Rogue
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135344:0|t[Falchion] |cRXP_WARN_when you are level 41|r
.use 2528
.itemcount 2528,1
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.6
step << Rogue
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135341:0|t[Rondel] |cRXP_WARN_in your off-hand when you are level 39|r
.use 2534
.itemcount 2534,1
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
step << Priest
.goto Undercity,69.54,26.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Zane|r|cRXP_BUY_. Buy a|r |T133718:0|t[Blackbone Wand] |cRXP_BUY_from him|r
.collect 5239,1,503,1 
.money <4.0769
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<35.3
.target Zane Bradford
step << Priest
#optional
#completewith BracersofBinding
+|cRXP_WARN_Equip the|r |T135344:0|t[Blackbone Wand] |cRXP_WARN_when you are level 41|r
.use 5239
.itemcount 5239,1
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<35.3
step << Undead Mage
#optional
#completewith next
.subzone 159 >> Travel to Brill
.xp <30,1
.money <38
.skill riding,75,1
.dungeon SM
step << Undead Mage
#optional
.goto Tirisfal Glades,60.09,52.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velma|r and |cRXP_FRIENDLY_Zachariah|r
.train 10906 >>Train |T136103:0|t[Undead Horsemanship]
.vendor >>|cRXP_BUY_Buy a|r |T132264:0|t[|cFF0070FFSkeletal Horse|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Velma Warnam
.target Zachariah Post
.dungeon SM
step
#label EnterSM
.goto Eastern Kingdoms,47.43,19.71,30,0
.goto Eastern Kingdoms,47.76,19.49
.subzone 796,2 >> Enter Scarlet Monastery. Start with Library so you can loot the [|cRXP_FRIENDLY_The Scarlet Key|r] at the end
.zoneskip 304
.zoneskip 305
.dungeon SM




step << !Undead
#completewith Bosses
>>Loot the |cRXP_LOOT_Compendium of the Fallen|r
>>|cRXP_WARN_It's located in a bookshelf on the left in the last corner of the dungeon|r
.complete 1049,1 
.dungeon SM
step
#completewith Compendium
>>Kill |cRXP_LOOT_Scarlet|r mobs. Loot them for their |cRXP_LOOT_Hearts of Zeal|r
.complete 1113,1 
.isOnQuest 1113
.dungeon SM
step
#label Bosses
>>Kill |cRXP_ENEMY_Houndmaster Loksey|r, |cRXP_ENEMY_Herod|r, |cRXP_ENEMY_High Inquisitor Whitemane|r and |cRXP_ENEMY_Scarlet Commander Mograine|r
>>|cRXP_ENEMY_Houndmaster Loksey|r |cRXP_WARN_is located in the Library|r
>>|cRXP_ENEMY_Herod|r |cRXP_WARN_is located in the Armory|r
>>|cRXP_ENEMY_High Inquisitor Whitemane|r |cRXP_WARN_and |cRXP_ENEMY_Scarlet Commander Mograine|r are located in the Cathedral|r
.complete 1048,4 
.complete 1048,3 
.complete 1048,1 
.complete 1048,2 
.isOnQuest 1048
.mob Houndmaster Loksey
.mob Herod
.mob High Inquisitor Whitemane
.mob Scarlet Commander Mograine
.dungeon SM
step << !Undead
#label Compendium
>>Loot the |cRXP_LOOT_Compendium of the Fallen|r
>>|cRXP_WARN_It's located in a bookshelf on the left in the last corner of the dungeon|r
.complete 1049,1 
.isOnQuest 1049
.dungeon SM
step << Mage
#completewith SMturnin
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
.dungeon SM
step << !Mage
#completewith SMturnin
.goto Undercity,66.07,9.18,150 >> Travel to Undercity
.zoneskip Undercity
.dungeon SM
step
#completewith SMturnin
.goto Undercity,51.92,64.68,15 >>Travel toward |cRXP_FRIENDLY_Varimathras|r
.isQuestComplete 1048
.dungeon SM
step
#label SMturnin
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.turnin 1048 >>Turn in Into The Scarlet Monastery
.isQuestComplete 1048
.target Varimathras
.dungeon SM
step
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.accept 6521 >>Accept An Unholy Alliance
.target Varimathras
.isQuestTurnedIn 6522 
.dungeon RFD
step
#completewith next
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Faranell|r
.isQuestComplete 1113
.dungeon SM
step
.goto Undercity,48.80,69.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faranell|r
.turnin 1113 >> Turn in Hearts of Zeal
.target Master Apothecary Faranell
.isQuestComplete 1113
.dungeon SM
step
.goto Undercity,74.05,33.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andrew|r
.accept 3341 >> Accept Bring the End
.target Andrew Brownell
.dungeon RFD
step << Warrior
.goto Undercity,77.48,49.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Nathaniel|r|cRXP_BUY_Buy two stacks of|r |T135424:0|t[Gleaming Throwing Axe] |cRXP_BUY_from him|r
.collect 25876,400,1713,1 
.target Nathaniel Steenwick
.itemcount 29010,<400
step << Warrior
#ah
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r in the Trade Quarter
>>|cRXP_BUY_If you have money leftover after buying|r |T134717:0|t[Nature Protection Potions]|cRXP_BUY_, purchase the following items from the Auction House:|r
.collect 4480,8,1713,1 
.collect 4479,8,1713,1 
.collect 4481,8,1713,1 
.collect 3357,8,1712,1 
.target Auctioneer Stockton
step << Warrior
#ah
.goto Undercity,71.42,46.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r in the Trade Quarter
>>|cRXP_BUY_Buy|r |T134717:0|t[Nature Protection Potions] |cRXP_BUY_from the auction house|r
.collect 6052,2,1713,1 
.target Auctioneer Stockton
step
#ah
.goto Undercity,71.42,46.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Stockton|r in the Trade Quarter
>>|cRXP_BUY_If you have money leftover, purchase the following items from the Auction House:|r
.collect 3829,1 
.collect 4389,1 
.collect 929,1 
.collect 3823,1 

.collect 4611,9 
.collect 3404,4 
.target Auctioneer Stockton

step << skip 
.goto Undercity,57.4,93.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sharlindra|r
.accept 495 >> Accept The Crown of Will
.target Sharlindra
step
.goto Undercity,62.31,48.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Patrick|r
.accept 2342 >> Accept Reclaimed Treasures
.target Patrick Garrett
step
#optional
#label UCVisit3
step
#optional
.abandon 1048,1113


step << Warrior
#completewith next
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
>>|cRXP_ENEMY_Fly to Tarren Mill instead if you bought 8 Cresting, Thundering and Burning charms on the AH and skip the next 3 steps|r
.fly Hammerfall >> Fly to Hammerfall
.target Michael Garrett
.zoneskip Arathi Highlands
step << Warrior
#label Cresting
.goto Arathi Highlands,66.72,29.72
>>Kill |cRXP_ENEMY_Cresting Exiles|r. Loot them for their |T133438:0|t[Cresting Charms]
.collect 4481,8 
.mob Cresting Exile
step << Warrior
.goto Arathi Highlands,52.06,50.60
>>Kill |cRXP_ENEMY_Thundering Exiles|r. Loot them for their |T133435:0|t[Thundering Charms]
>>|cRXP_WARN_Be careful!|r |cRXP_ENEMY_Thundering Exiles|r |cRXP_WARN_have high burst damage|r
.collect 4480,8 
.mob Thundering Exile
step << Warrior
.goto Arathi Highlands,25.47,30.09
>>Kill |cRXP_ENEMY_Burning Exiles|r. Loot them for their |T133434:0|t[Burning Charms]
.collect 4479,8 
.mob Burning Exile
step << Warrior
#completewith BracersofBinding
.goto Hillsbrad Foothills,62.06,20.19,120 >> Travel to Tarren Mill
.zoneskip Hillsbrad Foothills
step << !Warrior
#completewith BracersofBinding
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Michael Garrett
.zoneskip Hillsbrad Foothills
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r

.accept 518 >> Accept The Crown of Will
.target Melisara
step
.goto Hillsbrad Foothills,62.63,20.65
>>Click the |cRXP_PICK_WANTED: Baron Vardus|r poster next to |cRXP_FRIENDLY_Melisara|r
.accept 566 >> Accept WANTED: Baron Vardus
.target Melisara
.isQuestTurnedIn 549
step
.goto Hillsbrad Foothills,63.24,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.accept 503 >> Accept Gol'dir
.target Krusk
.isQuestTurnedIn 498
step << Mage
.goto Hillsbrad Foothills,62.76,19.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shay|r
.home >>Set your hearthstone to Tarren Mill
.target Innkeeper Shay
.isQuestAvailable 507
.bindlocation 272
.train 3567,3 
step
#label BracersofBinding
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bel'varil|r and |cRXP_FRIENDLY_Wordeen|r
.accept 557 >> Accept Bracers of Binding
.target +Keeper Bel'varil
.goto Hillsbrad Foothills,61.60,20.86
.accept 545 >> Accept Dalaran Patrols
.target +Magus Wordeen Voidglare
.goto Hillsbrad Foothills,61.49,20.93
.maxlevel 40
step << Warrior
#completewith Whirlwind
+|cRXP_WARN_It is VERY important to watch this video on how to cheese Cyclonian for the|r |T132403:0|t[Whirlwind Axe]
.link https://www.youtube.com/watch?v=BiuWeMSHEhA >> CLICK HERE
step << Warrior
#ah
#optional
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
.use 6052 >>|cRXP_WARN_While traveling, use a|r |T134717:0|t[Nature Protection Potion]
.turnin 1714 >> Turn in Essence of the Exile
.target Bath'rah the Windwatcher
.itemcount 6052,1
step << Warrior
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
.turnin 1714 >> Turn in Essence of the Exile
.target Bath'rah the Windwatcher
step << Warrior
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r
.turnin 1712 >>Turn in Cyclonian
.accept 1713 >>Accept The Summoning
.target Bath'rah the Windwatcher
step << Warrior
#label Whirlwind
.goto Alterac Mountains,80.6,62.2
>>Wait for |cRXP_FRIENDLY_Bath'rah's|r roleplay, then kill |cRXP_LOOT_Cyclonian|r and loot him for his |cRXP_LOOT_Heart|r
>>|cRXP_WARN_Equip your|r |T135424:0|t[Gleaming Throwing Axe] |cRXP_WARN_if you haven't|r
.complete 1713,1 
.unitscan Cyclonian
step << Warrior
.goto Alterac Mountains,80.49,66.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bath'rah the Windwatcher|r and choose the |T132403:0|t[Whirlwind Axe]
.turnin 1713 >>Turn in The Summoning
.turnin 1792 >>Turn in Whirlwind Weapon
.target Bath'rah the Windwatcher
step << Warrior
#completewith Goldir
.destroy 6929 >>|cRXP_WARN_Destroy|r |T134327:0|t[Bath'rah's Parchment] |cRXP_WARN_as it's not needed for anything|r
step
#completewith next
.goto Alterac Mountains,42.2,77.8,90,0
.goto Alterac Mountains,46.2,78.2,90,0
>>Kill |cRXP_ENEMY_Mountain Lions|r. Loot them for a |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r]
>>|cRXP_WARN_The|r |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r] |cRXP_WARN_disappears after 30 minutes|r
.collect 5810,1,1136,1 
.mob Feral Mountain Lion
.mob Mountain Lion
.mob Starving Mountain Lion
.mob Hulking Mountain Lion
step
.goto Alterac Mountains,37.56,68.22
.use 5810 >> |cRXP_WARN_Use the|r |T134368:0|t[|cRXP_LOOT_Fresh Carcass|r] |cRXP_WARN_inside Growless Cave to summon|r |cRXP_ENEMY_Frostmaw|r
>>Kill him and loot him for his |cRXP_LOOT_Mane|r
.complete 1136,1 
.unitscan Frostmaw
step
#label Ruins1
#completewith next
.goto Alterac Mountains,41.86,46.98,100 >>Travel to the Ruins of Alterac
step
#loop
.goto Alterac Mountains,46.1,46.6,0
.goto Alterac Mountains,41.4,48.7,50,0
.goto Alterac Mountains,38.1,40.3,50,0
.goto Alterac Mountains,46.1,46.6,50,0
>>Kill |cRXP_ENEMY_Crushridge Maulers|r in the area
>>|cRXP_WARN_They share spawns with other |cRXP_ENEMY_Ogres|r so kill them also if needed|r
.complete 518,1 
.mob Crushridge Mauler
step
#completewith Goldir
>>Kill |cRXP_ENEMY_Baron Vardus|r and loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_One of his spawnpoints is inside the inn in Strahnbrad. You will complete this quest later if he isn't there|r
.complete 566,1 
.unitscan Baron Vardus
.isQuestTurnedIn 549
step
#loop
.goto Alterac Mountains,60.55,43.91,0
.goto Alterac Mountains,63.10,43.47,0
.goto Alterac Mountains,62.67,40.16,0
.goto Alterac Mountains,61.77,43.88,8,0
.goto Alterac Mountains,60.55,43.91,8,0
.goto Alterac Mountains,63.10,43.47,8,0
.goto Alterac Mountains,62.31,41.59,8,0
.goto Alterac Mountains,62.67,40.16,12,0
>>Kill |cRXP_ENEMY_Jailor Borhuin|r. Loot him for his |cRXP_LOOT_Key|r
>>|cRXP_WARN_He has multiple spawn locations in Strahnbrad:|r
>>|cRXP_WARN_Inside the inn on the second floor|r
>>|cRXP_WARN_Inside the building opposite of the inn on the ground floor|r
>>|cRXP_WARN_Inside the town hall|r
.complete 503,1 
.unitscan Jailor Borhuin
.isQuestTurnedIn 498
step
#label Goldir
.goto Alterac Mountains,60.00,43.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gol'dir|r on the second floor of the inn
.turnin 503 >> Turn in Gol'dir
.accept 506 >> Accept Blackmoore's Legacy
.target Gol'dir
.isQuestTurnedIn 498
step
#completewith next
.goto Hillsbrad Foothills,62.37,20.32
.subzone 272 >> Travel to Tarren Mill
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Melisara|r
.turnin 518 >> Turn in The Crown of Will
.accept 519 >> Accept The Crown of Will
.target Melisara
step
.goto Hillsbrad Foothills,63.24,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.turnin 506 >> Turn in Blackmoore's Legacy
.accept 507 >> Accept Lord Aliden Perenolde
.target Krusk
.isQuestTurnedIn 498
.group
step
.goto Hillsbrad Foothills,63.24,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.turnin 506 >> Turn in Blackmoore's Legacy
.target Krusk
.isQuestTurnedIn 498
step
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Darthalia|r
.turnin 566 >> Turn in WANTED: Baron Vardus
.target High Executor Darthalia
.isQuestComplete 566
step
.goto Hillsbrad Foothills,62.76,19.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shay|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Shay
.subzoneskip 272,1
step
#label Ruins2
#completewith TargsHead
.goto Alterac Mountains,41.86,46.98,100 >>Travel to the Ruins of Alterac
step
#requires Ruins2
#completewith TargsHead
+|cRXP_WARN_Be careful of |cRXP_ENEMY_Grel'borg the Miser|r (elite). He patrols around|r
.mob Grel'borg the Miser
step
.goto Alterac Mountains,39.49,41.82
>>Kill |cRXP_ENEMY_Glommus|r. Loot him for his |cRXP_LOOT_Head|r
.complete 519,3 
.unitscan Glommus
step
.goto Alterac Mountains,38.61,46.78
>>Kill |cRXP_ENEMY_Muckrake|r. Loot him for his |cRXP_LOOT_Head|r
.complete 519,2 
.unitscan Muckrake
step
#label TargsHead
.goto Alterac Mountains,39.59,52.86
>>Kill |cRXP_ENEMY_Targ|r. Loot him for his |cRXP_LOOT_Head|r
.complete 519,1 
.unitscan Targ
step
#loop
.goto Alterac Mountains,10.30,78.50,0
.goto Alterac Mountains,20.50,75.20,50,0
.goto Alterac Mountains,21.30,53.50,50,0
.goto Alterac Mountains,17.80,56.20,50,0
.goto Alterac Mountains,21.30,53.50,50,0
.goto Alterac Mountains,20.50,75.20,50,0
.goto Alterac Mountains,10.30,78.50,50,0
>>Kill |cRXP_ENEMY_Dalaran Summoners|r and |cRXP_ENEMY_Elemental Slaves|r. Loot them for their |cRXP_LOOT_Bracers|r
.complete 545,1 
.mob +Dalaran Summoner
.complete 545,2 
.mob +Elemental Slave
.complete 557,1 
.mob +Elemental Slave
.isOnQuest 545
.isOnQuest 557
step
.goto Alterac Mountains,39.28,14.52
>>Kill |cRXP_ENEMY_Lord Aliden Perenolde|r
>>|cRXP_WARN_Be mindful of |cRXP_ENEMY_Syndicate Assassins|r|cRXP_WARN_.|r |cRXP_ENEMY_Aliden|r |cRXP_WARN_uses Power Word: Shield, casts Renew, and will sleep pets and other players|r
.complete 507,1 
.unitscan Lord Aliden Perenolde
.mob Syndicate Assassin
.isQuestTurnedIn 506
.group 2
step
.goto Alterac Mountains,39.30,14.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elysa|r
.turnin 507 >> Turn in Lord Aliden Perenolde
.accept 508 >> Accept Taretha's Gift
.target Elysa
.isQuestTurnedIn 506
.group
step
#loop
.goto Alterac Mountains,47.8,17.1,0
.goto Alterac Mountains,53.6,20.6,0
.goto Alterac Mountains,56.2,26.8,0
.goto Alterac Mountains,58.1,29.9,0
.goto Alterac Mountains,59.7,43.9,0
.goto Alterac Mountains,47.8,17.1,70,0
.goto Alterac Mountains,53.6,20.6,70,0
.goto Alterac Mountains,56.2,26.8,70,0
.goto Alterac Mountains,58.1,29.9,70,0
.goto Alterac Mountains,59.7,43.9,70,0
>>Search for |cRXP_ENEMY_Baron Vardus|r in each camp and the Strahnbrad's inn. Kill him and loot him for his |cRXP_LOOT_Head|r
.complete 566,1 
.unitscan Baron Vardus
step << Mage
#completewith TMTurnins2
.hs >>Hearth to Tarren Mill
.use 6948
.subzoneskip 272
.bindlocation 272,1
.cooldown item,6948,>0,1
.train 3567,3 
step
#completewith TMTurnins2
.goto Hillsbrad Foothills,62.37,20.32
.subzone 272 >> Travel to Tarren Mill
.train 3567,1 << Mage
step
.goto Hillsbrad Foothills,62.37,20.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_High Executor Darthalia|r
.turnin 566 >> Turn in WANTED: Baron Vardus
.target High Executor Darthalia
.isQuestComplete 566
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.turnin 519 >> Turn in The Crown of Will
.accept 520 >> Accept The Crown of Will
.target Melisara
.group
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.turnin 519 >> Turn in The Crown of Will
.target Melisara
step
.goto Hillsbrad Foothills,63.20,20.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krusk|r
.turnin 508 >> Turn in Taretha's Gift
.target Krusk
.isOnQuest 508
.group
step
.goto Hillsbrad Foothills,61.56,20.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wordeen|r
.turnin 545 >> Turn in Dalaran Patrols
.target Magus Wordeen Voidglare
.isQuestComplete 545
step
#label TMTurnins2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bel'varil|r
.turnin 557 >> Turn in Bracers of Binding
.target +Keeper Bel'varil
.goto Hillsbrad Foothills,61.49,20.93
.isQuestComplete 557
step
#label Ruins3
#completewith MugtholsHead
.goto Alterac Mountains,41.86,46.98,100 >>Travel to the Ruins of Alterac
.group 0
step
#optional
.goto Alterac Mountains,37.9,52.2
.xp 39 >> Grind to 39 on |cRXP_ENEMY_Ogres|r in the area
step
#requires Ruins3
#completewith MugtholsHead
+|cRXP_WARN_Be careful of |cRXP_ENEMY_Grel'borg the Miser|r (elite). He patrols around|r
.mob Grel'borg the Miser
.group 0
step
#label MugtholsHead
.goto Alterac Mountains,35.68,54.25
>>Kill |cRXP_ENEMY_Mug'thol|r. Loot him for his |cRXP_LOOT_Head|r and for the |cRXP_LOOT_Crown of Will|r
>>|cRXP_WARN_Be very careful of|r |cRXP_ENEMY_Crushridge Warmongers|r|cRXP_WARN_, who call for help at low HP|r
.complete 520,1 
.complete 520,2 
.unitscan Mug'thol
.group 2
step
#completewith CrownComplete
.subzone 272 >>Travel to Tarren Mill
.group
step
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.turnin 520 >> Turn in The Crown of Will
.accept 521 >> Accept The Crown of Will
.target Melisara
.isQuestComplete 520
.group
step
#optional
#label CrownComplete
.goto Hillsbrad Foothills,62.63,20.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melisara|r
.accept 521 >> Accept The Crown of Will
.target Melisara
.isQuestTurnedIn 520
.group
step
#completewith Arathipt2Start
.goto Hillsbrad Foothills,60.14,18.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zarise|r
.fly Hammerfall >> Fly to Hammerfall
.target Zarise
.zoneskip Arathi Highlands
step
.goto Arathi Highlands,62.50,33.80
>>Click the |cRXP_PICK_Shards of Myzrael|r
.accept 642 >> Accept The Princess Trapped
step
.goto Arathi Highlands,73.80,33.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zengu|r
.turnin 638 >> Turn in Trollbane
.accept 639 >> Accept Sigil of Strom
.target Zengu
step
.goto Arathi Highlands,74.30,33.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drum Fel|r
.accept 678 >> Accept Call to Arms
.target Drum Fel
step
#label Arathipt2Start
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.accept 701 >> Accept Guile of the Raptor
.accept 673 >> Accept Foul Magics
.target Tor'gan
step
#loop
.goto Arathi Highlands,84.32,30.93,0
.goto Arathi Highlands,80.80,39.91,20,0
.goto Arathi Highlands,82.25,38.94,20,0
.goto Arathi Highlands,82.39,36.78,20,0
.goto Arathi Highlands,83.56,35.02,20,0
.goto Arathi Highlands,84.87,31.67,20,0
.goto Arathi Highlands,87.10,31.31,20,0
.goto Arathi Highlands,84.73,28.99,20,0
.goto Arathi Highlands,84.32,30.93,20,0
>>Kill |cRXP_ENEMY_Drywhisker Kobolds|r, |cRXP_ENEMY_Diggers|r and |cRXP_ENEMY_Surveyors|r. Loot them for their |cRXP_LOOT_Motes of Myzrael|r
.complete 642,1 
.mob Drywhisker Kobold
.mob Drywhisker Digger
.mob Drywhisker Surveyor
step
.goto Arathi Highlands,84.30,30.95
>>Click the |cRXP_PICK_Iridescent Shards|r towards the back of the cave
.turnin 642 >> Turn in The Princess Trapped
.accept 651 >> Accept Stones of Binding
step
.goto Arathi Highlands,66.70,29.80
>>Loot the |cRXP_PICK_Stone of East Binding|r for the |cRXP_LOOT_Cresting Key|r
>>|cRXP_ENEMY_Cresting Exiles|r |cRXP_WARN_have Frost Armor and Frost Nova|r
.complete 651,2 
.mob Cresting Exile
step
.goto Arathi Highlands,52.00,50.80
>>Loot the |cRXP_PICK_Stone of Outer Binding|r for the |cRXP_LOOT_Thundering Key|r
>>|cRXP_ENEMY_Thundering Exiles|r |cRXP_WARN_have powerful burst damage|r
.complete 651,3 
.mob Thundering Exile
step
#completewith BurningKey
.goto Arathi Highlands,45.78,43.61,0
+|cRXP_WARN_Be careful of getting too close to Refuge Point (Alliance base) in the centre of the zone.|r |cRXP_ENEMY_Refuge Point Defenders|r |cRXP_WARN_can kill you|r
.unitscan Refuge Point Defender
step
.goto Arathi Highlands,25.50,30.10
>>Loot the |cRXP_PICK_Stone of West Binding|r for the |cRXP_LOOT_Burning Key|r
>>|cRXP_WARN_If you find yourself in danger, use a|r |T133438:0|t[Cresting Charm] |cRXP_WARN_on|r |cRXP_ENEMY_Burning Exiles|r
.complete 651,1 
.mob Burning Exile
.itemcount 4481,1
step
#label BurningKey
#optional
.goto Arathi Highlands,25.50,30.10
>>Loot the |cRXP_PICK_Stone of West Binding|r for the |cRXP_LOOT_Burning Key|r
.complete 651,1 
.mob Burning Exile
.itemcount 4481,<1
step
#completewith SigilofStrom
.subzone 324 >>Travel to Stromgarde Keep
step
#completewith next
>>Kill |cRXP_ENEMY_Syndicate|r. Loot them for the |cRXP_LOOT_Sigil of Strom|r
>>|cRXP_WARN_It has a very low drop rate. Be careful of respawns. Be careful of|r |cRXP_ENEMY_Syndicate Prowlers|r|cRXP_WARN_, who can net and disarm|r
.complete 639,1 
.mob Syndicate Prowler
.mob Syndicate Conjuror
.mob Syndicate Magus
.mob Syndicate Thief
step
.goto Arathi Highlands,29.45,64.39,30,0
.goto Arathi Highlands,29.63,62.95
>>Kill |cRXP_ENEMY_Marez Cowl|r. Loot her for her |cRXP_LOOT_Orb|r
>>|cRXP_WARN_She has two spawn locations in the eastern side of the keep|r
.complete 673,1 
.unitscan Marez Cowl
step
#label SigilofStrom
#loop
.goto Arathi Highlands,25.73,62.60,0
.goto Arathi Highlands,25.73,62.60,40,0
.goto Arathi Highlands,27.79,65.64,40,0
.goto Arathi Highlands,26.86,60.37,40,0
.goto Arathi Highlands,29.53,61.66,40,0
>>Kill |cRXP_ENEMY_Syndicate|r. Loot them for the |cRXP_LOOT_Sigil of Strom|r
>>|cRXP_WARN_It has a very low drop rate. Be careful of respawns. Be careful of|r |cRXP_ENEMY_Syndicate Prowlers|r|cRXP_WARN_, who can net and disarm|r
.complete 639,1 
.mob Syndicate Prowler
.mob Syndicate Conjuror
.mob Syndicate Magus
.mob Syndicate Thief
step
.goto Arathi Highlands,36.20,57.30
>>Click the |cRXP_PICK_Stone of Inner Binding|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Rumbling Exiles|r|cRXP_WARN_. Their stun has no diminishing return|r
.turnin 651 >> Turn in Stones of Binding
.accept 652 >> Accept Breaking the Keystone
.group
step
.goto Arathi Highlands,36.20,57.30
>>Click the |cRXP_PICK_Stone of Inner Binding|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Rumbling Exiles|r|cRXP_WARN_. Their stun has no diminishing return|r
.turnin 651 >> Turn in Stones of Binding
step
#loop
.goto Arathi Highlands,67.3,31.1,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,21.1,36.5,50,0
.goto Arathi Highlands,26.4,30.3,50,0
.goto Arathi Highlands,26.0,45.4,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,67.3,31.1,50,0
>>Find and kill |cRXP_ENEMY_Fozruk|r. Loot him for his |cRXP_LOOT_Rod of Order|r
>>|cRXP_WARN_Don't go out of your way to finish this step, he patrols the whole zone|r
>>|cRXP_ENEMY_Fozruk|r |cRXP_WARN_is a level 42 non-elite. Kill the |cRXP_ENEMY_Kobolts|r first and then reset if needed to make the fight easier|r
>>|cRXP_WARN_Scout for him with|r |T132172:0|t[Eagle Eye] << Hunter
>>|cRXP_WARN_Scout for him with|r |T136034:0|t[Far Sight] << Shaman
.complete 652,1 
.unitscan Fozruk
.train 6196,3 << Shaman
.train 6197,3 << Hunter
.group 2
step << Shaman/Hunter
#optional
#loop
.goto Arathi Highlands,67.3,31.1,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,21.1,36.5,50,0
.goto Arathi Highlands,26.4,30.3,50,0
.goto Arathi Highlands,26.0,45.4,50,0
.goto Arathi Highlands,30.5,54.6,50,0
.goto Arathi Highlands,47.4,56.8,50,0
.goto Arathi Highlands,61.8,43.0,50,0
.goto Arathi Highlands,67.3,31.1,50,0
>>Find and kill |cRXP_ENEMY_Fozruk|r. Loot him for his |cRXP_LOOT_Rod of Order|r
>>|cRXP_WARN_Don't go out of your way to finish this step, he patrols the whole zone|r
>>|cRXP_ENEMY_Fozruk|r |cRXP_WARN_is a level 42 non-elite. Kill the |cRXP_ENEMY_Kobolts|r first and then reset if needed to make the fight easier|r
.complete 652,1 
.unitscan Fozruk
.train 6196,1 << Shaman
.train 6197,1 << Hunter
.group 2
step
.goto Arathi Highlands,36.07,58.09
>>Click the |cRXP_PICK_Keystone|r
.turnin 652 >> Turn in Breaking the Keystone
.accept 688 >> Accept Myzrael's Allies
.isQuestComplete 652
.group
step
#optional
.goto Arathi Highlands,36.07,58.09
>>Click the |cRXP_PICK_Keystone|r
.accept 688 >> Accept Myzrael's Allies
.isQuestTurnedIn 652
.group
step
#completewith next
>>Kill |cRXP_ENEMY_Highland Fleshstalkers|r. Loot them for their |cRXP_LOOT_Hearts|r
.complete 701,1 
.mob Highland Fleshstalker
step
#loop
.goto Arathi Highlands,53.68,79.95,0
.goto Arathi Highlands,52.06,74.38,50,0
.goto Arathi Highlands,53.81,74.59,50,0
.goto Arathi Highlands,53.58,76.20,50,0
.goto Arathi Highlands,54.52,78.00,15,0
.goto Arathi Highlands,53.68,79.95,20,0
>>Kill |cRXP_ENEMY_Boulderfist Brutes|r and |cRXP_ENEMY_Boulderfist Magi|r
>>|cRXP_WARN_Be careful of the Magi's Frost Armor and Frost Nova|r
>>|cFFEB144CBe **EXTREMELY CAUTIOUS** of the rare spawn "Molok the Crusher" which is a non-elite that hits for 250-450|r
.complete 678,1 
.mob +Boulderfist Brute
.complete 678,2 
.mob +Boulderfist Magus
.unitscan Molok the Crusher
step
#loop
.goto Arathi Highlands,49.71,68.69,0
.goto Arathi Highlands,52.77,63.56,70,0
.goto Arathi Highlands,50.22,65.00,70,0
.goto Arathi Highlands,49.71,68.69,70,0
.goto Arathi Highlands,48.07,74.25,70,0
.goto Arathi Highlands,46.21,76.74,70,0
.goto Arathi Highlands,46.04,79.55,70,0
.goto Arathi Highlands,48.59,80.56,70,0
>>Kill |cRXP_ENEMY_Highland Fleshstalkers|r. Loot them for their |cRXP_LOOT_Hearts|r
.complete 701,1 
.mob Highland Fleshstalker
step
#label HammerFallArrive
#completewith HammerFallVisit1
.subzone 321 >>Travel to Hammerfall
step
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 673 >> Turn in Foul Magics
.turnin 701 >> Turn in Guile of the Raptor
.accept 702 >> Accept Guile of the Raptor
.target Tor'gan
step
.goto Arathi Highlands,74.40,35.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaruk|r
.turnin 688 >> Turn in Myzrael's Allies
.accept 687 >> Accept Theldurin the Lost
.target Zaruk
.isQuestTurnedIn 652
.group
step
.goto Arathi Highlands,72.64,33.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gor'mul|r
.turnin 702 >> Turn in Guile of the Raptor
.accept 847 >> Accept Guile of the Raptor
.target Gor'mul

step
.goto Arathi Highlands,73.80,33.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zengu|r
.turnin 639 >> Turn in Sigil of Strom
.accept 640 >> Accept The Broken Sigil
.target Zengu
step
.goto Arathi Highlands,74.30,33.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drum Fel|r
.turnin 678 >> Turn in Call to Arms
.accept 679 >> Accept Call to Arms
.target Drum Fel
step
.goto Arathi Highlands,74.00,33.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korin Fel|r
.accept 680 >> Accept The Real Threat
.target Korin Fel
step
.goto Arathi Highlands,73.84,32.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Adegwa|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Adegwa
.subzoneskip 321,1
.isQuestAvailable 665
step
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 847 >> Turn in Guile of the Raptor
.target Tor'gan
step
.goto Arathi Highlands,73.41,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doctor Gregory Victor|r
.accept 6622 >> Accept Triage
.target Doctor Gregory Victor
.skill firstaid,<225,1
step
.goto Arathi Highlands,73.03,36.84
.use 16991 >> |cRXP_WARN_Channel the|r |T133682:0|t[Triage Bandage] |cRXP_WARN_on the |cRXP_FRIENDLY_Horde Soldiers|r. Prioritize |cRXP_FRIENDLY_Critically Injured Soldiers|r first|r
.complete 6622,1 
.target Critically Injured Horde Soldier
.target Badly Injured Horde Soldier
.target Injured Horde Soldier
.isOnQuest 6622
step
.goto Arathi Highlands,73.41,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doctor Gregory Victor|r
.turnin 6622 >> turnin Triage
.target Doctor Gregory Victor
.isQuestComplete 6622
step
.destroy 16991 >> |cRXP_WARN_Delete the|r |T133682:0|t[Triage Bandage]|cRXP_WARN_. You no longer need it|r
.isQuestTurnedIn 6622
step
#optional
#label HammerFallVisit1
step
#optional
#completewith SigilFragments
.abandon 652
step
#completewith SigilFragments
.subzone 324 >>Travel to Stromgarde Keep
step
#completewith next
>>Kill |cRXP_ENEMY_Boulderfist Shamans|r and |cRXP_ENEMY_Boulderfist Lords|r
.complete 679,1 
.mob +Boulderfist Shaman
.complete 679,2 
.mob +Boulderfist Lord
step
.goto Arathi Highlands,18.74,66.30,30,0
.goto Arathi Highlands,19.6,66.9
>>Kill |cRXP_ENEMY_Or'Kalar|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_ENEMY_Or'Kalar|r |cRXP_WARN_can spawn in two areas around the Tower of Arathor's base|r
.complete 680,1 
.unitscan Or'Kalar
step
#loop
.goto Arathi Highlands,18.91,65.80,0
.goto Arathi Highlands,18.91,65.80,50,0
.goto Arathi Highlands,20.05,65.43,50,0
.goto Arathi Highlands,20.50,66.72,50,0
.goto Arathi Highlands,21.49,67.03,50,0
.goto Arathi Highlands,21.84,65.41,50,0
.goto Arathi Highlands,23.64,65.69,50,0
.goto Arathi Highlands,22.25,67.74,50,0
.goto Arathi Highlands,20.89,69.19,50,0
.goto Arathi Highlands,19.51,69.14,50,0
.goto Arathi Highlands,18.26,67.42,50,0
>>Kill |cRXP_ENEMY_Boulderfist Shamans|r and |cRXP_ENEMY_Boulderfist Lords|r
.complete 679,1 
.mob +Boulderfist Shaman
.complete 679,2 
.mob +Boulderfist Lord
step
#label SigilFragments
#loop
.goto Arathi Highlands,23.73,60.75,0
.goto Arathi Highlands,23.73,60.75,50,0
.goto Arathi Highlands,23.25,63.09,50,0
.goto Arathi Highlands,22.03,63.07,50,0
.goto Arathi Highlands,21.21,63.22,50,0
.goto Arathi Highlands,21.19,60.65,50,0
.goto Arathi Highlands,22.49,59.37,50,0
.goto Arathi Highlands,22.83,58.02,50,0
.goto Arathi Highlands,23.82,57.13,50,0
.goto Arathi Highlands,24.92,57.18,50,0
.goto Arathi Highlands,27.50,57.62,50,0
.goto Arathi Highlands,27.37,58.92,50,0
.goto Arathi Highlands,24.36,58.87,50,0
.goto Arathi Highlands,23.49,59.57,50,0
>>Kill |cRXP_ENEMY_Stromgarde Soldiers|r. Loot them for their |cRXP_LOOT_Sigil Fragments|r
>>|cRXP_ENEMY_Stormgarde Defenders|r |cRXP_WARN_have Shield Bash|r
.complete 640,1 
.mob Stromgarde Troll Hunter
.mob Stromgarde Defender
.mob Stromgarde Vindicator
step
#completewith next
.goto Arathi Highlands,24.48,65.09,10 >> Jump onto the metal wall alongside the castle wall
step
#completewith next
.goto Arathi Highlands,24.42,66.57,10,0
.goto Arathi Highlands,21.04,69.69,20 >> Run along the metal wall until you reach the whole in the castle wall
step
#completewith next
.goto Arathi Highlands,21.58,75.61,30,0
.goto Arathi Highlands,22.08,79.85,40 >> Run through the cave to Faldir's Cove
step
.goto Arathi Highlands,31.83,82.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lolo|r
.accept 663 >> Accept Land Ho!
.target Lolo the Lookout
step
.goto Arathi Highlands,32.28,81.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shakes O'Breen|r
.turnin 663 >> Turn in Land Ho!
.target Shakes O'Breen
step
.goto Arathi Highlands,32.78,81.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nilzlix|r
.accept 662 >> Accept Deep Sea Salvage
.target First Mate Nilzlix
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelgut|r and |cRXP_FRIENDLY_Phizzlethorpe|r
.accept 664 >> Accept Drowned Sorrows
.target +Captain Steelgut
.goto Arathi Highlands,34.00,80.79
.accept 665 >> Accept Sunken Treasure
.target +Professor Phizzlethorpe
.goto Arathi Highlands,33.87,80.55
step
.goto Arathi Highlands,35.7,79.7
>>Wait for |cRXP_FRIENDLY_Phizzlethorpe's|r roleplay, then kill the two |cRXP_ENEMY_Vengeful Surges|r that spawn.
>>|cRXP_WARN_These mobs are level 40. Get them off of| |cRXP_FRIENDLY_Phizzlethorpe|r |cRXP_WARN_as soon as you can|r
.complete 665,1 
.unitscan Vengeful Surge
step
.goto Arathi Highlands,33.8,80.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doctor Draxlegauge|r
.turnin 665 >> Turn in Sunken Treasure
.accept 666 >> Accept Sunken Treasure
.target Doctor Draxlegauge
step << !Druid !Warlock !Shaman
#ah
#completewith SLog
.aura 7178 >>|cRXP_WARN_Drink an|r |T134797:0|t[Elixir of Water Breathing]
.use 5996
.itemcount 5996,1
step
#sticky
#completewith Daggerspines
+|cRXP_ENEMY_Daggerspine Raiders|r |cRXP_WARN_have a Net ability, so be very careful of your breath if you haven't used an|r |T134797:0|t[Elixir of Water Breathing] << !Druid !Warlock !Shaman
+|cRXP_ENEMY_Daggerspine Raiders|r |cRXP_WARN_have a Net ability, so be sure to keep Water Breathing applied|r << Warlock/Shaman
+|cRXP_WARN_Use Aquatic Form when your breath gets low|r << Druid
step
#completewith ElvenGems
>>Kill |cRXP_ENEMY_Daggerspine Raiders|r and |cRXP_ENEMY_Sorceresses|r
.complete 664,1 
.mob +Daggerspine Raider
.complete 664,2 
.mob +Daggerspine Sorceress
step
#completewith SLog
>>Find |cRXP_PICK_Calcified Elven Gems|r. Loot them for |cRXP_LOOT_Elven Gems|r
.use 4491 >>|cRXP_WARN_Equip your|r |T133149:0|t[Goggles of Gem Hunting] |cRXP_WARN_to see them on your minimap|r
.complete 666,1 
step
.goto Arathi Highlands,23.40,85.09
>>Loot the |cRXP_PICK_Book|r for |cRXP_LOOT_Maiden's Folly Log|r
>>|cRXP_WARN_The log is on the ship's mid-level, towards its front|r
.complete 662,2 
step
.goto Arathi Highlands,23.04,84.51
>>Loot the |cRXP_PICK_Unfurled Parchment|r for |cRXP_LOOT_Maiden's Folly Charts|r
>>|cRXP_WARN_The charts are on the ship's mid-level, towards its center|r
.complete 662,1 
step
.goto Arathi Highlands,20.46,85.61
>>Loot the |cRXP_PICK_Unfurled Parchment|r for |cRXP_LOOT_Spirit of Silverpine Charts|r
>>|cRXP_WARN_The charts are on the ship's mid-level, towards its front, on a crate next to a cannon|r
.complete 662,3 
step
#label SLog
.goto Arathi Highlands,20.65,85.10
>>Loot the |cRXP_PICK_Book|r for |cRXP_LOOT_Spirit of Silverpine Log|r
>>|cRXP_WARN_The log is on the ship's lowest-level, towards its front, laying in dirt|r
.complete 662,4 
step
#label ElvenGems
#loop
.goto Arathi Highlands,19.30,84.10,0
.goto Arathi Highlands,19.30,84.10,50,0
.goto Arathi Highlands,17.70,89.50,50,0
.goto Arathi Highlands,25.50,90.80,50,0
.goto Arathi Highlands,24.10,85.70,50,0
.goto Arathi Highlands,23.20,89.70,50,0
>>Find |cRXP_PICK_Calcified Elven Gems|r. Loot them for |cRXP_LOOT_Elven Gems|r
.use 4491 >>|cRXP_WARN_Equip your|r |T133149:0|t[Goggles of Gem Hunting] |cRXP_WARN_to see them on your minimap|r
.complete 666,1 
step
#label Daggerspines
#loop
.goto Arathi Highlands,21.05,84.62,0
.goto Arathi Highlands,21.05,84.62,60,0
.goto Arathi Highlands,23.44,84.76,60,0
.goto Arathi Highlands,25.38,86.03,60,0
.goto Arathi Highlands,23.14,89.88,60,0
.goto Arathi Highlands,21.55,86.67,60,0
.goto Arathi Highlands,18.75,85.31,60,0
.goto Arathi Highlands,19.76,84.00,60,0
>>Finish killing |cRXP_ENEMY_Daggerspine Raiders|r and |cRXP_ENEMY_Sorceresses|r
.complete 664,1 
.mob +Daggerspine Raider
.complete 664,2 
.mob +Daggerspine Sorceress
step
#completewith next
+|cRXP_WARN_Re-equip your usual helm|r
step
.goto Arathi Highlands,32.77,81.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nilzlix|r
.turnin 662 >> Turn in Deep Sea Salvage
.target First Mate Nilzlix
step
.goto Arathi Highlands,33.86,80.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draxlegauge|r
.turnin 666 >> Turn in Sunken Treasure
.accept 668 >> Accept Sunken Treasure
.target Doctor Draxlegauge
step
.goto Arathi Highlands,34.00,80.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Steelgut|r
.turnin 664 >> Turn in Drowned Sorrows
.target Captain Steelgut
step
#label PiratesComplete
.goto Arathi Highlands,32.28,81.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shakes O'Breen|r
.turnin 668 >> Turn in Sunken Treasure
.accept 669 >> Accept Sunken Treasure
.target Shakes O'Breen
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 41-42 Badlands
#next 42-43 Stranglethorn Vale part 2
step
#completewith next
.zone Wetlands >> Swim to Wetlands
step
.goto Wetlands,53.87,70.32,0
.goto Wetlands,53.87,70.32,15,0
.goto Wetlands,49.37,70.56,15,0
.goto Wetlands,48.27,67.52,25,0
.goto Wetlands,50.14,71.57,15,0
.goto Wetlands,50.18,78.30,15,0
.goto Wetlands,50.63,82.57,15,0
.goto Wetlands,55.13,83.53,15,0
.goto Loch Modan,25.27,0.04,15,0
.goto Loch Modan,25.56,10.12,15,0
.zone Loch Modan >>Travel through Dun Algaz into Loch Modan
.zoneskip Badlands
step
#completewith next
.goto Loch Modan,25.34,67.27,0
.goto Loch Modan,24.76,70.59,30,0
.goto Loch Modan,25.10,72.98,30,0
.goto Loch Modan,26.11,75.42,30,0
.goto Loch Modan,23.27,81.30,30,0
.goto Loch Modan,22.82,84.81,30,0
.goto Loch Modan,19.59,87.23,30,0
.goto Loch Modan,20.37,91.08,30,0
.goto Loch Modan,22.33,91.55,30,0
.goto Loch Modan,22.87,94.92,30,0
.goto Badlands,5.73,29.78,0
>>Use the shortcut to get to Badlands faster
.zone Badlands >> Run to the Badlands
.link https://www.youtube.com/watch?v=oNFXup-DCM0 >> CLICK HERE for a video tutorial
step
.goto Badlands,3.99,44.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fp Kargath >> Get the Kargath Flight Path
.target Gorrik
.isQuestAvailable 1419
step
.goto Badlands,2.90,47.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sranda|r
.vendor >>|cRXP_BUY_Sell your junk and repair, if necessary|r
.target Sranda
step
#optional
.goto Badlands,2.91,45.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorn|r
.accept 782 >> Accept Broken Alliances
.target Gorn
.xp <40,1
step
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal|r
.accept 2258 >> Accept Badlands Reagent Run
.target Jarkal Mossmeld
step
.goto Badlands,6.0,48.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Advisor Sarophas|r
.accept 9439 >> Accept Unclaimed Baggage
.target Advisor Sarophas
step
.goto Badlands,6.4,47.5
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neeka|r
.accept 1419 >> Accept Coyote Thieves
.target Neeka Bloodscar
step
#ah
.goto Badlands,25.95,44.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.accept 713 >> Accept Coolant Heads Prevail
.turnin 713 >> Turn in Coolant Heads Prevail
.target Lotwil Veriatus
.itemcount 3829,1 
step
#ah
.goto Badlands,25.95,44.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.accept 714 >> Accept Gyro... What?
.turnin 714 >> Turn in Gyro... What?
.target Lotwil Veriatus
.itemcount 4389,1 
.isQuestTurnedIn 713
step
.goto Badlands,25.95,44.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.accept 710 >> Accept Study of the Elements: Rock
.target Lotwil Veriatus
step
#ah
.goto Badlands,25.82,44.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lucien|r
.accept 715 >> Accept Liquid Stone
.turnin 715 >> Turn in Liquid Stone
.target Lucien Tosselwrench
.itemcount 929,1 
.itemcount 3823,1 
.isQuestTurnedIn 714
step
#completewith AngorFortress
>>While questing, kill any |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r you encounter. Loot them for their |cRXP_LOOT_Wings|r, |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.collect 3404,4,703,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#loop
.goto Badlands,23.41,45.26,0
.goto Badlands,23.41,45.26,50,0
.goto Badlands,21.90,43.22,50,0
.goto Badlands,19.99,43.10,50,0
.goto Badlands,17.76,41.06,50,0
.goto Badlands,16.62,38.29,50,0
.goto Badlands,14.78,37.34,50,0
.goto Badlands,13.48,37.80,50,0
.goto Badlands,13.01,40.09,50,0
.goto Badlands,15.11,41.89,50,0
.goto Badlands,16.94,42.80,50,0
.goto Badlands,19.17,45.74,50,0
.goto Badlands,20.47,48.40,50,0
.goto Badlands,23.12,48.20,50,0
>>Kill |cRXP_ENEMY_Earth Elementals|r. Loot them for their |cRXP_LOOT_Stone Shards|r and |cRXP_LOOT_Elemental Shards|r
.complete 710,1 
.complete 2258,3 
.mob Lesser Rock Elemental
step
.goto Badlands,25.95,44.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil Veriatus|r
.turnin 710 >> Turn in Study of the Elements: Rock
.accept 711 >> Accept Study of the Elements: Rock
.target Lotwil Veriatus
step
#label AngorFortress
#completewith next
.goto Badlands,42.9,29.9,30 >> Enter Angor Fortress
step
>>Loot the |cRXP_PICK_Weapon Rack|r for the |cRXP_LOOT_Advisor's Rapier|r
>>Loot the |cRXP_PICK_Empty Barrel|r for the |cRXP_LOOT_Advisor's Pack|r
.complete 9439,2 
.goto Badlands,41.67,26.93
.complete 9439,1 
.goto Badlands,41.07,29.25
step
#completewith BrokenAlliance
#label signofearthBL
>>Find & kill |cRXP_ENEMY_Boss Tho'grun|r. Loot him for the |cRXP_LOOT_Sign of Earth|r
>>|cRXP_ENEMY_Boss Tho'grun|r |cRXP_WARN_patrols the zone, accompanied by five guards|r
.complete 782,1 
.unitscan Boss Tho'grun
.isOnQuest 782
step
#optional
#completewith InduriumFlakes
>>While questing, kill any |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r you encounter. Loot them for their |cRXP_LOOT_Wings|r, |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.collect 3404,4,703,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#completewith BarbWings
.goto Badlands,42.47,52.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jazzrik|r
.vendor >>|cRXP_BUY_Sell your junk and repair, if necessary|r
.target Jazzrik
step
#ah
.goto Badlands,42.39,52.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r
.accept 705 >> Accept Pearl Diving
.turnin 705 >> Turn in Pearl Diving
.target Rigglefuzz
.itemcount 4611,9 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r and |cRXP_FRIENDLY_Martek|r
.accept 703 >> Accept Barbecued Buzzard Wings
.target +Rigglefuzz
.goto Badlands,42.39,52.92
.turnin 1106 >> Turn in Martek the Exiled
.accept 1108 >> Accept Indurium
.target +Martek the Exiled
.goto Badlands,42.21,52.70
.isOnQuest 1106
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r and |cRXP_FRIENDLY_Martek|r
.accept 703 >> Accept Barbecued Buzzard Wings
.target +Rigglefuzz
.goto Badlands,42.39,52.92
.accept 1108 >> Accept Indurium
.target +Martek the Exiled
.goto Badlands,42.21,52.70
.isQuestTurnedIn 1106
step
#label BarbWings
.goto Badlands,42.39,52.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r
.turnin 703 >> Turn in Barbecued Buzzard Wing
.target Rigglefuzz
.isQuestComplete 703
step
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin|r
.turnin 687 >> Turn in Theldurin the Lost
.accept 709 >> Accept Solution to Doom
.target Theldurin the Lost
.isQuestTurnedIn 653
.group
step
#optional
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin|r
.accept 709 >> Accept Solution to Doom
.target Theldurin the Lost
step
#label InduriumFlakes
#loop
.goto Badlands,47.16,69.82,0
.goto Badlands,47.16,69.82,50,0
.goto Badlands,48.38,72.06,50,0
.goto Badlands,49.86,72.12,50,0
.goto Badlands,51.20,71.93,50,0
.goto Badlands,52.41,69.96,50,0
.goto Badlands,52.55,67.79,50,0
.goto Badlands,52.46,65.90,50,0
.goto Badlands,51.00,63.86,50,0
.goto Badlands,49.66,63.97,50,0
.goto Badlands,49.69,66.39,50,0
.goto Badlands,49.78,68.28,50,0
.goto Badlands,48.14,68.30,50,0
>>Kill |cRXP_ENEMY_Stonevault Troggs|r. Loot them for their |cRXP_LOOT_Indurium Flakes|r
.complete 1108,1 
.mob Stonevault Bonesnapper
.mob Stonevault Shaman
step
#loop
.goto Badlands,36.20,75.10,0
.goto Badlands,36.20,75.10,50,0
.goto Badlands,46.00,78.40,50,0
.goto Badlands,42.80,87.20,50,0
>>Kill |cRXP_ENEMY_Rock Elementals|r. Loot them for their |cRXP_LOOT_Stone Slabs|r
>>|cRXP_ENEMY_Rock Elementals|r |cRXP_WARN_are abundant in this southern location, but the northern location from the prior elemental quest has a few as well|r
.complete 711,1 
.mob Rock Elemental
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Coyotes|r. Loot them for their |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#loop
.goto Badlands,17.24,58.53,0
.goto Badlands,17.24,58.53,50,0
.goto Badlands,15.35,58.51,50,0
.goto Badlands,14.85,60.16,50,0
.goto Badlands,15.00,61.98,50,0
.goto Badlands,16.15,61.84,50,0
.goto Badlands,17.01,61.24,50,0
>>Kill |cRXP_ENEMY_Buzzards|r. Loot them for their |cRXP_LOOT_Wings|r and |cRXP_LOOT_Gizzards|r
.collect 3404,4,703,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 2258,1 
.disablecheckbox
step
#optional
#completewith EnterUldaCave
>>Kill |cRXP_ENEMY_Coyotes|r and |cRXP_ENEMY_Buzzards|r. Loot them for their |cRXP_LOOT_Jawbones|r, |cRXP_LOOT_Fangs|r and |cRXP_LOOT_Gizzards|r
>>|cRXP_WARN_Don't focus on this. You can complete it later|r
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rigglefuzz|r and |cRXP_FRIENDLY_Martek|r
.turnin 703 >> Turn in Barbecued Buzzard Wing
.target +Rigglefuzz
.goto Badlands,42.39,52.92
.turnin 1108 >> Turn in Indurium
.timer 20,Indurium RP
.accept 1137 >> Accept News for Fizzle
.target +Martek the Exiled
.goto Badlands,42.21,52.70
step
#label EnterUldaCave
#completewith GFamilyChest
.goto Eastern Kingdoms,52.40,63.61,30 >>Travel to Uldaman and enter the cave
.subzoneskip 1337
step
#requires EnterUldaCave
#completewith Tablet
>>Kill |cRXP_ENEMY_Shadowforge Dwarves|r and |cRXP_ENEMY_Stonevault Troggs|r for a chance of getting a |T133289:0|t[|cRXP_LOOT_Shattered Necklace|r]
.collect 7666,1,2283,1 
step
#requires EnterUldaCave
#label Tablet
.goto Eastern Kingdoms,52.06,63.81,20,0
.goto Eastern Kingdoms,52.11,64.01
>>Loot the |cRXP_PICK_Ancient Chest|r in the middle of the room for the |cRXP_LOOT_Tablet of Ryun'eh|r
.complete 709,1 
step
#requires EnterUldaCave
#label GFamilyChest
.goto Eastern Kingdoms,51.78,63.77,15,0
.goto Eastern Kingdoms,51.72,63.73,15,0
.goto Eastern Kingdoms,51.68,63.81,15,0
.goto Eastern Kingdoms,51.80,64.00
>>Loot the |cRXP_PICK_Garret Family Chest|r in the southern corner of the South Common Hall for the |cRXP_LOOT_Garrett Family Treasure|r
>>|cRXP_WARN_The South Common Hall is southwest of the Uldaman instance portal|r
.complete 2342,1 
.isOnQuest 2342
step
#label ExitCave
#completewith DoomSolved
.goto Eastern Kingdoms,52.40,63.61,30 >>Exit the cave
step
#requires ExitCave
#optional
#completewith ElementRock2TI
>>Finish killing |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r. Loot them for their |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#requires ExitCave
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin the Lost|r
.turnin 709 >> Turn in Solution to Doom

.target Theldurin the Lost
.isQuestComplete 709
step << skip
#optional
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin the Lost|r
.accept 728 >> Accept To the Undercity for Yagyin's Digest
.target Theldurin the Lost
.isQuestTurnedIn 709

step
#optional
#label DoomSolved
step
#label ElementRock2TI
.goto Badlands,25.95,44.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lotwil|r
.turnin 711 >> Turn in Study of the Elements: Rock
.target Lotwil Veriatus
step
#loop
.goto Badlands,30.28,62.70,0
.goto Badlands,44.11,71.87,90,0
.goto Badlands,37.09,69.28,90,0
.goto Badlands,30.28,62.70,90,0
.goto Badlands,25.09,55.10,90,0
.goto Badlands,44.11,71.87,90,0
.goto Badlands,37.09,69.28,90,0
.goto Badlands,30.28,62.70,90,0
>>Finish killing |cRXP_ENEMY_Buzzards|r and |cRXP_ENEMY_Coyotes|r. Loot them for their |cRXP_LOOT_Gizzards|r, |cRXP_LOOT_Jawbones|r and |cRXP_LOOT_Fangs|r
.complete 2258,1 
.mob +Buzzard
.mob +Giant Buzzard
.mob +Starving Buzzard
.complete 1419,1 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
.complete 2258,2 
.mob +Crag Coyote
.mob +Feral Crag Coyote
.mob +Rabid Crag Coyote
.mob +Elder Crag Coyote
step
#label KargathVisit2
#completewith KargathTurnins
.subzone 340 >>Travel to Kargath
step
.goto Badlands,6.0,48.2
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Advisor Sarophas|r
.turnin 9439 >> Turn in Unclaimed Baggage
.target Advisor Sarophas
step
.goto Badlands,6.49,47.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neeka|r
.turnin 1419 >> Turn in Coyote Thieves
.target Neeka Bloodscar
step
#label BrokenAlliance
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal|r
.turnin 2258 >> Turn in Badlands Reagent Run
.target Jarkal Mossmeld
step
>>Find & kill |cRXP_ENEMY_Boss Tho'grun|r. Loot him for the |cRXP_LOOT_Sign of Earth|r
>>|cRXP_ENEMY_Boss Tho'grun|r |cRXP_WARN_patrols the zone, accompanied by five guards|r
>>|cRXP_WARN_Skip this step if you cannot find him|r
.complete 782,1 
.unitscan Boss Tho'grun
.isOnQuest 782
step
#label KargathTurnins
.goto Badlands,2.91,45.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorn|r
.turnin 782 >> Turn in Broken Alliances
.target Gorn
.isQuestComplete 782
step
#optional
#completewith HammerFallFinalTurnIns
.abandon 782 
step
#completewith HammerFallFinalTurnIns
.goto Badlands,3.99,44.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrik|r
.fly Hammerfall >> Fly to Hammerfall
.target Gorrik
.zoneskip Arathi Highlands
step
.goto Arathi Highlands,74.25,33.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drum Fel|r
.turnin 679 >> Turn in Call to Arms
.target Drum Fel
step
.goto Arathi Highlands,74.00,33.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korin Fel|r
.turnin 680 >> Turn in The Real Threat
.target Korin Fel
step
#label HammerFallFinalTurnIns
.goto Arathi Highlands,74.70,36.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tor'gan|r
.turnin 640 >> Turn in The Broken Sigil
.target Tor'gan
step << Druid
#completewith DruidTraining4
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9634 >> Train your class spells
.target Loganaar
.xp <40,1
.xp >42,1
step << Druid
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9750 >> Train your class spells
.target Loganaar
.xp <40,1
.xp >42,1
step << Druid
#label DruidTraining4
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 22812 >> Train your class spells
.target Loganaar
.xp <44,1
step << Mage
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
.train 3567,3
step
#optional << Mage
#completewith next << !Mage
.hs >> Hearth to Orgrimmar
.use 6948
.bindlocation 1637,1
.zoneskip Orgrimmar
.train 3567,1 << Mage
step << !Mage
.goto Orgrimmar,54.65,67.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barkeep Morag|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Barkeep Morag
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8423 >> Train your class spells
.target Pephredo
.xp <40,1
.xp >42,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10159 >> Train your class spells
.target Pephredo
.xp <42,1
.xp >44,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10185 >> Train your class spells
.target Pephredo
.xp <44,1
step << Mage
.goto Orgrimmar,38.70,85.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r at the top of the hut
.train 11417 >> Train |T135744:0|t[Portal: Orgrimmar]
.target Thuul
.xp <40,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 8134 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
.xp >42,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 11314 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
.xp >42,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10392 >> Train your class spells
.target Kardris Dreamseeker
.xp <44,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <40,1
.xp >42,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <42,1
.xp >44,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11341 >> Train |T11341:0|t[Instant Poison IV]
.target Ormok
.xp <44,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11665 >> Train your class spells
.target Mirket
.xp <40,1
.xp >42,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 6789 >> Train your class spells
.target Mirket
.xp <42,1
.xp >44,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11671 >> Train your class spells
.target Mirket
.xp <44,1
step << Warlock
.goto Orgrimmar,47.52,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurgul|r
.vendor >>Buy any pet upgrades you can afford
.target Kurgul
.zoneskip Orgrimmar,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14324 >> Train your class spells
.target Ormak Grimshot
.xp <40,1
.xp >42,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14289 >> Train your class spells
.target Ormak Grimshot
.xp <42,1
.xp >44,1
step << Hunter
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 13542 >> Train your class spells
.target Ormak Grimshot
.xp <44,1
step << Hunter
#optional
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 14925 >> Train your pet spells
.target Xao'tsu
.xp <40,1
.xp >42,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24561 >> Train your pet spells
.target Xao'tsu
.xp <42,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 8106 >> Train your class spells
.target Ur'kyo
.xp <40,1
.xp >42,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 8106 >> Train your class spells
.target Ur'kyo
.xp <42,1
.xp >44,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10927 >> Train your class spells
.target Ur'kyo
.xp <44,1
step
.goto Orgrimmar,59.4,36.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dran|r
.accept 2283 >> Accept Necklace Recovery
.turnin 2283 >> Turn in Necklace Recovery
.target Dran Droffers
.itemcount 7666,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11608 >> Train your class spells
.target Grezz Ragefist
.xp <40,1
.xp >42,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11550 >> Train your class spells
.target Grezz Ragefist
.xp <42,1
.xp >44,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11584 >> Train your class spells
.target Grezz Ragefist
.xp <44,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20922 >> Train your class spells
.target Master Pyreanor
.xp <40,1
.xp >42,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20307 >> Train your class spells
.target Master Pyreanor
.xp <42,1
.xp >44,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 24275 >> Train your class spells
.target Master Pyreanor
.xp <44,1
step << Hunter
.goto Orgrimmar,78.08,38.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Jin'sora|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from him if it's available|r
.target Jin'sora
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
.itemcount 11307,<1
step << Orc !Warlock
#optional
.goto Orgrimmar,69.40,13.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kildar|r and |cRXP_FRIENDLY_Ogunaro|r
.train 825 >>Train |T136103:0|t[Wolf Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132224:0|t[|cFF0070FFWolf|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Kildar
.target Ogunaro Wolfrunner
step << Troll
#optional
#completewith next
.subzone 367 >> Travel to Sen'Jin Village
.xp <30,1
.money <38
.skill riding,75,1
step << Troll
#optional
.goto Durotar,55.28,75.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xar'Ti|r and |cRXP_FRIENDLY_Zjolnir|r
.train 10861 >>Train |T136103:0|t[Raptor Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132253:0|t[|cFF0070FFRaptor|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Xar'Ti
.target Zjolnir
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 42-43 Stranglethorn Vale part 2
#next 43-45 Dustwallow Marsh part 2
step
#completewith STVZepp
.zone Durotar >> Leave Orgrimmar
.zoneskip Durotar
step
#label STVZepp
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Stranglethorn Vale >>Take the Zeppelin to Stranglethorn Vale
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,32.12,29.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.accept 572 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.turnin 1240 >> Turn in The Troll Witchdoctor
.target Kin'weelay
.isQuestTurnedIn 1238
step
.goto Stranglethorn Vale,32.10,27.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nimboya|r
.accept 584 >> Accept Bloodscalp Clan Heads
.target Nimboya
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.accept 598 >> Accept Split Bone Necklace
.target Kin'weelay
step
#completewith TrollHeads
.goto Stranglethorn Vale,23.82,10.78,200 >> Travel to the Ruins of Zul'Kunda
.subzoneskip 102
step
#completewith TrollHeads
.goto Stranglethorn Vale,23.82,10.78,200 >> Travel to the Ruins of Zul'Kunda
.subzoneskip 102
step
#completewith next
>>Kill an |cRXP_ENEMY_Elder Saltwater Crocolisk|r. Loot it for its |cRXP_LOOT_Skin|r
.complete 628,1 
.unitscan Elder Saltwater Crocolisk
step
.goto Stranglethorn Vale,23.52,9.53
>>Kill |cRXP_ENEMY_Nezzliok the Dire|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Be very careful! |cRXP_ENEMY_Nezzliok|r casts|r |T136115:0|t[Shock]|cRXP_WARN_. An instant 280 damage spell|r
.complete 584,2 
.unitscan Nezzliok the Dire
step
#label TrollHeads
.goto Stranglethorn Vale,23.44,8.14
>>Kill |cRXP_ENEMY_Gan'zulah|r. Loot him for his |cRXP_LOOT_Head|r
.complete 584,1 
.unitscan Gan'zulah
step
#completewith next
.subzone 117 >> Return to Grom'gol Base Camp
step
#completewith next
>>Kill an |cRXP_ENEMY_Elder Saltwater Crocolisk|r. Loot it for its |cRXP_LOOT_Skin|r
.complete 628,1 
.unitscan Elder Saltwater Crocolisk
step
.goto Stranglethorn Vale,32.22,27.60
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.turnin 584 >> Turn in Bloodscalp Clan Heads
.accept 585 >> Accept Speaking with Nezzliok
step
#loop
.goto Stranglethorn Vale,32.99,38.06,0
.goto Stranglethorn Vale,31.00,42.50,60,0
.goto Stranglethorn Vale,32.99,38.06,50,0
.goto Stranglethorn Vale,31.42,40.17,50,0
.goto Stranglethorn Vale,30.14,43.06,50,0
.goto Stranglethorn Vale,28.36,43.47,50,0
.goto Stranglethorn Vale,28.53,45.96,50,0
.goto Stranglethorn Vale,30.61,44.54,50,0
.goto Stranglethorn Vale,31.80,43.08,50,0
.goto Stranglethorn Vale,33.24,40.38,50,0
.goto Stranglethorn Vale,33.85,38.45,50,0
>>Kill |cRXP_ENEMY_Jungle Stalkers|r. Loot them for their |cRXP_LOOT_Feathers|r
.complete 196,1 
.complete 572,1 
.mob Jungle Stalker
step
#loop
.goto Stranglethorn Vale,40.36,41.93,0
.goto Stranglethorn Vale,40.36,41.93,50,0
.goto Stranglethorn Vale,43.73,41.47,50,0
.goto Stranglethorn Vale,44.73,42.05,50,0
.goto Stranglethorn Vale,43.26,42.29,50,0
.goto Stranglethorn Vale,42.55,41.55,50,0
.goto Stranglethorn Vale,41.48,41.18,50,0
.goto Stranglethorn Vale,41.43,40.36,50,0
>>Kill |cRXP_ENEMY_Venture Co. Goblins|r. Loot them for their |cRXP_LOOT_Crystals|r
.complete 600,1 
.mob Venture Co. Surveyor
.mob Venture Co. Foreman
.mob Venture Co. Strip Miner
.mob Venture Co. Tinkerer
.mob Foreman Cozzle
step
#completewith SkullP
>>Kill |cRXP_ENEMY_Skullsplitter Trolls|r. Loot them for their |cRXP_LOOT_Tusks|r and |cRXP_LOOT_Necklaces|r
.complete 209,1 
.complete 598,1 
.mob Skullsplitter Mystic
.mob Skullsplitter Warrior
.mob Skullsplitter Axe Thrower
step
.goto Stranglethorn Vale,42.20,36.10
>>Loot the |cRXP_PICK_Ziata'jai Trophy Skulls|r for its |cRXP_LOOT_Trophy|r
.complete 585,2 
step
.goto Stranglethorn Vale,47.60,39.60
>>Loot the |cRXP_PICK_Zul'Mamwe Trophy Skulls|r for its |cRXP_LOOT_Trophy|r
.complete 585,3 
step
#label SkullP
.goto Stranglethorn Vale,46.10,32.30
>>Loot the |cRXP_PICK_Balia'mah Trophy Skulls|r for its |cRXP_LOOT_Trophy|r
.complete 585,1 
step
#loop
.goto Stranglethorn Vale,42.13,36.29,0
.goto Stranglethorn Vale,42.13,36.29,50,0
.goto Stranglethorn Vale,41.89,35.93,50,0
.goto Stranglethorn Vale,42.45,35.03,50,0
.goto Stranglethorn Vale,42.47,33.35,50,0
.goto Stranglethorn Vale,43.47,33.25,50,0
.goto Stranglethorn Vale,45.06,32.39,50,0
.goto Stranglethorn Vale,45.51,31.66,50,0
.goto Stranglethorn Vale,46.42,31.98,50,0
.goto Stranglethorn Vale,47.19,30.85,50,0
.goto Stranglethorn Vale,47.11,32.54,50,0
.goto Stranglethorn Vale,47.13,34.31,50,0
.goto Stranglethorn Vale,45.23,34.47,50,0
.goto Stranglethorn Vale,44.00,35.53,50,0
.goto Stranglethorn Vale,43.44,37.92,50,0
>>Finish killing |cRXP_ENEMY_Skullsplitter Trolls|r. Loot them for their |cRXP_LOOT_Tusks|r and |cRXP_LOOT_Necklaces|r
.complete 209,1 
.complete 598,1 
.mob Skullsplitter Mystic
.mob Skullsplitter Warrior
.mob Skullsplitter Axe Thrower
step
#loop
.goto Stranglethorn Vale,47.26,28.58,0
.goto Stranglethorn Vale,48.95,19.87,0
.goto Stranglethorn Vale,47.26,28.58,50,0
.goto Stranglethorn Vale,49.61,23.98,50,0
.goto Stranglethorn Vale,48.95,19.87,50,0
.goto Stranglethorn Vale,47.26,23.98,50,0
.goto Stranglethorn Vale,48.95,19.87,50,0
>>Kill |cRXP_ENEMY_Bhag'thera|r. Loot him for his |cRXP_LOOT_Fang|r
>>|cRXP_WARN_Before engaging|r |cRXP_ENEMY_Bhag'thera|r|cRXP_WARN_, clear the area of|r |cRXP_ENEMY_Shadowmaw Panthers|r |cRXP_WARN_to avoid adds|r
.complete 193,1 
.unitscan Bhag'thera
step
#sticky
#completewith EnterUldaman
.subzone 1337,2 >> Now you should be looking for a group to Uldaman
.dungeon ULDA
step
#completewith next
.subzone 100 >>Travel to Nesingwary's Expedition
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet|r and |cRXP_FRIENDLY_S. J. Erlgadin|r
.turnin 196 >> Turn in Raptor Mastery
.accept 197 >> Accept Raptor Mastery
.target +Hemet Nesingwary Jr.
.goto Stranglethorn Vale,35.66,10.81
.turnin 193 >> Turn in Panther Mastery
.goto Stranglethorn Vale,35.55,10.55
.target +Sir S. J. Erlgadin
step
#completewith GGturnins2
.subzone 117 >>Travel to Grom'gol Base Camp
step
.goto Stranglethorn Vale,32.20,27.70
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.turnin 585 >> Turn in Speaking with Nezzliok
.accept 1261 >> Accept Marg Speaks
.isQuestTurnedIn 1240
step
#optional
.goto Stranglethorn Vale,32.20,27.70
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.turnin 585 >> Turn in Speaking with Nezzliok
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.turnin 598 >> Turn in Split Bone Necklace
.target Kin'weelay
step
#label GGturnins2
.goto Stranglethorn Vale,32.10,29.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.turnin 572 >> Turn in Mok'thardin's Enchantment
.accept 571 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
.goto Stranglethorn Vale,33.51,32.53
>>Kill an |cRXP_ENEMY_Elder Saltwater Crocolisk|r. Loot it for its |cRXP_LOOT_Skin|r
>>|cRXP_WARN_There are more|r |cRXP_ENEMY_Elder Saltwater Crocolisks|r |cRXP_WARN_north along the coast|r
.complete 628,1 
.unitscan Elder Saltwater Crocolisk
step
#completewith BloodSailPart1
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fly Booty Bay >> Fly to Booty Bay
.target Thysta
.subzoneskip 35
step
.goto Stranglethorn Vale,27.10,77.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleet Master Seahorn|r
.turnin 669 >> Turn in Sunken Treasure
.target Fleet Master Seahorn
.isOnQuest 669
step
.goto Stranglethorn Vale,26.95,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kebok|r on the inn's top floor
.turnin 209 >> Turn in Skullsplitter Tusks
.target Kebok
step
.goto Stranglethorn Vale,26.99,77.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Krazek|r
.accept 2864 >> Accept Tran'rek
.target Krazek
step
.goto Stranglethorn Vale,27.10,77.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank|r on the inn's ground floor
.turnin 600 >> Turn in Venture Company Mining
.target Crank Fizzlebub
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.accept 2872 >> Accept Stoley's Debt
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,28.29,77.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drizzlik|r
.turnin 628 >> Turn in Excelsior
.target Drizzlik
step
#completewith EnterUldaman
.goto Stranglethorn Vale,26.87,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Badlands >> Fly to Badlands
.target Gringer
.zoneskip Badlands
.dungeon ULDA
step
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal Mossmeld|r
.accept 2202 >> Accept Uldaman Reagent Run
.target Jarkal Mossmeld
.isQuestTurnedIn 2258
.dungeon ULDA
step
.goto Badlands,51.38,76.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Theldurin the Lost|r
.accept 709 >> Accept Solution to Doom
.target Theldurin the Lost
.dungeon ULDA
step
.goto Eastern Kingdoms,54.49,57.77
.zone 1415 >> Travel to Uldaman
.dungeon ULDA
step
#completewith EnterUldaman
>>Loot the |cRXP_LOOT_Magenta Fungus Caps|r on the ground
>>|cRXP_WARN_This can be completed INSIDE and OUTSIDE of Uldaman.|r
>>|cRXP_WARN_It is recommended that maximum 3 players attempt to complete this quest if you're doing only 1 run. There aren't enough|r |cRXP_LOOT_Magenta Fungus Caps|rr |cRXP_WARN_for everybody|r
.complete 2202,1 
.isOnQuest 2202
.dungeon ULDA
step
#label EnterUldaman
.goto Eastern Kingdoms,53.85,57.68
.subzone 1337,2 >> Zone into Uldaman
.dungeon ULDA
step
>>Kill |cRXP_ENEMY_Archaedas|r
>>Click |cRXP_PICK_The Discs of Norgannon|r
.accept 2278 >> Accept The Platinum Discs
.mob Archaedas
.dungeon ULDA
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lore Keeper of Norgannon|r
.complete 2278,1 
.skipgossip
.target Lore Keeper of Norgannon
.dungeon ULDA
step
>>Click |cRXP_PICK_The Discs of Norgannon|r
.turnin 2278 >> Turn in The Platinum Discs
.accept 2280 >> Accept The Platinum Discs
.dungeon ULDA
step
#completewith next
.zone Badlands >>Leave Uldaman
.dungeon ULDA
step
.goto Badlands,2.42,46.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jarkal Mossmeld|r
.turnin 2202 >> Turn in Uldaman Reagent Run
.target Jarkal Mossmeld
.dungeon ULDA
.isQuestComplete 2202







step << Mage
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
.train 3567,3
step
#optional << Mage
#completewith next << !Mage
.hs >> Hearth to Orgrimmar
.use 6948
.bindlocation 1637,1
.zoneskip Orgrimmar
.train 3567,1 << Mage
step << !Mage
.goto Orgrimmar,54.65,67.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barkeep Morag|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Barkeep Morag
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 8423 >> Train your class spells
.target Pephredo
.xp <40,1
.xp >42,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10159 >> Train your class spells
.target Pephredo
.xp <42,1
.xp >44,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10185 >> Train your class spells
.target Pephredo
.xp <44,1
step << Mage
.goto Orgrimmar,38.70,85.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r at the top of the hut
.train 11417 >> Train |T135744:0|t[Portal: Orgrimmar]
.target Thuul
.xp <40,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 8134 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
.xp >42,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 11314 >> Train your class spells
.target Kardris Dreamseeker
.xp <40,1
.xp >42,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10392 >> Train your class spells
.target Kardris Dreamseeker
.xp <44,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <40,1
.xp >42,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8624 >> Train your class spells
.target Ormok
.xp <42,1
.xp >44,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11341 >> Train |T11341:0|t[Instant Poison IV]
.target Ormok
.xp <44,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11665 >> Train your class spells
.target Mirket
.xp <40,1
.xp >42,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 6789 >> Train your class spells
.target Mirket
.xp <42,1
.xp >44,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11671 >> Train your class spells
.target Mirket
.xp <44,1
step << Warlock
.goto Orgrimmar,47.52,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurgul|r
.vendor >>Buy any pet upgrades you can afford
.target Kurgul
.zoneskip Orgrimmar,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14324 >> Train your class spells
.target Ormak Grimshot
.xp <40,1
.xp >42,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14289 >> Train your class spells
.target Ormak Grimshot
.xp <42,1
.xp >44,1
step << Hunter
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 13542 >> Train your class spells
.target Ormak Grimshot
.xp <44,1
step << Hunter
#optional
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 14925 >> Train your pet spells
.target Xao'tsu
.xp <40,1
.xp >42,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24561 >> Train your pet spells
.target Xao'tsu
.xp <42,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 8106 >> Train your class spells
.target Ur'kyo
.xp <40,1
.xp >42,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 8106 >> Train your class spells
.target Ur'kyo
.xp <42,1
.xp >44,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10927 >> Train your class spells
.target Ur'kyo
.xp <44,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11608 >> Train your class spells
.target Grezz Ragefist
.xp <40,1
.xp >42,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11550 >> Train your class spells
.target Grezz Ragefist
.xp <42,1
.xp >44,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11584 >> Train your class spells
.target Grezz Ragefist
.xp <44,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20922 >> Train your class spells
.target Master Pyreanor
.xp <40,1
.xp >42,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20307 >> Train your class spells
.target Master Pyreanor
.xp <42,1
.xp >44,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 24275 >> Train your class spells
.target Master Pyreanor
.xp <44,1
step << Hunter
.goto Orgrimmar,78.08,38.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Jin'sora|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from him if it's available|r
.target Jin'sora
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
.itemcount 11307,<1
step
.goto Orgrimmar,75.18,34.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom Rockmaul|r
.accept 2981 >> Accept A Threat in Feralas
.target Belgrom Rockmaul
step
#completewith ThunderBluffVisit3
.goto Orgrimmar,45.13,63.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.zoneskip Thunder Bluff
.target Doras
step << Hunter
.goto Thunder Bluff,46.98,45.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kuna Thunderhorn|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from her if it's available|r
.target Kuna Thunderhorn
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
.itemcount 11307,<1
step << Shaman
#ah
.goto Thunder Bluff,53.00,56.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Kard|r|cRXP_BUY_. Buy a|r |T135341:0|t[Rondel] |cRXP_BUY_from him for your off-hand|r
>>|cRXP_WARN_Alternatively, buy a better one handed weapon from the AH|r
.collect 2534,1,11201,1 
.money <4.0888
.target Kard Ragetotem
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
step << Shaman
#ssf
.goto Thunder Bluff,53.00,56.63
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Kard|r|cRXP_BUY_. Buy a|r |T135341:0|t[Rondel] |cRXP_BUY_from him for your off-hand|r
.collect 2534,1,11201,1 
.money <4.0888
.target Kard Ragetotem
.itemStat 17,QUALITY,<7
.itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<24.0
step << Shaman
#ah
.goto Thunder Bluff,54.06,57.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Delgo|r|cRXP_BUY_. Buy a|r |T132392:0|t[Francisca] |cRXP_BUY_from him|r
>>|cRXP_WARN_Alternatively, buy a better one handed weapon from the AH|r
.money <4.1776
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.8
.target Delgo Ragetotem
step << Shaman
#ssf
.goto Thunder Bluff,54.06,57.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Delgo|r|cRXP_BUY_. Buy a|r |T132392:0|t[Francisca] |cRXP_BUY_from him|r
.money <4.1776
.itemStat 16,QUALITY,<7
.itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<25.8
.target Delgo Ragetotem
step
.goto Thunder Bluff,61.40,80.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melor|r
.turnin 1136 >> Turn in Frostmaw
.accept 1205 >> Accept Deadmire
.target Melor Stonehoof
.isQuestComplete 1136
step
#optional
#completewith ThunderBluffVisit3
.destroy 5838 >>|cRXP_WARN_Destroy the|r |T134252:0|t[Kodo Skin Scroll] |cRXP_WARN_as you no longer need it|r
step
#optional
.goto Thunder Bluff,61.40,80.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melor|r
.accept 1205 >> Accept Deadmire
.target Melor Stonehoof
step
#label ThunderBluffVisit3
.goto Thunder Bluff,54.00,80.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mosarn|r
.turnin 1276 >> Turn in The Black Shield
.accept 11204 >> Accept Return to Krog
.target Mosarn
step << !Undead 
.goto Thunder Bluff,34.42,46.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage|r
.turnin 1049 >> Accept Compendium of the Fallen
.target Sage
.dungeon SM
.isQuestComplete 1049
step << Mage
.goto Thunder Bluff,22.48,16.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Birgitte|r
.train 3566 >> Train |T135765:0|t[Teleport: Thunder Bluff]
.target Birgitte Cranston
step << !Undead
#optional
.abandon 1049 >> Compendium of the Fallen
.isOnQuest 1049
.dungeon SM
step << Tauren
#optional
#completewith next
.subzone 222 >> Travel to Bloodhoof Village
.xp <30,1
.money <38
.skill riding,75,1
step << Tauren
#optional
#label KodoRiding
.goto Mulgore,47.64,58.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xar'Ti|r and |cRXP_FRIENDLY_Zjolnir|r
.train 132245 >>Train |T136103:0|t[Kodo Riding]
.vendor >>|cRXP_BUY_Buy a|r |T132253:0|t[|cFF0070FFKodo|r]
.xp <30,1
.money <38
.skill riding,75,1
.target Kar Stormsinger
.target Harb Clawhoof
step << Tauren
#optional
#completewith FlyDWM1
.subzone 378 >>Travel to Camp Taurajo
.skill riding,<75,1
.zoneskip Thunder Bluff
.dungeon !RFD
step
#sticky
#completewith EnterRFD
.subzone 722,2 >> Now you should be looking for a group to Razorfen Downs
.dungeon RFD
step
#completewith EnterRFD
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Camp Taurajo >>Fly to Camp Taurajo
.target Tal
.zoneskip Thunder Bluff,1 << Tauren
.dungeon RFD
step
#completewith EnterRFD
.goto The Barrens,46.30,90.27,200 >> Travel to Razorfen Downs
.dungeon RFD
step
#completewith EnterRFD
>>|cRXP_WARN_Have somebody in your group share the following quests if possible. Alternatively, go to Undercity to pick them up yourself|r
.accept 3341 >> Accept Bring the End
.accept 6521 >> Accept An Unholy Alliance
.target Andrew Brownell
.target Varimathras
.isQuestTurnedIn 6522
.dungeon RFD
step
#optional
#completewith EnterRFD
>>|cRXP_WARN_Have somebody in your group share the following quest if possible. Alternatively, go to Undercity to pick it up yourself|r
.accept 3341 >> Accept Bring the End
.target Andrew Brownell
.isQuestAvailable 6522
.dungeon RFD
step
#completewith next
.goto The Barrens,46.30,90.27,50,0
.goto The Barrens,46.92,91.84,50,0
.goto The Barrens,48.20,92.66,50,0
>>Kill |cRXP_ENEMY_Ambassador Malcin|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_He can spawn at 4 different tents outside the instance|r
.complete 6521,1 
.unitscan Ambassador Malcin
.isOnQuest 6521
.dungeon RFD
step
.goto The Barrens,49.012,94.938
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Myriam Moonsinger|r
.accept 6626 >> Accept A Host of Evil
.target Myriam Moonsinger
.dungeon RFD
step
#completewith next
>>Kill |cRXP_ENEMY_Razorfen Battleguards|r, |cRXP_ENEMY_Razorfen Thornweavers|r and |cRXP_ENEMY_Death's Head Cultists|r
>>|cRXP_WARN_This quest is completed outside of the Instance|r
.complete 6626,1 
.mob +Razorfen Battleguard
.complete 6626,2 
.mob +Razorfen Thornweaver
.complete 6626,3 
.mob +Death's Head Cultist
.isOnQuest 6626
.dungeon RFD
step
#loop
.goto The Barrens,48.57,95.69,0
.goto The Barrens,48.20,92.66,0
.goto The Barrens,46.92,91.84,0
.goto The Barrens,46.30,90.27,0
.goto The Barrens,48.57,95.69,50,0
.goto The Barrens,48.20,92.66,50,0
.goto The Barrens,46.92,91.84,50,0
.goto The Barrens,46.30,90.27,50,0
>>Kill |cRXP_ENEMY_Ambassador Malcin|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_He can spawn at 4 different tents outside the instance|r
.complete 6521,1 
.unitscan Ambassador Malcin
.isOnQuest 6521
.dungeon RFD
step
#loop
.goto The Barrens,48.23,92.31,0
.goto The Barrens,48.23,92.31,70,0
.goto The Barrens,48.15,90.57,70,0
.goto The Barrens,47.86,88.75,70,0
.goto The Barrens,46.46,90.19,70,0
.goto The Barrens,46.94,92.19,70,0
>>Kill |cRXP_ENEMY_Razorfen Battleguards|r, |cRXP_ENEMY_Razorfen Thornweavers|r and |cRXP_ENEMY_Death's Head Cultists|r
>>|cRXP_WARN_This quest is completed outside of the Instance|r
.complete 6626,1 
.mob +Razorfen Battleguard
.complete 6626,2 
.mob +Razorfen Thornweaver
.complete 6626,3 
.mob +Death's Head Cultist
.isOnQuest 6626
.dungeon RFD
step
.goto The Barrens,49.012,94.938
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Myriam Moonsinger|r
.turnin 6626 >> Turn in A Host of Evil
.target Myriam Moonsinger
.isQuestComplete 6626
.dungeon RFD
step
#label EnterRFD
.goto The Barrens,49.255,93.077,0
.goto The Barrens,49.255,93.077,30,0
.goto 1414,53.26,71.18
.subzone 722,2 >> Enter Razorfen Downs
.dungeon RFD
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belnistrasz|r
>>|cRXP_WARN_Take the left path and stick left the entire way until you reach The Murder Pens to get to|r |cRXP_FRIENDLY_Belnistrasz|r
>>|cRXP_WARN_Do not accept Extinguishing the Idol until the rest of your party is ready as this begins the escort. Auto accept has been turned off for this step|r
.accept 3523 >> Accept Scourge of the Downs
.turnin 3523 >> Turn in Scourge of the Downs
.accept 3525,1 >> Accept Extinguishing the Idol
.target Belnistrasz
.dungeon RFD
step
>>Follow and protect |cRXP_FRIENDLY_Belnistrasz|r during his ritual
.complete 3525,1 
.target Belnistrasz
.isOnQuest 3525
.dungeon RFD
step
>>Click |cRXP_PICK_Belnistrasz's Brazier|r
.turnin 3525 >> Turn in Extinguishing the Idol
.isQuestComplete 3525
.dungeon RFD
step
>>Kill |cRXP_ENEMY_Amnennar the Coldbringer|r. Loot him for his |cRXP_LOOT_Skull|r
.complete 3341,1 
.mob Amnennar the Coldbringer
.isOnQuest 3341
.dungeon RFD
step
#optional
#completewith UCRFDTurnins
.zone Undercity >>Travel to Undercity to turn in your RFD quests
>>|cRXP_WARN_Alternatively abandon "Bring the End" and "An Unholy Alliance" or turn it in later|r
>>|cRXP_WARN_The guide won't have you go to Undercity again until level 50|r
.isQuestComplete 3341
.isQuestComplete 6521
.dungeon RFD
step
#optional
#completewith UCRFDTurnins
.zone Undercity >>Travel to Undercity to turn in your RFD quest
>>|cRXP_WARN_Alternatively abandon "Bring the End" or turn it in later|r
>>|cRXP_WARN_The guide won't have you go to Undercity again until level 50|r
.isQuestComplete 3341
.isNotOnQuest 6521
.dungeon RFD
step
#optional
#completewith UCRFDTurnins
.zone Undercity >>Travel to Undercity to turn in your RFD quest
>>|cRXP_WARN_Alternatively abandon "An Unholy Alliance" or turn it in later|r
>>|cRXP_WARN_The guide won't have you go to Undercity again until level 50|r
.isQuestComplete 6521
.isNotOnQuest 3341
.dungeon RFD
step
#optional
.goto Undercity,74.05,33.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andrew|r
.turnin 3341 >>Turn in Bring the End
.target Andrew Brownell
.isQuestComplete 3341
.dungeon RFD
step
#optional
.goto Undercity,56.24,92.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Varimathras|r
.turnin 6521 >>Turn in An Unholy Alliance
.target Varimathras
.isQuestComplete 6521
.dungeon RFD
step
#optional
#label UCRFDTurnins
step
#optional
.abandon 6521,6626,3341
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 30-45
<< Horde
#name 43-45 Dustwallow Marsh part 2
#next 45-46 Feralas
step
#completewith DWM2Start
.zone Dustwallow Marsh >>Travel to Dustwallow Marsh
.dungeon RFD
step << Tauren
#label FlyDWM1
#completewith DWM2Start
.goto The Barrens,44.45,59.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Omusa|r
.fly Brackenwall Village >>Fly to Brackenwall Village
.target Omusa Thunderhorn
.zoneskip Thunder Bluff
.dungeon !RFD
step
#label FlyDWM2
#completewith DWM2Start
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Brackenwall Village >>Fly to Brackenwall Village
.target Tal
.zoneskip Dustwallow Marsh << !Tauren
.zoneskip Thunder Bluff,1 << Tauren
.dungeon !RFD
step
.goto Dustwallow Marsh,36.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overlord Mok'Morokk|r
.accept 1166 >> Accept Overlord Mok'Morokk's Concern
.target Overlord Mok'Morokk
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 11204 >> Turn in Return to Krog
.accept 11200 >> Accept More than Coincidence
.accept 11201 >> Accept The Grimtotem Plot
.target Krog
step
.goto Dustwallow Marsh,36.89,32.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Little" Logok|r
.home >> Set your Hearthstone to Brackenwall Village
.target "Little" Logok
.bindlocation 496
.isQuestAvailable 11162
step
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.accept 1169 >> Accept Identifying the Brood
.target Draz'Zilb
step
.goto Dustwallow Marsh,37.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharg|r
.accept 1168 >> Accept Army of the Black Dragon
.target Tharg
step
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.turnin 1261 >> Turn in Marg Speaks
.accept 11213 >> Accept Check Up on Tabetha
.accept 11215 >> Accept Help Mudsprocket
.target Nazeer Bloodpike
.isQuestTurnedIn 1240
step
#optional
#label DWM2Start
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.accept 11213 >> Accept Check Up on Tabetha
.accept 11215 >> Accept Help Mudsprocket
.target Nazeer Bloodpike
step
#completewith next
>>Loot |cRXP_LOOT_Blackhoof Armaments|r on the ground
.complete 11200,1 
step
#label GrimtotemNotes
#loop
.goto Dustwallow Marsh,40.82,12.17,0
.goto Dustwallow Marsh,43.03,14.79,40,0
.goto Dustwallow Marsh,42.19,13.71,40,0
.goto Dustwallow Marsh,40.82,12.17,40,0
.goto Dustwallow Marsh,41.02,10.56,40,0
.goto Dustwallow Marsh,42.37,11.55,40,0
>>Kill |cRXP_ENEMY_Grimtotem Elders|r. Loot them for their |T134328:0|t[|cRXP_LOOT_Grimtotem Notes|r]
.collect 33050,4,11201,1 
.mob Grimtotem Elder
step
#requires GrimtotemNotes
.use 33050 >>|cRXP_WARN_Use the|r |T134328:0|t[|cRXP_LOOT_Grimtotem Notes|r] |cRXP_WARN_to create the|r |T134331:0|t[|cRXP_LOOT_Grimtotem Battle Plan|r]
.complete 11201,1 
step
#loop
.goto Dustwallow Marsh,42.88,15.50,0
.goto Dustwallow Marsh,41.66,12.92,30,0
.goto Dustwallow Marsh,41.43,10.79,30,0
.goto Dustwallow Marsh,42.32,11.22,30,0
.goto Dustwallow Marsh,42.88,15.50,30,0
.goto Dustwallow Marsh,44.81,17.71,30,0
>>Loot |cRXP_LOOT_Blackhoof Armaments|r on the ground
.complete 11200,1 
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 11200 >> Turn in More than Coincidence
.turnin 11201 >> Turn in The Grimtotem Plot
.accept 11203 >> Accept Seek Out Tabetha
.target Krog
step
#completewith next
.subzone 4049 >>Travel to Tabetha's Farm
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r and |cRXP_FRIENDLY_Apprentice Garion|r
.turnin 11203 >> Turn in Seek Out Tabetha
.turnin 11213 >> Turn in Check Up on Tabetha
.accept 11205 >> Accept Raze Direhorn Post!
.target +Tabetha
.goto Dustwallow Marsh,46.02,57.10
.accept 11169 >> Accept The Grimtotem Weapon
.accept 11173 >> Accept The Reagent Thief
.target +Apprentice Garion
.goto Dustwallow Marsh,46.05,57.25
step
.goto Dustwallow Marsh,46.10,57.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Morlann|r outside
.accept 11156 >> Accept Direhorn Raiders
.accept 11172 >> Accept The Zeppelin Crash
.target Apprentice Morlann
step
.goto Dustwallow Marsh,53.57,56.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moxie Steelgrille|r
.turnin 11172 >> Turn in The Zeppelin Crash
.accept 11174 >> Accept Corrosion Prevention
.accept 11207 >> Accept Secure the Cargo!
.target Moxie Steelgrille
step
#completewith SeafBooster
.use 33108 >>|cRXP_WARN_Use the|r |T133000:0|t[Ooze Buster] |cRXP_WARN_on|r |cRXP_ENEMY_Swamp Oozes|r
>>|cRXP_WARN_This can only be used when you are|r |T136048:0|t[Energized!] |cRXP_WARN_. Stand near a |cRXP_PICK_Power Core Fragment|r to obtain the buff|r
.complete 11174,1 
.mob Acidic Swamp Ooze
.mob Bubbling Swamp Ooze
step
#completewith ElectricOozes
>>Loot |cRXP_LOOT_Zeppelin Cargo|r on the ground
.complete 11207,1 
step
#label SeafBooster
.goto Dustwallow Marsh,54.10,56.50
>>Loot the |cRXP_PICK_Crate|r on the ground near the crashed Zeppelin for the |cRXP_LOOT_Seaforium Booster|r
.complete 1187,1 
step
#label ElectricOozes
#loop
.goto Dustwallow Marsh,53.73,55.87,0
.goto Dustwallow Marsh,52.94,51.98,0
.goto Dustwallow Marsh,51.98,55.52,0
.goto Dustwallow Marsh,51.61,58.59,0
.goto Dustwallow Marsh,53.73,55.87,50,0
.goto Dustwallow Marsh,52.94,51.98,50,0
.goto Dustwallow Marsh,51.98,55.52,50,0
.goto Dustwallow Marsh,51.61,58.59,50,0
.use 33108 >>|cRXP_WARN_Use the|r |T133000:0|t[Ooze Buster] |cRXP_WARN_on|r |cRXP_ENEMY_Swamp Oozes|r
>>|cRXP_WARN_This can only be used when you are|r |T136048:0|t[Energized!] |cRXP_WARN_. Stand near a |cRXP_PICK_Power Core Fragment|r to obtain the buff|r
.complete 11174,1 
.mob Acidic Swamp Ooze
.mob Bubbling Swamp Ooze
step
#loop
.goto Dustwallow Marsh,52.71,52.58,0
.goto Dustwallow Marsh,52.71,52.58,50,0
.goto Dustwallow Marsh,51.73,51.54,50,0
.goto Dustwallow Marsh,51.37,52.65,50,0
.goto Dustwallow Marsh,50.86,55.91,50,0
.goto Dustwallow Marsh,51.07,59.02,50,0
.goto Dustwallow Marsh,49.75,60.45,50,0
.goto Dustwallow Marsh,51.39,60.93,50,0
.goto Dustwallow Marsh,52.76,59.12,50,0
.goto Dustwallow Marsh,54.53,56.71,50,0
.goto Dustwallow Marsh,54.59,54.62,50,0
>>Loot |cRXP_LOOT_Zeppelin Cargo|r on the ground
.complete 11207,1 
step
.goto Dustwallow Marsh,53.57,56.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Moxie Steelgrille|r
.turnin 11174 >> Turn in Corrosion Prevention
.turnin 11207 >> Turn in Secure the Cargo!
.accept 11208 >> Accept Delivery for Drazzit
.target Moxie Steelgrille
step
#loop
.goto Dustwallow Marsh,56.51,61.15,0
.goto Dustwallow Marsh,56.51,61.15,50,0
.goto Dustwallow Marsh,55.46,61.60,50,0
.goto Dustwallow Marsh,54.80,62.41,50,0
.goto Dustwallow Marsh,54.31,63.24,50,0
.goto Dustwallow Marsh,54.68,64.41,50,0
.goto Dustwallow Marsh,56.10,65.14,50,0
.goto Dustwallow Marsh,56.52,63.62,50,0
.goto Dustwallow Marsh,56.81,62.56,50,0
.goto Dustwallow Marsh,57.30,60.20,50,0
>>Kill |cRXP_ENEMY_Muckshell Makruras|r on the beach. Loot them for a |cRXP_LOOT_Jeweled Pendant|r
.complete 1261,1 
.isOnQuest 1261
.mob Muckshell Razorclaw
.mob Muckshell Clacker
.mob Muckshell Scrabbler
.mob Muckshell Pincer
.mob Muckshell Snapclaw
.unitscan Lord Angler
step
#completewith DireGrims
.subzone 4046 >> Travel to Direhorn Post
step
#completewith DireGrims
.use 33115 >>Kill |cRXP_ENEMY_Apothecary Cylla|r. Loot her for the |T133472:0|t[|cRXP_LOOT_Sealed Letter|r]. Use it to accept the quest
.collect 33115,1,11186 
.accept 11186 >> Accept Signs of Treachery?
.unitscan Apothecary Cylla
step
#completewith next
>>Kill |cRXP_ENEMY_Grimtotem Earthbinders|r and |cRXP_ENEMY_Grimtotem Destroyers|r
.complete 11156,1 
.mob Grimtotem Earthbinder
.mob Grimtotem Destroyer
step
.use 33072 >>|cRXP_WARN_Use|r |T135432:0|t[Tabetha's Torch] |cRXP_WARN_in the |cRXP_ENEMY_Grimtotem|r tents|r
.complete 11205,1 
.goto Dustwallow Marsh,46.62,46.04
.complete 11205,2 
.goto Dustwallow Marsh,47.23,46.59
.complete 11205,3 
.goto Dustwallow Marsh,47.41,47.54
step
#label DireGrims
#loop
.goto Dustwallow Marsh,46.64,49.08,0
.goto Dustwallow Marsh,46.64,49.08,40,0
.goto Dustwallow Marsh,46.07,47.06,40,0
.goto Dustwallow Marsh,47.09,45.39,40,0
.goto Dustwallow Marsh,47.26,47.90,40,0
>>Kill |cRXP_ENEMY_Grimtotem Earthbinders|r and |cRXP_ENEMY_Grimtotem Destroyers|r
.complete 11156,1 
.mob Grimtotem Earthbinder
.mob Grimtotem Destroyer
step
.goto Dustwallow Marsh,47.22,46.59
.use 33115 >>Kill |cRXP_ENEMY_Apothecary Cylla|r. Loot her for the |T133472:0|t[|cRXP_LOOT_Sealed Letter|r]. Use it to accept the quest
.collect 33115,1,11186 
.accept 11186 >> Accept Signs of Treachery?
.unitscan Apothecary Cylla
step
#completewith MudsprocketVisit1
.use 33101 >>|cRXP_WARN_Use the|r |T136008:0|t[Captured Totem] |cRXP_WARN_within The Quagmire|r
>>Kill |cRXP_ENEMY_Mottled Drywallow Crocolisks|r and |cRXP_ENEMY_Drywall Snapper|r near the totem
.complete 11169,1 
.mob Mottled Drywallow Crocolisk
.mob Drywall Snapper
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r
.turnin 11205 >> Turn in Raze Direhorn Post!
.accept 11206 >> Accept Justice Dispensed
.target Tabetha
.goto Dustwallow Marsh,46.02,57.09
step
.goto Dustwallow Marsh,46.021,57.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r
.accept 2846 >> Accept Tiara of the Deep
.target Tabetha
.dungeon ZF
step
.goto Dustwallow Marsh,46.10,57.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Morlann|r outside
.turnin 11156 >>Turn in Direhorn Raiders
.target Apprentice Morlann
step
#label MudsprocketVisit1
#completewith next
.subzone 4010 >>Travel to Mudsprocket
step
#completewith Mudsprocket1
.goto Dustwallow Marsh,42.82,72.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dyslix Silvergrub|r
.fp >> Get the Mudsprocket flight path
.target Dyslix Silvergrub
step
.goto Dustwallow Marsh,42.33,72.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazzit Dripvalve|r
.turnin 11215 >> Turn in Help Mudsprocket
.turnin 11208 >> Turn in Delivery for Drazzit
.target Drazzit Dripvalve
step
.goto Dustwallow Marsh,41.75,73.11
>>Click |cRXP_PICK_the Wanted Poster|r
.accept 11184 >> Accept WANTED: Goreclaw the Ravenous
step
.goto Dustwallow Marsh,41.55,73.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gizzix Grimegurgle|r
.accept 11217 >>Accept Catch a Dragon by the Tail
.target Gizzix Grimegurgle
step
#label Mudsprocket1
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.accept 11158 >>Accept Bloodfen Feathers
.target Brogg
step
#completewith next
>>Kill |cRXP_ENEMY_Bloodfen Raptors|r. Loot them for their |cRXP_LOOT_Feathers|r
.complete 11158,1 
.mob Bloodfen Razormaw
.mob Bloodfen Lashtail
step
.goto Dustwallow Marsh,32.07,65.55
>>Kill |cRXP_ENEMY_Goreclaw the Ravenous|r
.complete 11184,1 
.mob Goreclaw the Ravenous
step
#loop
.goto Dustwallow Marsh,32.96,64.37,0
.goto Dustwallow Marsh,32.96,64.37,50,0
.goto Dustwallow Marsh,34.51,65.20,50,0
.goto Dustwallow Marsh,34.86,66.62,50,0
.goto Dustwallow Marsh,36.84,66.08,50,0
.goto Dustwallow Marsh,37.73,70.28,50,0
>>Kill |cRXP_ENEMY_Bloodfen Raptors|r. Loot them for their |cRXP_LOOT_Feathers|r
.complete 11158,1 
.mob Bloodfen Razormaw
.mob Bloodfen Lashtail
step
#completewith MudTurnins1
.subzone 4010 >>Return to Mudsprocket
step
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11158 >> Turn in Bloodfen Feathers
.accept 11160 >> Accept Banner of the Stonemaul
.accept 11161 >> Accept The Essence of Enmity
.target Brogg
step
#label MudTurnins1
.goto Dustwallow Marsh,42.33,72.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Drazzit Dripvalve|r
.turnin 11184 >> Turn in WANTED: Goreclaw the Ravenous
.target Drazzit Dripvalve
step
#completewith ScalebaneCave
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#completewith Dragondeez
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
>>|cRXP_WARN_Use|r |T136021:0|t[Brogg's Totem] |cRXP_WARN_on their corpses|r |cRXP_WARN_to collect|r |cRXP_LOOT_Black Dragonkin Essence|r
.complete 1168,1 
.mob +Firemane Scout
.complete 1168,2 
.mob +Firemane Ash Tail
.complete 11161,1 
.mob +Firemane Scout
.mob +Firemane Ash Tail
step
.goto Dustwallow Marsh,38.70,65.60
>>Loot the |cRXP_PICK_Vase|r on the ground for |cRXP_LOOT_Mok'Morokk's Grog|r
.complete 1166,2 
step
#label ScalebaneCave
#completewith Dragondeez
.goto Dustwallow Marsh,38.31,66.23,12 >>Enter the cave
step
#completewith next
>>Kill |cRXP_ENEMY_Firemane Scalebanes|r
>>|cRXP_WARN_They can only be found inside the cave|r
.complete 1168,3 
.mob Firemane Scalebane
step
.goto Dustwallow Marsh,36.60,69.50
>>Loot the |cRXP_PICK_Chest|r in the back of the cave for |cRXP_LOOT_Mok'Morokk's Strongbox|r
.complete 1166,3 
step
#label StonemaulBanner
.goto Dustwallow Marsh,38.12,69.45
>>Loot the |cRXP_ENEMY_Stonemaul Clan Banner|r in the back of the cave
.complete 11160,1 
step
#label Dragondeez
#loop
.goto Dustwallow Marsh,37.44,68.47,0
.goto Dustwallow Marsh,37.44,68.47,15,0
.goto Dustwallow Marsh,38.59,68.10,15,0
.goto Dustwallow Marsh,38.31,66.98,15,0
.goto Dustwallow Marsh,37.27,67.39,15,0
>>Kill |cRXP_ENEMY_Firemane Scalebanes|r
>>|cRXP_WARN_They can only be found inside the cave|r
.complete 1168,3 
.mob Firemane Scalebane
step
#completewith next
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#loop
.goto Dustwallow Marsh,39.46,64.42,0
.goto Dustwallow Marsh,43.34,65.78,0
.goto Dustwallow Marsh,38.62,68.06,15,0
.goto Dustwallow Marsh,38.65,65.81,15,0
.goto Dustwallow Marsh,39.46,64.42,40,0
.goto Dustwallow Marsh,39.51,66.65,40,0
.goto Dustwallow Marsh,43.34,65.78,50,0
.goto Dustwallow Marsh,45.86,66.06,50,0
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
>>|cRXP_WARN_Use|r |T136021:0|t[Brogg's Totem] |cRXP_WARN_on their corpses|r |cRXP_WARN_to collect|r |cRXP_LOOT_Black Dragonkin Essence|r
.complete 1168,1 
.disablecheckbox
.complete 1168,2 
.disablecheckbox
.complete 11161,1 
.mob Firemane Scout
.mob Firemane Ash Tail
step
#completewith MudTurnins2
.subzone 4010 >>Return to Mudsprocket
step
#label MudTurnins2
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11160 >> Turn in Banner of the Stonemaul
.turnin 11161 >> Turn in The Essence of Enmity
.accept 11159 >> Accept Spirits of Stonemaul Hold
.target Brogg
step
#completewith Firemanemobs
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#completewith MokSnuff
.use 33091 >>|cRXP_WARN_Use the|r |T136021:0|t[Energized Totem] |cRXP_WARN_on |cRXP_PICK_Ogre Remains|r on the ground|r
>>Kill the |cRXP_ENEMY_Stonemaul Spirits|r that appear
.complete 11159,1 
.mob Stonemaul Spirit
step
#completewith StonemaulSpirits
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
.complete 1168,1 
.mob +Firemane Scout
.complete 1168,2 
.mob +Firemane Ash Tail
step
#label MokSnuff
.goto Dustwallow Marsh,44.50,66.00
>>Loot the |cRXP_PICK_Barrel|r on the ground for |cRXP_LOOT_Mok'Morokk's Snuff|r
.complete 1166,1 
step
#label StonemaulSpirits
#loop
.goto Dustwallow Marsh,43.98,67.76,0
.goto Dustwallow Marsh,43.98,67.76,40,0
.goto Dustwallow Marsh,42.78,66.81,40,0
.goto Dustwallow Marsh,42.29,65.67,40,0
.goto Dustwallow Marsh,43.63,64.62,40,0
.goto Dustwallow Marsh,44.11,63.63,40,0
.goto Dustwallow Marsh,45.34,63.76,40,0
.goto Dustwallow Marsh,46.61,66.21,40,0
.goto Dustwallow Marsh,45.66,68.51,40,0
.use 33091 >>|cRXP_WARN_Use the|r |T136021:0|t[Energized Totem] |cRXP_WARN_on |cRXP_PICK_Ogre Remains|r on the ground|r
>>Kill the |cRXP_ENEMY_Stonemaul Spirits|r that appear
.complete 11159,1 
.mob Stonemaul Spirit
step
#label Firemanemobs
#loop
.goto Dustwallow Marsh,39.08,65.92,0
.goto Dustwallow Marsh,39.08,65.92,80,0
.goto Dustwallow Marsh,42.81,66.35,80,0
.goto Dustwallow Marsh,44.63,66.16,80,0
>>Kill |cRXP_ENEMY_Firemane Scouts|r and |cRXP_ENEMY_Firemane Ash Tails|r
.complete 1168,1 
.mob +Firemane Scout
.complete 1168,2 
.mob +Firemane Ash Tail
step
#completewith next
.subzone 4010 >>Return to Mudsprocket
step
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11159 >> Turn in Spirits of Stonemaul Hold
.accept 11162 >> Accept Challenge to the Black Flight
.target Brogg
step
#completewith next
>>Loot |cRXP_LOOT_Wyrmtail|r on the ground
.complete 11217,1 
step
#loop
.goto Dustwallow Marsh,45.60,82.28,0
.goto Dustwallow Marsh,48.10,80.85,60,0
.goto Dustwallow Marsh,47.09,82.39,60,0
.goto Dustwallow Marsh,45.60,82.28,60,0
.goto Dustwallow Marsh,43.99,81.35,60,0
.goto Dustwallow Marsh,42.31,80.73,60,0
.goto Dustwallow Marsh,42.08,78.40,60,0
.goto Dustwallow Marsh,42.45,75.89,60,0
.goto Dustwallow Marsh,45.60,82.28,60,0
>>Kill |cRXP_ENEMY_Searing Whelps|r and |cRXP_ENEMY_Searing Hatchlings|r. Loot them for their |cRXP_LOOT_Tongues|r and |cRXP_LOOT_Hearts|r
.complete 1169,1 
.complete 1169,2 
.mob Searing Whelp
.mob Searing Hatchling
step
#loop
.goto Dustwallow Marsh,49.09,70.09,0
.goto Dustwallow Marsh,50.75,73.87,50,0
.goto Dustwallow Marsh,49.09,70.09,50,0
.goto Dustwallow Marsh,45.87,73.72,50,0
.goto Dustwallow Marsh,46.80,77.23,50,0
.goto Dustwallow Marsh,48.92,78.78,50,0
.goto Dustwallow Marsh,48.63,81.98,50,0
.goto Dustwallow Marsh,50.52,80.73,50,0
.goto Dustwallow Marsh,51.23,78.14,50,0
>>Loot |cRXP_LOOT_Wyrmtail|r on the ground
.complete 11217,1 
step
#completewith next
.goto Dustwallow Marsh,52.08,75.82
.cast 42425 >>|cRXP_WARN_Use the|r |T132484:0|t[Stonemaul Banner] |cRXP_WARN_at the entrance of Onyxia's Lair|r
.timer 22,Challenge to the Black Flight RP
step
.goto Dustwallow Marsh,52.08,75.82
>>Kill |cRXP_ENEMY_Smolderwing|r as he appears
.complete 11162,1 
.mob Smolderwing
.use 33095
step
#completewith BrackenWallTurnins2
.hs >> Hearth to Brackenwall Village
.bindlocation 496,1
.subzoneskip 496
step
.goto Dustwallow Marsh,35.21,30.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.turnin 11186 >> Turn in Signs of Treachery?
.target Nazeer Bloodpike
step
#optional
.goto Dustwallow Marsh,35.30,30.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazeer|r
.accept 1262 >> Accept Report to Zor
.target Nazeer Bloodpike
.isQuestTurnedIn 1261
step
.goto Dustwallow Marsh,36.30,31.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overlord Mok'Morokk|r
.turnin 1166 >> Turn in Overlord Mok'Morokk's Concern
.target Overlord Mok'Morokk
step
.goto Dustwallow Marsh,37.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tharg|r
.turnin 1168 >> Turn in Army of the Black Dragon
.target Tharg
step
.goto Dustwallow Marsh,36.42,31.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krog|r
.turnin 11206 >> Turn in Justice Dispensed
.target Krog
step
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1169 >> Turn in Identifying the Brood
.accept 1170 >> Accept The Brood of Onyxia
.target Draz'Zilb

step
.goto Dustwallow Marsh,36.30,31.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mok'Morokk|r
.turnin 1170 >>Turn in The Brood of Onyxia
.accept 1171 >>Accept The Brood of Onyxia
.target Overlord Mok'Morokk
step
#label BrackenWallTurnins2
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1171 >>Turn in The Brood of Onyxia
.accept 1172 >>Accept The Brood of Onyxia
.target Draz'Zilb
step
#completewith next
.goto Dustwallow Marsh,35.57,31.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shardi|r
.fly Mudsprocket >> Fly to Mudsprocket
.target Shardi
.subzoneskip 4010
step
.goto Dustwallow Marsh,41.54,72.99
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gizzix Grimegurgle|r
.turnin 11217 >>Turn in Catch a Dragon by the Tail
.target Gizzix Grimegurgle
step
.goto Dustwallow Marsh,41.86,73.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brogg|r
.turnin 11162 >>Turn in Challenge to the Black Flight
.target Brogg
step
#completewith DeadMireKill
.use 33101 >>|cRXP_WARN_Use the|r |T136008:0|t[Captured Totem] |cRXP_WARN_within The Quagmire|r
>>Kill |cRXP_ENEMY_Mottled Drywallow Crocolisks|r and |cRXP_ENEMY_Drywall Snapper|r near the totem
.complete 11169,1 
.mob Mottled Drywallow Crocolisk
.mob Drywall Snapper
step
#completewith TotemTests
>>Kill |cRXP_ENEMY_Noxious Shredders|r and |cRXP_ENEMY_Darkfang Creepers|r. Loot them for their |cRXP_LOOT_Marsh Venom|r
.complete 11173,1 
.mob Noxious Shredders
.mob Darkfang Creeper
step
#label DeadMireKill
#loop
.line Dustwallow Marsh,50.57,52.82,50.51,55.20,49.15,57.14,48.01,55.61,47.24,57.70,45.94,61.21,44.69,62.28,45.94,61.21,47.24,57.70,48.01,55.61,47.24,54.53,46.08,54.38,45.72,53.06,46.08,54.38,47.24,54.53,47.15,51.45
.goto Dustwallow Marsh,50.57,52.82,50,0
.goto Dustwallow Marsh,50.51,55.20,50,0
.goto Dustwallow Marsh,49.15,57.14,50,0
.goto Dustwallow Marsh,48.01,55.61,50,0
.goto Dustwallow Marsh,47.24,57.70,50,0
.goto Dustwallow Marsh,45.94,61.21,50,0
.goto Dustwallow Marsh,44.69,62.28,50,0
.goto Dustwallow Marsh,45.94,61.21,50,0
.goto Dustwallow Marsh,47.24,57.70,50,0
.goto Dustwallow Marsh,47.24,54.53,50,0
.goto Dustwallow Marsh,46.08,54.38,50,0
.goto Dustwallow Marsh,45.72,53.06,50,0
.goto Dustwallow Marsh,46.08,54.38,50,0
.goto Dustwallow Marsh,47.73,53.18,50,0
.goto Dustwallow Marsh,47.15,51.45,50,0
.goto Dustwallow Marsh,50.57,52.82,0
>>Find & kill |cRXP_ENEMY_Deadmire|r. Loot him for his |cRXP_LOOT_Tooth|r
>>|cRXP_WARN_He's a White Crocolisk who patrols in the water mires in the area|r
.complete 1205,1 
.unitscan Deadmire
step
#label TotemTests
#loop
.goto Dustwallow Marsh,41.64,56.36,0
.goto Dustwallow Marsh,39.11,53.51,0
.goto Dustwallow Marsh,44.93,47.36,0
.goto Dustwallow Marsh,41.64,56.36,60,0
.goto Dustwallow Marsh,38.64,59.30,60,0
.goto Dustwallow Marsh,39.11,53.51,60,0
.goto Dustwallow Marsh,40.24,48.76,60,0
.goto Dustwallow Marsh,42.04,45.45,60,0
.goto Dustwallow Marsh,44.93,47.36,60,0
.use 33101 >>|cRXP_WARN_Use the|r |T136008:0|t[Captured Totem] |cRXP_WARN_within The Quagmire|r
>>Kill |cRXP_ENEMY_Mottled Drywallow Crocolisks|r and |cRXP_ENEMY_Drywall Snapper|r near the totem
.complete 11169,1 
.mob Mottled Drywallow Crocolisk
.mob Drywall Snapper
step
#loop
.goto Dustwallow Marsh,43.50,48.32,0
.goto Dustwallow Marsh,38.56,52.05,0
.goto Dustwallow Marsh,43.46,53.64,0
.goto Dustwallow Marsh,43.50,48.32,70,0
.goto Dustwallow Marsh,39.02,46.56,70,0
.goto Dustwallow Marsh,38.56,52.05,70,0
.goto Dustwallow Marsh,40.43,56.51,70,0
.goto Dustwallow Marsh,43.46,53.64,70,0
>>Kill |cRXP_ENEMY_Noxious Shredders|r and |cRXP_ENEMY_Darkfang Creepers|r. Loot them for their |cRXP_LOOT_Marsh Venom|r
.complete 11173,1 
.mob Noxious Shredders
.mob Darkfang Creeper
step
.goto Dustwallow Marsh,46.06,57.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Apprentice Garion|r
.turnin 11169 >> Turn in The Grimtotem Weapon
.turnin 11173 >> Turn in The Reagent Thief
.target Apprentice Garion
step
#loop
.goto Dustwallow Marsh,48.5,73.6,0
.goto Dustwallow Marsh,48.5,73.6,15,0
.goto Dustwallow Marsh,48.4,76.0,15,0
.goto Dustwallow Marsh,52.3,83.9,15,0
.goto Dustwallow Marsh,56.0,81.9,15,0
.goto Dustwallow Marsh,56.7,75.5,15,0
.goto Dustwallow Marsh,53.6,72.5,15,0
>>Click |cRXP_PICK_Eggs of Onyxia|r to destroy them
.complete 1172,1 
step
#completewith DWM2End
.goto Dustwallow Marsh,42.82,72.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dyslix Silvergrub|r
.fly Brackenwall >> Fly to Brackenwall Village
.target Dyslix Silvergrub
.subzoneskip 496
step
.goto Dustwallow Marsh,37.15,33.08
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1172 >>Turn in The Brood of Onyxia
.target Draz'Zilb
step
.goto Dustwallow Marsh,36.30,31.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mok'Morokk|r
>>|cRXP_WARN_Accepting this quest turns|r |cRXP_ENEMY_Overlord Mok'Morokk|r |cRXP_WARN_hostile. He hits extremely hard and should be kited. Be prepared|r
.accept 1173,1 >>Accept Challenge Overlord Mok'Morokk
.unitscan Overlord Mok'Morokk
.group 4
step
.goto Dustwallow Marsh,36.30,31.50
>>Defeat |cRXP_ENEMY_Overlord Mok'Morokk|r by reducing his health to about 30%
>>|cRXP_WARN_He hits extremely hard and should be kited|r
>>|cRXP_WARN_He can be feared|r << Warlock/Priest/Warrior
.complete 1173,1 
.unitscan Overlord Mok'Morokk
.group 4
step
.goto Dustwallow Marsh,37.10,33.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Draz'Zilb|r
.turnin 1173 >>Turn in Challenge Overlord Mok'Morokk
.target Draz'Zilb
.isQuestComplete 1173
.group
step
#label DWM2End
#optional
.abandon 1173 >>Abandon Challenge Overlord Mok'Morokk if you are unable to complete it
.group
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 45-46 Feralas
#next 46-47 Stranglethorn Vale part 3
step
#completewith TanarisPU1
.goto Dustwallow Marsh,35.57,31.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shardi|r
.fly Tanaris >> Fly to Tanaris
.target Shardi
.zoneskip Tanaris
step
.goto Tanaris,51.60,26.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.turnin 2864 >> Turn in Tran'rek
.target Tran'rek
step
#label TanarisPU1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r and |cRXP_FRIENDLY_Luglunket|r
.turnin 243 >> Turn in Into the Field
.accept 379 >> Accept Slake That Thirst
.accept 1690 >> Accept Wastewander Justice
.target +Chief Engineer Bilgewhizzle
.goto Tanaris,52.46,28.52
.accept 1707 >> Accept Water Pouch Bounty
.target +Spigot Operator Luglunket
.goto Tanaris,52.49,28.44
step
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 992 >> Accept Gadgetzan Water Survey
.target Senior Surveyor Fizzledowser
step << Hunter
#completewith next
.goto Tanaris,52.253,28.001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Laziphus|r
.stable >> Stable your pet. You will tame a |cRXP_ENEMY_Scorpid Hunter|r shortly
.xp <40,1
.target Laziphus
step << Hunter
.goto Tanaris,54.07,32.21
>>|cRXP_WARN_Cast|r |T132164:0|t[Tame Beast] |cRXP_WARN_on a |cRXP_ENEMY_Scorpid Hunter|r to tame it|r 
.train 2976 >>|cRXP_WARN_Attack mobs with it to learn|r |T132140:0|t[Claw (Rank 6)]
.link https://www.wow-petopia.com/classic/training.php >> |cRXP_WARN_Click here for more info about pet training|r
.xp <40,1
.mob Scorpid Hunter
.zoneskip Tanaris,1
step << Hunter
.goto Tanaris,52.253,28.001
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Laziphus|r
.stable >> Abandon the |cRXP_ENEMY_Scorpid Hunter|r and retrieve your regular pet
.target Laziphus
.train 2976,3
.zoneskip Tanaris,1
step
#completewith next
.goto Tanaris,59.36,24.75,60,0
.goto Tanaris,60.46,23.42,60,0
>>Kill |cRXP_ENEMY_Wastewander Bandits|r and |cRXP_ENEMY_Wastewander Thieves|r in the Noonshade Ruins en route to Steamwheedle Port. Loot them for their |cRXP_LOOT_Water Pouches|r
.complete 1690,1 
.mob +Wastewander Bandit
.complete 1690,2 
.mob +Wastewander Thief
.collect 8483,10 
.mob +Wastewander Bandit
.mob +Wastewander Thief
step
.goto Tanaris,66.60,22.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Modiste|r
.accept 8365 >>Accept Pirate Hats Ahoy!
.target Haughty Modiste
step
.goto Tanaris,67.00,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.accept 3520 >> Accept Screecher Spirits
.target Yeh'kinya
step << Hunter
.goto Tanaris,67.01,21.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jabbey|r
>>|cRXP_BUY_Buy|r |T135661:0|t[Jagged Arrows] |cRXP_BUY_from him|r
.collect 11285,2600,1690,1 
.target Jabbey
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r and |cRXP_FRIENDLY_Stoley|r
.accept 8366 >>Accept Southsea Shakedown
.target +Security Chief Bilgewhizzle
.goto Tanaris,67.06,23.89
.turnin 2872 >>Turn in Stoley's Debt
.accept 2873 >>Accept Stoley's Shipment
.target +Stoley
.goto Tanaris,67.11,23.98
step
.goto Tanaris,64.22,29.16,0
.goto Tanaris,64.22,29.16,60,0
.goto Tanaris,63.62,31.32,60,0
.goto Tanaris,63.24,32.84,60,0
.goto Tanaris,59.36,24.75,60,0
.goto Tanaris,60.46,23.42,60,0
>>Kill |cRXP_ENEMY_Wastewander Bandits|r and |cRXP_ENEMY_Wastewander Thieves|r. Loot them for their |cRXP_LOOT_Water Pouches|r
.complete 1690,1 
.mob +Wastewander Bandit
.complete 1690,2 
.mob +Wastewander Thief
.collect 8483,10 
.mob +Wastewander Bandit
.mob +Wastewander Thief
step
.goto Tanaris,52.46,28.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r
.turnin 379 >> Turn in Slake That Thirst
.turnin 1690 >> Turn in Wastewander Justice

.target Chief Engineer Bilgewhizzle
step
.goto Tanaris,52.49,28.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Luglunket|r
.turnin 1707 >> Turn in Water Pouch Bounty
.target Spigot Operator Luglunket
.itemcount 8483,5
step
#completewith ShimmFlats2
.zone Thousand Needles >>Travel to the Shimmering Flats
step
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle|r
.accept 2770 >> Accept Gahz'rilla
.target Wizzle Brassbolts
.dungeon ZF
step
.goto Thousand Needles,78.07,77.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzle|r
.turnin 1137 >> Turn in News for Fizzle
.target Fizzle Brassbolts
.isQuestTurnedIn 1108
step
#label ShimmFlats2
.goto Thousand Needles,80.18,75.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pozzik|r
.accept 1190 >> Accept Keeping Pace
.target Pozzik
.isQuestTurnedIn 1108
step
.goto Thousand Needles,80.33,76.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razzeric|r
.turnin 1187 >>Turn in Razzeric's Tweaking
.accept 1188 >>Accept Safety First
.target Razzeric
.isQuestComplete 1187
step
#optional
.goto Thousand Needles,80.33,76.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Razzeric|r
.accept 1188 >>Accept Safety First
.target Razzeric
.isQuestTurnedIn 1187
step
#completewith next
.goto Thousand Needles,79.81,77.02
>>Talk with |cRXP_FRIENDLY_Zamek|r to create a diversion
.turnin 1191 >> Turn in Zamek's Distraction
.target Zamek
.timer 30,Zamek's Distraction RP
step
.goto Thousand Needles,77.21,77.41
>>Click on |cRXP_PICK_Rizzle's Unguarded Plans|r inside the metal hut
.turnin 1190 >> Turn in Keeping Pace
.accept 1194 >> Accept Rizzle's Schematics
.isQuestTurnedIn 1108
step
#label ShimmFlats2
.goto Thousand Needles,80.18,75.88
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pozzik|r
.turnin 1194 >> Turn in Rizzle's Schematics
.target Pozzik
step
#optional
#completewith FeralasArrive
.destroy 5866 >>|cRXP_WARN_Destroy the|r |T134575:0|t[Sample of Indurium Ore] |cRXP_WARN_as it's not needed for anything|r
.itemcount 5866,1
step
#completewith FlyFreeWind
.subzone 976 >>Travel to Gadgetzan
step
.goto Tanaris,51.00,27.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shreev|r
.turnin 1188 >>Turn in Safety First
.target Shreev
.isQuestComplete 1188
step
#label FlyFreeWind
#completewith next
.goto Tanaris,51.60,25.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Freewind Post >> Fly to Freewind Post
.target Bulkrek Ragefist
.zoneskip Feralas
step
#label FeralasArrive
#completewith next
.goto Feralas,89.12,41.19
.zone Feralas >> Travel to Feralas
step
.goto Feralas,76.06,43.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bronk|r
.vendor >> |cRXP_BUY_Buy|r |T134833:0|t[Superior Healing Potions] |cRXP_BUY_from him if they're up|r
.target Bronk
.isQuestAvailable 2975
step
#requires FeralasArrive
#completewith FeralasHS
.line Feralas,75.99,42.85,76.49,43.22,75.53,43.68,74.38,44.01,73.56,46.53,73.52,45.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rok|r
>>|cRXP_WARN_She patrols the road through Camp Mojache|r
.turnin 2981 >> Turn in A Threat in Feralas
.accept 2975 >> Accept The Ogres of Feralas
.unitscan Rok Orhan
step
#requires FeralasArrive
.goto Feralas,75.70,44.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orwin|r
.accept 2987 >> Accept Gordunni Cobalt
.target Orwin Gizzmick
step
.goto Feralas,76.00,42.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krueg|r
.accept 2973 >> Accept A New Cloak's Sheen
.target Krueg Skullsplitter
step
.goto Feralas,74.90,42.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.accept 2862 >> Accept War on the Woodpaw
.target Hadoken Swiftstrider
step
.goto Feralas,74.50,42.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jangdor|r inside the building
.accept 2822 >> Accept The Mark of Quality
.target Jangdor Swiftstrider
step
#label FeralasHS
.goto Feralas,74.81,45.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Greul|r
.home >> Set your Hearthstone to Camp Mojache
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Greul
.bindlocation 1099
.isQuestAvailable 2863,2973
step
#loop
.line Feralas,75.99,42.85,76.49,43.22,75.53,43.68,74.38,44.01,73.56,46.53,73.52,45.13
.goto Feralas,73.56,46.53,20,0
.goto Feralas,73.71,46.03,20,0
.goto Feralas,75.99,42.85,20,0
.goto Feralas,76.49,43.22,20,0
.goto Feralas,75.53,43.68,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rok|r
>>|cRXP_WARN_She patrols the road through Camp Mojache|r
.turnin 2981 >> Turn in A Threat in Feralas
.accept 2975 >> Accept The Ogres of Feralas
.unitscan Rok Orhan
step << Hunter
#completewith next
.goto Feralas,74.49,43.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyrka Wolfrunner|r
.stable >> Stable your pet. You will tame a |cRXP_ENEMY_Longtooth Runner|r shortly
.target Shyrka Wolfrunner
step << Hunter
#loop
.goto Feralas,72.18,43.82,0
.goto Feralas,70.61,41.52,0
.goto Feralas,72.18,43.82,60,0
.goto Feralas,70.61,41.52,60,0
>>|cRXP_WARN_Cast|r |T132164:0|t[Tame Beast] |cRXP_WARN_on a |cRXP_ENEMY_Longtooth Runner|r to tame it|r 
.train 17266 >>|cRXP_WARN_Attack mobs with it to learn|r |T132278:0|t[Bite (Rank 6)]
.link https://www.wow-petopia.com/classic/training.php >> |cRXP_WARN_Click here for more info about pet training|r
.mob Longtooth Runner
step << Hunter
.goto Feralas,74.49,43.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyrka Wolfrunner|r
.stable >> Abandon the |cRXP_ENEMY_Longtooth Runner|r and retrieve your regular pet
.target Shyrka Wolfrunner
.train 17266,3
.zoneskip Feralas,1
step
#sticky
#completewith YetiHide
>>Look out for the |T132836:0|t[|cRXP_FRIENDLY_Distress Beacon|r] drop as you quest throughout Feralas
.collect 8705,1,2766
.accept 2766 >> Accept Find OOX-22/FE!
step
#loop
.goto Feralas,72.79,39.32,0
.goto Feralas,72.79,39.32,60,0
.goto Feralas,72.11,37.21,60,0
.goto Feralas,73.18,36.29,60,0
>>Kill |cRXP_ENEMY_Woodpaw Gnolls|r. Loot them for their |cRXP_LOOT_Manes|r
>>|cRXP_ENEMY_Woodpaw Trappers|r |cRXP_WARN_cast|r |T132149:0|t[Net] |cRXP_WARN_which immobilizes movement for 10 seconds|r
.complete 2862,1 
.mob Woodpaw Mongrel
.mob Woodpaw Trapper
.mob Woodpaw Brute
.mob Woodpaw Reaver
.mob Woodpaw Mystic
.mob Woodpaw Alpha
step
#completewith Scroll
.goto Feralas,75.30,28.26,0
.use 9466 >>|cRXP_WARN_Use|r |T134435:0|t[Orwin's Shovel] |cRXP_WARN_at the blue circles|r
>>Loot the |cRXP_PICK_Gordunni Dirt Mounds|r that spawn on the ground for |cRXP_LOOT_Gordunni Cobalt|r
.complete 2987,1 
step
#completewith Shovel
.goto Feralas,76.10,33.20,0
>>Kill |cRXP_ENEMY_Gordunni Ogres|r, |cRXP_ENEMY_Ogre Mages|r, and |cRXP_ENEMY_Brutes|r at the Gordunni Outpost
.complete 2975,1 
.mob +Gordunni Ogre
.complete 2975,2 
.mob +Gordunni Ogre Mage
.complete 2975,3 
.mob +Gordunni Brute
step
#label Scroll
#loop
.goto Feralas,75.25,34.44,0
.goto Feralas,79.40,34.80,25,0
.goto Feralas,80.50,34.30,25,0
.goto Feralas,80.80,35.00,25,0
.goto Feralas,75.10,29.80,25,0
.goto Feralas,75.20,28.70,25,0
.goto Feralas,74.60,27.90,25,0
>>Loot the |cRXP_PICK_Scroll|r on the ground for the |T134943:0|t[|cRXP_LOOT_Gordunni Scroll|r]. Use it to start the quest
>>|cRXP_WARN_Follow the arrow to its different spawn locations|r
.collect 9370,1,2978 
.accept 2978 >> Accept The Gordunni Scroll
.use 9370
step
#label Shovel
#loop
.goto Feralas,74.29,28.98,0
.goto Feralas,74.29,28.98,30,0
.goto Feralas,75.35,28.23,30,0
.goto Feralas,76.01,29.00,30,0
.goto Feralas,76.89,29.60,30,0
.goto Feralas,76.47,33.05,30,0
.goto Feralas,76.70,33.86,30,0
.use 9466 >>|cRXP_WARN_Use|r |T134435:0|t[Orwin's Shovel] |cRXP_WARN_at the blue circles|r
>>Loot the |cRXP_PICK_Gordunni Dirt Mounds|r that spawn on the ground for |cRXP_LOOT_Gordunni Cobalt|r
.complete 2987,1 
step
.goto Feralas,74.82,27.53,0
.goto Feralas,74.82,27.53,50,0
.goto Feralas,75.25,29.55,50,0
.goto Feralas,76.51,30.48,50,0
.goto Feralas,75.45,34.59,50,0
>>Kill |cRXP_ENEMY_Gordunni Ogres|r, |cRXP_ENEMY_Ogre Mages|r, and |cRXP_ENEMY_Brutes|r at the Gordunni Outpost
.complete 2975,1 
.mob +Gordunni Ogre
.complete 2975,2 
.mob +Gordunni Ogre Mage
.complete 2975,3 
.mob +Gordunni Brute
step << Shaman
#completewith WoodpawWarTurnin
.hs >> Hearth to Camp Mojache
.use 6948
.bindlocation 1099,1
.subzoneskip 1099
step << !Shaman
#completewith next
.subzone 1099 >> Return to Camp Mojache
step
#label WoodpawWarTurnin
.goto Feralas,74.90,42.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 2862 >> Turn in War on the Woodpaw
.accept 2863 >> Accept Alpha Strike
.target Hadoken Swiftstrider
step
#completewith next
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rok|r
>>|cRXP_WARN_She patrols the road through Camp Mojache|r
.turnin 2975 >> Turn in The Ogres of Feralas
.accept 2980 >> Accept The Ogres of Feralas
.turnin 2978 >> Turn in The Gordunni Scroll
.accept 2979 >> Accept Dark Ceremony
.target Rok Orhan
step
.goto Feralas,75.70,44.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orwin|r
.turnin 2987 >> Turn in Gordunni Cobalt
.target Orwin Gizzmick
step
#loop
.line Feralas,75.99,42.85,76.49,43.22,75.53,43.68,74.38,44.01,73.56,46.53,73.52,45.13
.goto Feralas,73.56,46.53,20,0
.goto Feralas,73.71,46.03,20,0
.goto Feralas,75.99,42.85,20,0
.goto Feralas,76.49,43.22,20,0
.goto Feralas,75.53,43.68,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rok|r
>>|cRXP_WARN_She patrols the road through Camp Mojache|r
.turnin 2975 >> Turn in The Ogres of Feralas
.accept 2980 >> Accept The Ogres of Feralas
.turnin 2978 >> Turn in The Gordunni Scroll
.accept 2979 >> Accept Dark Ceremony
.target Rok Orhan
step
.goto Feralas,68.80,48.00
>>Kill |cRXP_ENEMY_Sprite Darters|r. Loot them for their |cRXP_LOOT_Wings|r
.complete 2973,1 
.mob Sprite Darter
step
#loop
.goto Feralas,69.05,55.78,0
.goto Feralas,68.60,54.25,0
.goto Feralas,71.51,55.98,0
.goto Feralas,72.42,56.63,0
.goto Feralas,73.21,56.25,0
.goto Feralas,69.05,55.78,50,0
.goto Feralas,68.60,54.25,50,0
.goto Feralas,71.51,55.98,50,0
.goto Feralas,72.42,56.63,50,0
.goto Feralas,73.21,56.25,50,0
.goto Feralas,72.42,56.63,50,0
.goto Feralas,71.51,55.98,50,0
.goto Feralas,68.60,54.25,50,0
>>Kill |cRXP_ENEMY_Woodpaw Alphas|r within the allotted time
>>|cRXP_WARN_There's usually one in each camp|r
>>|cRXP_WARN_This is a timed quest (1hour). Re-accept the quest if you failed it|r
.complete 2863,1 
.unitscan Woodpaw Alpha
step
#completewith AlphaStrikeTI
.subzone 1099 >> Return to Camp Mojache
step
.goto Feralas,76.00,42.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krueg|r
.turnin 2973 >> Turn in A New Cloak's Sheen
.accept 2974 >> Accept A Grim Discovery
.target Krueg Skullsplitter
step
.goto Feralas,76.06,43.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bronk|r
.vendor >> |cRXP_BUY_Buy|r |T134833:0|t[Superior Healing Potions] |cRXP_BUY_from him if they're up|r
.target Bronk
.subzoneskip 1099,1
step
#label AlphaStrikeTI
.goto Feralas,74.90,42.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 2863 >> Turn in Alpha Strike
.accept 2902 >> Accept Woodpaw Investigation
.target Hadoken Swiftstrider
step
#loop
.goto Feralas,66.63,46.62,0
.goto Feralas,69.92,38.97,60,0
.goto Feralas,68.71,39.90,60,0
.goto Feralas,68.08,46.12,60,0
.goto Feralas,66.63,46.62,60,0
.goto Feralas,69.92,38.97,60,0
>>Kill |cRXP_ENEMY_Grimtotem Taurens|r. Loot them for their |cRXP_LOOT_Horns|r
>>|cRXP_ENEMY_Grimtotem Raiders|r |cRXP_WARN_cast|r |T132149:0|t[Net] |cRXP_WARN_which immobilizes movement for 10 seconds|r
.complete 2974,1 
.mob Grimtotem Shaman
.mob Grimtotem Raider
.mob Grimtotem Naturalist
step
.goto Feralas,71.60,55.90
>>Click on the |cRXP_PICK_Woodpaw Battle Map|r, on top of a crate
.turnin 2902 >> Turn in Woodpaw Investigation
.accept 2903 >> Accept The Battle Plans
step
.goto Feralas,76.00,42.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krueg|r
.turnin 2974 >> Turn in A Grim Discovery
.accept 2976 >> Accept A Grim Discovery
.target Krueg Skullsplitter
step
.goto Feralas,74.90,42.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 2903 >> Turn in The Battle Plans
.accept 7730 >> Accept Zukk'ash Infestation
.accept 7731 >> Accept Stinglasher
.target Hadoken Swiftstrider
step << Hunter
.goto Feralas,74.94,45.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cawind Trueaim|r
>>|cRXP_BUY_Buy|r |T135661:0|t[Jagged Arrows] |cRXP_BUY_from him|r
.collect 11285,2600,7731,1 
.target Cawind Trueaim
step << !Mage
.goto Feralas,74.81,45.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Greul|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food|r << Rogue/Warrior
>>|cRXP_WARN_Make sure to buy 5 stacks or more. A LONG grind section is coming up|r
.target Innkeeper Greul
.isQuestAvailable 7730,7731,2980,2979,2822
step
#optional
#completewith Stinglasher
.destroy 9460 >>|cRXP_WARN_Destroy the leftover|r |T133721:0|t[Grimtotem Horn] |cRXP_WARN_in your bag as it's no longer needed|r
step
#completewith next
.goto Feralas,73.38,62.94,0
>>Kill |cRXP_ENEMY_Zukk'ash Silithid|r. Loot them for their |cRXP_LOOT_Carapace|r
.complete 7730,1 
.mob Zukk'ash Worker
.mob Zukk'ash Wasp
.mob Zukk'ash Tunneler
.mob Zukk'ash Stinger
step
#label Stinglasher
#loop
.goto Feralas,73.38,63.24,0
.goto Feralas,76.36,61.19,0
.goto Feralas,73.38,63.24,50,0
.goto Feralas,76.36,61.19,50,0
>>Kill |cRXP_ENEMY_Stinglasher|r. Loot it for its |cRXP_LOOT_Glands|r
>>|cRXP_WARN_This mob can be quite hard make sure to have cooldowns available|r
>>|cRXP_WARN_It patrols inside and outside of the Silithid Hives|r
.complete 7731,1 
.unitscan Stinglasher
step
#loop
.goto Feralas,73.38,63.24,0
.goto Feralas,76.36,61.19,0
.goto Feralas,73.38,63.24,50,0
.goto Feralas,76.36,61.19,50,0
>>Kill |cRXP_ENEMY_Zukk'ash Silithid|r. Loot them for their |cRXP_LOOT_Carapace|r
.complete 7730,1 
.mob Zukk'ash Worker
.mob Zukk'ash Wasp
.mob Zukk'ash Tunneler
.mob Zukk'ash Stinger
step
#completewith egghypo
.goto Feralas,56.15,46.88,0
.use 10699 >>Kill |cRXP_ENEMY_Vale Screechers|r
>>|cRXP_WARN_Use|r |T135474:0|t[Yeh'kinya's Bramble] |cRXP_WARN_on their corpses. Talk to the|r |cRXP_FRIENDLY_Screecher Spirit|r |cRXP_WARN_that appears|r
.complete 3520,1 
.unitscan Rogue Vale Screecher
.unitscan Vale Screecher
.target Screecher Spirit
step
#completewith next
.goto Feralas,58.59,69.85,0
>>Kill |cRXP_ENEMY_Gordunni Mage-Lords|r. Loot them for their |cRXP_LOOT_Orb|r
.complete 2979,1 
.mob Gordunni Mage-Lord
step
.goto Feralas,59.72,62.77,0
.goto Feralas,61.86,54.46,60,0
.goto Feralas,61.03,56.55,60,0
.goto Feralas,60.69,58.52,60,0
#loop
.goto Feralas,59.72,62.77,60,0
.goto Feralas,58.93,64.13,60,0
.goto Feralas,58.31,65.20,60,0
.goto Feralas,58.25,66.56,60,0
.goto Feralas,58.55,67.75,60,0
.goto Feralas,59.54,68.37,60,0
.goto Feralas,60.85,69.68,60,0
.goto Feralas,60.95,67.65,60,0
.goto Feralas,60.35,66.63,60,0
.goto Feralas,60.11,64.93,60,0
.goto Feralas,59.58,64.51,60,0
>>Kill |cRXP_ENEMY_Gordunni Maulers|r, |cRXP_ENEMY_Warlocks|r, and |cRXP_ENEMY_Shamans|r
>>|cRXP_WARN_Kill every|r |cRXP_ENEMY_Shaman|r |cRXP_WARN_you see as they have limited spawns|r
.complete 2980,1 
.mob +Gordunni Shaman
.complete 2980,2 
.mob +Gordunni Warlock
.complete 2980,3 
.mob +Gordunni Mauler
step
#loop
.goto Feralas,60.95,67.65,0
.goto Feralas,59.72,62.77,60,0
.goto Feralas,58.93,64.13,60,0
.goto Feralas,58.31,65.20,60,0
.goto Feralas,58.25,66.56,60,0
.goto Feralas,58.55,67.75,60,0
.goto Feralas,59.54,68.37,60,0
.goto Feralas,60.85,69.68,60,0
.goto Feralas,60.95,67.65,60,0
.goto Feralas,60.35,66.63,60,0
.goto Feralas,60.11,64.93,60,0
.goto Feralas,59.58,64.51,60,0
>>Kill |cRXP_ENEMY_Gordunni Mage-Lords|r. Loot them for their |cRXP_LOOT_Orb|r
.complete 2979,1 
.mob Gordunni Mage-Lord
step
#ssf
#completewith next
>>Kill |cRXP_ENEMY_Frayfeather Hippogryphs|r. Loot them for their |T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r]
>>|T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r] |cRXP_WARN_are dropped by|r |cRXP_ENEMY_Hippogryphs|r |cRXP_WARN_only.|r |cRXP_ENEMY_Stagwings|r |cRXP_WARN_and|r |cRXP_ENEMY_Skystormers|r |cRXP_WARN_DO NOT drop them|r
.collect 4589,10,7842,1 
.mob Frayfeather Hippogryph
step
#ah
#completewith next
>>Kill |cRXP_ENEMY_Frayfeather Hippogryphs|r. Loot them for their |T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r]
>>|cRXP_WARN_You could also buy these from the Auction House instead|r
>>|T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r] |cRXP_WARN_are dropped by|r |cRXP_ENEMY_Hippogryphs|r |cRXP_WARN_only.|r |cRXP_ENEMY_Stagwings|r |cRXP_WARN_and|r |cRXP_ENEMY_Skystormers|r |cRXP_WARN_DO NOT drop them|r
.collect 4589,10,7842,1 
.mob Frayfeather Hippogryph
step
#label egghypo
.goto Feralas,56.66,75.89
>>Loot a |T132833:0|t[|cRXP_LOOT_Hippogryph Egg|r] from a hippogryph nest
>>|cRXP_WARN_There are multiple nests located in the southern mountains|r
.collect 8564,1 
step
#completewith next
.use 10699 >>Kill |cRXP_ENEMY_Vale Screechers|r
>>|cRXP_WARN_Use|r |T135474:0|t[Yeh'kinya's Bramble] |cRXP_WARN_on their corpses. Talk to the|r |cRXP_FRIENDLY_Screecher Spirit|r |cRXP_WARN_that appears|r
.complete 3520,1 
.unitscan Rogue Vale Screecher
.unitscan Vale Screecher
.target Screecher Spirit
step
#ssf
#loop
.goto Feralas,56.71,64.09,0
.goto Feralas,56.71,64.09,60,0
.goto Feralas,56.61,62.01,60,0
.goto Feralas,55.87,60.34,60,0
.goto Feralas,54.79,60.44,60,0
.goto Feralas,55.30,62.17,60,0
.goto Feralas,54.49,64.33,60,0
.goto Feralas,55.23,66.21,60,0
.goto Feralas,55.88,65.91,60,0
>>Kill |cRXP_ENEMY_Frayfeather Hippogryphs|r. Loot them for their |T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r]
>>|T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r] |cRXP_WARN_are dropped by|r |cRXP_ENEMY_Hippogryphs|r |cRXP_WARN_only.|r |cRXP_ENEMY_Stagwings|r |cRXP_WARN_and|r |cRXP_ENEMY_Skystormers|r |cRXP_WARN_DO NOT drop them|r
.collect 4589,10,7842,1 
.mob Frayfeather Hippogryph
step
#ah
#loop
.goto Feralas,56.71,64.09,0
.goto Feralas,56.71,64.09,60,0
.goto Feralas,56.61,62.01,60,0
.goto Feralas,55.87,60.34,60,0
.goto Feralas,54.79,60.44,60,0
.goto Feralas,55.30,62.17,60,0
.goto Feralas,54.49,64.33,60,0
.goto Feralas,55.23,66.21,60,0
.goto Feralas,55.88,65.91,60,0
>>Kill |cRXP_ENEMY_Frayfeather Hippogryphs|r. Loot them for their |T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r]
>>|cRXP_WARN_You could also buy these from the Auction House instead|r
>>|T135992:0|t[|cRXP_LOOT_Long Elegant Feathers|r] |cRXP_WARN_are dropped by|r |cRXP_ENEMY_Hippogryphs|r |cRXP_WARN_only.|r |cRXP_ENEMY_Stagwings|r |cRXP_WARN_and|r |cRXP_ENEMY_Skystormers|r |cRXP_WARN_DO NOT drop them|r
.collect 4589,10,7842,1 
.mob Frayfeather Hippogryph
step
#loop
.goto Feralas,58.39,51.88,0
.goto Feralas,57.54,48.70,0
.goto Feralas,55.74,46.71,0
.goto Feralas,58.45,55.83,0
.goto Feralas,58.39,51.88,80,0
.goto Feralas,57.54,48.70,80,0
.goto Feralas,55.74,46.71,80,0
.goto Feralas,58.45,55.83,80,0
.goto Feralas,56.70,56.13,80,0
.use 10699 >>Kill |cRXP_ENEMY_Vale Screechers|r
>>|cRXP_WARN_Use|r |T135474:0|t[Yeh'kinya's Bramble] |cRXP_WARN_on their corpses. Talk to the|r |cRXP_FRIENDLY_Screecher Spirit|r |cRXP_WARN_that appears|r
.complete 3520,1 
.unitscan Rogue Vale Screecher
.unitscan Vale Screecher
.target Screecher Spirit
step
#label YetiHide
#loop
.goto Feralas,52.05,58.40,0
.goto Feralas,55.14,56.35,70,0
.goto Feralas,53.12,56.27,70,0
.goto Feralas,52.05,58.40,70,0
>>Kill |cRXP_ENEMY_Yetis|r. Loot them for their |cRXP_LOOT_Hides|r
.complete 2822,1 
.mob Feral Scar Yeti
.mob Enraged Feral Scar
.mob Hulking Feral Scar
.mob Lurking Feral Scar
.mob Bloodroar the Stalker
step
.accept 2766 >> Accept Find OOX-22/FE!
.itemcount 8705,1 
.use 8705
step
.goto Feralas,53.35,55.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r
.turnin 2766 >> Turn in Find OOX-22/FE!
.target Homing Robot OOX-22/FE
.isOnQuest 2766
step
.goto Feralas,53.35,55.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r
.accept 2767,1 >> Accept Rescue OOX-22/FE!
>>|cRXP_WARN_This starts the chicken escort; be ready to use cooldowns/consumables, as this quest is HARD|r

.target Homing Robot OOX-22/FE
.isQuestTurnedIn 2766
step
.goto Feralas,55.47,56.37,30,0
.goto Feralas,54.38,51.32,60,0
.goto Feralas,50.31,49.91,40,0
.goto Feralas,48.38,44.83,40,0
.goto Feralas,45.04,43.27
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-22/FE|r to the shore
>>|cRXP_WARN_3 Waves of mobs will spawn on the way. Save all your very long cooldowns for the|r |cRXP_ENEMY_Gnolls|r|cRXP_WARN_, and use some on the|r |cRXP_ENEMY_Yetis|r
+|cRXP_WARN_3 Yetis (level 46)|r
.disablecheckbox
+|cRXP_WARN_3 Gorillas (level 43)|r
.disablecheckbox
+|cRXP_WARN_4 Gnolls (level 41-43)|r
.disablecheckbox
.complete 2767,1 
.isOnQuest 2767
.target Homing Robot OOX-22/FE
step
.hs >> Hearth to Camp Mojache
.use 6948
.cooldown item,6948,>0
.bindlocation 1099,1
.subzoneskip 1099
.isQuestComplete 2822
step
.subzone 1099 >> Return to Camp Mojache
.cooldown item,6948,<0
.isQuestComplete 2822
step
.goto Feralas,74.81,45.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Greul|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
>>|cRXP_WARN_Make sure you DO NOT sell any|r |T135992:0|t[Long Elegant Feathers]
.target Innkeeper Greul
.subzoneskip 1099,1
step << Hunter
.goto Feralas,74.94,45.69
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cawind Trueaim|r
>>|cRXP_BUY_Buy|r |T135661:0|t[Jagged Arrows] |cRXP_BUY_from him|r
.collect 11285,2600,3002,1 
.target Cawind Trueaim
.subzoneskip 1099,1
step
#completewith MorePotions
.line Feralas,75.99,42.85,76.49,43.22,75.53,43.68,74.38,44.01,73.56,46.53,73.52,45.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rok|r
>>|cRXP_WARN_She patrols the road through Camp Mojache|r
.turnin 2980 >> Turn in The Ogres of Feralas
.turnin 2979 >> Turn in Dark Ceremony
.accept 3002 >> Accept The Gordunni Orb
.target Rok Orhan
step
.goto Feralas,74.90,42.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hadoken|r
.turnin 7730 >> Turn in Zukk'ash Infestation
.turnin 7731 >> Turn in Stinglasher
.accept 7732 >> Accept Zukk'ash Report
.target Hadoken Swiftstrider
step
.goto Feralas,74.40,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.accept 3121 >>Accept A Strange Request
.accept 3380 >>Accept The Sunken Temple
.target Witch Doctor Uzer'i
.xp <46,1
step
#optional
.goto Feralas,74.40,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.accept 3121 >>Accept A Strange Request
.target Witch Doctor Uzer'i
step
.goto Feralas,74.40,42.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jangdor|r
.turnin 2822 >> Turn in The Mark of Quality
.target Jangdor Swiftstrider
step
#label MorePotions
.goto Feralas,76.06,43.28
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bronk|r
.vendor >> |cRXP_BUY_Buy|r |T134833:0|t[Superior Healing Potions] |cRXP_BUY_from him if they're up|r
.target Bronk
.subzoneskip 1099,1
step
#loop
.line Feralas,75.99,42.85,76.49,43.22,75.53,43.68,74.38,44.01,73.56,46.53,73.52,45.13
.goto Feralas,73.56,46.53,20,0
.goto Feralas,73.71,46.03,20,0
.goto Feralas,75.99,42.85,20,0
.goto Feralas,76.49,43.22,20,0
.goto Feralas,75.53,43.68,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rok|r
>>|cRXP_WARN_She patrols the road through Camp Mojache|r
.turnin 2980 >> Turn in The Ogres of Feralas
.turnin 2979 >> Turn in Dark Ceremony
.accept 3002 >> Accept The Gordunni Orb
.target Rok Orhan
step
#optional
.goto Feralas,74.40,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.accept 3380 >>Accept The Sunken Temple
.target Witch Doctor Uzer'i
.xp <46,1
step << Druid
.goto Feralas,76.0,42.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jannos|r
.trainer >>Train your class spells
.target Jannos Lighthoof
step << !Mage
#completewith DeadmireTI
.goto Feralas,75.45,44.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.target Shyn
.zoneskip Thunder Bluff
step << Mage
#completewith DeadmireTI
.cast 3566 >>|cRXP_WARN_Cast|r |T135765:0|t[Teleport: Thunder Bluff]
.zoneskip Thunder Bluff
step
#label PlatDiscsTurnin
.goto Thunder Bluff,34.42,46.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage|r
.turnin 2280 >> Turn in The Platinum Discs
.target Sage Truthseeker
.isQuestTurnedIn 2278
.dungeon ULDA
step
#label DeadmireTI
.goto Thunder Bluff,61.50,80.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melor|r
.turnin 1205 >>Turn in Deadmire
.target Melor Stonehoof
.isQuestComplete 1205
step
#completewith StinkyTurnin
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Ratchet >>Fly to Ratchet
.target Tal
.zoneskip Thunder Bluff,1
step
#optional
#completewith STVZepp2
.goto Feralas,75.45,44.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Ratchet >>Fly to Ratchet
.target Shyn
.zoneskip Feralas,1
step
#label StinkyTurnin
.goto The Barrens,62.40,37.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mebok|r
.turnin 1270 >> Turn in Stinky's Escape
.target Mebok Mizzyrix
.isQuestComplete 1270
step << !Mage
#optional
#completewith STVZepp2
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Tal
.zoneskip Thunder Bluff,1
step << !Mage
#completewith STVZepp2
.goto The Barrens,63.09,37.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Orgrimmar >> Fly to Orgrimmar
.zoneskip The Barrens,1
.target Bragok
step << Mage
#completewith STVZepp2
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step
.goto Orgrimmar,39.20,86.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uthel'nay|r
.turnin 3002 >> Turn in The Gordunni Orb
.target Uthel'nay
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10185 >> Train your class spells
.target Pephredo
.xp <44,1
.xp >46,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10197 >> Train your class spells
.target Pephredo
.xp <46,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10927 >> Train your class spells
.target Ur'kyo
.xp <44,1
.xp >46,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10945 >> Train your class spells
.target Ur'kyo
.xp <46,1
step
.goto Orgrimmar,39.00,38.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zor|r
.turnin 1262 >> Turn in Report to Zor
.target Zor Lonetree
.isOnQuest 1262
step
.goto Orgrimmar,39.00,38.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zor|r
.accept 7541 >> Accept Service to the Horde
.turnin 7541 >> Turn in Service to the Horde
.target Zor Lonetree
.isQuestTurnedIn 1262
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 16315 >> Train your class spells
.target Kardris Dreamseeker
.xp <44,1
.xp >46,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10472 >> Train your class spells
.target Kardris Dreamseeker
.xp <46,1
step
.goto Orgrimmar,56.50,46.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zilzibin|r
>>|cRXP_WARN_He is located on the upper level in the Drag|r
.turnin 7732 >> Turn in Zukk'ash Report
.target Zilzibin Drumlore
step
.goto Orgrimmar,75.20,34.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.turnin 2976 >> Turn in A Grim Discovery
.target Belgrom Rockmaul
step << Hunter
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14285 >> Train your class spells
.target Ormak Grimshot
.xp <44,1
.xp >46,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14304 >> Train your class spells
.target Ormak Grimshot
.xp <46,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11584 >> Train your class spells
.target Grezz Ragefist
.xp <44,1
.xp >46,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11578 >> Train your class spells
.target Grezz Ragefist
.xp <46,1
step << Hunter
.goto Orgrimmar,78.11,38.46
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Jin'sora|r
.vendor >> |cRXP_BUY_Buy a|r |T135489:0|t[|cRXP_FRIENDLY_Massive Longbow|r] |cRXP_BUY_from him if it's available|r
.target Jin'sora
.money <6.7952
.itemStat 18,QUALITY,<7
.itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<21.9
.itemcount 11307,<1
step
.goto Orgrimmar,49.60,50.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neeru|r
.turnin 3121 >> Turn in A Strange Request
.accept 3122 >> Accept Return to Witch Doctor Uzer'i
.target Neeru Fireblade
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11341 >> Train your class spells
.target Ormok
.xp <44,1
.xp >46,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11293 >> Train your class spells
.target Ormok
.xp <46,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11671 >> Train your class spells
.target Mirket
.xp <44,1
.xp >46,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11699 >> Train your class spells
.target Mirket
.xp <46,1
step << Warlock
.goto Orgrimmar,47.52,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurgul|r
.vendor >>Buy any pet upgrades you can afford
.target Kurgul
.zoneskip Orgrimmar,1
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 46-47 Stranglethorn Vale part 3
#next 47-49 Tanaris
step
#optional
.maxlevel 47,StranglethornSkip
step
.goto Orgrimmar,49.58,69.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karus|r
.bankdeposit 10699,8564 >>Deposit the following onto your bank:
>>|T135474:0|t[Yeh'kinya's Bramble] 
>>|T132833:0|t[Hippogryph Egg] 
.target Karus
step
#ah
#completewith STVZepp2
+|cRXP_WARN_Check your bank for any missing|r |T134332:0|t[Green Hills of Stranglethorn - Pages] |cRXP_WARN_and buy any that you still need from the Auction House|r
>>|cRXP_WARN_Chapter.1 requires: Pages 1,4,6,8|r
>>|cRXP_WARN_Chapter.2 requires: Pages 10,11,14,16|r
>>|cRXP_WARN_Chapter.3 requires: Pages 18,20,21,24|r
>>|cRXP_WARN_Chapter.4 requires: Pages 25,26,27|r
>>|cRXP_WARN_Place any newly bought Pages into your bank. Skip this step if you aren't able to aquire them|r
step
#ah
.goto Orgrimmar,55.59,62.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Thathung|r
>>|cRXP_BUY_Buy ten|r |T134298:0|t[Gorilla Fangs] |cRXP_BUY_from the Auction House|r
.collect 2799,10,349,1 
.target Auctioneer Thathung
.zoneskip Orgrimmar,1
.group
step
#completewith next
.zone Durotar >> Leave Orgrimmar
.zoneskip Durotar
step
#label STVZepp2
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Stranglethorn Vale >>Take the Zeppelin to Grom'Gol Base Camp
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,32.20,27.60
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.accept 586 >> Accept Speaking with Gan'zulah
step
.goto Stranglethorn Vale,32.10,29.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.accept 571 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
.goto Stranglethorn Vale,28.80,44.80
>>Kill |cRXP_ENEMY_Tethis|r. Loot him for his |cRXP_LOOT_Talon|r
>>|cRXP_WARN_He patrols all around the raptor area|r
.complete 197,1 
.unitscan Tethis
step
#completewith Anathek
>>Kill |cRXP_ENEMY_Skullsplitter Hunters|r, |cRXP_ENEMY_Berserkers|r and |cRXP_ENEMY_Headhunters|r
.complete 586,1 
.mob +Skullsplitter Hunter
.complete 586,3 
.mob +Skullsplitter Berserker
.complete 586,2 
.mob +Skullsplitter Headhunter
step
#label Anathek
#loop
.goto Stranglethorn Vale,47.10,40.70,0
.goto Stranglethorn Vale,47.10,40.70,40,0
.goto Stranglethorn Vale,44.30,44.90,40,0
.goto Stranglethorn Vale,45.80,41.20,40,0
>>Kill |cRXP_ENEMY_Ana'thek the Cruel|r. Loot him for his |cRXP_LOOT_Armor|r
*|cRXP_WARN_Be careful of Ana'thek's adds and his|r |cFFEB144Cexecute ability.|r
.complete 586,4 
.unitscan Ana'thek the Cruel
step
#loop
.goto Stranglethorn Vale,47.90,42.90,0
.goto Stranglethorn Vale,47.60,44.10,50,0
.goto Stranglethorn Vale,46.00,42.80,50,0
.goto Stranglethorn Vale,44.40,41.90,50,0
.goto Stranglethorn Vale,47.40,39.80,50,0
.goto Stranglethorn Vale,47.90,42.90,50,0
>>Kill |cRXP_ENEMY_Skullsplitter Hunters|r, |cRXP_ENEMY_Berserkers|r and |cRXP_ENEMY_Headhunters|r
.complete 586,1 
.mob +Skullsplitter Hunter
.complete 586,3 
.mob +Skullsplitter Berserker
.complete 586,2 
.mob +Skullsplitter Headhunter
step
#completewith next
.subzone 100 >>Travel to Nesingwary's Expedition
step
.goto Stranglethorn Vale,35.66,10.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet|r
.turnin 197 >> Turn in Raptor Mastery
.accept 208 >> Accept Big Game Hunter
.target Hemet Nesingwary Jr.
.group
step
.goto Stranglethorn Vale,35.66,10.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet|r
.turnin 197 >> Turn in Raptor Mastery
.target Hemet Nesingwary Jr.
step
#completewith next
.subzone 117 >>Travel to Grom'gol Base Camp
step
.goto Stranglethorn Vale,32.20,27.70
>>Click on the |cRXP_PICK_Bubbling Cauldron|r
.turnin 586 >> Turn in Speaking with Gan'zulah
.accept 588 >> Accept The Fate of Yenniku
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.turnin 588 >> Turn in The Fate of Yenniku
.accept 589 >> Accept The Singing Crystals
.target Kin'weelay
step
#completewith BloodSailPart1
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fly Booty Bay >> Fly to Booty Bay
.target Thysta
.subzoneskip 35
step
.goto Stranglethorn Vale,27.12,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank Fizzlebub|r on the inn's lowest level
.accept 621 >> Accept Zanzil's Secret
.target Crank Fizzlebub
step
.goto Stranglethorn Vale,26.70,76.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Privateer Bloads|r
.accept 617 >> Accept Akiris by the Bundle
.target Privateer Bloads
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.accept 606 >> Accept Scaring Shaky
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,28.40,76.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe|r
.turnin 2767 >>Turn in Rescue OOX-22/FE!
.target Oglethorpe Obnoticus
.isQuestComplete 2767
step
.goto Stranglethorn Vale,27.70,76.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fin|r
.accept 348 >> Accept Stranglethorn Fever
.target Fin Fizracket
.group 2
step
.goto Stranglethorn Vale,28.10,76.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Mate Crazz|r
.accept 595 >> Accept The Bloodsail Buccaneers
.target First Mate Crazz
step
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Hecklebury Smotts|r
.accept 8551 >> Accept The Captain's Chest
.target Captain Hecklebury Smotts
.group 2
step << skip
.goto Stranglethorn Vale,27.039,77.310
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Skindle|r
.home >> Set your Hearthstone to Booty Bay
.target Innkeeper Skindle
.bindlocation 35
step
#completewith next
.goto Stranglethorn Vale,28.00,73.52,20,0
.goto Stranglethorn Vale,28.84,73.16,15,0
.goto Stranglethorn Vale,29.62,72.33,30 >>Exit Booty Bay
step
#label BloodSailPart1
.goto Stranglethorn Vale,27.27,69.51
>>Click on the |cRXP_PICK_Bloodsail Correspondence|r on top of a barrel in the center of the camp
.turnin 595 >> Turn in The Bloodsail Buccaneers
.accept 597 >> Accept The Bloodsail Buccaneers
step
#completewith SavageMokk
.goto Stranglethorn Vale,31.19,68.29,60,0
.goto Stranglethorn Vale,32.92,65.99,60,0
.goto Stranglethorn Vale,33.74,63.40,60,0
.goto Stranglethorn Vale,32.73,61.44,60,0
>>Kill |cRXP_ENEMY_Elder Mistvale Gorillas|r. Loot them for their |cRXP_LOOT_Giblets|r, a |T134298:0|t[|cRXP_LOOT_Gorilla Fang|r] and an |cRXP_LOOT_Aged Gorilla Sinew|r
.complete 606,1 
.complete 571,1 
.collect 2799,1 
.mob Elder Mistvale Gorilla
.addquestitem 2799,348
.group 0
step
.goto Stranglethorn Vale,35.27,60.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Unbagwa|r
>>|cRXP_WARN_This will start an event where 3|r |cRXP_ENEMY_Gorillas|r |cRXP_WARN_come into the cave one after another. Kill them|r
.turnin 349 >> Turn in Stranglethorn Fever
.target Witch Doctor Unbagwa
.isOnQuest 348
.unitscan Mokk the Savage
.group 2
step
#label SavageMokk
.goto Stranglethorn Vale,35.27,60.40
>>Face the |cRXP_ENEMY_Gorillas|r until |cRXP_ENEMY_Mokk the Savage|r appears. Kill him and loot him for his |cRXP_LOOT_Heart|r
.complete 348,1 
.unitscan Mokk the Savage
.isOnQuest 348
.group 2
step
#loop
.goto Stranglethorn Vale,32.73,61.44,0
.goto Stranglethorn Vale,31.19,68.29,60,0
.goto Stranglethorn Vale,32.92,65.99,60,0
.goto Stranglethorn Vale,33.74,63.40,60,0
.goto Stranglethorn Vale,32.73,61.44,60,0
.goto Stranglethorn Vale,31.12,59.80,60,0
.goto Stranglethorn Vale,31.27,65.53,60,0
.goto Stranglethorn Vale,32.92,65.99,60,0
.goto Stranglethorn Vale,33.74,63.40,60,0
.goto Stranglethorn Vale,32.73,61.44,60,0
>>Kill |cRXP_ENEMY_Elder Mistvale Gorillas|r. Loot them for their |cRXP_LOOT_Giblets|r and an |cRXP_LOOT_Aged Gorilla Sinew|r
.complete 606,1 
.complete 571,1 
.mob Elder Mistvale Gorilla
step
#completewith next
.goto Stranglethorn Vale,37.50,49.54,50,0
.goto Stranglethorn Vale,38.91,50.56,50,0
.goto Stranglethorn Vale,41.78,50.14,25 >>Enter the Crystalvein Mine
step
#loop
.goto Stranglethorn Vale,43.84,47.77,0
.goto Stranglethorn Vale,42.69,49.05,20,0
.goto Stranglethorn Vale,43.84,47.77,20,0
>>Kill |cRXP_ENEMY_Ironjaw Basilisks|r. Loot them for their |cRXP_LOOT_Shards|r
.complete 589,1 
.mob Ironjaw Basilisk
step
.goto Stranglethorn Vale,38.18,35.60
>>Kill |cRXP_ENEMY_King Bangalash|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_He comes with 2 mobs when he spawns, and spawns 2 more at about 50% health|r
.complete 208,1 
.unitscan King Bangalash
.group 2
step
#completewith next
.subzone 117 >>Travel to Grom'gol Base Camp
step
.goto Stranglethorn Vale,32.10,29.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.turnin 571 >> Turn in Mok'thardin's Enchantment
.accept 573 >> Accept Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
.goto Stranglethorn Vale,32.28,27.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kin'weelay|r
.turnin 589 >> Turn in The Singing Crystals
.target Kin'weelay
step
#completewith BootyBayTurnins2
.goto Stranglethorn Vale,32.5,29.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thysta|r
.fly Booty Bay >> Fly to Booty Bay
.target Thysta
.subzoneskip 35
step
.goto Stranglethorn Vale,27.60,76.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fin Fizracket|r
.turnin 348 >> Turn in Stranglethorn Fever
.target Fin Fizracket
.group 2
.isQuestComplete 348
step
.goto Stranglethorn Vale,28.09,76.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_First Mate Crazz|r
.turnin 597 >> Turn in The Bloodsail Buccaneers
.accept 599 >> Accept The Bloodsail Buccaneers
.target First Mate Crazz
step
.goto Stranglethorn Vale,26.90,73.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Shaky" Phillipe|r
.turnin 606 >> Turn in Scaring Shaky
.accept 607 >> Accept Return to MacKinley
.target "Shaky" Phillipe
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.turnin 607 >> Turn in Return to MacKinley
.accept 609 >> Accept Voodoo Dues
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,26.92,77.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deeg|r upstairs
.accept 587 >> Accept Up to Snuff
.target Deeg
step
.goto Stranglethorn Vale,27.17,77.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleet Master Seahorn|r
.turnin 599 >> Turn in The Bloodsail Buccaneers
.accept 604 >> Accept The Bloodsail Buccaneers
.target Fleet Master Seahorn
step
.goto Stranglethorn Vale,26.55,76.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Viznik Goldgrubber|r
.bankdeposit 2725,2728,2735,2730,2742,2732,2748,2751,2734,2740,2749,2745,2738,2744,2750,5862,9628 >>Deposit all your |T134332:0|t[Green Hills of Stranglethorn Pages] on the bank
.target Viznik Goldgrubber
.isQuestAvailable 587,576,604,621,573,617,609
step
#label BootyBayTurnins2
.goto Stranglethorn Vale,28.59,75.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dizzy One-Eye|r
.accept 576 >> Accept Keep An Eye Out
.target Dizzy One-Eye
step
#completewith Swashbucklers
>>Loot the |cRXP_PICK_Half-Burried Bottles|r along the southeastern coast for a |T133469:0|t[|cRXP_LOOT_Carefully Folded Note|r]. Use it to accept the quest
.collect 4098,1,594 
.accept 594 >> Accept Message in a Bottle
step
#completewith next
>>Kill |cRXP_ENEMY_Bloodsail Pirates|r. Loot them for their |cRXP_LOOT_Snuff|r and |cRXP_LOOT_Dizzy's Eye|r
.complete 604,1 
.complete 587,1 
.complete 576,1 
.mob Bloodsail Swashbuckler
step
#loop
.goto Stranglethorn Vale,26.94,82.49,0
.goto Stranglethorn Vale,29.61,80.89,20,0
.goto Stranglethorn Vale,27.75,83.13,20,0
.goto Stranglethorn Vale,27.18,82.66,20,0
.goto Stranglethorn Vale,26.94,82.49,20,0
>>Loot the |cRXP_LOOT_Bloodsail Orders|r and |cRXP_LOOT_Bloodsail Charts|r
>>|cRXP_WARN_They're typically in the large camp on the peninsula, or in the boat near that camp|r
.complete 604,2 
.complete 604,3 
step
#label Swashbucklers
.goto Stranglethorn Vale,32.02,79.47,0
.goto Stranglethorn Vale,32.02,79.47,60,0
.goto Stranglethorn Vale,29.83,81.11,60,0
.goto Stranglethorn Vale,27.18,82.79,60,0
.goto Stranglethorn Vale,32.02,79.47,60,0
.goto Stranglethorn Vale,29.83,81.11,60,0
.goto Stranglethorn Vale,27.18,82.79,60,0
>>Kill |cRXP_ENEMY_Bloodsail Pirates|r. Loot them for their |cRXP_LOOT_Snuff|r and |cRXP_LOOT_Dizzy's Eye|r
.complete 604,1 
.complete 587,1 
.disablecheckbox
.complete 576,1 
.mob Bloodsail Swashbuckler
step
#loop
.goto Stranglethorn Vale,34.22,73.25,0
.goto Stranglethorn Vale,34.01,77.21,0
.goto Stranglethorn Vale,32.34,79.44,0
.goto Stranglethorn Vale,32.38,82.23,0
.goto Stranglethorn Vale,34.22,73.25,60,0
.goto Stranglethorn Vale,34.01,77.21,60,0
.goto Stranglethorn Vale,32.34,79.44,60,0
.goto Stranglethorn Vale,32.38,82.23,60,0
>>Loot the |cRXP_PICK_Half-Burried Bottles|r along the southeastern coast for a |T133469:0|t[|cRXP_LOOT_Carefully Folded Note|r]. Use it to accept the quest
.collect 4098,1,594 
.accept 594 >> Accept Message in a Bottle
step
#completewith next
.subzone 297 >>Swim to Jaguero Isle
step
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Poobah|r
.turnin 594 >>Turn in Message in a Bottle
.accept 630 >>Accept Message in a Bottle
.target Princess Poobah
step
.goto Stranglethorn Vale,40.94,83.89
>>Kill |cRXP_ENEMY_King Mukla|r. Loot him for his |cRXP_LOOT_Key|r
>>|cRXP_WARN_Clear a bit of space around|r |cRXP_ENEMY_King Mukla|r|cRXP_WARN_, as he has a fear|r
.complete 630,1 
.unitscan King Mukla
step
.goto Stranglethorn Vale,38.53,80.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Princess Poobah|r
.turnin 630 >>Turn in Message in a Bottle
.target Princess Poobah
step
.goto Stranglethorn Vale,36.86,69.51
>>Kill |cRXP_ENEMY_Gorlash|r. Loot him for his |cRXP_LOOT_Chest|r
>>|cRXP_WARN_Be careful as he hits hard!|r
>>|cRXP_WARN_You can kite him back to the Booty Bay guards, and get credit as long as you did the majority damage|r
.link https://youtu.be/lNy2ohTWeLw?t=1037 >> CLICK HERE for a reference
.complete 8551,1 
.isOnQuest 8551
.unitscan Gorlash
.group 2
step
#completewith next
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
>>|cRXP_WARN_Do NOT pull or attack|r |cRXP_ENEMY_Zanzil the Outcast|r
.complete 621,1 
step
.goto Stranglethorn Vale,40.00,58.24
>>Kill |cRXP_ENEMY_Chucky|r. Loot him for his |cRXP_LOOT_Ring|r
.complete 609,3 
.unitscan Chucky "Ten Thumbs"
step
#optional
#loop
.goto Stranglethorn Vale,39.49,58.77,0
.goto Stranglethorn Vale,39.49,58.77,40,0
.goto Stranglethorn Vale,40.89,59.35,40,0
.goto Stranglethorn Vale,41.28,56.94,40,0
.goto Stranglethorn Vale,39.57,57.68,40,0
.goto Stranglethorn Vale,38.80,59.32,40,0
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
|cRXP_WARN_Try to get at least 8 |cRXP_LOOT_Mixtures|r as there are limited |cRXP_ENEMY_Zanzil|r mobs in the next camp|r
>>|cRXP_WARN_Do NOT pull or attack|r |cRXP_ENEMY_Zanzil the Outcast|r
.complete 621,1,8 
step
#optional
#completewith Maury
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
.complete 621,1 
step
.goto Stranglethorn Vale,34.92,51.84
>>Kill |cRXP_ENEMY_Jon-Jon|r. Loot him for his |cRXP_LOOT_Spyglass|r
.complete 609,2 
.unitscan Jon-Jon the Crow
step
#label Maury
.goto Stranglethorn Vale,35.25,51.25
>>Kill |cRXP_ENEMY_Maury|r. Loot her for her |cRXP_LOOT_Clubbed Foot|r
.complete 609,1 
.unitscan Maury "Club Foot" Wilkins
step
#loop
.goto Stranglethorn Vale,34.66,51.96,0
.goto Stranglethorn Vale,34.66,51.96,30,0
.goto Stranglethorn Vale,35.12,50.82,30,0
>>Kill |cRXP_ENEMY_Zanzil Undeads|r. Loot them for their |cRXP_LOOT_Mixture|r
>>|cRXP_WARN_Return to the previous camp to find more |cRXP_ENEMY_Zanzil Undeads|r if needed|r
.complete 621,1 
.mob Zanzil Zombie
.mob Zanzil Hunter
.mob Zanzil Witch Doctor
.mob Zanzil Naga
step
#completewith HolyWater
.goto Stranglethorn Vale,27.07,59.30,40,0
.goto Stranglethorn Vale,27.37,62.97,30 >>Travel to the Nek'Mani Wellspring
step
#completewith next
>>Kill |cRXP_ENEMY_Naga Explorers|r. Loot them for their |cRXP_LOOT_Akiris Reed|r
.complete 573,1 
.complete 617,1 
.mob Naga Explorer
step
#label HolyWater
.goto Stranglethorn Vale,28.96,61.94
>>Click |cRXP_PICK_The Holy Spring|r to loot the |cRXP_LOOT_Holy Spring Water|r
.complete 573,2 
step
#loop
.goto Stranglethorn Vale,28.00,63.12,0
.goto Stranglethorn Vale,28.00,63.12,50,0
.goto Stranglethorn Vale,28.15,64.42,50,0
.goto Stranglethorn Vale,25.55,63.11,50,0
.goto Stranglethorn Vale,25.07,63.73,50,0
.goto Stranglethorn Vale,24.61,64.59,50,0
.goto Stranglethorn Vale,24.02,63.74,50,0
.goto Stranglethorn Vale,24.15,62.14,50,0
.goto Stranglethorn Vale,24.49,61.33,50,0
.goto Stranglethorn Vale,24.73,59.87,50,0
.goto Stranglethorn Vale,25.21,59.03,50,0
.goto Stranglethorn Vale,25.92,59.52,50,0
.goto Stranglethorn Vale,26.95,59.14,50,0
.goto Stranglethorn Vale,27.00,61.39,50,0
>>Finish killing |cRXP_ENEMY_Naga Explorers|r. Loot them for their |cRXP_LOOT_Akiris Reed|r
.complete 573,1 
.complete 617,1 
.mob Naga Explorer
step
.goto Stranglethorn Vale,26.70,73.60,150 >> Travel to Booty Bay
.subzoneskip 35
.isQuestComplete 617
step
.goto Stranglethorn Vale,26.70,73.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Hecklebury Smotts|r
.turnin 8551 >> Turn in The Captain's Chest
.target Captain Hecklebury Smotts
.isQuestComplete 8551
.group
step
.goto Stranglethorn Vale,28.60,75.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dizzy One-Eye|r
.turnin 576 >> Turn in Keep An Eye Out
.target Dizzy One-Eye
.isQuestComplete 576
step
.goto Stranglethorn Vale,27.80,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf" MacKinley|r
.turnin 609 >> Turn in Voodoo Dues
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,26.70,76.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Privateer Bloads|r
.turnin 617 >> Turn in Akiris by the Bundle
.target Privateer Bloads
step
.goto Stranglethorn Vale,26.55,76.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Viznik Goldgrubber|r
.bankwithdraw 2725,2728,2735,2730,2742,2732,2748,2751,2734,2740,2749,2745,2738,2744,2750,5862,9628 >>Withdraw all your |T134332:0|t[Green Hills of Stranglethorn Pages] from the bank
.target Viznik Goldgrubber
step
.goto Stranglethorn Vale,26.55,76.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Viznik Goldgrubber|r
.bankwithdraw 10699,8564 >>Withdraw the following from your bank:
>>|T135474:0|t[Yeh'kinya's Bramble] 
>>|T132833:0|t[Hippogryph Egg] 
.target Viznik Goldgrubber
step
.goto Stranglethorn Vale,27.11,77.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Crank|r
.turnin 621 >> Turn in Zanzil's Secret
.target Crank Fizzlebub
step
.goto Stranglethorn Vale,27.13,77.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Whiskey Slim|r
.accept 580 >> Accept Whiskey Slim's Lost Grog
.target Whiskey Slim
step
.goto Stranglethorn Vale,27.00,77.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Deeg|r upstairs
.turnin 587 >> Turn in Up to Snuff
.target Deeg
.isQuestComplete 587
step
.goto Stranglethorn Vale,26.99,77.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tReturn to |cRXP_FRIENDLY_Krazek|r
.accept 2864 >> Accept Tran'rek
.target Krazek
step
.goto Stranglethorn Vale,27.17,77.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fleet Master Seahorn|r
.turnin 604 >> Turn in The Bloodsail Buccaneers
.target Fleet Master Seahorn
step
#completewith BigGameTurnin
.goto Stranglethorn Vale,26.87,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Grom'gol >> Fly to Grom'gol Base Camp
.target Gringer
.subzoneskip 117
step
.goto Stranglethorn Vale,32.10,29.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Far Seer Mok'thardin|r
.turnin 573 >> Turn in Mok'thardin's Enchantment
.target Far Seer Mok'thardin
step
#completewith BigGameTurnin
.subzone 100 >>Travel to Nesingwary's Expedition
step
#completewith next
.goto Stranglethorn Vale,35.70,10.80,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Barnil|r
+Turn in all the |T134332:0|t[Green Hills of Stranglethorn - Pages] that you have
.target Barnil Stonepot
step
#label BigGameTurnin
.goto Stranglethorn Vale,35.70,10.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hemet|r
.turnin 208 >> Turn in Big Game Hunter
.target Hemet Nesingwary Jr.
.isQuestComplete 208
.group
step
#optional
#label StranglethornSkip
step
.hs >> Hearth to Camp Mojache
.use 6948
.bindlocation 1099,1
.subzoneskip 1099
.cooldown item,6948,>2,1
step
.goto Orgrimmar,45.13,63.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Camp Mojache >> Fly to Camp Mojache
.target Doras
.zoneskip Orgrimmar,1
step
#optional
.abandon 2864,571,197,587,348
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 47-49 Tanaris
#next 49-51 The Hinterlands
step
.goto Feralas,74.50,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.turnin 3122 >>Turn in Return to Witch Doctor Uzer'i
.timer 23,Return to Witch Doctor Uzer'i RP
.accept 3123 >>Accept Testing the Vessel
.accept 3380 >>Accept The Sunken Temple
.target Witch Doctor Uzer'i
step
#completewith TanarisHS
.goto Feralas,75.45,44.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Gadgetzan >>Fly to Gadgetzan
.target Shyn
.zoneskip Tanaris
step
.goto Tanaris,51.56,26.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.accept 3362 >>Accept Thistleshrub Valley
.target Tran'rek
step
.goto Tanaris,51.84,27.02
>>Click on the |cRXP_PICK_Wanted Poster|r
.accept 2781 >> Accept WANTED: Caliph Scorpidsting
.accept 2875 >> Accept WANTED: Andre Firebeard
step
.goto Tanaris,52.39,26.97
>>Click on the |cRXP_PICK_Egg-O-Matic|r next to the teleporter, then turn in your Hippogryph Egg
.accept 2741 >>Accept The Super Egg-O-Matic
.turnin 2741 >>Turn in The Super Egg-O-Matic
.addquestitem 8564,2741
.itemcount 8564,1
step
.goto Tanaris,52.80,27.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andi|r
.accept 5863 >>Accept The Dunemaul Compound
.target Andi Lynn
step
+|cRXP_WARN_Open your|r |T132594:0|t[Egg Crate]
.itemcount 8647,1 
.use 8647
step
.goto Tanaris,52.358,26.904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curgle Cranklehop|r
.accept 2750 >> Accept A Bad Egg
.turnin 2750 >> Turn in A Bad Egg
.target Curgle Cranklehop
.itemcount 8646,1 
step
.goto Tanaris,52.358,26.904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curgle Cranklehop|r
.accept 2749 >> Accept An Ordinary Egg
.turnin 2749 >> Turn in An Ordinary Egg
.target Curgle Cranklehop
.itemcount 8645,1 
step
.goto Tanaris,52.358,26.904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curgle Cranklehop|r
.accept 2748 >> Accept A Fine Egg
.turnin 2748 >> Turn in A Fine Egg
.target Curgle Cranklehop
.itemcount 8644,1 
step
.goto Tanaris,52.358,26.904
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Curgle Cranklehop|r
.accept 2747 >> Accept An Extraordinary Egg
.turnin 2747 >> Turn in An Extraordinary Egg
.target Curgle Cranklehop
.itemcount 8643,1 
step
+|cRXP_WARN_Open your|r |T132594:0|t[Box of Rations]
.itemcount 9539,1 
.use 9539
step
+|cRXP_WARN_Open your|r |T132595:0|t[Box of Spells]
.itemcount 9540,1 
.use 9540
step
+|cRXP_WARN_Open your|r |T132597:0|t[Box of Goodies]
.itemcount 9541,1 
.use 9541
step
#label TanarisHS
.goto Tanaris,52.50,27.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Fizzgrimble|r
.home >> Set your Hearthstone to Gadgetzan
.target Innkeeper Fizzgrimble
.bindlocation 976
step
.goto Tanaris,52.46,28.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r and |cRXP_FRIENDLY_Luglunket|r
.accept 1691 >> Accept More Wastewander Justice
.target Chief Engineer Bilgewhizzle
step
.goto Tanaris,51.80,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marin|r
.accept 2605 >>Accept The Thirsty Goblin
.target Marin Noggenfogger
step
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 992 >> Accept Gadgetzan Water Survey
.target Senior Surveyor Fizzledowser

step
.goto Tanaris,39.10,29.30
.use 8584 >> |cRXP_WARN_Use the|r |T134867:0|t[Untapped Dowsing Widget] |cRXP_WARN_at the pool|r
>>|cRXP_WARN_Run away from the two mobs that spawn without attacking them|r
.complete 992,1 
step
#completewith next
.line Tanaris,61.91,35.57,61.91,34.80,62.93,33.28,63.92,31.73,63.93,33.36,63.43,34.33,62.47,35.20,61.91,35.57,60.95,36.69,60.33,37.27,59.56,38.41,58.86,39.41,59.56,38.41,60.33,37.27,60.95,36.69,61.91,35.57,62.47,35.20,63.35,37.42,62.21,37.99,60.84,38.59,62.21,37.99,63.35,37.42,64.21,36.43,64.64,35.28,64.30,33.66,64.18,32.42,63.94,31.73
>>Kill |cRXP_ENEMY_Caliph Scorpidsting|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Be careful; he has two stealthed adds with him|r
.complete 2781,1 
.unitscan Caliph Scorpidsting
step
#loop
.goto Tanaris,61.04,32.76,0
.goto Tanaris,58.75,36.42,80,0
.goto Tanaris,60.10,37.07,80,0
.goto Tanaris,60.84,38.91,80,0
.goto Tanaris,61.04,32.76,80,0
.goto Tanaris,61.84,34.95,80,0
.goto Tanaris,63.48,37.90,80,0
.goto Tanaris,63.80,39.94,80,0
.goto Tanaris,65.10,39.50,80,0
.goto Tanaris,65.36,36.67,80,0
.goto Tanaris,61.04,32.76,80,0
>>Kill |cRXP_ENEMY_Wastewander Rogues|r, |cRXP_ENEMY_Assassins|r and |cRXP_ENEMY_Shadow Mages|r
.complete 1691,1 
.mob +Wastewander Rogue
.complete 1691,2 
.mob +Wastewander Assassin
.complete 1691,3 
.mob +Wastewander Shadow Mage
step
#loop
.line Tanaris,61.91,35.57,61.91,34.80,62.93,33.28,63.92,31.73,63.93,33.36,63.43,34.33,62.47,35.20,61.91,35.57,60.95,36.69,60.33,37.27,59.56,38.41,58.86,39.41,59.56,38.41,60.33,37.27,60.95,36.69,61.91,35.57,62.47,35.20,63.35,37.42,62.21,37.99,60.84,38.59,62.21,37.99,63.35,37.42,64.21,36.43,64.64,35.28,64.30,33.66,64.18,32.42,63.94,31.73
.goto Tanaris,61.09,35.99,0
.goto Tanaris,61.09,35.99,60,0
.goto Tanaris,61.91,34.80,60,0
.goto Tanaris,62.93,33.28,60,0
.goto Tanaris,63.92,31.73,60,0
.goto Tanaris,63.93,33.36,60,0
.goto Tanaris,63.43,34.33,60,0
.goto Tanaris,62.47,35.20,60,0
.goto Tanaris,61.91,35.57,60,0
.goto Tanaris,60.95,36.69,60,0
.goto Tanaris,60.33,37.27,60,0
.goto Tanaris,59.56,38.41,60,0
.goto Tanaris,58.86,39.41,60,0
.goto Tanaris,59.56,38.41,60,0
.goto Tanaris,60.33,37.27,60,0
.goto Tanaris,60.95,36.69,60,0
.goto Tanaris,61.91,35.57,60,0
.goto Tanaris,62.47,35.20,60,0
.goto Tanaris,63.35,37.42,60,0
.goto Tanaris,62.21,37.99,60,0
.goto Tanaris,60.84,38.59,60,0
.goto Tanaris,62.21,37.99,60,0
.goto Tanaris,63.35,37.42,60,0
.goto Tanaris,64.21,36.43,60,0
.goto Tanaris,64.64,35.28,60,0
.goto Tanaris,64.30,33.66,60,0
.goto Tanaris,64.18,32.42,60,0
.goto Tanaris,63.94,31.73,60,0
>>Kill |cRXP_ENEMY_Caliph Scorpidsting|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Be careful; he has two stealthed adds with him|r
.complete 2781,1 
.unitscan Caliph Scorpidsting
step
#label RiggerCove
#completewith FireBeard
.goto Tanaris,68.76,41.51,30,0
.subzone 1336 >>Travel south to Lost Rigger Cove
.isOnQuest 8365,2873,8366,2875
step
#requires RiggerCove
#completewith PiratesEnd
>>|cRXP_WARN_Open any|r |T132596:0|t[Pirate's Footlocker] |cRXP_WARN_you loot.|r It may contain the |T134939:0|t[|cRXP_LOOT_Ship Schedule|r]. Use it to accept the quest
>>|cRXP_WARN_Ignore this step if you don't get it|r
.collect 9250,1,2876 
.accept 2876 >>Accept Ship Schedules
step
#requires RiggerCove
#completewith StolenCargo
>>Kill |cRXP_ENEMY_Southsea Pirates|r. Loot them for their |cRXP_LOOT_Pirate Hats|r
.complete 8366,3 
.mob +Southsea Dock Worker
.complete 8366,4 
.mob +Southsea Swashbuckler
.complete 8366,1 
.mob +Southsea Pirate
.complete 8366,2 
.mob +Southsea Freebooter
.complete 8365,1 
.mob +Southsea Pirate
.mob +Southsea Freebooter
.mob +Southsea Dock Worker
.mob +Southsea Swashbuckler
step
#requires RiggerCove
#completewith next
>>Loot the |cRXP_PICK_Stolen Cargo|r for |cRXP_LOOT_Stoley's Shipment|r on the second floor of the western house
.complete 2873,1 
step
#requires RiggerCove
#label FireBeard
.goto Tanaris,73.37,47.14
>>Kill |cRXP_ENEMY_Andre Firebeard|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_He pulls with nearby mobs. Split-pull him if you can|r << Mage/Warlock
.complete 2875,1 
.unitscan Andre Firebeard
step
#label StolenCargo
.goto Tanaris,72.23,46.81
>>Loot the |cRXP_PICK_Stolen Cargo|r for |cRXP_LOOT_Stoley's Shipment|r on the second floor of the western house
.complete 2873,1 
step
#label PiratesEnd
>>Kill |cRXP_ENEMY_Southsea Pirates|r. Loot them for their |cRXP_LOOT_Pirate Hats|r
.complete 8366,3 
.mob +Southsea Dock Worker
.goto Tanaris,74.55,46.95,20,0
.goto Tanaris,74.67,48.04,25,0
.goto Tanaris,73.66,47.97,30,0
.goto Tanaris,74.67,48.04
.complete 8366,4 
.mob +Southsea Swashbuckler
.goto Tanaris,74.89,46.16,40,0
.goto Tanaris,75.44,45.52,40,0
.goto Tanaris,76.19,45.22,40,0
.goto Tanaris,72.83,48.15,40,0
.goto Tanaris,75.44,45.52
.complete 8366,1 
.mob +Southsea Pirate
.goto Tanaris,70.94,42.85,50,0
.goto Tanaris,72.22,44.35,50,0
.goto Tanaris,72.58,45.30,50,0
.goto Tanaris,71.07,46.03,50,0
.goto Tanaris,71.25,47.98,50,0
.goto Tanaris,72.39,48.23,50,0
.goto Tanaris,72.59,47.10,50,0
.goto Tanaris,73.27,47.99,50,0
.goto Tanaris,74.25,47.27,50,0
.goto Tanaris,73.68,45.89,50,0
.goto Tanaris,72.58,45.30,50,0
.goto Tanaris,72.22,44.35,50,0
.goto Tanaris,70.94,42.85
.complete 8366,2 
.mob +Southsea Freebooter
.goto Tanaris,70.94,42.85,50,0
.goto Tanaris,72.22,44.35,50,0
.goto Tanaris,72.58,45.30,50,0
.goto Tanaris,71.07,46.03,50,0
.goto Tanaris,71.25,47.98,50,0
.goto Tanaris,72.39,48.23,50,0
.goto Tanaris,72.59,47.10,50,0
.goto Tanaris,73.27,47.99,50,0
.goto Tanaris,74.25,47.27,50,0
.goto Tanaris,73.68,45.89,50,0
.goto Tanaris,72.58,45.30,50,0
.goto Tanaris,72.22,44.35,50,0
.goto Tanaris,70.94,42.85
.complete 8365,1 
.mob +Southsea Pirate
.mob +Southsea Freebooter
.mob +Southsea Dock Worker
.mob +Southsea Swashbuckler
.goto Tanaris,70.94,42.85,50,0
.goto Tanaris,72.22,44.35,50,0
.goto Tanaris,72.58,45.30,50,0
.goto Tanaris,71.07,46.03,50,0
.goto Tanaris,71.25,47.98,50,0
.goto Tanaris,72.39,48.23,50,0
.goto Tanaris,72.59,47.10,50,0
.goto Tanaris,73.27,47.99,50,0
.goto Tanaris,74.25,47.27,50,0
.goto Tanaris,73.68,45.89,50,0
.goto Tanaris,72.58,45.30,50,0
.goto Tanaris,72.22,44.35,50,0
.goto Tanaris,70.94,42.85
step
#completewith PirateTurnins
.subzone 977 >>Travel north to Steamwheedle Port
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r and |cRXP_FRIENDLY_Stoley|r
.turnin 2875 >>Turn in WANTED: Andre Firebeard
.turnin 8366 >>Turn in Southsea Shakedown
.turnin 2876 >> Turn in Ship Schedules
.target +Security Chief Bilgewhizzle
.goto Tanaris,67.06,23.89
.turnin 2873 >>Turn in Stoley's Shipment
.accept 2874 >>Accept Deliver to MacKinley
.target +Stoley
.goto Tanaris,67.11,23.98
.isOnQuest 2876
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r and |cRXP_FRIENDLY_Stoley|r
.turnin 2875 >>Turn in WANTED: Andre Firebeard
.turnin 8366 >>Turn in Southsea Shakedown
.target +Security Chief Bilgewhizzle
.goto Tanaris,67.06,23.89
.turnin 2873 >>Turn in Stoley's Shipment
.accept 2874 >>Accept Deliver to MacKinley
.target +Stoley
.goto Tanaris,67.11,23.98
step
#label PirateTurnins
.goto Tanaris,66.60,22.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Haughty|r
.turnin 8365 >>Turn in Pirate Hats Ahoy!
.target Haughty Modiste
step << Shaman
#completewith TanarisTurnins1
.hs >>Hearth back to Gadgetzan
.use 6948
.subzoneskip 976
.cooldown item,6948,>0
.bindlocation 976,1
step
#completewith TanarisTurnins1
.subzone 976 >>Travel to Gadgetzan
.cooldown item,6948,<0 << Shaman
step
.goto Tanaris,52.40,28.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r
.turnin 1691 >> Turn in More Wastewander Justice
.turnin 2781 >> Turn in WANTED: Caliph Scorpidsting
.target Chief Engineer Bilgewhizzle
.isQuestComplete 2781
step
#label TanarisTurnins1
.goto Tanaris,52.40,28.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bilgewhizzle|r
.turnin 1691 >> Turn in More Wastewander Justice
.target Chief Engineer Bilgewhizzle
step
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 992 >> Turn in Gadgetzan Water Survey
.accept 82 >> Accept Noxious Lair Investigation
.target Senior Surveyor Fizzledowser
step
.goto Tanaris,52.70,45.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon|r
.turnin 3380 >>Turn in The Sunken Temple
.accept 3444 >> Accept The Stone Circle
.accept 3161 >> Accept Gahz'ridian
.target Marvon Rivetseeker
.isOnQuest 3380
step
#optional
.goto Tanaris,52.70,45.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon|r
.accept 3444 >> Accept The Stone Circle
.accept 3161 >> Accept Gahz'ridian
.target Marvon Rivetseeker
.isQuestTurnedIn 3380
step
.goto Tanaris,52.70,45.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon|r
.accept 3161 >> Accept Gahz'ridian
.target Marvon Rivetseeker
step
#completewith ToogaAccept
.use 9978 >>Equip your |T133151:0|t[Gahz'ridian Detector]
>>Loot any |cRXP_PICK_Piles of Sand|r you see for |cRXP_LOOT_Gahz'ridian Ornaments|r
>>|cRXP_WARN_Gahz'ridian will appear on your minimap. Many can be found in and around the Eastmoon and Southmoon ruins|r
.complete 3161,1 
.use 9978
step
#completewith next
.subzone 982 >>Travel west to The Noxious Lair
step
#loop
.goto Tanaris,35.68,39.78,0
.goto Tanaris,35.68,39.78,70,0
.goto Tanaris,36.55,41.98,70,0
.goto Tanaris,35.59,44.08,70,0
.goto Tanaris,35.60,48.79,70,0
.goto Tanaris,31.70,49.12,70,0
.goto Tanaris,30.83,46.10,70,0
>>Kill |cRXP_ENEMY_Centipaar Silithids|r. Loot them for their |cRXP_LOOT_Insect Parts|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Centipaar Swarmers|r|cRXP_WARN_. They can spawn many minions and social aggro from great distances|r
>>|cRXP_WARN_All|r |cRXP_ENEMY_Centipaar|r |cRXP_WARN_cast|r |T132152:0|t[Thrash] |cRXP_WARN_(Charges 2 extra attacks every 10 seconds)
.complete 82,1 
.mob Centipaar Wasp
.mob Centipaar Stinger
.mob Centipaar Swarmer
.mob Centipaar Worker
.mob Centipaar Sandreaver
.mob Centipaar Tunneler
step
#completewith Garmarok
.subzone 983 >>Travel to the Dunemaul Compound
step
#completewith next
>>Kill |cRXP_ENEMY_Dunemaul Brutes|r and |cRXP_ENEMY_Dunemaul Enforcers|r
>>|cRXP_WARN_Avoid|r |cRXP_ENEMY_Dunemaul Warlocks|r|cRXP_WARN_, as they have Curse of Thorns|r << Rogue/Warrior/Shaman/Paladin/Hunter
.complete 5863,1 
.mob +Dunemaul Brute
.complete 5863,2 
.mob +Dunemaul Enforcer
step
#label Garmarok
.goto Tanaris,41.50,57.80
>>Kill |cRXP_ENEMY_Gor'marok|r in the cave
>>|cRXP_WARN_Be careful of his heavy damage output and Mortal Strike|r
.complete 5863,3 
.unitscan Gor'marok the Ravager
step
#loop
.goto Tanaris,39.86,73.23,0
.goto Tanaris,44.97,63.83,80,0
.goto Tanaris,47.66,65.53,80,0
.goto Tanaris,41.98,71.25,80,0
.goto Tanaris,39.86,73.23,80,0
>>Kill |cRXP_ENEMY_Dunemaul Brutes|r and |cRXP_ENEMY_Dunemaul Enforcers|r
>>|cRXP_WARN_Avoid|r |cRXP_ENEMY_Dunemaul Warlocks|r|cRXP_WARN_, as they have Curse of Thorns|r << Rogue/Warrior/Shaman/Paladin/Hunter
.complete 5863,1 
.mob +Dunemaul Brute
.complete 5863,2 
.mob +Dunemaul Enforcer
step
#completewith Thistleshrubs
.goto Tanaris,31.06,64.91,60,0
.subzone 980 >>Travel to Thistleshrub Valley
step
#completewith next
>>Kill |cRXP_ENEMY_Thistleshrub Dew Collectors|r. Loot them for a |cRXP_LOOT_Laden Dew Gland|r
>>|cRXP_WARN_This has a low drop rate and its spawn is shared with other mob types, so kill everything to make them spawn faster|r
.complete 2605,1 
.mob Thistleshrub Dew Collector
step
#label Thistleshrubs
#loop
.goto Tanaris,29.50,62.98,0
.goto Tanaris,29.50,62.98,60,0
.goto Tanaris,27.76,65.80,60,0
.goto Tanaris,28.30,68.39,60,0
.goto Tanaris,30.63,66.57,60,0
.goto Tanaris,30.62,63.76,60,0
>>Kill |cRXP_ENEMY_Gnarled Thistleshrubs|r and |cRXP_ENEMY_Thistleshrub Rootshaper|r
.complete 3362,1 
.mob +Gnarled Thistleshrub
.complete 3362,2 
.mob +Thistleshrub Rootshaper
step
#label ThistleshrubsEnd
#loop
.goto Tanaris,29.50,62.98,0
.goto Tanaris,29.50,62.98,60,0
.goto Tanaris,27.76,65.80,60,0
.goto Tanaris,28.30,68.39,60,0
.goto Tanaris,30.63,66.57,60,0
.goto Tanaris,30.62,63.76,60,0
>>Kill |cRXP_ENEMY_Thistleshrub Dew Collectors|r. Loot them for a |cRXP_LOOT_Laden Dew Gland|r
>>|cRXP_WARN_This has a low drop rate and its spawn is shared with other mob types, so kill everything to make them spawn faster|r
.complete 2605,1 
.mob Thistleshrub Dew Collector
step
#label ToogaAccept
#loop
.goto Tanaris,29.37,59.97,0
.goto Tanaris,28.70,67.32,0
.goto Tanaris,31.66,74.70,0
.goto Tanaris,29.37,59.97,50,0
.goto Tanaris,28.70,67.32,50,0
.goto Tanaris,31.66,74.70,50,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tSearch for |cRXP_FRIENDLY_Tooga|r, then talk to him to start his escort quest
>>|cRXP_WARN_He has 4 different spawn locations in the area|r
.accept 1560,1 >>Accept Tooga's Quest
.target Tooga
step
#completewith next
>>Guide |cRXP_FRIENDLY_Tooga|r toward Steamwheedle Port
>>|cRXP_WARN_You will fail the quest if you get too far away from him|r
>>|cRXP_WARN_This quest has a 30 minute timer!|r
.complete 1560,1 
.target Tooga
step
#loop
.goto Tanaris,39.86,73.23,0
.goto Tanaris,44.97,63.83,80,0
.goto Tanaris,47.66,65.53,80,0
.goto Tanaris,41.98,71.25,80,0
.goto Tanaris,39.86,73.23,80,0
.use 9978 >>Equip your |T133151:0|t[Gahz'ridian Detector]
>>Loot the |cRXP_PICK_Piles of Sand|r for |cRXP_LOOT_Gahz'ridian Ornaments|r
>>|cRXP_WARN_Gahz'ridian will appear on your minimap. Many can be found in and around the Eastmoon and Southmoon ruins|r
.complete 3161,1 
.use 9978
step
.goto Tanaris,66.58,25.64
>>Guide |cRXP_FRIENDLY_Tooga|r toward Steamwheedle Port
>>|cRXP_WARN_You will fail the quest if you get too far away from him|r
>>|cRXP_WARN_This quest has a 30 minute timer!|r
.complete 1560,1 
.target Tooga
step
.goto Tanaris,66.58,25.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torta|r
.turnin 1560 >>Turn in Tooga's Quest
.target Torta
step
.goto Tanaris,67.00,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3520 >>Turn in Screecher Spirits
.accept 3527 >> Accept The Prophecy of Mosh'aru
.target Yeh'kinya
.isQuestComplete 3520
.dungeon ZF
step
.goto Tanaris,67.00,22.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3520 >>Turn in Screecher Spirits
.target Yeh'kinya
.isQuestComplete 3520
step
#completewith TanarisTurnins2
#optional
.abandon 3520
step << Shaman
#completewith TanarisTurnins2
.hs >>Hearth or Astrall Recall back to Gadgetzan
.use 6948
.subzoneskip 976
.bindlocation 976,1
step << !Shaman
#completewith TanarisTurnins2
.subzone 976 >>Travel to Gadgetzan
step
.goto Tanaris,52.80,27.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andi|r
.turnin 5863 >>Turn in The Dunemaul Compound
.target Andi Lynn
step
.goto Tanaris,51.80,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marin|r
.turnin 2605 >>Turn in The Thirsty Goblin
.accept 2606 >>Accept In Good Taste
.target Marin Noggenfogger
step
.goto Tanaris,51.10,26.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sprinkle|r
.turnin 2606 >>Turn in In Good Taste
.accept 2641 >>Accept Sprinkle's Secret Ingredient
.target Sprinkle
step
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 82 >>Turn in Noxious Lair Investigation
.target Alchemist Pestlezugg
step
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.accept 10 >>Accept The Scrimshank Redemption
.target Senior Surveyor Fizzledowser
step
.goto Tanaris,51.50,26.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.turnin 3362 >>Turn in Thistleshrub Valley
.target Tran'rek
step
#label TanarisTurnins2
.goto Tanaris,52.70,45.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon|r
.turnin 3161 >>Turn in Gahz'ridian
.target Marvon Rivetseeker
.isQuestComplete 3161
step
#completewith next
.goto Tanaris,56.19,66.62,30,0
.subzone 981 >>Travel south to The Gaping Chasm
step
#label BugHole
.goto Tanaris,55.69,69.44,50,0
.goto Tanaris,56.36,68.44,30,0
.goto Tanaris,57.45,70.45,30,0
.goto Tanaris,55.96,71.16
>>Enter the silithid hive, then click the |cRXP_PICK_Scrimshank's Surveying Gear console|r and loot |cRXP_LOOT_Scrimshank's Surveying Gear|r
>>|cRXP_WARN_Be extremely cautious of |cRXP_ENEMY_Hazzali Swarmers|r |cRXP_WARN_as they can rapidly summon adds which deal high damage. They can also social aggro other mobs from extreme distances|r
.complete 10,1 
.unitscan Hazzali Swarmer
step
.use 8623 >>If you've found the |T132836:0|t[|cRXP_FRIENDLY_OOX-17/TN Distress Beacon|r], use it to accept its quest
>>|cRXP_WARN_Skip this step if you did not find it|r
.accept 351 >>Accept Find OOX-17/TN!
.itemcount 8623,1
step
#optional
.goto Tanaris,60.20,64.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r
.turnin 351 >>Turn in Find OOX-17/TN!
.target Homing Robot OOX-17/TN
.isOnQuest 351
step
#optional
.goto Tanaris,60.23,64.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r again to start the escort quest
>>|cRXP_WARN_This quest can be difficult. Eat/drink to full and apply any self-buffs (scrolls, food, elixirs, etc.)|r
.accept 648,1 >>Accept Rescue OOX-17/TN!
.target Homing Robot OOX-17/TN
.isQuestTurnedIn 351
step
#optional
.goto Tanaris,67.09,23.18
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-17/TN|r to Steamwheedle Port
>>|cRXP_WARN_A pack of 3 level 46-47|r |cRXP_ENEMY_Scorpions|r |cRXP_WARN_will spawn at the next mountain chain|r
>>|cRXP_WARN_A pack of 3 level 43-45|r |cRXP_ENEMY_Wastewander mobs|r |cRXP_WARN_will spawn around Waterspring Field. Focus the|r |cRXP_ENEMY_Scofflaw|r|cRXP_WARN_. It EXECUTES when you're below 20% health|r
.complete 648,1 
.target Homing Robot OOX-17/TN
.unitscan Wastewander Scofflaw
.isQuestTurnedIn 351
step << Druid
#completewith DruidTraining6
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
.cooldown item,6948,<0
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9829 >> Train your class spells
.target Loganaar
.xp <46,1
.xp >48,1
.cooldown item,6948,<0
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 22828 >> Train your class spells
.target Loganaar
.xp <48,1
.xp >50,1
.cooldown item,6948,<0
step << Druid
#label DruidTraining6
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9884 >> Train your class spells
.target Loganaar
.xp <50,1
.cooldown item,6948,<0
step
#sticky
#completewith EnterZF
.subzone 978,2 >> Now you should be looking for a group to Zul'Farrak
.dungeon ZF
step
#completewith TanarisTurnins3
.hs >>Hearth back to Gadgetzan
.use 6948
.subzoneskip 976
.cooldown item,6948,>0
.bindlocation 976,1
step
#completewith TanarisTurnins3
.subzone 976 >>Travel to Gadgetzan
.cooldown item,6948,<0
step
.goto Tanaris,50.21,27.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 10 >>Turn in The Scrimshank Redemption
.accept 110 >>Accept Insect Part Analysis
.target Senior Surveyor Fizzledowser
step
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 110 >>Turn in Insect Part Analysis
.accept 113 >>Accept Insect Part Analysis
.target Alchemist Pestlezugg
step
#label TanarisTurnins3
.goto Tanaris,50.20,27.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzledowser|r
.turnin 113 >>Turn in Insect Part Analysis
.accept 32 >>Accept Rise of the Silithid
.target Senior Surveyor Fizzledowser
step
.goto Tanaris,51.413,28.752
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trenton Lighthammer|r
.accept 3042 >> Accept Troll Temper
.target Trenton Lighthammer
.dungeon ZF
step
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.accept 2768 >> Accept Divino-matic Rod
.target Chief Engineer Bilgewhizzle
.dungeon ZF
step
.goto Tanaris,51.566,26.759
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.accept 2865 >> Accept Scarab Shells
.target Tran'rek
.dungeon ZF
step
#label EnterZF
.goto Tanaris,38.91,20.78,40,0
.goto Tanaris,38.731,19.839
.subzone 978,2 >> Enter Zul'Farrak
.dungeon ZF
step
#completewith Gahzrilla
>>Kill |cRXP_ENEMY_Trolls|r. Loot them for their |cRXP_LOOT_Troll Temper|r
.complete 3042,1 
.isOnQuest 3042
.dungeon ZF
step
#completewith next
>>Kill |cRXP_ENEMY_Scarabs|r. Loot them for their |cRXP_LOOT_Uncracked Scarab Shell|r
.complete 2865,1 
.isOnQuest 2865
.dungeon ZF
step
>>Kill |cRXP_ENEMY_Theka the Martyr|r. Loot him for the |cRXP_LOOT_First Mosh'aru Tablet|r
.complete 3527,1 
.mob Theka the Martyr
.isOnQuest 3527
.dungeon ZF
step
>>Kill |cRXP_ENEMY_Scarabs|r. Loot them for their |cRXP_LOOT_Uncracked Scarab Shell|r
.complete 2865,1 
.isOnQuest 2865
.dungeon ZF
step
#completewith next
+Ascend the Pyramid
>>Kill the |cRXP_ENEMY_Sandfury Executioner|r. Loot him for the |cRXP_LOOT_Executioner's Key|r
>>|cRXP_WARN_Anyone in the party may loot the|r |cRXP_LOOT_Key|r
>>|cRXP_WARN_Use the|r |cRXP_LOOT_Executioner's Key|r |cRXP_WARN_on one of the |cRXP_PICK_Troll Cages|r to free |cRXP_FRIENDLY_Sergeant Bly|r and his band|r
.collect 8444,1 
.disablecheckbox
.isOnQuest 2768
.mob Sandfury Executioner
.dungeon ZF
step
>>Defend |cRXP_FRIENDLY_Sergeant Bly|r and his band, then move down with them after a short period of time
>>Kill |cRXP_ENEMY_Nekrum Gutchewer|r. Eat and drink then talk to |cRXP_FRIENDLY_Sergeant Bly|r to fight him
>>Kill |cRXP_ENEMY_Sergeant Bly|r. Loot him for the |cRXP_LOOT_Divino-matic Rod|r
.complete 2768,1 
.isOnQuest 2768
.skipgossip
.dungeon ZF
step
>>Kill |cRXP_ENEMY_Hydromancer Velratha|r. Loot her for the |cRXP_LOOT_Tiara of the Deep|r and the |cRXP_LOOT_Second Mosh'aru Tablet|r
.complete 2846,1 
.complete 3527,2 
.mob Hydromancer Velratha
.isOnQuest 2846
.isOnQuest 3527
.dungeon ZF
step
#optional
>>Kill |cRXP_ENEMY_Hydromancer Velratha|r. Loot her for the |cRXP_LOOT_Tiara of the Deep|r
.complete 2846,1 
.mob Hydromancer Velratha
.isOnQuest 2846
.dungeon ZF
step
#optional
>>Kill |cRXP_ENEMY_Hydromancer Velratha|r. Loot her for the |cRXP_LOOT_Second Mosh'aru Tablet|r
.complete 3527,2 
.mob Hydromancer Velratha
.isOnQuest 3527
.dungeon ZF
step
#label Gahzrilla
>>|cRXP_WARN_Use the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_on the |cRXP_PICK_Gong of Zul'Farrak|r to summon|r |cRXP_ENEMY_Gahz'rilla|r
>>Kill |cRXP_ENEMY_Gahz'rilla|r. Loot him for |cRXP_LOOT_Gahz'rilla's Electrified Scale|r
>>|cRXP_WARN_If no one in your party has the|r |T133056:0|t[Mallet of Zul'Farrak] |cRXP_WARN_you will not be able to summon|r |cRXP_ENEMY_Gahz'rilla|r
.complete 2770,1 
.mob Gahz'rilla
.isOnQuest 2770
.dungeon ZF
step
>>Kill |cRXP_ENEMY_Trolls|r. Loot them for their |cRXP_LOOT_Troll Temper|r
.complete 3042,1 
.isOnQuest 3042
.dungeon ZF
step
#completewith FlyDWM2
.hs >>Hearth back to Gadgetzan
.use 6948
.cooldown item,6948,>0
.dungeon ZF
.zoneskip Tanaris
.bindlocation 976,1
step
.goto Tanaris,51.413,28.752
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trenton Lighthammer|r
.turnin 3042 >> Turn in Troll Temper
.target Trenton Lighthammer
.isQuestComplete 3042
.dungeon ZF
step
.goto Tanaris,52.462,28.514
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chief Engineer Bilgewhizzle|r
.turnin 2768 >> Turn in Divino-matic Rod
.target Chief Engineer Bilgewhizzle
.isQuestComplete 2768
.dungeon ZF
step
.goto Tanaris,51.566,26.759
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.turnin 2865 >> Turn in Scarab Shells
.target Tran'rek
.isQuestComplete 2865
.dungeon ZF
step
#completewith AncientEggTurnin
.subzone 977 >> Travel to Steamwheedle Port
.dungeon ZF
step
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3527 >> Turn in The Prophecy of Mosh'aru
.target Yeh'kinya
.isQuestComplete 3527
.dungeon ZF
step
#label AncientEggTurnin
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.accept 4787 >> Accept The Ancient Egg
.target Yeh'kinya
.isQuestTurnedIn 3527
.dungeon ZF
step
#completewith next
.zone Thousand Needles >> Travel to the Shimmering Flats
.dungeon ZF
step
.goto Thousand Needles,78.143,77.120
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wizzle Brassbolts|r
.turnin 2770 >> Turn in Gahz'rilla
.target Wizzle Brassbolts
.isQuestComplete 2770
.dungeon ZF
step
#optional
.abandon 2770 >> Abandon Gahz'rilla
.dungeon ZF
step
#completewith next
.goto Tanaris,51.60,25.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Brackenwall >> Fly to Dustwallow Marsh
.target Bulkrek Ragefist
.dungeon ZF
step
.goto Dustwallow Marsh,46.021,57.096
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tabetha|r
.turnin 2846 >> Turn in Tiara of the Deep
.target Tabetha
.isQuestComplete 2846
.dungeon ZF
step << Mage
#completewith DeadmireTurnin
.cast 3566 >>|cRXP_WARN_Cast|r |T135765:0|t[Teleport: Thunder Bluff]
.zoneskip Thunder Bluff
step << !Mage
#completewith PlatDiscsTurnin
.goto Dustwallow Marsh,35.57,31.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shardi|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.target Shardi
.zoneskip Dustwallow Marsh,1
.zoneskip Thunder Bluff

.isQuestTurnedIn 2846
step << !Mage
#completewith DeadmireTurnin
.goto Tanaris,51.60,25.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.target Bulkrek Ragefist
.zoneskip Thunder Bluff
.zoneskip Dustwallow Marsh
step
#label DeadmireTurnin
.goto Thunder Bluff,61.50,80.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Melor|r
.turnin 1205 >>Turn in Deadmire
.target Melor Stonehoof
.isQuestComplete 1205
step
#label PlatDiscsTurnin
.goto Thunder Bluff,34.42,46.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sage|r
.turnin 2280 >> Turn in The Platinum Discs
.target Sage Truthseeker
.isQuestTurnedIn 2278
.dungeon ULDA
step
#sticky
#completewith EnterMaraudon
.subzone 2100,2 >> Now you should be looking for a group to Maraudon
.dungeon MARA
step
#completewith MaraPickups
.goto Tanaris,51.60,25.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Shadowprey Village >>Fly to Shadowprey Village
.target Bulkrek Ragefist
.zoneskip Tanaris,1
.dungeon MARA
step
#completewith MaraPickups
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Shadowprey Village >>Fly to Shadowprey Village
.target Tal
.zoneskip Thunder Bluff,1
.dungeon MARA
step
.goto Desolace,23.22,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vark|r at the top of the hut
.accept 7029 >> Accept Vyletongue Corruption
.target Vark Battlescar
.dungeon MARA
step
.goto Desolace,26.87,77.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Selendra|r
.accept 7064 >> Accept Corruption of Earth and Seed
.target Selendra
.dungeon MARA
step
#label MaraPickups
#loop
.line Desolace,50.48,86.66,50.39,86.61,50.18,87.01,49.89,87.11,48.95,87.04,48.73,87.11,48.25,87.14,47.82,87.34,47.01,86.96,45.68,86.22,45.16,86.32,44.74,86.12,44.40,85.69,44.11,85.25,43.77,84.93,43.59,84.93
.goto Desolace,43.59,84.93,50,0
.goto Desolace,47.01,86.96,70,0
.goto Desolace,50.48,86.66,50,0
.goto Desolace,50.48,86.66,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Centaur Pariah|r
>>|cRXP_WARN_The |cRXP_FRIENDLY_Centaur Pariah|r patrols slightly around southern Desolace|r
.accept 7067 >> Accept The Pariah's Instructions
.target Centaur Pariah
.dungeon MARA
step
.goto Desolace,62.194,39.624
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Willow|r
>>|cRXP_WARN_Have a party member share this quest if possible|r
.accept 7028 >> Accept Twisted Evils
.target Willow
.dungeon MARA
step
.goto Desolace,29.89,62.44,0
.goto 1414,38.43,57.97
.zone 1414 >> Travel to Maraudon
.dungeon MARA
step
#completewith EnterMaraudon
>>Kill all |cRXP_ENEMY_Monsters|r in Maraudon. Loot them for their |cRXP_LOOT_Theradric Crystal Carvings|r
>>|cRXP_WARN_This can be completed OUTSIDE and INSIDE of the Instance. Don't attempt to complete this now|r
.complete 7028,1 
.isOnQuest 7028
.dungeon MARA
step
>>Kill |cRXP_ENEMY_The Nameless Prophet|r. Loot it for the |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance. |cRXP_ENEMY_The Nameless Prophets|r may be patrolling|r
.collect 17757,1,7067,1 
.mob The Nameless Prophet
.isOnQuest 7067
.dungeon MARA
step
#completewith next
>>Kill |cRXP_ENEMY_Shadowshard Smashers|r and |cRXP_ENEMY_Shadowshard Rumblers|r. Loot them for their |cRXP_LOOT_Shadowshard Fragments|r
>>|cRXP_WARN_These are only found in the Purple section outside of the Instance|r
.complete 7068,1 
.mob Shadowshard Smasher
.mob Shadowshard Rumbler
.isOnQuest 7068
.dungeon MARA
step
#loop
.goto 1414,38.469,57.287,20,0
.goto 1414,38.380,57.376,30,0
.goto 1414,38.469,57.287,0
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Gelk|r
>>Kill |cRXP_ENEMY_Gelk|r. Loot him for the |T134104:0|t[|cRXP_LOOT_Gem of the Second Khan|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance|r
.collect 17762,1,7067,1 
.use 17757 
.mob Spirit of Gelk
.mob Gelk
.isOnQuest 7067
.dungeon MARA
step
#loop
.goto 1414,38.13,56.90,60,0
.goto 1414,28.76,56.96,60,0
.goto 1414,38.13,56.90,0
>>Kill |cRXP_ENEMY_Shadowshard Smashers|r and |cRXP_ENEMY_Shadowshard Rumblers|r. Loot them for their |cRXP_LOOT_Shadowshard Fragments|r
>>|cRXP_WARN_These are only found in the Purple section outside of the Instance|r
.complete 7068,1 
.mob Shadowshard Smasher
.mob Shadowshard Rumbler
.isOnQuest 7068
.dungeon MARA
step
.goto 1414,38.497,57.721
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Kolk|r
>>Kill |cRXP_ENEMY_Kolk|r. Loot him for the |T134129:0|t[|cRXP_LOOT_Gem of the First Khan|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance|r
.collect 17761,1,7067,1 
.use 17757 
.mob Spirit of Kolk
.mob Kolk
.isOnQuest 7067
.dungeon MARA
step
.goto 1414,38.77,58.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cavindra|r
.accept 7044 >> Accept Legends of Maraudon
.target Cavindra
.dungeon MARA
step
.goto 1414,38.928,58.354
>>|cRXP_WARN_Use the|r |T134865:0|t[Coated Cerulean Vial] |cRXP_WARN_in the Orange pool|r
.complete 7029,2 
.use 17693 
.isOnQuest 7029
.dungeon MARA
step
#loop
.goto 1414,39.00,58.32,70,0
.goto 1414,39.13,57.68,60,0
.goto 1414,39.25,57.71,20,0
.goto 1414,39.13,57.68,0
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Magra|r
>>Kill |cRXP_ENEMY_Magra|r. Loot him for the |T134135:0|t[|cRXP_LOOT_Gem of the Third Khan|r]
>>|cRXP_WARN_This is completed OUTSIDE of the Instance|r
.collect 17763,1,7067,1 
.use 17757 
.mob Spirit of Magra
.mob Magra
.isOnQuest 7067
.dungeon MARA
step
#label EnterMaraudon
.goto 1414,39.266,58.205
.subzone 2100,2 >> Enter the Maraudon Instance through the Orange side
.dungeon MARA
step
#completewith CrystalCarving
>>Kill any |cRXP_ENEMY_Monster|r in Maraudon. Loot them for their |cRXP_LOOT_Theradric Crystal Carvings|r
.complete 7028,1 
.isOnQuest 7028
.dungeon MARA
step
#completewith next
>>|cRXP_WARN_Use the|r |T134804:0|t[Filled Cerulean Vial] |cRXP_WARN_on small flowers/plants inside Orange|r
>>Kill the |cRXP_ENEMY_Noxxious Scions|r that are summoned
.complete 7029,1 
.use 17696 
.isOnQuest 7029
.dungeon MARA
step
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Veng|r
>>Kill |cRXP_ENEMY_Veng|r. Loot him for the |T134116:0|t[|cRXP_LOOT_Gem of the Fifth Khan|r]
>>|cRXP_ENEMY_Veng|r |cRXP_WARN_patrols around INSIDE the Maraudon Orange Instance|r
.collect 17765,1,7067,1 
.use 17757 
.mob Spirit of Veng
.mob Veng
.isOnQuest 7067
.dungeon MARA
step
>>|cRXP_WARN_Use the|r |T134804:0|t[Filled Cerulean Vial] |cRXP_WARN_on small flowers/plants inside Orange|r
>>Kill the |cRXP_ENEMY_Noxxious Scions|r that are summoned
.complete 7029,1 
.use 17696 
.isOnQuest 7029
.dungeon MARA
step
>>Kill |cRXP_ENEMY_Noxxion|r. Loot him for the |cRXP_LOOT_Celebrian Rod|r
>>Kill |cRXP_ENEMY_Lord Vyletongue|r. Loot him for the |cRXP_LOOT_Celebrian Diamond|r
>>|cRXP_ENEMY_Noxxion|r |cRXP_WARN_is in the Orange section and |cRXP_ENEMY_Lord Vyletongue|r in the Purple|r
.complete 7044,2 
.mob +Noxxion
.complete 7044,1 
.mob +Lord Vyletongue
.isOnQuest 7044
.dungeon MARA
step
>>|cRXP_WARN_Use the|r |T133277:0|t[|cRXP_LOOT_Amulet of Spirits|r] |cRXP_WARN_on the|r |cRXP_FRIENDLY_Spirit of Maraudos|r
>>Kill |cRXP_ENEMY_Maraudos|r. Loot him for the |T134132:0|t[|cRXP_LOOT_Gem of the Fourth Khan|r]
>>|cRXP_ENEMY_Maraudos|r |cRXP_WARN_patrols around INSIDE the Maraudon Purple Instance|r
.collect 17764,1,7067,1 
.use 17757 
.mob Spirit of Maraudos
.mob Maraudos
.isOnQuest 7067
.dungeon MARA
step
>>|cRXP_WARN_Channel any of the|r |T134129:0|t|T134104:0|t|T134135:0|t|T134132:0|t|T134116:0|t[|cRXP_LOOT_Gems of the Khans|r] |cRXP_WARN_to create the|r |T133277:0|t[|cRXP_LOOT_Amulet of Union|r]
.complete 7067,1 
.use 17761,1
.use 17762,1
.use 17763,1
.use 17764,1
.use 17765,1
.itemcount 17761,1
.itemcount 17762,1
.itemcount 17763,1
.itemcount 17764,1
.itemcount 17765,1
.isOnQuest 7067
.dungeon MARA
step
>>Kill |cRXP_ENEMY_Celebras the Cursed|r then talk to |cRXP_FRIENDLY_Celebras the Redeemed|r
.turnin 7044 >> Turn in Legends of Maraudon
.isQuestComplete 7044
.mob Celebras the Cursed
.target Celebras the Redeemed
.dungeon MARA
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celebras the Redeemed|r
.accept 7046 >> Accept The Scepter of Celebras
.timer 14,Incantation of Celebras Spawning RP
.target Celebras the Redeemed
.isQuestTurnedIn 7044
.dungeon MARA
step
.cast 6477 >> Click the |cRXP_PICK_Incantation of Celebras|r on the ground
.timer 34,The Scepter of Celebras RP
.isQuestTurnedIn 7044
.dungeon MARA
step
>>|cRXP_WARN_Wait out the RP|r
.complete 7046,1 
.isQuestTurnedIn 7044
.dungeon MARA
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Celebras the Redeemed|r
.turnin 7046 >> Turn in The Scepter of Celebras
.isQuestTurnedIn 7044
.target Celebras the Redeemed
.dungeon MARA
step
>>Kill |cRXP_ENEMY_Princess Theradras|r
.complete 7064,1 
.mob Princess Theradras
.isOnQuest 7064
.dungeon MARA
step
#label CrystalCarving
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zaetar's Spirit|r
.accept 7066 >> Accept Seed of Life
.target Zaetar's Spirit
.dungeon MARA
step
>>Kill any |cRXP_ENEMY_Monster|r in Maraudon. Loot them for their |cRXP_LOOT_Theradric Crystal Carvings|r
>>|cRXP_WARN_This can be completed OUTSIDE and INSIDE of the Instance|r
.complete 7028,1 
.isOnQuest 7028
.dungeon MARA
step
#completewith MaraTurnins
.zone Desolace >> Leave the Maraudon instance
.dungeon MARA
step
.goto Desolace,26.87,77.67
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Selendra|r
.turnin 7064 >> Turn in Corruption of Earth and Seed
.target Selendra
.isQuestComplete 7064
.dungeon MARA
step
.goto Desolace,23.22,70.33
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vark|r at the top of the hut
.turnin 7029 >> Turn in Vyletongue Corruption
.target Vark Battlescar
.isQuestComplete 7029
.dungeon MARA
step
#loop
.line Desolace,50.48,86.66,50.39,86.61,50.18,87.01,49.89,87.11,48.95,87.04,48.73,87.11,48.25,87.14,47.82,87.34,47.01,86.96,45.68,86.22,45.16,86.32,44.74,86.12,44.40,85.69,44.11,85.25,43.77,84.93,43.59,84.93
.goto Desolace,43.59,84.93,50,0
.goto Desolace,47.01,86.96,70,0
.goto Desolace,50.48,86.66,50,0
.goto Desolace,50.48,86.66,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Centaur Pariah|r
>>|cRXP_WARN_The |cRXP_FRIENDLY_Centaur Pariah|r patrols slightly around southern Desolace|r
.turnin 7067 >> Turn in The Pariah's Instructions
.target Centaur Pariah
.isQuestComplete 7067
.dungeon MARA
step
#label MaraTurnins
.goto Desolace,62.194,39.624
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Willow|r
.turnin 7028 >> Turn in Twisted Evils
.target Willow
.isQuestComplete 7028
.dungeon MARA
step << !Mage
#completewith next
.hs >>Hearth to Tanaris
.use 6948
.dungeon MARA
.subzoneskip 976
.bindlocation 976,1
step << !Mage
.goto Tanaris,52.63,28.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dirge|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Dirge Quikcleave
.dungeon MARA
step << Mage
#completewith OrgEnd
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << !Mage
#completewith OrgEnd
.goto Tanaris,51.60,25.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Bulkrek Ragefist
.zoneskip Tanaris,1
step << !Mage
#optional
#completewith OrgEnd
.goto Tanaris,51.60,25.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Orgrimmar >>Fly to Orgrimmar
.target Bulkrek Ragefist
.zoneskip Dustwallow Marsh,1
step << !Mage
#optional
#completewith OrgEnd
.goto Thunder Bluff,47.00,49.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Orgrimmar >>Fly to Orgrimmar
.target Tal
.zoneskip Thunder Bluff,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10197 >> Train your class spells
.target Pephredo
.xp <46,1
.xp >48,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10053 >> Train your class spells
.target Pephredo
.xp <48,1
.xp >50,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10160 >> Train your class spells
.target Pephredo
.xp <50,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10945 >> Train your class spells
.target Ur'kyo
.xp <46,1
.xp >48,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10899 >> Train your class spells
.target Ur'kyo
.xp <48,1
.xp >50,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10893 >> Train your class spells
.target Ur'kyo
.xp <50,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10472 >> Train your class spells
.target Kardris Dreamseeker
.xp <46,1
.xp >48,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10431 >> Train your class spells
.target Kardris Dreamseeker
.xp <48,1
.xp >50,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10437 >> Train your class spells
.target Kardris Dreamseeker
.xp <50,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 10300 >> Train your class spells
.target Master Pyreanor
.xp <46,1
.xp >48,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20356 >> Train your class spells
.target Master Pyreanor
.xp <48,1
.xp >50,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 20923 >> Train your class spells
.target Master Pyreanor
.xp <50,1
step
.isOnQuest 7732
.goto Orgrimmar,56.50,46.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zilzibin|r
>>|cRXP_WARN_He is located on the upper level in the Drag|r
.turnin 7732 >> Turn in Zukk'ash Report
.target Zilzibin Drumlore
step
.isOnQuest 32
.goto Orgrimmar,56.40,46.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zilzibin|r
>>|cRXP_WARN_He is located on the upper level in the Drag|r
.turnin 32 >>Turn in Rise of the Silithid
.target Zilzibin Drumlore
step
.goto Orgrimmar,59.40,36.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dran|r
.accept 649 >>Accept Ripple Recovery
.target Dran Droffers
step
.goto Orgrimmar,59.50,36.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malton|r
.turnin 649 >>Turn in Ripple Recovery
.accept 650 >>Accept Ripple Recovery
.target Malton Droffers
step
.isOnQuest 2976
.goto Orgrimmar,75.20,34.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.turnin 2976 >> Turn in A Grim Discovery
.target Belgrom Rockmaul
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11578 >> Train your class spells
.target Grezz Ragefist
.xp <46,1
.xp >48,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 20661 >> Train your class spells
.target Grezz Ragefist
.xp <48,1
.xp >50,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 1719 >> Train your class spells
.target Grezz Ragefist
.xp <50,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14304 >> Train your class spells
.target Ormak Grimshot
.xp <46,1
.xp >48,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14321 >> Train your class spells
.target Ormak Grimshot
.xp <48,1
.xp >50,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 13554 >> Train your class spells
.target Ormak Grimshot
.xp <50,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24562 >> Train your pet spells
.target Xao'tsu
.xp <48,1
step
.isOnQuest 3121
.goto Orgrimmar,49.60,50.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Neeru|r
.turnin 3121 >> Turn in A Strange Request

.target Neeru Fireblade
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11293 >> Train your class spells
.target Ormok
.xp <46,1
.xp >48,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11299 >> Train your class spells
.target Ormok
.xp <48,1
.xp >50,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8643 >> Train your class spells
.target Ormok
.xp <50,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11729 >> Train your class spells
.target Mirket
.xp <46,1
.xp >48,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11712 >> Train your class spells
.target Mirket
.xp <48,1
.xp >50,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11667 >> Train your class spells
.target Mirket
.xp <50,1
step << Warlock
.goto Orgrimmar,47.52,46.73
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kurgul|r
.vendor >>Buy any pet upgrades you can afford
.target Kurgul
.zoneskip Orgrimmar,1
step
#optional
.abandon 2846,3527,2768,3042




.dungeon ZF
step
#optional
.abandon 7029,7064,7067,7028,7068,7044






.dungeon MARA
step
#optional
#label OrgEnd
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 49-51 The Hinterlands
#next 51-51 Blasted lands (optional)
step
.goto Orgrimmar,54.10,68.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Gryshka|r
.home >>Set your Hearthstone to Orgrimmar
.target Innkeeper Gryshka
.bindlocation 1637
.zoneskip Orgrimmar,1
step << !Mage
#completewith next
.zone Durotar >> Leave Orgrimmar
step << !Mage
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Tirisfal Glades >>Take the Zeppelin to Undercity
.zoneskip Tirisfal Glades
.zoneskip Undercity
step << Mage
#completewith FlyHillsbrad1
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << Mage
.goto Undercity,82.79,15.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Hannah|r
>>|cRXP_BUY_Buy two or more|r |T134419:0|t[Rune of Teleportation] |cRXP_BUY_from him|r
.collect 17031,2 
.target Hannah Akeley
step << !Mage
#completewith FlyHillsbrad1
.goto Tirisfal Glades,61.80,65.06,20,0
.zone Undercity >>Enter Undercity
step
.goto Undercity,62.31,48.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Patrick|r
.turnin 2342 >> Turn in Reclaimed Treasures
.target Patrick Garrett
.isQuestComplete 2342
step << skip
.goto Undercity,53.77,54.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bel'dugur|r
.turnin 728 >> Turn in To the Undercity for Yagyin's Digest
.target Keeper Bel'dugur
step
.goto Undercity,73.20,32.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oran|r
.accept 2995 >>Accept Lines of Communication
.target Oran Snakewrithe
step
#completewith next
.goto Undercity,51.99,64.54,10,0
.goto Undercity,46.25,73.22,10,0
.goto Undercity,45.32,78.32,10,0
.goto Undercity,46.26,83.91,10,0
.goto Undercity,49.03,87.92,10,0
.goto Undercity,52.94,89.60,10 >>Enter the Royal Quarter
.group
step
.isOnQuest 521
.goto Undercity,57.65,93.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sharlindra|r
.turnin 521 >> Turn in The Crown of Will
.target Sharlindra
.group
step
#label FlyHillsbrad1
#completewith next
.goto Undercity,63.27,48.55
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Michael|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Michael Garrett
.zoneskip Hillsbrad Foothills
step << Mage
.goto Hillsbrad Foothills,62.76,19.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Shay|r
.home >>Set your hearthstone to Tarren Mill
.target Innkeeper Shay
.isQuestAvailable 7840
.bindlocation 272
.train 3567,3 
step
#label EnterHinterlands
#completewith next
.goto Hillsbrad Foothills,88.44,27.44,0
.goto Hillsbrad Foothills,88.44,27.44,80,0
.zone The Hinterlands >> Travel to Hillsbrad and enter The Hinterlands
step
#requires EnterHinterlands
#label VenomBottle
.goto The Hinterlands,23.00,57.73
>>Click one of the green |cRXP_PICK_Venom Bottles|r around the camp
.accept 2933 >> Accept Venom Bottles
step
.goto The Hinterlands,26.70,48.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gilveradin|r
.turnin 650 >>Turn in Ripple Recovery
.accept 77 >>Accept A Sticky Situation
.target Gilveradin Sunchaser
step
#label Tragan
.goto The Hinterlands,40.00,59.90
>>Swim to the bottom of the pond, then loot the |cRXP_PICK_Mushroom|r for a |cRXP_LOOT_Violet Tragan|r
.complete 2641,1 
step
#completewith next
.subzone 3317 >>Travel to Revantusk Village
step
#label ViHo
.goto The Hinterlands,77.52,80.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slagtree|r
.accept 7839 >>Accept Vilebranch Hooligans
.target Smith Slagtree
step
.goto The Hinterlands,78.80,78.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yayo'jin|r
.accept 7844 >>Accept Cannibalistic Cousins
.target Mystic Yayo'jin
step
#label JinthaAlor
.goto The Hinterlands,79.08,78.99
>>Click the |cRXP_PICK_Call to Arms!|r wanted poster by the hut
.accept 7861 >>Accept Wanted: Vile Priestess Hexx and Her Minions
.accept 7862 >>Accept Job Opening: Guard Captain of Revantusk Village
.group
step
.goto The Hinterlands,79.40,79.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Otho|r
.accept 7841 >>Accept Message to the Wildhammer
.target Otho Moji'ko
step
.goto The Hinterlands,79.10,79.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
.accept 7828 >>Accept Stalking the Stalkers
.accept 7829 >>Accept Hunt the Savages
.accept 7830 >>Accept Avenging the Fallen
.accept 7849 >>Accept Separation Anxiety
.target Huntsman Markhor
.group
step
.goto The Hinterlands,79.10,79.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
.accept 7828 >>Accept Stalking the Stalkers
.accept 7829 >>Accept Hunt the Savages
.accept 7830 >>Accept Avenging the Fallen
.target Huntsman Markhor
step
.goto The Hinterlands,78.20,81.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lard|r
.accept 7840 >>Accept Lard Lost His Lunch
.target Lard
step
#completewith next
.goto The Hinterlands,77.76,81.51,6,0
.goto The Hinterlands,77.64,81.92,6,0
.goto The Hinterlands,77.85,82.14,6,0
.goto The Hinterlands,78.09,81.74,4 >>Go upstairs
.group
step
.goto The Hinterlands,78.20,81.17
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torntusk|r upstairs
.accept 7845 >>Accept Kidnapped Elder Torntusk!
.accept 7850 >>Accept Dark Vessels
.target Primal Torntusk
.group
step
.goto The Hinterlands,80.40,81.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Katoom|r
.accept 7815 >>Accept Snapjaws, Mon!
.accept 7816 >>Accept Gammerita, Mon!
.target Katoom the Angler
step << Hunter
#completewith next
.goto The Hinterlands,79.10,79.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
.stable >> Stable your pet. You will tame a |cRXP_ENEMY_Saltwater Snapjaw|r shortly
.target Huntsman Markhor
step << Hunter
#loop
.goto The Hinterlands,80.00,58.80,0
.goto The Hinterlands,80.00,58.80,50,0
.goto The Hinterlands,77.20,61.80,50,0
.goto The Hinterlands,77.20,64.20,50,0
.goto The Hinterlands,74.80,68.60,50,0
.goto The Hinterlands,75.60,72.00,50,0
.goto The Hinterlands,78.20,69.20,50,0
.goto The Hinterlands,78.00,64.20,50,0
>>|cRXP_WARN_Cast|r |T132164:0|t[Tame Beast] |cRXP_WARN_on a |cRXP_ENEMY_Saltwater Snapjaw|r to tame it|r 
.train 17267 >>|cRXP_WARN_Attack mobs with it to learn|r |T132278:0|t[Bite (Rank 7)]
.link https://www.wow-petopia.com/classic/training.php >> |cRXP_WARN_Click here for more info about pet training|r
.mob Saltwater Snapjaw
step << Hunter
.goto The Hinterlands,79.10,79.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
.stable >> Abandon the |cRXP_ENEMY_Saltwater Snapjaw|r and retrieve your regular pet
.target Huntsman Markhor
.train 17267,3
.zoneskip The Hinterlands,1
step
#completewith Gammerita
>>Loot the |cRXP_PICK_Pupellyverbos Port Bottles|r along the shore
.complete 580,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Saltwater Snapjaws|r
.complete 7815,1 
.mob Saltwater Snapjaw
step
#label Gammerita
#loop
.goto The Hinterlands,78.83,76.26,0
.goto The Hinterlands,81.87,49.36,70,0
.goto The Hinterlands,79.86,60.32,70,0
.goto The Hinterlands,78.54,67.85,70,0
.goto The Hinterlands,79.14,71.45,70,0
.goto The Hinterlands,77.47,75.83,70,0
.goto The Hinterlands,78.83,76.26,70,0
>>Kill |cRXP_ENEMY_Gammerita|r. Loot her for |cRXP_LOOT_Katoom's Best Lure|r
>>|cRXP_WARN_She patrols the length of the coast. Kite her to the guards. If you can't re-leash her consistently, wait until she is close to the village|r
.complete 7816,1 
.unitscan Gammerita
step
.goto The Hinterlands,84.40,41.30
>>Click |cRXP_PICK_Lard's Picnic Basket|r. Kill the 3 |cRXP_ENEMY_Vilebranch Kidnappers|r that spawn. Loot one of them for |cRXP_LOOT_Lard's Lunch|r
>>|cRXP_WARN_The 3 |cRXP_ENEMY_Vilebranch Kidnappers|r all have|r |T135358:0|t[Execute]|cRXP_WARN_. Be extremely careful on this quest, try not to let your health dip near 20%|r
.complete 7840,1 
.unitscan Vilebranch Kidnapper
step
#completewith next
>>Loot the |cRXP_PICK_Pupellyverbos Port Bottles|r along the shore
.complete 580,1 
step
#loop
.goto The Hinterlands,80.00,58.80,0
.goto The Hinterlands,80.00,58.80,50,0
.goto The Hinterlands,77.20,61.80,50,0
.goto The Hinterlands,77.20,64.20,50,0
.goto The Hinterlands,74.80,68.60,50,0
.goto The Hinterlands,75.60,72.00,50,0
.goto The Hinterlands,78.20,69.20,50,0
.goto The Hinterlands,78.00,64.20,50,0
>>Kill |cRXP_ENEMY_Saltwater Snapjaws|r
.complete 7815,1 
.mob Saltwater Snapjaw
step
#loop
.goto The Hinterlands,78.83,76.26,0
.goto The Hinterlands,79.86,60.32,80,0
.goto The Hinterlands,78.54,67.85,80,0
.goto The Hinterlands,79.14,71.45,80,0
.goto The Hinterlands,77.47,75.83,80,0
.goto The Hinterlands,78.83,76.26,80,0
>>Loot the |cRXP_PICK_Pupellyverbos Port Bottles|r along the shore
.complete 580,1 
step
#completewith KeyRecovery
.goto The Hinterlands,66.96,63.75
.subzone 354 >>Travel to Jintha'alor
.group
step
#completewith KeyRecovery
>>Loot the |cRXP_LOOT_Vessels of Tainted Blood|r on the ground
>>|cRXP_WARN_Don't worry about focusing on this; you can finish it in later steps|r
.complete 7850,1 
.group 2
step
#completewith KeyRecovery
>>Kill |cRXP_ENEMY_Vilebranch Trolls|r
>>|cRXP_WARN_Don't worry about focusing on this; you can finish it in later steps|r
.complete 7862,4 
.mob +Vilebranch Soul Eater
.complete 7862,1 
.mob +Vilebranch Berserker
.complete 7862,3 
.mob +Vilebranch Blood Drinker
.complete 7862,2 
.mob +Vilebranch Shadow Hunter
.group 2
step
.goto The Hinterlands,62.1,75.3
>>Loot the |cRXP_PICK_Pile of Bones|r at the center of the pit for |cRXP_LOOT_Huntsman Malkhor's Bones|r
.complete 7849,2 
.group 2
step
.goto The Hinterlands,58.6,64.9
>>Loot the |cRXP_PICK_Pile of Skulls|r for |cRXP_LOOT_Huntsman Malkhor's Skull|r
.complete 7849,1 
.group 2
step
.goto The Hinterlands,59.6,77.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Torntusk|r
.turnin 7845 >>Turn in Kidnapped Elder Torntusk!
.accept 7846 >>Accept Recover the Key!
.target Elder Torntusk
.group
step
#label KeyRecovery
#optional
.goto The Hinterlands,59.6,77.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Torntusk|r
.accept 7846 >>Accept Recover the Key!
.target Elder Torntusk
.isQuestTurnedIn 7845
.group
step
#completewith Hitahya
.goto The Hinterlands,57.26,85.98,20 >>|cRXP_WARN_You can get to the upper level (without fighting through many guards) by doing a jump skip|r
.link https://www.youtube.com/watch?v=UPiNtMem9tM >> Click here for a video guide
.group
step
#completewith Hitahya
>>Kill |cRXP_ENEMY_Vilebranch Aman'zasi Guards|r
.complete 7861,2 
.mob Vilebranch Aman'zasi Guard
.group 2
step
.goto The Hinterlands,59.3,78.2
>>Kill |cRXP_ENEMY_Vile Priestess Hex|r
>>|cRXP_WARN_Be extremely cautious of her Hex ability, which she can potentially spam|r
.complete 7861,1 
.unitscan Vile Priestess Hexx
.group 2
step
#completewith next
>>Loot the |cRXP_LOOT_Ancient Egg|r
.complete 4787,1 
.isQuestTurnedIn 3527
.group 2
step
#label Hitahya
.goto The Hinterlands,57.8,86.8
>>Kill |cRXP_ENEMY_Hitah'ya the Keeper|r. Loot her for her |cRXP_LOOT_Key|r
.complete 7846,1 
.unitscan Hitah'ya the Keeper
.group 2
step
.goto The Hinterlands,57.60,86.79
>>Loot the |cRXP_LOOT_Ancient Egg|r
.complete 4787,1 
.isQuestTurnedIn 3527
.group 2
step
.goto The Hinterlands,59.6,77.9
>>Kill |cRXP_ENEMY_Vilebranch Aman'zasi Guards|r
.complete 7861,2 
.mob Vilebranch Aman'zasi Guard
.group 2
step
.goto The Hinterlands,59.6,77.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Torntusk|r
.turnin 7846 >>Turn in Recover the Key!
.accept 7847 >>Accept Return to Primal Torntusk
.target Elder Torntusk
.isQuestComplete 7846
.group
step
#label ReKey
.goto The Hinterlands,59.6,77.9
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Elder Torntusk|r
.accept 7847 >>Accept Return to Primal Torntusk
.target Elder Torntusk
.isQuestTurnedIn 7846
.group
step
#completewith next
>>Loot the |cRXP_LOOT_Vessels of Tainted Blood|r on the ground
.complete 7850,1 
.group 2
step
#label Vilebranchs
.goto The Hinterlands,60.6,65.4
>>Finish killing |cRXP_ENEMY_Vilebranch Trolls|r
>>|cRXP_ENEMY_Soul Eaters|r |cRXP_WARN_are on the 2nd level.|r |cRXP_ENEMY_Berserkers|r |cRXP_WARN_are on the 3rd level.|r |cRXP_ENEMY_Blood Drinkers|r |cRXP_WARN_and|r |cRXP_ENEMY_Shadow Hunters|r |cRXP_WARN_are on the 4th and 5th levels|r
.complete 7862,4 
.mob +Vilebranch Soul Eater
.complete 7862,1 
.mob +Vilebranch Berserker
.complete 7862,3 
.mob +Vilebranch Blood Drinker
.complete 7862,2 
.mob +Vilebranch Shadow Hunter
.group 2
step
.goto The Hinterlands,67.9,73.4
>>Loot the |cRXP_LOOT_Vessels of Tainted Blood|r on the ground
.complete 7850,1 
.group 2
step
#completewith Bucket
>>Kill |cRXP_ENEMY_Silvermane Stalkers|r
.complete 7828,1 
.mob Silvermane Stalker
step
#completewith Bucket
>>Kill |cRXP_ENEMY_Savage Owlbeasts|r
.use 9618 >>Kill |cRXP_ENEMY_Savage Owlbeasts|r and use the |T133841:0|t[Wildkin Muisek Vessel] near their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 7829,1 
.complete 3123,1 
.mob Savage Owlbeast
step
#completewith Bucket
>>Kill |cRXP_ENEMY_Vilebranch Scalpers|r and |cRXP_ENEMY_Vilebranch Soothsayers|r
>>|cRXP_ENEMY_Vilebranch Scalpers|r |cRXP_WARN_have Execute. Be extremely careful on this quest, try not to let your health dip near 20%|r
.complete 7844,1 
.mob +Vilebranch Scalper
.complete 7844,2 
.mob +Vilebranch Soothsayer
step
#label Bucket
#loop
.goto The Hinterlands,72.53,52.92,0
.goto The Hinterlands,71.14,48.64,0
.goto The Hinterlands,66.09,44.71,0
.goto The Hinterlands,57.57,42.50,0
.goto The Hinterlands,53.18,39.20,0
.goto The Hinterlands,72.53,52.92,25,0
.goto The Hinterlands,71.14,48.64,25,0
.goto The Hinterlands,66.09,44.71,25,0
.goto The Hinterlands,57.57,42.50,25,0
.goto The Hinterlands,53.18,39.20,25,0
>>Loot |cRXP_PICK_Slagtree's Lost Tools|r (a small bucket)
>>|cRXP_WARN_The bucket can spawn in 5 locations, they are marked on your map|r
.complete 7839,1 
step
#completewith next
.goto The Hinterlands,58.7,41.9,50,0
.subzone 351 >>Enter the Skulk Rock cave
step
#loop
.goto The Hinterlands,56.53,43.94,0
.goto The Hinterlands,57.28,43.86,30,0
.goto The Hinterlands,59.77,42.41,30,0
.goto The Hinterlands,56.53,43.94,30,0
.goto The Hinterlands,58.36,42.63,30,0
.goto The Hinterlands,57.56,39.83,30,0
>>Loot the |cRXP_PICK_Horde Supply Crates|r for their |cRXP_LOOT_Hinterlands Honey Ripple|r
.complete 77,1 
step
#optional
#completewith QuelDanilLodge
>>Kill |cRXP_ENEMY_Savage Owlbeasts|r
.use 9618 >>Kill |cRXP_ENEMY_Savage Owlbeasts|r and use the |T133841:0|t[Wildkin Muisek Vessel] near their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 7829,1 
.complete 3123,1 
.mob Savage Owlbeast
step
#completewith next
>>Kill |cRXP_ENEMY_Silvermane Howlers|r
.complete 7828,2 
.mob Silvermane Howler
step
#label QuelDanilLodge
.goto The Hinterlands,31.06,47.84,50,0
.subzone 350 >>Travel west to Quel'Danil Lodge
.isOnQuest 7841
step
#requires QuelDanilLodge
#completewith Escort
>>Kill |cRXP_ENEMY_Highvale High Elves|r
>>|cRXP_WARN_Be careful with your health!|r |cRXP_ENEMY_Highvale Rangers|r |cRXP_WARN_can Faerie Fire, making escape more difficult|r << Rogue
.complete 7841,1 
.mob +Highvale Scout
.complete 7841,2 
.mob +Highvale Outrunner
.complete 7841,3 
.mob +Highvale Ranger
.complete 7841,4 
.mob +Highvale Marksman
step
.goto The Hinterlands,29.60,48.70
>>Click the |cRXP_PICK_Highvale Notes|r on the ground
.complete 2995,2 
step
.goto The Hinterlands,28.60,46.10
>>Click the |cRXP_PICK_Highvale Report|r on the table
.complete 2995,3 
step
.goto The Hinterlands,32.00,46.90
>>Click the |cRXP_PICK_Highvale Records|r on the ground
.complete 2995,1 
step
.goto The Hinterlands,30.73,46.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rin'ji|r
>>|cRXP_WARN_This will start an escort!|r
.accept 2742,1 >>Accept Rin'ji is Trapped!
.target Rin'ji
step
#label Escort
.goto The Hinterlands,34.98,56.92
>>Escort |cRXP_FRIENDLY_Rin'ji|r
.complete 2742,1 
step
#loop
.goto The Hinterlands,33.00,51.60,0
.goto The Hinterlands,33.00,51.60,50,0
.goto The Hinterlands,30.40,51.00,50,0
.goto The Hinterlands,29.60,48.60,50,0
.goto The Hinterlands,28.60,46.60,50,0
.goto The Hinterlands,29.60,48.60,50,0
.goto The Hinterlands,32.20,47.60,50,0
.goto The Hinterlands,32.60,43.60,50,0
.goto The Hinterlands,33.80,44.80,50,0
.goto The Hinterlands,33.80,48.60,50,0
>>Finish killing |cRXP_ENEMY_Highvale High Elves|r
>>|cRXP_WARN_Be careful with your health;|r |cRXP_ENEMY_Highvale Rangers|r |cRXP_WARN_can Faerie Fire, making escape more difficult|r << Rogue
.complete 7841,1 
.mob +Highvale Scout
.complete 7841,2 
.mob +Highvale Outrunner
.complete 7841,3 
.mob +Highvale Ranger
.complete 7841,4 
.mob +Highvale Marksman
step
.goto The Hinterlands,33.751,75.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Atal'ai Exile|r
.accept 1446 >>Accept Jammal'an the Prophet
.target Atal'ai Exile
.dungeon ST
step
#loop
.goto The Hinterlands,38.80,50.80,0
.goto The Hinterlands,51.00,41.60,60,0
.goto The Hinterlands,51.40,47.80,60,0
.goto The Hinterlands,51.20,57.20,60,0
.goto The Hinterlands,50.60,63.60,60,0
.goto The Hinterlands,49.60,59.80,60,0
.goto The Hinterlands,45.60,58.80,60,0
.goto The Hinterlands,43.20,61.80,60,0
.goto The Hinterlands,39.20,63.20,60,0
.goto The Hinterlands,36.80,58.60,60,0
.goto The Hinterlands,39.40,55.80,60,0
.goto The Hinterlands,38.80,50.80,60,0
.goto The Hinterlands,39.40,46.20,60,0
.goto The Hinterlands,43.40,46.40,60,0
.goto The Hinterlands,38.80,50.80,60,0
>>Finish killing |cRXP_ENEMY_Silvermane Howlers|r
.complete 7828,2 
.mob Silvermane Howler
step
#loop
.goto The Hinterlands,45.60,63.40,0
.goto The Hinterlands,45.60,63.40,50,0
.goto The Hinterlands,44.40,67.00,50,0
.goto The Hinterlands,46.40,68.80,50,0
.goto The Hinterlands,49.60,65.20,50,0
.goto The Hinterlands,50.60,65.80,50,0
.goto The Hinterlands,50.60,62.40,50,0
>>Finish killing |cRXP_ENEMY_Vilebranch Scalpers|r and |cRXP_ENEMY_Vilebranch Soothsayers|r around the base of the temple
>>|cRXP_ENEMY_Vilebranch Scalpers|r |cRXP_WARN_have Execute. Be extremely careful on this quest, try not to let your health dip near 20%|r
.complete 7844,1 
.mob +Vilebranch Scalper
.complete 7844,2 
.mob +Vilebranch Soothsayer
step
#completewith SkylordPlume
>>Kill |cRXP_ENEMY_Silvermane Stalkers|r
.complete 7828,1 
.mob Silvermane Stalker
step
#optional
#completewith next
>>Kill |cRXP_ENEMY_Savage Owlbeasts|r
.use 9618 >>Kill |cRXP_ENEMY_Savage Owlbeasts|r and use the |T133841:0|t[Wildkin Muisek Vessel] near their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 7829,1 
.complete 3123,1 
.mob Savage Owlbeast
step
#label SkylordPlume
#loop
.goto The Hinterlands,50.60,53.00,0
.goto The Hinterlands,53.00,56.60,60,0
.goto The Hinterlands,54.00,54.20,60,0
.goto The Hinterlands,56.00,51.60,60,0
.goto The Hinterlands,58.60,53.00,60,0
.goto The Hinterlands,61.00,54.80,60,0
.goto The Hinterlands,64.20,56.60,60,0
.goto The Hinterlands,63.80,53.60,60,0
.goto The Hinterlands,64.60,48.60,60,0
.goto The Hinterlands,66.60,42.60,60,0
.goto The Hinterlands,61.40,42.40,60,0
.goto The Hinterlands,60.60,48.20,60,0
.goto The Hinterlands,59.80,52.20,60,0
.goto The Hinterlands,57.00,50.20,60,0
.goto The Hinterlands,54.60,47.00,60,0
.goto The Hinterlands,51.00,44.00,60,0
.goto The Hinterlands,50.60,53.00,60,0
>>Find and kill a |cRXP_ENEMY_Razorbeak Skylord|r. Loot it for its |cRXP_LOOT_Plume|r
.complete 7830,1 
.unitscan Razorbeak Skylord
step
#optional
#completewith Stalkers
>>Kill |cRXP_ENEMY_Savage Owlbeasts|r
.use 9618 >>Kill |cRXP_ENEMY_Savage Owlbeasts|r and use the |T133841:0|t[Wildkin Muisek Vessel] near their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 7829,1 
.complete 3123,1 
.mob Savage Owlbeast
step
#label Stalkers
#loop
.goto The Hinterlands,70.60,63.40,0
.goto The Hinterlands,70.60,63.40,60,0
.goto The Hinterlands,70.60,57.40,60,0
.goto The Hinterlands,73.20,52.60,60,0
.goto The Hinterlands,69.00,50.60,60,0
.goto The Hinterlands,69.00,45.60,60,0
.goto The Hinterlands,66.60,48.00,60,0
.goto The Hinterlands,63.20,47.80,60,0
.goto The Hinterlands,61.60,41.80,60,0
.goto The Hinterlands,58.60,46.80,60,0
.goto The Hinterlands,56.20,46.80,60,0
.goto The Hinterlands,54.40,44.00,60,0
.goto The Hinterlands,53.60,49.20,60,0
.goto The Hinterlands,53.20,55.60,60,0
.goto The Hinterlands,55.60,51.40,60,0
.goto The Hinterlands,58.60,53.20,60,0
.goto The Hinterlands,60.80,55.60,60,0
.goto The Hinterlands,64.00,54.60,60,0
.goto The Hinterlands,66.60,57.20,60,0
.goto The Hinterlands,68.40,62.60,60,0
>>Finish killing |cRXP_ENEMY_Silvermane Stalkers|r
.complete 7828,1 
.mob Silvermane Stalker
step
#loop
.goto The Hinterlands,65.71,57.44,0
.goto The Hinterlands,65.71,57.44,60,0
.goto The Hinterlands,63.13,48.55,60,0
.goto The Hinterlands,61.16,41.89,60,0
.goto The Hinterlands,54.55,51.54,60,0
.goto The Hinterlands,51.88,45.87,60,0
.goto The Hinterlands,55.35,43.69,60,0
.goto The Hinterlands,64.26,47.92,60,0
.goto The Hinterlands,68.40,62.60,60,0
>>Kill |cRXP_ENEMY_Savage Owlbeasts|r
.use 9618 >>Kill |cRXP_ENEMY_Savage Owlbeasts|r and use the |T133841:0|t[Wildkin Muisek Vessel] near their corpses
>>|cRXP_WARN_This item has a cooldown and only works on one corpse at a time, even if they're stacked|r
.complete 7829,1 
.complete 3123,1 
.mob Savage Owlbeast
step
.use 8704 >>If you've found the |T132836:0|t[|cRXP_FRIENDLY_OOX-17/TN Distress Beacon|r], use it to accept its quest
>>|cRXP_WARN_Skip this step if you did not find it|r
.accept 485 >>Accept Find OOX-17/TN!
.itemcount 8704,1
step
.goto The Hinterlands,49.30,37.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r
.turnin 485 >>Turn in Find OOX-09/HL!
.target Homing Robot OOX-09/HL
.isOnQuest 485
step
.goto The Hinterlands,49.35,37.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to start the escort
.accept 836,1 >>Accept Rescue OOX-09/HL!
.target Homing Robot OOX-09/HL
.isQuestTurnedIn 485
step
.goto The Hinterlands,79.47,61.21
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to the coast
>>|cRXP_WARN_A pack of 3 level 46|r |cRXP_ENEMY_Marauding Owlbeasts|r |cRXP_WARN_will spawn south of Skulk Rock, on the road. They enrage at low HP, so try to kill one at a time|r
>>|cRXP_WARN_A pack of 3 level 47|r |cRXP_ENEMY_Vilebranch Ambushers|r |cRXP_WARN_will spawn in the woods north of Jintha'Alor. They execute when you're below 20% health. Use long CC if you can, and have the chicken tank one or two of them until it's around half HP|r
.complete 836,1 
.target Homing Robot OOX-09/HL
.mob Marauding Owlbeast
.unitscan Vilebranch Ambusher
.isQuestTurnedIn 485
step
.goto The Hinterlands,86.30,59.00
>>Swim to the island to the far east, then click |cRXP_PICK_Rinji's Secret|r
.turnin 2742 >>Turn in Rin'ji is Trapped!
.accept 2782 >>Accept Rin'ji's Secret
step
#completewith next
.goto The Hinterlands,77.28,78.64,30,0
.subzone 3317 >>Travel to Revantusk Village
step
.goto The Hinterlands,77.20,80.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Slagtree|r
.turnin 7839 >>Turn in Vilebranch Hooligans
.target Smith Slagtree
step
.goto The Hinterlands,78.80,78.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yayo'jin|r
.turnin 7844 >>Turn in Cannibalistic Cousins
.target Mystic Yayo'jin
step
.goto The Hinterlands,79.30,79.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Otho|r
.turnin 7841 >>Turn in Message to the Wildhammer
.target Otho Moji'ko
step
.goto The Hinterlands,79.30,79.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Otho|r
.accept 7842 >>Accept Another Message to the Wildhammer
.turnin 7842 >>Turn in Another Message to the Wildhammer
.target Otho Moji'ko
.itemcount 4589,10
step
.goto The Hinterlands,79.10,79.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
.turnin 7828 >>Turn in Stalking the Stalkers
.turnin 7829 >>Turn in Hunt the Savages
.turnin 7830 >>Turn in Avenging the Fallen
.turnin 7849 >>Turn in Separation Anxiety
.target Huntsman Markhor
.isQuestComplete 7849
.group
step
.goto The Hinterlands,79.10,79.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Markhor|r
.turnin 7828 >>Turn in Stalking the Stalkers
.turnin 7829 >>Turn in Hunt the Savages
.turnin 7830 >>Turn in Avenging the Fallen
.target Huntsman Markhor
step
.goto The Hinterlands,78.20,81.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lard|r
.turnin 7840 >>Turn in Lard Lost His Lunch
.target Lard
step
#completewith next
.goto The Hinterlands,77.76,81.51,6,0
.goto The Hinterlands,77.64,81.92,6,0
.goto The Hinterlands,77.85,82.14,6,0
.goto The Hinterlands,78.09,81.74,4 >>Go upstairs
.group
step
.goto The Hinterlands,78.20,81.18
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Primal Torntusk|r
.turnin 7862 >>Turn in Job Opening: Guard Captain of Revantusk Village
.turnin 7861 >>Turn in Wanted: Vile Priestess Hexx and Her Minions
.turnin 7850 >>Turn in Dark Vessels
.turnin 7847 >>Turn in Return to Primal Torntusk
.target Primal Torntusk
.group
step
.goto The Hinterlands,80.30,81.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Katoom|r
.turnin 7815 >>Turn in Snapjaws, Mon!
.turnin 7816 >>Turn in Gammerita, Mon!
.target Katoom the Angler
step
#completewith TrainRuneclothBandage
.goto The Hinterlands,81.70,81.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorkas|r
>>|cRXP_WARN_If you do not have the Hammerfall flight path, fly to Tarren Mill and run there instead|r
.fly Hammerfall >> Fly to Hammerfall
.target Gorkas
.skill firstaid,<260,1
.zoneskip Arathi Highlands
step
#label TrainRuneclothBandage
.goto Arathi Highlands,73.41,36.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doctor Gregory Victor|r
.train 18629 >> Train Runecloth Bandage
.target Doctor Gregory Victor
.skill firstaid,<260,1
step
#completewith VenomBottleTurnin
.goto Arathi Highlands,73.10,32.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urda|r
.fly Tarren Mill >>Fly to Tarren Mill
.target Urda
.zoneskip Arathi Highlands,1
step
#completewith VenomBottleTurnin
.goto The Hinterlands,81.70,81.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorkas|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Gorkas
.zoneskip The Hinterlands,1
step
#label VenomBottleTurnin
.goto Hillsbrad Foothills,61.53,19.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydon|r
.turnin 2933 >> Turn in Venom Bottles
.accept 2934 >>Accept Undamaged Venom Sac
.target Apothecary Lydon
step
#completewith StickyTurnin
.goto Hillsbrad Foothills,88.44,27.44,0
.goto Hillsbrad Foothills,88.44,27.44,80,0
.zone The Hinterlands >> Travel to The Hinterlands
step
#label StickyTurnin
.goto The Hinterlands,26.61,48.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gilveradin|r
.turnin 77 >>Turn in A Sticky Situation
.accept 81 >>Accept Ripple Delivery
.target Gilveradin Sunchaser
step
#completewith next
.goto The Hinterlands,35.9,63.9,40,0
.subzone 353 >>Travel southeast to Shadra'Alor
step
#loop
.goto The Hinterlands,33.19,69.66,0
.goto The Hinterlands,36.28,68.43,60,0
.goto The Hinterlands,34.16,67.00,60,0
.goto The Hinterlands,33.19,69.66,60,0
.goto The Hinterlands,30.66,69.71,60,0
.goto The Hinterlands,32.08,73.36,60,0
.goto The Hinterlands,35.48,74.42,60,0
.goto The Hinterlands,35.32,70.90,60,0
.goto The Hinterlands,35.79,64.35,60,0
.goto The Hinterlands,33.19,69.66,60,0
>>Kill |cRXP_ENEMY_Witherbark Broodguards|r. Loot them for an |cRXP_LOOT_Undamaged Venom Sac|r
>>|cRXP_WARN_The|r |cRXP_LOOT_Undamaged Venom Sac|r |cRXP_WARN_has a 30 minute duration, so turn it in ASAP|r
.complete 2934,1 
.mob Witherbark Broodguard
step
.goto The Hinterlands,49.30,37.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r
.accept 485 >>Accept Find OOX-09/HL!
.turnin 485 >>Turn in Find OOX-09/HL!
.target Homing Robot OOX-09/HL
.itemcount 8704,1 
step
.goto The Hinterlands,49.35,37.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to start the escort
.accept 836,1 >>Accept Rescue OOX-09/HL!
.target Homing Robot OOX-09/HL
.isQuestTurnedIn 485
step
.goto The Hinterlands,79.47,61.21
>>Escort |cRXP_FRIENDLY_Homing Robot OOX-09/HL|r to the coast
>>|cRXP_WARN_A pack of 3 level 46|r |cRXP_ENEMY_Marauding Owlbeasts|r |cRXP_WARN_will spawn south of Skulk Rock, on the road. They enrage at low HP, so try to kill one at a time|r
>>|cRXP_WARN_A pack of 3 level 47|r |cRXP_ENEMY_Vilebranch Ambushers|r |cRXP_WARN_will spawn in the woods north of Jintha'Alor. They execute when you're below 20% health. Use long CC if you can, and have the chicken tank one or two of them until it's around half HP|r
.complete 836,1 
.target Homing Robot OOX-09/HL
.mob Marauding Owlbeast
.unitscan Vilebranch Ambusher
.isQuestTurnedIn 485
step << !Mage
.hs >> Hearth to Tarren Mill
.cooldown item,6948,>0,1
.bindlocation 272,1
.subzoneskip 272
step
#optional << Mage
#completewith next
.goto The Hinterlands,77.28,78.64,30,0
.subzone 3317 >>Travel to Revantusk Village
.subzoneskip 353
step
#optional << Mage
#label FlyTM2
#completewith next
.goto The Hinterlands,81.70,81.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorkas|r
>>|cRXP_WARN_You could run there instead if you are closer to Tarren Mill than Revantusk Village|r
.fly Tarren Mill >> Fly to Tarren Mill
.target Gorkas
.zoneskip Hillsbrad Foothills
.subzoneskip 353
step
.goto Hillsbrad Foothills,61.53,19.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lydon|r
>>|cRXP_WARN_The|r |cRXP_LOOT_Undamaged Venom Sac|r |cRXP_WARN_has a 30 minute duration, so turn it in ASAP|r
.turnin 2934 >>Turn in Undamaged Venom Sac
.target Apothecary Lydon
step << !Mage
.goto Hillsbrad Foothills,60.14,18.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zarise|r
.fly Undercity>> Fly to Undercity
.target Zarise
.zoneskip Undercity
step << Mage
#completewith next
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << Mage
.goto Undercity,82.79,15.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannah|r
>>|cRXP_BUY_Buy at least four|r |cRXP_BUY_Rune of Teleportation|r
.collect 17031,4 
.target Hannah Akeley
step
.goto Undercity,73.50,32.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oran|r
.turnin 2995 >>Turn in Lines of Communication
.turnin 2782 >>Turn in Rin'ji's Secret
.accept 8273 >>Accept Oran's Gratitude
.turnin 8273 >>Turn in Oran's Gratitude
.target Oran Snakewrithe
step
#completewith next
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Cuely|r
step
.goto Undercity,48.50,71.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cuely|r
.accept 3568 >>Accept Seeping Corruption
.target Chemist Cuely
step << Druid
#completewith DruidTraining7
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9884 >> Train your class spells
.target Loganaar
.xp <50,1
.xp >52,1
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9894 >> Train your class spells
.target Loganaar
.xp <52,1
.xp >54,1
step << Druid
#label DruidTraining7
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9830 >> Train your class spells
.target Loganaar
.xp <54,1
step << !Mage
#completewith Orgvisit2
.hs >>Hearth to Orgrimmar
.use 6948
.bindlocation 1637,1
.zoneskip Orgrimmar
step << Mage
#completewith Orgvisit2
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step << !Mage
#ah
.goto Orgrimmar,55.59,62.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thathung|r
>>|cRXP_BUY_Buy one|r |T133021:0|t[Mithril Casing] |cRXP_BUY_from the Auction House|r 
.target Auctioneer Thathung
.collect 10561,1,4244,1 
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10180 >> Train your class spells
.target Pephredo
.xp <50,1
.xp >52,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10186 >> Train your class spells
.target Pephredo
.xp <52,1
.xp >54,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10199 >> Train your class spells
.target Pephredo
.xp <54,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10893 >> Train your class spells
.target Ur'kyo
.xp <50,1
.xp >52,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10946 >> Train your class spells
.target Ur'kyo
.xp <52,1
.xp >54,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10900 >> Train your class spells
.target Ur'kyo
.xp <54,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 15207 >> Train your class spells
.target Kardris Dreamseeker
.xp <50,1
.xp >52,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10448 >> Train your class spells
.target Kardris Dreamseeker
.xp <52,1
.xp >54,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 16316 >> Train your class spells
.target Kardris Dreamseeker
.xp <54,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 19942 >> Train your class spells
.target Master Pyreanor
.xp <50,1
.xp >52,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 19838 >> Train your class spells
.target Master Pyreanor
.xp <52,1
.xp >54,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 10308 >> Train your class spells
.target Master Pyreanor
.xp <54,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 8643 >> Train your class spells
.target Ormok
.xp <50,1
.xp >52,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11342 >> Train your class spells
.target Ormok
.xp <52,1
.xp >54,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11294 >> Train your class spells
.target Ormok
.xp <54,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11667 >> Train your class spells
.target Mirket
.xp <50,1
.xp >52,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11660 >> Train your class spells
.target Mirket
.xp <52,1
.xp >54,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11672 >> Train your class spells
.target Mirket
.xp <54,1
step
.goto Orgrimmar,56.40,46.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zilzibin|r
>>|cRXP_WARN_He is located on the upper level in the Drag|r
.accept 4494 >>Accept March of the Silithid
.target Zilzibin Drumlore
step
.goto Orgrimmar,59.40,36.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dran|r
.turnin 81 >>Turn in Ripple Delivery
.target Dran Droffers
.isOnQuest 81
step
.goto Orgrimmar,55.60,34.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jes'rimon|r
>>|cRXP_WARN_He is located at the top of the building|r
.accept 4300 >>Accept in Bone-Bladed Weapons
.target Jes'rimon
step
.goto Orgrimmar,75.00,34.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.accept 3504 >>Accept Betrayed
.target Belgrom Rockmaul
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11609 >> Train your class spells
.target Grezz Ragefist
.xp <50,1
.xp >52,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11551 >> Train your class spells
.target Grezz Ragefist
.xp <52,1
.xp >54,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11556 >> Train your class spells
.target Grezz Ragefist
.xp <54,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 13554 >> Train your class spells
.target Ormak Grimshot
.xp <50,1
.xp >52,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14286 >> Train your class spells
.target Ormak Grimshot
.xp <52,1
.xp >54,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14290 >> Train your class spells
.target Ormak Grimshot
.xp <54,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24631 >> Train your pet spells
.target Xao'tsu
.xp <54,1
step << Hunter
.goto Orgrimmar,48.13,80.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trak'gen|r
>>|cRXP_BUY_Buy|r |T135661:0|t[Jagged Arrows] |cRXP_BUY_from him|r
.collect 11285,2600,3504,1 
.target Trak'gen
step << Mage
#ah
.goto Orgrimmar,55.59,62.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thathung|r
>>|cRXP_BUY_Buy one|r |T133021:0|t[Mithril Casing] |cRXP_BUY_from the Auction House|r 
.target Auctioneer Thathung
.collect 10561,1,4244,1 
step
#optional
#label Orgvisit2
.goto Orgrimmar,45.13,63.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Ratchet >> Fly to Ratchet
.zoneskip The Barrens
.target Doras
step
.goto The Barrens,62.50,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv|r
.accept 4502 >>Accept Volcanic Activity
.target Liv Rizzlefix
step
.goto The Barrens,62.50,38.60
>>Loot |cRXP_PICK_Marvon's Chest|r outside of the building for the |cRXP_LOOT_Stone Circle|r
.complete 3444,1 
step
.goto The Barrens,62.05,39.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Wiley|r
.home >>Set your Hearthstone to Ratchet
.target Innkeeper Wiley
.bindlocation 392
.subzoneskip 392,1
step
.goto The Barrens,62.639,37.421,-1
.goto The Barrens,62.680,37.395,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fuzruckle|r or |cRXP_FRIENDLY_Zikkel|r
.bankdeposit 10695,10687,10688,10689,10690,8526,9618,9594,10556,10643 >>Put the following on the bank:
>>|T132594:0|t[Box of Empty Vials] |cRXP_WARN_(or the|r |T132793:0|t[Empty Vials] |cRXP_WARN_if you openend the box)|r
>>|T134527:0|t[Violet Tragan] 
>>|T133841:0|t[Wildkin Muisek Vessel] 
>>|T135992:0|t[Wildkin Muisek] 
>>|T134430:0|t[Stone Circle] 
>>|T133469:0|t[Sealed Letter to Ag'tor] 
.target Fuzruckle
.target Zikkel
step
.goto The Barrens,62.639,37.421,-1
.goto The Barrens,62.680,37.395,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fuzruckle|r or |cRXP_FRIENDLY_Zikkel|r
.bankwithdraw 4306,15 >> Withdraw 15 |T132905:0|t[Silk Cloth] from your bank
.target Fuzruckle
.target Zikkel
step
#label Boat2STV2
.goto The Barrens,63.74,38.66
.zone Stranglethorn Vale >>Take the boat to Stranglethorn Vale
.zoneskip Stranglethorn Vale
step
.goto Stranglethorn Vale,28.40,76.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe|r
.turnin 648 >>Turn in Rescue OOX-17/TN!
.target Oglethorpe Obnoticus
.isQuestComplete 648
step
.goto Stranglethorn Vale,28.40,76.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe|r
.turnin 836 >>Turn in Rescue OOX-09/HL!
.target Oglethorpe Obnoticus
.isQuestComplete 836
step
.goto Stranglethorn Vale,28.40,76.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe|r
.turnin 2767 >>Turn in Rescue OOX-22/FE!
.target Oglethorpe Obnoticus
.isQuestComplete 2767
step
.goto Stranglethorn Vale,28.40,76.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Oglethorpe|r
.accept 3721 >>Accept An OOX of Your Own
.turnin 3721 >>Turn in An OOX of Your Own
.target Oglethorpe Obnoticus
.isQuestTurnedIn 648
.isQuestTurnedIn 836
.isQuestTurnedIn 2767
step
.goto Stranglethorn Vale,27.70,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_"Sea Wolf"|r
.turnin 2874 >>Turn in Deliver to MacKinley
.target "Sea Wolf" MacKinley
step
.goto Stranglethorn Vale,27.10,77.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Whiskey Slim|r
.turnin 580 >>Turn in Whiskey Slim's Lost Grog
.target Whiskey Slim
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 51-51 Blasted lands (optional)
#next 51-52 Searing Gorge/Burning Steppes
step
#optional
.maxlevel 51,BlastedSkip
step
#completewith EnterDuskW
.goto Stranglethorn Vale,26.87,77.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Grom'gol >> Fly to Grom'gol Base Camp
.target Gringer
.subzoneskip 35,1
.zoneskip Duskwood
.zoneskip Swamp of Sorrows
.zoneskip Blasted Lands
step
#label EnterDuskW
.goto Stranglethorn Vale,39.30,6.49,60,0
.goto Stranglethorn Vale,40.63,3.12,50 >> Travel to Duskwood
.zoneskip Duskwood
.zoneskip Swamp of Sorrows
.zoneskip Blasted Lands
step
#completewith next
.goto Duskwood,74.06,56.49,70,0
.goto Duskwood,80.46,54.47,70,0
.goto Duskwood,82.11,46.62,70,0
+|cRXP_WARN_Be careful of the |cRXP_WARN_Darkshire Guards|r! Don't mindlessly follow the road|r
>>|cRXP_WARN_Follow the waypoint arrow for safety|r
step
#completewith next
.goto Duskwood,88.47,41.00,50 >> Travel to Deadwind Pass
.zoneskip Deadwind Pass
step
.goto Deadwind Pass,48.02,34.60,60,0
.goto Deadwind Pass,58.43,41.51,50,0
.zone Swamp of Sorrows >> Travel to Swamp of Sorrows
.zoneskip Swamp of Sorrows
.zoneskip Blasted Lands
step
#completewith StonardPots2
.subzone 75 >>Travel to Stonard
step << Hunter
.goto Swamp of Sorrows,47.27,53.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogrom|r
.train 13554 >> Train your class spells
.target Ogrom
.xp <50,1
.xp >52,1
step << Hunter
#optional
.goto Swamp of Sorrows,47.27,53.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ogrom|r
.train 13543 >> Train your class spells
.target Ogrom
.xp <52,1
step << Warlock
.goto Swamp of Sorrows,48.64,55.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kartosh|r
.train 17925 >> Train your class spells
.target Kartosh
.xp <50,1
.xp >52,1
step << Warlock
#optional
.goto Swamp of Sorrows,48.64,55.64
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kartosh|r
.train 11675 >> Train your class spells
.target Kartosh
.xp <52,1
step << Warlock
.goto Swamp of Sorrows,48.59,55.27
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greshka|r
.vendor >>Buy any pet upgrades you can afford
.target Greshka
.subzoneskip 75,1
step << Shaman
#optional
.goto Swamp of Sorrows,48.19,57.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greshka|r
.train 10437 >> Train your class spells
.target Haromm
.xp <50,1
.xp >52,1
step << Shaman
.goto Swamp of Sorrows,48.19,57.94
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greshka|r
.train 10467 >> Train your class spells
.target Haromm
.xp <52,1
step << Warrior
#optional
.goto Swamp of Sorrows,44.89,57.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malosh|r
.train 1719 >> Train your class spells
.target Malosh
.xp <50,1
.xp >52,1
step << Warrior
.goto Swamp of Sorrows,44.89,57.62
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malosh|r
.train 11551 >> Train your class spells
.target Malosh
.xp <52,1
step
.goto Swamp of Sorrows,45.78,52.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thultazor|r
.vendor >> |cRXP_BUY_Buy|r |T134833:0|t[Superior Healing Potions] |cRXP_BUY_from him if they're up|r
.target Thultazor
step
.goto Swamp of Sorrows,45.38,56.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rartar|r inside the inn
.vendor >> |cRXP_BUY_Buy|r |T134833:0|t[Superior Healing Potions] |cRXP_BUY_from him if they're up|r
.target Rartar
step
#label StonardPots2
.goto Swamp of Sorrows,46.10,54.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breyk|r
.fp Stonard >> Get the Stonard Flight Path
.target Breyk
.subzoneskip 75,1
step << Mage
.goto Swamp of Sorrows,47.89,55.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorrin Foxfire|r
.train 49358 >>Train |T135762:0|t[Teleport: Stonard]
.train 49361 >>Train |T135747:0|t[Portal: Stonard]
.target Lorrin Foxfire
.subzoneskip 75,1
step
#completewith BlastedEnd
.zone Blasted Lands >>Travel to Blasted Lands
step
#completewith BlastedEnd
>>As you're questing, keep an eye out for |T134089:0|t[|cRXP_LOOT_Imperfect Draenethyst Fragments|r] and a |T134564:0|t[|cRXP_LOOT_Flawless Draenethyst Sphere|r]
.collect 10593,1,3501,1 
.collect 8244,1,3501,1 
step << Hunter/Rogue
#completewith next
.blastedLands
#loop
.goto Blasted Lands,62.48,27.98,0
.goto Blasted Lands,49.00,18.20,70,0
.goto Blasted Lands,49.31,23.30,70,0
.goto Blasted Lands,45.25,22.64,70,0
.goto Blasted Lands,45.57,34.71,70,0
.goto Blasted Lands,52.98,37.94,70,0
.goto Blasted Lands,57.95,35.28,70,0
.goto Blasted Lands,56.69,29.18,70,0
.goto Blasted Lands,62.48,27.98,70,0
>>Kill |cRXP_ENEMY_Vultures|r. Loot them for their |cRXP_LOOT_Gizzards|r
>>Kill |cRXP_ENEMY_Basilisks|r. Loot them for their |cRXP_LOOT_Brains|r
>>Kill |cRXP_ENEMY_Boars|r. Loot them for their |cRXP_LOOT_Lungs|r
>>Kill |cRXP_ENEMY_Scorpids|r. Loot them for their |cRXP_LOOT_Pincers|r
>>Kill |cRXP_ENEMY_Hyenas|r. Loot them for their |cRXP_LOOT_Jowls|r
>>|cRXP_WARN_Prioritize |cRXP_ENEMY_Scorpids|r, |cRXP_ENEMY_Vultures|r and |cRXP_ENEMY_Boars|r so you can receive the 25 Agility buff|r
>>|cRXP_WARN_|cRXP_ENEMY_Basilisks|r share spawns with |cRXP_ENEMY_Boars|r, and |cRXP_ENEMY_Hyenas|r share spawns with|r |cRXP_ENEMY_Scorpids|r
.mob Redstone Basilisk
.mob Redstone Crystalhide
.mob Black Slayer
.mob Bone Picker
.mob Starving Snickerfang
.mob Snickerfang Hyena
.mob Scorpok Stinger
.mob Ashmane Boar
step << Hunter/Rogue
.goto Blasted Lands,50.548,14.204
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Ardalan|r
>>|cRXP_WARN_Once you have 3 |cRXP_LOOT_Pincers|r, 2 |cRXP_LOOT_Gizzards|r and 1 |cRXP_LOOT_Lung|r turn in the quest for the 25 Agility buff|r
.collect 8393,3,2585,1 
.collect 8396,2,2585,1 
.collect 8392,1,2585,1 
.accept 2585 >> Accept The Decisive Striker
.disablecheckbox
.turnin 2585 >> Turn in The Decisive Striker
.disablecheckbox
.target Bloodmage Drazial
step << Hunter/Rogue
.goto Blasted Lands,50.548,14.204
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Ardalan|r
.accept 2585 >> Accept The Decisive Striker
.turnin 2585 >> Turn in The Decisive Striker
.target Bloodmage Drazial
step << Druid/Shaman/Warrior
#completewith next
.blastedLands
#loop
.goto Blasted Lands,62.48,27.98,0
.goto Blasted Lands,49.00,18.20,70,0
.goto Blasted Lands,49.31,23.30,70,0
.goto Blasted Lands,45.25,22.64,70,0
.goto Blasted Lands,45.57,34.71,70,0
.goto Blasted Lands,52.98,37.94,70,0
.goto Blasted Lands,57.95,35.28,70,0
.goto Blasted Lands,56.69,29.18,70,0
.goto Blasted Lands,62.48,27.98,70,0
>>Kill |cRXP_ENEMY_Vultures|r. Loot them for their |cRXP_LOOT_Gizzards|r
>>Kill |cRXP_ENEMY_Basilisks|r. Loot them for their |cRXP_LOOT_Brains|r
>>Kill |cRXP_ENEMY_Boars|r. Loot them for their |cRXP_LOOT_Lungs|r
>>Kill |cRXP_ENEMY_Scorpids|r. Loot them for their |cRXP_LOOT_Pincers|r
>>Kill |cRXP_ENEMY_Hyenas|r. Loot them for their |cRXP_LOOT_Jowls|r
>>|cRXP_WARN_Prioritize |cRXP_ENEMY_Hyenas|r, |cRXP_ENEMY_Boars|r and |cRXP_ENEMY_Scorpids|r so you can receive the 25 Strength buff|r
>>|cRXP_WARN_|cRXP_ENEMY_Basilisks|r share spawns with |cRXP_ENEMY_Boars|r, and |cRXP_ENEMY_Hyenas|r share spawns with|r |cRXP_ENEMY_Scorpids|r
.mob Redstone Basilisk
.mob Redstone Crystalhide
.mob Black Slayer
.mob Bone Picker
.mob Starving Snickerfang
.mob Snickerfang Hyena
.mob Scorpok Stinger
.mob Ashmane Boar
step << Druid/Shaman/Warrior
.goto Blasted Lands,50.548,14.204
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ambassador Ardalan|r
>>|cRXP_WARN_Once you have 3 |cRXP_LOOT_Jowls|r, 2 |cRXP_LOOT_Lungs|r and 1 |cRXP_LOOT_Pincer|r turn in the quest for the 25 Strength buff|r
.collect 8391,3,2581,1 
.collect 8392,2,2581,1 
.collect 8393,1,2581,1 
.accept 2581 >> Accept Snickerfang Jowls
.disablecheckbox
.turnin 2581 >> Turn in Snickerfang Jowls
.disablecheckbox
.target Bloodmage Drazial
step << Druid/Shaman/Warrior
.goto Blasted Lands,50.548,14.204
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodmage Drazial|r
.accept 2581 >> Accept Snickerfang Jowls
.turnin 2581 >> Turn in Snickerfang Jowls
.target Bloodmage Drazial
step
.blastedLands
#loop
.goto Blasted Lands,62.48,27.98,0
.goto Blasted Lands,49.00,18.20,70,0
.goto Blasted Lands,49.31,23.30,70,0
.goto Blasted Lands,45.25,22.64,70,0
.goto Blasted Lands,45.57,34.71,70,0
.goto Blasted Lands,52.98,37.94,70,0
.goto Blasted Lands,57.95,35.28,70,0
.goto Blasted Lands,56.69,29.18,70,0
.goto Blasted Lands,62.48,27.98,70,0
>>Kill |cRXP_ENEMY_Vultures|r. Loot them for their |cRXP_LOOT_Gizzards|r
>>Kill |cRXP_ENEMY_Basilisks|r. Loot them for their |cRXP_LOOT_Brains|r
>>Kill |cRXP_ENEMY_Boars|r. Loot them for their |cRXP_LOOT_Lungs|r
>>Kill |cRXP_ENEMY_Scorpids|r. Loot them for their |cRXP_LOOT_Pincers|r
>>Kill |cRXP_ENEMY_Hyenas|r. Loot them for their |cRXP_LOOT_Jowls|r
>>|cRXP_WARN_|cRXP_ENEMY_Basilisks|r share spawns with |cRXP_ENEMY_Boars|r, and |cRXP_ENEMY_Hyenas|r share spawns with|r |cRXP_ENEMY_Scorpids|r
.mob Redstone Basilisk
.mob Redstone Crystalhide
.mob Black Slayer
.mob Bone Picker
.mob Starving Snickerfang
.mob Snickerfang Hyena
.mob Scorpok Stinger
.mob Ashmane Boar
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bloodmage Lynnore|r and |cRXP_FRIENDLY_Bloodmage Drazial|r
.accept 2601 >> Accept The Basilisk's Bite
.turnin 2601 >> Turn in The Basilisk's Bite
.accept 2603 >> Accept Vulture's Vigor
.turnin 2603 >> Turn in Vulture's Vigor
.target +Bloodmage Lynnore
.goto Blasted Lands,50.640,14.299
.accept 2585 >> Accept The Decisive Striker
.turnin 2585 >> Turn in The Decisive Striker
.accept 2583 >> Accept A Boar's Vitality
.turnin 2583 >> Turn in A Boar's Vitality
.accept 2581 >> Accept Snickerfang Jowls
.turnin 2581 >> Turn in Snickerfang Jowls
.target +Bloodmage Drazial
.goto Blasted Lands,50.548,14.204
.addquestitem 8391,2581
.addquestitem 8392,2583
.addquestitem 8393,2585
.addquestitem 8394,2601
.addquestitem 8396,2603
step
#optional
#completewith BlastedEnd
.goto Blasted Lands,51.799,35.636
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kum'isha the Collector|r
.accept 3501 >> Accept Everything Counts In Large Amounts
.turnin 3501 >> Turn in Everything Counts In Large Amounts
.collect 10593,1,3501,1 
.itemcount 10593,1 
.target Kum'isha the Collector
step
#optional
#completewith BlastedEnd
.goto Blasted Lands,51.799,35.636
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kum'isha the Collector|r
.accept 2521 >> Accept To Serve Kum'isha
.turnin 2521 >> Turn in To Serve Kum'isha
.collect 8244,1,2521,1 
.itemcount 8244,1 
.target Kum'isha the Collector
step
#label BlastedEnd
#completewith next
.subzone 75 >> Travel to Stonard
.subzoneskip 75
step
.goto Swamp of Sorrows,45.78,52.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thultazor|r
.vendor >> |cRXP_BUY_Buy|r |T134833:0|t[Superior Healing Potions] |cRXP_BUY_from him if they're up|r
.target Thultazor
step
.goto Swamp of Sorrows,45.38,56.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rartar|r inside the inn
.vendor >> |cRXP_BUY_Buy|r |T134833:0|t[Superior Healing Potions] |cRXP_BUY_from him if they're up|r
.target Rartar
step
#optional
#label BlastedSkip
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 51-52 Searing Gorge/Burning Steppes
#next 52-54 Un'goro Crater
step
#optional
.maxlevel 53,SearingSkip
step
#optional
#completewith EnterSearingG
.goto Swamp of Sorrows,46.10,54.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Breyk|r
.fly Badlands >>Fly to Badlands
.target Breyk
.zoneskip Swamp of Sorrows,1
step
#completewith EnterSearingG
.goto Stranglethorn Vale,26.87,77.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gringer|r
.fly Badlands >>Fly to Badlands
.target Gringer
.zoneskip Badlands
.zoneskip Swamp of Sorrows
step
.goto Badlands,3.40,48.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thal'trak|r
>>|cRXP_WARN_You may have to wait for|r |cRXP_FRIENDLY_Thal'trak|r |cRXP_WARN_to finish his RP. Just follow him|r
.accept 3821 >>Accept Dreadmaul Rock
.target Thal'trak Proudtusk
step
#label EnterSearingG
.goto Badlands,3.62,61.88,50,0
.goto Searing Gorge,72.34,55.47
.zone Searing Gorge >>Travel to Searing Gorge
step
#label CaughtSG
.goto Searing Gorge,65.55,62.15
>>Click on the |cRXP_PICK_Wooden Outhouse|r
>>|cRXP_WARN_Skip this step if you do not have at least 12|r |T132905:0|t[Silk Cloth]
.accept 4449 >>Accept Caught!
.itemcount 4306,12 
step
#loop
.goto Searing Gorge,63.43,60.91,0
.goto Searing Gorge,69.29,33.39,0
.goto Searing Gorge,63.43,60.91,40,0
.goto Searing Gorge,69.29,33.39,40,0
>>Kill |cRXP_ENEMY_Dark Iron Geologists|r
>>|cRXP_WARN_You may need to travel between the northern camp and the southern digsite to complete this quest|r
>>|cRXP_WARN_Skip this quest for now if there is too much competition|r
.complete 4449,1 
.complete 4449,2 
.mob Dark Iron Geologist
.isOnQuest 4449
step
.goto Searing Gorge,39.10,39.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.accept 3441 >>Accept Divine Retribution
.target Velarok Windblade

step
.goto Searing Gorge,39.10,39.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r and complete his dialogue
.complete 3441,1 
.target Velarok Windblade
.skipgossip
step
.goto Searing Gorge,39.05,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3441 >>Turn in Divine Retribution
.accept 3442 >>Accept The Flawless Flame
.target Velarok Windblade
step
#completewith next
.goto Searing Gorge,32.50,32.48,30,0
.subzone 1446 >>Travel west up the hill toward Thorium Point
step
.goto Searing Gorge,34.84,30.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grisha|r
.fp Thorium >>Get the Searing Gorge Flight Path
.target Grisha
step
.goto Searing Gorge,37.64,26.47
>>Click on the |cRXP_PICK_Wanted/Missing/Lost & Found|r board
.accept 7728 >>Accept STOLEN: Smithing Tuyere and Lookout's Spyglass
.accept 7729 >>Accept JOB OPPORTUNITY: Culling the Competition
.accept 7701 >>Accept WANTED: Overseer Maltorius
step
.goto Searing Gorge,38.59,27.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hansel|r
.accept 7723 >>Accept Curse These Fat Fingers
.accept 7724 >>Accept Fiery Menace!
.accept 7727 >>Accept Incendosaurs? Whateverosaur is More Like It
.target Hansel Heavyhands
step
.goto Searing Gorge,38.80,28.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Burninate|r
.accept 7722 >>Accept What the Flux?
.target Master Smith Burninate
step
#completewith Spiders
>>Kill |cRXP_ENEMY_War Golems|r and |cRXP_ENEMY_Elementals|r. Loot them for their |cRXP_LOOT_Heart of Flame|r and |cRXP_LOOT_Golem Oil|r
>>|cRXP_WARN_Kill any|r |cRXP_ENEMY_Magma Elementals|r |cRXP_WARN_that you see. They can drop both quest items|r
.complete 3442,1 
.mob +Inferno Elemental
.mob +Blazing Elemental
.mob +Magma Elemental
.complete 3442,2 
.mob +Heavy War Golem
.mob +Tempered War Golem
.mob +Magma Elemental
step
#completewith Elementals
.goto Searing Gorge,32.6,55.0,40,0
.goto Searing Gorge,36.2,61.6,40,0
.goto Searing Gorge,44.6,62.6,40,0
.goto Searing Gorge,52.4,57.8,40,0
.goto Searing Gorge,51.4,55.8,40,0
>>Kill |cRXP_ENEMY_Dark Iron Lookouts|r. Loot them for a |cRXP_LOOT_Lookout's Spyglass|r
.complete 7728,2 
.mob Dark Iron Lookout
step
#completewith Elementals
.goto Searing Gorge,38.0,49.8,40,0
.goto Searing Gorge,40.8,49.8,40,0
.goto Searing Gorge,42.8,51.6,40,0
>>Kill |cRXP_ENEMY_Dark Iron Steamsmiths|r. Loot them for a |cRXP_LOOT_Smithing Tuyere|r
.complete 7728,1 
.unitscan Dark Iron Steamsmith
step
#label Spiders
#loop
.goto Searing Gorge,33.00,39.60,0
.goto Searing Gorge,33.00,39.60,60,0
.goto Searing Gorge,28.80,43.80,60,0
.goto Searing Gorge,27.60,52.00,60,0
.goto Searing Gorge,30.80,59.80,60,0
.goto Searing Gorge,26.60,69.40,60,0
.goto Searing Gorge,22.60,74.00,60,0
.goto Searing Gorge,25.00,76.20,60,0
.goto Searing Gorge,29.60,75.80,60,0
.goto Searing Gorge,30.60,71.80,60,0
.goto Searing Gorge,31.80,66.40,60,0
.goto Searing Gorge,30.80,59.80,60,0
.goto Searing Gorge,27.60,52.00,60,0
.goto Searing Gorge,28.80,43.80,60,0
>>Kill |cRXP_ENEMY_Greater Lava Spiders|r along the western/southwestern mountains
.complete 7724,1 
.mob Greater Lava Spider
step
#completewith next
.goto Searing Gorge,43.61,40.78,0
.goto Searing Gorge,32.54,47.19,0
>>Kill |cRXP_ENEMY_Heavy War Golems|r
.complete 7723,1 
.mob Heavy War Golem
step
#label Elementals
#loop
.goto Searing Gorge,44.00,38.20,0
.goto Searing Gorge,44.00,38.20,60,0
.goto Searing Gorge,46.60,37.80,60,0
.goto Searing Gorge,47.00,41.40,60,0
.goto Searing Gorge,43.60,44.60,60,0
.goto Searing Gorge,40.60,44.80,60,0
.goto Searing Gorge,36.80,47.60,60,0
.goto Searing Gorge,33.20,52.20,60,0
.goto Searing Gorge,34.00,59.60,60,0
.goto Searing Gorge,36.60,62.80,60,0
.goto Searing Gorge,32.60,70.60,60,0
.goto Searing Gorge,30.60,64.60,60,0
.goto Searing Gorge,28.40,64.00,60,0
.goto Searing Gorge,25.60,53.60,60,0
.goto Searing Gorge,32.40,53.60,60,0
.goto Searing Gorge,33.80,47.40,60,0
.goto Searing Gorge,35.60,41.20,60,0
.goto Searing Gorge,37.60,44.60,60,0
.goto Searing Gorge,40.60,42.80,60,0
>>Finish killing |cRXP_ENEMY_War Golems|r and |cRXP_ENEMY_Elementals|r. Loot them for their |cRXP_LOOT_Heart of Flame|r and |cRXP_LOOT_Golem Oil|r
>>|cRXP_WARN_Kill any|r |cRXP_ENEMY_Magma Elementals|r |cRXP_WARN_that you see. They can drop both quest items|r
.complete 3442,1 
.mob +Inferno Elemental
.mob +Blazing Elemental
.mob +Magma Elemental
.complete 3442,2 
.mob +Heavy War Golem
.mob +Tempered War Golem
.mob +Magma Elemental
step
.goto Searing Gorge,39.05,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3442 >>Turn in The Flawless Flame
.accept 3443 >>Accept Forging the Shaft
.target Velarok Windblade
step
#completewith next
.goto Searing Gorge,47.54,46.89,30 >>Jump down to the platform, and go inside the cave
step
.goto Searing Gorge,51.49,36.55,40,0
#loop
.goto Searing Gorge,51.36,32.24,0
.goto Searing Gorge,51.36,32.24,50,0
.goto Searing Gorge,50.35,24.24,50,0
.goto Searing Gorge,46.76,20.91,50,0
.goto Searing Gorge,44.04,25.41,50,0
.goto Searing Gorge,48.64,27.42,50,0
.goto Searing Gorge,49.68,31.63,50,0
>>Kill |cRXP_ENEMY_Incendosaurs|r in the lower level of the cave
.complete 7727,1 
.mob Incendosaur
step
#completewith Shanksinnit
.goto Searing Gorge,47.03,42.76,20,0
.goto Searing Gorge,47.52,46.76,20,0
.goto Searing Gorge,49.41,45.03,20 >>Exit the cave again and re-enter through its right side
step
#completewith Shanksinnit
>>Kill |cRXP_ENEMY_Dark Iron Taskmasters|r and |cRXP_ENEMY_Dark Iron Slavers|r
.complete 7729,1 
.mob +Dark Iron Taskmaster
.complete 7729,2 
.mob +Dark Iron Slaver
step
.goto Searing Gorge,40.45,35.75
>>Kill |cRXP_ENEMY_Overseer Maltorius|r. Loot him for his |cRXP_LOOT_Head|r and loot the |cRXP_PICK_Secret Plans: Fiery Flux|r
>>|cRXP_WARN_This is a challenging fight. Make a path for kiting or escape by clearing the entire room before getting the plans|r
.complete 7722,1 
.complete 7701,1 
.unitscan Overseer Maltorius
step
#loop
.goto Searing Gorge,46.36,53.91,0
.goto Searing Gorge,46.36,53.91,50,0
.goto Searing Gorge,42.75,54.91,50,0
.goto Searing Gorge,41.35,53.44,50,0
.goto Searing Gorge,37.97,49.17,50,0
.goto Searing Gorge,39.32,44.55,50,0
.goto Searing Gorge,37.97,49.17,50,0
.goto Searing Gorge,35.85,42.12,50,0
.goto Searing Gorge,38.16,38.35,50,0
.goto Searing Gorge,39.24,32.84,50,0
.goto Searing Gorge,41.60,26.95,50,0
.goto Searing Gorge,43.59,22.85,50,0
.goto Searing Gorge,43.46,28.38,50,0
.goto Searing Gorge,46.04,25.49,50,0
.goto Searing Gorge,45.47,30.46,50,0
.goto Searing Gorge,43.13,32.50,50,0
.goto Searing Gorge,43.41,35.64,50,0
.goto Searing Gorge,48.27,43.38,50,0
.goto Searing Gorge,49.88,46.10,50,0
.goto Searing Gorge,48.28,50.79,50,0
>>Kill all |cRXP_ENEMY_Dark Iron Dwarves|r and |cRXP_ENEMY_Slave Workers|r. Loot them for their |cRXP_LOOT_Daggers|r
.complete 3443,1 
.mob Dark Iron Steamsmith
.mob Dark Iron Lookout
.mob Dark Iron Slaver
.mob Dark Iron Taskmaster
.mob Dark Iron Geologist
.mob Dark Iron Watchman
.mob Dark Iron Steelshifter
.mob Dark Iron Kidnapper
step
#label Shanksinnit
#loop
.goto Searing Gorge,46.36,53.91,0
.goto Searing Gorge,46.36,53.91,50,0
.goto Searing Gorge,42.75,54.91,50,0
.goto Searing Gorge,41.35,53.44,50,0
.goto Searing Gorge,37.97,49.17,50,0
.goto Searing Gorge,39.32,44.55,50,0
.goto Searing Gorge,37.97,49.17,50,0
.goto Searing Gorge,35.85,42.12,50,0
.goto Searing Gorge,38.16,38.35,50,0
.goto Searing Gorge,39.24,32.84,50,0
.goto Searing Gorge,41.60,26.95,50,0
.goto Searing Gorge,43.59,22.85,50,0
.goto Searing Gorge,43.46,28.38,50,0
.goto Searing Gorge,46.04,25.49,50,0
.goto Searing Gorge,45.47,30.46,50,0
.goto Searing Gorge,43.13,32.50,50,0
.goto Searing Gorge,43.41,35.64,50,0
.goto Searing Gorge,48.27,43.38,50,0
.goto Searing Gorge,49.88,46.10,50,0
.goto Searing Gorge,48.28,50.79,50,0
>>Keep killing |cRXP_ENEMY_Dark Iron Dwarves|r until you loot the |T134246:0|t[|cRXP_LOOT_Grimesilt Outhouse Key|r]
.collect 11818,1,4451 
.accept 4451 >>Accept The Key to Freedom
.use 11818
.mob Dark Iron Steamsmith
.mob Dark Iron Lookout
.mob Dark Iron Slaver
.mob Dark Iron Taskmaster
.mob Dark Iron Geologist
.mob Dark Iron Watchman
.mob Dark Iron Steelshifter
.mob Dark Iron Kidnapper
step
.goto Searing Gorge,39.05,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3443 >>Turn in Forging the Shaft
.accept 3452 >>Accept The Flame's Casing
.target Velarok Windblade
step
.goto Searing Gorge,26.56,35.03,70,0
#loop
.goto Searing Gorge,24.56,39.25,0
.goto Searing Gorge,24.56,39.25,50,0
.goto Searing Gorge,22.50,39.77,50,0
.goto Searing Gorge,22.18,36.45,50,0
.goto Searing Gorge,24.52,34.62,50,0
.goto Searing Gorge,25.02,31.00,50,0
.goto Searing Gorge,25.74,29.39,50,0
.goto Searing Gorge,22.33,26.85,50,0
.goto Searing Gorge,25.73,25.38,50,0
.goto Searing Gorge,27.43,24.93,50,0
.goto Searing Gorge,25.74,29.39,50,0
.goto Searing Gorge,25.02,31.00,50,0
.goto Searing Gorge,24.52,34.62,50,0
>>Kill |cRXP_ENEMY_Twilight mobs|r. Loot them for the |cRXP_LOOT_Symbol of Ragnaros|r
.complete 3452,1 
.mob Twilight Dark Shaman
.mob Twilight Fire Guard
.mob Twilight Geomancer
.mob Twilight Idolater
step
.isQuestComplete 3452
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.turnin 3452 >> Turn in The Flame's Casing
.accept 3453 >> Accept The Torch of Retribution
.timer 28,The Torch of Retribution RP
step
#optional
.isQuestTurnedIn 3452
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
.accept 3453 >> Accept The Torch of Retribution
.timer 28,The Torch of Retribution RP
step
#optional
.isQuestTurnedIn 3452
.goto Searing Gorge,39.057,38.990
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r
>>|cRXP_WARN_Wait for the RP to finish|r
.turnin 3453 >> Turn in The Torch of Retribution
.accept 3454 >> Accept The Torch of Retribution
.target Velarok Windblade
step
#completewith next
+Talk to |cRXP_FRIENDLY_Velarok Windblade|r
.skipgossip
.target Velarok Windblade

step
.goto Searing Gorge,39.055,39.067
>>Click on the |cRXP_PICK_Torch of Retribution|r
.turnin 3454 >> Turn in The Torch of Retribution
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Velarok Windblade|r and |cRXP_FRIENDLY_Maltrake|r
.accept 3462 >>Accept Squire Maltrake
.target +Velarok Windblade
.goto Searing Gorge,39.06,38.99
.turnin 3462 >>Turn in Squire Maltrake
.accept 3463 >>Accept Set Them Ablaze!
.target +Squire Maltrake
.goto Searing Gorge,39.17,39.00
step
#completewith OuthouseAndy
.goto Searing Gorge,34.08,53.99,0
>>Kill |cRXP_ENEMY_Dark Iron Lookouts|r. Loot them for the |cRXP_LOOT_Lookout's Spyglass|r
.complete 7728,2 
.mob Dark Iron Lookout
step
#completewith WarGolems
.goto Searing Gorge,40.90,50.31,0
>>Kill |cRXP_ENEMY_Dark Iron Steamsmiths|r. Loot them for the |cRXP_LOOT_Smithing Tuyere|r
.complete 7728,1 
.unitscan Dark Iron Steamsmith
step
#completewith next
.goto Searing Gorge,43.61,40.78,0
.goto Searing Gorge,32.54,47.19,0
>>Kill |cRXP_ENEMY_Heavy War Golems|r
.complete 7723,1 
.mob Heavy War Golem
step
.goto Searing Gorge,33.30,54.47
>>Climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.use 10515 >>|cRXP_WARN_Equip the|r |T135466:0|t[Torch of Retribution] |cRXP_WARN_to be able light it|r
.complete 3463,4 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
#label WarGolems
#loop
.goto Searing Gorge,35.16,45.78,0
.goto Searing Gorge,35.16,45.78,70,0
.goto Searing Gorge,40.40,44.42,70,0
.goto Searing Gorge,45.72,41.98,70,0
.goto Searing Gorge,50.66,39.23,70,0
>>Kill |cRXP_ENEMY_Heavy War Golems|r
.complete 7723,1 
.mob Heavy War Golem
step
#loop
.goto Searing Gorge,40.43,49.37,0
.goto Searing Gorge,42.91,51.73,50,0
.goto Searing Gorge,40.43,49.37,50,0
.goto Searing Gorge,37.81,49.66,50,0
>>Kill |cRXP_ENEMY_Dark Iron Steamsmiths|r. Loot them for the |cRXP_LOOT_Smithing Tuyere|r
.complete 7728,1 
.unitscan Dark Iron Steamsmith
step
.goto Searing Gorge,35.66,60.68
>>Climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.use 10515 >>|cRXP_WARN_Equip the|r |T135466:0|t[Torch of Retribution] |cRXP_WARN_to be able light it|r
.complete 3463,1 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
.goto Searing Gorge,44.03,60.90
>>Climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.use 10515 >>|cRXP_WARN_Equip the|r |T135466:0|t[Torch of Retribution] |cRXP_WARN_to be able light it|r
.complete 3463,2 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
#loop
.goto Searing Gorge,63.43,60.91,0
.goto Searing Gorge,69.29,33.39,0
.goto Searing Gorge,63.43,60.91,40,0
.goto Searing Gorge,69.29,33.39,40,0
>>Kill |cRXP_ENEMY_Dark Iron Geologists|r
>>|cRXP_WARN_You may need to travel between the northern camp and the southern digsite to complete this quest|r
.complete 4449,1 
.complete 4449,2 
.mob Dark Iron Geologist
.isOnQuest 4449
step
.goto Searing Gorge,65.59,62.17
>>Click on the |cRXP_PICK_Wooden Outhouse|r
.turnin 4449 >>Turn in Caught!
.turnin 4451 >>Turn in The Key to Freedom
.addquestitem 4306,4449
.isQuestComplete 4449
step
#optional
.goto Searing Gorge,65.59,62.17
>>Click on the |cRXP_PICK_Wooden Outhouse|r
.turnin 4451 >>Turn in The Key to Freedom
.addquestitem 4306,4449
step
#label OuthouseAndy
.goto Searing Gorge,50.10,54.70
>>Climb the tower and click the |cRXP_PICK_Sentry Brazier|r
.use 10515 >>|cRXP_WARN_Equip the|r |T135466:0|t[Torch of Retribution] |cRXP_WARN_to be able light it|r
>>|cRXP_WARN_Be careful, it's possible to fall through the bridge on the northern side! Make sure you jump onto the bridge when leaving the tower|r << !Tauren
.complete 3463,3 
.unitscan Dark Iron Sentry
.isQuestTurnedIn 3452
step
.goto Searing Gorge,34.08,53.99
>>Kill |cRXP_ENEMY_Dark Iron Lookouts|r. Loot them for the |cRXP_LOOT_Lookout's Spyglass|r
.complete 7728,2 
.mob Dark Iron Lookout
step
#loop
.goto Searing Gorge,46.36,53.91,0
.goto Searing Gorge,46.36,53.91,50,0
.goto Searing Gorge,42.75,54.91,50,0
.goto Searing Gorge,41.35,53.44,50,0
.goto Searing Gorge,37.97,49.17,50,0
.goto Searing Gorge,39.32,44.55,50,0
.goto Searing Gorge,37.97,49.17,50,0
.goto Searing Gorge,35.85,42.12,50,0
.goto Searing Gorge,38.16,38.35,50,0
.goto Searing Gorge,39.24,32.84,50,0
.goto Searing Gorge,41.60,26.95,50,0
.goto Searing Gorge,43.59,22.85,50,0
.goto Searing Gorge,43.46,28.38,50,0
.goto Searing Gorge,46.04,25.49,50,0
.goto Searing Gorge,45.47,30.46,50,0
.goto Searing Gorge,43.13,32.50,50,0
.goto Searing Gorge,43.41,35.64,50,0
.goto Searing Gorge,48.27,43.38,50,0
.goto Searing Gorge,49.88,46.10,50,0
.goto Searing Gorge,48.28,50.79,50,0
>>Kill |cRXP_ENEMY_Dark Iron Taskmasters|r and |cRXP_ENEMY_Dark Iron Slavers|r
.complete 7729,1 
.mob +Dark Iron Taskmaster
.complete 7729,2 
.mob +Dark Iron Slaver
step
#completewith next
.goto Searing Gorge,39.05,38.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maltrake|r
.turnin 3463 >>Turn in Set Them Ablaze!
.target Squire Maltrake
.isQuestTurnedIn 3452
step
.goto Searing Gorge,38.85,38.99
>>Open the chest on the ground twice, then open the |cRXP_PICK_Hoard of the Black Dragonflight|r and loot the |cRXP_LOOT_Black Dragonflight Molt|r
.accept 3481 >>Accept Trinkets...
.turnin 3481 >>Turn in Trinkets...
.isQuestTurnedIn 3452
step
#optional
#completewith SGEnd
.destroy 10515 >>|cRXP_WARN_You can destroy the|r |T135466:0|t[Torch of Retribution] |cRXP_WARN_as it's no longer needed|r
step
#completewith SGEnd
.goto Searing Gorge,32.50,32.48,30,0
.subzone 1446 >>Travel to Thorium Point
step
.goto Searing Gorge,37.60,26.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lolo|r
.turnin 7701 >>Turn in WANTED: Overseer Maltorius
.target Lookout Captain Lolo Longstriker
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hansel|r and |cRXP_FRIENDLY_Scrange|r
.turnin 7723 >>Turn in Curse These Fat Fingers
.turnin 7724 >>Turn in Fiery Menace!
.turnin 7727 >>Turn in Incendosaurs? Whateverosaur is More Like It
.target +Hansel Heavyhands
.goto Searing Gorge,38.58,27.80
.turnin 7728 >>Turn in STOLEN: Smithing Tuyere and Lookout's Spyglass
.turnin 7729 >>Turn in JOB OPPORTUNITY: Culling the Competition
.target +Taskmaster Scrange
.goto Searing Gorge,38.98,27.50
step
#label SGEnd
.goto Searing Gorge,38.80,28.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Burninate|r
.turnin 7722 >>Turn in What the Flux?
.target Master Smith Burninate
step
#completewith next
.goto Searing Gorge,59.80,77.65,0
.goto Searing Gorge,59.80,77.65,50,0
.goto Searing Gorge,59.57,85.06,20,0
.goto Burning Steppes,46.59,21.45
.zone Burning Steppes >>Travel to southeast Searing Gorge to do a skip through the mountains into Burning Steppes
>>|cRXP_WARN_Alternatively you run through Blackrock Mountain|r
.link https://www.youtube.com/watch?v=tFVsNuMvI5c&ab_channel=RestedXP >> Click HERE for reference
step
.goto Burning Steppes,65.69,24.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vahgruk|r
.fp Flame Crest >>Get the Burning Steppes Flight Path
.target Vahgruk
.isQuestAvailable 4726
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r and |cRXP_FRIENDLY_Maxwort|r
.accept 4726 >>Accept Broodling Essence
.target +Tinkee Steamboil
.goto Burning Steppes,65.24,24.01
.accept 4296 >>Accept Tablet of the Seven
.target +Maxwort Uberglint
.goto Burning Steppes,65.15,23.94
step
#completewith HoardO
.use 12284 >>|cRXP_WARN_Use your|r |T133001:0|t[Draco-Incarcinatrix 900] |cRXP_WARN_on|r |cRXP_ENEMY_Black Broodlings|r
>>Kill them and loot the |cRXP_LOOT_Broodling Essence|r from the |cRXP_PICK_Red Obelisk|r over their corpses
.complete 4726,1 
.mob Black Broodling
step
.goto Burning Steppes,54.10,40.70
>>Click the |cRXP_PICK_Stone Placard|r in front of the Dwarf statue to create a |cRXP_LOOT_Tablet Transcript|r
.complete 4296,1 
.skipgossip
step
.goto Burning Steppes,77.68,38.23,60,0
.goto Burning Steppes,79.80,45.60
>>Cross the bridge, then go up the mountain. Click on |cRXP_PICK_Sha'ni Proudtusk's Remains|r atop the altar
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sha'ni|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Firegut Brutes'|r |cRXP_WARN_knockback, as it can knock you off the mountain|r
.turnin 3821 >>Turn in Dreadmaul Rock
.target Sha'ni Proudtusk
step
#label HoardO
.goto Burning Steppes,95.09,31.56
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cyrus|r
.use 10569>>|cRXP_WARN_Open your|r |T132595:0|t[Hoard of the Black Dragonflight] |cRXP_WARN_if you haven't yet|r
.accept 4022 >>Accept A Taste of Flame
.turnin 4022 >>Turn in A Taste of Flame
.target Cyrus Therepentous
.isQuestTurnedIn 3452
step
#loop
.goto Burning Steppes,81.80,27.80,0
.goto Burning Steppes,81.80,27.80,60,0
.goto Burning Steppes,85.80,30.20,60,0
.goto Burning Steppes,90.60,29.80,60,0
.goto Burning Steppes,92.00,39.40,60,0
.goto Burning Steppes,90.60,49.40,60,0
.goto Burning Steppes,88.80,56.20,60,0
.goto Burning Steppes,85.20,61.40,60,0
.goto Burning Steppes,82.00,61.60,60,0
.goto Burning Steppes,84.60,56.00,60,0
.goto Burning Steppes,89.40,52.60,60,0
.goto Burning Steppes,88.60,44.80,60,0
.goto Burning Steppes,91.60,38.40,60,0
.goto Burning Steppes,89.80,33.60,60,0
.goto Burning Steppes,86.40,32.00,60,0
.use 12284 >>|cRXP_WARN_Use your|r |T133001:0|t[Draco-Incarcinatrix 900] |cRXP_WARN_on|r |cRXP_ENEMY_Black Broodlings|r
>>Kill them and loot the |cRXP_LOOT_Broodling Essence|r from the |cRXP_PICK_Red Obelisk|r over their corpses
.complete 4726,1 
.mob Black Broodling
step
#label BSTurnins
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tinkee|r and |cRXP_FRIENDLY_Maxwort|r
.turnin 4726 >>Turn in Broodling Essence
.accept 4808 >>Accept Felnok Steelspring
.target +Tinkee Steamboil
.goto Burning Steppes,65.24,24.01
.turnin 4296 >>Turn in Tablet of the Seven
.target +Maxwort Uberglint
.goto Burning Steppes,65.15,23.94
step
#optional
.goto Burning Steppes,77.68,38.23
.xp 52 >> Grind mobs in the area to level 52

step << Druid
#completewith DruidTraining8
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9884 >>Train your class spells
.target Loganaar
.xp <50,1
.xp >52,1
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9894 >>Train your class spells
.target Loganaar
.xp <52,1
.xp >54,1
step << Druid
#label DruidTraining8
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9830 >>Train your class spells
.target Loganaar
.xp <54,1
step
#completewith FlyTanaris
.hs >>Hearth to Ratchet
.use 6948
.bindlocation 392,1
.subzoneskip 392
step
#optional
#label Searingskip
step
#optional
#completewith FlyTanaris
.hs >>Hearth to Ratchet
.use 6948
.cooldown item,6948,>0
.zoneskip Stranglethorn Vale,1
.bindlocation 392,1
.subzoneskip 392
step
#completewith FlyTanaris
.goto Stranglethorn Vale,25.76,73.04
.zone The Barrens >>Take the boat to Ratchet
.zoneskip Stranglethorn Vale,1
.cooldown item,6948,<0
step
.goto The Barrens,62.639,37.421,-1
.goto The Barrens,62.680,37.395,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fuzruckle|r or |cRXP_FRIENDLY_Zikkel|r
.bankwithdraw 8526,9618,9594,10556 >>Withdraw the following from the bank:
>>|T134527:0|t[Violet Tragan] 
>>|T133841:0|t[Wildkin Muisek Vessel] 
>>|T135992:0|t[Wildkin Muisek] 
>>|T134430:0|t[Stone Circle] 
.target Fuzruckle
.target Zikkel
step
#label FlyTanaris
#completewith StoneCircleTI
.goto The Barrens,63.09,37.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Gadgetzan >> Fly to Gadgetzan
.target Bragok
.zoneskip Tanaris
step
.goto Tanaris,51.10,26.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sprinkle|r
.turnin 2641 >>Turn in Sprinkle's Secret Ingredient
.accept 2661 >>Accept Delivery for Marin
.target Sprinkle
step
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4494 >>Turn in March of the Silithid
.accept 4496 >>Accept Bungle in the Jungle
.target Alchemist Pestlezugg
step
.goto Tanaris,51.56,26.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.accept 4504 >>Accept Super Sticky
.target Tran'rek
step
.goto Tanaris,51.80,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marin|r
.turnin 2661 >>Turn in Delivery for Marin
.accept 2662 >>Accept Noggenfogger Elixir
.turnin 2662 >>Turn in Noggenfogger Elixir
.target Marin Noggenfogger
.isQuestTurnedIn 2641
step
.goto Tanaris,51.80,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marin|r
>>|cRXP_BUY_Buy 2 or more additional stacks of|r |T134863:0|t[Noggenfogger Elixir] |cRXP_BUY_from him|r
>>|T134863:0|t[Noggenfogger Elixirs] |cRXP_WARN_can be used to get the|r |T135992:0|t[Slow Fall] |cRXP_WARN_buff which will be needed later in the guide. Put the additional stacks on the bank|r
.collect 8529,60
.target Marin Noggenfogger
.isQuestTurnedIn 2662
.subzoneskip 976,1
step
#optional
.abandon 2641 >>Abandon Sprinkle's Secret Ingredient
step
.goto Tanaris,52.50,27.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fizzgrimble|r
.home >>Set your Hearthstone to Gadgetzan
.target Innkeeper Fizzgrimble
.bindlocation 976
step
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 4787 >> Turn in The Ancient Egg
.target Yeh'kinya
.isQuestComplete 4787
.dungeon ZF
step
#label StoneCircleTI
.goto Tanaris,52.70,45.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon|r
.turnin 3444 >>Turn in The Stone Circle
.target Marvon Rivetseeker
.isOnQuest 3444
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 52-54 Un'goro Crater
#next 54-56 Azshara/Felwood/Winterspring
step
#completewith next
.goto Tanaris,27.00,55.66,150,0
.goto Tanaris,27.00,50.21
.zone Un'Goro Crater >>Travel to Un'Goro Crater
step
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.accept 4289 >>Accept The Apes of Un'Goro
.accept 4290 >>Accept The Fare of Lar'korwi
.target Torwa Pathfinder
step
#completewith StickyTars
.goto Un'Goro Crater,70.60,53.26,0
>>Save 25 |cRXP_LOOT_Un'Goro Soil|r that you'll loot from mobs as you quest
.collect 11018,25 
step
#completewith StickyTars
>>Loot a |T133743:0|t[|cRXP_LOOT_A Mangled Journal|r]. Use it to start the quest
>>|cRXP_WARN_Any mob in Un'Goro Crater may drop it|r
.collect 11116,1,3884 
.accept 3884 >> Accept Williden's Journal
.use 11116
step
#completewith StickyTars
.goto Un'Goro Crater,73.06,51.57,0
>>Loot 7 |cRXP_LOOT_Power Crystals|r of each color as you quest
.collect 11186,7,4284,1 
.collect 11188,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
step
#completewith Scent
>>Kill |cRXP_ENEMY_Ravasaur Raptors|r. Loot them for their |cRXP_LOOT_Claws|r
>>|cRXP_WARN_Don't focus on this quest yet, just kill them if they cross your path|r
.complete 4300,1 
.mob Ravasaur
.mob Ravasaur Hunter
.mob Venomhide Ravasaur
.mob Ravasaur Runner
.mob Ravasaur Matriarch
.isOnQuest 4300
step
.goto Un'Goro Crater,63.10,68.60
>>Click the |cRXP_PICK_Wrecked Raft|r
.accept 3844 >>Accept It's a Secret to Everybody
step
.goto Un'Goro Crater,63.10,69.00
>>Go underwater, then click the |cRXP_PICK_Small Pack|r
.turnin 3844 >>Turn in It's a Secret to Everybody
.accept 3845 >>Accept It's a Secret to Everybody
step
.goto Un'Goro Crater,68.80,56.80
>>Loot the |cRXP_PICK_Fresh Threshadon Carcass|r for a |cRXP_LOOT_Piece of Threshadon Carcass|r
.complete 4290,1 
step
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4290 >>Turn in The Fare of Lar'korwi
.accept 4291 >>Accept The Scent of Lar'korwi
.target Torwa Pathfinder
step
#loop
.goto Un'Goro Crater,67.30,73.10,0
.goto Un'Goro Crater,66.60,66.70,0
.goto Un'Goro Crater,67.30,73.10,20,0
.goto Un'Goro Crater,66.60,66.70,20,0
>>Step on the small egg nests to summon |cRXP_ENEMY_Lar'Korwi Mates|r. Kill them and loot them for their |cRXP_LOOT_Glands|r
.complete 4291,1 
.unitscan Lar'Korwi Mate
step
#label Scent
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4291 >>Turn in The Scent of Lar'korwi
.accept 4292 >>Accept The Bait for Lar'korwi
.target Torwa Pathfinder
step
#label BoneBlade
#loop
.goto Un'Goro Crater,68.20,75.00,0
.goto Un'Goro Crater,68.20,75.00,60,0
.goto Un'Goro Crater,67.00,71.20,60,0
.goto Un'Goro Crater,67.80,67.00,60,0
.goto Un'Goro Crater,68.00,61.60,60,0
.goto Un'Goro Crater,64.80,62.60,60,0
.goto Un'Goro Crater,63.00,66.40,60,0
.goto Un'Goro Crater,61.60,70.80,60,0
.goto Un'Goro Crater,59.80,75.20,60,0
.goto Un'Goro Crater,59.40,79.00,60,0
.goto Un'Goro Crater,62.00,82.40,60,0
.goto Un'Goro Crater,61.80,76.00,60,0
.goto Un'Goro Crater,63.60,77.20,60,0
.goto Un'Goro Crater,66.20,77.80,60,0
>>Kill |cRXP_ENEMY_Ravasaur raptors|r. Loot them for their |cRXP_LOOT_Claws|r
.complete 4300,1 
.mob Ravasaur
.mob Ravasaur Hunter
.mob Venomhide Ravasaur
.mob Ravasaur Runner
.mob Ravasaur Matriarchaw
.isOnQuest 4300
step
#label FungalRock
#loop
.goto Un'Goro Crater,62.86,18.17,0
.goto Un'Goro Crater,61.85,17.71,50,0
.goto Un'Goro Crater,64.32,16.35,25,0
.goto Un'Goro Crater,65.83,15.61,20,0
.goto Un'Goro Crater,68.70,17.13,20,0
.goto Un'Goro Crater,69.52,16.82,20,0
.goto Un'Goro Crater,68.63,14.36,20,0
.goto Un'Goro Crater,68.51,13.27,20,0
.goto Un'Goro Crater,65.64,14.60,20,0
.goto Un'Goro Crater,65.06,16.70,20,0
.goto Un'Goro Crater,63.91,16.35,20,0
.goto Un'Goro Crater,62.86,18.17,20,0
>>Kill |cRXP_ENEMY_Un'Goro Stompers|r, |cRXP_ENEMY_Un'Goro Thunderers|r. and |cRXP_ENEMY_Un'Goro gorillas|r. Loot them for their |cRXP_LOOT_Pelts|r
>>|cRXP_WARN_Be careful!|r |cRXP_ENEMY_Un'Goro Gorillas|r |cRXP_WARN_call for help in a 90 yard range.|r |cRXP_ENEMY_Un'Goro Thunderers|r |cRXP_WARN_have a high-damage, instant shock spell|r
.complete 4289,2 
.mob +Un'Goro Stomper
.complete 4289,3 
.mob +Un'Goro Thunderer
.complete 4289,1 
.mob +Un'Goro Gorilla
step
#label StickyTars
#loop
.goto Un'Goro Crater,47.20,14.70,0
.goto Un'Goro Crater,47.20,14.70,60,0
.goto Un'Goro Crater,48.10,17.70,60,0
.goto Un'Goro Crater,49.80,20.60,60,0
.goto Un'Goro Crater,51.30,23.90,60,0
.goto Un'Goro Crater,53.60,22.70,60,0
.goto Un'Goro Crater,54.50,27.00,60,0
.goto Un'Goro Crater,52.20,27.60,60,0
.goto Un'Goro Crater,49.20,31.20,60,0
.goto Un'Goro Crater,48.00,36.30,60,0
.goto Un'Goro Crater,46.60,30.50,60,0
.goto Un'Goro Crater,48.20,24.70,60,0
.goto Un'Goro Crater,47.80,20.50,60,0
.goto Un'Goro Crater,43.70,21.10,60,0
.goto Un'Goro Crater,41.30,21.00,60,0
.goto Un'Goro Crater,42.80,15.90,60,0
>>Kill |cRXP_ENEMY_Tar Elementals|r. Loot them for their |cRXP_LOOT_Super Sticky Tar|r
>>|cRXP_WARN_Be careful as the|r |cRXP_ENEMY_Tar Lords|r |cRXP_WARN_cast Entangling Roots|r << !Warrior !Rogue !Shaman
>>|cRXP_WARN_Be careful as the|r |cRXP_ENEMY_Tar Lords|r |cRXP_WARN_cast Entangling Roots.|r |cRXP_ENEMY_Tar Beasts|r |cRXP_WARN_can disarm you for four seconds when they are hit|r << Warrior/Rogue/Shaman
.complete 4504,1 
.mob Tar Beast
.mob Tar Creeper
.mob Tar Lord
.mob Tar Lurker
step 
>>Loot 7 |cRXP_LOOT_Power Crystals|r of each color
.collect 11186,7,4284,1 
.collect 11188,7,4284,1 
.collect 11185,7,4284,1 
.collect 11184,7,4284,1 
step
.goto Un'Goro Crater,46.37,13.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna|r
.accept 4243 >>Accept Chasing A-Me 01
.target Karna Remtravel
step
.goto Tanaris,12.80,8.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shizzle|r
.accept 4503 >>Accept Shizzle's Flyer
.target Shizzle
step
.goto Un'Goro Crater,45.53,8.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larion|r
.accept 4145 >>Accept Larion and Muigin
.target Larion
step
#completewith next
.goto Un'Goro Crater,44.70,8.10
.use 11107 >>|cRXP_WARN_Open|r |T133653:0|t[A Small Pack] |cRXP_WARN_for the following:|r
.complete 3845,1 
.complete 3845,2 
.complete 3845,3 
step
.goto Un'Goro Crater,44.70,8.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Linken|r
.turnin 3845 >>Turn in It's a Secret to Everybody
.accept 3908 >>Accept It's a Secret to Everybody
.target Linken
step
.destroy 11107 >>Destroy |T133653:0|t[A Small Pack]
.destroy 3108 >>Destroy the |T135427:0|t[Heavy Throwing Daggers]
.destroy 11108 >>Destroy the |T134944:0|t[Faded Photograph]
>>|cRXP_WARN_You no longer need these|r
step
.goto Un'Goro Crater,43.61,8.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle|r
.accept 4492 >>Accept Lost!
.target Spraggle Frock
step
.goto Un'Goro Crater,43.55,8.42
>>Click the |cRXP_PICK_Wanted Poster|r
.accept 4501 >>Accept Beware of Pterrordax
step
.goto Un'Goro Crater,43.50,7.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spark|r
.accept 3882 >>Accept Roll the Bones
.target Spark Nilminer
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hol'anyee|r and |cRXP_FRIENDLY_Williden|r
.accept 3883 >>Accept Alien Ecology
.target +Hol'anyee Marshal
.goto Un'Goro Crater,43.89,7.24
.accept 3881 >>Accept Expedition Salvation
.target +Williden Marshal
.goto Un'Goro Crater,43.95,7.14
step
.goto Un'Goro Crater,43.947,7.137
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Williden Marshal|r
.use 11116 >>|cRXP_WARN_Use |T133743:0|t[A Mangled Journal] to start the quest|r
.collect 11116,1,3884,1 
.accept 3884 >> Accept Williden's Journal
.turnin 3884 >> Turn in Williden's Journal
.target Williden Marshal
.itemcount 11116,1
step
.goto Un'Goro Crater,43.16,6.24,30,0
.goto Un'Goro Crater,41.90,2.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r
.accept 4284 >>Accept Crystals of Power
.turnin 4284 >>Turn in Crystals of Power
.accept 4285 >> Accept The Northern Pylon
.accept 4288 >> Accept The Western Pylon
.accept 4287 >> Accept The Eastern Pylon
.target J.D. Collie
step
.goto Un'Goro Crater,43.16,6.24,30,0
.goto Un'Goro Crater,45.23,5.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tExit the cave, then talk to |cRXP_FRIENDLY_Gryfe|r
.fp Marshal >>Get the Un'Goro Crater Flight Path
.target Gryfe
step
#completewith Mighty
>>Collect |cRXP_LOOT_Un'Goro Soil|r as you quest throught Un'Goro
.collect 11018,25 
step
#completewith next
>>Kill a few |cRXP_ENEMY_Pterrordax|r in the area. Loot them for their |cRXP_LOOT_Scales|r
.complete 4501,1 
.complete 4503,2 
.unitscan Pterrordax
step
.goto Un'Goro Crater,56.49,12.44
>>Click the |cRXP_PICK_Northern Crystal Pylon|r
.complete 4285,1 
.skipgossip
step
#completewith Ucha
>>Kill |cRXP_ENEMY_Diemetradons|r. Loot them for their |cRXP_LOOT_Bones|r and |cRXP_LOOT_Scales|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Elder Diemetradons'|r |cRXP_WARN_Pummel ability, which interrupts spells|r << Warlock/Priest/Mage/Shaman/Druid
.complete 3882,1 
.complete 4503,1 
.mob Diemetradon
.mob Young Diemetradon
.mob Elder Diemetradon
step
#loop
.goto Un'Goro Crater,57.60,36.80,0
.goto Un'Goro Crater,57.60,36.80,60,0
.goto Un'Goro Crater,64.40,30.80,60,0
.goto Un'Goro Crater,68.20,24.00,60,0
.goto Un'Goro Crater,71.20,31.00,60,0
.goto Un'Goro Crater,74.20,39.60,60,0
.goto Un'Goro Crater,76.00,47.40,60,0
.goto Un'Goro Crater,74.20,39.60,60,0
.goto Un'Goro Crater,69.40,38.00,60,0
.goto Un'Goro Crater,66.60,35.60,60,0
.goto Un'Goro Crater,60.00,39.40,60,0
>>Kill |cRXP_ENEMY_Bloodpetal Threshers|r, |cRXP_ENEMY_Bloodpetal Lashers|r and |cRXP_ENEMY_Bloodpetal Flayers|r
>>|cRXP_WARN_Their poison deals high damage and they can disarm|r << Warrior/Rogue/Shaman
>>|cRXP_WARN_Their poison deals high damage and drains mana|r << !Warrior !Rogue !Shaman
.complete 4145,4 
.mob +Bloodpetal Thresher
.complete 4145,1 
.mob +Bloodpetal Lasher
.complete 4145,3 
.mob +Bloodpetal Flayer
step
.goto Un'Goro Crater,68.54,36.54
>>Loot the |cRXP_PICK_Crate of Foodstuffs|r on the ground
.complete 3881,1 
step
.goto Un'Goro Crater,77.24,49.96
>>Click the |cRXP_PICK_Eastern Crystal Pylon|r
.complete 4287,1 
.skipgossip
step
.goto Un'Goro Crater,79.94,49.88
.use 11568 >>|cRXP_WARN_Open|r |T133635:0|t[Torwa's Pouch]
.use 11569 >>|cRXP_WARN_Stand near the big flat rock, then use the|r |T133970:0|t[Preserved Threshadon Meat]
.use 11570 >>|cRXP_WARN_Use the|r |T134743:0|t[Preserved Pheromone Mixture]
>>Kill |cRXP_ENEMY_Lar'korwi|r as he spawns. Loot him for his |cRXP_LOOT_Head|r
.complete 4292,1 
.mob Lar'korwi
step
#label Ucha
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4289 >>Turn in The Apes of Un'Goro
.accept 4301 >>Accept The Mighty U'cha
.turnin 4292 >>Turn in The Bait for Lar'korwi
.target Torwa Pathfinder
step
#completewith HiveSample
.goto Un'Goro Crater,50.59,77.06,0
>>Kill |cRXP_ENEMY_Gorishi Silithid|r. Loot them for a |cRXP_LOOT_Gorishi Scent Gland|r
.complete 4496,1 
.mob Gorishi Worker
.mob Gorishi Wasp
.mob Gorishi Reaver
.mob Gorishi Tunneler
.mob Gorishi Stinger
.mob Gorishi Hive Guard
step
.goto Un'Goro Crater,49.96,81.69,15 >>Enter the Silithid cave
.isOnQuest 3883
step
#completewith next
.goto Un'Goro Crater,49.43,82.90,15,0
.goto Un'Goro Crater,49.17,84.51,12 >>Enter the room on the left
step
#label HiveSample
.goto Un'Goro Crater,48.69,85.31
.use 11132 >>|cRXP_WARN_Use your|r |T134864:0|t[Scraping Vial] |cRXP_WARN_in the centre of the room|r
.complete 3883,1 
step
#loop
.goto Un'Goro Crater,51.74,75.36,0
.goto Un'Goro Crater,49.44,82.85,40,0
.goto Un'Goro Crater,50.35,79.55,50,0
.goto Un'Goro Crater,48.69,76.45,70,0
.goto Un'Goro Crater,47.58,81.58,70,0
.goto Un'Goro Crater,49.38,82.32,70,0
.goto Un'Goro Crater,52.38,84.31,70,0
.goto Un'Goro Crater,54.03,78.15,70,0
.goto Un'Goro Crater,51.74,75.36,70,0
>>Kill |cRXP_ENEMY_Gorishi Silithid|r. Loot them for a |cRXP_LOOT_Gorishi Scent Gland|r
.complete 4496,1 
.mob Gorishi Worker
.mob Gorishi Wasp
.mob Gorishi Reaver
.mob Gorishi Tunneler
.mob Gorishi Stinger
.mob Gorishi Hive Guard
step
#loop
.goto Un'Goro Crater,43.6,92.4,0
.goto Un'Goro Crater,56.2,88.2,40,0
.goto Un'Goro Crater,57.0,92.6,40,0
.goto Un'Goro Crater,50.4,87.8,40,0
.goto Un'Goro Crater,50.6,89.8,40,0
.goto Un'Goro Crater,43.0,85.2,40,0
.goto Un'Goro Crater,43.6,92.4,40,0
>>Kill |cRXP_ENEMY_Pterrordax|r in the southern mountains
.complete 4501,1 
.unitscan Pterrordax
step
#completewith FirePlumeRidge
>>Kill |cRXP_ENEMY_Bloodpetal Trappers|r
>>|cRXP_WARN_Their poison deals high damage, and they can cast entangling roots|r << Warrior/Rogue/Shaman
>>|cRXP_WARN_Their poison deals high damage and drains mana. They can cast entangling roots|r << !Warrior !Rogue !Shaman
.complete 4145,2 
.mob Bloodpetal Trapper
step
#completewith FirePlumeRidge
>>Kill |cRXP_ENEMY_Diemetradons|r. Loot them for their |cRXP_LOOT_Bones|r and |cRXP_LOOT_Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Diemetradon
.mob Young Diemetradon
.mob Elder Diemetradon
step
.goto Un'Goro Crater,38.46,66.07
>>Loot the |cRXP_PICK_Research Equipment boxes|r on the ground
.complete 3881,2 
step
.goto Un'Goro Crater,23.87,59.21
>>Click the |cRXP_PICK_Western Crsytal Pylon|r
.complete 4288,1 
.skipgossip
step
#completewith FirePlumeRidge
.goto Un'Goro Crater,20.95,59.45,80,0
.goto Un'Goro Crater,36.76,35.47,0
>>Kill |cRXP_ENEMY_Frenzied Pterrordax|r. Loot them for their |cRXP_LOOT_Scales|r
.complete 4501,2 
.complete 4503,2 
.mob Frenzied Pterrordax
step
.goto Un'Goro Crater,30.94,50.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krakle|r
.accept 974 >>Accept Finding the Source
.target Krakle
step
#label FirePlumeRidge
.goto Un'Goro Crater,47.1,47.1
.subzone 537 >>Travel to Fire Plume Ridge
.isOnQuest 974
step
#completewith HotSpot
.goto Un'Goro Crater,47.1,47.1,10,0
.goto Un'Goro Crater,47.7,48.3,10,0
.goto Un'Goro Crater,48.2,50.1,10,0
.goto Un'Goro Crater,48.6,49.8,20 >>Take the lava path shortcut on the west side of the volcano to the top
step
#completewith next
>>Kill |cRXP_ENEMY_Fire Elementals|r. Loot them for their |cRXP_LOOT_Ash|r
.complete 4502,1 
.mob Scorching Elemental
.mob Living Blaze
.mob Blazing Invader
step
#label HotSpot
.goto Un'Goro Crater,49.6,45.7
.use 12472 >>|cRXP_WARN_Climb up to the top of the volcano, then use|r |T132995:0|t[Krakle's Thermometer]
>>|cRXP_WARN_Be very careful of |cRXP_ENEMY_Blazerunner|r (56 elite) at the top of the mountain!|r
.complete 974,1 
.unitscan Blazerunner
step
#optional
#completewith Springs
>>Kill |cRXP_ENEMY_Bloodpetal Trappers|r
>>|cRXP_WARN_Their poison deals high damage, and they can cast entangling roots|r << Warrior/Rogue/Shaman
>>|cRXP_WARN_Their poison deals high damage and drains mana. They can cast entangling roots|r << !Warrior !Rogue !Shaman
.complete 4145,2 
.mob Bloodpetal Trapper
step
#optional
#completewith Springs
>>Kill |cRXP_ENEMY_Diemetradons|r. Loot them for their |cRXP_LOOT_Bones|r and |cRXP_LOOT_Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Diemetradon
.mob Young Diemetradon
.mob Elder Diemetradon
step
#optional
#completewith Springs
>>Kill |cRXP_ENEMY_Frenzied Pterrordax|r. Loot them for their |cRXP_LOOT_Scales|r
.complete 4501,2 
.complete 4503,2 
.mob Frenzied Pterrordax
step
#label Springs
.goto Un'Goro Crater,30.94,50.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krakle|r
.turnin 974 >>Turn in Finding the Source
.accept 980 >>Accept The New Springs
.target Krakle
step
#completewith PterrordaxAndys
.goto Un'Goro Crater,35.49,43.91,0
>>Kill |cRXP_ENEMY_Diemetradons|r. Loot them for their |cRXP_LOOT_Bones|r and |cRXP_LOOT_Scales|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Elder Diemetradons'|r |cRXP_WARN_Pummel ability, which interrupts spells|r << Warlock/Priest/Mage/Shaman/Druid
.complete 3882,1 
.complete 4503,1 
.mob Diemetradon
.mob Young Diemetradon
.mob Elder Diemetradon
step
#completewith next
.goto Un'Goro Crater,36.76,35.47,0
>>Kill |cRXP_ENEMY_Frenzied Pterrordax|r. Loot them for their |cRXP_LOOT_Scales|r
.complete 4501,2 
.complete 4503,2 
.mob Frenzied Pterrordax
step
#loop
.goto Un'Goro Crater,31.16,31.18,0
.goto Un'Goro Crater,31.16,31.18,60,0
.goto Un'Goro Crater,40.68,31.29,60,0
.goto Un'Goro Crater,41.51,39.52,60,0
.goto Un'Goro Crater,41.05,43.46,60,0
.goto Un'Goro Crater,39.34,51.44,60,0
.goto Un'Goro Crater,29.37,43.13,60,0
>>Kill |cRXP_ENEMY_Bloodpetal Trappers|r
>>|cRXP_WARN_Their poison deals high damage, and they can cast entangling roots|r << Warrior/Rogue/Shaman
>>|cRXP_WARN_Their poison deals high damage and drains mana. They can cast entangling roots|r << !Warrior !Rogue !Shaman
.complete 4145,2 
.mob Bloodpetal Trapper
step
#label PterrordaxAndys
#loop
.goto Un'Goro Crater,30.80,59.60,0
.goto Un'Goro Crater,36.60,65.80,60,0
.goto Un'Goro Crater,40.80,62.80,60,0
.goto Un'Goro Crater,41.80,56.80,60,0
.goto Un'Goro Crater,40.60,51.20,60,0
.goto Un'Goro Crater,39.60,43.40,60,0
.goto Un'Goro Crater,37.80,36.60,60,0
.goto Un'Goro Crater,32.60,34.40,60,0
.goto Un'Goro Crater,27.60,37.20,60,0
.goto Un'Goro Crater,26.00,45.40,60,0
.goto Un'Goro Crater,26.80,58.20,60,0
.goto Un'Goro Crater,30.80,68.00,60,0
.goto Un'Goro Crater,38.40,74.00,60,0
.goto Un'Goro Crater,40.80,67.20,60,0
.goto Un'Goro Crater,32.80,63.20,60,0
.goto Un'Goro Crater,30.80,59.60,60,0
>>Kill |cRXP_ENEMY_Frenzied Pterrordax|r. Loot them for their |cRXP_LOOT_Scales|r
.complete 4501,2 
.complete 4503,2 
.mob Frenzied Pterrordax
step
#loop
.goto Un'Goro Crater,40.80,62.80,0
.goto Un'Goro Crater,36.60,65.80,60,0
.goto Un'Goro Crater,40.80,62.80,60,0
.goto Un'Goro Crater,41.80,56.80,60,0
.goto Un'Goro Crater,40.60,51.20,60,0
.goto Un'Goro Crater,39.60,43.40,60,0
.goto Un'Goro Crater,37.80,36.60,60,0
.goto Un'Goro Crater,32.60,34.40,60,0
.goto Un'Goro Crater,27.60,37.20,60,0
.goto Un'Goro Crater,26.00,45.40,60,0
.goto Un'Goro Crater,26.80,58.20,60,0
.goto Un'Goro Crater,30.80,68.00,60,0
.goto Un'Goro Crater,38.40,74.00,60,0
.goto Un'Goro Crater,40.80,67.20,60,0
.goto Un'Goro Crater,32.80,63.20,60,0
.goto Un'Goro Crater,30.80,59.60,60,0
>>Kill |cRXP_ENEMY_Diemetradons|r. Loot them for their |cRXP_LOOT_Bones|r and |cRXP_LOOT_Scales|r
.complete 3882,1 
.complete 4503,1 
.mob Diemetradon
.mob Young Diemetradon
.mob Elder Diemetradon
step
#loop
.goto Un'Goro Crater,46.70,53.20,0
.goto Un'Goro Crater,46.70,53.20,50,0
.goto Un'Goro Crater,49.80,53.90,50,0
.goto Un'Goro Crater,52.20,54.20,50,0
.goto Un'Goro Crater,51.20,51.60,50,0
.goto Un'Goro Crater,53.10,50.40,50,0
.goto Un'Goro Crater,52.60,45.30,50,0
.goto Un'Goro Crater,51.50,46.30,50,0
.goto Un'Goro Crater,50.30,47.70,50,0
.goto Un'Goro Crater,51.30,49.40,50,0
.goto Un'Goro Crater,50.30,47.70,50,0
.goto Un'Goro Crater,49.50,47.30,50,0
.goto Un'Goro Crater,47.80,50.90,50,0
>>Kill |cRXP_ENEMY_Fire Elementals|r. Loot them for their |cRXP_LOOT_Ash|r
.complete 4502,1 
.mob Scorching Elemental
.mob Living Blaze
.mob Blazing Invader
step
#completewith next
.goto Un'Goro Crater,52.42,51.00,30 >> Enter the cave on the east side of the volcano
step
.goto Un'Goro Crater,51.90,49.85
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ringo|r
.turnin 4492 >>Turn in Lost!
.accept 4491,1 >>Accept A Little Help From My Friends
.target Ringo
step
.goto Un'Goro Crater,43.62,8.50
.use 11804 >>Escort |cRXP_FRIENDLY_Ringo|r to Marshal's Refuge. Use |T132805:0|t[Spraggle's Canteen] on him when he falls down
>>|cRXP_WARN_Be careful not to ride away too fast from Ringo|r
.complete 4491,1 
.target Ringo
step
.goto Un'Goro Crater,44.23,11.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shizzle|r
.turnin 4503 >>Turn in Shizzle's Flyer
.target Shizzle
step
.goto Un'Goro Crater,43.61,8.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle|r
.turnin 4501 >>Turn in Beware of Pterrordax
.target Spraggle Frock
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hol'anyee|r and |cRXP_FRIENDLY_Williden|r
.turnin 3883 >>Turn in Alien Ecology
.target +Hol'anyee Marshal
.goto Un'Goro Crater,43.89,7.24
.turnin 3881 >>Turn in Expedition Salvation
.target +Williden Marshal
.goto Un'Goro Crater,43.95,7.14
step
.goto Un'Goro Crater,43.16,6.24,30,0
.goto Un'Goro Crater,41.9,2.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r inside the cave
.turnin 4285 >>Turn in The Northern Pylon
.turnin 4288 >>Turn in The Western Pylon
.turnin 4287 >>Turn in The Eastern Pylon
.target J.D. Collie
step
.goto Un'Goro Crater,41.9,2.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_J.D. Collie|r inside the cave
.accept 4321 >>Accept Making Sense of It
.turnin 4321 >>Turn in Making Sense of It
.target J.D. Collie

step
#optional
#completewith U'chaKill
.destroy 11482 >>|cRXP_WARN_Destroy|r |T133740:0|t[Crystal Pylon User's Manual] |cRXP_WARN_as it's not needed for anything|r
step
.goto Un'Goro Crater,43.50,7.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spark|r
.turnin 3882 >>Turn in Roll the Bones
.target Spark Nilminer
step
.goto Un'Goro Crater,43.61,8.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Spraggle|r
.turnin 4491 >>Turn in A Little Help From My Friends
.target Spraggle Frock
step
.goto Un'Goro Crater,45.53,8.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larion|r
.turnin 4145 >>Turn in Larion and Muigin
.accept 4147 >>Accept Marvon's Workshop
.target Larion
step
#completewith U'chaKill
.goto Un'Goro Crater,62.97,17.39,40,0
.subzone 542 >>Travel to Fungal Rock
step
#ssf
.goto Un'Goro Crater,64.17,16.43,40,0
.goto Un'Goro Crater,67.66,16.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHug the right wall as you enter the cave, then talk to |cRXP_FRIENDLY_A-Me 01|r
.turnin 4243 >>Turn in Chasing A-Me 01
.target A-Me 01
step
#label U'chaKill
.goto Un'Goro Crater,68.0,13.2
>>Kill |cRXP_ENEMY_U'cha|r in the back of the cave. Loot him for his |cRXP_LOOT_Pelt|r
.complete 4301,1 
.unitscan U'cha
step
#ah
.goto Un'Goro Crater,67.67,16.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me|r
.turnin 4243 >>Turn in Chasing A-Me 01
.target A-Me 01
step
#ah
.goto Un'Goro Crater,67.67,16.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me|r
.accept 4244 >>Accept Chasing A-Me 01
.turnin 4244 >>Turn in Chasing A-Me 01
.accept 4245,1 >>Accept Chasing A-Me 01
.target A-Me 01
.itemcount 10561,1
step
#ah
#optional
.goto Un'Goro Crater,67.67,16.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_A-Me|r
.accept 4245,1 >>Accept Chasing A-Me 01
.target A-Me 01
.isQuestTurnedIn 4244
step
#ah
.goto Un'Goro Crater,46.37,13.43
>>Escort |cRXP_FRIENDLY_A-Me 01|r back to the outside of Marshal's Refuge
.complete 4245,1 
.isOnQuest 4245
step
.goto Un'Goro Crater,46.37,13.43
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karna|r
.turnin 4245 >>Turn in Chasing A-Me 01
.target Karna Remtravel
.isQuestComplete 4245
step
#label Mighty
.goto Un'Goro Crater,71.64,75.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torwa|r
.turnin 4301 >>Turn in The Mighty U'cha
.target Torwa Pathfinder
step
#loop
.goto Un'Goro Crater,50.93,67.97,0
.goto Un'Goro Crater,46.60,62.37,70,0
.goto Un'Goro Crater,49.25,64.43,70,0
.goto Un'Goro Crater,50.93,67.97,70,0
.goto Un'Goro Crater,55.97,69.52,70,0
.goto Un'Goro Crater,57.84,63.53,70,0
.goto Un'Goro Crater,58.80,57.84,70,0
.goto Un'Goro Crater,58.43,52.67,70,0
.goto Un'Goro Crater,57.94,44.83,70,0
>>Collect |cRXP_LOOT_Un'Goro Soil|r from mobs or |cRXP_PICK_Un'Goro Dirt Piles|r
.collect 11018,25 
step
#completewith STPickups
.goto Tanaris,27.06,56.58
.zone Tanaris >> Travel up to Tanaris
.dungeon ST
step
.goto Tanaris,52.707,45.923
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marvon Rivetseeker|r
.accept 3446 >> Accept Into the Depths
.accept 3447 >> Accept Secret of the Circle
.target Marvon Rivetseeker
.isQuestTurnedIn 3444
.dungeon ST
step
#label STPickups
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.accept 3528 >> Accept The God Hakkar
.target Yeh'kinya
.isQuestTurnedIn 4787 
.dungeon ST
step
#completewith next
.hs >>Hearth to Gadgetzan
.subzoneskip 976
.use 6948
.bindlocation 976,1
step
.goto Tanaris,52.63,28.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dirge|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Dirge Quikcleave
step
.goto Tanaris,51.56,26.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tran'rek|r
.turnin 4504 >>Turn in Super Sticky
.target Tran'rek
step
.goto Tanaris,50.90,27.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pestlezugg|r
.turnin 4496 >>Turn in Bungle in the Jungle
.target Alchemist Pestlezugg
step
#completewith next
.goto Tanaris,51.60,25.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Feralas >> Fly to Feralas
.target Bulkrek Ragefist
.zoneskip Feralas
step
.goto Feralas,74.50,43.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uzer'i|r
.turnin 3123 >>Turn in Testing the Vessel
.target Witch Doctor Uzer'i
step << !Mage
#completewith TBVisit
.goto Feralas,75.45,44.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shyn|r
.fly Thunder Bluff >>Fly to Thunder Bluff
.target Shyn
.zoneskip Thunder Bluff
step << Mage
#completewith TBVisit
.cast 3566 >>|cRXP_WARN_Cast|r |T135765:0|t[Teleport: Thunder Bluff]
.zoneskip Thunder Bluff
step << Hunter
.goto Thunder Bluff,59.13,86.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 14286 >> Train your class spells
.target Urek Thunderhorn
.xp <52,1
.xp >54,1
step << Hunter
#optional
.goto Thunder Bluff,59.13,86.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 14290 >> Train your class spells
.target Urek Thunderhorn
.xp <54,1
.xp >56,1
step << Hunter
#optional
.goto Thunder Bluff,59.13,86.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 14305 >> Train your class spells
.target Urek Thunderhorn
.xp <56,1
step << Hunter
.goto Thunder Bluff,54.07,84.02
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hesuwa|r
.train 24631 >> Train your pet spells
.target Hesuwa Thunderhorn
.xp <54,1
step << Warrior
.goto Thunder Bluff,57.59,85.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ker|r
.train 11551 >> Train your class spells
.target Ker Ragetotem
.xp <52,1
.xp >54,1
step << Warrior
#optional
.goto Thunder Bluff,57.27,87.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torm|r
.train 11556 >> Train your class spells
.target Torm Ragetotem
.xp <54,1
.xp >56,1
step << Warrior
#optional
.goto Thunder Bluff,57.27,87.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Torm|r
.train 20662 >> Train your class spells
.target Torm Ragetotem
.xp <56,1
step << Druid
.goto Thunder Bluff,76.79,31.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kym|r
.train 9894 >> Train your class spells
.target Kym Wildmane
.xp <52,1
.xp >54,1
step << Druid
#optional
.goto Thunder Bluff,76.79,31.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kym|r
.train 9830 >> Train your class spells
.target Kym Wildmane
.xp <54,1
.xp >56,1
step << Druid
#optional
.goto Thunder Bluff,76.79,31.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kym|r
.train 22829 >> Train your class spells
.target Kym Wildmane
.xp <56,1
step << Priest
.goto Thunder Bluff,25.31,15.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miles|r
.train 10946 >> Train your class spells
.target Miles Welsh
.xp <52,1
.xp >54,1
step << Priest
#optional
.goto Thunder Bluff,25.31,15.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miles|r
.train 10900 >> Train your class spells
.target Miles Welsh
.xp <54,1
.xp >56,1
step << Priest
#optional
.goto Thunder Bluff,25.31,15.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Miles|r
.train 10929 >> Train your class spells
.target Miles Welsh
.xp <56,1
step << Mage
.goto Thunder Bluff,22.74,14.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shymm|r
.train 10186 >> Train your class spells
.target Archmage Shymm
.xp <52,1
.xp >54,1
step << Mage
#optional
.goto Thunder Bluff,22.74,14.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shymm|r
.train 10199 >> Train your class spells
.target Archmage Shymm
.xp <54,1
.xp >56,1
step << Mage
#optional
.goto Thunder Bluff,22.74,14.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shymm|r
.train 10157 >> Train your class spells
.target Archmage Shymm
.xp <56,1
step << Mage
.goto Thunder Bluff,22.48,16.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Birgitte|r
.train 11420 >> Train |T135750:0|t[Portal: Thunder Bluff]
.target Birgitte Cranston
.xp <50,1
step << Shaman
.goto Thunder Bluff,23.64,18.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigor|r
.train 10448 >> Train your class spells
.target Tigor Skychaser
.xp <52,1
.xp >54,1
step << Shaman
#optional
.goto Thunder Bluff,23.64,18.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigor|r
.train 10408 >> Train your class spells
.target Tigor Skychaser
.xp <54,1
.xp >56,1
step << Shaman
#optional
.goto Thunder Bluff,23.64,18.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigor|r
.train 10432 >> Train your class spells
.target Tigor Skychaser
.xp <56,1
step
.goto Thunder Bluff,78.50,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hamuul|r
.accept 3761 >>Accept Un'Goro Soil
.target Arch Druid Hamuul Runetotem
step
.goto Thunder Bluff,77.30,22.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ghede|r
.turnin 3761 >>Turn in Un'Goro Soil
.target Ghede
.addquestitem 11018,3761
step
#ah
#completewith next
.goto Thunder Bluff,45.22,59.40
+If you bought enough cloth earlier, go to the mailbox and retrieve the following:
.collect 2592,60 
.collect 4306,60 
.collect 4338,60 
.collect 14047,60 
step
#label TBVisit
.goto Thunder Bluff,43.3,42.8
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rumstag|r
>>|cRXP_WARN_Disable any other addons that automatically turn in reputation items, or you'll be told to buy cloth again later|r
>>|cRXP_WARN_Skip any of the donations which you do not have enough cloth for|r
.turnin 7820 >>Turn in A Donation of Wool
.turnin 7821 >>Turn in A Donation of Silk
.turnin 7822 >>Turn in A Donation of Mageweave
.turnin 7823 >>Turn in A Donation of Runecloth
.target Rumstag Proudstrider
step
#sticky
#completewith EnterST
.subzone 1417 >> Now you should be looking for a group to Sunken Temple
.dungeon ST
step
#completewith next
.goto Thunder Bluff,47.02,49.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Ratchet >>Fly to Ratchet
.target Tal
.zoneskip The Barrens
step
.goto The Barrens,62.50,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv|r
.turnin 4502 >>Turn in Volcanic Activity
.turnin 4147 >>Turn in Marvon's Workshop
.target Liv Rizzlefix
step
.goto The Barrens,62.50,38.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Liv|r
.accept 4146 >>Accept Zapper Fuel
.target Liv Rizzlefix
.isQuestTurnedIn 4147
.dungeon ST
step
#completewith next
.goto The Barrens,63.74,38.66
.zone Stranglethorn Vale >> Take the boat to Stranglethorn Vale
.zoneskip Stranglethorn Vale
.dungeon ST
step
.goto Stranglethorn Vale,26.90,77.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|ttalk to |cRXP_FRIENDLY_Gringer|r
>>|cRXP_WARN_Fly to Stonard if you have the flight path|r
.fly Grom'gol >> Fly to Grom'gol Base Camp
.target Gringer
.zoneskip Swamp of Sorrows
.zoneskip Duskwood
.zoneskip Deadwind Pass
.dungeon ST
step
#completewith next
.goto Stranglethorn Vale,39.30,6.49,60,0
.goto Stranglethorn Vale,40.63,3.12,50 >> Travel to Duskwood
.zoneskip Swamp of Sorrows
.zoneskip Duskwood
.zoneskip Deadwind Pass
.dungeon ST
step
#completewith next
.goto Duskwood,88.47,41.00,50 >> Travel to Deadwind Pass
.zoneskip Swamp of Sorrows
.zoneskip Deadwind Pass
.dungeon ST
step
.goto Deadwind Pass,48.02,34.60,60,0
.goto Deadwind Pass,58.43,41.51,50,0
.goto Deadwind Pass,59.91,41.22
.zone Swamp of Sorrows >> Travel to Swamp of Sorrows
.zoneskip Swamp of Sorrows
.dungeon ST
step
.goto 1415,56.33,76.28
.subzone 1477 >> Travel to Sunken Temple
.dungeon ST
step
#label EnterST
.goto 1415,56.33,76.28,40,0
.goto 1415,56.46,75.54,20,0
.goto 1415,56.83,75.86,20,0
.goto 1415,56.94,76.03,15,0
.goto 1415,57.06,75.58,20,0
.goto 1415,56.76,75.35,15,0
.goto 1415,56.809,75.151
.subzone 1477,2 >> Zone into Sunken Temple
.dungeon ST
step
#completewith STEnd
>>Kill |cRXP_ENEMY_Deep Lurkers|r, |cRXP_ENEMY_Murk Worms|r and |cRXP_ENEMY_Saturated Oozes|r. Loot them for their |cRXP_LOOT_Atal'ai Haze|r
>>|cRXP_WARN_Take a right down the stairs at the beginning of the instance to find these mobs|r
.complete 4146,1 
.isOnQuest 4146
.dungeon ST
step 
#completewith next
>>Click on the |cRXP_PICK_Altar of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Altar of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3446 >> Turn in Into the Depths
.isOnQuest 3446
.dungeon ST
step 
>>Click on the |cRXP_PICK_Idol of Hakkar|r
>>|cRXP_WARN_Clicking all of the |cRXP_PICK_Atal'ai Statues|r on the platforms will activate the|r |cRXP_PICK_Idol of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Idol of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3447 >> Turn in Secret of the Circle
.isOnQuest 3447
.dungeon ST
step 
#label Altar
>>Click on the |cRXP_PICK_Altar of Hakkar|r
>>|cRXP_WARN_The |cRXP_PICK_Altar of Hakkar|r is located on the lower level of Sunken Temple|r
.turnin 3446 >> Turn in Into the Depths
.isOnQuest 3446
.dungeon ST
step
>>|cRXP_WARN_Use the|r |T132834:0|t[Egg of Hakkar] |cRXP_WARN_while next to the Dragonflayer Skeleton, then complete the event|r
>>Kill the minions of |cRXP_ENEMY_Hakkar|r until the |cRXP_ENEMY_Avatar of Hakkar|r joins
>>Kill the |cRXP_ENEMY_Avatar of Hakkar|r. Loot it for the |T136148:0|t[|cRXP_LOOT_Essence of Hakkar|r]
>>|cRXP_WARN_Use the|r |T136148:0|t[|cRXP_LOOT_Essence of Hakkar|r] |cRXP_WARN_to fill the|r |T132834:0|t[Egg of Hakkar]
.collect 10663,1,3528,1 
.disablecheckbox
.complete 3528,1 
.use 10465 
.use 10663 
.mob Avatar of Hakkar
.isOnQuest 3528
.dungeon ST
step
>>Kill |cRXP_ENEMY_Jammal'an the Prophet|r. Loot him for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_You must kill the 6 |cRXP_ENEMY_Trolls|r on the upper platforms to gain access to|r |cRXP_ENEMY_Jammal'an the Prophet|r
.complete 1446,1 
.mob Jammal'an the Prophet
.isOnQuest 1446
.dungeon ST
step
>>Kill the |cRXP_ENEMY_Shade of Eranikus|r. Loot him for the |T135229:0|t[|cRXP_LOOT_Essence of Eranikus|r]
>>|cRXP_WARN_Use the |T135229:0|t[|cRXP_LOOT_Essence of Eranikus|r] to start the quest|r
>>|cRXP_WARN_Ensure you have killed all |cRXP_ENEMY_Dragonkin|r mobs on the upper level before engaging the |cRXP_ENEMY_Shade of Eranikus|r otherwise they will all aggro onto you|r
.collect 10454,1,3373,1 
.accept 3373 >> Accept The Essence of Eranikus
.mob Shade of Eranikus
.dungeon ST
step
>>Click the |cRXP_PICK_Essence Font|r
.turnin 3373 >> Turn in The Essence of Eranikus
.isOnQuest 3373
.dungeon ST
step
#label STEnd
#completewith next
.hs >>Hearth to Gadgetzan
.use 6948
.subzoneskip 976
.dungeon ST
.bindlocation 976,1
step
.goto Tanaris,52.63,28.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dirge|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Dirge Quikcleave
.dungeon ST
step
.goto Tanaris,66.989,22.354
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yeh'kinya|r
.turnin 3528 >> Turn in The God Hakkar
.target Yeh'kinya
.isQuestComplete 3528
.dungeon ST
step
#completewith next
.goto Tanaris,51.60,25.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Un'Goro Crater >>Fly to Un'Goro Crater
.target Bulkrek Ragefist
.isQuestComplete 4146
.dungeon ST
step
.goto Un'Goro Crater,45.53,8.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larion|r
.turnin 4146 >>Turn in Zapper Fuel
.target Larion
.isQuestComplete 4146
.dungeon ST
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 54-56 Azshara/Felwood/Winterspring
#next 56-59 Western/Eastern Plaguelands
step
#optional
.goto Un'Goro Crater,43.16,6.24,30,0
.goto Un'Goro Crater,45.23,5.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tExit the cave, then talk to |cRXP_FRIENDLY_Gryfe|r
.fly Ratchet >>Fly to Ratchet
.target Gryfe
.zoneskip Un'Goro Crater,1
.dungeon ST
step
.goto Tanaris,51.60,25.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Ratchet >>Fly to Ratchet
.target Bulkrek Ragefist
.zoneskip Tanaris,1
.dungeon ST
step
.goto The Barrens,62.05,39.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Wiley|r
.home >>Set your Hearthstone to Ratchet
.target Innkeeper Wiley
.bindlocation 392
.subzoneskip 392,1
step
.goto The Barrens,62.639,37.421,-1
.goto The Barrens,62.680,37.395,-1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Fuzruckle|r or |cRXP_FRIENDLY_Zikkel|r
.bankwithdraw 10695,10687,10688,10689,10690,10643 >>Withdraw the following from the bank:
>>|T132594:0|t[Box of Empty Vials] |cRXP_WARN_(or the|r |T132793:0|t[Empty Vials] |cRXP_WARN_if you openend the box)|r
>>|T133469:0|t[Sealed Letter to Ag'tor] 
.target Fuzruckle
.target Zikkel
.subzoneskip 392,1
step
#completewith next
.goto The Barrens,63.09,37.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Splintertree Post >> Fly to Splintertree Post
.target Bragok
.zoneskip Ashenvale
step
#label EnterAzshara
#completewith next
.goto Ashenvale,75.37,64.73,20,0
.goto Ashenvale,79.07,55.41,30,0
.goto Ashenvale,91.24,46.47,30,0
.goto Ashenvale,95.33,48.38,15,0
.subzone 879 >>Travel to Azshara
step
#requires EnterAzshara
#completewith next
.goto Azshara,22.00,49.70,30,0
.subzone 1237 >> Travel northeast to Valormok
step
#requires EnterAzshara
.goto Azshara,22.00,49.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kroum|r
.fp Azshara >>Get the Azshara Flight Path
.target Kroum
step
.goto Azshara,22.20,51.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ag'tor|r
.turnin 3504 >>Turn in Betrayed
.target Ag'tor Bloodfist
.isOnQuest 3504
step
.goto Azshara,22.20,51.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ag'tor|r
.accept 3505 >>Accept Betrayed
.target Ag'tor Bloodfist
.isQuestTurnedIn 3504
step
.goto Azshara,22.50,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.accept 3517 >>Accept Stealing Knowledge
.target Jediga
step
#label KJI
.goto Azshara,53.45,21.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kim'jael|r
.accept 3601 >>Accept Kim'jael Indeed!
.target Kim'jael
step
#completewith Magus
>>Loot the |cRXP_PICK_Kim'Jael's Equipment|r boxes scattered around the camp
.complete 3601,1 
.complete 3601,2 
.complete 3601,3 
.complete 3601,4 
step
#loop
.goto Azshara,55.80,25.90,0
.goto Azshara,55.80,25.90,50,0
.goto Azshara,57.80,26.40,50,0
.goto Azshara,58.00,28.20,50,0
.goto Azshara,59.20,29.60,50,0
.goto Azshara,57.90,31.40,50,0
.goto Azshara,57.00,30.30,50,0
.goto Azshara,56.90,27.50,50,0
.goto Azshara,56.00,29.70,50,0
.goto Azshara,55.40,29.70,50,0
>>Kill |cRXP_ENEMY_Blood Elf Reclaimers|r and |cRXP_ENEMY_Blood Elf Surveyors|r
>>|cRXP_WARN_Be careful!|r |cRXP_ENEMY_Surveyors|r |cRXP_WARN_have a short cooldown Fire Nova, and|r |cRXP_ENEMY_Reclaimers|r |cRXP_WARN_have a high-damage fireball|r
.complete 3505,1 
.mob +Blood Elf Reclaimer
.complete 3505,2 
.mob +Blood Elf Surveyor
.isOnQuest 3505
step
.goto Azshara,59.50,31.31
>>Click the |cRXP_PICK_Kaldorei Tome of Summoning|r on the pedestal in the summoning circle
.complete 3505,3 
.turnin 3505 >>Turn in Betrayed
.isOnQuest 3505
step
.goto Azshara,59.50,31.31
>>Click the |cRXP_PICK_Kaldorei Tome of Summoning|r again
.accept 3506 >>Accept Betrayed
.isQuestTurnedIn 3505
step
#label Magus
.goto Azshara,59.50,31.40
>>Destroy one of the |cRXP_PICK_Arcane Focusing Crystals|r. This will summon a |cRXP_ENEMY_Blood Elf Defender|r
>>After 13 seconds |cRXP_ENEMY_Magus Rimtori|r will spawn. Kill her and loot her for her |cRXP_LOOT_Head|r
.complete 3506,1 
.isQuestTurnedIn 3505
.mob Blood Elf Defender
.unitscan Magus Rimtori
step
#loop
.goto Azshara,58.50,25.00,0
.goto Azshara,58.50,25.00,25,0
.goto Azshara,58.90,28.30,25,0
.goto Azshara,59.60,30.90,25,0
.goto Azshara,57.00,29.90,25,0
.goto Azshara,56.50,28.40,25,0
>>Loot the |cRXP_PICK_Kim'Jael's Equipment|r boxes scattered around the camp
.complete 3601,1 
.complete 3601,2 
.complete 3601,3 
.complete 3601,4 
step
.goto Azshara,53.45,21.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kim'jael|r
.turnin 3601 >>Turn in Kim'jael Indeed!
.accept 5534 >>Accept Kim'jael's "Missing" Equipment
.target Kim'jael
step
#completewith Tablets
>>Kill all |cRXP_ENEMY_Spitelash Nagas|r. Loot them for |cRXP_LOOT_Some Rune|r
.complete 5534,1 
.mob Spitelash Myrmidon
.mob Spitelash Enchantress
.mob Spitelash Battlemaster
.mob Spitelash Siren
step
#completewith next
.use 10695 >>|cRXP_WARN_Open your|r |T132594:0|t[Box of Empty Vials]
.collect 10687,1,3568,1
.collect 10688,1,3568,1
.collect 10689,1,3568,1
.collect 10690,1,3568,1
step
.goto Azshara,47.50,46.20
.use 10690 >>|cRXP_WARN_Use your|r |T132793:0|t[Empty Vial Labeled #4] |cRXP_WARN_in the centre of the puddle|r
.complete 3568,4 
step
.goto Azshara,48.70,48.50
.use 10689 >>|cRXP_WARN_Use your|r |T132793:0|t[Empty Vial Labeled #3] |cRXP_WARN_in the centre of the puddle|r
.complete 3568,3 
step
.goto Azshara,47.80,51.30
.use 10688 >>|cRXP_WARN_Use your|r |T132793:0|t[Empty Vial Labeled #2] |cRXP_WARN_in the centre of the puddle|r
.complete 3568,2 
step
.goto Azshara,47.80,60.80
.use 10687 >>|cRXP_WARN_Use your|r |T132793:0|t[Empty Vial Labeled #1] |cRXP_WARN_in the centre of the puddle|r
.complete 3568,1 
step
#label Tablets
#loop
.goto Azshara,35.86,53.49,0
.goto Azshara,39.80,46.81,40,0
.goto Azshara,39.86,48.72,40,0
.goto Azshara,37.30,48.12,40,0
.goto Azshara,38.55,54.58,40,0
.goto Azshara,40.97,55.00,40,0
.goto Azshara,40.81,62.69,40,0
.goto Azshara,42.95,63.76,40,0
.goto Azshara,38.70,63.30,40,0
.goto Azshara,36.35,58.75,40,0
.goto Azshara,35.92,57.55,40,0
.goto Azshara,34.89,53.93,40,0
.goto Azshara,35.86,53.49,40,0
>>Loot the |cRXP_PICK_Glowing Tablets|r scattered around the ruins
.complete 3517,1 
.complete 3517,2 
.complete 3517,3 
.complete 3517,4 
step
#label SomeRune
#loop
.goto Azshara,44.00,48.20,0
.goto Azshara,44.00,48.20,50,0
.goto Azshara,45.60,43.80,50,0
.goto Azshara,47.00,41.60,50,0
.goto Azshara,48.80,45.00,50,0
.goto Azshara,47.40,49.00,50,0
.goto Azshara,48.20,54.00,50,0
.goto Azshara,48.20,59.80,50,0
.goto Azshara,48.60,64.80,50,0
.goto Azshara,46.20,61.00,50,0
.goto Azshara,45.60,57.80,50,0
.goto Azshara,46.00,52.80,50,0
>>Kill all |cRXP_ENEMY_Spitelash Nagas|r. Loot them for |cRXP_LOOT_Some Rune|r
.complete 5534,1 
.mob Spitelash Myrmidon
.mob Spitelash Enchantress
.mob Spitelash Battlemaster
.mob Spitelash Siren
step
#completewith next
.goto Azshara,45.55,37.79,50 >>Run up the hill to leave the Ruins of Eldarath
step
.goto Azshara,53.45,21.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kim'jael|r
.turnin 5534 >>Turn in Kim'jael's "Missing" Equipment
.target Kim'jael
step
.goto Azshara,22.60,51.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r
.turnin 3517 >>Turn in Stealing Knowledge
.accept 3518 >>Accept Delivery to Magatha
.accept 3541 >>Accept Delivery to Jes'rimon
.accept 3542 >>Accept Delivery to Andron Gant
.accept 3561 >>Accept Delivery to Archmage Xylem
.target Jediga
step
.goto Azshara,22.26,51.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ag'tor|r
.turnin 3506 >>Turn in Betrayed
.accept 3507 >>Accept Betrayed
.target Ag'tor Bloodfist
.isQuestTurnedIn 3505
step
#completewith next
.goto Azshara,28.11,50.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sanath|r
.turnin 3503 >>Turn in Meeting with the Master
.target Sanath Lim-yo
step
.goto Azshara,29.7,40.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Xylem|r
.turnin 3561 >>Turn in Delivery to Archmage Xylem

.target Archmage Xylem
step
#completewith next
.goto Azshara,26.466,46.271
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nyrill|r
>>|cRXP_WARN_This will teleport you back down|r
.turnin 3421 >> Turn in Return Trip
.timer 8,Return Trip RP
.target Nyrill
step
.goto Azshara,22.56,51.42
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jediga|r

.target Jediga
step
#label AzsharaEnd
.goto Azshara,21.96,49.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kroum|r
.fly Splintertree Post >>Fly to Splintertree Post
.target Kroum
.zoneskip Ashenvale
step
.goto Ashenvale,55.78,28.12
.zone Felwood >>Travel to Felwood
.isQuestTurnedIn 3565
step
#completewith next
.goto Felwood,51.53,82.21
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrim|r
.fp Emerald Sanctuary >> Get the Emerald Sanctuary flight path
.target Gorrim
step
.goto Felwood,51.20,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.accept 5155 >>Accept Forces of Jaedenar
.target Greta Mosshoof
step
.goto Felwood,50.90,81.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn|r
.accept 5156 >>Accept Verifying the Corruption
.target Taronn Redfeather
step
.goto Felwood,46.70,83.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maybess|r
.accept 4102 >>Accept Cleansing Felwood
.target Maybess Riverbreeze
step
#completewith next
.subzone 1763 >> Travel to Jaedenar
step
#loop
.goto Felwood,36.49,61.40,0
.goto Felwood,38.55,59.14,50,0
.goto Felwood,36.49,61.40,60,0
.goto Felwood,35.01,59.83,60,0
.goto Felwood,36.49,61.40,60,0
.goto Felwood,38.55,59.14,60,0
.goto Felwood,36.49,61.40,60,0
>>Kill |cRXP_ENEMY_Jaedenar Hounds|r, |cRXP_ENEMY_Guardians|r, |cRXP_ENEMY_Adepts|r and |cRXP_ENEMY_Cultists|r
>>|cRXP_WARN_Be careful of|r |cRXP_ENEMY_Jaedenar Adepts|r|cRXP_WARN_; they have blink, as well as a strong fireball and fire blast|r
.complete 5155,1 
.mob +Jaedenar Hound
.complete 5155,2 
.mob +Jaedenar Guardian
.complete 5155,3 
.mob +Jaedenar Adept
.complete 5155,4 
.mob +Jaedenar Cultist
step
#completewith next
.goto Felwood,37.37,49.83,40,0
.goto Felwood,35.45,50.10,40,0
.goto Felwood,34.57,52.12
.subzone 1997 >> Travel to Bloodvenom Post
step
.goto Felwood,34.80,52.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dreka'Sur|r
.accept 6162 >>Accept A Husband's Last Battle
.target Dreka'Sur
step
.goto Felwood,34.20,52.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Winna|r
.accept 4505 >>Accept Well of Corruption
.target Winna Hazzard
step
.goto Felwood,34.40,53.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakkar|r
.fly Emerald Sanctuary >>Fly to Emerald Sanctuary
.target Brakkar
.zoneskip Felwood,1
step
.goto Felwood,51.20,82.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.turnin 5155 >>Turn in Forces of Jaedenar
.accept 5157 >>Accept Collection of the Corrupt Water
.target Greta Mosshoof
step
.goto Felwood,51.00,85.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grazle|r
.accept 8460 >>Accept Timbermaw Ally
.target Grazle
step
.goto Felwood,51.00,85.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grazle|r
.accept 8460 >>Accept Timbermaw Ally
.target Grazle
step
#completewith next
>>Kill |cRXP_ENEMY_Deadwood Warriors|r, |cRXP_ENEMY_Deadwood Pathfinders|r and |cRXP_ENEMY_Deadwood Gardeners|r
.complete 8460,1 
.mob +Deadwood Warrior
.complete 8460,2 
.mob +Deadwood Pathfinder
.complete 8460,3 
.mob +Deadwood Gardener
step
.goto Felwood,48.20,94.30
>>Kill |cRXP_ENEMY_Overlord Ror|r. Loot him for his |cRXP_LOOT_Claw|r
>>|cRXP_WARN_Clear the area to avoid complications from his AoE fear|r
.complete 6162,1 
.unitscan Overlord Ror
step
#loop
.goto Felwood,48.20,94.30,0
.goto Felwood,48.20,94.30,50,0
.goto Felwood,46.80,91.80,50,0
.goto Felwood,46.60,90.40,50,0
.goto Felwood,46.60,88.60,50,0
.goto Felwood,48.60,89.40,50,0
.goto Felwood,49.20,91.60,50,0
>>Kill |cRXP_ENEMY_Deadwood Warriors|r, |cRXP_ENEMY_Deadwood Pathfinders|r and |cRXP_ENEMY_Deadwood Gardeners|r
.complete 8460,1 
.mob +Deadwood Warrior
.complete 8460,2 
.mob +Deadwood Pathfinder
.complete 8460,3 
.mob +Deadwood Gardener
step
.goto Felwood,51.00,85.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grazle|r
.turnin 8460 >>Turn in Timbermaw Ally
.target Grazle
step
#completewith next
.goto Felwood,36.02,66.99,70,0
.goto Felwood,32.30,66.60,50 >>Travel to the green moonwell in the Ruins of Constellas
step
.goto Felwood,32.30,66.60
.use 12566 >> |cRXP_WARN_Use your|r |T134870:0|t[Hardened Flasket] |cRXP_WARN_in the moonwell|r
>>|cRXP_WARN_There are stealthed |cRXP_ENEMY_Satyrs|r with strong slowing poison in this area. Some of them patrol, so be careful|r
.complete 4505,1 
.unitscan Jadefire Shadowstalker
step
#completewith next
.subzone 1763 >> Travel to Jaedenar
step
#label RepCheck
.goto Felwood,35.20,59.80
.use 12922 >>Use your |T132788:0|t[Empty Canteen] in the green moonwell
>>|cRXP_WARN_Be very careful of Jaedenar Adepts; they have blink, as well as a strong fireball and fire blast|r
.complete 5157,1 
.unitscan Jaedenar Adept
step
#completewith next
.goto Felwood,37.37,49.83,40,0
.goto Felwood,35.45,50.10,40,0
.goto Felwood,34.57,52.12
.subzone 1997 >> Travel to Bloodvenom Post
step
.goto Felwood,34.20,52.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Winna|r
.turnin 4505 >>Turn in Well of Corruption
.accept 4506 >>Accept Corrupted Sabers
.target Winna Hazzard

step
.goto Felwood,34.80,52.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dreka'Sur|r
.turnin 6162 >>Turn in A Husband's Last Battle
.target Dreka'Sur
step
.goto Felwood,34.80,52.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trull|r
.accept 4521 >>Accept Wild Guardians
.target Trull Failbane
step
#optional
#completewith next
>>|cRXP_WARN_Run into a crater|r
.complete 5156,3 
step
#loop
.goto Felwood,40.60,42.40,0
.goto Felwood,40.60,42.40,50,0
.goto Felwood,42.00,37.60,50,0
.goto Felwood,45.60,38.60,50,0
.goto Felwood,44.60,42.60,50,0
>>Kill |cRXP_ENEMY_Entropic Beasts|r and |cRXP_ENEMY_Entropic Horrors|r
>>|cRXP_WARN_They share spawns, so you may have to kill extra of each type|r
.complete 5156,1 
.mob +Entropic Beast
.complete 5156,2 
.mob +Entropic Horror
.complete 5156,3 
step
.goto Felwood,41.20,42.82
>>|cRXP_WARN_Run into a crater|r
.complete 5156,3 
step
#label BloodAmbers
#loop
.goto Felwood,59.2,20.4,0
.goto Felwood,56.6,17.4,40,0
.goto Felwood,57.8,19.2,40,0
.goto Felwood,57.6,21.8,40,0
.goto Felwood,59.2,20.4,40,0
>>Kill |cRXP_ENEMY_Warpwood Moss Flayers|r and |cRXP_ENEMY_Warpwood Shredders|r. Loot them for their |cRXP_LOOT_Blood Ambers|r
.complete 4102,1 
.mob Warpwood Moss Flayer
.mob Warpwood Shredder
step
#completewith next
.goto Felwood,64.70,8.10,70 >>Travel to the the Timbermaw Hold Entrance
step
.goto Felwood,64.70,8.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.accept 8461 >>Accept Deadwood of the North
.target Nafien
step
#label Deadwoods
.goto Felwood,63.19,13.01,0
.goto Felwood,61.67,7.23,50,0
.goto Felwood,62.68,8.39,50,0
.goto Felwood,62.55,10.49,50,0
.goto Felwood,63.19,13.01,50,0
>>Kill |cRXP_ENEMY_Deadwood Den Watchers|r, |cRXP_ENEMY_Deadwood Avengers|r ann |cRXP_ENEMY_Deadwood Shamans|r
>>|cRXP_WARN_Kill|r |cRXP_ENEMY_Deadwood Avengers|r |cRXP_WARN_first. If you multi-pull it will enrage if any furbolgs die nearby|r
.complete 8461,1 
.mob +Deadwood Den Watcher
.complete 8461,2 
.mob +Deadwood Avenger
.complete 8461,3 
.mob +Deadwood Shaman
step
#loop
.goto Felwood,61.67,7.23,50,0
.goto Felwood,62.68,8.39,50,0
.goto Felwood,62.55,10.49,50,0
.goto Felwood,63.19,13.01,50,0
.reputation 576,unfriendly
>>|cRXP_WARN_Do NOT skip this step. You'll need the reputation to travel through Timbermaw Hold safely|r
.mob Deadwood Den Watcher
.mob Deadwood Shaman
.mob Deadwood Avenger
step
.goto Felwood,64.70,8.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nafien|r
.turnin 8461 >>Turn in Deadwood of the North
.accept 8465 >>Accept Speak to Salfa
.target Nafien
step
#completewith next
.goto Felwood,65.37,6.92,20,0
.goto Felwood,64.89,5.82,20,0
.goto Felwood,64.56,3.46,20,0
.goto Felwood,65.41,2.77,20,0
.goto Felwood,65.38,1.08,20,0
.goto Felwood,65.98,0.64,20,0
.goto Kalimdor,52.27,22.95,20,0
.goto Kalimdor,52.33,22.62,20,0
.goto Kalimdor,52.23,22.49,20,0
.goto Kalimdor,52.27,22.35,20,0
.goto Kalimdor,52.33,22.34,20,0
.goto Moonglade,35.74,72.37,20,0
.zone Moonglade >>Enter the tunnel, then take the north exit into Moonglade
.zoneskip Moonglade
.isOnQuest 7066
.dungeon MARA
step
.goto Moonglade,36.178,41.798
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Keeper Remulos|r
.turnin 7066 >> Turn in Seed of Life
.target Keeper Remulos
.isOnQuest 7066
.dungeon MARA
step
#completewith next
.goto Felwood,65.44,2.81,20,0
.goto Felwood,66.51,2.98,20,0
.goto Felwood,67.82,4.33,20,0
.goto Felwood,67.93,5.11,20,0
.zone Winterspring >>Travel through Timbermaw Hold to Winterspring
>>|cRXP_WARN_If you are not Unfriendly with Timbermaw Hold, |cRXP_ENEMY_Furbolgs|r will attack you|r
step
.goto Winterspring,27.736,34.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.turnin 8465 >>Turn in Speak to Salfa
.target Salfa
step
.goto Winterspring,31.269,45.164
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova Snowden|r
.turnin 3908 >>Turn in It's a Secret to Everybody
.timer 36,It's a Secret to Everybody RP
.turnin 980 >>Turn in The New Springs
.accept 5082 >>Accept Threat of the Winterfall
.target Donova Snowden
step
#completewith next
>>Kill |cRXP_ENEMY_Winterfall Furbolgs|r until you loot an |T134865:0|t[|cRXP_LOOT_Empty Firewater Flask|r]. Use it to accept the quest
>>|cRXP_WARN_This has a low droprate and is NOT groupeshared|r
.collect 12771,1,5083 
.accept 5083 >>Accept Winterfall Firewater
.use 12771
.mob Winterfall Pathfinder
.mob Winterfall Den Watcher
.mob Winterfall Totemic
step
#loop
.goto Winterspring,31.00,36.80,0
.goto Winterspring,31.00,36.80,50,0
.goto Winterspring,30.00,35.80,50,0
.goto Winterspring,31.00,34.80,50,0
.goto Winterspring,33.60,37.00,50,0
>>Kill |cRXP_ENEMY_Winterfall Pathfinders|r, |cRXP_ENEMY_Winterfall Den Watchers|r and |cRXP_ENEMY_Winterfall Totemics|r
>>|cRXP_WARN_Clear the southeastern camps if you run out of spawns|r
.complete 5082,1 
.mob +Winterfall Pathfinder
.complete 5082,2 
.mob +Winterfall Den Watcher
.complete 5082,3 
.mob +Winterfall Totemic
step
#loop
.goto Winterspring,39.00,42.80,0
.goto Winterspring,39.00,42.80,50,0
.goto Winterspring,41.80,44.60,50,0
.goto Winterspring,42.40,42.40,50,0
>>Kill |cRXP_ENEMY_Winterfall Furbolgs|r until you loot an |T134865:0|t[|cRXP_LOOT_Empty Firewater Flask|r]. Use it to accept the quest
>>|cRXP_WARN_This has a low droprate and is NOT groupeshared|r
.collect 12771,1,5083 
.accept 5083 >>Accept Winterfall Firewater
.use 12771
.mob Winterfall Pathfinder
.mob Winterfall Den Watcher
.mob Winterfall Totemic
step
.goto Winterspring,31.30,45.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova|r
.turnin 5082 >>Turn in Threat of the Winterfall
.turnin 5083 >>Turn in Winterfall Firewater
.accept 5084 >>Accept Falling to Corruption
.target Donova Snowden
step
#completewith next
.goto Felwood,68.73,6.38,40,0
.goto Felwood,68.24,5.60,40,0
.goto Felwood,66.40,2.95,40,0
.goto Felwood,64.67,3.14,40,0
.goto Felwood,65.16,7.88,40,0
.zone Felwood >>Travel through Timbermaw Hold to Felwood
step
.goto Felwood,60.20,5.90
>>Click the |cRXP_PICK_Deadwood Cauldron|r
>>|cRXP_WARN_This is an instant cast. You can run away from the |cRXP_ENEMY_Deadwood Furbolgs|r after turning it in|r
.turnin 5084 >>Turn in Falling to Corruption
.accept 5085 >>Accept Mystery Goo
step
#completewith next
.goto Felwood,65.16,7.88,40,0
.goto Felwood,64.67,3.14,40,0
.goto Felwood,66.40,2.95,40,0
.goto Felwood,68.24,5.60,40,0
.goto Felwood,68.73,6.38
.zone Winterspring >>Travel through Timbermaw Hold to Winterspring
step
.goto Winterspring,31.30,45.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova|r
.turnin 5085 >>Turn in Mystery Goo
.accept 5086 >>Accept Toxic Horrors
.accept 4842 >>Accept Strange Sources
.target Donova Snowden
step
#completewith BankVials
.subzone 2255 >> Travel to Everlook
step
#completewith BankVials
>>Kill |cRXP_ENEMY_Ragged Owlbeasts|r on your way to Everlook
.complete 4521,2 
.mob Ragged Owlbeast
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gregor Greystone|r and |cRXP_FRIENDLY_Jessica Redpath|r
.accept 6029 >> Accept The Everlook Report
.accept 6030 >> Accept Duke Nicholas Zverenhoff
.target +Gregor Greystone
.goto Winterspring,61.348,38.973
.accept 5601 >> Accept Sister Pamela
.goto Winterspring,61.281,38.981
.target +Jessica Redpath
step
.goto Winterspring,61.60,38.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felnok|r
.turnin 4808 >>Turn in Felnok Steelspring
.target Felnok Steelspring
.isOnQuest 4808
step
#label BankVials
.goto Winterspring,61.45,36.97
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Izzy Coppergrab|r
.bankdeposit 10691,10692,10693,10694 >>Put the following on the bank:
>>|T134815:0|t[Filled Vial Labeled #1]
>>|T134822:0|t[Filled Vial Labeled #2]
>>|T134836:0|t[Filled Vial Labeled #3]
>>|T134857:0|t[Filled Vial Labeled #4]
.target Izzy Coppergrab
.isOnQuest 3568
step << Hunter
#completewith next
.goto Winterspring,60.389,37.917
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azzleby|r
.stable >> Stable your pet. You will tame a |cRXP_ENEMY_Shardtooth Bear|r or |cRXP_ENEMY_Winterspring Owl|r shortly
.target Azzleby
step << Hunter
#loop
.goto Winterspring,53.27,37.30,0
.goto Winterspring,51.64,38.87,0
.goto Winterspring,45.47,37.40,0
.goto Winterspring,53.27,37.30,70,0
.goto Winterspring,51.64,38.87,70,0
.goto Winterspring,45.47,37.40,70,0
>>|cRXP_WARN_Cast|r |T132164:0|t[Tame Beast] |cRXP_WARN_on a |cRXP_ENEMY_Shardtooth Bear|r or |cRXP_ENEMY_Winterspring Owl|r to tame it|r 
.train 2977 >>|cRXP_WARN_Attack mobs with it to learn|r |T132140:0|t[Claw (Rank 7)]
.link https://www.wow-petopia.com/classic/training.php >> |cRXP_WARN_Click here for more info about pet training|r
.mob Shardtooth Bear
.mob Winterspring Owl
.zoneskip Winterspring,1
step << Hunter
.goto Winterspring,60.389,37.917
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azzleby|r
.stable >> Abandon the |cRXP_ENEMY_Shardtooth Bear|r or |cRXP_ENEMY_Winterspring Owl|r and retrieve your regular pet
.target Azzleby
.train 2977,3
.zoneskip Winterspring,1
step
#label FlyFelwood1
#completewith next
.goto Winterspring,60.47,36.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yugrek|r
.fp Everlook >>Get the Everlook Flight Path
.fly Emerald Sanctuary >>Fly to Emerald Sanctuary
.target Yugrek
.zoneskip Felwood
step
.goto Felwood,51.20,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.turnin 5157 >>Turn in Collection of the Corrupt Water
.accept 5158 >>Accept Seeking Spiritual Aid
.target Greta Mosshoof
step
.goto Felwood,50.90,81.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Taronn|r
.turnin 5156 >>Turn in Verifying the Corruption
.target Taronn Redfeather
step
#completewith next
.hs >>Hearth to Ratchet
.use 6948
.bindlocation 392,1
.subzoneskip 392
step
.goto The Barrens,65.80,43.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Islen|r
.turnin 5158 >>Turn in Seeking Spiritual Aid
.timer 48,Seeking Spiritual Aid RP
.target Islen Waterseer
step
.goto The Barrens,65.80,43.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Islen|r
>>|cRXP_WARN_Wait for the RP to finish|r
.accept 5159 >>Accept Cleansed Water Returns to Felwood
.target Islen Waterseer
step << !Mage
#completewith AzsharaFWWSend
.goto Felwood,51.5,82.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrim|r
.fly Orgrimmar >>Fly to Orgrimmar
.target Gorrim
.zoneskip Orgrimmar
step
#optional
#label AzsharaFWskip
step << !Mage
#optional
.goto Un'Goro Crater,43.16,6.24,30,0
.goto Un'Goro Crater,45.23,5.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tExit the cave, then talk to |cRXP_FRIENDLY_Gryfe|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Gryfe
.zoneskip Un'Goro Crater,1
.dungeon ST
step << !Mage
#optional
.goto Tanaris,51.60,25.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Bulkrek Ragefist
.zoneskip Tanaris,1
.dungeon ST
step << !Mage
#completewith AzsharaFWWSend
.goto The Barrens,63.09,37.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bragok|r
.fly Orgrimmar >> Fly to Orgrimmar
.target Bragok
.zoneskip The Barrens,1
step << Mage
#completewith AzsharaFWWSend
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step
#completewith AzsharaFWWSend
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warcaller Gorlach|r
>>|cRXP_WARN_He walks all around Orgrimmar. If you can't find him, skip it|r
.accept 5093 >>Accept A Call to Arms: The Plaguelands!
.unitscan Warcaller Gorlach
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10199 >> Train your class spells
.target Pephredo
.xp <54,1
.xp >56,1
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10157 >> Train your class spells
.target Pephredo
.xp <56,1
.xp >58,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10161 >> Train your class spells
.target Pephredo
.xp <58,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10929 >> Train your class spells
.target Ur'kyo
.xp <54,1
.xp >56,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10947 >> Train your class spells
.target Ur'kyo
.xp <56,1
.xp >58,1
step << Priest
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10900 >> Train your class spells
.target Ur'kyo
.xp <58,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10408 >> Train your class spells
.target Kardris Dreamseeker
.xp <54,1
.xp >56,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10432 >> Train your class spells
.target Kardris Dreamseeker
.xp <56,1
.xp >58,1
step << Shaman
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10473 >> Train your class spells
.target Kardris Dreamseeker
.xp <58,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 10329 >> Train your class spells
.target Master Pyreanor
.xp <54,1
.xp >56,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 10301 >> Train your class spells
.target Master Pyreanor
.xp <56,1
.xp >58,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 19943 >> Train your class spells
.target Master Pyreanor
.xp <58,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11294 >> Train your class spells
.target Ormok
.xp <54,1
.xp >56,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11300 >> Train your class spells
.target Ormok
.xp <56,1
.xp >58,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11305 >> Train your class spells
.target Ormok
.xp <58,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11672 >> Train your class spells
.target Mirket
.xp <54,1
.xp >56,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11689 >> Train your class spells
.target Mirket
.xp <56,1
.xp >58,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11713 >> Train your class spells
.target Mirket
.xp <58,1
step
.goto Orgrimmar,55.52,34.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jes'rimon|r
>>|cRXP_WARN_He is located at the top of the building|r
.turnin 4300 >>Turn in Bone-Bladed Weapons
.turnin 3541 >>Turn in Delivery to Jes'rimon

.target Jes'rimon
.isOnQuest 3541
step
#optional
.goto Orgrimmar,55.52,34.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jes'rimon|r
>>|cRXP_WARN_He is located at the top of the building|r
.turnin 4300 >>Turn in Bone-Bladed Weapons

.target Jes'rimon
.isQuestTurnedIn 3541
step
#optional
.goto Orgrimmar,55.60,34.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jes'rimon|r
>>|cRXP_WARN_He is located at the top of the building|r
.turnin 4300 >>Turn in Bone-Bladed Weapons
.target Jes'rimon
step
.goto Orgrimmar,75.20,34.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Belgrom|r
.turnin 3507 >>Turn in Betrayed
.target Belgrom Rockmaul
.isOnQuest 3507
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11556 >> Train your class spells
.target Grezz Ragefist
.xp <54,1
.xp >56,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 20662 >> Train your class spells
.target Grezz Ragefist
.xp <56,1
.xp >58,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11597 >> Train your class spells
.target Grezz Ragefist
.xp <58,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14290 >> Train your class spells
.target Ormak Grimshot
.xp <54,1
.xp >56,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14305 >> Train your class spells
.target Ormak Grimshot
.xp <56,1
.xp >58,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14322 >> Train your class spells
.target Ormak Grimshot
.xp <58,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24631 >> Train your pet spells
.target Xao'tsu
.xp <54,1
step
.goto Orgrimmar,49.57,69.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Karus|r
.bankwithdraw 8529 >>Withdraw |T134863:0|t[Noggenfogger Elixir] from your bank if you have any. Have at least 40 in your bags for a mountain skip in EPL
>>|cRXP_WARN_Alternatively,|r |T132917:0|t[Light Feathers] |cRXP_WARN_will also work for|r |T135992:0|t[Slow Fall] << Mage
.target Karus
step << !Mage
.goto Orgrimmar,54.10,68.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Innkeeper Gryshka|r
.home >>Set your Hearthstone to Orgrimmar
.target Innkeeper Gryshka
.bindlocation 1637
step
#optional
.abandon 3507 >>Abandon Betrayed
step
#optional
#label AzsharaFWWSend
step
#loop
.goto Orgrimmar,52.43,78.40,0
.goto Orgrimmar,52.43,78.40,50,0
.goto Orgrimmar,49.82,59.40,50,0
.goto Orgrimmar,57.23,58.28,50,0
.goto Orgrimmar,59.32,40.80,50,0
.goto Orgrimmar,49.84,36.47,50,0
.goto Orgrimmar,42.66,36.82,50,0
.goto Orgrimmar,38.79,52.78,50,0
.goto Orgrimmar,49.48,48.23,50,0
.goto Orgrimmar,39.29,53.00,50,0
.goto Orgrimmar,42.33,67.69,50,0
.goto Orgrimmar,37.48,76.82,50,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warcaller Gorlach|r
>>|cRXP_WARN_He walks all around Orgrimmar. If you can't find him, skip it|r
.accept 5093 >>Accept A Call to Arms: The Plaguelands!
.unitscan Warcaller Gorlach
step
#ah
.goto Orgrimmar,55.59,62.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Auctioneer Thathung|r
>>|cRXP_BUY_Buy the following items from the Auction House. You will need these later for multiple free quest turn ins in EPL|r
>>|cRXP_WARN_There are 5 different quests and each require 30. If you can't get 30 of one type then skip it|r
>>|cRXP_WARN_Don't take these out of your mailbox yet|r
.collect 22529,30,9136,1 
.collect 22526,30,9126,1 
.collect 22525,30,9124,1 
.collect 22527,30,9128,1 
.collect 22528,30,9131,1 
.collect 12359,2,6026,1 
.collect 11128,1,6026,1 
.collect 10562,8,6026,1 
.collect 10560,8,6026,1 
.target Auctioneer Thathung
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 56-59 Western/Eastern Plaguelands
#next 59-60 Hellfire Peninsula part 1
step << Mage
#completewith Bulwark1
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << Mage
.goto Undercity,82.79,15.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannah Akeley|r
>>|cRXP_BUY_Buy at least two|r |T134419:0|t[Rune of Teleportation]
.collect 17031,2,5096,1 
.target Hannah Akeley
step << !Mage
#completewith next
.zone Durotar >> Leave Orgrimmar
.zoneskip Durotar
step << !Mage
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Tirisfal Glades >>Take the Zeppelin to Tirisfal Glades
.zoneskip Tirisfal Glades
step << Mage
#completewith Bulwark1
.goto Tirisfal Glades,61.92,64.85
.zone Tirisfal Glades >> Exit Undercity
.zoneskip Undercity,1
step
#completewith Bulwark1
.subzone 152 >>Travel to the Bulwark
step
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5093 >>Turn in A Call to Arms: The Plaguelands!
.accept 5096 >>Accept Scarlet Diversions
.target High Executor Derrington
.isOnQuest 5093
step
#optional
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.accept 5096 >>Accept Scarlet Diversions
.target High Executor Derrington
step
.goto Western Plaguelands,26.55,56.18
>>Click the |cRXP_PICK_Box of Incendiaries|r by the fire
.collect 12814,1,5096,1 
step
.goto Tirisfal Glades,83.19,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garush|r
.turnin 6029 >>Turn in The Everlook Report
.target Argent Officer Garush
.isOnQuest 6029
step
.goto Tirisfal Glades,83.19,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garush|r
.turnin 5405 >>Turn in Argent Dawn Commission
.target Argent Officer Garush
.itemcount 12846,<1
step
.goto Tirisfal Glades,83.2,71.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mehlar Dawnblade|r
.accept 9443 >>Accept The So-Called Mark of the Lightbringer
.target Mehlar Dawnblade
.group
step
#label Bulwark1
.goto Tirisfal Glades,83.30,72.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mickey|r
.accept 5901 >>Accept A Plague Upon Thee
.target Mickey Levine
step
#completewith next
+|cRXP_WARN_Equip your|r |T133440:0|t[Argent Dawn Commission] |cRXP_WARN_trinket|r
.use 12846
.itemcount 12846,1
step
.goto Western Plaguelands,40.5,51.8
.use 12807 >>Click the |cRXP_PICK_Command Tent|r, then use your |T132484:0|t[Scourge Banner]
>>|cRXP_WARN_These mobs are relatively difficult and can chain-pull each other, so be careful|r
.complete 5096,1 
step
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5096 >>Turn in Scarlet Diversions
.accept 5098 >>Accept All Along the Watchtowers
.accept 5228 >>Accept The Scourge Cauldrons
.target High Executor Derrington
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5228 >>Turn in The Scourge Cauldrons
.accept 5229 >>Accept Target: Felstone Field
.target Shadow Priestess Vandis
step
.goto Western Plaguelands,37.12,57.18
>>Kill |cRXP_ENEMY_Cauldron Lord Bilemaw|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
.complete 5229,1 
.unitscan Cauldron Lord Bilemaw
step
.goto Western Plaguelands,37.2,56.8
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
.turnin 5229 >>Turn in Target: Felstone Field
.accept 5230 >>Accept Return to the Bulwark
step
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice|r on the 2nd floor
>>|cRXP_WARN_You can talk to her from outside at the back of the building|r
.accept 5021 >>Accept Better Late Than Never
.target Janice Felstone
step
#label FelstoneField
.goto Western Plaguelands,38.8,55.3
>>Click |cRXP_PICK_Janice's Parcel|r in the barn
>>|cRXP_WARN_You can click it through the hallway wall if you want to skip the mobs inside|r
.turnin 5021 >>Turn in Better Late Than Never
.accept 5023 >>Accept Better Late Than Never
step
#completewith next
.subzone 152 >> Return to The Bulwark
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5230 >>Turn in Return to the Bulwark
.accept 5231 >>Accept Target: Dalson's Tears
.target Shadow Priestess Vandis
step
.goto Western Plaguelands,42.28,66.05
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway

.complete 5098,2 
step
.goto Western Plaguelands,46.04,52.33
>>Kill |cRXP_ENEMY_Cauldron Lord Malvinious|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
.complete 5231,1 
.unitscan Cauldron Lord Malvinious
step
.goto Western Plaguelands,46.2,52.0
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
.turnin 5231 >>Turn in Target: Dalson's Tears
.accept 5232 >>Accept Return to the Bulwark
step
.goto Western Plaguelands,47.8,50.6
>>Click |cRXP_PICK_Mrs. Dalson's Diary|r
.turnin 5058 >>Turn in Mrs. Dalson's Diary
step
.goto Western Plaguelands,47.49,51.00
>>Kill the |cRXP_ENEMY_Wandering Skeleton|r. Loot it for its |cRXP_LOOT_Outhouse Key|r
>>|cRXP_WARN_Grind Bone Fragments if the skeleton isn't spawned|r
.collect 12738,1 
.unitscan Wandering Skeleton
step
#completewith next
.goto Western Plaguelands,48.2,49.7
>>Click the |cRXP_PICK_Outhouse|r
.turnin 5059 >>Turn in Locked Away
step
.goto Western Plaguelands,48.2,49.7
>>Kill |cRXP_ENEMY_Farmer Dalson|r. Loot him for his |cRXP_LOOT_Cabinet Key|r
.collect 12739,1,5060 
.unitscan Farmer Dalson
step
.goto Western Plaguelands,47.4,49.7
>>Click the |cRXP_PICK_Locked Cabinet|r on the top floor of the house
.turnin 5060 >>Turn in Locked Away
step
#label TowerOne
.goto Western Plaguelands,40.15,71.50
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway

.complete 5098,1 
step
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.accept 4971 >>Accept A Matter of Time
.target Chromie
step
.goto Western Plaguelands,44.24,63.06
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway

.complete 5098,3 
step
.goto Western Plaguelands,45.8,63.3
.use 12627 >>Spawn the |cRXP_ENEMY_Temporal Parasites|r by using your |T134229:0|t[Temporal Displacer] near the glowing silos
>>|cRXP_WARN_Temporal Parasites spam Slow and can spawn more parasites upon death. Be ready to run to the water if they begin overwhelming you; they cannot swim|r
.complete 4971,1 
.mob Temporal Parasite
step
.goto Western Plaguelands,46.73,71.14
.use 12815 >>Use your |T135432:0|t[Beacon Torch] on the outside corner of the tower's doorway

.complete 5098,4 
step
#completewith next
.goto Western Plaguelands,65.23,86.30,0
.goto Western Plaguelands,65.23,86.30,40,0
.goto The Hinterlands,22.32,27.19,30,0
.goto The Hinterlands,24.37,31.09,30,0
.goto The Hinterlands,23.91,33.27,30,0
.goto The Hinterlands,24.44,36.69,30,0
.goto The Hinterlands,23.87,38.59,30,0
.goto The Hinterlands,24.70,44.70,60 >> Travel south east along a path into The Hinterlands. Follow the waypoint for directions
.zoneskip The Hinterlands
.dungeon ST
step
.goto The Hinterlands,33.751,75.210
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Atal'ai Exile|r
.turnin 1446 >> Turn in Jammal'an the Prophet
.target Atal'ai Exile
.isQuestComplete 1446
.dungeon ST
step
#completewith next
.goto The Hinterlands,24.70,44.70,0
.goto The Hinterlands,24.70,44.70,60,0
.goto The Hinterlands,23.87,38.59,30,0
.goto The Hinterlands,24.44,36.69,30,0
.goto The Hinterlands,23.91,33.27,30,0
.goto The Hinterlands,24.37,31.09,30,0
.goto The Hinterlands,22.32,27.19,30,0
.goto Western Plaguelands,65.23,86.30,40 >> Return to the Western Plaguelands
.zoneskip Western Plaguelands
.isQuestTurnedIn 1446
.dungeon ST
step
#completewith next
.subzone 152 >> Return to The Bulwark
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5232 >>Turn in Return to the Bulwark
.accept 5233 >>Accept Target: Writhing Haunt
.target Shadow Priestess Vandis
step
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5098 >>Turn in All Along the Watchtowers
.accept 838 >>Accept Scholomance
.target High Executor Derrington
step
#optional
#completewith SkeletalFragments
.destroy 12815 >>|cRXP_WARN_Destroy the|r |T135432:0|t[Beacon Torch] |cRXP_WARN_as you no longer need it|r
step
.goto Tirisfal Glades,83.28,69.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dithers|r
.turnin 838 >>Turn in Scholomance
.accept 964 >>Accept Skeletal Fragments
.target Apothecary Dithers
step
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.turnin 4971 >>Turn in A Matter of Time
.accept 4972 >>Accept Counting Out Time
.target Chromie
step
#completewith next
>>Loot the |cRXP_PICK_Small Lockboxes|r in the ruined buildings for |cRXP_LOOT_Andorhal Watches|r
.complete 4972,1 
.isOnQuest 4972
step
#label SkeletalFragments
#loop
.goto Western Plaguelands,46.40,70.00,0
.goto Western Plaguelands,46.40,70.00,50,0
.goto Western Plaguelands,45.60,72.20,50,0
.goto Western Plaguelands,42.60,71.40,50,0
.goto Western Plaguelands,41.60,73.20,50,0
.goto Western Plaguelands,38.80,71.00,50,0
.goto Western Plaguelands,38.80,68.20,50,0
.goto Western Plaguelands,40.40,66.40,50,0
.goto Western Plaguelands,42.60,70.00,50,0
.goto Western Plaguelands,43.40,64.40,50,0
.goto Western Plaguelands,45.80,65.80,50,0
>>Kill all |cRXP_ENEMY_Skeletons|r in Andorhal. Loot them for their |cRXP_LOOT_Fragments|r
>>|cRXP_ENEMY_Skeletal Executioners|r |cRXP_WARN_can execute|r
.complete 964,1 
.mob Skeletal Executioner
.mob Skeletal Acolyte
.mob Skeletal Warlord
.mob Skeletal Sorcerer
.mob Skeletal Flayer
.mob Skeletal Terror
step
#loop
.goto Western Plaguelands,40.40,66.50,0
.goto Western Plaguelands,40.40,66.50,30,0
.goto Western Plaguelands,38.90,68.10,30,0
.goto Western Plaguelands,41.30,69.80,30,0
.goto Western Plaguelands,42.80,73.90,30,0
.goto Western Plaguelands,43.60,73.40,30,0
.goto Western Plaguelands,45.10,73.70,30,0
.goto Western Plaguelands,46.50,73.00,30,0
.goto Western Plaguelands,44.80,70.50,30,0
.goto Western Plaguelands,42.90,68.50,30,0
.goto Western Plaguelands,40.90,67.20,30,0
>>Loot the |cRXP_PICK_Small Lockboxes|r in the ruined buildings for |cRXP_LOOT_Andorhal Watches|r
.complete 4972,1 
.isOnQuest 4972
step
.goto Western Plaguelands,53.07,65.97
>>Kill |cRXP_ENEMY_Cauldron Lord Razarch|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_have a 5-second long, instant cast AoE stun|r
.complete 5233,1 
.unitscan Cauldron Lord Razarch
step
.goto Western Plaguelands,53.0,65.7
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_have a 5-second long, instant cast AoE stun|r
.turnin 5233 >>Turn in Target: Writhing Haunt
.accept 5234 >>Accept Return to the Bulwark
step
#label WildlifePU
.goto Western Plaguelands,53.73,64.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mulgris|r inside the house
>>|cRXP_ENEMY_Freezing Ghouls|r |cRXP_WARN_have a 5-second long, instant cast AoE stun|r
.accept 4984 >>Accept The Wildlife Suffers Too
.target Mulgris Deepriver
step
#completewith Businessman
>>Kill |cRXP_ENEMY_Diseased Wolves|r
>>|cRXP_ENEMY_Diseased Wolves|r |cRXP_WARN_share spawns with|r |cRXP_ENEMY_Carrion Lurkers|r|cRXP_WARN_. If necessary, kill them to reset the area|r
.complete 4984,1 
.unitscan Diseased Wolf
step
.goto Western Plaguelands,51.92,28.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta|r
.accept 6004 >>Accept Unfinished Business
.target Kirsta Deepshadow
step
#completewith next
.goto Western Plaguelands,50.43,41.12,70,0
.goto Western Plaguelands,53.50,36.85,70,0
.goto Western Plaguelands,50.43,41.12,70,0
>>Kill |cRXP_ENEMY_Scarlet Mages|r and |cRXP_ENEMY_Scarlet Knights|r
>>|cRXP_WARN_The|r |cRXP_ENEMY_Mages|r |cRXP_WARN_and|r |cRXP_ENEMY_Knights|r |cRXP_WARN_share respawns. If necessary, kill extra mobs to reset the area|r
.complete 6004,3 
.mob +Scarlet Mage
.complete 6004,4 
.mob +Scarlet Knight
step
.goto Western Plaguelands,51.77,44.13,70,0
.goto Western Plaguelands,40.83,52.30,70,0
.goto Western Plaguelands,47.35,51.54,0
.goto Western Plaguelands,51.77,44.13
>>Kill |cRXP_ENEMY_Scarlet Medics|r and |cRXP_ENEMY_Scarlet Hunters|r
>>|cRXP_ENEMY_Medics|r |cRXP_WARN_and|r |cRXP_ENEMY_Hunters|r |cRXP_WARN_can be found in the camps. If necessary, kill extra mobs to reset the area|r
.complete 6004,1 
.mob +Scarlet Medic
.complete 6004,2 
.mob +Scarlet Hunter
step
.goto Western Plaguelands,50.43,41.12,70,0
.goto Western Plaguelands,53.50,36.85,70,0
.goto Western Plaguelands,50.43,41.12
>>Finish killing |cRXP_ENEMY_Scarlet Mages|r and |cRXP_ENEMY_Scarlet Knights|r
>>|cRXP_WARN_The|r |cRXP_ENEMY_Mages|r |cRXP_WARN_and|r |cRXP_ENEMY_Knights|r |cRXP_WARN_share respawns. If necessary, kill extra mobs to reset the area|r
.complete 6004,3 
.mob +Scarlet Mage
.complete 6004,4 
.mob +Scarlet Knight
step
.goto Western Plaguelands,51.92,28.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta|r
.turnin 6004 >>Turn in Unfinished Business
.accept 6023 >>Accept Unfinished Business
.target Kirsta Deepshadow
step
.goto Western Plaguelands,57.83,36.10
>>Kill |cRXP_ENEMY_Huntsman Radley|r
>>|cRXP_WARN_The mobs around her can chain pull easily. The Spellbinders cast Frost Nova|r
.complete 6023,1 
.unitscan Huntsman Radley
step
.goto Western Plaguelands,54.64,23.71
>>Kill |cRXP_ENEMY_Cavalier Durgen|r
>>|cRXP_WARN_This encounter is much more safe if you wait for him to patrol out of the tower before pulling. He has a 5 second, instant cast stun|r
.complete 6023,2 
.unitscan Cavalier Durgen
step
#label crusader
.goto Western Plaguelands,55.1,23.5
>>Loot the |cRXP_PICK_Holy Coffer|r at the top of the tower for |cRXP_LOOT_Mark of the Lightbringer|r
>>|cRXP_WARN_The |cRXP_ENEMY_Scarlet High Clerist|r (63 elite) may be up. Skip this quest if needed|r
.complete 9443,1 
.unitscan Scarlet High Clerist
.group 2
step
.goto Western Plaguelands,51.92,28.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta|r
.turnin 6023 >>Turn in Unfinished Business
.accept 6025 >>Accept Unfinished Business
.target Kirsta Deepshadow
.group
step
#label Businessman
.goto Western Plaguelands,51.92,28.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kirsta|r
.turnin 6023 >>Turn in Unfinished Business
.target Kirsta Deepshadow
step
#loop
.goto Western Plaguelands,46.80,39.60,0
.goto Western Plaguelands,46.80,39.60,70,0
.goto Western Plaguelands,45.80,46.40,70,0
.goto Western Plaguelands,43.40,54.80,70,0
.goto Western Plaguelands,46.00,59.20,70,0
.goto Western Plaguelands,51.60,61.60,70,0
.goto Western Plaguelands,51.00,53.20,70,0
.goto Western Plaguelands,50.00,46.60,70,0
.goto Western Plaguelands,47.80,43.40,70,0
>>Kill |cRXP_ENEMY_Diseased Wolves|r
>>|cRXP_ENEMY_Diseased Wolves|r |cRXP_WARN_share spawns with|r |cRXP_ENEMY_Carrion Lurkers|r|cRXP_WARN_. If necessary, kill them to reset the area|r
.complete 4984,1 
.unitscan Diseased Wolf
step
.goto Western Plaguelands,53.73,64.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mulgris|r
.turnin 4984 >>Turn in The Wildlife Suffers Too
.accept 4985 >>Accept The Wildlife Suffers Too
.target Mulgris Deepriver
step
#loop
.goto Western Plaguelands,56.08,63.26,0
.goto Western Plaguelands,56.08,63.26,90,0
.goto Western Plaguelands,60.15,59.93,90,0
.goto Western Plaguelands,59.43,52.40,90,0
.goto Western Plaguelands,68.18,46.23,90,0
>>Kill |cRXP_ENEMY_Diseased Grizzlies|r
>>|cRXP_ENEMY_Diseased Grizzlies|r |cRXP_WARN_share spawns with|r |cRXP_ENEMY_Plague Lurkers|r|cRXP_WARN_. If necessary, kill them to reset the area|r
.complete 4985,1 
.unitscan Diseased Grizzly
step
#completewith next
.goto Eastern Plaguelands,7.59,43.57,50 >> Travel toward |cRXP_FRIENDLY_Tirion|r in the Eastern Plaguelands
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.accept 5542 >>Accept Demon Dogs
.accept 5543 >>Accept Blood Tinged Skies
.accept 5544 >>Accept Carrion Grubbage
.target Tirion Fordring
step
#completewith WormMeat
>>Kill |cRXP_ENEMY_Carrion Worms|r. Loot them for their |cRXP_LOOT_Meat|r
.complete 5544,1 
.mob Carrion Grub
.mob Carrion Worm
.mob Carrion Devourer
step
#completewith Pamela
>>Kill |cRXP_ENEMY_Plaguebats|r and |cRXP_ENEMY_Plaguehound Runts|r
.complete 5543,1 
.mob +Plaguebat
.complete 5542,1 
.mob +Plaguehound Runt
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.accept 6022 >>Accept To Kill With Purpose
.accept 6042 >>Accept Un-Life's Little Annoyances
.accept 6133 >>Accept The Ranger Lord's Behest
.target Nathanos Blightcaller
.group
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.accept 6022 >>Accept To Kill With Purpose
.accept 6042 >>Accept Un-Life's Little Annoyances
.target Nathanos Blightcaller
step
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.turnin 5601 >>Turn in Sister Pamela
.accept 5149 >>Accept Pamela's Doll
.target Pamela Redpath
.isOnQuest 5601
step
#optional
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.accept 5149 >>Accept Pamela's Doll
.target Pamela Redpath
.isQuestTurnedIn 5601
step
.goto Eastern Plaguelands,38.10,92.24
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12886,1,5149,1 
.unitscan Ghost of the Past
.isOnQuest 5149
step
.goto Eastern Plaguelands,39.64,92.51
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12887,1,5149,1 
.unitscan Ghost of the Past
.isOnQuest 5149
step
.goto Eastern Plaguelands,39.67,90.24
>>Loot the 3 |cRXP_PICK_Doll Parts|r on the floor in ruined buildings
>>|cRXP_WARN_Clicking the doll pieces can spawn a few|r |cRXP_ENEMY_Ghosts of the Past|r |cRXP_WARN_which have ice armor and frost shock|r
.collect 12888,1,5149,1 
.unitscan Ghost of the Past
.isOnQuest 5149
step
.goto Eastern Plaguelands,36.47,90.80
.use 12886 >>|cRXP_WARN_Click|r |T134164:0|t[Pamela's Doll's Head] |cRXP_WARN_to combine the three pieces|r
.complete 5149,1 
.isOnQuest 5149
step
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.turnin 5149 >>Turn in Pamela's Doll
.accept 5152 >>Accept Auntie Marlene
.accept 5241 >>Accept Uncle Carlin
.target Pamela Redpath
.isQuestComplete 5149
step
#optional
.goto Eastern Plaguelands,36.47,90.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pamela|r
.accept 5152 >>Accept Auntie Marlene
.accept 5241 >>Accept Uncle Carlin
.target Pamela Redpath
.isQuestTurnedIn 5149
step
#optional
#label Pamela
step
#loop
.goto Eastern Plaguelands,34.16,82.21,0
.goto Eastern Plaguelands,40.09,82.83,70,0
.goto Eastern Plaguelands,43.06,82.47,70,0
.goto Eastern Plaguelands,43.97,74.96,70,0
.goto Eastern Plaguelands,36.35,69.28,70,0
.goto Eastern Plaguelands,30.46,70.17,70,0
.goto Eastern Plaguelands,19.69,68.12,70,0
.goto Eastern Plaguelands,18.24,77.03,70,0
.goto Eastern Plaguelands,24.94,70.55,70,0
.goto Eastern Plaguelands,31.20,72.10,70,0
.goto Eastern Plaguelands,34.16,82.21,70,0
>>Kill |cRXP_ENEMY_Plaguebats|r and |cRXP_ENEMY_Plaguehound Runts|r
.complete 5543,1 
.mob +Plaguebat
.complete 5542,1 
.mob +Plaguehound Runt
step
#completewith next
>>Kill |cRXP_ENEMY_Plaguehound|r and |cRXP_ENEMY_Noxious Plaguebats|r
.complete 5542,2 
.mob +Plaguehound
.complete 6042,1 
.mob +Noxious Plaguebat
step
#completewith RottingUndead
.subzone 2264 >> Travel to Corrin's Crossing
step
#completewith next
>>Kill |cRXP_ENEMY_Undead|r. Loot them for their |cRXP_LOOT_Living Rot|r.
>>|cRXP_WARN_Groups of elites patrol the north and east road. Invisible mobs patrol inside of Corrin's Crossing, so try to pull mobs out|r
.collect 15447,7 
.mob Hate Shrieker
.mob Scourge Warder
.mob Stitched Horror
.mob Gibbering Ghoul
.mob Unseen Servant
.mob Dark Caster
step
#label RottingUndead
#loop
.goto Eastern Plaguelands,58.20,70.20,0
.goto Eastern Plaguelands,58.20,70.20,25,0
.goto Eastern Plaguelands,60.40,71.60,25,0
.goto Eastern Plaguelands,61.00,69.40,25,0
.goto Eastern Plaguelands,61.40,66.40,25,0
.goto Eastern Plaguelands,59.40,66.40,25,0
.goto Eastern Plaguelands,58.00,67.60,25,0
.use 15454 >>|cRXP_WARN_Use the|r |T133748:0|t[Mortar and Pestle] |cRXP_WARN_before the |cRXP_LOOT_Living Rot|r expires|r
.complete 6022,1 
step
#loop
.goto Eastern Plaguelands,77.94,69.64,0
.goto Eastern Plaguelands,46.14,65.32,70,0
.goto Eastern Plaguelands,49.24,61.48,70,0
.goto Eastern Plaguelands,50.26,54.66,70,0
.goto Eastern Plaguelands,55.24,54.72,70,0
.goto Eastern Plaguelands,61.47,61.92,70,0
.goto Eastern Plaguelands,65.18,70.17,70,0
.goto Eastern Plaguelands,69.94,72.99,70,0
.goto Eastern Plaguelands,72.99,75.98,70,0
.goto Eastern Plaguelands,77.94,69.64,70,0
>>Kill |cRXP_ENEMY_Plaguehound|r and |cRXP_ENEMY_Noxious Plaguebats|r
.complete 5542,2 
.mob +Plaguehound
.complete 6042,1 
.mob +Noxious Plaguebat
step
#completewith LHFP
.subzone 2268 >> Travel to Light's Hope Chapel
step
.goto Eastern Plaguelands,81.44,59.81
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nicholas|r
.turnin 6030 >>Turn in Duke Nicholas Zverenhoff
.target Duke Nicholas Zverenhoff
.isOnQuest 6030
step
.goto Eastern Plaguelands,81.51,59.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin|r
.turnin 5241 >>Turn in Uncle Carlin
.accept 5211 >>Accept Defenders of Darrowshire
.target Carlin Redpath
.isQuestTurnedIn 5149
step
#optional
.goto Eastern Plaguelands,81.51,59.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin|r
.turnin 5241 >>Turn in Uncle Carlin
.target Carlin Redpath
.isQuestTurnedIn 5149
step
.goto Eastern Plaguelands,79.60,63.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alen|r
.accept 6021 >>Accept Zaeldarr the Outcast
.accept 5281 >>Accept The Restless Souls
.target Caretaker Alen
step
#optional
.goto Eastern Plaguelands,79.60,63.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alen|r
.accept 6021 >>Accept Zaeldarr the Outcast
.target Caretaker Alen
step << Mage
.isQuestAvailable 5181,5211,5846,5901,5781,6135,6136
.goto Eastern Plaguelands,81.627,58.077
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessica Chambers|r
.home >> Set your Hearthstone to Light's Hope Chapel
.target Jessica Chambers
.bindlocation 2268
step
#label LHFP
.isQuestAvailable 6604,5168,5181,5211,,9474,5237,6389,5846
.goto Eastern Plaguelands,80.22,57.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Georgia|r
.fp Light's Hope Chapel	>>Get the Light's Hope Chapel flight path
.target Georgia
step
#completewith AugustusVendor
.goto Eastern Plaguelands,77.11,48.00,0
.goto Eastern Plaguelands,67.30,40.67,0
.goto Eastern Plaguelands,26.48,37.58,0
>>Kill |cRXP_ENEMY_Diseased Flayers|r and |cRXP_ENEMY_Gibbering Ghouls|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Darrowshire Spirits|r that appear over their corpses
>>|cRXP_WARN_These mobs share spawns with a few mob types, so kill everything after all the ghouls have died|r
.complete 5211,1 
.unitscan Diseased Flayer;Gibbering Ghoul;Cannibal Ghoul
.skipgossip
.isOnQuest 5211
step
#label WormMeat
#loop
.goto Eastern Plaguelands,51.18,39.91,0
.goto Eastern Plaguelands,69.73,50.55,70,0
.goto Eastern Plaguelands,70.42,43.50,70,0
.goto Eastern Plaguelands,70.34,38.47,70,0
.goto Eastern Plaguelands,67.02,34.41,70,0
.goto Eastern Plaguelands,62.69,34.72,70,0
.goto Eastern Plaguelands,50.36,28.49,70,0
.goto Eastern Plaguelands,51.18,39.91,70,0
>>Kill |cRXP_ENEMY_Monstrous Plaguebats|r and |cRXP_ENEMY_Frenzied Plaguehounds|r
>>|cRXP_WARN_Be careful as|r |cRXP_ENEMY_Monstrous Plaguebats|r |cRXP_WARN_can silence for 10 seconds in melee range|r << !Rogue !Warrior
.complete 6042,2 
.mob +Monstrous Plaguebat
.complete 5542,3 
.mob +Frenzied Plaguehound
step
#loop
.goto Eastern Plaguelands,67.02,34.41,0
.goto Eastern Plaguelands,69.73,50.55,70,0
.goto Eastern Plaguelands,70.42,43.50,70,0
.goto Eastern Plaguelands,70.34,38.47,70,0
.goto Eastern Plaguelands,67.02,34.41,70,0
.goto Eastern Plaguelands,62.69,34.72,70,0
.goto Eastern Plaguelands,50.36,28.49,70,0
.goto Eastern Plaguelands,51.18,39.91,70,0
>>Kill |cRXP_ENEMY_Carrion Worms|r. Loot them for their |cRXP_LOOT_Meat|r
.complete 5544,1 
.mob Carrion Grub
.mob Carrion Worm
.mob Carrion Devourer
step
#completewith next
.goto Eastern Plaguelands,52.14,18.30,0
>>Loot the |cRXP_LOOT_Quel'Thalas Registry|r on top of the bench
.complete 6133,4 
.isOnQuest 6133
.group 2
step
#loop
.goto Eastern Plaguelands,52.88,19.18,0
.goto Eastern Plaguelands,51.75,21.66,40,0
.goto Eastern Plaguelands,50.73,18.33,40,0
.goto Eastern Plaguelands,50.89,16.50,40,0
.goto Eastern Plaguelands,52.97,17.29,40,0
.goto Eastern Plaguelands,52.88,19.18,40,0
>>Kill |cRXP_ENEMY_Pathstriders|r, |cRXP_ENEMY_Rangers|r and |cRXP_ENEMY_Woodsmen|r
>>|cRXP_WARN_These mobs hit very hard for non-elites|r << !Rogue !Druid
>>|cRXP_WARN_These mobs hit very hard for non-elites; remember Pathstrider's Faerie Fire ability, in case you need to escape|r << Rogue/Druid
.complete 6133,1 
.mob +Pathstrider
.complete 6133,2 
.mob +Ranger
.complete 6133,3 
.mob +Woodsman
.isOnQuest 6133
.group 2
step
.goto Eastern Plaguelands,52.14,18.30
>>Loot the |cRXP_LOOT_Quel'Thalas Registry|r on top of the bench
.complete 6133,4 
.isOnQuest 6133
.group 2
step
#completewith next
.subzone 2277 >> Travel to Plaguewood
step
#label Termites
#loop
.goto Eastern Plaguelands,42.80,34.24,0
.goto Eastern Plaguelands,39.97,21.11,50,0
.goto Eastern Plaguelands,34.90,24.67,50,0
.goto Eastern Plaguelands,30.69,24.99,50,0
.goto Eastern Plaguelands,26.59,23.84,50,0
.goto Eastern Plaguelands,24.19,23.62,50,0
.goto Eastern Plaguelands,21.15,24.05,50,0
.goto Eastern Plaguelands,20.90,29.89,50,0
.goto Eastern Plaguelands,23.75,32.44,50,0
.goto Eastern Plaguelands,26.48,37.58,50,0
.goto Eastern Plaguelands,29.55,34.13,50,0
.goto Eastern Plaguelands,34.89,35.29,50,0
.goto Eastern Plaguelands,42.80,34.24,50,0
>>Loot the tan |cRXP_PICK_Termite Mounds|r for its |cRXP_LOOT_Termites|r
.complete 5901,1 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tEnter the house, then talk to |cRXP_FRIENDLY_Egan|r and |cRXP_FRIENDLY_Augustus|r
.turnin 5281 >>Turn in The Restless Souls
.target +Egan
.goto Eastern Plaguelands,14.45,33.74
.accept 6164 >>Accept Augustus' Receipt Book
.target +Augustus the Touched
.goto Eastern Plaguelands,14.44,33.51
.isOnQuest 5281
step
#optional
.goto Eastern Plaguelands,14.44,33.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tEnter the house, then talk to |cRXP_FRIENDLY_Augustus|r
.accept 6164 >>Accept Augustus' Receipt Book
.target Augustus the Touched
.isQuestTurnedIn 5281
step
.goto Eastern Plaguelands,17.43,31.08
>>Loot |cRXP_PICK_Augustus' Receipt Book|r on the second floor of the inn
.complete 6164,1 
.isOnQuest 6164
step
.goto Eastern Plaguelands,14.44,33.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Augustus|r back in the house
.turnin 6164 >>Turn in Augustus' Receipt Book
.target Augustus the Touched
.isQuestComplete 6164
step
#label AugustusVendor
.goto Eastern Plaguelands,14.44,33.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Augustus|r again
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r
.isQuestTurnedIn 6164
step
#completewith next
.goto Eastern Plaguelands,27.59,43.33,0
.goto Eastern Plaguelands,16.37,42.00,0
.goto Eastern Plaguelands,27.59,43.33,40,0
.goto Eastern Plaguelands,24.43,41.00,40,0
.goto Eastern Plaguelands,23.33,42.30,40,0
.goto Eastern Plaguelands,21.80,40.36,40,0
.goto Eastern Plaguelands,19.58,42.98,40,0
.goto Eastern Plaguelands,18.71,40.81,40,0
.goto Eastern Plaguelands,16.37,42.00,40,0
.goto Eastern Plaguelands,10.99,47.75,40,0
+Perform the Eastern Plaguelands mountain skip to save time
>>|cRXP_WARN_You MUST have|r |T134863:0|t[Noggenfogger Elixirs] |cRXP_WARN_in your bag for this|r
.link https://www.youtube.com/watch?v=6VIULBxMyfU >> Click HERE for reference
.use 8529
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.turnin 5542 >>Turn in Demon Dogs
.turnin 5543 >>Turn in Blood Tinged Skies
.turnin 5544 >>Turn in Carrion Grubbage
.accept 5742 >>Accept Redemption
.target Tirion Fordring
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
>>|cRXP_WARN_Type /sit when listening to Tirion's Tale. You can be mounted when doing this|r
.complete 5742,1 
.turnin 5742 >>Turn in Redemption
.target Tirion Fordring
.skipgossip
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.accept 5781 >>Accept Of Forgotten Memories
.target Tirion Fordring
.group
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6022 >>Turn in To Kill With Purpose
.turnin 6042 >>Turn in Un-Life's Little Annoyances
.turnin 6133 >>Turn in The Ranger Lord's Behest
.accept 6135 >>Accept Duskwing, Oh How I Hate Thee...
.accept 6136 >>Accept The Corpulent One
.target Nathanos Blightcaller
.isQuestComplete 6133
.group
step
#optional
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.accept 6135 >>Accept Duskwing, Oh How I Hate Thee...
.accept 6136 >>Accept The Corpulent One
.target Nathanos Blightcaller
.isQuestTurnedIn 6133
.group
step
#optional
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 6022 >>Turn in To Kill With Purpose
.turnin 6042 >>Turn in Un-Life's Little Annoyances
.target Nathanos Blightcaller
step
#optional
.abandon 6133 >>Abandon The Ranger Lord's Behest
step
#optional
.goto Eastern Plaguelands,46.2,64.0,0
.goto Eastern Plaguelands,27.2,73.6,0
.goto Eastern Plaguelands,46.2,64.0,80,0
.goto Eastern Plaguelands,27.2,73.6,80,0
>>Kill |cRXP_ENEMY_Duskwing|r. Loot him for his |cRXP_LOOT_Fur|r
>>|cRXP_WARN_He patrols nearby|r
.complete 6135,1 
.unitscan Duskwing
.isOnQuest 6135

step
.goto Eastern Plaguelands,28.34,86.79
>>Click the |cRXP_PICK_Loose Dirt Mound|r to summon |cRXP_ENEMY_Mercutio Filthgorger|r and 3 |cRXP_ENEMY_Crypt Robbers|r. Kill him, then loot him for his |cRXP_LOOT_Hammer|r
>>|cRXP_WARN_This quest is very dangerous. The|r |cRXP_ENEMY_Crypt Robbers|r |cRXP_WARN_are unusual; they take a LONG time to reset and can re-leash on a split pull|r
.complete 5781,1 
.mob Crypt Robber
.unitscan Mercutio Filthgorger
.group 2
step
.goto Eastern Plaguelands,27.41,84.92
>>Kill |cRXP_ENEMY_Zaeldarr the Outcast|r inside the crypt. Loot him for his |cRXP_LOOT_Head|r
.complete 6021,1 
.unitscan Zaeldarr the Outcast
step
.goto Eastern Plaguelands,27.28,85.22
>>Click the big |cRXP_PICK_Torn Scroll|r on the ground inside the crypt
.accept 6024 >>Accept Hameya's Plea
.group
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.turnin 5781 >>Turn in Of Forgotten Memories
.accept 5845 >>Accept Of Lost Honor
.target Tirion Fordring
.isQuestComplete 5781
.group
step
#optional
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.accept 5845 >>Accept Of Lost Honor
.target Tirion Fordring
.isQuestTurnedIn 5781
.group
step
#completewith LostSymbol
>>Kill |cRXP_ENEMY_Diseased Flayers|r and |cRXP_ENEMY_Gibbering Ghouls|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Darrowshire Spirits|r that appear over their corpses
>>|cRXP_WARN_These mobs share spawns with a few mob types, so kill everything after all the ghouls have died|r
.complete 5211,1 
.unitscan Diseased Flayer;Gibbering Ghoul;Cannibal Ghoul
.skipgossip
.isOnQuest 5211
.group 0
step
.goto Eastern Plaguelands,56.3,31.0
>>Kill |cRXP_ENEMY_Borelgore|r
>>|cRXP_WARN_He patrols around this area. Find him & kill him|r
.complete 6136,1 
.unitscan Borelgore
.isOnQuest 6136
.group 2


step
#completewith next
.subzone 2273 >> Travel to Zul'Mashar
.group
step
.goto Eastern Plaguelands,64.25,22.09,50,0
.goto Eastern Plaguelands,68.57,20.95,50,0
.goto Eastern Plaguelands,69.23,18.48
>>Kill |cRXP_ENEMY_Infiltrator Hameya|r. Loot her for her |cRXP_LOOT_Key|r
>>|cRXP_WARN_You should be able to avoid all the mobs en route up the mountain. Run past them all then run up the mountains to the east. Do not go near the graves|r
.complete 6024,1 
.unitscan Infiltrator Hameya
.group 2
step
#label LostSymbol
.goto Eastern Plaguelands,71.30,33.97
>>Loot the |cRXP_LOOT_Symbol of Lost Honor|r underwater
.complete 5845,1 
.isQuestTurnedIn 5781
.group 0
step
#loop
.goto Eastern Plaguelands,77.11,48.00,0
.goto Eastern Plaguelands,67.30,40.67,0
.goto Eastern Plaguelands,26.48,37.58,0
.goto Eastern Plaguelands,68.20,40.80,60,0
.goto Eastern Plaguelands,68.60,38.60,60,0
.goto Eastern Plaguelands,66.00,36.00,60,0
.goto Eastern Plaguelands,64.60,38.00,60,0
.goto Eastern Plaguelands,65.40,41.20,60,0
.goto Eastern Plaguelands,66.60,38.60,60,0
.goto Eastern Plaguelands,68.20,40.80,60,0
>>Kill |cRXP_ENEMY_Diseased Flayers|r and |cRXP_ENEMY_Gibbering Ghouls|r
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Darrowshire Spirits|r that appear over their corpses
>>|cRXP_WARN_These mobs share spawns with a few mob types, so kill everything after all the ghouls have died|r
.complete 5211,1 
.unitscan Diseased Flayer;Gibbering Ghoul;Cannibal Ghoul
.skipgossip
.isOnQuest 5211
step << Mage
#completewith LHTurnins
.hs >>Hearth to Light's Hope Chapel
.use 6948
.bindlocation 2268,1
.subzoneskip 2268
.cooldown item,6948,>0,1
step
#optional << Mage
#completewith LHTurnins
.subzone 2268 >>Travel to Light's Hope Chapel
.zoneskip Undercity
.cooldown item,6948,<0 << Mage
step
.goto Eastern Plaguelands,79.60,63.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alen|r
.turnin 6021 >>Turn in Zaeldarr the Outcast
.target Caretaker Alen
.isQuestComplete 6021
step
#label LHTurnins
.goto Eastern Plaguelands,81.51,59.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin|r
.turnin 5211 >>Turn in Defenders of Darrowshire
.target Carlin Redpath
.isQuestComplete 5211
step << !Mage
#completewith UCvisit1
.goto Eastern Plaguelands,80.22,57.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Georgia|r
.fly Undercity >>Fly to Undercity
.target Georgia
.zoneskip Undercity
step << Mage
#completewith UCvisit1
.cast 3563 >>|cRXP_WARN_Cast|r |T135766:0|t[Teleport: Undercity]
.zoneskip Undercity
step << Mage
.goto Undercity,85.15,10.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 10157 >> Train your class spells
.target Anastasia Hartwell
.xp <56,1
.xp >58,1
step << Mage
#optional
.goto Undercity,85.15,10.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Anastasia|r
.train 10054 >> Train your class spells
.target Anastasia Hartwell
.xp <58,1
step << Mage
.goto Undercity,82.79,15.82
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hannah Akeley|r
>>|cRXP_BUY_Buy at least two|r |T134419:0|t[Rune of Teleportation]
.collect 17031,2 
.target Hannah Akeley
step << Warlock
.goto Undercity,88.93,15.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Richard|r
.train 11689 >> Train your class spells
.target Richard Kerwin
.xp <56,1
.xp >58,1
step << Warlock
#optional
.goto Undercity,88.93,15.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Richard|r
.train 11713 >> Train your class spells
.target Richard Kerwin
.xp <58,1
step << Warlock
.goto Undercity,85.70,16.07
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Martha|r
.trainer >>Upgrade your pet's abilities
.target Martha Strain
step << Priest
.goto Undercity,47.55,18.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 10929 >> Train your class spells
.target Father Lazarus
.xp <56,1
.xp >58,1
step << Priest
#optional
.goto Undercity,47.55,18.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lazarus|r
.train 10947 >> Train your class spells
.target Father Lazarus
.xp <58,1
step << Warrior
.goto Undercity,48.32,15.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angela|r
.train 20662 >> Train your class spells
.target Angela Curthas
.xp <56,1
.xp >58,1
step << Warrior
#optional
.goto Undercity,48.32,15.98
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Angela|r
.train 11597 >> Train your class spells
.target Angela Curthas
.xp <58,1
step << Rogue
.goto Undercity,83.86,72.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carolyn|r
.train 11300 >> Train your class spells
.target Carolyn Ward
.xp <56,1
.xp >58,1
step << Rogue
#optional
.goto Undercity,83.86,72.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carolyn|r
.train 11305 >> Train your class spells
.target Carolyn Ward
.xp <58,1
step
.goto Undercity,69.79,43.16
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bauhaus|r
.turnin 5023 >>Turn in Better Late Than Never
.accept 5049 >>Accept The Jeremiah Blues
.target Royal Overseer Bauhaus
step
.goto Undercity,67.61,44.14
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jeremiah|r
.turnin 5049 >>Turn in The Jeremiah Blues
.accept 5050 >>Accept Good Luck Charm
.target Jeremiah Payson
step
.goto Undercity,65.99,44.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_William|r
.bankwithdraw 10691,10692,10693,10694 >>Withdraw the following from the bank:
>>|T134815:0|t[Filled Vial Labeled #1]
>>|T134822:0|t[Filled Vial Labeled #2]
>>|T134836:0|t[Filled Vial Labeled #3]
>>|T134857:0|t[Filled Vial Labeled #4]
.target William Montague
.isOnQuest 3568
step
#completewith SeepringCorTurnin
.goto Undercity,47.20,59.69,0
.goto Undercity,47.20,59.69,12,0
.goto Undercity,43.55,68.11,12,0
.goto Undercity,45.20,71.67,12 >>Travel toward |cRXP_FRIENDLY_Cuely|r
step
.goto Undercity,48.50,71.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cuely|r
.turnin 3568 >>Turn in Seeping Corruption
.target Chemist Cuely
.isQuestComplete 3568
step
#label SeepringCorTurnin
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cuely|r and |cRXP_FRIENDLY_Thersa|r
.accept 3569 >>Accept Seeping Corruption
.target +Chemist Cuely
.goto Undercity,48.71,71.40
.turnin 3569 >>Turn in Seeping Corruption
.turnin 3570 >>Turn in Seeping Corruption
.target +Thersa Windsong
.goto Undercity,49.03,70.81
.isQuestTurnedIn 3568

step
.goto Undercity,54.81,76.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andron|r
.turnin 3542 >>Turn in Delivery to Andron Gant

.target Andron Gant
.isOnQuest 3542
step << skip
#optional
.goto Undercity,54.81,76.32
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Andron|r
.accept 3564 >>Accept Andron's Payment to Jediga
.target Andron Gant
.isQuestTurnedIn 3542
step
#completewith next
.goto Undercity,51.99,64.54,10,0
.goto Undercity,46.25,73.22,10,0
.goto Undercity,45.32,78.32,10,0
.goto Undercity,46.26,83.91,10,0
.goto Undercity,49.03,87.92,10,0
.goto Undercity,52.94,89.60,10 >>Enter the Royal Quarter
step
.goto Undercity,58.07,91.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Sylvanas|r
.accept 5961 >>Accept The Champion of the Banshee Queen
.target Lady Sylvanas Windrunner
step << Paladin
#optional
.goto Undercity,58.0,90.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carolyn|r
.train 10301 >> Train your class spells
.target Champion Cyssa Dawnrose
.xp <56,1
.xp >58,1
step << Paladin
.goto Undercity,58.0,90.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carolyn|r
.train 19943 >> Train your class spells
.target Champion Cyssa Dawnrose
.xp <58,1
step
#ah
#completewith next
>>If you bought enough cloth earlier, go to the mailbox and retrieve the following:
.collect 2592,60 
.collect 4306,60 
.collect 4338,60 
.collect 14047,60 
step
#label UCClothTurnins
.goto Undercity,71.66,29.25
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ralston|r
>>|cRXP_WARN_Disable any other addons that automatically turn in reputation items, or you'll be told to buy cloth again later|r
>>|cRXP_WARN_Skip any of the donations which you do not have enough cloth for|r
.turnin 7813 >>Turn in A Donation of Wool
.turnin 7814 >>Turn in A Donation of Silk
.turnin 7817 >>Turn in A Donation of Mageweave
.turnin 7818 >>Turn in A Donation of Runecloth
.target Ralston Farnsley

step
#label UCvisit1
#completewith next
.goto Tirisfal Glades,61.85,66.59,60 >>Exit Undercity
.zoneskip Tirisfal Glades
step
.goto Tirisfal Glades,83.28,69.23
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dithers|r
.turnin 964 >>Turn in Skeletal Fragments
.target Apothecary Dithers
step
.goto Tirisfal Glades,83.2,71.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mehlar Dawnblade|r
.turnin 9443 >>Turn in The So-Called Mark of the Lightbringer

.target Mehlar Dawnblade
.isQuestComplete 9443
.group
step << skip 
#optional
.goto Tirisfal Glades,83.2,71.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mehlar Dawnblade|r
.accept 9444 >>Accept Defiling Uther's Tomb
.target Mehlar Dawnblade
.isQuestTurnedIn 9443
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5234 >>Turn in Return to the Bulwark
.accept 5235 >>Accept Target: Gahrron's Withering
.target Shadow Priestess Vandis
step
.goto Tirisfal Glades,83.29,72.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mickey|r
.turnin 5901 >>Turn in A Plague Upon Thee
.accept 5902 >>Accept A Plague Upon Thee
.target Mickey Levine
step
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice|r on the 2nd floor
>>|cRXP_WARN_You can talk to her from outside at the back of the building|r
.turnin 5050 >>Turn in Good Luck Charm
.accept 5051 >>Accept Two Halves Become One
.target Janice Felstone
step
#loop
.line Western Plaguelands,36.8,58.6,36.4,56.4,37.4,55.6,38.6,56.2,37.8,57.6,36.8,58.6
.goto Western Plaguelands,36.80,58.60,0
.goto Western Plaguelands,36.80,58.60,50,0
.goto Western Plaguelands,36.40,56.40,50,0
.goto Western Plaguelands,37.40,55.60,50,0
.goto Western Plaguelands,38.60,56.20,50,0
.goto Western Plaguelands,37.80,57.60,50,0
>>Kill the |cRXP_ENEMY_Jabbering Ghoul|r. Loot it for the |cRXP_LOOT_Good Luck Other-Half-Charm|r
.use 12722 >> Use it to create the |cRXP_LOOT_Good Luck Charm|r
.complete 5051,1 
.unitscan Jabbering Ghoul
step
.goto Western Plaguelands,38.40,54.05
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Janice|r on the 2nd floor
>>|cRXP_WARN_You can talk to her from outside at the back of the building|r
.turnin 5051 >>Turn in Two Halves Become One
.target Janice Felstone
step
.goto Western Plaguelands,49.13,78.53
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Marlene|r inside the house
.turnin 5152 >>Turn in Auntie Marlene
.accept 5153 >>Accept A Strange Historian
.target Marlene Redpath
.isQuestTurnedIn 5149
step
.goto Western Plaguelands,49.69,76.75
>>Loot |cRXP_PICK_Joseph Redpath's Monument|r for |cRXP_LOOT_Joseph's Wedding Ring|r
.complete 5153,1 
.isQuestTurnedIn 5149
step << skip
.goto Western Plaguelands,52.14,83.56
.use 23691 >>|cRXP_WARN_Equip the|r |T135160:0|t[Corrupted Mark of the Lightbringer] |cRXP_WARN_in your off-hand|r
>>|cRXP_WARN_Use the it at the statue|r
.complete 9444,1 
.isQuestTurnedIn 9443
step
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.turnin 4972 >>Turn in Counting Out Time
.turnin 5153 >>Turn in A Strange Historian
.target Chromie
.isQuestTurnedIn 5149
step
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.turnin 4972 >>Turn in Counting Out Time
.target Chromie
.isQuestComplete 4972
step
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.accept 5154 >>Accept The Annals of Darrowshire
.target Chromie
.isQuestTurnedIn 5153
step
.goto Western Plaguelands,43.4,69.6
>>Loot |cRXP_PICK_Musty Tomes|r inside the town hall until you loot the |cRXP_LOOT_Annals of Darrowshire|r
>>|cRXP_WARN_Many books are fake and spawn mobs when opened. The real books have entirely white pages, no gray/dark coloration. You may have to click fake books in order to spawn a real one|r
.complete 5154,1 
.link https://i.imgur.com/B2HDb6K.png >> Click HERE for a visual example
.isOnQuest 5154
step
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.turnin 5154 >>Turn in The Annals of Darrowshire
.accept 5210 >>Accept Brother Carlin
.target Chromie
.isQuestComplete 5154
step
#optional
.goto Western Plaguelands,39.46,66.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r on the top floor of the inn
.accept 5210 >>Accept Brother Carlin
.target Chromie
.isQuestTurnedIn 5154
step
.goto Western Plaguelands,49.1,66.7
>>Kill more |cRXP_ENEMY_Undeads|r. Loot them for their |cRXP_LOOT_Bone Fragments|r
>>|cRXP_WARN_If you accidentally sold or dropped them earlier, skip this step|r
.collect 22526,30,9126,1 
step
.goto Western Plaguelands,53.73,64.66
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mulgris|r
.turnin 4985 >>Turn in The Wildlife Suffers Too
.accept 4987 >>Accept Glyphed Oaken Branch
.target Mulgris Deepriver
step
.goto Western Plaguelands,62.80,58.76
>>Kill |cRXP_ENEMY_Cauldron Lord Soulwrath|r. Loot him for his |cRXP_LOOT_Cauldron Key|r
>>|cRXP_WARN_This mob has a 10-second silencing disease|r << !Priest
>>|cRXP_WARN_This mob has a 10-second silencing disease; pre-cast Abolish Disease and keep it up|r << Priest
.complete 5235,1 
.unitscan Cauldron Lord Soulwrath
step
.goto Western Plaguelands,62.5,58.6
>>Click the |cRXP_PICK_Scourge Cauldron|r roiling atop the dais
.turnin 5235 >>Turn in Target: Gahrron's Withering
.accept 5236 >>Accept Return to the Bulwark
step
#completewith next
.subzone 192 >>Travel to Northridge Lumber Camp
step
.goto Western Plaguelands,48.35,32.00
>>Enter the mill. Click the |cRXP_PICK_Northridge Lumber Mill Crate|r by the ramp, then click the |cRXP_PICK_Termite Barrel|r
.turnin 5902 >>Turn in A Plague Upon Thee
.accept 6390 >>Accept A Plague Upon Thee
.skipgossip
step
#completewith HearthglenOverlook
.subzone 190 >> Travel to Hearthglen
.group 0
step
#label HearthglenOverlook
.goto Western Plaguelands,47.94,21.43,60,0
.goto Western Plaguelands,43.31,17.34,50,0
.goto Western Plaguelands,45.6,18.6
>>Run up to the top of the tower. Be careful as |cRXP_ENEMY_Scarlet Paladins|r outside can heal
>>|cRXP_WARN_Be mindful that mobs have no Z axis range. They can hit you from the bottom of the tower if they're directly below you|r
>>|cRXP_WARN_Be careful of |cRXP_ENEMY_High Protector Lorik|r (level 61 elite), he patrols around|r
>>|cRXP_WARN_Be careful of the |cRXP_ENEMY_Scarlet Executioner|r that might patrol at the top of the tower|r
.complete 6025,1 
.unitscan High Protector Lorik
.unitscan Scarlet Executioner
.group 2
step
.goto Western Plaguelands,51.92,28.06
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tLeave Hearthglen, then talk to |cRXP_FRIENDLY_Kirsta|r
.turnin 6025 >>Turn in Unfinished Business
.target Kirsta Deepshadow
.isQuestComplete 6025
.group
step
#completewith MissionAcc
.subzone 152 >>Travel back to the Bulwark
step << skip
.goto Tirisfal Glades,83.2,71.4
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mehlar Dawnblade|r
.turnin 9444 >>Turn in Defiling Uther's Tomb
.target Mehlar Dawnblade
.isQuestComplete 9444
step
.goto Tirisfal Glades,83.03,71.91
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vandis|r
.turnin 5236 >>Turn in Return to the Bulwark
.target Shadow Priestess Vandis
step
.goto Tirisfal Glades,83.30,72.34
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mickey|r
.turnin 6390 >>Turn in A Plague Upon Thee
.target Mickey Levine
step
#label MissionAcc
.goto Tirisfal Glades,83.15,68.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Derrington|r
.turnin 5238 >>Turn in Mission Accomplished!
.target High Executor Derrington
step
.goto Tirisfal Glades,83.19,68.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Garush|r
.turnin 5408 >>Turn in Minion's Scourgestones
.target Argent Officer Garush
.itemcount 12840,20 
step
#completewith LHTurnins
+|cRXP_WARN_Save at least one of your|r |T133441:0|t[Argent Dawn Valor Tokens] |cRXP_WARN_as it's needed for a quest turn-in soon|r
.itemcount 12844,1 
step
#completewith TirionFinal
.goto Eastern Plaguelands,7.59,43.57,50 >>Travel back to Tirion
.group 0
step
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.turnin 5845 >>Turn in Of Lost Honor
.target Tirion Fordring
.isQuestComplete 5845
.group
step
#label TirionFinal
.goto Eastern Plaguelands,7.59,43.57
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tirion|r
.accept 5846 >>Accept Of Love and Family
.target Tirion Fordring
.isQuestTurnedIn 5845
.group
step
#completewith next
.goto Western Plaguelands,65.79,75.41,100 >>Swim to Caer Darrow << !Shaman/Priest
.goto Western Plaguelands,65.79,75.41,100 >>Waterwalk to Caer Darrow, or swim << Shaman
.goto Western Plaguelands,65.79,75.41,100 >>Use Levitate and run to Caer Darrow, or swim << Priest
.group 0
step
.goto Western Plaguelands,65.79,75.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Renfray|r
.turnin 5846 >>Turn in Of Love and Family
.target Artist Renfray
.isOnQuest 5846
.group
step
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 5961 >>Turn in The Champion of the Banshee Queen
.turnin 6135 >>Turn in Duskwing, Oh How I Hate Thee...
.turnin 6136 >>Turn in The Corpulent One
.target Nathanos Blightcaller
.isQuestComplete 6135
.isQuestComplete 6136
.group
step
#optional
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 5961 >>Turn in The Champion of the Banshee Queen
.turnin 6135 >>Turn in Duskwing, Oh How I Hate Thee...
.target Nathanos Blightcaller
.isQuestComplete 6135
.group
step
#optional
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 5961 >>Turn in The Champion of the Banshee Queen
.turnin 6136 >>Turn in The Corpulent One
.target Nathanos Blightcaller
.isQuestComplete 6136
.group
step
#optional
.goto Eastern Plaguelands,26.55,74.72
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nathanos|r
.turnin 5961 >>Turn in The Champion of the Banshee Queen
.target Nathanos Blightcaller
step
.goto Eastern Plaguelands,28.03,86.16
>>Click on the |cRXP_PICK_mound of dirt|r behind the crypt
.turnin 6024 >>Turn in Hameya's Plea
.isQuestComplete 6024
.group
step
#completewith LHTurnins
.subzone 2268 >>Travel to Light's Hope Chapel
step
#ah
.goto Eastern Plaguelands,80.937,58.515
>>|cRXP_WARN_Withdraw the following items from your mailbox if you bought them earlier. If you didn't buy them, skip this step|r
.collect 12359,2,6026,1 
.collect 11128,1,6026,1 
.collect 10562,8,6026,1 
.collect 10560,8,6026,1 
step
#ah
.goto Eastern Plaguelands,80.937,58.515
+|cRXP_WARN_If you bought|r |T133614:0|t[Dark Iron Scraps] |cRXP_WARN_/|r |T134139:0|t[Core of Elements] |cRXP_WARN_/|r |T133571:0|t[Crypt Fiend Parts] |cRXP_WARN_/|r |T133724:0|t[Bone Fragments] |cRXP_WARN_/|r |T136074:0|t[Savage Fronds] |cRXP_WARN_take them out of your mail. If you did not buy any, skip this step|r
.itemcount 22529,<30 
.itemcount 22526,<30 
.itemcount 22525,<30 
.itemcount 22527,<30 
.itemcount 22528,<30 
step
#completewith 5TurnIns
.goto Western Plaguelands,50.01,76.90,0
>>|cRXP_WARN_If you do not have the Reputation required to accept these quests, grind on nearby |cRXP_ENEMY_Undead|r until you are Friendly with the Argent Dawn|r
>>|cRXP_WARN_If you still have quests to turn in at Western Plaguelands fly there and turn them in, then grind any needed reputation still at Sorrow Hill in WPL. The location is marked on your map|r
.reputation 529,friendly
step
#optional
.goto Eastern Plaguelands,81.200,59.000
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rayne|r
.accept 9136 >> Accept Savage Flora
.turnin 9136 >> Turn in Savage Flora
.itemcount 22529,30
.target Rayne
step
#optional
.goto Eastern Plaguelands,81.505,58.556
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Huntsman Leopold|r
.accept 9124 >> Accept Cryptstalker Armor Doesn't Make Itself...
.turnin 9124 >> Turn in Cryptstalker Armor Doesn't Make Itself...
.itemcount 22525,30
.target Huntsman Leopold
step
#optional
.goto Eastern Plaguelands,81.428,58.507
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rohan the Assassin|r
.accept 9126 >> Accept Bonescythe Digs
.turnin 9126 >> Turn in Bonescythe Digs
.itemcount 22526,30
.target Rohan the Assassin
step
#optional
.goto Eastern Plaguelands,81.523,58.269
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Archmage Angela Dosantos|r
.accept 9128 >> Accept The Elemental Equation
.turnin 9128 >> Turn in The Elemental Equation
.itemcount 22527,30
.target Archmage Angela Dosantos
step
#optional
#label 5TurnIns
.goto Eastern Plaguelands,81.798,58.079
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Korfax|r
.accept 9131 >> Accept Binding the Dreadnaught
.turnin 9131 >> Turn in Binding the Dreadnaught
.itemcount 22528,30
.target Korfax, Champion of the Light
step
#optional
.goto Eastern Plaguelands,80.605,57.979
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Smokey LaRue|r
.accept 6026 >> Accept That's Asking A Lot
.turnin 6026 >> Turn in That's Asking A Lot
.itemcount 12359,2 
.itemcount 11128,1 
.itemcount 10562,8 
.itemcount 10560,8 
.target Smokey LaRue
step
.goto Eastern Plaguelands,81.0,57.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Dispatch Commander Metz|r
.accept 9141 >>Accept They Call Me "The Rooster"
.turnin 9141 >>Turn in They Call Me "The Rooster"
.target Dispatch Commander Metz
.itemcount 12844,1 
step
.goto Eastern Plaguelands,81.51,59.77
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Carlin|r
.turnin 5210 >>Turn in Brother Carlin
.target Carlin Redpath
.isOnQuest 5210
step
#optional
#label LHTurnins
step << Druid
#completewith DruidTraining9
.cast 18960 >>Cast |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
.xp <60,1
.bindlocation 1637,1
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 22829 >>Train your class spells
.target Loganaar
.xp <56,1
.xp >58,1
.bindlocation 1637,1
step << Druid
#optional
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 9841 >>Train your class spells
.target Loganaar
.xp <58,1
.xp >60,1
.bindlocation 1637,1
step << Druid
#label DruidTraining9
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 31018 >>Train your class spells
.target Logan
.xp <60,1
.bindlocation 1637,1
step << !Mage
.hs >>Hearth to Orgrimmar
.use 6948
.bindlocation 1637,1
.zoneskip Orgrimmar
step << Mage
.cast 3567 >>|cRXP_WARN_Cast|r |T135759:0|t[Teleport: Orgrimmar]
.zoneskip Orgrimmar
step
#ah
#completewith OrgClothTurnins
.goto Orgrimmar,50.68,70.37,0
>>If you bought enough cloth earlier, go to the mailbox and retrieve the following:
.collect 2592,60 
.collect 4306,60 
.collect 4338,60 
.collect 14047,60 
step
.goto Orgrimmar,63.62,51.24
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rashona|r
>>|cRXP_WARN_Disable any other addons that automatically turn in reputation items, or you'll be told to buy cloth again later|r
>>|cRXP_WARN_Skip any of the donations which you do not have enough cloth for|r
.turnin 7826 >>Turn in A Donation of Wool
.turnin 7827 >>Turn in A Donation of Silk
.turnin 7831 >>Turn in A Donation of Mageweave
.turnin 7824 >>Turn in A Donation of Runecloth
.target Rashona Straglash
step
#label OrgClothTurnins
.goto Orgrimmar,37.69,87.92
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vehena|r
>>|cRXP_WARN_Disable any other addons that automatically turn in reputation items, or you'll be told to buy cloth again later|r
>>|cRXP_WARN_Skip any of the donations which you do not have enough cloth for|r
.turnin 7833 >>Turn in A Donation of Wool
.turnin 7834 >>Turn in A Donation of Silk
.turnin 7835 >>Turn in A Donation of Mageweave
.turnin 7836 >>Turn in A Donation of Runecloth
.target Vehena
step << Mage
#optional
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 10161 >> Train your class spells
.target Pephredo
.xp <58,1
.xp >60,1
step << Mage
.goto Orgrimmar,38.36,85.54
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Pephredo|r
.train 25304 >> Train your class spells
.target Pephredo
.xp <60,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10947 >> Train your class spells
.target Ur'kyo
.xp <58,1
.xp >60,1
step << Priest
#optional
.goto Orgrimmar,35.59,87.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to|r |cRXP_FRIENDLY_Ur'kyo|r
.train 10952 >> Train your class spells
.target Ur'kyo
.xp <60,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 10473 >> Train your class spells
.target Kardris Dreamseeker
.xp <58,1
.xp >60,1
step << Shaman
#optional
.goto Orgrimmar,38.82,36.41
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kardris|r
.train 29228 >> Train your class spells
.target Kardris Dreamseeker
.xp <60,1
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 19943 >> Train your class spells
.target Master Pyreanor
.xp <58,1
.xp >60,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 25291 >> Train your class spells
.target Master Pyreanor
.xp <60,1
step << Rogue
#optional
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 11305 >> Train your class spells
.target Ormok
.xp <58,1
.xp >60,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 31016 >> Train your class spells
.target Ormok
.xp <60,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
#optional
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 11713 >> Train your class spells
.target Mirket
.xp <58,1
.xp >60,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 25311 >> Train your class spells
.target Mirket
.xp <60,1
step << Warrior
#optional
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11597 >> Train your class spells
.target Grezz Ragefist
.xp <58,1
.xp >60,1
step << Warrior
.goto Orgrimmar,79.91,31.36
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Grezz|r
.train 11585 >> Train your class spells
.target Grezz Ragefist
.xp <60,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 14325 >> Train your class spells
.target Ormak Grimshot
.xp <58,1
.xp >60,1
step << Hunter
#optional
.goto Orgrimmar,66.05,18.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormak|r
.train 25294 >> Train your class spells
.target Ormak Grimshot
.xp <60,1
step << Hunter
.goto Orgrimmar,66.34,14.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xao'tsu|r
.train 24632 >> Train your pet spells
.target Xao'tsu
.xp <60,1
step
#label ZepptoSTV
.goto Durotar,50.8,13.8,40 >>Go up the Zeppelin Tower
.zone Stranglethorn Vale >>Take the Zeppelin to Stranglethorn Vale
.zoneskip Stranglethorn Vale
.zoneskip Duskwood
.zoneskip Swamp of Sorrows
.zoneskip Blasted Lands
.train 49361,1 << Mage 
step
#completewith next
.goto Stranglethorn Vale,39.30,6.49,60,0
.goto Stranglethorn Vale,40.63,3.12,50 >> Travel to Duskwood
.zoneskip Duskwood
.train 49361,1 << Mage 
step
#completewith next
.goto Duskwood,88.47,41.00,50 >>Travel to Deadwind Pass
.zoneskip Swamp of Sorrows
.zoneskip Blasted Lands
.train 49361,1 << Mage 
step
.goto Deadwind Pass,48.02,34.60,60,0
.goto Deadwind Pass,58.43,41.51,50,0
.zone Swamp of Sorrows >>Travel to Swamp of Sorrows
>>|cRXP_WARN_Alternatively, pay a mage for a portal to Stonard or fly there if you have the flight path|r
.zoneskip Blasted Lands
.train 49361,1 << Mage 
step << Mage
#optional
.cast 49361 >>|cRXP_WARN_Cast|r |T135762:0|t[Teleport: Stonard]
.zoneskip Swamp of Sorrows
.zoneskip Blasted Lands
.train 49361,3 << Mage
step
.goto Swamp of Sorrows,33.4,71.9,60,0
.goto Swamp of Sorrows,33.2,68.4
.zone Blasted Lands >> Travel to Blasted Lands
step
#optional
.abandon 9444
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 59-60 Hellfire Peninsula part 1
#next 60-61 Winterspring/Silithus
step
#completewith ArriveThrallmar
+|cRXP_WARN_You will now travel to Outland to complete a few quick and easy quests for item upgrades in Hellfire Peninsula. You will then return to Azeroth to finish quests in Winterspring and Silithus before returning to Outland again|r
step
.goto Blasted Lands,58.1,56.1
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Warlord Dar'toon|r
.accept 9407 >>Accept Through the Dark Portal
.target Warlord Dar'toon
step
#completewith next
.goto Blasted Lands,58.74,60.28
.zone Hellfire Peninsula >> Go through the Dark Portal
step
.goto Hellfire Peninsula,87.35,49.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orion|r
.turnin 9407 >> Turn in Through the Dark Portal
.accept 10120 >> Accept Arrival in Outland
.target Lieutenant General Orion
step
.goto Hellfire Peninsula,87.34,48.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vlagga|r
.turnin 10120 >> Turn in Arrival in Outland
.accept 10289 >> Accept Journey to Thrallmar
.target Vlagga Freyfeather
step
.goto Hellfire Peninsula,87.34,48.13
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vlagga|r
.fly Thrallmar >> Fly to Thrallmar
.skipgossip
.isOnQuest 10289
.target Vlagga Freyfeather
.subzoneskip 3538
step
#label ArriveThrallmar
.goto Hellfire Peninsula,55.89,36.60,15,0
.goto Hellfire Peninsula,55.86,37.12
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Krakork|r
.turnin 10289 >> Turn in Journey to Thrallmar
.accept 10291 >> Accept Report to Nazgrel
.target General Krakork
step
.goto Hellfire Peninsula,56.71,37.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Floyd|r
.home >> Set your Hearthstone to Thrallmar
.target Floyd Pinkus
.bindlocation 3536
.zoneskip Hellfire Peninsula,1
step << !Mage
.goto Hellfire Peninsula,56.71,37.47
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Floyd|r
.vendor >>|cRXP_BUY_Stock up on level 55 food/water|r << !Warrior !Rogue !DK
.vendor >>|cRXP_BUY_Stock up on level 55 food/water|r << Warrior/Rogue/DK
.target Floyd Pinkus
.zoneskip Hellfire Peninsula,1
step
.goto Hellfire Peninsula,55.14,37.28,20,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazgrel|r and |cRXP_FRIENDLY_Vurtok|r
.turnin 10291 >> Turn in Report to Nazgrel
.accept 10121 >> Accept Eradicate the Burning Legion
.target +Nazgrel
.goto Hellfire Peninsula,55.01,35.96
.accept 10450 >> Accept Bonechewer Blood
.target +Vurtok Axebreaker
.goto Hellfire Peninsula,55.13,36.39
step
.goto Hellfire Peninsula,55.18,38.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Megzeg|r
.accept 10086 >> Accept I Work... For the Horde!
.target Megzeg Nukklebust
step
#completewith next
+|cFFFF0000HIGH DEATH RISK WARNING:|r
>>|cRXP_WARN_DO NOT APPROACH|r |cRXP_FRIENDLY_Sergeant Shatterskull|r |cRXP_WARN_yet!|r
>>|cRXP_WARN_Every 5-10 minutes a group of |cRXP_ENEMY_Infernal Invaders|r will drop out of the sky which will stun and kill you INSTANTLY at the quest giver location|r
>>|cRXP_WARN_Wait until this happens. After this is over you have time to safely accept the quest|r
step
.goto Hellfire Peninsula,57.00,43.28 

>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shatterskull|r
.turnin 10121 >> Turn in Eradicate the Burning Legion
.accept 10123 >> Accept Felspark Ravine
.target Sergeant Shatterskull
step
#loop
.goto 1944/530,2383.50000,138.80000,0
.goto 1944/530,2274.10010,180.10001,0
.goto 1944/530,2087.40015,224.80000,0
.goto 1944/530,2383.50000,138.80000,50,0
.goto 1944/530,2274.10010,180.10001,50,0
.goto 1944/530,2087.40015,224.80000,50,0
>>Kill a |cRXP_ENEMY_Dreadcaller|r, |cRXP_ENEMY_Imps|r and |cRXP_ENEMY_Infernals|r
.complete 10123,1 
.mob +Dreadcaller
.complete 10123,2 
.mob +Flamewaker Imp
.complete 10123,3 
.mob +Infernal Warbringer
step
#completewith next
+|cFFFF0000HIGH DEATH RISK WARNING:|r
>>|cRXP_WARN_DO NOT APPROACH|r |cRXP_FRIENDLY_Sergeant Shatterskull|r |cRXP_WARN_yet!|r
>>|cRXP_WARN_Every 5-10 minutes a group of |cRXP_ENEMY_Infernal Invaders|r will drop out of the sky which will stun and kill you INSTANTLY at the quest giver location|r
>>|cRXP_WARN_Wait until this happens. After this is over you have time to safely turn in the quest|r
step
#label ThrallmarHS
.goto Hellfire Peninsula,57.00,43.28 

>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Shatterskull|r
.turnin 10123 >> Turn in Felspark Ravine
.accept 10124 >> Accept Forward Base: Reaver's Fall
.target Sergeant Shatterskull
step
#loop
.goto Hellfire Peninsula,61.67,47.95,0
.goto Hellfire Peninsula,58.26,47.71,0
.goto Hellfire Peninsula,60.14,46.51,0
.goto Hellfire Peninsula,61.67,47.95,50,0
.goto Hellfire Peninsula,60.14,46.51,50,0
.goto Hellfire Peninsula,58.26,47.71,50,0
.goto Hellfire Peninsula,55.61,47.22,50,0
.goto Hellfire Peninsula,52.33,47.29,50,0
.goto Hellfire Peninsula,61.67,47.95,50,0
.goto Hellfire Peninsula,60.14,46.51,50,0
.goto Hellfire Peninsula,58.26,47.71,50,0
>>Kill |cRXP_ENEMY_Bonechewers|r
>>Collect the |cRXP_PICK_Metal|r and |cRXP_PICK_Wood|r on the ground
>>|cRXP_WARN_Avoid|r |cRXP_ENEMY_Tagar Spinebreaker|r |cRXP_WARN_who is a level 61 elite that patrols the area|r
.complete 10086,1 
.complete 10086,2 
.complete 10450,1 
.mob +Bonechewer Mutant
.mob +Bonechewer Raider
.mob +Bonechewer Peon
.mob +Bonechewer Scavenger
.mob +Bonechewer Evoker
.mob +Bonechewer Orc
.unitscan Tagar Spinebreaker
step
.goto Hellfire Peninsula,55.17,38.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Megzeg|r
.turnin 10086 >> Turn in I Work... For the Horde!
.accept 10087 >> Accept Burn It Up... For the Horde!
.target Megzeg Nukklebust
step
.goto Hellfire Peninsula,55.13,36.39
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vurtok|r
.turnin 10450 >> Turn in Bonechewer Blood
.accept 10449 >> Accept Apothecary Zelana
.target Vurtok Axebreaker
step
.use 27479 >>|cRXP_WARN_Use the|r |T135432:0|t[Flaming Torch] |cRXP_WARN_on the |cRXP_ENEMY_Western Cannon|r and|r |cRXP_ENEMY_Eastern Cannon|r
.complete 10087,2 
.goto Hellfire Peninsula,54.70,53.83
.complete 10087,1 
.goto Hellfire Peninsula,60.38,51.81
.use 27479
step
#completewith next
.subzone 3807 >>Travel to Reaver's Fall
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_To'arch|r and |cRXP_FRIENDLY_Zelana|r
.turnin 10124 >> Turn in Forward Base: Reaver's Fall
.accept 10208 >> Accept Disrupt Their Reinforcements
.target +Forward Commander To'arch
.goto Hellfire Peninsula,65.89,43.59
.turnin 10449 >> Turn in Apothecary Zelana
.accept 10242 >> Accept Spinebreaker Post
.target +Apothecary Zelana
.goto Hellfire Peninsula,66.17,41.95
step
#loop
.goto Hellfire Peninsula,72.75,40.16,0
.goto Hellfire Peninsula,70.75,43.11,50,0
.goto Hellfire Peninsula,70.14,47.28,50,0
.goto Hellfire Peninsula,72.75,40.16,50,0
>>Kill |cRXP_ENEMY_Demons|r. Loot them for their |cRXP_LOOT_Rune Stones|r
.collect 28513,4 
.isOnQuest 10208
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
.goto Hellfire Peninsula,70.83,45.46
>>Click |cRXP_PICK_Portal Xilus|r to disrupt it
.complete 10208,1 
step
.goto Hellfire Peninsula,74.00,38.73
>>Kill |cRXP_ENEMY_Demons|r. Loot them for their |cRXP_LOOT_Rune Stones|r. Then click |cRXP_PICK_Portal Kruul|r to disrupt it
.collect 28513,5,10208,1,-1 
.complete 10208,2 
.mob Subjugator Shi'aziv
.mob Fel Handler
.mob Wrathguard
.mob Doomwhisperer
.mob Netherhound
step
#completewith next
.subzone 3807 >>Return to Reaver's Fall
step
.goto Hellfire Peninsula,65.89,43.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_To'arch|r
.turnin 10208 >> Turn in Disrupt Their Reinforcements
.accept 10129 >> Accept Mission: Gateways Murketh and Shaadraz
.target Forward Commander To'arch
step
#completewith next
.goto Hellfire Peninsula,66.10,43.71
.gossipoption 118693 >>Talk to |cRXP_FRIENDLY_Brack|r to go on your bombing run
.timer 98,Mission: Gateways Flight
.skipgossip
.target Wing Commander Brack
step
.use 28038 >>|cRXP_WARN_Use the|r |T133712:0|t[Seaforium PU-36 Explosive Nether Modulator] |cRXP_WARN_on |cRXP_PICK_Gateway Shaadraz|r and |cRXP_PICK_Gateway Murketh|r whilst on the flight|r
.complete 10129,2 
.goto Hellfire Peninsula,77.73,51.80,-1
.complete 10129,1 
.goto Hellfire Peninsula,78.00,47.24,-1
step
.goto Hellfire Peninsula,65.89,43.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_To'arch|r
.turnin 10129 >> Turn in Mission: Gateways Murketh and Shaadraz
.accept 10162 >> Accept Mission: The Abyssal Shelf
.target Forward Commander To'arch
step
#completewith next
.goto Hellfire Peninsula,66.10,43.71
.gossipoption 118698 >>Talk to |cRXP_FRIENDLY_Brack|r to to fly to the Abyssal Shelf
>>|cRXP_WARN_If you don't kill everything after the first flight, talk to him again|r
.timer 177,Mission: The Abyssal Shelf Flight
.skipgossip
.target Wing Commander Brack
step
.goto Hellfire Peninsula,72.21,23.78,-1
.goto Hellfire Peninsula,72.60,19.99,-1
.goto Hellfire Peninsula,73.04,15.18,-1
.goto Hellfire Peninsula,72.69,11.19,-1
.use 28132 >>|cRXP_WARN_Use the|r |T133709:0|t[Area 52 Special] |cRXP_WARN_on |cRXP_ENEMY_Peons|r, |cRXP_ENEMY_Overseers|r and |cRXP_ENEMY_Cannons|r whilst on the flight|r
.complete 10162,1 
.complete 10162,2 
.complete 10162,3 
step
.goto Hellfire Peninsula,65.89,43.59
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_To'arch|r
.turnin 10162 >> Turn in Mission: The Abyssal Shelf
.accept 10388 >> Accept Return to Thrallmar
.target Forward Commander To'arch
step
#completewith next
.goto Hellfire Peninsula,66.10,43.71
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brack|r
.fly Spinebreaker Post>> Fly to Spinebreaker Post
.skipgossip 19401,1
.timer 46,Spinebreaker Post Flight
.isOnQuest 10242
.target Wing Commander Brack
.subzoneskip 3812

step
.goto Hellfire Peninsula,61.66,81.19
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Amilya|r
.fp Spinebreaker Post >> Get the Spinebreaker Post Flight Path
.target Amilya Airheart
.isQuestAvailable 10220
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mordiba|r, |cRXP_FRIENDLY_Albreck|r and |cRXP_FRIENDLY_Grelag|r
.accept 10220 >> Accept Make Them Listen
.target +Emissary Mordiba
.goto Hellfire Peninsula,61.78,81.71
.turnin 10242 >> Turn in Spinebreaker Post

.target +Apothecary Albreck
.goto Hellfire Peninsula,61.13,81.77
.accept 9345 >>Accept Preparing the Salve
.target +Grelag
.goto Hellfire Peninsula,60.93,81.67
step
#completewith HonorTurnin
>>Gather |cRXP_PICK_Hellfire Spineleaves|r on the ground throughout Hellfire Peninsula
.complete 9345,1 
step
#completewith next
>>Kill |cRXP_ENEMY_Footmen|r, |cRXP_ENEMY_Sorcerers|r and |cRXP_ENEMY_Knights|r in the area
.complete 10220,1 
.mob +Unyielding Footman
.complete 10220,2 
.mob +Unyielding Sorcerer
.complete 10220,3 
.mob +Unyielding Knight
step
#loop
.goto Hellfire Peninsula,55.89,78.43,0
.goto Hellfire Peninsula,57.96,80.19,50,0
.goto Hellfire Peninsula,58.20,77.58,50,0
.goto Hellfire Peninsula,55.89,78.43,50,0
>>Kill |cRXP_ENEMY_Unyielding Knights|r. Loot them for a |T133743:0|t|cRXP_LOOT_Mysterious Tome|r. Use it to accept the quest
.collect 28552,1,10229
.accept 10229 >> Accept Decipher the Tome
.use 28552
.unitscan Unyielding Knight
step
#completewith next
.subzone 3812 >>Return to Spinebreaker Post
step
.goto Hellfire Peninsula,61.74,81.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Althen|r
.turnin 10229 >> Turn in Decipher the Tome
.accept 10230 >> Accept The Battle Horn
.target Althen the Historian
step
#completewith next
>>Kill |cRXP_ENEMY_Footmen|r, |cRXP_ENEMY_Sorcerers|r and |cRXP_ENEMY_Knights|r in the area
.complete 10220,1 
.mob +Unyielding Footman
.complete 10220,2 
.mob +Unyielding Sorcerer
.complete 10220,3 
.mob +Unyielding Knight
step
.goto Hellfire Peninsula,54.75,83.71
>>Kill |cRXP_ENEMY_Commander Thalvos|r. Loot him for his |cRXP_LOOT_Horn|r
.complete 10230,1 
.mob Lieutenant Commander Thalvos
step
>>Kill |cRXP_ENEMY_Footmen|r, |cRXP_ENEMY_Sorcerers|r and |cRXP_ENEMY_Knights|r in the area
.complete 10220,1 
.mob +Unyielding Footman
.goto Hellfire Peninsula,58.50,79.42,50,0
.goto Hellfire Peninsula,58.54,77.36,50,0
.goto Hellfire Peninsula,57.70,75.28,50,0
.goto Hellfire Peninsula,56.70,74.36,50,0
.goto Hellfire Peninsula,55.59,79.20
.complete 10220,2 
.mob +Unyielding Knight
.goto Hellfire Peninsula,56.44,77.81,50,0
.goto Hellfire Peninsula,54.57,78.22,50,0
.goto Hellfire Peninsula,53.58,85.16,50,0
.goto Hellfire Peninsula,55.25,85.59
.complete 10220,3 
.mob +Unyielding Sorcerer
.goto Hellfire Peninsula,55.89,79.86,50,0
.goto Hellfire Peninsula,55.47,81.52,50,0
.goto Hellfire Peninsula,54.45,81.43,50,0
.goto Hellfire Peninsula,54.21,79.08,50,0
.goto Hellfire Peninsula,55.11,79.59
step
#completewith next
.subzone 3812 >>Return to Spinebreaker Post
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Althen|r and |cRXP_FRIENDLY_Mordiba|r
.turnin 10230 >> Turn in The Battle Horn
.accept 10250 >> Accept Bloody Vengeance
.target +Althen the Historian
.goto Hellfire Peninsula,61.74,81.79
.turnin 10220 >> Turn in Make Them Listen
.target +Emissary Mordiba
.goto Hellfire Peninsula,61.78,81.71
step
#completewith next
.goto Hellfire Peninsula,63.42,77.60
.cast 34622 >>|cRXP_WARN_Use the|r |T134229:0|t[Unyielding Battle Horn] |cRXP_WARN_at the wooden stairs to summon|r |cRXP_ENEMY_Urtrak|r
.use 28651
step
.goto Hellfire Peninsula,63.41,77.12
>>Kill |cRXP_ENEMY_Urtrak|r
.complete 10250,1 
.use 28651
.mob Urtrak
step
#completewith next
.subzone 3812 >>Return to Spinebreaker Post
step
.goto Hellfire Peninsula,61.74,81.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Althen|r
.turnin 10250 >> Turn in Bloody Vengeance
.accept 10258 >> Accept Honor the Fallen
.target Althen the Historian
step
#label HonorTurnin
.goto Hellfire Peninsula,56.92,77.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hogarth|r inside the tower
.turnin 10258 >> Turn in Honor the Fallen
.target Commander Hogarth
step << Druid
#completewith DruidTraining11
.cast 18960 >>Cast |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
.xp <60,1
.bindlocation 3538,1
.cooldown item,6948,>2,1
step << Druid
#label DruidTraining11
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 31018 >>Train your class spells
.target Logan
.xp <60,1
.bindlocation 3538,1
.cooldown item,6948,>2,1
step
.hs >> Hearth to Thrallmar
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue !DK
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue/DK
.bindlocation 3536,1
.subzoneskip 3536
step
.goto Hellfire Peninsula,55.18,38.79
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Megzeg|r
.turnin 10087 >> Turn in Burn It Up... For the Horde!
.target Megzeg Nukklebust
step
.goto Hellfire Peninsula,55.14,37.28,20,0
.goto Hellfire Peninsula,55.01,35.96
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nazgrel|r
.turnin 10388 >>Turn in Return to Thrallmar


.target Nazgrel
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r outside Thrallmar Mine
.accept 10236 >> Accept Outland Sucks!
.target Foreman Razelcraz
step << Shaman
#loop
.goto Hellfire Peninsula,47.98,37.39,0
.goto Hellfire Peninsula,47.28,42.34,0
.goto Hellfire Peninsula,48.85,35.37,0
.goto Hellfire Peninsula,49.02,37.63,50,0
.goto Hellfire Peninsula,47.98,37.39,50,0
.goto Hellfire Peninsula,48.41,40.86,50,0
.goto Hellfire Peninsula,47.28,42.34,50,0
.goto Hellfire Peninsula,47.17,43.74,50,0
.goto Hellfire Peninsula,48.85,35.37,50,0
>>Loot the |cRXP_PICK_Shredder Parts|r boxes on the ground
.complete 10236,1 
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10236 >> Turn in Outland Sucks!
.accept 10238 >> Accept How to Serve Goblins
.target Foreman Razelcraz
step << Shaman
>>Free |cRXP_FRIENDLY_Manni|r, |cRXP_FRIENDLY_Moh|r and |cRXP_FRIENDLY_Jakk|r from the cages
.complete 10238,1 
.target +Manni
.goto Hellfire Peninsula,45.12,41.11,-1
.complete 10238,2 
.target +Moh
.goto Hellfire Peninsula,46.42,45.18,-1
.complete 10238,3 
.target +Jakk
.goto Hellfire Peninsula,47.50,46.63,-1
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10238 >> Turn in How to Serve Goblins
.accept 10629 >> Accept Shizz Work
.target Foreman Razelcraz
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
#completewith next
.cast 37690 >> |cRXP_WARN_Use the|r |T133942:0|t[Felhound Whistle] |cRXP_WARN_whilst beside |cRXP_FRIENDLY_Foreman Razelcraz|r to summon a|r |cRXP_FRIENDLY_Felhound|r
.use 30803
step << Shaman
.goto Hellfire Peninsula,50.7,28.9
>>Kill |cRXP_ENEMY_Deranged Helboars|r. Loot the |cRXP_LOOT_Droppings|r after the |cRXP_FRIENDLY_Felhound's RP|r for the |cRXP_PICK_Shredder Keys|r
.complete 10629,1 
.use 30803
.mob Deranged Helboar
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10629 >> Turn in Shizz Work
.accept 10630 >> Accept Beneath Thrallmar
.target Foreman Razelcraz
step << Shaman
.goto Hellfire Peninsula,51.72,31.68,20,0
.goto Hellfire Peninsula,52.57,30.59,20,0
.goto Hellfire Peninsula,54.39,31.57
>>Kill |cRXP_ENEMY_Urga'zz|r in the back of Thrallmar Mine
.complete 10630,1 
.mob Urga'zz
step << Shaman
.goto Hellfire Peninsula,51.37,30.52
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Razelcraz|r
.turnin 10630 >> Turn in Beneath Thrallmar
.target Foreman Razelcraz
step
.goto 1944/530,3228.800,-1295.300,80,0
.goto 1944/530,3697.200,-1623.900,80,0
.goto 1952/530,4286.600,-1878.900,80,0
.goto 1955/530,5128.300,-1964.300,80 >> Travel to Shattrath City
.zoneskip Shattrath City
step
.goto Shattrath City,64.061,41.112
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nutral|r
.fp Shattrath >> Get the Shattrath City flight path
.target Nutral
step << Mage
.goto Shattrath City,58.749,47.167
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Iorioa|r
.train 33690 >> Train |T135760:0|t[Teleport: Shattrath]
.target Iorioa
.xp <60,1
step << Paladin/Warlock/Rogue
#completewith ORGTraining
.goto Shattrath City,52.20,52.90
.zone Orgrimmar >>Take the portal to Orgrimmar
.train 25291,1 << Paladin
.train 31016,1 << Rogue
.train 25311,1 << Warlock
step << Paladin
#optional
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 19943 >> Train your class spells
.target Master Pyreanor
.xp <58,1
.xp >60,1
step << Paladin
.goto Orgrimmar,32.29,35.74
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Pyreanor|r
.train 25291 >> Train your class spells
.target Master Pyreanor
.xp <60,1
step << Rogue
.goto Orgrimmar,43.90,54.65
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ormok|r
.train 31016 >> Train your class spells
.target Ormok
.xp <60,1
step << Rogue
.goto Orgrimmar,42.10,49.49
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cRXP_BUY_Talk to|r |cRXP_FRIENDLY_Rekkul|r
.vendor >>|cRXP_BUY_Stock up on|r |T134387:0|t[Flash Powder] |cRXP_BUY_and|r |T132273:0|t[Poisons]
.target Rekkul
.zoneskip Orgrimmar,1
step << Warlock
.goto Orgrimmar,48.62,46.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mirket|r
.train 25311 >> Train your class spells
.target Mirket
.xp <60,1
step << Paladin/Warlock/Rogue
#optional
#label ORGTraining
.goto Orgrimmar,45.13,63.89
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Doras|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.zoneskip Orgrimmar,1
.target Doras
step
.goto Shattrath City,52.79,53.10
.zone Thunder Bluff >>Take the portal to Thunder Bluff
.zoneskip Shattrath City,1
step << Druid
.goto Thunder Bluff,76.46,27.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turak|r
.train 9885 >>Train your class spells
.target Turak Runetotem
.xp <60,1
step << Hunter
.goto Thunder Bluff,59.11,86.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 25294 >>Train your class spells
.target Urek Thunderhorn
.xp <60,1
step << Hunter
.goto Thunder Bluff,54.08,84.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hesuwa|r
.train 24632 >>Train your pet spells
.target Hesuwa Thunderhorn
.xp <60,1
step << Warrior
.goto Thunder Bluff,57.56,85.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ker|r
.train 11585 >>Train your class spells
.target Ker Ragetotem
.xp <60,1
step << Shaman
.goto Thunder Bluff,22.84,21.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigor|r
.train 29228 >>Train your class spells
.target Tigor Skychaser
.xp <60,1
step << Priest
.goto Thunder Bluff,24.56,22.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malakai|r
.train 10952 >> Train your class spells
.target Malakai Cross
.xp <60,1
step << Mage
.goto Thunder Bluff,25.18,20.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thurston|r
.train 25304 >> Train your class spells
.target Thurston Xane
.xp <60,1
step
#completewith Glyphturnin
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluff Runner Windstrider|r
>>|cRXP_WARN_He patrols the terraces, so you may have to look around for him|r
.accept 1000 >>Accept The New Frontier
.unitscan Bluff Runner Windstrider
step
.goto Thunder Bluff,70.20,30.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Magatha|r
.turnin 3518 >>Turn in Delivery to Magatha
.target Magatha Grimtotem
.isOnQuest 3518
step
#label Glyphturnin
.goto Thunder Bluff,75.80,31.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nara|r
.turnin 4987 >>Turn in Glyphed Oaken Branch
.target Nara Wildmane
step
#loop
.goto Thunder Bluff,41.54,57.87,70,0
.goto Thunder Bluff,52.76,62.07,30,0
.goto Thunder Bluff,55.63,50.08,70,0
.goto Thunder Bluff,41.54,57.87,0
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bluff Runner Windstrider|r
>>|cRXP_WARN_He patrols the terraces, so you may have to look around for him|r
.accept 1000 >>Accept The New Frontier
.unitscan Bluff Runner Windstrider
step
.goto Thunder Bluff,78.50,28.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hamuul|r
.turnin 1000 >>Turn in The New Frontier
.accept 1123 >>Accept Rabine Saturna
.target Arch Druid Hamuul Runetotem
step
.goto Thunder Bluff,47.02,49.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Emerald Sanctuary >>Fly to Emerald Sanctuary
.target Tal
.zoneskip Felwood
]])

RXPGuides.RegisterGuide([[#version 7
#tbc
#group RestedXP Survival Guide (H)
#subgroup RestedXP Survival Guide 45-60
<< Horde
#name 60-61 Winterspring/Silithus
#next 61-62 Hellfire Peninsula part 2
step
.goto Felwood,51.20,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.turnin 5159 >>Turn in Cleansed Water Returns to Felwood
.accept 5165 >>Accept Dousing the Flames of Protection
.target Greta Mosshoof
step
.goto Felwood,46.60,83.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maybess|r
.turnin 4102 >>Turn in Cleansing Felwood
.target Maybess Riverbreeze
step
.goto Felwood,46.60,83.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maybess|r again to receive a |T134249:0|t[Cenarion Beacon]
>>|cRXP_WARN_Select the option:|r "I need a Cenarion beacon."
.collect 11511,1 
.target Maybess Riverbreeze

step
.goto Felwood,36.02,66.99,70,0
.goto Felwood,32.40,66.60
.cast 15647 >>|cRXP_WARN_Use|r |T132599:0|t[Winna's Kitten Carrier] |cRXP_WARN_at the corrupted moonwell at the Ruins of Constellas|r
.use 12565
.isOnQuest 4506
step
#label EnterShadowH
.goto Felwood,35.367,58.376
.subzone 1770 >> Travel to Shadow Hold within Jaedenar
.isOnQuest 5165
step
#completewith next
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
>>Kill |cRXP_ENEMY_Jaedenar Enforcers|r, |cRXP_ENEMY_Jaedenar Darkweavers|r, |cRXP_ENEMY_Jaedenar Warlocks|r and |cRXP_ENEMY_Jaedenar Legionnaires|r. Loot them for a |T134235:0|t[|cRXP_LOOT_Blood Red Key|r]
>>|cRXP_WARN_Use the|r |T134235:0|t[|cRXP_LOOT_Blood Red Key|r] |cRXP_WARN_to start the quest|r
>>|cRXP_WARN_This will begin an escort quest. Start this escort even if you still need to Extinguish Braziers|r
.collect 13140,1,5202 
.accept 5202 >> Accept A Strange Red Key
.use 13140 
.mob Jaedenar Enforcer
.mob Jaedenar Darkweaver
.mob Jaedenar Warlock
.mob Jaedenar Legionnaire
step
#label eStart
.goto Felwood,36.207,55.465
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captured Arko'narin|r
.turnin 5202 >> Turn in A Strange Red Key
.accept 5203,1 >> Accept Rescue From Jaedenar
.target Captured Arko'narin
step
#completewith next
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
.goto Felwood,35.44,59.01
>>Escort |cRXP_FRIENDLY_Arko'narin|r through Shadow Hold. After |cRXP_FRIENDLY_Arko'narin|r equips her armor, kill the 3 |cRXP_ENEMY_Felguard|r that spawn
>>|cRXP_FRIENDLY_Arko'narin|r |cRXP_WARN_has 6,000 HP; let her tank mobs. Extinguish the Braziers within Shadow Hold as you progress towards the entrance|r
>>Once |cRXP_FRIENDLY_Arko'narin|r leaves the cave, the |cRXP_ENEMY_Spirit of Trey Lightforge|r will spawn. Kill him
>>|cRXP_WARN_Be careful of adds. He has a 500 damage shock spell and hits very hard. Use all of your offensive cooldowns here, if you have them|r
.complete 5203,1 
.target Arko'narin
step
>>Click the four |cRXP_PICK_Braziers|r on the ground
.complete 5165,1 
.goto Felwood,36.267,56.297
.complete 5165,4 
.goto Felwood,36.484,55.183
.complete 5165,3 
.goto Felwood,36.732,53.262
.complete 5165,2 
.goto Felwood,37.677,52.685
step
#completewith next
.goto Felwood,37.37,49.83,40,0
.goto Felwood,35.45,50.10,40,0
.goto Felwood,34.57,52.12
.subzone 1997 >> Travel to Bloodvenom Post
step
#completewith next
>>|cRXP_WARN_Interact with the|r |cRXP_FRIENDLY_Corrupted Saber|r |cRXP_WARN_once you are standing next to|r |cRXP_FRIENDLY_Winna Hazzard|r
.complete 4506,1 
.skipgossip
.target Corrupted Saber
step
.goto Felwood,34.20,52.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tApproach |cRXP_FRIENDLY_Winna|r. Talk to the |cRXP_FRIENDLY_Corrupted Saber|r and then talk to |cRXP_FRIENDLY_Winna|r
.turnin 4506 >>Turn in Corrupted Sabers
.target Winna Hazzard
step
.goto Felwood,34.80,52.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trull|r
.accept 4521 >>Accept Wild Guardians
.target Trull Failbane
step
#completewith next
.goto Felwood,34.40,53.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakkar|r
.fly Emerald Sanctuary >>Fly to Emerald Sanctuary
.target Brakkar
.subzoneskip 2479
step
.goto Felwood,51.20,82.10
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.turnin 5165 >>Turn in Dousing the Flames of Protection
.accept 5242 >>Accept A Final Blow
.target Greta Mosshoof
step
.goto Felwood,51.30,82.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessir|r
.turnin 5203 >>Turn in Rescue From Jaedenar
.accept 5204 >>Accept Retribution of the Light
.target Jessir Moonbow
step
.goto Felwood,48.48,89.60,0
.goto Felwood,48.48,89.60,70,0
.goto Felwood,48.22,93.81,70,0
.goto Felwood,46.68,88.03,70,0
>>Loot |cRXP_LOOT_Corrupted Soul Shards|r from any Mobs in Felwood
.collect 11515,6,5882,1 
.itemcount 11511,1 
.zoneskip Felwood,1
step
.goto Felwood,46.60,83.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Maybess|r
>>Turn in your |T132884:0|t[|cRXP_LOOT_Corrupted Soul Shards|r] to receive |T132804:0|t[|cRXP_LOOT_Cenarion Plant Salves|r]
>>|cRXP_WARN_If you don't have 6 get them from the |cRXP_ENEMY_Furbolgs|r to the south|r
.collect 11515,6,5887,1 
.turnin 5887 >> Turn in Salve via Hunting
.target Maybess Riverbreeze
.zoneskip Felwood,1
.mob Deadwood Warrior
.mob Deadwood Pathfinder
.mob Deadwood Gardener
step
#completewith EnterSH2
#icon |T135934:0|t
.goto Felwood,55.808,10.438,0
.goto Felwood,50.575,13.918,0
.goto Felwood,63.336,22.610,0
.goto Felwood,40.142,44.353,0
.goto Felwood,40.142,56.523,0
.goto Felwood,48.260,75.650,0
.goto Felwood,45.942,85.219,0
.goto Felwood,52.893,87.825,0
.aura 15366 >> |cRXP_WARN_Look for a |cRXP_PICK_Corrupted Songflower|r. Click it to cleanse it. Click the |cRXP_PICK_Cleansed Songflower|r to receive the hour-long|r |T135934:0|t[Songflower Serenade] |cRXP_WARN_buff|r
>>|cRXP_WARN_Their locations have been marked on your map. Skip this step if you aren't able to find one|r
.itemcount 11516,2 
step
#label EnterSH2
#completewith ShadowLordFelidan
.goto Felwood,35.367,58.376
.subzone 1770 >> Travel to Shadow Hold within Jaedenar
step
.goto Felwood,35.39,58.74,30,0
.goto Felwood,38.30,50.50
>>Kill |cRXP_ENEMY_Rakaiah|r deep inside Shadow Hold
.complete 5204,1 
.unitscan Rakaiah
step
.goto Felwood,38.50,50.40
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Remains of Trey Lightforge|r
>>|cRXP_WARN_Mobs around the remains can bug by keeping you in combat, despite not attacking you|r
.turnin 5204 >>Turn in Retribution of the Light
.accept 5385 >>Accept The Remains of Trey Lightforge
.target Remains of Trey Lightforge
.isQuestTurnedIn 5203
step
#label ShadowLordFelidan
.goto Felwood,38.90,46.80
>>Kill |cRXP_ENEMY_Shadow Lord Fel'dan|r, |cRXP_ENEMY_Moora|r and |cRXP_ENEMY_Salia|r. Loot |cRXP_ENEMY_Shadow Lord Fel'dan|r for his |cRXP_LOOT_Head|r
>>|cRXP_WARN_Linger outside of the room and use line of sight (LOS) to avoid Fel'dan's shadowbolts. When he starts casting, hide out of sight. As soon as his cast ends/fails, step into sight so he starts casting again/doesn't get too close to the LOS point|r
.complete 5242,1 
.mob +Moora
.complete 5242,2 
.mob +Salia
.complete 5242,3 
.unitscan +Shadow Lord Felidan
step
.goto Felwood,35.42,58.72,15 >>Exit Shadow Hold
.isQuestComplete 5242
step
.goto Felwood,49.76,27.29,0
.goto Felwood,50.87,23.72,50,0
.goto Felwood,49.44,23.39,50,0
.goto Felwood,48.86,24.80,50,0
.goto Felwood,49.76,27.29,50,0
>>Kill |cRXP_ENEMY_Toxic Horrors|r. Loot them for their |cRXP_LOOT_Toxic Horror Droplets|r
.complete 5086,1 
.mob Toxic Horror
step << !Druid
#completewith RabineSaturna
.goto Felwood,65.19,7.79,15,0
.goto Felwood,65.36,6.71,15,0
.goto Felwood,64.82,5.85,15,0
.goto Felwood,64.55,3.27,15,0
.goto Felwood,65.42,2.77,15,0
.goto Felwood,65.45,0.95,15,0
.goto Felwood,66.05,0.42,15,0
.goto Kalimdor,52.27,22.94,15,0
.goto Kalimdor,52.32,22.81,15,0
.goto Kalimdor,52.33,22.61,15,0
.goto Kalimdor,52.22,22.47,15,0
.goto Kalimdor,52.25,22.36,15,0
.goto Kalimdor,52.33,22.32,15,0
.goto Moonglade,35.67,72.38,15,0
.zone Moonglade >>Enter the tunnel, then take the north exit into Moonglade
step << Druid
#completewith RabineSaturna
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step
#label RabineSaturna
.goto Moonglade,51.70,45.00
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine|r
.turnin 1123 >>Turn in Rabine Saturna
.accept 1124 >>Accept Wasteland
.target Rabine Saturna
step
.goto Moonglade,51.68,45.09
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rabine|r, then work through his dialogue
>>|cRXP_WARN_Skip this step if the Dire Maul dialogue is not available. It will be available if you have gone to Dire Maul's outdoor zone/discovered Dire Maul at any point|r
.accept 5527 >>Accept A Reliquary of Purity
.target Rabine Saturna
.skipgossip
step
#completewith EverlookPickups
.goto Moonglade,32.10,66.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faustron|r
.fly Everlook >>Fly to Everlook
.target Faustron
.zoneskip Winterspring
step
.goto Winterspring,60.88,37.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umi|r
.accept 3783 >>Accept Are We There, Yeti?
.target Umi Rumplesnicker
step
.goto Winterspring,61.11,38.44
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Harlo|r
.accept 6606 >>Accept A Little Luck
.target Harlo Wigglesworth
step
.goto Winterspring,61.60,38.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felnok|r
.accept 4809 >>Accept Chillwind Horns
.target Felnok Steelspring
.isQuestTurnedIn 4808
step
.goto Winterspring,61.91,38.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Mau'ari|r
.turnin 6606 >>Turn in A Little Luck
.accept 969 >> Accept Luck Be With You
.target Witch Doctor Mau'ari
.group
step
.goto Winterspring,61.91,38.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Mau'ari|r
.turnin 6606 >>Turn in A Little Luck
.target Witch Doctor Mau'ari

step
#label EverlookPickups
.goto Winterspring,61.93,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Storm|r
.accept 5054 >> Accept Ursius of the Shardtooth
.target Storm Shadowhoof
step
#completewith RaggedOwlbeasts
>>Kill |cRXP_ENEMY_Rogue Ice Thistle Yetis|r and |cRXP_ENEMY_Ice Thistle Yetis|r. Loot them for their |cRXP_LOOT_Fur|r
>>|cRXP_WARN_Don't focus on this; you can finish it later|r
.complete 3783,1 
.mob Rogue Ice Thistle
.mob Ice Thistle Yeti
step
#completewith next
.goto Winterspring,60.67,29.81,0
.goto Winterspring,58.64,34.51,0
>>Kill |cRXP_ENEMY_Raging Owlbeasts|r
.complete 4521,1 
.mob Raging Owlbeast
step
#loop
.goto Winterspring,63.40,27.04,0
.goto Winterspring,56.62,32.34,70,0
.goto Winterspring,60.50,33.02,70,0
.goto Winterspring,62.55,30.83,70,0
.goto Winterspring,62.43,28.08,70,0
.goto Winterspring,63.40,27.04,70,0
.goto Winterspring,64.65,23.99,70,0
>>Kill |cRXP_ENEMY_Ursius|r
>>|cRXP_WARN_He patrols around|r
.complete 5054,1 
.unitscan Ursius

step
#loop
.goto Winterspring,60.58,29.76,0
.goto Winterspring,60.58,29.76,50,0
.goto Winterspring,58.82,27.41,70,0
.goto Winterspring,56.06,27.83,70,0
.goto Winterspring,55.97,30.25,70,0
.goto Winterspring,55.10,32.16,70,0
>>Kill |cRXP_ENEMY_Raging Owlbeasts|r
.complete 4521,1 
.mob Raging Owlbeast
step
#label RaggedOwlbeasts
#loop
.goto Winterspring,54.39,37.32,0
.goto Winterspring,47.46,36.84,0
.goto Winterspring,38.47,38.19,0
.goto Winterspring,45.14,42.46,0
.goto Winterspring,54.39,37.32,80,0
.goto Winterspring,48.13,34.60,80,0
.goto Winterspring,47.46,36.84,80,0
.goto Winterspring,44.39,37.72,80,0
.goto Winterspring,42.23,37.52,80,0
.goto Winterspring,38.47,38.19,80,0
.goto Winterspring,37.08,41.15,80,0
.goto Winterspring,45.14,42.46,80,0
>>Kill |cRXP_ENEMY_Ragged Owlbeasts|r west of Everlook
.complete 4521,2 
.mob Ragged Owlbeast
step
#completewith next
.goto Winterspring,31.30,45.20,60 >>Travel to |cRXP_FRIENDLY_Donova Snowden|r
step
.goto Winterspring,31.30,45.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova|r
.turnin 5086 >>Turn in Toxic Horrors
.accept 5087 >>Accept Winterfall Runners
.target Donova Snowden
step
#loop
.line Winterspring,28.07,35.29,28.02,36.46,28.32,37.14,28.47,37.92,28.53,39.39,28.80,39.76,29.32,40.86,29.91,42.27,30.44,42.54,31.65,42.44,32.60,42.17,33.59,41.99,34.67,41.91,36.04,42.16,38.21,41.98,40.23,40.75,42.32,39.97,44.29,39.90,46.45,39.66,48.38,38.86,49.19,38.15,49.35,37.79,49.65,37.59,50.57,36.63,51.67,36.21,52.25,35.75,52.75,35.30,53.46,34.27,53.75,33.38,53.93,32.50,53.97,31.32,54.60,30.91,55.51,30.05,57.14,29.72,58.07,28.93,58.74,27.94,59.01,26.99,59.24,26.48,60.37,25.02,60.62,24.75,61.11,24.44,61.29,24.35,61.92,23.82,62.34,23.92,62.37,24.95,62.21,25.30,62.60,25.99,63.04,26.55,63.50,27.81,63.95,28.34,64.12,28.94,64.10,30.84,64.21,31.40,64.97,33.08,65.44,33.48,66.44,33.71,66.63,33.93,66.80,34.47,66.87,34.87,66.97,35.22,67.53,37.01,68.12,37.76,68.65,38.20,68.76,38.13,68.94,37.84,69.29,38.40,69.61,38.29
.goto Winterspring,28.01,34.60,0
.goto Winterspring,28.01,34.60,40,0
.goto Winterspring,30.12,42.57,40,0
.goto Winterspring,39.36,41.28,40,0
.goto Winterspring,47.81,39.23,40,0
.goto Winterspring,53.49,34.13,40,0
.goto Winterspring,54.07,30.98,40,0
.goto Winterspring,57.30,28.05,40,0
.goto Winterspring,61.97,23.00,40,0
.goto Winterspring,62.41,25.53,40,0
.goto Winterspring,64.37,32.06,40,0
.goto Winterspring,66.16,33.66,40,0
.goto Winterspring,67.96,37.54,40,0
>>Kill the |cRXP_ENEMY_Winterfall Runners|r. Loot them for their |cRXP_LOOT_Winterfall Crate|r
>>|cRXP_WARN_Their spawn point is on the west side of Winterspring near the Timbermaw tunnel. Their patrol route is marked on your map|r
>>|cRXP_WARN_Alternatively, run back through the cave to Felwood, and kill the Runner located at the cauldron in Felpaw Village|r
.complete 5087,1 
.unitscan Winterfall Runner
.zoneskip Felwood
step
.goto Felwood,60.20,5.90
>>Kill |cRXP_ENEMY_Winterfall Runners|r
>>|cRXP_WARN_The Runner's located at the cauldron in the northwest of Felpaw Village|r
.complete 5087,1 
.unitscan Winterfall Runner
step
.goto Winterspring,31.30,45.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova|r
.turnin 5087 >>Turn in Winterfall Runners
.accept 5121 >>Accept High Chief Winterfall
.target Donova Snowden

step
.goto Winterspring,27.736,34.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.accept 8464 >>Accept Winterfall Activity
.target Salfa
step
#completewith next
.goto Felwood,68.11,5.40,15,0
.goto Felwood,67.76,4.24,15,0
.goto Felwood,66.43,2.94,15,0
.goto Felwood,65.40,2.94,15,0
.goto Felwood,65.44,1.01,15,0
.goto Felwood,65.98,0.71,15,0
.goto Kalimdor,52.27,22.94,15,0
.goto Kalimdor,52.34,22.61,15,0
.goto Kalimdor,52.21,22.47,15,0
.goto Kalimdor,52.25,22.35,15,0
.goto Kalimdor,52.33,22.33,15,0
.goto Moonglade,35.75,72.40,15,0
.zone Moonglade >>Enter the Furbolg tunnel and take the north exit into Moonglade
step
#completewith next
.goto Moonglade,32.10,66.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faustron|r
.fly Bloodvenom Post >> Fly to Bloodvenom Post
.target Faustron
.subzoneskip 1997
step
.goto Felwood,34.70,52.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trull|r
.turnin 4521 >>Turn in Wild Guardians
.accept 4741 >>Accept Wild Guardians
.target Trull Failbane
step
.hs >>Hearth to Everlook
.use 6948
.bindlocation 2255,1
.subzoneskip 2255
.cooldown item,6948,>0,1
step
#label FlyEverlook3
.goto Felwood,34.40,53.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakkar|r
.fly Everlook >>Fly to Everlook
.target Brakkar
.zoneskip Felwood,1
.zoneskip Winterspring
.cooldown item,6948,<0
step
.goto Winterspring,61.93,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Storm|r
.turnin 5054 >> Turn in Ursius of the Shardtooth
.accept 5055 >> Accept Brumeran of the Chillwind
.target Storm Shadowhoof
step
#completewith next
.goto Winterspring,66.33,30.78,60,0
.goto Winterspring,66.18,26.71,60,0
>>Kill all |cRXP_ENEMY_Chillwind Chimaeras|r north of Everlook. Loot them for their |cRXP_LOOT_Horns|r
.complete 4809,1 
.mob Fledgling Chillwind
.mob Chillwind Chimaera
.mob Chillwind Ravager
.isOnQuest 4809
step
#loop
.goto Winterspring,65.27,19.27,0
.goto Winterspring,65.46,23.81,60,0
.goto Winterspring,66.70,21.74,60,0
.goto Winterspring,65.27,19.27,60,0
.goto Winterspring,63.82,21.87,60,0
>>Kill |cRXP_ENEMY_Moontouched Owlbeasts|r
>>|cRXP_WARN_Their moonfire hits fairly hard, and their rejuvenation is strong|r
.complete 4741,1 
.mob Moontouched Owlbeast
step
#completewith next
.goto Winterspring,60.47,36.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Yugrek|r
.fly Felwood>>Fly to Felwood
.target Yugrek
.zoneskip Felwood
step
.goto Felwood,34.70,52.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trull|r
.turnin 4741 >>Turn in Wild Guardians
.accept 4721 >>Accept Wild Guardians
.target Trull Failbane
step
.hs >>Hearth to Everlook
.use 6948
.bindlocation 2255,1
.subzoneskip 2255
.cooldown item,6948,>0,1
step
#label FlyEverlook3
.goto Felwood,34.40,53.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakkar|r
.fly Everlook >>Fly to Everlook
.target Brakkar
.zoneskip Felwood,1
.zoneskip Winterspring
.cooldown item,6948,<0
step
#loop
.goto Winterspring,66.50,41.70,0
.goto Winterspring,66.50,41.70,50,0
.goto Winterspring,64.90,40.20,50,0
.goto Winterspring,65.90,43.60,50,0
.goto Winterspring,66.20,45.80,50,0
.goto Winterspring,67.60,45.60,50,0
.goto Winterspring,67.60,43.80,50,0
.goto Winterspring,67.20,43.00,50,0
.goto Winterspring,67.60,41.90,50,0
.goto Winterspring,68.40,41.50,50,0
.goto Winterspring,69.00,41.30,50,0
.goto Winterspring,69.50,40.00,50,0
.goto Winterspring,69.80,41.80,50,0
.goto Winterspring,70.10,42.00,50,0
.goto Winterspring,70.30,40.80,50,0
.goto Winterspring,71.30,40.80,50,0
.goto Winterspring,71.80,39.80,50,0
.goto Winterspring,70.50,38.30,50,0
.goto Winterspring,71.80,39.80,50,0
.goto Winterspring,71.30,40.80,50,0
.goto Winterspring,70.30,40.80,50,0
.goto Winterspring,69.50,40.00,50,0
.goto Winterspring,69.00,41.30,50,0
.goto Winterspring,68.40,41.50,50,0
>>Kill |cRXP_ENEMY_Rogue Ice Thistle Yetis|r and |cRXP_ENEMY_Ice Thistle Yetis|r. Loot them for their |cRXP_LOOT_Fur|r
.complete 3783,1 
.mob Rogue Ice Thistle
.mob Ice Thistle Yeti
step
#completewith DarkGorge
>>Kill every |cRXP_ENEMY_Chillwind Chimaera|r you encounter. Loot them for their |cRXP_LOOT_Horns|r
.complete 4809,1 
.mob Fledgling Chillwind
.mob Chillwind Chimaera
.mob Chillwind Ravager
.isOnQuest 4809
step
#loop
.line Winterspring,54.7,46.0,56.6,52.4,60.5,55.6,62.4,58.9,58.8,63.5
.goto Winterspring,58.8,63.5,0
.goto Winterspring,54.7,46.0,60,0
.goto Winterspring,56.6,52.4,60,0
.goto Winterspring,60.5,55.6,60,0
.goto Winterspring,62.4,58.9,60,0
.goto Winterspring,58.8,63.5,60,0
>>Kill |cRXP_ENEMY_Brumeran|r
>>|cRXP_WARN_He patrols around|r
.complete 5055,1 
.unitscan Brumeran
step
#completewith DarkGorge
>>Loot the |cRXP_PICK_Frostmaul Shards|r around the outer perimeter of the canyon
.complete 969,1 
.group 2
step
#label DarkGorge
.goto Winterspring,60.09,73.34
>>Explore Darkwhisper Gorge. You can do this without aggroing any of the nearby Elites
.complete 4842,1 
step
.goto Winterspring,60.43,65.31
>>Loot the |cRXP_PICK_Frostmaul Shards|r around the outer perimeter of the canyon
.complete 969,1 
.group 2
step
.hs >>Hearth to Everlook
.use 6948
.bindlocation 2255,1
.subzoneskip 2255
.cooldown item,6948,>0,1
step
#completewith next
.subzone 2255 >> Travel to Everlook
.cooldown item,6948,<0
step
.goto Winterspring,60.88,37.61
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umi|r
.turnin 3783 >>Turn in Are We There, Yeti?
.accept 977 >>Accept Are We There, Yeti?
.target Umi Rumplesnicker
step
.goto Winterspring,61.91,38.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Mau'ari|r
.turnin 969 >> Turn in Luck Be With You
.target Witch Doctor Mau'ari
.isQuestComplete 969
.group
step
.goto Winterspring,61.93,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Storm|r
.turnin 5055 >> Turn in Brumeran of the Chillwind
.accept 5056 >> Accept Shy-Rotam
.target Storm Shadowhoof
step
.goto Winterspring,61.6,38.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felnok|r
.turnin 4809 >>Turn in Chillwind Horns
.target Felnok Steelspring
.isQuestComplete 4809
step
.goto Winterspring,61.36,38.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vizzie|r
.vendor >>|cRXP_BUY_Sell your junk, then restock on food and water if necessary|r << !Rogue !Warrior
.vendor >>|cRXP_BUY_Sell your junk, then restock on food if necessary|r << Rogue/Warrior
.target Innkeeper Vizzie
step << Hunter
#completewith next
.goto Winterspring,60.389,37.916
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Azzleby|r
.stable >> Stable your pet. You will tame a |cRXP_ENEMY_Winterspring Screecher|r shortly
.target Azzleby
.zoneskip Winterspring,1
step << Hunter
.goto Winterspring,57.8,26.4,70,0
.goto Winterspring,59.6,18.0
>>|cRXP_WARN_Cast|r |T132164:0|t[Tame Beast] |cRXP_WARN_on a |cRXP_ENEMY_Winterspring Screecher|r to tame it|r
.train 3666 >>|cRXP_WARN_Attack mobs with it to learn|r |T132140:0|t[Claw (Rank 8)]
.link https://www.wow-petopia.com/classic/training.php >> |cRXP_WARN_Click here for more info about pet training|r
.mob Winterspring Screecher
.zoneskip Winterspring,1
step << Hunter
#completewith next
.subzone 2255 >> Travel to Everlook
step << Hunter
.goto Winterspring,60.389,37.916
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ulbrek Firehand|r
.stable >> Withdraw your pet
.target Azzleby
.zoneskip Winterspring,1
step
#completewith next
.subzone 2241 >> Travel to Frostsaber Rock
.isQuestTurnedIn 5055
step
#completewith next
#loop
.goto Winterspring,51.64,11.34,0
.goto Winterspring,50.54,14.27,50,0
.goto Winterspring,48.52,12.15,50,0
.goto Winterspring,49.72,8.84,50,0
.goto Winterspring,48.54,7.89,50,0
.goto Winterspring,49.67,7.03,50,0
.goto Winterspring,51.94,9.31,50,0
.goto Winterspring,51.64,11.34,50,0
>>Kill |cRXP_ENEMY_Frostsabers|r. Loot them for |T133298:0|t[|cRXP_LOOT_Sacred Frostsaber Meat|r]
.collect 12733,1,5056,1 
.mob Frostsaber Pride Watcher
.mob Frostsaber Huntress
.mob Frostsaber Stalker
.mob Frostsaber Cub
.mob Frostsaber
.isQuestTurnedIn 5055
step
.goto Winterspring,49.68,9.75
.use 12733 >>|cRXP_WARN_Place the|r |T133298:0|t[|cRXP_LOOT_Sacred Frostsaber Meat|r] |cRXP_WARN_at the stone|r
>>Kill |cRXP_ENEMY_Shy-Rotam|r as he appears
.complete 5056,1 
.unitscan Shy-Rotam
.isQuestTurnedIn 5055
step
#loop
.goto Winterspring,64.00,22.60,0
.goto Winterspring,64.00,22.60,50,0
.goto Winterspring,65.60,23.20,50,0
.goto Winterspring,67.60,22.60,50,0
.goto Winterspring,65.60,19.60,50,0
.goto Winterspring,63.60,16.20,50,0
.goto Winterspring,65.60,19.60,50,0
.goto Winterspring,64.00,20.80,50,0
>>Kill |cRXP_ENEMY_Berserk Owlbeasts|r. Loot them for a |T133298:0|t[|cRXP_LOOT_Blue-feathered Necklace|r]. Use it to accept the quest
.complete 4721,1 
.collect 12558,1,4721,1 
.accept 4882 >>Accept Guarding Secrets
.use 12558
.mob Berserk Owlbeast
step
#completewith next
.goto Winterspring,66.33,30.78,60,0
.goto Winterspring,66.18,26.71,60,0
>>Kill |cRXP_ENEMY_Chillwind Chimaeras|r. Loot them for their |cRXP_LOOT_Horns|r
.complete 4809,1 
.mob Fledgling Chillwind
.mob Chillwind Chimaera
.mob Chillwind Ravager
.isOnQuest 4809
step
#label WVillageArrive
.subzone 2244 >>Travel to Winterfall Village
.isQuestAvailable 5123
step
#requires WVillageArrive
#completewith next
>>Kill |cRXP_ENEMY_Winterfall Ursa|r, |cRXP_ENEMY_Winterfall Shamans|r and |cRXP_ENEMY_Winterfall Den Watchers|r
>>|cRXP_WARN_If there is too much competition, skip this step|r
.complete 8464,1 
.mob +Winterfall Shaman
.complete 8464,2 
.mob +Winterfall Den Watcher
.complete 8464,3 
.mob +Winterfall Ursa
step
#requires WVillageArrive
.goto Winterspring,69.62,38.31
>>Kill |cRXP_ENEMY_High Chief Winterfall|r. Loot him for his |T133740:0|t[|cRXP_LOOT_Crudely-written Log|r]. Use it to accept the quest
.complete 5121,1 
.collect 12842,1,5123 
.accept 5123 >>Accept The Final Piece
.use 12842
.mob Winterfall Shaman
.unitscan High Chief Winterfall
step
#requires WVillageArrive
#loop
.goto Winterspring,67.60,34.10,0
.goto Winterspring,67.60,34.10,50,0
.goto Winterspring,66.40,34.30,50,0
.goto Winterspring,65.90,35.30,50,0
.goto Winterspring,66.60,36.30,50,0
.goto Winterspring,67.50,35.50,50,0
.goto Winterspring,68.40,35.70,50,0
.goto Winterspring,68.30,37.30,50,0
.goto Winterspring,67.50,37.90,50,0
.goto Winterspring,66.80,37.30,50,0
.goto Winterspring,65.60,37.70,50,0
.goto Winterspring,66.70,39.10,50,0
.goto Winterspring,68.00,39.40,50,0
.goto Winterspring,68.80,37.70,50,0
.goto Winterspring,68.40,35.70,50,0
>>Kill |cRXP_ENEMY_Winterfall Ursa|r, |cRXP_ENEMY_Winterfall Shamans|r and |cRXP_ENEMY_Winterfall Den Watchers|r
>>|cRXP_WARN_If there is too much competition, skip this step|r
.complete 8464,1 
.mob +Winterfall Shaman
.complete 8464,2 
.mob +Winterfall Den Watcher
.complete 8464,3 
.mob +Winterfall Ursa
step
#loop
.goto Winterspring,66.50,41.70,0
.goto Winterspring,66.50,41.70,40,0
.goto Winterspring,64.90,40.20,40,0
.goto Winterspring,65.90,43.60,40,0
.goto Winterspring,66.20,45.80,40,0
.goto Winterspring,67.60,45.60,40,0
.goto Winterspring,67.60,43.80,40,0
.goto Winterspring,67.20,43.00,40,0
.goto Winterspring,67.60,41.90,40,0
.goto Winterspring,68.40,41.50,40,0
.goto Winterspring,69.00,41.30,40,0
.goto Winterspring,69.50,40.00,40,0
.goto Winterspring,69.80,41.80,40,0
.goto Winterspring,70.10,42.00,40,0
.goto Winterspring,70.30,40.80,40,0
.goto Winterspring,71.30,40.80,40,0
.goto Winterspring,71.80,39.80,40,0
.goto Winterspring,70.50,38.30,40,0
.goto Winterspring,71.80,39.80,40,0
.goto Winterspring,71.30,40.80,40,0
.goto Winterspring,70.30,40.80,40,0
.goto Winterspring,69.50,40.00,40,0
.goto Winterspring,69.00,41.30,40,0
.goto Winterspring,68.40,41.50,40,0
>>Kill |cRXP_ENEMY_Ice Thistle Patriarchs|r and |cRXP_ENEMY_Ice Thistle Matriarchs|r. Loot them for their |cRXP_LOOT_Pristine Yeti Horns|r
.complete 977,1 
.mob Ice Thistle Patriarch
.mob Ice Thistle Matriarch
step
#loop
.goto Winterspring,67.60,48.20,0
.goto Winterspring,67.60,48.20,60,0
.goto Winterspring,66.20,52.40,60,0
.goto Winterspring,63.60,47.20,60,0
.goto Winterspring,61.60,45.00,60,0
.goto Winterspring,58.20,45.00,60,0
.goto Winterspring,57.40,46.60,60,0
.goto Winterspring,55.40,49.00,60,0
.goto Winterspring,55.20,46.40,60,0
.goto Winterspring,48.60,45.00,60,0
.goto Winterspring,44.80,42.20,60,0
.goto Winterspring,44.00,36.00,60,0
.goto Winterspring,48.00,36.60,60,0
.goto Winterspring,49.40,34.40,60,0
.goto Winterspring,54.00,36.80,60,0
.goto Winterspring,56.60,25.60,60,0
.goto Winterspring,55.60,22.40,60,0
.goto Winterspring,58.00,19.80,60,0
.goto Winterspring,60.60,23.60,60,0
.goto Winterspring,66.40,26.80,60,0
.goto Winterspring,65.60,32.60,60,0
.goto Winterspring,62.40,36.20,60,0
.goto Winterspring,61.20,41.60,60,0
>>Kill |cRXP_ENEMY_Chillwind Chimaeras|r. Loot them for their |cRXP_LOOT_Horns|r
.complete 4809,1 
.mob Fledgling Chillwind
.mob Chillwind Chimaera
.mob Chillwind Rava
step
.hs >>Hearth to Everlook
.use 6948
.bindlocation 2255,1
.subzoneskip 2255
.cooldown item,6948,>0,1
step
#completewith Yeti2Turnin
.subzone 2255 >> Travel to Everlook
.cooldown item,6948,<0
step
.goto Winterspring,61.6,38.6
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Felnok|r
.turnin 4809 >>Turn in Chillwind Horns
.target Felnok Steelspring
.isQuestComplete 4809
step
.goto Winterspring,61.93,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Storm|r
.turnin 5056 >>Turn in Shy-Rotam
.target Storm Shadowhoof
.isQuestComplete 5056
step
#optional
.goto Winterspring,61.93,38.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Storm|r
.turnin 5057 >>Turn in Past Endeavors
.target Storm Shadowhoof
.isOnQuest 5057

step
#label Yeti2Turnin
.goto Winterspring,60.90,37.70
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Umi|r
.turnin 977 >>Turn in Are We There, Yeti?
.accept 5163 >>Accept Are We There, Yeti?
.target Umi Rumplesnicker
step
.goto Winterspring,61.50,38.60
.use 12928 >>|cRXP_WARN_Use the|r |T133003:0|t[Mechanical Yeti] |cRXP_WARN_on|r |cRXP_FRIENDLY_Legacki|r
.complete 5163,1 
.target Legacki
.isOnQuest 5163
step
#completewith next
.goto Winterspring,31.30,45.20,60 >> Travel to |cRXP_FRIENDLY_Donova|r
step
.goto Winterspring,31.30,45.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Donova|r
.turnin 5121 >>Turn in High Chief Winterfall
.turnin 5123 >>Turn in The Final Piece
.turnin 4842 >>Turn in Strange Sources
.accept 5128 >>Accept Words of the High Chief
.target Donova Snowden
step
.goto Winterspring,27.736,34.499
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Salfa|r
.turnin 8464 >> Turn in Winterfall Activity
.target Salfa
.isQuestComplete 8464
step
#completewith FlyFelwood3
.goto Moonglade,32.10,66.60,100 >>Enter the Furbolg tunnel and take the north exit into Moonglade
step
.goto Felwood,65.48,3.47,20,0
.goto Felwood,65.35,1.37
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kernda|r
>>|cRXP_FRIENDLY_Kernda|r |cRXP_WARN_patrols the lower Timbermaw Hold path|r
.use 20742 >>|cRXP_WARN_Use the |T135816:0|t[|cRXP_LOOT_Winterfall Ritual Totem|r] to start the quest|r
>>Skip this step if you aren't neutral with Timbermaw Hold
.accept 8471 >> Accept Winterfall Ritual Totem
.turnin 8471 >> Turn in Winterfall Ritual Totem
.reputation 576,neutral,<0,1 
.itemcount 20742,1 
.target Kernda
step
#label Runeclothcheck
.goto Felwood,65.692,2.810
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Meilosh|r
>>Skip this step if you aren't friendly with Timbermaw Hold
.accept 6031 >> Accept Runecloth
.turnin 6031 >> Turn in Runecloth
.reputation 576,friendly,<0,1 
.itemcount 14047,30 
.target Meilosh
step
#label FlyFelwood3
#completewith Guardianspt3turnin
.goto Moonglade,32.10,66.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Faustron|r
.fly Bloodvenom Post >>Fly to Bloodvenom Post
.target Faustron
.subzoneskip 1997
step
.goto Felwood,34.80,52.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trull|r
.turnin 4721 >>Turn in Wild Guardians
.turnin 4882 >>Turn in Guarding Secrets
.accept 4883 >>Accept Guarding Secrets
.target Trull Failbane
.isQuestComplete 4721
step
#label Guardianspt3turnin
.goto Felwood,34.80,52.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Trull|r
.turnin 4882 >>Turn in Guarding Secrets
.accept 4883 >>Accept Guarding Secrets
.target Trull Failbane
step
#completewith next
.goto Felwood,34.40,53.90
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Brakkar|r
.fly Emerald Sanctuary >>Fly to Emerald Sanctuary
.target Brakkar
.subzoneskip 2479
step
.goto Felwood,51.14,81.76
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Kelek|r
.turnin 5128 >>Turn in Words of the High Chief
.target Kelek Skykeeper
.isQuestTurnedIn 5123
step
.goto Felwood,51.35,82.01
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Jessir|r
.turnin 5385 >>Turn in The Remains of Trey Lightforge
.target Jessir Moonbow
step
.goto Felwood,51.23,82.15
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Greta|r
.turnin 5242 >>Turn in A Final Blow
.target Greta Mosshoof
step << !Mage
#completewith NaraVisit
.goto Felwood,51.5,82.3
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gorrim|r
.fly Thunder Bluff >> Fly to Thunder Bluff
.target Gorrim
.zoneskip Thunder Bluff
step << Mage
#completewith NaraVisit
.cast 3566 >>|cRXP_WARN_Cast|r |T135765:0|t[Teleport: Thunder Bluff]
.zoneskip Thunder Bluff
step << Mage
.goto Thunder Bluff,25.18,20.95
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Thurston|r
.train 10187 >> Train your class spells
.target Thurston Xane
.xp <60,1
step
#label NaraVisit
.goto Thunder Bluff,75.80,31.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Nara|r
.turnin 4883 >>Turn in Guarding Secrets
.target Nara Wildmane
step << Hunter
.goto Thunder Bluff,59.11,86.87
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Urek|r
.train 25294 >>Train your class spells
.target Urek Thunderhorn
.xp <60,1
step << Warrior
.goto Thunder Bluff,57.56,85.48
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ker|r
.train 25289 >> Train your class spells
.target Ker Ragetotem
.xp <60,1
step << Shaman
.goto Thunder Bluff,22.84,21.11
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tigor|r
.train 10414 >>Train your class spells
.target Tigor Skychaser
.xp <60,1
step << Priest
#optional
.goto Thunder Bluff,24.56,22.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Malakai|r
.train 10901 >> Train your class spells
.target Malakai Cross
.xp <60,1
step << Druid
.goto Thunder Bluff,76.46,27.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Turak|r
.train 9885 >>Train your class spells
.target Tura
.xp <60,1
step
#completewith next
.goto Thunder Bluff,47.02,49.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Tanaris >>Fly to Tanaris
.target Tal
.zoneskip Tanaris
step
.goto Tanaris,51.10,26.90
.use 12928 >>|cRXP_WARN_Use the|r |T133003:0|t[Mechanical Yeti] |cRXP_WARN_on|r |cRXP_FRIENDLY_Sprinkle|r
.complete 5163,2 
.target Sprinkle
.isOnQuest 5163
step
.goto Tanaris,51.60,25.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bulkrek|r
.fly Un'Goro Crater >>Fly to Un'Goro Crater
.target Bulkrek Ragefist
.zoneskip Tanaris,1
step
#optional
.goto Thunder Bluff,47.02,49.83
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tal|r
.fly Un'Goro >>Fly to Un'Goro Crater
.target Tal
.zoneskip Thunder Bluff,1
step
.goto Un'Goro Crater,43.70,9.40
.use 12928 >>|cRXP_WARN_Use the|r |T133003:0|t[Mechanical Yeti] |cRXP_WARN_on|r |cRXP_FRIENDLY_Quixxil|r
.complete 5163,3 
.target Quixxil
.isOnQuest 5163
step
#completewith CenarionPickups1
.goto Silithus,88.09,23.43,70,0
.goto Un'Goro Crater,30.15,10.41,70,0
.goto Un'Goro Crater,25.14,12.71,70,0
.goto Silithus,81.87,18.93
.zone Silithus >>Head to Silithus
step
.goto Silithus,81.87,18.93
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Layo|r
.turnin 1124 >>Turn in Wasteland
.accept 1125 >>Accept The Spirits of Southwind
.target Layo Starstrike
step
#completewith CenarionPickups1
.subzone 3425 >>Travel to Cenarion Hold
step
.goto Silithus,51.893,39.163
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calandrath|r
.accept 8307 >> Accept Desert Recipe
.skill cooking,<285,1 
.target Calandrath
step
.goto Silithus,51.80,38.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beetix|r on the second floor of the inn
.accept 8277 >>Accept Deadly Desert Venom
.target Beetix Ficklespragg
step
.goto Silithus,51.15,38.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Proudhorn|r
.accept 8280 >>Accept Securing the Supply Lines
.target Windcaller Proudhorn
step
.goto Silithus,51.30,38.20
>>Click on the |cRXP_PICK_Wanted Poster|r
.accept 8283 >>Accept Wanted - Deathclasp, Terror of the Sands
.group
step
#label CenarionPickups1
.goto Silithus,49.60,37.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larksbane|r
.accept 8284 >>Accept The Twilight Mystery
.target Geologist Larksbane
step
.goto Silithus,37.943,45.315
>>Click the |cRXP_PICK_Sandy Cookbook|r at the Twilight Base Camp
>>|cRXP_WARN_Approach the Twilight Base Camp from the south for easier access to the|r |cRXP_PICK_Sandy Cookbook|r
.turnin 8307 >> Turn in Desert Recipe
.accept 8313 >> Accept Sharing the Knowledge
.skill cooking,<285,1 
step
.goto Silithus,51.893,39.163
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calandrath|r
.turnin 8313 >> Turn in Sharing the Knowledge
.accept 8317 >> Accept Kitchen Assistance
.skill cooking,<285,1 
.target Calandrath
step
.isQuestTurnedIn 1123
#completewith next
>>Kill |cRXP_ENEMY_Tortured Druids|r and |cRXP_ENEMY_Tortured Sentinels|r. |cRXP_WARN_Only ever engage ONE |cRXP_ENEMY_Tortured Druid|r or |cRXP_ENEMY_Tortured Sentinel|r at a time. When they die they have a chance to spawn a |cRXP_ENEMY_Hive'Ashi Drone|r which you will also have to kill|r
>>|cRXP_ENEMY_Hive'Ashi Drones|r may drop |T133463:0|t[|cRXP_LOOT_Brann Bronzebeard's Lost Letter|r]
.use 20461 >>|cRXP_WARN_Use |T133463:0|t[|cRXP_LOOT_Brann Bronzebeard's Lost Letter|r] to start the quest|r
.complete 1125,1 
.mob +Tortured Druid
.complete 1125,2 
.mob +Tortured Sentinel
.collect 20461,1,8308,1,1 
.mob +Tortured Druid
.mob +Tortured Sentinel
.accept 8308 >> Accept Brann Bronzebeard's Lost Letter
.disablecheckbox
step
.isOnQuest 5527
.goto Silithus,63.225,55.354
>>Enter the small lodge
>>Open the |cRXP_PICK_Dusty Reliquary|r on the ground. Loot it for the |cRXP_LOOT_Reliquary of Purity|r
.complete 5527,1 
step
.isQuestTurnedIn 1123
.goto Silithus,63.72,48.98
>>Kill |cRXP_ENEMY_Tortured Druids|r and |cRXP_ENEMY_Tortured Sentinels|r. |cRXP_WARN_Only ever engage ONE |cRXP_ENEMY_Tortured Druid|r or |cRXP_ENEMY_Tortured Sentinel|r at a time. When they die they have a chance to spawn a |cRXP_ENEMY_Hive'Ashi Drone|r which you will also have to kill|r
>>|cRXP_ENEMY_Hive'Ashi Drones|r may drop |T133463:0|t[|cRXP_LOOT_Brann Bronzebeard's Lost Letter|r]
.use 20461 >>|cRXP_WARN_Use |T133463:0|t[|cRXP_LOOT_Brann Bronzebeard's Lost Letter|r] to start the quest|r
.complete 1125,1 
.mob +Tortured Druid
.complete 1125,2 
.mob +Tortured Sentinel
.collect 20461,1,8308,1,1 
.mob +Tortured Druid
.mob +Tortured Sentinel
.accept 8308 >> Accept Brann Bronzebeard's Lost Letter
.disablecheckbox
step
#completewith HiveTower
>>Kill |cRXP_ENEMY_Dredge Strikers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
>>|cRXP_WARN_You don't need to collect all |cRXP_LOOT_Sandworm Meat|r now|r
.skill cooking,<285,1 
.complete 8280,1 
.collect 20424,10,8317,1,1 
.disablecheckbox
.mob Dredge Stalker
step
#completewith HiveTower
>>Kill |cRXP_ENEMY_Dredge Strikers|r
.complete 8280,1 
.mob Dredge Stalker
step
#completewith HiveTower
>>Kill |cRXP_ENEMY_Stonelash Scorpids|r and |cRXP_ENEMY_Sand Skitterers|r. Loot them for their |cRXP_LOOT_Stingers|r and |cRXP_LOOT_Fangs|r
.complete 8277,1 
.mob +Stonelash Scorpid
.complete 8277,2 
.mob +Sand Skitterer
step
.solo
.isQuestTurnedIn 1123
.goto Silithus,81.871,18.934
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Layo Starstrike|r
.turnin 1125 >> Turn in The Spirits of Southwind
.target Layo Starstrike
step
.group
.isQuestTurnedIn 1123
.goto Silithus,81.871,18.934
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Layo Starstrike|r
.turnin 1125 >> Turn in The Spirits of Southwind
.accept 1126 >> Accept Hive in the Tower
.target Layo Starstrike
step
.group 2
.isQuestTurnedIn 1123
.goto Silithus,60.354,52.558
>>Ascend the Southwind Village Tower. Entering the tower spawns 3 |cRXP_ENEMY_Hive'Ashi Drones|r which you will need to kill
>>Click the |cRXP_PICK_Hive'Ashi Pod|r atop the Tower. This will spawn 2 |cRXP_ENEMY_Hive'Ashi Ambushers|r
>>Kill the |cRXP_ENEMY_Hive'Ashi Ambushers|r. Loot them for the |cRXP_LOOT_Encrusted Silithid Object|r
.complete 1126,1 
.mob Hive'Ashi Ambusher
step
.group
.isQuestTurnedIn 1123
.goto Silithus,81.871,18.934
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Layo Starstrike|r
.turnin 1126 >> Turn in Hive in the Tower
.accept 6844 >> Accept Umber, Archivist
.target Layo Starstrike
step
#optional
#label HiveTower
step
#optional
#completewith s1
>>Kill |cRXP_ENEMY_Dredge Strikers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
>>|cRXP_WARN_You don't need to collect all |cRXP_LOOT_Sandworm Meat|r now|r
.skill cooking,<285,1 
.complete 8280,1 
.collect 20424,10,8317,1,1 
.disablecheckbox
.mob Dredge Stalker
step
#optional
#completewith s1
>>Kill |cRXP_ENEMY_Dredge Strikers|r
.complete 8280,1 
.mob Dredge Stalker
step
#optional
#completewith s1
>>Kill |cRXP_ENEMY_Stonelash Scorpids|r and |cRXP_ENEMY_Sand Skitterers|r. Loot them for their |cRXP_LOOT_Stingers|r and |cRXP_LOOT_Fangs|r
.complete 8277,1 
.mob +Stonelash Scorpid
.complete 8277,2 
.mob +Sand Skitterer
step
#label s1
#completewith next
.subzone 2740 >> Travel to The Crystal Vale
step
#loop
.goto Silithus,19.50,21.10,0
.goto Silithus,19.50,21.10,50,0
.goto Silithus,20.10,15.50,50,0
.goto Silithus,21.50,12.80,50,0
.goto Silithus,21.70,9.40,50,0
.goto Silithus,24.10,9.80,50,0
.goto Silithus,26.60,13.30,50,0
.goto Silithus,24.10,15.50,50,0
.goto Silithus,21.50,22.00,50,0
>>Loot the blue |cRXP_PICK_Glowing Tablets|r on the ground for |cRXP_LOOT_Twilight Tablet Fragments|r
.complete 8284,1 
step
#optional
#completewith StingFangs
>>Kill |cRXP_ENEMY_Dredge Strikers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
>>|cRXP_WARN_You don't need to collect all |cRXP_LOOT_Sandworm Meat|r now|r
.skill cooking,<285,1 
.complete 8280,1 
.collect 20424,10,8317,1,1 
.disablecheckbox
.mob Dredge Stalker
step
#optional
#completewith StingFangs
>>Kill |cRXP_ENEMY_Dredge Strikers|r
.complete 8280,1 
.mob Dredge Stalker
step
#label StingFangs
#loop
.goto Silithus,51.60,16.40,0
.goto Silithus,51.60,16.40,70,0,0
.goto Silithus,54.60,13.20,70,0,0
.goto Silithus,58.40,13.60,70,0,0
.goto Silithus,62.60,16.60,70,0,0
.goto Silithus,61.40,21.60,70,0,0
.goto Silithus,63.20,24.00,70,0,0
.goto Silithus,64.80,28.20,70,0,0
.goto Silithus,67.60,32.00,70,0,0
.goto Silithus,60.60,30.60,70,0,0
.goto Silithus,56.40,32.80,70,0,0
.goto Silithus,53.00,28.00,70,0,0
.goto Silithus,54.80,21.80,70,0,0
>>Kill |cRXP_ENEMY_Stonelash Scorpids|r and |cRXP_ENEMY_Sand Skitterers|r. Loot them for their |cRXP_LOOT_Stingers|r and |cRXP_LOOT_Fangs|r
.complete 8277,1 
.mob +Stonelash Scorpid
.complete 8277,2 
.mob +Sand Skitterer
step
#loop
.goto Silithus,63.20,24.00,0
.goto Silithus,51.60,16.40,70,0,0
.goto Silithus,54.60,13.20,70,0,0
.goto Silithus,58.40,13.60,70,0,0
.goto Silithus,62.60,16.60,70,0,0
.goto Silithus,61.40,21.60,70,0,0
.goto Silithus,63.20,24.00,70,0,0
.goto Silithus,64.80,28.20,70,0,0
.goto Silithus,67.60,32.00,70,0,0
.goto Silithus,60.60,30.60,70,0,0
.goto Silithus,56.40,32.80,70,0,0
.goto Silithus,53.00,28.00,70,0,0
.goto Silithus,54.80,21.80,70,0,0
>>Kill |cRXP_ENEMY_Dredge Strikers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
>>|cRXP_WARN_You don't need to collect all |cRXP_LOOT_Sandworm Meat|r now|r
.skill cooking,<285,1 
.complete 8280,1 
.collect 20424,10,8317,1,1 
.disablecheckbox
.mob Dredge Stalker
step
#loop
.goto Silithus,63.20,24.00,0
.goto Silithus,51.60,16.40,70,0,0
.goto Silithus,54.60,13.20,70,0,0
.goto Silithus,58.40,13.60,70,0,0
.goto Silithus,62.60,16.60,70,0,0
.goto Silithus,61.40,21.60,70,0,0
.goto Silithus,63.20,24.00,70,0,0
.goto Silithus,64.80,28.20,70,0,0
.goto Silithus,67.60,32.00,70,0,0
.goto Silithus,60.60,30.60,70,0,0
.goto Silithus,56.40,32.80,70,0,0
.goto Silithus,53.00,28.00,70,0,0
.goto Silithus,54.80,21.80,70,0,0
>>Kill |cRXP_ENEMY_Dredge Strikers|r
.complete 8280,1 
.mob Dredge Stalker
step
.goto Silithus,49.70,37.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larksbane|r
.turnin 8284 >>Turn in The Twilight Mystery
.accept 8285 >>Accept The Deserter
.target Geologist Larksbane
step
.goto Silithus,49.20,34.20
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mar'alith|r
.accept 8304 >>Accept Dearest Natalia
.target Commander Mar'alith
step
.goto Silithus,51.15,38.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Proudhorn|r
.turnin 8280 >>Turn in Securing the Supply Lines
.accept 8281 >>Accept Stepping Up Security
.target Windcaller Proudhorn
step
.goto Silithus,51.80,38.51
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beetix|r on the second floor of the inn
.turnin 8277 >>Turn in Deadly Desert Venom
.accept 8278 >>Accept Noggle's Last Hope
.target Beetix Ficklespragg
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bor|r and |cRXP_FRIENDLY_Huum|r
.accept 8361 >>Accept Abyssal Contacts
.accept 8318 >>Accept Secret Communication
.target +Bor Wildmane
.goto Silithus,48.64,37.86
.accept 8320 >>Accept Twilight Geolords
.target +Huum Wildmane
.goto Silithus,48.58,37.76
step
#completewith Dwarves
>>Kill |cRXP_ENEMY_Dredge Crushers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
.complete 8281,1 
.collect 20424,10,8317,1 
.skill cooking,<285,1 
.mob Dredge Crusher
step
#completewith Dwarves
>>Kill |cRXP_ENEMY_Dredge Crushers|r
.complete 8281,1 
.skill cooking,285,1 
.mob Dredge Crusher
step
#completewith Dwarves
.goto Silithus,62.52,64.00,0
.goto Silithus,50.73,55.99,0
>>Kill |cRXP_ENEMY_Stonelash Flayers|r and |cRXP_ENEMY_Stonelash Pincers|r. Loot them for their |cRXP_LOOT_Stingers|r
>>Kill |cRXP_ENEMY_Rock Stalkers|r. Loot them for their |cRXP_LOOT_Fangs|r
.complete 8278,1 
.mob +Stonelash Flayer
.complete 8278,2 
.mob +Stonelash Pincer
.complete 8278,3 
.mob +Rock Stalker
step
#label Deserter
.goto Silithus,67.19,69.75
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hermit|r
.turnin 8285 >>Turn in The Deserter
.accept 8279 >>Accept The Twilight Lexicon
.target Hermit Ortell
step
#optional
.goto Silithus,41.279,88.456
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rutgar Glyphshaper|r
.use 20461 >> |cRXP_WARN_Use|r |T133463:0|t[|cRXP_LOOT_Brann Bronzebeard's Lost Letter|r] |cRXP_WARN_to start the quest|r
.accept 8308 >> Accept Brann Bronzebeard's Lost Letter
.turnin 8308 >> Turn in Brann Bronzebeard's Lost Letter
.itemcount 20461,1 
.target Rutgar Glyphshaper
step
#label Dwarves
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rutgar|r and |cRXP_FRIENDLY_Frankal|r
.complete 8304,2 
.target +Rutgar Glyphshaper
.goto Silithus,41.27,88.45
.complete 8304,1 
.target +Frankal Stonebridge
.goto Silithus,40.81,88.86
.skipgossip
step
#optional
#completewith AbyssalCrest
>>Kill |cRXP_ENEMY_Twilight Geolords|r
.complete 8320,1 
.mob Twilight Geolord
step
#optional
#completewith Geolords
>>Kill |cRXP_ENEMY_Twilight Cultists|r. Loot them for their |cRXP_LOOT_Encrypted Twilight Texts|r
>>|cRXP_ENEMY_Twilight Keepers|r|cRXP_WARN_,|r |cRXP_ENEMY_Overlords|r |cRXP_WARN_and|r |cRXP_ENEMY_Masters|r |cRXP_WARN_have very high burst potential|r
.collect 20404,10,8323,1 
.mob Twilight Stonecaller
.mob Twilight Avenger
.mob Twilight Geolord
.mob Twilight Flamereaver
.mob Twilight Master
.mob Twilight Overlord
.mob Twilight Marauder
step
#optional
#completewith LexiconChapter2
>>Kill |cRXP_ENEMY_Twilight|r mobs in |cFFfa9602Silithus|r. Loot them for their |T132658:0|t[|cRXP_FRIENDLY_Twilight Cultist|r] gear
.collect 20407,1,8361,1 
.collect 20406,1,8361,1 
.collect 20408,1,8361,1 









step
.goto Silithus,40.86,42.22
>>Kill |cRXP_ENEMY_Twilight Keeper Havunth|r. Loot him for his |cRXP_LOOT_Twilight Lexicon Chapter|r
>>He patrols the east side of the camp that's just southwest of Cenarion Hold
>>|cRXP_WARN_Be careful, he has very high burst|r
.complete 8279,3 
.unitscan Twilight Keeper Havunth
step
.goto Silithus,26.34,36.62
>>Kill |cRXP_ENEMY_Twilight Keeper Mayna|r. Loot her for her |cRXP_LOOT_Twilight Lexicon Chapter|r
>>|cRXP_WARN_She patrols the camp far west of Cenarion Hold|r
>>|cRXP_WARN_Be careful, she has Psychic Scream (instant fear)|r
.complete 8279,1 
.unitscan Twilight Keeper Mayna
step
#label LexiconChapter2
.goto Silithus,16.08,86.37
>>Kill |cRXP_ENEMY_Twilight Keeper Exeter|r. Loot him for his |cRXP_LOOT_Twilight Lexicon Chapter|r
>>He's at the back of the camp very far to the southwest of Cenarion Hold/northwest of Ahn'Qiraj
>>|cRXP_WARN_Be careful, he has a stun and mortal strike|r
.complete 8279,2 
.unitscan Twilight Keeper Exeter
step
#loop
.goto Silithus,38.31,46.42,0
.goto Silithus,27.93,30.66,0
.goto Silithus,20.47,86.11,0
.goto Silithus,38.31,46.42,80,0
.goto Silithus,27.93,30.66,80,0
.goto Silithus,20.47,86.11,80,0
>>Kill |cRXP_ENEMY_Twilight|r mobs in |cFFfa9602Silithus|r. Loot them for their |T132658:0|t[|cRXP_FRIENDLY_Twilight Cultist|r] gear
.collect 20407,1,8361,1 
.collect 20406,1,8361,1 
.collect 20408,1,8361,1 
.mob Twilight Marauder
.mob Twilight Marauder Morna
.mob Twilight Avenger
.mob Twilight Geolord
.mob Twilight Stonecaller
.mob Twilight Overlord
.mob Twilight Flamereaver
.mob Twilight Master
step
#completewith next
+|cRXP_WARN_Equip the|r |T132658:0|t[|cRXP_FRIENDLY_Twilight Cultist|r] |cRXP_WARN_gear|r
step
#label AbyssalCrest
#loop
.goto Silithus,38.31,46.42,0
.goto Silithus,27.93,30.66,0
.goto Silithus,20.47,86.11,0
.goto Silithus,38.31,46.42,20,0
.goto Silithus,27.93,30.66,20,0
.goto Silithus,20.47,86.11,20,0
>>Travel to a |cRXP_PICK_Lesser Wind Stone|r in one of the three |cRXP_ENEMY_Twilight|r camps. They are marked on your map
>>Summon a |cRXP_ENEMY_Templar|r and kill it. Loot it for it's |T133438:0|t[|cRXP_LOOT_Abyssal Crest|r]
>>|cRXP_WARN_DO NOT click the |cRXP_PICK_Lesser Wind Stone|r without wearing the|r |T132658:0|t[|cRXP_FRIENDLY_Twilight Cultist|r] |cRXP_WARN_gear. This will instantly cause 1500 damage to you!|r
.collect 20513,1,8361,1 
.mob Earthen Templar
.mob Crimson Templar
.mob Hoary Templar
.mob Azure Templar
.skipgossip
step
#label Geolords
#loop
.goto Silithus,38.31,46.42,0
.goto Silithus,27.93,30.66,0
.goto Silithus,20.47,86.11,0
.goto Silithus,38.31,46.42,80,0
.goto Silithus,27.93,30.66,80,0
.goto Silithus,20.47,86.11,80,0
>>Kill |cRXP_ENEMY_Twilight Geolords|r
.complete 8320,1 
.mob Twilight Geolord
step
#loop
.goto Silithus,38.31,46.42,0
.goto Silithus,27.93,30.66,0
.goto Silithus,20.47,86.11,0
.goto Silithus,38.31,46.42,80,0
.goto Silithus,27.93,30.66,80,0
.goto Silithus,20.47,86.11,80,0
>>Kill |cRXP_ENEMY_Twilight Cultists|r. Loot them for their |cRXP_LOOT_Encrypted Twilight Texts|r
>>|cRXP_ENEMY_Twilight Keepers|r|cRXP_WARN_,|r |cRXP_ENEMY_Overlords|r |cRXP_WARN_and|r |cRXP_ENEMY_Masters|r |cRXP_WARN_have very high burst potential|r
.collect 20404,10,8323,1 
.mob Twilight Stonecaller
.mob Twilight Avenger
.mob Twilight Geolord
.mob Twilight Flamereaver
.mob Twilight Master
.mob Twilight Overlord
.mob Twilight Marauder
step
#optional
#completewith HermitTurnins
>>Kill |cRXP_ENEMY_Dredge Crushers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
.complete 8281,1 
.collect 20424,10,8317,1 
.skill cooking,<285,1 
.mob Dredge Crusher
step
#optional
#completewith HermitTurnins
>>Kill |cRXP_ENEMY_Dredge Crushers|r
.complete 8281,1 
.skill cooking,285,1 
.mob Dredge Crusher
step
#completewith HermitTurnins
.goto Silithus,62.52,64.00,0
.goto Silithus,50.73,55.99,0
>>Kill |cRXP_ENEMY_Stonelash Flayers|r and |cRXP_ENEMY_Stonelash Pincers|r. Loot them for their |cRXP_LOOT_Stingers|r
>>Kill |cRXP_ENEMY_Rock Stalkers|r. Loot them for their |cRXP_LOOT_Fangs|r
.complete 8278,1 
.mob +Stonelash Flayer
.complete 8278,2 
.mob +Stonelash Pincer
.complete 8278,3 
.mob +Rock Stalker
step
#label HermitTurnins
.goto Silithus,67.20,69.80
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Hermit|r
.turnin 8279 >>Turn in The Twilight Lexicon
.accept 8287 >>Accept A Terrible Purpose
.accept 8323 >>Accept True Believers
.turnin 8323 >>Turn in True Believers
.target Hermit Ortell
step
#optional
#completewith HermitTurnins
>>Kill |cRXP_ENEMY_Dredge Crushers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
.complete 8281,1 
.collect 20424,10,8317,1 
.skill cooking,<285,1 
.mob Dredge Crusher
step
#optional
#completewith HermitTurnins
>>Kill |cRXP_ENEMY_Dredge Crushers|r
.complete 8281,1 
.skill cooking,285,1 
.mob Dredge Crusher
step
#loop
.goto Silithus,62.20,63.20,0
.goto Silithus,62.20,63.20,70,0
.goto Silithus,57.00,59.20,70,0
.goto Silithus,50.80,58.00,70,0
.goto Silithus,47.80,54.60,70,0
.goto Silithus,40.80,50.20,70,0
.goto Silithus,34.60,49.40,70,0
.goto Silithus,36.20,39.40,70,0
.goto Silithus,33.60,34.60,70,0
.goto Silithus,27.80,43.40,70,0
.goto Silithus,33.00,49.00,70,0
.goto Silithus,34.60,53.60,70,0
.goto Silithus,34.60,60.40,70,0
.goto Silithus,34.20,65.40,70,0
.goto Silithus,39.40,64.60,70,0
.goto Silithus,42.60,61.40,70,0
.goto Silithus,48.80,62.40,70,0
.goto Silithus,52.80,63.00,70,0
.goto Silithus,59.00,64.40,70,0
.goto Silithus,62.60,66.20,70,0
>>Kill |cRXP_ENEMY_Stonelash Pincers|r. Loot them for their |cRXP_LOOT_Stingers|r
.complete 8278,2 
.mob Stonelash Pincer
step
#loop
.goto Silithus,62.20,63.20,0
.goto Silithus,62.20,63.20,70,0
.goto Silithus,57.00,59.20,70,0
.goto Silithus,50.80,58.00,70,0
.goto Silithus,47.80,54.60,70,0
.goto Silithus,40.80,50.20,70,0
.goto Silithus,34.60,49.40,70,0
.goto Silithus,36.20,39.40,70,0
.goto Silithus,33.60,34.60,70,0
.goto Silithus,27.80,43.40,70,0
.goto Silithus,33.00,49.00,70,0
.goto Silithus,34.60,53.60,70,0
.goto Silithus,34.60,60.40,70,0
.goto Silithus,34.20,65.40,70,0
.goto Silithus,39.40,64.60,70,0
.goto Silithus,42.60,61.40,70,0
.goto Silithus,48.80,62.40,70,0
.goto Silithus,52.80,63.00,70,0
.goto Silithus,59.00,64.40,70,0
.goto Silithus,62.60,66.20,70,0
>>Kill |cRXP_ENEMY_Dredge Crushers|r. Loot them for their |cRXP_LOOT_Sandworm Meat|r
.complete 8281,1 
.collect 20424,10,8317,1 
.skill cooking,<285,1 
.mob Dredge Crusher
step
#loop
.goto Silithus,62.20,63.20,0
.goto Silithus,62.20,63.20,70,0
.goto Silithus,57.00,59.20,70,0
.goto Silithus,50.80,58.00,70,0
.goto Silithus,47.80,54.60,70,0
.goto Silithus,40.80,50.20,70,0
.goto Silithus,34.60,49.40,70,0
.goto Silithus,36.20,39.40,70,0
.goto Silithus,33.60,34.60,70,0
.goto Silithus,27.80,43.40,70,0
.goto Silithus,33.00,49.00,70,0
.goto Silithus,34.60,53.60,70,0
.goto Silithus,34.60,60.40,70,0
.goto Silithus,34.20,65.40,70,0
.goto Silithus,39.40,64.60,70,0
.goto Silithus,42.60,61.40,70,0
.goto Silithus,48.80,62.40,70,0
.goto Silithus,52.80,63.00,70,0
.goto Silithus,59.00,64.40,70,0
.goto Silithus,62.60,66.20,70,0
>>Kill |cRXP_ENEMY_Dredge Crushers|r
.complete 8281,1 
.skill cooking,285,1 
.mob Dredge Crusher
step
#loop
.goto Silithus,42.60,86.40,0
.goto Silithus,42.60,86.40,70,0
.goto Silithus,38.60,87.40,70,0
.goto Silithus,38.20,83.20,70,0
.goto Silithus,34.00,76.60,70,0
.goto Silithus,32.00,81.00,70,0
.goto Silithus,27.60,85.20,70,0
.goto Silithus,24.60,82.00,70,0
.goto Silithus,23.40,77.20,70,0
.goto Silithus,27.60,76.40,70,0
.goto Silithus,31.60,74.80,70,0
.goto Silithus,34.60,71.40,70,0
.goto Silithus,38.60,69.20,70,0
.goto Silithus,43.00,68.40,70,0
.goto Silithus,46.80,69.60,70,0
.goto Silithus,44.20,75.60,70,0
.goto Silithus,45.40,80.20,70,0
.goto Silithus,45.40,85.60,70,0
>>Kill |cRXP_ENEMY_Stonelash Flayers|r and |cRXP_ENEMY_Rock Stalkers|r. Loot them for their |cRXP_LOOT_Stingers|r and |cRXP_LOOT_Fangs|r
.complete 8278,1 
.mob +Stonelash Flayer
.complete 8278,3 
.mob +Rock Stalker
step
.goto Silithus,51.15,38.29
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Proudhorn|r
.turnin 8281 >>Turn in Stepping Up Security
.target Windcaller Proudhorn
step
.goto Silithus,51.893,39.163
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Calandrath|r
.turnin 8317 >> Turn in Kitchen Assistance
.skill cooking,<285,1 
.target Calandrath
.isQuestComplete 8317
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Beetix|r and |cRXP_FRIENDLY_Noggle|r
.turnin 8278 >>Turn in Noggle's Last Hope
.target +Beetix Ficklespragg
.goto Silithus,51.80,38.51
.accept 8282 >>Accept Noggle's Lost Satchel
.target +Noggle Ficklespragg
.goto Silithus,51.62,38.50
step
.goto Silithus,49.20,34.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mar'alith|r
.turnin 8304 >>Turn in Dearest Natalia
.turnin 8287 >>Turn in A Terrible Purpose
.accept 8306 >>Accept Into The Maw of Madness
.target Commander Mar'alith
.group
step
.goto Silithus,49.20,34.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mar'alith|r
.turnin 8304 >>Turn in Dearest Natalia
.turnin 8287 >>Turn in A Terrible Purpose
.target Commander Mar'alith
.solo
step
#optional
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bor|r and |cRXP_FRIENDLY_Huum|r
.turnin 8361 >>Turn in Abyssal Contacts
.turnin 8318 >>Turn in Secret Communication
.target +Bor Wildmane
.goto Silithus,48.64,37.86
.turnin 8320 >>Turn in Twilight Geolords
.target +Huum Wildmane
.goto Silithus,48.58,37.76
.itemcount 20404,10 
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bor|r and |cRXP_FRIENDLY_Huum|r
.turnin 8361 >>Turn in Abyssal Contacts
.target +Bor Wildmane
.goto Silithus,48.64,37.86
.turnin 8320 >>Turn in Twilight Geolords
.target +Huum Wildmane
.goto Silithus,48.58,37.76
step
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rutgar|r and |cRXP_FRIENDLY_Frankal|r
.accept 8309 >> Accept Glyph Chasing
.target +Rutgar Glyphshaper
.goto Silithus,41.27,88.45
.accept 8310 >> Accept Breaking the Code
.target +Frankal Stonebridge
.goto Silithus,40.81,88.86
.group
step
#label HigeRegalHole
#completewith HiveRegalComplete
.goto Silithus,54.92,88.08,20 >> Enter the Hive'Regal bughole
.group 0
step
#requires HigeRegalHole
#completewith HiveRegalComplete
.goto Silithus,53.79,88.51,12,0
.goto Silithus,52.44,89.90,12,0
.goto Silithus,52.81,92.37,12,0
.goto Silithus,53.84,95.55,12,0
.goto Silithus,52.03,99.45,12 >>Travel toward the southern chamber in the Hive'Regal bughole
.group 0
step
#completewith HiveRegalComplete
>>Kill |cRXP_ENEMY_Hive'Regal Silithids|r. Look them for a |cRXP_LOOT_Hive'Regal Silithid Brain|r
.complete 8310,3 
.mob Hive'Regal Hive Lord
.mob Hive'Regal Slavemaker
.mob Hive'Regal Ambusher
.mob Hive'Regal Spitfire
.mob Hive'Regal Spitfire
.group 2
step
.goto Kalimdor,44.40,86.10
>>Kill |cRXP_ENEMY_Mistress Natalia Mar'alith|r
.complete 8306,1 
.mob Mistress Natalia Mar'alith
.group 2
step
#label HiveRegalComplete
.goto Kalimdor,44.40,86.10
>>Click on the |cRXP_PICK_Hive'Regal Glyphed Crystal|r
.complete 8309,3 
.skipgossip
.group 2
step
#loop
.goto Silithus,54.84,81.80,0
.goto Silithus,54.84,81.80,70,0
.goto Silithus,56.00,74.79,70,0
.goto Silithus,60.46,73.97,70,0
.goto Silithus,60.94,81.32,70,0
.goto Silithus,60.60,89.91,70,0
.goto Silithus,56.32,86.98,70,0
>>Kill |cRXP_ENEMY_Hive'Regal|r. Look them for a |cRXP_LOOT_Silithid Brain|r
.complete 8310,3 
.mob Hive'Regal Hive Lord
.mob Hive'Regal Slavemaker
.mob Hive'Regal Ambusher
.mob Hive'Regal Spitfire
.mob Hive'Regal Spitfire
.group 2
step
#label HiveZoraHole
#completewith HiveZoraComplete
.goto Silithus,27.98,66.11,20 >>Enter the Hive'Zora bughole
.group 0
step
#requires HiveZoraHole
#completewith HiveZoraComplete
.goto Silithus,28.65,67.10,12,0
.goto Silithus,30.37,68.36,12,0
.goto Silithus,31.78,65.82,12,0
.goto Silithus,32.81,63.40,12,0
.goto Silithus,35.69,63.55,12,0
.goto Silithus,36.51,63.98,12 >>Travel toward the eastern chamber in the Hive'Zora bughole
.group 0
step
#completewith HiveZoraComplete
>>Kill |cRXP_ENEMY_Hive'Zora Silithids|r. Loot them for a |cRXP_LOOT_Hive'Zora Silithid Brain|r
.complete 8310,2 
.mob Hive'Zora Reaver
.mob Hive'Zora Waywatcher
.mob Hive'Zora Hive Sister
.mob Hive'Zora Wasp
.mob Hive'Zora Tunneler
.group 2
step
#label HiveZoraComplete
.goto Silithus,37.27,62.47
>>Click on the |cRXP_PICK_Hive'Regal Glyphed Crystal|r
.complete 8309,2 
.skipgossip
.group 2
step
#loop
.goto Silithus,26.56,64.53,0
.goto Silithus,26.56,64.53,70,0
.goto Silithus,21.69,61.62,70,0
.goto Silithus,25.17,58.66,70,0
>>Kill |cRXP_ENEMY_Hive'Zora Silithids|r. Loot them for a |cRXP_LOOT_Hive'Zora Silithid Brain|r
.complete 8310,2 
.mob Hive'Zora Reaver
.mob Hive'Zora Waywatcher
.mob Hive'Zora Hive Sister
.mob Hive'Zora Wasp
.mob Hive'Zora Tunneler
.group 2
step
#label HiveAshiHole
#completewith HiveAshiComplete
.goto Silithus,49.31,25.42,20 >>Enter the Hive'Ashi bughole
>>|cRXP_WARN_Enter through the bottom entrance|r
.group 0
step
#requires HiveAshiHole
#completewith HiveAshiComplete
.goto Silithus,49.87,24.73,12,0
.goto Silithus,50.60,25.90,120 >>Travel toward the eastern chamber in the Hive'Ashi bughole
.group 0
step
#completewith HiveAshiComplete
>>Kill |cRXP_ENEMY_Hive'Ashi Silithid|r. Loot them for a |cRXP_LOOT_Hive'Ashi Silithid Brain|r
.complete 8310,1 
.mob Hive'Ashi Defender
.mob Hive'Ashi Swarmer
.mob Hive'Ashi Sandstalker
.mob Hive'Ashi Stinger
.mob Hive'Ashi Worker
.mob Hive'Ashi Ambusher
.mob Hive'Ashi Drone
.group 2
step
#label HiveAshiComplete
.goto Silithus,50.84,26.73
>>Click on the |cRXP_PICK_Hive'Ashi Glyphed Crystal|r
.complete 8309,1 
.skipgossip
.group 2
step
#loop
.goto Silithus,46.88,29.90,0
.goto Silithus,46.88,29.90,70,0
.goto Silithus,44.45,26.50,70,0
.goto Silithus,43.48,18.36,70,0
.goto Silithus,47.40,21.67,70,0
>>Kill |cRXP_ENEMY_Hive'Ashi Silithid|r. Loot them for a |cRXP_LOOT_Hive'Ashi Silithid Brain|r
.complete 8310,1 
.mob Hive'Ashi Defender
.mob Hive'Ashi Swarmer
.mob Hive'Ashi Sandstalker
.mob Hive'Ashi Stinger
.mob Hive'Ashi Worker
.mob Hive'Ashi Ambusher
.mob Hive'Ashi Drone
.group 2
step
.goto Silithus,40.81,88.86
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rutgar|r
.turnin 8310 >> Turn in Breaking the Code
.target Frankal Stonebridge
.isQuestComplete 8310
.group
step
.goto Silithus,41.27,88.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Frankal|r
.turnin 8309 >> Turn in Glyph Chasing
.accept 8314 >> Accept Unraveling the Mystery
.target Rutgar Glyphshaper
.isQuestComplete 8309
.group
step
#optional
.goto Silithus,41.27,88.45
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Frankal|r
.accept 8314 >> Accept Unraveling the Mystery
.target Rutgar Glyphshaper
.isQuestTurnedIn 8309
.group
step
#optional
.goto Silithus,41.279,88.456
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rutgar Glyphshaper|r
.use 20461 >> |cRXP_WARN_Use|r |T133463:0|t[|cRXP_LOOT_Brann Bronzebeard's Lost Letter|r] |cRXP_WARN_to start the quest|r
.accept 8308 >> Accept Brann Bronzebeard's Lost Letter
.turnin 8308 >> Turn in Brann Bronzebeard's Lost Letter
.itemcount 20461,1 
.target Rutgar Glyphshaper
step
.goto Silithus,45.00,92.20
>>Kill |cRXP_ENEMY_Deathclasp|r. Loot him for his |cRXP_LOOT_Pincer|r
>>|cRXP_WARN_This quest mob hits hard and has a poison debuff that can stun for 8 seconds|r
.complete 8283,1 
.mob Stonelash Flayer
.unitscan Deathclasp
.group 3
step
.goto Silithus,44.50,91.40
>>Loot |cRXP_LOOT_Noggle's Satchel|r on the ground
>>|cRXP_WARN_Be careful not to aggro |cRXP_ENEMY_Deathclasp|r. He hits hard and has a poison debuff that can stun for 8 seconds|r
.complete 8282,1 
.unitscan Deathclasp
.solo
step
.goto Silithus,44.50,91.40
>>Loot |cRXP_LOOT_Noggle's Satchel|r on the ground
.complete 8282,1 
.unitscan Deathclasp
.group 0
step
#completewith FinalSilithisTurnins
.subzone 3425 >>Travel to Cenarion Hold
step
.goto Silithus,48.57,37.78
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bor|r
.turnin 8318 >>Turn in Secret Communication
.target Bor Wildmane
.itemcount 20404,10 
step
.goto Silithus,49.20,34.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mar'alith|r
.turnin 8306 >> Turn in Into The Maw of Madness
.target Commander Mar'alith
.isQuestComplete 8306
.group
step
.goto Silithus,49.70,37.30
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Larksbane|r
.turnin 8314 >> Turn in Unraveling the Mystery
.target Geologist Larksbane
.group
.isOnQuest 8314
step
.goto Silithus,50.80,33.60
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Vish Kozus|r
.turnin 8283 >> Turn in Wanted - Deathclasp, Terror of the Sands
.target Vish Kozus
.isQuestComplete 8283
.group
step
#label FinalSilithisTurnins
.goto Silithus,51.62,38.50
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Noggle|r
.turnin 8282 >>Turn in Noggle's Lost Satchel
.target Noggle Ficklespragg
step << Druid
#completewith DruidTraining10
.cast 18960 >>|cRXP_WARN_Cast|r |T135758:0|t[Teleport: Moonglade]
.zoneskip Moonglade
step << Druid
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 31018 >>Train your class spells
.target Loganaar
.xp <60,1
step << Druid
#label DruidTraining10
.goto Moonglade,52.53,40.58
>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Loganaar|r
.train 26984 >>Train your class spells
.target Loganaar
.xp <61,1
step
.hs >> Hearth to Thrallmar
>>|cRXP_BUY_Buy food/water if needed|r << !Warrior !Rogue !DK
>>|cRXP_BUY_Buy food if needed|r << Warrior/Rogue/DK
.bindlocation 3536,1
.subzoneskip 3536
]])

