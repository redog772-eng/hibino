local addonName, addon = ...
if GetLocale() ~= "koKR" then return end
local translations = addon.koreanFull or {}
local previous = addon.locale.Get
local nativeNames = addon.koreanNativeNames or {}
local function localNames(text)
    return (text:gsub("%[([^%]]+)%]",function(name)
        local cleanName = name:gsub("|cRXP_[A-Z]+_", ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        local entry = nativeNames[cleanName]
        if not entry then return "["..name.."]" end
        local localized
        if entry[1] == "collect" and type(GetItemInfo) == "function" then
            localized = GetItemInfo(entry[2])
        elseif entry[1] == "train" then
            if C_Spell and type(C_Spell.GetSpellName) == "function" then
                localized = C_Spell.GetSpellName(entry[2])
            elseif type(GetSpellInfo) == "function" then
                localized = GetSpellInfo(entry[2])
            end
        end
        if localized and cleanName ~= name then
            local first,last = name:find(cleanName,1,true)
            if first then return "["..name:sub(1,first-1)..localized..name:sub(last+1).."]" end
        end
        return "["..(localized or name).."]"
    end))
end
local function translated(text)
    if type(text) ~= "string" then return text end
    if translations[text] then return localNames(translations[text]) end
    local trimmed = text:match("^%s*(.-)%s*$")
    if translations[trimmed] then return localNames(translations[trimmed]) end
    return localNames(previous(text))
end
addon.locale.Get = translated
addon.KoreanFullTranslate = translated
local L = LibStub("AceLocale-3.0"):GetLocale(addonName)
-- The generated table retains existing Korean translations and repairs format argument order.
for key, value in pairs(translations) do rawset(L,key,value) end
