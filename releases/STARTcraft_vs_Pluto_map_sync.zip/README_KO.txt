STARTcraft vs Pluto - 실행 전 맵 자동 동기화

설치:
1. StarCraft, StarterBot, Pluto를 모두 종료하세요.
2. 기존 run_STARTcraft_vs_Pluto.cmd가 있는 폴더를 여세요.
3. 그 안의 tools/run_arena.ps1을 run_arena.backup.ps1로 복사해 보관하세요.
4. 이 ZIP의 tools/run_arena.ps1을 기존 tools 폴더에 넣고 덮어쓰세요.
5. 평소처럼 run_STARTcraft_vs_Pluto.cmd를 실행하세요.

실행 전 host/maps의 .scx/.scm 파일을 pluto/maps의 같은 상대 경로로 복사합니다.
SHA256이 같으면 건너뛰며, 다르면 기존 Pluto 맵을 arena/STARTcraft_vs_Pluto/map_backups에 백업합니다.
맵이나 폴더를 삭제하지 않습니다. 파일 내용 확인이 실패하면 게임 실행을 중단합니다.
Maps verified: ... 메시지로 동기화 결과를 확인할 수 있습니다.

이 수정은 양쪽 맵 파일 불일치를 예방합니다. 게임 내부의 맵 검색/저장 경로가 다른 경우
다운로드가 계속될 수 있으므로, 그때는 양쪽 bwapi-data/bwapi.ini와 실행 화면을 확인해야 합니다.
이 환경에는 PowerShell/StarCraft가 없어 Windows 실행 검증은 하지 못했습니다.
AI 버전과 게임 전략은 바뀌지 않습니다.
