param(
    [int]$Matches = 5,
    [int]$TimeoutMinutes = 20,
    [string]$Root = 'C:\Users\User\starcraft-api\STARTcraft'
)

$ErrorActionPreference = 'Stop'
$arena = Join-Path $Root 'arena\STARTcraft_vs_Pluto'
$hostRoot = Join-Path $arena 'host'
$guestRoot = Join-Path $arena 'pluto'
$reports = Join-Path $Root 'AI_reports'
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$batch = Join-Path $reports "v52_batch_$stamp"

function Require-File([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Missing file: $Path"
    }
}

function Stop-Arena {
    Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -in @('StarCraft','StarterBot','pluto_infer')
    } | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 3
}

function Start-Game([string]$Runtime) {
    $inject = Join-Path $Runtime 'injectory_x86.exe'
    Start-Process -FilePath $inject -WorkingDirectory $Runtime `
        -ArgumentList @('--launch','StarCraft.exe','--inject','bwapi-data\BWAPI.dll') | Out-Null
}

try {
    if ($Matches -lt 1 -or $Matches -gt 20) { throw 'Matches must be between 1 and 20.' }
    $bot = Join-Path $hostRoot 'bin\StarterBot.exe'
    $hostGame = Join-Path $hostRoot 'StarCraft.exe'
    $guestGame = Join-Path $guestRoot 'StarCraft.exe'
    $finish = Join-Path $reports 'AI_v29_finished.flag'
    $construction = Join-Path $reports 'AI_v52_construction.csv'
    $timeline = Join-Path $reports 'AI_v29_latest.csv'
    $replay = Join-Path $hostRoot 'Replays\STARTcraft_vs_Pluto.rep'
    $plutoLog = Join-Path $guestRoot 'pluto.log'
    $inferLog = Join-Path $guestRoot 'pluto_infer.log'
    foreach ($file in @($bot,$hostGame,$guestGame,
        (Join-Path $hostRoot 'injectory_x86.exe'),
        (Join-Path $guestRoot 'injectory_x86.exe'))) { Require-File $file }
    New-Item -ItemType Directory -Path $batch -Force | Out-Null
    Stop-Arena

    for ($index=1; $index -le $Matches; $index++) {
        Write-Host "MATCH $index/$Matches starting..."
        Remove-Item -LiteralPath $finish,$construction,$timeline -Force -ErrorAction SilentlyContinue
        Start-Process -FilePath $bot -WorkingDirectory (Split-Path $bot) | Out-Null
        Start-Sleep -Seconds 2
        Start-Game $hostRoot
        Start-Sleep -Seconds 5
        Start-Game $guestRoot

        $deadline = (Get-Date).AddMinutes($TimeoutMinutes)
        while (-not (Test-Path -LiteralPath $finish -PathType Leaf)) {
            if ((Get-Date) -ge $deadline) { break }
            Start-Sleep -Seconds 5
        }
        $timedOut = -not (Test-Path -LiteralPath $finish -PathType Leaf)
        if ($timedOut) { Write-Host "MATCH $index timed out." }
        else { Write-Host "MATCH $index finished." }
        Start-Sleep -Seconds 5
        Stop-Arena

        $destination = Join-Path $batch ('match_{0:d2}' -f $index)
        New-Item -ItemType Directory -Path $destination -Force | Out-Null
        foreach ($item in @($finish,$construction,$timeline,$replay,$plutoLog,$inferLog)) {
            if (Test-Path -LiteralPath $item -PathType Leaf) {
                Copy-Item -LiteralPath $item -Destination $destination -Force
            }
        }
        if ($timedOut) { Set-Content -LiteralPath (Join-Path $destination 'TIMEOUT.txt') -Value 'Match timed out.' }
    }
    $zip = "$batch.zip"
    Compress-Archive -LiteralPath $batch -DestinationPath $zip -CompressionLevel Optimal -Force
    Write-Host "SUCCESS: $Matches matches collected"
    Write-Host "UPLOAD THIS ONE FILE: $zip"
    Start-Process explorer.exe -ArgumentList @('/select,', $zip) | Out-Null
} catch {
    Stop-Arena
    Write-Host "ERROR: $($_.Exception.Message)"
    exit 1
}
