STARTcraft AI v52 - path-based bunker defense

Install:
1. Close StarCraft, StarterBot, and Pluto.
2. Run upgrade_ai_v52.cmd.
3. Wait for: SUCCESS: AI v52 compiled and arena updated

Single match:
- Run the existing run_STARTcraft_vs_Pluto.cmd.

Automatic benchmark:
- Run run_5_matches_and_collect_v52.cmd once.
- It runs five matches, closes and restarts StarCraft, and collects every result.
- When finished, Explorer selects one v52_batch_*.zip file. Upload only that ZIP.
- Optional: run_5_matches_and_collect_v52.cmd 3 runs three matches.

Changes:
- Main bunker is placed beside the detected ground path/choke instead of using a straight enemy vector.
- Marines stage at the same path-based entrance.
- Keeps v51 stalled-build recovery and all v50 macro fixes.
- Construction log: AI_reports\AI_v52_construction.csv
