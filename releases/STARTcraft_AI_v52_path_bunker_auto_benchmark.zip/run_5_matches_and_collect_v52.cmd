@echo off
setlocal
cd /d "%~dp0"
set MATCHES=%~1
if "%MATCHES%"=="" set MATCHES=5
echo STARTcraft v52 automatic benchmark: %MATCHES% matches
echo Leave this window open. StarCraft will be restarted automatically.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\run_batch_v52.ps1" -Matches %MATCHES%
if errorlevel 1 (
  echo.
  echo BATCH FAILED. Send the ERROR line back.
)
pause
