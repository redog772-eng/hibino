local _, api = ...
api = api or {}
local forbidden = {"password", "passwd", "secret", "token", "license", "account", "credential", "username", "apikey", "api_key", "charkey", "battletag"}
local function safeKey(key)
    if type(key) ~= "string" or #key > 80 or not key:match("^[A-Za-z_][A-Za-z0-9_]*$") then return false end
    local lower = key:lower()
    if lower:gsub("guide", ""):find("guid",1,true) then return false end
    for _, word in ipairs(forbidden) do if lower:find(word,1,true) then return false end end
    return true
end
local function interesting(key)
    local lower = key:lower()
    if lower:find("wayfarerkoreanui",1,true)==1 then return false end
    return key=="NoName" or key=="NN" or lower:find("wayfarer",1,true) or lower:find("epic",1,true) or lower:find("devgather",1,true)
end
local function selectedField(key)
    local lower=key:lower()
    for _,word in ipairs({"path","nav","stuck","move","goal","train","equip","quest","state","running","pause","active","module","setting","profile","config","target","waypoint","recover","engine","trainer","inventory","loot","utils","api","skill","spell"}) do
        if lower:find(word,1,true) then return true end
    end
end
local function sortedKeys(value)
    local keys={}
    for key in pairs(value) do if safeKey(key) then keys[#keys+1]=key end end
    table.sort(keys)
    return keys
end
local function capture()
    local budget={entries=0,limit=1400,limited=false}
    local seen={}
    local function describe(value,depth)
        if type(value)~="table" or depth>2 or seen[value] then return nil end
        seen[value]=true
        local out={functions={},fields={},children={}}
        for _,key in ipairs(sortedKeys(value)) do
            if budget.entries>=budget.limit then budget.limited=true;break end
            local item=rawget(value,key)
            local kind=type(item)
            if kind=="function" then
                out.functions[#out.functions+1]=key;budget.entries=budget.entries+1
            elseif selectedField(key) then
                if kind=="boolean" or kind=="number" then
                    if kind=="number" and (item~=item or item==math.huge or item==-math.huge) then
                        out.fields[key]={type=kind,nonfinite_omitted=true}
                    else out.fields[key]={type=kind,value=item} end
                    budget.entries=budget.entries+1
                elseif kind=="table" then
                    local child=describe(item,depth+1)
                    if child then out.children[key]=child;budget.entries=budget.entries+1 end
                elseif kind=="string" then
                    -- Record only a type marker. A string could contain private configuration.
                    out.fields[key]={type="string",value_omitted=true};budget.entries=budget.entries+1
                end
            end
        end
        return out
    end
    local report={
        report_version=1,
        scope="WoW addon-visible globals and Wayfarer panel-owned fields only; missing exports may still exist in a private NN environment.",
        privacy="No credentials, GUID fields, license/config string values, file contents or function bodies collected. Character identity APIs are not called; class token and level only.",
        modules={},panel_objects={},capabilities={},character={},client={},
    }
    if type(UnitClass)=="function" then
        local ok,localized,token=pcall(UnitClass,"player")
        if ok and type(token)=="string" then report.character.class_token=token end
    end
    if type(UnitLevel)=="function" then local ok,value=pcall(UnitLevel,"player");if ok and type(value)=="number" then report.character.level=value end end
    if type(GetBuildInfo)=="function" then
        local ok,version,build,buildDate,interface=pcall(GetBuildInfo)
        if ok then
            if type(version)=="string" then report.client.version=version end
            if type(build)=="string" then report.client.build=build end
            if type(interface)=="number" then report.client.interface=interface end
        end
    end
    -- Existence/type check only. No movement, training, item or network operation is invoked.
    for _,name in ipairs({"ObjectPosition","Objects","ObjectFacing","Distance","GenerateLocalPath","GeneratePath","MoveTo","ClickToMove","MoveForwardStart","MoveForwardStop","FaceDirection","SetFacing","ObjectInteract","InteractUnit","BuyTrainerService","GetNumTrainerServices","GetTrainerServiceInfo","EquipItemByName","GetItemInfo","GetItemStats","GetInventoryItemLink","IsEquippableItem","IsUsableItem","Unlock"}) do
        report.capabilities[name]=type(rawget(_G,name))
    end
    for _,name in ipairs(sortedKeys(_G)) do
        if interesting(name) and type(rawget(_G,name))=="table" then
            local result=describe(rawget(_G,name),0)
            if result then report.modules[name]=result end
        end
    end
    if type(api.GetRoots)=="function" then
        for _,root in ipairs(api.GetRoots()) do
            local result=describe(root,0)
            if result then report.panel_objects[#report.panel_objects+1]=result end
        end
    end
    if type(api.GetRXPFeatures)=="function" then report.rxp=api.GetRXPFeatures() end
    report.entry_count=budget.entries
    report.scan_limited=budget.limited
    report.wayfarer_panels_found=#report.panel_objects
    WayfarerKoreanUIReport=report
    return report
end
api.CaptureDiagnostics=capture
