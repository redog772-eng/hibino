local _, api = ...
api=api or {}
local function profile()
    local rxp=rawget(_G,"RXP")
    if type(rxp)~="table" or type(rxp.settings)~="table" or type(rxp.settings.profile)~="table" then return nil end
    return rxp.settings.profile
end
function api.SetTrainerAutomation(value)
    local p=profile()
    if not p then return false,"RXPGuides가 준비되지 않았습니다." end
    p.enableTrainerAutomation=value==true
    return true,value and "RXPGuides의 기존 상급자 자동 학습을 켰습니다. 상급자 창을 열면 학습 목록에 따라 진행합니다." or "상급자 자동 학습을 껐습니다."
end
function api.SetEquipmentTips(value)
    local p=profile()
    if not p then return false,"RXPGuides가 준비되지 않았습니다." end
    p.enableItemUpgrades=value==true
    if value then p.enableTips=true end
    return true,value and "RXPGuides 장비 비교 안내를 켰습니다. /reload 후 아이템 설명을 확인하세요. 자동 착용 기능은 아닙니다." or "장비 비교 안내를 껐습니다."
end
function api.GetRXPFeatures()
    local p=profile()
    if not p then return {ready=false} end
    return {ready=true,trainer_automation=p.enableTrainerAutomation==true,equipment_tips=p.enableItemUpgrades==true,tips=p.enableTips==true}
end
