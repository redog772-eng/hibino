"""Local, opt-in setup for the user-provided relogger V9. No network access."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import time
import uuid

PACKAGE=Path(__file__).resolve().parent
BACKUPS='relogger-autologin-backups'
MARKER='.wayfarer-autologin-last-backup'

def normalized_hash(data):
    text=data.decode('utf-8-sig').replace('\r\n','\n')
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def atomic_write(path,data):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def load_config(root):
    path=Path(root)/'load_glue/account_data.json'
    obj=json.loads(path.read_text(encoding='utf-8-sig'))
    if isinstance(obj,list):
        if len(obj)!=1:raise ValueError('여러 계정 설정은 자동 수정하지 않습니다. 기존 파일을 유지했습니다.')
        row=obj[0]
    else:row=obj
    if not isinstance(row,dict):raise ValueError('지원하지 않는 계정 설정 형식입니다.')
    return obj,row

def apply(root,username,password,game_account,timeout):
    root=Path(root).resolve()
    if not isinstance(username,str) or not username.strip() or not isinstance(password,str) or not password:
        raise ValueError('이 PC에서 사용할 로그인 아이디와 비밀번호를 입력하세요.')
    timeout=int(timeout)
    if not 5<=timeout<=120:raise ValueError('대기 시간은 5~120초 사이로 입력하세요.')
    lua=root/'load_glue/reloggerV9.lua';config=root/'load_glue/account_data.json'
    original_lua=lua.read_bytes();original_config=config.read_bytes()
    manifest=json.loads((PACKAGE/'manifest.json').read_text(encoding='utf-8'))
    if normalized_hash(original_lua) not in (manifest['original_normalized_sha256'],manifest['patched_normalized_sha256']):
        raise ValueError('확인된 V9와 다른 로그인 스크립트입니다. 파일을 변경하지 않았습니다. reloggerV9.lua만 확인이 필요합니다.')
    replacement=(PACKAGE/'reloggerV9_patched.lua').read_bytes()
    if normalized_hash(replacement)!=manifest['patched_normalized_sha256']:
        raise ValueError('수정본 검증에 실패했습니다. 파일을 변경하지 않았습니다.')
    obj,row=load_config(root)
    row.update(enabled=True,logging=False,username=username.strip(),password=password,account=game_account.strip(),
               autoDismissConnecting=True,cancelConnectingAfter=timeout,preferCredentials=True,autoEnterWorld=False)
    if not isinstance(row.get('maxAttempts'),int) or isinstance(row.get('maxAttempts'),bool) or not 1<=row['maxAttempts']<=5:
        row['maxAttempts']=3
    # Keep original realm/slot settings for rollback, but this patch stops at character selection.
    row.setdefault('realmName','');row.setdefault('playerSlot',1);row.setdefault('waitBeforeEntering',30)
    encoded=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    name=time.strftime('%Y%m%d_%H%M%S_')+uuid.uuid4().hex[:8]
    backup=root/BACKUPS/name;backup.mkdir(parents=True,exist_ok=False)
    (backup/'reloggerV9.lua').write_bytes(original_lua)
    (backup/'account_data.json').write_bytes(original_config)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (backup/'reloggerV9.lua',backup/'account_data.json')}
    (backup/'backup_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
    try:
        atomic_write(lua,replacement);atomic_write(config,encoded)
        atomic_write(root/MARKER,name.encode('ascii'))
    except Exception:
        shutil.copyfile(backup/'reloggerV9.lua',lua)
        shutil.copyfile(backup/'account_data.json',config)
        raise
    return backup

def restore(root):
    root=Path(root).resolve();name=(root/MARKER).read_text(encoding='ascii').strip()
    if not re.fullmatch(r'\d{8}_\d{6}_[0-9a-f]{8}',name):raise ValueError('백업 기록 형식을 확인할 수 없습니다.')
    backup=root/BACKUPS/name
    hashes=json.loads((backup/'backup_hashes.json').read_text(encoding='utf-8'))
    manifest=json.loads((PACKAGE/'manifest.json').read_text(encoding='utf-8'))
    current=root/'load_glue/reloggerV9.lua'
    if normalized_hash(current.read_bytes())!=manifest['patched_normalized_sha256']:
        raise ValueError('설정 이후 로그인 스크립트가 변경되어 자동 복원을 중단했습니다. 백업은 그대로 있습니다.')
    saved={n:(backup/n).read_bytes() for n in ('reloggerV9.lua','account_data.json')}
    for n,data in saved.items():
        if hashlib.sha256(data).hexdigest()!=hashes.get(n):raise ValueError('백업 검증 실패: 원본 파일을 유지했습니다.')
    for n,data in saved.items():atomic_write(root/'load_glue'/n,data)
    return backup

def gui():
    import tkinter as tk
    from tkinter import filedialog,messagebox
    window=tk.Tk();window.title('Wayfarer 자동 로그인 설정');window.resizable(False,False)
    path=tk.StringVar(value=str(Path.home()/'Desktop/NoName_Release'))
    user=tk.StringVar();password=tk.StringVar();account=tk.StringVar();seconds=tk.StringVar(value='15')
    def load_existing():
        try:
            _,r=load_config(path.get());user.set(str(r.get('username','')));account.set(str(r.get('account','')))
        except Exception:pass
    def browse():
        selected=filedialog.askdirectory(title='load_glue 폴더가 들어 있는 NN 설치 폴더 선택')
        if selected:path.set(selected);load_existing()
    tk.Label(window,text='게임과 NN을 종료한 뒤 설정하세요. NNAV/9910 설정은 변경하지 않습니다.',wraplength=540).grid(row=0,column=0,columnspan=3,padx=16,pady=12)
    tk.Label(window,text='NN 설치 폴더').grid(row=1,column=0,sticky='w',padx=16)
    tk.Entry(window,textvariable=path,width=48).grid(row=1,column=1,padx=8)
    tk.Button(window,text='찾기',command=browse).grid(row=1,column=2,padx=12)
    for i,(label,var) in enumerate([('로그인 아이디',user),('로그인 비밀번호',password),('WoW 계정 선택명(필요 시)',account),('연결창 취소까지 대기(5~120초)',seconds)],start=2):
        tk.Label(window,text=label).grid(row=i,column=0,sticky='w',padx=16,pady=6)
        tk.Entry(window,textvariable=var,width=48,show='*' if var is password else '').grid(row=i,column=1,columnspan=2,sticky='w',padx=8)
    tk.Label(window,text='비밀번호는 NN 기본 계정 파일에 평문으로 저장됩니다.\n계정 파일과 백업을 다른 사람에게 보내지 마세요. 외부 전송 기능은 없습니다.',wraplength=540).grid(row=6,column=0,columnspan=3,padx=16,pady=12)
    def save():
        try:
            backup=apply(path.get(),user.get(),password.get(),account.get(),seconds.get());password.set('')
            messagebox.showinfo('설정 완료','자동 로그인을 설정했습니다.\nNN과 WoW를 다시 시작하세요.\n\n원본 백업: '+str(backup))
        except Exception as e:messagebox.showerror('설정 중단',str(e))
    def undo():
        if not messagebox.askyesno('원본 복원','마지막 설정 직전의 로그인 스크립트와 계정 파일로 복원할까요?'):return
        try:restore(path.get());messagebox.showinfo('복원 완료','마지막 설정 직전 파일로 복원했습니다.')
        except Exception as e:messagebox.showerror('복원 중단',str(e))
    tk.Button(window,text='자동 로그인 설정',command=save,width=22).grid(row=7,column=0,columnspan=2,pady=14)
    tk.Button(window,text='마지막 설정 원복',command=undo).grid(row=7,column=2,padx=12)
    load_existing();window.mainloop()

if __name__=='__main__':gui()
