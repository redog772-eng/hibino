@echo off
setlocal
cd /d "%~dp0"
py -3 setup_autologin.py
if errorlevel 1 (
  echo Setup failed. Python 3 with tkinter is required. Send the error above.
  pause
)
