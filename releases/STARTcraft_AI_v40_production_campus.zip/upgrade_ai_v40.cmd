@echo off
setlocal
cd /d "%~dp0"
py -3 install_ai_v40.py
if errorlevel 1 (
  echo.
  echo INSTALL FAILED. Copy the ERROR lines and send them back.
) else (
  echo.
  echo AI v40 installation finished.
)
pause
