"""Data-only exact-source patch installer. Run on the user's Windows PC."""
from pathlib import Path
from datetime import datetime
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zlib

PAYLOAD = 'eNqlV/tvm0gQ/lcoP6SQ0og3GNs55Xn1qddEidtKFyJrWRZnVRsQuzSx0vzvNwsE40caX24la4Gdxzcz386uH+VsFk/YHTIdVw5kxzasnmO6tmf6vkds10ginLjiUfd03Yx8ENAd304Isi3kJgQ7VpwYka5j3XN7sian5H5pz7YTB0dGDFYNnSQxiSNskgT5NvJcJ0aJb9pubCUednyU9GI76Vku1nuuF8UOMUywR2LKmRzc3BimbRm+JibP1mSpM2ii8EVOhsPj70eXoyD4mlI+hg8sCMakKFA6OUeYZ8VC+vUrTKXV8YrmNUdFnhVcfQxT+Va7EfEbuiYmx1/CeIP/HR33W7+e1xN+fVtfDb/8eDgllbaiviEHO6q3iVBbQD3dEoB6nlcDwlnKuERTLmUlJ8UVimnJhnmRxSXmNEuPSzqLaTr9w7QDBc9KBkLwel3m+WwhPlqO2oZrey5U27J921kN98Xxdg68yd56gWzdMgwNJtswu/nAd6jYl3LE74ZXoaycBGH4lZGC1VMYMrCDC5TwjyinYXg9ProaV+9heDSaFET4YNXzT1ufVDaLOp8HmP1UQ3kJwHddAaBnNwWBMgwGoQyECeXBYIrmpKr1eQFPJ1mZckUdDN5r75/XyAzljMRjOiftCsCbkur52Y3j9oSbapJhmVMsMR4HwRzlA6i+Br9DaSrgXlNOrggvFkcJ1LoF6vimrzXTGnPS7H64FWi/rhrsdRAZgHWrd3GfQh7vaF7JqVs8HuAZQUVXeYvQjSj0AbgbnSrq7SGYVwvCyyKVEjRjpEXtmqL/wCTibsy943RGDij7hmY0VlRpb+9V2lRsn5xCXbkqPS65WOeg0bvMGBUlluaIpkqTDsE4/jnDSKwo6nNUYiRZoaCSZxLGQSMtXDOQ6vp4Ro0xbAMJJqj5A2VCrv1A2Uk2z2eEk7j+Wn88ny1gr1ZfNvaPkGh7yLuXYwfDc5TGkxOSQt5/Y+kUMKEUE0WErw4cXVchPZymJemv6jS+xlCGNmcYfNAYcbJkUtV62tRtNgBRNO05jI4tRdUMV6t4oPY38tg6WmVA7RUWK6+fSEGWklrlKRILpNBgJ5PNCokRZdlMSoG8V4RlZYHJ8JmM65LrjMFVcpce1S06LV3mQZuivynsJvABlIHQ5iKQeYcee3vb2+Z8tWC1d3Vg2rq6Al+E+jsk0yWSP8lCNMgayLTK6A5Api8AcXcDIrZFV059FFt72KaxHxUE/eg/rWp2XpvHp7bVrPUGtVPlo9E3y7E+Z1MllL9cTK5H47NQXqMGKHdL92rjGkLj+mCYekdnrY018Jpu5nvitHJ7fuc2VXVgSAJh/LI9toeGXo3+a70KJqJUQT/sW+aHCp14/U5jfqeo+7CTdjp6KxOLFROfCJ3e8crG1rYXrXc9yH8kmBO9zBwl2u3mc4xgwj/YRr+K/t/FK/rvF6+u+madlPoUho6pbCxq0er2ELVaOUEgYY0+elCV+EGLF+qhaYsDYMuC4Yrkbng5dEx9s5912f7PxZezydXZX2cn47PTbZyHqwpcWxiNyWR5c5xgNM9LFsrrzWy3XQHNqDnFTc/34HYEE/z1qHnfJP64yLL4HhUfD3O4lPIEsB6NJLAeSEscUo1DgqYgkYccpazifXWk1+Dk29unfwFK//7U'
ROOT=Path(r'C:\Users\User\starcraft-api\STARTcraft')
MSBUILD=Path(r'C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\amd64\MSBuild.exe')

class BuildStillRunning(RuntimeError):pass

def sha(data):return hashlib.sha256(data).hexdigest()

def apply_patch(data):
    spec=json.loads(zlib.decompress(base64.b64decode(PAYLOAD)))
    if sha(data)!=spec['old_sha256']:
        raise RuntimeError('Expected exact v39 source; no files changed')
    previous_end=0
    for start,end,replacement in spec['edits']:
        if start<previous_end or end<start or end>len(data):
            raise RuntimeError('Invalid patch data')
        previous_end=end
    result=data
    for start,end,replacement in reversed(spec['edits']):
        result=result[:start]+replacement.encode('utf-8')+result[end:]
    if sha(result)!=spec['new_sha256']:
        raise RuntimeError('Patched source checksum failed; no files changed')
    return result

def atomic(path,data):
    temp=path.with_suffix(path.suffix+'.v40tmp');created=False
    try:
        with temp.open('xb') as stream:
            created=True;stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.replace(temp,path)
    finally:
        if created and temp.exists():temp.unlink()

def build(command,log):
    with log.open('wb') as output:
        proc=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT)
        try:
            code=proc.wait(timeout=480)
        except BaseException as original:
            # Stop only this compiler process tree before restoring old outputs.
            try:
                subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],
                    stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT,timeout=30)
                proc.wait(timeout=30)
            except BaseException as stop_error:
                if proc.poll() is None:
                    raise BuildStillRunning(
                        'MSBuild is still running (PID '+str(proc.pid)+'). '
                        'Files were not restored while it may be writing. '
                        'Close MSBuild, then rerun this installer to recover safely.') from stop_error
            raise original
        if code:raise RuntimeError('MSBuild failed; see '+str(log))

def main():
    src=ROOT/'src/starterbot/StarterBot.cpp';exe=ROOT/'bin/StarterBot.exe'
    sln=ROOT/'visualstudio/STARTcraft.sln';log=ROOT/'AI_v40_build.log'
    for path in (src,exe,sln,MSBUILD):
        if not path.is_file():raise RuntimeError('Missing file: '+str(path))
    new=apply_patch(src.read_bytes())
    if '--check-only' in sys.argv:
        print('CHECK OK: v39 -> v40; nothing changed');return
    status=subprocess.run(['tasklist','/FO','CSV','/NH'],capture_output=True,check=True)
    if any(name in status.stdout.lower() for name in [b'"starcraft.exe"',b'"starterbot.exe"']):
        raise RuntimeError('Close StarCraft and StarterBot first; no files changed')
    backup=ROOT/'ai_backups'/('before_v40_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    backup.mkdir(parents=True,exist_ok=False)
    for path in (src,exe):
        shutil.copy2(path,backup/path.name)
        if sha(path.read_bytes())!=sha((backup/path.name).read_bytes()):
            raise RuntimeError('Backup verification failed; no source changes')
    print('Backup:',backup,flush=True)
    command=[str(MSBUILD),str(sln),'/t:Rebuild','/m:2','/nologo',
        '/p:Configuration=Release','/p:Platform=Win32','/p:PlatformToolset=v145',
        '/p:WindowsTargetPlatformVersion=10.0.26100.0']
    try:
        atomic(src,new)
        build(command,log)
        output=exe.read_bytes()
        if sha(output)==sha((backup/exe.name).read_bytes()) or b'AI v40: production campus and expansion supply' not in output:
            raise RuntimeError('New EXE version could not be verified')
        atomic(ROOT/'ai_backups/v40_last_backup.txt',str(backup).encode('utf-8'))
    except BaseException as error:
        if isinstance(error,BuildStillRunning):
            print('NOT RESTORED: compiler may still be writing; backup is safe at',backup)
            raise
        atomic(src,(backup/src.name).read_bytes())
        atomic(exe,(backup/exe.name).read_bytes())
        print('RESTORED: v39 source and EXE. Build log:',log)
        raise
    print('SUCCESS: AI v40 compiled')
    print('Start a NEW match with your existing run_ai_v35_3.cmd')
    print('After the match, upload AI_reports/AI_v40_construction.csv')

if __name__=='__main__':
    try:main()
    except BaseException as error:
        print('ERROR:',error);sys.exit(1)
