STARTcraft AI v40

1. Close StarCraft and StarterBot completely.
2. Extract this ZIP.
3. Double-click upgrade_ai_v40.cmd.
4. Confirm: SUCCESS: AI v40 compiled
5. Start a new match with the existing run_ai_v35_3.cmd.

This installer requires the exact v39 source. It backs up StarterBot.cpp and StarterBot.exe and restores both if the build fails.
